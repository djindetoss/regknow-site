# How to use this pack

1. Upload the other files in this pack as sources in NotebookLM, or as project knowledge in Claude.
   Don't upload this file: paste the text below into the project's instructions instead.
   NotebookLM has no such setting, so paste it at the start of your question if you need it.
2. Check that the files you upload are ones you're allowed to share with that service.

## Instructions to paste

Answer only from the uploaded documents. Cite each claim with the document title and the page or
section, using the "Page" and "Section" headings in the files. If the documents don't contain the
answer, say so instead of using outside knowledge. Mention the status and date of any legal text
you rely on, because a newer version may exist outside these documents.
