# Identification of Potential Tryptase Inhibitors from FDA-Approved Drugs Using Machine Learning, Molecular Docking, and Experimental Validation

- **Authors:** Muhammad Yasir, Jinyoung Park, Eun-Taek Han, Won Sun Park, Jin-Hee Han, Wanjoo Chun
- **Issuer:** ACS omega
- **Type:** Scientific article
- **Published:** 2024-09-04
- **Language:** en
- **DOI:** 10.1021/acsomega.4c04886
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39310179/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

This study explores the innovative use of machine learning (ML) to identify novel tryptase inhibitors from a library of FDA-approved drugs, with subsequent confirmation via molecular docking and experimental validation. Tryptase, a significant mediator in inflammatory and allergic responses, presents a therapeutic target for various inflammatory diseases. However, the development of effective tryptase inhibitors has been challenging due to the enzyme’s complex activation and regulation mechanisms. Utilizing a machine learning model, we screened an extensive FDA-approved drug library to identify potential tryptase inhibitors. The predicted compounds were then subjected to molecular docking to assess their binding affinity and conformation within the tryptase active site. Experimental validation was performed using RBL-2H3 cells, a rat basophilic leukemia cell line, where the efficacy of these compounds was evaluated based on their ability to inhibit tryptase activity and suppress β-hexosaminidase activity and histamine release. Our results demonstrated that several FDA-approved drugs, including landiolol, laninamivir, and cidofovir, significantly inhibited tryptase activity. Their efficacy was comparable to that of the FDA-approved mast cell stabilizer nedocromil and the investigational agent APC-366. These findings not only underscore the potential of ML in accelerating drug repurposing but also highlight the feasibility of this approach in identifying effective tryptase inhibitors. This research contributes to the field of drug discovery, offering a novel pathway to expedite the development of therapeutics for tryptase-related pathologies.

## Section: Introduction

Mast cells are central to the body’s immune response to external antigens and are predominantly found in vascularized tissues such as the mucosal and epithelial layers of the gastrointestinal tract, skin, and respiratory tract.1−3 These cells, when activated by various stimuli, release a range of inflammatory mediators from their cytoplasmic granules.4 This release can lead to the development of various inflammatory disorders, including asthma, atopic dermatitis, and severe anaphylactic shock.5−7 Among the diverse molecules stored in these granules are histamine, heparin, cytokines, and a spectrum of proteases, with tryptase being the most abundant protease present in human mast cells.8

Tryptase, a member of the trypsin family of proteases, is a tetrameric enzyme. It is composed of four catalytic subunits that together form a distinctive ring-like structure, with the active sites facing an oval-shaped central pore.9 This unique structural arrangement is crucial for its biological function. The role of tryptase in inflammatory and allergic responses has been extensively documented, highlighting its significance as a potential therapeutic target for a variety of inflammatory diseases.10−12 Its involvement in biological processes such as fibrosis, angiogenesis, and immune response modulation further emphasizes its clinical importance.5,13 Despite the critical role of tryptase in these processes, the development of effective inhibitors has been a complex challenge, mainly due to the intricate mechanisms governing its activation and regulation.13 Addressing this challenge requires a nuanced understanding of tryptase’s structure and function, as well as innovative approaches to inhibit its activity.

Given the complexity and resource-intensive nature of developing new drugs, drug repurposing, also known as drug repositioning, emerges as a promising strategy.14,15 Drug repurposing involves identifying new therapeutic applications for already approved drugs beyond their original intended uses.16 This approach can significantly accelerate the drug development process, augmenting the value of existing drugs and potentially offering new treatment avenues for diseases that currently lack effective therapies.17,18 Importantly, in the context of tryptase inhibitors, drug repurposing can provide new treatments for inflammatory diseases, aligning with the need for efficient and rapid therapeutic development. This approach holds significant potential in addressing unmet medical needs related to tryptase-related conditions.

Computational study, or computer-aided drug design (CADD), is now a crucial component in drug discovery and development.19−21 CADD utilizes computational methods and software for rapid and efficient screening of large compound libraries, offering a more time- and cost-effective alternative to traditional experimental approaches.22,23 This approach dramatically reduces the need for synthesizing and experimentally testing numerous compounds, allowing for the virtual screening of thousands of compounds.

Machine learning (ML), a subset of artificial intelligence, is another transformative force in drug development.24 It enables computers to learn from data, predict outcomes, and make decisions autonomously.25 ML excels in analyzing vast and complex data sets, identifying new drug targets, predicting drug efficacy, and optimizing drug properties. Within the sphere of machine learning techniques utilized in drug discovery, the Random Forest regression algorithm stands out for its efficacy and reliability.26−28 This algorithm operates by constructing a multitude of decision trees during training and outputting the mean prediction of the individual trees. This ensemble approach makes it exceptionally good at handling large data sets with numerous input variables, a common scenario in drug development. Random Forest is particularly adept at identifying complex, nonlinear relationships within data, making it suitable for predicting drug efficacy and toxicity. Its robustness against overfitting, even with relatively small data sets, is a significant advantage in the early stages of drug discovery.29,30 Moreover, the algorithm provides insights into feature importance, enabling researchers to identify key molecular descriptors and biological properties that are most predictive of a drug’s performance.31

In this study, we employed an ML-based model, trained using a reference library of known tryptase inhibitors, to screen an FDA-approved drug library to identify potential tryptase inhibitors. The candidate compounds were further analyzed using molecular docking. Subsequent biological examination was conducted to validate these candidates. This approach, leveraging drug repositioning, has the potential to yield novel tryptase inhibitors, contributing significantly to the field of inflammatory disease treatment.

## Section: Results and Discussion

Figure 1 illustrates the workflow that integrates machine learning algorithms, molecular docking experiments, and experimental validation approaches for drug repurposing of novel tryptase inhibitors. The study followed a seven-step process: (1) Extraction of molecular features from the reference data set using RDKit, (2) Training of machine learning algorithm, (3) Screening of an FDA-approved drug library to identify lead compounds, (4) Retrieval of tryptase 3D structure and preparation of ligands, (5) Conducting molecular docking for ligand-protein complexes, (6) Experimental validation of candidates through cell culture studies, (7) Analysis of results to assess the performance of repositioning of FDA-approved drug candidates as novel tryptase inhibitors.

Workflow diagram of the predicted research study.

## Section: Machine Learning Regression Analysis of the Tryptase Reference Data Set

Utilizing the RDKit toolkit, nine distinct molecular descriptors were computed for a data set of 168 compounds, known as the tryptase reference data set. This data set was subsequently partitioned into a training set and a test set, with the training set comprising 80% of the data, and the remaining 20% split evenly between two test sets (8:1:1). The training set was then subjected to Random Forest Regression to develop a predictive model. The model’s performance was assessed by applying it to the test set of the tryptase reference data set. In Figure 2A, a visual representation is provided that illustrates the relationship between the experimentally determined pIC50 values and those predicted by a custom-built regression model. The assessment of this regression model’s accuracy was conducted by computing the Mean Squared Error (MSE) and the regression coefficient, utilizing the scikit-learn library. The analysis yielded an MSE of 0.806 and a regression coefficient of 0.83. Considering the inherent variability in pIC50 values, which stem from diverse experimental methodologies, these metrics were deemed acceptable.

(A) Correlation of experimental pIC50 values with predicted pIC50 values with the regression model. (B) Illustration of the feature importance values.

## Section: Molecular Descriptor’s Contribution in Regression Prediction

To gain insight into the influence of individual descriptors on the regression model, the Random Forest Regression tool was employed to determine the importance of each feature. Feature importance serves as an indicator of the extent to which each descriptor affects the model’s predictive accuracy. Descriptors with greater importance scores are deemed to have a more significant effect on the pIC50 prediction, whereas those with lower scores are considered to have a lesser impact. Among nine molecular descriptors evaluated, including molecular weight, LogP value, counts of hydrogen bond donors and acceptors, the proportion of sp3 hybridized carbon atoms (CSP3), the number of aromatic bonds, ring count, topological polar surface area (TPSA), and the number of aromatic rings, the CSP3 descriptor emerged as the most influential in predicting pIC50 values. Following closely in importance were the TPSA and molecular weight descriptors (Figure 2B).

## Section: Prediction of pIC50 Values of FDA-Approved Drug Library Data Set

Following the development of the regression model using the tryptase reference data set, the prediction of the pIC50 value of an FDA-approved drug library data set was carried out. The molecular descriptors of 3,105 drugs were computed utilizing the RDKit toolkit. The regression model was utilized to predict pIC50 values by applying the data set of molecular features from the FDA-approved drug library. The predictions for FDA-approved drugs ranged from 4.676 M to 8.926. Drugs predicted to have high pIC50 values, specifically those above 8.2, are detailed in Table 1. To delve deeper into the effectiveness of these compounds in inhibiting tryptase, molecular docking studies and molecular dynamics (MD) simulations were conducted with the compounds having predicted pIC50 values of greater than 8.0, which corresponds to 10 nM in IC50 values. Considering the absence of any FDA-approved tryptase inhibitors, APC-366, a compound currently under investigation as a tryptase inhibitor, was used as a positive reference in computational and experimental evaluations.

## Section: Structural Analysis of the Tryptase Protein

Tryptase holds the distinction of being the most abundant serine proteinase derived from secretory granules within mast cells. Its presence has been utilized as a marker for mast cell activation.32 It is made up of 245 amino acids forming a single chain (PDBID: 2GDD). The protein exhibits a complex structure involving loops, α-helices, and β-sheets, contributing to its overall conformation. Furthermore, a VADAR 1.8 structural study revealed that tryptase is made up of 8% α-helices, 45% β-sheets, 46% coils, and 30% turns. Based on the Ramachandran plots, 94.6% of amino acids were situated within the favored region, while 100% of residues fall within the allowed zone of dihedral angles phi (φ) and psi (ψ) (Figure S1).

## Section: The Binding Pocket Analysis

The functional attributes of a binding pocket are influenced not only by its geometry and position within a protein but also by the particular amino acid residues that encircle it.33 In this study, the binding pocket residues were identified using the Discovery Studio ligand interaction approach, and compared to already available data (PBID: 2GDD) revealing Val35, Phe41, Cys58, Lys60, Leu64, Asp189, Gln192, Gln195, Ser214, Trp215, Gly219, and Gly226 as the active site amino acid residues. The cocrystallized ligand was utilized to construct the binding sphere, focusing on our selected binding pocket residues the sphere was contracted. Therefore, the sphere’s dimensions were adjusted to X = 13.4387, Y = 57.5649, and Z = 70.0616, with a fixed radius of 11.3075. These parameters were set to investigate the interaction of screened compounds against the tryptase active site (Figure 3).

(A) This panel shows the spatial positioning of the tryptase active site. The enzyme’s structure is represented as a ribbon in aquamarine, with the binding site surface highlighted in coral. (B) This panel focuses on the key residues within the active region of tryptase, crucial for ligand binding. Notably, the catalytic triad, consisting of His57, Asp102, and Ser195, is highlighted to emphasize its role in the enzyme’s activity. Additional crucial amino acids for ligand binding, including Gly193, Ser195, Asp194, Ser214, Ser190, and Asp189, are also emphasized.

## Section: Molecular Docking Analysis

The CDocker module within Discovery Studio was employed to forecast negative energy values, specifically CDocker energy and CDocker interaction energy. CDocker energy encapsulates the overall docking energy, which is derived from the 3D structural and physiochemical attributes of both the ligand and the protein. In contrast, CDocker interaction energy focuses exclusively on the energy related to the interactions between the ligand and the receptor. This encompasses the contributions from various intermolecular forces, such as van der Waals forces, electrostatic complementarity, and hydrogen bonding, all of which contribute to the binding affinity. CDocker Interaction Energy provides a granular understanding of the strength and character of the individual interactions between the ligand and the receptor.34 During the docking analysis of all screened compounds with tryptase, each compound underwent individual scrutiny and scoring based on minimal docking energy values. This comprehensive evaluation aimed to identify compounds with favorable binding characteristics and promising interactions within the active site of tryptase (Table 2). The results revealed that several screened drugs demonstrate more negative docking energy scores as compared to the reference APC-366, emphasizing the potential superiority of the identified ligands. All the docket compounds are sorted according to the lowest docking energy values. Furthermore, these compounds already have known activities instead of tryptase and could be a possible inhibitor of tryptase too.

## Section: Selection of Highly Predicted Drugs

From the tryptase inhibitors identified through molecular docking analysis, the top seven drugs along with the reference compound APC-366 (Figure 4) were chosen for in-depth investigation. This included analyses of binding modes and experimental evaluation. Enalapril, a prodrug of enalaprilat, was also included in this selection. Although it did not rank highly in the predictive analysis, its selection was influenced by the practical consideration of enalaprilat’s limited availability for experimental analysis. Laninamivir, known for inhibiting influenza neuraminidase, also appears to block tryptase, suggesting dual action that may enhance its antiviral effects. While neuraminidase inhibitors like laninamivir prevent virus spread by stopping the release of new viruses from cells, tryptase, released from mast cells, activates influenza hemagglutinin. This is significant, although some deadly influenza strains activate hemagglutinin differently. Our hypothesis about laninamivir’s dual inhibition remains speculative, based on in vitro results, and requires further exploration to understand its full antiviral potential.

Structures of highly predicted tryptase inhibitors from molecular docking with the reference compound of APC-366.

## Section: Binding Interaction Analysis

The binding interaction analysis was conducted to discern the specific interactions and their types with the active region amino acid residues of the tryptase protein. This analysis aimed to determine whether the ligands bound effectively within the active binding pocket. Additionally, the identification of hydrogen bonds and salt bridges was part of this approach. The results indicated that APC-366, aliskiren, citocoline, cidofovir, enalaprilat, landiolol, and laninamivir successfully bound to the active binding pocket of the target protein, demonstrating favorable interactions as shown in Figure 5.

The APC-366 ligand–receptor complex demonstrates five hydrogen bonds with His57, Lys60, Cys58, Cys42, and Phe41. The oxygen atom of the ligand made a hydrogen bond with Lys60 with a bonding distance of 2.04 Å. A hydrogen atom of ligand formed two hydrogen bonds against His57 and Cys58 with bond lengths of 2.46 and 2.84 Å. Furthermore, another hydrogen atom formed two hydrogen bonds against Phe41 and Cys42 with bonding distances of 2.53 and 2.80 Å respectively. The aliskiren docking interaction analysis to the target protein exhibited that the ligand bind in the active region of the tryptase and manifested four hydrogen bonds with the active region amino acids. The four different hydrogen atoms of the ligand formed hydrogen bonds against Cys58, Cys42, and Phe41 with bonding distances of 2.06 Å, 2.06 Å, 2.27 Å, and 2.14 Å respectively.

The citocoline compound docked to tryptase demonstrated five hydrogen bonds against four different amino acids Lys60, His 57, Cys58, and Gly193. The two oxygen atoms of the ligand form 2 hydrogen bonds with the same Lys60 with bonding distances of 1.74 Å, and 1.86 Å. Furthermore, two other oxygen atoms of ligand formed hydrogen bonds against His57 and Gly193 with bond lengths of 2.15 and 2.32 Å respectively. Moreover, the hydrogen atom of the ligand forms a hydrogen bond against Cys58 with a bond length of 1.98 Å. The cidofovir compound docked to tryptase depicted three hydrogen bonds and one salt bridge against the target protein. Two oxygen atoms of ligand formed two hydrogen bonds against Phe41 and Ser195 with bond lengths of 2.08 and 2.16 Å respectively. Furthermore, another hydrogen atom of the ligand formed a hydrogen bond against the binding pocket residues Cys58 with a bonding distance of 2.14 Å. Moreover, an oxygen atom of ligand formed a salt bridge against Lys60 with a bonding distance of 1.83 Å.

The enalaprilat-tryptase docked complex demonstrated three hydrogen bonds in the docking interaction analysis. Two different oxygen atoms of ligand formed two hydrogen bonds with different amino acid residues of binding pocket Ala97 and Lys60 with bond lengths of 2.25 and 2.35 Å respectively. Furthermore, a hydrogen atom of ligand formed a hydrogen bond against His57 with a bonding distance of 1.87 Å. Landiolol with a molecular weight of 509.6 g/mol occupied the extensive space in the active binding pocket of tryptase and exhibited four hydrogen bonds against the active region amino acids of the target protein. Three hydrogen atoms of landiolol formed hydrogen bonds against Ser195, Gln192, and Gly216 with bonding distances of 2.43 Å, 2.38 Å, and 2.43 Å respectively. Moreover, the oxygen atom of landiolol formed a hydrogen bond against Gly216 with a bonding distance of 2.43 Å. Laninamivir binds in the active region of tryptase and forms four hydrogen bonds against the active region of the target protein. The hydrogen atom of the ligand formed a hydrogen bond against Gly60 with a bond length of 1.79 Å. Furthermore, two hydrogen atoms formed two hydrogen bonds with the same amino acid residue His57 with bonding distances of 2.26 and 2.12 Å. Moreover, an oxygen atom of the ligand establishes a hydrogen bond with the aforementioned His57, with a bonding distance of 3.05 Å.

The 3D interactions between the ligand and the active region amino acids of tryptase. The hydrogen bond interaction and interacting amino acids are colored red, the salt bridges and salt bridge forming amino acids are colored cyan, and the other interacting amino acids are colored black.

## Section: Experimental Validation

RBL-2H3 cell line, derived from rat basophilic leukemia cells, possess key characteristics with mast cells, notably the capacity to degranulate and release inflammatory mediators such as histamine and cytokines upon specific stimulation. This makes RBL-2H3 cells an optimal model for studying mast cell activation, signaling pathways, and the effects of various agents on mast cell functionality.35,36 To induce mast cell activation, we exposed RBL-2H3 cells to known mast cell activators; phorbol myristate acetate (PMA) and calcium ionophore A23187. The effectiveness of activation was quantitatively assessed by measuring two primary markers of mast cell degranulation: the activity of β-hexosaminidase and the release of histamine. These markers are indicative of the degranulation process and the inflammatory response of mast cells. Additionally, in our experiments, we included nedocromil, an FDA-approved mast cell stabilizing agent, as a reference compound. The exact mechanism of action of nedocromil is not fully understood, but its established role in mast cell stabilization makes it a suitable reference. This was particularly pertinent given that APC-366 is an investigational tryptase inhibitor and there are currently no FDA-approved tryptase inhibitors available. Highly predicted drugs demonstrated significant suppression of both β-hexosaminidase activity (Figure 6A) and histamine release (Figure 6B) in RBL-2H3 cells challenged with PMA/A23187. These effects were observed to be similar in extent to those achieved by APC-366 and nedocromil. Most notably, the highly predicted drugs also significantly inhibited tryptase activity to the same extent as APC-366 and nedocromil (Figure 6C). Notably, tryptase inhibitors significantly reduced the release of histamine and β-hexosaminidase, in addition to inhibiting tryptase activity. Previous studies have demonstrated that tryptase inhibitors, such as APC366-also used in our study-effectively decrease not only tryptase activity but also other markers of mast cell activation.37,38 These findings suggest that tryptase may amplify mast cell activation, and its inhibition can consequently attenuate the overall mast cell response. However, additional research is needed to elucidate the specific mechanisms by which tryptase influences the degranulation process during mast cell activation. Nedocromil demonstrated a reduction in tryptase activity, which is likely attributable to its mast cell stabilizing properties, leading to decreased tryptase release, as opposed to a direct inhibitory effect on tryptase. This contrasts with other tested compounds that directly inhibited released tryptase during the mast cell activation process. These results are particularly significant as they suggest that these highly predicted drugs have the potential to serve as novel tryptase inhibitors.

Inhibition of PMA/A23187-induced β-hexosaminidase activity (A), histamine release (B), and tryptase activity (C) in RBL-2H3 cells.

## Section: Structural Evaluation and Similarity Comparison

To evaluate the structural resemblance among the drugs that were highly predicted by both experimental and computational data, the Tanimoto similarity measure was applied using RDKit. This metric is crucial for comparing the similarity and diversity among compounds. The Tanimoto coefficient ranges from 0 to 1, where 0 indicates no similarity and 1 indicates complete similarity. Although there is no universally accepted threshold for similarity, a Tanimoto coefficient of 0.4 generally signifies a moderate level of similarity. This means the compounds share certain features but also possess significant differences (Figure S2A, and S2B)). With a Tanimoto similarity value around 0.4 certain drug groups were identified: APC-366, agatroban, and enalaprilat formed one group; laninamir and agatroban another; and citocholine, agatroban, and cidofovir yet another. Despite these groupings, no overarching similarity was found across all highly predicted drugs (Table S1).

Despite the limited overall similarity of the highly predicted drugs to APC-366, the possibility of shared specific structural features is still present. To investigate this further, the Maximum Common Substructure (MCS) algorithm was employed within RDKit, with a threshold of 0.5 set for the analysis. This led to the identification of common substructures among APC-366, agatroban, aliskiren, enalapril, and enalaprilat, which were highlighted in green color (Figure S2A). Notably, APC0366, argatroban, enalapril, and enalaprilat shared an N-(3-phenylproppyl) methylamine group in their structures, a feature absent in other drugs. This suggests that inhibitory activity against tryptase may involve factors beyond structural motifs, potentially including spatial arrangement or specific conformations. Additionally, similarity maps generated using RDKit’s fingerprints assessed if the highly predicted drugs shared structural motifs with APC-366 (Figure S2B). The similarity maps revealed the extent to which APC-366’s structural motif was present in the chemical structures of the highly predicted drugs. The insights gained from both MCS and similarity map analyses are instrumental in guiding further optimization of the drugs.

## Section: Methodology › Tryptase Inhibitor Reference Data Set and FDA-Approved Drug Library

The reference data set of human tryptase inhibitor consists of 168 compounds, each with experimentally determined IC50 values. This data set was sourced from the ChEMBL database (https://www.ebi.ac.uk/chembl), specifically under the ChEMBL ID CHEMBL2095193. ChEMBL is a manually curated database known for its collection of bioactive molecules with drug-like properties. In the data set, all molecules are represented as canonicalized SMILES strings and IC50 values. For more efficient data representation and analysis, the IC50 values were converted to pIC50 values. The pIC50, which is the negative logarithm of the IC, ranges from 4.48 to 9.40. This corresponds to an IC range from 33,000 nM to 0.4 nM. Furthermore, an FDA-approved drug library was obtained from Selleck Chemicals (https://www.selleckchem.com). This library is comprised of 3,105 compounds. These FDA-approved drug molecules were initially in SDF (structure-data file) format and were converted to SMILES strings using RDKit.

## Section: Methodology › Molecular Descriptor Generation Using RDKit

To evaluate the molecular properties of compounds, the RDKit (https://www.rdkit.org) platform was utilized. This open-source cheminformatics and machine learning framework, developed in Python, is adept at handling small molecule data. It offers a suite of features for processing and interpreting chemical structures, including tools for generating molecular descriptors, chemical features, and visualizing chemical data.39 Therefore, the RDKit was employed to compute a set of nine molecular descriptors for both a tryptase reference data set and an FDA-approved drug library. These descriptors encompassed a range of molecular properties such as molecular weight, LogP value, number of hydrogen bond donors and acceptors, the proportion of sp3 hybridized carbon, the total number of aromatic bonds, ring count, topological polar surface area (TPSA), and the count of aromatic rings.

## Section: Methodology › Machine Learning Architecture

The analysis of the tryptase reference data set incorporated machine learning techniques via scikit-learn (https://scikit-learn.org), a Python-based, open-source library designed for efficient and straightforward data analysis and mining. This library encompasses various algorithms for tasks such as regression, classification, clustering, dimensionality reduction, and model selection.40 For this study, The data set was split into a training set and a test set in an 8:2 proportion. The molecular descriptors within the test set underwent training using the Random Forest Regression algorithm from the scikit-learn toolkit. Random Forest Regression, an ensemble learning approach, aggregates the outputs of numerous decision trees to enhance the model’s precision and reliability (https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestRegressor.html). Upon completion of the training phase with the training data set, the model’s accuracy was evaluated using the test data set, focusing on metrics like mean squared error and the regression coefficient. Additionally, the relative influence of each descriptor was quantified through feature importance values.41,42 To predict pIC50 values for the FDA-approved drug data set, we calculated its molecular descriptors using RDkit as with the tryptase reference data set and then applied these molecular descriptors to the Random Forest Regression model.

## Section: Methodology › Tryptase Structure Retrieval

Human beta 2 tryptase (TPSB2) exists in a tetrameric form, composed of four identical subunits. The 3D structure of tryptase protein was examined using the A subunit from the crystal structure identified as PDBID: 2GDD, which has a resolution of 2.35 Å, from the Protein Data Bank (PDB) (https://www.rcsb.org/structure/2GDD). To refine the structure for the analyses, energy minimization was employed using UCSF Chimera software. The tryptase protein, composed of α-helices, β-sheets, and turns, underwent a quantitative analysis of its structure using the VADAR (http://vadar.wishartlab.com/) Internet server.43 Additionally, the Ramachandran plots were generated using Discovery Studio.44 Moreover, the same tool was utilized to investigate the 3D structure of the protein.

## Section: Methodology › Prediction of Active Binding Site

The placement of a ligand within the protein’s holo-structure is a strong indicator of the targeted protein’s binding pocket.45,46 The tryptase inhibitor complex was obtained from the PDB (PDB ID: 2GDD). To ensure the precision of binding site selection, interacting amino acids were chosen using the ligand interaction feature of Discovery Studio. As a result, the cocrystallized ligand was selected, and the binding sphere was established using the current selection method within the define binding site window of Discovery Studio. Subsequently, the binding sphere was reduced to be confined to the chosen amino acids.

## Section: Methodology › Molecular Docking

Molecular docking stands as one of the most extensively employed methods for assessing the interactions and conformations of ligands with target proteins.47,48 Certainly, scoring algorithms in molecular docking enable the estimation of association strength or binding affinity between two molecules by assessing their preferred orientation. This predictive capability enhances our understanding of molecular interactions and aids in identifying potential ligands for target proteins.33 The protein underwent preparation steps before molecular docking, involving the removal of water molecules and the cocrystallized ligand by UCSF Chimera. Additionally, hydrogen atoms were added to the protein using Discovery Studio’s protein preparation approach. Ligand preparations for both screened and reference compounds were conducted, involving tautomer generation, ionization adjustments, and addressing bad valencies through Discovery Studio’s ligands preparation module. Subsequently, the CDOCKER module of Discovery Studio was utilized to carry out molecular docking of the screened FDA candidate compounds against tryptase, with default orientation and conformation settings at 10/10. Each chosen compound underwent molecular docking against tryptase, and the top hits were selected based on the lowest binding energy values (in kcal/mol) to identify the best-docked complexes.

## Section: Methodology › Binding Interaction Analysis

The top docked complexes, along with APC-366 as a reference drug, were subjected to three-dimensional (3D) graphical analysis using UCSF Chimera49 and Discovery Studio. This analysis aimed to comprehensively study the interactions between ligands and the target protein, providing insights into the spatial arrangement and binding characteristics of the compounds within the protein’s active site.

## Section: Methodology › Experimental Reagents and Cell Culture

Cidofovir dihydrate was acquired from GLPBIO (#GC13936, MONTCLAIR, USA). All other chemicals required for the experiment were procured from Sigma-Aldrich, located in St. Louis, MO, USA. The RBL-2H3 cells were acquired from the Korea cell line bank (KCLB), with the catalog number 22256 (RBL-2H3). The RBL-2H3 cells were cultured in RPMI 1640 medium (Hyclon Laboratories), supplemented with 10% heat-inactivated fetal bovine serum and 100 U/ml of penicillin-streptomycin (Gibco). The cells were maintained at 37 °C in an atmosphere containing 5% CO2.

## Section: Methodology › β-Hexosaminidase (β-HEX) Activity and Histamine Release Assay

To assess the impact of chemicals on degranulation, we quantified the levels of β-HEX activity and histamine release. This enzyme is found within the granules of mast cells and is commonly used as a marker for granule content.50 RBL-2H3 cells were grown in 12-well plates for a duration of 24 h. The medium was then discarded, and the cells were treated with 0.1 μM of inhibitors diluted in PIPES buffer for 1 h at 37 °C. Following this pretreatment, the cells were washed twice with PIPES buffer and subsequently stimulated with 50 nM of PMA and 1 μM of A23187 for 30 min at 37 °C. A 20 μL aliquot of the supernatant was then allowed to react with 80 μL of substrate buffer (containing 2 mM 4-p-nitrophenyl-N-acetyl-β-d-glucosaminide in 0.05 M sodium citrate buffer, pH 4.5) for 30 min at 37 °C. The reaction was halted by the addition of 200 μL of stop buffer (0.1 M NaHCO3, pH 10). The absorbance was measured at 405 nm using a microplate spectrophotometer (SpectraMax M5, Molecular Devices, USA). The concentration of histamine was determined using the o-phthalaldehyde (OPT) spectrofluorometric method.51 To each well’s 0.5 mL of supernatant, 0.1 mL of 1 M NaOH and 25 μL of OPT (1% weight/volume in methanol) were added. The mixture was then incubated for 4 min at room temperature. The reaction was terminated by adding 50 μL of 3 M HCl. The absorbance was measured at excitation and emission wavelengths of 360 and 450 nm, respectively, using a microplate spectrophotometer (SpectraMax M5, Molecular Devices, USA).

## Section: Methodology › Tryptase Inhibition Activity Assay

Tryptase activity was measured using the Tryptase Activity Assay kit from Tribioscience (#TBS2101, Tribioscience, USA) following the manufacturer’s instructions. To prepare cellular tryptase, RBL-2H3 cells were detached from the culture plate. After detaching the cells, wash them and adjust the cell concentration to 1.0 × 107 cells/mL with 1X assay buffer. The suspended cells were incubated in the presence of the 0.1 μM of inhibitors for 1 h and then stimulated with 50 nM of PMA and 1 μM of A23187 for 30 min at 37 °C in a 5% CO2 incubator. The cell suspension was centrifuged at 700 X g, and the supernatant was carefully collected. For the tryptase inhibition activity assay, the assay mixture was made by adding 50 μL of supernatant to 130 μL of assay buffer. The colorimetric reaction was initiated by adding 20 μL of the tryptase substrate. The reactions were observed at 405 nm in kinetic mode for a duration of 60 min at 37 °C using a microplate spectrophotometer (Molecular Devices, San Jose, CA, USA). Each assay was conducted in triplicate.

## Section: Methodology › Statistical Analysis

All values presented in the figures are depicted as the mean ± standard deviation (SD), derived from a minimum of three independent experiments. Statistical significance was determined using a two-tailed Student’s t test. Data with p-values less than 0.05 were considered statistically significant. Single (*) and double (**) asterisks indicate statistical significance at p < 0.05 and p < 0.01, respectively.

## Section: Conclusion

The increasing duration and cost of drug development necessitate the exploration of emerging techniques to streamline this process. Machine learning (ML) has emerged as a particularly effective tool in identifying lead compounds with high potential for successful drug development. Our study demonstrates the distinct advantages of ML-based screening in terms of efficiency and high throughput performance in drug design.

In our research, compounds predicted by ML to be effective were selected from FDA-approved drugs. These compounds were shown to fit well within the active region of tryptase, effectively blocking its active site in computational models. Further validation was provided through biological assessment of these compounds. The activities of these highly predicted drugs were comparable to the reference compound APC-366, underscoring their potential efficacy as tryptase inhibitors. Although numerous tryptase inhibitors have been previously reported, it is important to note that these are largely in investigational stages and have not yet received FDA approval. Notably, the fact that these compounds are already FDA-approved adds feasibility and safety to their potential use. Therefore, our study concludes that ML-based drug screening, particularly in the context of drug repurposing, presents a promising approach for the development of novel tryptase inhibitors, offering a significant contribution to the field of drug discovery.


---

# Identification of STAT3 phosphorylation inhibitors using generative deep learning, virtual screening, molecular dynamics simulations, and biological evaluation for non-small cell lung cancer therapy

- **Authors:** Weiji Cai, Beier Jiang, Yichen Yin, Lei Ma, Tao Li, Jing Chen
- **Issuer:** Molecular diversity
- **Type:** Scientific article
- **Published:** 2024-12-23
- **Language:** en
- **DOI:** 10.1007/s11030-024-11067-5
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39715975/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractThe development of phosphorylation-suppressing inhibitors targeting Signal Transducer and Activator of Transcription 3 (STAT3) represents a promising therapeutic strategy for non-small cell lung cancer (NSCLC). In this study, a generative model was developed using transfer learning and virtual screening, leveraging a comprehensive dataset of STAT3 inhibitors to explore the chemical space for novel candidates. This approach yielded a chemically diverse library of compounds, which were prioritized through molecular docking and molecular dynamics (MD) simulations. Among the identified candidates, the HG110 molecule demonstrated potent suppression of STAT3 phosphorylation at Tyr705 and inhibited its nuclear translocation in IL6-stimulated H441 cells. Rigorous MD simulations further confirmed the stability and interaction profiles of top candidates within the STAT3 binding site. Notably, HG106 and HG110 exhibited superior binding affinities and stable conformations, with favorable interactions involving key residues in the STAT3 binding pocket, outperforming known inhibitors. These findings underscore the potential of generative deep learning to expedite the discovery of selective STAT3 inhibitors, providing a compelling pathway for advancing NSCLC therapies.Supplementary InformationThe online version contains supplementary material available at 10.1007/s11030-024-11067-5.Keywords: NSCLC, Drug design, Signal transducer and activator of transcription 3, Molecular dynamics, Apoptosis

## Section: Introduction

Non-small cell lung cancer (NSCLC) is the predominant form of lung cancer [1], constituting approximately 85% of all cases [2]. Although it generally exhibits a slower progression compared to small cell lung cancer (SCLC), NSCLC remains a leading cause of cancer-related mortality worldwide [3, 4]. Traditional treatment modalities, including surgery, chemotherapy [5, 6], and radiotherapy [1], often encounter limitations due to adverse side effects and the development of resistance [3, 7, 8]. In recent years, targeted therapies have emerged as a promising strategy for NSCLC [9], particularly for tumors with specific mutations in genes such as EGFR [10], ALK, and ROS1 [11]. Agents targeting these mutations, including EGFR inhibitors like Gefitinib and ALK inhibitors such as Crizotinib, have shown significant efficacy in patients with these genetic alterations. However, challenges persist, including resistance to targeted therapies and limited options for patients lacking targetable mutations. Ongoing research aims to identify new molecular targets, including MET, RET [12], and KRAS [13], alongside immune checkpoint inhibitors like PD-1/PD-L1 inhibitors [14], which have demonstrated promise in clinical trials and represent an expanding area of therapeutic development for NSCLC.

Signal transducer and activator of transcription 3 (STAT3) has emerged as a critical therapy target for NSCLC, due to its role in enhancing cancer cell proliferation, survival, and immune evasion [15]. Dysregulated STAT3 signaling is commonly observed in various cancers [16], including NSCLC [17], where it is associated with poor prognosis and resistance to conventional therapies. Therefore, STAT3 has become a pivotal target in the development of novel cancer treatments [18, 19]. Several small-molecule inhibitors with diverse chemical scaffolds have been developed to inhibit STAT3 activity (Fig. 1). For instance, napabucasin, a quinolone derivative, inhibits STAT3-driven transcriptional activity and has shown anticancer effects in clinical trials. Another compound, stattic, selectively inhibits the SH2 domain of STAT3, obstructing its dimerization and activation. Benzimidazole-based inhibitors, such as BP-1-102 [20], effectively bind to the STAT3 SH2 domain, preventing its interaction with phosphotyrosine residues on activated receptors. Additionally, OPB-51602 [21], a novel STAT3 inhibitor featuring a piperazine scaffold, has demonstrated promising anticancer activity in both preclinical and clinical studies. These varied chemical scaffolds highlight the potential of STAT3 inhibitors as viable therapeutic options, particularly for cancers characterized by STAT3 overactivation [22]. Despite these advances, the clinical utility of STAT3 inhibitors has been limited by challenges such as poor bioavailability, off-target effects, and resistance mechanisms. Hence, there is a need for the development of more potent and selective inhibitors that can overcome these barriers and be translated into effective therapies for NSCLC.

Generative deep learning (GDL)-aided drug design is an innovative approach that leverages advanced algorithms to accelerate the discovery of new drug candidates by generating novel chemical structures with desired biological properties [23–25]. In GDL, algorithms such as generative adversarial networks (GANs) [26], recurrent neural networks (RNNs) [27], and variational autoencoders (VAEs) [28] are commonly used to create virtual libraries of potential drug molecules. GDL enables the design of novel compounds by learning from existing datasets of known drugs and predicting new chemical structures optimized for specific biological targets, such as STAT3 [29]. The process begins with the design of a target library, which typically involves selecting molecular scaffolds or fragments that are known to interact with the target protein or pathway of interest [30]. By integrating structure-based design principles [31] and applying GDL, researchers can expand this library to generate novel molecules. Virtual screening follows, where the designed molecules are computationally assessed for their ability to bind to the target using techniques like molecular docking or molecular dynamics simulations [32, 33]. By enhancing the chemical diversity and optimizing lead compounds early in the drug discovery process, GDL significantly accelerates the identification of promising therapeutic candidates. This innovative approach has the potential to overcome many of the limitations associated with traditional drug discovery methods and offers a pathway for the development of more effective STAT3 inhibitors for the treatment of NSCLC.

A comprehensive analysis of protein complexes using molecular dynamics and quantum calculations can provide deeper insights into their interactions. In this study, we employed generative deep learning to create customized virtual compound libraries aimed at discovering novel STAT3 inhibitors (Fig. 2). The libraries were generated using a conditional recurrent neural network (cRNN) model [34], which learned distribution patterns to synthesize diverse molecular structures. These compounds underwent a rigorous virtual screening process that included drug-like filtering, molecular docking studies, and synthesis of selected molecules. Ultimately, 95 small molecules were chosen for biological evaluation across H1299 and H441 cell lines. Among these, compounds HG106 and HG110 were subjected to further analysis using colony formation assays and apoptosis assays, alongside characterization of caspase-3-dependent apoptosis biomarkers. Furthermore, we assessed the in vivo inhibition of STAT3 (Tyr705) phosphorylation through immunoblotting and cellular immunofluorescence techniques. Our results demonstrated that HG106 and HG110 exhibited significant efficacy as STAT3 inhibitors, highlighting their potential for therapeutic applications in NSCLC.

Chemical structures of STAT3 inhibitors with different scaffolds

The flowchart for generative deep learning model, virtual screening, and biological assays to identify merging STAT3 inhibitors

## Section: Materials and methods › Cell lines and cell culture

NSCLC cell lines NCI-H1299, A549, NCI-H522, and NCI-H441 were obtained from the American Type Culture Collection. MRC-5 and GES-1 cell lines were donated to Prof. Ming-Yao Liu’s group at the Shanghai Institute of Key Regulated Life Sciences, East China Normal University, Shanghai, China. NCI-H441, NCI-H522, MRC-5, A549, NCI-H1299, and GES-1 cell lines were cultured in DMEM or RPMI-1640 with 10% fetal bovine serum (Gibco). All cells were cultured in an incubator with 5% CO2 at a constant temperature of 37 °C.

## Section: Materials and methods › Generative deep learning to generate virtual molecular library

The generative deep learning model was implanted from previous report. The package was obtained from the Yueshan Li et al. paper [35]. All the parameters were set as default without changing except especial mention in the paper (see Supplementary Table S1). Briefly, the generative model was built to convert molecular SMILES strings into reconstructed SMILES strings using a two-part structure: a feature extractor and a generative layer. The feature extractor is a one-layer bi-directional LSTM with 512 dimensions, converting input molecules into an initial state vector for the model. This state vector and a one-hot encoded SMILES string feed into a one-layer LSTM with 256 dimensions, followed by a dense layer and a SoftMax activation function. This structure enables a probability distribution over possible grammar production rules, which allows the model to generate chemically valid molecules in each step of SMILES generation. After training, generated molecules were generated with 39,477, and then filtered to remove the duplicate, unstable, and other molecules which cannot transform into 3D molecules (n = 27,863).

For the pretraining procedure, we collected STAT3 inhibitors from ChEMBL database (https://www.ebi.ac.uk/chembl/, update Sept 1st, 2024), in which IC50 is less than 1000 nM, and there were 411 molecules obtained and further transformed as SMILES for the following training. The source data were obtained from ZINC database (https://zinc.docking.org/, update to Sep 1st, 2024) with drug-like pre-set. The molecular structures retrieved from the ZINC database were initially represented in SMILES (Simplified Molecular Input Line Entry System) notation. Subsequently, these SMILES strings underwent a process of standardization and normalization. This involved the elimination of stereochemical details, the removal of counterions associated with salts, and the identification and exclusion of duplicate entries. The aforementioned operations were facilitated by employing the RDKit software package, version 2024.3.2, which is accessible at https://github.com/kuelumbus/rdkit-pypi. As a result of this meticulous curation, a comprehensive dataset comprising approximately 12 million unique molecular entities was assembled for subsequent analysis.

## Section: Materials and methods › Molecular docking

Molecular docking simulations were performed to predict the binding mode and affinity of the ligand to the target protein STAT3 using AutoDock 4.0. The docking protocol was designed to comprehensively explore the conformational space and provide reliable interaction profiles suitable for a high-impact publication.

Protein Preparation: The three-dimensional structure of the target protein was obtained from the Protein Data Bank (PDB ID: 6nuq), which was reported by Longchuan Bai et al. [36]. The protein structure was prepared using AutoDockTools (ADT) version 1.5.6 following these steps:

The prepared protein structure was saved in PDBQT format required by AutoDock.

## Section: Materials and methods › Molecular docking › Ligand preparation

The ligand structure was drawn using Kindraw and converted to a three-dimensional conformation using Accelrys ViewerLite 5.0 and further optimizing using openbabel (Version 3.0.0, https://pypi.org/project/openbabel/3.0.0a1/).

## Section: Materials and methods › Molecular docking › Grid preparation

The grid box was centered at the coordinates of the co-crystallized ligand (13.711, 54.024, − 0.083). The grid box size was set to 62 × 70 × 70 points with a grid spacing of 0.375 Å, ensuring sufficient space for the ligand to explore conformational freedom. AutoGrid 4.0 was used to pre-calculate the grid maps for all atom types present in the ligand, including electrostatic and desolvation maps.

Docking parameters: Docking simulations were performed using the Lamarckian Genetic Algorithm (LGA), which combines genetic algorithm search with local optimization, enhancing the efficiency of the docking process.

Number of runs: 100 independent docking runs were conducted to ensure thorough sampling.

Population size: Set to 150 individuals per generation.

Maximum number of evaluations: 2,500,000 energy evaluations per run.

Maximum number of generations: 27,000.

Mutation rate: 0.02.

Crossover rate: 0.8.

Elitism: The top individual was carried over to the next generation.

Local search: Solis and Wets local search method was applied with a probability of 0.06.

Analysis of docking results: The docking results were analyzed using ADT and visualized with UCSF Chimera 1.15. High-resolution images of the protein–ligand complex were generated to illustrate the binding interactions.

Computational Resources: All computations were performed on a workstation equipped with an Intel(R) Xeon(R) CPU E5-2678 processor, 32 GB RAM, and running Ubuntu 20.04 LTS operating system.

## Section: Materials and methods › Molecular dynamics simulation

Molecular dynamics (MD) simulations were performed using the OpenMM software package (version 7.7) to investigate the structural dynamics of the STAT 3 protein–ligand complex. The following protocol was employed to ensure a comprehensive and reproducible simulation process [37].

## Section: Materials and methods › Molecular dynamics simulation › Protein preparation

The crystal structure of the target protein was retrieved from the Protein Data Bank (PDB ID: 6nuq). Missing residues and side chains were modeled using PDBFixer and pdb2qpr package, and protonation states were assigned appropriate for pH 7.4 using the PropKa algorithm. Hydrogen atoms were added using the pdb2pqr module in OpenMM.

## Section: Materials and methods › Molecular dynamics simulation › Ligand preparation

The ligand structure was obtained by preparing using Kindraw software (HG106 and HG110). Geometry optimization and partial charge assignment were performed using the AM1-BCC method implemented in the OpenEye Quacpac toolkit 666. Ligand force field parameters were generated using the LigParGen (https://zarbi.chem.yale.edu/ligpargen/, CM1A with neutral charge). The PDB file of ligand and relative force field were downloaded and prepared for the next step.

## Section: Materials and methods › Molecular dynamics simulation › System assembly

The prepared protein and ligand were combined to form the protein–ligand complex using ChimeraX. The complex was then solvated in an explicit water box using the TIP3P water model, with a padding distance of 10 Å from the protein surface to the box edges. Sodium and chloride ions were added to neutralize the system and achieve a physiological ionic strength of 0.15 M using the Modeller module of openmm.

## Section: Materials and methods › Molecular dynamics simulation › Force field parameters

The AMBER99SB force field was employed for the protein, while the ligand was parameterized with GAFF2 parameters. The system’s topology and parameters were generated using the ForceField class in OpenMM, integrating both protein and ligand parameters seamlessly.

## Section: Materials and methods › Molecular dynamics simulation › Energy minimization

Energy minimization was conducted to relieve any steric clashes and optimize the initial geometry of the system. The conjugate gradient algorithm in OpenMM was used with a maximum of 5,000 steps or until the energy gradient converged below 0.01 kJ/mol/Å.

## Section: Materials and methods › Molecular dynamics simulation › Production MD simulation

An unrestrained production MD simulation was executed for 200 ns under NPT conditions at 300 K and 1 atm. The Langevin integrator was used with a time step of 4 fs. All covalent bonds involving hydrogen atoms were constrained using the SHAKE algorithm, allowing for the larger integration time step. Long-range electrostatic interactions were computed using the Particle Mesh Ewald (PME) method with a real-space cutoff of 10 Å. van der Waals interactions were smoothly switched off between 8.0 Å and 10.0 Å to reduce cutoff artifacts.

## Section: Materials and methods › Molecular dynamics simulation › Data collection

Coordinates were saved every 20 ps, resulting in 10,000 frames for analysis. The simulation was monitored by recording the energy components, temperature, pressure, and volume at regular intervals to ensure system stability.

## Section: Materials and methods › Molecular dynamics simulation › Software and hardware

All simulations were performed using OpenMM on a workstation equipped with an NVIDIA V100 GPU 16 GB, leveraging GPU acceleration for efficient computation.

## Section: Materials and methods › Calculations of molecular properties

The physicochemical properties of the obtained molecules were computed using RDKit (Version 2024.3.2, https://github.com/kuelumbus/rdkit-pypi), a cheminformatics toolkit. A set of critical molecular descriptors were calculated to evaluate the drug-likeness and other relevant properties of the compounds. The following properties were assessed:

## Section: Materials and methods › Calculations of molecular properties › Molecular weight (MW)

The molecular weight of each compound was calculated as the sum of the atomic weights of all atoms in the molecule, including isotopes and charge contributions, to determine the overall size of the molecule.

## Section: Materials and methods › Calculations of molecular properties › Water–octanol partition coefficient (LogP)

The LogP value was computed using the Crippen method to estimate the hydrophobicity of the compound. This coefficient indicates the compound’s ability to partition between the water phase and the octanol phase, which correlates with its lipophilicity and drug absorption potential.

## Section: Materials and methods › Calculations of molecular properties › Qualitative estimate of drug-likeness (QED)

The drug-likeness of each compound was evaluated using the Quantitative Estimate of Drug-likeness (QED), which ranges from 0 to 1. This descriptor combines several molecular properties, including molecular weight, rotatable bonds, hydrogen bond donors/acceptors, and more, to predict how “drug-like” a compound is based on its physicochemical features.

## Section: Materials and methods › Calculations of molecular properties › Topological polar surface area (TPSA)

TPSA was calculated to estimate the polar surface area of the molecule, which plays a significant role in predicting intestinal absorption, blood–brain barrier penetration, and overall bioavailability. This descriptor helps to determine the molecule’s ability to cross biological membranes.

## Section: Materials and methods › Calculations of molecular properties › Water solubility (LogS)

The water solubility (LogS) was predicted using the Ali method, which correlates molecular features with experimental solubility data. LogS is an important factor influencing drug absorption, distribution, and excretion.

## Section: Materials and methods › Calculations of molecular properties › Hydrogen bond donors (HBD)

The number of hydrogen bond donors was calculated by counting the number of hydrogen atoms attached to electronegative atoms (like oxygen or nitrogen) that can participate in hydrogen bonding interactions.

## Section: Materials and methods › Calculations of molecular properties › Hydrogen bond acceptors (HBA)

The number of hydrogen bond acceptors was determined by counting the number of electronegative atoms (oxygen, nitrogen, etc.) that have lone pairs of electrons capable of accepting a hydrogen bond from donors.

To ensure accurate predictions, all compounds were first converted into standard SMILES (Simplified Molecular Input Line Entry System) strings using RDKit, followed by the calculation of the above properties. Each descriptor was obtained by running the appropriate RDKit functions that are designed to handle different molecular types, such as aromatic rings, heteroatoms, and functional groups.

## Section: Materials and methods › Uniform manifold approximation and projection (UMAP)

To elucidate the relational similarities among the source data, target data, and generated data, we employed UMAP (umap-learn 0.4.6, https://pypi.org/project/umap-learn/) to create two-dimensional projections of high-dimensional data distributions. This analysis involved 3,000, 1,000, and 2,000 randomly selected molecules from the source, target, and generated datasets, respectively. All the images were generated using Python = 3.8 with scipy package (Version 1.10.1).

## Section: Materials and methods › Tree maps (TMAPs)

Scaffold and fingerprint diversity were assessed and visualized utilizing the Platform for Tree maps (tmap, https://tmap.gdb.tools/), based on a random selection of 15,678 molecules from the source data, target data, generated data, and filtered molecules, respectively.

## Section: Materials and methods › Cell viability assay

Cells were collected from culture dishes, counted, resuspended, and seeded into 96-well plates. After allowing them to adhere overnight, we replaced the medium with fresh medium containing various concentrations of the drug and incubated the cells for an additional 72 h. To fix the cells, we added 25 μL of 50% trichloroacetic acid (Sangon Biotech, China) to each well and refrigerated the plates at 4 °C overnight. Following fixation, the plates were washed and dried before adding 50 μL of 0.4% sulforhodamine B solution (A426137, Sangon Biotech, China) to each well for staining. After a 10-min incubation, excess dye was removed by washing the plates several times with 1% glacial acetic acid (A501931, Sangon Biotech, China) until the wash solution was clear. The plates were then air-dried, and 100 μL of 10 mM Tris buffer (T8060, Solarbio, China) was added to each well to dissolve the dye. Absorbance was measured at 515 nm using a plate reader.

## Section: Materials and methods › Colony-forming assay

Non-small cell lung cancer cell lines NCI-H441, NCI-H1299, NCI-H522, and A549 were seeded into 6-well plates at densities ranging from 1,000 to 3,000 cells per well and cultured for 24 h to allow for cell attachment. The following day, the cells were treated with HG106 and HG110 at given concentrations of 0.5 μM and 1 μM, respectively, for a period of 7 to 10 days, with three replicate wells for each group. The culture medium was refreshed and the drugs were re-applied every three days. After the treatment period, cells were fixed with 4% paraformaldehyde (P1110, Solarbio, China) for 30 min. The plates were washed three times with running water and air-dried. Cells were then stained with 0.1% crystal violet (A600331, Sangon Biotech, China), washed with ultrapure water, dried, and photographed. Colonies containing more than 50 cells were counted.

## Section: Materials and methods › Soft-agar colony formation assay

A 1.2% agar solution (A8190, Solarbio, China) was combined with growth medium and poured into the wells of a 6-well plate at a volume of 2 mL per well. The mixture was allowed to solidify at room temperature. Once the first agar layer had set, a second layer containing 0.5% agar and 2000 cells per well were added, using 1 mL per well. Fresh medium was then added on top of the second layer, and the cells were incubated for approximately 4 weeks. During this period, the medium supplemented with the specified drugs was refreshed every 3 days. At the end of the incubation period, the colonies were photographed for further analysis.

## Section: Materials and methods › Western blotting analysis

Cells were seeded into 60 mm culture dishes and allowed to adhere. After adhesion, different concentrations of the target compound drugs were added to the medium, and the cells were incubated for an additional 24 h. The medium was then removed, and the cells were washed three times with pre-chilled 1 × PBS (P1010, Solarbio, China). Next, 150 µL of cell lysis buffer (HY-K1001, MCE, USA) was added to each dish, and the protein lysate was collected into EP tubes (615,601, NEST, China) using a spatula. The lysates were kept on ice for 30 min, with gentle shaking for 15–20 s every 10 min to ensure complete lysis. Protein concentrations were measured using a BCA assay kit (23,235, Thermo, USA), and each sample was adjusted to approximately 50 µg of protein. The protein samples were mixed with 5X protein loading buffer (C516031, Sangon Biotech, China) and heated at 100 °C for 10 min to denature the proteins. The denatured proteins were then separated by electrophoresis until the bromophenol blue dye reached about 1 cm from the bottom of the gel. After electrophoresis, the proteins were transferred to a membrane, which was then incubated with the primary antibody overnight at 4 °C on a shaker. The following day, the membrane was incubated with a secondary antibody diluted in skimmed milk for 1 h on a shaker to complete the detection process.

The membrane was visualized using an Odyssey infrared two-color laser scanning imaging system. Reagents and antibodies: STAT3 (cat. no. 9139), antibodies against phosphorylated (p)-STAT3 (Tyr705; 9145), Bcl-2 (4223), Caspase-3 (4691), Bax (Ser465; 467) were purchased from Cell Signaling Technology. GAPDH and β-actin (cat. no. M1210-2) were purchased from Hangzhou Huaan Biotechnology. Other reagents, such as dimethyl sulfoxide, were obtained from Sigma-Aldrich (Merck KGaA).

## Section: Materials and methods › Apoptotic assay

NCI-H441 cells were treated with the specified drugs in 6-well plates for 24 h. After treatment, the cells were detached using EDTA-free trypsin (T1350, Solarbio, China) and collected into labeled EP tubes. Following centrifugation, the supernatant was removed. The cell pellet was resuspended gently in 500 µL of Binding Buffer (KGA1102, KeyGEN, China) to create a single-cell suspension. Next, 5 µL of Annexin V-FITC (KGA1102, KeyGEN, China) was added to each sample and mixed thoroughly, followed by the addition of 5 µL of propidium iodide (KGA1102, KeyGEN, China). The samples were incubated at room temperature in the dark for 5 to 10 min. Flow cytometry (BD Accuri™ C6 Plus, USA) analysis was then performed, examining 20,000 cells per sample. Early apoptotic cells were identified as those positive for Annexin V-FITC but negative for propidium iodide, while late apoptotic cells were positive for both Annexin V-FITC and propidium iodide. The results were expressed as the percentage of each apoptotic population relative to the total number of cells analyzed (FlowJo 10.8.1).

## Section: Materials and methods › Immunofluorescence

Cell slides were first soaked in 75% ethanol for 1 h and then dried by holding them with forceps approximately 2–3 cm from an alcohol lamp. The prepared slides were placed into a 24-well plate, and cells were seeded onto the slides and incubated until they adhered to the surface. After cell adhesion, the medium was replaced with fresh medium containing varying concentrations of the target compounds, and the cells were incubated for an additional 24 h. Subsequently, the cells were treated with interleukin-6 (PeproTech, USA)) for 2 h. The cells were then fixed on ice using 4% paraformaldehyde (P1110, Solarbio, China) for 20 min. Following fixation, the cells were permeabilized with 0.3% Triton X-100 (T8200, Solarbio, China) for 30 min and washed three times with PBS, each wash lasting 10 min. Blocking was performed using 1% bovine serum albumin (A8020, Solarbio, China) for 1 h to prevent non-specific antibody binding. After blocking, 100 µL of diluted primary antibody was added to each slide and incubated overnight at 4 °C on a shaker. The next day, the slides were washed with 1 × PBS for 10 min to remove any unbound antibody.

## Section: Materials and methods › DFT calculation

The optimization of the compounds was performed by using PySCF. For this process, B3LYP/6-311G + (d,p) level basic set of DFT was used. Afterward, the Frontier Molecular Orbitals (FMO) which were the highest occupied molecular orbital (HOMO) and lowest unoccupied molecular orbital (LUMO) were extracted and the energy gap was calculated by the difference between HOMO and LUMO energy values. Furthermore, quantum chemical parameters were calculated in order to predict the behavior of compounds and to get information about the transition state energies.

## Section: Materials and methods › Virtual screening strategies

Virtual screening was performed to identify potential small-molecule inhibitors for the target protein using a combination of drug-like filtering, molecular docking, and binding affinity calculations. Initially, a compound library was screened based on revised Lipinski’s Rule of Five (Molecular weight ≤ 700 Da; LogP ≤ 5; Hydrogen bond donors ≤ 5; Hydrogen bond acceptors ≤ 10) to select drug-like candidates with favorable pharmacokinetic properties.

To optimize the enrichment of active compounds, a hierarchical two-step pipeline was implemented for the structure-based virtual screening of potential inhibitors. Initially, AutoDock Vina was employed to dock a large compound library into the target protein’s binding site, which allowed for the rapid elimination of inactive or poorly binding compounds. The compounds were ranked according to their predicted binding affinities, and the top 10% were selected for further analysis.

In the second step, an in-house developed scoring function, CYSCORE [38], was used to refine the selection of compounds based on their predicted binding energies and other physicochemical properties. The top 10% of compounds from the AutoDock Vina docking were further analyzed using FitDock [39], a compound alignment and docking program. This tool assessed the structural similarities between the compounds, clustering them into groups based on common chemical scaffolds and binding modes. This two-step virtual screening strategy allowed for the identification of high-affinity inhibitors of MDM2, streamlining the selection of promising candidates for further experimental validation.

Additionally, Molecular Mechanics, General Born Surface Area (MM/GBSA) calculations (gmx_MMPBSA package with the GROMACS, 100 ps) were performed to refine the binding affinity predictions and assess the stability of the ligand–protein complexes. The final selection of top-ranked molecules was based on their docking scores, ligand efficiency, drug-likeness, with compounds that demonstrated favorable results proceeding to experimental validation.

## Section: Materials and methods › Statistical analysis

All experiments in this study were repeated three times independently, and all data were analyzed using GraphPad Prism 9.0. One-way analysis of variance (ANOVA) was used to compare the drug treatment group, positive control group, and blank control group. The results were expressed as mean ± standard deviation (SD). Differences were considered statistically significant at P < 0.05.

## Section: Results

Generation of a virtual compound library against STAT3 using the cRNN-ased generative model. A schematic illustration of library using GDL methods. B chemical space of generated space (gray dot), source space (red dot), and target space (blue dot) by transfer learning. C the distributions of molecular weight, logP, QED, and logS of targeted data and the generated data by GDL generation methods

HG106 and HG110 efficiently suppress cancer cell growth. A representative image (left panels) and quantification (right panels) of concentration-manner colony formation assays of cancer cells treating with HG106 and HG110, respectively. B bright-field images of soft agar colony formation of A549 cells treated with HG106 and HG110, respectively. All the data were presented as Mean±S.D. Statistical analysis was conducted by one-way ANOVA (***p < 0.001)

A The percentage of apoptotic cells quantitatively measured by using flow cytometry for the H441 cells stained by Annexin V/PI. Cells were treated with HG106 and HG110 at concentration of 5 uM for 24 h, respectively. DMSO was selected as control. B Immunoblot bands and quantitative measurement revealed apoptosis-associated protein expression levels after dose-dependent treatment against H441 cells. C Immunoblot analysis reveals the effect of HG110 on the phosphorylation levels of STAT3 at Tyr705 compared with HG106 at 24 h in H411 and H1299 cells. GAPDH was selected as inner standard. D HG110 suppressed phosphorylation levels of STAT3 at 24 h. E Immunofluorescent staining revealed the impacts of HG110 on IL6-promoted nucleus translocation of STAT3 in H441 cells. Scale bar is XX um. All the data were presented as Mean±S.D. Statistical analysis was conducted by one-way ANOVA (*p < 0.05, **p < 0.01, ***p < 0.001)

Molecular dynamic simulation to reveal the binding model of HG106 and HG110 with STAT3. A Molecular structure, binding model, and planar residue–ligand interaction of HG106. B Analysis of residue root mean square deviation (RMSD) in compound HG106 and STAT3 complex for protein (STAT3) stability. C Profile of hydrogen bonds between HG106 and STAT3 among molecular dynamic simulation. D Molecular structure, binding model, and planar residue–ligand interaction of HG110. E Analysis of residue root mean square deviation (RMSD) in compound HG110 and STAT3 complex for protein (STAT3) stability. F Profile of hydrogen bonds between HG110 and STAT3 among molecular dynamic simulation

## Section: Results › Generation of molecular libraries using generative deep learning

We employed a generative deep learning approach to construct a diverse library of molecular structures specifically designed to target the active site of STAT3 (Fig. 3A). Initially, we curated a dataset of STAT3 inhibitors exhibiting high biological activity (IC50 < 1000 nM) from the ChEMBL database (n = 411) as the target dataset. The AlogP value of STAT3 was selected as standard criteria for the subsequential and crude screening (Supplementary Fig. S1). Additionally, approximately 12.0 million compounds from the ZINC database were utilized as the source dataset, providing a broad spectrum of pharmacophoric fragments for model training (Supplementary Fig. S2). Using these datasets, we generated a library of 15,678 unique molecular structures, with any duplicates meticulously removed to ensure novelty.

The generated molecules were visualized using Uniform Manifold Approximation and Projection (UMAP) to assess their distribution in the chemical space relative to both the source and target datasets. UMAP is a dimensionality reduction technique that visualizes high-dimensional data by preserving both local and global structures, enabling a more interpretable representation of complex data distributions [40]. It was used in this study to assess the distribution of generated molecules, as it effectively reduces the high-dimensional molecular feature space into two dimensions, allowing for a clear visualization of the relationships between source, target, and generated data, and providing insights into the diversity and similarity of the molecular structures [41]. As shown in Fig. 3B, the generated molecules (represented by gray dots) demonstrate a clear transition from the chemical space of the source data (red dots) towards that of the target data (blue dots). This distribution indicates that the generative model effectively captured and transferred the relevant features from the source data to the target dataset, creating novel molecular entities aligned with the desired chemical properties of STAT3 inhibitors.

Further analysis of the physicochemical properties of the generated molecules, presented in Fig. 3C, revealed that 98.3% of the molecular scaffolds in the generated library were structurally distinct from those in both the source and target datasets. This substantial scaffold diversity suggests the successful generation of novel chemical space, providing a robust foundation for subsequent molecular docking and virtual screening efforts aimed at identifying promising STAT3 inhibitors.

Generation of a virtual compound library against STAT3 using the cRNN-ased generative model. A schematic illustration of library using GDL methods. B chemical space of generated space (gray dot), source space (red dot), and target space (blue dot) by transfer learning. C the distributions of molecular weight, logP, QED, and logS of targeted data and the generated data by GDL generation methods

## Section: Results › Virtual screening and molecular docking

After generation the library, we then conducted the virtual screening to obtain the potential STAT3 inhibitors (Fig. 2) with STAT3 protein structure (Supplementary Fig. S3) with optimized method (Supplementary Fig. S4). The screened molecules were presented using tree maps (TMAPs) according to the following features, including RECP-based structural similarity, molecular properties, and docking scores (Supplementary Fig. S5). These TMAPs well presented the unsupervised visualization of high-dimensional data with creating a 2D layout of spanning tree in the chemical space. From the top-ranked 95 molecules (Supplementary Fig. S6), we selected the molecules from the current library containing benzotriazole scaffold, and further conducted the biological screening to identify higher anticancer activity.

## Section: Results › HG106 and HG110 inhibits the viability of NSCLC cells

Following the outcomes of the virtual screening, we selected 90 novel small-molecule compounds for synthesis. These synthesized compounds were subsequently evaluated for their cytotoxic effects against NSCLC cell lines NCI-H441 and NCI-H1299. Among them, two compounds, i.e., HG106 and HG110, exhibited a significantly enhanced inhibitory effect on the proliferation of both H441 and H1299 cells (Supplementary Fig. S7A), thus identifying HG106 and HG110 as a lead candidate for further investigations. Subsequently, HG106 and HG110 were tested on a panel of four NSCLC cell lines (NCI-H441, NCI-H1299, NCI-H522, A549) and two normal cell lines (GES-1, MRC-5) over a 72-h incubation, and IC50 values were determined using the SRB assay. The results demonstrated that HG106 and HG110 markedly suppressed the viability of A549, NCI-H522, NCI-H441, and NCI-H1299 cells (Supplementary Fig. S7B). Furthermore, HG106 and HG110 exhibited minimal cytotoxicity towards normal human cell lines, including MRC-5 fibroblasts and GES-1 gastric epithelial cells, indicating a favorable safety profile.

## Section: Results › HG106 and HG110 inhibits the proliferation of NSCLC cells

HG106 and HG110 can efficiently suppress proliferation of lung cancer cells (A549, H522 H441, and H1299) compared with normal cells (MRC-5 and GES-1). To further evaluate cancer cell growth, colony formation assays was conducted. As given in Fig. 4A, NSCLC cell lines NCI-H441, NCI-H1299, NCI-H522, and A549 were dosage-dependent (0.5 and 1.0 μM) exposed to HG106 and HG110 for 7 to 10 days. The results demonstrated that HG106 and HG110 significantly suppressed colony formation in all tested NSCLC cell lines at a concentration of 1 μM Fig. 4A. This inhibitory effect was further corroborated by a soft agar colony formation assay, which yielded consistent results (Fig. 4B). Collectively, these findings indicate that HG106 and HG110 effectively inhibits the proliferation of NSCLC cells in vitro.

HG106 and HG110 efficiently suppress cancer cell growth. A representative image (left panels) and quantification (right panels) of concentration-manner colony formation assays of cancer cells treating with HG106 and HG110, respectively. B bright-field images of soft agar colony formation of A549 cells treated with HG106 and HG110, respectively. All the data were presented as Mean±S.D. Statistical analysis was conducted by one-way ANOVA (***p < 0.001)

## Section: Results › HG106 and HG110 promotes apoptosis in NSCLC cells

Flow cytometric analysis revealed that HG106 and HG110 significantly enhanced apoptotic cell death in H441 cells compared to the control group (Fig. 5A). This pro-apoptotic effect was further substantiated by western blot analysis, which demonstrated an upregulation of the pro-apoptotic protein Bax and the effector protein caspase-3, alongside a concurrent downregulation of the anti-apoptotic protein Bcl-2 following HG106 and HG110 treatment (Fig. 5B, C). These findings suggest that HG106 and HG110 induce apoptosis in H441 cells through the modulation of key apoptotic regulators.

A The percentage of apoptotic cells quantitatively measured by using flow cytometry for the H441 cells stained by Annexin V/PI. Cells were treated with HG106 and HG110 at concentration of 5 uM for 24 h, respectively. DMSO was selected as control. B Immunoblot bands and quantitative measurement revealed apoptosis-associated protein expression levels after dose-dependent treatment against H441 cells. C Immunoblot analysis reveals the effect of HG110 on the phosphorylation levels of STAT3 at Tyr705 compared with HG106 at 24 h in H411 and H1299 cells. GAPDH was selected as inner standard. D HG110 suppressed phosphorylation levels of STAT3 at 24 h. E Immunofluorescent staining revealed the impacts of HG110 on IL6-promoted nucleus translocation of STAT3 in H441 cells. Scale bar is XX um. All the data were presented as Mean±S.D. Statistical analysis was conducted by one-way ANOVA (*p < 0.05, **p < 0.01, ***p < 0.001)

## Section: Results › HG106 and HG110 exert anti-tumor activity by suppressing the activation of STAT3

Western blot analysis was employed to evaluate the inhibitory effect of HG106 and HG110 on STAT3 activation in H441 and H1299 cells following treatment with various concentrations of HG106 or HG110 for 24 h. The results indicated that HG106 and HG110 at a concentration of 5 μM significantly suppressed the phosphorylation of STAT3 (Fig. 5D–F). Additionally, immunofluorescence staining demonstrated that HG106 and HG110 treatment led to a notable reduction in nuclear STAT3 levels, suggesting an inhibition of STAT3 nuclear translocation (Fig. 5G).

## Section: Results › Binding model analysis and molecular dynamics simulations

As above-mentioned analysis, HG106 and HG110 presented the excellent anti-proliferation and suppression phosphorylation of STAT3 in vitro. In order to analyze the binding model between STAT3 and HG106 or HG110, we obtained the potential binding conformation of STAT3-HG106 and STAT3-HG110 by molecular docking.

As given in Fig. 6A, HG106 molecules well docked into the STAT3 bioactive pocket, which was widely used to design STAT3 inhibitors [36], and docking score was − 8.5 kcal/mol. By presenting using LigPlot software, we can observe that residue of STAT3, including Trp623, Gln635, Ser636, Val637, Tyr640, Tyr657, and Ile659 were interacted with HG106 by the hydrophilic interaction. Moreover, the amino group of Glu638 interacted with nitrogen atom of triazole ring by hydrogen bond, and NH2 of Gln644 amide group interacted with oxygen of methoxyl of HG106 by hydrogen bond. To further analyze the structure of STAT3-HG106, molecular dynamic simulation was conducted to evaluate the stabilization in 200 ns. Among the 200 ns simulation, system fast achieved the equilibrium at around 10 ns (Supplementary Fig. S8A), and HG106 molecule can stabilize to bind with the pocket of STAT3. To determine the fluctuating residues, we analyzed the RMSD of residue of residues among the 200 ns simulation, and alignment between RMSD and RMSF of residues (Fig. 6B) clearly revealed that the HG106 molecules can strongly interact with the residue of active pockets. The profile of hydrogen bonds altered during the simulation, and the hydrogen bond (Fig. 6C) between methoxyl group and Gln644 was stable.

The free energy landscape was conducted to determine the collective atomic motions during the simulation process with principal component analysis (PCA). As given in Supplementary Fig. S8B, C, the dark blue indicated the minimum valley of system energy, while the difference between top point and lower point is only 1.35 kcal/mol. Additionally, there are three minimum points during the simulation process, and difference is very small. These results may be caused by the weak hydrogen bonds between STAT3 and HG106, consistent with fluctuations of hydrogen bonds (Fig. 6C).

Similarly, HG110 molecules also well docked into the STAT3 bioactive pocket consistent with HG106. By analysis of binding model (Fig. 6D), we can observe that residue of STAT3 including Gln635, Trp623, Val637, Glu638, Pro639, Tyr640, Ile659, and Ser636 were interacted with HG110 by the hydrophilic interaction. Additionally, the NH2 of Gln644 amide part strongly interacted with two methoxyl groups of HG110 by forming hydrogen bonds, while hydroxyl of Tyr657 interacted with nitrogen atom of triazole ring by hydrogen bond. Among the 200 ns simulation (Supplementary Fig. S9A), we can observe that the RMSD of ligand (Fig. 6E) was more stable compared with HG106, and the comparison between RMSD and RMSF of residues also validated that HG110 molecule strongly interacted with STAT3 active pocket (Fig. 6E). Compared with HG106, hydrogen bonds (Gln644 and Tyr657) between HG110 and STAT3 were far more and stable than HG106, implying that the HG110 molecule was more strongly interacted with STAT3 compared with HG106, which is consistent with the above-mentioned biological activities (Fig. 5C). Moreover, the free energy landscape of STAT3-HG110 (Supplementary Fig. S9B, C), only one minimum point was observed compared with STAT3-HG106 complex (Supplementary Fig. S8B, C). This result also validated that stronger hydrogen bonds can stabilize the protein–ligand complex.

By further analysis of RMSD of HG106 and HG110 molecules during the 200 ns simulation, we observed that average RMSD value of HG106 and HG110 were 0.19 Å and 0.16 Å, respectively. This lower average RMSD value of these ligands indicated higher stability. Subsequentially, we also conducted the quantum calculation to obtain the frontier molecular orbitals of HG106 and HG110. The energy gap between the LUMO and HOMO is often used to determine the kinetic stability. As shown in Supplementary Fig. S10A, B, the energy gap of HG110 (9.6300 eV) was higher than HG106 (9.4757 eV), implying that lower reactivity of HG110 and suppression of STAT3 may be originated from the stronger binding, not irreversible covalent binding.

Molecular dynamic simulation to reveal the binding model of HG106 and HG110 with STAT3. A Molecular structure, binding model, and planar residue–ligand interaction of HG106. B Analysis of residue root mean square deviation (RMSD) in compound HG106 and STAT3 complex for protein (STAT3) stability. C Profile of hydrogen bonds between HG106 and STAT3 among molecular dynamic simulation. D Molecular structure, binding model, and planar residue–ligand interaction of HG110. E Analysis of residue root mean square deviation (RMSD) in compound HG110 and STAT3 complex for protein (STAT3) stability. F Profile of hydrogen bonds between HG110 and STAT3 among molecular dynamic simulation

## Section: Discussion

The aberrant activation of STAT3 in vivo plays a pivotal role in driving cancer cell proliferation and regulating multiple tumor-associated pathways, including cell cycle [36], apoptosis resistance [42], angiogenesis [43], and immune evasion [44]. Targeting the overactivation of STAT3, particularly its phosphorylation at Tyr705, is therefore a promising therapeutic strategy for cancer treatment. In this study, we employed a generative deep learning model to design and synthesize a library of potential STAT3 inhibitors. From this library, two lead compounds, HG106 and HG110, were identified, both derived from a benzotriazole scaffold. Notably, HG110 demonstrated superior efficacy compared to HG106 in inhibiting STAT3 phosphorylation at Tyr705, leading to enhanced induction of apoptosis in NSCLC cells.

In vivo experiments further confirmed the therapeutic potential of HG110, showing its ability to effectively inhibit IL6-induced translocation of phosphorylated STAT3 (p-STAT3) to the nucleus, thereby disrupting STAT3-mediated transcriptional activity. Upon IL6 binding to its receptor, gp130, JAK1 and JAK2 kinases are activated, leading to phosphorylation of STAT3 at Tyr705 [45, 46]. This phosphorylation triggers the dimerization of STAT3, which subsequently translocates to the nucleus to initiate the transcription of genes involved in cell survival, proliferation, and immune evasion [47]. Our studies indicate that HG110 effectively inhibits this phosphorylation step, thereby preventing the nuclear translocation of STAT3 and its downstream transcriptional activity. Molecular dynamics simulations provided additional insights, revealing that HG110 forms stable interactions with key residues in the active pocket of STAT3, thus stabilizing the STAT3-HG110 complex and enhancing its inhibitory effect. These findings collectively highlight HG110 as a potent and selective STAT3 inhibitor with the capability to suppress STAT3 phosphorylation and promote apoptosis, underscoring its potential application in cancer therapy. Further preclinical and clinical studies are warranted to validate these results and explore the full therapeutic potential of HG110 in STAT3-driven malignancies.

Direct binding to the active site of STAT3 can interfere with its phosphorylation at Tyr705, subsequently affecting cellular activities. In cancer cells, receptor-bound JAK kinases, primarily JAK1 and JAK2, are activated upon cytokine signaling and phosphorylate the cytoplasmic domain of the receptor [47]. This phosphorylation generates docking sites for STAT3, allowing it to bind via its SH2 domain. The receptor-associated JAKs then phosphorylate STAT3 at Tyr705, which induces its dimerization and translocation to the nucleus [48]. Once in the nucleus, STAT3 modulates the expression of various target genes involved in inflammatory responses, cancer progression, and immune evasion [47]. Several studies have demonstrated the potential of targeting STAT3 phosphorylation as a therapeutic strategy: Zhang et al. reported [49] that S3I-201.1066 binds to the STAT3 SH2 domain and disrupts STAT3 phosphorylation in vivo; Gabriele et al. [50] found that thiosulfonic compounds selectively bind the STAT3 SH2 domain, effectively inhibiting cancer cell proliferation; and He et al. [51] described the use of oral STAT3 inhibitors to suppress gastric cancer proliferation by downregulating STAT3 phosphorylation at Tyr705. These findings highlight the growing promise of targeting the STAT3 active site with emerging inhibitors as a therapeutic strategy for cancer.

Traditional drug discovery methodologies have often been hindered by high costs, low efficiency, and a dependence on the experience and intuition of medicinal chemists, which can limit the exploration of chemical space. Consequently, scaffold designs and structural modifications are typically constrained to well-known chemical entities. In contrast, the advent of machine learning (ML)-aided drug design has revolutionized the field by enabling a more extensive exploration of chemical space and enhancing the hit rate of targeted compounds. By leveraging sophisticated algorithms and comprehensive chemical datasets, ML models can predict the biological activities and physicochemical properties of molecules with high accuracy, significantly expediting the drug discovery process.

Various machine learning architectures, including Deep Neural Networks (DNNs), Convolutional Neural Networks (CNNs), Recurrent Neural Networks (RNNs), and Generative Adversarial Networks (GANs), have demonstrated remarkable potential in drug design. These models can efficiently handle complex chemical data, predict molecular properties, and forecast interactions with biological targets. In particular, generative models have introduced novel approaches to drug discovery by learning the probability distribution of training data, extracting key structural features, and generating novel compounds with the desired properties. This capability allows for the generation of new molecules that resemble known active compounds but possess unique structural variations that could lead to improved efficacy and reduced toxicity. In our investigation, we introduced the GDL to build the potential STAT3 inhibitors, which were trained from ZINC database and fine-tuned by current STAT3 inhibitors (Fig. 3A). This virtual molecular library contained the enough chemical space exploration and provided more insights to develop emerging chemical entities as potential STAT3 inhibitors. After screening, we selected the potential molecules, which contained the benzotriazole scaffold and modification with various chemical space exploration.

The application of machine learning extends beyond molecule generation and encompasses a wide range of drug discovery activities, including predicting drug–protein interactions, assessing drug efficacy, and identifying safety biomarkers. These capabilities streamline complex workflows and increase the throughput of drug discovery pipelines. However, despite the significant advancements, several challenges persist. The success of ML models is contingent on the quality and diversity of training data, and there is an ongoing need to enhance the interpretability and transparency of these models to facilitate their integration into conventional drug discovery workflows.

The newly identified STAT3 inhibitors, including HG110, offer a promising therapeutic strategy for NSCLC by targeting the pivotal STAT3 signaling pathway, which plays a critical role in tumorigenesis, immune evasion, and metastasis [47]. These inhibitors work by directly binding to the SH2 domain or the active site of STAT3, preventing its phosphorylation at Tyr705, a crucial step for STAT3 activation and its subsequent nuclear translocation [50]. This inhibition disrupts STAT3’s ability to regulate gene expression involved in cell proliferation, survival, and immune modulation, offering a novel therapeutic approach. In comparison to current standard therapies, such as chemotherapy, EGFR inhibitors, and immune checkpoint inhibitors, STAT3 inhibitors provide several potential advantages. Chemotherapy, while effective, is often associated with significant off-target toxicity and limited efficacy in advanced or metastatic NSCLC [52]. EGFR inhibitors and ALK inhibitors target specific mutations but are limited by the development of resistance [53]. Immune checkpoint inhibitors, though revolutionary in treating NSCLC, are not effective in all patients and may result in immune-related adverse events [54]. STAT3 inhibitors, by targeting a central oncogenic pathway implicated in both tumor progression and resistance mechanisms, may overcome some of these limitations. Moreover, preliminary studies suggest these inhibitors are well tolerated with a manageable safety profile, presenting fewer systemic side effects compared to chemotherapy and fewer immune-related adverse events compared to checkpoint inhibitors. However, challenges remain, including the potential for resistance to STAT3 inhibition and the need for further clinical validation. When used in combination with other therapies, such as immune checkpoint inhibitors, STAT3 inhibitors could potentially enhance therapeutic outcomes, particularly in patients with resistant or refractory disease. Overall, while current therapies have provided significant survival benefits, the emerging STAT3 inhibitors represent a promising addition to the therapeutic armamentarium for NSCLC, with the potential to improve patient outcomes, especially in cases of resistance to traditional treatment modalities.

## Section: Conclusion

This study demonstrates that HG110, a novel small-molecule inhibitor, effectively suppresses NSCLC cell proliferation and induces apoptosis in vitro by targeting STAT3 phosphorylation. Mechanistically, HG110 inhibits STAT3 phosphorylation at Tyr705, disrupting STAT3-mediated oncogenic signaling pathways critical to tumor progression. In vivo, HG110 significantly reduces tumor growth in NSCLC xenograft models, underscoring its potential as an antitumor agent. These findings highlight HG110 as a promising therapeutic candidate for NSCLC treatment. Future research should prioritize optimizing its pharmacokinetic and pharmacodynamic properties to improve clinical applicability. Additionally, investigating the synergistic effects of HG110 in combination with current standard therapies—such as targeted therapies and immune checkpoint inhibitors—may further elucidate its broader therapeutic potential. In conclusion, this study provides a robust foundation for the continued development of HG110 as a novel and effective STAT3 inhibitor, addressing an important unmet need in NSCLC management.

## Section: Supplementary Information

Below is the link to the electronic supplementary material.

Supplementary file1 (DOCX 2306 KB)

## Section: Acknowledgements

We are grateful to Professor Chen Yihua’s research group for providing us with the small-molecule compounds. This work was supported by the National Natural Science Foundation of China (82060663, 82260716), Regional Key R&D Program of Ningxia Hui Automous Region(2023BEG02010).

## Section: Author contributions

Weiji Cai, Beier Jiang, Yichen Ying, Lei Ma, Jing Chen, and Tao Li designed and performed in vivo experiments; Beier Jiang contributed to machine learning- and molecular dynamics simulation-associated experiments; Weiji Cai, Beier Jiang, Yichen Ying, and Lei Ma provided cell lines and assisted with in vitro experiments; Beier Jiang and Weiji Cai analyzed the data and discussed the results; Jing Chen and Tao Li conceived and co-supervised the overall project and wrote the paper with contributions from all authors.

## Section: Data availability

No datasets were generated or analysed during the current study.

## Section: Declarations › Conflict of interest

The authors declare no competing interests.

## Section: Contributor Information

Tao Li, Email: lit1979@163.com.

Jing Chen, Email: chenjing1979@163.com.

## Section: Associated Data

Supplementary file1 (DOCX 2306 KB)

## Section: Associated Data › Supplementary Materials

Supplementary file1 (DOCX 2306 KB)

## Section: Associated Data › Data Availability Statement

No datasets were generated or analysed during the current study.


---

# Identifying molecular subtypes and tumor microenvironment infiltration signatures in kidney renal clear cell carcinoma based on stemness-associated disulfidptosis genes by integrating machine learning, single-cell analyses and experimental validation

- **Authors:** Hongquan Liu, Xiaoqing Liang, Gonglin Tang, Xiaofeng Wang, Zhen Wang, Leijie Tong, Qiancheng Mao, Jian Ma, Jitao Wu
- **Issuer:** Heliyon
- **Type:** Scientific article
- **Published:** 2024-02-13
- **Language:** en
- **DOI:** 10.1016/j.heliyon.2024.e26094
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38390172/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Clear cell renal cell carcinoma (ccRCC) is an aggressive malignant tumor. Disulfidptosis is a new programmed cell death mechanism, which is characterized by the abnormal accumulation of intracellular disulfides that are highly toxic to cells. However, the contribution of disulfidptosis to ccRCC progression has not been fully clarified. In this study, two different molecular subtypes related to disulfidptosis were identified in ccRCC patients by the non-negative matrix factorization (NMF) algorithm. The cluster 1 was characterized by a worse prognosis and higher mRNAsi levels. Then, difference analysis and weighted gene co-expression network analysis (WGCNA) were conducted to search modular genes that are highly associated with tumor stemness and tumor microenvironment. Subsequently, a SADG signature containing nine genes was constructed stepwise by WGCNA and least absolute shrinkage and selection operator (LASSO) Cox regression analysis. The high-risk score group had a worse outcome, and immune regulation and metabolic signatures might be responsible for cancer progression in the high-risk group. After that, a predictive nomogram was constructed, and the predicting power of the risk model was verified using inter and three independent external validation datasets. Nine SADGs were shown to significantly correlate with immune infiltration, tumor mutation burden (TMB), microsatellite instability (MSI) and immune checkpoint. In addition, based on the single-cell RNA sequencing dataset (GSE139555), the distribution and expression of nine hub genes in various types of immune cells were analyzed. Finally, the expression level of the nine genes was verified in clinical samples by qRT-PCR.

## Section: Introduction

Renal cell carcinoma (RCC) is a malignant solid tumor with a high prevalence. In 2023, it is estimated that more than 70,000 new cases of RCC will be diagnosed, along with 13,780 deaths, according to the survey of US statistics [1]. RCC consists of three important histological subtypes—clear cell RCC (ccRCC), papillary RCC, and chromophobe RCC. Among these, ccRCC accounts for more than 70% of RCC incidence [2,3]. Surgery remains the primary therapy for early-stage localized ccRCC patients, yet more than 30% of them suffer from post-surgery recurrence or develop metastases [4,5]. Radiotherapy and chemotherapy are not effective enough in treating advanced metastatic renal cancer, so the clinical management for those patients is extremely limited with a 5-year survival rate of 13% [6]. Recently, targeted therapy and immunotherapy have brought encouraging hope for advanced-stage ccRCC. Current treatments, however, lack specificity, and drug resistance often occurs. Traditional targeted treatment and immunotherapy remain to be ineffective for some patients, leading to generally poor prognoses [7,8]. Thus, exploring the mechanism and prognostic markers of ccRCC is a promising direction for further kidney cancer research.

Tumorigenesis and progression are regulated by the active and controlled cell death process known as programmed cell death (PCD), which is driven by genes [9]. Disulfidptosis, a novel mechanism of cell death, is mediated by the susceptibility of the actin cytoskeleton to disulfide stress, which occurs with the unusual accumulation of disulfides and can be harmful to cells, inhibiting the survival and proliferation of cancer cells [10]. In glucose-starved cells with overexpressed SLC7A11, disulfidptosis is triggered by the accumulation of intracellular disulfides. Liu et al. found that increased SLC7A11 expression in renal cancer cells under glucose deprivation promotes the depletion of nicotinamide adenine dinucleotide phosphate (NADPH) in the cytoplasm [11]. NADPH often offers reducing power to combat disulfide stress and keep cells in a state of equilibrium. However, in the absence of glucose, the pentose phosphate pathway (PPP)'s ability to produce NADPH from glucose is constrained. High rates of cystine uptake mediated by overexpressed SLC7A11 further depletes intracellular NADPH, causing its depletion, which induces multiple intermolecular disulfide-bond formation between actin cytoskeleton proteins and filament (F-actin) contraction, inducing disulfide stress and triggering disulfidptosis, which is toxic to cells [12]. These studies illustrated the significance of disulfidptosis to tumor progression, which may be a focus of cancer immunotherapy in the future. Besides, one of the most important characteristics influencing cancer metastasis is cancer stemness. A particularly promising strategy for cancer treatment is to target cancer stemness [13]. Meanwhile, the development and proliferation of malignant tumors are related to features of the tumor microenvironment, and systemic therapy responses may be impacted by these characteristics [14].

As a new cell death, disulfidptosis holds importance in exploring potentially powerful therapeutic strategies for cancer. The relationship between disulfidptosis and ccRCC patients remains unknown. In our study, we sought to thoroughly explore the molecular characteristics of disulfidptosis-related genes (DRGs) in renal cancer. This study demonstrates the significance of DRGs in the progression of renal cancer and establishes a basis for the therapeutic application of disulfidptosis regulators in kidney cancer. We established and validated a stemness-associated disulfidptosis gene (SADG) signature, which demonstrated high accuracy in estimating the long-term survival of ccRCC patients and response to immunotherapy with independent cohorts. This study holds great potential to provide a unique understanding of the significance of SADG in ccRCC progression and paves the way for the therapeutic application of disulfidptosis regulators in renal cancer.

## Section: Materials and methods

External cohorts used for model validation.

## Section: Materials and methods › Data download and processing

The RNA-seq and clinical data of TCGA-KIRC patients were downloaded from the cancer genome atlas (TCGA) website (https://portal.gdc.cancer.gov/). External validation datasets were downloaded from IMVIGOR210 (http://research-pub.gene.com/), ICGC-RECA (https://dcc.icgc.org/) and E-MTAB-1980 (https://www.ebi.ac.uk/biostudies/). The characteristics of eligible ccRCC patients included in this study were summarized in Supplementary Table 1. Single-cell sequencing data of ccRCC comes from the GEO database (https://www.ncbi.nlm.nih.gov/geo/, GSE139555). Before analysis, all TCGA RNA-seq data was normalized into transcripts per million (TPM) data. The patients with incomplete clinical survival information and expression were excluded from our study. A total of 88 disulfidptosis-related genes were obtained based on published literature (Supplementary Table 2) [11]. Genetic mutation data, including single-nucleotide variants (SNVs) and copy number variation (CNV), was downloaded from the UCSC Xena database (https://xena.ucsc.edu/).

## Section: Materials and methods › NMF clustering and survival analysis

Using the R package “coxph” to conduct univariate Cox analysis to find prognosis-related genes (p < 0.05). The non-negative matrix factorization (NMF) clustering was conducted based on expression data of 44 disulfidptosis-related genes (DRGs) to clustering TCGA-RCC samples (rank = 2:10, method = “brunet, nrun = 10”). After considering indicators such as cophenetic, dispersion, and silhouette, the best K value (K = 2) was determined. Kaplan-Meier (KM) survival analysis was conducted to identify the Overall survival (OS) difference between different NMF clusters.

## Section: Materials and methods › Prognostic risk model construction

All differential expression analysis was performed using the R package “DEseq2” with the following thresholds: adjusted p-value <0.01, |log2 fold change |> 1. The study initially conducted a difference analysis between two groups, NMF-cluster C1 and C2. Subsequently, the researchers employed weighted gene co-expression network analysis (WGCNA) to identify the co-expression module correlated with tumor stemness and tumor microenvironment [15]. Candidate module genes were identified by intersecting the key module genes obtained through WGCNA analysis with the differential genes of cancer and para-cancer in ccRCC patients. Subsequently, genes associated with ccRCC patients' overall survival were screened using univariate analysis. Finally, a stemness-associated disulfidptosis gene (SADG) signature for ccRCC patients was built using the Least Absolute Shrinkage and Operator (LASSO) Cox regression analysis. The risk score is evaluated according to the following formula:

Riskscore = ∑i=xnCoe(genei)*Exp(genei).

Coe(genei): the coefficient of each gene in the SADG signature.

Exp (genei): the relative expression level of each gene in this study.

After that, ccRCC patients were divided into high- and low-risk groups based on the optimal cut-off value for risk score. Kaplan-Meier analysis was conducted to compare the survival rate between high- and low-risk score groups. A nomogram was developed after LASSO and multivariate Cox regression analysis, which integrated the SADG signature and clinicopathological characteristics to predict survival probability. Next, using the R package “ggDCA” to draw decision curve analysis (DCA) and evaluate the predicting power and clinical benefit of the nomogram.

## Section: Materials and methods › Internal and external validation of the prognostic model

Patients with ccRCC from the TCGA were randomly allocated to training and test cohorts at a 7:3 ratio. In our study, in order to compare the overall survival (OS) and progression-free survival (PFS) in low- and high-risk cohorts, we conducted the survival analysis using the R packages "survminer" and "survival". Furthermore, clinical information correlated with the prognosis of patients was combined with riskscore to draw forest charts. Additionally, external datasets were used to validate the SADG signature. As shown in Table 1, three independent external cohorts were used for validating the SADG model.Table 1External cohorts used for model validation.Table 1NameWebsiteIMVIGOR210http://research-pub.gene.com/ICGC-RECAhttps://dcc.icgc.org/E-MTAB-1980https://www.ebi.ac.uk/biostudies/According to the same standards mentioned above, patients in the external cohorts were divided into high- and low-risk score groups. Survival analysis and ROC curve were drawn in these three validation cohorts.

External cohorts used for model validation.

## Section: Materials and methods › Functional enrichment analysis of differentially expressed genes

The R package “ClusterProfiler” was utilized to conduct GSEA analysis between high- and low-risk score groups. The annotation files were downloaded from MSigDB (https://www.gsea-msigdb.org/gsea/msigdb) and ConsensusPathDB (http://cpdb.molgen.mpg.de/) database.

## Section: Materials and methods › Immune infiltration analysis

In this study, the R package “ESTIMATE” was utilized for the estimation of tumor purity and stromal components in the tumor microenvironment (TME) between NMF-cluster C1 and C2 [16]. Moreover, we identified the different infiltrated immune cells between the high- and low-risk score groups based on the CIBERSORT algorithm (https://cibersort.stanford.edu/).

## Section: Materials and methods › Exploring of hub genes by single-cell sequencing

The Tumor Immune Single-Cell Hub (TISCH) (http://tisch.comp-genomics.org) is a scRNA-seq database that attempts to characterize TME at single-cell resolution. With corresponding clinical data, TISCH has more than 70 high-quality single-cell transcriptome datasets of 27 cancers. Based on this database, we analyzed the GSE139555 dataset to explore the heterogeneous expression pattern of nine prognostic genes in ccRCC cells and different immune cells at the single-cell level [17].

## Section: Materials and methods › Validation of nine SADGs by GEPIA

The Gene Expression Profiling Interactive Analysis (GEPIA) database (http://gepia2.cancer-pku.cn/index.html) was utilized for further validation and survival analysis. Based on the TCGA and GTEx databases, the information of gene expression for ccRCC and normal samples was gathered. Survival analysis was conducted based on the survival data of the TCGA database.

## Section: Materials and methods › Collection of human tissue specimens and quantitative real-time polymerase chain reaction (qRT-PCR)

Authorized by the ethics committee of the affiliated Yantai Yuhuangding Hospital of Qingdao University (No.2023-314), ccRCC tissues and adjacent normal samples from eight patients who underwent radical or partial nephrectomy were gathered. Two different pathologists independently verified the pathological specimens. Using SteadyPure Quick RNA Extraction Kit (Accurate Biology, China), we extracted total RNA from clinical samples. Subsequently, The SYBR Green Premix Pro Taq HS qPCR Kit and Rox Reference Dye (Accurate Biology, China) were used for the qRT-PCR procedure. Based on the 2®−ΔΔCT calculation method, we calculated the mRNA expression of core genes. For each experiment, three multiple holes were set. The primer sequences used can be found in Supplementary Table 3.

## Section: Materials and methods › Statistics

All of the bioinformatics analyses were conducted using the software R version 4.2.0. For comparisons between two independent samples and comparisons among multiple samples for non-parametric data, respectively, we utilized the Wilcoxon test and the Kruskal–Wallis test. For parametric data, t-tests and one-way ANOVA were utilized. We conducted the survival study using the Kaplan-Meier method and the log-rank test. For each analysis, p < 0.05 was considered statistically significant.

## Section: Results

Workflow of this study.

Identification of disulfidptosis -related genes related NMF-cluster.

(A) TCGA-KIRC patients were divided into two distinct gene cluster by using non-negative matrix factorization (NMF) based on disulfidptosis -related genes.

(B) Survial analysis of OS between NMF-cluster 1 and NMF-cluster 2 in TCGA-KIRC patients.

(C) Expression profile of disulfidptosis-related genes and the relationship with clinical information shaped by NMF-cluster 1 and NMF-cluster 2.

(D) The mDNAsi and EREG-mDNAsi difference between NMF-cluster 1 and NMF-cluster 2.

(E) The mRNAsi and EREG-mRNAsi difference between NMF-cluster 1 and NMF-cluster 2.

(F) The stromal score, immune score and ESTIMATE score difference between NMF-cluster 1 and NMF-cluster 2.

Construction of the stemness-associated disulfidptosis gene (SADG) signature.

(A) Difference expressed genes between NMF-cluster C1 and NMF-cluster C2.

(B) Module-trait associations based on the WGCNA.

(C) The relationship between WGCNA gene modules with stemness index and tumor microenvironment.

(D) Volcano plot showed the DEGs between cancer and para-cancer tissue in TCGA-KIRC patients.

(E) Venn plot showed intersection of gene lists between up-expressed genes in tumor tissue and hub genes in WGCNA.

(F) Forest map showed univariate Cox regression analysis result of 71 cell stemness and TME associated disulfidptosis-related DEGs.

(G, H) Least absolute shrinkage and selection operator (LASSO) regression analysis.

The coefficient of each gene in SADG signature.

Kaplan-Meier analysis of PFS and OS between low- and high-risk score subgroup in the entire, internal training sets and validation sets.

(A) K-M plot of PFS of entire TCGA-KIRC set.

(B) K-M plot of OS of entire TCGA-KIRC set.

(C) K-M plot of PFS of TCGA-KIRC test set.

(D) K-M plot of OS of TCGA-KIRC test set.

(E) K-M plot of PFS of TCGA-KIRC training set.

(F) K-M plot of OS of TCGA-KIRC training set.

(K–M: Kaplan-Meier analysis, OS: overall survival, PFS: progression-free survival).

Kaplan-Meier analysis of OS between low- and high-risk score subgroup in the external validation sets.

(A) Survival curve for OS in the IMvigor210.

(B) 1-,3-,5-year ROC curves of SADG signature in the IMvigor210.

(C) Survival curve for OS in the ICGC-RECA.

(D) 1-,3-,5-year ROC curves of SADG signature in the ICGC-RECA.

(E) Survival curve for OS in the E-MTAB-1980.

(F) 1-,3-,5-year ROC curves of SADG signature in the E-MTAB-1980.

Development of a clinical practicability nomogram.

(A) Development of a nomogram based on TNM stage, gender, age, stage and riskscore in internal training dataset.

(B) Calibration curves for 1-, 3-, and 5-year survival rates in the internal training dataset.

(C) DCA curves of the internal training dataset.

(D) The nomogram based on TNM stage, gender, age, stage and riskscore in internal test dataset.

(E) Calibration curves for 1-, 3-, and 5-year survival rates in the internal test dataset.

(F) DCA curves of the internal test dataset.

(DCA: decision curve analysis, (*p-value <0.05; **p-value <0.01; ***p-value <0.001).

Univariate and multivariate Cox analyses of SADG and clinical factors.

(A) Univariate Cox analysis of SADG and clinical factors (Age, gender and stage).

(B) Multivariate Cox analysis of SADG and clinical factors (Age, gender and stage).

(C, D, E) The ROC curves for 1-, 3-, and 5-year prediction of the nomogram, and AUC values are calculated.

Immune infiltration analysis associated with SADG signature.

(A) Immune checkpoints expression profile shaped by SADGs in TCGA-KIRC patients.

(B) Box plot showed tumor immune subtype influenced by SADGs.

(C, D, E) The difference of Immune score, stromal score and tumor purity between low- and high-riskscore group in TCGA-KIRC patients.

Immune infiltration analysis associated with SADG signature.

(A) Box plot display the ssGSEA analysis result of SADG in TCGA-KIRC patients.

(B) Immune cell infiltration difference between low- and high-risk score group.

Gene set enrichment analysis result.

(A) GSEA functional enrichment analysis of high-risk group.

(B) GSEA functional enrichment analysis of low-risk group.

Expression patterns of nine key SADGs in single-cell RNA sequencing of ccRCC.

(A) Clusters for ccRCC cases.

(B) UMAP plot of 11 predominant cell types in the ccRCC tumor microenvironment. (C)Visualization of percentage of cell number distribution of each cell type in all ccRCC cases.

(D) The distribution of cells in each ccRCC case in GSE139555.

(E) UMAP plots for visualizing the distribution of nine DRGs in various types of cells.

(F) Violin plot for displaying the expression levels of nine DRGs in each cell types.

The expression of nine SADGs at the single-cell level after stratification based on stage. The expression of (A) MYO1F, (B) FMNL1, (C) FCGR1B, (D) TNFAIP8L2, (E) CYTH4, (F) NCF4, (G) TNFSF13B, (H) POU2F2 and (I) SLAMF1 at the single-cell level after stratification based on stage.

Somatic mutation landscape.

(A) The waterfall plot showed the top 15 most mutated genes individually in high-risk group.

(B) The waterfall plot showed the top 15 most mutated genes individually in low-risk group.

(C) Scatter diagram showed the relationship between risk score and tumor Mutations burden.

(D–E) Association between risk score and MSI (D) as well as TIDE (E).

Expression pattern validation and the relationship between the expression of the nine SADGs and the prognosis of ccRCC patients.

(A) Expression levels of the nine SADGs in ccRCC and normal tissues from the GEPIA database.

(B) The prognostic value of the nine SADGs expression ccRCC overall survival (OS).

The relative expression levels of the nine SADGs in ccRCC tumor tissues and para-cancerous tissues. The relative expression levels of (A) MYO1F, (B) FMNL1, (C) FCGR1B, (D) TNFAIP8L2, (E) CYTH4, (F) NCF4, (G) TNFSF13B, (H) POU2F2 and (I) SLAMF1 in ccRCC tumor tissues and para-cancerous tissues.

## Section: Results › NMF clustering based on disulfidptosis-related genes (DRGs) in patients with ccRCC

The whole workflow of our study is presented in Fig. 1. Firstly, the “coxph” function in the R package “survival” was performed to conduct univariate Cox regression analysis, and 44 OS-related DRGs were found (p < 0.05). Next, using NMF clustering, we discovered two ccRCC subtypes associated with DRGs according to the filter standard (Fig. 2A and Supplementary Fig. 1). The KM curves showed that the OS of patients in cluster 1 was better than in cluster 2 (Fig. 2B). The DRGs expression profile of ccRCC patients is divided into two clusters (Fig. 2C).Fig. 1Workflow of this study.Fig. 1Fig. 2Identification of disulfidptosis -related genes related NMF-cluster.(A) TCGA-KIRC patients were divided into two distinct gene cluster by using non-negative matrix factorization (NMF) based on disulfidptosis -related genes.(B) Survial analysis of OS between NMF-cluster 1 and NMF-cluster 2 in TCGA-KIRC patients.(C) Expression profile of disulfidptosis-related genes and the relationship with clinical information shaped by NMF-cluster 1 and NMF-cluster 2.(D) The mDNAsi and EREG-mDNAsi difference between NMF-cluster 1 and NMF-cluster 2.(E) The mRNAsi and EREG-mRNAsi difference between NMF-cluster 1 and NMF-cluster 2.(F) The stromal score, immune score and ESTIMATE score difference between NMF-cluster 1 and NMF-cluster 2.Fig. 2

During cancer progression, cancer cells lose their differentiated phenotype and acquisition of characteristics similar to progenitor cells and stem cells. Tumor stem cells undergo a loss of their various differentiation phenotypes while simultaneously acquiring the ability of self-renewal and differentiation [18,19]. The stemness index (SI) is a commonly used metric in stemness research, and tumor stem cell-like features (mRNAsi) were used to describe it based on the mRNA expression file [18]. EREG-mRNAsi is a stemness index that is created through the use of a panel of genes that are associated with stemness and regulated by epigenetics. Upon comparing the two NMF-clusters, it was observed that cluster-c2 had higher mDNAsi, ERGE-mDNSsi, and EREG-mRNAsi, whereas cluster 1 exhibited higher mRNAsi levels (as illustrated in Fig. 2D and E). The TME represents a complex ecosystem and is comprised of stromal cells, endothelial cells, pericytes, and innate and adaptive immune cells [20]. Illustrating the interactions between cancer cells and TME will help improve therapeutic targets since contact-dependent communication may promote immune evasion and tumor progression [21,22]. In this study, the TME score (comprised of stromal score, immune score and ESTIMATE score) was compared between NMF-cluster 1 and NMF-cluster 2. The cluster 1 showed a lower stromal score but a higher immune score and ESTIMATE score, indicating that the patients in cluster 1 got more immunosuppressive cells and had a relatively worse prognostic outcome (Fig. 2F).

Workflow of this study.

Identification of disulfidptosis -related genes related NMF-cluster.

(A) TCGA-KIRC patients were divided into two distinct gene cluster by using non-negative matrix factorization (NMF) based on disulfidptosis -related genes.

(B) Survial analysis of OS between NMF-cluster 1 and NMF-cluster 2 in TCGA-KIRC patients.

(C) Expression profile of disulfidptosis-related genes and the relationship with clinical information shaped by NMF-cluster 1 and NMF-cluster 2.

(D) The mDNAsi and EREG-mDNAsi difference between NMF-cluster 1 and NMF-cluster 2.

(E) The mRNAsi and EREG-mRNAsi difference between NMF-cluster 1 and NMF-cluster 2.

(F) The stromal score, immune score and ESTIMATE score difference between NMF-cluster 1 and NMF-cluster 2.

## Section: Results › Identification and vilification of SADG signature

Firstly, differentially expressed genes (DEGs) analysis was conducted between NMF-cluster 1 and NMF-cluster 2, and 11509 DEGs were obtained (Fig. 3A, Supplementary Table 4). WGCNA is a systems biology method used to describe gene association patterns between different samples, which can be used to identify gene sets with highly synergistic changes and to identify candidate organisms based on the interconnection of gene sets and the relationship between gene sets and phenotypes marker genes or therapeutic targets. In our study, we used WCGNA to screen the DEGs related to cell stemness and TME by obtaining the most relevant modules (Fig. 3B). As shown in Fig. 3C, the co-expression pink module was significantly positively associated with cell stemness and TME (Supplementary Table 5). Next, differentially expressed analysis was carried out in cancer and para-cancer tissues in TCGA-KIRC transcriptome data (Fig. 3D). By taking the intersection of the up-expressed genes in tumor tissues and hubgenes from WGCNA, we obtained 71 stemness and TME associated disulfidptosis-related DEGs. After that, we screened genes that were closely correlated with OS based on univariate Cox regression analysis (Fig. 3E and F). Finally, LASSO and multiCox analysis identified nine signature genes: MYO1F, FMNL1, FCGR1B, TNFAIP8L2, CYTH4, NCF4, TNFSF13B, POU2F2 and SLAMF1 (Fig. 3G and H). The coefficient of each gene in the prognostic signature is shown in Table 2.Fig. 3Construction of the stemness-associated disulfidptosis gene (SADG) signature.(A) Difference expressed genes between NMF-cluster C1 and NMF-cluster C2.(B) Module-trait associations based on the WGCNA.(C) The relationship between WGCNA gene modules with stemness index and tumor microenvironment.(D) Volcano plot showed the DEGs between cancer and para-cancer tissue in TCGA-KIRC patients.(E) Venn plot showed intersection of gene lists between up-expressed genes in tumor tissue and hub genes in WGCNA.(F) Forest map showed univariate Cox regression analysis result of 71 cell stemness and TME associated disulfidptosis-related DEGs.(G, H) Least absolute shrinkage and selection operator (LASSO) regression analysis.Fig. 3Table 2The coefficient of each gene in SADG signature.Table 2Gene idEnsemble idcoefficientHazard ratioMYO1FENSG00000142347−0.83801.245(1.002–1.548)FMNL1ENSG000001849220.81041.488(1.171–1.890)FCGR1BENSG000002911350.35801.407(1.155–1.713)TNFAIP8L2ENSG00000163154−0.45911.245(1.001–1.549)CYTH4ENSG00000100055−0.51841.275(1.023–1.589)NCF4ENSG000001003650.49041.374(1.093–1.726)TNFSF13BENSG000001025240.29881.386(1.144–1.681)POU2F2ENSG000000282770.56201.486(1.214–1.819)SLAMF1ENSG00000117090−0.28111.216(1.016–1.455)Riskscore = (−0.8380 * exp MYO1F) + (0.8104 * exp FMNL1) + (0.3580 * exp FCGR1B) + (−0.4591 * exp TNFAIP8L2) + (−0.5184* exp CYTH4) + (0.4904 * exp NCF4) + (0.2988 * exp TNFSF13B) + (0.5620 * exp POU2F2) + (−0.2811 * exp SLAMF1).

In the end, we divided the patients from the TCGA-KIRC cohort into high- and low-risk groups based on the median of the riskscore. Longer OS and PFS were found in the low-risk group in the entire TCGA-KIRC set, internal training set and test set (Fig. 4A–F). The prognosis evaluation of the risk model was verified in external validation datasets IMVIGOR210, ICGC-RECA and E-MTAB-1980 (Fig. 5A–F).Fig. 4Kaplan-Meier analysis of PFS and OS between low- and high-risk score subgroup in the entire, internal training sets and validation sets.(A) K-M plot of PFS of entire TCGA-KIRC set.(B) K-M plot of OS of entire TCGA-KIRC set.(C) K-M plot of PFS of TCGA-KIRC test set.(D) K-M plot of OS of TCGA-KIRC test set.(E) K-M plot of PFS of TCGA-KIRC training set.(F) K-M plot of OS of TCGA-KIRC training set.(K–M: Kaplan-Meier analysis, OS: overall survival, PFS: progression-free survival).Fig. 4Fig. 5Kaplan-Meier analysis of OS between low- and high-risk score subgroup in the external validation sets.(A) Survival curve for OS in the IMvigor210.(B) 1-,3-,5-year ROC curves of SADG signature in the IMvigor210.(C) Survival curve for OS in the ICGC-RECA.(D) 1-,3-,5-year ROC curves of SADG signature in the ICGC-RECA.(E) Survival curve for OS in the E-MTAB-1980.(F) 1-,3-,5-year ROC curves of SADG signature in the E-MTAB-1980.Fig. 5

Construction of the stemness-associated disulfidptosis gene (SADG) signature.

(A) Difference expressed genes between NMF-cluster C1 and NMF-cluster C2.

(B) Module-trait associations based on the WGCNA.

(C) The relationship between WGCNA gene modules with stemness index and tumor microenvironment.

(D) Volcano plot showed the DEGs between cancer and para-cancer tissue in TCGA-KIRC patients.

(E) Venn plot showed intersection of gene lists between up-expressed genes in tumor tissue and hub genes in WGCNA.

(F) Forest map showed univariate Cox regression analysis result of 71 cell stemness and TME associated disulfidptosis-related DEGs.

(G, H) Least absolute shrinkage and selection operator (LASSO) regression analysis.

The coefficient of each gene in SADG signature.

Kaplan-Meier analysis of PFS and OS between low- and high-risk score subgroup in the entire, internal training sets and validation sets.

(A) K-M plot of PFS of entire TCGA-KIRC set.

(B) K-M plot of OS of entire TCGA-KIRC set.

(C) K-M plot of PFS of TCGA-KIRC test set.

(D) K-M plot of OS of TCGA-KIRC test set.

(E) K-M plot of PFS of TCGA-KIRC training set.

(F) K-M plot of OS of TCGA-KIRC training set.

(K–M: Kaplan-Meier analysis, OS: overall survival, PFS: progression-free survival).

Kaplan-Meier analysis of OS between low- and high-risk score subgroup in the external validation sets.

(A) Survival curve for OS in the IMvigor210.

(B) 1-,3-,5-year ROC curves of SADG signature in the IMvigor210.

(C) Survival curve for OS in the ICGC-RECA.

(D) 1-,3-,5-year ROC curves of SADG signature in the ICGC-RECA.

(E) Survival curve for OS in the E-MTAB-1980.

(F) 1-,3-,5-year ROC curves of SADG signature in the E-MTAB-1980.

## Section: Results › Nomogram construction and clinicopathological characteristic based on SADG prognostic signature

We constructed a clinical utility nomogram to explore the relationship between SADG and the clinicopathological characteristics of ccRCC patients. Clinical factors and riskscore were incorporated in the nomogram in the internal training set and test set (Fig. 6A–D). The prediction power of the nomogram was close to the ideal curve (Fig. 6B–E). The nomogram in this study has outstanding performance in predicting 1-,3- and 5- year OS, as shown in DCA curves (Fig. 6C–F). Using univariate and multivariate Cox analysis, we can find that the riskscore has independent predicting power in ccRCC patients (Fig. 7A and B). As shown in the receiver operating characteristic (ROC) curve (Fig. 7C–E), this nomogram that combined riskscore and clinicopathological characteristics has better predictive effectiveness in predicting 1-,3- and 5-yeas OS in patients with ccRCC than riskscore alone.Fig. 6Development of a clinical practicability nomogram.(A) Development of a nomogram based on TNM stage, gender, age, stage and riskscore in internal training dataset.(B) Calibration curves for 1-, 3-, and 5-year survival rates in the internal training dataset.(C) DCA curves of the internal training dataset.(D) The nomogram based on TNM stage, gender, age, stage and riskscore in internal test dataset.(E) Calibration curves for 1-, 3-, and 5-year survival rates in the internal test dataset.(F) DCA curves of the internal test dataset.(DCA: decision curve analysis, (*p-value <0.05; **p-value <0.01; ***p-value <0.001).Fig. 6Fig. 7Univariate and multivariate Cox analyses of SADG and clinical factors.(A) Univariate Cox analysis of SADG and clinical factors (Age, gender and stage).(B) Multivariate Cox analysis of SADG and clinical factors (Age, gender and stage).(C, D, E) The ROC curves for 1-, 3-, and 5-year prediction of the nomogram, and AUC values are calculated.Fig. 7

Development of a clinical practicability nomogram.

(A) Development of a nomogram based on TNM stage, gender, age, stage and riskscore in internal training dataset.

(B) Calibration curves for 1-, 3-, and 5-year survival rates in the internal training dataset.

(C) DCA curves of the internal training dataset.

(D) The nomogram based on TNM stage, gender, age, stage and riskscore in internal test dataset.

(E) Calibration curves for 1-, 3-, and 5-year survival rates in the internal test dataset.

(F) DCA curves of the internal test dataset.

(DCA: decision curve analysis, (*p-value <0.05; **p-value <0.01; ***p-value <0.001).

Univariate and multivariate Cox analyses of SADG and clinical factors.

(A) Univariate Cox analysis of SADG and clinical factors (Age, gender and stage).

(B) Multivariate Cox analysis of SADG and clinical factors (Age, gender and stage).

(C, D, E) The ROC curves for 1-, 3-, and 5-year prediction of the nomogram, and AUC values are calculated.

## Section: Results › Immune infiltration analysis associated with SADG signature

Shaped by SADGs, patients in the low- and high-risk groups showed different expression patterns of immune checkpoints. In the high-risk score subgroup, IFNG, PTPRC, LAG3, CD86, TNFRSF9, LGALS9, CD8A, CD40LG, TNFSF9, IL23A and CD80 are highly expressed (Fig. 8A). Previous studies have analyzed tumor samples in TCGA and identified six immune subtypes to characterize the immune landscape. Six immune subtypes were clustered, namely C1 (wound healing), C2 (IFN-g dominant), C3 (inflammatory), C4 (lymphocyte depleted), C5 (immunologically quiet) and C6 (TGF-β dominant) [23]. Among the six tumor immune subtypes, subtype C1 got the highest risk score (Fig. 8B). Furthermore, the high-risk subgroup had a higher immune score and stromal score but lower tumor purity (Fig. 8C–E). In addition, ssGSEA analysis showed that the high-risk score subgroup had a higher score in Inflammation−promoting, Tfh and Inflammation−promoting (Fig. 9A). The high-risk score group had more infiltration of CD8 cells, Treg cells, T cells CD4 memory resting and NK cells resting, which mainly conducted anti-tumor immunity (Fig. 9B).Fig. 8Immune infiltration analysis associated with SADG signature.(A) Immune checkpoints expression profile shaped by SADGs in TCGA-KIRC patients.(B) Box plot showed tumor immune subtype influenced by SADGs.(C, D, E) The difference of Immune score, stromal score and tumor purity between low- and high-riskscore group in TCGA-KIRC patients.Fig. 8Fig. 9Immune infiltration analysis associated with SADG signature.(A) Box plot display the ssGSEA analysis result of SADG in TCGA-KIRC patients.(B) Immune cell infiltration difference between low- and high-risk score group.Fig. 9

Immune infiltration analysis associated with SADG signature.

(A) Immune checkpoints expression profile shaped by SADGs in TCGA-KIRC patients.

(B) Box plot showed tumor immune subtype influenced by SADGs.

(C, D, E) The difference of Immune score, stromal score and tumor purity between low- and high-riskscore group in TCGA-KIRC patients.

Immune infiltration analysis associated with SADG signature.

(A) Box plot display the ssGSEA analysis result of SADG in TCGA-KIRC patients.

(B) Immune cell infiltration difference between low- and high-risk score group.

## Section: Results › SADGs-associated different functional pathways

In order to quest potential biological processes influenced by the SADGs, we used GSEA to explore the significant signaling pathway that high- and low-risk patients enriched in. As shown in Fig. 10A and B, high-risk patients were correlated with immune-associated processes, such as the chemokine signaling pathway, Nod-like receptor signaling pathway and primary immunodeficiency, etc. Meanwhile, the low-risk group was mainly enriched in the fatty acid metabolism, oxidative phosphorylation, PPAR signaling pathway, etc.Fig. 10Gene set enrichment analysis result.(A) GSEA functional enrichment analysis of high-risk group.(B) GSEA functional enrichment analysis of low-risk group.Fig. 10

Gene set enrichment analysis result.

(A) GSEA functional enrichment analysis of high-risk group.

(B) GSEA functional enrichment analysis of low-risk group.

## Section: Results › Correlation between hub genes and tumor immune microenvironment of ccRCC

The cellular heterogeneity of tumors and their surroundings are essentially mapped by single-cell RNA-sequencing (scRNA-seq), which offers transcript abundance of individual cells with high sensitivity. In the study, we analyzed the ccRCC data (GSE139555) using the TISCH database. UMAP-based cell clustering results in the identification of 25 significant clusters after dimensionality reduction (Fig. 11A). These clusters were designated as B cells, conventional CD4+ T cells (CD4Tconv), CD8 T+ cells, exhausted CD8+ T cells (CD8Tex), Dendritic Cells (DC), Mast Cells, endothelial cells, monocytes or macrophages (Mono/Macro), Natural Killer Cells (NK), plasmocytes, and Tprolif cells based on the lineage markers (Fig. 11B). As shown in Fig. 11 C, D, we visualized the proportion of cell numbers in all patients of GSE139555 and the distribution of cells in each case. Of the nine genes in our constructed model, MYO1F was mainly distributed in monocytes/macrophages, NK cells and DC cells. FMNL1 and TNFAIP8L2 were mainly expressed in monocytes/macrophages, DC cells and Tprolif cells. FCGR1B was mainly enriched in monocytes/macrophages and Tprolif cells. CYTH4 and TNFSF13B were mainly expressed in monocytes/macrophages and DC cells. NCF4 was mainly distributed in plasmocytes, Mast Cells, monocytes/macrophages, DC cells and B cells. POU2F2 was mainly enriched in monocytes/macrophages and B cells. SLAMF1 was mainly distributed in plasmocytes (Fig. 11E and F). Furthermore, we compared the expression of nine DRGs in various immune cell types of ccRCC patients stratified based on the TNM stage, and we found the expression of these hub genes in specific immune cells was statistically different in patients with different stages. As shown in Fig. 12A, the expression of MYO1F in conventional CD4+ T cells, CD8 T+ cells, exhausted CD8+ T cells, and NK cells was statistically different in patients with different TNM stages. FMNL1 expression was shown to be statistically different in B cells, conventional CD4+ T cells and monocytes/macrophages (Fig. 12B). No statistical difference was discovered in FCGR1B expression in immune cell types was discovered (Fig. 12C). There were statistically different TNFAIP8L2 expression levels in B cells, conventional CD4+ T cells, and monocytes/macrophages (Fig. 12D). And we discovered that the CYTH4 expression in various immune cell types was statistically significant, such as in conventional CD4+ T cells, CD8 T+ cells, exhausted CD8+ T cells, NK cells and Tprolif cells (Fig. 12E). NCF4 expression in DC cells, monocytes/macrophages, and Tprolif cells was different (Fig. 12F). Likewise, the expression level of TNFSF13B expression in plasmocytes and Tprolif cells was significantly different (Fig. 12G). POU2F2 expression was shown to be statistically different in B cells, conventional CD4+ T cells, exhausted CD8+ T cells, monocytes/macrophages and Tprolif cells (Fig. 12H). And we found that the expression of SLAMF1 in B cells, conventional CD4+ T cells and monocytes/macrophages was statistically different (Fig. 12I). Overall, the findings showed that the nine SADGs were highly related to the tumor immune microenvironment.Fig. 11Expression patterns of nine key SADGs in single-cell RNA sequencing of ccRCC.(A) Clusters for ccRCC cases.(B) UMAP plot of 11 predominant cell types in the ccRCC tumor microenvironment. (C)Visualization of percentage of cell number distribution of each cell type in all ccRCC cases.(D) The distribution of cells in each ccRCC case in GSE139555.(E) UMAP plots for visualizing the distribution of nine DRGs in various types of cells.(F) Violin plot for displaying the expression levels of nine DRGs in each cell types.Fig. 11Fig. 12The expression of nine SADGs at the single-cell level after stratification based on stage. The expression of (A) MYO1F, (B) FMNL1, (C) FCGR1B, (D) TNFAIP8L2, (E) CYTH4, (F) NCF4, (G) TNFSF13B, (H) POU2F2 and (I) SLAMF1 at the single-cell level after stratification based on stage.Fig. 12

Expression patterns of nine key SADGs in single-cell RNA sequencing of ccRCC.

(A) Clusters for ccRCC cases.

(B) UMAP plot of 11 predominant cell types in the ccRCC tumor microenvironment. (C)Visualization of percentage of cell number distribution of each cell type in all ccRCC cases.

(D) The distribution of cells in each ccRCC case in GSE139555.

(E) UMAP plots for visualizing the distribution of nine DRGs in various types of cells.

(F) Violin plot for displaying the expression levels of nine DRGs in each cell types.

The expression of nine SADGs at the single-cell level after stratification based on stage. The expression of (A) MYO1F, (B) FMNL1, (C) FCGR1B, (D) TNFAIP8L2, (E) CYTH4, (F) NCF4, (G) TNFSF13B, (H) POU2F2 and (I) SLAMF1 at the single-cell level after stratification based on stage.

## Section: Results › SADG signature influenced somatic mutation landscape of ccRCC patients

We conducted somatic mutation analysis between the two groups in TCGA-KIRC patients. There was a difference in the frequency of mutations. The mutation frequency of gene VHL, PBRM1, SETD2, BAP1 and MTOR was higher in the high-risk group, which mainly were missense mutations (Fig. 13A and B). Then, we found that the tumor mutation burden increased with the increasing risk score (Fig. 13C). Furthermore, the high-risk score group had higher microsatellite instability (MSI) (Fig. 13D). The predictive markers and mechanisms of immunotherapy resistance are the focus of current research. TIDE (Tumor Immune Dysfunction and Exclusion) analysis is usually used to estimate the effectiveness of immune checkpoint blocking (anti-PD-1/anti-CTLA-4) therapy. A higher TIDE score means a higher likelihood of immune surveillance evasion and a lower immunotherapy success rate. In this study, the high-risk group in the SADG signature showed a higher TIDE score, which indicates the SADG signature has good performance in predicting the immunotherapy response [24] (Fig. 13E).Fig. 13Somatic mutation landscape.(A) The waterfall plot showed the top 15 most mutated genes individually in high-risk group.(B) The waterfall plot showed the top 15 most mutated genes individually in low-risk group.(C) Scatter diagram showed the relationship between risk score and tumor Mutations burden.(D–E) Association between risk score and MSI (D) as well as TIDE (E).Fig. 13

Somatic mutation landscape.

(A) The waterfall plot showed the top 15 most mutated genes individually in high-risk group.

(B) The waterfall plot showed the top 15 most mutated genes individually in low-risk group.

(C) Scatter diagram showed the relationship between risk score and tumor Mutations burden.

(D–E) Association between risk score and MSI (D) as well as TIDE (E).

## Section: Results › Expression verification of nine SADGs between ccRCC samples and normal samples and survival analysis by GEPIA

In our study, the GEPIA database was utilized to confirm the differential expression of nine SADGs between ccRCC and normal samples. As shown in Fig. 14A, in comparison to normal samples, mRNA expression levels of MYO1F, FMNL1, FCGR1B, TNFAIP8L2, CYTH4, NCF4, TNFSF13B and POU2F2 were significantly higher in ccRCC. Although not significantly, SLAMF1 was also highly expressed in ccRCC compared with para-cancer samples. Furthermore, utilizing the GEPIA online database, a survival analysis was also carried out. Patients were grouped based on the median gene expression levels. High expression of FMNL1 (P = 0.048, HR = 1.4), NCF4 (P = 0.0053, HR = 1.5), TNFSF13B (P = 0.0097, HR = 1.5) and POU2F2 (P = 0.024, HR = 1.4) was related to poor prognosis (Fig. 14B).Fig. 14Expression pattern validation and the relationship between the expression of the nine SADGs and the prognosis of ccRCC patients.(A) Expression levels of the nine SADGs in ccRCC and normal tissues from the GEPIA database.(B) The prognostic value of the nine SADGs expression ccRCC overall survival (OS).Fig. 14

Expression pattern validation and the relationship between the expression of the nine SADGs and the prognosis of ccRCC patients.

(A) Expression levels of the nine SADGs in ccRCC and normal tissues from the GEPIA database.

(B) The prognostic value of the nine SADGs expression ccRCC overall survival (OS).

## Section: Results › Experimental verification of the expression of nine SADGs in clinical samples

To verify the reliability of the nine SADGs that made up the risk model, eight paired tissues of cancer and adjacent normal tissues from ccRCC patients were used to explore the expression level of 9 SADGs by qRT-PCR. As shown in Fig. 15, high expression of FMNL1, TNFAIP8L2, CYTH4, NCF4, TNFSF13B and POU2F2 was found in ccRCC based on the qRT-PCR analysis. Besides, there was a trend of upregulation of MYO1F, FCGR1B and SLAMF1 in tumor tissues, but it was not statistically significant, which may be attributed to the small sample size and excessive individual differences.Fig. 15The relative expression levels of the nine SADGs in ccRCC tumor tissues and para-cancerous tissues. The relative expression levels of (A) MYO1F, (B) FMNL1, (C) FCGR1B, (D) TNFAIP8L2, (E) CYTH4, (F) NCF4, (G) TNFSF13B, (H) POU2F2 and (I) SLAMF1 in ccRCC tumor tissues and para-cancerous tissues.Fig. 15

The relative expression levels of the nine SADGs in ccRCC tumor tissues and para-cancerous tissues. The relative expression levels of (A) MYO1F, (B) FMNL1, (C) FCGR1B, (D) TNFAIP8L2, (E) CYTH4, (F) NCF4, (G) TNFSF13B, (H) POU2F2 and (I) SLAMF1 in ccRCC tumor tissues and para-cancerous tissues.

## Section: Discussion

As the most common subtype of all renal cancers, ccRCC is highly aggressive [25]. Immune blockade and targeted therapy have shown remarkable outcomes. However, not all patients respond well to such therapies [26,27]. Therefore, it is crucial to explore novel therapeutic targets or adjuvants to enhance immune therapy for renal cancer. The occurrence of tumors is a dynamic process influenced by a wide range of factors, multiple stages and multiple genes. And the dysregulation of programmed cell death is closely correlated with the occurrence and prognosis of tumors [28]. Disulfidptosis exhibits an unusual accumulation of intracellular disulfides, which sets it apart from other forms of PCD processes. In the condition of high SLC7A11 expression, limiting NADPH synthesis from the PPP by glucose deprivation results in a significant buildup of small molecule disulfides, a number of redox abnormalities, as well as rapid cell death [11,29]. That's to say, disulfidptosis has the potential to be applied to a novel effective therapy method for ccRCC patients. Besides, a subgroup of tumor cells known as cancer stem cells (CSCs) has the ability to initiate tumors and trigger relapses. Due to the primary characteristics of cancer stem cells, it is claimed that cancer stemness is the primary reason for metastasis and tumor relapse following conventional therapy. In addition to genetic modification, TME may play a role in facilitating the acquisition of stemness characteristics [30,31].

Currently, there is limited research on the impact of disulfidoptosis-related genes on the prognosis of ccRCC. In our study, we collected 88 DRGs. Using univariate Cox regression analysis, we obtained 44 prognostic genes in ccRCC. Then, we discovered two ccRCC subtypes associated with DRG from the TCGA through the NMF algorithm. Compared to the C1 subtype, ccRCC patients in cluster 2 had a better clinical outcome, which confirmed the significance of DRGs in ccRCC prognosis. Next, differential genes related to cell stemness and TME were obtained through WGCNA analysis with the differential genes between the two clusters. And we obtained 71 cell stemness and TME associated disulfidptosis-related DEGs by taking the intersection up-expressed genes in tumor samples and hub genes in WGCNA. After univariate Cox analysis, we used LASSO regression analysis based on the expression matrix of genes highly related to outcome (p < 0.05) to establish a prognostic signature including nine genes (MYO1F, FMNL1, FCGR1B, TNFAIP8L2, CYTH4, NCF4, TNFSF13B, POU2F2 and SLAMF1) from the training set, which shown great efficiency in predicting survival outcome and immunotherapeutic response. Additionally, the disulfidptosis risk score was identified as an independent prognostic factor in ccRCC patients. Subsequently, a nomogram was developed, integrating the risk score and clinical features, to predict the survival outcome of ccRCC patients.

Of the nine genes in our constructed model, MYO1F is associated with the mitochondrial network and promotes tumor growth in thyroid cancer [32]. Low expression of FMNL1 may prevent the proliferation of kidney cancer cells, which is a potential KIRC-specific neoantigen candidate for KIRC mRNA vaccine development. FCGR1B is the Fc fragment of immunoglobulin G and is related to the poor prognostic of ccRCC patients [33]. TNFAIP8L2 is highly expressed in various tumors and is related to the process of immunological homeostasis [34]. According to a recent study, TNFAIP8 may be correlated with tumor-associated microbiota in colorectal cancer [35]. CYTH4 belongs to the PSCD family, regulating protein sorting and membrane dynamics. In glioma, the overexpression of CYTH4 is a biomarker for predicting a poor prognosis by affecting pyroptosis [36]. NCF4 is a component of the NAPDH complex, correlated with immune activation and immunological regulation [37]. TNFSF13B, commonly known as BAFF, is a member of the tumor necrosis factor (TNF) ligand family. It could serve as a crucial communication channel between the tumor cell and the tumor microenvironment for KIRC [38]. As a marker of prognosis in cancer, POU2F2 is highly expressed in various solid tumors. POU2F2 has been implicated in promoting the glycolysis and progression of glioblastoma by the activation the AKT pathway [[39], [40], [41], [42]]. SLAMF1 has been described as a vital molecule in regulating autophagy in chronic lymphocytic leukemia cells. In choriocarcinoma, SLAMF1 promotes resistance to MTX by activating autophagy-related pathways [43]. These key genes' differential expression was strongly correlated with the prognosis of tumors. Further research on these molecules may provide a reference for exploring novel therapeutics and prognostic indicators for renal cancer.

TME is a dynamic system and is characterized by various components, including immune cells, stromal cells and cytokines, which is not only closely correlated with the occurrence, growth and metastasis of tumors, but also vital to the treatment of tumors [44,45]. TME plays a crucial part in malignant progression, immune escape and treatment resistance. TME relies largely on CD8 T cells, which are essential for recognising and eliminating tumor cells [46]. Besides, neutrophils play a crucial role as a significant component of immune cells infiltrating the TME. Recent research has revealed that the infiltration of neutrophils plays a role in promoting lymphangiogenesis and lymph node metastasis, which was associated with poor prognosis [47,48]. Both CD8 T cell and Treg cell expression were found to be significantly higher in the high-risk group of our study. A significant number of immunosuppressive substances may be present in TME, inhibiting the antitumor activity of CD8 T cells, which may explain why the high-risk group with poor prognosis showed an abundant infiltration of CD8 T cells. Tregs are a unique subgroup of T cells, which have the function of suppressing the immune response, thereby maintaining homeostasis and self-tolerance. Inhibiting T cell growth and cytokine production, as shown by studies, is one way that Tregs help to avoid autoimmunity [49]. High Tregs infiltration was significantly correlated with shorter OS of renal cancer and breast cancer [50,51]. This may explain why we found a negative correlation between the infiltration of Tregs and prognosis in the high-risk group. M1 macrophages are considered as tumor-killing macrophages [52], and the infiltration of M1 macrophages was significantly increased in the low-risk group in our analysis. In the microenvironment of solid malignant tumors, various inflammatory cells contribute to innate and acquired immune responses. Among these cells, neutrophils constitute a significant portion. Recent evidence suggests that tumor-associated neutrophils (TAN) may exhibit either a N1 anti-tumor or N2 pro-tumor phenotype. Neutrophils can undergo a transformation into tumor-promoting cells in the microenvironment. Apart from their cytotoxic effects, they have the ability to facilitate tumor cell dissemination by releasing elastase and matrix metalloproteinases. Moreover, T cell-mediated anti-tumor immune responses are restricted by the tumor-promoting state's regulation of immunosuppression through the secretion of arginase-1 and reactive oxygen species. Targeting these tumor-promoting effects could hold promise for cancer therapy. Neutrophils also contribute to tumor promotion through the formation of neutrophil extracellular traps (NETs) within the tumor, a process called NETosis. Existing evidence predominantly supports the tumor-promoting role of neutrophils, with the degree of neutrophil infiltration correlating with a poorer prognosis. In our study, we observed higher levels of neutrophil infiltration in the high-risk group. Notably, the depletion of neutrophils is related to the significant reduction in lung carcinogenesis. These findings suggest that the SADG-related risk score model may have the potential to guide personalized immunotherapy for patients with ccRCC [[53], [54], [55], [56]].

Immune checkpoint inhibitors (ICIs) are gradually being suggested as first-line adjuvant treatment for diverse tumors due to their impressive therapeutic outcomes [26,57,58]. The immune checkpoint-associated genes were also found to be substantially different between the two risk groupings and to be more strongly expressed in the high-risk group, suggesting that high-risk patients may respond to ICI immunotherapy better. The TIDE approach has been applied to forecast the ICB response in ccRCC patients. TIDE score predicts the likelihood of immune evasion. According to our findings, patients in the high-risk group may be more likely to experience an immunological escape since their TIDE scores were higher than those of the low-risk group. Overall, the findings imply that the patients' different immunological states may have contributed to the differences in prognosis between the high- and low-risk groups.

Although this study performed a genomics analysis of disulfidptosis, and this SADG-related risk score model showed great capacity to predict the prognosis of patients with ccRCC, several limitations should be noted. First, although the expression of nine core genes was verified in TCGA and a small number of clinical samples collected by us, prospective studies with a significant sample size and prognostic information are essential for further verification. Second, the results were obtained by bioinformatics analyses from public databases, which need to be validated by further biological evidence from experimental studies. Furthermore, the underlying mechanisms between the SADGs and the immune microenvironment in ccRCC deserve further research.

## Section: Conclusion

In conclusion, we thoroughly explored the differences among biological processes, the immune states and the survival outcomes between the two molecular subtypes of disulfidoptosis. Furthermore, we established a novel signature based on nine stemness-associated disulfidptosis genes with excellent validity and potential clinical applications. This study will improve our understanding of the function of disulfidptosis in ccRCC, which offers a new reference for identifying prognostic markers and contributes to the improvement of therapeutic approaches.

## Section: Data availability statement

The datasets researched in this study are available in online repositories. The names of the repositories and accession numbers can be found in the article.

## Section: Ethics statement

This study was authorized by the ethics committee of the affiliated Yantai Yuhuangding Hospital of Qingdao University (No. 2023-314), and all patients signed relevant informed consent forms during their hospitalization.

## Section: Funding

This work was supported by grants from the National Nature Science Foundation of China (Nos. 82370690 and Nos. 82073131) and the Taishan Scholars Program of Shandong Province (No. tsqn201909199).

## Section: CRediT authorship contribution statement

Hongquan Liu: Writing – original draft, Formal analysis, Data curation. Xiaoqing Liang: Writing – original draft, Formal analysis, Data curation. Gonglin Tang: Writing – original draft, Visualization, Supervision, Methodology, Data curation. Xiaofeng Wang: Writing – original draft, Visualization, Supervision, Methodology, Data curation. Zhen Wang: Visualization, Supervision, Methodology, Data curation. Leijie Tong: Writing – original draft, Visualization, Supervision, Methodology, Conceptualization. Qiancheng Mao: Writing – review & editing, Visualization, Validation, Methodology, Data curation. Jian Ma: Writing – review & editing, Visualization, Formal analysis. Jitao Wu: Writing – review & editing, Project administration, Methodology, Funding acquisition, Conceptualization.

## Section: Declaration of competing interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.


---

# Integrating Artificial Intelligence and PET Imaging for Drug Discovery: A Paradigm Shift in Immunotherapy

- **Authors:** Jeremy P McGale, Harrison J Howell, Arnaud Beddok, Mickael Tordjman, Roger Sun, Delphine Chen, Anna M Wu, Tarek Assi, Samy Ammari, Laurent Dercle
- **Issuer:** Pharmaceuticals (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2024-02-06
- **Language:** en
- **DOI:** 10.3390/ph17020210
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38399425/
- **Licence:** CC-BY

## Section: Abstract

The integration of artificial intelligence (AI) and positron emission tomography (PET) imaging has the potential to become a powerful tool in drug discovery. This review aims to provide an overview of the current state of research and highlight the potential for this alliance to advance pharmaceutical innovation by accelerating the development and deployment of novel therapeutics. We previously performed a scoping review of three databases (Embase, MEDLINE, and CENTRAL), identifying 87 studies published between 2018 and 2022 relevant to medical imaging (e.g., CT, PET, MRI), immunotherapy, artificial intelligence, and radiomics. Herein, we reexamine the previously identified studies, performing a subgroup analysis on articles specifically utilizing AI and PET imaging for drug discovery purposes in immunotherapy-treated oncology patients. Of the 87 original studies identified, 15 met our updated search criteria. In these studies, radiomics features were primarily extracted from PET/CT images in combination (n = 9, 60.0%) rather than PET imaging alone (n = 6, 40.0%), and patient cohorts were mostly recruited retrospectively and from single institutions (n = 10, 66.7%). AI models were used primarily for prognostication (n = 6, 40.0%) or for assisting in tumor phenotyping (n = 4, 26.7%). About half of the studies stress-tested their models using validation sets (n = 4, 26.7%) or both validation sets and test sets (n = 4, 26.7%), while the remaining six studies (40.0%) either performed no validation at all or used less stringent methods such as cross-validation on the training set. Overall, the integration of AI and PET imaging represents a paradigm shift in drug discovery, offering new avenues for more efficient development of therapeutics. By leveraging AI algorithms and PET imaging analysis, researchers could gain deeper insights into disease mechanisms, identify new drug targets, or optimize treatment regimens. However, further research is needed to validate these findings and address challenges such as data standardization and algorithm robustness.

## Section: 1. Introduction

The discovery, development, and clinical application of immunotherapy have radically impacted therapeutic approaches to numerous cancers, resulting in a significant impact on survival outcomes for many patients. By exploiting a number of innate biological mechanisms, including regulation of cytotoxic T-cells via checkpoint molecules (e.g., PD-1, PD-L1, CTLA-4, and LAG-3), specifically directed oncolytic viruses, and engineered immunocytokines and T-cells, clinicians have been able to divert from the traditional but highly morbid approaches of chemotherapy and radiation. These treatments are inherently more selective for cancer cells, and they seek to target and overcome the mechanisms by which tumors can evade a patient’s natural defense mechanisms. However, the development of novel immunotherapies is an incredibly intricate process, impeded by challenges not only at the bench-top during target identification and molecular development, but also once a drug has left the lab and entered human trials. Clinical deployment of new immunotherapies is complicated by atypical response patterns previously unseen with chemotherapy, including pseudoprogression, in which a tumor initially appears to grow or spread before eventually regressing, as well as various treatment-related inflammatory conditions that can appear in nearly any organ system. Additionally, only a subset of patients exhibit partial or complete responses with immunotherapy, emphasizing the need for better a priori candidate selection.

Positron emission tomography (PET), an imaging modality that provides information about tissue metabolic function, is already widely used for initial cancer diagnosis and staging. Further, the combination of PET and artificial intelligence (AI), which provides high-throughput computation and specifically trained pattern recognition, may help improve efficiency at each step of the development pipeline, ultimately allowing for quicker evaluation and implementation of effective therapeutics in patient care.

This review aims to highlight current studies examining the combination of PET and AI for use in patients treated with immunotherapy. We first provide general background information on immunotherapy, as well as its therapeutic counterpart, targeted molecular therapy, in addition to describing the basics of PET imaging and AI. We then discuss the results of our subgroup analysis with a focus on pain points in the drug development process, including target validation, safety, biomarkers for prognostication and response evaluation, and generalizability to clinical application. For each topic area, we describe current challenges and relevant AI/PET studies from our focused review, as well as other related and current advances. We conclude by describing promising developments that could incite future research and impact the field moving forward.

## Section: 2. Background › 2.1. Targeted Molecular Therapy

While traditional cytotoxic chemotherapy is non-selective and affects both neoplastic and normal host cells, targeted molecular therapies were developed with the goal of improving treatment specificity. This type of therapy generally involves small molecules designed to target mutated proteins or biochemical pathways that allow for unregulated growth and development in tumor cells. The first example in this class was imatinib, a BCR-ABL tyrosine kinase inhibitor found to induce high response rates in chronic myelogenous leukemia [1]. Additional tyrosine kinase inhibitors have since become mainstays of non-small cell lung cancer (NSCLC) treatment, including erlotinib for patients with epidermal growth factor receptor (EGFR) mutations and crizotinib for those with anaplastic lymphoma kinase-positive (ALK+) disease [2]. The former is now part of first-line treatment protocols for NSCLC, and the latter was shown to result in superior survival over first- and second-line cytotoxic chemotherapy regimens [3]. Countless other molecular targets, such as KRAS, BRAF, KIT, HER2, CDK 4/6, and PARP, have been approached with small molecules, but while improved selectivity overall results in fewer off-target effects, these treatments are highly susceptible to resistance through de novo mutations at the target moiety of interest [4,5,6].

## Section: 2. Background › 2.2. Immunotherapy

Immunotherapy represents an alternative approach for blunting the tumorigenic properties of cancer and addressing the aforementioned mechanisms of targeted therapy resistance. This type of treatment focuses on immune pathways, inhibiting tumor-mediated processes for immune downregulation while simultaneously amplifying host response against malignancy. As a result, modern approaches to immunotherapy development greatly diverge from the traditional methods of chemotherapeutic drug discovery and are more similar to those employed for targeted therapy. When creating a novel immunotherapy, researchers first identify a suitable or theoretically relevant target via cell lines, animal models, or bioinformatics before subsequently exploiting cellular machinery to develop antibodies highly specific for proteins expressed on cancer cells. As an example, ipilimumab, one of the earliest FDA-approved immunotherapies, was developed after the identification of the CTLA-4 cell surface receptor, a protein that functions as an immune checkpoint inhibitor (ICI), suppressing host immune defenses [7]. In theory, blocking this receptor on cancer cells would reduce inhibition of the host immune response, leading to the destruction of malignant cells. By utilizing a transgenic mouse model and capitalizing on the natural processes of class-switching and somatic mutation, researchers were able to generate a massive library of IgG antibodies, subsequently identifying those that were most selective for CTLA-4 [8]. The isolated antibodies were then validated in both in vitro and in vivo mouse models to ensure selectivity and efficacy against tumors.

It is important to note that combinations of immunotherapy with cytotoxic chemotherapy or small molecule inhibitors may beget even more significant responses, and tandem therapy remains an active area of research [9,10].

## Section: 2. Background › 2.3. PET Imaging

Positron emission tomography (PET) is a medical imaging technique that quantifies the distribution of radioactive molecules throughout the human body. The most commonly employed radiotracer, 18F-FDG, is composed of a radioactive fluorine atom paired with a glucose moiety, allowing clinicians to visualize in vivo glucose metabolism. For years, 18F-FDG PET imaging has been the standard of care in oncology for the initial assessment and staging of cancerous lesions. PET has also been employed in response assessment, allowing clinicians to track the regression, malignant spread, and recurrence of cancer by analyzing changes in metabolic activity over time [11]. Recently, the scope of PET has widened in light of new developments in radiotracer technology, generally involving the linkage of radiolabels and highly targeted monoclonal antibodies. PET imaging is primed to play a role in future oncologic drug development due to its current status as the gold standard for diagnosis and staging, wide availability, and ease of technical modification and development.

## Section: 2. Background › 2.4. AI and Radiomics

Fundamentally, medical images are made up of two-dimensional pixels (or three-dimensional voxels) that each have a corresponding brightness (or intensity/gray-level) value. The amalgamation of many different individual pixels of varying brightness values creates a macroscopic image from which a radiologist generates an interpretation. However, there is an immense amount of potentially valuable data buried in the micro-scale relationships between individual pixels that may hold clues to underlying biological processes imperceptible to the human eye. Additionally, these relationships cannot be reproducibly quantified by clinicians (due to inter- and intra-observer variability) and are difficult to compare and combine into complex decision algorithms. Artificial intelligence, and in particular the subcategory of radiomics (i.e., extracting textural information from medical imaging through mathematical processes), could be used to address these challenges by quantifying relationships between pixel intensities through discrete imaging “features”. These features describe patterns such as the maximum, mean, and distribution of brightness values in a certain image, as well as symmetry, heterogeneity, and geometric co-occurrences (i.e., spatial relationships of all pixels with identical intensities) of pixels in a region of interest. In theory, by using radiomics and a large dataset of medical images for model training, researchers could identify a precise combination of imaging features and relative weights to create an “imaging phenotype” that is correlated to a particular disease process or patient outcome. Model outputs are generally binary, classifying patients as likely or not likely to have a particular outcome, but even this information can be essential to progressing care or facilitating clinical trials.

## Section: 3. AI and Immunotherapy: Current Landscape

A 2022 scoping review surveyed three databases, MEDLINE (PubMed), CENTRAL (Cochrane Central Register of Controlled Trials), and EMBASE, for all studies through 26 February 2022, using search terms related to artificial intelligence and radiomics applied to the medical imaging of immunotherapy-treated cancer patients [12]. There was one additional relevant study added that was identified in references but did not appear in the original search. Studies were included if they involved the immunotherapeutic treatment of human cancers or models of human cancers and if they employed radiomics with PET, CT, or MRI imaging. Case reports, systematic reviews or meta-analyses, perspectives, editorials, book chapters, workshop reports, conference abstracts, and non-English language reports were excluded. In total, 87 studies were recorded.

To survey the current state of artificial intelligence specifically applied to PET imaging, we performed a focused second-look analysis of this review, examining studies that involved the extraction of imaging features from 18F-FDG PET and CT images in combination (9 of the 87 total studies, 10.3%) and those utilizing only PET images (n = 6, 6.9%). The complete study selection process, including that of the original review, is displayed in Figure 1.

We explored this subsection of 15 articles for the cancer of interest, the primary (and if applicable, secondary) predictive task of the radiomics model (e.g., prognosis, treatment response, tumor phenotyping, etc.), the data collection strategy employed (prospective or retrospective and single- or multi-center), and the validation method used to stress-test each radiomics model. The primary cancers of interest were NSCLC (n = 11, 73.3%), melanoma (n = 3, 20.0%), and lymphoma (diffuse-large B-cell lymphoma, n = 1, 6.7%), with the former two diseases also representing the most common indications for immunotherapy overall. The median [interquartile range] size of aggregated patient cohorts was 132 [148], with the largest number of patients (n = 697) having been recruited in a study of NSCLC. Summaries of these articles are displayed in Table 1 and Figure 2.

## Section: 4. Target Validation

Medical imaging and AI can help researchers and clinicians identify the presence and distribution of specific molecular targets, aiding in the deployment of patient-tailored treatments.

## Section: 4. Target Validation › 4.1. Challenges

Immunotherapy works by targeting very specific mechanisms exploited by tumor biology to either suppress or evade the host immune system. Characteristics of individual tumors, such as PD-L1 and CTLA-4 expression, as well as tumor immune cell infiltration, indicate that a patient’s specific disease may be particularly susceptible to certain types of treatment. The current standard for molecular assessment involves using immunohistochemistry to analyze a tissue sample collected via biopsy. Acquiring these samples is invasive and not without risk, leading clinicians to minimize their use of the procedure, typically only performed before treatment initiation or at disease relapse. Biopsies are also limited in both time and space, leading to a chance of mischaracterizing disease. Additionally, tumors are innately heterogeneous, with different cells possessing varying combinations of mutations, allowing for evolution as treatment is applied [28,29]. Cells with more susceptible phenotypes will die, while those less specifically targeted by a treatment will live on, changing the distribution of molecular expression within a tumor over time. Lastly, even at a single time point, a simple biopsy may fail to capture all cell phenotypes represented within a tumor and would not account for inter-tumoral heterogeneity if only the primary tumor was sampled [29].

## Section: 4. Target Validation › 4.2. State of the Art

In the 15 original studies reviewed, AI was used for classification of either tumor phenotype (n = 4, 26.7%), primarily in describing PD-1/PD-L1 expression, or tumor immune microenvironment (TME, e.g., tumor infiltration by host immune cells, n = 2, 13.3%). The former studies built radiomics models using medical imaging for prediction of PD-L1 overexpression in a certain percentage of cells, i.e., a model would generate a binary output that roughly translated to a prediction that over or under 1% of cells within an analyzed tumor had increased expression of PD-L1. Importantly, these models were built using radiomics features extracted from the primary tumor alone and correlated to known PD-L1 expression confirmed by histologic analysis, which remains the current ground truth for comparison. In describing TME, studies sought to quantify the infiltration and distribution of CD8+ T-cells within a tumor, as well as describe immune cell transcriptomic signatures as a proxy for immune activity.

These classifications correlate with a tumor’s likelihood of treatment response—a tumor with high PD-L1 expression or increased infiltration by host immune cells is more likely to respond to immune-activating or checkpoint-inhibitor therapy. In clinical trials, quantifying tumor character a priori may allow for more directed recruitment of patients, facilitating the identification of populations for which the efficacy of novel therapeutics is likely to be high. In other words, response rates of a PD-L1-inhibiting monoclonal antibody will be much higher in a cohort of highly PD-L1-expressing patients than in a mixed cohort with unknown PD-L1 expression, overall increasing the effect size and lowering the recruitment requirements necessary for a positive trial.

An additional approach aimed at resolving the time scale limitations of traditional tissue biopsies is the evaluation of free circulating tumor DNA (ctDNA), so-called “liquid biopsies.” ctDNA is a subdivision of circulating free DNA (cfDNA, or genetic material shed into general circulation by any cell, especially those undergoing apoptosis) that is specific to cancer. Detecting these ctDNA fragments in patient plasma can allow for non-invasive time-dependent monitoring of tumor genetic profiles, responses to treatment, and metastases, among many other metrics. A full discussion of ctDNA application is beyond the scope of this review, but has been covered extensively by other groups [30,31,32,33,34].

## Section: 5. Safety

Imaging can help clinicians evaluate immunotherapy-induced toxicity and perform risk stratification, allowing for careful decision making on whether or not to proceed with further treatment.

## Section: 5. Safety › 5.1. Challenges

Establishing standard dosing regimens for new immunotherapeutic agents remains challenging. Insufficient dosing may fail to stimulate a patient’s native immune system, resulting in little or no clinical effect, while supratherapeutic doses may precipitate side effects severe enough to dramatically increase morbidity and mortality or lead to treatment interruption [35]. By definition, some classes of immunotherapy, specifically ICI, release the “brakes” of a patient’s immune system, often resulting in the collateral damage of native tissues and the induction of a number of inflammatory conditions such as pneumonitis, colitis, hepatitis, and pancreatitis [36]. These side effects are known as immune-related adverse events (irAEs) and are feared complications in immunotherapy due to their ability to derail the application of treatment. irAEs are also difficult to track as they may be delayed compared to the adverse events associated with more traditional therapies, potentially necessitating longer trial durations [37]. Lastly, there is an intricate differential for in-treatment inflammatory changes on imaging (e.g., pneumonitis must be differentiated from cancer progression or radiation therapy toxicity), which must be fully explored in order to make the most appropriate judgment on ongoing treatment plans.

## Section: 5. Safety › 5.2. State of the Art

Prediction of sequelae from treatment (e.g., irAEs) was facilitated by AI in 2 studies (13.3%). Both studies utilized pretreatment imaging; one predicted the development of colitis, pneumonitis, Guillain–Barré syndrome, hepatitis, myalgia, or rash, while the other predicted the development of cancer-related cachexia in patients treated with ICI. Both studies utilized weighted multivariate logistic regression analysis to build models correlating radiomics features to specific adverse events, and one of the studies validated its model on a prospectively collected cohort of patients. Even without AI, some groups have previously demonstrated that PET imaging has the capacity to capture 75% of irAEs [38,39].

Identification of adverse events at the earliest possible moment, or prediction of which patients will likely experience adverse events due to innate, baseline physiology, is crucial to avoid delaying the administration of life-prolonging treatment. Having an accurate read of irAE risk would improve clinical agility in switching patients between therapeutic regimens. Additionally, ending negative trials, or those in which patients are at risk for high-morbidity adverse events, would promote patient safety. This could reduce barriers to patient enrollment and improve trial retention, while also helping to address disparities in communities traditionally underrepresented in clinical trials.

## Section: 6. Biomarkers for Prognostication and Response Evaluation

Artificial intelligence allows for the creation of patient-specific imaging “phenotypes”, which can be analyzed before, during, or after treatment. In this model, textural features extracted from images act as biomarkers for the patient’s disease, allowing clinicians to not only prognosticate by using large patient populations with similar phenotypes and known outcomes, but also monitor changes in the imaging manifestations of underlying biological processes during treatment.

## Section: 6. Biomarkers for Prognostication and Response Evaluation › 6.1. Challenges

There is a high bar for the approval of new drugs entering clinical trials; new therapies must demonstrate clear evidence of clinical benefit, defined as an improvement in survival, quality of life, or physical functioning. Beyond this, additional endpoints that have been used in accelerated approvals include the demonstration of more rapid tumor size reduction or longer delay in growth than with traditional therapy, as well as improved progression-free survival (PFS) or complete response (CR) in the absence of treatment-related side effects. Trials are designed around achieving these goals, and any tools that can facilitate this process are invaluable in accelerating approval or preventing setbacks.

A factor complicating clear demonstrations of benefit is that traditional methods of monitoring disease response to treatment using medical imaging (e.g., RECIST, RANO, Cheson, PERCIST, among others) have proven insufficient in capturing the novel tumor behavior seen with immunotherapy. This includes pseudoprogression (initial apparent growth of a tumor before eventual response), mixed responses (certain lesions respond more than others), and hyperprogression (accelerated growth after treatment administration) [40,41,42]. Pseudoprogression may lead to early termination of treatment due to perceived progression, while a true mixed response might compel clinicians to continue treating with the same regimen instead of appropriately switching therapy to address intrinsic tumor heterogeneity. Hyperprogression is far more sinister and may lead to disastrous outcomes from rapid disease progression of unknown origin if not recognized at the earliest possible moment [43].

## Section: 6. Biomarkers for Prognostication and Response Evaluation › 6.2. State of the Art

Per our review, AI was most commonly employed for prognostication (n = 6, 40%), either for predicting overall survival (OS) at a specific time point, progression-free survival (PFS, i.e., time from onset of treatment until disease progression or relapse), or durable clinical benefit (DCB, i.e., progression-free survival past a certain predefined time point). One study utilized AI to make baseline predictions about treatment response compared with eventual PERCIST outcomes. No studies specifically examined the differential classification of atypical response patterns discussed above, and thus this remains an area of potential exploration.

At baseline, evaluating the quality of a patient’s tumor and utilizing imaging to predict the likelihood and estimated time frame of survival is crucial for informed decision-making and the selection of a proper course of treatment. More hostile tumors, signified by a lower estimated OS, require more aggressive therapeutic strategies, influencing the treatment outcomes of clinical trials they are involved in. Trial length, an important factor for cost and time considerations in drug development, could also be shortened via early termination if patients displayed imaging phenotypes indicating a low probability of a good outcome with the continuation of a particular treatment. Furthermore, saving money by avoiding failed trials could open the door for the evaluation of additional new drugs, including those for orphan conditions.

In addition to the biomarkers mentioned above, a modified version of the RECIST consensus guidelines has been developed, termed iRECIST, with the intent of addressing atypical tumor behavior observed in response to immunotherapy [44]. A major improvement of iRECIST is its ability to more precisely discriminate instances of progression by including definitions for unconfirmed and confirmed progressive disease (iUPD and iCPD, respectively). When an increase in size or novel lesions are first observed on imaging after treatment initiation, the patient is noted to have iUPD until subsequent assessment, at which time persistence of growth or spread would indicate iCPD. Importantly, patients with iUPD that eventually regresses are eligible for partial response, complete response, or stable disease designations, whereas in standard RECIST, any degree of observed progression precludes attainment of these statuses.

## Section: 7. Challenges to Clinical Application

As discussed, medical imaging helps clinicians monitor the therapeutic effects of a drug and can help guide decision-making during different stages of clinical testing and implementation. However, in order for AI to be applied in more widespread clinical settings, extensive validation must be performed to ensure that simulated performance will be maintained in new populations.

## Section: 7. Challenges to Clinical Application › 7.1. Generalizability

While individual studies may report impressive performances for AI models in isolation, the interpretation of these results must be carried out with caution. The applicability and generalizability of models beyond the initial study populations depend on the quality of patient cohorts used for model training and the rigor of subsequent model validation. Per our review, nearly all studies (n = 14, 93.3%) recruited patients retrospectively, and most were based at single institutions (n = 11, 73.3%). One study included a prospective testing cohort for model validation. In general, training predictive algorithms on patients from multiple institutions allows the model to be exposed to more heterogeneity between patients and imaging acquisition techniques. Additionally, collecting data prospectively helps to eliminate the bias of retrospective analysis, further supporting the internal and external validity of results.

Model validation is a crucial step in AI development and represents the first real test of predictive ability: applying an algorithm to data separate from what was used for training. Validation methodology can be graded based on the quality of the cohorts used, with the lowest quality validation cohort involving reuse and reorganization of the training set, known as cross-validation. The use of a validation set involves splitting recruited patients into two buckets, one for model training and the other for validation. Alternatively, a validation set can be defined as a cohort of patients recruited separately from the training set, but at the same institution using similar inclusion criteria. In this way, and regardless of the approach, both training and validation sets will have similar patient distributions and characteristics, but the model is being tested on patients that it has not previously been exposed to. A more rigorous validation method involves testing models using a validation set immediately followed by a test set (denoted by us as “validation set; test set”), with the latter defined as a cohort of patients independent from the training/validation sets (i.e., patients were recruited from a different database/institution, recruited using different criteria, or received a different treatment). This strategy provides the highest external validity for AI, as model performances are observed in truly independent cohorts, indicating potential for broad application. Test sets, as defined above, could also be used in isolation, independent of validation sets. Per our review, most studies used validation strategies involving either a “validation set; test set” (n = 4, 26.7%) or a “validation set” alone (n = 4, 26.7%). Surprisingly, four (26.7%) studies reported no validation whatsoever, while two (13.3%) reported only cross-validation on the training set. One study used a test set in isolation. The relative absence of substantive validation is a trend observed previously in the field, with a 2019 meta-analysis finding that only 6% of studies surveyed in a pool of 516 performed any sort of external validation, while none validated radiomics models with prospective, multicenter external cohorts [45].

## Section: 7. Challenges to Clinical Application › 7.2. Radiomics Quality Score

While scrutinizing the rigor of validation allows for some ability to judge the quality of an AI model, there is a need for a more standardized approach to evaluation in order to properly recognize the relevance, predictive ability, and potential for application of each individual algorithm. Lambin et al. proposed a 16-point scoring system that accounts for, among other metrics, thoroughly described research methods, quality of validation, and description of biological correlates [46]. Although this measure, called the radiomics quality score (RQS), does not take into account sample size or discrete model performance, it allows for standardized assessment and comparison of AI studies. Overall, higher scores (with a maximum score of 36) indicate higher quality studies that can be more easily translated into practice. Of the 15 studies reviewed, the median [interquartile range] radiomics quality score was 15 [10], and the highest score achieved was 24.

## Section: 8. Future Directions: PET-Specific Radiotracers

An emerging technique, immunoPET, seeks to circumvent the use of imaging feature proxies for biological phenomena by more directly interrogating tumor biology through radiotracers appended to monoclonal antibodies (mAbs). The primary molecular targets of these highly specific mAbs are markers on CD8+ T-cells, as well as PD-L1 proteins. Cancers with low levels of CD8+ T-cell infiltration, indicating a lack of immune access to a tumor, or high PD-L1 expression, signaling a blunting of the host immune response, are less likely to respond to immune mobilization via immunotherapy. As previously discussed, a precise description of these variables, based on the pattern and intensity of radiotracer uptake as measured by PET, would allow for a curated selection of patients for trials, identifying those most likely to achieve durable clinical benefit.

Building on a decade of in vivo experimental studies using targeted radiotracers, recent proof-of-concept and Phase I trials have deployed a radiotracer comprised of an 89Zr atom tethered to a minibody (engineered antibody) specific for human CD8 protein to evaluate whole-body cytotoxic T-cell distribution and tumor infiltration [47,48,49,50]. Additionally, and perhaps more widely investigated at present, are agents targeting the PD-L1 co-receptor. Radiotracers built from 64Cu-, 89Zr-, 18F-, 111In-, and 99mTc-containing scaffolds with high-affinity PD-L1-specific peptides are being used in pre-clinical studies to precisely define tumor surface protein expression [51,52,53,54,55]. Human studies are also underway, with a recent trial of 22 patients demonstrating that PD-L1-specific 89Zr PET tracer uptake was more strongly correlated with outcomes than immunohistochemistry or RNA sequencing-based biomarkers [56]. Another trial used an 18F-labeled anti-PD-L1 Adnectin protein and demonstrated higher tracer uptake in treatment-responsive NSCLC [57]. A potential future avenue of investigation involves using radiomics or AI not as surrogate measurements for tumor microenvironment, as was performed in many of the studies described in this literature survey, but instead as a means to more thoroughly describe the behavior of these highly specific radiotracers. AI could be used to quantify patterns of radiotracer uptake and distribution that can be compared inter- or intra-patient in a longitudinal series, ultimately correlating them to clinical endpoints specifically chosen for a particular clinical trial.

## Section: 9. Conclusions

The modern development of immunotherapy is marked by significantly higher throughput, cost, and complexity than ever before. Tools are constantly being developed to improve efficiency at each step in the process, and AI may represent a solution for predicting treatment efficacy and minimizing side effects, thereby streamlining the clinical trial portion of novel pharmaceutical testing [42]. When paired with PET imaging, which is already widely used for staging purposes in oncology, AI could allow clinicians to appreciate and quantify the microscopic imaging biomarkers that define a patient’s disease. Even prior to trial onset, researchers could use AI for non-invasive, radiographic tumor phenotyping in order to assess susceptibility to treatment (e.g., evaluating PD-L1 status for patients prior to a trial for anti-PD-L1 monoclonal antibodies) and select patients most likely to achieve clinical benefit. Additionally, while an investigative treatment is being administered, radiographic changes could be used to predict prognosis or signal the insidious development of adverse reactions or atypical response patterns, allowing for increasingly swift reflexes from clinical trial teams. In theory, if a new drug trial were to be associated with poor radiographic phenotypes at first follow-up, it could be terminated at an earlier time point than is currently possible. Further development of AI, combined with high-specificity radiotracers to fully illuminate tumor cell microenvironments, could precipitate a paradigm shift in immunotherapy drug development, dramatically increasing efficiency and decreasing potential morbidity, ultimately facilitating bench-to-bedside transitions for novel therapeutics.


---

# Integrating Artificial Intelligence for Drug Discovery in the Context of Revolutionizing Drug Delivery

- **Authors:** Anita Ioana Visan, Irina Negut
- **Issuer:** Life (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2024-02-07
- **Language:** en
- **DOI:** 10.3390/life14020233
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38398742/
- **Licence:** CC-BY

## Section: Abstract

AbstractDrug development is expensive, time-consuming, and has a high failure rate. In recent years, artificial intelligence (AI) has emerged as a transformative tool in drug discovery, offering innovative solutions to complex challenges in the pharmaceutical industry. This manuscript covers the multifaceted role of AI in drug discovery, encompassing AI-assisted drug delivery design, the discovery of new drugs, and the development of novel AI techniques. We explore various AI methodologies, including machine learning and deep learning, and their applications in target identification, virtual screening, and drug design. This paper also discusses the historical development of AI in medicine, emphasizing its profound impact on healthcare. Furthermore, it addresses AI’s role in the repositioning of existing drugs and the identification of drug combinations, underscoring its potential in revolutionizing drug delivery systems. The manuscript provides a comprehensive overview of the AI programs and platforms currently used in drug discovery, illustrating the technological advancements and future directions of this field. This study not only presents the current state of AI in drug discovery but also anticipates its future trajectory, highlighting the challenges and opportunities that lie ahead. Keywords: artificial intelligence, drug discovery, machine learning, deep learning, drug repurposing, pharmaceutical AI

## Section: 1. Introduction

Drug discovery is a highly intricate and lengthy process that requires the identification of potential drug candidates that can effectively treat various diseases. The use of AI has brought a significant shift in the approach to drug discovery. AI has fundamentally transformed the pharmaceutical industry by speeding up the drug discovery process, improving precision, and decreasing costs. In this review, we will explore the different types of AI techniques used in drug discovery, including ML (to predict drug properties, identify potential drug candidates, and optimize chemical structures), DL (to analyze large-scale biological data, predict drug properties, and identify potential drug candidates), NLP (to analyze the scientific literature for potential drug candidates and to generate drug summaries), GM (to generate new molecules that could potentially be drug candidates), and network-based approaches (to identify potential targets for drug development).

Digital survey (2010–2023) justifying the importance of the subject.

## Section: 1. Introduction › 1.1. Historical Background and the Concept of AI in Medicine

The use of artificial intelligence techniques, algorithms, and technologies in medicine and healthcare is referred to as AI in medicine. It involves the use of computer systems and specialized software to analyze medical data, make decisions, and perform tasks that are usually completed by human healthcare professionals. AI in medicine aims to improve the accuracy, efficiency, and effectiveness of medical diagnosis, treatment, and patient care by leveraging ML, NLP, and other AI methodologies.

AI in medicine includes its diverse applications in areas such as medical image analysis, drug discovery, personalized treatment planning, disease diagnosis and prediction, virtual health assistants, electronic health record management, and patient monitoring. By processing vast amounts of patient data and medical literature, AI systems can assist healthcare professionals in making more up-to-date decisions, detecting patterns, and predicting patient outcomes, leading to better patient care and medical outcomes. The field of AI in medicine is rapidly advancing and making an impact in areas such as drug discovery, virtual health assistants, and remote patient monitoring. The use of AI-driven tools is expected to improve medical diagnoses, disease prevention, and treatment outcomes, ultimately leading to a more patient-centric and efficient healthcare system. The history of AI in medicine dates back several decades, with significant developments in both AI and medical sciences contributing to its evolution. Key milestones and events in the historical development of AI in medicine include the establishment of the field of AI in the 1950s by researchers like Alan Turing, who proposed the idea of intelligent machines [1]. Early work in AI involved attempts to mimic human problem-solving abilities through formal logic and rule-based systems [1]. In the 1960s, the concept of “expert systems” emerged, where the knowledge and expertise of human experts was encoded into computer programs to aid decision-making in specific domains [1]. This laid the foundation for AI applications in medicine. The development of early expert systems, such as Dendral and MYCIN, further advanced the use of AI in medicine. The 1970s saw an increase in AI applications in medicine, including computer-aided diagnosis (CAD) systems for medical imaging AI [1]. MYCIN, an expert system for diagnosing bacterial infections, demonstrated the potential of AI in healthcare [1]. In the 1980s, AI-based image recognition algorithms began to be applied in medical imaging, aiding in the interpretation of X-rays, CT scans, and MRIs [1]. AI techniques, such as pattern recognition and ML, were integrated into medical imaging systems [1]. The 1990s witnessed progress in NLP, enabling AI systems to “understand” and process medical text data [1]. Robotic surgery systems, such as the da Vinci Surgical System, were developed, combining AI and robotics for minimally invasive procedures [1]. With the advent of electronic health records (EHRs) and the growth of big data in healthcare, AI applications expanded to handle vast amounts of patient data [1]. AI in medicine began contributing to personalized medicine, predicting patient responses to treatments based on their individual characteristics [1]. DL, a subset of ML, revolutionized AI applications, including medical image analysis and disease diagnosis [1]. AI in medicine played a crucial role in advancing precision medicine, tailoring treatments based on genetic and molecular data [1]. These developments highlight the significant progress made in AI applications in medicine over the years, paving the way for improved healthcare outcomes and personalized treatment approaches.

## Section: 1. Introduction › 1.2. Statement of Significance

The historical background of AI in medicine shows a progressive journey from early explorations to the current era of sophisticated AI applications in various aspects of healthcare. As AI technologies continue to advance, they hold the potential to reshape the future of medicine and revolutionize healthcare practices for the benefit of patients and healthcare professionals alike. Overall, the number of published papers on AI has been increasing rapidly over time, with a peak of 348,684 papers being published in 2023. The number of published papers on AI-assisted material discovery in drug delivery has also been increasing in recent years, with a peak of 1234 papers being published in 2022. The number of published papers on AI in medicine has also been increasing in recent years, with a peak of 188,845 papers being published in 2021. The increase in the number of published papers on AI suggests that there is a growing interest in this technology and that more research is being conducted in this area. The number of published papers on AI in medicine has also been increasing in recent years but at a slower pace (Figure 1). The increase in the number of published papers on AI-assisted material discovery in drug delivery suggests that there is also a growing interest in the potential use of AI in this field. This suggests that there is still some way to go before AI is widely adopted into this field.

While the specific focus on AI-assisted material discovery in drug delivery is not extensively covered in the literature, the literature highlights the potential of AI in advancing pharmaceutical product development, including formulation design and drug discovery [2,3]. These insights suggest that AI can be a valuable tool in accelerating the discovery and optimization of materials for drug delivery. However, for a more detailed review specifically focusing on AI-assisted material discovery in drug delivery, it would be beneficial to explore additional research articles or publications that specifically address this topic.

Digital survey (2010–2023) justifying the importance of the subject.

## Section: 2. AI in Discovering New Drugs

In the field of medicine, there are two types of AI applications: physical and virtual. Physical applications include the following: robot-assisted surgery, AI-enhanced prosthetics, real-time patient monitoring, and automated laboratory processes.

For example, AI in robot-assisted surgery can provide medical professionals with relevant information to assist them in making more informed decisions. While AI cannot replace human doctors, it can enhance their capabilities and improve patient care. Thus, AI-powered surgical robots enable surgeons to perform complex procedures with greater precision, control, and flexibility. These robots can reduce the risk of complications, minimize invasiveness, and shorten recovery times, leading to better surgical outcomes [4]. On the other hand, AI-driven prosthetics are designed to adapt to the user’s movements and respond to their neural signals. These advanced prosthetics significantly improve the quality of life for amputees, allowing them to perform complex tasks with greater ease and naturalness. AI-based monitoring systems continuously analyze patient data, such as their vital signs and electronic health records, to identify potential signs of deterioration or complications. This enables healthcare providers to intervene on time and avert adverse events. Studies have also shown that AI-based algorithms can outperform human doctors in certain diagnostic tasks, such as detecting certain types of cancer or interpreting pulmonary function tests [5]. Some automated laboratory processes, such as AI-powered robotic systems that streamline and automate laboratory processes, include sample analysis, sorting, and preparation. This reduces the workload for laboratory staff and minimizes the risk of human errors, ensuring more accurate results.

Drug Discovery and Development belong to the Virtual Applications category, together with diagnostic assistance, personalized treatment plans, and virtual health assistants. Virtual AI applications aid healthcare professionals in diagnosing diseases more accurately and efficiently. AI algorithms can analyze medical imaging data, such as X-rays, CT scans, and MRI images, to detect abnormalities and assist in early disease detection [6]. This capability translates to a significantly reduced chance of misdiagnosis and leads to better patient outcomes. The power of AI lies in its ability to process and analyze large amounts of medical data, spotting patterns that may not be immediately visible to humans. In doing so, AI can help improve diagnostic accuracy and develop personalized treatment plans. In particular, DL algorithms can identify anomalies or potential diseases in medical images, which can assist radiologists in their interpretations [6]. For instance, AI has proven useful in the field of gastroenterology by detecting abnormal structures in endoscopy and ultrasound images, such as colonic polyps [7]. Additionally, AI-powered wearable devices can remotely monitor patients and provide real-time data to healthcare professionals, offering early intervention opportunities. These devices have even been developed to detect and notify caregivers about seizures in epilepsy-suffering patients [8]. Also, AI-powered virtual applications can analyze an individual’s health data, including their genetics [9], medical history [10], lifestyle factors [11], and current health status, to create personalized treatment plans. These plans can optimize their medication dosage, predict their treatment response, and recommend targeted therapies, ensuring more effective and personalized patient care. AI can also contribute to precision medicine by analyzing a patient’s genetic data and medical history to predict their disease risk, determine optimal treatment plans, and identify potential drug targets. Moreover, virtual health assistants, powered by AI, offer patients 24/7 support and personalized health advice [12]. They can answer medical queries, remind patients about medication schedules, and provide lifestyle recommendations, promoting patient engagement and proactive healthcare management.

Regarding drug discovery and development, AI algorithms assist researchers in identifying potential drug candidates by analyzing vast databases of molecular structures, biological interactions, and clinical trial data. This accelerates the drug discovery process and holds promise for a faster development of new medications.

AI in drug discovery implies:

AI has significantly impacted the field of drug discovery, particularly in the areas of target identification and validation. This process involves identifying potential biological targets and elucidating their roles in diseases, followed by validating these targets to ensure they are directly involved in a disease mechanism and that the modulation of the target is likely to have a therapeutic effect and plays a crucial role in identifying potential drug targets by analyzing the genomic, proteomic, and metabolomic data (Figure 2). ML algorithms sift through large datasets to pinpoint the proteins or biological pathways implicated in specific diseases, offering researchers valuable insights for drug development [13].

For instance, ML-based approaches, such as Kronecker regularized least squares (KronRLS), evaluate the similarities between drugs and protein molecules to determine DTBA. Correspondingly, SimBoost utilizes regression trees to predict DTBA, and considers both feature-based and similarity-based interactions [14].

AI also aids in the selection of the target. An optimal target should be druggable, safe, efficient, and able to fulfill commercial requirements. However, emerging modalities for disease treatment include previously less tractable targets. Target validation is a crucial step in drug discovery because it ensures that a molecular target is directly involved in a disease mechanism and that the modulation of the target is likely to have a therapeutic effect [15]. Target validation may involve determining the structure–activity relationship, the genetic manipulation of target genes (knockdown or overexpression), generating a drug-resistant mutant of the presumed target, using degradation-based tools to anticipate the effects of the target, and monitoring the signaling pathways downstream of the presumed target [16]. AI has been used to predict drug–target interactions [17], measure the binding affinity of a drug [18], and select and validate targets [19].

AI-powered virtual screening tools analyze the three-dimensional structures of target proteins and predict how potential drug molecules would interact with them. This speeds up the process of drug designing and allows researchers to identify promising drug candidates for further testing [20].

Virtual drug screening is a computational approach that uses AI to predict the activity of potential drugs by fitting chemical structures to targets (Figure 3). This method allows researchers to rapidly test a library of compounds for their potential to bind and inhibit specific receptor or enzyme targets [21]. AI algorithms can analyze molecular structures, predict binding affinities, and prioritize compounds for further experimental testing [21]. Also, AI techniques, such as Bayesian docking approximations and RL, can be used in molecular docking simulations [22]. Molecular docking involves predicting the preferred orientation of a small molecule (drug candidate) when it is bound to a target protein. AI algorithms can explore the conformational space and predict the binding affinity between the drug and the target protein [22]. ML algorithms for drug design can be trained on/with large datasets of known drug–target interactions to envisage new drug–target pairs or optimize the properties of existing drugs. These algorithms can learn the patterns and relationships between chemical structures and biological activities, enabling the discovery of novel drug candidates [23]. For example, graph neural networks (GNNs) have been used to predict molecular properties and optimize drug design [24]. GNNs have been increasingly utilized in drug discovery for their ability to accurately predict molecular properties. These advanced AI models excel in understanding the complex structures of molecules, enabling a more efficient and targeted drug design. By representing molecules as graphs with atoms as nodes and chemical bonds as edges, GNNs effectively analyze and predict how these molecular structures will behave, leading to optimized drug design processes. AI can enhance high-throughput virtual screening, which involves screening large databases of compounds to identify potential drug candidates. ML algorithms can analyze chemical features, structure–activity relationships, and other molecular properties to prioritize compounds with high potential for further investigation [25].

AI techniques, such as DL and quantum chemistry, can be used for predictive modeling and optimization in drug design. DL models can analyze vast amounts of data, including chemical structures, biological activities, and pharmacokinetic properties, to predict the efficacy and safety of potential drugs [26]. Quantum chemistry combined with AI can accelerate the exploration of chemical space and guide the design of new drug candidates [25]. It is important to note that while AI has shown promising results in virtual screening and drug designing, experimental validation is still necessary for the identified drug candidates. AI is a powerful tool that can assist researchers in the early stages of drug discovery, but it should always be complemented with traditional experimental methods and rigorous testing [23]. Overall, AI has the potential to significantly accelerate the drug discovery process, improve the efficiency of virtual screening, and enable the design of novel drug candidates with optimized properties. As research in AI and ML continues to advance, we can expect further advancements in virtual screening and drug design methodologies.

AI algorithms can predict the physicochemical properties of drug candidates, such as the solubility, bioavailability, and toxicity [16]. This helps in optimizing drug development by focusing on compounds with a higher chance of success, thus reducing costs and time. ML algorithms can be trained to predict drug properties using a database of known compounds. These algorithms learn to recognize patterns and correlations between the chemical structure of a compound and its physicochemical properties [20]. Once trained, these models can predict the physicochemical properties of new, untested compounds, aiding in the early stages of drug development [20]. For instance, ML models have been used to predict solubility, a crucial property for drug candidates [27]. Similarly, ML algorithms have been used to predict bioavailability, another critical property for drug candidates [28]. Toxicity prediction is another area where AI has shown promise. ML models have been used to predict the toxicity of compounds based on their chemical structures [29]. These models can help in early-stage drug discovery by identifying compounds that are less likely to be toxic, thereby reducing the risk of harm to humans during the testing phase [14].

AI enables researchers to identify new therapeutic applications for existing drugs by analyzing vast databases of drug–target interactions and disease pathways. This drug repurposing approach can significantly reduce the time and cost required to bring a drug to market (Figure 4) [30].

AI used in drug combination identification implies enhanced synergy detection, combination optimization, personalized combination therapies, and prediction of adverse drug interactions.

AI algorithms analyze high-dimensional biological data to identify potential synergistic drug combinations. By exploring interactions between drugs and their targets, AI can predict combinations that exhibit enhanced therapeutic effects while minimizing adverse reactions [31]. AI can optimize drug dosage and scheduling within a combination to maximize its efficacy and reduce side effects [32]. This fine-tuning ensures that the combination’s therapeutic benefits are fully realized, making it a more viable treatment option. AI-driven precision medicine allows the identification of patient-specific drug combinations based on individual molecular profiles and disease characteristics [33]. This personalized approach aims to achieve better treatment outcomes and minimize the risk of drug resistance. AI models can predict potential adverse interactions between drugs in a combination, ensuring the safety of patients and avoiding potential harm [34].

Drug development process: target deconvolution vs. target discovery.

Virtual screening ML model in the drug development process.

Drug repurposing approach.

AI methods that are frequently utilized in drug discovery.

Collaborations between pharmaceutical companies and AI providers.

## Section: 2. AI in Discovering New Drugs › 2.1. AI Techniques Used in Material Discovery

AI techniques, particularly in materials science, focus on discovering and designing new materials with desirable properties. This is directly applicable to drug discovery, as the process often requires the identification of novel compounds with specific biological activities. AI algorithms that excel in predicting the properties of new materials can similarly predict the pharmacological profiles of drug candidates. This crossover allows for the more efficient screening and optimization of potential drugs, leveraging AI’s predictive capabilities to streamline both the material and drug discovery processes.

AI techniques in materials discovery include supervised and unsupervised learning. Supervised learning uses labeled data to train models that can classify or predict outcomes of new data. Unsupervised learning, on the other hand, deals with unlabeled data and aims to develop models that can identify recurring patterns and clusters of the input data without prior knowledge. In contrast, in drug discovery, AI techniques are used at various stages, including in data collection and curation, compound representation, and AI methods and their applications. Data resources, data representation schemes, and AI methods are the three key components of applying AI to drug discovery and evaluation. AI techniques used in drug discovery include regression analysis, the decision tree, logistic regression, the support vector machine, the convolution neural network, the recurrent neural network, the generative adversarial network, k-means clustering, hierarchical clustering, principal component analysis, and t-distributed stochastic neighbor embedding.

In drug discovery, the selection and application of AI techniques are problem-oriented to ensure they are ideal. Two commonly used types of AI techniques in the realm of drug discovery are supervised and unsupervised learning [35].

Table 1 lists the widely used AI techniques in drug discovery, which are briefly discussed in the following sections.

AI methods that are frequently utilized in drug discovery.

Collaborations between pharmaceutical companies and AI providers.

## Section: 2. AI in Discovering New Drugs › 2.1. AI Techniques Used in Material Discovery › 2.1.1. Supervised Learning Methods

Supervised learning involves using input-labeled data to train models capable of classifying and/or predicting outcomes for new data, e.g., where the output is its corresponding property (e.g., band gap, thermal conductivity) [46]. Supervised learning models can then predict the properties of new materials based on the patterns learned during training [47]. In contrast, unsupervised learning deals with unlabeled data and aims to advance models which identify recurring patterns and clusters within the input data without prior knowledge [48]. They can help identify novel material classes that might not be apparent through manual analysis [49]. Supervised learning techniques are further split into classification and regression algorithms, while unsupervised learning techniques include clustering and dimensionality reduction algorithms.

Linear regression models the relationship between a dependent variable and one or more independent variables by fitting a linear equation to the observed data. In drug discovery, linear regression can be used to predict a physicochemical property of a compound based on its molecular descriptors. Ridge regression and lasso regression are types of linear regression that use shrinkage, which is a technique for reducing the complexity of a model. SVR is a type of regression analysis that uses the concept of support vectors. It is a flexible method for regression and can handle both linear and non-linear problems. It can also handle high-dimensional data and is effective in high-noise situations. In material discovery, reinforcement learning (RL) can be applied to optimize the synthesis process [50]. Reinforcement Learning (RL) is an area of ML where an agent learns to make decisions by performing actions in an environment to achieve some goals. The agent receives feedback in the form of rewards or penalties, guiding it to learn the best strategy, known as a policy. RL involves trial and error, where the agent explores various actions and learns from the outcomes to optimize its behavior. This method is particularly useful in scenarios where explicit instructions on how to achieve a goal are not available, allowing the agent to autonomously discover effective strategies through iterative learning and adaptation. This approach is gaining traction in various fields, including robotics, gaming, and autonomous vehicles, due to its ability to adapt and improve through experience [50]. Two common RL algorithms are Q-learning and deep Q-Networks (DQNs). Q-learning is a model-free reinforcement learning algorithm that learns the value of an action in a particular state without requiring a model of the environment. A DQN combines deep learning with Q-learning to allow the agent to learn directly from raw pixels or other raw input. One of the key advantages of RL is that it focuses on the problem as a whole rather than dividing it into subproblems. It is capable of trading off short-term rewards for long-term benefits, and it does not require a separate data collection step, as training data are obtained via the direct interaction of the agent with the environment. To facilitate the application of these AI techniques, various open-source packages and frameworks have been developed, such as Scikit-learn [51], PyTorch [52], and Keras [53]. These packages provide access to a range of algorithms for users to practice using in drug discovery. Regression analysis algorithms play a crucial role in drug discovery, particularly in the prediction of the physicochemical properties of compounds. These algorithms can help optimize the drug development process by identifying compounds with desirable properties and reducing the time and cost of testing.

Regression analysis is a statistical method used in drug discovery to predict the outcome of an experiment based on the values of predictor variables [54]. In the context of drug discovery, the outcome could be a physicochemical property of a compound, such as its solubility, bioavailability, or toxicity [54]. Linear regression is a basic and commonly used regression analysis method. It models the relationship between a dependent variable and one or more independent variables by fitting a linear equation to the observed data [55]. In drug discovery, linear regression can be used to predict a physicochemical property of a compound based on its molecular descriptors [56]. Ridge regression is a type of linear regression that uses shrinkage, which is a technique for reducing the complexity of a model [57]. The shrinkage parameter (or tuning constant) determines the amount of the shrinkage: the larger the value of the shrinkage parameter, the greater the amount of the shrinkage [58]. Lasso regression is another type of linear regression that uses shrinkage and can also handle high-dimensional data [59]. The main difference between ridge and lasso regression is that lasso can result in sparse solutions, where some of the feature coefficients are exactly zero, excluding those features from the model [60]. SVR is a type of regression analysis that uses the concept of support vectors [38]. It is a flexible method for regression and can handle both linear and non-linear problems. It can also handle high-dimensional data and is effective in high-noise situations [38].

Classification involves assigning data points to one of several possible categories. In drug discovery, classification algorithms can be used to predict whether a compound is likely to be effective or not.

A support vector machine (SVM) is a type of supervised learning algorithm used for classification and regression analysis. It works by finding a hyperplane in a high-dimensional space that distinctly classifies the data points. In drug discovery, SVM can be used to classify compounds based on their properties and predict their effectiveness.

A convolutional neural network (CNN) is a type of deep learning algorithm that is primarily used for image processing. However, it can also be used in drug discovery for tasks such as predicting the properties of new molecules. A CNN can automatically learn and extract features from raw data, making it suitable for handling complex and high-dimensional data.

A recurrent neural network (RNN) is a type of deep learning algorithm that is particularly suited for processing sequential data. In drug discovery, an RNN can be used to predict the properties of new molecules based on their sequence data.

A generative adversarial network (GAN) is a type of deep learning algorithm that consists of two neural networks, the generator and the discriminator, which are trained in an adversarial manner to generate realistic data samples. In drug discovery, GANs are applied to generate new molecular structures with desired properties.

## Section: 2. AI in Discovering New Drugs › 2.1. AI Techniques Used in Material Discovery › 2.1.2. Unsupervised Learning Methods

Unsupervised learning involves using unlabeled data to identify patterns and relationships within the data. In drug discovery, unsupervised learning techniques can be used to identify novel material classes or to explore the chemical space of potential drug candidates.

Clustering (k-means) is a type of unsupervised learning technique that groups data points based on their similarity. In drug discovery, clustering can be used to identify groups of compounds with similar properties, which can help in identifying novel drug candidates.

Hierarchical clustering is a type of clustering technique that builds a hierarchy of clusters through either a bottom-up or top-down approach. In drug discovery, hierarchical clustering can be used to identify groups of compounds with similar properties at different levels of granularity.

Dimensionality reduction (PCA, t-SNE) techniques are used to reduce the number of variables in a dataset while retaining its essential characteristics. Principal component analysis (PCA) and t-distributed stochastic neighbor embedding (t-SNE) are two common dimensionality reduction techniques. In drug discovery, dimensionality reduction can be used to visualize high-dimensional data and identify patterns or trends that might not be apparent in the original data.

## Section: 2. AI in Discovering New Drugs › 2.1. AI Techniques Used in Material Discovery › 2.1.3. AI Algorithms Used in Drug Discovery

While traditional approaches used in drug discovery rely heavily on manual research, experimentation, and testing, AI-driven methods/algorithms leverage data-driven analysis, ML, and rapid simulation.

Collaborations between pharmaceutical companies and AI providers.

## Section: 2. AI in Discovering New Drugs › 2.1. AI Techniques Used in Material Discovery › 2.1.3. AI Algorithms Used in Drug Discovery

ML and DL are subsets of AI that have found applications in drug discovery. While they share some similarities, they have distinct differences in terms of their approach, architecture, and capabilities [61].

ML is a broad field that encompasses various algorithms that can learn patterns and make predictions based on data. These algorithms typically work with structured data, and they require feature engineering, where relevant features are selected or engineered before feeding the data into the model [61,62,63]. Feature engineering is a critical step in preparing the data for ML models [63]. Traditional ML algorithms require well-structured and labeled data for training. ML algorithms are generally simpler and require less computational power compared to DL models [61,62]. They can perform well on certain tasks with limited data but may struggle with highly complex and non-linear problems. Traditional ML models may require a substantial amount of labeled data to achieve good performance, especially in complex tasks. Traditional ML models are generally more interpretable, meaning it is easier to understand how the model arrived at its predictions based on the selected features and parameters [61,62].

On the other hand, DL is a specialized form of ML that uses artificial neural networks to learn representations of data [64]. These neural networks have multiple layers, allowing them to learn hierarchical features from raw data. Unlike traditional ML, DL models can automatically learn features from data, eliminating the need for extensive feature engineering [65]. DL models can handle unstructured data, such as images, texts, and sequences, without the need for extensive feature engineering. They learn hierarchies of representations directly from raw data, making them more suitable for handling complex and high-dimensional data [65]. DL models are more complex and require significant computational resources, especially when dealing with large datasets. They excel at handling complex patterns and non-linear relationships in data, making them particularly suitable for tasks like image and language processing [65]. DL models can often achieve better performance with less-labeled data due to their ability to automatically learn features and representations from the data. DL models are often considered less interpretable due to their multiple layers and complex learned representations. Understanding the decision-making process of DL models can be challenging. Gong D. et al. demonstrated how ML technology can be used to screen polymers for gene delivery in silico [66]. This work reported the application of state-of-the-art ML algorithms to a dataset of synthetic biodegradable polymers, PBAEs, which have shown promise for therapeutic gene delivery in vitro and in vivo [66]. The dataset included polymer properties as inputs as well as polymeric nanoparticle transfection performance and nanoparticle toxicity in a range of cells as outputs. These data were used to train and evaluate several state-of-the-art ML algorithms for their ability to predict transfection and understand structure–function relationships [66]. By developing an encoding scheme for vectorizing the structure of a PBAE polymer in a machine-readable format, the authors demonstrated that a random forest model can satisfactorily predict DNA transfection in vitro based on the chemical structure of the constituent PBAE polymer in a cell line-dependent manner [66]. Thus, a computational approach that encoded the chemical descriptors of polymers was able to demonstrate that the in silico computational screening of polymeric nanomedicine compositions had utility in predicting de novo biological experiments.

DL is a branch of AI that employs both supervised and unsupervised learning techniques, depending on the problem and data being analyzed [67].

High-throughput density functional theory (DFT) calculations are computationally expensive but vital for understanding material properties at the atomic level [68]. High-throughput DFT involves using efficient algorithms and parallelization to predict the properties of a large number of materials rapidly [68]. DFT has become increasingly relevant in drug discovery, where it plays a crucial role in understanding and predicting the interactions between drug molecules and biological targets.

High-throughput DFT can be used to calculate the binding energies and binding affinities between drug molecules and their target proteins [69]. These calculations help identify potential drug candidates with strong binding interactions, leading to a more efficient screening and selection of promising compounds. High-throughput DFT can be used in virtual screening to predict the binding affinities of a large library of drug-like compounds toward a specific target [70]. By virtually screening large numbers of compounds, researchers can prioritize the most promising candidates for further experimental validation. With the help of high-throughput DFT, researchers can investigate the nature of drug–target interactions at the molecular level [71]. It can identify key residues involved in binding and analyze the effects of ligand modifications on the binding affinity, which helps in the rational development of effective and selective drugs [72]. Algorithm high-throughput DFT can also predict physicochemical properties such as solubility, lipophilicity, and metabolic stability, which are crucial for assessing the pharmacokinetics and toxicity of a drug candidate [73]. These predictions guide the selection of compounds with favorable ADMET profiles and reduce the likelihood of failure in later stages of drug development. Also, high-throughput DFT can be used to study drug metabolisms by predicting the energy of various metabolic reactions such as hydroxylation or oxidation [74,75]. These predictions help identify potential metabolic sites and understand the metabolic pathways of drug candidates. On the other hand, high-throughput DFT can explore the conformational flexibility of ligands and identify the most stable conformers [76]. This information is critical for accurately representing ligand flexibility in molecular docking and molecular dynamics simulations and leads to more reliable binding predictions. High-throughput DFT can be used in fragment-based drug designing to analyze the binding of small fragments to a target protein. These calculations help select fragments that can be assembled into larger, more potent drug-like molecules [77].

NLP is a key AI technique used in text mining for drug discovery. NLP algorithms can process and interpret human language to extract relevant information from scientific literature, patents, clinical trial data, and other textual sources [78]. NLP-powered AI models can identify drug names, target proteins, chemical entities, and disease-related information, aiding researchers in gathering crucial data for drug discovery [78].

Text mining enables the identification of existing drugs with potential applications in different therapeutic areas [79]. By analyzing the literature, AI models can suggest drug candidates that have a demonstrated efficacy against specific diseases or targets, leading to drug repurposing opportunities and exploring the concept of polypharmacology [79]. AI models can integrate diverse data sources, such as clinical trial results, genomic data, and chemical databases, to build knowledge graphs [80]. Knowledge graphs represent complex relationships between drugs, targets, diseases, and biological pathways, facilitating comprehensive analysis and hypothesis generation [80]. Also, AI models can mine the literature to identify the adverse drug reactions reported in clinical studies and post-marketing surveillance. Extracting adverse drug reaction information from scientific literature helps improve drug safety assessments and informs decision-making in clinical trials [81]. Text mining by AI models can uncover the potential biomarkers associated with specific diseases or drug responses [82]. These biomarkers play a crucial role in personalized medicine, aiding in patient stratification and the development of targeted therapies.

Various text mining-based tools have been harnessed through AI-driven techniques to leverage their capabilities. For instance, Jang et al. introduced PISTON (http://databio.gachon.ac.kr/tools/PISTON/ (accessed on 1 February 2024)), a tool that employs NLP and topic modeling to predict drug side effects and indications [83]. DisGeNET (https://www.disgenet.org/ (accessed on 1 February 2024)) is a text mining-driven database offering a wealth of information on gene–disease and variant–disease relationships [84]. DisGeNET’s data analysis encompasses diverse biological processes, including adverse drug reactions, molecular pathways involved in diseases, and drug actions on targets. Another tool is STRING (https://string-db.org/ (accessed on 1 February 2024)), which represents a text mining-driven database. It offers an abundance of information on protein–protein interactions across various organisms [85]. In addition, STITCH (http://stitch.embl.de/ (accessed on 1 February 2024)) provides valuable information on interactions between proteins and chemicals–small molecules [86]. STITCH’s information is also utilized to determine drug binding affinities and drug–target associations.

GANs are a class of ML algorithms that consist of two neural networks, the generator and the discriminator, which are trained in an adversarial manner to generate realistic data samples [87]. In drug discovery, GANs are applied to generate new molecular structures [88] and optimize lead compounds [89], among other applications.

For example, GANs can generate novel molecular structures with certain desired properties. The generator network learns to produce realistic chemical structures, while the discriminator network evaluates their authenticity based on a training dataset. This process encourages the generator to produce new molecules that resemble the properties of known drugs, making GANs useful in de novo drug design [90].

Also, it was found that GANs can be employed to optimize lead compounds by generating modifications or analogs of existing drug candidates. By using the discriminator’s feedback to guide the generation of new chemical structures, GANs can propose modifications that are more likely to be biologically active and have improved pharmacological properties [91].

A number of studies have also shown that GANs can be used for multi-objective drug designing, where the goal is to optimize multiple drug properties simultaneously [41]. By adjusting the loss function of the GAN, researchers can balance various factors, such as the binding affinity, solubility, and selectivity, to generate molecules with desirable multi-objective profiles [41,89]. It should be noted that previous studies [92] have indicated that GANs can optimize specific molecular properties, such as the lipophilicity, molecular weight, or solubility. This capability allows researchers to fine-tune lead compounds or design molecules with the desired physicochemical properties [93].

According to the evidence to date, GANs can explore rare chemical space and identify molecules that are not commonly found in traditional drug databases. This capacity is valuable for discovering novel chemical entities with unique properties, potentially leading to the development of innovative drugs [94].

Studies show that GANs can be integrated into virtual screening pipelines to propose novel drug candidates. By generating diverse sets of molecules, GANs can expand the chemical diversity of virtual screening libraries and increase the chances of identifying hits against specific targets [95].

It should be noted that GANs can augment small datasets of known active compounds, enabling better generalization and improving the performance of predictive models by generating additional data samples [88]. Also, GANs enhance the efficiency and accuracy of the ML models used in drug discovery [96].

Present day science indicates that GANs can be used to predict drug–target interactions by generating molecular structures that are likely to interact with specific protein targets. The generated compounds can then be experimentally validated to identify potential novel drug–target interactions [94,97].

The other two AI algorithms used in drug discovery are transfer learning and active learning.

Transfer Learning makes it possible to fine-tune models that have been pre-trained on a larger dataset to cater to a specific material class or property using a smaller dataset. This is especially useful when there is a scarcity of labeled data. Transfer learning in drug discovery is an ML method that leverages knowledge gained from one task and applies it to another related task with limited data. This approach has shown great promise in addressing the challenge of sparsely labeled data in in silico drug discovery efforts [98]. In transfer learning, a pre-trained model developed for a specific task, such as image recognition, is used as a starting point for a new model targeting a different task, such as predicting drug–target interactions or identifying high-efficacy drug compounds [99]. By transferring the learned representations from the pre-trained model, the new model can benefit from the knowledge and generalization capabilities of the pre-trained model, even with a small amount of labeled data. In the past, quantitative structure–activity relationship (QSAR) models utilized regression models to establish links between molecule descriptors and biological properties [100].

In the field of drug discovery, ML techniques such as support vector machine algorithms and decision trees have been utilized for drug-like classification and the prediction of absorption, distribution, metabolism, excretion, and toxicity (ADME/T) properties [101,102,103]. Significant progress has been made in various areas through the use of AI technology, including predicting molecular properties and activities [104,105,106], virtual screening [107,108], retrosynthetic analysis [109,110], and generating new drugs [111,112]. Deep transfer learning, which involves using deep neural networks, is the most commonly used type of transfer learning in drug discovery [113]. Deep learning models, such as convolutional neural networks (CNN) and recurrent neural networks (RNN), have been applied to various drug discovery tasks, including compound activity prediction, virtual screening, and de novo drug designing [113]. These models can learn complex representations of chemical structures or biological data and transfer that knowledge to related drug discovery tasks. DL utilizes deep neural networks with multiple hidden layers to grasp and analyze complex knowledge, in contrast to traditional “shallow” ML approaches. Big data refers to datasets that are voluminous, diverse (i.e., originating from multiple sources), rapidly updated (i.e., in real-time), comprehensive (i.e., capturing the entirety of the system’s features rather than just samples), valuable (i.e., yielding numerous insights and potential for repurposing the data), and possess other defining characteristics [114]. Transfer learning offers a significant advantage in drug discovery by overcoming the challenge of limited and diverse datasets. Researchers can leverage pre-trained models to gain insights from vast and varied datasets in related fields [98]. For example, a pre-trained CNN model that has been trained on a large dataset of images can be fine-tuned and applied to analyze chemical structures or molecular fingerprints, enabling the prediction of compound activity or identifying potential drug–target interactions [98]. One useful application of transfer learning is its potential to speed up the process of discovering new drugs and enhance the effectiveness of identifying potent drug compounds. Through utilizing the knowledge stored in pre-existing models, researchers can decrease the amount of time and resources needed to train models from the ground up [98]. The method of using transfer learning in drug discovery enables faster testing and experimentation, which leads to speedy identification of promising drug candidates. Nevertheless, it is important to keep in mind that transfer learning in drug discovery is still an area of research with ongoing challenges and limitations to consider. One of these challenges is selecting the right pre-trained models and then fine-tuning them correctly. When choosing a pre-trained model, it is crucial to consider its relevance to the target task and the availability of appropriate datasets [35]. It is important to note that transfer learning does not always lead to better performance. This is particularly true when the source and target tasks are quite different. It is crucial to carefully assess how transferable the knowledge is between the tasks to ensure that the transferred representations are relevant and useful for the desired target task [98]. To sum up, transfer learning is a hopeful strategy in drug discovery which tackles the problem of insufficient labeled data and speeds up the detection of effective drug compounds. It involves using pre-trained models and applying knowledge from similar tasks to enhance the drug discovery process. This method can help researchers obtain useful representations and improve the efficiency of the process. However, there is still a need for more research to optimize the selection and fine-tuning of pre-trained models, and to explore the broader possibilities of transfer learning in drug discovery.

On the other hand, through the active selection of informative samples, active learning can determine which materials to test or simulate next, significantly reducing the number of experiments required. The use of AI techniques in material discovery has led to impressive advancements in drug discovery. By leveraging the power of computation and data-driven insights, researchers can more efficiently design and discover materials with customized properties for various applications. This ultimately accelerates innovation across industries [98]. Active learning is an ML technique used in drug discovery. Its goal is to improve the selection of compounds for experimental testing by iteratively selecting the most informative samples to label. This approach reduces the need for the exhaustive screening of large compound libraries and focuses on areas of chemical space with the highest potential for success while also considering structural novelty [115]. Active learning involves starting with a small group of labeled compounds and continuously choosing more compounds to label based on the model’s predictions. The selected compounds are then tested and the results are used to update the model and improve the selection process for future cycles [115]. By actively choosing which compounds to label, active learning algorithms can effectively navigate and utilize the chemical space, resulting in more efficient and cost-effective drug discovery processes. These algorithms strive for greater predictive accuracy using fewer labeled samples than traditional passive learning methods [115]. There are many drug discovery tasks that can benefit from active learning methods. These include predicting compound activity, optimizing leads, and virtual screening. Active learning can be used with various ML models, such as SVM, RF, and neural networks [115]. Active learning in drug discovery offers several benefits, including saving costs and resources. This is achieved by selecting a targeted subset of compounds for experimental testing, thereby reducing the need for extensive screening and saving time and resources [115]. Active learning algorithms can efficiently explore chemical space by choosing compounds that are likely to yield valuable information. This approach leads to a more targeted and effective drug discovery process [115]. Active learning can enhance the model’s predictive accuracy by regularly updating it with experimental feedback. This process leads to more precise predictions of compound activities over time [115]. When it comes to implementing active learning in drug discovery, there are some challenges and factors to consider. One of the biggest is choosing the right ML model and optimizing its parameters, which is crucial for success. It is important to find a model that can comprehend the complex connections between the chemical structures and activities, and the optimization process itself should be thoughtfully designed to balance exploration and exploitation. The selection of compounds for labeling is another vital step in active learning, and there are various strategies to consider, including uncertainty sampling, querying by committee, and diversity-based sampling. The best approach will depend on the task at hand and the data available. Finally, integrating active learning into existing drug discovery workflows may require some adjustments and considerations. The infrastructure, experimental design, automation, and data management should all be aligned with the active learning process to maximize its benefits [115]. To summarize, active learning is an effective method in drug discovery that leads to faster and more precise compound selection for testing. This is achieved by repeatedly selecting compounds based on the model’s predictions and experimental results. Active learning lowers expenses, enhances the exploration of chemical space, and improves predictive precision. However, it is crucial to thoughtfully select the models, data selection strategies, and workflow integration in order to successfully integrate active learning into drug discovery pipelines.

In the end of Section 2, we have centralized in Table 2 some collaborations between pharmaceutical companies and AI providers.

Collaborations between pharmaceutical companies and AI providers.

## Section: 3. Studies of AI-Assisted Drug Discovery

AI offers a powerful tool for drug discovery, with applications ranging from predicting drug properties to generating new chemical structures and optimizing drug properties (Figure 5). One of the most common applications of AI in drug discovery is through the use of ML algorithms. These algorithms can learn from large datasets of chemical structures and biological data to predict the properties of new compounds, such as their ability to bind to a target protein (affinity prediction) or their toxicity (toxicity prediction). This can help to identify potential drug candidates that can be tested in the lab. Another application of AI in drug discovery is through the use of GANs that can be used to generate new chemical structures that are likely to bind to a target protein based on the chemical structures of known active and inactive compounds. AI can also be used in drug discovery for multi-objective optimization, where the goal is to optimize a drug for multiple desirable properties, such as high efficacy, low toxicity, and good solubility.

Applications of artificial intelligence in drug discovery.

AI tools/platforms already used in drug discovery.

## Section: 3. Studies of AI-Assisted Drug Discovery › 3.1. AI Programs and Platforms Used for Drug Discovery

Different AI tools/platforms are already used in drug discovery (Table 3).

For example, an MLP model uses a Python-based AI system to find a suitable candidate in drug discovery (DeepChem) and can be accessed at [116].

Another Python-based system driven by computational tools can aid the detection of the molecular activity of compounds (DeepNeuralNetQSAR) and can be found at [117].

On the other hand, there exists a program that helps to report the procedure for chemical synthesis in a standardized format (Chemputer) [118].

The Tox21 Data Challenge tested 12,000 chemicals for toxic effects using specially designed assays. DL was used in this example to predict toxicity. DeepTox software outperformed other methods, proving DL to be a superior method for toxicity prediction [119].

AlphaFold is an AI program developed by DeepMind, a subsidiary of Alphabet, that predicts the 3D structures of proteins. The program utilizes deep learning techniques and has been highly successful in protein structure prediction. AlphaFold participated in the Critical Assessment of Structure Prediction (CASP) competition and achieved remarkable accuracy in predicting protein structures, outperforming other groups [120]. AlphaFold has undergone two major versions: AlphaFold 1 (2018) and AlphaFold 2 (2020). In both versions, the program demonstrated exceptional performance in predicting protein structures. AlphaFold 2, in particular, achieved a level of accuracy much higher than any other group in the CASP competition. It scored above 90 for approximately two-thirds of the proteins in the global distance test (GDT), a measure of how closely the predicted structure aligns with the experimentally determined structure.

The success of AlphaFold has been regarded as a significant breakthrough in the field of structural bioinformatics. However, it is important to note that while AlphaFold has achieved remarkable accuracy, there are still challenges to be addressed, and the protein folding problem is not considered completely solved. Nonetheless, the technical achievement of AlphaFold has garnered widespread respect and has the potential to accelerate the advancement of structural bioinformatics.

AlphaFold utilizes an AI-based approach called Evoformer, which treats protein structure prediction as a graph inference problem in 3D space. This approach involves updated operations applied in series within each block of the network. The pair representation in AlphaFold encodes information about the relationships between the residues, while the MSA (multiple sequence alignment) representation encodes individual residues and the sequences in which they appear. The MSA representation updates the pair representation through an element-wise outer product, allowing continuous communication between the evolving MSA representation and the pair representation. This approach enables the accurate prediction of protein structures [121]. The development of AlphaFold has the potential to revolutionize structural bioinformatics and accelerate the advancement of our understanding of protein structures. By combining AI techniques with curated structure and sequence databases, it can help bridge the gap between genomics and experimental structure determination, leading to a deeper understanding of biological processes and the development of new therapies [121].

ORGANIC [122] is a molecular generation tool that helps create molecules with certain desired properties. It utilizes generative ML approaches and deep neural networks to enable the design of novel molecular materials. The goal-directed generative model powered by deep neural networks and high-throughput simulations allow for a more directed design approach, minimizing design bias and enabling the exploration of specific material’s property spaces [123]. One of the key applications of ORGANIC is in the design of organic electronic materials, such as those used in organic light-emitting diodes (OLEDs). By leveraging generative ML frameworks, such as recurrent neural networks (RNNs) and deep RL, ORGANIC can rapidly identify new materials for OLED applications. This approach accelerates the development of novel organic electronic materials while also enabling expansion into other domains like catalyst design, aerospace, life science, and petrochemicals [123].

Another area where ORGANIC can be applied is in the virtual design of organic semiconductors based on metal–organic frameworks (MOFs). MOFs offer a supramolecular approach to modulate the arrangement of organic semiconductor molecules, allowing for the tailoring of the material properties. ORGANIC can automate the design process by generating MOF structures, sampling their structural dynamics, and predicting properties such as the conduction properties, absorption, and interaction with light. This automated workflow tool enhances the modeling and characterization of a wide variety of MOFs [124].

The development of ORGANIC provides researchers with a powerful tool for molecular generation and property optimization. By leveraging ML techniques and high-throughput simulations, it enables the rapid exploration of chemical space and the design of molecules with the desired properties. The availability of user-friendly interfaces and its integration with existing computational chemistry software, such as VASP and Gaussian, further enhances its usability and applicability in various research domains [125].

PotentialNet [126] is a program that utilizes neural networks to predict the binding affinity of ligands in protein–ligand complexes. It employs deep attention mechanisms and descriptor embeddings to improve the accuracy of binding affinity prediction [127]. The program focuses on intermolecular interactions within the molecular complex to capture important descriptors for an accurate prediction [127]. The approach used in PotentialNet involves representing the molecular complex as a 1D vector based on the descriptor information obtained from the training dataset. The descriptors are generated for the contacted protein and ligand atom pairs in the complex. The distance between the protein atom and the ligand atom pair is calculated using the Euclidean distance, with a cutoff value typically set at 12 Å [127]. The program considers various intermolecular interactions, including steric interactions, hydrophobic interactions, and hydrogen bonding.

The model architecture of PotentialNet incorporates an attention mechanism, which highlights important descriptors for a binding affinity prediction [128]. This mechanism helps capture the binding sites in the protein–ligand complex and improves the overall prediction performance. The program also utilizes a deep neural network model, specifically a PUResNet architecture, which consists of encoder and decoder blocks with skip connections [128].

To evaluate the performance of the binding affinity models, several metrics are used, including the mean absolute error (MAE), root mean square error (RMSE), Pearson’s correlation coefficient (PCC), Spearman’s correlation coefficient (SCC), and the standard deviation in regression (SD) [127]. The selection of an optimal number of descriptors is conducted by training a random forest model and sorting the descriptors according to their priorities. The model is then trained using different numbers of descriptors, and the performance is evaluated to determine the optimal number [127].

Hit Dexter is an ML technique used for predicting molecules that might respond to biochemical assays. It is an ML model specifically designed for hit discovery in the drug discovery process. Hit discovery involves identifying small molecules that have the potential to bind to a target and alter its function. By applying diverse algorithms and multivariate parameters, Hit Dexter aims to identify hits against specific biological targets or neurological complications [35].

One of the key components of Hit Dexter is the utilization of deep learning techniques to extract and analyze the chemical and physical properties of molecules. For example, deep learning models have been used to predict properties such as the absorption, distribution, metabolism, and excretion (ADME) of drug candidates. These models incorporate molecular graphs and utilize concepts like CNNs and ANNs to predict properties such as oral drug absorption. By considering various molecular descriptors and using ML algorithms like SVM regression and boosting, accurate predictions can be made [35].

Another aspect of Hit Dexter is the use of QSAR models. QSAR models leverage deep learning techniques to extract features from chemical strings and automatically extract relevant molecular descriptors. These models have shown promising results in hit-to-lead optimization research, providing predictions for binding affinities and aiding in the selection of potential drug candidates [35].

The application of Hit Dexter extends beyond drug discovery. It can also be used in the prediction of bioactivity, prognosis of prote–protein interactions, homology modeling/prediction of protein folding, and digital pathology [35].

DeltaVina [129] is a scoring function used for rescoring the binding affinity between proteins and ligands. It incorporates ML techniques and diverse algorithms to improve the accuracy of binding affinity predictions [130]. DeltaVina is designed to improve the accuracy of scoring the protein–ligand binding affinity. It utilizes various ML algorithms, including XGBoost and random forest, to incorporate different molecular descriptors and features. The performance of DeltaVina has been evaluated on benchmark datasets and compared to classical scoring functions, demonstrating its effectiveness in predicting binding affinities and identifying potential drug candidates. The scoring function and its code are available for use and further research [131].

The neural graph fingerprint [132] is a technique used to predict the properties of novel molecules. It involves generating molecular sentences and encoding them using a language model, such as BERT, to obtain high-dimensional embeddings of the substructures. These embeddings represent the molecules in vector form, which can be used for downstream tasks like molecular property prediction [133].

Once the molecular sentences are constructed, they are encoded using a language model, such as BERT. This pre-trained model can generate high-dimensional embeddings of the substructures, representing the molecules in vector form. These embeddings capture important features and structural information of the molecules, which can be used for predicting their various molecular properties [133]. To evaluate the performance of the prediction model, different metrics are used. For example, for classification tasks, the cross-entropy loss function is used, and the prediction performance is evaluated using the ROC-AUC (the area under the receiver operating characteristic curve) [133]. The ROC-AUC represents the ability of the model to distinguish between positive and negative samples. On the other hand, for regression tasks, the mean squared error (MSE) loss function is used, and the prediction performance is evaluated using the root mean squared error (RMSE) and the coefficient of determination (R2) [133]. The RMSE measures the average squared difference between the predicted and real property values, while the R2 reflects the goodness of fit and prediction. The neural graph fingerprint, with its molecular sentence generation and language model-based encoding, offers a powerful approach for predicting the properties of novel molecules. By leveraging deep learning techniques and molecular embeddings, it enables accurate predictions and the analysis of various molecular properties [133].

GastroPlus [134] is a platform that utilizes AI and predictive modeling to aid in the design and optimization of drug formulations. This software is used for pharmaceutical products (dosage form) in many animal models, including rats, primates, and animals, allowing researchers to predict the drug absorption, distribution, metabolism, and excretion [135]. GastroPlus’s AI-driven approach aids in the development of more effective and bioavailable drug formulations, streamlining the drug development process.

AI tools/platforms already used in drug discovery.

## Section: 3. Studies of AI-Assisted Drug Discovery › 3.2. Example of AI in Drug Design

Next, we will present some examples which cover a range of topics related to AI in drug design, including the integration of AI in drug discovery, the prediction of drug–protein interactions, and practical guidelines for using ML algorithms. They provide valuable insights into the use of AI in the pharmaceutical industry and offer potential solutions to challenges in drug design and development.

For example, Paul D. et al. discusses the integration of artificial intelligence in drug discovery and development, including the tools and techniques used. They also highlight ongoing challenges and ways to overcome them [14].

Dara S. et al. explores various applications of artificial intelligence in drug design, including in the prediction of drug–protein interactions, the discovery of drug efficacy, and ensuring safety biomarkers [35].

Jiménez-Luna et al. focuses on explaining compound activity predictions using a substructure-aware loss for graphing neural networks. They explore the use of deep learning in predicting molecular properties [24]. They also provide practical guidelines for using gradient boosting in molecular property prediction. They offer insights into the application of ML algorithms in drug design.

Schneider et al. discuss the foundation of artificial intelligence in therapeutic science, including its applications in drug design. They explore adaptive graph learning methods for automated molecular interactions and property predictions [136].

The iterative process to design the 3D structures of receptors to generate a novel molecule is termed de novo drug designing, which is intended to produce new dynamics. Researchers utilized the indolent space portrayal to prepare a model dependent on the quantitative estimate of the drug likeness and drug similarity scores, and the manufactured availability score and synthetic accessibility score [137].

## Section: 3. Studies of AI-Assisted Drug Discovery › 3.3. Examples Cases of AI Used in Polypharmacology

Next, we present some examples of papers that shed light on the application of AI in polypharmacology and drug discovery. They discuss how AI can be used to predict drug–protein interactions and design safer drug molecules. Understanding polypharmacology is crucial in developing drugs that are effective against multiple targets while minimizing off-target effects. These papers provide valuable insights into the advancements and challenges in this field and offer potential strategies for improving drug design and development. Chauhari et al. explain the concept of polypharmacology, which refers to the tendency of a drug molecule to interact with multiple receptors, leading to off-target effects. They explore how artificial intelligence can aid in the design of safer drug molecules by considering polypharmacology [138].

Reddy et al. [139] provide an overview of polypharmacology studies and the challenges involved. They discuss the potential of a rational design using polypharmacology to develop more effective and less toxic therapeutic agents. The review outlines the latest progress in this field. Other authors [140] explore polypharmacy using AI and data analysis. The AI axis focuses on defining and detecting polypharmacy using algorithms to predict health outcomes based on medication combinations.

The use of AI in pharmaceutical product development is also discussed in a review [14]. The review suggests that AI can replace the traditional trial-and-error method in designing formulations. Computational tools, including quantitative structure–relationship (QSPR) models and decision-support tools, can help address issues related to formulation design such as stability, dissolution, and porosity. Furthermore, the integration of AI with mathematical models like computational fluid dynamics (CFD) can speed up the production of pharmaceutical products [14].

The involvement of AI in the development of a pharmaceutical product from the bench to the bedside can be imagined given that it can aid rational drug design [141]; assist in decision making; determine the right therapy for a patient, including personalized medicines; and manage the clinical data generated and use it for future drug development [142]. E-VAI is an analytical and decision-making AI platform, developed by Eularis, which uses ML algorithms along with an easy-to-use user interface to create analytical roadmaps based on the competitors, key stakeholders, and currently held market share to predict key drivers in the sales of pharmaceuticals [143], thus helping marketing executives allocate resources for the maximum market share gain, reversing poor sales and enabling them to anticipate where to make investments.

## Section: 3. Studies of AI-Assisted Drug Discovery › 3.4. Example Cases of AI in Drug Chemical Synthesis

The following example cases of AI in drug chemical synthesis highlight the use of artificial intelligence and ML in drug chemical synthesis. They explore the application of DL models in de novo drug design, the prediction of reaction outcomes, and the optimization of synthetic routes. The integration of AI with chemical knowledge and data-driven approaches has the potential to accelerate the drug discovery process and facilitate the design of new drug molecules. The paper by Paul D. et al. [14] is focused on the application of DL in drug discovery and medicinal chemistry, including the synthesis of new drug molecules. It explores the use of generative models and RL for de novo drug design and optimization.

Jiménez-Luna et al. [24] describe the use of AI in synthetic organic chemistry, specifically in reaction prediction, retrosynthesis, and reaction optimization. They discuss the integration of ML algorithms with chemical knowledge for efficient and automated synthesis planning. Their paper introduces DeepChem, a deep learning toolkit designed for drug discovery tasks. It covers various applications, including the generation of novel chemical structures, predicting chemical properties, and optimizing synthetic routes. The paper highlights the potential of deep learning in accelerating the drug discovery process. It also presents ML models for predicting the outcomes of organic reactions, including the yield and regioselectivity. It discusses the use of reaction fingerprints and molecular descriptors as input features for predicting reaction outcomes. The study demonstrates the potential of ML in guiding synthetic chemistry efforts.

## Section: 3. Studies of AI-Assisted Drug Discovery › 3.5. Case Examples of AI Used in Drug Screening

These examples provide insights into the application of AI in drug screening and discovery. They highlight the use of AI algorithms for identifying novel compounds, designing new drug candidates, and predicting protein structures. The integration of AI in drug screening processes can help accelerate the discovery of potential drug candidates and optimize the drug discovery pipeline.

Paul D et al. [14] discuss the integration of AI in various sectors of the pharmaceutical industry, including drug discovery and development. They highlight the use of AI in drug screening and repurposing, reducing the human workload, and accelerating the achievement of targets. Their paper also discusses the ongoing challenges and the potential ways to overcome them, along with the future of AI in the pharmaceutical industry.

Blanco-González et al. [3] present case studies demonstrating the successful application of AI in drug discovery. They showcase examples where AI algorithms have been used to identify novel compounds for cancer treatment, inhibitors for specific proteins involved in diseases like Alzheimer’s, and potential drugs for combating COVID-19. Their paper highlights the ability of AI to accelerate the drug discovery process and enable the development of more effective medications. It explores the impact of AI on the drug discovery process, with a focus on the design of novel compounds. It discusses how AI-based approaches, such as deep learning algorithms, can rapidly and efficiently design new drug candidates with desirable properties and activities. The paper also mentions the use of AI in structural biology, such as the development of AlphaFold, a software platform that uses AI to predict protein structures. This advancement has the potential to revolutionize personalized medicine and drug discovery.

Discovering drugs through AI models is a topic discussed on nexocode.com [144]. By analyzing large amounts of data, AI models can detect correlations that were previously unknown. This technology is being utilized in drug discovery to identify new drugs, design drug candidates, and assist in preclinical testing. AI is also being used to screen chemical repositories, identify new drug targets, and aid in computer-assisted molecular design.

A recent study showcased the use of AI in material discovery, as seen on unibas.ch [145]. The study’s author, a doctoral student, utilized quantum mechanics to generate predictions for thousands of crystals that had randomly determined chemical compositions. These predictions served as training data for statistical ML models. The ML models demonstrated an accuracy level equivalent to standard quantum mechanical approaches, but with the added benefit of speed. In a day, ML models can provide predictions, while quantum mechanical calculations would take a supercomputer over 20 million hours.

An interesting example is found on popularmechanics.com [146], where researchers used AI to develop a new type of compressible material. They did not have to rely on trial-and-error experimentation because they used existing research and AI algorithms to create new designs. This approach made the material discovery process much faster and allowed scientists to explore more design possibilities. The research also showed how important data-driven methods are in materials science. AI can suggest new approaches and designs as long as there are enough accurate data available.

The use of AI in the field of medicine goes beyond discovering new materials. According to ibm.com [147], AI has the potential to support precision medicine by providing patients with real-time recommendations that are tailored to their medical history, preferences, and needs. AI-powered virtual assistants are available 24/7 to provide healthcare information and address patient queries. Furthermore, AI is employed in medical imaging to detect diseases like breast cancer with comparable accuracy to human radiologists. Additionally, AI can help clinicians make sense of vast numbers of medical images and data, making them more manageable and enhancing patient care.

Healthcare is an ever-evolving field that is exploring the potential of AI in various medical domains. A comprehensive overview of AI in healthcare can be found on en.wikipedia.org [148]. In oncology, AI is used for cancer diagnosis, risk stratification, the molecular characterization of tumors, and drug discovery. For instance, AI algorithms have shown high accuracy in identifying breast cancer and prostate cancer. AI techniques such as artificial neural networks and Bayesian networks are used to diagnose and classify diseases. With the assistance of electronic health records, AI can analyze large amounts of data and help doctors with a patient’s diagnosis and treatment. Physics-inspired ML approaches are also being explored to enhance medical diagnostic approaches and perform biomarker analysis.

To benchmark and test AI applications in the health domain, the United Nations (WHO/ITU) has established the ITU-WHO Focus Group on Artificial Intelligence for Health (FG-AI4H). They are working on various cases for its use such as in assessing breast cancer risk, guiding antivenom selection, and diagnosing skin lesions.

The market potential of AI applications in drug discovery and development is immense. AI has emerged as a powerful tool in the pharmaceutical industry, revolutionizing the way new drugs are discovered, developed, and brought to market. With its ability to analyze vast amounts of data, AI offers the potential to accelerate the drug development process, reduce costs, and improve the success rate of bringing new medicines to patients.

Pharmaceutical companies, research institutions, and startups are increasingly investing in AI technologies to streamline drug discovery processes and gain a competitive edge in the market. Partnerships between AI companies and pharmaceutical giants are becoming more common, fostering the development of innovative drug discovery platforms.

## Section: 3. Studies of AI-Assisted Drug Discovery › 3.6. AI in Drug Discovery and Repurposing

In this section we provide information on different drugs discovered by means of AI, highlighting AI’s significant role in drug discovery, accelerating the identification of potential drug candidates and optimizing drug development processes. In the following, we present some drugs that have been discovered or aided by AI.

Zong et al. [149] explore a computational drug repurposing application by using electronic health records (EHRs) to discover new applications for approved or investigational drugs. Their review identified four themes: publication venues, data types and sources, data processing and prediction methods, and targeted diseases, validation, and released tools. The utilization of EHRs in drug repurposing is hindered by validation, accessibility, and understanding issues.

Yadi et al. [150] introduce guidelines on how to use AI for accelerating drug repurposing or repositioning. They present how to use AI models in precision medicine, and as an example, how AI models can accelerate COVID-19 drug repurposing.

In the paper by Wang et al. [151], a novel scoring algorithm, DrugRepo, uses chemical and genomic data to repurpose drugs for various diseases. In total, 516 approved drugs have been repurposed for 545 diseases using DrugRepo. Hundreds of novel predicted compounds have the potential for matching ongoing clinical trials.

Different research groups used AI algorithms to discover that naproxen, a commonly used pain reliever, has potential antiviral properties. An excellent illustration of an in silico and target-based technique for finding novel antivirals is naproxen. Lejal et al. used the X-ray structure of the RNA-free NP of H1N1 as a prototype to develop a structural-based modeling technique to find potential medications that target the nucleoprotein (NP) of the influenza A virus [152]. The non-steroidal anti-inflammatory medication naproxen, a well-known inhibitor of inducible cyclooxygenase type 2 (COX-2), was discovered using an in silico screening that was concentrated on a selected particular location of the NP structure. AI models identified this drug as potential inhibitors of a viral enzyme, providing valuable insights for future antiviral drug development [152]. In another study, naproxen demonstrated antiviral properties against SARS-CoV-2 using an in silico molecular docking analysis (using Autodock Vina) [153].

By using molecular modeling and virtual screening studies, Mostafa et al. tested the antiviral activity of anti-microbial and anti-inflammatory FDA-approved drugs, commonly prescribed to relieve respiratory symptoms, against SARS-CoV-2 [154]. The docking study was performed using OpenEye scientific software version 2.2.5. A virtual screening study illustrated that Azithromycin, Niclosamide, and Nitazoxanide bind to the main protease of SARS-CoV-2.

Baricitinib is an oral Janus kinase (JAK)1/JAK2 inhibitor approved for the treatment of rheumatoid arthritis. The Eli Lilly and Incyte Corporation used AI algorithms to analyze large-scale datasets to predict its usefulness on COVID-19 infection through planned anti-cytokine effects and as an inhibitor of host cell viral propagation [155].

DSP-1181 was Developed by Sumitomo Dainippon Pharma and Exscientia. It is a drug designed using AI algorithms [156]. It became the first AI-designed drug to enter human clinical trials for the treatment of obsessive-compulsive disorder (OCD). DSP-1181 is a long-acting, potent serotonin 5-HT1A receptor agonist [156]. AI played a pivotal role in the drug’s discovery by rapidly analyzing vast datasets, identifying potential drug candidates, and optimizing the molecular structures to enhance their therapeutic effects. The successful progression of DSP-1181 to clinical trials showcases the potential of AI in expediting drug development for challenging neurological disorders [156].

DSP-2230 was also Developed by Sumitomo Dainippon Pharma and Exscientia, by means of AI-design, and is being investigated for the treatment of OCD. AI algorithms were utilized to analyze biological data and identify the novel compounds that can modulate the specific brain receptors implicated in the disorder [157].

Berzosertib (formerly M6620, VX-970), developed by Merck KGaA and C4X Discovery [158], is a promising drug investigated for its applications in targeting the DNA repair mechanisms in various cancers. AI played a significant role in identifying Berzosertib as a potential candidate for cancer treatment [159]. Through the AI-driven analysis of genetic and molecular data, researchers could pinpoint specific DNA repair pathways that the drug could effectively target, making it a promising addition to cancer therapy.

Halicin is a revolutionary antibiotic discovered by MIT researchers through the application of AI models [160]. It demonstrated remarkable effectiveness against a wide range of bacterial infections, including drug-resistant strains [161]. AI enabled the screening of a vast number of chemical compounds to identify Halicin as a potent antibiotic. The discovery of Halicin highlights the potential of AI in quickly identifying new classes of antibiotics to combat the growing problem of antibiotic resistance.

Evinacumab is a drug developed by Regeneron Pharmaceuticals using AI [162]. The drug was identified as a potential therapy for homozygous familial hypercholesterolemia (a rare genetic disorder characterized by extremely high cholesterol levels), refractory hypercholesterolemia (both familial and non-familial), and severe hypertriglyceridaemia [162]. AI algorithms were utilized to analyze vast datasets of genetic and biochemical information to identify the specific targets and pathways involved in cholesterol regulation. This helped researchers identify evinacumab as a monoclonal antibody that binds to and blocks an enzyme called ANGPTL3, thereby reducing cholesterol levels in affected individuals [162].

The Amarin Corporation developed Icosapent Ethyl to reduce cardiovascular risk [163]. The AI-driven analysis of clinical trial data helped demonstrate the drug’s effectiveness in reducing cardiovascular events in patients with high triglyceride levels, leading to its approval by regulatory authorities. Icosapent Ethyl is a high-purity prescription form of EPA ethyl ester approved by the US Food and Drug Administration at a dose of 4 g/day as an adjunct to diet to reduce plasma triglyceride levels in adults with severe hypertriglyceridemia [164].

LegoChem Biosciences, using AI models, developed Delpazolid (LCB-010371) as a potential antibiotic with effectiveness against drug-resistant bacteria, including Methicillin-resistant Staphylococcus aureus (MRSA) and Vancomycin-resistant Enterococci (VRE) [165]. AI-driven drug discovery methods were employed to identify Delpazolid as a novel antibiotic candidate. LegoChem Biosciences utilizes its ConjuAll and Legochemisty platform technologies to discover and develop drugs.

InSilico Medicine has used their AI platform Pharma.AI™ to develop INS018-055 to help treat idiopathic pulmonary fibrosis [166]. Targeting the discoidin domain receptor 1 (DDR1) is how INS-08055 works. DDR1, an epithelial cell-expressed pro-inflammatory receptor tyrosine kinase involved in fibrosis, is activated by collagen and inhibited by INS-08055. The medication candidate, which is delivered orally and intravenously, improves illness symptoms by inhibiting DDR1 [166].

Developed by Merck & Co., Pembrolizumab (Keytruda) is an AI-discovered drug used for the treatment of various cancers, including melanoma, lung cancer, and head and neck cancers [167].

The UK Medicines and Healthcare Products Regulatory Agency (MHRA) has received a clinical trial application from BenevolentAI for BEN-8744, a small molecule phosphodiesterase 10 (PDE10) inhibitor that is intended to treat ulcerative colitis [168].

Sotorasib (AMG 510), developed by Amgen, is an AI-optimized drug used for the treatment of non-small cell lung cancer with specific genetic mutations. AI algorithms were used to analyze cancer genomic data and identify potential compounds that selectively inhibit the mutated protein responsible for tumor growth [169].

The above-mentioned drug examples highlight the diverse applications of AI in drug discovery and development, from optimizing drug structures and formulations to identifying novel targets and repurposing existing drugs for new indications. AI technologies continue to revolutionize the pharmaceutical industry, enabling more efficient and targeted drug development processes that hold the potential to transform patient care and treatment outcomes.

## Section: 4. The Market Prospects of AI-Based Drug Development

Pharmaceutical companies are converting to AI solutions to reduce the financial costs and potential losses connected with virtual screening. Between 2015 and 2018, the AI market grew from USD 200 to USD 700 million, and by 2024, it is expected to reach USD 5 billion [170]. An expected 40% increase from 2017 to 2024 suggests that AI may reshape the pharmaceutical and medical industries. Many pharmaceutical companies have invested in AI or are continuing to do so, as well as collaborating with AI service providers to develop critical medical equipment. Examples of collaboration are given in Table 4.

Collaborations of pharmaceutical companies with AI providers/developers for various applications.

## Section: 5. Challenges and Limitations in AI-Assisted Drug Discovery

The use of AI to aid in the discovery of new materials holds immense potential in developing materials with specific properties for diverse applications. However, there are challenges and limitations that need to be acknowledged and addressed to ensure its effective implementation [3].

One of the main challenges highlighted in our paper is related to the quality and quantity of data. AI models require a large volume of high-quality data for training. In materials science, obtaining comprehensive and dependable datasets can be difficult due to the vast number of materials and properties that can be taken into consideration. Incomplete or inaccurate data can result in biased or erroneous predictions.

Therefore, reliable and high-quality data are the foundation of AI-assisted research. Industries must ensure that the data used for training AI models are precise, representative, and related to the specific research objectives. It is crucial to address data limitations, such as biases or incomplete datasets, to avoid skewed results and unreliable conclusions.

When it comes to discovering new materials, there are several important factors to consider. Firstly, data representation is key. This involves transforming complex material data, like crystal structures or chemical compositions, into formats that AI models can understand. It is important to develop representations that capture essential features while remaining interpretable [171].

Algorithm selection and development is also crucial. The appropriate AI algorithms for a material’s discovery will depend on the specific problem at hand. Developing custom algorithms that can handle the unique challenges of material data, such as high dimensionality and non-linear relationships, requires expertise in both AI and materials science.

While AI models can predict material properties with impressive accuracy, interpreting the underlying reasons for these predictions remains a challenge. Understanding the relationship between the input features and output properties is essential for guiding further research and design.

Finally, effective material discovery often requires the integration of domain-specific knowledge, such as quantum mechanics or thermodynamics. Combining AI techniques with specialized scientific insights is essential to ensure accurate predictions and meaningful discoveries [14].

When training data are biased, AI models may not perform well when presented with new materials or conditions. It is crucial to ensure diversity and representativeness in the training dataset to avoid this issue. However, researchers may face limitations in accessing a powerful computing infrastructure, which is often necessary for resource-intensive tasks, such as simulating material properties at different scales or conducting high-throughput calculations. Additionally, the vast and intricate search space of potential materials can pose a challenge when trying to find the optimal candidate. Advanced optimization techniques are required to explore this space efficiently [172].

It is also important to validate AI model predictions through experimental testing, which can be a time-consuming and costly process. Moreover, discovering new materials with advanced properties raises ethical and safety concerns. AI-assisted discoveries must be safe, environmentally friendly, and compliant with regulations. Industries must establish ethical guidelines that ensure responsible data usage, transparent algorithms, and the fair treatment of all stakeholders to address these concerns. Overall, AI-assisted research presents exciting opportunities but also requires the careful consideration of these issues [173]. When incorporating AI tools into the material discovery process, researchers must adjust their workflows and thinking. Cooperation between materials scientists and AI specialists is crucial for the optimal usage of these tools. AI-assisted material discovery offers exciting possibilities for revolutionizing the field by speeding up the identification of materials with the desired properties. However, the challenges and limitations mentioned above stress the importance of interdisciplinary collaboration, better data organization, innovative algorithms, and ethical and scientific considerations. Overcoming these obstacles will lead to the successful integration of AI in material discovery and ultimately fuel innovation across various industries [174].

Industries that handle sensitive or proprietary data should prioritize data security and implement strong measures to safeguard information against unauthorized access and breaches. It is crucial to balance the benefits of AI-powered insights with data security concerns. To ensure the reliability and applicability of AI-generated insights across various contexts, rigorous validation procedures are essential. Since AI-assisted research often requires significant computational resources, including powerful hardware and significant energy consumption, industries need to assess their computational needs and allocate resources effectively. Industries should implement strategies to identify and mitigate biases in AI models that may inadvertently perpetuate the biases present in the training data. In regulated industries, AI-assisted research must comply with relevant regulations and standards. To reap the full benefits of AI-driven research outcomes, industries must commit to long-term strategies that require continuous investment in updating models, refining algorithms, and adapting to evolving research needs. In fostering a collaborative environment, industries must encourage researchers to work alongside AI systems, leveraging their strengths to make more informed decisions and discoveries, and augmenting human capabilities [3]. To sum up, utilizing AI in research can lead to groundbreaking discoveries and drive innovation in various industries. However, it is crucial to carefully consider important factors such as data quality, ethics, expertise, security, and collaboration to ensure successful implementation. By thoughtfully addressing these considerations, industries can fully utilize the potential of AI to revolutionize their research practices and achieve unprecedented levels of discovery and innovation [3].

## Section: 6. Future Directions and Opportunities in AI-Assisted Drugs Discovery

The global AI-in-drug discovery market is projected to witness significant growth in the coming years. Advancements in AI technologies, such as ML, natural language processing, and deep learning, have led to the development of sophisticated algorithms capable of analyzing complex biological data and predicting the interactions between drugs and their targets.

AI-driven platforms are being used for the virtual screening of large compound libraries, identifying potential drug candidates with higher accuracy and efficiency than traditional methods. These platforms can also optimize lead compounds and predict their pharmacokinetic and toxicity profiles, aiding in the selection of the most promising candidates for further development.

Furthermore, AI is transforming drug design by enabling the generation of novel molecular structures with specific properties. AI-generated molecules can be tailored to target specific diseases and biological pathways, offering new opportunities for precision medicine.

As regulatory agencies, such as the FDA, continue to embrace AI applications in drug development, the market potential of AI in the pharmaceutical industry is expected to grow further. However, challenges remain, including data privacy concerns, the validation of AI models, and the integration of AI with existing drug development processes.

Moreover, AI’s potential extends beyond drug discovery and development. It also plays a critical role in clinical trials, patient stratification, and the real-time monitoring of treatment responses, enabling personalized medical approaches that enhance patient outcomes.

The use of advanced simulation and modeling techniques in AI has the potential to revolutionize the drug discovery process, making it more efficient and effective. With AI, it is possible to model and simulate biological networks, which deepens our understanding of disease mechanisms and helps in the discovery of new drugs [175].

The use of AI in drug discovery has many benefits. Traditional approaches face obstacles such as high costs, inefficiency, and lengthy timelines. AI can address these issues by automating and optimizing processes, resulting in more efficient and effective drug discovery. This enables the discovery of novel drug candidates that may have been overlooked using traditional approaches. AI leverages advancements in biology and computing to develop cutting-edge algorithms for drug discovery, leveling the playing field and enabling more researchers to access powerful computational tools for drug development. Furthermore, AI models have a higher predictive power, reducing the potential for false positives in drug screening. By carefully designing the assay parameters, AI can identify meaningful interactions and prioritize promising targets for further investigation [176].

The use of AI in drug discovery shows potential by moving drug screening from the lab to a virtual environment, resulting in faster screening and the ability to identify promising targets without extensive effort and manpower. However, implementing advanced simulation and modeling techniques in AI for drug discovery poses challenges such as the data quality, interpretability of AI models, and the need for validation and reproducibility. Despite these challenges, AI has the potential to improve drug discovery efficiency, enable unbiased exploration, and enhance its predictive power, leading to reduced costs and an increased likelihood of successful drug candidates. To successfully integrate AI in drug discovery, addressing these challenges and ensuring the reliability and interpretability of AI models is crucial.

## Section: 7. Conclusions

The future of AI in drug discovery involves a closer integration with automation, which would allow AI systems to make decisions on compound design and synthesis without human input. This shift from an augmented drug design paradigm to an autonomous one has the potential to accelerate the drug discovery process and yield better starting points for drug development. Ultimately, the goal is to develop fully autonomous laboratories that can iterate through the design–make–test–analyze cycle of drug discovery on their own. This could lead to faster and more efficient drug discovery processes, with AI systems suggesting and testing new compounds autonomously. However, there are challenges to overcome, such as proving the reliability and reproducibility of AI-assisted findings. Furthermore, the availability of robust datasets and investments in AI technology are important considerations for the future adoption and success of AI in drug discovery.

The major challenge for the medical industry while developing a new drug is its increased costs and reduced efficiency. ML approaches and recent developments in DL come with great opportunities to reduce this cost, increase efficiency, and save time during the drug discovery and development process. Even though there are some obstacles and a tremendous amount of work to be conducted to incorporate AI tools in the drug discovery cycle, concretely, despite these challenges, AI has already demonstrated promising results in discovering new combinations of materials for drug discovery, accelerating the search for drug candidates, optimizing drug formulation and delivery, improving target identification, and enhancing virtual screening. The future outlook for AI in drug discovery is promising, with advancements expected in autonomous decision-making and the integration of AI with automation.

## Section: Author Contributions

Conceptualization, A.I.V.; methodology, A.I.V.; software, I.N.; validation, A.I.V.; formal analysis, I.N.; investigation, A.I.V. and I.N.; resources, I.N.; data curation, I.N.; writing—original draft preparation, A.I.V. and I.N.; writing—review and editing, A.I.V.; visualization, I.N.; supervision, A.I.V.; project administration, I.N.; funding acquisition, I.N. All authors have read and agreed to the published version of the manuscript.

## Section: Institutional Review Board Statement

Not applicable.

## Section: Informed Consent Statement

Not applicable.

## Section: Data Availability Statement

Not applicable.

## Section: Conflicts of Interest

The authors declare no conflicts of interest.

## Section: Funding Statement

This work was supported by the Romanian Ministry of Education and Research, under Romanian National Nucleu Program LAPLAS VII—contract no. 30N/2023. A.I.V. acknowledges the financial support of the Romanian Ministry of Education and Research, CNCS-UEFISCDI, project no. PN-III-P4-ID-PCE-2020-2273 (11/2020, RENERI), within PNCDI III. I.N. acknowledges the support of a grant of the Ministry of Research, Innovation and Digitization, CNCS—UEFISCDI, project no. PN-III-P2-2.1-PED-2021-3178 within PNCDI III.

## Section: Associated Data › Data Availability Statement

Not applicable.


---

# Integrating machine learning algorithms and multiple immunohistochemistry validation to unveil novel diagnostic markers based on costimulatory molecules for predicting immune microenvironment status in triple-negative breast cancer

- **Authors:** Chao Zhang, Wenyu Zhai, Yuyu Ma, Minqing Wu, Qiaoting Cai, Jiajia Huang, Zhihuan Zhou, Fangfang Duan
- **Issuer:** Frontiers in immunology
- **Type:** Scientific article
- **Published:** 2024-06-28
- **Language:** en
- **DOI:** 10.3389/fimmu.2024.1424259
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39007147/
- **Licence:** CC-BY

## Section: Abstract

AbstractIntroductionCostimulatory molecules are putative novel targets or potential additions to current available immunotherapy, but their expression patterns and clinical value in triple-negative breast cancer (TNBC) are to be clarified. MethodsThe gene expression profiles datasets of TNBC patients were obtained from The Cancer Genome Atlas and the Gene Expression Omnibus databases. Diagnostic biomarkers for stratifying individualized tumor immune microenvironment (TIME) were identified using the Least Absolute Shrinkage and Selection Operator (LASSO) and Support Vector Machine-Recursive Feature Elimination (SVM-RFE) algorithms. Additionally, we explored their associations with response to immunotherapy via the multiplex immunohistochemistry (mIHC). ResultsA total of 60 costimulatory molecule genes (CMGs) were obtained, and we determined two different TIME subclasses (“hot” and “cold”) through the K-means clustering method. The “hot” tumors presented a higher infiltration of activated immune cells, i.e., CD4 memory-activated T cells, resting NK cells, M1 macrophages, and CD8 T cells, thereby enriched in the B cell and T cell receptor signaling pathways. LASSO and SVM-RFE algorithms identified three CMGs (CD86, TNFRSF17 and TNFRSF1B) as diagnostic biomarkers. Following, a novel diagnostic nomogram was constructed for predicting individualized TIME status and was validated with good predictive accuracy in TCGA, GSE76250 and GSE58812 databases. Further mIHC conformed that TNBC patients with high CD86, TNFRSF17 and TNFRSF1B levels tended to respond to immunotherapy. ConclusionThis study supplemented evidence about the value of CMGs in TNBC. In addition, CD86, TNFRSF17 and TNFRSF1B were found as potential biomarkers, significantly promoting TNBC patient selection for immunotherapeutic guidance.Keywords: triple-negative breast cancer, costimulatory molecules, diagnostic biomarker, tumor immune microenvironment, machine learning algorithm

## Section: Introduction

Triple-negative breast cancer (TNBC) accounts for nearly 15% of all breast cancers (1). Due to its paucity of definitive targets and the intrinsic aggressiveness, most TNBC-related deaths occur, and it remains a grave life-threatening disease among women worldwide (2–5). In view of lacking estrogen receptor (ER), progesterone receptor (PR), and human epidermal growth factor receptor 2 (HER2), TNBC can’t benefit from endocrine and targeted treatments, and depend on traditional chemotherapy with little clinical benefits realized, a median overall survival (OS) about 12 to 18 months (6–9).

In recent years, immune-checkpoint inhibitors (ICIs) have revolutionized the therapeutic landscape of multiple tumors, such as nasopharyngeal carcinoma, melanoma, and lung cancer, wherein, ICIs generated durable responses, resulted in substantial survival progress, and have been recommended as a part of standardized treatments (10). Compared with other breast cancer subtypes, TNBC exhibits stronger immunogenicity, abundant tumor-infiltrating lymphocytes (TILs), higher programmed cell death ligand 1 (PD-L1) expression and tumor mutation burden (TMB) (2, 11, 12), numerous explorations on adding ICIs to the therapeutic arsenal of TNBC have acquired inspiring feedback (13–15). While survival benefits derived from ICIs in TNBC are relatively minimal as compared to other tumors (2, 16, 17). Therefore, identifying and developing optimal biomarkers have become a hot area. Currently, PD-L1 and TMB are most used predictors for patient selection in clinical practice, but absence of standardized criteria for the methodology and expression cutoff values leads to their inconsistency predictive value in different clinical trials and therapeutic regimes (16, 18, 19). Although a possible association between higher TILs and improved pCR rates from an immunotherapeutic perspective has been examined, it is confined to the early stage of TNBC (20). Hence, novel predictors of immunotherapeutic response are necessary and meaningful to appropriately select ideal patients who can benefit from ICIs with the aim to design individualized strategies.

The tumor immune microenvironment (TIME), composed of various immune cells, stromal cells, mesenchymal cells, cytokines, and chemokines, plays a crucial role in the processes of tumor initiation, progress, development, and metastasis (21). A deep parsing of the diversity and complexity of TIME is valuable for improving anti-tumor immune responses and patient stratification according to their unique TIME classes and subclasses, thereby greatly improving therapeutic benefits from ICIs and unraveling novel targets (22). Increasing evidence suggests that features associated with the “hot” tumor, including abundant TILs in TIME, markers related to T cell activation, as well as signatures for adhesion, are potential factors for predicting responses to ICIs (23). Costimulatory molecules, comprising the B7-CD28 family with 13 molecules and the tumor necrosis factor (TNF) family with 48 molecules, are vital for the differentiation, proliferation, maturation, survival, activation, and functions of immune cells. The former includes the most common PD-1 and PD-L1 axis of ICIs, the latter includes 19 members belong to the TNF ligand superfamily (TNFSF) and 29 members to the TNF receptor superfamily (TNFRSF) (22, 24, 25). Moreover, they are putative novel targets or potential additions to current available immunotherapeutic strategies (26, 27). The predictive model based on costimulatory molecule genes (CMGs) have been explored in lung adenocarcinoma (28), while their functions and clinic value in TNBC are little illustrated.

Herein, we aimed to systematically dissect the expression pattern and clinical value of costimulatory molecules in TNBC. Using the transcriptional profiles of TNBC patients from The Cancer Genome Atlas (TCGA) and the Gene Expression Omnibus (GEO) databases, we stratified patients into two different TIME status (“cold” and “hot”) through the K-means clustering method and compared their difference in immune cell infiltrations via the CIBERSORT algorithm (29). Subsequently, Least Absolute Shrinkage and Selection Operator (LASSO) (30) and Support Vector Machine-Recursive Feature Elimination (SVM-RFE) (31) were utilized to identify diagnostic markers from CMGs. Following, a diagnostic signature for stratifying individualized TIME status of TNBC patients was stablished, and its predictive performance was further validated. Moreover, we conducted a small-sample exploratory analysis via the multiplex immunohistochemistry (mIHC) to explore the correlation between the expression level of identified CMGs biomarkers and response to immunotherapy.

## Section: Materials and methods › Data acquisition and preparation

We downloaded the gene expression profile datasets of TNBC patients from TCGA (https://tcga-data.nci.nih.gov/tcga/) and GEO databases (https://www.ncbi.nlm.nih.gov/geo/) (GSE76250 and GSE58812 datasets) using the “GEO query” package (32). All microarray datasets were standardized via the “SVA” and “limma” R packages. TCGA, GSE76250, and GSE58812 datasets consisted of 168, 165, and 107 tumor samples, respectively. A total of 60 CMGs, including 13 members of B7-CD28 family and 47 members of TNF family, were obtained from a previously published study ( Supplementary Table 1 ) (28).

## Section: Materials and methods › Patient-clustering based on CMGs

To investigate the potential value and functions of abovementioned 60 CMGs in the TIME of TNBC, we classified patients into different clusters after the k-means machine learning algorithm, an unsupervised consensus clustering method, using the “Cluster” package. First, we determined the corresponding optimal cluster numbers in three datasets via the “factoextra” package. After k-means clustering, we performed the principal component analysis (PCA) with the “factoextra” package. Next, we utilized the “ESTIMATE” package (33) to calculate and compare the tumor purity, immune, and stromal scores among different clusters in TCGA, GSE76250, and GSE58812 datasets. TNBC patients in three datasets were further stratified into the “hot” and “cold” tumor groups according to their immune and stromal scores.

## Section: Materials and methods › Estimation of the immune cell infiltration landscape in TIME

The standardized gene expression profiles of TNBC patients in TCGA, GSE76250, and GSED58812 datasets were performed by the CIBERSORT algorithm with perm set to 1000 to analyze the characteristics of 22 immune cells infiltration (29) between patients belonging to the “hot” and “cold” tumor groups.

## Section: Materials and methods › Functional annotation and pathway enrichment analyses

Gene set enrichment analysis (GSEA, https://www.gsea-msigdb.org/gsea/index.jsp) was performed for patients in “hot” vs “cold” tumors through the Java GSEA (version4.0.1) and the Kyoto Encyclopedia of Genes and Genomes (KEGG) pathway in C2 and Gene Ontology (GO) terms in C5 to evaluate potential functional pathways and biological mechanisms enriched in patients (34). False discovery rate (FDR) < 0.25 and normalized P < 0.05 were set as cutoffs to obtain significant enrichment.

## Section: Materials and methods › Screening and identification of the diagnostic CMGs biomarkers

In the TCGA and GSE76250, to avoid possible influence of multicollinearity, we firstly conducted the LASSO logistic regression analysis through the “glmnet” package to screen out biomarkers from above all 60 CMGs at the optimal value of log lambda with the smallest classification error (30). Besides, the SVM-RFE machine learning algorithm based on the support vector machine was utilized to identify the most valuable biomarkers from all 60 CMGs by subtracting the feature vector determined using SVM with the “e1071” and “caret” R packages (31). Next, we merged identified CMGs from above-mentioned machine learning algorithms via the “scMerge” package to further narrow the number of markers. These overlapped CMGs markers were finally input for the logistics regression analysis to identify the final diagnostic biomarkers.

## Section: Materials and methods › Conduction and validation of the diagnostic nomogram based on CMGs biomarkers

Based on abovementioned final CMGs biomarkers, a diagnostic signature for individualized TIME status was constructed and visually presented as nomogram via the “rms” R package. Then, we evaluated and validated the predictive accuracy and clinical value of the CMG-based nomogram using the receiver operating characteristic (ROC) curves, calibration curves, and decision curve analysis (DCA) in both training and validation datasets.

## Section: Materials and methods › Tissue multiplex immunohistochemistry

We stained TNBC samples using the multiplex fluorescence immunohistochemical kit, PDOne four-color TSA-RM-275 (20 T) (cat 10001100020 Panovue, Beijing, China) according to the manual provided. Paraffin-embedded samples were sequentially incubated with primary antibodies and horseradish peroxidase (HRP)-conjugated secondary antibodies. Then, we performed the tyrosine signal amplification (TSA) to label antigens, after each TSA labeling step, we removed the primary and secondary antibodies through a microwave treatment for heat-induced antigen retrieval. After the sample was eluted, the next antigen was labeled, and this procedure was repeated for all four antigen markers. Anti-CD86 (E2G8P, dilution 1:200, Rabbit, Cell Signaling Technology, Danvers, MA, USA), TNFRSF17 (ab245940, dilution 1:100, Rabbit, Abcam, Cambridge, UK) and TNFRSF1B (28746–1-AP, dilution 1:200, Proteintech, Rosemont, USA) were utilized as primary antibodies. The dyes Opal520, Opal570, Opal650 and 4′-6′-diamidino-2-phenylindole (DAPI, Sigma-Aldrich) were utilized for staining. We scanned TNBC samples and obtained their fluorescence images at ×20 magnification with a PanoVIEW VS200 slide scanner (Panovue, Beijing, China) and an Olympus 20× lens. Image recognition and analysis were performed with QuPath image analysis software (Version 0.3.0, Queen’s University of Belfast, Northern Ireland, UK). The images were quantized into data by tissue segmentation and cell segmentation using the positive threshold settings and phenotypic recognition. By means of an R script (Version 4.0.1), we assumed the quantitative data and basic data such as the positive cell number, positive staining rate and density for subsequent analysis.

## Section: Materials and methods › Statistical analysis

In current study, the expression levels of CMGs in TNBC patients were presented as raw and standardized data. We conducted this study in two phases. During the first phase, we classified TNBC patients into the “hot” and “cold” tumors according to their immune and stromal scores. During the second phase, TCGA dataset was used as the training cohort, TCGA and the GSE76250 datasets were utilized as internal validation cohorts, and the GSE58812 dataset was as external validation cohort. A diagnostic signature based on identified CMGs biomarkers for predicting individualized TIME subclasses in TNBC was constructed and validated.

All statistical analyses herein were performed using the R software (version 4.0.1, Vanderbilt University, Nashville, TN). The Mann-Whitney U test and Kruskal-Wallis H test were utilized to compare the immune score, stromal score, and tumor purity among different clusters. The unpaired Student’s t test was performed to compare differences in responses to immunotherapy among patients with TNBC. A P-value <0.05 was considered statistically significant unless specified.

## Section: Results

Flowchart of the study design.

TNBC patient-clustering based on costimulatory molecule genes (CMGs). (A) The curve of the total within the sum of squared error curve for the corresponding cluster number k in TCGA dataset; (B) The principal component analysis (PCA) plot of clustered patients in TCGA dataset; (C) The curve of the total within the sum of squared error curve for the corresponding cluster number k in GSE76250 dataset; (D) The PCA plot of clustered patients in GSE76250 dataset; (E) The curve of the total within the sum of squared error curve for the corresponding cluster number k in GSE58812 dataset; (F) The PCA plot of clustered patients in GSE58812 dataset.

Calculation and comparison of tumor-stromal and immune scores between different TIME subclasses in TNBC, where red represents patients in the “hot” tumor and green shows patients in the “cold” tumor. The comparison of stromal scores (A) and immune scores (B) between “hot” (clusters 2 to 5) and “cold” (cluster 1) tumor groups in TCGA dataset; The comparison of stromal scores (C) and immune scores (D) between “hot” (clusters 4 and 5) and “cold” (clusters 1,2,3,6 and 7) tumor groups in GSE76250 dataset; The comparison of stromal scores (E) and immune scores (F) between “hot” (clusters 1 and 2) and “cold” (clusters 3 and 4) tumor groups in GSE58812 dataset.

Evaluation and visualization of 22 immune cell type infiltration landscape between different TIME status. The violin plot depicts infiltration disparities among immune cell types between the “hot” tumor (red) and the “cold” tumor (blue) in TCGA (A), GSE76250 (B), and GSE58812 datasets (C).

Functional analysis for the “hot” tumor and the “cold” tumor based on costimulatory molecule genes (CMGs). (A, C, E) The Kyoto Encyclopedia of Genes and Genomes (KEGG) enrichment analysis in TCGA, GSE76250, and GSE58812 datasets, respectively; (B, D, F) Gene Ontology (GO) analysis for biological processes in TCGA, GSE76250, and GSE58812 datasets, respectively.

The selection of diagnostic biomarkers from candidate costimulatory molecule genes (CMGs). The lower abscissa is the log lambda value, while the upper abscissa is the number of CMGs with non-zero coefficient; the vertical axis represents the Least Absolute Shrinkage and Selection Operator (LASSO) coefficient of CMGs, and each curve shows the variation trajectory of the coefficients of each gene. (A) Determination of the number of CMGs with non-zero coefficients at the optimal value -5.830026 of log lambda in TCGA dataset; (B) LASSO coefficient profiles of 27 candidate CMGs after the 10-fold cross-validation in TCGA dataset; (C) Support Vector Machine-Recursive Feature Elimination (SVM-RFE) method to identify markers in TCGA dataset; (D) Definition of the number of CMGs with non-zero coefficients at the optimal value -3.836916 of log lambda in GSE76250 dataset; (E) LASSO coefficient profiles of 35 candidate CMGs after the 10-fold cross-validation in GSE76250 dataset; (F) SVM-RFE method to identify markers in GSE76250 dataset; (G) Venn diagram presents the overlapping diagnostic markers identified by LASSO and SVM-REF algorithms.

Development and validation of the diagnostic nomogram. (A) A nomogram for diagnosing individualized tumor immune environment subclass. The receiver operating characteristic (ROC) curve of the diagnostic efficacy verification in TCGA (B), GSE76250 (C), and GSE58812 datasets (D); The calibration plots of the diagnostic accuracy validation in three datasets (E–G); The decision curve analysis (DCA) of the clinical value for therapeutic guidance in TCGA (H), GSE76250 (I), and GSE58812 datasets (J).

Expression of CMGs biomarkers are positively related to the efficacy of immunotherapy in TNBC. Representative multiplex immunofluorescence images demonstrating the protein expression of CD86 (blue), TNFRSF1B (red) and TNFRSF17 (purple) in samples from nonresponders (A) and responders (B); (C) Correlation analysis showed that TNFRSF1B, CD86 and TNFRSF17 were significantly associated with the immune response.

## Section: Results › Data extraction and processing

The flow chart for the study design is presented in Figure 1 . All microarray matrixes of three publicly available datasets were annotated, following which, TCGA dataset consisted of 168 TNBC samples (46999 genes), GSE76250 and GSE 58812 datasets included 165 TNBC samples (30906 genes) and 107 TNBC samples (20161 genes), respectively. Next, 60 CMGs were overlapped with TCGA dataset, except for the TNFRSF6B gene due to its low expression, a total of 59 CMGs were identified. Similarly, 60 CMGs were merged with GEO datasets, wherein, only 57 CMGs in the GSE76250 dataset and 58 CMGs in the GSE58812 dataset were eligible. Then, we standardized the expression levels of CMGs in three datasets using the “SVA” and “limma” R packages. Finally, a total of 56 CMGs were used for subsequent analysis.

Flowchart of the study design.

## Section: Results › Patient-clustering based on CMGs

To explore the clinical value and functions of above CMGs in TNBC, an unsupervised consensus clustering analysis was performed to stratify patients. Figures 2A, C, E show the curves of the total within the sum of squared error for the corresponding cluster numbers of k. These suggested that a k value of 5, 7, and 4 were the most optimal in TCGA, GSE76250, and GSE58812 datasets, respectively. The PCA was performed to evaluate the credibility of these cluster numbers, and it demarcated five clusters at k = 5 in TCGA dataset ( Figures 2B ). Similarly, patients were distinguished at k = 7 in the GSE76250 dataset ( Figure 2D ), and k = 4 in the GSE58812 dataset ( Figures 2F ).

Next, we used the “ESTIMATE” R package (33) to estimate the tumor purity, and to calculate the percentages of stromal and immune cells infiltrations in TIME of TNBC patients based on their CMGs expression profiles. It showed that the tumor purity among patient clusters was significantly different for TCGA, GSE76250 and GSE58812 datasets ( Supplementary Figure 1 ). Besides, significant differences among multiple clusters for tumor stroma and immune scores in TCGA ( Supplementary Figures 2A, B ), GSE76250 ( Supplementary Figures 2C, D ), and GSE58812 ( Supplementary 2E, F ) datasets were also observed. Accordingly, we classified the TNBC patients in cluster 1 of TCGA dataset into the “cold” tumor group, while those in clusters 2 to 5 were in the “hot” tumor group. In the GSE76250 dataset, we categorized patients in clusters 4 and 5 as the “hot” tumor group and patients in other clusters formed the “cold” tumor group. In the GSE58812 dataset, TNBC patients in clusters 1 and 2 were divided into the “hot” tumor, while the remaining patients were in the “cold” tumor group.

Next, we used the “ESTIMATE” R package (33) again to calculate and compare the tumor purity, stromal, and immune cells infiltrations between “cold” and “hot” tumors. There were significant differences in the stromal and immune cell types among TCGA ( Figures 3A, B ), GSE76250 ( Figures 3C, D ), and GSE58812 datasets ( Figures 3E, F ). A significantly higher tumor purity in the “cold” tumor relative to the “hot” tumor in TCGA, GSE76250, and GSE58812 datasets ( Supplementary Figure 3 ) was observed.

TNBC patient-clustering based on costimulatory molecule genes (CMGs). (A) The curve of the total within the sum of squared error curve for the corresponding cluster number k in TCGA dataset; (B) The principal component analysis (PCA) plot of clustered patients in TCGA dataset; (C) The curve of the total within the sum of squared error curve for the corresponding cluster number k in GSE76250 dataset; (D) The PCA plot of clustered patients in GSE76250 dataset; (E) The curve of the total within the sum of squared error curve for the corresponding cluster number k in GSE58812 dataset; (F) The PCA plot of clustered patients in GSE58812 dataset.

Calculation and comparison of tumor-stromal and immune scores between different TIME subclasses in TNBC, where red represents patients in the “hot” tumor and green shows patients in the “cold” tumor. The comparison of stromal scores (A) and immune scores (B) between “hot” (clusters 2 to 5) and “cold” (cluster 1) tumor groups in TCGA dataset; The comparison of stromal scores (C) and immune scores (D) between “hot” (clusters 4 and 5) and “cold” (clusters 1,2,3,6 and 7) tumor groups in GSE76250 dataset; The comparison of stromal scores (E) and immune scores (F) between “hot” (clusters 1 and 2) and “cold” (clusters 3 and 4) tumor groups in GSE58812 dataset.

## Section: Results › Estimation of the immune cell infiltration landscape in TIME

The landscape of 22 immune cell type infiltrations in TNBC tissues were estimated based on the gene expression profiles via the CIBERSORT algorithm (29), and we also evaluated the correlation between the immune cells in the TIME of TNBC patients. In TCGA dataset, the distribution of immune cells between “cold” and “hot” tumors were significantly different, including CD8 T cells (P = 0.001), CD4 memory activated T cells (P < 0.001), resting NK cells (P = 0.028), monocytes (P = 0.011), M0 macrophages (P = 0.005), M1 macrophages (P < 0.001), and M2 macrophages (P = 0.001). Among them, the proportion of M0 and M2 macrophages were higher in the “cold” tumor (P < 0.05), while that of others was higher in the “hot” tumor (P < 0.05) ( Figure 4A ). Significant differences in the proportion of immune cells between the “cold” and “hot” tumors were also found in GSE76250 dataset, namely, memory B cells (P < 0.001), CD8 T cells (P < 0.001), resting CD4 memory T cells (P < 0.001), CD4 memory activated T cells (P < 0.001), follicular helper T cells (P = 0.001), regulatory T cells (Tregs) (P < 0.001), activated NK cells (P = 0.028), monocytes (P = 0.011), M0 macrophages (P = 0.017), and M1 macrophages (P < 0.001). Among them, the distributions of memory B cells, resting CD4 memory T cells, CD4 memory activated T cells, and M1 macrophages were higher, while CD8 T cells, follicular helper T cells, Tregs, activated NK cells, monocytes and M0 macrophages were lower in the “hot” tumor (P < 0.05) ( Figure 4B ). In GSE58812 dataset, multiple immune cell types infiltrating the “cold” and “hot” tumors showed significantly different distributions, including the naïve B cells (P < 0.001), CD8 T cells (P < 0.001), CD4 naïve T cells (P < 0.001), resting CD4 memory T cells (P < 0.001), CD4 memory activated T cells (P < 0.001), M0 macrophages (P = 0.003), and M2 macrophages (P = 0.006). Among them, the proportions of naïve B cells, CD8 T cells, CD4 naïve T cells, and CD4 memory-activated T cells were higher in the “hot” tumor (P < 0.05) ( Figure 4C ).

Additionally, the correlation matrix for the 22 immune cells in TNBC tissues was constructed ( Supplementary Figure 4 ). For example, a positive correlation between CD4 memory-activated T cells and M1 macrophages (Cor = 0.37), and CD4 memory-activated T cells and CD8 T cells (Cor = 0.31) was observed in TCGA dataset ( Supplementary Figure 4A ). Likewise, a positive correlation between CD8 T cells and activated NK cells (Cor = 0.66) in GSE76250 dataset ( Supplementary Figure 4B ), a positive correlation between CD4 memory activated T cells and M1 macrophages (Cor = 0.31) in the GSE58812 dataset ( Supplementary Figure 4C ) were observed.

Evaluation and visualization of 22 immune cell type infiltration landscape between different TIME status. The violin plot depicts infiltration disparities among immune cell types between the “hot” tumor (red) and the “cold” tumor (blue) in TCGA (A), GSE76250 (B), and GSE58812 datasets (C).

## Section: Results › Functional annotation and pathway enrichment analyses

We performed GO and KEGG enrichment analyses for the “cold” and “hot” tumors to reveal potential functions and pathways. It demonstrated that “hot” tumor group was enriched in the chemokine signaling pathway, cytokine-cytokine receptor signaling pathway, JAK-STAT signaling pathway, nature killer cell-mediated signaling pathway, B cell receptor, and T cell receptor signaling pathway in TCGA ( Figure 5A ), GSE76250 ( Figure 5C ), and GSE58812 datasets ( Figure 5E ). As for the biological processes (BP), the “hot” tumor was mainly associated with the T cells activation and the regulation of immune responses in all three datasets ( Figures 5B, D, F ).

Functional analysis for the “hot” tumor and the “cold” tumor based on costimulatory molecule genes (CMGs). (A, C, E) The Kyoto Encyclopedia of Genes and Genomes (KEGG) enrichment analysis in TCGA, GSE76250, and GSE58812 datasets, respectively; (B, D, F) Gene Ontology (GO) analysis for biological processes in TCGA, GSE76250, and GSE58812 datasets, respectively.

## Section: Results › Screening and identification of the diagnostic CMGs biomarkers

In TCGA dataset, we performed the LASSO logistic regression analysis and screened out 27 CMGs from 56 candidates, having zero coefficients at the optimal value -5.830026 of log lambda ( Figures 6A, B ). 26 CMGs from 56 candidates were recognized as diagnostic biomarkers based on the result of SVM-RFE algorithm ( Figure 6C ). Diagnostic biomarkers identified using above two algorithms were overlapped and 13 CMGs remained to be biomarkers ( Figure 6G ). Similarly, in GSE76250 dataset, 11 CMGs and 46 CMGs from 56 candidates were identified as putative diagnostic biomarkers via the LASSO (a value -3.836916 of the optimal log lambda) ( Figures 6D, E ) and SVM-RFE ( Figures 6F ) machine learning algorithms. Among these, 11 CMGs were overlapping ( Figure 6G ). Next, we merged candidate CMGs identified from above two datasets and performed the logistic regression analysis to further narrow the number of diagnostic biomarkers, three CMGs (CD86, TNFRSF17, and TNFRSF1B) were determined as final diagnostic biomarkers ( Figure 6G ). All CMGs analyzed in this phase were listed in Supplementary Table 2 .

The selection of diagnostic biomarkers from candidate costimulatory molecule genes (CMGs). The lower abscissa is the log lambda value, while the upper abscissa is the number of CMGs with non-zero coefficient; the vertical axis represents the Least Absolute Shrinkage and Selection Operator (LASSO) coefficient of CMGs, and each curve shows the variation trajectory of the coefficients of each gene. (A) Determination of the number of CMGs with non-zero coefficients at the optimal value -5.830026 of log lambda in TCGA dataset; (B) LASSO coefficient profiles of 27 candidate CMGs after the 10-fold cross-validation in TCGA dataset; (C) Support Vector Machine-Recursive Feature Elimination (SVM-RFE) method to identify markers in TCGA dataset; (D) Definition of the number of CMGs with non-zero coefficients at the optimal value -3.836916 of log lambda in GSE76250 dataset; (E) LASSO coefficient profiles of 35 candidate CMGs after the 10-fold cross-validation in GSE76250 dataset; (F) SVM-RFE method to identify markers in GSE76250 dataset; (G) Venn diagram presents the overlapping diagnostic markers identified by LASSO and SVM-REF algorithms.

## Section: Results › Construction and validation of the diagnostic nomogram based on CMGs

To develop a practical tool for individually predicting TIME subclass in patients with TNBC, we constructed the diagnostic nomogram incorporating above three final CMGs biomarkers, including CD86, TNFRSF17, and TNFRSF1B, based on findings in TCGA ( Figure 7A ). Each biomarker could be scored in points line according to its expression, and after summation, every TNBC patient could have a total score, based on which, the probability of “hot” tumor could be predicted by locating the total score on the probability of the hot tumor scale. For example, TNBC patients with high expression of above three CMGs were more likely to be recognized as “hot” tumor. We further assessed the diagnostic efficiency of this nomogram in three datasets by calculating the area under the ROC curve (AUC), which suggested a satisfactory diagnostic accuracy in TCGA ( Figure 7B ), GSE76250 ( Figure 7C ), and GSE58812 datasets ( Figure 7D ). Moreover, a favorable agreement between actual and predicted probability through the diagnostic nomogram in all three datasets was observed via the calibration curves ( Figures 7E–G ). Additionally, the DCA results demonstrated a good clinical value of this diagnostic nomogram in predicting TIME status ( Figures 7H–J ).

Development and validation of the diagnostic nomogram. (A) A nomogram for diagnosing individualized tumor immune environment subclass. The receiver operating characteristic (ROC) curve of the diagnostic efficacy verification in TCGA (B), GSE76250 (C), and GSE58812 datasets (D); The calibration plots of the diagnostic accuracy validation in three datasets (E–G); The decision curve analysis (DCA) of the clinical value for therapeutic guidance in TCGA (H), GSE76250 (I), and GSE58812 datasets (J).

## Section: Results › Expression of CMGs markers positively related to efficacy of immunotherapy

To further verify the associations between the expression level of these three CMGs biomarkers in tumor tissues of TNBC patients receiving immunotherapy and patients’ response to treatment, we collected 27 patients’ paraffin-embedded samples and performed the mIHC assays. Figures 8A , B showed the representative mIHC images of DAPI and three CMGs biomarkers in tumor tissues of responders and no-responders, i.e., DAPI (blue), CD86 (green), TNFRSF17 (purple) and TNFRSF1B (red). Further statistical analysis demonstrated that there were significant associations between high expression of CMGs biomarkers and patients’ positive response to immunotherapy ( Figure 8C ).

Expression of CMGs biomarkers are positively related to the efficacy of immunotherapy in TNBC. Representative multiplex immunofluorescence images demonstrating the protein expression of CD86 (blue), TNFRSF1B (red) and TNFRSF17 (purple) in samples from nonresponders (A) and responders (B); (C) Correlation analysis showed that TNFRSF1B, CD86 and TNFRSF17 were significantly associated with the immune response.

## Section: Discussion

In recent years, the therapeutic landscape of TNBC patients has broadened owing to the rapid development of immunotherapy, but only a few patients benefit from ICIs treatment unlike the excellent therapeutic responses achieved in other tumors (16). Effective biomarkers for predicting responses to ICIs in TNBC are lacking in the clinical setting (19). Increasing evidence demonstrated that understanding the unique subsets of personalized TIME is meaningful for identifying novel therapeutic targets and guiding immunotherapeutic strategies (21). In current study, we creatively classified TNBC patients into the “hot” and “cold” tumors according to their TIME clusters determined by CMGs. Further, we executed two machine learning algorithms and identified three CMGs (CD86, TNFRSF17, and TNFRSF1B) as diagnostic biomarkers, based on which, a diagnostic nomogram for predicting TIME subclasses in TNBC in TCGA dataset was constructed, which presented satisfactory predictive accuracy and good clinical value in both the training and validation datasets. Moreover, exploratory analysis in a real-world clinic cohort of patients with TNBC via mIHC also revealed an apparently positive association between the expression level of these three CMGs biomarkers with responses to immunotherapy. This suggest that these CMGs biomarkers might be promising tool for TNBC patients’ stratification to immunotherapeutic guidance.

The failure of current immunotherapy targeting CTLA-4 or PD-1 may be caused by intratumor T cell exhaustion (2), therefore increasing interests revolve around costimulatory molecules residing in the TIME in TNBC tumors. The costimulatory molecules mainly include the B7-CD28 family and the TNF family of proteins (24, 25). Their expressions on tumor cell and lymphocyte surfaces play important roles in regulating the anti-tumor immune responses (22). The immune surveillance function of the immune system in the human body helps to distinguish malignant from normal cells and initiates subsequent attacks. During this process, the naïve T cells should be activated through two indispensable signals, one of which is the costimulatory signal (35), so the activation of T cells could be blocked without costimulatory signals (28). Generally, malignant cells deliver incorrect messages to T cells and prevent the recognition of costimulatory signals by altering their structures and expressions in TIME, and further inducing an immunosuppressive TIME, thereby helping tumor cells to evade immune-induced elimination (36). A single-cell RNA profile analysis of B cells in breast cancer showed that tumors elicited immune-suppressive B cells owing to their failure in extracting costimulatory signals from them, which facilitated further breast tumor cell evasion of immune surveillance (37). ICIs, by blocking the PD1-PD-L1 and the CD86/CTLA4 axes, prevent tumor cells from releasing wrong messages to T cells, thereby restoring tumor-induced immuno-deficiency in TIME (38). While except for common realized PD1/PD-L1 and CD86/CTLA4 axes, many costimulatory members are still poorly understood. To explore the clinical value of costimulatory molecules in TNBC, we obtained 56 CMGs from public databases in this study. Utilizing the unsupervised consensus clustering algorithm, we clustered patients into two different TIME subclasses, namely the “cold” tumor and the “hot” tumor. TIME, composed of several immune cells, carcinoma-associated fibroblasts, stromal cells, and tumor endothelial stromal cells, plays a crucial role in multiple biological processes, including tumor initiation, angiogenesis, and immune regulation (21, 22). Classifying the immune contexts within a TIME represents the first level of cognizing immunological composition and status (activated or suppressed), their influence on survival outcomes and responses possibilities to anti-tumor treatment. Moreover, TIME classifications might also promote to understand its principle of affecting the establishment and maintenance of specific immunological compositions (21).

Tumors were generally classified as “cold” with immune deficiency if their TIME population included immune cells but lacked activation, which could promote metastasis and disease progression as adaptive immunity could not recognize extrinsic antigens or malignancies (39). Whereas, a high expression of activation biomarkers, such as PD-L1, on activated immune cells or tumor cells within a tumor, are the key characteristics of an immunological “hot” tumor, which is likely to initiate anti-tumor immune responses to attack tumors (21). Herein, we simultaneously examined the immune cells infiltrations in the “hot” and “cold” tumors to elucidate the differences in their TIME. The findings demonstrated that immunosuppressive cells, such as M0 and M2 macrophages, had significant infiltration in the “cold” tumor. Typically, M1 macrophages secret cytokines to activate T cells and exert antitumoral effects, while M2 macrophages are pro-tumorigenic factors via angiogenesis and the chemotaxis of Tregs (40). Therefore, the presence of poor immunogenic TIME in patients with “cold” tumors was reasonably speculated. The “hot” tumor exhibited significantly higher infiltrations of various activated immune cells, including CD4 memory activated T cells, resting NK cells, M1 macrophages, and CD8 T cells, which demonstrated that TNBC patients with “hot” tumors had an immuno-active TIME. Similarly, our functional enrichment analysis presented that B cell and T cell receptor-signaling pathways were significantly enriched in “hot” tumors. Significant associations with the activation of T cells and the regulation of immune responses were found in “hot” tumors. Complex interactions between immunosuppressive cells cooperate to suppress the anti-tumor immune responses and promote disease progression. Hence, our findings might provide a reference for guiding combinatorial immunotherapy strategies. For example, a patient with “hot” TNBC tumors might respond to a single ICI, resulting in the intensification of the preexisting anti-tumor benefits and further prolonging survival. However, in TNBC patients with “cold” tumors, a single-agent ICI might not be sufficient. Thus, radiotherapy, chemotherapy, or novel therapeutic strategies, such as inducible T cells co-stimulator (ICOS) agonist, NCT03829501, transforming growth factor-beta (TGF-β) inhibitor, NCT04429542, along with ICIs might unleash the silent anti-tumor immunity and further generate promising clinical prognosis by transforming the “cold” tumor into a “hot” tumor (2, 16, 41).

Different predictive models focus on the TIME and immune landscape for TNBC clinical prognosis and therapeutic sensitivity, but most of them only emphasized clusters and characteristics of intratumoral immunes cells, mRNA panels, and/or protein signatures, and their clinical applications remain to be clarified (42–45). Given the current unsatisfactory immunotherapeutic benefits in patients with TNBC, patient selection using reliable biomarkers for predicting responses is necessary (2). PD-L1, TILs, and TMB are commonly used to guide treatment, but they were subjected to inconsistent results and low predictive accuracy in different clinical trials (16, 18–20). Herein, we highlighted the comprehensive landscape and diagnostic value of CMGs, for the exploration of novel biomarkers. Moreover, traditional prognostic signatures were established through an individual-based model, which required the recognition of survival event information a priory, i.e., it was “supervised”. In current study, we executed the unsupervised consensus clustering algorithm based on expression profiles of CMGs to evaluate the characteristic subclasses of TIME, which could maximize the homogeneity of immune composition within the same cluster and the heterogeneity among different clusters (46). In addition, we identified candidate CMGs rigorously by integrating LASSO regression analysis with the SVM-RFE machine learning algorithm to reinforce the statistical power of the results.

Subsequently, we identified three CMGs (CD86, TNFRSF17, and TNFRSF1B) as diagnostic markers by numerous bioinformatics. CD86, also termed as B70 (B7–2), exerts a suppressive role through CTLA-4 on T cells activation. Thus, its competitive stimulation signal by binding to CD28 is crucial in immune responses, survival of T lymphocytes, and generation of cytokines (47). In the stimulatory status, CD86 can up-regulate its expression via antigen-presenting cells (APCs), and further combine with CD28 delivering stimulation signals to promote anti-tumor immune and enhance activating T cells (48, 49). TNFRSF17, a transmembrane glycoprotein, also known as B cell maturation antigen, is preferentially expressed by mature B lymphocytes and critically regulate B cell proliferation and survival, as well as maturation and differentiation into plasma cells. Previous studies indicated that TNFRSF17 has a dispensable role in overall B cells homeostasis and is an important surface protein supporting the survival of multiple myeloma cells (50, 51). Preclinical models found that the overexpression and activation of TNFRSF17 was associated with multiple myeloma, supporting its potential utility as a therapeutic target. And significant clinical responses in patients with refractory multiple myeloma who failed at least three prior treatments had been achieved by the anti-TNFRSF17 antibody-drug conjugate (52). TNFRSF1B or TNFR2, a member of the TNF receptor superfamily, is expressed by T cells, deliver activating signals, which are largely dependent on antigen recognition and participate in activation, clonal expansion, and differentiation of T cells. Accumulating evidence in recent years indicates that costimulatory signals via TNFR2 plays indispensable roles in protective immunity, inflammatory, autoimmune diseases, and tumor immunotherapy (53).

Based on above three diagnostic markers, we developed a diagnostic nomogram for TNBC patients, which showed that patients with high expressions of CD86, TNFRSF17, and TNFRSF1B had a high probability of “hot” tumor. Besides, satisfactory predictive performance of this nomogram was validated in three independent datasets, including the TCGA, GSE76250, and GSE58812. The “hot” TNBC tumors were mainly related to the BPs of T cell activation and immune response regulation, which implied that patients with “hot” tumors might likely respond to immunotherapy. In consistent with above presumption, the mIHC results showed that responders to immunotherapy were significantly associated with high expressions of CD86, TNFRSF17 and TNFRSF1B in TNBC patients. Hence, our diagnostic nomogram has the potential to aid identifying ideal TNBC patients who may benefit from ICIs, thereby providing immunotherapeutic guidance.

There were some limitations in this study. First, although we included three different independent datasets in current study, it is a retrospective analysis and all data were obtained from public databases, so practical bias might be unavoidable. Second, the underlying mechanism of these three diagnostic markers (TNFRSF17, CD86 and TNFRSF1B) remain poorly understood. Third, we performed this research by means of bioinformatics, further experimental validation of their predictive ability and clinical value are needed in future. Finally, although we constructed our diagnostic model based on CMGs from TCGA data consisting of samples from the United States and validated it using GEO datasets comprising of populations from France and China, prospective studies in different populations are warranted to further validate these results.

## Section: Conclusions

In summary, we comprehensively parse the expression patterns and clinical value of costimulatory molecules in TNBC patients and further clustered patients into two TIME subclasses (“hot” and “cold”) for patients’ stratification. In addition, we identified three CMGs (CD86, TNFRSF17 and TNFRSF1B) as putative diagnostic markers, based on which, a novel diagnostic nomogram for predicting TIME status were constructed and validated with good predictive accuracy and clinical value. This may provide a new insight into the value of CMGs in stratifying TIME status of patients with TNBC, which might serve as a tool to identify ideal candidates and tailor rational immunotherapeutic strategies for TNBC patients.

## Section: Data availability statement

The datasets presented in this study can be found in online repositories. The names of the repository/repositories and accession number(s) can be found in the article/ Supplementary Material .

## Section: Ethics statement

The studies involving humans were approved by the Ethics Committee of Sun Yat-Sen University Cancer Center. The studies were conducted in accordance with the local legislation and institutional requirements. The ethics committee/institutional review board waived the requirement of written informed consent for participation from the participants or the participants’ legal guardians/next of kin because Written informed consent from all participants was waived due to its retrospective nature.

## Section: Author contributions

CZ: Writing – review & editing, Writing – original draft, Formal analysis, Data curation. WZ: Methodology, Writing – review & editing, Writing – original draft, Formal analysis. YM: Data curation, Writing – review & editing, Writing – original draft. MW: Writing – review & editing, Data curation. QC: Writing – review & editing, Data curation. JH: Project administration, Funding acquisition, Writing – review & editing. ZZ: Writing – original draft, Conceptualization, Writing – review & editing, Project administration. FD: Methodology, Formal analysis, Data curation, Writing – review & editing, Writing – original draft, Conceptualization.

## Section: Acknowledgments

Thanks to all researchers who participated in this work.

## Section: Funding Statement

The author(s) declare financial support was received for the research, authorship, and/or publication of this article. This study was supported by the cultivation foundation for the junior teachers in Sun Yat-sen University (No.20ykpy164).

## Section: Conflict of interest

The authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.

## Section: Publisher’s note

All claims expressed in this article are solely those of the authors and do not necessarily represent those of their affiliated organizations, or those of the publisher, the editors and the reviewers. Any product that may be evaluated in this article, or claim that may be made by its manufacturer, is not guaranteed or endorsed by the publisher.

## Section: Supplementary material

The Supplementary Material for this article can be found online at: https://www.frontiersin.org/articles/10.3389/fimmu.2024.1424259/full#supplementary-material

Comparison of tumor purity among different TNBC patient clusters. The comparison of tumor purity in TCGA (A); GSE76250 (B); and GSE58812 datasets (C).

Comparison of tumor-stromal and immune scores among different TNBC patient clusters. The comparison of stromal scores (A) and immune scores (B) among different clusters in TCGA dataset; The comparison of stromal scores (C) and immune scores (D) among different clusters in GSE76250 dataset; The comparison of stromal scores (E) and immune scores (F) among different clusters in GSE58812 dataset.

Comparison of tumor purity between different immune environment subclasses. Significant differences in tumor purity between the “cold” and the “hot” tumor groups in TCGA (A); GSE76250 (B); and GSE58812 datasets (C).

The correlation heat map shows the correlation of 22 immune cells between two TIME subclasses in TCGA (A), GSE76250 (B), and GSE58812 datasets (C). The number within colored squares represents the strength of the correlation; the larger is the number, the stronger is the correlation. Blue represents a negative correlation and red represents a positive correlation.

## Section: Associated Data

Comparison of tumor purity among different TNBC patient clusters. The comparison of tumor purity in TCGA (A); GSE76250 (B); and GSE58812 datasets (C).

Comparison of tumor-stromal and immune scores among different TNBC patient clusters. The comparison of stromal scores (A) and immune scores (B) among different clusters in TCGA dataset; The comparison of stromal scores (C) and immune scores (D) among different clusters in GSE76250 dataset; The comparison of stromal scores (E) and immune scores (F) among different clusters in GSE58812 dataset.

Comparison of tumor purity between different immune environment subclasses. Significant differences in tumor purity between the “cold” and the “hot” tumor groups in TCGA (A); GSE76250 (B); and GSE58812 datasets (C).

The correlation heat map shows the correlation of 22 immune cells between two TIME subclasses in TCGA (A), GSE76250 (B), and GSE58812 datasets (C). The number within colored squares represents the strength of the correlation; the larger is the number, the stronger is the correlation. Blue represents a negative correlation and red represents a positive correlation.

## Section: Associated Data › Supplementary Materials

Comparison of tumor purity among different TNBC patient clusters. The comparison of tumor purity in TCGA (A); GSE76250 (B); and GSE58812 datasets (C).

Comparison of tumor-stromal and immune scores among different TNBC patient clusters. The comparison of stromal scores (A) and immune scores (B) among different clusters in TCGA dataset; The comparison of stromal scores (C) and immune scores (D) among different clusters in GSE76250 dataset; The comparison of stromal scores (E) and immune scores (F) among different clusters in GSE58812 dataset.

Comparison of tumor purity between different immune environment subclasses. Significant differences in tumor purity between the “cold” and the “hot” tumor groups in TCGA (A); GSE76250 (B); and GSE58812 datasets (C).

The correlation heat map shows the correlation of 22 immune cells between two TIME subclasses in TCGA (A), GSE76250 (B), and GSE58812 datasets (C). The number within colored squares represents the strength of the correlation; the larger is the number, the stronger is the correlation. Blue represents a negative correlation and red represents a positive correlation.

## Section: Associated Data › Data Availability Statement

The datasets presented in this study can be found in online repositories. The names of the repository/repositories and accession number(s) can be found in the article/ Supplementary Material .


---

# Integrating Traditional Machine Learning and Deep Learning for Precision Screening of Anticancer Peptides: A Novel Approach for Efficient Drug Discovery

- **Authors:** Meiqi Xu, Jiefu Pang, Yangyang Ye, Ziyi Zhang
- **Issuer:** ACS omega
- **Type:** Scientific article
- **Published:** 2024-04-01
- **Language:** en
- **DOI:** 10.1021/acsomega.4c01374
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38617603/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractThe rapid and effective identification of anticancer peptides (ACPs) by computer technology provides a new perspective for cancer treatment. In the identification process of ACPs, accurate sequence encoding and effective classification models are crucial for predicting their biological activity. Traditional machine learning methods have been widely applied in sequence analysis, but deep learning provides a new approach to capture sequence complexity. In this study, a two-stage ACPs classification model was innovatively proposed. Three novel coding strategies were explored; two mainstream Natural Language Processing (NLP) models and 11 machine learning models were fused to identify ACPs, which significantly improved the prediction accuracy of ACPs. We analyzed the correlation between peptide chain amino acids and evaluated the relevant performance of the model by the ROC curve and t-SNE dimensionality reduction technique. The results indicated that the deep learning and machine learning fusion models of M3E-base and KNeighborsDist models, especially when considering the semantic information on amino acid sequences, achieved the highest average accuracy (AvgAcc) of 0.939, with an AUC value as high as 0.97. Then, in vitro cell experiments were used to verify that the two ACPs predicted by the model had antitumor efficacy. This study provides a convenient and effective method for screening ACPs. With further optimization and testing, these strategies have the potential to play an important role in drug discovery and design.

## Section: Introduction

Cancer is a significant global public health issue, with a rapid increase in cancer incidence and mortality rates worldwide.1,2 It is estimated that by 2025, the annual number of new cancer cases globally will exceed 20 million.3 Common cancer treatment modalities include surgery, chemotherapy, and radiotherapy.4 Among these, chemotherapy is one of the primary approaches to cancer treatment. However, the major challenge faced by traditional chemotherapy is the lack of specificity of chemotherapeutic drugs, making it difficult to target tumor sites for localized treatment. This leads to collateral damage to healthy tissues and a range of complications, often necessitating discontinuation of treatment. Therefore, there is a pressing need for breakthroughs in cancer drug therapy.

Anticancer peptides (ACPs) represent a class of peptides with anticancer activity and are found in various organisms, including mammals, plants, birds, amphibians, fish, insects, and microorganisms.5 Compared to traditional chemotherapy drugs, proteins, monoclonal antibodies and other agents, ACPs possess several distinctive characteristics, such as high specificity, ease of synthesis and modification, strong tumor penetration capabilities and diverse administration methods.6 As an emerging anticancer therapy, ACPs have received widespread attention in recent years. In terms of clinical applications, although ACPs are still in the early stages of development, a small number of peptide drugs have successfully entered clinical trials, demonstrating their potential in treating specific cancers. With the in-depth research on ACPs and the advancement of related technologies, we have reason to believe that ACPs will play an increasingly important role in future cancer treatment and bring new hope to cancer patients.

Ideally, anticancer peptides can selectively target cancer cells without harming normal tissue cells, inducing cancer cell death by altering cell membrane permeability, or interacting with intrinsic targets within cancer cells. The mechanisms of action of ACPs from different sources and their modified peptides have become a recent focus of research in anticancer drug development.7−9 Some ACP-based drugs have already entered clinical trials or been approved for use.10 Therefore, the rapid identification of potential ACPs holds significant importance for the development of cancer treatments. However, traditional methods of identifying ACPs through wet laboratory experiments are relatively costly and time-consuming. Computational techniques in the field of bioinformatics provide a solution to the rapid and accurate identification of ACPs. Among various computational methods, machine learning has emerged as a promising approach to efficiently identifying ACPs.

Traditional machine learning methods for ACP identification involve manually designing features for classifying protein sequences, followed by the use of classification models such as Support Vector Machines (SVM), Random Forest (RF), K-Nearest Neighbors (KNN), Extra Trees and Gradient Boosting Trees.11−14 However, relying solely on handcrafted features may not fully capture the complexity and diversity of data features.15,16 Deep learning methods, known for their ability to efficiently handle unstructured data, have increasingly been applied in ACP identification.17 Yi et al. introduced a deep learning Long Short-Term Memory (LSTM) neural network model, ACP-DL, which automatically learned how to identify anticancer peptides and nonanticancer peptides by integrating binary profile features and a simplified amino acid alphabet sparse matrix.18 However, this method still fundamentally used handcrafted features as inputs, limiting the neural network’s ability to acquire raw information. Yang et al. proposed the CACPP model, which employed a convolutional neural network (CNN) to extract high-potential features from peptide sequences and a contrastive learning module to learn more distinguishable feature representations in a deep learning framework.19 However, due to the restricted receptive field of the CNN network, it was challenging to capture the interactions between amino acids that are distant from each other in long peptide chains. Sun et al. proposed an ACP-BC model, which uses a bidirectional long short-term memory network (BiLSTM) to extract features from the original sequence and obtains deep abstract features through a bidirectional encoder representation converter (BERT), achieving an accuracy of 87%.20 However, handcrafted features also limited the neural network’s ability to acquire raw information, and using chemical formulas as inputs for the BERT network made it prone to truncation when peptide chains were too long. Currently, it appears that neural networks commonly used in computer vision, such as CNNs, and sequence-based neural networks, such as LSTMs, are more prevalent in ACP identification models. However, we believe that models related to Natural Language Processing (NLP) are more suitable for ACP screening.

In this study, we employed four different feature representation and encoding methods, and trained and compared various deep learning and machine learning models to screen peptide sequences with anticancer potential. First, we performed bigram processing on amino acid sequences to generate overlapping matrices and conducted relevant statistical analysis and t-SNE dimensionality reduction visualization. This aided in exploring the co-occurrence relationships and correlations between amino acids, providing support for the design and prediction of peptide sequences with anticancer potential. In the feature engineering phase, we utilized three encoding methods: (1) encoding considering only the amino acid letter information, (2) encoding considering both amino acid letter information and amino acid position information, and (3) encoding the amino acid sequence as if it were a sentence. In the third encoding method, we used two different NLP sequence representations, with or without splitting amino acids, and performed transfer training using two NLP models, BERT and M3E. We employed a greedy soup strategy to enhance network generalization and trained various machine learning models on top of deep learning. The results for each method included peptide sequence classification as well as performance evaluation using tools such as ROC curves and t-SNE dimensionality reduction plots. We identified the model combination of the m3e-base and KNeighborsDist with the highest average accuracy (ValACC and TestACC) of 93.85%. Using this model, we screened peptide sequences effectively validated by both the original NLP model and the comprehensive model, followed by synthesis and in vitro antitumor efficacy validation. The results indicated that the peptides validated by the model demonstrated significant anticancer cell cytotoxicity. Overall, our innovative approach combining NLP language models and machine learning models for ACP screening achieved high accuracy and ease of implementation compared with traditional screening methods. Through in vitro experiments, we confirmed that the peptides selected by our model possess effective anticancer activity, which could aid researchers in discovering more potential ACPs and promoting the development of ACP-based drugs. The workflow of this study was illustrated in Figure 1.

Workflow of this study.

## Section: Materials and Methods › Data Collection

The data for this study were collected from various publicly available anticancer peptide databases, including APD3 (https://aps.unmc.edu/database/anti), BioPepDB (http://bis.zju.edu.cn/biopepdbr/index.php?p=search&field=category&query=anticancer), DPL (http://www.peptide-ligand.cn/search/?csrfmiddlewaretoken=PSqYxvTcUbmCHIAOCjLDJa0tzZky9MoQ6YR9NrAVsHHqeUB6uBkdMNyrmIJ1o2Zf&q0=&q1=&q2=&q4=Anticancer+&q3=&q5=&submit=Search), PlantPepDB (http://14.139.61.8/PlantPepDB/pages/browse_result.php), and FeptideDB (http://www4g.biotec.or.th/FeptideDB/peptide_search.php). These diverse databases provided comprehensive data support by offering a wide range of anticancer peptide sequence information. To ensure data integrity, duplicate peptides within individual databases and between databases were removed, and the anticancer activity of each peptide was rigorously validated. The integrated database consists of 859 anticancer peptides. Additionally, to balance the data set, an equal number of random peptides were generated using a randomization process to serve as control samples for training and testing.

## Section: Materials and Methods › Data Preprocessing

Data preprocessing played a critical role in this study to ensure the quality and suitability of the amino acid sequence data. Strategies employed included identifying inconsistent or unexpected format data within sequences and correcting or removing them to ensure data set consistency and reliability. Furthermore, techniques such as imputation, deletion, or interpolation were applied to address missing values or blank data, ensuring data completeness and usability. In addition, noise data were also processed during data cleaning using filtering or other denoising methods to reduce random interference in the data, ensuring the stability and reliability of subsequent analyses.

After data cleaning, the Bigram method for processing amino acid sequences was a key step in this study.21 By applying Bigram processing to amino acid sequences, we generated an overlapping matrix. This matrix recorded the pairwise occurrences of amino acids in the sequences and, through statistical analysis methods, explored co-occurrence relationships and correlations between amino acids. Through the analysis of these relationships, we identified potential patterns and feature sequences with anticancer potential.

## Section: Materials and Methods › Peptide Sequence Feature Extraction and Representation

In this study, the feature extraction methods covered three novel encoding methods aiming to better capture the features of amino acid sequences. First, the first method considered only the encoding of the amino acid letters themselves, mapping different amino acids to specific symbols or numbers. Second, the second method comprehensively considered the letter and position information on amino acids for a more comprehensive representation of amino acid sequence features. Lastly, the third method viewed amino acid sequences as natural language texts, employing two different NLP sequence representation methods: one split the amino acid sequence into individual amino acids as words and the other treated the entire amino acid sequence as a sentence. Both methods used models from NLP (e.g., BERT and M3E) to represent amino acid sequences in vectorized form, facilitating understanding and processing by deep learning models.

## Section: Materials and Methods › Screening Model Construction › Construction of Screening Models Based on Machine Learning

In this study, for screening anticancer peptides, the research team chose a variety of machine learning algorithms for comparative analysis. These algorithms included LightGBMLarge, LightGBMXT, XGBoost, LightGBM, CatBoost, KNeighborsDist, KNeighborsUnif, RandomForestEntr, RandomForestGini, ExtraTreesEntr and ExtraTreesGini.

For model training and optimization, exhaustive parameter adjustments and optimizations were conducted for the machine learning models. For gradient boosting tree models such as LightGBM, XGBoost, and CatBoost, key parameters such as learning rate, tree depth, and number of leaf nodes were adjusted to improve model generalization and predictive performance. In KNN models, parameters such as the number of neighbors and distance measurement methods were adjusted. For ensemble learning methods such as Random Forests and Extra Trees, parameters such as the number of trees and maximum number of features were optimized to achieve the best model effect. During the training process, methods such as grid search were used to further enhance model stability and performance.

## Section: Materials and Methods › Screening Model Construction › Construction of Screening Models Based on Deep Learning

Specifically, two main deep learning models, BERT (Bidirectional Encoder Representations from Transformers) and M3E (Multiscale 3D Epitope Prediction), were chosen and explored in this study. BERT, a milestone in the NLP field with a Transformer structure, excels in capturing sequence features and context. M3E, a multitask model, has been enhanced for text classification tasks, allowing it to process multiscale features between sequences, which is advantageous for protein function prediction.

Moreover, in addition to the deep learning models, machine learning models were also incorporated to enhance the model performance. Specifically, comparative experiments were conducted in the BERT and M3E models, including using only NLP models and combining them with various machine learning models. These machine learning models include the ones listed above, such as LightGBMLarge, XGBoost, KNeighbors, etc., used to further enhance predictive performance on top of deep learning models.

During the model training and optimization process, this study conducted exhaustive tuning for different deep learning models and strategies. For BERT and M3E models, key hyperparameters such as learning rate, number of layers, and number of hidden units were adjusted, and techniques like pretraining and fine-tuning were used to improve model performance. In the model combination stage, parameters of different machine learning models were adjusted, and optimization methods such as grid search were used. Throughout the training process, appropriate loss functions and evaluation metrics were used to obtain more robust models with stronger generalization capabilities.

## Section: Materials and Methods › Experimental Design

In the experimental design of this study, a strict validation and test data set division approach was adopted (60% of the data for training, 20% for validation and tuning model parameters, and the final 20% for the ultimate model testing and evaluation). For the optimization of model parameters, methods like grid search were used to determine the best combination of hyperparameters, thereby enhancing the model’s generalizability. Regarding computational equipment and configuration, the experiment utilized high-performance computing servers equipped with high-memory GPUs (NVIDIA GeForce RTX 2070 graphics cards) to accelerate the model training and optimization process. The experimental environment was based on the Python programming language, employing relevant deep learning frameworks (such as PyTorch) and machine learning libraries (such as Scikit-learn), ensuring stability and efficiency of the experimental platform.

## Section: Materials and Methods › Model Evaluation

In the model evaluation process of this study, the performance metrics used covered multiple aspects, including Accuracy, Recall, Precision, F1 Score, and Area Under the Curve (AUC). These metrics were capable of comprehensively assessing the model’s performance in various aspects.

Accuracy intuitively reflects the overall predictive accuracy of the model, that is, the proportion of correctly predicted samples, and is a key indicator of the model’s basic performance. Recall measures the proportion of anticancer peptides identified by the model out of the total actual anticancer peptides, focusing on the model’s coverage capability. Precision assesses the proportion of samples correctly identified as anticancer peptides by the model out of the total samples predicted as anticancer peptides, reflecting the model’s accuracy. The F1 Score, which is the harmonic mean of precision and recall, provides an evaluation of comprehensive performance, particularly suitable for imbalanced data sets. Lastly, the AUC value measures the model’s overall performance at different thresholds, serving as an important indicator of the model’s predictive capacity. Together, these evaluation metrics enable us to understand and assess the model’s performance from multiple dimensions comprehensively, ensuring the model’s effectiveness and reliability in practical applications.

## Section: Materials and Methods › In Vitro Antitumor Efficacy of Synthetic Peptides

The model with the best effect was selected to predict two peptides with a high antitumor efficacy for synthesis. The two peptide sequences were purchased from Jill Biochemical Co., Ltd. (Shanghai, China) and synthesized by the synthesis method of fluorenylmethyloxy carbonyl chloride protective amino acids. The purity of the synthetic peptide was detected by high-performance liquid chromatography (HPLC) to be more than 95%. The in vitro cytotoxicity of peptides was evaluated in 4T1 cells (mouse breast cancer cells) using the sulfonyl rhodamine B (SRB) assay (Sigma-Aldrich, St. Louis, MO, USA).22,23 4T1 cells (6 × 103 cells/well) were seeded in 96-well plates, incubated for 24 h, and then treated with peptides at 37 °C for 24 h. The cell viability was determined using SRB, which allowed quantification of the living cells by measuring absorbance at 540 nm with a 96-well plate reader (model 680; Bio-Rad Laboratories Inc., Hercules, CA, USA). The half-maximal inhibitory concentration (IC50) was calculated according to the dose–effect curves using GraphPad Prism 8 software.

## Section: Results

Overlapping matrix visualization.

Visual analysis of encoding based on amino acid letters only. (a) ROC curves and AUC values. ROC: receiver operating characteristic; AUC: area under the ROC curve. (b) T-SNE dimensionality reduction diagram.

Visual analysis of encoding considering both amino acid letter and position information. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

Visual analysis of deep learning models. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

Visual analysis of fusion models of deep learning and machine learning. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

ROC curves and AUC values of the highest AvgAcc models and comparisons with other ACP predictors.

## Section: Results › Distribution Statistics Display

The activity of ACPs is influenced by the composition of amino acids and their structure. Previous studies mostly considered the frequency of individual amino acids in ACPs.24 However, we believed that the co-occurrence relationships and correlations between amino acids are more meaningful in the search for and exploration of peptides with anticancer activity. Therefore, we processed the amino acid sequences through bigram processing, generated overlapping matrices, and conducted a statistical analysis of the results.

As shown in the context matrix plot (Figure 2), lysine (Lys, K), alanine (Ala, A), and leucine (Leu, L) had the highest frequency in ACPs. This may be attributed to the positively charged nature of these amino acids or their hydrophobic properties. When ACPs interact with cancer cell membranes, the positively charged hydrophilic regions effectively bind to the negatively charged surface of cancer cell membranes through electrostatic adsorption. Simultaneously, the hydrophobic regions bind to the membrane lipids. This laid the foundation for the selective action of ACPs on cancer cells, and the results were consistent with the findings reported in the literature.25 It was noteworthy that the top three amino acid pairs in terms of occurrence frequency are K-K, A-K, and K-L, with frequencies of 617, 485, and 457, respectively (Table 1). Identifying amino acid pairs with higher occurrence frequencies was more helpful in designing amino acid sequences with anticancer activity based on contextual relationships, which could not be achieved by only counting individual amino acids.

Overlapping matrix visualization.

## Section: Results › Machine Learning Model Performance Evaluation Results

Visual analysis of encoding based on amino acid letters only. (a) ROC curves and AUC values. ROC: receiver operating characteristic; AUC: area under the ROC curve. (b) T-SNE dimensionality reduction diagram.

Visual analysis of encoding considering both amino acid letter and position information. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

## Section: Results › Machine Learning Model Performance Evaluation Results › Results of Encoding Based on Amino Acid Letters Only

We first explored the impact of encoding based on amino acid letters on the performance of machine learning models. This encoding strategy maps different amino acids to a set of unique symbols or numbers, serving as the basis for training and predicting machine learning models. To comprehensively assess the effectiveness of this encoding method, we employed a series of advanced machine learning algorithms, including but not limited to LightGBMLarge, XGBoost, CatBoost, etc. Each algorithm was evaluated on multiple dimensions including precision (Pre), recall (Rec), F1 score, and accuracy (ACC). The specific results are shown in Table 2. In the comparative analysis, we observed that the XGBoost model achieved a high score of 0.873 in average ACC, and its precision, recall, and F1 scores were also impressive at 0.909, 0.851, and 0.879, respectively. Furthermore, by conducting ROC curve analysis for the top 6 models ranked by ACC (Figure 3a), both XGBoost and LightGBMLarge models demonstrated outstanding performance with AUC values reaching 0.93, highlighting their excellence in classification tasks.

We further performed visual analysis of features using the t-SNE dimensionality reduction technique. Despite the simplicity and intuitiveness of this encoding method, the results in Figure 3b revealed a challenge. There seemed to be a difficulty in distinguishing between ACPs and non-ACPs using features extracted by this encoding method. This might be attributed to the fact that this encoding strategy overlooks spatial positions and contextual information in amino acid sequences, which often play crucial roles in biological sequence analysis.

Visual analysis of encoding based on amino acid letters only. (a) ROC curves and AUC values. ROC: receiver operating characteristic; AUC: area under the ROC curve. (b) T-SNE dimensionality reduction diagram.

## Section: Results › Machine Learning Model Performance Evaluation Results › Results of Encoding Considering Both Amino Acid Letter and Position Information

Next, we delved into a more complex encoding strategy that not only included the letter information on amino acids but also integrated their positional information in the sequence to achieve a comprehensive representation of amino acid sequence features. By introducing positional information, we aimed to capture the spatial structural characteristics of amino acid sequences, thereby enhancing the model’s classification ability for ACPs and non-ACPs. As shown in Table 3, we evaluated various machine learning models, including but not limited to XGBoost, LightGBM, etc. The results indicated that when positional information is introduced, the top-performing models remained comparable to the first encoding method across all metrics. XGBoost and LightGBMLarge models continued to exhibit the best performance. Furthermore, we conducted a comparative analysis of model performance through ROC curves (Figure 4a), and the results corroborated the numerical indicators in the table, demonstrating that the overall performance of the models was maintained.

To further analyze the impact of encoding on classification performance, we applied the t-SNE technique for dimensionality reduction and visualized the model’s classification results (Figure 4b). Despite the introduction of positional information, there was an improvement in the separation of the models in distinguishing ACPs from non-ACPs. However, the results suggested that this improvement was not significant, and the models still faced challenges in clearly distinguishing between the two sequence classes. This might indicate that simply adding positional information had limitations in enhancing the model’s ability to recognize ACPs, or it might suggest the need for further optimization of feature expression and model structure to fully leverage positional information. In conclusion, while the second encoding method provided a more complex and comprehensive feature representation by considering both amino acid letters and positional information, its practical application did not significantly improve model performance.

Visual analysis of encoding considering both amino acid letter and position information. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

## Section: Results › Deep Learning Model Performance Evaluation Results

Visual analysis of deep learning models. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

Visual analysis of fusion models of deep learning and machine learning. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

ROC curves and AUC values of the highest AvgAcc models and comparisons with other ACP predictors.

## Section: Results › Deep Learning Model Performance Evaluation Results › Results without Adding Machine Learning Models

In an effort to improve the results of traditional machine learning models, we experimented with two NLP deep learning models—BERT and M3E. Simultaneously, we employed a third encoding method that treats amino acid sequences as natural language text and utilized two different NLP sequence representation approaches: one treating the entire amino acid sequence as a single sentence and the other splitting the amino acid sequence into individual amino acids as words. This was done to vectorize the amino acid sequences for understanding and processing by deep learning models. As shown in Table 4, in the first NLP sequence representation method (treating the entire amino acid sequence as a single sentence), the BERT model performed better with test set ACC, Pre, Rec, and F1 scores of 0.904, 0.961, 0.851, and 0.903, respectively. The average ACC for the test and validation sets was 0.904. In the second NLP sequence representation method (splitting the amino acid sequence into individual amino acids as words), the M3E model showed superior performance, surpassing the optimal results of the first representation method. The test set ACC, Pre, Rec, and F1 scores reached 0.919, 0.925, 0.920, and 0.923, respectively, with the average ACC for the test and validation sets reaching 0.915. The ROC curve demonstrated an AUC value of 0.96 for the first representation method and a remarkable AUC value of 0.98 for the second representation method (Figure 5a). The t-SNE dimensionality reduction plot also indicated that the second representation method combined with the M3E model had better discriminability for the ACPs (Figure 5b). This aligns with reality as splitting amino acids in the sequence into individual words with a natural order is more consistent with the natural distribution of amino acids in the sequence. Therefore, transforming amino acid sequences into vector representations with semantic information can better capture advanced features and relationships in the sequence, leading to a noticeable improvement in model accuracy.

Visual analysis of deep learning models. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

## Section: Results › Deep Learning Model Performance Evaluation Results › Results of Fusion Models of Machine Learning and Deep Learning

In this study, to enhance the accuracy of deep learning models, we not only independently utilized NLP deep learning models, but also attempted to combine them with traditional machine learning models using the Greedy Soup strategy to achieve a superior performance. Through this fusion approach, we could leverage the ability of deep learning models to extract complex features from amino acid sequences and enhance the final classification accuracy by using machine learning models. We selected the model with the highest ACC from numerous combinations for detailed evaluation, and the results were listed in Table 5. The findings indicated that the overall performance of the model improved after incorporation of machine learning models. In particular, the combination of the M3E-base and KNeighborsDist models exhibited the highest accuracy in all tests, reaching an impressive 93.9%.

On the other hand, we visually presented the experimental results of this fusion strategy. The ROC curve graph clearly illustrated the classification performance of the fusion model (Figure 6a). We observed that when not considering the semantic information on amino acids, the combination of M3E-base and KNeighborsDist achieved an AUC value of 0.95, demonstrating excellent classification capability. In the presence of semantic information, the combination of M3E-base and KNeighborsDist increased the AUC value to 0.97, while the combination of bert_base_uncased and LightGBMXT reached an AUC value of 0.98. This highlighted the significance of semantic information in enhancing model performance.

Furthermore, the t-SNE dimensionality reduction plot revealed the separation of the model in handling different categories of data (Figure 6b). Comparing the dimensionality reduction results of different model combinations, we found that considering spatial information significantly improved the model’s ability to differentiate between ACPs (label = 1) and non-ACPs (label = 0). In particular, the combination of bert_base_uncased and LightGBMXT exhibited a higher category separation in the dimensionality reduction plot, corroborating its high AUC value in the ROC curve graph.

These results not only confirmed the effectiveness of NLP deep learning models in handling amino acid sequences but also indicated that traditional machine learning models could effectively enhance the performance of deep learning models, especially when incorporating semantic information into the sequence. Through this hybrid model, we could more accurately identify and classify ACPs, thereby applying them more effectively in drug design and related fields of bioinformatics.

Visual analysis of fusion models of deep learning and machine learning. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

## Section: Results › Deep Learning Model Performance Evaluation Results › Comprehensive Results and Performance Comparison

This study conducted a comprehensive comparison of the impact of different encoding methods and model combinations on the task of identifying ACPs. By contrasting various encoding strategies and deep learning (DL) models with or without the inclusion of machine learning (ML) models, our determined the optimal model configuration for achieving high-precision recognition of ACPs. In addition, we compared the performance of our models with several currently known excellent ACP predictors. In Table 6, we compared six different encoding and model combination strategies, recording their average accuracy (AvgAcc). XGBoost models based on integer encoding (intEncode) and integer encoding considering amino acid position information (intPositionEncode) both demonstrated an AvgAcc of 0.873, providing a stable baseline performance. However, when transitioning to NLP deep learning models, we noted that bert-base-uncased achieved an AvgAcc of 0.904 without semantic information and without combining ML models. Furthermore, the m3e-base model, when considering semantic information and not combining ML models, reached an AvgAcc of 0.922. When combining DL models with ML models, performance showed a significant improvement. In particular, when not considering semantic information, the combination of the m3e-base and KNeighborsDist increased AvgAcc to 0.915. In the presence of semantic information, the same combination achieved the highest AvgAcc value in this study, reaching 0.939.

The ROC curve graph in Figure 7 provided an intuitive way to compare performance. From the graph, we observed that the combination of m3e-base and KNeighborsDist, which incorporated semantic information, demonstrated the most outstanding classification ability among all of the models, with an AUC value of 0.97. This further emphasized the importance of semantic information in enhancing model accuracy and the potential of ML models to effectively boost the performance of DL models.

Then, we selected two currently known excellent ACP predictors, iACP-FSCM26 and ACPred-FL,27 tested them with our data set, and compared their ROC curves and AccAvg values with our models. The performance comparison results showed that our models were significantly higher than the iACP-FSCM and ACPred-FL models in terms of the AUC value and AccAvg value. It proved that our models were advanced compared to existing ACP predictors.

ROC curves and AUC values of the highest AvgAcc models and comparisons with other ACP predictors.

## Section: Results › Model Prediction and In Vitro Antitumor Efficacy of Peptides

We randomly selected 741 peptides as test peptides in the database and predicted them using the model m3e-base+KNeighborsDist with the highest comprehensive evaluation. Two peptides with potentially high anticancer activity were predicted, namely, KEWLE and KRLAFA. Mass spectrometry results showed that the two peptides were successfully synthesized, and HPLC results confirmed that the purity of both peptides was above 95% (Figures S1–S4). Mouse breast cancer cell 4T1 cells were selected to validate the in vitro antitumor efficacy of the two peptides. The experimental results are shown in Table 7, and the IC50 values of the two peptides were, respectively, 47.46 ± 12.14 and 39.99 ± 9.744 μM, and both had in vitro antitumor efficacy.

## Section: Discussion

This study aimed to construct a precise and automated model for the screening of ACPs using machine learning methods. Initially, three different feature representation and encoding methods were employed, with the third encoding method combining two different NLP sequence representations, utilizing NLP models such as BERT and M3E, and introducing a combination strategy of machine learning models. By integration of various machine learning and deep learning models, a model combination with higher accuracy was ultimately selected. In vitro anticancer efficacy validation was performed, demonstrating that the peptides validated by the model exhibited potent anticancer cell toxicity. Overall, this study innovatively incorporated NLP into the screening of anticancer peptides, achieving higher and more achievable accuracy compared to traditional methods and confirming the practical and effective anticancer activity of the selected peptides.

The machine learning methods employed in this study, such as LightGBM, XGBoost, etc., demonstrated good generalization performance in terms of model efficiency, especially when dealing with high-dimensional features and large-scale data, exhibiting high efficiency and prediction accuracy. These machine learning models effectively screened anticancer peptides through traditional feature engineering and model fusion strategies, confirming their reliability in peptide sequence analysis. In contrast, deep learning methods such as BERT, M3E, etc., showed advantages in capturing sequence features and contextual information. These models could better utilize the sequential information and global context in the sequences, enhancing the model’s predictive capabilities through learning advanced features. Particularly, the BERT model, as an advanced model in the natural language processing field, successfully applied the Transformer structure to learn representations of protein sequences, offering new possibilities for the screening of anticancer peptides. In summary, traditional machine learning models have advantages in efficiency, while deep learning models excel in learning and representing sequence features. Therefore, combining machine learning and deep learning methods may become a new trend in the future for screening anticancer peptides. It is worth noting that compared with the studies by Wei et al.27 and Charoenkwan et al.,26 this study focuses on predicting the activity of ACP using a combination of deep learning and efficient feature expression, achieving the highest prediction accuracy of 0.939. The above comparative studies construct effective sequence feature expressions and achieve prediction through traditional machine learning, and the prediction accuracy is slightly lower than that in this study.

It was noteworthy that this experiment demonstrated significant practical value in the screening of anticancer peptides. By application of a combination of machine learning and deep learning models, the efficiency of anticancer peptide screening was improved. Traditional methods of anticancer peptide screening typically required extensive experimentation and human resources. The model constructed in this study could rapidly and accurately predict peptide sequences with potential anticancer activity, significantly shortening the screening cycle. This precise screening method effectively reduced the cost of developing new anticancer drugs, accelerating the drug development process. This is also in line with the future development trend in this field using advanced computational methods to discover functional peptides to aid drug screening.28

From a longer-term perspective, ACPs have emerged as a promising alternative due to their specificity, lower toxicity, and ability to circumvent drug resistance mechanisms that often limit the effectiveness of traditional therapies. Traditional chemotherapy indiscriminately targets rapidly dividing cells, leading to significant side effects, whereas ACPs offer a more targeted approach, potentially leading to more effective and less harmful treatments. Moreover, advancements in peptide engineering and drug delivery systems have significantly enhanced the stability, bioavailability, and tumor-targeting capabilities of ACPs, making them a viable option in the arsenal against cancer. However, despite these advantages, the clinical application of ACPs still faces several challenges such as their rapid degradation in the bloodstream, potential immunogenicity, and the complexity of large-scale synthesis. These issues necessitate further research and innovation to overcome. Additionally, while ACPs show promise in preclinical studies, their efficacy and safety in human trials must be rigorously tested. The possibility of replacing traditional anticancer drugs with peptides depends not only on overcoming these technical hurdles but also on demonstrating superior clinical outcomes.

While this study has made significant progress in anticancer peptide screening, there are limitations that need to be considered. First, the quality and quantity of the data set have a crucial impact on the training and prediction of machine learning and deep learning models, and the data set used in this study may have limitations. The size and coverage of the data set may influence the generalization ability and predictive performance of the model. Therefore, a more extensive and representative data set could further enhance the robustness of the model. Second, the choice of feature representation and encoding methods has a significant impact on the performance of the model. Although the feature engineering methods used in this study are diverse, there may still be a potential optimization space. Further exploration of more effective feature representation and encoding methods may improve the model’s ability to abstractly represent peptide sequences, thereby enhancing predictive performance. Lastly, despite the in vitro experiments validating the anticancer activity of the peptides screened by the model, more experimental data and further clinical trials are needed to verify the feasibility and effectiveness of their clinical application. There is a certain difference between laboratory conditions and actual treatment environments, necessitating more clinical data to support the experimental results obtained in this study.

## Section: Conclusions

This study successfully integrated different encoding methods with multiple machine learning approaches to construct a precise screening model for anticancer peptides. Through rigorous model training and comparison, the study accurately screened peptide sequences with anticancer potential and confirmed the effectiveness of the model’s predictions in in vitro experiments. Particularly, the introduction of NLP language models into the screening of anticancer peptides in this study, compared with traditional methods, significantly improved both the accuracy and efficiency of screening. This opened up new possibilities and avenues for the discovery and research of anticancer drugs. However, despite the relatively outstanding results achieved in this study, there were still some suggestions for improvement to consider. In future research, we will continue to explore and incorporate the latest technologies and theoretical advancements to continuously enhance the performance and practicality of the model, promoting the development and application of anticancer drugs.

## Section: Acknowledgments

Authors gratefully acknowledge the financial support from the Zhejiang City University Research and Incubation Fund (J-202326).

## Section: Data Availability Statement

All code used in data analysis and preparation of the manuscript, alongside a description of necessary steps for reproducing results, can be found in a GitHub repository: https://github.com/Keda0411/acps.

## Section: Supporting Information Available

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acsomega.4c01374.

## Section: Author Contributions

M.X. conceived the basic idea and designed the framework. M.Q. and J.P. performed the experiments. M.X., J.P., and Z.Z. wrote the manuscript. Y.Y. revised the manuscript.

## Section: Text

The authors declare no competing financial interest.

## Section: Supplementary Material

ao4c01374_si_001.pdf

## Section: Associated Data

ao4c01374_si_001.pdf

## Section: Associated Data › Supplementary Materials

ao4c01374_si_001.pdf

## Section: Associated Data › Data Availability Statement

All code used in data analysis and preparation of the manuscript, alongside a description of necessary steps for reproducing results, can be found in a GitHub repository: https://github.com/Keda0411/acps.


---

# Interpretable machine learning in predicting drug-induced liver injury among tuberculosis patients: model development and validation study

- **Authors:** Yue Xiao, Yanfei Chen, Ruijian Huang, Feng Jiang, Jifang Zhou, Tianchi Yang
- **Issuer:** BMC medical research methodology
- **Type:** Scientific article
- **Published:** 2024-04-20
- **Language:** en
- **DOI:** 10.1186/s12874-024-02214-5
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38643122/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackgroundThe objective of this research was to create and validate an interpretable prediction model for drug-induced liver injury (DILI) during tuberculosis (TB) treatment.MethodsA dataset of TB patients from Ningbo City was used to develop models employing the eXtreme Gradient Boosting (XGBoost), random forest (RF), and the least absolute shrinkage and selection operator (LASSO) logistic algorithms. The model's performance was evaluated through various metrics, including the area under the receiver operating characteristic curve (AUROC) and the area under the precision recall curve (AUPR) alongside the decision curve. The Shapley Additive exPlanations (SHAP) method was used to interpret the variable contributions of the superior model.ResultsA total of 7,071 TB patients were identified from the regional healthcare dataset. The study cohort consisted of individuals with a median age of 47 years, 68.0% of whom were male, and 16.3% developed DILI. We utilized part of the high dimensional propensity score (HDPS) method to identify relevant variables and obtained a total of 424 variables. From these, 37 variables were selected for inclusion in a logistic model using LASSO. The dataset was then split into training and validation sets according to a 7:3 ratio. In the validation dataset, the XGBoost model displayed improved overall performance, with an AUROC of 0.89, an AUPR of 0.75, an F1 score of 0.57, and a Brier score of 0.07. Both SHAP analysis and XGBoost model highlighted the contribution of baseline liver-related ailments such as DILI, drug-induced hepatitis (DIH), and fatty liver disease (FLD). Age, alanine transaminase (ALT), and total bilirubin (Tbil) were also linked to DILI status.ConclusionXGBoost demonstrates improved predictive performance compared to RF and LASSO logistic in this study. Moreover, the introduction of the SHAP method enhances the clinical understanding and potential application of the model. For further research, external validation and more detailed feature integration are necessary.Supplementary InformationThe online version contains supplementary material available at 10.1186/s12874-024-02214-5.Keywords: Machine learning, Logistic regression, Tuberculosis, Drug-induced liver injury, Retrospective study

## Section: Background

Drug-induced liver injury (DILI) presents significant challenges in the context of tuberculosis (TB) treatment. Anti-TB drugs exhibit noteworthy involvement in the occurrence of DILI [1, 2], and the lack of certain early-detection biomarkers [3] further poses challenges to the timely diagnosis and management of DILI. This absence of early detection may result in treatment interruptions and failures amongst TB patients [4, 5], impeding global TB eradication efforts [6]. In China, the elevated incidence rates of DILI in comparison to western nations highlight the potential involvement of traditional Chinese medicines (TCM) and herbal medicines in the development of DILI [7]. This requires addressing various challenges and complexities associated with DILI assessment in a comprehensive and objective manner. Therefore, the primary objective of this study is to develop an optimal predictive model for assessing DILI status, with a specific focus on TB patients within the Chinese context.

The emergence of machine learning (ML) algorithms presents an exciting opportunity to enhance DILI prediction models [8]. Among these, eXtreme Gradient Boosting (XGBoost) [9] and random forest (RF) [10] stand out as two widely-used ensemble learning techniques, each distinguished by its algorithmic approach and features. Selecting the most suitable option between them hinges on the particular characteristics of the data and the prediction objective. Therefore, it is often advisable to conduct experiments with both models to compare their performance.

Nevertheless, one of the primary challenges in implementing ML algorithms in clinical settings is interpreting the outcomes of the models [11, 12]. The Shapley Additive exPlanations (SHAP) framework [13] provides insights into the influence of various features on model predictions and the effect of these features on the DILI status in individuals, thus bridging the interpretability gap.

This study focuses on the development and validation of a prediction model for DILI in the context of TB treatment by using advanced ML algorithms with SHAP interpretability. Through this endeavor, we aim to achieve a balance between accurate prediction and the interpretability of the model, which is crucial for its clinical application.

## Section: Methods

Study schema for subject selection. Abbreviations: EHR, Electronic healthcare record; CDC, Center for Disease Control and Prevention

## Section: Methods › Data source

The study participants comprised individuals diagnosed with TB at specified hospitals in Ningbo from 1st January 2015 to 2nd January 2020, initially referred by the Chinese Center for Disease Control and Prevention (CDC) [14]. Thereafter, they were connected to administrative records obtained from the electronic health records (EHR) system employed by the local government [15]. The merged dataset comprised demographic information, hospitalization records (both inpatient and outpatient), laboratory tests, and medication profiles.

## Section: Methods › Exclusion criteria

To ensure consistency in the identification of covariates, individuals with only one health care encounter during the study period were excluded. Furthermore, individuals without ethnicity information and those under 18 years old at diagnosis were not included in the study. The exclusion criteria also filtered out misdiagnosed cases of DILI and liver injuries attributed to known factors like alcohol-related liver disease, non-alcoholic fatty liver disease (NAFLD), and viral hepatitis unrelated to drug-induced causes. The detailed flowchart is presented in Fig. 1.

Study schema for subject selection. Abbreviations: EHR, Electronic healthcare record; CDC, Center for Disease Control and Prevention

## Section: Methods › Baseline laboratory result collection

For patients included in the study, we defined the baseline period for collecting laboratory test results as from January 1, 2015, to the day before the index diagnosis of pulmonary tuberculosis, as shown in Supplemental Fig. 1. Additionally, liver function test indicators such as alanine transaminase (ALT) or alkaline phosphatase (ALP) were simultaneously examined.

To address the issue of varied baseline definitions in laboratory testing, we utilized two main strategies. Firstly, we employed a binary variable approach to categorize laboratory testing indicators as abnormal or normal, by comparing their values with predefined normal ranges. Secondly, we utilized ratio-based representation to quantify indicator abnormalities, such as calculating ALT multiples relative to the upper limit of the normal (ULN) range.

## Section: Methods › Factor identification

In our research, we followed the initial steps outlined in the high dimensional propensity score (HDPS) methodology by Schneeweiss et al. [16]. First, we identified 24 common factors, such as age and gender, to integrate into our models. We then categorized our data into four dimensions: outpatient records, inpatient records, laboratory test records, and medication records. Following the approach of Chen et al. [17], we identified the top 500 most prevalent codes within each dimension. Next, we evaluated code recurrence, classifying codes into three binary variables based on their frequency of occurrence over a 12-month baseline period. This yielded a total of 4*500*3 binary factors. Using a multiplicative model considering binary factor and DILI status, we prioritized covariates and selected the top 400 for inclusion in our final model based on an arbitrary cutoff recommendation [18, 19]. Finally, considering the previously specified 24 variables, our model training ultimately involved incorporating a total of 424 factors.

## Section: Methods › DILI diagnostic process

The determination of DILI outcomes followed the revised criteria set forth by the Chinese Society of Hepatology (CSH) DILI consensus, as outlined in Supplemental Table 1 [20].

## Section: Methods › Extraction of features used in prediction model

The LASSO regression method, aimed at reducing the number of variables and preventing overfitting [21], was applied to extract significant features for constructing the logistic model. Additionally, both the XGBoost and RF algorithms come equipped with their own feature selection techniques tailored to enhance their respective models.

## Section: Methods › Statistical analysis

The study reported the features of both the non-DILI and DILI groups by mean and standard deviation (SD) or as numbers and percentages whenever necessary. Laboratory variables were represented in median and quartiles [22]. The Kruskal–Wallis rank sum test was used for continuous variables, while the chi-square test was used for categorical variables. These analyses were conducted using the statistical software packages SAS 9.4 and R 4.0.3. A statistically significant result was determined with a two-sided P-value below 0.05.

## Section: Methods › Data splitting

In order to create training and validation sets, a stratified random function in R randomly assigned records at a 7:3 ratio, following conventional practices.

## Section: Methods › Parameter optimization

To optimize the parameters of the XGBoost and RF models, a ten-fold cross-validation process combined with grid search [23] was employed. This approach entailed identifying the hyperparameter set that yielded the maximum receiver operating characteristic (ROC). A detailed breakdown of the grid search particulars and optimal results can be found in Supplemental Table 2.

## Section: Methods › Model evaluation and interpretation

To assess the model's capacity to differentiate between positive and negative cases, we computed both the area under the receiver operating characteristic curve (AUROC) and the area under the precision recall curve (AUPR) [24]. Calibration was examined through reliability diagrams and Brier scores. Furthermore, the model's clinical utility was evaluated using decision curve analysis. The SHAP technique was utilized to delve deeper into variable contributions. A comprehensive overview of the workflow can be found in Supplemental Fig. 2.

## Section: Results

Demographic and clinical characteristics of patients with and without DILI

Comparison of performance ability of the three models in the validation set

Comparison of the AUROC of the XGBoost, logistic and random forest in the validation set

Comparison of the AUPR of the XGBoost, logistic and random forest in the validation set

Comparison of the calibration curve of the XGBoost, logistic and random forest in the validation set

The decision curve of the XGBoost, logistic and random forest in the validation set

Top important features selected by XGBoost (> 0.01). Abbreviations: ODILIO, outpatient drug-induced liver injury, once occurring; ODIHO, outpatient drug induced hepatitis, once occurring; ODIHS, outpatient drug induced hepatitis, sporadically occurring; IDIHO, inpatient drug induced hepatitis, once occurring; ODILIS, outpatient drug induced liver injury, sporadically occurring; IDIHF, inpatient drug induced hepatitis, frequently occurring; IDILIO, inpatient drug induced liver injury, once occurring; ODILIF, outpatient drug induced liver injury, frequently occurring; TBIL, total bilirubin; ALP, alkaline phosphatase; IDILIS, inpatient drug induced liver injury, sporadically occurring; ALT, alanine aminotransferase; FLD, fatty liver disease

## Section: Results › Participant and factor identification

The preliminary linkage of data yielded 12,087 instances. Following the application of exclusion criteria, a total of 7,071 subjects were identified as suitable for inclusion in the study.

During a one-year baseline period, we identified the 500 most prevalent codes across each data dimension (outpatient, inpatient, medication, and laboratory test) using the International Classification of Diseases-Tenth Revision (ICD-10), Current Procedural Terminology (CPT), and generic drug names. These items were then categorized into three binary variables: "ever occurring", "sporadically occurring", and "frequently occurring", indicating their recurrence. This process resulted in a total of 6,000 variables, from which the top 400 binary empirical variables were chosen based on their highest risk ratios associated with DILI status. Additionally, the final model incorporated 24 predefined baseline variables, such as gender, age, education level, medication, and maximum ratio of ULN for ALT, ALP, and Tbil, etc. Out of an initial pool of 424 features, 37 were selected for logistic model development using LASSO. The factors included in the LASSO logistic model are detailed in Supplemental Table 3.

## Section: Results › Epidemiology of DILI

The incidence of DILI was observed to be 16.3% overall, with a slightly higher observed in female patients (17.3% vs. 15.8%, p = 0.134). Detailed demographics and clinical information are outlined in Table 1. Compared to non-DILI individuals, those with DILI demonstrated lower educational attainment and a higher incidence of abnormal baseline levels in ALT and ALP [ALT: 91 (7.9%) vs. 273 (4.6%), p < 0.001; ALP: 100 (8.7%) vs. 400 (6.8%), p = 0.023]. Individuals of middle age, females, and those with pre-existing chronic liver conditions were found to have a higher susceptibility to DILI. Significant associations with DILI were identified for certain drugs, including pyrazinamide (PZA), isoniazid (INH), traditional Chinese medicines (TCM), and hepatoprotective agents such as silymarin and glycyrrhetinic acid.

Demographic and clinical characteristics of patients with and without DILI

## Section: Results › Model development and validation

The XGBoost and RF models were constructed using optimal parameters obtained through the previously mentioned GridSearchCV method. The LASSO logistic model was constructed with the aforementioned variables. Internal validation was conducted by partitioning validation sets, resulting in a comparison of model performance among the three models showcased in Table 2. The XGBoost model exhibited slightly superior discriminatory ability when compared with the RF and LASSO logistic model, with AUROC values of 0.89 versus 0.88/0.85 and AUPR values of 0.75 versus 0.73/0.67, respectively, as shown in Figs. 2 and 3. The RF model demonstrated increased recall with a score of 0.78, while the XGBoost model achieved the highest F1-score of 0.57. Calibration was evaluated through ten predictive probability-based bins and verified by the reliability diagram presented in Fig. 4, supported by a Brier score of 0.08, indicating the impressive alignment in calibration between the XGBoost and LASSO logistic models. Extensive analysis of the decision curve revealed positive net benefits for all models. Notably, XGBoost models outperformed both the RF and LASSO logistic models within the threshold range of approximately 0.2 to 0.5, as demonstrated in Fig. 5.

Comparison of performance ability of the three models in the validation set

Comparison of the AUROC of the XGBoost, logistic and random forest in the validation set

Comparison of the AUPR of the XGBoost, logistic and random forest in the validation set

Comparison of the calibration curve of the XGBoost, logistic and random forest in the validation set

The decision curve of the XGBoost, logistic and random forest in the validation set

## Section: Results › Model interpretation

Revealing the factors that influenced the outperformed model's predictions, Fig. 6 laid out the most paramount features of XGBoost (with feature importance > 0.01). Of note, historical occurrences of DILI, DIH, and fatty liver disease (FLD) during the baseline phase were consistently highlighted. Moreover, the ULN for ALT, ALP and Tbil were also identified as critical factors. The SHAP values calculated for the XGBoost model, as shown in Supplemental Fig. 3, indicate that individuals who had chronic liver disease during baseline were more likely to be in DILI status. Interestingly, we found that those with a lower educational level were more susceptible to DILI status. To gain a deeper understanding of the underlying mechanism and the effects of features in the XGBoost model, we randomly selected two typical patients from the dataset. Furthermore, we created force plots to visualize their decision process, as illustrated in Supplemental Fig. 4 and Supplemental Fig. 5. The average SHAP value was 0.168, where yellow indicates a positive impact and purple represents a negative impact. In Supplemental Fig. 4, the identified patient with a SHAP value of 1.06, surpassing the average, is likely to develop DILI. The significant influencing factor is being diagnosed with DILI or DIH at least once during the baseline period. The same rationale applies to the identified patient as depicted in Supplemental Fig. 5. Additionally, Supplemental Fig. 6 presents a force plot that captures the aggregate effect in the validation set.

Top important features selected by XGBoost (> 0.01). Abbreviations: ODILIO, outpatient drug-induced liver injury, once occurring; ODIHO, outpatient drug induced hepatitis, once occurring; ODIHS, outpatient drug induced hepatitis, sporadically occurring; IDIHO, inpatient drug induced hepatitis, once occurring; ODILIS, outpatient drug induced liver injury, sporadically occurring; IDIHF, inpatient drug induced hepatitis, frequently occurring; IDILIO, inpatient drug induced liver injury, once occurring; ODILIF, outpatient drug induced liver injury, frequently occurring; TBIL, total bilirubin; ALP, alkaline phosphatase; IDILIS, inpatient drug induced liver injury, sporadically occurring; ALT, alanine aminotransferase; FLD, fatty liver disease

## Section: Discussion

To our knowledge, this study represents the initial attempt to evaluate the prediction for DILI in an Asian population, predominantly of Han ethnicity, with TB using regional electronic health records. We observed slightly enhanced discrimination abilities in ML models compared to the logistic model. While logistic regression offers better clinical generalizability, it struggles with overfitting and handling missing variables, resulting in overall weaker performance than anticipated. In contrast, both XGBoost and RF employ more advanced techniques. XGBoost utilizes gradient boosting, progressively building weak learners and effectively capturing non-linear relationships with built-in regularization. On the other hand, RF, a bagging ensemble method, constructs independent decision trees on random subsets of data, resulting in robust averaging but with less explicit regularization. XGBoost excels in capturing intricate non-linear patterns, making it suitable for tasks involving complex and dynamic interactions like predicting DILI during TB treatment. Its training efficiency is also evident when handling large datasets. RF, with its robust averaging, is well-suited for further application in diverse datasets but may encounter challenges in effectively capturing subtle non-linear patterns among multiple explanatory variables.

Several prior studies have identified risk factors associated with DILI during TB treatment, involving chronic liver disease, specific drug combinations, age, and various demographic characteristics [25–27]. Lammert et al. [28] suggested an increased risk of DILI in patients with chronic liver disease indicative of NAFLD. Chang et al. [29] indicated a significant rise in hepatotoxicity risk associated with adding PZA to INH and RIF. Hosford et al. [30] established a notable elevation in hepatotoxicity risk among individuals over 60 years of age through a systematic literature review. Abbara et al. [2] found low patient weight, HIV-1 co-infection, higher baseline ALP levels, and alcohol intake were risk factors. Thus, in our model, we predefined enzyme levels, utilization of anti-TB drugs such as PZA, INH, and RIF, hepatoprotective agents such as silymarin and glycyrrhetinic acid, alcohol intake, and demographic variables such as age, gender, education level, ethnicity, profession as predictors. In the ultimate XGBoost model, the contribution weights for chronic liver disease, ULN of ALT, ALP, Tbil, and age surpass 0.01, consistent with earlier research discoveries.

Currently, a range of predictive models for DILI primarily operates at the molecular level in preclinical settings [31], utilizing diverse artificial intelligence assisted algorithms [32]. Minerali et al. [33] employed the Bayesian ML method, resulting in an AUROC of 0.81, 74% sensitivity, 76% specificity, and 75% accuracy. Xu et al. [34] proposed a deep learning model, achieving 87% accuracy, 83% sensitivity, 93% specificity, and an AUROC of 0.96. Dominic et al.'s Bayesian prediction model [35] demonstrated balanced performance with 86% accuracy, 87% sensitivity, 85% specificity, 92% positive predictive value, and 78% negative predictive value. In the clinical stage, only Zhong et al. introduced a single tree XGBoost model with 90% precision, 74% recall, and 76% classification accuracy for DILI prediction, using a clinical sample of 743 TB cases [36]. In our study, we leveraged regional healthcare data and employed the XGBoost algorithm. The model exhibited 76% recall, 82% specificity, and 81% accuracy in predicting DILI status. Our approach was proven robust, as evidenced by a mean AUROC of 0.89 and AUPR of 0.75 upon tenfold cross validation. During the clinical treatment stage, our model exhibited high levels of accuracy and interpretability.

The choice of a cutoff in a DILI prediction model is crucial and depends on specific study goals and requirements. Various studies have investigated optimal cutoff values in DILI prediction models to enhance understanding and prediction accuracy. For instance, in a study focused on drug-induced liver tumors, the maximum Youden index was utilized to determine the ideal cutoff point [37]. Another study, aimed at predicting DILI and cardiotoxicity, determined 0.4 as the optimal cutoff value using chemical structure and in vitro assay data [38]. Similarly, a system named DILIps, designed to predict DILI in drug safety, utilized the ROC curve to select the best cutoff value [39]. Given the imbalanced dataset in our study, we found the precision recall curve method seemed to be more appropriate. Additionally, considering the severe consequences of DILI, prioritizing the detection of DILI suggests choosing a lower cutoff to maximize sensitivity. Thus, in our study, we opted for the maximum Youden index as the best cutoff.

However, the acceptability of ML in the medical community faces a significant hurdle regarding interpretability, particularly in settings where clinical decisions are paramount. Our research employed SHAP strategies to illuminate the complex mechanisms of the XGBoost model.

## Section: Strengths and limitations

The study utilized a large dataset of over 7,000 TB patients to develop a robust model and comprehensively included clinical, demographic, and biochemical variables to improve predictive accuracy. Furthermore, the model incorporates SHAP analysis to improve interpretability. However, as we embark on the integration of ML into clinical settings, a vital concern persists regarding the generalizability of models [40]. While our model demonstrates enhanced predictive accuracy, it's important to recognize the inherent limitations stemming from the lack of external validation. Patient characteristics [41] and drug interactions [42] may differ widely across populations. This underscores the importance of validating models on diverse patient cohorts and geographical regions. Moreover, the study's reliance on a data-driven approach and the inherent complexity of integrating ML models into clinical practice present additional limitations [43]. Additionally, the dependence on clinical diagnosis for DILI and the potential influence of unmeasured variables on model accuracy are acknowledged. While the study's findings offer valuable insights, careful consideration is warranted when interpreting them.

## Section: Conclusions

XGBoost shows improved predictive performance compared to RF and LASSO logistics in this study. Moreover, introducing the SHAP method enhances the clinical understanding and potential application of the model. For further research, external validation and more detailed feature integration are necessary.

## Section: Conclusions › Code availability statement

To enhance reproducibility and facilitate peer review, we uploaded the code used for model fitting. The source code associated with this research is available on the GitHub repository (https://github.com/cpu-pharmacoepi/TB-DILI). For inquiries or assistance related to the code, please contact 1,020,202,613@cpu.edu.cn.

## Section: Supplementary Information

Supplementary Material 1.

Supplementary Material 2.

## Section: Acknowledgements

The authors thank all staff of the tuberculosis control centers, designated hospitals, community health service centers, and township health centers in ten counties/districts from Ningbo for their hard work and help in collecting clinical data. We also thank our colleagues from Ningbo Health Information Center for providing clinically relevant data for this study.

## Section: Acknowledgements › Disclosure of AI tools

We hereby disclose that generative AI tools were not utilized in the preparation or analysis of data presented in this manuscript. All methodologies and analyses were conducted utilizing established statistical and machine learning techniques as outlined in the Method section.

## Section: Authors’ contributions

All authors were involved in the design of the study, FJ and RH cleaned data and constructed the cohort; YC was involved in conceptualizing the study; YX and JZ were responsible for the analysis of the data and interpretation of the results.; YX, JZ and TY contributed to the drafting of the manuscript. All authors read and approved the final manuscript.

## Section: Funding

This research was supported by Zhejiang Medical Research Project(2018KY733) and Natural Science Foundation of Ningbo (2019A610386, 2019A610385). The content is solely the responsibility of the authors and does not necessarily represent the official views of the funding agencies.

## Section: Availability of data and materials

The datasets used and analyzed during the current study are available from the corresponding author on reasonable request. Data cannot be shared publicly because of privacy and confidentially of the TB patients in Ningbo, Zhejiang, China.

## Section: Declarations › Ethics approval and consent to participate

All aspects of this study, including research methods were conducted in strict accordance with relevant guidelines and regulations. This study was conducted in compliance with the ethical principles outlined in the Declaration of Helsinki. All patient data in the database were de-identified, and this study was determined to be exempt by the Institutional Review Board of the Ningbo Municipal Center for Disease Control and Prevention. Written informed consent was waived for the present study. The institutional Review Board of the Ningbo Municipal Center for Disease Control and Prevention waived the need for informed consent.

## Section: Declarations › Consent for publication

Not applicable.

## Section: Declarations › Competing interests

The authors declare no competing interests.

## Section: Contributor Information

Jifang Zhou, Email: 1020202613@cpu.edu.cn.

Tianchi Yang, Email: cn-yangtc@outlook.com.

## Section: Associated Data

Supplementary Material 1.

Supplementary Material 2.

## Section: Associated Data › Supplementary Materials

Supplementary Material 1.

Supplementary Material 2.

## Section: Associated Data › Data Availability Statement

The datasets used and analyzed during the current study are available from the corresponding author on reasonable request. Data cannot be shared publicly because of privacy and confidentially of the TB patients in Ningbo, Zhejiang, China.


---

# Large language models facilitating modern molecular biology and novel drug development

- **Authors:** Xiao-Huan Liu, Zhen-Hua Lu, Tao Wang, Fei Liu
- **Issuer:** Frontiers in pharmacology
- **Type:** Scientific article
- **Published:** 2024-12-24
- **Language:** en
- **DOI:** 10.3389/fphar.2024.1458739
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39776586/
- **Licence:** CC-BY

## Section: Abstract

AbstractThe latest breakthroughs in information technology and biotechnology have catalyzed a revolutionary shift within the modern healthcare landscape, with notable impacts from artificial intelligence (AI) and deep learning (DL). Particularly noteworthy is the adept application of large language models (LLMs), which enable seamless and efficient communication between scientific researchers and AI systems. These models capitalize on neural network (NN) architectures that demonstrate proficiency in natural language processing, thereby enhancing interactions. This comprehensive review outlines the cutting-edge advancements in the application of LLMs within the pharmaceutical industry, particularly in drug development. It offers a detailed exploration of the core mechanisms that drive these models and zeroes in on the practical applications of several models that show great promise in this domain. Additionally, this review delves into the pivotal technical and ethical challenges that arise with the practical implementation of LLMs. There is an expectation that LLMs will assume a more pivotal role in the development of innovative drugs and will ultimately contribute to the accelerated development of revolutionary pharmaceuticals.Keywords: artificial intelligence, large language models, drug development, ChatGPT, protein structure prediction

## Section: 1 Introduction

During the past few decades, the field of drug discovery has undergone a transformative revolution, largely due to the rapid advancements in information technology and modern biotechnology, such as artificial intelligence (AI), machine learning (ML), structural revolution (crystallography), and synthetic biology (Sadybekov and Katritch, 2023; Murray et al., 2023; Cova et al., 2022; Roggia et al., 2024). A notable paradigm shift is evident in contemporary drug discovery, where emerging technologies have streamlined the drug development process, consequently reducing associated costs (Pandey et al., 2022). Among them, computational approaches guided by molecular modeling techniques with AI for “hit identification” and “lead optimization” have garnered significant interest from biotech firms and research institutions (Jayatunga et al., 2022; Chakraborty et al., 2023). “Hit identification” is the process of screening large compound libraries to discover molecules that exhibit initial biological activity against a specific target, serving as potential starting points for drug development. “Lead optimization” is the systematic process of refining and enhancing the potency, selectivity, and pharmacokinetic properties of a promising drug candidate to improve its therapeutic potential and reduce side effects. Nowadays, the strategic application of AI in drug discovery has significantly hastened the development timeline and diminished both the cost and duration of early-stage drug discovery phases (Chakraborty et al., 2023; Lamberti et al., 2019).

LLMs are cutting-edge AI systems crafted on the foundation of neural network architectures and refined through exposure to human language from a plethora of sources, including articles, books, and news reports. Consequently, LLMs are capable of capture the complicated associative relationships between words in a text-based training dataset, harnessing the capabilities of deep learning (Thirunavukarasu et al., 2023). These models have been effectively integrated into numerous fields, demonstrating a versatility that encompasses dialogue and beyond. In particular, the recent surge in advancements within LLMs have paved the way for their integration into healthcare and biotechnological pharmaceutics (Liu et al., 2023a). Boasting the capacity to execute a multitude of language-centric tasks, LLMs capitalize on neural networks and are trained on vast repositories of text generated by humans, thus transforming them into invaluable assets for information retrieval and the delivery of biomedical insights. Consequently, they can serve as valuable tools for retrieving information and providing biomedical solutions (Thirunavukarasu et al., 2023; Eggmann et al., 2023). Among the vanguard of AI-powered LLMs, ChatGPT stands as a notable example, which was instrumental in streamlining the drug discovery process (De Angelis et al., 2023). Typically, LLMs in drug development could be utilized for understanding disease mechanisms, designing and optimizing drug molecules, predicting efficacy and safety, integrating with AI tools, translating between molecules and indications, and exploring federated learning for enhanced data utilization and task generalization. Especially, LLMs can be integrated with other AI technologies like machine learning and computational biology tools to synergistically accelerate drug discovery. For example, machine learning algorithms can analyze vast databases to identify intricate patterns, leading to the discovery of novel therapeutic targets and prediction of potential drug candidates with better accuracy and speed. Quantitative structure-activity relationship (QSAR) modeling and molecular docking simulations are AI-driven predictive techniques that provide insights into predicting the biological activity of novel compounds with great accuracy.

There is a strong belief that the rapid evolution and widespread adoption of AI are defining trends of our time. In this review, the recent development of LLMs was highlighted, including their architectural frameworks and operational mechanisms. Furthermore, the manuscript has placed a special emphasis on the practical applications of Large Language Models (LLMs) in the biopharmaceutical sector. Several successful case studies were detailed to highlight the strengths and limitations of these models. Each case study includes an in-depth analysis and critical evaluation of the respective models. It is especially crucial to diligently evaluate and address the associated concerns, risks, and potential pitfalls (Borji, 2023). It is believed that the integration of LLMs in drug discovery would greatly facilitate the acceleration of the drug discovery pipeline.

## Section: 2 Designing an artificial intelligence-driven platform

Schematic representation of the ChatGPT-assisted drug addiction research process. (This process initiates with grasping the roles of AI in drug addiction research and generating drug-like molecules. It advances by refining the GNC model to produce leads targeting DAT, NET, and SERT receptors. Optimization is driven by the Langevin equation and an enhanced GNC model, prioritizing binding affinity predictions, which led to 15 potential drug leads pinpointed. ChatGPT supports this process by offering creative input, methodological insights, and coding aid, from debugging to interpretation).

Schematic of a GRU-enhanced autoencoder for drug design: from SMILES encoding to cocaine addiction treatment leads. (The molecular generation pipeline uses a GRU-based autoencoder to encode and decode SMILES strings, and the stochastic generator was used to create novel molecules. The process starts from input SMILES through latent space manipulation to generated SMILES. Subsequently ADMET screening and binding affinity prediction were achieved for the identification of potential cocaine addiction treatment leads).

The study flowchart to predict and explain drug-drug interactions with ChatGPT.

T Overview of the benchmark MultiMedQA, PaLM and Med-PaLM. (Various medical question-answering datasets are integrated into a multimodal framework, which would improve the performance of PaLM through prompting and instruction tuning for clinical applications).

The workflow of MolReGPT. (This figure illustrates a four-step process for generating molecular captions and text-based molecular designs. Initially, it retrieves examples from a database using molecular information. Subsequently, it curates prompts with system instructions for tasks like molecular captioning and generation. In the third phase, it uses a few examples to facilitate a language model learn and generate responses. Finally, it calibrates the generation to ensure the responses are accurate and in the correct format for tasks like Mol2Cap, where it describes molecules).

The workflow of Chemformer. (It shows a two-step process for training a molecular model. In Step 1, the model is pre-trained on 100 million molecules, where it learns to encode and decode molecular structures. In Step 2, the model is fine-tuned for specific tasks, such as predicting reactions, optimizing molecules, and estimating molecular properties. Each task uses an encoder to understand the molecule and a decoder to generate the result).

The architectural structure of MolGPT.

The architectural structure of MOLGEN. (In Step 1, the model learns molecular language syntax and meaning by encoding and decoding molecular structures. In Step 2, the model is fine-tuned with domain-agnostic molecular prefixes to improve the capability of understanding molecular structures. In this process, a self-feedback paradigm was included, where the model is capable of generating candidates, evaluating them based on properties, and learns from the feedback to enhance the performance for generating synthetic and natural product molecules).

The architectural structure of KV-PLM. (The workflow of KV-PLM starts with internal molecular structure serialization into SMILES format, then the Meta-knowledge mapping is utilized to correlates molecular features to human intelligence. External biomedical text would subsequently be fused with molecular data. The language model pre-training would empower the model with the ability to predict molecular properties. It enables knowledgeable machine reading across different molecular properties (e.g., molecular structure, chemical properties, natural language documentation, and structured biomedical knowledge), which would facilitate tasks like description generation, property prediction, and knowledge extraction).

The workflow of MolT5. (MolT5 is trained in two steps (Sadybekov and Katritch, 2023): in pre-training, it learns from public data such as the chemical formulas and reactions (Murray et al., 2023). In fine-tuning, it specializes in tasks like creating molecule descriptions and generating new molecules).

The pipeline of Text + Chem T5. (Text + Chem T5 is capable of dealing with both text and chemistry information, which has a text encoder and a chemistry encoder that work together to understand inputs from different domains. The model is capable of understanding a chemical structure and generate a description for it, or it could receive a description and generate the chemical structure in SMILES format).

A four-step process of Mol-Instructions for creating and refining molecular descriptions and data. [(Sadybekov and Katritch, 2023) human and AI work together to generate task descriptions about molecules (Murray et al., 2023); information about molecules is gathered from data sources and formatted for AI (Cova et al., 2022); biological data is turned into text using templates, such as description of the functions of a specific protein (Roggia et al., 2024); the quality of molecules and proteins is checked].

Outline of the ConPLex model architecture and training framework (In step (Sadybekov and Katritch, 2023), a pre-trained protein language model and a circular fingerprint method are used to analyze molecular structures. In step (Murray et al., 2023), embedding layers process the molecular data, creating a numerical representation. In step (Cova et al., 2022), the model undergoes a series of binary and contrastive epochs to update and refine the learning rate and margin for improved accuracy in predicting molecular interactions).

The model architecture of ComplexQA with the deep graph convolution network. (ComplexQA is capable of molecular analysis that processes various molecular features through Conv1D blocks and integrates edge information using Conv2D blocks. Then applies graph convolutional networks (GCNs) with multiple blocks was used for feature aggregation and normalization. Finally, it concludes with the generation of a residue interface score to assess molecular interactions).

The workflow of ProteinMPNN. (ProteinMPNN is consisted of a backbone encoder that processes protein backbone coordinates and edge information, and a sequence decoder capable of generating protein sequences. Nodes and edges are updated in the encoder, and through iterative decoding, it produces a protein sequence with a calculated probability).

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development

Armed with the capabilities of natural language processing (NLP) and machine learning technologies, chatbots have demonstrated significant potential and have made substantial contributions across several fields (Haque and Rubya, 2023; Xu et al., 2021; Suppadungsuk et al., 2023). In particular, the emergence of ChatGPT, with its harnessing of generative models, has heightened global awareness of the vast of generative AI (Sallam, 2023). As this technology continues to evolve, this section aims to offer a comprehensive of the recent advances in LLMs within the realm of biotechnological pharmaceutics.

Schematic representation of the ChatGPT-assisted drug addiction research process. (This process initiates with grasping the roles of AI in drug addiction research and generating drug-like molecules. It advances by refining the GNC model to produce leads targeting DAT, NET, and SERT receptors. Optimization is driven by the Langevin equation and an enhanced GNC model, prioritizing binding affinity predictions, which led to 15 potential drug leads pinpointed. ChatGPT supports this process by offering creative input, methodological insights, and coding aid, from debugging to interpretation).

Schematic of a GRU-enhanced autoencoder for drug design: from SMILES encoding to cocaine addiction treatment leads. (The molecular generation pipeline uses a GRU-based autoencoder to encode and decode SMILES strings, and the stochastic generator was used to create novel molecules. The process starts from input SMILES through latent space manipulation to generated SMILES. Subsequently ADMET screening and binding affinity prediction were achieved for the identification of potential cocaine addiction treatment leads).

The study flowchart to predict and explain drug-drug interactions with ChatGPT.

T Overview of the benchmark MultiMedQA, PaLM and Med-PaLM. (Various medical question-answering datasets are integrated into a multimodal framework, which would improve the performance of PaLM through prompting and instruction tuning for clinical applications).

The workflow of MolReGPT. (This figure illustrates a four-step process for generating molecular captions and text-based molecular designs. Initially, it retrieves examples from a database using molecular information. Subsequently, it curates prompts with system instructions for tasks like molecular captioning and generation. In the third phase, it uses a few examples to facilitate a language model learn and generate responses. Finally, it calibrates the generation to ensure the responses are accurate and in the correct format for tasks like Mol2Cap, where it describes molecules).

The workflow of Chemformer. (It shows a two-step process for training a molecular model. In Step 1, the model is pre-trained on 100 million molecules, where it learns to encode and decode molecular structures. In Step 2, the model is fine-tuned for specific tasks, such as predicting reactions, optimizing molecules, and estimating molecular properties. Each task uses an encoder to understand the molecule and a decoder to generate the result).

The architectural structure of MolGPT.

The architectural structure of MOLGEN. (In Step 1, the model learns molecular language syntax and meaning by encoding and decoding molecular structures. In Step 2, the model is fine-tuned with domain-agnostic molecular prefixes to improve the capability of understanding molecular structures. In this process, a self-feedback paradigm was included, where the model is capable of generating candidates, evaluating them based on properties, and learns from the feedback to enhance the performance for generating synthetic and natural product molecules).

The architectural structure of KV-PLM. (The workflow of KV-PLM starts with internal molecular structure serialization into SMILES format, then the Meta-knowledge mapping is utilized to correlates molecular features to human intelligence. External biomedical text would subsequently be fused with molecular data. The language model pre-training would empower the model with the ability to predict molecular properties. It enables knowledgeable machine reading across different molecular properties (e.g., molecular structure, chemical properties, natural language documentation, and structured biomedical knowledge), which would facilitate tasks like description generation, property prediction, and knowledge extraction).

The workflow of MolT5. (MolT5 is trained in two steps (Sadybekov and Katritch, 2023): in pre-training, it learns from public data such as the chemical formulas and reactions (Murray et al., 2023). In fine-tuning, it specializes in tasks like creating molecule descriptions and generating new molecules).

The pipeline of Text + Chem T5. (Text + Chem T5 is capable of dealing with both text and chemistry information, which has a text encoder and a chemistry encoder that work together to understand inputs from different domains. The model is capable of understanding a chemical structure and generate a description for it, or it could receive a description and generate the chemical structure in SMILES format).

A four-step process of Mol-Instructions for creating and refining molecular descriptions and data. [(Sadybekov and Katritch, 2023) human and AI work together to generate task descriptions about molecules (Murray et al., 2023); information about molecules is gathered from data sources and formatted for AI (Cova et al., 2022); biological data is turned into text using templates, such as description of the functions of a specific protein (Roggia et al., 2024); the quality of molecules and proteins is checked].

Outline of the ConPLex model architecture and training framework (In step (Sadybekov and Katritch, 2023), a pre-trained protein language model and a circular fingerprint method are used to analyze molecular structures. In step (Murray et al., 2023), embedding layers process the molecular data, creating a numerical representation. In step (Cova et al., 2022), the model undergoes a series of binary and contrastive epochs to update and refine the learning rate and margin for improved accuracy in predicting molecular interactions).

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.1 ChatGPT

The chat generative pretrained transformer (ChatGPT), developed by OpenAI, stands at the forefront of language model-based chatbots, renowned for its conversational interactivity (https://openai.com/blog/chatgpt). On 14 March 2023, an upgraded version, GPT-4, was launched, which boasts improved capabilities for addressing complex issues with heightened precision and rationality. Furthering its progression, on 6 November 2023, the state-of-the-art model, GPT-4 Turbo, was introduced. This iteration is marked by its superior performance, an updated knowledge cutoff date of April 2023, and the introduction of a 128k context window, equating to the processing capacity of approximately 300 pages of text within a single prompt. Utilizing a neural network to process natural language, it is adept at generating contextually relevant responses and delivering nuanced, sophisticated answers through advanced modeling techniques (Brown et al., 2020).

Generally, ChatGPT can be harnessed in the following capacities. Primarily, ChatGPT serves as an intuitive interface a that facilitates more straightforward interactions between users and various AI systems, offering an alternative to traditional knowledge graph navigation. Indeed, it has emerged as a leading example of sophisticated human–computer interaction (HCI). Secondly, ChatGPT can be specifically applied for drug discovery, functioning as an advanced search engine tailored to the nuances of biological science in different ways (Savage, 2023). For rational drug design, ChatGPT could be used to generate innovative chemical structures with a high potential for clinical success and predict the absorption, distribution, metabolism, excretion, and toxicity (ADMET) profiles of the identified compounds (Savage, 2023; Zhao and Wu, 2023). Within this domain, efficient screening can be performed with ultra-large virtual libraries (greatly expanded drug-like chemical spaces), which would significantly amplify the drug-like chemical spaces and enhancing the probability of hit identification and lead discovery. Thirdly, ChatGPT holds promise in the generation of new protein targets for drug development. When equipped with extensive unlabeled data (e.g., the nearly 250 million protein sequences contained in the UniProt database and 1.28 million protein sequences contained in the PDB database), ChatGPT can autonomously deduce the intricate relationships between molecular building blocks on its own. In this field, its functionality mirrors that of AlphaFold, which depends heavily on (new) big data analytics and artificial intelligence for its operations.

In a study by Wang et al. (2023a), ChatGPT was successfully applied for the discovery of an anti-cocaine-addiction drug, which functions as a virtual guide offering strategic and methodological insights, as well as generative models for optimal drug-like molecules with desired properties (Figure 1). With the aid of ChatGPT, a novel platform named the Stochastic Generative Network Complex (SGNC) was developed. With this project, ChatGPT primarily serves for idea generation, methodology clarification, and coding assistance (Figure 2). For idea generation, ChatGPT was augmented with three plugins (WebPilot, ScholarAI, and AskYourPDF), which improves its capacity to comprehend the research background of anti-cocaine-addiction drug development, providing up-to-date available sources and accessing insights from previous works. For methodology clarification, plugins (WebPilot, Link Reader and Wolfram) were used to significantly improve the mathematical and statistical capabilities of ChatGPT. In terms of coding assistance, WebPilot, ChatwithGit, and Prompt Perfect were leveraged to refine coding skills and craft perfect prompts.

ChatGPT has been instrumental in successful identification of 15 promising drug leads capable of targeting the dopamine transporter (DAT), norepinephrine transporter (NET), and serotonin transporter (SERT). It was clearly indicated that the “cognitive abilities” of ChatGPT have the potentials to significantly streamline the development of modern pharmaceuticals offering potential promising avenues for drug discovery. However, it was also noted that the application of ChatGPT for drug development still faces many challenges due to the inherent limitations of generative AI. For example, it is still susceptible to generate false narratives and spread misinformation. Consequently, it is recommended that the information generated by ChatGPT-4 undergo rigorous and consistent verification to ensure its accuracy and reliability.

Mondal et al. explored the proficiency of ChatGPT in predicting and elucidating common drug-drug interactions (DDIs) (Figure 3) (Juhi et al., 2023). Initially, a curated set of 40 pairs of previously listed DDIs were selected for analysis via ChatGPT through a two-tiered questioning approach. The outcomes showed that for the initial query, one response was incorrect, while of the correct responses, 19 were definitive and 20 remained ambiguous. For the second question, one answer was deemed incorrect, with 17 correct answers being definitive and 22 being inconclusive. These results suggest that ChatGPT serves as a moderately effective instrument for assessing DDIs; however, it occasionally falls short in offering comprehensive guidance, indicating the necessity for further refinements to enhance its accuracy and reliability.

Zhang et al. investigated the competencies of ChatGPT in the realms of question-answering, knowledge discovery, and knowledge reasoning within the biomedical field, specifically its ability to establish connections between pairs of proposed entities. The performance of ChatGPT was then compared with existing biomedical knowledge graphs (BKGs) (Hou et al., 2023). The findings indicated that ChatGPT-4.0 outperformed BKGs in terms of providing existing knowledge, although BKGs had a higher confidence level and demonstrated higher reliability in terms of information accuracy. Moreover, compared with BKGs, ChatGPT demonstrated a limited ability to perform novel discoveries based on the existing information and to provide reasoning for knowledge discovery. Therefore, the study proposed that strategies integrating LLMs (like ChatGPT) and BKGs could be promising to enhance task performance and mitigate potential risks.

Xu et al. delved into the prowess and promise of ChatGPT within the realm of biomedical information retrieval, with a particular focus on its ability to discern associations between drugs and diseases (Gao et al., 2023). Their findings showed that ChatGPT achieved an impressive accuracy range of 74.6%–83.5% in identifying drug-disease associations and an even more remarkable 96.2%–97.6% for true and false pairs under varying prompt designs. This revealed that ChatGPT could serve as a valuable “assistant” in unearthing knowledge related to biotechnological and pharmaceutical advancements, with a level of reliability that is quite satisfactory. Nevertheless, it was also emphasized that the insights gleaned from ChatGPT should undergo thorough verification before being integrated into clinical practice. In a separate study, ChatGPT was employed to meticulously annotate single-cell RNA sequencing data, successfully correlating rare cell types with their functions and uncovering several distinct differentiation pathways of cell subtypes that had previously eluded detection (Zehua and Du, 2023).

Blatz et al. demonstrated the transformative potential of ChatGPT and other LLMs in the field of dental medicine (Eggmann et al., 2023). It was concluded that LLMs (e.g., ChatGPT) could be instrumental in several areas (Sadybekov and Katritch, 2023): revolutionizing dental practice by streamlining administrative tasks (Murray et al., 2023); enhancing dental telemedicine through real-time language translation services, thereby making consultations more accessible and scalable, particularly in underserved regions (Cova et al., 2022); bolstering clinical decision support by swiftly summarizing voluminous medical records or aggregating evidence-based medical findings (Roggia et al., 2024); expediting administrative tasks such as routine correspondence and record-keeping (Pandey et al., 2022); enriching patient education with credible health advice and guidance (Jayatunga et al., 2022); advancing dental education through the creation and administration of multiple-choice exams, practical assessments, and supervised patient treatments; and (Chakraborty et al., 2023) refining scientific writing, making it more coherent for non-native English speakers. In addition, the study underscored the imperative to address several critical challenges effectively (Sadybekov and Katritch, 2023): ensuring robust cybersecurity measures to safeguard patient data and medical information against malware attacks (Murray et al., 2023); implementing stringent patient data privacy protections to maintain confidentiality and security; and (Cova et al., 2022) conducting thorough scientific evaluations and verifications of LLM-generated responses to maintain accuracy and reliability.

As highlighted in numerous studies, ChatGPT is poised to exert profound influences on various aspects of natural science and social science in the near future. On the one hand, it is imperative to recognize that at present, ChatGPT might not be a fully-fledged “sage” capable of providing responses replete with adequate reasoning and evidence-based justifications (Heck, 2023). Consequently, robust quality control protocols must be established to safeguard the accuracy, credibility, privacy, and cybersecurity of the swift and beneficial information dispensed by ChatGPT. On the other hand, there remains a critical need to improve the “intelligence” of ChatGPT, thereby transforming it into an indispensable asset for researchers.

Schematic representation of the ChatGPT-assisted drug addiction research process. (This process initiates with grasping the roles of AI in drug addiction research and generating drug-like molecules. It advances by refining the GNC model to produce leads targeting DAT, NET, and SERT receptors. Optimization is driven by the Langevin equation and an enhanced GNC model, prioritizing binding affinity predictions, which led to 15 potential drug leads pinpointed. ChatGPT supports this process by offering creative input, methodological insights, and coding aid, from debugging to interpretation).

Schematic of a GRU-enhanced autoencoder for drug design: from SMILES encoding to cocaine addiction treatment leads. (The molecular generation pipeline uses a GRU-based autoencoder to encode and decode SMILES strings, and the stochastic generator was used to create novel molecules. The process starts from input SMILES through latent space manipulation to generated SMILES. Subsequently ADMET screening and binding affinity prediction were achieved for the identification of potential cocaine addiction treatment leads).

The study flowchart to predict and explain drug-drug interactions with ChatGPT.

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.2 Google bard and microsoft bing

Bard AI, a cutting-edge large language model developed by Google, signifies a new frontier in the field of AI-powered chatbots (Pichai, 2023). Propelled by the Language Model for Dialogue Applications (LaMDA, a state-of-the-art transformer-based neural language model), Bard is honed on an expansive dataset, ensuring its proficiency in conversational AI. Sharing a repertoire of capabilities with ChatGPT, Google Bard has demonstrated its efficacy across a spectrum of scientific applications, marking it as a formidable contender in the landscape of advanced AI technologies.

Sulaiman et al. conducted a study to assess proficiency of Google Bard in critically evaluating DDI screening, and it was subsequently compared with the authorized Lexicomp® Online™ database (Sulaiman et al., 2023). The interrater reliability analysis revealed a minimal concordance between Lexicomp and Google Bard in assessing DDI risk, with a Cohen’s kappa (κ) value of 0.01; similarly, a slight agreement between was observed in their severity ratings (κ = 0.02). However, there was a lack of consensus regarding the reliability rate, reflected by a κ value of −0.02. In a parallel study, AI platforms (ChatGPT, Bard, and Bing) were applied for DDI the prediction, and the sensitivity, specificity, and accuracy of each model were subsequently evaluated (Al-Ashwal et al., 2023). Notably, Microsoft Bing emerged as the top performer in terms of specificity (0.769) and accuracy (0.788). Furthermore, ChatGPT-3.5 and ChatGPT-4 exhibited the greatest variability in the consistency of their accuracy, highlighting the nuances in their predictive capabilities.

Cheungpasitporn et al. conducted a comparative analysis of the performance of various AI models (ChatGPT 3.5, ChatGPT 4, Bard AI, and Bing Chat) in identifying potassium and phosphorus content in foods (Qarajeh et al., 2023). The study revealed that ChatGPT 4 outperformed others in determining potassium content, achieving an overall accuracy of 81%, with specific rates of 60% for low-potassium foods and an impressive 99% for high-potassium foods. Comparatively, ChatGPT 3.5, Bard AI and Bing Chat showed accuracies of 66%, 79% and 81% accuracy, respectively. In the realm of phosphorus content identification, Bard AI stood out with a perfect 100% accuracy rate; in contrast, ChatGPT 3.5, ChatGPT 4 and Bing Chat managed to correctly identify high-phosphorus foods only 85%, 77% and 89% of the time, respectively. These findings illustrate the promising potential of AI-powered models in supporting renal diet management, particularly as adjunct tools for enhancing nutritional education and counseling. Nonetheless, it is evident that further enhancements are essential to achieve the desired levels of precision and reliability.

Tham et al. evaluated the proficiency of ChatGPT-3.5, ChatGPT-4.0, and Google Bard in generating accurate responses to inquiries concerning myopia (Beutel et al., 2023). Frequently asked myopia care-related questions were categorized into six different domains and allocated to the AI models. The responses generated were subsequently reviewed independently by three expert ophthalmologists, who graded them as poor, borderline, or good. A consensus approach was then used to establish the final assessment of each reply. The results showed that ChatGPT-4.0 outperformed in terms of accuracy, with 80.6% of the responses deemed ‘good’, surpassing 54.8% for Google Bard (Google Bard: 4.35 and ChatGPT-4.0: 4.23). All the models showed high average comprehensiveness scores and significant self-correction capabilities (66.7% for ChatGPT-4.0% and 60% for Google Bard). This highlighted the potential of ChatGPT-4.0 and Google Bard to deliver essential answers to myopia-related queries, although it is clear that their accuracy requires further enhancement and rigorous evaluation.

In a recent investigation, the capacity of ChatGPT and Google Bard to generate professional-quality responses to inquiries regarding ocular symptoms were systematically examined (Pushpanathan et al., 2023). The answers procured were meticulously appraised and graded by ophthalmologists at the consultant level, based on criteria of accuracy, comprehensiveness, and self-awareness. ChatGPT-4.0 achieved an impressive ‘good’ rating of 89.2%, significantly outperforming Google Bard, which registered at 40.5%. Although all the models garnered high mean comprehensiveness scores, they were concurrently found to display inadequate self-awareness capabilities. Parallel results were also observed in the accuracy of ChatGPT and Google Bard when addressing clinical radiology challenges on the Japan Radiology Board Examination (JRBE) (Toyama et al., 2023).

Therefore, although ChatGPT-4.0 demonstrated a distinct advantage in providing logical answers to a broad spectrum of inquiries, rigorous validation remains essential to ensure reliability and accuracy. In the context of research writing and data collection, it is worth noting that while Bard represents a modest improvement over ChatGPT (ChatGPT3.5) in analyzing the diversity of manuscript bibliographies, it still falls short of reference identification capabilities, even with its integration with Google search (King, 2023).

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.3 Med-PaLM

Recently, Google and DeepMind introduced MultiMedQA, which is a comprehensive collection of seven medical question-answering datasets (Figure 4), including LiveQA, MedQA, MedMCQA, MedicationQA, PubMedQA, HealthSearchQA, and MMLU clinical topics (Singhal et al., 2023). Utilizing MultiMedQA as a foundation, both the pathway language model (PaLM) (Chowdhery et al., 2022) and its instruction-tuned derivative, Flan-PaLM, were subjected to rigorous examination (Chung et al., 2022). The results showed that Flan-PaLM excelled in achieving the highest historical accuracy on the aforementioned datasets. Notably, Flan-PaLM scored an impressive 67.6% accuracy on MedQA (US Medical Licensing Exam-style questions), surpassing the previous state of the art by over 17%. These results prompted the implementation of prompt tuning to further specialize Flan-PaLM for the medical domain, resulting in the Med-PaLM model. Med-PaLM was capable of providing more favorable answers to the medical queries than clinicians, although its overall performance was still somewhat inferior to that of medical professionals. This demonstrated the effectiveness of instruction prompt tuning in improving the performance of Med-PaLM.

However, the study also identified limitations and proposed future research direction. These include expanding MultiMedQA to better mirror real-world clinical workflows, developing key LLM capabilities for numerous clinically significant applications, refining human evaluation, and addressing issues of fairness, equity, and ethical considerations.

T Overview of the benchmark MultiMedQA, PaLM and Med-PaLM. (Various medical question-answering datasets are integrated into a multimodal framework, which would improve the performance of PaLM through prompting and instruction tuning for clinical applications).

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.4 DrugChat

In a cutting-edge study, a pharmaceutical domain-specific LLM prototype, DrugChat, was developed to utilize ChatGPT-like capabilities for the analysis of drug compounds and the provision of insights on drug–molecule graphs (Liang et al., 2023). Like ChatGPT, DrugChat engages in multi-turn, interactive dialogues to address inquiries about uploaded compound molecule graphs. It is composed of three core components: a graph neural network (GNN), a large language model (LLM), and an adaptor, all of which are trained in an end-to-end fashion.

The GNN is tasked with interpreting the input compound molecule graph and extracting a meaningful representation. The adaptor then converts this graph representation into a format that is compatible with LLM. The LLM processes the transformed compound representation alongside the questions posed about the compound, ultimately generating answers.

For the instruction tuning phase, datasets comprising 10,834 drug compounds and 143,517 question-answer pairs were curated to train DrugChat. In this process, a pretrained GNN and a pre-trained Vicuna-13b model were utilized, with the weight parameters for the GNN and LLMs being fixed. However, the weight parameters for the adapter were continuously refined. The results demonstrated the proficiency of DrugChat in responding to various questions about the input compounds, such as “What makes this compound unique?” and “What diseases might this compound be able to treat?”, even when evaluated on the drug compound graphs not present in the training data.

However, as highlighted, the most significant challenge for DrugChat could be the phenomenon of “artificial (molecular) hallucinations” stemming from the implanted LLMs. The generation of unreliable answers and descriptions could seriously impede its practical application in drug discovery, potentially leading to undesirable consequences.

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.5 MolReGPT

Recently, a groundbreaking LLM-based system known as MolReGPT has been developed, which showcases the ability to translating molecule captions into natural language (Li et al., 2023). This system employs a retrieval-based prompt paradigm through in-context learning for both molecule captioning and text-based molecule generation. This could potentially revolutionize molecule discovery with MolReGPT without the need for fine-tuning. MolReGPT is structured around four principal components (Figure 5), including molecule caption retrieval (identifying the n most analogous examples), prompt management (constructing the system prompt), in-context few-shot molecule learning (translating molecule caption), and generation calibration (assessing validity). For the task of molecule caption retrieval, MolReGPT leverages Morgan fingerprints for molecule captioning and BM25 for text-based molecule generation. Prompt management encompasses four key steps: role identification, task description, example generation, and instruction output.

The results indicated that MolReGPT surpasses the performance of the tested fine-tuned models (e.g., MolT5-base) without any additional fine-tuning, achieving Text2Mol scores of 0.560 for molecule captioning and 0.571 for molecule generation. In terms of molecule understanding and text-based molecule generation, MolReGPT is comparable to the fine-tuned model MolT5-large. These findings suggest that MolReGPT could provide an innovative and adaptable platform for harnessing the potential of LLMs to advance molecule discovery through in-context learning, which might greatly reduce the cost associated with domain transfer.

The workflow of MolReGPT. (This figure illustrates a four-step process for generating molecular captions and text-based molecular designs. Initially, it retrieves examples from a database using molecular information. Subsequently, it curates prompts with system instructions for tasks like molecular captioning and generation. In the third phase, it uses a few examples to facilitate a language model learn and generate responses. Finally, it calibrates the generation to ensure the responses are accurate and in the correct format for tasks like Mol2Cap, where it describes molecules).

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.6 Chemformer

To tackle the resource-intensive challenge and multitasking demands in cheminformatics, a transformer-based model named Chemformer has been introduced, leveraging SMILES notation (Irwin et al., 2022). Chemformer, which is based on the BART language model, is versatile and can be readily applied to diverse tasks, such as sequence-to-sequence (e.g., reaction prediction and molecular optimization) and discriminative cheminformatics (e.g., property prediction) tasks, with the encoder stack alone being sufficient for many of these applications.

The training of Chemformer primarily consists of two stages (Figure 6): self-supervised pretraining and downstream fine-tuning. In the pretraining phase, extensive unlabeled SMILES datasets are used for model training through three different self-supervised pretraining tasks (masking, augmentation and a combination of masking and augmentation). During the fine-tuning phase, the pretrained Chemformer is tailored to a specific downstream task and further refined. A multitask learning strategy is utilized in this process to optimize multiple tasks concurrently, such as multiproperty prediction and multigene activity prediction. In particular, Chemformer has achieved the highest accuracy available on benchmark datasets for direct synthesis and retrosynthesis prediction.

The outcomes for chemical reaction prediction, molecular optimization and property prediction demonstrate the adaptability of Chemformer to various downstream tasks. The convergence rate and performance of Chemformer on downstream tasks could be improved by self-supervised pretraining. When training time is limited, the synergy of transfer learning and the innovative augmentation strategy can produce state-of-the-art results across all the tested downstream Seq2seq tasks, including chemical reaction prediction and molecular optimization.

The workflow of Chemformer. (It shows a two-step process for training a molecular model. In Step 1, the model is pre-trained on 100 million molecules, where it learns to encode and decode molecular structures. In Step 2, the model is fine-tuned for specific tasks, such as predicting reactions, optimizing molecules, and estimating molecular properties. Each task uses an encoder to understand the molecule and a decoder to generate the result).

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.7 MolGPT

To develop a generative pretraining (GPT) model adept at generating chemical structures with tailored properties or synthesizing drug-like molecules, a transformer-decoder-based generative model named MolGPT has been proposed (Bagal et al., 2022). MolGPT is comprised of three principal components (Figure 7): the input encoder, transformer-decoder model, and output decoder. The input encoder translates target molecules represented in the Simplified Molecular Input Line Entry System (SMILES) notation into a string of characters. The transformer-decoder model is comprised of multiple transformer modules and a single decoder module. Each transformer module features a multi-head masked self-attention mechanism calculated by the “Scaled Dot Product Attention”, and a feed-forward network designed to capture contextual information of the input sequence. The decoder module employs both self-attention and an encoder-decoder attention mechanism to generate the subsequent SMILES token. The output decoder then translates the generated SMILES string into a molecular structure. In this process, the resultant molecules can be generated based on desired single or multiple properties, a specified scaffold, or a combination of both.

Benchmarking experiments for training and evaluation demonstrated that MolGPT boasts exceptionally high validity and uniqueness scores, along with commendable Frechet ChemNet Distance (FCD) and KL divergence scores for the MOSES and GuacaMol datasets. Moreover, in terms of validity and novelty, MolGPT outperformed all the other tested methods for the GuacaMol dataset. In addition, MolGPT was found to acquire higher-level chemical representations through molecular property control, enabling the generation of molecules with intriguing properties or specified scaffolds. Based on these results, MolGPT is poised to play a critical role in the realm of rational drug design.

In a recent advancement, a conditional generative pretrained transformer model, cMolGPT, was designed for the autoregressive generation of target-specific de novo molecules using natural language processing (NLP) techniques (Wang et al., 2023b). This model was initially pretrained on an extensive SMILES dataset, enabling it to learn the parametric probabilistic distribution of drug-like properties (e.g., LogP and molecular weight), across the SMILES vocabulary space in an unsupervised manner. The cMolGPT model incorporates a of key-value pairs within the transformer architecture, which is further enforced by target-specific embeddings to facilitate the conditional generation of multihead attention for drug-like compounds. The findings revealed that cMolGPT is adept at generating SMILES strings that represent both drug-like and active compounds. In addition, the generated compounds not only closely resemble the chemical space of actual target-specific molecules but also encompass a significant portion of novel compounds. To assess the performance in generating target-specific compounds, evaluations were conducted on three target-biased datasets: EGFR, HTR1A, and S1PR1. The compounds generated by cMolGPT were predicted to exhibit higher activity compared to those generated by the tested conditional RNN models. This suggests that cMolGPT is a promising tool in the field of drug discovery, capable of expanding the chemical space of potential therapeutic agents.

To encapsulate the findings, it is evident that a transformer-decoder-based generative model could achieve state-of-the-art performance in the rational design and discovery of desired chemical structures. Consequently, such a model is regarded as an invaluable asset in the realm of de novo drug design, showcasing its potential to revolutionize the way we approach the development of novel therapeutics.

The architectural structure of MolGPT.

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.8 MOLGEN

To synthesize molecules with specific desired attributes, MOLGEN, a sophisticated pretrained molecular language model, has been recently introduced (Fang et al., 2023b). This system encompasses two pivotal stages (Figure 8): (Sadybekov and Katritch, 2023) a two-stage domain-agnostic molecular pretraining and (Murray et al., 2023) a self-feedback mechanism designed to mitigate the occurrence of “molecular hallucinations”. During the initial phase, the system reconstructs over 100 million molecules using SELFIES, a highly robust molecular language. This approach is complemented by the introduction of the domain-agnostic molecular prefix, which improves the transferability of the knowledge across diverse domains. The subsequent stage introduces a self-feedback paradigm, which is instrumental in fine-tuning the model’s parameters in accordance with generative probabilities, thereby incrementally refining the optimization of the generated molecules. This mechanism is pivotal in enabling MOLGEN to produce molecules with desired properties while circumventing the pitfalls of “molecular hallucinations”.

The efficacy of MOLGEN was subjected to a rigorous evaluation through extensive testing on established benchmarks. The assessments focused on its ability to accurately capture molecular distributions, generate diverse and realistic molecules, pinpoint targeted molecules and refine molecules under constraints. Across the domains of natural products and synthetic molecules, MOLGEN has consistently its proficiency in generating molecules that align with desired chemical preferences (e.g., logP (octanol–water partition coefficient), QED (quantitative estimate of drug likeness). Moreover, it has demonstrated a notable potential for identifying essential molecular substructures and navigating the chemical space, highlighting its value in the realm of molecular design and drug discovery.

The architectural structure of MOLGEN. (In Step 1, the model learns molecular language syntax and meaning by encoding and decoding molecular structures. In Step 2, the model is fine-tuned with domain-agnostic molecular prefixes to improve the capability of understanding molecular structures. In this process, a self-feedback paradigm was included, where the model is capable of generating candidates, evaluating them based on properties, and learns from the feedback to enhance the performance for generating synthetic and natural product molecules).

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.9 KV-PLM

Recognizing the limitations of current machine reading models, which tend to handle various data types separately, a significant divide often emerges between the nuanced interpretation of molecular structures and the absorption of knowledge from biomedical literature. To address this, Recently, a groundbreaking machine reading system known as KV-PLM has been introduced. It is designed to seamlessly integrate molecular structure data with biomedical text within a single deep learning architecture (Figure 9) (Zeng et al., 2022). The KV-PLM leverages the pretrained language model BERT12 as its foundational component. It employs the simplified molecular-input line-entry system (SMILES) to encode molecular structures into a format compatible with the byte pair encoding (BPE) algorithm. This encoding process transforms SMILES strings into a series of substring patterns. These patterns are then integrated into a comprehensive biomedical data and subjected to pretraining under a unified language modeling framework. The culmination of this process is the acquisition of meta-knowledge through a self-supervised language model, which can be efficiently adapted through fine-tuning for specific application within the biomedical domain.

To evaluate the efficacy of KV-PLM, a range of mono-source biomedical tasks were conducted, encompassing both molecular structure-related and biomedical text-related tasks. The system’s performance was benchmarked on MoleculeNet for SMILES property classification across datasets such as BBBP, SIDER, TOX21, and HIV, as well as for chemical reaction classification was evaluated on USPTO 1k TPL dataset. Additionally, the system was evaluated on biomedical named entity recognition (NER) and the relation extraction (RE) task using BC5CDR and ChemProt. The results indicated that KV-PLM model not only outperformed other model in these tasks but also demonstrated an ability to engage in knowledgeable and versatile reading.

Moreover, the system’s proficiency in versatile reading tasks involving “cross-information retrieval”, “match judging”, and “human professional performance” was confirmed. KV-PLM excelled in these versatile tasks, notably in facilitating effective cross retrieval between substances and property descriptions. These capabilities highlight the immense potential of KV-PLM in the realms of novel drug discovery and molecular property prediction, offering researchers a tool to gain a holistic and in-depth comprehension of molecular entities.

The architectural structure of KV-PLM. (The workflow of KV-PLM starts with internal molecular structure serialization into SMILES format, then the Meta-knowledge mapping is utilized to correlates molecular features to human intelligence. External biomedical text would subsequently be fused with molecular data. The language model pre-training would empower the model with the ability to predict molecular properties. It enables knowledgeable machine reading across different molecular properties (e.g., molecular structure, chemical properties, natural language documentation, and structured biomedical knowledge), which would facilitate tasks like description generation, property prediction, and knowledge extraction).

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.10 MolT5

To facilitate efficient communication between molecules structures and natural language, and to address challenge of limited data, Molecular T5 (MolT5), a self-supervised learning framework, was developed (Edwards et al., 2022). This framework employs a transformer-based architecture (Figure 10), leveraging the T5 that has been pretrained text-to-text model, enabling the simultaneous processing of vast amounts of unlabeled natural language text and molecular string data for pre-training purposes. In pursuit of this objective, two new tasks were introduced and formalized: molecular language tasks, specifically molecule captioning, and text-guided de novo molecule generation. Although these molecule–language tasks share similarities with vision–language tasks, there present distinct challenges, particularly the increased complexity of molecular captioning due to the diverse range of possible languages used for captioning. The performance of MolT5 was rigorously assessed using a suite of evaluation metrics, including BLEU, ROUGE, and METEOR, as well as a newly developed cross-modal retrieval similarity metric, the Text2Mol metric. When evaluated against the ChEBI-20 dataset using both the Text2Mol metric and BLEU metric, MolT5 achieved superior scores and outperformed RNNs and transformers in the two newly defined tasks. Notably, the performance of MolT5 further improved as the language model size increased.

MolT5 pretrains models on single-modal data, effectively mitigating the issue of data scarcity within the chemical domain. Furthermore, a variety metrics were also adopted including a new cross-modal embedding-based metric, to evaluate the performance of molecule captioning and text-based molecule generation. Results show that MolT5-based models are capable of generating high-quality outputs, encompassing both molecules and captions, in numerous instances.

As previously mentioned, the effective deployment of MolT5 poised to bolster the application of molecular AI, empowering researchers to uncover potential drug candidates by engaging with AI through natural language interactions and acquiring target chemical structures with specific functional attributes rather than relying solely on their properties. However, it is imperative to pay close attention to the potential biases introduced by the training dataset, the SMILES strings utilized, and the authenticity of the compounds listed in ChEBI-20.

The workflow of MolT5. (MolT5 is trained in two steps (Sadybekov and Katritch, 2023): in pre-training, it learns from public data such as the chemical formulas and reactions (Murray et al., 2023). In fine-tuning, it specializes in tasks like creating molecule descriptions and generating new molecules).

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.11 Text + Chem T5

To bridge the gap between human‒machine interactions and establish a cohesive framework for natural language and chemical representations, the first multidomain, multitask language model, Multitask Text and Chemistry T5 (Text + Chem T5 (Figure 11), https://github.com/GT4SD/gt4sd-core), was developed (Christofidellis et al., 2023). This model excels in managing both chemical and natural languages in parallel, outperforming others in cross-domain tasks across a broad spectrum of NLP-based evaluation metrics. Moreover, it negates the need for costly mono-domain pretraining and task-specific models. The capabilities of Text + Chem T5 was rigorously assessed across a range of tasks, including the predictions of forward and reverse chemical reactions, the generation of text-conditional novel molecules, the captioning of molecules spanning various domains, and execution of paragraph-to-action tasks within the linguistic domain. The findings underscored the effectiveness of Text + Chem T5 as a versatile multidomain and multitask model, adept at generating precise and enlightening captions (with a BLEU-2 score of 0.625, a Rouge-1 score of 0.647 and a Rouge-2 score of 0.498) and adeptly translating between natural language and the SMILES representation of molecules in both text-to-chemistry and chemistry-to-text endeavors.

In particular, Text + Chem distinguishes itself by its capacity to navigate complex drug discovery workflows, such as a hypothetical molecular discovery process, with a unified model. In this study, Text + Chem T5 uniquely succeeded in generating the desired molecule for the “text-to-SMILES task”, provide a synthetic route identical to the target reaction for “retrosynthesis”, and conceptually succeed in identifying and proposing an extremely similar reaction in a chemistry laboratory for a “paragraphs to actions” task. This fascinating capability, previously uncharted, positions Text + Chem T5 as superior even to established models such as ChatGPT and Galactica 1.3B.

The paramount advantage of Text + Chem T5 lies in its multifaceted task management. As indicated in this manuscript, Text + Chem is poised for targeted application across a variety of fields, such as chemical reaction prediction and retrosynthesis, significantly and efficiently bolstering modern drug development discovery in the physical sciences. It streamlines these processes by circumventing the need for task-specific fine-tuning and enhancing human–model interactions.

The pipeline of Text + Chem T5. (Text + Chem T5 is capable of dealing with both text and chemistry information, which has a text encoder and a chemistry encoder that work together to understand inputs from different domains. The model is capable of understanding a chemical structure and generate a description for it, or it could receive a description and generate the chemical structure in SMILES format).

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.12 Mol-Instructions

Recently, a novel LLM named Mol-Instructions has been introduced, specifically crafted to address the complexities of biomacromolecules, particularly those relevant to structural biology (Fang et al., 2023a). This model encompasses a comprehensive instruction dataset that is segmented into three pivotal components (Figure 12). (Sadybekov and Katritch, 2023) Molecule-oriented instructions, which delve into the inherent properties and behaviors of small molecules essential for chemical reactions and molecular design (Murray et al., 2023); protein-oriented instructions, which are geared towards predicting the structures, functions, and activities of proteins for protein design; and (Cova et al., 2022) biomolecular text instructions, which engage in natural language processing (NLP) tasks that are integral to the fields of associated with bioinformatics and cheminformatics.

As shown in Figure 12, Mol-Instructions demonstrates great potential in biomolecular studies. In particular, Mol-Instructions could be applied in three major areas (Sadybekov and Katritch, 2023): assessment of cross-modal comprehension, which involves the integration of different types of data to enhance understanding of biomolecular systems (Murray et al., 2023). Exploration of deeper biomolecular design, enabling the development of more sophisticated and effective molecular structures (Cova et al., 2022). Tool learning to address complex biological challenges, leveraging advanced computational methods to address intricate biological questions. Mol-Instructions stands as a significant advancement in the integration of computational linguistics and molecular biology, offering a multifaceted approach to understanding and manipulating biomacromolecules.

A four-step process of Mol-Instructions for creating and refining molecular descriptions and data. [(Sadybekov and Katritch, 2023) human and AI work together to generate task descriptions about molecules (Murray et al., 2023); information about molecules is gathered from data sources and formatted for AI (Cova et al., 2022); biological data is turned into text using templates, such as description of the functions of a specific protein (Roggia et al., 2024); the quality of molecules and proteins is checked].

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.13 ConPLex (https://ConPLex.csail.mit.edu)

Recently, a sophisticated deep learning model known as ConPLex has been successfully developed for the sequence-based prediction of drug-target interactions with remarkable accuracy, broad adaptivity, and specificity (Singh et al., 2023). ConPLex boasts a competitive edge due to the innovative integration of pretrained protein language models (“PLex”, for lexicographic pretraining) and protein-anchored contrastive coembedding (“Con”, for contrastive learning) (Figure 13). The “PLex” component is capable of alleviating challenges posed by limited DTI training data, while the “Con” aspect effectively maps target proteins and drugs into a unified latent space, ensuring distinct separation between true interacting partners. Consequently, ConPLex enables more accurate predictions of DTIs by leveraging the distance within the learned representations, even when dealing with massive compound libraries and the expansive human proteome.

The experimental results have demonstrated the model’s efficacy in successfully predicting the tested kinase-drug interactions, with 12 out of 19 pairs showing K D values less than 100 nM, including four with subnanomolar affinity and an efficient EPHB1 inhibitor (PD-166326, K D = 1.3 nM). Beyond its broad generalizability and high specificity, ConPLex enhances interpretability, rendering the drug-target embedding space and the functions of human cell-surface proteins more transparent. In addition to the in silico screening of small-molecular-weight compounds, ConPLex holds potential for screening other drugs types, such as antibodies, and for toxicity prediction.

Given these significant advantages, ConPLex is anticipated to revolutionize in silico drug screening at the genomic scale and to accelerate the development of innovative drugs in modern pharmaceutical research.

Outline of the ConPLex model architecture and training framework (In step (Sadybekov and Katritch, 2023), a pre-trained protein language model and a circular fingerprint method are used to analyze molecular structures. In step (Murray et al., 2023), embedding layers process the molecular data, creating a numerical representation. In step (Cova et al., 2022), the model undergoes a series of binary and contrastive epochs to update and refine the learning rate and margin for improved accuracy in predicting molecular interactions).

## Section: 2 Designing an artificial intelligence-driven platform › 2.2 Deep learning for macromolecular drugs (protein structure prediction)

Protein structures are traditionally elucidated through experimental techniques such as by X-ray crystallography, nuclear magnetic resonance (NMR) and electron cryomicroscopy (cryo-EM), which are known for their precision. However, these methods are complex, time-consuming, and costly, which limits their widespread application. In light of these constraints and the growing need for novel protein structures, there has been a surge in interest in innovative strategies, particularly bioinformatics approaches to obtain novel protein structures. Despite the promise of these methods, they still necessitate considerable experimental effort.

The model architecture of ComplexQA with the deep graph convolution network. (ComplexQA is capable of molecular analysis that processes various molecular features through Conv1D blocks and integrates edge information using Conv2D blocks. Then applies graph convolutional networks (GCNs) with multiple blocks was used for feature aggregation and normalization. Finally, it concludes with the generation of a residue interface score to assess molecular interactions).

The workflow of ProteinMPNN. (ProteinMPNN is consisted of a backbone encoder that processes protein backbone coordinates and edge information, and a sequence decoder capable of generating protein sequences. Nodes and edges are updated in the encoder, and through iterative decoding, it produces a protein sequence with a calculated probability).

## Section: 2 Designing an artificial intelligence-driven platform › 2.2 Deep learning for macromolecular drugs (protein structure prediction) › 2.2.1 AlphaFold

AlphaFold, developed by DeepMind, has revolutionized protein structure prediction with unprecedented accuracy and reliability, harnessing the power of neural networks and homology modeling for protein model construction (Pandey et al., 2022). To extend the capabilities to predict protein complexes accurately and efficiently, AlphaFold-Multimer was introduced, expanding the capabilities of Alphafold2 to handle multiple chains (Yin et al., 2022). The latest version, AlphaFold3, has been successfully applied in various fields, including modeling of conventional protein structures and structures with novel folds, structural construction of artificial constructs and prediction of protein‒protein interactions. In particular, models generated by AlphaFold typically achieve TM-scores greater above 0.9, suggesting that both the overall fold and the details of the constructed models are theoretically correct (Skolnick et al., 2021). To date, AlphaFold DB (AlphaFold DB, https://alphafold.ebi.ac.uk) has provided open access to more than 214 million protein structure predictions (Varadi et al., 2023).

The exceptional performance of AlphaFold is largely attributed to the novel neural network architectures and specialized training regimens that incorporate evolutionary, physical and geometric constraints inherent to protein structures (Jumper and Hassabis, 2022). Alongside the simultaneous generation of multiple sequence alignments (MSAs) and pairwise features, two key modules, Evoformer and the structure module, play critical roles in protein structure development (Skolnick et al., 2021). Evoformer, a building block of a novel neural network, approaches predict protein structures as a graph inference problem, with graph edge defined by the proximity of residues. It consists of two specialized transformers for distinct data types: the MSA transformer and the pair representation transformer. The structure module is tasked with local side chain packing rearrangements, prioritizing the orientations of the protein backbone and residues, and positioning the side chains of different residues.

In a study utilizing the program Accuracy of NMR Structures Using RCI and Rigidity (ANSURR), the accuracy of AlphaFold-generated structures was compared to NMR structures (Fowler and Williamson, 2022). The results revealed that the AlphaFold models generally surpass NMR ensembles in accuracy, although there are scenarios, particularly those involving dynamic structures, where NMR ensembles may be more precise. This suggests that AlphaFold might display relatively low confidence in predicting dynamic structures. Consequently, it has been proposed that AlphaFold could be instrumental in refining NMR structure. Furthermore, structures generated by AlphaFold and subsequently validated by ANSURR are likely to satisfy application requirements, potentially eliminating the need for additional refinement processes.

## Section: 2 Designing an artificial intelligence-driven platform › 2.2 Deep learning for macromolecular drugs (protein structure prediction) › 2.2.2 MULTICOM

To enhance the precision of AlphaFold-Multimer in predicting complex structure (Zhu et al., 2023), a sophisticated quaternary structure prediction system (MULTICOM) has been developed (Liu et al., 2023b). It is capable of optimizing the inputs transformed into AlphaFold-Multimer, evaluating and refining the resulting outputs. It employs a dual approach, utilizing traditional sequence alignment and Foldseek-based structure alignment to generate MSAs and to identify templates for individual monomers. These MSAs for monomers are subsequently merged to form MSAs for multimers. Moreover, the structural predictions generated can be appraised using a suite of complementary metrics, and the refinement of structural predictions can be achieved through a Foldseek-based structure alignment strategy.

The results showed that the average TM-score for the initial predictions from MULTICOM for CASP15 assembly targets was ∼0.76, making a 5.3% increase over the standard AlphaFold-Multimer. The average TM-score for the top 5 predictions by MULTICOM was ∼0.80, which represents an 8% increase compared with the standard AlphaFold-Multimer. In addition, the Foldseek structure alignment-based multimer structure generation (FSAMG) method outperformed several prevalent sequences alignment-based multimer structure generation methods, such as NBIS-AF2-multimer predictions.

## Section: 2 Designing an artificial intelligence-driven platform › 2.2 Deep learning for macromolecular drugs (protein structure prediction) › 2.2.3 ComplexQA

In a cutting-edge study, a novel model quality assessment method, ComplexQA, has been introduced. This method leverages a deep graph neural network-based algorithm designed to assess the local quality of interfacial residues within protein complexes (Figure 14) (Zhang et al., 2023). It does so by analyzing a combination of sequence data, 3D structural information, and chemical properties. The process begins by converting the protein complex structures into undirected graphs, followed by the derivation of feature representation for each graph node. All the features, including the hidden features, are concatenated and used for graph learning purposes. To represent the edges of the graph, residue–residue features are acquired, primarily through two newly designed matrices: the adjacent matrix and the edge distance matrix. By integrating these two representations, the edge embedding features are generated, which are then employed for the subsequent edge convolution operations within the graph convolutional network block. This block further consists of two subblocks: one for edge convolution and another for node convolution. Finally, the output is transformed into a 1D convolutional layer, which employs a linear activation function to produce the final results. This sophisticated approach by ComplexQA offers a comprehensive evaluation of protein complex structures, enhancing our ability to understand and predict their quality.

In comparative evaluations across diverse datasets, ComplexQA outperformed the other leading algorithms (DProQA, GNN-DOVE, TRScore, GOAP, and ZRANK2). It also displayed commendable performance on challenging targets that featured a sparse number of acceptable models. Furthermore, ComplexQA is capable of delivering a detailed assessment of each interface residue, offering a level of precision that is invaluable in the field of protein complex structure analysis.

The model architecture of ComplexQA with the deep graph convolution network. (ComplexQA is capable of molecular analysis that processes various molecular features through Conv1D blocks and integrates edge information using Conv2D blocks. Then applies graph convolutional networks (GCNs) with multiple blocks was used for feature aggregation and normalization. Finally, it concludes with the generation of a residue interface score to assess molecular interactions).

## Section: 2 Designing an artificial intelligence-driven platform › 2.2 Deep learning for macromolecular drugs (protein structure prediction) › 2.2.4 ProtGPT2

ProtGPT2 (https://huggingface.co/nferruz/ProtGPT2), a cutting-edge autoregressive transformer model grounded in language-based principles, has been engineered to de novo construct protein structures with high throughput efficiency (Ferruz et al., 2022). The transformer was trained on an expansive dataset of ∼50 million non-annotated sequences from the UniRef50 (UR50) database, encompassing the full spectrum of protein diversity, thereby enabling it to learn and “comprehend” the intricacies of protein language in an autoregressive manner. In addition to the standard performance metrics, a suite of extrinsic tests was meticulously designed to assess the quality of the protein sequences generated by ProtGPT2.

The findings were compelling that ProtGPT2 demonstrated an impressive ability to generate sequences that, while remotely related to natural counterparts, also bore resemblance to known structural spaces. The generated proteins mirrored the natural amino acid propensities observed in their naturally occurring counterparts, with a notable predilection for globular structures, accounting for roughly 80% of the generated proteins. Moreover, sequences generated by ProtGPT2 were found to be only distantly related to those found in nature. When these results were integrated with similarity network analyses, it became evident that ProtGPT2 possesses the unique capability to explore and sample previously uncharted territories within the vast protein space.

## Section: 2 Designing an artificial intelligence-driven platform › 2.2 Deep learning for macromolecular drugs (protein structure prediction) › 2.2.5 ProteinMPNN

Recently, a novel deep learning-based protein sequence design strategy, ProteinMPNN, has emerged, demonstrating significant advantages in both in silico and experimental tests (Dauparas et al., 2022). This innovative approach is founded on the structured transformer framework (Figure 15), incorporating a message-passing neural network (MPNN) architecture that encompasses 3 encoder layers, 3 decoder layers and 128 hidden layers. ProteinMPNN was designed to predict target protein sequences in an autoregressive manner from the N- to C-terminus using protein backbone features as input data. The sequence recovery rate of the baseline model was approximately 41.2%, which was notably increased to more than 50% following a series of improvements. These enhancements were primarily focused on the following aspects (Sadybekov and Katritch, 2023): incorporating additional distance metrics between virtual Cβs (Murray et al., 2023), introducing an edge update mechanism (Cova et al., 2022), employing random sampling for the decoding order within the decoder (Roggia et al., 2024), integrating coding information regarding the relative position and chain number, and (Pandey et al., 2022) the incorporation of Gaussian noise to enhance model robustness.

The results were impressive, with ProteinMPNN demonstrating the ability to design sequences for monomers and cyclic oligomers with remarkable stability and precision. Most of the proteins produced by the MPNN were soluble (96 design sequences, 73 soluble). The crystal structures and the electron cloud density of the core side chain were highly consistent with the intended design structures. Similar successes were achieved in the design of proteins with cyclic and internal repeat symmetries as well as those incorporating polyproline II helix motifs.

ProteinMPNN achieved a sequence recovery rate of 52.4%, marking a 19.5% increase compared to that of Rosetta for native protein backbones, and even surpassed AlphaFold in this specific task. The running time was remarkably swift, averaging approximately one second. In particular, ProteinMPNN also enabled the coupling of amino acid sequences at various positions across single or multiple chains, further expanding its versatility and applicability in protein sequence design.

The workflow of ProteinMPNN. (ProteinMPNN is consisted of a backbone encoder that processes protein backbone coordinates and edge information, and a sequence decoder capable of generating protein sequences. Nodes and edges are updated in the encoder, and through iterative decoding, it produces a protein sequence with a calculated probability).

## Section: 3 Concluding remarks

AI has become an indispensable tool for addressing a multitude of societal challenges. The future of AI in drug development is set to be a landscape of innovation and efficiency, and it has been seeing a significant shift towards data-driven approaches, personalized medicine and clinical trials revolution. Take the AI-driven drug discovery and personalized medicines for examples. AI is expected to dominate drug discovery by making more accurate predictions of drug-target interactions and enhancing our understanding of disease physiopathology. AI models will be trained on larger biomedical datasets, including genomics, proteomics, and metabolomics, to identify novel drug candidates and optimize drug design. AI will continue to drive the growth of personalized medicines by leveraging Big Data to tailor treatments to individual patients. The ability to analyze genetic, environmental, and lifestyle data will lead to the development of highly personalized treatment plans. AI has the potential to revolutionize clinical trials by improving patient recruitment, monitoring, and data analysis. Advanced algorithms will enable the identification of suitable candidates based on genetic and phenotypic profiles, ensuring that trials are conducted with the most appropriate cohort of participants. Particularly noteworthy is the proliferation of AI algorithm programs, including DeepMind AlphaFold, Atomwise, Recursion Pharmaceuticals, BenevolentAI, and Insilico Medicine. These examples showcase the diverse integration of AI across the drug development spectrum, from the early stages of drug discovery to manufacturing processes and post-market surveillance. The future looks promising, with AI set to play a central role in making drug development more efficient, targeted, and personalized.

Nevertheless, the proliferation of LLMs ha as also sparked significant apprehensions, such as the phenomenon of “artificial hallucinations” (Beutel et al., 2023; Ji et al., 2022). The dissemination of AI-generated misinformation, fiction, or unsubstantiated claims poses a risk of misguiding unsuspecting users. To optimize benefits and mitigate risks, several key challenges must be surmounted to harness the full potential of LLMs (Sadybekov and Katritch, 2023). Transparency concerns. This is paramount for academic discourse surrounding generative AI. It is recommended that the judicious use of AI in scientific research be underscored and clearly articulated, as this could significantly bolster credibility (Tang et al., 2024). Therefore, tools and techniques that enhance the explain ability and interpretability of AI models are crucial. Moreover, the transparency in data governance is essential, providing insight into the quality and suitability of data used for training and inference in algorithmic decision-making. This includes documenting the origin of data, collection methods, and any preprocessing steps, which is crucial for identifying and mitigating potential biases (Murray et al., 2023). Combating AI hallucinations. AI hallucinations can occur due to several factors, including overfitting, training data bias/inaccuracy, and high model complexity. The foundation of preventing AI hallucinations lies in using high-quality, diverse training data that represents real-life scenarios without biases and errors. Moreover, regular validation using test datasets and human-in-the-Loop verification should also be instituted to preempt the spread of misinformation and to counteract biased responses. Finally, risk-based review systems and retrieval-augmented generation (RAG) might also be helpful in prioritizing and verifying the review of AI outputs (Cova et al., 2022). Dataset limitations. Owing to the nature of AI, the quality and scope of available data are pivotal to the design and practical application of AI models. There is a pressing need to focus on the quantity and quality of data, with larger and more diverse datasets being crucial for enhancing model performance (Roggia et al., 2024). Building trust in models. Trust is established through a combination of technical reliability, transparency, and alignment with user expectations. The factors that foster trust in models predominantly center on selecting the appropriate neural network architecture and molecular representations, alongside the advancement of innovative architectures imbued with inductive bias. For instance, recurrent neural networks (RNNs) are well-suited for sequential data due to their ability to maintain a form of memory. However, the choice extends beyond RNNs to include other architectures like convolutional neural networks (CNNs), which are effective for image data, and graph neural networks (GNNs), which are particularly adept at handling graph-structured data like molecules. As for molecular representations, except for SMILES strings, graph representations could capture the molecular structure more directly, including both topological and geometrical information, which is essential for tasks like drug discovery and material science. Moreover, innovative architectures with inductive bias (e.g., the 3D-CNN architecture (Skalic et al., 2019)) should be further developed to better address the nuances of specialized tasks. For example, geodesic 3D convolutional neural networks (gCNNs) use geodesic convolutions that consider the intrinsic geometry of the data, which is particularly useful in medical applications where the curvature and shape of organs, bones, and tissues are critical. These architectures can lead to improved model accuracy and computational efficiency by focusing on the most important information in the data (Pandey et al., 2022). Data safety and privacy. The safeguarding of personal information in terms of security, privacy, and confidentiality is non-negotiable, especially in the context of research, standards development, and commercial applications (Jayatunga et al., 2022). Computational complexity (time complexity, space complexity and scalability). The challenges posed by the computational demands and intricacies of contemporary deep learning methods are expected to remain a significant factor in the near term. For example, to address the scalability challenge, many AI applications leverage distributed computing and parallel processing techniques. Reducing the computational complexity of deep learning models can be achieved through network compression and acceleration techniques. Moreover, quantum computing offers a potential solution to overcoming computational limitations in AI. Quantum algorithms for machine learning, such as Grover’s algorithm, can potentially reduce the complexity of certain tasks, making previously intractable problems solvable. Additionally, quantum neural networks leveraging qubits could operate with higher efficiency and improved processing speed.

With unwavering conviction, we are stand atop the pinnacle of research, an epoch where AI, and especially LLMs, are set to transcend mere advancement and emerge as vital pillars of contemporary pharmaceutical innovation. It is imperative to accentuate the sophisticated and proficient application of AI throughout the biotechnological pharmaceutical development continuum, demonstrating its unparalleled ability to catalyze scientific breakthroughs and augment the efficacy of drug discovery endeavors.

## Section: Funding Statement

The author(s) declare that financial support was received for the research, authorship, and/or publication of this article. The authors express their gratitude to the Traditional Chinese Medicine Science and Technology Project of Shandong Province (M-2023080), the Shandong Provincial University Youth Innovation Team, China (No. 2022KJ102), the National Natural Science Foundation of China (No. 32000194), and the Research Fund for Academician Lin He New Medicine (JYHL2021MS23).

## Section: Author contributions

X-hL: Data curation, Formal Analysis, Writing–original draft. Z-hL: Methodology, Resources, Software, Writing–original draft. TW: Funding acquisition, Project administration, Supervision, Validation, Writing–review and editing. FL: Funding acquisition, Project administration, Supervision, Writing–review and editing.

## Section: Conflict of interest

The authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.

## Section: Publisher’s note

All claims expressed in this article are solely those of the authors and do not necessarily represent those of their affiliated organizations, or those of the publisher, the editors and the reviewers. Any product that may be evaluated in this article, or claim that may be made by its manufacturer, is not guaranteed or endorsed by the publisher.


---

# Machine Learning Assisted Hit Prioritization for High Throughput Screening in Drug Discovery

- **Authors:** Davide Boldini, Lukas Friedrich, Daniel Kuhn, Stephan A Sieber
- **Issuer:** ACS central science
- **Type:** Scientific article
- **Published:** 2024-03-15
- **Language:** en
- **DOI:** 10.1021/acscentsci.3c01517
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38680560/
- **Licence:** CC-BY

## Section: Abstract

AbstractEfficient prioritization of bioactive compounds from high throughput screening campaigns is a fundamental challenge for accelerating drug development efforts. In this study, we present the first data-driven approach to simultaneously detect assay interferents and prioritize true bioactive compounds. By analyzing the learning dynamics during training of a gradient boosting model on noisy high throughput screening data using a novel formulation of sample influence, we are able to distinguish between compounds exhibiting the desired biological response and those producing assay artifacts. Therefore, our method enables false positive and true positive detection without relying on prior screens or assay interference mechanisms, making it applicable to any high throughput screening campaign. We demonstrate that our approach consistently excludes assay interferents with different mechanisms and prioritizes biologically relevant compounds more efficiently than all tested baselines, including a retrospective case study simulating its use in a real drug discovery campaign. Finally, our tool is extremely computationally efficient, requiring less than 30 s per assay on low-resource hardware. As such, our findings show that our method is an ideal addition to existing false positive detection tools and can be used to guide further pharmacological optimization after high throughput screening campaigns.

## Section: Introduction

High throughput screening (HTS) has significantly accelerated drug discovery efforts by allowing researchers to test large chemical libraries for bioactivity in a time and cost efficient manner, thus providing a crucial starting point for synthesizing small molecules with suitable pharmacological properties.1−4

However, one fundamental issue with HTS is its tendency to provide false positive readouts, either because the experimental response for a given hit compound is not reproducible or because it is not correlated with the intended biological activity.5−9 The underlying causes for the false positive readout can be extremely heterogeneous, including colloidal aggregation,10 autofluorescence,11 interference with assay technology,5,8 chemical reactivity,12 metal impurities,13 and measurement uncertainty.14

For these reasons, choosing which active compounds to prioritize for further pharmacological development after an HTS campaign still relies on further experimental profiling,15−17 thus increasing the time and resources necessary to identify true hits and subsequently deliver a drug to the market.

This issue has garnered significant attention in the cheminformatics community, leading to the development of several in-silico tools for false positive detection in HTS data.6,7,18−22 These methods are generally based on expert rule based approaches, for example Pan-Assay Interferent (PAINS) substructure filters,5,8 or machine learning models trained on historical HTS data.7,18,19 However, there are two main limitations to the use of these tools. First, they generally make assumptions concerning the assay interference mechanism, limiting their applicability to a narrow selection of false positives.6,18 Furthermore, this aspect also limits their trustworthiness in identifying true positives since they can only prioritize compounds that are unlikely to be interferents according to that specific mechanism. For example, given an autofluorescence predictor for HTS interferent detection, even if it classifies a compound as nonfluorescent, that molecule might still be a false positive due to other phenomena, e.g., statistical fluctuations or colloidal aggregation. Second, these approaches depend on the chemical, biological, and technological space evaluated to generate them.5,7 As such, their performance might be unreliable when evaluating compounds outside of the applicability domain of the model or when applied to HTS campaigns targeting unseen protein families, relying on new assay technologies and so forth.7

To speed up HTS hit triaging, we propose herein minimal variance sampling analysis (MVS-A), the first machine learning approach to simultaneously identify false positive compounds and prioritize true biologically active molecules in HTS data. Our approach is inspired by recent findings in gradient-based data valuation,23−25 which showcase how tracing sample gradients during the training process can highlight mislabeled data in computer vision and natural language processing applications.23,26 To make gradient-based data valuation more applicable out-of-the-box and reduce computational complexity, MVS-A is based on a novel formulation of sample influence for gradient boosting, thus enabling processing of large HTS data sets (e.g., above 300.000 compounds) in mere seconds. Because of this, MVS-A operates in an orthogonal fashion to prior false positive detection tools for HTS data: instead of requiring a preexisting library of assay interferents, it only requires training on the HTS itself, avoiding out-of-domain (OOD) applicability issues altogether. Additionally, since it does not make any assumptions about the interference mechanism, it can be used to successfully prioritize true positives.

To evaluate our approach, we curated a selection of 17 publicly available HTS data sets and 3 industrial ones with different sizes, class imbalance, biological targets, assay technology, and false positive rates. Our results show that MVS-A can outperform a variety of rule-based and data-driven baselines both at true positive and false positive identification.

## Section: Results and Discussion

Illustration of our proposed approach. After an HTS campaign is carried out, the most active compounds in the primary screen are usually prioritized for further testing. However, this strategy often does not distinguish well between true positives (TP) and false positives (FP), leading to high false positive rates in the confirmatory screens. In our approach, we first fit a Gradient Boosting Machine classifier on the primary HTS screen data and compute MVS-A scores for each active compound. Problematic compounds according to the classifier will have high MVS-A scores and are likely false positives and vice versa for true hits. Selecting compounds according to their MVS-A score leads to reduced false positive rates in subsequent confirmatory screens and enables the identification of false positives in the primary HTS screen.

False positive detection performance across all data sets. Asterisks denote significance according to one-tailed Wilcoxon Signed Rank tests with Bonferroni correct (one asterisk corresponds to α = 0.05, two asterisks to α = 0.01). P-values are reported in Table S5. (a) Distribution of relative precision scores across all data sets. The dotted gray line denotes random performance. (b) Distribution of enrichment factor scores across all data sets. (c) Distribution of BEDROC scores across all data sets.

True positive detection performance across all data sets. Asterisks denote significance according to one-tailed Wilcoxon Signed Rank tests with Bonferroni correct (one asterisk corresponds to α = 0.05, two asterisks to α = 0.01). P-values are reported in Table S6. (a) Distribution of relative precision scores across all data sets. The dotted gray line denotes random performance. (b) Distribution of enrichment factor scores across all data sets. (c) Distribution of BEDROC scores across all data sets.

Structural diversity distribution analysis. White diamonds indicate the median of the distribution. (a) Distribution of the scaffold diversity scores across all data sets for false positive detection. (b) Distribution of the scaffold diversity scores across all data sets for true positive detection.

(a) Structures of the most relevant true positive compounds from the choline transporter inhibitor screening campaign. (b) Rank percentiles for the lead compounds according to MVS-A and the experimental readout from the primary HTS. (c) Compound ranking for the primary hits according to MVS-A. (d) Compound ranking according to the experimental readout for the primary hits.

## Section: Results and Discussion › Using MVS-A to Prioritize Hits from HTS Campaigns

In recent years, analyzing sample gradient dynamics during supervised neural network training has attracted significant interest for modeling noisy data sets.23−28 These methods enable quantification of the influence of each sample on the neural network weights once the model has been trained. When training on noisy data, such as HTS campaigns, it has been shown that sample influence correlates with the likelihood of being mislabeled, thus enabling the identification of both trustworthy and problematic samples. However, neural network based approaches are computationally expensive and sensitive to hyperparameters, especially for large, imbalanced molecular data sets such as HTS data,29,30 making their use for nonexperts particularly challenging.

To tackle these limitations, we have developed minimum variance sampling analysis (MVS-A) to estimate sample influence in gradient boosting machines (GBM). GBM is a machine learning algorithm that fits an ensemble of decision trees in a sequence, each compensating for the mistakes of the previous tree. The advantages of using GBM instead of neural networks for computing sample influence are faster computation of importance scores, robust out-of-the-box performance, and classification performance on imbalanced HTS data, thus providing a good inductive bias for detecting false positive compounds.31,32 In practice, the way MVS-A works is by quantifying how “unusual” a certain active compound is according to the GBM model when comparing it to the boundary it has learned to separate active and inactive molecules. If a compound is labeled as active in the training set, but the pattern learned by the GBM model contradicts that, it will have a high MVS-A score. Vice versa, if a bioactive molecule is easily identified as such by the classifier, it will have a low MVS-A score. These scores can be used accordingly to prioritize compounds for further testing, or a threshold can be set to label true positives and false positives depending on the hit validation budget. In this study, we consider for all data sets the bottom 10% of the hits as true positives and the top 10% as false positives, as done in another ranking evaluation study.33

As such, our proposed approach for ranking HTS hits goes as follows (Figure 1):

Thanks to its computational efficiency, this pipeline takes only a few seconds on low-end hardware, even for large HTS data sets. Crucially, our approach relies exclusively on the HTS data set of interest. As such, it does not rely on historical information on which compounds tend to be false positives for that assay technology (like, e.g., PAINS), nor on assumptions of which biophysical process is causing the interference (e.g., aggregation or autofluorescence predictors). This means that our method is inherently applicable to any assay technology and any region of the chemical space while being able to detect any type of interferent.

Finally, we provide a more in-depth discussion of the theory behind MVS-A in chapter 1 of the Supporting Information.

Illustration of our proposed approach. After an HTS campaign is carried out, the most active compounds in the primary screen are usually prioritized for further testing. However, this strategy often does not distinguish well between true positives (TP) and false positives (FP), leading to high false positive rates in the confirmatory screens. In our approach, we first fit a Gradient Boosting Machine classifier on the primary HTS screen data and compute MVS-A scores for each active compound. Problematic compounds according to the classifier will have high MVS-A scores and are likely false positives and vice versa for true hits. Selecting compounds according to their MVS-A score leads to reduced false positive rates in subsequent confirmatory screens and enables the identification of false positives in the primary HTS screen.

## Section: Results and Discussion › Constructing a Benchmark for HTS Hit Prioritization

To evaluate our proposed approach, we curated a selection of 17 data sets from publicly available HTS data,34,35 for a total of 471370 unique compounds measured against 10 different protein families, using a variety of readout measurements and activity thresholds (Table 1, Table S1, Table S2, Table S3, and Table S4). We focused on HTS data sets where more than 200 hits were investigated both in primary and confirmatory screens, excluding campaigns where the false positive rate was above 95% or below 5%. Where possible, we prioritized the selection of assays targeting different protein families and confirmatory screen protocols.

As a result of this selection process, the false positive rates in our benchmark range from 11% to 91%, and the screened libraries evaluate different regions of the chemical space (Figure S1), thus covering a broad spectrum of HTS campaigns.

Each data set is generated from a primary screen, relying on single-dose measurements, and a confirmatory screen, which either adds replicates or assesses the dose–response activity against the same biological target. To define which molecules are considered bioactive in a given primary or confirmatory screen, we employed the original activity thresholds defined by the authors of the screening campaign. This ensures that our analysis accurately reflects real drug discovery campaigns as close as possible, where bioactivity criteria vary on a case-by-case basis, depending on the biological target and the purpose of the drug.

We define a compound as false positive if it was reported to be active in the primary screen but was found to be inactive or inconclusive in the confirmatory screen. Depending on the protocol employed for the confirmatory screen, different false positive types can be identified. When adding replicates, only errors associated with readout fluctuations or systematic errors (e.g., dust in the well plate) can be identified, while dose–response measurements enable detection of autofluorescence, colloidal aggregation, assay technology interference, and so forth.

## Section: Results and Discussion › Defining a Protocol to Assess HTS Hit Prioritization Strategies

For a given HTS data set, we run the MVS-A pipeline exclusively on the primary screening data. Then, we measure how effective our approach is at separating true actives and false positives by comparing its compound ranking to the confirmatory screening data. To evaluate the sorting performance, we measure top-K Precision, Enrichment Factor, and Boltzmann-Enhanced Discrimination of Receiver Operating Characteristic (BEDROC).33 Since Precision is sensitive to the amount of noise in the data set, we scale it with respect to the false positive and true positive rate for each data set, making this metric more consistent across data sets. Therefore, a relative top-K precision score of 0.0 indicates that a given ranking is equal to random sorting, while values above 0.0 denote percent improvements over assay noise. We further discuss our metric selection in chapter 4 of the Supporting Information.

To contextualize the performance of MVS-A, we provide the following baselines:

Additionally, to compare our approach with publicly available HTS interference predictors, we add the following baselines for false positive identification:

## Section: Results and Discussion › MVS-A Achieves Best Performance in HTS False Positive Detection

In terms of false positive detection, MVS-A matches or outperforms, on average, all alternative methods across all metrics (Figure 2). The performance of our approach is mostly consistent across different metrics, meaning that MVS-A provides the best performance both when considering the top 10% predictions, as indicated by relative precision and enrichment factor, and when evaluating the entire ranking, as measured by BEDROC. Crucially, MVS-A outperforms all baselines across all metrics and data sets on 12 out of 17 data sets, while achieving second best performance on the remaining 5, making it an ideal option for out-of-the-box scenarios.

CatBoost object importance is the most competitive alternative; however, MVS-A still outperforms it on 16 out of 17 data sets across all metrics. Compared to this baseline, MVS-A provides an improvement of 29%, 6%, and 10% for relative precision, enrichment factor, and BEDROC respectively. Considering the differences in sample importance formulation between these methods, this result supports our method’s assumption that focusing on the splitting decisions provides a better inductive bias for discovering mislabeled data.

Both anomaly detection methods, namely, Isolation Forest and VAE, struggle on this benchmark. Specifically, MVS-A outperforms them across all metrics on 16/17 and 15/17 data sets, respectively. Concerning VAE, this is likely due to the fact that these algorithms require large data sets (e.g., 106 compounds) to be trained properly,44 while the number of hits per HTS is much lower. Regarding Isolation Forest, its performance is likely affected by the high dimensionality of the input molecular representations, rendering the use of random splits less effective.39 In contrast, data valuation approaches like MVS-A object importance select the subset of informative features by first fitting a supervised classifier to distinguish active and inactive compounds, thus mitigating the issue of high dimensionality.

In comparison to GSK and REOS structural filters, MVS-A outperforms them on 16/17 data sets across all metrics. However, these alerts do not only detect false positives, but also focus on chemical moieties associated with target promiscuity or other undesirable pharmacological properties.36,47,48 This mismatch then could explain the poor performance observed in identifying false positives in this benchmark.

Finally, Hit Dexter, SCAM Detective, and the autofluorescence predictor show subpar false positive detection performance when compared to MVS-A, with our approach outperforming them across all metrics on 16/17, 17/17, and 15/17 data sets, respectively. This is likely because these approaches, unlike MVS-A, focus on specific interference mechanisms, while our benchmark makes no assumptions about the false positive origin. Furthermore, the performance of these baselines is likely degraded by applicability domain issues, while MVS-A is tailored to each specific screening campaign.

False positive detection performance across all data sets. Asterisks denote significance according to one-tailed Wilcoxon Signed Rank tests with Bonferroni correct (one asterisk corresponds to α = 0.05, two asterisks to α = 0.01). P-values are reported in Table S5. (a) Distribution of relative precision scores across all data sets. The dotted gray line denotes random performance. (b) Distribution of enrichment factor scores across all data sets. (c) Distribution of BEDROC scores across all data sets.

## Section: Results and Discussion › MVS-A Provides the Most Efficient HTS True Hit Prioritization Strategy

In line with the false positive retrieval benchmark, MVS-A on average matches or outperforms all other approaches across all metrics in terms of true hit detection (Figure 3) Specifically, it achieves the best performance in 13 data sets out of 17 across all metrics, and it ranks second best in the remaining 4 data sets, further highlighting its potential as an optimal out-of-the-box solution.

On average, the most competitive baseline is again CatBoost object importance; however, MVS-A still outperforms it on 16/17 data sets. This further highlights that MVS-A is more effective at assessing sample influence than the previous state-of-the-art GBM algorithms since it detects high fidelity data more efficiently.

As for the false positive detection benchmark, anomaly detection methods provide subpar performance for true positive identification, with VAE showing slightly better performance than Isolation Forest. This is likely a consequence of the low data available for training the VAE and the high dimensionality of the input in the case of the Isolation Forest.

Finally, in comparison to the primary readout ranking, MVS-A outperforms it on 15 data sets, with average improvements of 50%, 13%, and 14% in terms of relative precision, enrichment factor, and BEDROC. This is especially impressive considering that ranking compounds according to their primary HTS readout is the industry standard for hit triaging in HTS campaigns. The relatively low performance of this method could be due to the fact that assay interferents can be outliers in terms of primary readout, for example, by exhibiting very strong autofluorescence, causing them to be at the top of the primary readout ranking. As such, this benchmark shows that our data-driven approach is more efficient at finding true actives than the currently used criteria for HTS hit triaging

True positive detection performance across all data sets. Asterisks denote significance according to one-tailed Wilcoxon Signed Rank tests with Bonferroni correct (one asterisk corresponds to α = 0.05, two asterisks to α = 0.01). P-values are reported in Table S6. (a) Distribution of relative precision scores across all data sets. The dotted gray line denotes random performance. (b) Distribution of enrichment factor scores across all data sets. (c) Distribution of BEDROC scores across all data sets.

## Section: Results and Discussion › MVS-A Identifies Structurally Diverse Interferents

While being able to correctly prioritize true positives and exclude false positives is a fundamental requirement for an HTS hit triaging strategy, retrieving a diverse set of compounds is also crucial. To assess this, we investigated the ability of our approach to identify heterogeneous true actives and assay interferents by measuring the fraction of unique Murcko scaffolds among the hits for both categories in each data set.

In terms of false positive variety, MVS-A selects the most diverse selection of interferents, peaking at around 95% scaffold diversity, closely followed by Hit Dexter and CatBoost object importance (Figure 4a). In general, data valuation algorithms such as MVS-A naturally tend to identify more varied interferents since they do not rely on the presence of specific molecular motifs in the false positives but rather highlight any active that deviates from the pattern they learned while training on the primary screening data. This more flexible definition of what constitutes a false positive then leads to the identification of more structurally different interferents, outperforming even anomaly detection algorithms. On the contrary, structural filters and assumption-based predictors are inherently biased toward specific chemical scaffolds, thus flagging more homogeneous compounds. One exception to this seems to be frequent hitters, which likely encompass several different interference mechanisms in their definition and, as such, have more diverse chemical structures.

This trend is inverted for true positive discovery, where both data valuation approaches tend to yield less diverse selections of true hits, centered around 60% scaffold diversity (Figure 4b). In this case, the true positives identified by MVS-A and CatBoost are the ones that fit well the learned class boundary between actives and inactives in the primary data. The boundary in this case tends to include only a limited region of the chemical space, leading to more structurally similar true actives. In contrast, primary readout ranking has no chemical bias in its selection criteria, thus retrieving the most diverse true positives. Finally, the scaffold diversity rate distribution across all data sets for the anomaly detection baselines is comparable with the one observed to randomly picking hits from each HTS (Table S4). This is because the true positives identified by these methods correspond to distribution inliers, thus approximating the distribution of chemical motifs present in the training data.

Structural diversity distribution analysis. White diamonds indicate the median of the distribution. (a) Distribution of the scaffold diversity scores across all data sets for false positive detection. (b) Distribution of the scaffold diversity scores across all data sets for true positive detection.

## Section: Results and Discussion › MVS-A Identifies False Positives Belonging to Different Interferent Classes

By design, MVS-A makes no assumption concerning the interference mechanism of the false positive compounds in the primary screen; therefore, it should cover all types of interferents. To test this assumption, we measure across all data sets the fraction of compounds predicted to be false positives by our method that were also identified by the other assumption-based predictors (Figure S2).

MVS-A shows the highest overlap across all data sets with the autofluorescence predictor, with a median of 66%. This however is likely due to the nonselectivity of the autofluorescence predictor, which tends to flag the majority of compounds as fluorescent across all data sets (Table S7). These overconfident predictions could be due to applicability domain issues given that the training set used for this model originated from assays related to toxicological screening. Compared to the remaining in-silico predictors, MVS-A shows a median overlap of 51% with the colloidal aggregators identified by SCAM Detective, 33% with the structural filters from GSK and REOS and 8% with the frequent hitters detected by Hit Dexter.

Taken together, these results confirm the hypothesis that MVS-A can identify different classes of false positives while showing complementary performance with tools covering also compound promiscuity, such as frequent hitter predictors and general nuisance compound structural alerts.

## Section: Results and Discussion › Case Study I: Choline Transporter Inhibitor Screen from Vanderbilt University

To assess how well MVS-A would perform in a real drug discovery campaign, we investigated whether the true actives identified by our method are biased toward chemical moieties that would make them unsuitable for further pharmacological optimization. To do so, we re-evaluated the data set with the codename “transporter” from the publicly available HTS assays evaluated in this work. This assay was conducted in order to identify novel inhibitors for the presynaptic choline transporter (CHT), a potential therapeutic target for Alzheimer’s disease and schizophrenia.49 We chose this data set from our collection as a case study because the hits from its primary HTS screen were extensively validated by additional counterscreens and confirmatory assays (PubChem AID 488997). The goal of these experimental validation efforts was to identify potent selective CHT inhibitors eliciting the desired phenotypic response from primary HTS hits.

After 11 rounds of screening, only six compounds that were present in the primary HTS made it to the end of the pipeline, one of which, CHT4, was a false negative (Figure 5a). Crucially, all five true positives were immediately flagged as more promising than most other hits from the HTS campaign by MVS-A (Figure 5b), ranking within the top 20 primary HTS according to our method. Notably, among these five compounds there was also ML352, the best inhibitor from the screening campaign, which also showed suitable ADME properties.49 In contrast, ranking by experimental readout from the primary screen is far less efficient, with ML352, CHT5, and CHT3 ranking between 150th and 500th, CHT1 around 750th, and CHT2 around 2300th (Figure 5b,d).

We then used MVS-A to rank primary inactive compounds in terms of false negative likelihood by sorting inactive compounds in terms of importance to the underlying GBM classifier according to our method. Crucially, our approach correctly identified CHT4 as the most likely false negative compound out of all primary inactives (Figure 5b). This finding is especially relevant, since mining dark chemical matter in HTS data is a promising but largely unexplored starting point for drug discovery,50 given the lack of in-silico approaches to determine which samples to reinvestigate.

To summarize, in this case study MVS-A was able to identify the 6 most biologically relevant compounds just by observing the primary HTS data, including a false negative, while prioritizing molecules according to their experimental readout in the primary screen was a less efficient selection strategy. Additionally, this finding shows that MVS-A is not biased toward undesirable chemical moieties in terms of further pharmacological development.

(a) Structures of the most relevant true positive compounds from the choline transporter inhibitor screening campaign. (b) Rank percentiles for the lead compounds according to MVS-A and the experimental readout from the primary HTS. (c) Compound ranking for the primary hits according to MVS-A. (d) Compound ranking according to the experimental readout for the primary hits.

## Section: Results and Discussion › Case Study II: Industrial HTS Campaigns from Merck KGaA

To further evaluate the applicability of MVS-A on real scenarios, we investigated three currently ongoing HTS campaigns from Merck KGaA, aimed at different biological targets (Table S8). Each of these data sets is larger than the largest publicly available data set we included in our study so far, thus providing a realistic benchmark for how our method would fare in industrial applications. Due to computational limitations, we could only test MVS-A, CatBoost and primary readout ranking on these data sets.

In terms of false positive detection, on average, MVS-A outperforms all baselines across all metrics (Table S9). Regarding true positive detection, on average, CatBoost and MVS-A achieve similar performance, while primary readout ranking outperforms all alternatives in terms of precision and BEDROC (Table S10). In general, primary readout ranking performs much better as a baseline in these data sets, likely due to less assay noise compared to publicly available data, making the initial HTS screen more predictive of a compound’s performance in further validation screens.

## Section: Results and Discussion › Limitations and Practical Guidelines for the Use of MVS-A

While MVS-A achieved excellent performance in terms of false positive and true positive detection, it still requires careful deployment for real use cases.

First, the performance of MVS-A can fluctuate from data set to data set, and it can be difficult to forecast how effective it will be for a given HTS data set. While we investigated the relationship between its performance and the HTS of interest, such as the protein target family, structural diversity of the data set (Figure S3), and the cross-validation performance of the GBM classifier (Figure S4), we could not detect meaningful correlation between these factors. As such, although MVS-A never performs worse than random picking in our benchmarks, the bias toward specific scaffolds in terms of true positive prioritization can be problematic if it is not associated with an improved true hit rate. This issue can be tackled, however, by hybrid hit selection strategies aimed at selecting diverse chemical scaffolds according to the MVS-A true hit likelihood.

Another factor that can influence the performance is the choice of molecular representation for the analysis. However, we observed only a 3% performance variation when using different molecular fingerprints and molecular descriptors (Figure S5), consistently with the results observed for molecular property prediction tasks.

In terms of computational cost, unlike other false positive predictors, MVS-A requires to be retrained for each new HTS data set. However, our testing shows that the algorithm is extremely efficient and lightweight, taking less than 5 s per data set on a server with an AMD Ryzen Threadripper 3970X 32-Core Processor and less than 30 s on a laptop with an AMD Ryzen 5 3600 6-Core Processor (Figure S6).

Finally, while MVS-A accurately distinguishes between interferents and true positives, it does not account for other relevant factors for hit prioritization such as promiscuity. As such, the ideal application of our approach is not as a stand-alone tool, but in conjunction with other in-silico tools, e.g., structural alerts or frequent hitter predictors, to get a global view of the pharmacological potential of each primary HTS hit. To highlight this, we revisited the top 20 ranked compounds from the CHT inhibitor screening campaign according to MVS-A, as discussed in Case Study I, focusing on the 15 compounds our approach incorrectly selected as the true hit. Six of those could be removed according to REOS and GSK filters, one according to Hit Dexter and one according to InterPred, while SCAM Detective flagged most compounds as potential colloidal aggregators (Table S10). As such, the synergistic combination of these approaches could have brought the true positive rate from 25% when using MVS-A on its own to 38%.

## Section: Conclusions

High throughput screening holds a key role in current drug discovery research, but its impact is limited by the presence of many false positive compounds, making further pharmacological development of bioactive compounds slower and more expensive. In this study, we introduced minimal variance sampling analysis, a novel approach inspired by data valuation methods to simultaneously prioritize true positive compounds and detect assay interferents in HTS data.

To test our proposed method, we have constructed a new benchmark consisting of 17 primary-confirmatory HTS data set pairs, encompassing a variety of biological targets, assay technologies, number of compounds, and false positive rates.

MVS-A consistently matches or outperforms the other baselines in terms of both false positive and true positive detection. Crucially, it provides average improvements up to 50%, 13%, and 14% in terms of relative precision, enrichment factor, and BEDROC against primary readout sorting, a popular heuristic used in the pharmaceutical industry for HTS hit prioritization. Concerning false positive discovery, our method can identify a wide range of structurally diverse interferents with low overlap with the predictions of prior in-silico tools focusing on compound promiscuity, making our method an excellent addition to HTS false positive detection pipelines.

Regarding hit prioritization, MVS-A was able to identify the most biologically relevant hits from a primary HTS campaign in a retrospective case study on publicly available data. Interestingly, one of the hits correctly detected by MVS-A was a false positive, highlighting the potential of our approach to detect promising compounds from dark chemical matter.

On the three data sets provided by Merck KGaA, MVS-A performs competitively in terms of false positive detection and false positive retrieval, indicating that our approach is also reliable in the chemical space typically explored in industrial screening campaigns.

Finally, our method is extremely computationally efficient, allowing processing of HTS data on a laptop in under 30 s with minimal RAM usage. In light of these results, we are confident MVS-A will help accelerate HTS hit triaging and will stimulate further research into data valuation approaches for handling large chemical data sets. We provide this tool as an open source package at https://github.com/dahvida/AIC_Finder.

## Section: Acknowledgments

The authors thank Merck KGaA Darmstadt for their generous support with the Merck Future Insight Prize 2020. This project was also cofunded by the European Union (ERC, breakingBAC, 101096911). D.B. thanks Maximilian Schuh and Joshua Hesse for their help revising the draft and creating the pictures.

## Section: Data Availability Statement

All PubChem assays investigated in this study can be accessed from PubChem according to their AID, as shown in Table 1. The Python environment, data sets, performance of each method across all metrics, data sets and replicates, and code required to reproduce the results are available at the following GitHub repository: https://github.com/dahvida/AIC_Finder.

## Section: Supporting Information Available

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acscentsci.3c01517.

## Section: Author Contributions

Conceptualization: D.B. Benchmarking: D.B. Software: D.B. Methodology: D.B. and L.F. Analysis of the results: all authors. Writing original draft: D.B. Writing review and editing: all authors. All authors have given approval to the final version of the manuscript.

## Section: Text

Views and opinions expressed are those of the author(s) only and do not necessarily reflect those of the European Union or the European Research Council. Neither the European Union nor the granting authority can be held responsible for them.

## Section: Text

The authors declare no competing financial interest.

## Section: Supplementary Material

oc3c01517_si_001.pdf

## Section: Associated Data

oc3c01517_si_001.pdf

## Section: Associated Data › Supplementary Materials

oc3c01517_si_001.pdf

## Section: Associated Data › Data Availability Statement

All PubChem assays investigated in this study can be accessed from PubChem according to their AID, as shown in Table 1. The Python environment, data sets, performance of each method across all metrics, data sets and replicates, and code required to reproduce the results are available at the following GitHub repository: https://github.com/dahvida/AIC_Finder.


---

# Machine learning-based identification and immune characterization of ferroptosis-related molecular clusters in osteoarthritis and validation

- **Authors:** Xiaocheng Guo, Xinyuan Feng, Yue Yang, Wenying An, Lunhao Bai
- **Issuer:** Aging
- **Type:** Scientific article
- **Published:** 2024-05-29
- **Language:** en
- **DOI:** 10.18632/aging.205875
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38814177/
- **Licence:** CC-BY

## Section: Abstract

Osteoarthritis (OA), a degenerative joint disease, involves synovial inflammation, subchondral bone erosion, and cartilage degeneration. Ferroptosis, a regulated non-apoptotic programmed cell death, is associated with various diseases. This study investigates ferroptosis-related molecular subtypes in OA to comprehend underlying mechanisms. The Gene Expression Omnibus datasets GSE206848, GSE55457, GSE55235, GSE77298 and GSE82107 were used utilized. Unsupervised clustering identified the ferroptosis-related gene (FRG) subtypes, and their immune characteristics were assessed. FRG signatures were derived using LASSO and SVM-RFE algorithms, forming models to evaluate OA's ferroptosis-related immune features. Three FRG clusters were found to be immunologically heterogeneous, with cluster 1 displaying robust immune response. Models identified nine key signature genes via algorithms, demonstrating strong diagnostic and prognostic performance. Finally, qRT-PCR and Western blot validated these genes, offering consistent results. In addition, some of these genes may have implications as new therapeutic targets and can be used to guide clinical applications.


---

# Machine learning driven bioequivalence risk assessment at an early stage of generic drug development

- **Authors:** Dejan Krajcar, Dejan Velušček, Iztok Grabnar
- **Issuer:** European journal of pharmaceutics and biopharmaceutics : official journal of Arbeitsgemeinschaft fur Pharmazeutische Verfahrenstechnik e.V
- **Type:** Scientific article
- **Published:** 2024-10-26
- **Language:** en
- **DOI:** 10.1016/j.ejpb.2024.114553
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39490606/
- **Licence:** CC-BY

## Section: Abstract

Bioequivalence risk assessment as an extension of quality risk management lacks examples of quantitative approaches to risk assessment at an early stage of generic drug development. The aim of our study was to develop a model-based approach for bioequivalence risk assessment that uses pharmacokinetic and physicochemical characteristics of drugs as predictors and would standardize the first step of risk assessment. The Sandoz in-house bioequivalence database of 128 bioequivalence studies with poorly soluble drugs (23.5% non-bioequivalent) was used to train and validate the model. Four different modeling approaches, random forest, XGBoost, logistic regression and naïve Bayes, were compared. Among the best performing machine learning models, random forest was selected and optimized for the number of features, resulting in an accuracy of 84% on the test data set. The most important features for prediction were those related to solubility (dose number, acid dissociation constant), absorption and elimination rate, effective permeability, variability of pharmacokinetic endpoints, and absolute bioavailability. All features had a conceivable influence on the model predictions. The model was used to develop a bioequivalence risk assessment approach to categorize drugs in early development into high, medium or low risk classes.


---

# Machine Learning Empowering Drug Discovery: Applications, Opportunities and Challenges

- **Authors:** Xin Qi, Yuanchun Zhao, Zhuang Qi, Siyu Hou, Jiajia Chen
- **Issuer:** Molecules (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2024-02-18
- **Language:** en
- **DOI:** 10.3390/molecules29040903
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38398653/
- **Licence:** CC-BY

## Page 1 (Section: Introduction )

Citation: Qi, X.; Zhao, Y.; Qi, Z.; Hou,
S.; Chen, J. Machine Learning
Empowering Drug Discovery:
Applications, Opportunities and
Challenges. Molecules 2024, 29, 903.
https://doi.org/10.3390/
molecules29040903
Academic Editor: Shijun Zhong
Received: 15 January 2024
Revised: 8 February 2024
Accepted: 14 February 2024
Published: 18 February 2024
Copyright:
© 2024 by the authors.
Licensee MDPI, Basel, Switzerland.
This article is an open access article
distributed
under
the
terms
and
conditions of the Creative Commons
Attribution (CC BY) license (https://
creativecommons.org/licenses/by/
4.0/).
molecules
Review
Machine Learning Empowering Drug Discovery: Applications,
Opportunities and Challenges
Xin Qi 1,*,†, Yuanchun Zhao 1,†, Zhuang Qi 2, Siyu Hou 1 and Jiajia Chen 1
1
School of Chemistry and Life Sciences, Suzhou University of Science and Technology, Suzhou 215011, China;
2111121006@post.usts.edu.cn (Y.Z.); 2211121003@post.usts.edu.cn (S.H.); njucjj@126.com (J.C.)
2
School of Software, Shandong University, Jinan 250101, China; z_qi@mail.sdu.edu.cn
*
Correspondence: qixin@usts.edu.cn; Tel.: +86-0512-68418434
†
These authors contributed equally to this work.
Abstract: Drug discovery plays a critical role in advancing human health by developing new medica-
tions and treatments to combat diseases. How to accelerate the pace and reduce the costs of new drug
discovery has long been a key concern for the pharmaceutical industry. Fortunately, by leveraging
advanced algorithms, computational power and biological big data, artiﬁcial intelligence (AI) tech-
nology, especially machine learning (ML), holds the promise of making the hunt for new drugs more
efﬁcient. Recently, the Transformer-based models that have achieved revolutionary breakthroughs in
natural language processing have sparked a new era of their applications in drug discovery. Herein,
we introduce the latest applications of ML in drug discovery, highlight the potential of advanced
Transformer-based ML models, and discuss the future prospects and challenges in the ﬁeld.
Keywords: machine learning; drug discovery; transformer; opportunity; challenge
1. Introduction
Drug research and development play a vital role in improving human health and
well-being. However, the discovery of a new drug is an extremely complex, expensive and
time-consuming process, typically costing approximately USD 2.6 billion [1] and taking
more than 10 years on average [2]. Despite the high investment levels, the approval success
rate of launching a small-molecule drug to market from phase I clinical trial is less than
10% [3], highlighting the considerable risk of failure. Therefore, how to reduce the costs
and accelerate the pace of new drug discovery has emerged as a key concern within the
pharmaceutical industry.
The increasing availability of large-scale biomedical data provides tremendous op-
portunities for computational drug discovery, but effectively mining, correlating, and
analyzing these huge amounts of data has become a critical challenge. Fortunately, with
the advent of efﬁcient mathematical tools and abundant computational resources, artiﬁcial
intelligence (AI) approaches have rapidly developed (Figure 1). As the representative AI
method, machine learning (ML), empowers machines to learn from existing data by using
statistical approaches and make predictions, which can be further classiﬁed into supervised,
unsupervised, and reinforcement learnings [4,5]. Deep learning (DL), a subset of ML,
focuses on using multi-layered artiﬁcial neural networks (ANNs) structures to simulate
the neural networks of the human brain for learning data representations, making it more
powerful and ﬂexible in handling complex and high-dimensional data [6,7]. With the
advantages of low cost and fast speed, the ML approaches are revolutionizing and strength-
ening multiple stages of drug discovery, such as target identiﬁcation, de novo drug design
and drug repurposing. For example, DL-based open-source tools, such as DeepDTAF [8]
and DeepAfﬁnity [9], have been applied to predict the binding afﬁnity of drug–target
interactions (DTIs), making the hunt for new pharmaceuticals more efﬁcient. Accordingly,
more and more pharmaceutical giants, such as Sanoﬁ(Paris, France), Merck (Darmstadt,
Molecules 2024, 29, 903. https://doi.org/10.3390/molecules29040903
https://www.mdpi.com/journal/molecules

## Page 2 (Section: Introduction )

Molecules 2024, 29, 903
2 of 20
Germany), Takeda (Takeda, Japan) and Genentech (South San Francisco, America), have
initiated cooperation with AI companies to develop new drugs.
Figure 1. Introduction diagram of artiﬁcial intelligence and its subﬁelds: machine learning and
deep learning.
Notably, the Transformer-based language models, such as the Generative Pre-training
Transformer (GPT), Bidirectional Encoder Representations from Transformers (BERT) and
the Text-to-Text Transfer Transformer (T5), have not only achieved revolutionary break-
throughs but have also brought about a paradigm shift in the area of natural language
processing (NLP) [10]. In particular, the outstanding learning ability, generalization ability
and transferability of Transformer-based language models have sparked a new era of their
applications in drug discovery and development, primarily owing to the inherent similari-
ties between drug-related biological sequences and natural languages. Their remarkable
advantages, including capturing long-range dependencies in sequences, processing input
sequences in parallel, employing an attention mechanism, and having extendibility to incor-
porate multimodal information, make them valuable tools for various aspects of the drug
discovery process [11]. For example, by employing Transformer-based language models,
Kalakoti et al. [12] have successfully developed a modular framework called TransDTI for
predicting novel DTIs from sequence data. Its performance proved to be superior to existing
methods. Therefore, the Transformer-based models have the potential to revolutionize the
identiﬁcation and development of new drugs.
Given the signiﬁcance of ML techniques in the pharmaceutical industry, we here focus
on introducing the recent advancements, opportunities and challenges of ML applications

## Page 3 (Section: Applications of ML in Drug Discovery )

Molecules 2024, 29, 903
3 of 20
in drug discovery. First, we provide an updated overview of the emerging applications of
ML in different stages of the drug discovery process, including drug design, drug screening,
drug repurposing and chemical synthesis. Next, we highlight the opportunities of the
advanced Transformer-based models in empowering drug discovery. Furthermore, we
discuss the challenges and future prospects of ML in the ﬁeld of drug discovery.
2. Applications of ML in Drug Discovery
The process of discovering effective new drugs is time-consuming and predominantly
the most challenging part of drug development. With the advantages in learning from data,
discerning patterns, and making intelligent decisions, ML-based approaches have emerged
as versatile tools that can be applied in multiple stages of drug discovery, including drug
design, drug screening, drug repurposing and chemical synthesis (Figure 2). Moreover, con-
siderable efforts are dedicated to developing models, tools, software and databases based
on the core architecture of ML algorithms, to counter the inefﬁciencies and uncertainties
inherent in traditional drug development methods (Table 1).
Figure 2. Machine learning can be applied in multiple stages of the drug discovery process, mainly
including drug design, drug screening, drug repurposing and chemical synthesis.

## Page 4 (Section: Applications of ML in Drug Discovery )

Molecules 2024, 29, 903
4 of 20
Table 1. ML-based software/model used for drug discovery.
Name
Algorithm
Speciﬁc Function
PMID
Prediction of the target protein structure
TrRosetta server
DNN
Predict 3D structures of proteins
[13]
AlphaFold
DNN
Predict 3D structures of proteins
[14]
ComplexQA
GNN
Predict protein complex structure
[15]
ProteinBERT
Transformer
Predict secondary structure
[16]
ESMfold
Transformer
Predict structure of proteins
[17]
Predicting protein–protein interactions
IntPred
RF
Predict PPI interface sites
[18]
eFindSite
SVM; NBC
Predict PPI interfaces
[19]
DELPHI
RNN; CNN
Predict PPI sites
[20]
PPISP-XGBoost
XGBoost
Predict PPI sites
[21]
HN-PPISP
CNN
Predict PPI sites
[22]
TAGPPI
GCN
Predict PPIs
[23]
Struct2Graph
GAT
Predict PPIs
[24]
DeepFE-PPI
DNN
Predict PPIs
[25]
SGPPI
GCN
Predict PPIs
[26]
DeepPPI
DNN
Predict PPIs
[27]
DL-PPI
GNN
Predict PPIs
[28]
DeepSG2PPI
CNN
Predict PPIs
[29]
MaTPIP
Transformer; CNN
Predict PPIs
[30]
ProtInteract
Autoencoder; CNN
Predict PPIs
[31]
Predicting drug–target interactions
DeepC-SeqSite
CNN
Predict DTI binding sites
[32]
DeepSurf
CNN; ResNet
Predict DTI binding sites
[33]
PrankWeb
RF
Predict DTI binding sites
[34]
PUResNet
ResNet
Predict DTI binding sites
[35]
AGAT-PPIS
GNN
Predict DTI binding sites
[36]
DeepDTA
CNN
Predict DTI binding afﬁnity
[37]
SimBoost
GBM
Predict DTI binding afﬁnity
[38]
DEELIG
CNN
Predict DTI binding afﬁnity
[39]
DeepDTAF
CNN
Predict DTI binding afﬁnity
[8]
GraphDelta
CNN
Predict DTI binding afﬁnity
[40]
PotentialNet
CNN
Predict DTI binding afﬁnity
[41]
DeepAfﬁnity
RNN, CNN
Predict DTI binding afﬁnity
[9]
TeM-DTBA
CNN
Predict DTI binding afﬁnity
[42]
Wang et al.’s method
RL
Predict DTI binding pose
[43]
Nguyen et al.’s method
RF; CNN
Predict DTI binding pose
[44]
AMMVF-DTI
GAT; NTN
Predict drug–target interactions
[45]
De novo drug design
ReLeaSE
RNN; RL
Conduct de novo drug design
[46]
ChemVAE
CNN; GRU
Conduct de novo drug design
[47]
MolRNN
RNN
Conduct multi-objective de novo drug design
[48]
PaccMann(RL)
VAE
Generate compounds with anti-cancer drug properties
[49]
druGAN
AAE
Conduct de novo drug design
[50]
SCScore
CNN
Evaluate the molecular accessibility
[51]
UnCorrupt SMILES
Transformer
Conduct de novo drug design
[52]
PETrans
Transfer learning
Conduct de novo drug design
[53]
FSM-DDTR
Transformer
Conduct de novo drug design
[54]
DNMG
GAN
Conduct de novo drug design
[55]
MedGAN
GAN
Design novel molecule
[56]
Prediction of the physicochemical properties
Panapitiya et al.’s method
GNN
Predict aqueous solubility
[57]
SolTranNet
Transformer
Predict aqueous solubility
[58]
Zang et al.’s method
SVM
Predict multiple physicochemical properties
[59]
Prediction of the ADME/T properties
ADMETboost
XGBoost
Predict ADME/T properties
[60]
vNN
k-NN
Predict ADME/T properties
[61]
Interpretable-ADMET
CNN; GAT
Predict ADME/T properties
[62]
XGraphBoost
GNN
Predict ADME/T properties
[63]
DeepTox
DNN
Predict toxicity of compounds
[64]
Li et al.’s method
DNN
Predict human Cytochrome P450 inhibition
[65]
LightBBB
LightGBM
Predict blood–brain barrier
[66]
Deep-B3
CNN
Predict blood–brain barrier
[67]
PredPS
GNN
Predict stability of compounds in human plasma
[68]
Khaouane et al.’s method
CNN
Predict plasma protein binding
[69]
Application of AI in drug repurposing
deepDTnet
Autoencoder
Predict new targets of known drugs
[70]
NeoDTI
GCN
Predict new targets of known drugs
[71]
DTINet
Network diffusion algorithm and the
dimensionality reduction
Predict new targets of known drugs
[72]
MBiRW
Birandom walk algorithm
Predict new indications of known drugs
[73]
GDRnet
GNN
Predict new indications of known drugs
[74]
deepDR
VAE
Predict new indications of known drugs
[75]
GIPAE
VAE
Predict new indications of known drugs
[76]
DrugRep-HeSiaGraph
Heterogeneous siamese neural
network
Predict new indications of known drugs
[77]
iEdgeDTA
GCNN
Predict DTI binding afﬁnity
[78]

## Page 5 (Section: Application of ML in Drug Design )

Molecules 2024, 29, 903
5 of 20
Table 1. Cont.
Name
Algorithm
Speciﬁc Function
PMID
Retrosynthesis prediction
Segler et al.’s method
MCTS, DNN
Predict retrosynthetic analysis
[79]
Liu et al.’s method
RNN
Predict retrosynthetic analysis
[80]
RAscore
RF
Predict retrosynthetic accessibility score
[81]
Reaction prediction
Wei et al.’s method
Neural network
Predict reaction classes
[82]
Coley et al.’s method
Neural network
Predict products of chemical reactions
[83]
Gao et al.’s method
Neural network
Predict optimal reaction conditions
[84]
Marcou et al.’s method
RF
Evaluate reaction feasibility
[85]
Note: DNN, deep neural network; RNN, recurrent neural network; RF, random forest; CNN, convolutional neural
network; XGBoost, eXtreme gradient boosting; GCN, graph convolutional network; GAT, graph attention network;
SVM, support vector machine; NBC, naïve Bayes classiﬁer; ResNet, residual network; GBM, gradient boosting
machines; RL, reinforcement learning; GRU, gated recurrent unit; VAE, variational autoencoder; AAE, adaptive
adversarial autoencoder; GNN, graph neural networks; k-NN, k-nearest neighbor; LightGBM, light gradient
boosting machine; MCTS, Monte Carlo tree search, NTN, neural tensor network; GAN, generative adversarial
network; GCNN, graph convolutional neural network.
2.1. Application of ML in Drug Design
2.1.1. Prediction of the Target Protein Structure
Since proteins play crucial roles in various biological processes, their dysfunctions can
lead to abnormal cell behavior and lead to the development of diseases [86]. For selective
targeting of diseases, small-molecule compounds are generally designed based on the three-
dimensional (3D) chemical environment surrounding the ligand-binding sites of the target
protein [87]. Hence, predicting the 3D structure of the target protein is of great signiﬁcance
for structure-based drug discovery. Homology modeling has traditionally been used for this
purpose, relying on known protein structures as templates [88]. Comparatively, ML-based
approaches have shown great promise in predicting the 3D structures of target proteins
with improved accuracy and efﬁciency. For example, AlphaFold is a state-of-the-art protein
structure prediction system developed by DeepMind, a leading AI company. Based on deep
neural network (DNN), it has achieved remarkable success in multiple protein structure
prediction competitions, demonstrating its ability to accurately predict the 3D structures
of proteins by analyzing the adjacent amino acid distances and peptide bond angles [14].
Importantly, AlphaFold has signiﬁcantly advanced the ﬁeld of protein structure prediction
and has the potential to revolutionize drug discovery [14]. Therefore, ML-based approaches
hold great potential to enhance our understanding of protein structures. It should be noted
that protein structures can undergo changes in different environments, and proteins may
form multiple coexisting structures under the same conditions [89]. This complexity adds
to the challenges of structure prediction.
2.1.2. Prediction of PPIs
In most cases, proteins rarely implement their functions alone, but rather cooperate with
other proteins to form intricate relationships known as the protein–protein interaction (PPI)
network [86]. PPIs possess indispensable functions in diverse biological processes. They
can contribute to altering protein specificity, regulating protein activity and generating novel
binding sites for effector molecules [90]. Hence, understanding and targeting PPIs offers
opportunities to design innovative drugs that can modulate complex biological processes.
Currently, ML-based methods for PPI prediction can be broadly grouped into structure-
based and sequence-based categories. Structure-based approaches mainly leverage the
knowledge of protein structure similarity to predict PPIs [91]. For example, IntPred, a
random forest ML tool, was developed to predict protein–protein interface sites based on
structural features. Compared with other methods, the IntPred predictor showed strong
performance in identifying interactions at both the surface-patch and residue levels on
independent test sets of both obligate and transient complexes (Matthews’ Correlation
Coefﬁcient (MCC) = 0.370, accuracy = 0.811, speciﬁcity = 0.916, sensitivity = 0.411) [18].
Struct2Graph, a graph attention network (GAT)-based classiﬁer, was proposed to identify
PPIs directly from the 3D structure of protein chains [24]. The accuracy of Struct2Graph

## Page 6 (Section: Prediction of DTIs )

Molecules 2024, 29, 903
6 of 20
on balanced sets with equal numbers of positive and negative pairs was 0.9989, and the
average accuracy of ﬁve-fold cross-validation on unbalanced sets with a ratio of positive
and negative pairs of 1:10 was 0.9942 [24]. Comparatively, sequence-based PPI prediction
approaches aim to identify physical interactions between two proteins by leveraging
information from their protein sequences [92]. DNNs provide a robust solution for this
purpose. They are composed of multiple layers of interconnected neurons, allowing them
to automatically extract complex patterns and features from data. For example, DeepPPI
applied DNNs to effectively learn protein representations from common protein descriptors,
thereby contributing to the prediction of PPIs. It can achieve excellent performance on the
S. cerevisiae dataset with an accuracy of 0.925, precision of 0.9438, recall of 0.9056, speciﬁcity
of 0.9449, MCC of 0.8508 and area under the curve (AUC) of 0.9743, respectively [27].
Extensive experiments showed that DeepPPI was able to learn the useful features of protein
pairs through a layer-wise abstraction, resulting in better predictive performance than
existing methods on core S. cerevisiae, H. pylori and H. sapien datasets [27]. In addition,
based on Uniprot database, Li et al. [20] developed a DELPHI, a new sequence-based deep
ensemble model for PPI-binding sites’ prediction. Therefore, ML-based approaches have
great potential in enhancing the identiﬁcation of PPI sites. Compared with sequence-based
approaches, structure-based ones are limited by the scarcity of available protein structures
and the low quality of familiar protein structures [90,93].
2.1.3. Prediction of DTIs
Most drugs exert therapeutic effects by speciﬁcally interacting with target molecules
within the body, such as enzymes, receptors and ion channels. Hence, the accurate predic-
tion of DTIs is a pivotal step in the drug design pipeline. As the traditional experimental
approaches are time-consuming and costly, ML-based methods have been increasingly
developed and applied by researchers to predict DTIs. These methods primarily focus
on three key aspects: predicting the binding sites of drugs on target molecules, estimat-
ing the binding afﬁnity between drugs and targets, and determining the binding pose or
conformation of the drug within the target molecule [94].
Firstly, binding sites, also referred to as binding pockets, are speciﬁc locations within
a protein where interactions occur between the protein and a ligand (such as a drug
molecule) [94]. By introducing a deep convolutional neural network (CNN), Cui et al. [32]
developed a sequence-based method, DeepC-SeqSite, for predicting protein–ligand binding
residues. Notably, this method exhibited superior performance compared with multiple
existing sequence-based and 3D-structure-based methods, including the leading ligand-
binding method COACH [32]. Similarly, Zhou et al. [36] proposed a binding site prediction
method called AGAT-PPIS based on augmented GAT. It demonstrated signiﬁcant im-
provements over the state-of-the-art method, achieving an accuracy increase of 8% on the
benchmark test set. Moreover, binding afﬁnity represents the strength of an interaction
between a drug and its target. Some tools based on ML and DL algorithms have been
applied to determine DTIs’ binding afﬁnity, such as DEELIG [39] and GraphDelta [40].
In addition, the active conformation of ligands plays a crucial role in facilitating the ef-
fective binding between proteins and drugs [94]. By combining random forest and CNN
strategies, Nguyen et al. [44] proposed a scoring function to select the most relevant poses
generated by docking software tools including GOLD, GLIDE and Autodock Vina, thereby
contributing to obtaining more accurate and effective ligand–target binding conﬁgurations.
Therefore, ML algorithms have been extensively employed to predict DTIs and hold the
potential to facilitate the design of new drugs.
2.1.4. De Novo Drug Design
De novo drug design refers to the process of creating new drug molecules from scratch
using computational methods, without relying on existing bioactive compounds or known
drug structures. It involves designing molecules that have speciﬁc properties and functions
to target a particular disease or condition [95,96]. Compounds developed with traditional

## Page 7 (Section: Application of ML in Drug Screening )

Molecules 2024, 29, 903
7 of 20
de novo drug design methods (e.g., the fragment-based approach) usually have poor drug
metabolism and pharmacokinetics properties and are hard to synthesize due to the com-
plexity and impracticality of compound structures [97,98]. Therefore, there is high demand
for new methods to explore chemical entities that meet the requirements of biological
activity, drug metabolism, pharmacokinetics and synthesis practicality.
Recently, ML-based approaches, especially auto-encoder variants (e.g., the variational
auto-encoder (VAE) and adversarial auto-encoder (AAE)) have gained attention in the ﬁeld
of de novo drug design. PaccMannRL is an example of these approaches that combines a
hybrid VAE with reinforcement learning for the de novo design of anti-cancer molecules
from transcriptomic data [49]. Similarly, another approach, known as druGAN, utilizes
a deep generative AAE model to generate novel molecules that possess speciﬁc anti-
cancer properties [50]. In addition, a Wasserstein GAN and GCN-based model, known as
MedGAN, has been successfully developed to generate novel quinoline-scaffold molecules
from complicated molecular graphs and evaluate drug-related properties [56]. It has been
demonstrated that the MedGAN was able to produce 25% effective molecules, 62% fully
connected, among which 92% are quinoline, 93% are novel, and 95% are unique [56]. To
address the difﬁculty in synthesizing generated molecules, Coley et al. [51] deﬁned a
synthetic complexity score, namely SCScore, that utilizes precedent reaction knowledge to
train a neural network model for evaluating the level of synthetic complexity. Therefore,
ML-empowering approaches play crucial roles in de novo drug design, revolutionizing the
process of discovering and developing new drugs.
2.2. Application of ML in Drug Screening
2.2.1. Prediction of the Physicochemical Properties
The physicochemical properties of drugs, mainly including solubility, ionization de-
gree, partition coefﬁcient, permeability coefﬁcient and stability, play a signiﬁcant role in
determining their behavior (e.g., bioavailability, absorption, transportation and perme-
ability) in biological systems as well as the environment, and in evaluating their potential
risks to human health [6,59]. Hence, these properties are assessed during drug screening
to select promising candidates for further development and optimization. At present,
multiple ML-based tools have been proposed to predict the physicochemical properties of
molecules. For example, Francoeur et al. [58] developed a molecule attention Transformer
called SolTranNet for predicting aqueous solubility from the SMILES representation of
drug molecules. It has been demonstrated to function as a classiﬁer for ﬁltering insoluble
compounds, achieving a sensitivity of 0.948 on Challenge to Predict Aqueous Solubility
(SC2) datasets, which is competitive with other methods [58]. Moreover, by using molecular
ﬁngerprints and four ML algorithms, Zang et al. [59] developed a quantitative structure–
property relationship workﬂow to predict six physicochemical properties of environmental
chemicals, such as water solubility, octanol–water partition coefﬁcient, melting point, boil-
ing point, bioconcentration factor, and vapor pressure [59]. Therefore, these ML-based
predictors are valuable tools in drug discovery, as they can help in screening potential drug
candidates based on their physicochemical properties.
2.2.2. Prediction of the ADME/T Properties
Once hit or lead compounds are identiﬁed during the drug discovery process, a series
of tests and evaluations are conducted to assess their absorption, distribution, metabolism,
and excretion and toxicity (ADME/T) properties [99]. These pharmacokinetic properties
are essential for understanding how the compounds will behave in the human body and
whether they have the potential to be safe and effective as drugs. Imbalanced ADME/T
properties frequently cause the failure of drug candidates in late stages of drug development
and may even lead to the withdrawal of approved drugs [100]. Hence, ADME/T properties
are often employed as molecular ﬁlters to screen large databases of compounds in the early
stage of drug discovery, thereby helping to increase efﬁciency and improve the success rate
of drug screening [93,100].

## Page 8 (Section: Application of ML in Drug Repurposing )

Molecules 2024, 29, 903
8 of 20
To detect the ADME/T properties of drugs, various evaluation criteria such as hepa-
totoxicity, passing through the blood–brain barrier (BBB), plasma protein binding (PPB)
and cytochrome P450 2D6 (CYP2D6) inhibition are commonly used [101,102]. Accordingly,
there has been growing interest in developing ML-based tools for the prediction of these
criteria. For example, Tian et al. [60] developed a web server called ADMETboost that
utilizes the powerful extreme gradient boosting (XGBoost) model to learn about molecule
features from multiple ﬁngerprints and descriptors, allowing for the accurate prediction
of ADME/T properties, such as Caco2, BBB, CYP2C9 inhibition, CL-Hepa and hERG. It
has been demonstrated that this model can achieve remarkable results in the Therapeutics
Data Commons ADMET benchmark, ranking ﬁrst in 18 out of 22 tasks and within the top
three in 21 tasks [60]. Similarly, by utilizing more than 13 000 compounds obtained from
the PubChem BioAssay Database, Li et al. [65] proposed a multitask autoencoder DNN
model to predict the inhibitors of ﬁve major cytochrome P450 (CYP450) isoforms (1A2, 2C9,
2C19, 2D6 and 3A4). Especially, the multi-task DNN model achieved average prediction
accuracies of 86.4% in 10-fold cross-validation and 88.7% on external test datasets, outper-
forming single-task models, earlier described classiﬁers and conventional ML methods [65].
Furthermore, the Tox21 Challenge is a collaborative effort aimed at developing predictive
models for toxicity assessment using high-throughput screening data. In this context, Mayr
et al. [64] developed a DL pipeline, DeepTox, for toxicity prediction. It outperformed
all other computational methods (e.g., naïve Bayes, random forest and support vector
machine) in 10 out of 15 cases in the Tox21 Challenge [64]. Therefore, ML algorithms have
made signiﬁcant progress in predicting the ADME/T properties of drugs, contributing to
guiding drug safety assessment and preclinical research.
2.3. Application of ML in Drug Repurposing
Drug repurposing, also known as drug repositioning, is a strategy to identify new
indications from approved or investigational (including failed in clinical trials) drugs that
have not been approved [103]. As this approach takes advantage of the extensive safety
testing conducted during clinical trials for other purposes, repurposing known drugs not
only speeds up the drug development process but also presents cost-saving advantages
compared to developing entirely new drugs from scratch [103]. Currently, researchers are
increasingly developing and applying ML-based methods to conduct drug repurposing,
which can be broadly divided into target-centered and disease-centered approaches [104].
In target-centered drug repurposing, network-based methods have been widely ap-
plied to search new targets for known drugs. For example, by employing autoencoder and
Positive-Unlabeled matrix completion algorithms, Zeng et al. [70] developed a calculation
method called deepDTnet to identify new targets for known drugs from a heterogeneous
drug–gene–disease network. Experiments have shown that the deepDTnet achieved a high
accuracy in predicting new targets of existing drugs (AUC = 0.963), which is superior to
traditional ML methods [70]. Similarly, by combining the network diffusion algorithm and
the dimensionality reduction approach, Luo et al. [72] developed DTINet, a novel network-
integration procedure for DTI prediction and drug repositioning. It can outperform other
existing methods, with AUC and area under precision-recall (AUPR) 5.7% and 5.9% higher
than the second best method, respectively, providing an effective tool in the ﬁeld of drug
discovery and target identiﬁcation [72].
In addition, disease-centered approaches are mainly aimed at identifying drug–disease
relationships and can be widely divided into similarity-based and network-based ones [104].
Similarity-based methods have achieved signiﬁcant progress by combining drug or disease
characteristics with the known drug–disease associations [104]. For example, based on the
assumption that similar drugs are commonly associated with similar diseases, Luo et al. [73]
proposed a novel computational approach called MBiRW, which combines similarity mea-
surements and a Bi-Random walk algorithm to recognize potential novel indications for
a speciﬁc drug. MBiRW can achieve a high accuracy in predicting drug–disease associa-
tions (AUC = 0.917), which is superior to other methods [73]. In addition, network-based

## Page 9 (Section: Application of ML in Chemical Synthesis )

Molecules 2024, 29, 903
9 of 20
methods integrate information from different biological networks to improve the predictive
accuracy of drug–disease relationships. For example, Doshi et al. [74] developed a graph
neural network model called GDRnet for drug repurposing, which can efﬁciently screen
existing drugs in the database and predict their unknown therapeutic effects by evaluating
the scores of drug–disease pairs. Therefore, ML technology holds signiﬁcant promise in the
ﬁeld of drug repurposing, providing strong support for accelerating drug discovery.
2.4. Application of ML in Chemical Synthesis
Organic synthesis is a key part of the small-molecule drug-discovery process [97].
New molecules are synthesized along the path of compound optimization to achieve
improved properties. To promote molecule synthesis, researchers have developed multiple
ML-based computational tools applicable to the retrosynthesis prediction and forward
reaction prediction.
2.4.1. Retrosynthesis Prediction
Retrosynthesis planning aims to identify efﬁcient synthetic routes for a desired molecule
by recursively converting it into easier precursors. Therefore, it can effectively solve the syn-
thesis of complex molecules to facilitate the development of organic synthesis science [105].
At present, a series of ML-based approaches have been used for retrosynthesis planning,
mainly including template-based and template-free approaches.
The template-based approach involves systematically comparing the target molecule
with a set of templates, each representing alternative substructure patterns that occur during
a chemical reaction [105]. The ﬁrst work involving DNNs for this issue was presented by
Segler et al. [79], published in Nature. They found that Monte Carlo tree search (MCTS)
combined with DNNs and symbolic rules can be utilized to perform chemical synthesis
effectively. The routes generated by the model were comparable to those reported in the
literature in a double-blind AB test, thereby conﬁrming the accuracy of the model [79].
However, it is worth noting that template-based approaches cannot be extended beyond
templates, limiting their predictive ability [106].
As for the template-free method, it aims to uncover hidden relationships within
the data concerning reaction mechanisms rather than relying on direct matching [105].
For example, by using neural sequence-to-sequence models, Liu et al. [80] proposed the
template-free method called seq2seq, to perform the retrosynthetic reaction-prediction
tasks. This model was based on an encoder–decoder framework consisting of two re-
current neural networks (RNNs) and was trained on a dataset of 50,000 experimental
reactions extracted from the United States’ patent literature, demonstrating comparable
performances to the rule-based expert system model [80]. Therefore, ML algorithms have
been extensively employed to conduct retrosynthetic analysis and hold the potential to
facilitate chemical synthesis.
2.4.2. Forward Reaction Prediction
Contrary to retrosynthesis analysis, forward reaction prediction aims to identify po-
tential molecules that can be synthesized from given reactants and reagents [105]. Given
the reactant molecules as input, the ML model analyzes their structural and chemical
properties to generate predictions about the resulting products and reaction conditions. For
example, Wei et al. [82] introduced a novel reaction ﬁngerprinting approach that utilizes
neural networks to predict reaction types. The prediction results of this method on 16 basic
reactions of alkyl halides and alkenes indicates that neural networks can contribute to iden-
tify key features from the structure of reactant molecules to classify new reaction types [82].
Similarly, Coley et al. [83] proposed a neural network model to predict the main products
of chemical reactions by training the data extracted from a collection of 150,000 compounds’
reaction templates in the US patent database. In addition, in practical chemical synthesis
reactions, reaction conditions (e.g., solvent and temperature) are critical to maximize the
yield of desired products. Based on this, Gao et al. [84] proposed a neural network model

## Page 10 (Section: Opportunities for Transformer-Based ML Models in Empowering Drug Discovery )

Molecules 2024, 29, 903
10 of 20
to predict the optimal reaction conditions for various types of reactions. This model was
trained using a vast dataset of nearly 10 million entries extracted from the Reaxys database
and can effectively predict the ideal catalyst, solvent, reagent, and temperature for a given
reaction, facilitating the optimization of reaction conditions [84]. Therefore, the utilization
of ML-based models can assist in predicting reaction types, accelerating the discovery of
new chemical molecules, and identifying optimal reaction conditions, thereby holding
great potential in improving the efﬁciency of chemical synthesis processes.
3. Opportunities for Transformer-Based ML Models in Empowering Drug Discovery
The Transformer model, ﬁrstly proposed in the paper ‘Attention is All You Need’ by
Vaswani et al., is a highly advanced DL architecture utilizing self-attention mechanisms.
As it allows for parallelization and captures long-range dependencies more efﬁciently than
traditional RNN models, the Transformer model has proven to be highly effective in a wide
range of tasks and has set new benchmarks in the corresponding ﬁelds [10,11]. Given the
advantages of the Transformer, it has emerged as a promising future direction of ML in the
ﬁeld of drug discovery (Figure 3).
Figure 3. Opportunities for Transformer-based models in empowering drug discovery.

## Page 11 (Section: Opportunity 1: Transformer Models Empowering PPIs Identification )

Molecules 2024, 29, 903
11 of 20
3.1. Opportunity 1: Transformer Models Empowering PPIs Identiﬁcation
Existing ML-based approaches mainly use CNNs to extract low-dimensional features
from protein sequences based on the amino acid composition, while disregarding the long-
range relationships within these sequences [107]. Fortunately, transformers can capture
the long-distance dependencies in the protein sequences, making them suitable to predict
whether and how given proteins interact with each other [108]. For example, by utilizing
the advantage of the Transformer model in evolutionary scale modeling-multiple sequence
alignment, Lin et al. [109] developed DeepHomo2.0, a DL-based model that predicts
PPIs of homodimeric complexes by combining Transformer features, monomer structure
information, and direct-coupling analysis. The results showed that DeepHomo2.0 can
achieve a high accuracy of over 70% and 60% in terms of experimental monomer structure
and predicted monomer structure for the top 10 contacts predicted on the Protein Data Bank
(PDB)test set, respectively, which is superior to the DCA-based, protein language model-
based and other ML-based methods [109]. Similarly, Kang et al. [110] proposed AFTGAN,
a neural network that combines Transformer and GAT frameworks for effective protein
information extraction and multi-type PPI prediction. Experimental comparisons validated
the superior performance of AFTGAN in accurately predicting the PPIs of unknown
proteins. Therefore, given the advantage of the Transformer in extracting protein sequences,
it has demonstrated remarkable potential in advancing the prediction of PPIs.
3.2. Opportunity 2: Transformer Models Empowering DTIs’ Identiﬁcation
Despite the remarkable performance improvement of DL models in DTI prediction,
the primary challenge lies in the limited representation of drugs in these methods, as they
only consider SMILES sequences, SMARTS strings or molecular graphs, failing to capture
comprehensive drug representations [107]. It is worth noting that Transformers can be
employed either independently or in combination with other AI algorithms to address
these problems. For example, DeepMGT-DTI, a DL model that incorporates a Transformer
network and multilayer graph information, can effectively capture the structural features of
drugs, leading to improved DTI prediction [111]. Experiments have demonstrated that the
DeepMGT-DTI can achieve an AUC of 90.24%, an AUPR of 77.11%, an F1 score of 79.31%
and an accuracy of 85.15% on the DrugBank dataset. These performance metrics surpassed
those previous target sequence structure models, such as Deep DTA and Transformer-
CPI [111]. Moreover, GSATDTA, a novel triple-channel model based on graph–sequence
attention and Transformer, has been developed to predict the drug-target binding afﬁnity
with outstanding performance [107]. Therefore, Transformer models have shown promising
results for DTIs’ prediction.
3.3. Opportunity 3: Transformer Models Empowering De Novo Drug Design
Most existing deep generative models either focus on virtual screening on the available
database of compounds by DTI binding-afﬁnity prediction, or unconditionally generate
molecules with speciﬁc physicochemical and pharmacological properties, which ignore the
function of protein targets during the generation process [112]. In contrast, Transformer
models have the capability to consider the protein target and achieve target-speciﬁc molec-
ular generation. For example, AlphaDrug, a method for protein target-speciﬁc de novo
drug design, has been recently proposed. It utilizes a modiﬁed Transformer to optimize
the learning of protein information and integrates an efﬁcient MCTS guided by the Trans-
former’s predictions as well as docking values [112]. Notably, in terms of average docking
score, uniqueness, the octanol–water partition coefﬁcient logP, the quantitative estimate
of drug-likeness (QED), synthetic accessibility (SA) and Natural products-likeness (NP-
likeness) criteria, AlphaDrug is superior to other methods (such as LiGANN, SBMolGen
and SBDD-3D) [112]. In addition, the GPT model is a powerful language generation model
that can be ﬁne-tuned for speciﬁc tasks after pre-training on large amounts of text data [113].
It has been successfully applied to accelerate molecular generation for speciﬁc targets in
the ﬁeld of drug discovery. For example, cMolGPT, a GPT-inspired model, is a useful tool

## Page 12 (Section: Opportunity 4: Transformer Models Empowering Molecular Property Prediction )

Molecules 2024, 29, 903
12 of 20
for target-speciﬁc de novo molecular generation. The chemical space of the compounds
generated by cMolGPT closely matches with that of real target-speciﬁc ones [114].
3.4. Opportunity 4: Transformer Models Empowering Molecular Property Prediction
Despite the widespread application of ML-based models, the shortage of labeled data
continues to be a significant challenge in efficient molecular property predictions [10,115]. To
address this, researchers are exploring the use of unlabeled data and leveraging transformer-
based self-supervised learning (e.g., BERT) to improve predictions on small-scale labeled
data [116]. Currently, several BERT-based pre-training methods for molecular property
prediction have been proposed [10,117]. For example, a novel pre-training method, known
as K-BERT, was developed to extract chemical information from SMILES similar to chemists
for molecular property prediction in drug discovery [118]. The K-BERT model exhibited
superior performance in 8 out of 15 tasks, thus reflecting the efficacy and benefits of the
proposed pre-training approach in drug discovery. Specifically, K-BERT had an average AUC
score of 0.806, outperforming other competing methods (e.g., XGBoost-MACCS, XGBoost-
ECFP4, HRGCN+ and Attentive FP) [118]. Moreover, Wang et al. [119] proposed a two-stage
(pre-training and fine-tuning) model called SMILES-BERT that could use both unlabeled
data and labeled data to improve molecular property prediction. Compared with a range of
state-of-the-art approaches (e.g., CircularFP, NeuralFP, Seq2seqFP, Seq3seqFP), it exhibited
superior performance on three different datasets (the LogP dataset, PM2 dataset and PCBA-
686978 dataset) with accuracies of 0.9154, 0.7589, and 0.8784, respectively [119]. Therefore,
these Transformer-based predictors are essential tools for molecular property prediction,
contributing to the efficient screening of potential drug candidates.
3.5. Opportunity 5: Transformer Models Empowering Chemical Synthesis
Previous sequence-based approaches commonly employed RNNs for both the encoder
and decoder, with a single-head attention layer connecting them. These models treated
reactants and reagents separately in the input by utilizing atom mapping, which limits
the interpretability of the model [120]. Fortunately, Transformer-powered models have
shown potential to accelerate chemical synthesis. One notable example is the effectiveness
of the multi-head attention Molecular Transformer model in predicting chemical reactions
and reaction conditions [120,121]. In addition, inspired by the success of the Molecular
Transformer for forward reaction prediction, Schwaller et al. [122] proposed an enhanced
Molecular Transformer architecture coupled with a hyper-graph exploration algorithm
for automated retrosynthetic pathway prediction. This approach surpasses previous ML-
based methods by not only predicting reactants but also identifying reagents for each
retrosynthetic step, thereby signiﬁcantly raising the complexity of the prediction task.
4. Challenges of ML-Based Models in Drug Discovery
Given the remarkable advantages in identifying and extracting features from high-
dimensional and complex big data, ML-based models have made signiﬁcant progress in
multiple stages of drug discovery [99]. However, there remain several challenges that have
yet to be effectively resolved (Figure 4).
First, the effectiveness of ML algorithms heavily relies on the quantity of training
data, and typically, a larger dataset tends to yield a more accurate model [96]. When the
amount of data is inadequate, it can signiﬁcantly impact the performance and reliability
of ML models, potentially resulting in the risk of overﬁtting [123]. Indeed, the limited
availability of data, especially labeled data, poses a signiﬁcant challenge to the progress
of ML-driven drug discovery. One potential approach to address this issue is employing
transfer learning algorithms, where knowledge acquired from one task can be effectively
applied to another task [124–126]. Additionally, in light of the challenges associated with
acquiring extensive labeled datasets in drug discovery, there is a growing trend for the
effectiveness of concentrating efforts on smaller, carefully curated datasets. This shift
highlights the signiﬁcance of extracting meaningful insights from limited yet relevant data,

## Page 13 (Section: Opportunity 4: Transformer Models Empowering Molecular Property Prediction )

Molecules 2024, 29, 903
13 of 20
thereby enhancing the precision and applicability of ML models in the complex landscape
of drug discovery.
Figure 4. Challenges of machine learning-based models in drug discovery.
Second, the quality of the data is also crucial in determining the prediction performance
of ML models. The experimental drug-related data collected in public databases frequently
originates from varying biological assays, conditions, or methods, leading to disparate
results when different measurement techniques are employed for a speciﬁc compound,
thereby hindering direct comparisons. Hence, the strategies for ﬁltering raw inputs with
noise, outliers, or irrelevant information and automating data entry may be helpful to
achieve reliable and accurate ML models for drug discovery. For example, during the
data processing phase, noise reduction and outlier detection algorithms, such as Z-scores,
box plots or iterative deletion, can be applied to identify and purge outliers from the data,
enhancing its quality for ML model prediction. In addition, researchers can use cross-
validation experiments to assess the generalization ability of the models, ensuring that they
perform well not only on speciﬁc datasets but also on new, unseen data.
Third, due to the abundance of ML model architectures and the constant emergence
of new ones, it becomes challenging to choose the most suitable models that meet speciﬁc
research task requirements in the ﬁeld of drug discovery [99]. Generally, the model selec-
tion involves evaluating various options and considering factors such as the complexity of
the problem, available data, and computational resources. Furthermore, once the model
architecture is selected, the next step is to ﬁne-tune its parameters to optimize the model’s
performance. Although hyperparameter optimization tools have been proposed to auto-
mate the process of tuning substantial parameters in ML models, the entire system process
is also relatively complicated, which may bring certain difﬁculties to the application of
researchers [99,127]. In addition, the setting of hyper-parameters usually requires human

## Page 14 (Section: Concluding Remarks )

Molecules 2024, 29, 903
14 of 20
intervention, which may lead to their incomplete or inaccurate selection. Accordingly,
cross-validation is commonly used in variable selection and model parameter tuning to
evaluate the performances of various ML methods [128]. Moreover, establishing clear
performance metrics at the outset, such as accuracy, precision, recall, F1 score, AUC and
AUPR can help in objectively evaluating the suitability of different models depending on
the nature of the problem.
Fourth, unlike traditional models where the reasoning and decision-making process
can be easily understood, ML models, particularly DL models, operate using complex
mathematical algorithms and layers of interconnected neurons, making it challenging to in-
terpret their inner workings. The lack of transparency and interpretability pose difﬁculties
for ML models in explaining the observed phenomena and understanding the underlying
biological mechanisms. Hence, the ML models are often referred to as “black boxes” [99].
For this issue, employing visualization tools such as Activation Maximization [129], Local
Interpretable Model-agnostic Explanations (LIME) [130] and SHapley Additive exPlana-
tions (SHAP) [131] can help in understanding the model’s decision-making process by
providing insights into which features are most inﬂuential. In the future, a continuous
requirement is to develop robust models with high interpretability.
Therefore, a tremendous amount of work has been done to incorporate ML tools to
expedite the drug discovery cycle, but further advancement and improvement of these
tools is needed before the full potential of ML in drug discovery can be realized.
5. Concluding Remarks
The research and development of new drugs can contribute to meet the human de-
mand for treating diseases and provide more effective, safer, and more convenient treatment
options. Compared with the traditional strategies of drug discovery, ML-based approaches
have the potential to reduce time and costs, improve safety, and bridge the gap between
drug discovery and drug effectiveness, making them increasingly favored by the pharma-
ceutical industry and academia. In particular, the introduction of chatGPT has sparked
researchers’ growing interest and exploration in leveraging the Transformer model’s NLP
capabilities, particularly its self-attention mechanisms, to accelerate multiple stages of the
drug discovery process, thereby opening up new opportunities for advancements.
However, the current challenges in ML-based models can result in generating false
positives or false negatives, potentially leading to incorrect predictions and resource waste.
Further in vitro and in vivo experiments as well as clinical trials are needed to fully demon-
strate the practicability of ML-based drug discovery and obtain more reliable and accurate
results. Therefore, future research should focus on improving data quality, enhancing the in-
terpretability of ML algorithms, and integrating them with human professional knowledge
to increase the efﬁcacy of drug discovery.
Author Contributions: X.Q. and Y.Z. designed the review; Y.Z. collected the related data; X.Q. and
Y.Z. drafted the manuscript; X.Q., Y.Z., S.H., Z.Q. and J.C. revised the manuscript. All authors have
read and agreed to the published version of the manuscript.
Funding: This work was supported by the National Natural Science Foundation of China (Grant No.
32270705) and the Postgraduate Research & Practice Innovation Program of Jiangsu Province (Grant
No. KYCX23_3344).
Institutional Review Board Statement: Not applicable.
Informed Consent Statement: Not applicable.
Data Availability Statement: Not applicable.
Conﬂicts of Interest: The authors declare no conﬂicts of interest.

## Page 15 (Section: References)

Molecules 2024, 29, 903
15 of 20
Abbreviations
AI, artiﬁcial intelligence; ML, machine learning; DL, deep learning; ANN, artiﬁcial neural network;
NLP, natural language processing; DTI, drug–target interaction; 3D, three-dimensional; DNN, deep
neural network; PPI, protein–protein interaction; GAT, graph attention network; CNN, convolutional
neural network; VAE, variational auto-encoder; AAE, adversarial auto-encoder; RNN, recurrent
neural network; RF, random forest; XGBoost, eXtreme gradient boosting; GCN, graph convolutional
network; SVM, support vector machine; NBC, naïve Bayes classiﬁer; NTN, neural tensor network;
GAN, generative adversarial network; GCNN, graph convolutional neural network; ResNet, residual
network; GBM, gradient boosting machines; RL, reinforcement learning; GRU, gated recurrent unit;
GNN, graph neural networks; k-NN, k-nearest neighbor; LightGBM, light gradient boosting machine;
MCTS, Monte Carlo tree search, NTN, neural tensor network; GAN, generative adversarial network;
GCNN, graph convolutional neural network; ADME/T, absorption, distribution, metabolism, and
excretion and toxicity; BBB, blood–brain barrier; PPB, plasma protein binding, CYP2D6, cytochrome
P450 2D6; XGBoost, extreme gradient boosting; CYP450, cytochrome P450;MCTS, Monte Carlo Tree
Search; GPT, Generative Pre-Training Transformer; BERT, bidirectional encoder representations from
transformers; SC2, Challenge to Predict Aqueous Solubility; MCC, Matthews’ Correlation Coefﬁcient;
AUC, area under the curve; AUPR, area under precision-recall; PDB, Protein Data Bank; QED,
quantitative estimate of drug-likeness; SA, synthetic accessibility;NP, natural products; LIME, Local
Interpretable Model-agnostic Explanations; SHAP, SHapley Additive exPlanations.
References
1.
DiMasi, J.A.; Grabowski, H.G.; Hansen, R.W. Innovation in the pharmaceutical industry: New estimates of R&D costs. J. Health
Econ. 2016, 47, 20–33. [CrossRef] [PubMed]
2.
Ashburn, T.T.; Thor, K.B. Drug repositioning: Identifying and developing new uses for existing drugs. Nat. Rev. Drug Discov.
2004, 3, 673–683. [CrossRef]
3.
Dowden, H.; Munro, J. Trends in clinical success rates and therapeutic focus. Nat. Rev. Drug Discov. 2019, 18, 495–496. [CrossRef]
[PubMed]
4.
Deng, J.; Yang, Z.; Ojima, I.; Samaras, D.; Wang, F. Artiﬁcial intelligence in drug discovery: Applications and techniques. Brief.
Bioinform 2022, 23, bbab430. [CrossRef] [PubMed]
5.
Mak, K.K.; Pichika, M.R. Artiﬁcial intelligence in drug development: Present status and future prospects. Drug Discov. Today 2019,
24, 773–780. [CrossRef]
6.
Paul, D.; Sanap, G.; Shenoy, S.; Kalyane, D.; Kalia, K.; Tekade, R.K. Artiﬁcial intelligence in drug discovery and development.
Drug Discov. Today 2021, 26, 80–93. [CrossRef]
7.
Chen, H.; Engkvist, O.; Wang, Y.; Olivecrona, M.; Blaschke, T. The rise of deep learning in drug discovery. Drug Discov. Today
2018, 23, 1241–1250. [CrossRef]
8.
Wang, K.; Zhou, R.; Li, Y.; Li, M. DeepDTAF: A deep learning method to predict protein-ligand binding afﬁnity. Brief. Bioinform.
2021, 22, bbab072. [CrossRef]
9.
Karimi, M.; Wu, D.; Wang, Z.; Shen, Y. DeepAfﬁnity: Interpretable deep learning of compound-protein afﬁnity through uniﬁed
recurrent and convolutional neural networks. Bioinformatics 2019, 35, 3329–3338. [CrossRef]
10.
Zhang, S.; Fan, R.; Liu, Y.; Chen, S.; Liu, Q.; Zeng, W. Applications of transformer-based language models in bioinformatics:
A survey. Bioinform. Adv. 2023, 3, vbad001. [CrossRef]
11.
Vaswani, A.; Shazeer, N.; Parmar, N.; Uszkoreit, J.; Jones, L.; Gomez, A.N.; Kaiser, Ł.; Polosukhin, I. Attention is all you need. Adv.
Neural Inf. Process. Syst. 2017, 30, 1–11.
12.
Kalakoti, Y.; Yadav, S.; Sundar, D. TransDTI: Transformer-Based Language Models for Estimating DTIs and Building a Drug
Recommendation Workﬂow. ACS Omega 2022, 7, 2706–2717. [CrossRef] [PubMed]
13.
Du, Z.; Su, H.; Wang, W.; Ye, L.; Wei, H.; Peng, Z.; Anishchenko, I.; Baker, D.; Yang, J. The trRosetta server for fast and accurate
protein structure prediction. Nat. Protoc. 2021, 16, 5634–5651. [CrossRef]
14.
Senior, A.W.; Evans, R.; Jumper, J.; Kirkpatrick, J.; Sifre, L.; Green, T.; Qin, C.; Žídek, A.; Nelson, A.W.R.; Bridgland, A.; et al.
Improved protein structure prediction using potentials from deep learning. Nature 2020, 577, 706–710. [CrossRef]
15.
Zhang, L.; Wang, S.; Hou, J.; Si, D.; Zhu, J.; Cao, R. ComplexQA: A deep graph learning approach for protein complex structure
assessment. Brief. Bioinform. 2023, 24, bbad287. [CrossRef] [PubMed]
16.
Brandes, N.; Ofer, D.; Peleg, Y.; Rappoport, N.; Linial, M. ProteinBERT: A universal deep-learning model of protein sequence and
function. Bioinformatics 2022, 38, 2102–2110. [CrossRef]
17.
Lin, Z.; Akin, H.; Rao, R.; Hie, B.; Zhu, Z.; Lu, W.; Smetanin, N.; Verkuil, R.; Kabeli, O.; Shmueli, Y.; et al. Evolutionary-scale
prediction of atomic-level protein structure with a language model. Science 2023, 379, 1123–1130. [CrossRef]

## Page 16 (Section: References)

Molecules 2024, 29, 903
16 of 20
18.
Northey, T.C.; Bareši´c, A.; Martin, A.C.R. IntPred: A structure-based predictor of protein-protein interaction sites. Bioinformatics
2018, 34, 223–229. [CrossRef]
19.
Maheshwari, S.; Brylinski, M. Template-based identiﬁcation of protein-protein interfaces using eFindSitePPI. Methods 2016, 93,
64–71. [CrossRef]
20.
Li, Y.; Golding, G.B.; Ilie, L. DELPHI: Accurate deep ensemble model for protein interaction sites prediction. Bioinformatics 2021,
37, 896–904. [CrossRef]
21.
Wang, X.; Zhang, Y.; Yu, B.; Salhi, A.; Chen, R.; Wang, L.; Liu, Z. Prediction of protein-protein interaction sites through eXtreme
gradient boosting with kernel principal component analysis. Comput. Biol. Med. 2021, 134, 104516. [CrossRef]
22.
Kang, Y.; Xu, Y.; Wang, X.; Pu, B.; Yang, X.; Rao, Y.; Chen, J. HN-PPISP: A hybrid network based on MLP-Mixer for protein-protein
interaction site prediction. Brief. Bioinform. 2023, 24, bbac480. [CrossRef]
23.
Song, B.; Luo, X.; Luo, X.; Liu, Y.; Niu, Z.; Zeng, X. Learning spatial structures of proteins improves protein-protein interaction
prediction. Brief. Bioinform. 2022, 23, bbab558. [CrossRef] [PubMed]
24.
Baranwal, M.; Magner, A.; Saldinger, J.; Turali-Emre, E.S.; Elvati, P.; Kozarekar, S.; VanEpps, J.S.; Kotov, N.A.; Violi, A.; Hero, A.O.
Struct2Graph: A graph attention network for structure based predictions of protein-protein interactions. BMC Bioinform. 2022, 23,
370. [CrossRef] [PubMed]
25.
Yao, Y.; Du, X.; Diao, Y.; Zhu, H. An integration of deep learning with feature embedding for protein-protein interaction prediction.
PeerJ 2019, 7, e7126. [CrossRef]
26.
Huang, Y.; Wuchty, S.; Zhou, Y.; Zhang, Z. SGPPI: Structure-aware prediction of protein-protein interactions in rigorous conditions
with graph convolutional network. Brief. Bioinform. 2023, 24, bbad020. [CrossRef]
27.
Du, X.; Sun, S.; Hu, C.; Yao, Y.; Yan, Y.; Zhang, Y. DeepPPI: Boosting Prediction of Protein-Protein Interactions with Deep Neural
Networks. J. Chem. Inf. Model. 2017, 57, 1499–1510. [CrossRef] [PubMed]
28.
Wu, J.; Liu, B.; Zhang, J.; Wang, Z.; Li, J. DL-PPI: A method on prediction of sequenced protein-protein interaction based on deep
learning. BMC Bioinform. 2023, 24, 473. [CrossRef]
29.
Zhang, F.; Zhang, Y.; Zhu, X.; Chen, X.; Lu, F.; Zhang, X. DeepSG2PPI: A Protein-Protein Interaction Prediction Method Based on
Deep Learning. IEEE/ACM Trans. Comput. Biol. Bioinform. 2023, 20, 2907–2919. [CrossRef] [PubMed]
30.
Ghosh, S.; Mitra, P. MaTPIP: A deep-learning architecture with eXplainable AI for sequence-driven, feature mixed protein-protein
interaction prediction. Comput. Methods Programs Biomed. 2024, 244, 107955. [CrossRef]
31.
Soleymani, F.; Paquet, E.; Viktor, H.L.; Michalowski, W.; Spinello, D. ProtInteract: A deep learning framework for predicting
protein-protein interactions. Comput. Struct. Biotechnol. J. 2023, 21, 1324–1348. [CrossRef]
32.
Cui, Y.; Dong, Q.; Hong, D.; Wang, X. Predicting protein-ligand binding residues with deep convolutional neural networks. BMC
Bioinform. 2019, 20, 93. [CrossRef]
33.
Mylonas, S.K.; Axenopoulos, A.; Daras, P. DeepSurf: A surface-based deep learning approach for the prediction of ligand binding
sites on proteins. Bioinformatics 2021, 37, 1681–1690. [CrossRef]
34.
Jendele, L.; Krivak, R.; Skoda, P.; Novotny, M.; Hoksza, D. PrankWeb: A web server for ligand binding site prediction and
visualization. Nucleic Acids Res. 2019, 47, W345–w349. [CrossRef]
35.
Kandel, J.; Tayara, H.; Chong, K.T. PUResNet: Prediction of protein-ligand binding sites using deep residual neural network.
J. Cheminform. 2021, 13, 65. [CrossRef] [PubMed]
36.
Zhou, Y.; Jiang, Y.; Yang, Y. AGAT-PPIS: A novel protein-protein interaction site predictor based on augmented graph attention
network with initial residual and identity mapping. Brief. Bioinform. 2023, 24, bbad122. [CrossRef] [PubMed]
37.
Öztürk, H.; Özgür, A.; Ozkirimli, E. DeepDTA: Deep drug-target binding afﬁnity prediction. Bioinformatics 2018, 34, i821–i829.
[CrossRef] [PubMed]
38.
He, T.; Heidemeyer, M.; Ban, F.; Cherkasov, A.; Ester, M. SimBoost: A read-across approach for predicting drug-target binding
afﬁnities using gradient boosting machines. J. Cheminform. 2017, 9, 24. [CrossRef]
39.
Ahmed, A.; Mam, B.; Sowdhamini, R. DEELIG: A Deep Learning Approach to Predict Protein-Ligand Binding Afﬁnity. Bioinform.
Biol. Insights 2021, 15, 11779322211030364. [CrossRef]
40.
Karlov, D.S.; Sosnin, S.; Fedorov, M.V.; Popov, P. graphDelta: MPNN Scoring Function for the Afﬁnity Prediction of Protein-Ligand
Complexes. ACS Omega 2020, 5, 5150–5159. [CrossRef]
41.
Feinberg, E.N.; Sur, D.; Wu, Z.; Husic, B.E.; Mai, H.; Li, Y.; Sun, S.; Yang, J.; Ramsundar, B.; Pande, V.S. PotentialNet for Molecular
Property Prediction. ACS Cent. Sci. 2018, 4, 1520–1530. [CrossRef]
42.
Liyaqat, T.; Ahmad, T.; Saxena, C. TeM-DTBA: Time-efﬁcient drug target binding afﬁnity prediction using multiple modalities
with Lasso feature selection. J. Comput. Aided Mol. Des. 2023, 37, 573–584. [CrossRef]
43.
Wang, C.; Chen, Y.; Zhang, Y.; Li, K.; Lin, M.; Pan, F.; Wu, W.; Zhang, J. A reinforcement learning approach for protein-ligand
binding pose prediction. BMC Bioinform. 2022, 23, 368. [CrossRef]
44.
Nguyen, D.D.; Cang, Z.; Wu, K.; Wang, M.; Cao, Y.; Wei, G.W. Mathematical deep learning for pose and binding afﬁnity prediction
and ranking in D3R Grand Challenges. J. Comput. Aided Mol. Des. 2019, 33, 71–82. [CrossRef]
45.
Wang, L.; Zhou, Y.; Chen, Q. AMMVF-DTI: A Novel Model Predicting Drug-Target Interactions Based on Attention Mechanism
and Multi-View Fusion. Int. J. Mol. Sci. 2023, 24, 14142. [CrossRef]

## Page 17 (Section: References)

Molecules 2024, 29, 903
17 of 20
46.
Popova, M.; Isayev, O.; Tropsha, A. Deep reinforcement learning for de novo drug design. Sci. Adv. 2018, 4, eaap7885. [CrossRef]
[PubMed]
47.
Gómez-Bombarelli, R.; Wei, J.N.; Duvenaud, D.; Hernández-Lobato, J.M.; Sánchez-Lengeling, B.; Sheberla, D.; Aguilera-
Iparraguirre, J.; Hirzel, T.D.; Adams, R.P.; Aspuru-Guzik, A. Automatic Chemical Design Using a Data-Driven Continuous
Representation of Molecules. ACS Cent. Sci. 2018, 4, 268–276. [CrossRef] [PubMed]
48.
Li, Y.; Zhang, L.; Liu, Z. Multi-objective de novo drug design with conditional graph generative model. J. Cheminform. 2018, 10, 33.
[CrossRef] [PubMed]
49.
Born, J.; Manica, M.; Oskooei, A.; Cadow, J.; Markert, G.; Rodríguez Martínez, M. PaccMann(RL): De novo generation of hit-like
anticancer molecules from transcriptomic data via reinforcement learning. iScience 2021, 24, 102269. [CrossRef]
50.
Kadurin, A.; Nikolenko, S.; Khrabrov, K.; Aliper, A.; Zhavoronkov, A. druGAN: An Advanced Generative Adversarial Autoen-
coder Model for de Novo Generation of New Molecules with Desired Molecular Properties in Silico. Mol. Pharm. 2017, 14,
3098–3104. [CrossRef]
51.
Coley, C.W.; Rogers, L.; Green, W.H.; Jensen, K.F. SCScore: Synthetic Complexity Learned from a Reaction Corpus. J. Chem. Inf.
Model. 2018, 58, 252–261. [CrossRef] [PubMed]
52.
Schoenmaker, L.; Béquignon, O.J.M.; Jespers, W.; van Westen, G.J.P. UnCorrupt SMILES: A novel approach to de novo design.
J. Cheminform. 2023, 15, 22. [CrossRef] [PubMed]
53.
Wang, X.; Gao, C.; Han, P.; Li, X.; Chen, W.; Rodríguez Patón, A.; Wang, S.; Zheng, P. PETrans: De Novo Drug Design with
Protein-Speciﬁc Encoding Based on Transfer Learning. Int. J. Mol. Sci. 2023, 24, 1146. [CrossRef] [PubMed]
54.
Monteiro, N.R.C.; Pereira, T.O.; Machado, A.C.D.; Oliveira, J.L.; Abbasi, M.; Arrais, J.P. FSM-DDTR: End-to-end feedback strategy
for multi-objective De Novo drug design using transformers. Comput. Biol. Med. 2023, 164, 107285. [CrossRef] [PubMed]
55.
Song, T.; Ren, Y.; Wang, S.; Han, P.; Wang, L.; Li, X.; Rodriguez-Patón, A. DNMG: Deep molecular generative model by fusion of
3D information for de novo drug design. Methods 2023, 211, 10–22. [CrossRef]
56.
Macedo, B.; Ribeiro Vaz, I.; Taveira Gomes, T. MedGAN: Optimized generative adversarial network with graph convolutional
networks for novel molecule design. Sci. Rep. 2024, 14, 1212. [CrossRef]
57.
Panapitiya, G.; Girard, M.; Hollas, A.; Sepulveda, J.; Murugesan, V.; Wang, W.; Saldanha, E. Evaluation of Deep Learning
Architectures for Aqueous Solubility Prediction. ACS Omega 2022, 7, 15695–15710. [CrossRef]
58.
Francoeur, P.G.; Koes, D.R. SolTranNet-A Machine Learning Tool for Fast Aqueous Solubility Prediction. J. Chem. Inf. Model. 2021,
61, 2530–2536. [CrossRef]
59.
Zang, Q.; Mansouri, K.; Williams, A.J.; Judson, R.S.; Allen, D.G.; Casey, W.M.; Kleinstreuer, N.C. In Silico Prediction of
Physicochemical Properties of Environmental Chemicals Using Molecular Fingerprints and Machine Learning. J. Chem. Inf. Model.
2017, 57, 36–49. [CrossRef]
60.
Tian, H.; Ketkar, R.; Tao, P. ADMETboost: A web server for accurate ADMET prediction. J. Mol. Model. 2022, 28, 408. [CrossRef]
61.
Schyman, P.; Liu, R.; Desai, V.; Wallqvist, A. vNN Web Server for ADMET Predictions. Front. Pharmacol. 2017, 8, 889. [CrossRef]
[PubMed]
62.
Wei, Y.; Li, S.; Li, Z.; Wan, Z.; Lin, J. Interpretable-ADMET: A web service for ADMET prediction and optimization based on deep
neural representation. Bioinformatics 2022, 38, 2863–2871. [CrossRef] [PubMed]
63.
Deng, D.; Chen, X.; Zhang, R.; Lei, Z.; Wang, X.; Zhou, F. XGraphBoost: Extracting Graph Neural Network-Based Features for a
Better Prediction of Molecular Properties. J. Chem. Inf. Model. 2021, 61, 2697–2705. [CrossRef] [PubMed]
64.
Mayr, A.; Klambauer, G.; Unterthiner, T.; Hochreiter, S. DeepTox: Toxicity prediction using deep learning. Front. Environ. Sci.
2016, 3, 80. [CrossRef]
65.
Li, X.; Xu, Y.; Lai, L.; Pei, J. Prediction of Human Cytochrome P450 Inhibition Using a Multitask Deep Autoencoder Neural
Network. Mol. Pharm. 2018, 15, 4336–4345. [CrossRef]
66.
Shaker, B.; Yu, M.S.; Song, J.S.; Ahn, S.; Ryu, J.Y.; Oh, K.S.; Na, D. LightBBB: Computational prediction model of blood-brain-barrier
penetration based on LightGBM. Bioinformatics 2021, 37, 1135–1139. [CrossRef]
67.
Tang, Q.; Nie, F.; Zhao, Q.; Chen, W. A merged molecular representation deep learning method for blood-brain barrier permeability
prediction. Brief. Bioinform. 2022, 23, bbac357. [CrossRef]
68.
Jang, W.D.; Jang, J.; Song, J.S.; Ahn, S.; Oh, K.S. PredPS: Attention-based graph neural network for predicting stability of
compounds in human plasma. Comput. Struct. Biotechnol. J. 2023, 21, 3532–3539. [CrossRef]
69.
Khaouane, A.; Khaouane, L.; Ferhat, S.; Hanini, S. Deep Learning for Drug Development: Using CNNs in MIA-QSAR to Predict
Plasma Protein Binding of Drugs. AAPS PharmSciTech 2023, 24, 232. [CrossRef] [PubMed]
70.
Zeng, X.; Zhu, S.; Lu, W.; Liu, Z.; Huang, J.; Zhou, Y.; Fang, J.; Huang, Y.; Guo, H.; Li, L.; et al. Target identiﬁcation among known
drugs by deep learning from heterogeneous networks. Chem. Sci. 2020, 11, 1775–1797. [CrossRef] [PubMed]
71.
Wan, F.; Hong, L.; Xiao, A.; Jiang, T.; Zeng, J. NeoDTI: Neural integration of neighbor information from a heterogeneous network
for discovering new drug-target interactions. Bioinformatics 2019, 35, 104–111. [CrossRef]
72.
Luo, Y.; Zhao, X.; Zhou, J.; Yang, J.; Zhang, Y.; Kuang, W.; Peng, J.; Chen, L.; Zeng, J. A network integration approach for
drug-target interaction prediction and computational drug repositioning from heterogeneous information. Nat. Commun. 2017, 8,
573. [CrossRef]

## Page 18 (Section: References)

Molecules 2024, 29, 903
18 of 20
73.
Luo, H.; Wang, J.; Li, M.; Luo, J.; Peng, X.; Wu, F.X.; Pan, Y. Drug repositioning based on comprehensive similarity measures and
Bi-Random walk algorithm. Bioinformatics 2016, 32, 2664–2671. [CrossRef]
74.
Doshi, S.; Chepuri, S.P. A computational approach to drug repurposing using graph neural networks. Comput. Biol. Med. 2022,
150, 105992. [CrossRef] [PubMed]
75.
Zeng, X.; Zhu, S.; Liu, X.; Zhou, Y.; Nussinov, R.; Cheng, F. deepDR: A network-based deep learning approach to in silico drug
repositioning. Bioinformatics 2019, 35, 5191–5198. [CrossRef]
76.
Jiang, H.J.; Huang, Y.A.; You, Z.H. Predicting Drug-Disease Associations via Using Gaussian Interaction Proﬁle and Kernel-Based
Autoencoder. BioMed Res. Int. 2019, 2019, 2426958. [CrossRef]
77.
Ghorbanali, Z.; Zare-Mirakabad, F.; Salehi, N.; Akbari, M.; Masoudi-Nejad, A. DrugRep-HeSiaGraph: When heterogenous
siamese neural network meets knowledge graphs for drug repurposing. BMC Bioinform. 2023, 24, 374. [CrossRef] [PubMed]
78.
Suviriyapaisal, N.; Wichadakul, D. iEdgeDTA: Integrated edge information and 1D graph convolutional neural networks for
binding afﬁnity prediction. RSC Adv. 2023, 13, 25218–25228. [CrossRef]
79.
Segler, M.H.S.; Preuss, M.; Waller, M.P. Planning chemical syntheses with deep neural networks and symbolic AI. Nature 2018,
555, 604–610. [CrossRef]
80.
Liu, B.; Ramsundar, B.; Kawthekar, P.; Shi, J.; Gomes, J.; Luu Nguyen, Q.; Ho, S.; Sloane, J.; Wender, P.; Pande, V. Retrosynthetic
Reaction Prediction Using Neural Sequence-to-Sequence Models. ACS Cent. Sci. 2017, 3, 1103–1113. [CrossRef]
81.
Thakkar, A.; Chadimová, V.; Bjerrum, E.J.; Engkvist, O.; Reymond, J.L. Retrosynthetic accessibility score (RAscore)—Rapid
machine learned synthesizability classiﬁcation from AI driven retrosynthetic planning. Chem. Sci. 2021, 12, 3339–3349. [CrossRef]
82.
Wei, J.N.; Duvenaud, D.; Aspuru-Guzik, A. Neural Networks for the Prediction of Organic Chemistry Reactions. ACS Cent. Sci.
2016, 2, 725–732. [CrossRef]
83.
Coley, C.W.; Barzilay, R.; Jaakkola, T.S.; Green, W.H.; Jensen, K.F. Prediction of Organic Reaction Outcomes Using Machine
Learning. ACS Cent. Sci. 2017, 3, 434–443. [CrossRef]
84.
Gao, H.; Struble, T.J.; Coley, C.W.; Wang, Y.; Green, W.H.; Jensen, K.F. Using Machine Learning To Predict Suitable Conditions for
Organic Reactions. ACS Cent. Sci. 2018, 4, 1465–1476. [CrossRef]
85.
Marcou, G.; Aires de Sousa, J.; Latino, D.A.; de Luca, A.; Horvath, D.; Rietsch, V.; Varnek, A. Expert system for predicting reaction
conditions: The Michael reaction case. J. Chem. Inf. Model. 2015, 55, 239–250. [CrossRef]
86.
You, Z.H.; Li, S.; Gao, X.; Luo, X.; Ji, Z. Large-scale protein-protein interactions detection by integrating big biosensing data with
computational model. BioMed Res. Int. 2014, 2014, 598129. [CrossRef]
87.
Chan, H.C.S.; Shan, H.; Dahoun, T.; Vogel, H.; Yuan, S. Advancing Drug Discovery via Artiﬁcial Intelligence. Trends Pharmacol.
Sci. 2019, 40, 592–604. [CrossRef]
88.
Muhammed, M.T.; Aki-Yalcin, E. Homology modeling in drug discovery: Overview, current applications, and future perspectives.
Chem. Biol. Drug Des. 2019, 93, 12–20. [CrossRef]
89.
Zhang, Y.; Skolnick, J. The protein structure prediction problem could be solved using the current PDB library. Proc. Natl. Acad.
Sci. USA 2005, 102, 1029–1034. [CrossRef]
90.
Tang, T.; Zhang, X.; Liu, Y.; Peng, H.; Zheng, B.; Yin, Y.; Zeng, X. Machine learning on protein-protein interaction prediction:
Models, challenges and trends. Brief. Bioinform. 2023, 24, bbad076. [CrossRef]
91.
Soleymani, F.; Paquet, E.; Viktor, H.; Michalowski, W.; Spinello, D. Protein-protein interaction prediction with deep learning:
A comprehensive review. Comput. Struct. Biotechnol. J. 2022, 20, 5316–5341. [CrossRef]
92.
Li, S.; Wu, S.; Wang, L.; Li, F.; Jiang, H.; Bai, F. Recent advances in predicting protein-protein interactions with the aid of artiﬁcial
intelligence algorithms. Curr. Opin. Struct. Biol. 2022, 73, 102344. [CrossRef]
93.
Tripathi, N.; Goshisht, M.K.; Sahu, S.K.; Arora, C. Applications of artiﬁcial intelligence to drug design and discovery in the big
data era: A comprehensive review. Mol. Divers. 2021, 25, 1643–1664. [CrossRef]
94.
Dhakal, A.; McKay, C.; Tanner, J.J.; Cheng, J. Artiﬁcial intelligence in the prediction of protein-ligand interactions: Recent advances
and future directions. Brief. Bioinform. 2022, 23, bbab476. [CrossRef]
95.
Nicolaou, C.A.; Kannas, C.; Loizidou, E. Multi-objective optimization methods in de novo drug design. Mini Rev. Med. Chem.
2012, 12, 979–987. [CrossRef]
96.
Zhong, F.; Xing, J.; Li, X.; Liu, X.; Fu, Z.; Xiong, Z.; Lu, D.; Wu, X.; Zhao, J.; Tan, X.; et al. Artiﬁcial intelligence in drug design. Sci.
China. Life Sci. 2018, 61, 1191–1204. [CrossRef]
97.
Hessler, G.; Baringhaus, K.H. Artiﬁcial Intelligence in Drug Design. Molecules 2018, 23, 2520. [CrossRef]
98.
Schneider, G.; Funatsu, K.; Okuno, Y.; Winkler, D. De novo Drug Design—Ye olde Scoring Problem Revisited. Mol. Inform. 2017,
36, 1681031. [CrossRef]
99.
Wang, L.; Ding, J.; Pan, L.; Cao, D.; Jiang, H.; Ding, X. Artiﬁcial intelligence facilitates drug design in the big data era. Chemom.
Intell. Lab. Syst. 2019, 194, 103850. [CrossRef]
100. Yang, X.; Wang, Y.; Byrne, R.; Schneider, G.; Yang, S. Concepts of Artiﬁcial Intelligence for Computer-Assisted Drug Discovery.
Chem. Rev. 2019, 119, 10520–10594. [CrossRef]
101. Yu, E.; Xu, Y.; Shi, Y.; Yu, Q.; Liu, J.; Xu, L. Discovery of novel natural compound inhibitors targeting estrogen receptor α by an
integrated virtual screening strategy. J. Mol. Model. 2019, 25, 278. [CrossRef]

## Page 19 (Section: References)

Molecules 2024, 29, 903
19 of 20
102. Zhong, W.; Zhao, L.; Yang, Z.; Yu-Chian Chen, C. Graph convolutional network approach to investigate potential selective Limk1
inhibitors. J. Mol. Graph. Model. 2021, 107, 107965. [CrossRef]
103. Zhou, Y.; Wang, F.; Tang, J.; Nussinov, R.; Cheng, F. Artiﬁcial intelligence in COVID-19 drug repurposing. Lancet Digit. Health
2020, 2, e667–e676. [CrossRef]
104. Pan, X.; Lin, X.; Cao, D.; Zeng, X.; Yu, P.S.; He, L.; Nussinov, R.; Cheng, F. Deep learning for drug repurposing: Methods, databases,
and applications. Wiley Interdiscip. Rev. Comput. Mol. Sci. 2022, 12, e1597. [CrossRef]
105. Dong, J.; Zhao, M.; Liu, Y.; Su, Y.; Zeng, X. Deep learning in retrosynthesis planning: Datasets, models and tools. Brief. Bioinform.
2022, 23, bbab391. [CrossRef] [PubMed]
106. Lee, A.A.; Yang, Q.; Sresht, V.; Bolgar, P.; Hou, X.; Klug-McLeod, J.L.; Butler, C.R. Molecular Transformer uniﬁes reaction
prediction and retrosynthesis across pharma chemical space. Chem. Commun. 2019, 55, 12152–12155. [CrossRef]
107. Yan, X.; Liu, Y. Graph-sequence attention and transformer for predicting drug-target afﬁnity. RSC Adv. 2022, 12, 29525–29534.
[CrossRef]
108. Lee, M. Recent Advances in Deep Learning for Protein-Protein Interaction Analysis: A Comprehensive Review. Molecules 2023,
28, 5169. [CrossRef]
109. Lin, P.; Yan, Y.; Huang, S.Y. DeepHomo2.0: Improved protein-protein contact prediction of homodimers by transformer-enhanced
deep learning. Brief. Bioinform. 2023, 24, bbac499. [CrossRef] [PubMed]
110. Kang, Y.; Elofsson, A.; Jiang, Y.; Huang, W.; Yu, M.; Li, Z. AFTGAN: Prediction of multi-type PPI based on attention free
transformer and graph attention network. Bioinformatics 2023, 39, btad052. [CrossRef]
111. Zhang, P.; Wei, Z.; Che, C.; Jin, B. DeepMGT-DTI: Transformer network incorporating multilayer graph information for Drug-
Target interaction prediction. Comput. Biol. Med. 2022, 142, 105214. [CrossRef]
112. Qian, H.; Lin, C.; Zhao, D.; Tu, S.; Xu, L. AlphaDrug: Protein target speciﬁc de novo molecular generation. PNAS Nexus 2022,
1, pgac227. [CrossRef]
113. Radford, A.; Narasimhan, K.; Salimans, T.; Sutskever, I. Improving Language Understanding by Generative Pre-Training. 2018.
Available online: https://www.mikecaptain.com/resources/pdf/GPT-1.pdf (accessed on 14 January 2024).
114. Wang, Y.; Zhao, H.; Sciabola, S.; Wang, W. cMolGPT: A Conditional Generative Pre-Trained Transformer for Target-Speciﬁc De
Novo Molecular Generation. Molecules 2023, 28, 4430. [CrossRef]
115. Chithrananda, S.; Grand, G.; Ramsundar, B. ChemBERTa: Large-scale self-supervised pretraining for molecular property
prediction. arXiv 2020, arXiv:2010.09885.
116. Devlin, J.; Chang, M.-W.; Lee, K.; Toutanova, K. Bert: Pre-training of deep bidirectional transformers for language understanding.
arXiv 2018, arXiv:1810.04805.
117. Liu, Z.; Roberts, R.A.; Lal-Nag, M.; Chen, X.; Huang, R.; Tong, W. AI-based language models powering drug discovery and
development. Drug Discov. Today 2021, 26, 2593–2607. [CrossRef] [PubMed]
118. Wu, Z.; Jiang, D.; Wang, J.; Zhang, X.; Du, H.; Pan, L.; Hsieh, C.Y.; Cao, D.; Hou, T. Knowledge-based BERT: A method to extract
molecular features like computational chemists. Brief. Bioinform. 2022, 23, bbac131. [CrossRef]
119. Wang, S.; Guo, Y.; Wang, Y.; Sun, H.; Huang, J. Smiles-bert: Large scale unsupervised pre-training for molecular property
prediction. In Proceedings of the 10th ACM International Conference on Bioinformatics, Computational Biology and Health
Informatics, Niagara Falls, NY, USA, 7–10 September 2019; pp. 429–436.
120. Schwaller, P.; Laino, T.; Gaudin, T.; Bolgar, P.; Hunter, C.A.; Bekas, C.; Lee, A.A. Molecular Transformer: A Model for Uncertainty-
Calibrated Chemical Reaction Prediction. ACS Cent. Sci. 2019, 5, 1572–1583. [CrossRef]
121. Andronov, M.; Voinarovska, V.; Andronova, N.; Wand, M.; Clevert, D.-A.; Schmidhuber, J. Reagent prediction with a molecular
transformer improves reaction data quality. Chem. Sci. 2023, 14, 3235–3246. [CrossRef]
122. Schwaller, P.; Petraglia, R.; Zullo, V.; Nair, V.H.; Haeuselmann, R.A.; Pisoni, R.; Bekas, C.; Iuliano, A.; Laino, T. Predicting
retrosynthetic pathways using transformer-based models and a hyper-graph exploration strategy. Chem. Sci. 2020, 11, 3316–3325.
[CrossRef]
123. Mamoshina, P.; Vieira, A.; Putin, E.; Zhavoronkov, A. Applications of Deep Learning in Biomedicine. Mol. Pharm. 2016, 13,
1445–1454. [CrossRef]
124. Lu, J.; Wang, C.; Zhang, Y. Predicting Molecular Energy Using Force-Field Optimized Geometries and Atomic Vector Representa-
tions Learned from an Improved Deep Tensor Neural Network. J. Chem. Theory Comput. 2019, 15, 4113–4121. [CrossRef]
125. Cai, C.; Wang, S.; Xu, Y.; Zhang, W.; Tang, K.; Ouyang, Q.; Lai, L.; Pei, J. Transfer Learning for Drug Discovery. J. Med. Chem. 2020,
63, 8683–8694. [CrossRef]
126. Altae-Tran, H.; Ramsundar, B.; Pappu, A.S.; Pande, V. Low Data Drug Discovery with One-Shot Learning. ACS Cent. Sci. 2017, 3,
283–293. [CrossRef]
127. Krizhevsky, A.; Sutskever, I.; Hinton, G.E. ImageNet classiﬁcation with deep convolutional neural networks. Commun. ACM 2017,
60, 84–90. [CrossRef]
128. Chang, M. AI for Drug Development and Well-Being.
2020.
Available online: http://ctrisoft.net/StatisticiansOrg/AI/
AIforWellbingebook5.5x8.5in.pdf (accessed on 14 January 2024).
129. Erhan, D.; Bengio, Y.; Courville, A.C.; Vincent, P. Visualizing Higher-Layer Features of a Deep Network; University of Montreal:
Montreal, QC, USA, 2009.

## Page 20 (Section: References)

Molecules 2024, 29, 903
20 of 20
130. Ribeiro, M.T.; Singh, S.; Guestrin, C. “Why Should I Trust You?”: Explaining the Predictions of Any Classiﬁer. In Proceedings of
the 22nd ACM SIGKDD International Conference on Knowledge Discovery and Data Mining, San Francisco, CA, USA, 13–17
August 2016; pp. 1135–1144.
131. Lundberg, S.M.; Lee, S.-I. A Uniﬁed Approach to Interpreting Model Predictions. In Proceedings of the Neural Information
Processing Systems, Long Beach, CA, USA, 4–9 December 2017.
Disclaimer/Publisher’s Note: The statements, opinions and data contained in all publications are solely those of the individual
author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to
people or property resulting from any ideas, methods, instructions or products referred to in the content.


---

# Machine-Learning-Guided Peptide Drug Discovery: Development of GLP-1 Receptor Agonists with Improved Drug Properties

- **Authors:** Jens Christian Nielsen, Claudia Hjo Rringgaard, Mads Mo Rup Nygaard, Anita Wester, Lisbeth Elster, Trine Porsgaard, Randi Bonke Mikkelsen, Silas Rasmussen, Andreas Nygaard Madsen, Morten Schlein, Niels Vrang, Kristoffer Rigbolt, Louise S Dalbo Ge
- **Issuer:** Journal of medicinal chemistry
- **Type:** Scientific article
- **Published:** 2024-07-08
- **Language:** en
- **DOI:** 10.1021/acs.jmedchem.4c00417
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38977267/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractPeptide-based drug discovery has surged with the development of peptide hormone-derived analogs for the treatment of diabetes and obesity. Machine learning (ML)-enabled quantitative structure–activity relationship (QSAR) approaches have shown great promise in small molecule drug discovery but have been less successful in peptide drug discovery due to limited data availability. We have developed a peptide drug discovery platform called streaMLine, enabling rigorous design, synthesis, screening, and ML-driven analysis of large peptide libraries. Using streaMLine, this study systematically explored secretin as a peptide backbone to generate potent, selective, and long-acting GLP-1R agonists with improved physicochemical properties. We synthesized and screened a total of 2688 peptides and applied ML-guided QSAR to identify multiple options for designing stable and potent GLP-1R agonists. One candidate, GUB021794, was profiled in vivo (S.C., 10 nmol/kg QD) and showed potent body weight loss in diet-induced obese mice and a half-life compatible with once-weekly dosing.

## Section: Introduction

Peptide-based therapeutics are gaining increasing attention in the pharmaceutical industry. Peptide hormones have both high receptor potency and selectivity, minimizing off-target effects and generally translating into an excellent drug safety and efficacy profile.1,2 These features make endogenous peptides a good starting point for the development of novel peptide therapeutics. However, native unmodified peptides are rarely used as drugs because of their inherent limitations due to their very short systemic half-life and unfavorable physicochemical properties which must be circumvented to develop peptide molecules suitable for therapeutic use.1,2

Early drug discovery phases aim to improve the properties of candidate molecules by modifying their chemical structure. Such improvements can be achieved by rational design using an iterative and often laborious approach, where small batches of compounds are screened in multiple rounds of optimization. In contrast, when larger data sets are available, it is useful to construct mathematical models that capture the quantitative structure–activity relationship (QSAR) to guide drug design. QSAR models have been widely used in the development of small molecule therapeutics e.g., to discover novel binders3 and elute chemical motifs necessary for binding.4 For peptide drug discovery, however, data are often sparse, and this has limited the use of machine learning (ML) for QSAR optimization. The amount and composition of data are crucial parameters for QSAR methods,5 which is why it is advantageous to generate data that are specifically designed for modeling purposes.

Glucagon-like peptide-1 (GLP-1) is an endogenous 30-amino acid peptide hormone produced by enteroendocrine L-cells and secreted into the hepatic portal in response to food intake. By activating GLP-1 receptors in the pancreas, native GLP-1 serves as an incretin hormone stimulating insulin release and inhibiting glucagon secretion.6 In addition, GLP-1 is an important appetite regulator by activating central GLP-1 receptors (GLP-1R).7 In line with this, long-acting GLP-1R agonists such as semaglutide have been shown to be important tools in the treatment of diabetes and obesity.8,9 However, GLP-1 is known to self-assemble into amyloid fibrils and the intrinsic physical instability of GLP-1 poses a significant challenge in synthesis and formulation.10,11

Recent drug development efforts have taken advantage of the varying degrees of sequence homology of GLP-1, glucagon, and glucose-dependent insulinotropic polypeptide (GIP) to engineer unimolecular dual or triple agonists targeting receptors of GLP-1, glucagon, and GIP. This approach has proven to be a successful concept for treatment intervention in diabetes and obesity.12−17

Alternatively, one could further envision to exploit sequence homology to obtain beneficial peptide properties not only in terms of receptor pharmacology, but also from a synthesis and/or formulation perspective.18

Secretin is a 27-amino acid peptide hormone that together with GLP-1 belongs to the glucagon superfamily of structurally related peptide hormones all targeting family B G-protein coupled receptors (GPCRs).19 This family of peptides is linear peptides comprising 25 or more residues allowing them to span two key receptor domains. The C-terminal region of the peptides binds to the extracellular domain of their respective receptor whereafter the N-terminal region interacts with the core domain of the receptor enabling receptor activation.20 The sequence identity of secretin and GLP-1 is shown in Table 1.

Contrary to other peptides of the glucagon family, such as GLP-1, secretin is not reported to aggregate.21 Thus, secretin could serve as the starting backbone with improved physicochemical properties compared to GLP-1.

The main physiological role of secretin is to regulate water homeostasis and bicarbonate secretion from the exocrine pancreas and inhibit gastric acid secretion by activating the secretin receptor (SCTR),19 i.e., endogenous activities we intended not to activate.

Hence, we aimed to leverage the more favorable physicochemical properties of secretin to develop a selective and physicochemical stable GLP-1R agonist based on the secretin backbone. With this aim, we exploited an innovative ML-based peptide drug discovery platform termed streaMLine and demonstrated how streaMLine effectively facilitates accelerated development of novel peptide-based therapeutics by rigorous design and ML-driven analysis of large peptide libraries.

## Section: Results

Overview of the data generation and data analysis workflow of the streaMLine platform. Initially a systematic library of peptides is designed, typically on the order of hundreds to thousands of peptides. The crude library of peptides are prepared using solid-phase-peptide synthesis (SPPS) and cleaved from the resin. Failed peptide samples are identified by high-resolution mass spectrometry and excluded from the analysis. A panel of high-throughput assays for determining receptor potency and physicochemical properties at different pH levels are measured. For each assay end point, a random forest model is trained and used for inferring key amino acids substitutions that determine peptide properties.

Schematic representation of the parallelized development process for generating a selective and stable GLP-1R agonist based on the secretin backbone. The two-step process for converting secretin into a preclinical drug candidate. First, a minimal GLP-1R agonist was developed by introducing only necessary GLP-1 residues to provide activation of GLP-1R. Second, a parallelized workflow was initiated where a deep mutational scan, a glutamate scan, and a lipidation scan provided a blueprint for generating various soluble, physically stable, and half-life extended GLP-1R agonist.

Overview of substitution-effects from a GLP-1 dial-in scan in the secretin backbone. (A) Effect of introducing GLP-1 residues into the secretin backbone. For each assay end point, a random forest model was trained on 768 peptides and used to compute SHAP values determining the level of contribution of each amino acid substitution. Delta mean SHAP values denote the contribution of substituting the secretin residue with the corresponding GLP-1 residue. (B) Detailed overview of SHAP values for selected positions, where substitutions were introduced to obtain analogs with dual GLP-1R and SCTR potency. Small points denote SHAP values per individual peptide and large points denote mean SHAP value.

Overview of substitution-effects from a deep mutational scan (DMS) in a secretin derived GLP-1R and SCTR dual agonist. (A) Effect of single mutations in all positions. For GLP-1R and SCTR potency, random forest models were trained on 1152 peptides encoded using z-scales.23 From the models, the effect of single mutations was computed to normalize for assay batch effects. (B) Detailed overview of selected positions highlighting the effect of individual substitutions.

Overview of substitution-effects from glutamate scan and half-life extender (HLE) scan in a secretin-derived GLP-1R and SCTR dual agonist. (A) Effect of introducing HLEs or glutamate. For each assay end point, a random forest model was trained on 576 peptides and used to compute SHAP values determining the level of contribution of each amino acid substitution. Delta mean SHAP values denote the contribution of substituting the backbone residue with either a glutamate or HLE. (B) Detailed overview of SHAP values for selected positions that tolerate HLE derivatization or glutamate substitution for improving half-life and solubility, respectively. Small points denote SHAP values per individual peptide and large points denote mean SHAP value.

Overview of substitution-effects from selected substitutions in secretin derived selective GLP-1R agonist. Effect of combining selected substitutions identified in the deep mutational scan, HLE scan, and glutamate scan. For each assay end point a random forest model was trained on 192 peptides and used to determine SHAP values determining the level of contribution of each amino acid substitution. Mean SHAP values denote the contribution of each substitution relative to the data set mean.

GUB021794 dose dependently reduces body weight and adipose tissue mass in DIO mice. DIO mice were treated subcutaneously once daily (QD) with vehicle, semaglutide (10 nmol/kg), and ascending doses of GUB021794 (3, 10, or 30 nmol/kg) for 28 days. (A) Body weight. (B) Body weight change (% of day 1) at the end of the study. (C) Daily food intake. (D) Cumulative food intake day 28. (E) Fat mass day 28. (F) Plasma exposure day 29, (samples taken 24 h after dosing). Values expressed as mean of n = 10 + SEM. Dunnett’s test one-factor linear model. *: P < 0.05, **: P < 0.01, ***: P < 0.001 compared to Vehicle.

## Section: Results › The streaMLine Platform

The streamline platform is a drug development tool where peptide libraries are designed, synthesized, and screened to provide large data sets suitable for machine learning (ML)-enabled quantitative structure–activity relationship (QSAR) approaches. An overview of the learning cycles in the streamline platform is illustrated in Figure 1.

In the streaMLine platform, peptides are synthesized using solid-phase peptide synthesis (SPPS) in a plate format. The crude peptide libraries are screened directly in functional potency assays and in preformulation assays for determination of, for example, fibrillation and solubility. Each peptide library is analyzed by using high-resolution mass spectrometry (HRMS) to determine purity. The average purity per library ranges between 30 and 50%, and peptide samples with less than 10% purity are excluded from further analysis.

The peptide libraries are designed in a highly systematic manner, where each substitution is observed multiple times in combination with other substitutions. Typically, peptide libraries consist of hundreds to thousands of peptides, which enables robust evaluation of each substitution in multiple chemical contexts, i.e., different backbones. The peptide sequences together with assay data are used as training data to construct random forest models22 describing the relationship between peptide sequence and assay end point. In the training data, the systematic peptide library is encoded using amino acid descriptors (z-scales23 or one-hot encoding), and potential laboratory batch effects are incorporated in the model to normalize, e.g., synthesis and assay plate differences. For each assay end point, a new model is trained and used for inferring the key amino acid substitutions affecting the end point. Model inference is done either by (1) correcting assay data for batch effects and amino acid similarity and thereby computing normalized assay measurements for individual peptides, (2) or by computing Shapley Additive explanation (SHAP) values.24 SHAP values are used to explain the effect of each amino acid substitution on the end point and can thus be used to infer the key drivers in the data set. After model inference, the most promising substitutions are assessed in a new peptide library design.

Data points obtained on crude peptides are challenging to interpret individually, but in the context of the systematically designed peptide libraries, the random forest model provides accurate guidance for identifying the effect of substitutions. The performances of all models generated in this study are given in Figure S1.

Overview of the data generation and data analysis workflow of the streaMLine platform. Initially a systematic library of peptides is designed, typically on the order of hundreds to thousands of peptides. The crude library of peptides are prepared using solid-phase-peptide synthesis (SPPS) and cleaved from the resin. Failed peptide samples are identified by high-resolution mass spectrometry and excluded from the analysis. A panel of high-throughput assays for determining receptor potency and physicochemical properties at different pH levels are measured. For each assay end point, a random forest model is trained and used for inferring key amino acids substitutions that determine peptide properties.

## Section: Results › Development of Dual GLP-1R-SCTR Agonists

We applied the streaMLine platform to generate selective GLP-1R agonists with suitable physicochemical parameters starting from the secretin backbone.

The native secretin peptide has no GLP-1R potency, hence to identify both desired substitutions a starting point with some GLP-1R potency was needed. We therefore aimed at generating first a dual GLP-1R-SCTR agonist that could be used as an intermediate for further optimization (Figure 2).

A peptide library was designed to evaluate the effect of introducing GLP-1 residues into the native secretin. Nonconserved residues (position 2–3, 9–10, 12–14, and 17–25), were changed into the corresponding GLP-1 residue, one at a time or in combinations (Table 1). The library (768 peptides) was screened by determining GLP-1R and SCTR potency (EC50), fibril formation (ThT assay), and solubility (turbidity), and random forest models were trained to determine the relationship between measured end points and the amino acid sequence of peptides. From these models, we computed SHAP values to determine the level of contribution of each substitution.22 Substitutions with positive SHAP values increase the end point, while substitutions with negative SHAP values decrease the end point.

Amino acid positions 2, 9, 18, and 22 had the highest positive SHAP values for GLP-1R EC50, thus being critical for improving GLP-1R potency. Conversely, positions 3, 9, 10, 14, and 19 exhibited the most negative SHAP values for SCTR EC50, hence being critical for abolishing SCTR potency or enhancing GLP-1R selectivity (Figure 3A).

In addition to potency determination, the propensity for fibril formation and a reduction in solubility was most pronounced when mutating amino acid positions 12, 14, 18, 19, 21, 23, and 25. The introduction of GLP-1 residues at these positions could thus negatively affect the physicochemical properties of a peptide (Figure 3B).

Based on these learnings, five substitutions were introduced in the secretin backbone to achieve an agonist with dual activity on GLP-1R and SCTR (Table 1). Mutations 9D, 18A, and 22F increased GLP-1R potency. Likewise, 2A was found to increase the GLP-1R potency. The substitution of alanine for 2-aminoisobutyric acid (Aib) is well-known to prevent DPP-4 proteolytic cleavage of the GLP-1 backbone without compromising GLP-1R potency9,25 hence 2Aib was introduced. The 3E mutation prevented the isomerization of the native aspartic acid residue in secretin without influencing receptor potency. Next, a comprehensive sequence exploration was performed on the dual GLP-1R-SCTR agonist, i.e., a deep mutational scan.

Schematic representation of the parallelized development process for generating a selective and stable GLP-1R agonist based on the secretin backbone. The two-step process for converting secretin into a preclinical drug candidate. First, a minimal GLP-1R agonist was developed by introducing only necessary GLP-1 residues to provide activation of GLP-1R. Second, a parallelized workflow was initiated where a deep mutational scan, a glutamate scan, and a lipidation scan provided a blueprint for generating various soluble, physically stable, and half-life extended GLP-1R agonist.

Overview of substitution-effects from a GLP-1 dial-in scan in the secretin backbone. (A) Effect of introducing GLP-1 residues into the secretin backbone. For each assay end point, a random forest model was trained on 768 peptides and used to compute SHAP values determining the level of contribution of each amino acid substitution. Delta mean SHAP values denote the contribution of substituting the secretin residue with the corresponding GLP-1 residue. (B) Detailed overview of SHAP values for selected positions, where substitutions were introduced to obtain analogs with dual GLP-1R and SCTR potency. Small points denote SHAP values per individual peptide and large points denote mean SHAP value.

## Section: Results › Development of Selective GLP-1R Agonists

A deep mutational scan (DMS) was designed such that all-natural amino acids (except cysteine and methionine) were introduced in all sequence positions, either as single mutations or as double mutations. The library consisted of 1152 peptides, which were screened for GLP-1R and SCTR potency. Based on these data, we trained random forest models on the relationship between all assay end points and the peptide amino acid sequence. The models were used to normalize for batch effects (synthesis and assay plate) and the resulting pEC50 values for each single mutant are shown in Figure 4.

The DMS identified several receptor-selectivity-promoting substitutions. For each position, substitution maps were obtained allowing us to navigate toward desired properties, including GLP-1R potency and/or improved receptor selectivity. Rather than identifying a single compound with desired properties through an iterative design process, the DMS generated a solution space of possible amino acid substitutions from which peptide candidates could be designed and synthesized. A selection of substitutions is described below.

We identified amino acid positions 9, 12, and 25 where substitutions could significantly improve GLP-1R selectivity by increasing GLP-1R potency and decreasing SCTR potency (Figures 4A, B and S2). At position 12, several substitutions improved GLP-1R selectivity. 12Y most effectively improved GLP-1R potency and reduced SCTR potency, whereas 12E only reduced SCTR potency. Aromatic residues 25H, 25F, 25Y, and 25W improved GLP-1R potency while also reducing SCTR potency, with 25H being the most effective. At position 9, only the native GLP-1 residue 9D improved potency and selectivity.

In addition, amino acid positions 10, 14, and 19 were identified to improve selectivity by decreasing SCTR potency with a neglectable effect on GLP-1R potency (Figures 4A, B and S2). 10I and 10V reduced SCTR potency without significantly compromising GLP-1R potency. A similar effect was seen by substituting position 14 to F, Y, or L.

Positions 16, 18, and 22 could be substituted to enhance GLP-1R selectivity. For position 16, all mutations, except P, increased GLP-1R potency (Figure S2). For positions 18 and 22, 18A, 18Aib, 18L, 18, 22F, 22W, and 22Y considerably improved GLP-1R potency while only marginally affecting SCTR potency.

Overview of substitution-effects from a deep mutational scan (DMS) in a secretin derived GLP-1R and SCTR dual agonist. (A) Effect of single mutations in all positions. For GLP-1R and SCTR potency, random forest models were trained on 1152 peptides encoded using z-scales.23 From the models, the effect of single mutations was computed to normalize for assay batch effects. (B) Detailed overview of selected positions highlighting the effect of individual substitutions.

## Section: Results › Improving Solubility and Conjugation of Fatty Acid

In parallel with DMS, we systematically investigated the effect and tolerability of glutamate substitution and derivatization with half-life extenders (HLEs) in our dual GLP-1R-SCTR agonist. Glutamate substitutions can be used to modulate the isoelectric point of a peptide, thereby improving solubility at the desired formulation pH.26 Fatty acid conjugation is a well-described technology broadly applied to extend the half-life of peptides from minutes to hours. Native secretin and GLP-1 have reported half-lives in the range of 2–4 min.27,28 Conjugation with fatty diacids facilitates strong binding to serum albumin, thus reducing renal clearance and enzymatic degradation.28,29

Fatty acid conjugation was investigated by attachment to the epsilon nitrogen of lysines via linker moieties. The combined fatty acid and linker is here referred to as the half-life extender (HLE). Six different HLEs were evaluated in each position representing different lengths of fatty diacids, octadecanedioic acid (C18DA) and eicosanedioic acid (C20DA), and varying combinations of linker moieties, L-γ-glutamyl (gGlu) and 3,8-dioxa-aminooctanoic acid (OEG).

A library of 576 peptides was designed where each HLE at each position was examined in backbones comprising 0, 1, or 2 glutamate mutations. All positions were screened, except a few positions in the pharmacophore essential for receptor activation. For the glutamate substitution screening, positions 1–5, 7, and 8 were excluded, with position 15 already being a glutamate. For the HLE screening, positions 1–5, 7–9, 18, and 22 were excluded. The library was screened for GLP-1R and SCTR potency and turbidity. For each end point, we computed SHAP values to determine the contribution of each mutation relative to the backbone residue (Figure 5).

Evaluating the effect of glutamate mutations on GLP-1R potency revealed several amino acid positions where glutamate was tolerated, i.e., positions 12, 16, 17, 19, 20, 21, 24, 25, and 27. Position 12, 16, and 24 were found to have a positive impact on GLP-1R potency compared to the backbone residue. Among these positions, we found the largest reduction in turbidity from introducing 16E and 24E, indicating improved solubility (Figure 5B).

For the HLEs, we found no major difference in potency across the different fatty acids and/or linker combinations and therefore analyzed the different HLEs as a single substitution. Evaluating the effect of attaching HLEs on the GLP-1R potency revealed several positions where HLEs were tolerated, i.e., positions 10, 12, 14, 16, 17, 20, 21, 24, 25, and 27. For positions 12, 14, and 16, the attachment of HLEs was found to have positive effects on GLP-1R potency compared to the backbone residue, with positions 12 and 14 also inducing GLP-1R selectivity. This selectivity effect of positions 12 and 14 was consistent with the observations from the DMS, where GLP-1R selectivity could also be improved by mutating these positions (Figure 4). Importantly, no effect on turbidity was observed when HLEs were conjugated to positions 12 (Figure 5A) and 14 (Figure 5A, B).

Overview of substitution-effects from glutamate scan and half-life extender (HLE) scan in a secretin-derived GLP-1R and SCTR dual agonist. (A) Effect of introducing HLEs or glutamate. For each assay end point, a random forest model was trained on 576 peptides and used to compute SHAP values determining the level of contribution of each amino acid substitution. Delta mean SHAP values denote the contribution of substituting the backbone residue with either a glutamate or HLE. (B) Detailed overview of SHAP values for selected positions that tolerate HLE derivatization or glutamate substitution for improving half-life and solubility, respectively. Small points denote SHAP values per individual peptide and large points denote mean SHAP value.

## Section: Results › Fine-Tuning Potency, Selectivity, and Physicochemical Properties

Previous sections described our parallel peptide development process. The conjugation of HLEs could dramatically alter the properties of a peptide.26 We therefore set out to investigate if an HLE was compatible with positions and substitutions found to be selectivity-inducing in the deep mutational scan. Furthermore, this library would enable us to rank the mutations relative to each other and according to desired end points to identify an optimal combination of substitutions providing a selective GLP-1R agonist with desired physicochemical properties. We designed a library of 192 compounds where selected substitutions were evaluated at positions 3, 10, 12, 18, 19, and 21 in the dual agonist backbone (Table 1) being lipidated at position 14 with the HLE: C18DA-gGlu-2xOEG. The selected substitutions all induce selectivity in differing degrees, while some also have different physicochemical properties, such as opposite charges, hydrophobicity, helix-inducing effect, etc. In addition to receptor potency, we also assessed the solubility and the propensity for forming amyloid fibrils using a Thioflavin T (ThT) assay. We trained random forest models for each end point and calculated SHAP values to determine the contribution of each mutation to the relevant end points in a lipidated backbone (Figure 6).

In terms of selectivity, we found that 10V and 12Y provided the greatest positive effect by increasing the GLP-1R potency and decreasing the SCTR potency. For 12Y this also led to increased turbidity, meaning that this mutation should be accompanied by mutations that improve solubility.

Interestingly, three mutations were identified to diminish the propensity for fibril formation, 18Aib, 19Aib, and 21E, where the two former did not affect potency on the two receptors. We further used SHAP values to determine the interaction effect of these mutations that prevent fibril formation and found that the reduction in fibril formation was not additive when combining 18Aib and 19Aib (Figure S3). Thus, only one of the mutations is necessary to provide a reduction in fibrillation propensity.

Overview of substitution-effects from selected substitutions in secretin derived selective GLP-1R agonist. Effect of combining selected substitutions identified in the deep mutational scan, HLE scan, and glutamate scan. For each assay end point a random forest model was trained on 192 peptides and used to determine SHAP values determining the level of contribution of each amino acid substitution. Mean SHAP values denote the contribution of each substitution relative to the data set mean.

## Section: Results › Design and Characterization of Final Candidate

Based on all of the substitution options identified, we designed GUB021794. The peptide sequence is shown in Table 1. We aimed for a peptide candidate with minimal (<10 fold) GLP-1R potency loss compared to native GLP-1 but with a 10,000-fold selectivity ratio (GLP-1R over SCTR). The peptide candidate should be soluble, chemically- and physically stable at neutral pH and have a pharmacokinetic profile compatible with once-weekly dosing in humans. The in vitro characterization and pharmacokinetic properties of GUB021794 are summarized in Table 2. GUB021794 is potent and selective with a GLP-1R potency of 0.018 nM and an hSCTR potency of 190 nM.

For GUB021794, we modified the dual-acting backbone at positions 10, 12, 14, 16, 18, 24, and 25. The pronounced GLP-1R potency and high selectivity were achieved by combining substitutions identified in the DMS to have a positive effect on those end points. From the DMS (Figure 4), we identified positions where substitutions could induce selectivity by decreasing SCTR potency, while also improving GLP-1R potency or not significantly impacting GLP-1R potency. For this design, we decided to pursue 12Y and 25H as both were found to improve GLP-1R potency while also decreasing SCTR potency. 10V was introduced to further decrease SCTR potency without significantly reducing GLP-1R potency. In the glutamate scan (Figure 5), we identified two positions where glutamate had a positive impact on GLP-1R potency while also decreasing the turbidity of the peptides. Hence, glutamates were introduced in positions 16 and 24 to achieve a solubility of at least 10 mg/mL. The HLE scan (Figure 5) identified two positions, 12 and 14, where the attachment of a HLE-induced selectivity without compromising solubility. For the design of GUB021794, the HLE was attached to position 14 to improve GLP-1R potency and selectivity, while maintaining high solubility. Finally, we identified two positions where Aib was found to decrease the propensity for forming amyloid fibrils (Figure 6). In GUB021794, 18Aib was introduced to preserve the nonfibrillating properties at neutral pH.

While improving solubility and potency, the substitution of positions 24 and 25 additionally removes a sequence motif, QG, prone to cause chemical instability due to the potential deamidation of glutamine positioned next to glycine. Additionally, the isomerization of aspartic acid was addressed by substituting aspartic acid in position 3 for glutamic acid and by introducing the sterically hindered valine in position 10 next to 9D. Therefore, we obtain a candidate with high chemical stability at neutral pH.

Based on the sequence homology of peptides in the glucagon superfamily of structurally related peptide hormones, GUB021794 was tested for cross-reactivity toward other receptors in the family. GUB021794 showed no activation of the GIPR, GLP-2R, or the GCGR when tested at concentrations up to 3000 nM (Table S2).

The albumin binding affinity of fatty diacids correlates with the length of the fatty diacids; C18- and C20 diacids have the highest affinity.29 A C20DA-gGlu-2xOEG has previously been described to provide a once-weekly dosing regimen in humans12 while 2Aib is known to protect against DPP-4 proteolytic cleavage.9,25 Thus, to achieve a long-acting drug candidate compatible with once-weekly dosing, we attached C20DA-gGlu-2xOEG to position 14, while 2Aib was introduced to prevent DPP-4 proteolytic cleavage.

GUB021794 demonstrated a prolonged pharmacokinetic half-life of 22 h after intravenous dosing in rats. Such a pharmacokinetic profile has previously been shown to translate to a once-weekly pharmacokinetic profile in humans.29,30

## Section: Results › Metabolic Effects of GUB021794 in DIO Mice

GUB021794 was characterized in a mouse model of diet-induced obesity (DIO). DIO mice were treated subcutaneously once daily with vehicle, semaglutide (10 nmol/kg), or GUB021794 (3, 10, or 30 nmol/kg) for 28 days. 28-day treatment with GUB021794 promoted a dose-dependent reduction in body weight, on par with an equimolar dose (10 nmol/kg) of semaglutide (Figure 7A, B). Food intake (Figure 7C) was dose-dependently reduced throughout the study with maximal effect on treatments days 2–3 (Figure 7D). The marked reduction in body weight and food intake was reflected by a substantial reduction in whole-body adipose tissue mass (Figure 7E). Plasma exposure in DIO mice (Figure 7F) was dose-dependent and supported the extended half-life of GUB021794.

Overall, the preclinical data demonstrate that GUB021794 is a potent long acting GLP-1R agonist promoting robust body weight loss in DIO mice comparable to clinically approved GLP-1R agonists, such as semaglutide.31,32

GUB021794 dose dependently reduces body weight and adipose tissue mass in DIO mice. DIO mice were treated subcutaneously once daily (QD) with vehicle, semaglutide (10 nmol/kg), and ascending doses of GUB021794 (3, 10, or 30 nmol/kg) for 28 days. (A) Body weight. (B) Body weight change (% of day 1) at the end of the study. (C) Daily food intake. (D) Cumulative food intake day 28. (E) Fat mass day 28. (F) Plasma exposure day 29, (samples taken 24 h after dosing). Values expressed as mean of n = 10 + SEM. Dunnett’s test one-factor linear model. *: P < 0.05, **: P < 0.01, ***: P < 0.001 compared to Vehicle.

## Section: Discussion

In this study, we demonstrated the capability of the streaMLine platform to accelerate the drug discovery process of peptide pharmaceuticals. We systematically explored secretin as a peptide backbone to generate potent, selective, and long-acting GLP-1R agonists without the intrinsic physical instability previously reported for GLP-1.10,11 A total of 2688 peptides were synthesized, screened, and analyzed using an ML-guided approach to map out a solution space for generating GLP-1R agonists derived from the secretin backbone. Based on this solution space, we designed and characterized a novel GLP-1R agonist, GUB021794, that showed potent body weight loss in DIO mice, a pharmacokinetic profile compatible with once-weekly dosing in humans, and beneficial physicochemical properties.

The key features employed in the streaMLine platform are (1) systematic peptide library design where each mutation is observed multiple times in multiple different backbones, (2) analysis of large libraries consisting of 100–1000 s of crude peptides, and (3) ML-guided peptide design. The screening of peptide crudes leads to faster data generation, as the laborious peptide purification following SPPS can be omitted. This leads to faster generation of lead molecules as well as potential identification of better compounds as a larger chemical space can be screened using the same amount of resources. Despite the contribution of synthesis byproducts in the individual assay measurements of the peptide crudes, we observe that these contributions have a negligible effect on the overall data interpretation when analyzed as part of a larger systematic peptide library design.

Following the crude screening campaign of this study, we subsequently purified and profiled GUB021794, and verified the conclusions obtained from the crude libraries. Aside from verifying the conclusions obtained during the crude screenings, GUB021794 also demonstrated that the thorough screening approach enabled the generation of a very potent therapeutic peptide. Despite being derived from the alternative starting point secretin, GUB021794 showed a weight-lowering effect in DIO mice on par with semaglutide, a clinically approved GLP-1 receptor agonists.31,32

In addition to verifying our screening approach by in-depth characterization of GUB021794, several of the key amino acid substitutions identified in this study have been reported previously. For example, the amino acid positions being important for GLP-1R potency (Figure 2A), agreed with previous studies reporting the high importance of phenylalanine in position 2233 and loss in GLP-1R potency when introducing 2S34 and 9E into a GLP-1 context.25 Furthermore, we found position 19 to be important for SCTR potency in agreement with previous SAR efforts on the secretin backbone.35 The physicochemical screening enabled the identification and validation of mutations associated with fibril formation of GLP-1R agonists. We identified three substitutions preventing fibril formation, 18Aib, 19Aib, and 21E which could be responsible for the formation of amyloid fibrils of GLP-1R agonists previously reported.10,11

Previous studies using QSAR for peptide optimization have been limited to case studies on peptide families with large data sets publicly available such as antimicrobial peptides (AMPs),36 Major histocompatibility complex (MHC)37 and antitumor activity of peptides.38 Other related studies have extracted information about QSAR from smaller publicly available data sets. Deng et al. collected a data set of 141 unique angiotensin-converting enzyme (ACE) inhibitory dipeptides, and fitted a regression model to IC50 values with model predictions being validated by synthesis and in vitro testing of five novel ACE inhibitory dipeptides.39 Although not evaluating the physicochemical properties of the developed peptides, the study by Deng et al. highlights the great potential of peptide QSAR, even based on a limited data set. Our study demonstrates the importance of co-optimizing potency and physicochemical properties to avoid developing potent but unstable peptides.

In addition, we have demonstrated how the platform allows multiparameter screening in a parallelized workflow, thus enabling timeline-efficient identification of learnings to obtain peptides with drug properties early in a project. This accelerated approach further enables fast evaluation of the in vitro/in vivo correlation. In case, the peptide design needs re-evaluation, and the already generated data sets provide alternative solutions to be evaluated without significant timeline delay.

While the aim of the present work was to dial out the secretin receptor potency and leverage the more favorable physicochemical properties of secretin, the streaMLine platform is highly applicable for the development of other peptide-based therapies such as polyagonists targeting multiple receptors, since it enables fine-tuning potency on multiple receptors and allows for exploration of a large chemical solution space. Another application of streaMLine could be the development and potency optimization of nonendogenous peptides identified de novo by display technologies including mRNA display,40 or in the development of peptides containing noncanonical amino acids.41 Recent advances in artificial intelligence (AI) with pretrained deep learning models such as AlphaFold42 and protein language models (PLMs)43 ,44 have enabled improved prediction of protein and peptide properties. For example, de novo design of protein binders has been drastically improved recently45 making peptide-based therapies approachable for previously undruggable targets. Applying QSAR methods as demonstrated in this study could aid in quickly advancing de novo peptide hits to the clinical stage.

## Section: Conclusions

In summary, we have developed an ML-based drug discovery platform to systematically identify design solutions for optimizing peptide-based drugs. As a validation, we exploited the secretin peptide backbone as a scaffold to determine a solution space for designing novel GLP-1R agonists with a selective receptor profile and improved physicochemical properties. This unprecedented QSAR approach enables accelerated development of peptide drug candidates on multiple parameters and demonstrates a novel approach that can be applied for future developments of peptide drug candidates.

## Section: Experimental Section › General Procedure for Peptide Library Synthesis

Peptide libraries were synthesized using standard Fmoc-based solid phase methods on a SyroII fully automated parallel peptide synthesizer (MultiSynTech GmbH, Germany) equipped with a heating block. Tentagel S RAM resin with a loading of 0.23–0.25 mmol/g (Rapp polymer GmbH, Germany) was used. Fmoc deprotection was performed in two stages by treating the resin with 40% piperidine/DMF (0.2 M HOBt (1-hydroxybenzotriazole)) for 3 min at 45 °C followed by 20% piperidine/DMF (0.1 M HOBt) for 7 min at 75 °C. Asp, Cys, and His residues were Fmoc-deprotected at room temperature; i.e. 40% piperidine/DMF (0.2 M HOBt) for 3 min followed by 20% piperidine/DMF (0.1 M HOBt) for 15 min. Coupling was performed using 0.5 M Fmoc-amino acid in 0.5 M oxyma in DMF (except His which was dissolved in NMP) added in 5-fold excess to the resin and activated by 5-fold DIC (N,N′-diisopropyl-carbodiimide). Coupling conditions were single or double couplings for 15 min at 75 °C, except for His and Cys residues, which were double coupled for 15 min at 50 °C. Also, amino acids coupled after Aib were double coupled. The resin was washed 5× with DMF after Fmoc deprotection and 3× after couplings.

For peptides lipidated at the lysine residue, Boc-protected amino acid was incorporated as the N-terminal residue, and the lipidation position was incorporated as lysine (Mtt). The Mtt group (4-methyl-trityl) was removed by treating the resin 3 times with 75% HFIP (1,1,1,3,3,3-hexafluoro-propan-2-ol), 5% TIPS in DCM (dichloromethane) for 10 min. The resin was washed with 10% DIPEA in DCM, followed by a 3× DMF wash. The linker residue(s) were coupled to the epsilon-amino group of the deprotected lysine using double- or triple-standard coupling conditions prior to coupling the mono-t-butyl-protected fatty diacid. The fatty acid was double coupled using 2 equiv building blocks.

For N-terminal lipidated peptides, linker residues and mono-t-butyl protected fatty diacid were coupled to the N-terminus using the conditions described above.

After synthesis, the resin was washed with DCM and dried, and the polypeptide was cleaved from the resin by a 45 min treatment with TFA (trifluoroacetic acid)/TES (triethylsilane)/DODT(2,2′-(ethylenedioxy)diethanethiol)/water (93/2.5/2.5/2.0) at 40 °C followed by precipitation and wash using cold diethyl ether.

## Section: Experimental Section › General Procedure for Peptide Library Synthesis › Crude Peptide Libraries

The peptides were characterized by HR-MS (Waters, Denmark) and quantified by LC-CAD (ThermoFisher Scientific, Denmark). Finally, the crude peptide libraries were lyophilized.

## Section: Experimental Section › General Procedure for Peptide Library Synthesis › Purified GUB021974

The crude peptide was dissolved in acetonitrile/water and purified by reverse phase HPLC using a Waters preparative HPLC with C18 column (Reprosil Gold 200 Å, 5 μm, 30 mm × 250 mm), preparative pumps (waters 2545), UV/vis detector (Waters 2489) and a Waters fraction collector III. The mobile phase was run with a gradient of buffer A (0.1% TFA in H2O) and buffer B (0.1% TFA in acetonitrile at a flow rate of 20 mL/min at room temperature). Relevant fractions were analyzed, pooled, and lyophilized. Finally, the peptide was freeze-dried using a Telstar benchtop freeze-drieder. Peptide purity and mass were determined by analytical RP-HPLC-MS on an ACQUITY UPLC Peptide CSH C18 column (Waters, ACQUITY UPLC Peptide CSH, C18, 130 Å, 1.7 μm, 2.1 mm × 100 mm) using a Waters Acquity HPLC System equipped with a 3100 Mass Detector. Analysis was performed by gradient elution with buffer A (0.3% TFA in H2O) and buffer B (0.3% TFA in acetonitrile) at a temperature of 40 °C (gradients used were 40–60%B over 14 min). GUB021794: purity = 95%; calc. mass: 3862.3871; m/z = 1288.2 (m + 3/3).

## Section: Experimental Section › In Vitro Functional Assay: General Procedure for the Determination of hGLP-1R Potency

A CHO-K1 cell line stably overexpressing the hGLP-1R was obtained from Euroscreen (FAST-0145L), expanded, aliquoted, and frozen. An aliquot was thawed and plated in DPBS with 0.05% casein and 0.5 mM IBMX (2000 cells/well) in a 384-well format. The cells were then immediately stimulated for 30 min at room temperature with graded doses of test compound using human GLP-1(7–36) (synthesized at Gubra) as a positive control. cAMP accumulation was measured using a Cisbio assay for Gs-coupled receptors (cat. no. 62AM4PEC), where the assay reagents were added as per the manufacturer’s instructions and time-resolved fluorescence energy transfer recorded after one hour on a CLARIOstar (BMG Labtech) plate reader.

## Section: Experimental Section › In Vitro Functional Assay: General Procedure for Determination of hSCTR Potency

Frozen division arrested CHO-K1 cells stably overexpressing the hSCTR was obtained from PerkinElmer (ES-712-AF). Alternatively, a CHO-K1 cell line stably overexpressing the hSCTR was obtained from Euroscreen (FAST-0161L), expanded, aliquoted, and frozen. An aliquot was thawed and plated in DPBS with 0.05% casein and 0.5 mM IBMX as 2000 cells/well in a 384-well format. The cells were then immediately stimulated for 30 min at room temperature with graded doses of test compound using human secretin (synthesized at Gubra) as a positive control. cAMP accumulation was measured using a Cisbio assay for Gs-coupled receptors (cat. no. 62AM4PEC), where the assay reagents were added as per the manufacturer’s instructions and time-resolved fluorescence energy transfer recorded after 1 h on a CLARIOstar (BMG Labtech) plate reader.

## Section: Experimental Section › Biophysics: General Procedure for Determination of Solubility and Fibril Formation

Peptides were dissolved in buffers (50 mM sodium phosphate at pH 7.0) to 267 μM and incubated for 1–2 h at room temperature. The samples were then divided into two replicates of 80 μL in a black 384-well plate (μ-clear, Greiner Bio-One) and mixed with Thioflavin T (ThT) to a final concentration of 4 μM. The plate was centrifuged for 2 min at 2000 rpm to remove air bubbles, sealed, and placed in a plate reader (CLARIOstar, BMG). First, the turbidity of the samples was measured as the absorbance at 600 nm as an indication of precipitated material. Second, the plate reader temperature was set to 40 °C and the fluorescence was measured every 10 min for 72 h by exciting the ThT at 450 nm and measuring the emission at 480 nm. Samples were stressed by shaking the plate at 700 rpm (linear) for five min before every measurement, and fibril formation was determined as the average emission for each sample.

## Section: Experimental Section › Data Modeling

A random forest model22 was constructed for each in vitro endpoint. Features consisted of the peptide sequences as well as the specific plate number for synthesis and assay, respectively. For the deep mutational scan, peptide sequences were encoded using z-scales,23 and for the remaining data sets, peptide sequences were one-hot encoded (binary classification of the presence or absence of each amino acid in each position). The models were implemented in the statistical programming language R using the randomForest package version 4.6.14, and SHAP values were computed based on the random forest models using the treeSHAP package version 0.1.1.

## Section: Experimental Section › Ethics

All animal experiments were approved by The Danish Animal Experiments Inspectorate (License No. 2017-15-0201-01378). Animal experiments were conducted in agreement with internal Gubra bioethical guidelines that are fully compliant with internationally accepted principles for the care and use of laboratory animals.

## Section: Experimental Section › Pharmacokinetics in Rats

Male Spraque Dawley rats were obtained from Janvier (Janvier Laboratories, France) at 6 weeks of age. The animals were single-housed on the day of arrival. After 1 week of acclimatization, the animals (n = 3) were codosed with two test peptides; one compound was dosed intravenously and the other was dosed subcutaneously. In a parallel group (n = 3), the same two test peptides were dosed with opposite routes of administration. This allowed for profiling both the intravenous and subcutaneous administration routes and obtaining key pharmacokinetics parameters. Following dose administration, blood samples (90 μL) were collected in K2EDTA tubes at time points: 0.17, 1, 3, 6, 24, 30, 48, 72, and 96 h post-dosing. Plasma was obtained by centrifugation of the blood samples (3000 × g, 10 min 4 °C), and the plasma samples were frozen at −70 °C until analysis.

Pharmacokinetics parameters were calculated by noncompartmental analysis (NCA) of the individual plasma concentration–time profile from the animals. NCA was performed in the R-package NonCompart, using the log-linear trapezoidal method for the estimation of AUC and AUMC. AUC0–∞ was extrapolated <20%.

## Section: Experimental Section › LC-MSMS Analysis

Plasma concentrations were measured by LC-MSMS using electrospray ionization and multiple reaction monitoring. Calibration standards and quality control (QC) samples were prepared in a species-match matrix. In brief, 15 μL calibration standards, QC, and study samples were extracted by protein precipitation using 60 μL of methanol followed by the addition of 45 μL of Milli-Q water. Samples were shaken (800 rpm) at room temperature for 5 min before centrifugation (2570 × g, 40 min, 4 °C), and the supernatant was transferred to a LoBind PCR plate. Samples were analyzed on a Thermo Triscend UHPLC system coupled to a Sciex API 6500+ mass spectrometer. Samples were subject to online SPE cleanup on an HLB column (1 × 50 mm, Waters) before being loaded onto an Aeris Peptide XB C18 column (3.6 μm, 100 Å, 2 × 50 mm, Phenomenex, Torrance, USA) analytical column. The mobile phases consisted of acetonitrile and Milli-Q H2O both containing 0.1% V/V formic acid.

## Section: Experimental Section › Pharmacodynamics: Effect on Weight-Loss

Male C57BL/6JRj mice were obtained from Janvier (Janvier Laboratories, France), and group-housed in a controlled environment (12/12 h light-dark cycle, lights off at 3 PM, 22 °C ± 2 °C, humidity 50% ± 10%). Each animal was identified by an implantable subcutaneous microchip (PetID Microchip, E-vet, Haderslev, Denmark). Mice arrived at 5 weeks of age and were offered tap water and regular chow (Altromin 1324, Brogaarden, Denmark) or diet-induced obesity (DIO) was induced by offering ad libitum access to a 60% high-fat diet (5.15 kcal/g; 60 kcal% fat, 20 kcal% carbohydrates, 20% kcal% protein; D12492, Ssnif, Soest, Germany) for 46 weeks before study start. The mice were kept on a diet throughout the study. Mice were randomized according to body weight in week −1. The mice were SC-dosed once daily with Vehicle (50 mM phosphate, 3.5% mannitol) Lean (n = 10), Vehicle DIO (n = 10), positive control semaglutide (Ozempic, Novo Nordisk A/S, Denmark) 10 nmol/kg (n = 10) or the GLP-1R agonists; GUB021794, at 3, 10, or 30 nmol/kg (n = 10 mice/group) for 28 days. Body weight and food intake were measured daily from days −3 to 28. Whole-body lean/fat tissue composition was analyzed by noninvasive EchoMRI scanning (EchoMRI-900, Houston, TX, USA) performed on study day 28. Terminal exposure was measured using LC-MSMS on samples obtained 24 h after the last dosing.

## Section: Acknowledgments

We thank Henrik Björk Hansen for his help in revising the manuscript.

## Section: Supporting Information Available

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acs.jmedchem.4c00417.

## Section: Author Contributions

J.C.N., N.V., K.R., and L.S.D. conceptualized the study. C.H., A.W., L.E., R.B.M., M.S., carried out the in vitro experiments. T.P., S.R., A.N.M. caried out the in vivo experiments. J.C.N., C.H., M.M.N., A.W. analyzed the data. J.C.N., C.H., and L.S.D. wrote the paper. All authors reviewed and approved the final paper. J.C.N. and C.H. contributed equally to this work.

## Section: Text

The authors declare the following competing financial interest(s): All authors are employed at Gubra.

## Section: Notes

† Joint first author.

## Section: Supplementary Material

jm4c00417_si_001.pdf

jm4c00417_si_002.csv

## Section: Associated Data

jm4c00417_si_001.pdf

jm4c00417_si_002.csv

## Section: Associated Data › Supplementary Materials

jm4c00417_si_001.pdf

jm4c00417_si_002.csv


---

# Machine Learning to Predict Drug-Induced Liver Injury and Its Validation on Failed Drug Candidates in Development

- **Authors:** Fahad Mostafa, Victoria Howle, Minjun Chen
- **Issuer:** Toxics
- **Type:** Scientific article
- **Published:** 2024-05-24
- **Language:** en
- **DOI:** 10.3390/toxics12060385
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38922065/
- **Licence:** CC-BY

## Section: Abstract

AbstractDrug-induced liver injury (DILI) poses a significant challenge for the pharmaceutical industry and regulatory bodies. Despite extensive toxicological research aimed at mitigating DILI risk, the effectiveness of these techniques in predicting DILI in humans remains limited. Consequently, researchers have explored novel approaches and procedures to enhance the accuracy of DILI risk prediction for drug candidates under development. In this study, we leveraged a large human dataset to develop machine learning models for assessing DILI risk. The performance of these prediction models was rigorously evaluated using a 10-fold cross-validation approach and an external test set. Notably, the random forest (RF) and multilayer perceptron (MLP) models emerged as the most effective in predicting DILI. During cross-validation, RF achieved an average prediction accuracy of 0.631, while MLP achieved the highest Matthews Correlation Coefficient (MCC) of 0.245. To validate the models externally, we applied them to a set of drug candidates that had failed in clinical development due to hepatotoxicity. Both RF and MLP accurately predicted the toxic drug candidates in this external validation. Our findings suggest that in silico machine learning approaches hold promise for identifying DILI liabilities associated with drug candidates during development.Keywords: machine learning, drug-induced live injury, liver toxicity, random forest, multilayer perceptron, failed drug candidates

## Section: 1. Introduction

Drug-induced liver injury (DILI) continues to be a significant challenge for the pharmaceutical industry and regulatory organizations [1]. DILI is a complex safety issue characterized by various underlying processes, varying degrees of severity, population-specific differences, and the inherent challenges in categorizing the risk connected to medications, especially those recently granted marketing approval [2,3,4]. To prevent drugs with DILI liability from entering the market, it is crucial to enhance the ability to predict the potential risk of DILI in humans before obtaining marketing approval [5]. This improvement would lead to safer pharmaceuticals and more cost-effective drug development. In addition, prompt discontinuation of the development of drug candidates with a high propensity to cause DILI can result in the timely use of resources [6].

In silico models have gained popularity among researchers due to their rapid development times, cost-effectiveness and no requirement of physical substances, although experimental approaches such as in vitro and in vivo assays are still integral in the assessment of DILI risk [5,7]. Typically, in silico DILI prediction models have been developed and validated using marketed drugs, neglecting testing on drug candidates in the developmental stages [8]. Recognizing the challenge of the “translational gap” between drug development and clinical research [9,10], it becomes imperative to evaluate the performance of these in silico models using drug candidates that have failed during the drug development process.

In this study, we employed a large DILI likelihood dataset [11] created by the experts from the NIH LiverTox consortium [12]. We conducted a comparative analysis of various machine learning and deep learning algorithms to develop Quantitative Structure–Activity Relationship (QSAR) models, utilizing in-house Mold2 chemical descriptors. The evaluation through 10-fold cross-validation was used to select the model with the highest performance in terms of accuracy (ACC) or Matthews Correlation Coefficient (MCC). Subsequently, these models underwent external validation using a set of drug candidates that failed in clinical development due to hepatotoxicity in humans.

## Section: 2. Materials and Methods

Feature selection for DILI prediction.

## Section: 2. Materials and Methods › 2.1. Data and Annotation for DILI Likelihood

Medications can be classified in terms of their likelihood to cause liver injury in humans. The NIH LiverTox consortium has created a five-point classification for measuring the possibility that a medicine caused DILI. This classification is mostly based on the published literature. A drug is categorized by likelihood score on DILI [11] as category A (well known for DILI), Category B (highly likely to cause DILI), Category C (probably linked to DILI), Category D (possible cases for DILI), Category E (no evidence for DILI), or Category E* (suspected but no convincing DILI cases).

In this study, the dataset is reclassified into drugs with the likelihood to cause DILI (DILI group) and without the likelihood to cause DILI (non-DILI group). The likelihood of YES to DILI is enumerated as 1 for categories A, B, and C, and NO to DILI as 0 with E and E*. The training set comprises 240 DILI-positive, which includes 61 drugs belonging to group A, 80 of group B, and 99 of group C, and 335 DILI-negative with 206 of group E and 129 of group E*. Notably, the DILI-positives contained 34 medications with Black Box Warnings or withdrawn from the market due to DILI concern. An independent dataset were used as the external validation, including 22 drug candidates that were terminated in development due to liver toxicity [13].

## Section: 2. Materials and Methods › 2.2. Molecular Descriptors

Here, we used Mold2 to calculate 777 1D, and 2D molecular descriptors to capture critical two-dimensional chemical structural information associated with drugs. Mold2 is a software package developed by the FDA NCTR for fast calculating a large and diverse set of molecular descriptors encoding two-dimensional chemical structure information [14]. Compared with those calculated from commercial software on published datasets Mold2 descriptors provides similar or better performance to represent sufficient structural information [14].

## Section: 2. Materials and Methods › 2.3. Model Development

In the binary classification of machine learning, the data are represented as a set of pairs (x,y), where x denotes the input features and y represents the binary target variable. Mathematically, the input features are typically denoted as a real-valued vector x∈ Rn, where n is the dimensionality of the feature space. The target variable y is a binary label, taking on one of two values: 0 or 1. The goal of binary classification is to learn mapping from input features to the binary labels, which is represented as a function f:Rn→{0,1}. This mapping is learned through a training process using a labeled dataset, and the objective is to find a decision boundary or a hypothesis h(x) that accurately predicts the binary label y based on the input features x in a way that minimizes a suitable loss or cost function. The framework of model development for DILI prediction includes the following:

Feature selection for DILI prediction.

## Section: 2. Materials and Methods › 2.3. Model Development › 2.3.1. Feature Selection from Chemical Descriptors

Feature selection helps identifying the features that have the most impact on the prediction. It combats computational complexity, overfitting, and improves model interpretability by selecting the most relevant characteristics. Choosing influential features helps a model generalize to new data, minimizes noise, and adds to more efficient model training (Figure 1).

To assess the importance of input features, we analyzed the coefficients (weights) associated with each feature in the logistic regression model [15]. The absolute values of these coefficients represent the feature’s importance. The larger the absolute coefficient, the more important the feature is in predicting the binary outcome.

The logistic regression model represents the relationship between the features and the binary outcome (0 or 1) using the logistic function (sigmoid function). The model is defined as follows:

The logistic regression model can then be defined as

To reduce overfitting, Lasso regularization is adopted during logistic regression, which encourages sparse coefficient values, making feature selection more explicit [16]. The logistic regression model with L1 regularization is represented as follows with the defined objective function:

Here, J(θ) is the logistic regression cost function with Lasso regularization, m is the number of training samples, n is the number of features, θ represents the model parameters (weights), x(i) is the feature vector of the i-th sample, and hθx(i) is the logistic function. The λ term controls the strength of Lasso regularization. The Lasso regularization term encourages some of the θ coefficients to become exactly zero, which effectively selects a subset of features. The features with non-zero coefficients in the trained model are considered important for the classification task.

Feature selection for DILI prediction.

## Section: 2. Materials and Methods › 2.3. Model Development › 2.3.2. Model Selection and Mathematical Analysis

Model selection is an important component of developing predictive models since algorithms have different capabilities for modeling. In our current DILI study, binary classification was considered.

If x is the input features of dimension n, then y is the binary class with class labels 0 and 1. If θ is the model parameters and Hθ is the predicted P(y=1∣x,θ), the SVM classifier’s prediction probability is:

Hθ(x) predicts the class label, θ is the weight of the parameters and b is the bias. The objective function to minimize is

In the case of the DT classifier [17], it recursively partitions the feature space into regions by selecting split based on Gini impurity or the entropy index. Random forest (RF) is an ensemble of DTs [18,19]. Each tree is trained on a bootstrap sample, and the final prediction is obtained by aggregating predictions of individual trees. A deep learning-based classifier, which is known as multilayer perceptron (MLP), is also used to train the model. The mathematical representation of a neural network is as follows:

where W(1) and W(2) are weight matrices, and b(1) and b(2) are the biases. The cross-entropy loss function is

The KNN classifier assigns a class label C to a new instance xnew based on the majority class among its k-nearest neighbors as follows:

where Cxnew is the predicted class label for the xnew,c iterates the overall possible class labels, and δyi,c is the Kronecker delta, which is 1 if yi=c and 0 otherwise. To find the KNN of xnew, the Euclidean distance metric is used as dxi,xnew= ∑j=1mxij−xnew,j2, where m is the number of features in the data. Stochastic Gradient Descent (SGD) and Adaptive Moment Estimation (ADAM) are two optimization methods that are often used in machine learning models to minimize loss functions. SGD iteratively updates model parameters in logistic regression by examining small portions of training data, improving convergence speed and scalability [20]. These techniques let SVM discover the best hyperplane by repeatedly modifying the separation margins [21]. ADAM aids training in MLP by fine-tuning the network’s weights and biases, allowing it to approximate complicated correlations between inputs and outputs [22].

## Section: 2. Materials and Methods › 2.3. Model Development › 2.3.3. Model Evaluations and Statistical Analysis

To determine performance measures, predictions from each of the 100 iterations of the 10-fold cross-validation were compared with their actual DILI risk classifications. Each 10-fold cross-validation for the 2-class DILI prediction models produced a 2-by-2 confusion matrix.

A panel of statistical matrices are used for investigating machine learning models [23], such as accuracy (ACC), precision, recall, F1 score (F1), and MCC. The predictions made by a classifier can be categorized as true positive (TP), true negative (TN), false positive (FP), and false negative (FN).

## Section: 2. Materials and Methods › 2.3. Model Development › 2.3.4. Applicability Domain Analysis

Determining the applicability domain [24,25] often involves using various statistical and cheminformatics techniques, such as clustering analysis, distance measures, or domain-specific rules. These methods help assess whether new data points or compounds fall within the established domain. Knowing the domain of application enables users to apply the model to data that are comparable to the training data, enhancing trust in their robustness and generalizability. Normally, a hypothesis is considered for finding optimal prediction space in the 2D visualization of the prediction data points.

Here, the RF classifier and the Mahalanobis distance are utilized to apply the applicability domain [26] for evaluating the eligibility of new data points for prediction. Given a training dataset consisting of input features denoted as Xtrain and corresponding class labels ytrain, and a trained classifier model RF, the Mahalanobis distance, DOxnew, is calculated for a new data point xnew using the mean and covariance matrix of Xtrain. A threshold value, T, determined by a chosen significance level α and degrees of freedom, is utilized. The RF classifier predicts the class label ypred for xnew. If DOxnew is less than T,xnew is within the applicability domain; otherwise, it’s outside. The Mahalanobis distance’s comparison with T dictates the data point’s classification.

## Section: 3. Results

Shapley values used to explain the prediction of a model by attributing the contribution of 10 most important features out of 168 top features to the prediction.

Performance matrices for different machine learning and deep learning models on DILI prediction (mean ± standardized deviation).

MCC scores from the permuted labels vs. the real labels by RF (upper) and MLP models (down). Both tests were statistically significant (p-value < 0.001).

An applicability domain defines the specific conditions under which a predictive model or algorithm is expected to perform well. The blue dots are the training data points and elliptic circle indicates domain threshold.

Model predictions for drug candidates terminated in drug development with hepatotoxicity findings.

## Section: 3. Results › 3.1. Assessments of Feature Selection

Feature selection is critical for machine learning to solve the issues associated with high-dimensional DILI datasets. Here, we used a regularized logistic regression method for identifying the most important features. The dataset was split into training and validation sets with an 80–20 ratio by using a simple random sampling technique. Then, we selected the top important features for classification based on their root mean squared error (RMSE) and λ using least absolute shrinkage and selection operator (lasso) and transformed the training and testing sets to include only the selected features. For doing this we selected a range of values for the regularization parameter λ using cross-validation. For each value of λ, we fit a lasso regression model on the training data. Then, we used a validation dataset to evaluate the performance of each lasso model. Once the optimal λ was determined, we fit the lasso regression model with this λ value on the entire dataset to obtain the final model. Using lasso with 10-fold CV, 168 top-ranked molecular descriptors were selected with the best λ = 0.01 and minimum RMSE of 0.466. The model employed feature selection using L1 regularization with logistic regression and calculated p-values for the selected features. After standardizing the features, it fit the lasso model to the training data, identifying the features with non-zero coefficients and the lowest p-values. From the 168 top-ranked descriptors obtained through the lasso variable selection strategy, we extracted the 10 most valuable features with the smallest p-values for DILI prediction. Subsequently, we assessed feature importance using SHAP (Figure 2) [27], and the detailed descriptions of these features can be found in Supplementary Table S1.

Shapley values used to explain the prediction of a model by attributing the contribution of 10 most important features out of 168 top features to the prediction.

## Section: 3. Results › 3.2. Model Development and Performance Assessments

Table 1 presents a comparison of several machine learning methods in terms of performance measures evaluated by 100 repeats of 10-fold cross-validation.

RF had the highest ACC of 0.631, followed by MLP (0.626) and SVM (0.617). RF also had the highest recall of 0.716, followed by KNN (0.664) and MLP (0.658). It achieved the highest F1 score value of 0.677, followed by MLP (0.660) and SVM (0.654). Meanwhile, RF had the lowest standard deviation in the recall and F1 score.

MLP had the highest MCC means (0.245), followed by RF and SVM (0.226 and 0.225, respectively). It also had the highest precision (0.673), followed by SVM (0.663) and NB (0.662). MLP recorded the second highest recall (0.658) and F1 score (0.660).

Considering the metrics, RF consistently performs well in terms of ACC, precision, recall, MCC, and F1 score. It has the highest or near-highest mean values in most metrics. MLP has the highest MCC and precision and performs well in terms of recall. In summary, RF and MLP seem to be the best models based on the metrics provided.

We conducted a permutation test for the selected QSAR models based on RF and MLP. By randomly shuffling the labels, we generated a permuted label distribution. The MCCs from our RF and MLP models (Figure 3) were significantly higher than those obtained from the models with permuted labels (p-value < 0.0001). This suggests that the predictions from our models are not due to chance.

We evaluated the RF model for the application domain. For threshold 0.6 (Figure 4), we observed the number of training data points inside the application domain to be 428 and the number of train data points outside the domain to be 32. Accordingly, the ACC within the domain is 0.64 and outside is 0.62.

Performance matrices for different machine learning and deep learning models on DILI prediction (mean ± standardized deviation).

MCC scores from the permuted labels vs. the real labels by RF (upper) and MLP models (down). Both tests were statistically significant (p-value < 0.001).

An applicability domain defines the specific conditions under which a predictive model or algorithm is expected to perform well. The blue dots are the training data points and elliptic circle indicates domain threshold.

## Section: 3. Results › 3.3. Model Validation by Drug Candidates That Failed in Development

We tested the models using a set of 22 drug candidates that failed in drug development due to hepatotoxicity [15]. Both RF and MLP classifiers successfully predicted whether medications would result in “No-DILI-Concern” or “Most-DILI-Concern” with a success rate of 19/22 (90.9%) (Table 2). As a comparison, the rule-of-two model correctly predicted 13/22 compounds (59%), of which 8 compounds (*) were determined as ambiguous with either a high daily dose of >100 mg/day or a high logP value of >3 alone. We also applied the ToxSTAR online tool [28] for evaluating these drug candidates, which resulted in the correct prediction of 18/22 compounds (82%) for cholestasis and 16/22 compounds (73%) for hepatitis.

Model predictions for drug candidates terminated in drug development with hepatotoxicity findings.

## Section: 4. Discussions

In this study, we endeavored to construct computer models for assessing DILI risk caused by medications, utilizing a substantial human dataset annotated by experts from LiverTox. To achieve this, an extensive exploration of various machine learning and deep learning techniques was undertaken to evaluate the efficacy of different modeling classifiers.

A 10-fold cross-validation procedure was employed to assess several selected machine learning algorithms, complemented by external testing. Our findings revealed that the RF and MLP models stood out as highly effective in predicting DILI. Specifically, RF outperformed other machine learning strategies, achieving an average prediction accuracy of 0.631 during cross-validation, while the MLP deep learning approach attained the best MCC of 0.245. The permutation tests revealed that the predictions from both models are better than by chance.

QSAR models for DILI have been extensively studied in the literature. It is crucial to recognize that different endpoints in DILI prediction models can yield varying predictions due to differences in underlying mechanisms, data availability, and model complexities. In this study, we utilized a large dataset of drugs with quality endpoints related to DILI likelihood, as curated by the NIH’s LiverTox [11]. To the best of our knowledge, no other QSAR DILI model has been specifically based on the same endpoint. Another widely used dataset for developing QSAR models is DILIrank [29]. As detailed in Supplementary Table S2, various algorithms were employed to build these models, and they demonstrated comparable performance to ours, achieving accuracies in the range of 60–70% [8,30,31,32,33,34].

The top selected features by our models include Geary topological structure autocorrelation length-1 weighted by atomic van der Waals volumes (D455), Moran topological structure autocorrelation length-2 weighted by atomic masses (D480), the number of group Al-C(=X)-Al (D742), structure lopping centric group index (D253), and mean molecular topological order-9 charge index (D529). Interestingly, our top two ranking features have also been reported to contribute to QSAR models for predicting the inhibition of Cytochrome P450 enzymes, specifically CYP3A4, CYP2D6 [35] and CYP2C8 [36]. Notably, the inhibition of CYP enzymes is known to be associated with an increased risk of DILI in humans [37].

The RF model exhibited competitive F1 and AUC scores, demonstrating its capacity to successfully discriminate between positive and negative occurrences in the prediction process, achieving a harmonious balance between precision and recall. Of significant note, both models demonstrated their accuracy when externally validated against a set of 22 failed drug candidates with hepatotoxicity, although false negative rates need further evaluation. This underscores their potential in identifying compounds with hepatotoxic liabilities, mitigating risks to patients, and enhancing drug development procedures.

Both MLP and RF have unique advantages when developing QSAR models. RF offers robustness through its ensemble of decision trees, feature importance analysis, and noise resilience. On the other hand, MLPs excel at automatically learning from complex features and identifying non-linear connections between molecular descriptors and DILI. Without the need for additional ensemble methodologies, MLPs and RF can independently achieve competitive performance in DILI prediction by leveraging their respective strengths in feature learning and ensemble learning. These methods help identify important structural traits associated with DILI, providing a deeper understanding of the connections between chemical properties and liver damage.

However, there are also drawbacks to applying machine learning methods. One challenge is the availability of labeled data—finding high-quality, readily available data for training can be difficult. The size, quality, and representativeness of training datasets often vary, affecting the broad applicability of models. Another issue is class imbalance in datasets used for DILI prediction. For instance, when the proportion of liver injury cases is much lower than non-liver injury cases, models may perform poorly on the minority class and favor the dominant class. Extracting relevant traits or biomarkers from complex biological data can also be challenging. While machine learning algorithms can handle high-dimensional data, their interpretability may be limited, making it hard to understand the biological processes underlying DILI prediction. Additionally, complex models like deep learning neural networks (such as MLP) are prone to overfitting, especially when trained on small or noisy datasets. Overfitting occurs when a model memorizes the training data rather than capturing underlying patterns, leading to poor generalization performance on unseen data.

Developing a robust in silico model to predict the DILI risk in humans remains an unmet challenge in drug development. The urgency for accurate DILI prediction in pharmaceutical research and patient safety underscores the need for improved risk management and drug development practices. Machine learning approaches offer a promising solution to address these complex healthcare concerns. This study paves the way for future research into the application of machine learning in DILI prediction and its broader implications for medication safety and healthcare.

## Section: Supplementary Materials

The following supporting information can be downloaded at: https://www.mdpi.com/article/10.3390/toxics12060385/s1, Table S1: Top 10 ranking features out of 168 lasso selected features with symbol and chemical definition; Table S2: The published QSAR models for predicting liver toxicity in humans using DILIrank dataset as the endpoint.

## Section: Author Contributions

Conceptualization, M.C.; methodology, F.M., V.H. and M.C.; validation, F.M. and M.C.; data curation, F.M. and M.C.; writing—original draft preparation, F.M.; writing—review and editing, V.H. and M.C.; visualization, F.M.; supervision, M.C.; project administration, M.C. All authors have read and agreed to the published version of the manuscript.

## Section: Institutional Review Board Statement

Not applicable.

## Section: Informed Consent Statement

Not applicable.

## Section: Data Availability Statement

The datasets used and/or analyzed during the current study are available from the corresponding author on reasonable request.

## Section: Conflicts of Interest

The authors declare no conflict of interest.

## Section: Funding Statement

This research received no external funding.

## Section: Associated Data › Data Availability Statement

The datasets used and/or analyzed during the current study are available from the corresponding author on reasonable request.


---

# Meta-research on reporting guidelines for artificial intelligence: are authors and reviewers encouraged enough in radiology, nuclear medicine, and medical imaging journals?

- **Authors:** Burak Koçak, Ali Keleş, Fadime Köse
- **Issuer:** Diagnostic and interventional radiology (Ankara, Turkey)
- **Type:** Scientific article
- **Published:** 2024-02-20
- **Language:** en
- **DOI:** 10.4274/dir.2024.232604
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38375627/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractPURPOSETo determine how radiology, nuclear medicine, and medical imaging journals encourage and mandate the use of reporting guidelines for artificial intelligence (AI) in their author and reviewer instructions.METHODSThe primary source of journal information and associated citation data used was the Journal Citation Reports (June 2023 release for 2022 citation data; Clarivate Analytics, UK). The first-and second-quartile journals indexed in the Science Citation Index Expanded and the Emerging Sources Citation Index were included. The author and reviewer instructions were evaluated by two independent readers, followed by an additional reader for consensus, with the assistance of automatic annotation. Encouragement and submission requirements were systematically analyzed. The reporting guidelines were grouped as AI-specific, related to modeling, and unrelated to modeling.RESULTSOut of 102 journals, 98 were included in this study, and all of them had author instructions. Only five journals (5%) encouraged the authors to follow AI-specific reporting guidelines. Among these, three required a filled-out checklist. Reviewer instructions were found in 16 journals (16%), among which one journal (6%) encouraged the reviewers to follow AI-specific reporting guidelines without submission requirements. The proportions of author and reviewer encouragement for AI-specific reporting guidelines were statistically significantly lower compared with those for other types of guidelines (P < 0.05 for all).CONCLUSIONThe findings indicate that AI-specific guidelines are not commonly encouraged and mandated (i.e., requiring a filled-out checklist) by these journals, compared with guidelines related to modeling and unrelated to modeling, leaving vast space for improvement. This meta-research study hopes to contribute to the awareness of the imaging community for AI reporting guidelines and ignite large-scale group efforts by all stakeholders, making AI research less wasteful.CLINICAL SIGNIFICANCEThis meta-research highlights the need for improved encouragement of AI-specific guidelines in radiology, nuclear medicine, and medical imaging journals. This can potentially foster greater awareness among the AI community and motivate various stakeholders to collaborate to promote more efficient and responsible AI research reporting practices.Keywords: Artificial intelligence, machine learning, guideline, checklist, reporting

## Section: Text

Poor or suboptimal reporting of medical research is regarded as a significant and widespread issue that contributes to the waste of scarce and valuable resources invested in research projects.1, 2, 3, 4, 5 For such studies, readers cannot assess the validity of the method relative to existing knowledge, and thus the reliability and reproducibility of the findings.6 This hinders the clinical translation of promising research findings7 and their comparability with other publications for evidence synthesis or meta-analysis.8 The adherence to consensus-based reporting standards (i.e., reporting guidelines) is one of the principal methods for reducing the risk of poor reporting. To promote this, vast projects, like Enhancing the QUAlity and Transparency Of health Research (EQUATOR) network, were started, and several reporting guidelines were developed and published in the literature.9, 10 Typically, these guidelines take the form of online or offline checklists, flowcharts, or explicit texts that instruct authors on how to report their research. Several studies researched the effectiveness of adhering to reporting guidelines in various study types. They found that adherence is associated with improved manuscript quality in peer review,11 favorable reviewer ratings and editorial decisions,12 higher citation counts and opportunity to be published in journals with a higher impact factor,13 and improved completeness and quality of the research.14, 15, 16, 17, 18, 19, 20, 21, 22

Similar to healthcare literature, medical artificial intelligence (AI) research faces poor or suboptimal reporting issues. With the massive growth of healthcare literature using AI, including medical imaging,23 the need for complete and structured reporting of prognostic and diagnostic studies that use machine learning algorithms or models has increased. An expanding body of research indicates that AI studies frequently fall short of expected reporting standards,24, 25 lacking sufficient details on modeling and its evaluation, and failing to adequately address potential sources of bias.26, 27, 28, 29, 30, 31, 32 Multiple specific guidelines relevant to AI studies have been developed to address these issues.25, 33, 34, 35, 36, 37, 38, 39, 40, 41 Examples of these guidelines include Checklist for AI in Medical Imaging (CLAIM),42, 43 Fairness, Universality, Traceability, Usability, Robustness, and Explainability-AI (FUTURE-AI),44 Minimum Information about Clinical AI Modelling (MI-CLAIM),45 CheckList for EvaluAtion of Radiomics research (CLEAR),46 and METhodological RadiomICs Score (METRICS).47 In addition, as a continuation of previous efforts, several guidelines are currently under development, such as Standards for the Reporting of Diagnostic Accuracy Studies-AI (STARD-AI) for AI-centered diagnostic test accuracy studies and Transparent Reporting of a Multivariable Prediction Model for Individual Prognosis or Diagnosis-AI (TRIPOD-AI) for those related to diagnostic models.48, 49 The most widely recognized AI guidelines and ones currently under development can be found in the following seminal papers.50, 51

The availability of reporting guidelines and checklists has not yet resolved the problem of inadequate reporting. While editorial guidance advocating for transparent reporting is widespread and well-intentioned, authors frequently overlook or fail to adhere to these guidelines.52, 53, 54, 55, 56, 57 In a very recent citation analysis of an AI checklist on medical imaging and a meta-research on radiomics, claims regarding the use of checklists and quality scoring tools for self-reporting (i.e., reporting with filling checklists by study authors) have been supported.26, 32 Journals can significantly impact the quality of reporting by encouraging or mandating responsible reporting practices, such as the use of reporting guidelines and checklists in their author and reviewer instructions.58, 59 However, research on the encouragement of AI reporting guidelines by journals specialized in radiology, nuclear medicine, and medical imaging is scarce.60 Investigating this issue could yield valuable insights to foster higher-quality research within these journals.

This meta-research study aims to determine how these journals encourage and mandate (i.e., requiring a filled-out checklist) the use of AI reporting guidelines in their author and reviewer instructions by comparing reporting guidelines that are specific to AI, related to modeling, and unrelated to modeling.

## Section: Methods

Figure 1 presents the key study steps of this meta-research.

Key study steps. WoS, Web of Science; RNMMI, Radiology, Nuclear Medicine, and Medical Imaging; SCIE, Science Citation Index Expanded; ESCI, Emerging Sources Citation Index; Q1, first quartile; Q2, second quartile; PDF, portable document format; AI, artificial intelligence.

## Section: Methods › Dataset

The primary source of journals and associated citation data used was the Journal Citation Reports (June 2023 release for 2022 citation data; Clarivate Analytics, UK). This report was based on data obtained from the Web of Science (WoS) (Clarivate Analytics, UK).

Journals indexed in the WoS category, radiology, nuclear medicine, and medical imaging, that met the following criteria were included in this study: inclusion in the Science Citation Index Expanded (SCIE) or Emerging Sources Citation Index (ESCI) and placement within the first quartile (Q1; top 25% of journals in the list) or second quartile (Q2; journals in the top 25%–50% group) based on the 2022 Journal Impact Factor. This analysis excluded journals that had a limited scope, specifically those that focused solely on review articles (i.e., not publishing original research articles), as these journals were not expected to publish articles using AI reporting guidelines.

Two readers, each in their third year of radiology residency and with prior experience conducting systematic reviews on reporting quality in AI or radiomics, accessed the author and reviewer instructions from the journals’ websites and saved them as PDF files. The task was distributed evenly among the readers, and they also reviewed each other’s resulting files. All author and reviewer instructions were accessed between September 4 and 7, 2023. In the case of multiple instructions, the most up-to-date version was selected.

To mitigate errors during the assessment of instructions, a custom Python script based on the PyMuPDF package was used to automatically annotate certain terms within the PDF documents. The terms covered AI, machine learning, reporting, guidelines, checklists, and their specific names or acronyms. The code and exact terms can be accessed at https://github.com/radiomic/PDFhighlighter.

## Section: Methods › Evaluation of author and reviewer instructions

The author and reviewer instructions that were automatically annotated by the script were evaluated by the same readers who downloaded the instructions. All evaluations underwent a meticulous review process overseen by an additional reader possessing 8 years of expertise as a radiology specialist, complemented by over 5 years of research experience in machine learning, radiomics, and systematic reviews. Final decisions were reached by consensus among all readers.

The collected data primarily fell into two categories: encouragement of authors or reviewers and the presence of submission requirements for filled-out checklists in case of encouragement. When evaluating the encouragement, to elicit a positive evaluation from readers, it was imperative to explicitly state the name of the reporting guideline or make a direct reference to it. In addition, encouragement was defined as any sort of mention of specific guidelines. For instance, if authors and reviewers are recommended for adherence, referral, or usage of the guidelines, even if not explicitly intended for integration into their workflow, it was considered encouragement. The inclusion of general references to the central source or hub of guidelines or checklists, such as the EQUATOR network website, was not regarded as a specific encouragement in this work. To fulfill the submission requirement (i.e., mandating), this study sought a clear indication that the filled-out checklist would be uploaded to the submission system as an integral part of both the manuscript and peer review processes. The submission systems were only investigated when the submission requirements were unclear in the instructions. Checklists without an associated publication in a journal (i.e., checklists as part of journal instructions without a digital object identifier) were not considered as a reporting guideline.

Three types of reporting guidelines were analyzed as follows: i) AI-specific reporting guidelines; ii) those related to modeling (e.g., diagnostic or prognostic modeling; may or may not be associated with AI or machine learning); and iii) those unrelated to modeling. AI-specific reporting guidelines and those related to modeling included those specified in two recent seminal articles.50, 51 For AI-specific guidelines (e.g., CLAIM, Consolidated Standards of Reporting Trials for AI (CONSORT-AI), Standard Protocol Items: Recommendations for Interventional Trials for AI (SPIRIT-AI), FUTURE-AI, MI-CLAIM), this study referred to the publication of Klontzas et al.50, which did not limit its scope to a specific data type. For guidelines related to modeling, including AI-specific ones (e.g. TRIPOD), this study referred to the paper of Klement and El Emam51, which primarily focused on structured data. Due to the potential omission of relevant reporting guidelines in these papers, this study refrained from confining its criteria to those listed in the aforementioned articles.

## Section: Methods › Statistical analysis

Statistical analysis was performed using Jamovi (version 2.2.5). The majority of the findings were presented through descriptive statistics, wherein percentages were rounded to the nearest whole number. The inter-reader agreement analysis of the first two readers was conducted using Cohen’s kappa or percentage agreement, as appropriate. The following grading system was used to interpret Cohen’s kappa: kappa ≤0.00, no; 0.00< kappa ≤0.20, slight; 0.20< kappa ≤0.40, fair; 0.40< kappa ≤0.60, moderate; 0.60< kappa ≤0.80, substantial; 0.80< kappa ≤1, almost perfect agreement. Comparison of the distribution of quantitative variables was conducted using either the Student’s t-test or the Mann–Whitney U test, depending on the statistical normality of the data. The chi-square test or Fisher’s exact test was employed to assess differences in the distribution of categorical variables across various citation variables between subjects. Furthermore, McNemar’s test was used for the same purpose within subjects, and the continuity correction was also applied. A P value of <0.05 was considered statistically gnificant.

## Section: Results

Encouragement of authors and reviewers for the reporting guidelines with and without submission requirements. AI, artificial intelligence. *Only the top five most frequently encouraged reporting guidelines were included.

## Section: Results › Baseline characteristics of journals

Out of 102 Q1 and Q2 radiology, nuclear medicine, and medical imaging journals indexed in SCIE and ESCI databases, 98 were included in this study. Four journals were excluded because they published only review articles. Of the journals included, 66 were from SCIE (Q1/Q2, 32/34), with a median 2022 impact factor of 3.9 (interquartile range: 2.4). The remaining 32 journals were from ESCI (Q1/Q2, 16/16), with a median 2022 impact factor of 2.25 (interquartile range: 1.9).

For all 98 journals, instructions specific to authors were found. However, specific instructions for reviewers or referees were found for 16 journals only (16%).

## Section: Results › Analysis of author instructions

Table 1 summarizes the encouragement of authors to use reporting guidelines that are specific to AI, related to modeling, and unrelated to modeling, as well as the requirement of submission for these reporting guidelines.

Considering all 98 journals, only five journals (5%) encouraged the authors to follow AI-specific reporting guidelines. Table 2 presents the AI-specific guidelines recommended in these journals: CLAIM (n = 3), Proposed Requirements for Cardiovascular Imaging-Related Machine Learning Evaluation (PRIME) (n = 1), and Checklist for AI in Medical Physics (CLAMP) (n = 1).42, 61, 62 Of these, three (60%) required a filled-out checklist along with the submission.

In total, 30 journals (31% of 98) endorsed at least one reporting guideline related to modeling, including both general modeling guidelines and AI-specific ones: TRIPOD (n = 26), along with the three aforementioned AI reporting guidelines, namely CLAIM, PRIME, and CLAMP.42, 61, 62, 63 One journal encouraged two modeling-related guidelines (TRIPOD and CLAIM). Of the 30 journals, only four (13%) required a filled-out checklist along with the submission. Furthermore, only one of the journals, Ultrasound in Obstetrics and Gynecology, encouraged TRIPOD and mandated a filled-out checklist.

A total of 75 journals (77% of 98) encouraged at least one guideline unrelated to modeling. The frequency of the most well-known guidelines in these categories is as follows: CONSORT (n = 61), Preferred Reporting Items for Systematic Reviews and Meta-Analyses (PRISMA) (n = 51), Animal Research: Reporting of In Vivo Experiments (ARRIVE) (n = 45), STARD (n = 44), and Strengthening the Reporting of Observational Studies in Epidemiology (STROBE) (n = 42).64, 65, 66, 67, 68 Of these journals, 36 (48%) required a filled-out checklist along with the submission.

The level of encouragement for authors, both with and without submission requirements, regarding the naming of reporting guidelines, is summarized in Figure 2, alongside a comparison with that of reviewers.

Statistically significant differences were observed in the proportions of author encouragement among pairwise comparisons of AI-specific reporting guidelines, those related to modeling, and those unrelated to modeling (P < 0.001 for all). Notably, the encouragement level for guidelines unrelated to modeling was consistently higher across all pairs.

There were no statistically significant differences in the distribution of author encouragement status concerning the journal index (i.e., SCIE vs. ESCI) and quartile (i.e., Q1 vs. Q2) (P > 0.05 for all).

Regarding the encouragement of reporting guidelines related to modeling in general, including AI-specific ones, as well as those unrelated to modeling, the inter-rater reliability analysis yielded almost perfect agreement, with Cohen’s kappa values ranging between 0.916 and 0.950.

Encouragement of authors and reviewers for the reporting guidelines with and without submission requirements. AI, artificial intelligence. *Only the top five most frequently encouraged reporting guidelines were included.

## Section: Results › Analysis of reviewer instructions

Table 1 summarizes the encouragement of reviewers to use reporting guidelines that are specific to AI, related to modeling, and unrelated to modeling, as well as the requirement of submission for these reporting guidelines.

Of the 16 journals that had instructions for reviewers, only one (6%), European Radiology, encouraged the reviewers to follow an AI-specific reporting guideline (CLAIM), which can also be regarded as a modeling-related guideline, without a filled-out checklist along with the submission of peer review.42 The primary purpose was, however, to check whether the authors provided the checklist.

Regarding the guidelines that are not related to modeling, six journals (38% of 16) encouraged the reviewers to follow at least one of those. The journals most frequently recommended CONSORT (n = 4) and PRISMA (n = 4) without a filled-out checklist along with the submission of peer review.67, 68

The summary of reviewer encouragement, both with and without submission requirements, regarding the naming of reporting guidelines, is depicted in Figure 2, alongside a comparison with that of the authors.

There was a statistically significant difference in the proportion of reviewer encouragement between AI-specific or modeling-related reporting guidelines and those unrelated to modeling (P < 0.025), with the latter being the higher.

There were no statistically significant differences in the distribution of reviewer encouragement status against the journal index (i.e., SCIE vs. ESCI) and quartile (i.e., Q1 vs. Q2) (P > 0.05 for all).

For reviewers, the encouragement of reporting guidelines related to modeling in general, including AI-specific ones, as well as those not related to modeling, resulted in high inter-rater reliability, with percentage agreement values ranging between 79% and 93%.

## Section: Discussion › Overview

This meta-research investigated how radiology, nuclear medicine, and medical imaging journals encourage and mandate (i.e., requiring a filled-out checklist) the use of AI reporting guidelines in their author and reviewer instructions. The results were presented by comparing reporting guidelines that are specific to AI, related to modeling, and unrelated to modeling. It was found that only a very small number of journals encouraged (5%, 5/98) and mandated (3%, 3/98) the use of AI reporting guidelines (i.e., CLAIM, PRIME, and CLAMP) for authors. In addition, only one journal (6% of 16 available reviewer instructions) encouraged the reviewers to follow AI reporting guidelines (i.e., CLAIM), without any requirement of submission. Encouragement and the mandated use of AI-specific guidelines and those related to modeling in the journals were generally lower compared with those unrelated to modeling.

## Section: Discussion › Previous related works

There is only one recent closely related study to this research in which the endorsement of AI reporting guidelines in radiology journals has been systematically analyzed.60 In their seminal study, Zhong et al.60 investigated the endorsement of 15 general reporting guidelines and 10 AI reporting guidelines. Of the 117 SCIE journals included, the authors found that CLAIM (1.7%, 2/117) was the only and the most implemented AI reporting guideline, while the other nine AI reporting guidelines were not mentioned. This study found that five (5%) out of the 98 journals encouraged AI-specific guidelines. The disparity in rates can be attributed to two methodological issues. First, the journals differed in their index sources. Second, our study encompassed half of the journals indexed in SCIE and ESCI (i.e., Q1–Q2). In contrast, Zhong et al.60 exclusively included all SCIE journals. Furthermore, the AI reporting guidelines considered for these works were different. This study referenced two prior works and imposed no additional restrictions on their use, provided that they were in the form of a publication (i.e., not a custom checklist that appears on the instructions of journals).50, 51 The authors of the prior investigation restricted their assessment to 10 AI reporting guidelines. Furthermore, both studies reached the same conclusion that the endorsement or encouragement to follow AI reporting guidelines in these journals was remarkably low. Their main findings were complementary and mutually reinforcing.

Given the scarcity of literature on the encouragement of AI reporting guidelines in radiology, nuclear medicine, and medical imaging journals, it would be beneficial to discuss studies that are not specifically pertinent to AI but are nevertheless extremely relevant to the encouragement of and mandating reporting guidelines. In a cross-sectional study, Malički et al.69 analyzed a representative sample of journal instructions for authors across multiple scientific fields, including health sciences. The instructions of 13% of journals suggested the use of reporting guidelines, while only 2% mandated its use. In addition, the authors discovered that journals in the health or life sciences, as well as those published by prominent publishers, were more likely to include reporting guidelines or standards in their author instructions. In a different study, Agha et al.70 investigated the impact of the mandatory implementation of reporting guidelines on the quality of reporting in a surgical journal. Compliance with STROBE, CONSORT, and PRISMA dramatically improved after the policy implementation. The authors observed that implementing a policy demanding the submission of a completed reporting checklist for observational research, randomized controlled trials, and systematic reviews can increase compliance. In addition, they recommended similar approaches for various journals and study types. In another seminal study, Hirst and Altman focused on the encouragement of reviewers to utilize reporting guidelines for 116 health research publications.59 They discovered that 41 (35%) of the journals offered reviewers with online instructions. In addition, they revealed that nearly half of the online instructions referred to these tools without providing clear instructions on how to use them.

## Section: Discussion › Potential reasons for low rates

Considering the relevant works above and the present study, it is evident that journals do not encourage and mandate AI reporting guidelines frequently. The potential causes can only be speculated because their analysis falls outside the scope of this study. The editorial team of the journals may wrongly presume that researchers are aware of these fundamental aspects of rigorous and transparent reporting and that authors are entirely responsible for implementing them, not the journals. The journals may also be hesitant to incorporate appropriate reporting practices through reporting guidelines, and they may be unwilling to address scientific misconduct and correct publication errors.71, 72, 73 The editors may also not want to unintentionally overburden the authors with too many instructions. Even if journals encourage good reporting practices, researchers may be resistant to fundamental change. Furthermore, despite the validity of these tools, journals may not agree on the importance of reporting guidelines and may be hesitant to recommend their usage in the absence of convincing proof of their effectiveness.

## Section: Discussion › What are the following steps?

In light of the outstanding and exponential growth of AI research on medical imaging over the past decade,23 it is necessary to promote the highest-quality research. It would be advantageous to conduct additional research to define the effectiveness of AI reporting guidelines. Such research will help persuade journals to encourage and mandate them. Hence, there is a need for further assessment of AI reporting guidelines to determine their optimal utilization. This assessment should consider whether they should be incorporated into the study design, applied during ongoing research, utilized solely for reporting purposes post-study completion, or implemented at the request of journals, among other potential considerations. Enhancing our understanding of the factors that influence the dissemination and implementation of these tools and strategies is crucial for improving their efficacy and promoting their broader adoption. Future research should investigate the obstacles journals might experience when adopting such policy changes in their journals, as well as how automated tools could minimize their workload while guaranteeing adherence to these reporting guidelines. Furthermore, radiology, nuclear medicine, and medical imaging journals may collaborate to improve reporting standards for research. These group initiatives should also be supported by scientific organizations, universities, institutions, societies, and funding agencies. This would make it more difficult for authors receiving negative reviews due to inadequate reporting to choose journals with more flexible reporting policies. This could enhance the overall reporting quality of the scientific literature. In certain areas of medical research, such as rehabilitation and disability, the journals established such collaborations.74 As of 2014, 28 prominent rehabilitation and disability journals have joined a group to require the adherence to reporting guidelines to increase the quality of research reporting, not just inside their journal but also within their field of medicine and research. They jointly published an editorial, announcing their agreement and urging authors to adhere to appropriate EQUATOR reporting guidelines when preparing articles for submission. They also requested reviewers to utilize reporting guidelines when evaluating submissions.74 A similar group effort is crucial to improve the overall reporting quality of AI research in radiology, nuclear medicine, and medical imaging journals.

## Section: Discussion › Limitations

This study has a few limitations. First, it assumed that instructions are the sole location where reporting guidelines that are encouraged or mandated can be found. However, some of the requirements editors put on authors and reviewers may not be necessarily outlined in the instructions. For instance, the submission systems of all the journals were not thoroughly analyzed to check whether they encouraged or requested the use of guidelines during the submission and/or review processes. It was presumed that this was not common practice. Nonetheless, their submission systems were only investigated when the submission requirements were not clear in the instructions. Second, only Q1 and Q2 SCIE and ESCI journals indexed in the WoS were included due to their well-known high standards for indexing. Therefore, it is unlikely to represent the editorial standards of all journals. To diversify the journal characteristics, Q1 and Q2 ESCI journals were included instead of Q3 and Q4 SCIE journals. However, achieving a perfect representation of journals in terms of diversity should not be a major concern in an exploratory study focusing on a new area of reporting guidelines. Third, while downloading the journal instructions, they were double-checked for accuracy. Due to the complex and multi-layered design of certain journal websites, some parts of the instructions may have been omitted. Additionally, this study aimed to evaluate the automatically annotated content of the instructions through independent readings by two readers, with consensus reached through consultation with a third reader. This study may have missed any reporting guidelines that were recommended or deemed necessary in the submission. However, the impact of missing instructions and their content analysis will likely be minor. Finally, the instructions were downloaded over a brief time frame (between September 4 and 7, 2023). If journals had improved their instructions after this period, these changes would not have been reflected in the results.

In conclusion, this meta-research study provides an overview of instructions for authors and peer reviewers across radiology, nuclear medicine, and medical imaging journals. It specifically examines the encouragement of AI-specific reporting guidelines and their submission requirements, comparing them with guidelines related to modeling and those unrelated to modeling. However, the findings indicate that these AI-specific guidelines are not commonly encouraged and mandated (i.e., requiring a filled-out checklist) by these journals, compared with other guidelines. To further encourage the use of these tools, all stakeholders, including developers, journal managers, editors, reviewers, authors, and funders, are required to collaborate. Given their position at the forefront of AI, if more of these journals enforce or encourage responsible reporting through guidelines, the value of articles and AI research may increase and become less wasteful.


---

# Mining for Potent Inhibitors through Artificial Intelligence and Physics: A Unified Methodology for Ligand Based and Structure Based Drug Design

- **Authors:** Jie Li, Oufan Zhang, Kunyang Sun, Yingze Wang, Xingyi Guan, Dorian Bagni, Mojtaba Haghighatlari, Fiona L Kearns, Conor Parks, Rommie E Amaro, Teresa Head-Gordon
- **Issuer:** Journal of chemical information and modeling
- **Type:** Scientific article
- **Published:** 2024-06-06
- **Language:** en
- **DOI:** 10.1021/acs.jcim.4c00634
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38843070/
- **Licence:** CC-BY

## Section: Abstract

AbstractDetermining the viability of a new drug molecule is a time- and resource-intensive task that makes computer-aided assessments a vital approach to rapid drug discovery. Here we develop a machine learning algorithm, iMiner, that generates novel inhibitor molecules for target proteins by combining deep reinforcement learning with real-time 3D molecular docking using AutoDock Vina, thereby simultaneously creating chemical novelty while constraining molecules for shape and molecular compatibility with target active sites. Moreover, through the use of various types of reward functions, we have introduced novelty in generative tasks for new molecules such as chemical similarity to a target ligand, molecules grown from known protein bound fragments, and creation of molecules that enforce interactions with target residues in the protein active site. The iMiner algorithm is embedded in a composite workflow that filters out Pan-assay interference compounds, Lipinski rule violations, uncommon structures in medicinal chemistry, and poor synthetic accessibility with options for cross-validation against other docking scoring functions and automation of a molecular dynamics simulation to measure pose stability. We also allow users to define a set of rules for the structures they would like to exclude during the training process and postfiltering steps. Because our approach relies only on the structure of the target protein, iMiner can be easily adapted for the future development of other inhibitors or small molecule therapeutics of any target protein.

## Section: Introduction

Discovery of new drugs that inhibit target proteins usually follows either a screening-based approach or a rational design approach.1,2 If no explicit information about either the structure of the protein target or a ligand that might bind to the protein is available, the screening of a large database might be the only realistic approach to identify a starting point for drug development. However, any additional information about the structure of either the protein or the ligand can narrow down the search space significantly and encourages rational ligand based or structure based drug design.2,3 The process of rational drug design requires either exquisite domain knowledge and devoted time by an experienced medicinal chemist or using an automated workflow that relies on virtual screening of protein–ligand databases combined with physics-based modeling, such as docking simulations, to identify candidate molecules that may potentially bind to the protein target of interest.4

In order to identify promising small molecule therapeutics, existing high-throughput virtual screening approaches often evaluate comprehensive drug databases such as ChEMBL,5 PubChem,6 and ZINC.7 Even with the recent advent of the Enamine REAL library of 6–11 billion molecules,8 it is still dwarfed by estimates for the total number of possible synthesizable small molecules that range from 1024–1060.9 Unfortunately, due to the size of such established or expanded databases, screening all compounds according to sufficiently sophisticated structure based methodologies, such as flexible ligand docking, can be intractable. Even with simpler methods such as pharmacophore modeling or rigid body docking, it can still be time-consuming to navigate through the chemically feasible space, with a tendency toward false-positives being ruled in while false-negatives, i.e., potential optimum lead molecules, can be ruled out.10,11

With the rise of modern machine learning, a more clever exploration of the chemical space for drug-like molecules becomes possible, thanks to the development of generative models that can generate molecules represented as either strings or graphs.12−22 More interestingly, the distribution can be skewed toward molecules with specific properties such as drug likeness using techniques such as variational autoencoders (VAEs),13,14 transfer learning,15 and reinforcement learning (RL).16−22 However, early deep learning methods rely on one-dimensional (1D) sequence or two-dimensional (2D) chemical representations of the drug and protein and do not take full advantage of three-dimensional (3D) structural information on the putative drug, thereby constraining the ability to generate drugs with shape and molecular compatibility with the target active site. When SMILES-based generative models were combined with additional information about protein structure, ligand structure, or protein–ligand interactions, the quality of generated molecules improved in terms of predicted binding affinity or binding mode similarity with a reference binder.23,24 Recent work has explored chemical space in the vicinity of some starting molecular scaffold, running docking simulations on these derived molecules,25 but the chemical space that can be explored by such a method is still rather limited. Generation of atomistic structures of new compounds conditioned on the 3D structure of a provided pocket or constrained on interaction fingerprints has also been proposed with sequential growth of atoms,26,27 hierarchical buildup of 3D coordinates28,29 or generating all-atom coordinates at once using diffusion models.30,31 However, these existing methods have either been tailored toward de novo generation or a local optimization but lack the flexibility to extend from de novo design to structure or ligand based rational design. These additional capabilities are essential for continuously improving the binding potency between ligands and proteins after a hit molecule is already identified.

In this work, we propose a novel composite workflow, dubbed “iMiner”, that mines chemical space for new tight binding inhibitors by combining deep RL with real-time flexible ligand docking against a protein binding site. We represent putative inhibitors as Self-Referencing Embedded Strings (SELFIES)32 that are generated from an Average Stochastic Gradient Descent Weigh-Dropped Long Short-Term Memory (AWD-LSTM)33 recurrent neural network (RNN), allowing wide coverage of chemical space. We illustrate the RL training procedure of iMiner that uses on-the-fly AutoDock Vina34 in a predefined binding pocket of the 3D structure of the protein to generate small molecule inhibitors, in which the AutoDock-Vina score is used to adjust the RNN so that the distribution of generated inhibitor molecules are shifted toward those that more strongly interact with the protein. The iMiner algorithm is further distinguished from other generative models with additional capabilities to drive not only de novo molecular design but also ligand based design (generating similar molecules to early optimized hits) and structure based design (growth from bound ligand fragments and/or enforcing ligand interaction with certain protein sites), a unique versatility within our reinforcement learning. Finally, iMiner also offers the option to provide a series of postfilters to down-select the generated molecules so that they obey Lipinski rules,35 increase the likelihood of synthetic accessibility (SA) and drug likeliness, avoid nonspecific binders (Pan-assay interference compounds or PAINS)36 or certain disfavored substructure elements, and find consensus molecules with alternative docking software and scoring functions.

To validate the effectiveness of the iMiner approach, we designed inhibitors for the popular SARS-COV-2 Main protease (Mpro) as an example (see Supporting Information). We chose this system because of the ready availability of experimental 3D structures37 and the fact that multiple effective ligands have already been proposed to inhibit Mpro,38 which provides ample information for different structure based and ligand based designing strategies.39 We illustrate the four features of the iMiner approach and evaluate our model’s capability to generate new inhibitors and perform structural modifications while keeping the pharmacophore intact, growing ligands from a fragment starting point, or retaining key interactions with a specified protein residue. Although illustrated on the SARS-COV-2 Mpro target, we would like to emphasize that the iMiner workflow can be readily adapted to generate small molecules for other protein targets, since it only requires a 3D structure of the target protein with a predefined binding site. Thus, we believe our ML algorithm will be of great interest to the drug design community to rapidly screen novel regions of chemical space in real-time for other antivirals or small molecule therapeutics in the future.

## Section: The iMiner Algorithm and Workflow

Figure 1 provides an illustration of the overall structure of the iMiner algorithm, which highlights the two major machine learning components, the generative and evaluative models, and their interplay for generating new inhibitor molecules. In addition, we embed the RL-physics model into a composite workflow for further analysis and down-selection, also displayed in Figure 1. Here we describe the iMiner algorithmic components and workflow in more detail.

Illustration of the overall structure of the iMiner algorithm and workflow. (a) The generative model uses SELFIES representations for molecules and a recurrent neural network to “mine” for new molecules that are presented to the evaluative model for 3D docking using AutoDock Vina. Vina scores and other loss/reward functions are used to drive gradient updates of the neural network. (b) The iMiner workflow provides automated postselection filters, consensus scoring, and MD simulations for overall ranking.

## Section: The iMiner Algorithm and Workflow › The Generative Module

Conceptually, generating molecules using a string representation is similar to the way text is generated in a natural language processing task. Our method starts with a specific [Break] token, and for each molecule, we utilized a RNN that takes in the last token in the string, together with the hidden state from the last step to predict a distribution of tokens following the current string. In this work a specific variant of the RNN, known as the AWD-LSTM, was used due to its exceptional performance in similar generative tasks (Figure 1a).33

## Section: The iMiner Algorithm and Workflow › The Generative Module › SELFIES Representation of Inhibitor Molecules

An arbitrary molecule can be represented as a topological graph using two main approaches: adjacency matrix methods and string based methods. The former uses an N by N matrix to encode a molecule, where N is the number of atoms in the molecule and the values of the matrix are typically bond orders between atoms. An adjacency matrix is not ideal for generative tasks because the size of the molecule that can be generated should not be fixed, and the learning of chemical knowledge by a ML model through adjacency matrix can be difficult. Instead, string based methods are more suited for molecular generation tasks, and SMILES strings have been the standard for molecular representation due to their conciseness and readability. However, SMILES strings have relatively complex syntax and require matching of open and closed brackets for branching, and ring modeling/modification is not trivial. Therefore, generating novel, chemically correct compounds through the use of SMILES strings can be challenging.

The SELFIES molecular representation32 is specifically designed to ensure that all generated strings correspond to valid molecules. By utilizing [Branch] and [Ring] tokens with predefined branch lengths and ring sizes, as well as generating symbols using derivation rules, the SELFIES representation guarantees that valence bond constraints are met and any combinations of tokens from its vocabulary correspond to a valid molecule. Therefore, we have used SELFIES in our generative model to encode molecules since it does not need to learn chemical syntax rules and can allocate more of its learning capacity toward generating valid molecules with properties of interest.

## Section: The iMiner Algorithm and Workflow › The Generative Module › Pretraining the Inhibitor Molecule Generation

The network was pretrained using supervised-learning (SL) of all molecules from the ChEMBL database to learn the conditional probability distributions of tokens that correspond to drug-like molecules. When our trained generative model is used for generating new molecules, a new token is sampled according to the predicted probabilities, and this new token is concatenated to the input string to sample the next token until the [Break] token is sampled, in which case a complete molecule has been generated.

We then validated our pretrained distributions using 13 drug-likeliness properties between our generated molecules and randomly sampled molecules from the ChEMBL database that we used for training. The molecular properties considered are well-recognized chemical features related to the drug-likeliness of a molecule which can be obtained through 2D topological connectivity of the molecule: fraction of sp3 hybridized carbons, number of heavy atoms, fraction of non-carbon atoms in all heavy atoms, number of hydrogen bond donors and acceptors, number of rotatable bonds, number of aliphatic and aromatic rings, molecular weight, approximate log partition coefficient between octanol and water (alogP),40 polarizable surface area (PSA), number of structural alerts,41 and size of the largest ring in the molecule. Despite the fact that during pretraining only token distributions were used as training targets, all distributions collected from our generated molecules closely follow the distributions from the ChEMBL database (Figure S1). This result suggests our pretrained model has learned key concepts of “drug-likeness” and provides a good starting point for the RL procedure.

## Section: The iMiner Algorithm and Workflow › The Evaluation Module

After our generative model was pretrained, we employed an RL workflow to bias the distribution of generated molecules toward specific properties of interest. RL training allows the model to interact with an environment by performing actions according to a policy model and uses the feedback from the environment to provide training signals to improve the model. In this work, the pretrained generative model is taken as the policy, and in each iteration, 2000 molecules were generated and sent to the evaluation module (Figure 1a).

## Section: The iMiner Algorithm and Workflow › The Evaluation Module › Physics-Based Docking

The central component of our evaluation model is docking with AutoDock Vina (Vina) in parallel with the RL. Within our evaluation model, the Vina score calculator takes a SMILES string representing the ligand and the 3D structure of the protein target, together with a predefined docking region, as input. AutoDock Vina then explores variations of the dihedral angle degrees of freedom and identifies the optimal conformation of the input inhibitor for placement in the designated protein binding site. Finally, AutoDock returns the Vina score as an approximation of the binding energy between the ligand and the protein. Multiple instances of the Vina score calculator tasks were established through GPU parallelization to allow high-throughput evaluation of the generated molecules.42 Vina scores were then cycled back to the generative model to improve molecule generation through proximal policy optimization (PPO),43 as will be discussed in next section. We emphasize that by using a physics-based docking model which utilizes the full 3D structure of our target protein and generated molecules as the critic, the training of the policy model is less likely to be contaminated due to exploiting failure modes of a neural-network based critic, an issue called wireheading.44 Instead, we benefit from a more reliable training signal and reduce the false positive and false negative rates of the generated molecules.

Vina scores alone are not sufficient to reliably train a molecule generator, as shown in the Supporting Information (Figure S2) because it will not always satisfy requirements for drug-likeness. To ensure that our generated molecules still bear drug-like properties, we incorporated an additional metric into the reward, SDL, which is a weighted average of the log likelihood for the 13 different drug-like properties used in pretraining assessment. Our custom drug-likeliness score is an extension of the widely used quantitative estimate of drug-likelihood (QED) value45 tailored to our deep learning generative model. Formally, the drug-likeliness score SDL is defined as

where propi(X) calculates the ith property of a molecule X and pi is defined by the probability distribution of property i by all molecules in the ChEMBL database. The parameter σi is defined as

where Si is the entropy of the distribution of property i,

such that a narrower distribution from the ChEMBL database contributes more to the drug likeliness score and defines the weights for each property as proportional to the inverse of the entropy. Introducing this additional reward ensures our model also accounts for similarity of generated molecules to the drug-likeliness present in the ChEMBL database and ensures that our generated molecules are more likely to be optimal leads for further drug design endeavors. Additionally, since the ChEMBL database also contains molecules with undesirable molecular scaffolds, we allow users to define specific undesirable chemical patterns using SMARTS strings46 and manually set the drug-likeliness score to 0 to discourage their appearances in future iterations. A set of suggested SMARTS patterns have been enabled by default, and further details are given in Supporting Information and Table S1.

## Section: The iMiner Algorithm and Workflow › The Evaluation Module › Reinforcement Learning with Different Reward Types

Our pretrained policy model defines a probability distribution for an arbitrary sequence of tokens from the SELFIES vocabulary, since the generation of the sequence is a Markovian decision process (MDP), and can be written as

where s0 corresponds to a starting state with [Break] as the only token in the string, st corresponds to an intermediate state with a finite length string of SELFIES tokens not ended with the [Break] token, and sT corresponds to the terminal state, with the last token being [Break] or the length of the string exceeding a predefined threshold. p(st|st–1) is the transition probability at time step t, which is the probability distribution of the next token from the generative RNN with the network parameters Θ. For each terminal state not exceeding the length limit, a corresponding molecule can be decoded, and the Vina score Svina and drug-likeliness score SDL, can be calculated and further optimized. The total reward for a terminal state with a decoded molecule X is then defined as

where i denotes the reward function types and λ parameters control the balance between the different scores. For the unconditional de novo generation case, where only the drug-likeliness score needs to be maximized and Vina score needs to be minimized, the reward becomes

Negative SDL is upward clipped to 0 and positive Svina is downward clipped to 0 to ensure the reward is non-negative. The expected reward under the MDP is then

To encourage the model to generate molecules based on a certain scaffold, we introduced a fragment similarity score, defined by the maximum Dice similarity of the Morgan fingerprints between fragments of the query molecule decomposed using BRICS47 and the target molecule or structural components, as well as a pharmacophore similarity score with the Pharm2D48 module in RDkit.49 In addition to molecular similarity, we also implemented a positional penalty of the docking score to impose a 3D structural similarity if needed. The algorithm identifies the most similar fragment component in a sampled molecule, calculates the shape alignment of the component to the target fragment, and clips the docking score to 0 if the alignment difference exceeds a given threshold.

A further augmented feature of iMiner is the generation of molecules that interact with specific protein residues in the pocket. We developed an interaction score as the weighted total of interactions of specific types between the predicted binding pose of a sampled molecule and the specific residues using Protein–Ligand Interaction Profiler (PLIP),50 where the weights are defined by users to prioritize certain interaction types and/or protein residues as desired. We also differentiated hydrogen bonding with angle <135° and the hydrogen-donor bond length >2.8 Å as weak interactions and down-scaled the corresponding interaction scores by 0.5 to encourage the generated molecules to form stronger bonds.

While we present results below using the different reward scores separately for clarity, all the above customized scores can be used jointly along with the drug-likeliness score and Vina score to meet different design criteria. Further details of the RL training procedure and hyperparameters λ are given in the Methods section and Supporting Information and Table S2.

## Section: The iMiner Algorithm and Workflow › The iMiner Workflow

The iMiner algorithm is embedded in a composite workflow that automates the postanalysis of generated molecules to help with overall ranking (Figure 1b) After completion of molecule generation and optimization, it is desirable to filter out PAINS molecules as well as molecules with Lipinski rule violations51 and to select for molecules with good synthetic accessibility (SA) scores according to the SwissADME software.52 We therefore developed and applied a set of filters requiring no PAINS, no Lipinski rule violations, and SA scores using the RDKit package,49 as well as a drug-likeliness score filter of >2.8 to exclude any structure that is not sufficiently drug-like. For the task to generate molecules with desired protein–ligand interactions, we applied an additional filter to extract molecules with confirmed interactions with the specified protein residue(s). While we use these specific values for the results described below, users have the option to change these values if desired.

Checking for consensus with alternate scoring functions is often considered good practice as any individual scoring function may have limited accuracy or be parametrized for different test cases.53 Thus, the workflow collects all molecules from RL training iterations with a user-defined Vina score cutoff and evaluates them with two alternative scoring functions. For cross-validation, we utilized a new AutoDock Vina score (newVina) and new InteractionGraphNet (newIGN)54 that were recently retrained using LP-PDBBind,55 a cleaned version of PDBBind data that implement control on the data similarity between the train, validation, and test data set. It was shown that the predicted binding affinities using retrained Vina and IGN scoring functions have much better accuracy and generalizability than those from the old versions, when evaluated using the cocrystal structures.55 The next step was to rescore the above resulting molecular poses with the newVina and newIGN scores and extract molecules that are in a certain consensus top range.

The final stage of the iMiner workflow is to run a molecular dynamics (MD) simulation for the protein–ligand complex. It has been widely recognized that molecular docking has some difficulties in terms of distinguishing nonbinders from binders as a consequence of lacking ensemble information and inability to capture induced-fit effects. Physics-based MD simulation has demonstrated its ability to improve the power of classical docking functions by effectively incorporating flexibility of both the receptor and the ligand while also including molecular aqueous solvent. Specifically, Guterres et al. have shown that 50 ns MD can serve as a postfilter for docking outcomes to distinguish decoys from binders if the ligand’s RMSD during the trajectory is larger than a threshold, which means that the binding is less stable.56 Therefore, we incorporate MD simulations into iMiner as a tool to validate the protein–ligand binding.

The automated MD procedure is described as follows: (1) the protein–ligand pose with the best Vina score is used as the initial structure and the simulation system is prepared by adding water solvent molecules and when required neutralizing counterions (Na+ or Cl–); (2) AMBER14SB/GAFF2/TIP3P are adopted to parametrize the protein, ligand, and water, respectively; (3) the system is first energy minimized followed by a 1 ns equilibration simulation in the NVT ensemble under 1 bar, 298.15 K, followed by a 1 ns simulation under the NPT ensemble; (4) a 50 ns production run is performed in the NPT ensemble and a total of 250 structures are collected for analysis in step 5; (5) for each structure the ligand’s RMSD is calculated with respect to the starting pose, and the probability of interactions between the ligand and protein are also analyzed with PLIP;50 (6) for a stable protein–ligand complex from step 5, if the user specifies, a longer production run in the NPT ensemble can be performed and the simulation time is also determined by the user. Herein, we use 1 μs for our SARS-CoV-2 main protease target in which the active site is not clearly defined solvent-exposed (not cryptic).57 For those targets that contain cryptic pockets or the structure is flexible, longer time may be needed.

## Section: Results

Kernel density estimate plots of Vina docking score and drug likeliness for de novo generated molecules before and after RL training. For this comparison, 1000 molecules were generated using the models before and after RL training to create the plot.

Drug-related property analysis between iMiner proposed molecules and experimentally confirmed binders. (a) Kernel density plots of the newVina and newIGN score distributions across two groups of molecules. (b) Distribution comparison of six different categories of bioactivity scores for the predicted target interaction.

iMiner generated structural analogs from a set of reference molecules. (a) The perampanel-derived38 reference molecules used to guide iMiner generation. (b) Surface rendering of the iMiner generated analogs in the Mpro canonical binding pocket. (c) 2D visualization of the iMiner-generated analogs with the shared motif highlighted in pink. Also see Table S5.

Structural based fragment growth using iMiner. (a) 2D and 3D visualization of the core fragment sitting in the pocket and interacting with His163 and Glu166. (b) Surface rendering of the filtered set of iMiner generated molecules overlaid in the Mpro canonical binding pocket denoted as P1, P1′, P2, and P3. The substructure fragments are shown in magenta. (c) Twelve representative filtered molecules with the fragment highlighted. Also see Table S6.

Molecules from iMiner interaction based design to target Mpro His163/Glu166. (a) Binding modes of the generated molecules show a rich polar interaction profile against specified residues. (b) Surface rendering of the generated molecules in the Mpro canonical binding pocket. (c) Twelve representative iMiner molecules with highlighted hydrogen bond donor/acceptor groups that form interaction with His163 (pink) and Glu166 (green). Also see Table S7.

Binding stability analysis between an iMiner-proposed molecule and a known ligand. (a) Representative 2D and 3D visualization of the crystal ligand of Mpro (PDB Code: 7L13) from Zhang et al.38 and iMiner_24_970 from the unconditional de novo design. (b) Residue-level protein–ligand interaction frequency comparison performed between both molecules.

## Section: Results › Unconditional De Novo Generation

We use SARS-CoV-2 Mpro as an example to demonstrate iMiner’s ability to generate a diverse set of potential small-molecule drug-like candidates without any information beyond the active site. To achieve this goal, two objectives are optimized during the RL training: (1) AutoDock Vina docking score to ensure the proposed molecules have good binding efficacy and (2) drug-likeliness to constrain our chemical search space only to molecules that are considered as drug-like.

When the training was completed, we looked at the shift in the distributions of the optimized objectives and the molecular properties of generated compounds. In Figure 2, we compare the distribution of Vina score and drug-likeliness score before and after RL training. The clear shift toward more negative Vina scores while maintaining a similar drug-likeliness distribution shows that iMiner can bias the generative model toward more potent and drug-like binders.

Furthermore, to inspect the changes in molecular properties before and after RL optimization, in Table 1, we evaluated the GuacaMol benchmarks,58 which probe 5 different aspects of the distribution of generated molecules with respect to the training data set. Model “validity” reports the proportion of syntactically correct molecules. Because we generated molecules via SELFIES representations, we achieved close to 100% validity for all generated molecules both in the pretrained step and after the RL optimization. Invalid molecules were either empty strings or molecules for which the SELFIES package failed to convert into a SMILES string and therefore were discarded before the next workflow steps. Model “uniqueness” reports how many generated molecules are duplicates versus those which are genuinely distinct. Our pretrained and RL models illustrate high uniqueness, indicating the model is able to generate a wide variety of nonredundant molecules. Model “novelty” is defined as the proportion of generated molecules that do not exist in the training data set. The high novelty of both our pretrained and RL model indicates that it is not memorizing molecules from the training data set but is indeed generating molecules that it has not seen before. By these 3 metrics, the pretrained and RL molecules satisfy the criteria of an unconditional de novo generation of unique molecules.

But the RL learning should also generate unique molecules that are specific to the 3D interaction space of the binding pocket. The Kullback–Leibler (KL) divergence measures differences in probability distributions of various physicochemical descriptors for the training set and the pretrained and RL model generated molecules. As defined by GuacaMol, a high KL divergence benchmark suggests that the generated molecules have similar physicochemical properties to those of the training data set. This is true for the pretrained models by design, but what is clear after the RL optimization is that the influence of the 3D shape requirements of the protein pocket and emphasis on drug-likeness results in significant deviation from the original training set. This is also reflected in the Frechet ChemNet Distance (FCD), which utilizes a hidden representation of molecules in a previously trained NN to predict biological activities and thus captures both chemical and biological similarities simultaneously for two sets of molecules.59 Molecules generated by our pretrained model have high FCD values, indicating that our molecules have similar biological activities as molecules from the ChEMBL training data set. However, the strong deviation after RL training shows that the generated molecules reside in a different chemical space. In Table S3, we show that the model after RL training can generate molecules that are more similar to those of known SARS-Cov-2 Mpro binders.

After the initial filtering with a top 10% Vina docking score cutoff, 12,600 molecules were selected for consensus rescoring and chemical property comparisons with other deep-learning-based methods were shown in Table S4. Then, 125 molecules were filtered from the consensus scoring for the final analysis to assess their distribution compared to a set of the known experimental binders borrowed from LP-PDBBind.55 Specifically, we looked at the newVina and newIGN score distributions as well as the bioactivity scores used in similar studies.60,61

In Figure 3a, the distribution of the surviving molecules falls in a similar and, in the case of newIGN, even better range compared to the known experimental binders, indicating that our stringent down-selection with consensus scoring could successfully lead us to molecules that have the potential to form strong interactions with our target protein. In Figure 3b, we examine the various bioactivity scores to show that our molecules are similar to the known binders from a pharmacological perspective. Bioactivity scores are a quantitative estimate of a compound’s interaction with different targets. A score of less than −0.5 usually means the compound is inactive; a score in the range of −0.5 to 0 corresponds to the compound being moderately active; and a score of larger than 0 indicates the compound is biologically active.60 Here, this similarity in the score distribution across all targets indicates that the proposed molecules and the experimental binders share close pharmacological properties. Specifically, 29 proposed molecules have a bioactivity score larger than 0 in the category of protease inhibitor, suggesting a high potential for proposed compounds to be effective.

Kernel density estimate plots of Vina docking score and drug likeliness for de novo generated molecules before and after RL training. For this comparison, 1000 molecules were generated using the models before and after RL training to create the plot.

Drug-related property analysis between iMiner proposed molecules and experimentally confirmed binders. (a) Kernel density plots of the newVina and newIGN score distributions across two groups of molecules. (b) Distribution comparison of six different categories of bioactivity scores for the predicted target interaction.

## Section: Results › Generation of Structural Analogs

Structural analogs are designed to have a similar structure to a reference molecule which is (often) a known binder but made to differ in certain functional groups to optimize the structure–activity relationship (SAR). Developing structural analogs is valuable in drug discovery because they can display a spectrum of biological activities distinct from the parent molecule, but it remains a combinatorial search challenge such that automated computational approaches can be of great value. We therefore have adapted iMiner’s reinforcement learning coupled with the docking algorithm to also include a structural similarity score to efficiently explore the variations in chemical space around a given target compound. We have considered two types of structural similarity: fingerprints that encode the topology of a molecule and pharmacophore models that capture the arrangement of chemical features important for biological activity. In this work, we exemplify this approach by generating analogs of the SARS-CoV-2 Mpro inhibitors reported by Zhang et al.38

Figure 4a displays the reference molecules which are comprised of a core cloverleaf motif around a central pyridinone ring, a pyridinyl group, and a meta-substituted phenyl ring directed toward His41, features considered to be well-optimized in ref (38). As seen in Figure 4b, the iMiner molecules generated to maintain similarity to the core motif have also varied the functional groups extending into the P3 region of the Mpro canonical binding pocket, as seen in Figure 4b. In addition, Table S5 shows that both newVina and newIGN scores of the docked poses of the generated molecules determined by Autodock Vina aggregate in the more negative energy (higher affinity) range compared to those of the reference perampanel derivatives since the iMiner model also optimizes binding affinities while exploring a local chemical space around the reference molecules.

iMiner generated structural analogs from a set of reference molecules. (a) The perampanel-derived38 reference molecules used to guide iMiner generation. (b) Surface rendering of the iMiner generated analogs in the Mpro canonical binding pocket. (c) 2D visualization of the iMiner-generated analogs with the shared motif highlighted in pink. Also see Table S5.

## Section: Results › Structure-Based Fragment Growth

Fragment-Based Drug Discovery (FBDD) has emerged as an attractive strategy in modern medicinal chemistry and drug development due to its advantages in lower experimental cost and diversity of paths to novel compounds.62 Fragments, for instance, from a screening campaign or as an interesting substructure of a validated binder, can serve as foundational building blocks which can be evolved and optimized into potent drug candidates. While fragments provide only starting points due to their modest affinity, deciding how to grow the molecule or even connect multiple fragments while enhancing activity can be an intricate and subtle task. While FBDD can be readily addressed by iMiner using structural similarity scores as demonstrated above, it is now more challenging because we are also enforcing the structural binding mode of the starting fragment. One intuitive approach would be to perform docking with constraints. However, few publicly available docking programs offer such a function without extensive reparametrization. Instead, iMiner employs a “top-down” approach that in addition to rewarding molecules with high similarity, also penalizes the docking scores of molecules whose binding poses do not match with the starting fragment, thereby reducing sampling of molecules with incorrect orientation or connectivity during the RL phase.

As an example, we use iMiner to propose molecules containing a pyridinone ring connected to a pyridinyl group that resides in the Mpro P1 pocket (Figure 5a), extracted from the molecules developed by Zhang et al. for Mpro, by performing RL training with a pose adjusted Vina score and fragment similarity score starting from a fine-tuned model (see Methods section). A set of 12 representative molecules in Figure 5b,c with the matching substructure aligned to the starting fragment were harvested from the validation and postfiltering process. As seen in the figure many of the proposed molecules extended from the fragment adopt a cloverleaf-like motif branching into the P1, P1′, and P2 subpockets as observed in Zhang et al. The preservation of hydrogen bonding interactions to His163 and Glu166 of these predicted poses, as adopted by the original fragment, was also preserved in the iMiner molecules. Together the results verify that the RL-physics model not only learned the chemical and structural information on the fragment but was able to grow a larger molecule that improves the pocket complementarity.

Structural based fragment growth using iMiner. (a) 2D and 3D visualization of the core fragment sitting in the pocket and interacting with His163 and Glu166. (b) Surface rendering of the filtered set of iMiner generated molecules overlaid in the Mpro canonical binding pocket denoted as P1, P1′, P2, and P3. The substructure fragments are shown in magenta. (c) Twelve representative filtered molecules with the fragment highlighted. Also see Table S6.

## Section: Results › Designing Molecules to Interact with Specific Protein Sites

An alternative scenario of significant interest involves designing molecules to engage with specific protein residues within the pocket. These residues may possess vital catalytic activities or exhibit low mutation rates; thus, the inhibitors designed specific to these residues are less likely to develop resistance to viral variants. We investigated the use of iMiner to generate molecules with hydrogen bonding interactions to His163 in the SARS-CoV-2 active site. His163 is a conserved residue in different SARS-CoV-2 strains and multiple inhibitors, such as the FDA-approved remdesivir63 and ensitrelvir,64 show consensus in forming a hydrogen bond with His163. Starting from the ChEMBL pretrained model and assuming no other knowledge about the structural and chemical features of a potential Mpro binder, we trained a model using an interaction score with respect to key residues such as His163 and Glu166, Vina docking score, and drug-likeliness score in the reward function.

In Figure 6, the overlay of postfiltered iMiner-generated molecules in their binding conformations determined through AutoDock Vina confirms their participation in hydrogen bonding interactions with His163 or Glu166 or both as expected. In Figure 6a, this set of 12 representative molecules has shown a diverse set of scaffolds while retaining the key interactions with the specified residues. Figure 6b further shows that the molecules could fill the P1, P2, P3, and P1′ subpockets, satisfying the pocket complementarity. In addition, several other key hydrogen bonding interactions with the backbone atoms of Cys145 and Ser144 were recovered from the docked poses of the proposed molecules, although these interactions were not explicitly enforced by the reward function.

Molecules from iMiner interaction based design to target Mpro His163/Glu166. (a) Binding modes of the generated molecules show a rich polar interaction profile against specified residues. (b) Surface rendering of the generated molecules in the Mpro canonical binding pocket. (c) Twelve representative iMiner molecules with highlighted hydrogen bond donor/acceptor groups that form interaction with His163 (pink) and Glu166 (green). Also see Table S7.

## Section: Results › Binding Stability Analysis

As the final step of the workflow following consensus scoring, we perform subsequent long MD simulations to measure the stability of the surviving molecules. The effectiveness of using MD to validate binding through experiment has also been demonstrated before.65 To illustrate this stability test, we analyzed the de novo generation design set, which consisted of 12 down-selected molecules from a more stringent newVina and newIGN rescoring threshold of the top 1.5% in each category. For each molecule, we start with 50 ns MD simulations, from which we found that 7 molecules had robust binding stability as defined by an average RMSD smaller than 4 Å and preserving more than 1 hydrogen bond between the ligand and protein residues. To validate the MD results for these 7 molecules more rigorously, the simulation was then prolonged to 1 μs based on previous studies of Mpro.57 In Figure 7, we show the best out of 3 de novo generated molecules that retained good binding within the active site. Further ligand trajectory-based analyses of other molecules proposed by all four protocols are shown in Figures S3 and S4. For comparison, we also performed 1 μs simulation for two known binders (PDB code: 7L11 and 7L13) reported by Zhang et al.38

As is evident in Figure 7 and Figures S3 and S4, the iMiner-generated molecules form very stable interactions such as hydrogen bonds, hydrophobic interactions, and pi-stacking, just as is the case for the known binders 7L11 and 7L13.38 In Figure 7 we find that both 7L13 and iMiner_24_970 form stable hydrogen bonds with Glu166, which is desirable as it is a low mutation site residue in Mpro such that these molecules may remain viable against future variants of SARS-Cov-2.66,67 The iMiner molecule also forms a long-lived pi–pi stacking interaction with His41, while the hydrogen bonding interaction with His41 is only weakly populated in 7L13. Similar conclusions are drawn when comparing the known binders against other iMiner proposed molecules. Thus, at the end of the iMiner workflow, the 3 generated molecules are certainly worth pursuing for synthesis and validation against biochemical and cellular assays.

Binding stability analysis between an iMiner-proposed molecule and a known ligand. (a) Representative 2D and 3D visualization of the crystal ligand of Mpro (PDB Code: 7L13) from Zhang et al.38 and iMiner_24_970 from the unconditional de novo design. (b) Residue-level protein–ligand interaction frequency comparison performed between both molecules.

## Section: Conclusions

In this work, we have shown that by combining real-time docking of 3D structures with state-of-the-art reinforcement learning algorithms, we can efficiently navigate through uncharted regions of chemical space while maintaining good metrics for synthetic feasibility and drug-likeness. The flexibility of the iMiner physics-ML model also allows for the creation of molecules that enforce interactions with target active site residues as well as growing molecules from fragments with options for satisfying chemical or structural restraints. As illustrated using the exemplar target, the Mpro catalytic site, the generated inhibitor molecules proposed by iMiner are optimized with respect to shape and intermolecular interactions to the target protein, but are also diverse enough when compared to other predicted Mpro inhibitor data sets, i.e., experimentally confirmed molecules extracted from LP-PDBBind,55 especially the trefoil inhibitors optimized by the Jorgensen group.38 Finally, every aspect of this work is generalizable to other protein targets and beyond the active site, for example, allosteric sites.

Overall, we believe the iMiner RL-physics algorithm and workflow tool will be of great benefit to the computational and medicinal chemistry fields at large and potentially aid traditional drug-design workflows as well. Although we have focused our current work on targeting Mpro of SARS-CoV-2, extension of this work to other protein targets relevant to other global diseases would be relatively trivial. For example, bacterial resistance to antibiotics is of preeminent concern in the medical community,68 and our iMiner workflow approach could be used to target novel bacterial biomolecules, such as bacterial ribosomes, or target resistance conferring bacterial proteins such as β-lactamase.68 Another direction pertains to molecules that are experimentally validated through a traditional HTVS approach as good binders, in which the iMiner algorithm could be utilized as an optimization or refinement step for elaborating on these existing leads or scaffolds. The potential of the method in this direction will be explored in future work.

## Section: Methods › Neural Network Architecture

The generative model employed in this study is an ASGD Weight-Dropped LSTM (AWD-LSTM),33 which is a specific variant of the Long Short-Term Memory (LSTM) recurrent neural network with shared DropConnect for weight regularization, and was trained through a non-monotonically triggered average stochastic gradient descent (NT-ASGD) algorithm.33,69 The basic LSTM cell contains two internal states, the hidden state ht and the cell state ct, and can be described through the following set of equations:

where [Wi, Wf, Wo, Wc, Ui, Uf, Uo, Uc] are the trainable parameters of the model, xt is the input to the cell at the current time step, c̃t contains the information to be added to the cell state, and it, ft, and ot represent the update gate, forget gate, and output gate, respectively, which are numbers between (0, 1) that control how much information should be updated, discarded, or retrieved from the cell state. σ denotes the sigmoid function, and ⊙ represents element-wise multiplication. The DropConnect mechanism70 was applied to the hidden-to-hidden weight matrices [Ui, Uf, Uo, Uc] by randomly zeroing out a small portion of the parameters in these weight matrices to prevent overfitting and ensured that the same positions in the hidden vectors were treated consistently throughout the forward and backward pass in regards to whether or not to be dropped.

The inputs into the RNN cells were tokens embedded as vectors of length 400, and 3 LSTM cells were stacked sequentially, that had 1152, 1152, and 400 units each. The hidden state from the last time step of the last RNN cell was then connected to a linear decoder with output size of 56 and softmax activation, representing the probabilities of the 56 possible tokens from the vocabulary. The dropout values used in the model were embedding dropout = 0.002, LSTM weight dropout = 0.02, RNN hidden state dropout = 0.015, and output dropout = 0.01. The neural network was implemented using pyTorch71 and the fastai package.72

## Section: Methods › Supervised Pretraining of the Network

The generative model was pretrained using molecules from ChEMBL24,5 and a total of 1,440,263 molecules were selected for training. All molecules were first converted to self-referencing embedded strings (SELFIES) using the selfies python package,32 and the tokens were extracted from the SELFIES with the fastai language model. We used categorical cross entropy loss:

where N represents the number of tokens in a molecule, p̂(ti|t1, t2, ..., ti–1) represents the actual probability of a specific token in the string at position i and with all previous defined tokens t1 through ti–1, and pΘ(ti|t1, t2, ..., ti–1) represents the probability predicted by the neural network with parameters Θ. The model was trained using Adam optimizer73 in batches of size 512, and we employed the “one cycle” learning rate policy74 with the maximum learning rate of 0.0005 to achieve superconvergence.75 During this pretraining stage we also used weight decay = 0.01 and the dropout multiplier of 0.2. The model was pretrained for 30 epochs.

For iMiner used to generate molecules similar to a scaffold or growing from a fragment, fine-tuning was conducted using molecules containing the target scaffold or fragment. These molecules can be curated from open source databases via a substructure search or from a set of molecules of any size defined by the users. While it is possible to directly perform RL training from the ChEMBL pretrained model with a fragment similarity reward term, the additional training ensures a consistent model performance in finding molecules with the desired substructures, as otherwise some specific fragments can be rare in the ChEMBL24 data set and the model cannot make sufficient sampling of the relevant structures in the initial few epochs of RL training. Details of the additional fine-tuning are provided in the Supporting Information.

## Section: Methods › Reinforcement Learning Procedure

Our RL training target goal is to maximize J(Θ) from formula 7 by taking steps along ∂ΘJ(Θ). The exact value for J(Θ) is intractable to evaluate but can be approximated through sampling the distribution of sT, which gives

and then

Directly taking gradients according to eq 17 corresponds to the REINFORCE algorithm.76 In this work, we further utilized the PPO algorithm,43 which estimated the gradients through a clipped reward and with an extra entropy bonus term:

where

with

denoting the ratio between the probability distribution in the current iteration and the probability distribution from the previous iteration (the iteration before last gradient update). A PPO algorithm reduces the variance in the gradient, stabilizes training runs, and encourages the model to explore a wider region of the chemical space through the introduction of an entropy bonus term.

After the pretraining finished, we copied the weights to a separate model with identical architecture and trained with reinforcement learning using PPO. Because AutoDock Vina can predict different scores and poses for the same molecules due to random initiation, docking-derived reward terms for the same molecules sampled multiple times in one batch were averaged before the target functions were calculated for training stability. In each iteration after the molecules were sampled, model weights were updated by taking gradient steps on the target function through formula 18 using an Adam optimizer. In each iteration, all collected data were used for training the model for a maximum of 10 epochs. The trainer would continue into next iteration and collect new molecules for training if the K-L divergence between the latest predicted probability and the old probability exceeded 0.03.

The model was trained with RL until the mean entropy of the predicted probability of the tokens from the RNN started to decrease drastically. The training details including batch size, learning rate, hyperparameters α and ϵ, and the ratio between the reward terms λ for the 4 tasks are reported in Table S2.

## Section: Acknowledgments

This work was supported by National Institute of Allergy and Infectious Disease grant U19-AI171954. This research used computational resources of the National Energy Research Scientific Computing, a DOE Office of Science User Facility supported by the Office of Science of the U.S. Department of Energy under Contract No. DE-AC02-05CH11231. The DALL-E 3 AI model was used to create illustrative artwork in Figure 1 (the lower left image demonstrating filtering of molecules).

## Section: Data Availability Statement

All the code for the iMiner reinforcement learning algorithm and workflow are provided in a private GitHub repository: https://github.com/THGLab/iMiner under reasonable requests.

## Section: Supporting Information Available

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acs.jcim.4c00634.

## Section: Author Contributions

∥ J.L., O.Z., and K.S. contributed equally. J.L., O.Z., and T.H-G. conceived the scientific direction, designed the experiments, analyzed results, and wrote the manuscript. F.L.K. prepared Mpro structures for docking in AutoDock Vina. C.P. wrote the code for pretraining the network. O.Z. wrote the code for the AutoDock Vina workflow. Y.W. wrote codes for molecular dynamics simulations and subsequent analysis. D.B., X.G., and K.S. contributed ideas and suggestions to the work. R.E.A. provided drug-design guidance. All authors discussed and performed final edits to the manuscript.

## Section: Text

The authors declare the following competing financial interest(s): C.P. has equity interest in Athae Bio.

## Section: Supplementary Material

ci4c00634_si_001.pdf

## Section: Associated Data

ci4c00634_si_001.pdf

## Section: Associated Data › Supplementary Materials

ci4c00634_si_001.pdf

## Section: Associated Data › Data Availability Statement

All the code for the iMiner reinforcement learning algorithm and workflow are provided in a private GitHub repository: https://github.com/THGLab/iMiner under reasonable requests.
