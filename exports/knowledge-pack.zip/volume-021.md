# Exploring regulatory flexibility to create novel incentives to optimize drug discovery

- **Authors:** Jacqueline A Sullivan, E Richard Gold
- **Issuer:** Frontiers in medicine
- **Type:** Scientific article
- **Published:** 2024-05-13
- **Language:** en
- **DOI:** 10.3389/fmed.2024.1379966
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38808140/
- **Licence:** CC-BY

## Page 1 (Section: Exploring regulatory flexibility to create novel incentives to optimize drug discovery)

Frontiers in Medicine
01
frontiersin.org
Exploring regulatory flexibility to 
create novel incentives to 
optimize drug discovery
Jacqueline A. Sullivan 1* and E. Richard Gold 2*
1 Department of Philosophy, Rotman Institute of Philosophy and Western Institute for Neuroscience, 
Western University, London, ON, Canada, 2 Faculty of Law and Faculty of Medicine and Health 
Sciences, McGill University, Montreal, QC, Canada
Efforts by governments, firms, and patients to deliver pioneering drugs for critical 
health needs face a challenge of diminishing efficiency in developing those 
medicines. While multi-sectoral collaborations involving firms, researchers, 
patients, and policymakers are widely recognized as crucial for countering this 
decline, existing incentives to engage in drug development predominantly target 
drug manufacturers and thereby do little to stimulate collaborative innovation. 
In this mini review, we consider the unexplored potential within pharmaceutical 
regulations to create novel incentives to encourage a diverse set of actors from 
the public and private spheres to engage in the kind of collaborative knowledge 
exchange requisite for fostering enhanced innovation in early drug development.
KEYWORDS
collaboration, drug development, incentives, open science, patents, regulatory 
exclusivity
Introduction
While governments (1), firms (2), and patients (3) seek to deliver new medicines for 
pressing health needs—particularly first-in-indication drugs or first effective drugs for diseases 
for which there is no good therapy—they face a problem of declining efficiency in developing 
those medicines (4). The result is not only decreasing investigation into higher risk research 
but also lack of affordability and access (5). For example, firms are decreasing investments in 
neurodegenerative diseases despite estimates that dementia will affect 100 million people by 
2050 (6) and not investing in antimicrobials despite predictions that 10 million people will die 
annually from lack of these drugs by 2050 (7). While there are between 263 and 446 million 
people suffering from rare diseases, 95% of these diseases lack even one treatment (8). This is 
despite the fact that over half of new drug approvals in both the United States and Europe are 
for orphan diseases, partially because firms are so adapt at strategic use of the orphan drug 
designation to fund large, even blockbuster, drugs (9–11) and because the largest proportion 
of orphan drugs are in oncology even though 80% of rare diseases are genetic in origin (12).
Partially in response to this productivity decline, firms, researchers, patients, and policy 
makers have moved toward a model of multi-sector and interdisciplinary collaborations to 
advance drug discovery (13–15). Such collaborations have been referred to as “Open Science 
Partnerships” (16), and they have been described as having different archetypes (17). For these 
collaborations to bear fruit, however, “there need to be the appropriate incentives in place, the 
engagement of many different stakeholders including patients and regulators but most of all 
people with the right expertise and enthusiasm to fully realize the value of new partnering 
models for human health” (14). While incentives exist in many settings—academic promotion, 
OPEN ACCESS
EDITED BY
Cristiana Sessa, 
Oncology Institute of Southern Switzerland 
(IOSI), Switzerland
REVIEWED BY
Segundo Mariz, 
European Medicines Agency, Netherlands
*CORRESPONDENCE
Jacqueline A. Sullivan 
 jsulli29@uwo.ca
E. Richard Gold 
 richard.gold2@mcgill.ca
RECEIVED 31 January 2024
ACCEPTED 17 April 2024
PUBLISHED 13 May 2024
CITATION
Sullivan JA and Gold ER (2024) Exploring 
regulatory flexibility to create novel incentives 
to optimize drug discovery.
Front. Med. 11:1379966.
doi: 10.3389/fmed.2024.1379966
COPYRIGHT
© 2024 Sullivan and Gold. This is an open-
access article distributed under the terms of 
the Creative Commons Attribution License 
(CC BY). The use, distribution or reproduction 
in other forums is permitted, provided the 
original author(s) and the copyright owner(s) 
are credited and that the original publication 
in this journal is cited, in accordance with 
accepted academic practice. No use, 
distribution or reproduction is permitted 
which does not comply with these terms.
TYPE  Mini Review
PUBLISHED  13 May 2024
DOI  10.3389/fmed.2024.1379966

## Page 2 (Section: Drug development)

Sullivan and Gold
10.3389/fmed.2024.1379966
Frontiers in Medicine
02
frontiersin.org
health care outcomes, advanced market commitments—drug 
regulations provide an underinvestigated opportunity to create them 
(18, 19). In this mini review, we explore this topic.
Collaborations between firms, university researchers, patients, 
philanthropies, and governments accelerate drug development by 
relying on the differential expertise of these actors, increasing the 
sharing of knowledge between them, building trust in science and its 
outcomes, and avoiding duplication (5, 16, 20–24). Because of the 
importance of health and safety in making drugs available to patients, 
the relationship between these actors is mediated, in part, through 
drug regulation and the agencies—such as the Food and Drug 
Administration (FDA) and the European Medicines Agency—that 
enforce them. As Eisenberg (18) notes, however, these regulations 
provide both incentives and disincentives to develop drugs: “[T] 
he  FDA’s core function of reviewing data from clinical trials to 
determine the safety and efficacy of drugs prior to market approval 
may be understood as a means of promoting costly investments in a 
particular form of R&D rather than simply as a means of protecting 
patients from untoward risks of harm.” Acknowledging the role of 
collaborations in contemporary pharmaceutical research, here 
we  examine how drug regulations, and the agencies that are 
responsible for them, create or could create incentives and 
disincentives for the various actors engaged in drug regulation to 
render them more efficient.
We begin, in Section 1, with a brief overview of the drug 
development process before moving on, in Section 2, to consider 
current incentives for actors to invest time and money in drug 
development. We note that these incentives are geared primarily at the 
private sector and are not well designed to encourage multi-sectoral 
participation in collaborations. We end, in Section 3, by considering 
the question of whether there is flexibility in the current system to 
introduce incentives for the plurality of actors who are actively 
involved in early drug development to work collaboratively to 
promote innovation.
Drug development
Drug development is usually described as a linear process with 
discrete scientific stages corresponding to safety and efficacy 
benchmarks set by regulations and the administrative bodies that 
apply them, such as the FDA [Figure 1; e.g., (14)]. After identifying 
potential compounds that could serve as drug candidates, researchers 
determine, in the pre-clinical stage, the toxicity and efficacy of these 
compounds to treat a specific disease in vitro (e.g., cell cultures, 
organoids) and in vivo (e.g., animal models of disease) in industrial 
and/or academic settings. If a drug passes these preclinical tests, the 
drug’s sponsor submits an Investigational New Drug Application 
(INDA) to the FDA to move to the next stage of assessing safety and 
efficacy in human subjects. Following the FDA’s approval of the INDA, 
the sponsor proceeds with clinical trials of the drug in small groups of 
human volunteers (25). These Phase I trials (20–80 subjects) provide 
a preliminary understanding of a drug’s safety, dosage, and identify 
potential side effects. If the drug meets Phase I safety benchmarks, the 
sponsor seeks approval to enter into larger Phase II clinical trials 
(100–300 participants) to more fully evaluate the drug’s safety and 
efficacy. If the drug passes that phase, the sponsor proceeds to Phase 
III clinical trials, which evaluate efficacy and side effects compared to 
currently available treatments for the disease. These studies involve 
many participants [1,000–3,000; with the exception of drugs for rare 
diseases, which involve smaller participant pools and sometimes 
combine Phases II&III clinical trials (26–28)]. If a drug passes Phase 
III, the drug manufacturer files a New Drug Application (NDA) with 
the FDA to seek approval to market the drug to patients. The FDA 
may require additional studies of the drug before approval. Once 
approved, the drug sponsor may conduct Phase IV clinical trials 
involving post-market monitoring of the drug,1 although up to a fifth 
of these trials are for pure marketing purposes (29).
The cost of meeting regulatory benchmarks at each stage of drug 
development increases as sponsors must enroll more subjects and 
more representatives from a pharmaceutical company (including 
administrators, investigators, clinicians, etc.) become involved. Risks 
of failure also increase at each stage, and failure may occur after a firm 
already has made a major financial investment in a drug. The only 
exceptions to these norms are cases of rare diseases that use much 
smaller patient cohorts, but cost savings from smaller trials have not 
incentivized large firms to invest in drug development for rare 
diseases. Given the high costs of drug development and an uncertain 
reward in the market, it is a high-risk endeavor.
The narrow scope of current 
incentives
Intellectual property protection in the form of patents granted by 
national or regional patent offices, such as the United States Patent and 
Trademark Office or the European Patent Office, have served as the 
central incentive for private sector investment in drug development 
(30). These patents last 20 years from the date of filing and, depending 
on jurisdiction, up to five additional years to compensate for 
1  https://www.nih.gov/health-information/nih-clinical-research-trials
FIGURE 1
The drug development process and regulatory framework.

## Page 3 (Section: Drug development)

Sullivan and Gold
10.3389/fmed.2024.1379966
Frontiers in Medicine
03
frontiersin.org
regulatory delays. This reliance on patents has shaped the direction of 
pharmaceutical innovation toward lower-risk research, such as second 
or third in class (“me-too”) drugs (31), and away from diseases where 
the biology is complex, such as antibiotics (32). From the perspective 
of large firms, the financial benefits resulting from investing in 
breakthrough science, especially in small or uncertain markets, is in 
many cases insufficient to justify the costs of investment.
Patents are not, of course, the only inducement for drug 
companies to take these risks. A number of other incentives for drug 
development exist comprising both push and pull mechanisms. Push 
incentives reduce research and development costs to drug sponsors. 
These include direct subsidies to firms and research and development 
tax credits, and indirect subsidies, such as investments in infrastructure 
and academic research grants. Pull incentives, in contrast, increase 
market reward. Beyond patents, these include data exclusivity, other 
niche exclusivities, and priority reviews. We illustrate these incentives 
by using the United States as an example, but similar incentives exist 
in other jurisdictions, such as the European Union.
The Orphan Drug Designation (ODD) is an example of a 
combination of push and pull incentives. It applies to drugs to treat 
diseases—orphan drugs (OD)—that affect fewer than 200,000 people 
in the United States (and a roughly pro rata number of people in other 
jurisdictions) by providing drug manufacturers with push incentives 
such as tax credits for certain research expenses, exemption from 
certain FDA fees (e.g., waivers of marketing applications fees), and 
research grants to subsidize clinical research costs. The ODD also 
includes a pull incentive, namely a 7-year market exclusivity period 
during which the FDA cannot approve another application for that 
drug for that indication (with some exceptions).
The Accelerated or Critical Path Initiative saves research and 
development costs and time by allowing firms to use biomarkers as 
surrogate endpoints for drugs for rare diseases [yet this is not without 
problems; (33)]. The Research and Experimentation Tax Credit, 
another push incentive, offers a large subsidy on incremental 
expenditures for experimental operations relative to a firm’s baseline 
level of expenditure (non-specific market).
Three Priority Review Voucher Programs (Rare Pediatric 
Diseases, Tropical Diseases, and Material Threat Medical 
Countermeasure) provide firms that develop qualifying drugs with a 
voucher that may be used to expedite the review of another drug, 
presumably one with a larger market, that is in the firm’s pipeline. 
Firms can either use the voucher themselves or to sell it to another 
firm, thus monetizing the vouchers. The latter option would 
be particularly attractive to small firms that may not have another 
drug in the pipeline. The Pediatric Exclusivity Provision (1997) allows 
drug companies to have 6 additional months of exclusivity for drugs 
that are tested in children. The Generating Antibiotic Incentives Now 
(GAIN) Act of 2012 allows drug manufacturers five additional years 
of exclusivity for certain antibiotics. Additional pull incentives include 
Priority Review, Fast-Track Designation, Accelerated Approval and 
Breakthrough Therapy Designation Pathways.
These push and pull incentives have been insufficient, on their 
own, to stimulate the level of investments needed to develop first-in-
indication and first effective for an indication drugs and to respond to 
unmet health needs. For example, while the ODD has been successful 
for rare diseases within its purview, some claim many ODs developed 
are not affordable (34) and that the incentive has served to decrease 
interest in developing drugs for other diseases equally worthy of 
consideration. A performance audit of the Priority Review Voucher 
Program suggests that although drug sponsors, researchers, and 
stakeholders value it, the program tends to serve as incentive for 
developing me-too drugs rather than novel treatments (35).
Failure of current incentives to stimulate sufficient levels of first-
in-indication and first effective for an indication drug development 
calls for an examination of alternative incentive mechanisms. These 
are not in short supply. One suggestion is, for example, to offer 
pharmaceutical companies tax credits to a percentage of research and 
development costs or to provide them with federal subsidies to engage 
in research and development on novel drugs (35). Other proposals 
seek to encourage firms to run clinical trials with individuals that are 
more representative of the population’s diversity. Some suggest, for 
example, that governments develop financial incentives (e.g., tax 
credits) for manufacturers to increase diversity in clinical trials in line 
with the Food & Drug Omnibus Reform Act of 2022 [FDORA; e.g., 
(36)]. An alternative suggestion for boosting diversity in clinical trials 
is for the government to offer sponsors that have diversity plans in 
place Fast-Track Designation, Priority Review, Priority Review 
Vouchers, or Pediatric Exclusivity (37).
The problem with all of these incentives is their exclusive focus on 
the financial interests of pharmaceutical firms, based on the 
assumption that drug sponsors alone hold the keys to the types of 
health innovation that patients and health systems desire. This narrow 
focus is unlikely to solve the problem of increasing investments into 
first-in-indication drugs or increasing the productivity of drug 
innovation. After all, firms will naturally orient themselves to 
investments in areas offering higher payoffs and lower risks. To gain 
real efficiencies, however, the drug discovery process needs to focus 
on how research is done and by whom.
To address declining efficiency, incentives need to be created that 
ease knowledge exchange, reduce barriers to knowledge production, 
and encourage contributions by more actors. Beyond pharmaceutical 
firms, there are many other actors: non-pharmaceutical firms (e.g., 
involved with equipment or artificial intelligence), philanthropies 
(including large philanthropies such as the Bill and Melinda Gates 
Foundation, the Chan Zuckerberg Initiatives, the Aligning Science 
Against Parkinson’s Initiative, and the Michael J. Fox Foundation), 
venture capital, angel investors, patient organizations (e.g., disease-
specific 
patient 
organizations), 
community 
organizations 
(representing, for example, ethnic or racial minorities), academic 
researchers, government researchers, intergovernmental organizations 
(e.g., the World Health Organization, the Organization for Economic 
Co-operation and Development), and more. These actors bring 
knowledge, tools, genetic material, probes, molecules, assays, 
processes, coordination, financing, expertise, and commitment that, 
when appropriately managed, have the potential to render the drug 
discovery process more efficient (16).
To achieve productivity gains, we need to focus on rendering the 
flow of knowledge, data, and materials between actors more efficient. 
Think, for example, of moving data and materials from an academic 
lab to an industry partner in the so-called “valley of death” between 
“finding a promising new agent and demonstrating its safety and 
efficacy in humans” (38). Financial incentives for pharmaceutical 
firms may encourage them to seek out such transfers but we also need 
to find incentives for researchers and research institutions to share. 
The prospect of money at some future point may help, but researchers 
generally have more immediate concerns such as maintaining

## Page 4 (Section: Actors, regulatory flexibility and the potential for novel incentives)

Sullivan and Gold
10.3389/fmed.2024.1379966
Frontiers in Medicine
04
frontiersin.org
credibility, attracting and retaining junior staff, obtaining grants and 
awards, and reputation. Universities care about meeting short term 
metrics, pleasing donors and funders, rising in university rankings, 
and pleasing government sponsors. If we focus narrowly on economic 
incentives, a set of mismatched incentives is the likely result.
Beyond the single lab and isolated university lie other coordination 
problems. Researchers with different expertise work in silos, 
experimental approaches are not standardized, results are too often 
not reproducible, and incentives work against collaboration (e.g., 
promotion criteria, authorship, etc.) (39). Universities compete with 
each other for researchers, students, funding, and increasing the 
number of patents (regardless of value) with little care for actually 
maximizing innovation (40) or social return.
If we were to develop an understanding of the goals of the various 
actors who contribute in a significant manner to drug development, 
we could identify novel or modified incentives that we can introduce 
into the drug discovery system. While these incentives may be found 
in a variety of settings and through diverse mechanisms, here we focus 
on the drug regulatory system. As indicated above, this system already 
incorporates numerous targeted incentives—priority, data exclusivity, 
vouchers, etc.—yet has been underexplored as a source of incentives 
for actors other than sponsors.
Actors, regulatory flexibility and the 
potential for novel incentives
Given the variety of actors involved, the incentives net must 
be  cast wide. To identify potential incentives, one needs to first 
develop an understanding of the preferences of the different actors and 
the kinds of incentives to which they may be responsive based on a 
literature review. A variety of qualitative approaches (e.g., ethnography, 
surveys, semi-structured interviews) can be used to probe actor beliefs 
and values: from the patients who donate tissue, DNA, and blood 
samples, to academic research scientists involved in preclinical 
research, to representatives of industry seeking to develop and market 
a new product. An economist looking at the results can build a utility 
function for each action, lawyers can construct an effective governance 
regime to address these understandings, and entrepreneurs can 
develop business plans. Indeed, we have previously undertaken some 
of this research (41).
Consider, for example, the views of academic scientists involved 
in drug development. These scientists include students, early career 
researchers (e.g., postdoctoral research fellows and assistant 
professors), mid-career and senior researchers.
Students need funding to complete their studies and they need 
experience. Given the scarcity of academic positions, most will work 
in the private sector and so would value previous exposure to firms.
Early career scientists who have secured tenure-track 
professorships seek start-up funding for their laboratories to buy 
equipment and materials, to recruit qualified personnel including 
postdoctoral researchers, students, and research and support staff. 
Progression in the profession (e.g., securing tenure), requires 
continued financial support through successful grant applications to 
fund their labs and programs of research, produce publications, travel 
to present research at academic conferences, and building their 
research networks and reputations.
Senior scientists, in addition to maintaining the same level of 
research they have historically, seek to maintain and expand the store 
of data and tools that underlies their research. Because they also care 
about legacy, they further aim to assist junior researchers to use those 
data and tools and build on them. They want their students and 
juniors to be successful by publishing in respected journals, obtaining 
research funds, and networking with those inside and outside 
academia to facilitate job progression and reputation.
For all scientists, the quality of their research matters. In the wake 
of the so-called “replication crisis in science,” funders and the research 
community have worked to make the research process more open and 
transparent to facilitate replication experiments and to root out error 
and fraud. This has an impact on the kinds of financial resources that 
researchers require to uphold standards of openness and transparency. 
Given the complexity of the diseases for which novel drugs are sought, 
not only is replication important, but so is collaboration across 
researchers [e.g., (42)]. For example, researchers conducting in vitro 
studies need to share with those conducting in vivo studies and at 
multiple different sites. To accomplish this, they must standardize and 
document techniques, ensuring that the collaboration produces 
replicable data and high-quality data sets. This leads, in turn, to having 
to cover expenses for technical personal to set-up and manage 
databases and data repositories for the (often) high costs of publishing 
in open access journals. Funding for sustainability of these databases 
and continuity of governance are also desirable, as is a credit system 
in science that encourages collaboration in ways that allow individuals 
to contribute to the science machine while getting credit for their 
individual contributions.
This openness and transparency runs straight into, however, the 
interests of pharmaceutical companies in keeping data about 
promising compounds private through patents and trade secrets. It is 
thus an interesting question in the current climate of drug 
development whether partnerships between private companies and 
public organizations can be open and what the conditions of that 
openness must be to spur all actors to coordinate and share. There are 
some examples of successful efforts; it would be  worthwhile to 
understand what features allowed them to be successful and, where 
they failed, to understand why. It is a waste of both private and public 
resources to invest money in drug discovery and preclinical research 
if that investment never leaves the bench.
With this broader perspective of actor needs, we return to the 
question of whether the drug regulatory system can be made to offer 
incentives not only to industry but to all actors to efficiently 
collaborate on drug development. We can consider responding, for 
example, to researcher needs for access to high-quality data by 
increasing disclosure requirements during clinical studies and, while 
preventing competitors from using the same data for regulatory 
purposes, require them to disclose more information about drugs 
going through the regulatory system. Regulations could also 
encourage firms to enter into partnerships with a broad range of 
actors without compromising disclosure by extending the term of 
data protection provided that the sponsor discloses all data and 
refrains from imposing patent restrictions on subsequent uses of that 
data to develop other drugs.
These are just examples of the type of incentives that we can build 
into the regulatory system beyond vouchers, priorities, and 
exclusivities aimed at sponsoring firms. This system is a good place to 
start without forgetting that incentives exist elsewhere, such as those

## Page 5 (Section: Discussion)

Sullivan and Gold
10.3389/fmed.2024.1379966
Frontiers in Medicine
05
frontiersin.org
managed by granting agencies, university promotion and tenure 
committee, and philanthropies.
Discussion
Addressing declining efficiencies in drug discovery requires 
incentives aimed at more than one participant: the pharmaceutical 
firm. We can render the process more productive by eliminating 
duplication (by sharing data and outcomes), reducing barriers to 
access expertise (by facilitating exchange between academics and 
industry), by coordinating efforts, and by seeking monetary and 
in-kind investments by a broader set of actors. Experiments with such 
efforts are underway (43). The Structural Genomics Consortium, the 
Open Discovery Innovation Network, the Montreal Neurological 
Hospital-Institute, and the Translational Research Initiative to De-Risk 
Neuro-Therapeutics (TRIDENT) all seek to advance drug discovery 
by bringing public and private actors together in which data and 
outputs are shared and not patented, and in which patients are the 
clear focus.
Lest one think that it is not possible to align so many actors at 
once, consider the great advance in open access publications and data 
over the last two decades. In that time, through the concerted efforts 
of philanthropies, granting councils, and researchers, the scientific 
community has moved from a system of restricted access to scientific 
publications to a strong norm of open access and data sharing (44). 
The same can be done for drug discovery incentives.
Author contributions
JS: Writing – original draft, Writing – review & editing. EG: 
Writing – original draft, Writing – review & editing.
Funding
The author(s) declare financial support was received for the 
research, authorship, and/or publication of this article. We gratefully 
acknowledge the financial support of the TRIDENT (TRanslational 
Initiative to DE-risk NeuroTherapeutics) project funded by the New 
Frontiers in Research Fund, application NFRFT-2022-00051, and of 
the CLEO (The Canadian Network for Learning Healthcare Systems 
and Cost-Effective ‘Omics Innovation) project, funded by Genome 
British Columbia, Genome Canada [G05CHS], and Genome Quebec.
Acknowledgments
The authors would like to thank audiences at both the Canadian 
Network for Learning Healthcare Systems and Cost-Effective ‘Omics 
Innovation (CLEO) 2nd Workshop for Learning Healthcare Systems 
and the working meeting of the Initiative for Translational 
Neuroscience & Translational Initiative to DeRisk NeuroTherapeutics 
(TRIDENT) for providing helpful feedback on an earlier version of 
this paper. We gratefully acknowledge the financial support of the 
TRIDENT (TRanslational Initiative to DE-risk NeuroTherapeutics) 
project funded by the New Frontiers in Research Fund, application 
NFRFT-2022-00051, and of the CLEO (The Canadian Network for 
Learning Healthcare Systems and Cost-Effective ‘Omics Innovation) 
project, funded by Genome British Columbia, Genome Canada 
[G05CHS], and Genome Quebec.
Conflict of interest
The authors declare that the research was conducted in the 
absence of any commercial or financial relationships that could 
be construed as a potential conflict of interest.
Publisher’s note
All claims expressed in this article are solely those of the authors 
and do not necessarily represent those of their affiliated organizations, 
or those of the publisher, the editors and the reviewers. Any product 
that may be evaluated in this article, or claim that may be made by its 
manufacturer, is not guaranteed or endorsed by the publisher.
References
	1.	OECD. (2024). Executive summary. Available at: https://www.oecd-ilibrary.org/
sites/3c8385d0-en/index.html?itemId=/content/publication/3c8385d0-en
	2.	Gautam A, Pan X. The changing model of big pharma: impact of key trends. Drug 
Discov Today. (2016) 21:379–84. doi: 10.1016/j.drudis.2015.10.002
	3.	Massachusetts General Hospital. (2015). How patient's unmet needs impact their 
health and health care. Science Daily 9. Available at: www.sciencedaily.com/
releases/2015/12/151209183515.htm.
	4.	Scannell JW, Blanckley A, Boldon H, Warrington B. Diagnosing the decline in 
pharmaceutical R & D efficiency. Nat Rev Drug Discov. (2012) 11:191–200. doi: 10.1038/
nrd3681
	5.	Gold ER, Edwards AM. Overcoming market failures in pandemic drug discovery 
through Open Science: a Canadian solution. Front Drug Discovery. (2022) 2:1–5. doi: 
10.3389/fddsv.2022.898654
	6.	Feigin VL, Nichols E, Alam T, Bannick MS, Beghi E, Blake N, et al. Global, regional, 
and national burden of neurological disorders, 1990–2016: a systematic analysis for the 
global burden of disease study 2016. Lancet Neurol. (2019) 18:459–80. doi: 10.1016/
S1474-4422(18)30499-X
	7.	Murray CJ, Ikuta KS, Sharara F, Swetschinski L, Aguilar GR, Gray A, et al. Global 
burden of bacterial antimicrobial resistance in 2019: a systematic analysis. Lancet. (2022) 
399:629–55. doi: 10.1016/S0140-6736(21)02724-0
	8.	Aartsma-Rus A, Dooms M, Le Cam Y. Orphan medicine incentives: how to address 
the unmet needs of rare disease patients by optimizing the European orphan medicinal 
product landscape guiding principles and policy proposals by the European expert 
group for orphan drug incentives (OD expert group). Front Pharmacol. (2021) 12:3666. 
doi: 10.3389/fphar.2021.744532
	9.	Daniel MG, Pawlik TM, Fader AN, Esnaola NF, Makary MA. The orphan drug act: 
restoring the mission to rare diseases. Am J Clin Oncol. (2016) 39:210–3. doi: 10.1097/
COC.0000000000000251
	10.	Rollet P, Lemoine A, Dunoyer M. Sustainable rare diseases business and drug 
access: no time for misconceptions. Orphanet J Rare Dis. (2013) 8:109–9. doi: 
10.1186/1750-1172-8-109
	11.	Wellman-Labadie O, Zhou Y. The US orphan drug act: rare disease research 
stimulator or commercial opportunity? Health Policy. (2010) 95:216–28. doi: 10.1016/j.
healthpol.2009.12.001
	12.	Melnikova I. Rare diseases and orphan drugs. Nat Rev Drug Discov. (2012) 
11:267–8. doi: 10.1038/nrd3654
	13.	Cheng F, Ma Y, Uzzi B, Loscalzo J. Importance of scientific collaboration in 
contemporary drug discovery and development: a detailed network analysis. BMC Biol. 
(2020) 18:138. doi: 10.1186/s12915-020-00868-3

## Page 6 (Section: Discussion)

Sullivan and Gold
10.3389/fmed.2024.1379966
Frontiers in Medicine
06
frontiersin.org
	14.	Hunter J. Challenges for pharmaceutical industry: new partnerships for sustainable 
human health. Philos Trans R Soc A Math Phys Eng Sci. (2011) 369:1817–25. doi: 
10.1098/rsta.2010.0377
	15.	Kiriiri GK, Njogu PM, Mwangi AN. Exploring different approaches to improve 
the success of drug discovery and development projects: a review. Future J 
Pharmaceutical Sci. (2020) 6:1–12. doi: 10.1186/s43094-020-00047-9
	16.	Gold ER. The fall of the innovation empire and its possible rise through open 
science. Res Policy. (2021) 50:104226. doi: 10.1016/j.respol.2021.104226
	17.	Norn M.T., Priego L.P., Ramos-Vielba I., Ryan T.K. (2023) Four archetypes of Open 
Science partnerships connecting aims and means in open research collaborations.
	18.	Eisenberg RS. The role of the FDA in innovation policy. Mich Telecomm & Tech L 
Rev. (2006) 13:345–88.
	19.	Mendoza RL. Incentives and disincentives to drug innovation: evidence from 
recent literature. J Med Econ. (2019) 22:713–21. doi: 10.1080/13696998.2019.1613240
	20.	European Commission, Directorate-General for Research and Innovation. Study 
on factors impeding the productivity of research and the prospects for open science 
policies to improve the ability of the research and innovation system – Final report, 
Publications Office of the European Union. (2022). Available at: https://data.europa.eu/
doi/10.2777/58887
	21.	Garden H. Collaborative mechanisms for sustainable health innovation: The case of 
vaccines and antibiotics. OECD science, technology and industry policy papers, no. 145. 
Paris: OECD Publishing (2023).
	22.	OECD. Collaborative mechanisms for intellectual property Management in the Life 
Sciences. Paris: OECD (2011).
	23.	Widdus R. Public–private partnerships for health: their main targets, 
their diversity, and their future directions. Bull World Health Organ. (2001) 79:713–20.
	24.	Winickoff D, Kreiling L, Borowiecki M, Garden H, Philp J. Collaborative platforms 
for emerging technology: Creating convergence spaces. OECD science, technology and 
industry policy papers, no. 109. Paris: OECD publishing (2021).
	25.	Holbein MB. Understanding FDA regulatory requirements for investigational new 
drug applications for sponsor-investigators. J Investig Med. (2009) 57:688–94. doi: 
10.2310/JIM.0b013e3181afdb26
	26.	Abrahamyan L, Feldman BM, Tomlinson G, Faughnan ME, Johnson SR, Diamond 
IR, et al. Alternative designs for clinical trials in rare diseases. Am J Med Genet C: Semin 
Med Genet. (2016) 172:313–31. doi: 10.1002/ajmg.c.31533
	27.	Bell SA, Tudur Smith C. A comparison of interventional clinical trials in rare 
versus non-rare diseases: an analysis of clinical Trials.gov. Orphanet J Rare Dis. (2014) 
9:170. doi: 10.1186/s13023-014-0170-0
	28.	Kempf L, Goldsmith JC, Temple R. Challenges of developing and conducting 
clinical trials in rare disorders. Am J Med Genet A. (2018) 176:773–83. doi: 10.1002/
ajmg.a.38413
	29.	Barbour V, Burch D, Godlee F, Heneghan C, Lehman R, Perera R, et al. 
Characterisation of trials where marketing purposes have been influential in study 
design: a descriptive study. Trials. (2016) 17:31. doi: 10.1186/s13063-015-1107-1
	30.	Grabowski H. Patents, innovation and access to new pharmaceuticals. J Int Econ 
Law. (2002) 5:849–60. doi: 10.1093/jiel/5.4.849
	31.	Feldman R. May your drug price be evergreen. J Law Biosci. (2018) 5:590–647. doi: 
10.1093/jlb/lsy022
	32.	Plackett B. Why big pharma has abandoned antibiotics. Nature. (2020) 586:S50–2. 
doi: 10.1038/d41586-020-02884-3
	33.	Kimmelman J. Ethics at phase 0: clarifying the issues. J Law Med Ethics. (2007) 
35:727–33. doi: 10.1111/j.1748-720X.2007.00194.x
	34.	Mikami K. Orphans in the market: the history of orphan drug policy. Soc Hist Med. 
(2019) 32:609–30. doi: 10.1093/shm/hkx098
	35.	US Government Accountability Office. (2020). Report to congressional 
committees: drug development, FDA’s Priority Review Voucher Programs. Available at: 
https://www.gao.gov/assets/gao-20-251.pdf.
	36.	Hwang TJ, Brawley OW. New federal incentives for diversity in clinical trials. N 
Engl J Med. (2022) 387:1347–9. doi: 10.1056/NEJMp2209043
	37.	Schick ST, Axelson K. Considering modifications to existing FDA regulatory 
incentives to achieve greater racial and ethnic diversity in pivotal clinical trials for drug 
approvals. Food & Drug LJ. (2022) 77:246.
	38.	Coller BS, Califf RM. Traversing the valley of death: a guide to assessing prospects for 
translational success. Sci Transl Med. (2009) 1:10cm9. doi: 10.1126/scitranslmed.3000265
	39.	Sullivan JA. Coordinated pluralism as a means to facilitate integrative taxonomies 
of cognition. Philos Explor. (2017) 20:129–45. doi: 10.1080/13869795.2017.1312497
	40.	Gold E.R., (2019). Should universities get out of the patent business?. Centre for 
International Governance Innovation (blog). Available at: https://www.cigionline.org/
articles/should-universities-get-out-patent-business/
	41.	Ali-Khan SE, Harris LW, Gold ER. Motivating participation in open science by 
examining researcher incentives. eLife. (2017) 6:e29319. doi: 10.7554/eLife.29319.001
	42.	Sullivan JA, Dumont JR, Memar S, Skirzewski M, Wan J, Mofrad MH. New 
frontiers in translational research: touchscreens, open science, and the mouse 
translational research accelerator platform. Genes Brain Behav. (2021) 20:e12705. doi: 
10.1111/gbb.12705
	43.	Williams H., Niehaus P. (2022). “Developing the science of science”. Available at: 
https://worksinprogress.co/issue/developing-the-science-of-science/.
	44.	Greussing E, Kuballa S, Taddicken M, Schulze M, Mielke C, Haux R. Drivers 
and obstacles of open access publishing. A qualitative investigation of individual 
and institutional factors. Front Commun. (2020) 5:587465. doi: 10.3389/
fcomm.2020.587465


---

# FDA regulatory considerations for oncology drug development

- **Authors:** Hanlim Moon, Dae Young Zang, Min-Hee Ryu, YeonSook Seo, Bitna Oh, Sunjin Hwang, Lee Farrand
- **Issuer:** Pharmacology research & perspectives
- **Type:** Scientific article
- **Published:** 2024-08-01
- **Language:** en
- **DOI:** 10.1002/prp2.1254
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39075638/
- **Licence:** CC-BY-NC-ND

## Section: Text

Over the past 20 years, more than 150 oncology drugs have been approved by the US Food and Drug Administration (FDA) including 42 novel therapeutics in 2021–2023 (Table 1). In this highly competitive environment, a proper understanding of the addressable challenges is essential for successful drug development. A clinical development program may benefit from being granted Accelerated Approval (AA) status if the caveats and obligations are properly understood. For US aspirations, it is important to consider early efforts toward dose optimization and a sufficient representation of ethnic diversity in patient populations. 1 , 2

A major challenge for oncology drug developers is the number of new drugs that reach approval every year. According to the annual report from the Oncology Center of Excellence (OCE), 66 new drugs or indications were approved in 2021, followed by 56 in 2022, 3 , 4 an average rate of more than one new approval per week. Recently, Demirci et al. 5 evaluated the clinical development time for 76 new anticancer drugs, using the earliest clinical trial start date to the date of submission of the marketing authorization application (MAA) in the United States. The study revealed how utilizing combinations of expedited regulatory approval programs is associated with shorter clinical development times, potentially benefiting the pharmaceutical industry by allowing earlier drug availability.

Clinical development for the early immuno‐oncology drug ipilimumab spanned a total of 127.4 months. This length of time stands in stark contrast to the more recently approved pembrolizumab, which benefited from previous lessons learned and close interaction with the FDA, achieving approval in 46 months from First‐Patient‐In. Five PD‐1/‐L1 inhibitors, pembrolizumab, nivolumab, avelumab, atezolizumab, and durvalumab have since received breakthrough designations in various cancer types, and subsequent Accelerated Approval (AA). 6 Drug developers face ever‐higher bars to show superior clinical efficacy against increasingly better comparators. Moreover, competition among comparators is not limited to the same class of drug but can extend beyond mechanisms of action.

With every new drug approval, the standard‐of‐care (SOC) changes accordingly. Drug developers must therefore seek to understand the unmet needs of today, as well as consider how upcoming approvals will impact the SOC in the future. The history of oncology clinical development has often shown a cyclical pattern, with the highest unmet needs moving from later lines of cancer treatment to earlier lines, before re‐emerging in later lines with the appearance of resistance to newly approved drugs. To accelerate the impact of new therapies, the FDA initiative FRONTRUNNER encourages sponsors to prioritize the development and approval of new cancer drugs in an earlier clinical setting rather than the usual approach of starting development in later lines of therapy. 7 Despite this initiative, robust clinical development strategies may benefit from flexibility and a thorough real‐time analysis of the competitive landscape, considering the priority indication, emerging targets, and how impending approvals from different drug classes may impact the SOC.

The FDA has created four mechanisms to expedite the development of new drugs: Fast Track, Breakthrough Therapy, AA, and Priority Review. For a deeper discussion, this paper will mainly focus on the AA program. The AA program is designed to enable earlier patient access to new therapies in areas of high unmet need, with relatively lower levels of evidence required. This can substantially offset the financial risk to drug developers, as AA can be granted at earlier developmental stages before confirmatory data is generated. The proportion of AA‐designated programs was 29% in 2021 and 18% in 2022, 3 , 4 with 75% (n = 155) granted in oncology. 8 Most have relied on data from single‐arm trials using surrogate endpoints of objective response rate and duration of response. AA is always granted as a temporary measure with the understanding that drug developers must provide follow‐up confirmatory evidence in a timely manner.

The FDA continues to encourage expedited regulatory approaches via the accelerated approval pathway. It is recommended that one or two randomized controlled trials should be conducted to support an AA program by confirming clinical benefits. The term “Dangling” refers to approvals where confirmatory trials did not verify clinical benefits, but for which marketing authorization continues. In certain cases where there are compelling reasons for a confirmatory trial failing to verify clinical benefit, approval can sometimes remain in place while another confirmatory trial is underway. When more conventional approaches such as single‐arm trials are considered for AA, a confirmatory trial should be initiated with a defined timeline for the final report to the FDA. 9 Furthermore, in the field of oncology, drug developers must not only consider the planning of their pivotal trial but also pay careful attention to subsequent development plans with a precise timeline.

Maximum tolerated dose (MTD) is frequently used to determine the recommended phase 2 dose (RP2D) but was conceived during a time when most cancer drugs were cytotoxic chemotherapeutic agents, with the rationale being that the highest tolerable dose would achieve maximum benefit. The arrival of targeted agents has shown that the clinically optimal dose is not necessarily the highest possible dose, with efficacy plateaus and toxicities weighing into more complex risk–benefit decisions. The FDA's OCE launched Project Optimus in 2021 to provide clearer guidance on determining the optimal dose through clinical trials and modeling. Importantly, it emphasizes the need to collect sufficient safety data beyond dose‐limiting toxicities at different dose levels for consideration in parallel with efficacy data. 1

Project equity is an FDA initiative that aims to ensure that data submitted to the FDA for the approval of oncology medical products adequately reflects the patient demographics for which the products are intended. Draft guidance for this diversity plan was first issued in April 2022, 2 followed closely by ICH Guidance E17 stressing the importance of well‐designed Multi‐Region Clinical Trials (MRCTs) to factor in regional differences. 10

Other initiatives include Project Orbis 11 and Real‐Time Oncology Review (RTOR). 12 Project Orbis is an initiative by the FDA's Oncology Center of Excellence that facilitates a collaborative international review process for oncology drugs, aiming to accelerate approval times and synchronize regulatory decisions across multiple countries. RTOR allows for an expedited review process where drug manufacturers can submit parts of a drug application in advance to reduce review times by addressing FDA queries in real time.

Programs developed outside the United States often feature early clinical trials lacking US patient involvement while simultaneously aiming for a US NDA or BLA, with the intention of accommodating US ethnic diversity in late‐phase development. For this strategy, several factors should be considered for applications based on ethnic data alone 13 : (1) The data should be applicable to the US population and US medical practice; (2) the studies should be performed by clinical investigators of recognized competence; and (3) the data should be considered valid without the need for an on‐site inspection by FDA or, if FDA considers such an inspection to be necessary, FDA is able to validate the data through an on‐site inspection or other appropriate means. The FDA recently approved toripalimab (Loqtorzi™) for advanced nasopharyngeal cancer based on clinical trial data derived solely from patients in China, Singapore, and Taiwan. The developer was requested to conduct a single‐arm post‐approval study with at least 100 patients in the United States and Canada with sufficient ethnic diversity. In this case, the FDA likely approved toripalimab due to the very high unmet need for nasopharyngeal cancer and the rarity of the disease in the United States. Global drug development programs benefit from such considerations in early phase trials and for programs originating outside the United States, a pivotal trial including US ethnic diversity is required for an NDA/BLA.

The goal of market authorization requires a robust clinical development plan with careful monitoring of the changing competitive landscape and close dialogue with regulatory agencies. Excellence in clinical trial strategy and management can help drug developers generate quality data more rapidly, a key factor for success in a highly competitive environment where numerous drugs are often under development for the same indication at the same time.

## Section: NOMENCLATURE OF TARGETS AND LIGANDS

Key protein targets and ligands in this article are hyperlinked to corresponding entries in http://www.guidetopharmacology.org, the common portal for data from the IUPHAR/BPS Guide to PHARMACOLOGY, 14 and are permanently archived in the Concise Guide to PHARMACOLOGY 2019/20 (Alexander et al., 2019) 15 .

## Section: AUTHOR CONTRIBUTIONS

Manuscript concept and design of structure: Moon H. Manuscript writing, Final approval of manuscript, Accountable for all aspects of the work: All authors.

## Section: DISCLOSURES

Hanlim Moon serves as a consultant for or is involved in an advisory role in GI Innovation, Panolos Bioscience, SCL Therapeutics, and GI Biome, and is employed with MediRama. Dae Young Zang has no disclosures. Min‐Hee Ryu has received honoraria from Ono Pharmaceutical, BMS, MSD, Lily, Taiho, Novartis, Daiichi Sankyo, and AstraZeneca, and has served as a consultant for DAEHWA Pharmaceutical, BMS, Lily, and Ono Pharmaceutical. Yeon Sook Seo, Bitna Oh, and Sunjin Hwang are employed with MediRama. Lee Farrand is employed with MediRama and Yuhan Corporation.

## Section: ETHICS STATEMENT

Not applicable.

## Section: ACKNOWLEDGMENTS

No financial support was received.

## Section: Text

Moon H, Zang DY, Ryu M‐H, et al. FDA regulatory considerations for oncology drug development. Pharmacol Res Perspect. 2024;12:e1254. doi: 10.1002/prp2.1254

## Section: DATA AVAILABILITY STATEMENT

Not applicable.

## Section: Associated Data › Data Availability Statement

Not applicable.


---

# Fingerprinting Interactions between Proteins and Ligands for Facilitating Machine Learning in Drug Discovery

- **Authors:** Zoe Li, Ruili Huang, Menghang Xia, Tucker A Patterson, Huixiao Hong
- **Issuer:** Biomolecules
- **Type:** Scientific article
- **Published:** 2024-01-05
- **Language:** en
- **DOI:** 10.3390/biom14010072
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38254672/
- **Licence:** CC-BY

## Section: Abstract

AbstractMolecular recognition is fundamental in biology, underpinning intricate processes through specific protein–ligand interactions. This understanding is pivotal in drug discovery, yet traditional experimental methods face limitations in exploring the vast chemical space. Computational approaches, notably quantitative structure–activity/property relationship analysis, have gained prominence. Molecular fingerprints encode molecular structures and serve as property profiles, which are essential in drug discovery. While two-dimensional (2D) fingerprints are commonly used, three-dimensional (3D) structural interaction fingerprints offer enhanced structural features specific to target proteins. Machine learning models trained on interaction fingerprints enable precise binding prediction. Recent focus has shifted to structure-based predictive modeling, with machine-learning scoring functions excelling due to feature engineering guided by key interactions. Notably, 3D interaction fingerprints are gaining ground due to their robustness. Various structural interaction fingerprints have been developed and used in drug discovery, each with unique capabilities. This review recapitulates the developed structural interaction fingerprints and provides two case studies to illustrate the power of interaction fingerprint-driven machine learning. The first elucidates structure–activity relationships in β2 adrenoceptor ligands, demonstrating the ability to differentiate agonists and antagonists. The second employs a retrosynthesis-based pre-trained molecular representation to predict protein–ligand dissociation rates, offering insights into binding kinetics. Despite remarkable progress, challenges persist in interpreting complex machine learning models built on 3D fingerprints, emphasizing the need for strategies to make predictions interpretable. Binding site plasticity and induced fit effects pose additional complexities. Interaction fingerprints are promising but require continued research to harness their full potential.Keywords: molecular fingerprints, 3D structural interaction fingerprints, machine learning, drug discovery, structure–activity relationships, protein–ligand interactions, predictive modeling

## Section: 1. Introduction

Molecular recognition is a fundamental process in living organisms, involving specific and high-affinity interactions between biological macromolecules and various small molecules, leading to the formation of specific complexes [1,2]. Among these macromolecules, proteins play a vital role as they carry out their functions by binding to themselves or other molecules [2]. Consequently, a comprehensive understanding of protein–ligand interactions holds the key to unraveling the intricacies of molecular biology. Additionally, this knowledge about the mechanisms governing protein–ligand recognition and binding serves as a valuable resource in drug discovery, design, and development. By delving into the specifics of these interactions, researchers can better advance their quest for new therapeutic agents and foster scientific advancements in the field of drug development.

Traditional experimental methods have long been employed to predict the binding activity of small molecules [3]. These methods include isothermal titration calorimetry, fluorescence thermal shift assay, cellular thermal shift assay, and analytical ultracentrifugation, among others [3]. However, the vastness of the chemical space allows for an astounding number of approximately 1060 possible small molecules to be synthesized [4]. Despite this immense potential, only a small fraction of the potential protein–ligand interactions has yet to be explored [4]. Efficiently navigating through this vast search space poses challenges for traditional experimental methods due to their inherent drawbacks: high cost, time consumption, and labor intensiveness. Consequently, the increasing demand for more efficient approaches to predict the biological activities of small molecules has driven the development of computational methods. These computational approaches serve as invaluable tools to streamline the search process, narrowing down the possibilities and enabling researchers to focus on promising targets.

One of the most widely used computational approaches in drug discovery is quantitative structure–activity/property relationship (QSAR/QSPR) analysis [5]. This approach operates on the assumption that similar molecules exhibit similar bioactivities or physicochemical properties [5,6]. Leveraging this assumption, QSAR/QSPR analysis predicts the activities or properties of new molecules by establishing correlations between their chemical or structural features and their observed activities or properties [5,6]. This approach significantly reduces the need for time-consuming and costly experimental assays. Central to QSAR/QSPR analysis is the concept of molecular similarity, which is usually measured based on various molecular descriptors and fingerprints [7,8]. Molecular descriptors are numerical descriptions of the structural features of a chemical and are widely used in the development of predictive models of predicting biological activity and chemical properties [9,10,11,12,13,14]. Fingerprints encode the structural features of a molecule. These fingerprints serve as property profiles, typically presented in the form of vectors, where each vector element represents the existence, degree, or frequency of a specific structural feature [15,16,17]. Molecular fingerprints play a fundamental role in various drug discovery processes, including virtual screening, similarity-based compound searches, target molecule ranking, drug ADMET (absorption, distribution, metabolism, excretion, and toxicity) prediction, and more. Over the past few decades, different types of two-dimensional (2D) fingerprints have been developed for molecular feature encoding [18,19,20]. These fingerprints can be extracted from molecular connection tables without requiring three-dimensional (3D) structural information. The main categories of 2D fingerprints are as follows: substructure key-based fingerprints, topological or path-based fingerprints, circular fingerprints, and pharmacophore fingerprints [21,22,23]. Two-dimensional fingerprints are advantageous due to their ease, speed, and convenience of generation, as they solely rely on 2D structures [5]. Consequently, they are extensively utilized as input for machine learning algorithms in various drug discovery applications, such as binding affinity prediction, toxicity assessment, solubility analysis, and partition coefficient estimation [24]. A typical workflow for using machine learning to predict the properties of molecules is shown in Figure 1.

In recent years, there has been a notable shift in the extensive use of machine learning from QSAR studies to focus on structure-based predictive modeling [25,26,27,28]. The availability of abundant structural and binding affinity data for protein–ligand complexes has enabled the training of binding affinity prediction models, leading to a surge in the development of machine-learning scoring functions [29]. These scoring functions exhibit exceptional performance in scoring works and have proven to outperform classical scoring functions, primarily due to their ability to handle large volumes of structural data effectively [29,30]. A critical aspect of constructing a machine-learning scoring function is feature engineering, which involves transforming complex structures into a series of descriptors. This process is guided by biologically-relevant interactions, such as hydrogen bonds, hydrophobic contacts, ionic interactions (salt bridges), π-stacking, and π-cation interactions [31].

Figure 2 illustrates a conventional fingerprint that is generated based only on the 2D structure of a small molecule and an emerging 3D interaction fingerprint that describes the interactions between a small molecule and its interacting macromolecule in a 3D structure. Recently, the focus of scoring function descriptors has shifted towards 3D interaction fingerprints (IFPs) because of their simplicity in representation and elaborate profiles of key interactions. IFPs are defined based on the interacting atoms between the protein and ligand within a protein–ligand complex structure. They are stored as one-dimensional (1D) vectors or matrices of Booleans, integers, or floating-point numbers, providing a concise and informative representation of the interaction patterns between the two entities [30,32]. The use of IFPs in machine-learning scoring functions holds significant promise in accurately characterizing and predicting protein–ligand interactions, thereby advancing the field of structure-based predictive modeling.

Typical workflow for using machine learning to predict properties of molecules.

Illustration of a 2D molecular fingerprint (left) and a 3D molecular fingerprint (right). The dash circles in different colors indicate different structural features that are recorded in a bit string (under the 2D structure) as the fingerprint of the molecule. In the right sub-figure, the small molecule is represented by a stick model and the protein is drawn in a grey ribbon model. The interactions between the small molecule and the protein are indicated with yellow dashed lines and are recorded as the fingerprint of the small molecule in the protein.

## Section: 2. Types of Structural Interaction Fingerprints

The development and application of various structural IFPs have been significant in advancing the field of protein–ligand interaction analysis. One of the pioneering structural IFP algorithms was introduced by Deng et al. in 2004, focusing on clustering kinase–inhibitor complexes [33]. Their fingerprint encompassed seven bits per interacting amino acid, representing predefined interaction types, including backbone, sidechain, polar, hydrophobic, and H-bond donor/acceptor interactions [33]. Mordalski et al. later extended this approach by adding two bits to encode aromatic and charged interactions, leading to improved technical implementation [34]. Notably, structural IFP was instrumental in identifying the critical amino acids involved in interactions with antagonists within serotonin 5-HT7 receptor homology models [35].

Another widely used variant, developed by Marcou and Rognan in 2006, employs a seven-bit fingerprint encoding hydrophobic, aromatic face-to-face and edge-to-face, H-bond donor/acceptor, and cationic/anionic interactions [36]. Importantly, the geometric definitions in this variant can be customized, allowing for the inclusion of less common interaction types like weak H-bonds, cation-pi, and metal complexation [36]. This flexibility has enhanced the versatility of the fingerprinting approach. Later, the Rognan group devised a method to encode protein–ligand interactions into a 1D binary IFP string represented by an array of 11-bit substrings [37,38]. This novel approach effectively describes how each amino acid within the binding pocket interacts with the ligand. Specifically, every amino acid is encoded into one 11-bit substring, corresponding to 11 distinct types of interactions: hydrophobic interaction, aromatic interaction (face-to-face), aromatic interaction (edge-to-face), hydrogen bond interaction (protein atom as acceptor), hydrogen bond interaction (protein atom as donor), ionic interaction (protein atom with positive charge), ionic interaction (protein atom with negative charge), weak hydrogen bond interaction (protein atom as acceptor), weak hydrogen bond interaction (protein atom as donor), π-cation interaction, and metal ionic interaction with the ligand [37,38]. This encoding system provides a comprehensive representation of the intricate interactions between amino acids and the ligand, enabling a detailed analysis of their binding patterns.

The Rognan group also introduced triplet IFPs, where interaction points forming triangles are encoded into a fixed-length fingerprint of 210 bits [30]. The protein–ligand interaction is characterized by two interacting atoms and an interaction pseudoatom for ionic interaction, hydrogen bonding, and metal complexation. The interaction pseudoatom can be in three positions: the geometric center of the interacting atoms, near the interacting protein atom, and near the interacting ligand atom [30]. Interaction pseudoatoms can be computed using any of these three positions, allowing for mapping the interaction either on ligand atoms, protein atoms, or naturally at the mid-distance between the interacting atoms [30]. For hydrophobic interactions, when a ligand atom interacts with more than one protein atom, the interaction with the shortest distance is used to define the interaction pseudoatom. For aromatic interactions, an aromatic interaction pseudoatom is placed in the middle between the aromatic ring centroids. Although primarily designed for binding site comparison, triplet IFPs showed comparable performance to IFP in the post-processing of docking results [30].

Python-based protein–ligand interaction fingerprint (PyPLIF), an open-source Python tool developed by Radifar et al., aims at improving the accuracy of molecular docking results in virtual screening [39]. PyPLIF converts 3D interaction data from molecular docking into 1D bitstring representations, where each bit encodes the presence or absence of specific interaction types with binding site residues [39]. The similarity between these fingerprints and a reference ligand fingerprint is then evaluated using metrics like the Tanimoto coefficient [39]. Selecting top docking poses based on interaction fingerprint similarity, rather than relying solely on docking scores, significantly improves the identification of true binders [39].

Atomic pairwise interaction fingerprint (APIF) offers a binding site size-independent encoding of protein–ligand interactions. It achieves this by considering the relative position and interaction type of all pairs of interacting atoms between the ligand and protein [40]. Each interacting atom pair is categorized by its interaction type, such as the hydrophobic-acceptor, and sorted into discrete distance ranges between the ligand and protein atoms [40]. Consequently, a 294-bit fixed-length binary fingerprint is generated, encompassing various combinations of interaction pairs and distances. APIF’s utilization of relative geometry rather than absolute positions allows for a comparison of binding modes across diverse binding sites [40]. This 1D fingerprint retains essential 3D information, making it valuable for virtual screening and docking pose selection. However, one limitation is the reduced precision in capturing geometric details, which may make interpreting interactions from APIF challenging [40]. Despite this, APIF stands out for providing a concise representation of conserved interaction patterns, independent of the binding site size, although it may lack the intuitive interpretability found in residue-specific interaction fingerprints.

The simple ligand–receptor interaction descriptor (SILIRID) is an innovative fixed-length vector representation that derives from protein–ligand interaction fingerprints, serving to characterize binding sites. It condenses the interactions between ligand atoms and binding site residues into a concise 168-dimensional vector [41]. This is achieved by summing the binary fingerprint bits for identical amino acids and capturing their corresponding interaction types (such as hydrophobic, hydrogen bond donor/acceptor, etc.) [41]. SILIRID’s distinct feature lies in its ability to merge residue-specific fingerprints into a binding site-independent summary, facilitating the comparison of interactions across binding sites of varying sizes [41]. As a result, SILIRID offers a compact representation of conserved interaction patterns that find applications in tasks like binding site comparison, virtual screening, and the visualization of chemogenomic space. One limitation to consider is the reduction in per-residue details, which may limit the granularity of interpretation [41]. Overall, SILIRID excels in encoding essential interaction features within a size-independent vector, although it may not possess the same level of interpretability found in residue-specific fingerprints.

Another unique approach to structural protein–ligand interaction fingerprints (SPLIF) was proposed by Da and Kireev [42]. It was designed to describe and compare protein–ligand interactions in a manner that is independent of the binding site. Unlike other approaches, SPLIFs explicitly encode the 3D structures of interacting ligand and protein fragments, capturing the nuances of the interaction modes and implicitly considers various contacts, such as π-π stacking [42]. The generation of SPLIF involves expanding contacting ligand and protein atoms to include neighboring atoms within a defined radius [42]. These circular fragments are assigned identifiers, and their 3D coordinates are retrieved [42]. The SPLIF then encodes the matching circular fragments between a docking pose and the reference complex, assessing similarity through a normalized score based on the fraction of matched fragments [42]. The evaluation involves both 2D fragment identity and 3D structural alignment, providing a comprehensive representation of the interaction patterns. A notable advantage of SPLIFs is their implicit inclusion of diverse interaction types in the 3D structure description [42]. However, the trade-off is the loss of precise geometric details. Overall, SPLIFs offer a robust platform for the quantitative comparison of conserved interaction patterns across binding sites of varying sizes.

Recently, Wojcikowski et al. introduced the protein–ligand extended connectivity fingerprint (PLECFP) [43], based on the atomic environment concept of the extended connectivity fingerprint initially proposed by Rogers and Hahn in 2010 [18]. PLECFP captures the local atomic environments between the interacting protein and ligand molecules. Its construction involves identifying contacting atom pairs and characterizing the neighborhood surrounding each atom within a specified bond depth. These ligand and receptor environments are paired, and their hashed bit positions create the final folded fingerprint. PLECFP’s parameterization and evaluation on binding affinity prediction tasks using linear regression, random forest, and neural network models showcased its impressive descriptive capabilities. Surprisingly, the simple linear model performed similar with more complex methods, underscoring the richness of PLECFP’s representation. Notably, PLECFP outperformed other interaction fingerprints like SILIRID and SPLIF, yielding Pearson correlation coefficients exceeding 0.8 on benchmark datasets [43]. Such exceptional performance suggests PLECFP’s potential for diverse drug discovery tasks, including lead optimization and scaffold hopping, thanks to its implicit capacity to capture relevant interactions. A summary of different types of protein–ligand interaction fingerprints is listed in Table 1. A list of currently available software for calculating interaction fingerprints is shown in Table 2.

Different types of protein–ligand interaction fingerprints and their characteristics.

Available software for calculating structural interaction fingerprints.

## Section: 3. Case Study of Structural Interaction Fingerprint Application

In this section, we highlight two case studies that incorporated structural interaction fingerprints into machine learning. The first case study demonstrated that molecular docking and machine learning can be combined to reveal key structure–activity relationships for drug targets [53]. The researchers compiled a dataset of approximately 2700 known ligands for the β2 adrenoceptor (β2AR). They computationally docked these ligands to β2AR structures to generate approximately 75,000 poses and calculated atomic interaction fingerprints describing receptor–ligand interactions. Machine learning models were trained on these fingerprints to predict whether ligands act as agonists or antagonists. Figure 3 shows the detailed workflow of this work. The models identified specific hydrophobic and polar contacts with receptor residues that differentiate agonists and antagonists. Agonists were found to preferentially interact with residues K97, F194, S203, S204, S207, H296, and K305 while antagonists were found to favor residues W286 and Y316. This structure–activity relationship modeling approach achieved high accuracy in predicting ligand pharmacological activity and provided molecular insights into β2AR activation and inhibition. This study demonstrates the power of interaction fingerprint-driven machine learning for elucidating ligand binding mechanisms and guiding rational drug design. The results from this case study revealed that structural interaction fingerprints derived from docking poses offer insights into the environment surrounding the ligand, which can be useful for differentiating the potential biological activities of ligands.

The second case study introduced a machine learning strategy employing an innovative molecular representation termed RPM (retrosynthesis-based pre-trained molecular) representation to predict protein–ligand dissociation rates (koff) [54]. The RPM representation was constructed through training on retrosynthesis reaction data, enabling the encapsulation of molecular reactivity and functional group information. Subsequently, these RPM features were fed into a partial least squares regression model to predict the koff values for 501 inhibitors spanning 55 proteins. Impressively, the RPM-based model demonstrated superior performance compared to other pre-trained representations such as the molecular pre-training graph-based deep learning framework and geometry-enhanced molecular representation, achieving a noteworthy Pearson correlation coefficient of 0.76 on this specific dataset. To exemplify its application, the model was further evaluated using 38 novel inhibitors targeting the N-terminal domain of the heat shock protein 90α (HSP90), yielding a commendable correlation of 0.73 with experimental koff values. In-depth mechanistic insights into the kinetics were sought through accelerated molecular dynamics simulations, which obtained data on relative retention times and protein–ligand IFPs along the dissociation trajectory. Figure 4 illustrates the detailed workflow of this case study. The simulated koff values exhibited reasonable agreement with experimental results, with the IFPs elucidating important residues like N51, S52, and L107 that significantly influence the dissociation process. In an additional validation, the machine learning model coupling with molecular dynamics simulation was extended to two new HSP90 inhibitors absent from the training set. Encouragingly, the model accurately predicted their relative koff values, which were aligned with experimental observations. Furthermore, the IFP analysis offered detailed insights into how substituents modulated binding kinetics. This case study combined different approaches and offered a comprehensive exploration of the molecular attributes and interactions that govern binding kinetics, thereby underlining its potential utility for kinetics-focused drug design endeavors.

Case study of Jimenez-Roses et al. [53]. Workflow of utilizing interaction fingerprints extracted from docking poses as input for machine learning model to identify key residues for ligand pharmacological activity on β2 receptors.

Case study of Zhou et al. [54]. Workflow of utilizing interaction fingerprints extracted from MD simulations as input for machine learning model to identify correlation between key residues and ligand kinetics. The ligand dataset in this case study was obtained from Amangeldiuly et al. [55] and Liu et al. [56].

## Section: 4. Future Perspective

Molecular fingerprints have become indispensable cornerstones in the realm of computational drug discovery, offering informative representations of ligands for property prediction and activity modeling. In this landscape, the realm of molecular fingerprints stands at an exciting crossroads, with 2D fingerprints providing simplicity and ease of use, while 3D structural interaction fingerprints hold the tantalizing potential to intricately encapsulate the minutiae of interactions within protein–ligand complexes. The future trajectory of this field is poised for further advancement, driven by the synergy of hybrid fingerprint design and technological progress. The amalgamation of 3D structural interaction descriptors with other properties, such as physicochemical attributes, has the potential to elevate the accuracy of ligand bioactivity predictions. By encompassing both structural intricacies and physicochemical subtleties, hybrid fingerprints extend the horizons of molecular characterization, and the application of advanced machine learning techniques holds the key to their optimal integration. As computational methodologies advance and resources expand, the landscape for harnessing the potential of 3D fingerprints in drug discovery grows even more fertile. The interplay of refined machine learning algorithms, augmented structural datasets, and enhanced computational power opens new possibilities and opportunities in interaction fingerprint design, training, and prediction, with deep learning strategies poised to unveil profound insights from intricate 3D interaction patterns.

Yet, as the future of molecular fingerprints shines brightly, it is not without its challenges. One such limitation lies in the dependency of 3D fingerprints on the accessibility of protein–ligand complex structures. Nonetheless, the ongoing advancements in structural determination techniques contribute to an increasing abundance of structures, facilitating the progress of molecular fingerprint development. Another drawback is the insufficient incorporation of the energy terms necessary to comprehensively characterize the interactions occurring between proteins and ligands. Recent deep learning-based scoring functions may potentially solve this problem. Decoding complex machine learning models constructed on 3D fingerprints is another challenge. The process of unraveling the pivotal interacting features driving a model’s predictions remains an active area of exploration. Novel strategies are essential to deconstruct model outputs into interpretable interaction insights, which in turn can illuminate pathways for molecular optimization. Moreover, the intricacy of binding site plasticity and induced fit effects introduces complexities in accurately characterizing interactions solely from static structural data. Another limitation is the reliance on the availability of known ligand–protein interaction information. In both case studies, the target has a large number of known ligands that can be used for model training. However, for targets that have few or no known ligands, for which the discovery of new ligands is in higher demand, this method would not be as applicable.

Overall, interaction fingerprints hold immense promise but require continued research to fully harness their potential and overcome existing limitations, unlocking new vistas of discovery and application.

## Section: Author Contributions

Writing—original draft preparation, Z.L.; writing—review and editing, R.H., M.X., T.A.P. and H.H.; supervision, H.H. All authors have read and agreed to the published version of the manuscript.

## Section: Conflicts of Interest

The authors declare no conflicts of interest.

## Section: Authors’ Disclaimer

This article reflects the views of the authors and does not necessarily reflect those of the U.S. Food and Drug Administration.

## Section: Funding Statement

This work was supported in part by an appointment to the Research Participation Program at the National Center for Toxicological Research (Zoe Li), administered by the Oak Ridge Institute for Science and Education through an interagency agreement between the US Department of Energy and the US Food and Drug Administration and the Intramural/Extramural research program of the NCATS, NIH.


---

# Functional microRNA-targeting drug discovery by graph-based deep learning

- **Authors:** Arash Keshavarzi Arshadi, Milad Salem, Heather Karner, Kristle Garcia, Abolfazl Arab, Jiann Shiun Yuan, Hani Goodarzi
- **Issuer:** Patterns (New York, N.Y.)
- **Type:** Scientific article
- **Published:** 2024-01-03
- **Language:** en
- **DOI:** 10.1016/j.patter.2023.100909
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38264717/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

SummaryMicroRNAs are recognized as key drivers in many cancers but targeting them with small molecules remains a challenge. We present RiboStrike, a deep-learning framework that identifies small molecules against specific microRNAs. To demonstrate its capabilities, we applied it to microRNA-21 (miR-21), a known driver of breast cancer. To ensure selectivity toward miR-21, we performed counter-screens against miR-122 and DICER. Auxiliary models were used to evaluate toxicity and rank the candidates. Learning from various datasets, we screened a pool of nine million molecules and identified eight, three of which showed anti-miR-21 activity in both reporter assays and RNA sequencing experiments. Target selectivity of these compounds was assessed using microRNA profiling and RNA sequencing analysis. The top candidate was tested in a xenograft mouse model of breast cancer metastasis, demonstrating a significant reduction in lung metastases. These results demonstrate RiboStrike’s ability to nominate compounds that target the activity of miRNAs in cancer.

## Section: Introduction

As a class of short non-coding RNAs, microRNAs (miRNAs) are among the essential regulators of cellular homeostasis. They oversee gene expression and regulate protein synthesis across many target regulons. The dysregulation of these post-transcriptional regulatory programs has been shown to contribute to tumor formation and progression.1 Since miRNAs regulate a variety of gene regulatory programs, they play an important role in the emergence of various oncogenic hallmarks, such as metastasis,2 angiogenesis,3 and resistance to apoptosis.4 There is recent evidence that they may contribute to the suppression of the immune response within the tumor microenvironment as well. It has also been established that miRNAs are involved in drug resistance in multiple cancers.5 Among miRNAs, miRNA-21 (miR-21) has been one of the most well-studied drivers of oncogenesis.6 miR-21 dysregulation has been implicated in ovary, gallbladder, colorectal, pancreatic, and many other cancers.

Much effort has been dedicated to targeting oncogenic miRNAs such as miR-21 to combat various tumors.7 This is largely achieved through the synthesis and delivery of antisense oligonucleotides (ASOs). For example, researchers developed ASOs that are capable of targeting miR-155, which is known to be involved in multiple types of cancer, including breast and lung tumors.8 However, delivering ASOs to cancer cells is often challenging due to their poor permeability, and short ASOs may also bind to other RNAs with similar sequences, leading to unintended off-target effects. To overcome these limitations, some researchers have focused on developing small molecules that bind and inhibit miRNAs.9,10 Unlike ASOs, small molecules are typically easier to formulate and have better bioavailability, making them more suitable for drug development. In recent years, researchers have made progress in developing small molecules that target various types of RNAs, both coding and non-coding.9 Dovitinib, for example, is a small molecule in early stages of discovery for its ability to treat triple-negative breast cancer and Alport syndrome by inducing the degradation of miR-21 via RNase L recruitment. As another example, risdiplam is an US Food and Drug Administration (FDA)-approved drug for its ability to treat spinal muscular atrophy (SMA) by targeting SMN2 pre-mRNA exon 7-intron junction.9

It has been challenging, however, to structurally inhibit the activity of RNAs with small molecules, especially small RNAs such as miRNAs. Unlike proteins, they typically have a dynamic structure11 and often lack the canonical pockets found in druggable proteins. Therefore, conventional docking approaches have not been successful for miRNAs.11 Furthermore, structurally binding a small molecule to miRNAs does not necessarily impair their functionality.12 Another approach to targeting miRNAs is to inhibit their upstream regulators, but outside of the miRNA biogenesis pathway, which is shared among all miRNAs, selective regulators of miRNA activity are largely unknown and poorly characterized. Despite significant research efforts, miRNAs are still considered to be largely undruggable,13 and a platform that enables selective inhibition of miRNAs remains an important problem in the field.

In this study, we use artificial intelligence to develop a small molecule drug discovery platform called RiboStrike, which aims to inhibit miRNA activity rather than disrupt their structure. Our approach is built on the capabilities of advanced deep-learning architectures to learn representations from molecular data and discover hidden patterns in an abstract and non-linear manner. As shown in Figure 1, we used graph convolutional neural networks (GCNNs)14 to aid the virtual screening of small molecules against the oncogenic miR-21 in silico, solely relying on the simplified molecular-input line-entry system (SMILES) encoding of small molecules as input. We used multitask learning to learn the relationship between chemical groups and molecular activity across multiple data sources, including large publicly available assays from PubChem.15 Furthermore, we developed several additional modules to improve our model’s performance and utility, such as uncertainty prediction, auxiliary modeling (e.g., toxicity prediction), and molecular diversification, to help prioritize molecules for wet-lab follow-up experimentation and validation.Figure 1Overview of the RiboStrike pipeline(A) Stages of discovery from input molecular data and deep-learning techniques to candidate selection and experimental validation. Molecular data are collected from multiple sources for training virtual screening models in multitask learning mode where different datasets are grouped together and share learned representations. A task recommender algorithm helps choose the grouping of the tasks for multitask learning to maximize performance. Nine million candidate molecules are filtered based on the predictions of the models on bioactivity, interactions, and toxicity and the uncertainty in those predictions. After clustering for a diverse selection, eight of the top candidates are experimentally validated.(B) Computational pipeline and the flow of data within the GCNN network. Molecules are represented as graphs with calculated node and bond features. The convolution layers learn distinctive representations, which are pooled into fixed-length vectors and used for classification by the fully connected network. Once a multitask learning model is trained, an in-house algorithm is used to recommend task grouping for another round of multitask learning.

As we demonstrate, RiboStrike selected eight candidate compounds from a pool of more than nine million molecules in the ZINC15 database.16 We then performed a battery of functional and molecular experiments, in cell culture and in mice, to functionally validate the anti-miRNA activity of our hit compounds. Taken together, our results indicate that RiboStrike can identify candidate inhibitory molecules without the need for the structural information of the target. Additionally, in this work, we have introduced a prediction-based algorithm for recommending input datasets for multitask learning in order to improve the performance of the modeling for the discovery of molecules that inhibit miR-21 activity.

Overview of the RiboStrike pipeline

(A) Stages of discovery from input molecular data and deep-learning techniques to candidate selection and experimental validation. Molecular data are collected from multiple sources for training virtual screening models in multitask learning mode where different datasets are grouped together and share learned representations. A task recommender algorithm helps choose the grouping of the tasks for multitask learning to maximize performance. Nine million candidate molecules are filtered based on the predictions of the models on bioactivity, interactions, and toxicity and the uncertainty in those predictions. After clustering for a diverse selection, eight of the top candidates are experimentally validated.

(B) Computational pipeline and the flow of data within the GCNN network. Molecules are represented as graphs with calculated node and bond features. The convolution layers learn distinctive representations, which are pooled into fixed-length vectors and used for classification by the fully connected network. Once a multitask learning model is trained, an in-house algorithm is used to recommend task grouping for another round of multitask learning.

## Section: Results

Summary of the datasets

The AP score of different sub-models for the task recommender algorithm

The tasks above the threshold line make predictions matching the miR-21 ground truth to a higher degree than the rest of the tasks. These tasks are the recommended tasks and are selected for training a new multitask model with narrower scope.

Performance of different models on the test set of the miR-21 dataset

Confusion matrix for models trained using different learning methods

(A) Single task, (B) multitask for all tasks, and (C) multitask for recommended tasks. Balance between true positives (predicted correctly as positive) and false negatives (predicted incorrectly as positive) is needed for virtual screening. Due to imbalanced data, false negatives hurt candidate pool quality drastically.

Performance of toxicity and DICER inhibition models on their corresponding test sets

UMAP of the inner features of the model for the inference and training data for

(A) ZINC data predicted to be active as the candidate space to select from, (B) the training data and the positive molecules from the FDA-approved set, showing that the candidate space spans the same area as the training set, and (C) the 10 clusters applied to this space for the inference sets (ZINC and Asinex) and the final selected molecules from these clusters to ensure diversity in selection.

Experimental validation results

(A) Dosage response assay in reporter cell lines for Ribo21D-1, Ribo21D-2, and Ribo21D-3.

(B) Enrichment and depletion patterns of putative miR-21 targets across gene expression changes for anti-miR21 as well as Ribo21D treatments (left). For this analysis, gene expression changes (log2 fold changes) were first sorted and divided into equally populated bins, from downregulation (left) to upregulation (right). For each analysis, the mutual information value (in bits) and its associated Z score are provided. The heatmaps show the enrichment and depletion patterns from the onePAGE package. Blue marks depletion and gold marks enrichment. Expression bins with statistically significant depletion or enrichment of miR-21 putative targets are marked by a dark blue or red border. As an alternative visualization, we have also shown the logFC values for the miR-21 targets and the background set of genes (right). The p values were calculated using t test.

(C) Expression of empirically determined miR-21 targets (microCLIP37 plus anti-miR transfections) in response to the top three compounds.

(D) Expression of miR-21 determined using small RNA-seq across the three treatments. The p values were calculated using DESeq2.

(E) In vivo lung colonization assays were used to measure impact of Ribo21D-1 on lung metastasis. Normalized lung photon flux, which measures luciferase activity in labeled cancer cells, as a function of time for each cohort (n = 5) is shown. Two-way ANOVA and Mann-Whitney U tests were used to assess statistical significance. Also shown is a representative mouse and lung image.

## Section: Results › Aggregating data for miR-21, cancer, and off-target interactions

We used three different data modalities to train RiboStrike for optimized hit selection. First, we used datasets relevant to the virtual screening task to train models that predict the effect of a particular small molecule on the activity of miR-21. In this category, we combined nearly 14,000 inhibitors of miR-21 activity (measured by a reporter assay in a 315,000-compound library),17 assays designed to identify cancer-fighting candidates (cell-based and biochemical assays), and the PCBA dataset (a collection of overlapping PubChem assays18). Combining all these datasets resulted in a total of 139 classification tasks; however, in order to create a more focused training dataset that is optimal for multitask learning, we used a supervised task recommender algorithm to narrow down the output of our model to seven tasks. Additionally, we also took advantage of a dataset that measures DICER inhibition to perform an in silico counter-screening. DICER is one of the main processing enzymes for miRNAs and its inclusion allowed us to select against inhibitors of DICER activity and identify miR-21 selective inhibitors as opposed to systemic inhibitors of miRNA biogenesis. This model, alongside a model trained on general cellular toxicity, guides the pipeline’s prediction to maximize on-target efficacy and specificity and filter overtly toxic compounds. Finally, we used large-scale libraries of drug-like in silico compounds as inference datasets to find candidates for further screening. These datasets include ZINC16 for its diverse and large collection of molecules and Asinex19 for its selection of molecules (including potential RNA binders). A summary of all datasets used for training, inference, and filtering in this research is listed in Table 1. As mentioned above, our model receives SMILES strings as input, in canonical form with isomeric information included. As for the outputs, each instance carries multiple binary labels denoting the existence of bioactivity or property classes for each of the output tasks.Table 1Summary of the datasetsDatasetTypeTasks# MoleculesActive (%)miR-2117VS1315.16K4.29CancerVS48535.45K2.54PCBA18VS128439K1.39CombinedVS139540.42K2.39RecommendedVS7448.87K4.53Toxicity20AUX588.36K18.73Toxicity recommendedAUX58.36K19.64DICER21Off146.72K6.05ZINC16MS–9.20M–Asinex19MS–3,652–FDA approved22MS–157–SAR sample23MS–37–Datasets used for virtual screening (VS), auxiliary modeling (AUX), and molecule selection (MS) as well as the number of tasks (assays), number of molecules, and the percentage of active molecules within each dataset. K, thousands; M, millions.

Summary of the datasets

## Section: Results › Computational pipeline: Training GCNNs on small molecules

In learning from molecular data, RiboStrike utilizes GCNNs as its primary modeling approach. Graph-based models are well suited for handling small molecules since nodes represent atoms within molecules and edges represent bonds between them.14,24 In this graph representation, each node contains features that describe the atom and its properties. Through the use of these features during training, abstract representations of the nodes can be formed by applying graph convolution, which can then be pooled into a representation for the given molecule through the graph gathering layer. We and others have used GCNNs to effectively learn the relationship between input molecules and their physicochemical properties,25 their impact on a given target’s function,26 and virtual screening.27 Other models, such as pretrained transformers (e.g., ChemBERTa28), which rely on masked token prediction from SMILES sequence or tensor field networks29 and extract features from coordinate clouds, were also considered for this work. However, GCNNs were ultimately chosen due to their simplicity, smaller size, and training efficiency (empirical comparison of performance to ChemBERTa can be found in Table S2). In this study, we have also taken advantage of evidential deep learning30 to provide an estimate of the uncertainty of a prediction given an input molecule, which shows the confidence of the model and guides the molecule selection process to have less uncertainty. As shown in Figure 1, we trained GCNN models to predict miR-21 activity suppression, DICER inhibition, and toxicity profiles of each input molecule, given their canonical SMILES. We have illustrated our pipeline for the flow of data in this study in Figure 1B.

## Section: Results › Task recommendation: Tailoring the training dataset for miR-21

The high number of tasks that results from combining all assays often degrades the model’s performance. A particular problem often arises during multitask learning and stochastic gradient descent (SGD) when training on multiple tasks may reduce the performance on one or more of the tasks (e.g., some tasks differ from others regarding the gradient direction), which results in a less efficient training process.31 To address this challenge in a principled way, we implemented a prediction-based recommendation algorithm to select a subset of tasks from the entire dataset and to create a smaller dataset that is optimized for higher performance for the specific tasks that are of our interest. Using this algorithm, sub-models with similar predictions to the target task (for example, miR-21) are identified, and the top-ranking tasks relating to these sub-models are selected as recommendations. Figure 2 provides an overview of the scores for all sub-models on the target miR-21 task as well as the threshold line we selected. Using our recommender technique, we identified seven tasks that scored higher than the threshold of the mean plus two standard deviations (the tasks are identified in Table S2).Figure 2The AP score of different sub-models for the task recommender algorithmThe tasks above the threshold line make predictions matching the miR-21 ground truth to a higher degree than the rest of the tasks. These tasks are the recommended tasks and are selected for training a new multitask model with narrower scope.

As expected, the counter-screen assay for miR-21 activity,32 which was an assay to detect false positives in the main screen by measuring the activator of the firefly luciferase, is positioned as one of the recommended tasks. This is intuitive due to this counter-screen’s direct association with the main task and the importance of molecular patterns and activity labels contained in this dataset. Interestingly, the remaining recommended tasks were not directly related to miR-21 and were included solely based on the observation that the output of their trained sub-model is similar to that of the miR-21 sub-model. In other words, the models trained on these recommended tasks perform better in predicting the effect on miR-21 activity than the rest of the sub-models, making their respective training data suitable for use in the recommended model.

The AP score of different sub-models for the task recommender algorithm

The tasks above the threshold line make predictions matching the miR-21 ground truth to a higher degree than the rest of the tasks. These tasks are the recommended tasks and are selected for training a new multitask model with narrower scope.

## Section: Results › Virtual screening results: Task recommendation offers the best performance

Following identification of the optimized tasks and implementation of all training scenarios, we compared a variety of modeling techniques to ascertain which dataset and training regimen resulted in the best-performing model. The results on the test set, 10% of the original miR-21 dataset that was held out and isolated throughout model training, were calculated and summarized in Table 2. The confusion matrices for three different training scenarios are shown in Figure 3.Table 2Performance of different models on the test set of the miR-21 datasetModel# TaskROC-AUCPrecisionAPSingle task10.817012.5223.03Multitask: cancer480.823911.1020.62Multitask: all1390.832510.1420.43Random selected tasks70.802718.1121.04Recommended tasks70.830520.9324.72∗Models have different types of training data, yet all contain the same miR-21 task for fair comparison. AP score is the main metric for performance comparison. Asterisk indicates best performance.Figure 3Confusion matrix for models trained using different learning methods(A) Single task, (B) multitask for all tasks, and (C) multitask for recommended tasks. Balance between true positives (predicted correctly as positive) and false negatives (predicted incorrectly as positive) is needed for virtual screening. Due to imbalanced data, false negatives hurt candidate pool quality drastically.

As was expected, the prediction-based task recommender algorithm resulted in the highest-performing model using the recommended tasks, compared to random tasks, all tasks, or the single miR-21 task, as the model trained on the recommended tasks achieves the highest average precision score. Since our model is conservative, it has a lower tendency to predict molecules as active, and therefore shows a lower performance in recall (in comparison to Figures 3A and 3B). It is evident, however, from the precision score in Table 2 and the confusion matrix in Figure 3C that molecules that are predicted to be active are more likely to be true positives, which is a desirable behavior for virtual screening models. This is because follow-up experimental validations are often costly and we therefore have a higher tolerance for false negatives than false positives in virtual screens.

Performance of different models on the test set of the miR-21 dataset

Confusion matrix for models trained using different learning methods

(A) Single task, (B) multitask for all tasks, and (C) multitask for recommended tasks. Balance between true positives (predicted correctly as positive) and false negatives (predicted incorrectly as positive) is needed for virtual screening. Due to imbalanced data, false negatives hurt candidate pool quality drastically.

## Section: Results › Evaluation of the RiboStrike model on held-out datasets

To independently verify the performance of our best-performing model, we took advantage of data from an independent study, namely the structural activity relationship sample dataset,23 which included 37 previously unseen molecules derived from two inhibitors of miR-21. Our virtual screening model successfully classified 33 out of the 37 molecules as “active,” closely matching the results of the related study,23 demonstrating the potential for this model in the context of structural activity relationship (SAR) scenarios. For the four misclassified molecules, our model was uncertain (with uncertainty of 100% for all four misclassified cases). This is likely because, for the most part, these molecules were in the last iteration of SAR and were therefore significantly altered. Consequently, these molecules are outside the familiarity zone of our model’s training set, resulting in an uncertain prediction for the model.

## Section: Results › Auxiliary models for selecting molecule candidate: DICER inhibition modeling results

As mentioned earlier, miRNAs are transcribed and matured through a predefined pathway. DICER is the main processing enzyme for miRNA biogenesis and inhibiting its activity will reduce the activity of all miRNAs and not just miR-21. To ensure that our model is resistant to this possibility, we added a counter-screening against DICER to ensure miR-21 specificity of the model.33 For this, we trained a specialized model on data from an assay regarding DICER-mediated maturation of pre-miRNA34 to predict inhibitory activities against the DICER as a way to identify and avoid unwanted inhibitory effects. The performance of this model is shown in Table 3.Table 3Performance of toxicity and DICER inhibition models on their corresponding test setsModel# TaskROC-AUCPrecisionAPDICER single task10.663112.2212.53∗Tox multitask580.740841.1338.41Tox recommended50.748338.2738.73∗The models belonging to the toxicity category are comparable. Asterisks indicate best performance.

Performance of toxicity and DICER inhibition models on their corresponding test sets

## Section: Results › Auxiliary models for selecting molecule candidate: Toxicity modeling results

It is imperative that candidates for drug development are non-toxic and have as few off-target interactions as possible. As a way to filter any unwanted inhibitory effects on selected targets that could lead to cell toxicity, we trained two toxicity models. In order to determine molecular toxicity against cell viability, we used data from HepG2, a liver cell line that is used as a standard model. Moreover, we trained additional auxiliary GCNN models on the Tox21 dataset,20 which includes 58 different toxicity tasks, with the purpose of filtering compounds that may be broadly toxic to cells. Overall, the molecules with few toxicity predictions (out of 58) and the lowest uncertainty on HepG2 toxicity prediction pass satisfy this filter. The performance of these two models is described in Table 3. As shown in Table 3, the model trained on the recommended tasks is capable of predicting HepG2 toxicity with a higher average precision (AP). This model is used to predict HepG2 toxicity and uncertainty, whereas the multitask model is used to perform the remainder of the toxicity predictions.

## Section: Results › Selecting diverse candidates by clustering the learned small molecule embeddings

Once the virtual screening model and the auxiliary models have been trained, they can be used to screen unseen molecules for their potential as drug candidates. Given its large and diverse collection of drug-like and synthesizable compounds, we used the ZINC15 library for our virtual screening; however, we also included compounds from the Asinex library, which represents an out-of-distribution collection and allows us to assess the generalizability of our model. We used our trained model to screen these datasets for suitable molecules that are most likely to specifically inhibit miR-21 activity with fewer potential side effects and least likely to cause overt toxicity. We first used our multitask virtual screening model trained on the seven recommended tasks to predict miR-21 activity inhibition across nine million molecules in silico.

To obtain a more complete understanding of how diverse the inference molecules are, we performed unsupervised analysis and clustering of the molecular embeddings learned by the model. This analysis also enabled us to select molecules from various regions of the molecular space. To accomplish this, the embedding features of the trained model were extracted, projected into a two-dimensional (2D) uniform manifold approximation and projection (UMAP) space for visualization, and clustered using the k-means algorithm. By separating molecules into clusters, different regions of the molecular space can be accessed to select more diverse molecules for follow-up and testing (Figure 4). In Figure 4A, this molecular space is depicted using the positively predicted candidates from the ZINC database, which occupies a wide range of the embedding space. Figure 4B depicts the same embedding space but for the molecules used for model training, showing the overlap between the positive and negative compounds in the training set. In Figure 4C, we have shown clusters within the feature space as well as the top eight compounds that were selected from these clusters using the RiboStrike algorithm.Figure 4UMAP of the inner features of the model for the inference and training data for(A) ZINC data predicted to be active as the candidate space to select from, (B) the training data and the positive molecules from the FDA-approved set, showing that the candidate space spans the same area as the training set, and (C) the 10 clusters applied to this space for the inference sets (ZINC and Asinex) and the final selected molecules from these clusters to ensure diversity in selection.

UMAP of the inner features of the model for the inference and training data for

(A) ZINC data predicted to be active as the candidate space to select from, (B) the training data and the positive molecules from the FDA-approved set, showing that the candidate space spans the same area as the training set, and (C) the 10 clusters applied to this space for the inference sets (ZINC and Asinex) and the final selected molecules from these clusters to ensure diversity in selection.

## Section: Results › Assessment of the learned small-molecule embeddings and selection of hit compounds for further validation

It is evident from Figure 4A that the molecules from the ZINC database that have been predicted to be positive cover most of the projected space, demonstrating that the model is not learning a singular molecular feature. It is also apparent that FDA-approved drugs22 are concentrated in certain clusters, which likely makes the selection of hit molecules from their vicinity favorable. Moreover, the positive and negative training data distributions in Figure 4B have a substantial overlap, which highlights the challenge in virtual screening for miR-21. By clustering the hit molecules into 10 groups across the embedding space, we ensured that our selected hit compounds were sampled from varying clusters and therefore retained molecular diversity.

Using clustering as the basis for the selection of molecules, those hit compounds that are predicted to affect the activity of miR-21 with high confidence were selected and virtually screened against DICER inhibition and cellular toxicity. To conclude, we selected a total of 10 molecules across the two inference datasets (ZINC and Asinex) specifically from embedding clusters where FDA-approved molecules are well represented. We also required them to have low uncertainty in predicted inhibition of miR-21’s activity, with few or no toxic activity predictions and without predicted activity against DICER. Overall, six molecules were selected from the ZINC dataset and four from Asinex. Of these, we successfully acquired eight molecules, six from ZINC and two from Asinex. We ensured that none of these molecules had previously been studied in this context and by and large represented new chemical entities. The selected molecules are identified by their IDs and SMILES in Table S3.

## Section: Results › RiboStrike training on miR-122 data for generalization and counter-screening purposes

While we had focused the bulk of our study to training RiboStrike against the oncogenic miR-21, the platform itself is general in concept and can be applied to other miRNAs or even other RNAs, for which activity can be measured in scalable formats. To demonstrate this possibility, we trained RiboStrike using an NIH dataset that measured miR-122 activity using a reporter system, similar to the dataset we had used for miR-21. As shown in Figure S4, RiboStrike achieved a performance comparable to the one we achieved for miR-21, with regard to recall and true-negative rate. In addition to establishing the possibility of extending RiboStrike to other miRNA targets, this model also allowed us to assess the target selectivity of our predictions between the miR-21 and miR-122 models This counter-screen enabled us to confirm that the selected miR-21-inhibitor molecules were specific to miR-21 and did not affect other miRNAs in silico (Table S4).

## Section: Results › Gene expression profiling to measure miR-21 activity in response to treatment with the selected hit compounds

Since miR-21 is a post-transcriptional regulator of RNA stability, reducing its activity results in an increase in the RNA levels of its target regulon. To experimentally verify the anti-miR-21 activity of our selected compounds, we used an RNA sequencing (RNA-seq) strategy amenable to scalable gene expression profiling, namely QuantSeq-Pool. For experimental testing, we used MDA-MB-231 cells, an established model of triple-negative breast cancer metastasis that is known to be driven by miR-21.34 Inhibition of miR-21 in these cells should significantly reduce their metastatic potential. We first used CellTiter-Glo to calculate the IC20 (inhibitory concentration of 20%) for each of our compounds, to ensure a regimen in which the key cellular processes are not affected by each treatment. We then performed QuantSeq-Pool on MDA-MB-231 cells treated at IC20 for 72 h in biological replicates. We also included DMSO-treated control samples. For positive control, we used an established anti-miR-21 ASO and included a non-targeting ASO as control. Upon measuring the gene expression changes induced by each compound, we asked whether they caused a systematic effect on the expression of miR-21 target RNAs. We used the set of RNAs that are annotated as miR-21 targets (based on Targetscan35) to perform gene set enrichment analyses (Figure S3). As expected, in the miR-21 ASO samples, we observed a significant enrichment of miR-21 targets among genes that were upregulated upon treatment. From the eight selected compounds, two show miR-21 target upregulation similar to that of the ASO, and a total of five show some activity (with a confidence score of over 85%). Based on these results, our model has a hit rate of 62.5%, higher than the in silico predicted precision score of 20.93% for our model.

## Section: Results › Reporter assays for targeted measurement of miR-21 activity in dose-response assays

For the five compounds showing anti-miR-21 activity based on RNA-seq data, we also used a reporter assay for an independent confirmation at multiple doses. For this, we designed a GFP reporter harboring two miR-21 recognition sites in its 3′ untranslated region (UTR) and transfected it into MDA-MD-231 breast cancer cells. This construct also drives the expression of an mCherry gene, which serves as an endogenous control for the construct.36 Through the use of miR-21 ASOs, non-targeting ASOs, and flow cytometry, we confirmed that inhibiting miR-21 resulted in a significant increase in GFP expression in these reporter cell lines. We then performed this experiment for each compound separately. As shown in Figure 5A, three (Ribo21D-1, Ribo21D-2, and Ribo21D-3) of the five compounds also showed significant dose-dependent activity against miR-21. Taken together, our platform showed an experimentally confirmed hit rate of 37.5% for entirely new chemical entities that were predicted in silico.Figure 5Experimental validation results(A) Dosage response assay in reporter cell lines for Ribo21D-1, Ribo21D-2, and Ribo21D-3.(B) Enrichment and depletion patterns of putative miR-21 targets across gene expression changes for anti-miR21 as well as Ribo21D treatments (left). For this analysis, gene expression changes (log2 fold changes) were first sorted and divided into equally populated bins, from downregulation (left) to upregulation (right). For each analysis, the mutual information value (in bits) and its associated Z score are provided. The heatmaps show the enrichment and depletion patterns from the onePAGE package. Blue marks depletion and gold marks enrichment. Expression bins with statistically significant depletion or enrichment of miR-21 putative targets are marked by a dark blue or red border. As an alternative visualization, we have also shown the logFC values for the miR-21 targets and the background set of genes (right). The p values were calculated using t test.(C) Expression of empirically determined miR-21 targets (microCLIP37 plus anti-miR transfections) in response to the top three compounds.(D) Expression of miR-21 determined using small RNA-seq across the three treatments. The p values were calculated using DESeq2.(E) In vivo lung colonization assays were used to measure impact of Ribo21D-1 on lung metastasis. Normalized lung photon flux, which measures luciferase activity in labeled cancer cells, as a function of time for each cohort (n = 5) is shown. Two-way ANOVA and Mann-Whitney U tests were used to assess statistical significance. Also shown is a representative mouse and lung image.

Experimental validation results

(A) Dosage response assay in reporter cell lines for Ribo21D-1, Ribo21D-2, and Ribo21D-3.

(B) Enrichment and depletion patterns of putative miR-21 targets across gene expression changes for anti-miR21 as well as Ribo21D treatments (left). For this analysis, gene expression changes (log2 fold changes) were first sorted and divided into equally populated bins, from downregulation (left) to upregulation (right). For each analysis, the mutual information value (in bits) and its associated Z score are provided. The heatmaps show the enrichment and depletion patterns from the onePAGE package. Blue marks depletion and gold marks enrichment. Expression bins with statistically significant depletion or enrichment of miR-21 putative targets are marked by a dark blue or red border. As an alternative visualization, we have also shown the logFC values for the miR-21 targets and the background set of genes (right). The p values were calculated using t test.

(C) Expression of empirically determined miR-21 targets (microCLIP37 plus anti-miR transfections) in response to the top three compounds.

(D) Expression of miR-21 determined using small RNA-seq across the three treatments. The p values were calculated using DESeq2.

(E) In vivo lung colonization assays were used to measure impact of Ribo21D-1 on lung metastasis. Normalized lung photon flux, which measures luciferase activity in labeled cancer cells, as a function of time for each cohort (n = 5) is shown. Two-way ANOVA and Mann-Whitney U tests were used to assess statistical significance. Also shown is a representative mouse and lung image.

## Section: Results › Total RNA and small RNA-seq for deeper analysis of the top three anti-miR21 compounds

To perform a high-resolution analysis of gene expression changes, we performed total RNA-seq for MDA-MB-231 cells treated with the three validated compounds (Ribo21D-1, Ribo21D-2, and Ribo21D-3) as well as DMSO control cells, in biological triplicates. We also performed RNA-seq for cells transfected with anti-miR21 ASOs and non-targeting controls (also in triplicates). First to confirm our results from QuantSeq-Pool and the ability of these compounds to decrease miR-21 activity, we defined a putative miR-21 target regulon by combining predictions from TargetScan35 and miR-DB.38 We then assessed the changes in the expression of this putative target regulon across each treatment. We performed this analysis in two ways: first, we performed the gene set enrichment analysis we have previously described,39 where the genes are sorted based on their log fold changes in each treatment and divided into equally populated bins. The enrichment or depletion of the target regulon is then assessed and visualized for each expression bin. The resulting heatmap showed an expected depletion in the leftmost bins (i.e., genes with lower expression upon miR-21 inhibition) and significant enrichment in the rightmost bins (i.e., genes with increased expression). The overall statistical association was measured using mutual information and the associated Z score (Figure 5B, left). In all three cases, we observed a significant depletion and enrichment pattern, mirroring the pattern observed for the ASO positive control. As a complementary analysis, we also performed t test between the log fold change (logFC) values for the putative miR-21 targets and the rest of the transcriptome. Consistent with our gene set enrichment analysis, all three treatments significantly increased the expression of this putative regulon above background (Figure 5B, right).

To ensure that our results were not biased by our selection of putative miR-21 targets, we also assembled an empirical miR-21 target regulon. For this, we intersected mRNAs bound by RNA-induced silencing complex (RISC) complex loaded with miR-21 based on the microCLIP dataset37 with those upregulated in our cells upon transfection with the anti-miR21 ASO. Similar to the putative regulon, this empirical miR-21 target set showed a similarly significant increase in their expression in each of our treatments (Figure 5C). Together, our results confirm the role of our hit compounds in increasing the expression of miR-21 regulon, which is consistent with the lower activity of this miRNA.

These compounds may be affecting miR-21 expression or activity. In the former, we expect reduced miR-21 levels due to a reduction in its biogenesis, whereas, in the latter mechanism, miR-21 levels do not change. The anti-miR21 ASOs are an example of this mechanism as they bind and sequester miR-21 and reduce its activity but not expression. To determine whether these compounds are working upstream or downstream of miR-21 and whether their effect is specific to miR-21, we performed small RNA-seq to profile miRNAs upon treatment of MDA-MB-231 cells in biological triplicates. As shown in Figure 5D, two out of three compounds, namely Ribo21D-1 and Ribo21D-3, resulted in a significant reduction in miR-21. However, a broader look at all miRNAs revealed that Ribo21D-3 resulted in a significant reduction in the expression of multiple additional miRNAs (Figure S3). Ribo21D-1, however, proved to be quite selective against miR-21, as no other miRNA was observed to be downregulated upon treatment. We did observe higher expression of four miRNAs, namely miR-663, miR-3196, miR-1908, and miR-941; however, the higher expression of these miRNAs is downstream of miR-21 downregulation. This is because these miRNAs are also upregulated upon anti-miR21 transfection, resulting in logFC values of 0.7, 1.1, 1.3, and 1.35 for these miRNAs, respectively. Together, our results confirm the anti-miR-21 activity of our selected compounds and highlights the fact that these compounds likely function through independent mechanisms. Ribo21D-1 is a selective inhibitor of miR-21 biogenesis, Ribo21D-2 acts downstream of miR-21 modifying its activity, and Ribo21D-3 is a non-specific regulator of miRNA biogenesis and lowers the expression of several miRNAs. This diversity in mechanism of action is consistent with our effort in selecting diverse compounds from our virtual screening hits.

## Section: Results › Measurement of anti-metastatic activity in xenograft mouse models

As mentioned earlier, miR-21 is a driver of metastasis in breast cancer. Therefore, we expect the inhibition of this miRNA to result in lower metastatic potential in breast cancer. To confirm this, we treated MDA-MB-231 breast cancer cells for 72h with the most promising candidate molecule, Ribo21D-1. We then injected these cells, along with DMSO-treated controls, into immunocompromised NOD-SCID gamma (NSG) mice via their tail-veins. We used in vivo imaging to monitor the colonization and growth of cancer cells in the lungs of mice over a period of roughly 40 days. As shown in Figure 5E, we observed that, consistent with anti-miR-21 activity, pre-treating breast cancer cells with Ribo21D-1 resulted in a significant reduction in their lung colonization capacity. Therefore, this compound not only reduced miR-21 expression and activity, as measured by small RNA-seq, RNA-seq, and reporter assays, but also reduced metastatic lung colonization in xenografted mice (Figure 5E). Together, our findings establish the utility of RiboStrike as an effective platform for discovering compounds against miRNAs.

## Section: Discussion

In light of the dynamic structure and small size of miRNAs, the discovery of inhibitory small molecules against them presents a number of challenges. This is further compounded by the fact that miRNA ligands do not necessarily interfere with the function and activity of miRNAs. Considering this, we propose discovering candidate hits that instead focus on targeting miRNA activity. The goal of this study was to implement a virtual screening platform that leverages deep learning to enable the selection of early hit candidates out of a large collection of diverse molecules. Multiple methods were implemented in order to ensure the practicality of the computational methods, as well as rigorous experimental characterization, resulting in the validation of multiple compounds in vitro and for our top hit also in vivo. The first step involved the use of deep-learning models to train on a large number of small molecule datasets to learn the chemical language underlying miR-21 activity. We also introduced a new task recommendation technique, which identified the optimal configuration for combining datasets to maximize training potential. The third methodology involved calculating uncertainty for all predictions made by the models, which enabled the ranking of molecules in spite of their binary nature. To finalize, the internal features of the model were used to represent molecules during inference, and clustering of these embedding features allowed the selection of a diverse set of molecules for experimental testing. Finally, we conducted additional training of the RiboStrike model using miR122 inhibitor data. The objective of this model was to filter potential miR-21 activity inhibitors and ensure the selectivity of the chosen molecules. It is crucial to note that the primary aim of this project was not to identify molecular binders of miR-21 but rather to uncover molecules capable of inhibiting miR-21 activity. Consequently, these molecules could potentially bind to an unidentified regulator of miR-21 to produce the desired effect. In total, the RiboStrike platform identified multiple hit candidates that were subsequently confirmed, demonstrating the advantage of using graph-based deep learning to identify hidden patterns of molecular hits against the activity of miRNAs without the need for sequence reading or structural information. The ultimate objective of utilizing miR-21 data is to construct a model capable of identifying molecules exhibiting ASO mimicry, rather than focusing on elucidating the precise molecular mechanisms behind miR-21 inhibition. Additionally, we integrated data from miR-122 and DICER, incorporating biological insights into potential inhibitors with fewer cellular side effects. It is likely that these compounds target molecular pathways upstream of miRNAs that regulate their processing, lifespan, and function. Therefore, once identified and validated, these hits can be used as toy compounds to identify their direct targets (e.g., using CRISPRi screen with miRNA reporter expression as readout).40 The not only is identification of these direct targets required for additional genetic and biochemical validations of their impact on the activity of specific miRNAs but this knowledge provides an avenue for further optimization of our tool compounds using traditional SAR and medicinal chemistry. Therefore, this approach may provide us with a better understanding of the mechanisms by which miRNAs are regulated through the discovery of crucial unknown players upstream.

## Section: Experimental procedures › Resource availability › Lead contact

Further information and requests for resources and reagents should be directed to and will be fulfilled by the lead contact, Hani Goodarzi (Hani.Goodarzi@ucsf.edu).

## Section: Experimental procedures › Resource availability › Materials availability

This study did not generate any new unique reagents.

## Section: Experimental procedures › Resource availability › Data and code availability

The data and code used in this work are available through our GitHub repository at https://github.com/LumosBio/RiboStrike. The version of this code and data at the time of publication is also captured and saved through Zenodo at https://doi.org/10.5281/zenodo.10068059.41

## Section: Experimental procedures › Data sources

Three categories of data are used throughout the RiboStrike pipeline: virtual screening datasets, off-target interaction datasets, and inference datasets, which are explored further in the following subsections. Each dataset is preprocessed to contain canonical SMILES as well as appropriate binary labels for the activity of molecules, and the details of this process can be found in the supplemental information. SMILES is a widely used molecular descriptor that encapsulates the structure of a molecule, serving as an input for models. Graph convolutional neural networks (GCNNs) utilize the SMILES input to create a graph representing the molecule, which in turn is used for feature representation learning. For instance, the SMILES descriptor "Cc1cc(C(=O)CSc2ccccn2)c(C)n1C" represents the molecular structure of Ribo21D-1.

## Section: Experimental procedures › Virtual screening training datasets

The datasets used to train the main virtual screening model or to help its performance via multitask learning are as follows.•miR-21 Data: primarily, an HTS (high throughput screening) dataset from miR-21 inhibition screening as a target is used in this study, a data repository originating from National Center for Advancing Translational Sciences (NCATS) and deposited in PubChem (ID: AID 228917). The aim of this assay had been the discovery of molecules with an inhibitory effect on miR-21 to finally induce cell apoptosis and tumor suppression. They used a cell-based firefly luciferase reporter gene assay optimized for qHTS (quantitative high throughput screening).•Cancer-related data: to assist the multitask training process, different cancer-related assays are collected from PubChem and the PCBA dataset. These assays include 20 tasks directly from the PubChem database, and 38 cancer-related tasks from the PubChem BioAssay (PCBA) dataset.18.•PCBA dataset: PCBA is a collection of datasets aggregated from PubChem consisting of the biological activities of small molecules generated by high-throughput screening. In this work, a subsection of PCBA with 128 bioassays is used with over 400,000 molecules, similar to the previous benchmarking methods.18 This dataset was selected due to its size, high number of tasks, and high molecular overlap with the miR-21 dataset. Due to these features, this dataset can be combined with the miR-21 dataset to create a large non-sparse training set for multitask learning.

Two further datasets are created from the mentioned dataset; the “combined” dataset from aggregating all data points, and the “recommended” dataset from algorithmically selecting tasks from the combined dataset using the task recommendation approach (discussed in the “prediction-based task recommendation” section). The preprocessing code for the miR21 data can be found in the GitHub repository under preprocessing_mir21 script. Once preprocessed, these data are augmented with the auxiliary datasets in the preprocessing_merge_pcba script in the GitHub repository.

## Section: Experimental procedures › Off-target interactions datasets: Toxicity and DICER inhibition

To increase the probability of any predicted bioactive molecule to be a drug candidate, the toxicity properties and the effect of these molecules on the DICER’s function are predicted. Therefore, two datasets related to these subjects are used for training in this work:•Toxicity in the twenty-first century (Tox-21): the most popular source available for the analysis of the toxicity of molecules.20 This dataset consists of 58 distinct tasks, each tested on an important protein target of humans. Candidate drugs that interact with those targets are likely to cause side effects and cellular toxicity. Therefore, we used 58 tasks from tox21 to filter out molecules that would show side effects in future steps.•DICER dataset: the DICER protein plays an important role in the maturation of several RNAs, not just miR-21. Therefore, if a candidate drug decreases the activity of the miR-21 by inhibiting the DICER protein, it would show significant side effects downstream. The dataset for this task is taken from PubChem data source of AID 1347074.21 This dataset was created using click chemistry and was selected due to the fact that this assay identified inhibitors of DICER based on pre-miR-21.

The preprocessing code for the auxiliary datasets can be found in the preprocessing_merge_pcba script of the GitHub repository.

## Section: Experimental procedures › Inference data: Sources for drug candidate selections

There are multiple datasets used in this work for the drug candidate selection:•ZINC: ZINC database is a diverse molecular library typically used for virtual screening.16 It contains millions of molecules that are indexed for search and properties. We used the drug-like subset (molecular weight: 250–500 g/mol, logP: −1 to 5) of the ZINC15 database, consisting of nine million molecules that had three-dimensional (3D) representations, standard reactivity, reference pH, a charge of −2 to +2, and were in stock for purchase.•Asinex: Asinex is a molecular library vendor that sells varieties of different classes of molecules, including macrocycles, alpha helix mimetics, and peptidomimetics. This vendor also offers a small-molecule library specifically designed to target RNA,19 which is a suitable candidate for this project. Moreover, the candidates in this set are different from the training set, allowing for testing the model’s generalizability.•FDA approved: this dataset was taken from a study22 that found 86 molecules that were suppressors of miR-21 activity from a pool of 696 compounds from the Bioactive Compound Library and 262 compounds from FDA-approved Drug Library. In this work, these molecules are deleted from the mentioned inference datasets, to avoid selection of previously discovered molecules. Moreover, these molecules will be used to assist the selection of the final molecules by identifying the favorable clusters as described in the “molecule selection” section.•SAR sample: this dataset originates from a study23 that takes two molecules that are known inhibitors of miR-21 and uses SAR to optimize these molecules and assist in overcoming chemoresistance in renal cell carcinoma. Overall, 37 molecules are tested and shown to be active, which can create a small validation set for this work.

After training, the inference data are loaded and preprocessed with the same steps as the training data. Then the trained model is used to make predictions on the inference sets as well as to attach uncertainty values to these predictions. The inference script within the GitHub repository contains the code for these necessary steps.

## Section: Experimental procedures › Graph convolutional neural network training

In recent years, GCNNs have proved to be helpful in learning representations from small molecules and modeling tasks such as virtual screening,26 molecular property prediction,25 and drug-target interaction.42,43 This success is owed to two facts: first, small molecules are inherently similar to graphs, with atoms represented as nodes and bonds represented as edges, making GCNNs suitable tools for handling this data type. Second, the feature extraction in the GCNN model, which is inspired by traditional circular fingerprint extraction from molecules, results in useful and often superior inner features due to the automatic representation learning aspect of deep learning.14,24

In this work, the GCNN implementation from the DeepChem library is used.44 In this model, the molecules are converted to graphs and atoms, then featurized to include features such as atom type, number of directly bonded neighbors, implicit valence, formal charge, and hybridization type. Isomeric information is also added to the features in the form of a vector with length of three (whether chirality is possible, right-hand, and left-hand). The model is trained in a multitask learning manner, with the intent to share the representation learning mechanism between multiple datasets and increase the efficiency of the training and the performance of the final model. This multitask learning approach is paired with an in-house algorithm that recommends a unique grouping of the tasks in multitask learning to optimize the final performance of the model. The logits of the model are viewed through the lens of evidential deep learning to attach uncertainty values to each prediction, The code used for model training can be found in the training script in the RiboStrike GitHub repository.

The molecular data are split using Murcko scaffolds to create training, validation, and test sets. The hyper-parameters of this model as well as the length of the training are found through hyper-parameter optimization in a grid-search manner via monitoring the performance of the model on the validation set. The code for this optimization can be found in the hyper_opt script within the GitHub repository (more on hyper-parameter optimization can be found in the supplemental information).

## Section: Experimental procedures › Evaluation metric

The metric used for evaluation in this work is the AP score. This metric computes the area under the precision-recall curve and was chosen due its fairness toward imbalanced datasets, where the positive label discovery is of importance. This is the case with most virtual screening tasks, where the number of active molecules is often much lower than the number of inactive molecules, resulting in highly imbalanced datasets. Moreover, discovery of these active candidates is of utmost importance in an early drug-discovery pipeline since these candidates will be passed on to the next steps of the drug discovery process. Therefore, AP score is favored in this work for comparison of models, different architectures, or different epochs during training. The results are also reported for accuracy, recall, precision, and the area under the receiver operator curve (ROC-AUC).

## Section: Experimental procedures › Optimizing the tasks for multitask learning

Multitask learning has proved to be beneficial in many instances via providing multiple tasks for the model to simultaneously learn from, with the hope that the learned representations for these tasks benefit from being shared within the same model. However, this is not the case in all scenarios and, in some cases, negative transfer occurs, where multitask learning hurts the performance of a given task when compared to single-task learning.31 In this work, to address the problem of negative transfer, the method of prediction-based task recommendation is proposed, which narrows the number of tasks selected for multitask learning via recommending a few tasks in an algorithmic manner.

## Section: Experimental procedures › Prediction-based task recommendation

To begin the process of task recommendation and selection of fewer training tasks, a multitask learning model is trained on all available tasks. After training, one target task is selected (e.g., miR-21 dataset) and inference is performed on the validation set of this target task. Since the model is trained on multiple tasks, it will have multiple predictions for each input molecule, each assigned to one input task. Given N total training tasks and M molecules in the target task’s validation set, the predictions of the model will then have a shape of M✖N, with each row representing the output of the sub-model assigned to one input task, denoted by Outputi. After this output is calculated, each Taski is scored using the scoring metric in Equation 1.(Equation 1)Scorei=AveragePrecisionScore(Labeltarget,Outputi)Here, Labeltarget denotes the ground truth labels for the target task. As can be seen from this equation, the labels are kept constant on the target set while the sub-model changes, which is the main difference between this method and simple inference. Using this scoring mechanism, the predictions of different sub-models are compared to the ground truth labels of the target task, with the sub-models that have more similar predictions to the target labels having a higher score. Through the identification of sub-models with similar predictions, this approach identifies their corresponding training tasks and selects the highest-scoring tasks for training. The recommended tasks are selected via applying a threshold of mean plus two standard deviations to the scores. This threshold is arbitrary and can be replaced with a simple selection of top K scores. The recommended tasks are then passed on as training data to the hyper-parameter optimization and training step for the final model. This recommendation process is repeated for the toxicity model as well, with the target task of HepG2. The code for this recommendation algorithm can be found in the training script of the RiboStrike GitHub repository.

## Section: Experimental procedures › Molecule selection: Inference and uncertainty prediction

After different categories of models are trained, the final models are used to predict the properties of the molecules from the inference datasets. All training data, as well as the FDA-approved data,22 are removed from the inference datasets to avoid the selection of redundant or previously discovered molecules. During the inference process, a binary label is predicted for each given molecule, reflecting its predicted effect on miR-21’s function. Having only binary labels to distinguish between different molecules is problematic, since molecules with the same predictions (e.g., active) become indistinguishable and no ranking can be assigned to the molecules for further drug candidate selection.

In order to overcome the selection challenges, an uncertainty prediction method is applied on the last layer of the model. To do so, evidential deep learning is used,30 which applies a Dirichlet distribution on the class probabilities and computes uncertainty for each prediction. This uncertainty score ranges from zero to one, with lower scores demonstrating more certain predictions. With this uncertainty score, the predictions become distinguishable and the molecules that are predicted to be active with low uncertainty become desirable. The code for this molecule selection process is located within the inference script of the RiboStrike GitHub repository.

## Section: Experimental procedures › Molecule selection: Neural fingerprints clustering

After the uncertainty is predicted, one challenge is faced, which is the lack of diversity in the top selected molecules with low uncertainty. The reason for this phenomenon is that similar molecules result in similar predictions and uncertainty, and the most certain predicted molecules are similar to each other and they populate the top of the certainty ranking list. This creates a problem in the further stages and specifically in vitro screening, where diversity among the candidates is needed to increase the chance of activity against different targets.

To enforce diversity within the selected molecules and create variety within the final selection, the molecules are clustered and a few molecules are selected from some of the clusters. To do so, the neural fingerprints of the molecules are extracted from the Graph Gather layer of the trained model. This fingerprint is the inner features of the model for an input molecule and is a numerical vector that can meaningfully represent this molecule. Neural fingerprint clustering allows the molecules belonging to different clusters to both be structurally different and exist in different locations within the feature space of the trained network. After the features are extracted, KMeans (K = 10) clustering is applied to the features, then visualized using 2D UMAP, resulting in 10 clusters formed from the inference molecules. The code for ensuring diversity within the final selection is located under the clustering script within the GitHub repository.

## Section: Experimental procedures › Molecule selection: Five criteria for final selection

After the molecules are clustered and uncertainty and bioactivity are predicted for all of them, five different criteria were checked for the final molecules to be selected:(1)Potency as miR-21 activity inhibitor: the selected molecules should be predicted to inhibit the function of miR-21.(2)Certainty: the molecules that had the least uncertainty in each cluster were considered.(3)Diversity: molecules should belong to different clusters in regard to the clustering of the neural fingerprint. Clusters that include more of the FDA-approved molecules are more likely to be selected from.(4)Pass majority of toxicity tests: the selected molecules are more likely to be predicted as non-toxic in most of the toxicity tests with low uncertainty for specifically the HepG2 test.(5)Low chance of interaction with miR-122: the selected molecules are predicted to be specific to miR-21 and do not interact with other miRNA, specifically miR-122.(6)Low chance of inhibiting the DICER: the selected molecules are more likely to be predicted to not affect the function of the DICER with low uncertainty.

Following these criteria, the inference molecules are first narrowed down to those predicted to be active with high certainty and then filtered via selecting top molecules from each 10 clusters. Afterward, the final molecules are selected from this list with consideration of toxicity and DICER activity and their uncertainties. In the end, eight molecules are selected from the inference datasets (ZINC and Asinex) and progress to the in vitro screening stage.

## Section: Experimental procedures › Cell culture

The MDA-MB-231 (MDA-parental, ATCC HTB-26) human breast cancer cell line; its highly metastatic derivative, MDA-LM245; its triple reporter version, MDA-MB-231tr; and HEK293T cells (ATCC CRL-3216) were cultured in Dulbecco’s modified Eagle’s medium supplemented with 10% fetal bovine serum (FBS), penicillin, streptomycin, and amphotericin B. Cells were all incubated at 37°C at 5% CO2 in a humidified incubator.

## Section: Experimental procedures › CellTiter-Glo cell viability assay

MDA-MB-231 cells were seeded at 1,000/well in white opaque 96-well plates (Corning 3917) and treated with serial dilutions of drug candidates ranging from 3.2 pM to 1 mM for 72 h in triplicate. Cell viability was measured using CellTiter-Glo 2.0 Assay (Promega G9243) to find IC20 concentrations.

## Section: Experimental procedures › High-throughput sequencing data generation

MDA-MB-231 cells were seeded at 3,000/well in clear 96-well plates and treated with drug candidates at IC20 for 72 h in duplicate. Controls were transfected with oligo inhibitors targeting either mir-21 or non-targeting controls in duplicate. For transfection of control wells, we added 0.5 μL of 100 μM oligo inhibitor, 100 μL of OptiMEM (Thermo Fisher Scientific 31985088), and 2.5 μL of Lipofectamine 2000 (Thermo Fisher Scientific 11668019), which were incubated together for 20 min at room temperature. Cells were then incubated at 37°C for 72 h. RNA was extracted using the Quick-RNA 96 kit (Zymo Research R1052) and concentrations were determined using Nanodrop. Libraries were prepared using the QuantSeq-Pool Sample-Barcoded 3′mRNA-Seq kit (Lexogen 139) with 10 ng of input RNA. Libraries were sequenced using NovaSeq 6000 SP (100 cycles).

## Section: Experimental procedures › High-throughput sequencing data generation for RNA-seq and smRNA-seq

MDA-MB-231 cells were seeded at 1 × 105/well on 24-well plates and treated with either Ribo21D-1, Ribo21D-2, or Ribo21D-3 at 0.1 μM for 72 h in triplicate. Controls were transfected with oligo inhibitors targeting either mir-21 or non-targeting controls in triplicate. For transfection of control wells, we added 0.5 μL of 100 μM oligo inhibitor, 100 μL of OptiMEM (Thermo Fisher Scientific 31985088), and 2.5 μL of Lipofectamine 2000 (Thermo Fisher Scientific 11668019), which were incubated together for 20 min at room temperature. Cells were then incubated at 37°C for 72 h. RNA was extracted using Direct-zol Mini-prep Kit (Zymo Research R2051). RNA RIN values and concentrations were assessed using the Agilent D1000 ScreenTape System and an Agilent Tapestation 4200 according to manufacturer’s instructions. RNA-seq libraries were prepared using the SMARTer Stranded Total RNA-seq V3-Pico Input Mammalian: cDNA kit (Takara 634486) with 5 ng of input RNA. The smRNA-seq (small non-coding RNAs) libraries were prepared using the SMARTer smRNA-Seq Kit (Takara 635031) with 30 ng of input RNA. Libraries were sequenced on a HiSeq4000.

## Section: Experimental procedures › QuantSeq-Pool data analysis

The QuantSeq-Pool data were demultiplexed and preprocessed using an implementation of the pipeline provided by Lexogen (https://github.com/Lexogen-Tools/quantseqpool_analysis). The outputs of this step are gene-level counts for all samples. The raw counts matrix used for differential expression analysis was prepared using the DESeq2 package.46 The logFCs from multiple differential expression comparisons used gene set analysis (Figure 5A).

Finally, we aimed to sort molecules based on their systematic effect on expression of miR-21 target mRNAs through gene set enrichment analysis. Thus, we downloaded TargetScan prediction of hsa-mir-21 3p target genes from miRBase dataset (miRBase: MI0000077). Then, we use a modified version of iPAGE39 (we call it onePAGE from here on) in which you can perform the gene set enrichment analysis powered by mutual information evaluation and statistical tests for a single gene set. The onePAGE analysis here reports enrichment of miR-21 target gene list in three bins of logFC values; from left to right, (0) lowest bin of log2FC (i.e., downregulated), (1) log2FC around zero (i.e., no expression change), (2) highest bin of log2FC (i.e., upregulated). After running this analysis for differential expression log2FC of all drugs and control conditions, we sorted drugs based on resulted Z score keeping miR-21 vs. negative control (nc) at the top (Figure 5A). From this step, we selected the top five drugs for further evaluation.

All scripts for preprocessing, differential expression, and onePAGE enrichment analysis are accessible in this GitHub repository (https://github.com/goodarzilab/targeting-miR-21-RNA-seq).

## Section: Experimental procedures › RNA-seq and small RNA-seq data analysis

For RNA-seq, salmon (v0.14.1) was used to measure gene expression (gencode v44 basic annotation). Tximport (v1.14) and DESeq2 (v1.24) were used to compare gene expression changes between treatments and controls. For putative targets, miR-21-5p targets from TargetScan7.1 and MirDB were downloaded from mirBase and combined into a unified set. onePAGE, as described above, was used to perform gene set enrichment analysis. For empirical targets, we used miR-21 microCLIP binding sites and intersected them with those upregulated upon anti-miR21 transfection.

For smRNA-seq, cutadapt (v3.5) was used to remove linkers and bowtie2 (v2.3.5). UMI-tools (v1.0.0) and UMICollapse were used to account for UMIs and remove duplicates. Annotated small RNAs were then counted and miRNA expression was compared using DESeq2 (v1.24).

## Section: Experimental procedures › Generation of MDA EGFPmiR-21 reporter cell line

The vector backbone for the reporter plasmids was generated from a vector with a bidirectional cytomegalovirus (CMV) promoter-driven lentiviral reporter, expressing eGFP and ΔlnGFR. This vector was a gift from David Erle.47 The ΔlnGFR ORF in the vector was replaced by a PuroR-T2A-mCherry fusion using Gibson assembly as previously described.48 In order to generate the eGFPmiR-21 reporter plasmid, two miR-21 binding sites were added to the end of eGFP using the NEBuilder HiFi DNA Assembly Cloning Kit. MDA-MD-231 cells were engineered to stably express the reporter plasmid using lentiviral delivery of the vector.•hsa-miR-21-5p•TCAACATCAGTCTGATAAGCTA•Sequences for reporter cell line generation were obtained from miRBase

## Section: Experimental procedures › FLOW cytometry analysis of miR-21 reporter cell line

MDA EGFPmiR-21 reporter cell lines were seeded at a density of 2 × 104 cells per well of a 96-well plate. Cells were treated for 3 days with serial dilutions of the six most promising drugs (dilutions determined by IC20 curves). Additionally, anti-miR controls (anti-mi21 and non-targeting) were also transiently transfected into cells using Lipofectamine 2000 (Thermo Fisher) according to the manufacturer’s protocol. Cells were collected after 3 days and fluorescence output was measured on a BD FACSCelesta flow cytometer.

## Section: Experimental procedures › Animal studies

All animal studies were performed according to IACUC guidelines (IACUC approval number AN194337-01G). Age-matched female NSG mice (Jackson Labs, 005557) were used for metastatic lung colonization assays. These assays were performed with MDA-MB-231 cells, which were seeded at 1.5 × 105 cells in two wells of a six-well plate on day 1. After 24 h 0.1 μM MCULE-9082109585 and 0.5% DMSO were added dropwise to one well each. After 48 h, MCULE-9082109585 and 0.5% DMSO medium was removed and the cells were prepped for tail vein injections. Cells were resuspended in 2 mL of PBS and each mouse received 5 × 104 cells/100 μL of PBS. Metastasis was measured by bioluminescent imaging (IVIS).


---

# Generative artificial intelligence and ethical considerations in health care: a scoping review and ethics checklist

- **Authors:** Yilin Ning, Salinelat Teixayavong, Yuqing Shang, Julian Savulescu, Vaishaanth Nagaraj, Di Miao, Mayli Mertens, Daniel Shu Wei Ting, Jasmine Chiat Ling Ong, Mingxuan Liu, Jiuwen Cao, Michael Dunn, Roger Vaughan, Marcus Eng Hock Ong, Joseph Jao-Yiu Sung, Eric J Topol, Nan Liu
- **Issuer:** The Lancet. Digital health
- **Type:** Scientific article
- **Published:** 2024-09-17
- **Language:** en
- **DOI:** 10.1016/s2589-7500(24)00143-2
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39294061/
- **Licence:** CC-BY

## Section: Abstract

The widespread use of Chat Generative Pre-trained Transformer (known as ChatGPT) and other emerging technology that is powered by generative artificial intelligence (GenAI) has drawn attention to the potential ethical issues they can cause, especially in high-stakes applications such as health care, but ethical discussions have not yet been translated into operationalisable solutions. Furthermore, ongoing ethical discussions often neglect other types of GenAI that have been used to synthesise data (eg, images) for research and practical purposes, which resolve some ethical issues and expose others. We did a scoping review of the ethical discussions on GenAI in health care to comprehensively analyse gaps in the research. To reduce the gaps, we have developed a checklist for comprehensive assessment and evaluation of ethical discussions in GenAI research. The checklist can be integrated into peer review and publication systems to enhance GenAI research and might be useful for ethics-related disclosures for GenAI-powered products and health-care applications of such products and beyond.

## Section: Introduction

In the past few years, development of Chat Generative Pre-trained Transformer (ChatGPT) and other chatbots powered by large language models (LLMs) have drawn the attention of the general public, researchers, and stakeholders to the fast developing technology of GenAI. GenAI differentiates from general AI technology due to its capacity to generate realistic content, such as text (eg, ChatGPT and Gemini), images (eg, Midjourney and DALL·E),1 and videos (eg, Sora).2 The promising capability of GenAI models are also being explored for their medical applications, such as for mental health,3 breast cancer,4 dietary care,5 and medical education.6

However, medical applications of GenAI raise additional ethical concerns due to the ongoing discussions on general AI. For example, the large data volume and user community of LLMs raise the stakes of privacy breaches, as exemplified by a brief ban of ChatGPT in Italy to address and clarify privacy concerns.7,8 GenAI-generated data might leak personal information if sufficient details were captured that almost reproduce real training samples.9 As GenAI is trained to generate realistic outputs based on patterns learnt from data and can create hallucinations (ie, incorrect and misleading outputs), ensuring factual accuracy for medical applications requires great effort.10 Stochasticity of GenAI output, vulnerability to prompt injections, and opacity of input data complicate the assessment of GenAI for clinical fairness, which is predominantly based on predictive performance in the current AI context.11 These factors lead to active discussions on, and urgent calls for, new guidelines, regulations, and legislations on GenAI,12–14 especially for health care and medical education.15–17

Emerging GenAI-powered technology has been quickly rolled out to a huge and diverse user community, which explains why there are enthusiastic discussions on its ethical implications on social media and within the research community. However, other GenAI methods, such as the generative adversarial network (GAN),18 have not been considered in current ethical discussions, even though these methods have been used in medical research and are subject to similar ethical considerations. Notably, GAN (and related GenAI methods)19 are often used as solutions to address some ethical concerns in medical research (eg, to protect privacy by masking images and videos,20,21 or by creating synthetic data).9,22,23 A closer investigation of existing discussions on GenAI that cause and mitigate ethical concerns would provide a more holistic view on this important topic, which could ultimately help identify actionable points for GenAI research. In this scoping review, we aimed to understand the responses of the research community to potential ethical issues of GenAI in health care. Informed by these findings, we developed an ethics checklist to operationalise existing ethical guidelines, which can be used by journals, institutional review boards, funders, and regulators to promote responsible GenAI research in health care and beyond.

## Section: Methods

Our systematic scoping review on ethical discussions associated with GenAI in health care followed the PRISMA extension for scoping reviews guidelines.24

## Section: Methods › Search strategy and selection criteria

We searched PubMed, Embase (Excerpta Medica Database, Ovid), Web of Science, and Scopus for articles written in English with a set of search terms associated with three main concepts: “AI ethics”, “generative AI”, and “healthcare” that were published between Jan 1, 2013, and July 25, 2023. Detailed definitions of the three concepts, search terms, and search strategy are described in the appendix (p 1).

We excluded articles that were not within the domain of health care, did not apply GenAI, or did not discuss ethical issues in relation to the use of GenAI in health care. We also excluded articles that were not peer reviewed, not published as research articles (eg, conference posters, conference abstracts, or book chapters), not full-length (ie, articles citing no more than ten references), or not written in English. The main aim of this scoping review is to understand the current ethical assessments in GenAI research and to inform future practice. Therefore, we restricted our scoping review to the published scientific literature that reflects a reasonable quality of ethical reporting accepted by the research community and that did not include grey literature (eg, preprints).

## Section: Methods › Data analysis

The articles we found were divided into three portions and screened based on title and abstract by three pairs of independent reviewers (ST and VN, YN and YS, and YN and DM), following the exclusion criteria. Uncertainties and conflicts were resolved via discussion with ST and YN. The included articles were further screened based on the full text with the same set of exclusion criteria.

From the included articles, we extracted information on seven variables pertaining to article type, GenAI, and ethics: (1) whether the article describes original research (including original empirical and theoretical GenAI research) or review-type articles (eg, reviews, viewpoints, or editorials that specifically covered GenAI); (2) data modalities of GenAI application; (3) GenAI models discussed; (4) role of GenAI (ie, whether it caused or resolved ethical issues); (5) ethical issues discussed; (6) if GenAI caused ethical issues and whether any solution was proposed; and (7) whether the article had ethical objectives or dedicated ethical discussions (as opposed to a brief mention of ethics in background information or general discussion). Based on (7), we further identified a subset of articles with a stronger ethical focus for subsequent checklist development. This subset included review-type articles aiming to discuss GenAI-related ethical issues, and original research either motivated by and framed around specific ethical considerations or discussed detailed ethical implications of GenAI.

To summarise the ethical issues discussed in the included articles, we categorised them through a codification system into nine overarching ethical principles that have been identified to be most pertinent across AI ethics guidelines and in application of AI in health-care settings.14,25 We have detailed the adopted definitions (panel 1) and the codes associated with each principle (panel 2), summarised based on the aforementioned discussion on ethics of AI for health care. Due to the focus on ethical concerns on LLMs in research in the past few years, we summarised GenAI application based on three general data modalities, namely text, image (including video), and structured (eg, tabular data, and signal data such as electrocardiogram or speech signal), to investigate any differences in associated ethical considerations. Information on the ethical principles discussed and the role of GenAI by data modality was analysed with evidence gap maps to understand the current research landscape in health care.

## Section: Methods › Checklist development

In a 2023 study that proposed an ethical framework of AI for health care for AI developers, the authors endorsed the need to work with health AI practitioners to develop ethical AI checklists as a means to operationalise considerations and solutions to ethical issues.26 Hence, to help address prominent gaps in GenAI research, we developed a checklist to promote systematic ethical assessments, named the Transparent Reporting of Ethics for Generative AI (TREGAI) checklist. By analysing the articles identified in our scoping review (especially those with a stronger ethics focus), we selected a set of well established ethical principles in the AI ethics literature to include in our checklist that are essential to, and operationalisable in, GenAI research in health care. We also highlighted the need to discuss solutions to the issues identified. Details on checklist development, specifically the choice of ethical principles and distinction from existing guides on AI, are described in the appendix (p 5).

## Section: Results

Our scoping review identified 1417 unique articles, of which 193 articles were included for analysis (figure 1). Detailed information extracted on these articles are presented in the appendix (p 10). The 193 articles included were published between Jan 1, 2018, and July 25, 2023; 162 articles are original research articles and the other 31 articles are review-type articles. 85 articles had dedicated discussions on or quantitative investigations of ethical issues, of which nine original research articles and 20 review-type articles had a stronger ethical focus (appendix p 10).

Although three articles discussed GenAI for more than one data modality (with two articles covering text and image and one article covering text, image, and structured data), most of the articles reviewed were dedicated to a single data modality when discussing ethical issues. Our analysis of these articles revealed notable differences in how researchers approach ethical concerns by data modality, especially on the ethical concerns discussed and the role of GenAI in causing or resolving these concerns (figure 2).

## Section: Results › GenAI for text data-based health care

41 of the 193 articles discussed the ethical considerations of GenAI applications for text data, with 20 articles describing methodological developments or applications of GenAI and the other 21 articles describing review-type work. Although some of these review-type articles used the general term GenAI, the main text and supporting evidence focused on LLMs. 28 articles investigated or had in-depth discussions on ethical issues; the other 13 articles only briefly touched on some ethical aspects.

Among the 41 articles that discussed ethical considerations, 29 focused on the ethical issues caused by LLMs (16 of which focused specifically on generative pretrained transformer models), covering a wide range of application scenarios, and considered the application of all nine ethical principles defined (panel 1; figure 2). Three articles also discussed ethical concerns such as the moral aspects (eg, compassion) of LLM outputs, human–AI interaction, and the rights of LLMs to be considered as coauthors in scientific papers (which we consider as a separate tenth category grouped as other). Of these, one paper only commented briefly on the need for ethical considerations in LLMs. Although all ethical principles are important, some are discussed more often than others, including non-maleficence (also referred to in the literature as benevolence), equity, and privacy, and some articles raised unique concerns related to general AI. In addition to generating medically inaccurate outputs,5,10 LLMs can cause harm by partial omission of input information.4 Much effort is required to assess the accuracy of LLMs for medical applications, including design of benchmark datasets and manual evaluations.10 The ability of LLMs to continuously adapt based on new knowledge raises concerns on the possibility for them to threaten the autonomy of patients and clinicians in medical settings.27

The ability of GenAI to work with flexible unstructured input and output provides unique opportunities to mitigate some ethical concerns. 15 of the 41 articles aimed to resolve some existing ethical issues (eg, confidentiality of medical data) by using LLMs and other GenAI (eg, GAN, autoencoder, or a diffusion model) to reduce privacy concerns by generating synthetic medical text, to reduce health-care disparities by providing accessible services and assistance, and to detect health-related misinformation. Specifically, some articles directly assessed human trust on LLMs as these models can generate human-like conversations28 or used LLMs to explain AI systems for improved trust and transparency.29 Although most articles focused on either identifying ethical issues caused by GenAI or proposing GenAI-based solutions, three articles discussed both to provide a more balanced perspective.

## Section: Results › GenAI for image and structured data-based health care

Unlike the diverse application scenarios of GenAI based on text data, for image and structured data, the use of GenAI focuses on data synthesis and encryption. Hence, most articles discussed the methodological developments of GenAI with a more distinctive and focused set of ethical issues.

Notably, more than half of the articles on image data (63 of 98 articles) and structured data (33 of 58 articles) only mentioned ethical considerations as a brief motivation for methodological developments or as a general discussion point (appendix p 10). The rest of the articles included more in-depth discussions or (mostly quantitative) evaluations of ethical issues. Among these 155 articles (as one article covered multiple modalities), 11 were review-type articles, of which ten articles reviewed methods that mentioned one or two ethical perspectives and only one article30 discussed detailed ethical concerns on GenAI applications.

Resolving privacy issues was the main aim of articles for two data modalities (74 articles for image data and 50 articles for structured data; figure 2), predominantly by generating synthetic data with GAN. Eight articles on image data and nine articles on structured data used GenAI to reduce bias (eg, by synthesising data for underrepresented subgroups in existing databases). Similar to LLMs, GenAI contributed to trust and transparency of image classifications by generating realistic images for explanations.31 Additionally, GenAI was used to improve accountability of, and hence trust in, image classification by improving input quality.32 For both data modalities, we did not see explicit discussions on resolving autonomy or integrity issues with GenAI and for structured data the articles did not have discussions on trust or transparency.

Only 11 articles for image data selectively discussed some of the ethical issues that GenAI can cause, without specific discussions regarding autonomy or integrity (figure 2). For structured data, only four articles discussed equity, privacy, or data security issues caused by GenAI. Only two articles on structured data included both the cause and resolving perspectives, discussing the ethical issues that might arise from limitations of the methods proposed, specifically the risk of biased representation of patient subgroups when synthesising data to resolve privacy issues. As data synthesis is proposed as a solution to medical data deficiency for research due to privacy and security concerns,22 multiple articles highlighted the need for data quality and reliability for downstream medical research.9,22,23,33 One article introduced metrics to quantify privacy preservation and utility for structured data, but more work is needed to extend for image or text modalities, and to preserve important characteristics of the original data and across small patient subgroups.34

## Section: Discussion

Despite the rising number of articles discussing ethical concerns on GenAI in health care, some important aspects are missing in the current literature. Our scoping review systematically summarises the inadequacies in the current literature based on 193 articles, in which we describe the four gaps in current research. Furthermore, we introduce the TREGAI checklist and elaborate on how it might contribute to more responsible GenAI research in health care and in broader application settings.

First, in current GenAI research there are few solutions for ethical issues. For articles focusing on identifying ethical issues caused by GenAI, regulations and guidelines were the most frequently raised solution. This solution was observed in 11 of the 29 articles discussing ethical issues caused by LLMs, and in one article reviewing issues caused by GenAI for images. In total, 16 of the 29 articles on ethical issues caused by LLMs discussed possible solutions, and 11 of these articles mentioned solutions beyond governance, which included ensuring doctor autonomy over LLMs, improving user awareness of the limitations of LLMs, and implementing security technology. The other 13 articles did not discuss any solutions. Although guidelines and regulations for appropriate use of GenAI are important, difficulties can arise when applying ethical guidance based on a set of principles, such as interpreting the specific requirements of a broad ethical principle in any given context of GenAI application or because the guidance offers little assistance when trade-offs need to be made between ethical principles.

Moreover, due to the complexity and fast advancements in methods and technology, compliance to well established legal regulations does not necessarily prevent ethical breaches. For example, the privacy rule enforced by the Health Insurance Portability and Accountability Act of the US Congress is insufficient to prevent privacy breaches (and a few other ethical issues) by the advanced technology used by LLMs;27 and additionally, the more recent European AI Act introduced in 2024 is inadequate in aspects such as formal AI definition and risk management.12 Similarly, general users of GenAI are unlikely to understand the technology well enough to prescribe a reasonable amount of trust on its output or be able to identify potential misinformation. By contrast, the nonhuman nature and the confident and professional tone of well designed LLMs might earn them unwarranted trust from lay users.27,35 Although the magnitude of such influence is not yet clear, the use of LLMs could potentially lead to more privacy leaks and harm from (partly) incorrect or biased information.

Second, discussion on the ethical concerns beyond LLMs is insufficient. Most of the dedicated ethical discussions have focused on LLMs, despite the use of other GenAI methods (eg, GAN) for text data and more prominently for other data modalities. LLM-powered chatbots, such as ChatGPT, make this powerful technology easily accessible to health-care professionals, medical students, and the general public without much need for technical background, hence substantially increasing the impact of any resulting ethical issues. However, similar inadequacies and concerns apply to other GenAI methods and can also affect health care directly or indirectly in the long run. For example, GAN-based approaches have been exploited for insurance scams by editing or injecting fake evidence for diseases into medical images, or have been targeted in cyberattacks to steal confidential information,36,37 among other malicious activities, but such topics are more often discussed from purely technical perspectives rather than from ethical perspectives. GAN-based approaches are becoming (if they have not already become) the state-of-the-art models for data synthesis in medical research. However, benchmarks are insufficient to comprehensively assess the quality of synthetic data to preserve privacy and to support unbiased and trustworthy future research,9,22,23,33,34 among other ethical gaps (figure 2).

Third, GenAI research does not have a common reference point for ethical discussions. Although viewpoint and perspective articles in leading journals discuss a wide range of ethical issues that could arise (or have arisen) from applications of LLMs in health-care and other settings, articles on GenAI for image or structured data have largely focused on a restricted set of issues, particularly privacy, that could be directly resolved via methodological or technological developments. Ethical discussions can be challenging for GenAI researchers as they are often not formally trained in the definition and interpretation of the ethical principles relevant to AI for health care. However, in the past few years, some studies have included dedicated ethical discussions beyond their main objectives, which shows an increasing interest within the research community to have more in-depth discussions on such issues.10,38 Recommendations and guides have been made on the general application of AI for health care,14,26,39,40 but currently they are not consistently operationalised in GenAI applications.

On the other hand, different authors might endorse different definitions of ethical terms or might select a subset of ethical keywords for discussion without clear justification. For example, the well established ethical principle of beneficence emphasises improvements to patients’ wellbeing in addition to avoiding harm, but this principle was much less discussed in the literature. Although some ethical principles might be less relevant in some application scenarios than in others (eg, the use of GenAI to synthesise structured data might not have as direct an effect on autonomy as for text data), such statements should be made explicitly by researchers with reasonable justifications rather than being inferred post hoc by users. Incomplete ethical discussions might lead to insufficient methodological developments or questionable applications of existing GenAI methods.

Finally, there is little discussion on multimodal GenAI. Most articles we reviewed involved unimodal GenAI (ie, models that accept and generate data in a single modality). Among the three articles that involved multiple modalities, only two discussed multimodal GenAI (specifically GAN), which simultaneously generated chest x-ray images and radiology reports, and the third article reviewed unimodal GANs for various modalities. Although multimodal GenAI is not yet widely applied in health care,41 notable progress has been made in other fields.42–44 These extended LLMs will certainly stimulate useful applications in health care and beyond. However, the increased complexity in the models and application settings will further complicate how model reliability is evaluated (which is already challenging for existing LLMs)45–47 and the extended capability and wide adoption of such technology can amplify the impact of related ethical issues.

Ongoing research is developing multimodal GenAI from a creative yet concerning approach to reconstruct input to study participants (be it images or text) by analysing their functional MRI (fMRI).38,48–50 This approach might be called reverse-mindreading. Each of these methodologies focused on a single input modality, but GenAI trained on one modality can be applied to other modalities with minimal adjustments.50 Although these studies provided additional insights on brain functions and potentially some health-care benefits, the direct extraction of information from brain activities beyond health-related purposes poses important concerns in neuroethics.51,52 Only two of the four papers explicitly discussed these kinds of ethical concerns, in which one paper performed additional experiments to show preservation of patient privacy50 and the other paper only highlighted the general need for regulations.38 A more disciplined approach is needed to ensure ethical use of medical data (including but not limited to fMRI) when developing multimodal GenAI for and beyond health-care applications.

To address these gaps in research requires a collaborative effort from researchers, regulators, and stakeholders. Despite the controversies on how to allocate responsibility and credibility to the harm and benefits caused by GenAI,53 researchers who develop GenAI (or modify existing ones) should be responsible for understanding and disclosing its capabilities and limitations, and those who apply existing GenAI in their research should be able to justify and discuss its appropriateness and potential issues in context. Some of the articles we reviewed have started call for actions for GenAI developers to reduce ethical issues, such as by highlighting their responsibilities in preventing ethical issues from arising in the first place16 and by developing benchmarks to evaluate the ethics of LLMs to facilitate future mitigation,10 but such discussions are not easily operationalised in future GenAI research without detailed actionable guides. Hence, we propose to reinforce ethical considerations in GenAI research in health care by mandating standardised and systematic evaluation during peer review via our proposed TREGAI checklist (appendix p 8).

Based on the development of the nine established ethical principles (panel 1) and the additional important principle of beneficence, our suggested TREGAI checklist provides a tool to reinforce systematic ethical assessments for GenAI research. To promote the operationalisation of systematic ethical investigations in research practice, we propose the checklist for use by scientific journals, institutional review boards, funders, and regulators to evaluate ethical discussions in new GenAI research (or proposals). Using the checklist, these users can request researchers to transparently document all ethical issues discussed related to GenAI, provide additional discussions on solutions related to GenAI (ie, solutions to issues caused by GenAI or using GenAI as a solution to ethical issues), and indicate where to find these discussions in the manuscript (appendix p 9). The checklist serves as a reference for peer review by philosophers and ethicists, focusing on the quality of ethical discussions and possible improvements from ethical perspectives. When an ethical principle is deemed not applicable, researchers are strongly encouraged to justify this conclusion within the manuscript. Ethical principles in the checklist vary in the level of abstraction and might not cover all relevant concerns (eg, when working with multimodal GenAI). However, we suggest that journals and other checklist users work with ethicists to adapt the checklist and in-context definitions of ethical principles to their specific needs.

Checklists do have their limitations54 and checklist ethics is especially notorious for undermining thorough ethical reflection. Therefore, when using our TREGAI checklist to document ethical discussions, researchers are highly recommended to collaborate with ethicists for in-depth assessments of (potential) ethical concerns and further investigations. By mandating all new research covering GenAI to complete a detailed ethics checklist and undergo peer review of ethical discussions, we at least strive for systematic ethical assessments of GenAI studies that facilitate more responsible and reliable applications. As GenAI is constantly evolving, we maintain the TREGAI checklist live online55 to allow timely updates, so that we can incorporate additional ethical principles (eg, from existing literature26,39 and emerging multimodal GenAI research2), updates in recommended actions, or future progress in GenAI regulations and guidelines to facilitate disciplined, comprehensive, and transparent reinforcement of responsible GenAI research. As the TREGAI checklist focuses on ethical considerations of GenAI, research developing GenAI could use it in addition to existing model development guidelines (eg, TRIPOD56,57 or CLAIM58,59) and other tools to enhance ethical discussion (eg, the Ethical Operating System Toolkit60 and the Organisation for Economic Co-operation and Development ethics principles),61 as appropriate. Use of GenAI (eg, ChatGPT) to assist the research process (eg, to draft the manuscript) should refer to the upcoming CANGARU checklist for more specific guides.62

With the growing application of AI for health-care and other high-stakes fields, literature is expanding on ethical concerns and guidelines for AI applications.26,39,63,64 Similar discussions are extending to GenAI,16,25,30 possibly by adopting and expanding ethical frameworks from other domains to health care,65 but they are not easily translated into improved research practice.26 Our scoping review comprehensively analyses ethical discussions on GenAI in health care to highlight the current absence of a systematic assessment of issues in all relevant application settings (eg, across model types and data modalities) and corresponding solutions, and the reliance on regulations and governance to reinforce ethical standards. However, in view of the complexity of GenAI, ethical considerations need to be incorporated during the development and implementation phase, instead of post-hoc mitigations when issues arise. Hence, we highlight the accountability of researchers to comprehensively discuss, fully disclose, and, when feasible, duly resolve, a well defined set of relevant ethical issues in GenAI research. We develop the TREGAI checklist for use by journals, institutional review boards, funders, regulators, and other potential users as a facilitating tool to promote systematic ethical investigations in GenAI research. As an immediate extension, the TREGAI checklist can be used for ethical assessments of GenAI-powered products derived from research based on user manuals.

As explained in the appendix (p 5), our scoping review might not capture all relevant ethical considerations (eg, sustainability, which is not often discussed in GenAI research for health care). Nonetheless, our scoping review reasonably reflects the current imbalance and inadequacies in ethical discussions on GenAI for health care to inform future research. As an initial step towards more responsible GenAI research, our TREGAI checklist does not include some ethical considerations that are not easily operationalised (eg, morality and dignity), but the checklist can be extended in collaboration with ethicists as appropriate. Moreover, we strongly advocate GenAI researchers to collaborate with ethicists for more in-depth ethical investigations, and, if applicable, modify the definitions of the ethical principles to suit local jurisdictions, culture, and application scenarios. Although the TREGAI checklist targets research-related settings, it could be modified for GenAI-created content (eg, social media posts or teaching materials) to assess benefits, limitations, and potential risks, where the social media platforms and educational institutions might take the responsibility to assemble a team of ethicists to review and advise on ethical issues. By maintaining the TREGAI checklist as a live document online,55 we keep it up-to-date with the fast development and expanding applications of GenAI. Meanwhile, additional critical analyses are needed to resolve ethical issues in GenAI research, preferably those which incorporate patients’ perspectives.66 Integrating ethical considerations in AI education is another important step towards ethical and responsible future research.67

## Section: Conclusion

GenAI is a powerful technology with various potential roles in health care and beyond. Failing to meet ethical standards in these roles can affect daily life by creating inefficient administrative services and can lead to worse health outcomes. However, GenAI is a recent innovation, especially with respect to its use or implementation in medical practice. The number of studies published up until this scoping review is relatively small, but identifying the issues that are essential features of GenAI as early as possible might ultimately help promote trust and adoption for clinicians, patients, and the general public. By suggesting the TREGAI checklist for ethical GenAI and maintaining it live to incorporate updated understanding and regulations, we advocate a systematic and balanced assessment of ethical considerations beyond standard methodological and technological perspectives, which could be extended to general AI and facilitate more responsible and trustworthy development of technology.


---

# Generative artificial intelligence empowers digital twins in drug discovery and clinical trials

- **Authors:** Maria Bordukova, Nikita Makarov, Raul Rodriguez-Esteban, Fabian Schmich, Michael P Menden
- **Issuer:** Expert opinion on drug discovery
- **Type:** Scientific article
- **Published:** 2024-01-08
- **Language:** en
- **DOI:** 10.1080/17460441.2023.2273839
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37887266/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

The concept of Digital Twins (DTs) translated to drug development and clinical trials describes virtual representations of systems of various complexities, ranging from individual cells to entire humans, and enables in silico simulations and experiments. DTs increase the efficiency of drug discovery and development by digitalizing processes associated with high economic, ethical, or social burden. The impact is multifaceted: DT models sharpen disease understanding, support biomarker discovery and accelerate drug development, thus advancing precision medicine. One way to realize DTs is by generative artificial intelligence (AI), a cutting-edge technology that enables the creation of novel, realistic and complex data with desired properties. The authors provide a brief introduction to generative AI and describe how it facilitates the modeling of DTs. In addition, they compare existing implementations of generative AI for DTs in drug discovery and clinical trials. Finally, they discuss technical and regulatory challenges that should be addressed before DTs can transform drug discovery and clinical trials. The current state of DTs in drug discovery and clinical trials does not exploit the entire power of generative AI yet and is limited to simulation of a small number of characteristics. Nonetheless, generative AI has the potential to transform the field by leveraging recent developments in deep learning and customizing models for the needs of scientists, physicians and patients.


---

# Generative artificial intelligence in drug discovery: basic framework, recent advances, challenges, and opportunities

- **Authors:** Amit Gangwal, Azim Ansari, Iqrar Ahmad, Abul Kalam Azad, Vinoth Kumarasamy, Vetriselvan Subramaniyan, Ling Shing Wong
- **Issuer:** Frontiers in pharmacology
- **Type:** Scientific article
- **Published:** 2024-02-07
- **Language:** en
- **DOI:** 10.3389/fphar.2024.1331062
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38384298/
- **Licence:** CC-BY

## Section: Abstract

AbstractThere are two main ways to discover or design small drug molecules. The first involves fine-tuning existing molecules or commercially successful drugs through quantitative structure-activity relationships and virtual screening. The second approach involves generating new molecules through de novo drug design or inverse quantitative structure-activity relationship. Both methods aim to get a drug molecule with the best pharmacokinetic and pharmacodynamic profiles. However, bringing a new drug to market is an expensive and time-consuming endeavor, with the average cost being estimated at around $2.5 billion. One of the biggest challenges is screening the vast number of potential drug candidates to find one that is both safe and effective. The development of artificial intelligence in recent years has been phenomenal, ushering in a revolution in many fields. The field of pharmaceutical sciences has also significantly benefited from multiple applications of artificial intelligence, especially drug discovery projects. Artificial intelligence models are finding use in molecular property prediction, molecule generation, virtual screening, synthesis planning, repurposing, among others. Lately, generative artificial intelligence has gained popularity across domains for its ability to generate entirely new data, such as images, sentences, audios, videos, novel chemical molecules, etc. Generative artificial intelligence has also delivered promising results in drug discovery and development. This review article delves into the fundamentals and framework of various generative artificial intelligence models in the context of drug discovery via de novo drug design approach. Various basic and advanced models have been discussed, along with their recent applications. The review also explores recent examples and advances in the generative artificial intelligence approach, as well as the challenges and ongoing efforts to fully harness the potential of generative artificial intelligence in generating novel drug molecules in a faster and more affordable manner. Some clinical-level assets generated form generative artificial intelligence have also been discussed in this review to show the ever-increasing application of artificial intelligence in drug discovery through commercial partnerships.Keywords: ChatGPT, de novo drug design, deep generative models, AlphaFold, variational autoencoders, generative adversarial network, large language models, chemical language models

## Section: 1 Introduction

New medication development is an expensive and time-consuming process. As a result of concerns about risk and acceptability, the success rate is low. The pharmaceutical sector is seeing a decline in productivity as the cost of developing and bringing a new medicine to market continues to rise (Paul et al., 2010; DiMasi et al., 2016). New processing hardware and novel and improved deep learning (DL) algorithms have increased the success of artificial intelligence (AI) in numerous areas, including computer vision, autonomous vehicles, robotics, and others (von Ungern-Sternberg, 2017; Coeckelbergh, 2020; Thierer et al., 2017; Collins and Moons, 2019). In recent years, DeepMind has developed two Go-playing AI algorithms (AlphaGo and AlphaGo Zero) that can now compete and even win against the best human players (Singh et al., 2017; Chao et al., 2018). Additionally, DeepMind has developed AlphaFold to address the protein-folding challenge, which has been regarded for a long time as a challenging biological problem. AlphaFold 2 performed better than any other technique in the 14th Critical Assessment of Protein Structure Prediction (CASP) (Service, 2020). These advances show the potential of AI to revolutionize basic research by drastically speeding up the pace of research. Motivated by these promising outcomes, medicinal researchers are exploring and utilizing how AI may be used in the pharmaceutical industry. Many pharmaceutical firms have partnered with AI startups and academic institutions or launched in-house AI initiatives. Various biomedical and drug discovery research branches have recently incorporated AI approaches, such as developing deep neural networks using transcriptional data to predict biologically active molecules (Aliper et al., 2016), and generating new small molecule therapeutic leads (Mamoshina et al., 2016). Ongoing studies reveal that AI is being used to revolutionize every step of the drug discovery process, from choosing targets to generating ligands, planning synthesis, selecting trial participants to repurpose existing drugs, analyzing cellular images, and making predictions about molecules’ physicochemical and biological properties.

Numerous criteria, including ADMET (absorption, distribution, metabolism, excretion, and toxicity) and synthesis feasibility, must be satisfied by each potential drug candidate. Therefore, predicting molecular characteristics with high precision is crucial in the drug development process. To save money on R&D, computational studies might screen and enhance projected molecular features before costly animal and clinical testing. For instance, predicting the inhibition of human cytochrome 450 (CYP450) using a multitask deep autoencoder was described by Li et al. (Li et al., 2018a), paving the way for minimizing adverse effects and drug interactions. To predict the aqueous solubility and logP of small compounds, Tang and coworkers employed a deep self-attention message-passing graph neural network (SAMPN) (Tang et al., 2020). In addition, their SAMPN model identified the primary structural characteristic for a target attribute, which shed interpretable light on the DL “black box” issue. Leads may also be found using neural networks trained to predict chemical properties. For instance, Stokes et al. (Stokes et al., 2020), used a deep neural network based on molecular graphs to predict antibiotic activity in compounds structurally distinct from known antibiotics and then validated it in experiments.

However, these methods have significant drawbacks in common, including the need for colossal training datasets and well-trained neural networks to learn the abstract representation of molecules, molecular grammar, molecular properties, and chemical aspects. Another point is that this prediction-based approach cannot generate new compounds if the basic or essential molecules are missing from the input chemical library. Here lies the role of generative AI (GAI). GAI is a type of AI that uses DL to generate novel content. GAI tools understand the patterns and intricacy of their training data and then generate new data (either similar or improved version per the user’s expectation). New data can be text, images, audio, video, chemical molecules, etc., based on patterns they have learned from training data. GAI is being used to generate content in response to user-given prompts. GAI is different from traditional AI systems, which are trained to examine data and make predictions based on pattern recognition.

One of the most appealing features of GAI-driven drug development is the ability of GAI models to produce completely novel compounds. Generating unique or novel molecular structures with desired features is known as de novo molecular generation. As a result, GAI models often include neural networks capable of predicting a given attribute. For example, in a representative work, Popova et al. (Popova et al., 2018), presented ReLeaSE, which associates a neural network (to predict molecular property) with a deep generative neural network (to design novel molecules with the necessary physicochemical and biological characteristics). However, the GAI model developed by Popova et al. was not verified by actual experiments. Subsequently, Merk et al. (Merk et al., 2018a), trained a GAI model on natural products to produce de novo ligands, and the resulting molecules were empirically verified as new retinoid X receptor (RXR) modulators. In another scientific breakthrough, to combat fibrosis, Hongkong/New York-based Insilico Medicine developed a GAI model GENTRL (Generative Tensorial Reinforcement Learning) to identify novel kinase DDR1 inhibitors. They performed biological tests to confirm the efficacy of the GENTRL-generated compounds. Their research stood out because they went from insilico to a successful preclinical phase in only 21 days, an achievement that had never been accomplished before (Zhavoronkov et al., 2019). Korshunova et al. recently employed RL, combining transfer learning with the policy gradient algorithm, experience replay, and real-time rewards to generate new EGFR inhibitors that have also been empirically verified (Korshunova et al., 2021).

These amazing use cases of GAI models provide hope for improved methods of producing novel therapeutic molecules from scratch. These examples demonstrate the potential effectiveness of a GAI-driven approach to the drug development process. It should be noted, however, that there is currently no one-size-fits-all approach to AI-driven drug development. For instance, the hyperparameters, GAI frameworks, and model training for any AI-driven drug discovery project may need to be fine-tuned extensively. The biggest obstacles to AI-driven drug development are the immense rounds of trial and error, the absence of a generic/universal mathematical system, and the lack of adequate data.

Furthermore, given the complexity of biological systems, it is unlikely that any of the aforementioned GAI models would continue to be effective if the aim were changed. For instance, there may not be enough data for the predictor and generator to produce drug-like compounds if the target is altered from A to A1 or B. The quantity and quality of the training sets determine the performance of the predictor or classifier or generator. While GAI frameworks and uses have been widely discussed among the core DL fraternity (Salakhutdinov, 2015), their full potential is yet to be tapped (for precise applications/successful use cases) in medicinal chemistry research (Lavecchia, 2019). Even though the aforementioned chain of events—from AI model training to molecular property prediction to the generation of novel drug-like molecules to web lab synthesis and biological validation—remains relatively rare in the scientific literature, GAI-driven drug discovery is emerging as an exciting tool for efficient de novo molecule generation. In this review, we introduce various GAI frameworks, explore their uses in drug development, highlight recent successes and challenges, and detail ongoing efforts to address these issues to generate customized needles rather than finding the ones in a haystack. In the Recent Advances section, we have shared comprehensive data about a few under investigation (clinical trial stage) molecules that emanated from generative AI.

## Section: 2 Generative AI

AI models (including machine learning-ML and DL) may, after analyzing patterns/insights in the input data given to them, categorize data (classification), predict numerical output (regression), group data (clustering), and generate either completely new data or data similar to input data. Most of these tasks fall under the purview of either computer vision (which employs the CNN, that is, convolutional neural network type of DL model for analyzing imageries like medical images, other images, and molecular structures in the form of molecular graphs) or natural language processing-NLP (which employs the recurrent neural network-RNN type of DL model for analyzing sequential data like sentences or chemical structures in the form of strings).

The capacity of GAI models to generate/design new sets of data (depending on the input data), such as photos, audios, phrases, films, chemical compounds, etc., has recently attracted much interest, mainly because of the success of large language model (LLM). Depending on the GAI model used and the specifics of the work at hand, the results might be exact copies of the inputs or improved versions of inputs (Figure 1).

Since its release in November 2021, OpenAI’s ChatGPT (Chat Generative Pre-trained Transformer) has been one of the most talked-about examples of proprietary GAI. ChatGPT is driven by the LLM (GPT-4) and designed and trained to generate natural-sounding text. Similarly to other LLM-based GAI, it has been trained on large datasets of text and code and can generate creative content, translate languages, generate new text, text similar to the text it was trained on, and answer user-provided prompts in an informative way. ChatGPT, which models human conversation, is the most advanced language simulator accessible today. Its state-of-the-art GAI technology is a transformer architecture learned using large online text datasets. DALL-E 2 (another invention from OpenAI falling in the domain of GAI that allows users to generate new pictures using text-to-graphics prompts) and Midjourney (an AI tool that converts words to images and makes images depending on user prompts) are two other prominent examples of proprietary GAI products (Editorials, 2023; Patel et al., 2023; Shen et al., 2023; Stokel-Walker and Van Noorden, 2023).

As mentioned earlier, discovering and developing new medications has been lengthy and expensive, but the industry has dramatically changed with the introduction of GAI. The GAI method can transform the sector entirely by automating many of the tedious and labor-intensive activities associated with drug development. The use of GAI models for developing therapeutic candidates based on existing biological and chemical information has recently been detailed. For example, NVIDIA’s BioNeMo, Insilico Medicine’s Pharma. AI, etc., are a few examples of GAI tools for the pharma sector (for drug development). NVIDIA’s BioNeMo is a cloud-based GAI platform for the pharmaceutical industry. It is a supercomputing framework for training and deploying massive biomolecular language models. Researchers can rapidly adapt and release scalable generative and predictive biomolecular AI models built using NVIDIA cloud APIs. BioNeMo also allows the implementation of GAI in the generation of protein and biomolecule structure and function, which speeds up the development of novel molecules in the quest for drug discovery. The Pharma. AI platform has a total of three function-specific platforms: PandaOmics, Chemistry42, and inClinico. Through a patented network analysis system called iPanda that deduces pathway activation or inhibition, uncovering linkages between apparently distinct genes basis dysregulated biochemical processes, PandaOmics is developed to allow multi-omics identification of new targets. PandaOmics generates a ranked list of prospective biological targets for a specific illness or subtype of disease and then selects those target theories basis their originality, approachability by small compounds, biologics, and safety. This process yields a potential target score. The company claims that users may discover new lead-like compounds using Chemistry42, the second function-specific platform, which is an automatic, de novo drug design and scalable tool. This discovery process can take as little as a week. Chemistry42 employs GAI to generate novel small drug-like molecules, fine-tuned for exact features by drawing on many chemicals and molecular fragments. Chemistry42 establishes standards for innovative compounds’ attributes, including molecular shape, chemical complexity, synthetic accessibility, metabolic stability, etc. A newly generated molecule is first annotated with its characteristics, including physicochemical parameters, binding scores, and drug-likeness traits, before being compared to other compounds in private libraries and vendor catalogues to determine its uniqueness. inClinico is a platform for a data-driven multimodal forecasts of clinical trials’ probability of success (PoS). It uses enormous amounts of data about the targets, ailments, clinical trials, and even researchers involved in the studies.

ChatGPT necessitates this much elaboration since this groundbreaking LLM will shape and reform how existing GAI-guided initiatives go towards de novo drug design (Liu et al., 2021; Chakraborty et al., 2023; Chen et al., 2023). There has been one recent publication on DrugGPT along the lines of ChatGPT. This is covered in more detail later in this article. In the case of AI-driven drug discovery, GAI may be divided into three classes based on how they are used to generate novel compounds:

A simple flowchart of the generative AI model’ working.

## Section: 3 Generative AI models

Classifying GAI tools as either non-autoregressive or autoregressive is a common practice. Some examples of non-autoregressive generating models include generative adversarial networks (GANs), reversible flow models, and variational autoencoders (VAEs) (Baillif et al., 2023; Xiao et al., 2023). For example, to construct a graph, non-autoregressive generative models generate both the edge-feature matrix and the node-feature matrix at the same time. On the other hand, iteratively improving an intermediate structure is how autoregressive generative models construct a graph. RNN serves as a prototypical example of the autoregressive generation model. GANs and VAEs are now the most popular GAI models for designing new therapeutic compounds. Transformers and LLMs/Chemical language models (CLMs) are more sophisticated and advanced GAI models. Some of the most fundamental elements of these GAI models include graph neural networks (GNNs), GCN (graph convolutional network)/CNNs (for processing molecular representations in the form of molecular graphs or images), and RNNs for processing molecular representations in the form of sequences like simplified molecular input line entry system (SMILES). In addition, RL is a valuable ML method in the GAI basket. As with the training of robots, driverless automobiles, etc., RL is used to optimize molecular characteristics, such as conditional VAEs and others, to modify the generation of molecules in the desired direction in real-time. In the below subsections, we will see these models individually. Figure 2 shows some GAI models and the general working of a GAI model from the viewpoint of drug discovery via transfer learning.

(i) Some GAI models; (ii) De novo molecular design workflow (involving transfer learning to address data scarcity) for generating small molecules against a pre-decided target. (A) Pre-trained deep generative model. (B) TL to learn the essential characteristics of small compounds concerning the target receptor, and RL approach to enhance the molecular properties in the desired direction. (C) Various physicochemical property filters, structural alerts, and virtual screening scores for selecting or ranking model-generated molecules for the next level.

(i) Encoding and decoding an input molecule using a VAE. The encoder’s job is to translate a molecule deterministically into a Gaussian distribution. Based on the generated mean (µ) and standard deviation (σ), a novel point is sampled before sending it to the decoder. Finally, the decoder’s job is to generate a novel compound from the sampled point. (ii) A detail illustration of a VAE framework indicating how similar molecules lie in latent space.

A self-explanatory sample framework of a GAN comprises two modules (the generator and the discriminator) contesting with each other. While training this deep generative model, the generative and discriminative losses are closely monitored.

Graph neural networks for automated de novo drug design.

(i) Illustration of the basic framework of a plain CNN (deployed to analyze an image, here a heart) consisting of convolutional layers, pooling layers, and a fully connected layer (ii) In the case of molecular design, a CNN input includes molecular structures or atom distances from molecular graphs.

(i) The elementary framework of an RNN showing input unit (x), hidden unit (s), and output unit (o). Different weight matrixes are U (for the shift from x to s), V (for the shift from s to s), and W (for the shift from s to o). (ii) Structure generation from RNNs as part of DL-driven de novo molecular design in a sequential manner.

Demonstration of a basic RL model for de novo molecular design (i) A benzene ring at state St at iteration t, and an initial reward Rt at iteration t, (ii) the agent picks an action At which attaches a methyl group to benzene (iii) The environment takes this knowledge for generating a subsequent response that is St+1 state and a new reward Rt+1. This sequence of events goes on until the episode ends.

(i) An illustration showing the working of CLM on the basic framework of LLM; (ii) Principles of chemical language models (CLMs). (a) Example of a molecular structure (Kekulé structure) and a corresponding SMILES string. (b) CLMs are trained to iteratively predict the next SMILES character based on the preceding string characters. (c) Multinomial sampling can be used to generate new SMILES strings from trained CLMs, where SMILES characters are sampled with a weighted random sampling of probability distributions learned by the CLM.

Different types of GAI models.

## Section: 3 Generative AI models › 3.1 VAEs

To build an autoencoder, one must first train a network to map the input into a low-dimensional latent vector through the encoder and then train a second network, the decoder, to map the latent vector back into the input data. By reproducing the input, the autoencoder generates a latent space. However, such basic autoencoders cannot represent molecular structure (in latent space) in a continuous manner. Overfitting and breaks in continuity in the original autoencoders inspired the development of VAEs. Unsupervised data compression using VAEs has become one of the most often used GAI methods due to its success with a wide range of input data types. Many complex data types, including handwritten digits, segmentation, and faces, have been successfully generated using VAEs (Doersch, 2016). VAEs are being used extensively in the search for novel drug-like molecules. In reality, current GAI-based drug development efforts are primarily focused on VAEs. VAEs have two primary components: an encoding network and a decoding network. The encoder network maps the input data to a probability distribution, compressing it into a lower-dimensional representation, the latent space. The input data is reconstructed from a sample taken from the latent space by the decoder network. The VAE seeks to learn optimal parameters to provide the highest likelihood of reproducing the input data. This allows VAEs to learn how to produce realistic samples in the latent space, from which fresh data may be inferred. In the context of drug development, VAEs maximize the similarity between the encoded molecules and a previous distribution in the latent space while minimizing the reconstruction loss during training. VAEs may develop novel molecules with structural and chemical characteristics comparable to the training data by sampling from the learned latent space. Gomez et al.'s research publication on VAE is one of the most often quoted and referred to representative pieces (from the perspective of producing new chemicals) (Gómez-Bombarelli et al., 2018). Several papers followed this seminal work, all of which used VAEs or VAEs after some add-on to generate novel small compounds in the hunt for drug-like molecules. Figure 3 illustrates the functioning of a VAE.

While there are several documented variations of VAE (Blaschke et al., 2018; Harel and Radinsky, 2018; Jørgensen et al., 2018; Kang and Cho, 2018; Sattarov et al., 2019), the essential structure is consistent across all of them. 3D grid-VAE, SMILES-VAE, and Graph-VAE are the three main variants of VAE based on the chemical representations they use. Owing to its simple deployment, SMILES-VAE has gained widespread favour. Additionally, due to their suitability for sequence data structures, stacked GRUs (gated recurrent units) or LSTMs (long short-term memory) are frequently used for both the encoder and decoder in SMILES-VAE. Though effective, the SMILES-VAEs suffer from the same issue that plagues most seq2seq models (namely, the inability to produce 100% verified SMILES strings).

Research groups have shown (Li et al., 2018b; Liu et al., 2018; Samanta et al., 2020; Jin et al., 2023a; Jin et al., 2023b; Jin et al., 2023c), that molecular generators based on molecular graphs can solve the 100% verified SMILES challenge. One such conditional graph generator for multi-objective de novo molecule creation was suggested by Li et al. In addition, Jin et al. revealed a string of studies based on Graph-VAE, with the first being a “Junction Tree” VAE. Each node of the junction tree stands in for a component of the original molecule or a single atom. There are two phases involved in making molecules. The first is a scaffolding over chemical components designed as a junction tree. Phase two involves using a graph message-passing network (MPN), a specific kind of GCN, to combine individual chemical building blocks into a whole molecule basis the junction tree (Jin et al., 2023c). Although this approach can keep the molecular representation chemically correct at every stage, the model requires extra work to learn the encoding of the tree structure and decoding the latent variable again to a new tree, making it inefficient for molecular production. Lim et al.'s (Lim et al., 2020), scaffold-based Graph-VAE is another seminal effort in this area; it employs a technique of developing derivative molecules that preserve a specific scaffold as a substructure. The method has the potential to be too particular, rendering it less beneficial when working on a novel, unrelated target protein. Three-dimensional grid-based VAEs, which take cues from 3D image recognition, are the third kind of cutting-edge VAEs (Ji et al., 2012). Inherently, grids make learning from 3D spatial conformations via 3D convolutions easier. This relies heavily on 3D-CNN for both the encoder and decoder. The input data for a 3D grid-VAE model of molecules should likewise be in 3D. However, there is a dearth of readily accessible datasets for 3D Grid-VAE when compared to those utilized for training SMILES-VAE or Graph-VAE. Because bioactive conformations are not always similar to probable least energy conformations, compiling a good 3D molecule database labelled with bioactive data is challenging. Even though some programmes can take 1D or 2D molecular structure data and output it as a random 3D molecular conformation, the actual 3D structure of the molecule, which may be connected to a molecular feature like the IC50 of a particular target, would be lost in the process (Sussman et al., 1998; Wang et al., 2005). These programmes, which are mostly force-field based 3D molecular conformation generators, can only ensure obtaining local potential energy minimum conformations and not the bioactive conformations that have been validated experimentally. In one of the studies, Sunseri et al. (Sunseri and Koes, 2020), designed a helpful toolbox called Libmolgrid, for encoding three-dimensional molecules onto a grid, greatly simplifying the procedure. Libmolgrid employs multidimensional grids to represent atomic coordinates to maintain the spatial connections between the original input’s three dimensions. It also supports contemporary GPU architectures. The atoms are shown as continuous, Gaussian-like densities on a three-dimensional grid with individual channels for every kind of atom. The encoder, made up mostly of 3D convolution networks, takes 3D chemical structures and encodes them into a latent space; the decoder then attempts to decode the latent variable into a new 3D grid display. By expanding the function, which adjusts with the atoms inside the lattice, and connecting the adjusted atoms with suitable geometry, the novel 3D grid may be converted again to a 3D version of a molecule. Although 3Dgrid-VAE shows promise, it has not yet been perhaps used for a genuine drug development effort that includes experimental validation. There have been reports of other AI models for generating molecules in 3D coordinates (Gogineni et al., 2020; Simm et al., 2023).

More and more researchers are paying attention to learning disentangled representations for VAE, where the objective is to have each latent variable in the latent vector capture a different characteristic or aspect of the input (Mita et al., 2023). A molecular feature may be altered independently of other qualities by modifying the latent variables linked with that feature if disentangled VAE is effectively implemented for generating the molecule. In conclusion, there is no ideal framework for generative modelling, but there are good reasons to consider using VAEs. Unlike a standard autoencoder, a VAE’s latent space is continuous and organized, allowing for more precise regulation of produced outputs and more natural interpolation between samples. This is very helpful in fields like drug design, where generating molecules with desired features is essential. In addition, they are more stable and simpler to train than GANs because they have a clearly defined optimization objective and avoid problems like mode collapse (it means the generator will only generate the most probable outputs it has found and will ignore the other modes present in the training data, resulting in a lack of variety in the produced samples.) and training instability. While models like GANs need a large training set to get reasonable results, VAEs may be made to learn in low-data regimes. A successfully produced 3D coordinates may be utilized directly in further molecular computations, including docking, molecular dynamics, and quantum mechanical simulations. We foresee this 3D technology being beneficial for AI-driven drug discovery initiatives in the near future, as evidenced by rapid research and fine-tuning of the models for better results. (Polykovskiy et al., 2018; Kwon et al., 2019; Simonovsky and Komodakis, 2023).

(i) Encoding and decoding an input molecule using a VAE. The encoder’s job is to translate a molecule deterministically into a Gaussian distribution. Based on the generated mean (µ) and standard deviation (σ), a novel point is sampled before sending it to the decoder. Finally, the decoder’s job is to generate a novel compound from the sampled point. (ii) A detail illustration of a VAE framework indicating how similar molecules lie in latent space.

## Section: 3 Generative AI models › 3.2 GANs

There has been a surge of new GAI models with the development of GANs (Goodfellow et al., 2020). GANs may be trained to generate synthetic compounds with the required characteristics via an adversarial training procedure. GANs have two parts: a generator and a discriminator. By studying the underlying distribution of actual/real/valid data, GANs may be trained to produce synthetic/fake data such as pictures, movies, and novel molecules. In a drug discovery scenario, expanding the chemical space for prospective drug candidates, GANs may generate novel molecules that are also chemically plausible. The GAN’s generator module takes in noise and outputs a synthetic molecular structure. In contrast, the discriminator module attempts to tell the difference between real and synthetic samples. The generator and the discriminator are trained simultaneously in a competitive fashion, with the generator learning to make more realistic molecules and the discriminator improving its ability to tell them apart. Whereas GANs produce data that is identical to existing data, VAEs generate data that is statistically comparable to existing data. Because of this, they are more suited to activities like designing novel therapeutic compounds with improved characteristics. Figure 4 explains a basic GAN structure.

ORGAN, ORGANIC, and MolGAN (Guimaraes et al., 2017; Sanchez-Lengeling et al., 2017; De Cao and Kipf, 2018), are a few of the GAN approaches that have been documented that use molecular GAN. Both ORGAN and ORGANIC rely heavily on SMILES strings and, therefore, suffer from the same issue of 100% validated SMILES that plagues most seq2seq models. GANs’ training and performance might be erratic and sluggish. Furthermore, training and convergence for GANs are often more challenging. Additionally, for optimal performance, hyperparameters must frequently be fine-tuned. As mentioned earlier, another issue is mode collapse, which is theoretically impossible to prevent (Su, 2018). Regularisation and algorithmic combination may boost their performance. ORGAN, for instance, combines the SeqGAN, as illustrated by Yu et al. (Yu et al., 2016), and the Wasserstein GAN (WGAN) (Weng, 2019), in its design. The team behind ORGAN also tweaked the traditional GAN goal function by including an “objective reinforcement” component in the reward function of generator RNN to encourage the RNN to generate molecules with a specific objective attribute or collection of qualities. Later, building on the foundation laid by ORGAN, the ORGANIC algorithm was suggested to optimize a distribution throughout molecular space in terms of a set of target qualities. Three applications, including organic photovoltaics and melting temperatures, were used to validate the effectiveness of ORGANIC. A graph-based GAN (that uses molecular graphs, unlike ORGAN and ORGANIC) is MolGAN. The computing burden of MolGAN is low, yet it can produce chemically viable structures with 100% accuracy. With the fast acceptance of GANs as one of the most advanced GAI tools for generating novel molecules, their uses in drug discovery are becoming a commonplace. Researchers have used various GAN flavours to aid drug development, and their results have been reported in several distinct studies (Kadurin et al., 2017a; Kadurin et al., 2017b; Putin et al., 2018; Bian et al., 2019; Lin et al., 2020; Bai et al., 2021).

The recent summary of GANs by Tripathi et al. is worth reading and analyzing (Tripathi et al., 2022). In this review, the authors looked at research on drug development that uses several GAN methods to assess molecular de novo design. In addition, they explored various GAN frameworks for dimensionality reduction of data during the preclinical phase of drug discovery. They also demonstrated several studies using GAN frameworks in de novo peptide and protein synthesis.

A self-explanatory sample framework of a GAN comprises two modules (the generator and the discriminator) contesting with each other. While training this deep generative model, the generative and discriminative losses are closely monitored.

## Section: 3 Generative AI models › 3.3 Flow-based models

Though they are being used widely, there is no explicit modelling of the true probability density function in either VAE or GAN. To assess the difference between valid (actual) molecules and synthetic molecules, VAE optimizes an implicit lower limit on a probability function, whereas GAN avoids modelling the distribution and instead learns in an adversarial manner. By capitalizing on normalizing flow, deep flow-based models can overcome the intractable problem of explicit density estimation (Rezende and Mohamed, 2023). A normalizing flow is an invertible deterministic transformation between the latent and raw data spaces. For instance, a new technique called MoFlow learns a chain of transformations to map valid molecules to their latent representations and a reverse sequence of transformations to map the latent representations to valid molecules (Zang and Wang, 2006). Shi et al. presented GraphAF to generate graphs using a flow-based autoregressive model (Shi et al., 2021). Using a breadth-first search strategy, they determined the optimal sequence for adding a molecule’s nodes and edges in the training data. The molecular graph generation process was then broken down into parallelizable one-step graph modification procedures. In the generation phase, GraphAF generates a molecule by sampling it repeatedly, a technique that permits the use of chemical domain knowledge in valency testing. Even without chemical knowledge criteria, GraphAF achieved a 68% validity rate on the ZINC data set, which increased to 100% with chemical rules. One significant drawback of flow-based models is the time needed to complete the intricate hyperparameter tuning. Introducing real-value noise into the molecule generation flow may turn the molecular graphs into continuous data, allowing the flow-based models to be used to their full potential. More study is needed in this area to compare these models with prevalent ones.

## Section: 3 Generative AI models › 3.4 Diffusion generative models

Diffusion probabilistic models have recently been proven to operate very well across a wide range of generating tasks, and a growing body of research has applied these models directly to the molecule discovery challenge. A series of photos are used to teach a diffusion model. They can learn the statistical connections between pixels in a picture and be used to produce new pictures with comparable characteristics to those in the dataset. One may use these models to get a sequence of interconnected data points. For instance, the Abdul Latif Jameel Clinic for Machine Learning in Health at MIT has developed a novel model called DiffDock that helps hasten drug discovery while decreasing the possibility of side effects. DiffDock employs a diffusion generative model to provide a docking pose space for protein-ligand interactions. More than 100,000 protein-ligand binding postures were used to train this model, all retrieved from the Protein Data Bank-PDB. This technique may uncover possible harmful side effects at an earlier stage in drug development and is more efficient than conventional approaches (as judged by the PDBBind blind docking benchmark, a typical benchmark for measuring the accuracy of molecular docking methods). DiffDock’s potential benefits include lowered drug research costs, faster drug development timelines, and reduced risks to human subjects. DiffDock is still in the developmental phase, but it might significantly alter how drugs are discovered (MITNEW, 2023). Yet another research presents a novel drug development strategy that uses a molecular fragment-based diffusion model. Here, the model may produce compounds with high binding affinity to the target protein and minimal toxicity. The model may produce more varied, valid, and drug-like compounds than other methods. The scientists found the diffusion model based on molecular fragments valuable for finding new drugs (Levy and Rector-Brooks, 2023). There must be more use cases for this strategy in drug development before it can be thoroughly analyzed.

## Section: 3 Generative AI models › 3.5 GNNs

Graphs are structured as 2D data representations without any spatial connections between elements. However, it is possible to encode 3D information, such as stereochemistry, into a graph representation. A graph is defined as a tuple G = (V, E) of a set of nodes V and a set of edges E, where each edge e ε E connects pairs of nodes in V. Molecular graphs typically lack directionality, resulting in unordered pairs in E. The concept of the molecular graph representation involves mapping atoms and bonds in a molecule into sets of nodes and edges. One possible approach is to consider the atoms in a molecule as nodes and the bonds as edges. However, alternative mappings are also worth considering. In standard graph representations, nodes are typically depicted as circles or spheres, while edges are represented as lines. In molecular graphs, nodes are commonly represented by letters corresponding to the atom type or by points where the bonds intersect, specifically for carbon atoms. Each node in the graph convolutional layer collects data from its neighbours, representing the regional chemical environment (Bondy and Murty, 1976).

Numerous software packages, for instance can effortlessly visualize the 2D and 3D depictions of graphs, ChemDraw (Reang et al., 2023), Mercury (Macrae et al., 2020), Avogadro (Hanwell et al., 2012), VESTA (Momma and Izumi, 2011), PyMOL (DeLano, 2002), and VMD (Humphrey et al., 1996).

Graph-based data, such as molecular graphs, may be directly processed by GNNs. The way these DL models handle molecular inputs makes them advanced neural network. Machines read these molecular representations directly from the molecular graph without requiring extensive modification or engineering by human experts. Among the various varieties of GNNs, the CNN-inspired graph convolution network (GCN) (Wu et al., 2022), and the attention-based graph attention network (GAT) stand out. In a typical molecular graph, atoms serve as nodes and chemical bonds as edges to represent a molecule (Figure 5). To perform tasks such as molecule synthesis, property prediction, and virtual screening, GNNs successfully learn from and generate molecular graphs. To update and disseminate data throughout a graph’s nodes and edges, GNNs use message-passing mechanisms.

Because of their ability to learn association information across heterogeneous and bipartite domains, such as the association between patients and illnesses, GNNs are well suited for generating novel drug-like molecules, predicting their properties, identifying new drug targets, and predicting the interactions between drugs and targets. Studies of GNNs from the perspective of drug discovery and development have been published in recent years by several research groups (Li et al., 2018b; Bradshaw et al., 2019; Lyu et al., 2019; Madhawa et al., 2019).

In their study to predict molecular properties, Jiang et al. showed that GNN was better than other property prediction methods (Jiang et al., 2021). According to recent research, the characteristics of compounds may be reliably predicted using a particular GNN named Chemi-Net (Liu et al., 2019).

While GNNs are among the most cutting-edge approaches to molecular DL setup, they have flaws. For example, GNNs have unique challenges, such as over-smoothing. When too many layers are stacked on top of one another, it becomes impossible to discern between the characteristics of individual nodes in a network, devastatingly affecting model performance. Because of this restriction, modern GNNs typically have no more than four layers. However, as the model becomes more comprehensive, its representational power will grow in tandem. It has been shown that ultradeep neural networks may be helpful in computer vision. Current state-of-the-art CNNs often include over 100 layers (He et al., 2016; Hu et al., 2018). To advance point cloud semantic segmentation, Li et al. (Li et al., 2020a), recently constructed a 56-layer GNN that outperformed prior art by 3.7%. They proved that ultradeep GNN stacking is feasible and showed the benefits of such networks. However, a crucial part of their approach to building such a deep GNN included randomly rearranging the edges of the graph, which does not apply to networks with fixed edges like molecules. As a result, research into techniques for constructing more sophisticated GNNs for molecular learning is also warranted from drug discovery and property prediction.

In addition, numerous types of molecules cannot be adequately described using the graph model. Any structure that includes delocalized bonds, like coordination compounds and molecules with polycentric bonds, ionic bonds, or metal-metal bonds, falls under this category. In the case of molecules with dynamic and ever-changing atomic arrangements in three-dimensional space, the graph representation may lack significance, particularly when bonds between atoms continuously break and form or when the structure undergoes frequent rearrangements. Another challenge in working with graph representations is their lack of compactness. A molecular graph can be represented in various ways, such as an image, a tuple of matrices, lists, or tables. However, these representations are typically more challenging to search through compared to a more concise linear representation, like a string encoding a structure ID. As the size of the graphs increases, they become increasingly burdensome, and their memory usage grows exponentially with the number of nodes (David et al., 2020). The issue does not arise with linear notations, as they utilize the graph framework to generate more condensed and memory-efficient representations for molecules (O Boyle, 2012). Linear notations offer the benefit of being suitable for use as entries in a table and are easily searchable, particularly for identity search rather than substructure search, in cases where a matrix representation is impractical.

Xia et al., in their review, beautifully explained the intricacies of GNNs from the viewpoint of de novo drug design (Xia et al., 2019). Another recent study briefly introduced GNNs and their applications in de novo drug discovery, including compound scoring, molecule generation and optimisation, and synthesis planning. Readers who need in-depth records may refer to these two review articles (Xiong et al., 2021). For more details on molecular graphs, readers may refer to an exhaustive review article on this subject matter (David et al., 2020).

LLMs have made notable progress in the field of NLP, particularly in terms of their reasoning capabilities. They are primarily intended for the analysis and interpretation of textual data. Nevertheless, there are practical situations in which textual data is linked to intricate graph structures or where graph data is combined with textual information. A thorough investigation by Jin et al. presents a detailed examination of scenarios and techniques pertaining to LLMs on graphs. The study categorizes these scenarios and techniques into three distinct types: pure graphs, text-rich graphs, and text-paired graphs. The paper explores various techniques for utilizing LLMs on graphs, including LLM as Predictor, Encoder, and Aligner. It also provides a comparative analysis of different models, highlighting their respective advantages and disadvantages. The paper also discusses practical applications and includes open-source codes and benchmark datasets (Jin et al., 2023d).

Graph neural networks for automated de novo drug design.

## Section: 3 Generative AI models › 3.6 CNNs

CNNs are a sort of artificial network that can automatically extract features from graph or image input by convolutional, pooling, and fully connected layers (LeCun et al., 1998; Rifaioglu et al., 2020; Sun et al., 2020). Running a short window across the input feature vector as a feature detector is a crucial component to the success of CNNs when applied to image processing (LeCun et al., 2015). This method enables a CNN to learn features from the input independently of their location in the feature vector, significantly improving its generalization ability. CNN and 2D molecular structure graphs come together in DeepScaffold (Li et al., 2019) to provide a complete scaffold-based de novo drug design solution. A wide variety of scaffold definitions may be used with this approach to build molecules, from cyclic skeletons to Bemis-Murcko scaffolds. One of the benefits of this approach is the ability to generalize the chemical principles for adding bonds and atoms to a given scaffold. By molecular docking of DeepScaffold-generated molecules to their corresponding biological targets, researchers were able to determine whether this method has potential for use in drug development. In another development, DeepGraphMolGen (Townshend et al., 2020) was developed using a graph CNN with RL to generate molecules with desired features. Since 2D graphs are a more natural molecular representation than SMILES strings, they were used in this technique for property prediction and molecular generation. Finally, a novel graph-based approach for drug design from scratch was developed. Figure 6 shows how a CNN works.

The CNN excels with atomistic geometry; hence, it is often used with the voxel (Townshend et al., 2020), (a voxel is a graphic data unit depicting a location in three-dimensional space). There have been several developments involving CNN. For instance, DEEPScreen (Rifaioglu et al., 2020), used a 2D representation of the molecule to predict the drug-target interaction (DTI), while RoseNet (Hassan-Harrirou et al., 2020), AK-score (Kwon et al., 2020), DeepDrug3D (Pu et al., 2019), and DeepPurpose (Huang et al., 2020), each transformed the receptor and ligand into a voxel for the same task. Although DeepConv-DTI (Lee et al., 2019), and transformer-CNN (Karpov et al., 2020), used the CNN framework for sequential input data to develop QSAR models, CNNs are (Karpov et al., 2020), not well suited for sequential expression strategies like SMILES (simplified molecular input line entry system) or protein building blocks.

In multimodal DTI prediction, a discriminative feature depiction of the drug-target pair plays a key role. Dehghan et al. proposed a novel multimodal method called TripletMultiDTI that leverages triplet loss and task prediction loss to accomplish this goal. This method provides a new framework that fuses the multimodal knowledge to predict interaction affinity labels. TripletMultiDTI also offers a novel loss function based on the triplet loss to learn more discriminative depiction. Using this model, researchers improved prediction results, as evident from the proposed approach’s evaluation on three putative datasets (Dehghan et al., 2023).

Palhamkhani et al. introduced DeepCompoundNet, a sophisticated model that employs DL to combine protein characteristics, drug properties, and various interaction data to predict chemical-protein interactions. This novel model surpassed the most advanced techniques in predicting compound-protein interactions, as evidenced by performance evaluations. The results of this study emphasize the synergistic relationship between various interaction data, which goes beyond the similarities in amino acid sequence and chemical structure. DeepCompoundNet achieved superior performance in predicting interactions between proteins and compounds that were not detected in the training samples (Palhamkhani et al., 2023).

(i) Illustration of the basic framework of a plain CNN (deployed to analyze an image, here a heart) consisting of convolutional layers, pooling layers, and a fully connected layer (ii) In the case of molecular design, a CNN input includes molecular structures or atom distances from molecular graphs.

## Section: 3 Generative AI models › 3.7 RNNs

The RNN is the most basic model for molecular GAI models. Perhaps the first team to use RNNs to generate compounds was Bjerrum et al. [ (Bjerrum and Threlfall, 2017). The concept came straight from the AI’s NLP subfield (Chowdhary and Chowdhary, 2020). The process of generating new molecules is recast as the creation of new, unique sequences of characters. These similar sequence models are sometimes called “seq2seq” (Sriram et al., 2017), because both the input and the output are sequences. Sequences from high-dimensional molecules are first reduced to a single dimension in the seq2seq procedure. Many programmes can do this. Owing to its long usage history and human legibility (Tang et al., 2020), the simplified molecular-input line-entry system (SMILES) is among the most used sequence string pattern for describing chemical structures. By modelling the molecule generation process as a series of phases (like phrase construction in a language translation job) and sampling from the network at each stage, it is possible to generate molecules that are likely genuine and chemically equivalent or improved versions of the training compounds (Olurotimi, 1994). An RNN may acquire the common associations between chemical building blocks after training on a known-molecule database. After training, the network can predict the degree of similarity between two atoms or functional groups. These probabilities will shift depending on whatever portion of the molecule the network has seen before. Attaching an extra model (like RL) as a property optimizer also yields unique compounds. Each input value impacts the subsequent output value when sequential data are fed into the RNN step by step.

Figure 7i illustrates an elementary RNN framework. The left side of this illustration indicates a folded RNN with a self-loop, which means the hidden layer s is used to modify itself depending on the input x. The right side of the illustration shows an unfolded RNN as a sequential framework to show its working. Sequential data x1, x2, . . , xt are fed to the RNN as input values, where at every step t, xt is a d-dimensional feature vector. For instance, if the model gets a group of words as input, then every word wi is shown as a vector xi. At every time-step t, the result from the preceding step, st-1, with the subsequent word vector in the document, xt, are leveraged to modify the hidden state st as st = f(Wst-1+Uxt) where f is the nonlinear activation function and U and W are the weights of inputs xt, and st-1 respectively. st, the hidden state, is the feature depiction of the sequence up to time t for the sequential input data. The opening states s0 are typically started as all 0. Thus, one can use it to accomplish various assignments like sentence building, document cataloguing, etc.

A similar idea may be used for generating molecules, as shown in Figure 7ii. The upper part of this Figure shows how an RNN applies logic to handle and process the information to generate the structure (right bottom). The y-axis displays all potential tokens that may be picked at each step; the color reflects the conditional probability for the character to be chosen at the current stage considering the previously picked characters, and the x-axis displays the character that was sampled in this case. The actual working of an RNN in structure-generation mode is shown in the bottom left part of the Figure. At every stage, a character is sampled based on the conditional probability distribution derived from the RNN, and the newly generated character will be utilized as the input for the next character to be generated.

Nonetheless, the fundamental RNN has a not-so-complex structure and has performance restrictions for uses in diverse contexts. The vanishing gradient problem is the most pressing issue. As the size of the input series increases, the influence of things distant from the presently inputted item decreases exponentially, resulting in low performance for lengthy data like proteins and other big molecules (Hochreiter, 1998). Moreover, training time is proportional to sequence length since the same operation is performed many times. Even in cases where the elements in sequential data have intricate associations, the features of these elements are not effectively learned. To address this vanishing gradient problem (which prevents the weights from being updated), the theory of long short-term memory (LSTM) was developed years ago and recently adopted extensively (Yu et al., 2019). In contrast to standard RNNs, the LSTM still performs well on longer data sequences. Several LSTM variants have been developed since its inception, and lately, gated recurrent units (GRU) with a simplified internal framework have also seen widespread use (Cho et al., 2014a; Mouchlis et al., 2021). Feeding a target protein sequence may be utilized for de novo drug discovery by arbitrarily generating small molecules (Jastrzębski et al., 2016). The LSTM and GRU outperformed the conventional RNN and are commonly used in drug discovery; however, there is still scope for newer methods to address the vanishing problem more effectively, especially for very long sequence data (Guimaraes et al., 2017; Popova et al., 2018; Martinelli, 2022). Validity, novelty, and variety improved when RL was coupled with a stacked RNN (Olivecrona et al., 2017; Gupta et al., 2018; Segler et al., 2018; van Deursen et al., 2020).

(i) The elementary framework of an RNN showing input unit (x), hidden unit (s), and output unit (o). Different weight matrixes are U (for the shift from x to s), V (for the shift from s to s), and W (for the shift from s to o). (ii) Structure generation from RNNs as part of DL-driven de novo molecular design in a sequential manner.

## Section: 3 Generative AI models › 3.8 Reinforcement learning

In RL, an agent learns to make successive choices in an environment to maximize a cumulative reward signal. In drug development, RL may optimize molecular characteristics in real-time throughout the design process if coupled with a GAI model. A drug discovery RL agent interacts with a representation of the chemical space, and at each step, it chooses an action (such as changing a molecule structure) that best fits its current situation. The generated molecule’s projected activity, binding affinity, and other attributes provide a reward signal to the agent. In this way, an RL algorithm, coupled with a GAI model, may generate compounds with desired qualities or optimize particular molecular attributes by iteratively exploring and utilizing the chemical space. Figure 8 indicates how an RL approach is used for generating optimized molecules.

Optimizing an agent’s ability to exert influence over its environment is made possible by RL theory, which offers a normative explanation based on psychological and neuroscientific views of animal behaviour (Mnih et al., 2015). The RL algorithm ensures that the GAI model is always optimized by constantly interacting with the environment and adopting actions to maximize predicted cumulative rewards. Unlike supervised and unsupervised ML, in which performance is limited by the availability of human previous knowledge and training data, RL is unconstrained by these factors and may provide superior results. The method may be used for various settings and issues (Chen, 2016; Li and Du, 2018; Zhu et al., 2018; Holcomb et al., 2019; Vázquez-Canteli and Nagy, 2019). AlphaGo is the most well-known application of RL algorithm ever since it beat human Go champions. REINVENT, developed by AstraZeneca researchers, is perhaps the first study linked to an RL-based model (Olivecrona et al., 2017), for applications in drug development. Drugs against dopamine D2 receptor, and analogues of the COX2 inhibitor, celecoxib, were generated, and their activities were predicted using this REINVENT. In developing REINVENT, a basic generative model based on RNNs was trained first; then, it used the RNN that had already been trained as a model for the agent network (Pal et al., 2018).

ReLeaSE (Popova et al., 2018), is another RL-based RNN model that uses a Markov decision process (MDP) to describe the generation of SMILES strings. It has fundamental RL components. In contrast to REINVENT, ReLeaSE employs a fully connected network prediction model as a reward function, which also requires pre-training. Both generative and predictive networks are crucial to ReLeaSE’s success. The authors behind ReLeaSE showed that ReLeaSE may be used to produce a library of JAK2 inhibitors. It may be challenging for the RNN to generate bioactive SMILES if the predictor is not trained appropriately. Motivated by the findings presented by Mnih et al., in 2015 (Mnih et al., 2015), Zhou et al. (Zhou et al., 2019), developed a generative model called Molecule Deep Q-Networks (MolDQN) by combining RL with chemical rules to circumvent issues with SMILES-based RL models. MolDQN guarantees complete chemical validity by specifying alterations to molecules in terms of adding or removing specific atoms or chemical bonds. Because MolDQN does not need specific training data, it is immune to biases introduced by the dataset on which it is used. The MolDQN model differs from the seq2seq models in that it describes the alteration of a compound as a molecular Markov decision process (MDP) (Van Otterlo and Wiering, 2012), and employs the deep Q-Networks (DQN) (Hester et al., 2017), to answer this MDP with the essential attributes as rewards. However, MolDQN’s performance while generating molecules is subpar. The stated modification only contains three distinct kinds (atom addition, bond removal, and bond addition); hence, it takes at least six steps for MolDQN to build a benzene molecule, for example,. All generated compounds have chemical significance; however, they may be too challenging to synthesize or have unfavourable drug-like qualities.

Covalent inhibitors to take on the SARS-CoV-2 major protease (a significant therapeutic target for COVID-19) were developed by Tang et al., in 2020 using an advanced deep Q-learning network with fragment-based drug design (ADQN-FBDD) (Tang et al., 2022). ADQN-FBDD is more effective at building molecules than MolDQN since it uses fragments rather than individual atoms. The DQN agent, guided by the reward function, picks out rewarding pieces to affix to the right spots in the current state (the intermediate structure). ADQN-FBDD generates more drug-like compounds because it considers chemical reaction laws and the three-dimensional shape of the binding site. As a result, ADQN-FBDD can effectively probe the chemical space around the given target.

The capacity of RL-based models to perform distributed computations is their greatest strength since this drastically shortens training times in many scenarios. When several computers are deployed, even the vast chemical space may be investigated efficiently (Horgan et al., 2018). However, the quality of the representation of the training data might significantly impact the performance of the models mentioned above. In contrast to efficient representations, which capture the most relevant information, ineffective representations lose key aspects while training AI models. Exciting new AI algorithms are being studied to fill this gap. For instance, researchers merged RL with variational inference in one of the studies to get better results (Fellows et al., 2019).

Demonstration of a basic RL model for de novo molecular design (i) A benzene ring at state St at iteration t, and an initial reward Rt at iteration t, (ii) the agent picks an action At which attaches a methyl group to benzene (iii) The environment takes this knowledge for generating a subsequent response that is St+1 state and a new reward Rt+1. This sequence of events goes on until the episode ends.

## Section: 3 Generative AI models › 3.9 Transformer

Relevance and meaning may be taught using a specific type of GAI called a transformer by tracing the links between sequential data, like the words in this statement. Transformer models apply to any input data as long as they use sequential text, picture, or video data. A transformer is used, for instance, whenever a person searches for something on search engine like Google, Bing, etc. GPT-4, BERT (Bidirectional Encoder Representations from Transformers), RoBERTa, XLNet, and Megatron-Turing NLG are all examples of transformers. To find how seemingly unrelated data points in a sequence impact and rely on one another, transformer models are used by leveraging a growing body of mathematical techniques collectively referred to as attention or self-attention. Transformers, first detailed in a Google study published in 2017 (Vaswani et al., 2017), are cutting-edge and highly effective GAI models. Nowadays, text and voice are being translated in real time by transformers, allowing a wider range of people, including those with hearing impairments, to participate in meetings and classes. In the medical field, transformers are being tried to assist scientists in deciphering gene and protein chains to expedite drug development. Technically, transformer models are huge encoding/decoding building components like most neural networks. The special power of transformers comes from the careful arrangement of their building components. Transformers use positional encoders to assign tags to data packets entering and leaving the network. The attention units then use these tags to create an algebraic map of the relationships between the various components. In multi-headed attention, attention inquiries are often conducted in parallel by computing a matrix of equations. Computers can now recognize patterns just as humans can with the help of these programmes (Monteiro et al., 2022).

The most common forms of DL only 5 years ago—CNNs and RNNs Networks—are being supplanted by Transformers. Seventy percent of the AI studies submitted to arXiv in the last 2 years make reference to transformers. This contradicts the findings of an IEEE research from 2017 that found RNNs and CNNs to be the most widely used models for pattern recognition. Before transformers were designed, users had to train neural networks to create large, labelled datasets, which was time-consuming and costly. Transformers eliminate this necessity by discovering mathematical patterns between portions of the billions of pictures and petabytes of text material stored in the internet and business databases. In addition, transformer mathematics is well-suited for parallel processing; therefore, these models are quick to execute. Popular performance leaderboards like SuperGLUE, a benchmark created in 2019 for language-processing systems, are now dominated by Transformers (Dosovitskiy et al., 2020).

A year later, another Google team tried processing text sequences both forward and backward with a transformer. This enhanced the model’s capacity to comprehend the meaning of a phrase by capturing more links between words. Their BERT model broke 11 records and was included in the Google search algorithm. Text is one of the most typical data kinds that businesses have; therefore, within weeks, researchers all across the globe were modifying BERT for use cases across various languages and sectors. BERT is especially adept at comprehending the context of words in a phrase since it was trained on a large text sample. A few activities that BERT is helpful for are sentiment analysis, named entity identification, and question-answering. Most information in the pharmaceutical industry is based on the structures of small molecules and comparatively larger molecules (receptors, amino acids, antibodies, etc.). The representation of these structures may take the form of strings or other sequences. For instance, DeepMind (an Alphabet-owned company) used a transformer known as AlphaFold2 to increase our knowledge of proteins. It processed amino acid sequences like text strings to establish a new watermark for characterizing how proteins fold. In another development, AstraZeneca and NVIDIA created MegaMolBART, a transformer specifically designed for drug discovery. It is a scaled-up version of the MolBART transformer developed by the pharmaceutical industry and trained on a sizable, unlabeled library of chemical compounds using the NVIDIA Megatron framework for creating large-scale transformer models. The academic health centre at the University of Florida also worked with NVIDIA researchers to develop GatorTron. This transformer model seeks to speed medical research by gleaning insights from vast clinical data (Devlin et al., 2018).

For generating drug-like compounds, Bagal et al. trained a transformer-decoder on the next token prediction task with masked self-attention, inspired by GPT models’ success in producing meaningful text. In terms of producing valid, unique, and innovative compounds, their model, dubbed MolGPT, performed on par with other recently suggested current ML frameworks for molecular generation. They also showed that the model may be taught conditionally to influence specific characteristics of the synthetic compounds. MolGPT may be utilized to build molecules with the desired scaffolds and property values by conditioning the molecule generation on scaffold SMILES strings with required scaffold chemical attributes (Bagal et al., 2021).

A recent finding emphasizes the growing interest in exploring bioactive molecules in cancer cell lines. The study proposes a novel DL-based approach called DeepTraSynergy for predicting drug combination synergy, recognizing the enhanced efficacy of multidisciplinary drugs in cancer treatment. The approach utilizes transformers to learn feature representations of drugs and incorporates multimodal input, including protein–protein interaction, drug–target interaction, and cell–target interaction. DeepTraSynergy employs a multitask strategy, predicting three outputs: toxic effect, drug–receptor interaction, and drug combination synergy, with synergy being the primary task. Three loss functions are defined:, toxic loss, synergy loss, and drug–protein interaction loss. DeepTraSynergy surpasses conventional and advanced models in predicting synergistic drug combinations on DrugCombDB and Oncology-Screen datasets, achieving accuracy values of 0.7715 and 0.8052, respectively. The evaluation of each component of DeepTraSynergy demonstrates its effectiveness, particularly highlighting the significance of incorporating protein–protein interaction networks in improving the prediction of synergistic drug combinations (Rafiei et al., 2023).

In conclusion, the attention technique analyses historical data concurrently, enabling the application of correlation with distant tokens without reduction, in contrast to the RNN, where only one hidden state is available. Furthermore, BERT have been used in drug discovery endeavors and have greatly improved natural language presentation by employing DL (Devlin et al., 2018). For DTI applications, the transformer model may be easily included in the prevalent RNN-based QSAR modelling. Pharmacological action predictions were made by Karpov et al. (Li et al., 2019) using a model that applied CNN to a transformer and used as input SMILES strings. For instance, by combining the protein sequence with CNN and the chemical structure with BERT, researchers proposed a molecular transformer DTI (MT-DTI) technique to estimate ligand-receptor binding affinity (Shin et al., 2023). In a similar vein to MT-DTI, but using BERT for protein and molecular structures, another group of researchers proposed a GCN-based method (Lennox et al., 2021). The goal of the transformer (in the context of chemical compounds) is to learn the connections between atoms, just as LLMs may learn the links between words in a sentence.

## Section: 3 Generative AI models › 3.10 LLMs and CLMs

As was previously noted, the groundbreaking product ChatGPT is making inroads, thanks to LLMs. Such LLMs are often constructed with the help of transformers. The latest version of ChatGPT has significantly increased interest in LLMs. It should be noted, however, that LLMs had already made substantial contributions in fields like voice recognition, machine translation, and part-of-speech tagging long before this. Hundreds of millions of users utilize ChatGPT, and there are other systems like Google’s Bard. Such systems have a straightforward method of operation. The user inputs a query, and the AI system responds with a string of words (technically tokens) in an autoregressive fashion, with each word feeding into the prompt for the next word’s generation.

Specialized transformers with hundreds of billions or, more recently, trillions of computable parameters exist behind the hood of an LLM. This model is then trained on enormous datasets taken from digitally accessible human-generated text such as that found on the internet. The cost of training such a huge model is high because it requires the employment of thousands of specialized pieces of computing hardware called graphics processing units (GPUs) to do the necessary trillions of mathematical calculations. The next-generation LLM GPT4 is more capacious and proficient in text and picture processing than its predecessors. It is probably not an exaggeration to state that LLMs like ChatGPT have effectively split times into two parts: before and after ChatGPT. Such models will undoubtedly inspire and inform future upgrades and advancements in GAI-driven drug development. The idea of analyzing sequence data and then producing new sequences (based on the grammar of these data) has been met with tremendous success, and it is currently being applied to chemical structures. In this sense, molecules may be seen as the building blocks of a chemical language (Figure 9) (Bralley, 1996).

There is a prescribed grammar for chemically valid compounds, just as in human language, in which discrete components (atoms, like words) may link (form bonds) only in specific ways. Different high-level features (such as physicochemical, biological, and toxicological) arise from the presence and arrangement of molecules’ constituent parts, giving rise to the concept of “semantic properties. De novo drug design (Elton et al., 2019), tackles the challenging topic of how to construct compounds afresh that are chemically valid (that is, syntax) and contain desirable pharmacokinetic and pharmacodynamic qualities (that is, semantics), making knowledge of the chemical language essential. The chemical cosmos that de novo designers must work with is enormous, with as many as 1060 tiny molecular entities to consider (Bohacek et al., 1996). This number is so high that it would be impractical to attempt a comprehensive enumeration. In particular, GAI has benefited de novo drug design domain from the current AI revival (in the form of DL) (LeCun et al., 2015). Chemical language models (CLMs) (Yuan et al., 2017; Segler et al., 2018), have been at the forefront of AI-driven de novo design. Since CLMs may theoretically synthesize many molecules in a single shot without expert-engineered rules, they show significant potential for navigating chemical space and exploring sparsely occupied places (Skinnider et al., 2021; Flam-Shepherd et al., 2022). CLMs use algorithms already established for NLP to understand chemical language. Simplified Molecular Input Line Entry Systems (SMILES (Weininger, 1988)), strings are an example of a string notation that enables this. Bioactive substances generated by CLMs and verified in investigations (Yuan et al., 2017; Merk et al., 2018b; Moret et al., 2021), show that this class of GAI may explore uncharted biochemical areas. DL algorithms have spurred a revival (Wiswesser, 1985; Öztürk et al., 2020), in using sequential molecular representations, initially developed for storing large databases and identifying molecules in the sequence processing field. The most popular molecular string representations for de novo design are:

Every representation may be seen as a separate chemical language with its own grammatical conventions that must be followed to produce chemically sound molecular entities. It has been noted that SELFIES can avoid the requirement to learn chemical grammar (since these strings always match genuine molecules) (Krenn et al., 2022). According to recent research, knowing the syntax of SMILES strings makes identifying and maintaining de novo designs that fit the target chemical space easier than SELFIES (Skinnider et al., 2021). This aligns with research in the NLP field (Russin et al., 2019), which emphasizes the advantages of syntax learning to provide improved semantical features. Overall, it seems that the improved performance of SMILES, SELFIES, or DeepSMILES is application-dependent, with generally modest differences (Chithrananda et al., 2020; Skinnider et al., 2021). InChI representations (explaining chemical compounds through layers of information separated by "/") were also employed with CLMs; however, their performance was very poor compared to SMILES. Compared to the complexity of structures like graphs, the simplicity of text generation makes molecular strings an appropriate representation for molecule generation. However, linear notations have other limitations, such as that atoms close together in the molecular graph may be far apart in the equivalent string (because of rings and branches). This may be the case since CLMs have been demonstrated to benefit from both bidirectional learning procedures (Flam-Shepherd et al., 2022) and the incorporation of language information (Kusner et al., 2017; Grisoni et al., 2020). Many flavours of GAI have been used for chemical language modelling (Liu et al., 2020; Öztürk et al., 2020).

Similarly, RNNs with memory cells (Hochreiter and Schmidhuber, 1997; Cho et al., 2014b), have found widespread usage (Brown et al., 2019; Polykovskiy et al., 2020; Flam-Shepherd et al., 2022), in drug discovery research. RNNs are often taught to create a single character at a time, with each character being informed by the characters that came before it in the molecular string. This allows them to be used to generate new molecular strings (Suresh et al., 2022). Other popular CLM architectures, as seen earlier in this review, are a) VAE, constituted by an encoder that converts molecular strings to latent vectors and a decoder that converts latent vectors back to molecular strings, and b) GANs, constituted by a generator network that produces novel molecular strings and a discriminator network aiming to distinguish between the de novo designs and existing molecules. Alternative DL approaches have been proposed for de novo design, for instance, molecular graph generation (Li et al., 2018b; Zhou et al., 2019) or fragment-based assembly (Jin et al., 2023c), but they have not been shown to outperform CLMs (Brown et al., 2019; Polykovskiy et al., 2020; Flam-Shepherd et al., 2022). Looking at the current progress and capabilities of powerful LLMs like ChatGPT and Bard, these CLMs can be used in various ways to assist drug discovery scientists, as mentioned below (Xue et al., 2023).

The large language model developed by the MIT/Tufts team (ConPLex) can match target proteins with potential drug molecules without performing the computationally intensive step of calculating the molecules’ structures. ConPLex can leverage the advances in pretrained protein language models (“PLex”) and use a protein-anchored contrastive coembedding (“Con”) to outperform state-of-the-art approaches. One recent review summarizes advances in AI-powered LLMs and their potential to aid drug discovery and development (Liu et al., 2021). Another review highlights opportunities for AI-powered LLMs in target identification, clinical design, regulatory decision-making, and pharmacovigilance (Chakraborty et al., 2023). To conclude, transformer, LLMs, GPT, BERT, and diffusion models are all interrelated in the context of generative AI. They are all based on the transformer architecture, a neural network architecture well suited for NLP tasks. The following Table 1 compares these GAI tools:

Frequent GAI, research in non-pharma domains, rapid adoptions of this in the pharma domain, and ongoing findings indicate that various shades of basic and advanced autoencoders and transformers will keep coming for better results emanating from GAI.

(i) An illustration showing the working of CLM on the basic framework of LLM; (ii) Principles of chemical language models (CLMs). (a) Example of a molecular structure (Kekulé structure) and a corresponding SMILES string. (b) CLMs are trained to iteratively predict the next SMILES character based on the preceding string characters. (c) Multinomial sampling can be used to generate new SMILES strings from trained CLMs, where SMILES characters are sampled with a weighted random sampling of probability distributions learned by the CLM.

Different types of GAI models.

## Section: 4 Data requirement for GAI in drug discovery

To succeed, the design of a new drug must account for a wide range of chemistry and biology parameters, including the drug’s on-target potency, specificity with respect to off-targets, physical qualities, and more. The standard approach of scientists sifting through a huge chemical space to find promising candidate compounds and then proving their worth experimentally is inefficient. The widespread use of GAI models is attributable, to a great extent, to their efficiency and accuracy in generating novel bioactive and synthesizable compounds. The downside is that GAI models are famously data-hungry, and drug discovery databases are infamously tiny (e.g., in the range of 101 to 104 known biologically active molecules). Transfer learning has been widely used for chemical space exploration to make the most of limited data sets. It is a two-step process with the goal of applying skills learned while completing one activity to another. First, during pre-training, GAI models are typically trained (for example, for predicting the next character in a molecular string) on a massive dataset comprising 105 to 106 molecules. The second phase involves refining this pre-trained generic GAI model using a select group of molecules with the necessary characteristics (such as bioactivity towards a specific pharmacological target). In low training data regimes, GAI models have shown potential for various applications, including generating bioactive compounds inspired by natural products and simultaneously learning many attributes. Multi-factor interaction is required for GAI to explore the chemical space successfully. Target molecule complexity affects the minimal number of molecules needed to train a reliable model. More complex and heterogeneous molecules need more training data. The breadth of the chemical space explored is proportional to the structural variety of the training molecules, for instance, in terms of molecular frameworks and structural assortment. Despite evidence that fine-tuning with 101–102 molecules may result in empirically proven biologically active designs, doing so may need more stringent post hoc ranking processes to evaluate just high-quality structures exclusively. Augmenting SMILES can improve the CLM performance, although this benefit decreases when the augmentation factor is increased (e.g., after a 10 to 20-fold augmentation, as shown in. Small training sets of molecules (not more than 10,000) benefit the most from SMILES augmentation, whereas its impact does not change massively for bigger sets of data of structurally complicated molecules (more than 500,000), perhaps with the danger of over-enumeration and decline in quality. Though hyperparameter tweaking may have minimal influence on the CLMs’ performance, the number of epochs required for refinement alters the semantical quality of the output and is dependent on the size and variety of the dataset (Moret et al., 2023).

Active learning, multitask learning, one-shot learning, federated learning (a sort of ML in which the model is trained by utilizing separate private data held in multiple places without sacrificing data privacy), etc., are many other methods (other than transfer learning and data augmentation) that may be used to make the most of the insufficient data. The originality and reliability of the resulting molecule from GAI are affected by several variables, including the nature of the data and the GAI model used. A few recent, well-drafted review articles might be helpful to readers in this respect (Goldman et al., 2022). Evaluating GAI models and the quality of their output is often more difficult and time-consuming than AI-based predictive models. This is because GAI tools sometimes need users to prioritize competing goals simultaneously (such as increasing the resemblance to known bioactive compounds while simultaneously increasing structural uniqueness). Accordingly, doing a thorough case-by-case analysis of the structures is recommended by drawing on both domain experience and supplementary computational methods (such as pharmacophore models and molecular dynamics). One obstacle to a comprehensive assessment of GAI tools is the time and money needed for chemical synthesis. Rapidly navigating the chemical space using GAI models will be possible in the future with the help of self-driving laboratories (Schneider, 2018).

## Section: 5 GAI in drug discovery: recent advances

Though at relevant places, we have discussed applications of GAI in molecular property prediction and de novo drug design, in this section, we will see a few recent applications of GAI in drug discovery. GAI models with a track record of effectiveness in other areas are finding growing use in the study of molecular generation. One recent work, probably the first to build on the success of ChatGPT, used the autoregressive model to create a tool called DrugGPT for ligand creation, emphasizing protein-ligand discovery and chemical space exploration (Li et al., 2023). To find new compounds that can associate with specific proteins, researchers in this work used the DrugGPT model to learn from a large quantity of protein-ligand binding data. The GPT-2 model was trained and optimized to meet the needs of the pharmaceutical industry. To accommodate the unique properties of proteins and ligands, they discarded the original tokenizer in favor of a BPE-based redesign and started training the GPT-2 model from scratch. DrugGPT can better record and comprehend drug compounds’ chemical rules and structural details with this update. It also improves its ability to interpret data on the interactions between proteins and ligands, which might lead to the development of novel therapeutics. To prevent the training process from becoming unstable due to the Mode Collapse issue of GANs, DrugGPT uses the back-propagation approach during model training. In addition, DrugGPT’s design philosophy gives it robust generalization capabilities, allowing it to learn and adapt to new tasks. GAI may be a new catchword lately, but Insilico Medicine, a drug development company, has used it for years. Early investment in DL is paying off for the firm, as a drug candidate found using its AI platform is moving forward into Phase 2 clinical trials for treating idiopathic pulmonary fibrosis. This rare respiratory condition causes a gradual deterioration in lung function. Insilico employed GAI throughout the preclinical drug development process to achieve this breakthrough, from identifying a new target to generating novel drug candidates to assessing the binding affinity of these candidates to the target to predicting the success of clinical trials. Using standard procedures would have required spending over $400 million and taking up to 6 years. Contrarily, Insilico could do these tasks using GAI in a third of the time and for a 10th of the expense, completing the first phase of clinical trials in little over two and a half years. In yet another study, the benefits of quantum GANs in generative chemistry were investigated. The authors presented a quantum-classical GAN hybrid for finding small molecules. The model’s quantum part is a variational quantum circuit (VQC), a quantum computer software suitable for molecular computations. The physicochemical features of the generated molecules and the model’s performance in a goal-directed benchmark were only two ways the authors demonstrated that the quantum GAN is superior to its classical counterpart. Based on their findings, the scientists think quantum GANs might be helpful in the field of drug development. In addition to being more effective than traditional GANs, the molecules they generate have superior characteristics. Nonetheless, the scientists acknowledge several remaining hurdles to overcome before quantum GANs are routinely employed in drug development. The scarcity of and the need for more sophisticated VQCs are contributing factors. Overall, the findings of this article are intriguing and show promise for using quantum GANs in the pharmaceutical industry. However, whether or not this promise may be realized requires more study (Mao et al., 2023).

Another study suggested a GAN based on a transformer for developing antiviral drugs. Researchers introduced a unique data-driven self-supervised pre-training generative model named “TransAntivirus” to perform select-and-replace edits on organic compounds and transform them into the necessary attributes for generating antiviral candidate analogues. The scientists proposed that molecular structures might be encoded in a more informative fashion by using transformers. They demonstrated that the transformer-based GAN is superior to previous GAN-based models in combating viruses. As a result of using this paradigm, it is possible to produce molecules with desirable characteristics like high binding affinity to the target protein and low toxicity. The model was also deemed more original, credible, distinctive, and varied than its baseline counterparts. As this is simply a proof-of-concept study, further investigation is required to evaluate whether transformer-based GANs can be utilized to identify novel medications in a realistic scenario. In addition, the scientists here only examined a tiny sample of compounds. It may be even more effective if the model were trained on a more extensive data set (Yu et al., 2023).

In another study, researchers detailed how they used generative models and structure-based drug design (SBDD) to find the macrocyclic CDK2 inhibitor QR-6401 more quickly. The scientists employed a generative model called FBVAE to develop a unique and proprietary lead CDK2 chemical 10 from previously reported CDK inhibitors. After using SBDD to improve compound 10 further, researchers isolated the macrocyclic inhibitor QR-6401. An IC50 of 0.46 nM was observed for QR-6401, indicating that it is highly active and selective against CDK2. The anti-cancer activity and oral bioavailability in an OVCAR3 ovarian cancer xenograft model were similarly promising. By combining generative models with SBDD, the scientists found that they could speed up finding novel medications. With QR-6401 as a proof-of-concept, generative models and SBDD are expected to be employed to find other effective drugs (Ren et al., 2023).

AlphaFold was recently employed to hasten the identification of a new CDK20 inhibitor. Before determining the exact fold of CDK20, the authors utilized AlphaFold to make educated guesses. The team then utilized this model to create a library of synthetic chemicals with binding predictions for CDK20. After synthesis and in vitro testing, it was shown that one of these compounds, ISM042-2-048, inhibits CDK20 activity in a particular and effective manner. AlphaFold, the scientists believe, may hasten the identification of novel medications by offering high-quality protein structures for use in generating computational compounds. Compared to conventional drug discovery strategies, their strategy only took 30 days to uncover a new CDK20 inhibitor. AlphaFold predictions may be used to create virtual molecules, which can then be utilized to discover new therapeutic targets. AlphaFold’s precise protein structures aid in discovering new therapeutic targets and quickening the pace at which new medications are brought to market (Drugdiscoveryonline, 2022).

A comprehensive review by Bai et al. delves into the application of DL and molecular docking in the field of de novo drug design. This method entails training a DL model to produce a molecular SMILES library. The generated molecular structures are then transformed into 3D ligands for docking with receptor targets. Binding affinity prediction for de novo drugs is conducted through virtual screening using DL models. Several tools, including SyntaLinker, Ligdream, GCPN, MolDQN, and others, utilize different DL techniques for molecular generation and optimization. Various models, including DeepDTA, Pafnucy, OnionNet, AttentionDTA, and GraphDTA, use deep CNNs and attention mechanisms to achieve precise binding affinity predictions between drugs and targets (Bai et al., 2022).

Below Table 2 shows some of the under investigation (clinical trial stage) molecules that emanated from AI:

Some DL-derived, under investigation (under clinical trials) drug candidates.

## Section: 6 GAI in drug discovery: challenges and opportunities

AI has recently taken the drug development industry by storm, allowing researchers to generate entirely novel compounds from scratch. The crucial driving force (Bickerton et al., 2012) of the international pharmaceutical business remains small molecules; therefore, GAI technologies are here to stay and reshape the current ways to discover or design drug molecules. There is growing evidence that GAI may be used to investigate hitherto undiscovered areas of chemistry. This is mainly due to the simplicity with which molecular strings (in the case of CLMs) can be generated and used and the breadth of tasks to which they can be put. We anticipate that future developments in LLMs/NLP algorithms and the addition of medicinal chemistry skills will further drive GAI’s capabilities in drug discovery. Despite GAI’s potential, many obstacles must be overcome before it can be extensively used in drug development. Optimizing toy yardsticks (such as molecular weight, octanol-water partitioning coefficient, or the quantitative estimation of drug-likeness (Renz et al., 2019), is a common way to assess the efficacy of GAI models. These goals capture the capability to generate compounds that meet set criteria, but they do not do justice to the complexity of actual drug development (and their exact behaviour/fate in biological system) and may result in simplistic answers (Merk et al., 2018b; Moret et al., 2021). Although they do not entirely address the quality of the generated compounds, existing de novo design benchmarks (such as GuacaMol (Brown et al., 2019) and MOSES (Polykovskiy et al., 2020), provide a way to ensure comparison across techniques developed separately.

Due to the computational difficulties inherent in assessing the quality of de novo designs, experimental validation represents the gold standard. Thus far, only a handful of potential GAI applications have been published (Li et al., 2020b; Grisoni et al., 2021; Moret et al., 2021). Implementing GAI into practical use will need cooperation amongst DL experts, cheminformaticists, and medicinal chemists. Although automated synthesis platforms may restrict the chemical space available for synthesis, they may be a viable alternative to speed up de novo design driven by GAI (van Tilborg et al., 2022).

Though BERT and GPT models have been used to comprehend molecular structures in the case of chemical compounds, their effect on drug development has not been particularly noteworthy thus far. Predicting DTIs computationally is another hurdle. The lack of labelled data is a significant challenge in training models working with peptides or proteins rather than small compounds. However, if LLMs can handle peptide and protein sequences as text, they may be able to make a difference in this field. In addition, with the latest advancements in DL, we can now predict which medication combinations will be most successful against complicated illnesses by gaining insight into the interaction between small compounds and genetic alterations. This demonstrates the promise of building GAI models that integrate data from many linked domains, such as chemical structures and gene expression. Large CLMs may be developed similarly to LLMs by learning from existing examples of such models.

The importance of conditional generation algorithms is predicted to grow in the coming years. These techniques may enable the generation of molecules designed to meet specific requirements, potentially overcoming the limits of current scoring systems (for instance, because of non-additivity, activity cliffs (Kwapien et al., 2022; Özçelik et al., 2022). A promising structure-based design may address de novo design for as-yet-undiscovered macromolecular targets (Volkov et al., 2022), by producing molecules that match specific binding sites’ electrostatic and shape properties. Potential shortcomings and bias in available protein-ligand affinity databases may account for the lacklustre practical implementation of structure-based de novo design (Graff et al., 2021). There is untapped potential in fields like polypharmacology and selectivity that might benefit significantly from fine-grained control over various aspects of de novo designs. Exorbitant expense (of GAI setup) and biased GAI models are further obstacles. If drug candidates are generated using biased models, they may be unsafe, ineffective, or reflect the biases of the experts. Cloud computing is one option to overcome the problem of high processing costs. Thanks to cloud computing, researchers no longer need to invest heavily in expensive computer gear to access extensive computing resources. The time and money required to train GAI models (and address the issue of inadequate data) may be cut drastically. As previously said, another option is to use transfer, active, and federated learning. Alternatively, one might try several data augmentation methods. As a result, GAI models may be less susceptible to bias due to data noise. Debiasing methods are another option since they may be used to either discover and eliminate biased features from the data or to alter the model’s weights to lessen the bias (Taly et al., 2019; Abdel-Aty and Gould, 2022).

Future applications of GAI models are anticipated to be bolstered by few-shot learning methodologies paired with large-scale pre-trained CLMs (Gao and Coley, 2020). The practical usefulness of CLMs in drug development is also likely to grow as their capacity to suggest synthesizable compounds is enhanced (Krenn et al., 2022). Expanding chemical languages to include increasingly complicated molecular entities, such as proteins and peptides with non-natural amino acids, also holds considerable promise for expanding the use of GAI tools in chemistry. Recent discussions (Bender and Cortés-Ciriano, 2021), have gone further on how SELFIES may be further developed to tackle the problems with existing molecular string representations, and these ideas could inform new iterations of SMILES and DeepSMILES as well. The function of GAI models in the drug development process is anticipated to grow in importance. GAI will improve time and cost efficiency by accelerating our ability to explore undiscovered parts of the chemical space and to create and test fascinating new scientific ideas for drug discovery. Experts in AI, chemistry, and biology will be able to work together in the future to create cutting-edge algorithms infused with scientific information and to acquire AI-powered novel insights into human biology. In their two reviews, Bender et al. (Gao and Coley, 2020; Bender and Cortés-Ciriano, 2021), explained what has been achieved and what lacunas are hindering major fruits in AI-driven drug discovery. Readers are referred to these two articles for an in-depth analysis of why other domains are getting more benefits from AI versus biological and chemical domains, primarily the drug discovery domain (Zhang et al., 2023).

## Section: 7 Summary and future directions

The development of GAI has had a profound impact on finding novel drugs. This article examines where GAI models are and how they may help researchers find new drugs. The molecular generators based on simple CNNs, GNNs, and RNNs may be somewhat efficient. All VAE, GAN, and related methods use a variational inference strategy. RL differs from variational inference because it allows real-time process tuning to produce the unique molecules of interest. There is great potential for these GAI methods, together with highly effective and modern transformers and LLMs, to profoundly alter the area of drug development. However, GAI models need vast and varied datasets of compounds to learn to produce new molecules with desirable features, even though current development and quick advancements in the algorithm imply that the future of GAI in drug discovery is quite promising. However, getting access to such databases may be time-consuming and costly. Although many techniques exist for dealing with insufficient data, new methods need to be developed so that GAI may be used to its full potential, just as in other fields. Research into various AI applications (such as autonomous vehicles, computer vision, and NLP) may be used for AI-driven drug development since the underlying algorithms are universal and need domain-specific adjustments to meet the particular requirements of chemical compounds and biological macromolecules. More and more scientists, enabled by today’s technology, are beginning to appreciate parallel and distributed computing for its many benefits. Furthermore, GAI models need to be interpretable to be helpful for drug development. This necessitates that researchers know why and how the model creates certain chemicals. There must be a high degree of data robustness in GAI models. This is because the training data for these models is often imperfect and contains noise. Despite these limitations, GAI models are promising to revolutionize drug discovery. These models can potentially speed up and lower the overall cost of drug development by automating the generation of novel compounds. There is a good chance that GAI models will play a crucial part in developing novel drugs as technology advances and GAI models become more sophisticated and as the difficulties of data insufficiency, model interpretation, bias, and computational expense are overcome. We are certain that GAI will revolutionize the drug discovery process and that, when combined with more conventional methods, we will see remarkable advances in the generation of life-saving compounds.

## Section: Funding Statement

The author(s) declare that no financial support was received for the research, authorship, and/or publication of this article.

## Section: Author contributions

AG: Conceptualization, Investigation, Editing, Writing–original draft. AA: Conceptualization, Investigation, Writing–original draft. IA: Conceptualization, Software, Writing–original draft, Writing–review and editing. AA: Conceptualization, Funding acquisition, Validation, Visualization, Writing–review and editing. VK: Funding acquisition, Writing–review and editing. VS: Funding acquisition, Writing–review and editing. LW: Project administration, Investigation, Resources, Writing–original draft.

## Section: Conflict of interest

The authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.

## Section: Publisher’s note

All claims expressed in this article are solely those of the authors and do not necessarily represent those of their affiliated organizations, or those of the publisher, the editors and the reviewers. Any product that may be evaluated in this article, or claim that may be made by its manufacturer, is not guaranteed or endorsed by the publisher.


---

# Global Harmonization of Artificial Intelligence-Enabled Software as a Medical Device Regulation: Addressing Challenges and Unifying Standards

- **Authors:** Sandeep Reddy
- **Issuer:** Mayo Clinic proceedings. Digital health
- **Type:** Scientific article
- **Published:** 2024-12-24
- **Language:** en
- **DOI:** 10.1016/j.mcpdig.2024.100191
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40207007/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractThe growing incorporation of artificial intelligence (AI) into medical device software offers substantial prospects and regulatory hurdles. As AI software as a medical device (AI-SaMD) continues to advance, ensuring its safety, effectiveness, and security is paramount. Nevertheless, the regulatory environment needs more cohesion, with various regions implementing diverse strategies. This paper underscores the necessity for globally harmonized AI-SaMD regulations by examining key regulatory frameworks from the United States, the European Union, China, and Australia. The article also explores crucial elements for harmonization, including algorithm transparency, risk management, data security, and clinical evaluation. Furthermore, the paper advocates for implementing international standards and global data security protocols, emphasizing the significance of cross-border cooperation to ensure the worldwide safety and efficacy of AI-SaMD.

## Section: Text

Artificial intelligence (AI) software as a medical device (AI-SaMD) has the potential to revolutionize patient care, bolster clinical decision-making, and enhance health care systems worldwide.1 However, the swift progress of these technologies has surpassed the development of regulatory frameworks, calling for harmonized global regulations to safeguard patients, foster trust, and promote innovation.2,3 As these technologies become increasingly sophisticated and widely adopted, ensuring their safety, effectiveness, and dependability is paramount.2 The diverse regulatory approaches across different countries and regions pose challenges for manufacturers seeking to enter global markets.4 This lack of uniformity may impede innovation, limit patient access to cutting-edge medical technologies, and create uncertainty for developers and health care providers. This article examines the pressing need for harmonized global regulations for AI-SaMD, focusing on regulatory frameworks in the United States, the European Union, China, and Australia.

## Section: Text

Current AI-SaMD Regulatory Landscape in the United States, European Union, China, and Australia

Similarities and Differences Between the Current AI-SaMD Regulatory Landscape in the US and EU

Critical Components for Harmonized Regulation of AI-SaMD

Harmonized regulatory framework for AI-SaMD.

## Section: The Current Regulatory Landscape: A Patchwork of Approaches

Artificial intelligence is increasingly being integrated into health care systems worldwide, with various regulatory bodies taking steps to ensure its safe and effective use.2 Regulatory frameworks are being developed to balance innovation with safety, particularly in the case of AI-driven medical devices.5 These frameworks often take a risk-based approach, classifying AI systems by their potential impact on patient care and applying more stringent requirements to those with higher risks. In addition to addressing safety concerns, regulators prioritize transparency, accountability, and ethical considerations. Regions such as the United States (US), the European Union (EU), and others are actively shaping their policies, though the specific details and implementation strategies vary.6 Although the US and the EU have been at the forefront of developing regulatory frameworks for AI-SaMD, other regions, such as China and Australia, are also actively working toward establishing their guidelines and standards (Table 1). This article delineates the diverse regulatory approaches adopted by these regions. The selection of these regions illustrates regulatory measures in regions with substantial AI activity or highlights diverse approaches to regulation.

Current AI-SaMD Regulatory Landscape in the United States, European Union, China, and Australia

## Section: The United States

The US regulatory approach to AI, particularly in health care, is characterized by a sectoral model that leverages existing federal laws and guidelines and aiming to introduce specific AI legislation and a dedicated federal regulatory authority in the future.7,8 There needs to be comprehensive federal legislation directly regulating the AI development or prohibiting its use. Instead, the US relies on existing laws like the 21st Century Cures Act, which, for instance, exempts specific clinical decision support software from the Food and Drug Administration (FDA) regulation under conditions. Although comprehensive AI law is still under debate, various frameworks and guidelines offer guidance. These include the SAFE Innovation AI Framework, a bipartisan set of principles encouraging federal AI law-making. However, the FDA plays a central role in regulating the AI-SaMD.9

The FDA approaches artificial intelligence/machine learning (AI/ML)-based software from the perspective that if its purpose is to treat, diagnose, cure, mitigate, or prevent diseases, it is classified as a medical device, regardless of its technology.10 This applies even if the software is consumer-facing, such as an application on a smartphone. This approach is consistent with the FDA’s role in ensuring the safety and effectiveness of medical products. Most AI/ML-based products considered as medical devices are categorized as SaMD. The FDA distinguishes between SaMD and software in a medical device (SiMD). The SiMD is integral to the hardware of a medical device, such as software that controls an X-ray panel. The SaMD, on the contrary, performs its medical purpose without being part of a hardware medical device. The SaMD includes software that aids stroke detection and diagnosis by analyzing magnetic resonance imaging images and computer-aided detection software for detecting breast cancer using medical images.

The FDA employs a risk-based strategy to oversee all medical devices, including SaMD.10,11 Devices classified as Class I present the lowest risk, such as programs that merely show readings from a continuous glucose monitor. Most Class II devices, deemed moderate to high-risk, necessitate a 510(k) review.12 This process requires manufacturers to prove to the FDA that their device is substantially equivalent to an existing device with the same intended purpose. Class III devices carrying the highest risk must undergo premarket approval. The FDA acknowledges that the iterative and adaptive nature of AI/ML software used in SaMD presents a unique regulatory challenge, as the AI/ML algorithms can evolve after the SaMD has been distributed and collects data from real-world usage. This has led the FDA to consider modifying its approach to premarket review for AI/ML-driven software changes.

In April 2019, the FDA issued a discussion paper outlining a proposed regulatory framework for AI/ML-based SaMD modifications to enable manufacturers to enhance performance and safeguarding patients from potential risks.13 The proposed framework is on the basis of a total product lifecycle (TPLC) approach,14 enabling the FDA to evaluate and monitor a product from premarket development through postmarket performance. The 4 pillars of the proposed TPLC framework are:

In January 2021, the FDA published an Action Plan11 on the basis of stakeholder feedback on the 2019 discussion paper13 that describes a multipronged approach to regulating AI/ML-based SaMD. The FDA committed to developing guidance on predetermined change control plans (PCCPs) as part of the action plan. The PCCPs allow manufacturers to prespecify planned modifications to their AI/ML-based SaMD and the methodology they will use to implement them. If the modifications are implemented according to the PCCP, manufacturers would not have to submit a new marketing submission each time a change is made. A PCCP would generally include:

The FDA published draft guidance on PCCPs in April 2023.14 The draft guidance describes the PCCP as an approach that would support the ability to modify ML-enabled device software functions and ensuring patient safety and effectiveness. In addition to developing guidance, the FDA supports research to develop methods for evaluating and improving AI/ML algorithms, including identifying and eliminating bias. The FDA is also working to encourage harmonization among technology developers on the development of good machine learning practice.8,15 The agency plans to update its regulatory framework further on the basis of stakeholder feedback.

## Section: The European Union

The AI Act (AIA) exemplifies the EU’s risk-based strategy for regulating AI.16 This comprehensive legislation establishes uniform guidelines for developing, commercializing, and using AI systems across diverse industries, including the health care sector.7,16 The EU champions a human-centric philosophy toward AI, emphasizing crucial elements such as AI systems’ safety, transparency, responsibility, equity, and environmental sustainability. Within the EU AI Act, AI systems are classified into 4 tiers of risk, each with its own set of stipulations and responsibilities:

In addition to the AIA, other relevant EU regulations impact AI in health care, such as the general data protection regulation, which governs the processing of personal data and the MDR, which regulates medical devices, including those incorporating AI.17,18 The MDR, under which AI-SaMD falls, mandates stringent requirements for the design, development, clinical evaluation, and postmarket surveillance of medical devices, including AI-powered ones.17 The EU’s regulatory framework for AI is still under development, with the AIA representing an important milestone in establishing comprehensive rules for this rapidly evolving field.7,16 The EU’s approach emphasizes a balance between fostering innovation and mitigating risks, aiming to establish itself as a global leader in trustworthy AI.

The EU also emphasizes international collaboration in AI governance, particularly with the United States.19 Aligning AI governance between these regions ensures a democratic approach to AI development and deployment (Table 2). The EU actively participates in international regulatory cooperation to facilitate information exchange on the safety of medical devices and to promote the adoption of global regulatory guidelines that ensure equivalent levels of health and safety protection globally.7

Similarities and Differences Between the Current AI-SaMD Regulatory Landscape in the US and EU

## Section: China

The Chinese government’s strategy for regulating AI is marked by a dynamic and proactive approach, combining top-down directives with specific regulations for various AI applications.20 The primary aim is to ensure AI development aligns with national objectives, such as preserving social stability, stimulating economic growth, and achieving technological supremacy, as outlined in documents like the new generation AI development plan (2017).7,20

China’s regulatory framework for AI considerably emphasizes algorithms employed in content recommendation and synthetic content creation.7,20 This is exemplified by the provisions on the administration of deep synthesis internet information services, which addresses AI-driven generation or modification of online content, including deepfakes.7 These regulations underscore China’s apprehension regarding AI’s potential to disseminate misinformation and disrupt social order. They mandate content labeling, adherence with information controls, and measures to prevent misuse, reporting a pre-emptive approach to mitigating potential risks associated with AI-generated content. Furthermore, China has been shown swift action in response to the rise of generative AI, as evidenced by the draft measures for the management of generative AI services after the widespread adoption of Chat Generative Pretrained Transformer.7

The Chinese model of AI governance adopts a phased implementation strategy, beginning with specific regulations on recommendation algorithms and profound synthesis.20 These initial regulations serve as a foundation for a comprehensive national AI law, indicating China’s intention to establish a robust and all-encompassing legal framework for AI.7 This approach enables iterative development and refinement of regulations in response to technological advancements and emerging risks. China’s strategy reflects a delicate balance between controlling AI’s potential risks and fostering innovation to achieve global AI leadership by 2030. The government acknowledges the need to address ethical concerns and potential societal impacts of AI whereas cultivating an environment conducive to technological progress.20 This is evident in the ongoing discourse surrounding the balance between information control and the promotion of technological development, particularly in the context of generative AI.

The cyberspace administration of China has emerged as a prominent regulatory body for online content, shaping AI governance related to algorithms and content generation.7 However, the Ministry of Science and Technology influences AI’s ethical development and use. The development of AI regulations involves various stakeholders, including think tanks, academics, and industry experts, highlighting a collaborative approach to policymaking, even within a politically constrained environment. In addition to the specific AI regulations, other laws, like the Personal Information Protection Law, influence data handling practices and impact AI development within China.7

China is actively developing its regulatory framework for AI-SaMD as part of its broader AI development plan.20 Critical aspects of China’s approach, include the publication of proposals and standards for AI-based medical devices, a focus on balancing innovation promotion with ensuring safety and effectiveness, stringent requirements for software registration, and an emphasis on comprehensive regulatory guidance for international manufacturers. As China continues refining its approach to AI-SaMD regulation, it aims to create a framework that fosters innovation although maintaining high patient safety and product efficacy standards.

## Section: Australia

Much like the US, Australia’s current approach to AI regulation is characterized by a voluntary and principles-based framework, primarily guided by the AI ethics principles21 published in 2019. Although not legally binding, these principles aim to foster the development and implementation of safe, secure, and reliable AI. The AI ethics principles prioritize human, societal, and environmental well-being, emphasizing human-centered values and fairness in AI systems. This focus underscores Australia’s commitment to ensuring AI benefits all Australians and minimizing potential harm. Australia still needs to enact specific laws or regulations directly governing AI. Existing laws like the Online Safety Act 2021 and the Australian Consumer Law can be applied to address AI-related Issues.7 However, there is a recognized need for a more comprehensive regulatory framework tailored explicitly to AI.

In Australia, the Therapeutic Goods Administration (TGA) oversees the regulation of all medical devices, such as software, mobile applications, and AI-based systems.22 The TGA classifies AI as a medical device designed for diagnosing, preventing, monitoring, predicting, forecasting, treating, or alleviating diseases, injuries, or disabilities.23 This broad definition encompasses numerous AI applications within the health care sector. The regulatory framework for AI medical devices in Australia is governed by the Therapeutic Goods Act 1989 and the Therapeutic Goods (medical devices) Regulations 2002.7 AI medical devices must be listed on the Australian register of therapeutic goods to be legally distributed in Australia.22

Like large language models, software incorporating generative AI is regulated as a medical device if it meets the TGA’s definition.23 This includes AI text-based products like generative pretrained transformer-4, highlighting the TGA’s proactive approach to regulating emerging AI technologies. The TGA mandates that developers of AI medical devices, including those using generative AI, provide clinical and technical evidence reporting the product’s safety, reliability, and performance.22,23 This ensures that AI medical devices meet the same rigorous standards as other medical devices. The TGA emphasizes that developers adapting or incorporating large language models into products offered in Australia are considered the manufacturers and are thus responsible for meeting all regulatory obligations, including those related to privacy, data security, cybersecurity, and advertising.

Australia’s approach to AI regulation is evolving. Although the current framework relies on voluntary principles and the application of existing laws, the government is actively exploring more comprehensive regulations, particularly for high-risk AI applications.7 The TGA’s proactive approach to regulating AI as a medical device, including emerging technologies like generative AI, reports a commitment to ensuring AI’s safe and effective integration into health care in Australia.

## Section: Harmonized Regulation

The varied regulatory frameworks across nations and regions create obstacles for manufacturers aiming to penetrate global markets.4,5 This inconsistency may hinder progress, restrict patients’ access to state-of-the-art medical technologies, and generate ambiguity for developers and health care professionals. Also, the varied regulatory structures may hinder multicenter AI clinical trials.24,25 There is also likely to be a risk of regulatory arbitrage where AI vendors may market less safe or less efficacious applications in regions with less stringent regulatory processes.26 There is an urgent requirement for standardized worldwide regulations concerning AI-SaMD that tackle crucial issues in transparency, risk management, data protection, and clinical evidence.22,27 To ensure patient safety and foster innovation, regulatory frameworks must establish clear guidelines for accountability, risk assessment, data protection, and performance evaluation. This comprehensive approach can build trust among stakeholders and accommodating AI’s unique characteristics in health care. The following are the critical components for consideration in developing harmonized regulation (Table 3).

Critical Components for Harmonized Regulation of AI-SaMD

## Section: Transparency and Accountability

Transparency and accountability are imperative for fostering trust in AI-SaMD.2,27 Regulatory frameworks must mandate comprehensive documentation of AI models and decision-making processes for effective oversight. Manufacturers should elucidate their AI models’ decision-making, particularly in high-risk applications, and maintain detailed training data records, model architecture, and performance metrics. Systems should track and record decision-making processes for post-hoc analysis. These measures collectively enhance transparency and accountability within the AI-SaMD ecosystem.

Beyond documentation, transparency and accountability encompass rigorous development, deployment, and continuous monitoring of AI technologies.27 Regulatory frameworks should necessitate regular audits and inspections to verify safety and efficacy, particularly for high-risk medical applications.13,15,27 Clear guidelines for reporting adverse events or unexpected outcomes should be established to ensure expeditious issue resolution and patient safety. Manufacturers should also implement user-friendly interfaces, enabling health care professionals to comprehend and interpret AI-generated recommendations. This transparency facilitates clinicians in making informed decisions rather than uncritically after automated suggestions. By promoting openness and responsibility, these measures engender public trust and ensure the ethical development and utilization of AI in health care.

## Section: Risk Management

Risk management in AI-SaMD faces distinct challenges due to AI’s adaptability and potential biases.2,27 Harmonized regulatory frameworks must integrate comprehensive risk assessment methodologies to ensure patient safety, considering the AI’s dynamic nature, which necessitates ongoing risk evaluation throughout the product lifecycle. Frameworks should mandate manufacturers to identify and mitigate biases in AI models, especially those affecting different patient populations. Real-world performance monitoring is essential to identify and address emerging risks.15 In addition, regulatory frameworks must be flexible to keep pace with AI advancements although upholding stringent safety standards.1,28 Regular audits and inspections by independent third parties should verify adherence and ensure continuous safety and efficacy. Manufacturers must also implement robust cybersecurity measures to protect AI-SaMD systems from threats and unauthorized access. Finally, a standardized reporting system for AI-SaMD adverse events should be established to identify and resolve issues quickly.

## Section: Data Security

Ensuring data security for AI-SaMD is a complex challenge, necessitating comprehensive regulatory standards and robust technical implementations to address data breaches and sophisticated threats like adversarial and cyberattacks.27 Essential security controls include robust data storage and transmission encryption to protect sensitive patient information, even if intercepted. Strict access controls and authentication mechanisms must limit data exposure to authorized individuals. Manufacturers must prove their systems’ resilience against adversarial attacks, which could manipulate AI model outputs, leading to incorrect diagnoses or treatment recommendations.13,29 This requires rigorous testing and validation. Privacy-enhancing technologies, such as federated learning and differential privacy, should be encouraged or mandated, allowing AI model development and minimizing individual patient data exposure. These measures collectively form a comprehensive security framework to protect against current threats and future challenges in AI-SaMD.

## Section: Clinical Evidence and Performance

Clinical evaluation standards for AI-SaMD are essential for ensuring patient safety and treatment efficacy.11,27 These standards should include comprehensive performance metrics for objectively comparing different AI-SaMD products, such as precision, recall, specificity, positive and negative predictive values, and algorithmic fairness and bias measures. In addition, guidelines for collecting and using real-world data should complement traditional clinical trial evidence, offering a holistic view of AI-SaMD performance in diverse settings.15 Standardizing postmarket surveillance across regulatory bodies would enhance the ongoing evaluation process, ensuring consistent assessment after market introduction and detecting unforeseen issues or performance degradation over time.13 Transparent and standardized reporting guidelines for clinical performance and outcomes should also be established. These guidelines would ensure clear communication of AI-SaMD capabilities and limitations to health care providers and patients, aiding informed decision-making and appropriate use of these technologies in clinical practice. Implementing these measures would foster greater trust in AI-SaMD and support their responsible integration into health care systems.27

## Section: Recommendations for Harmonized Global Standards

Harmonized global standards for AI-SaMD are crucial for ensuring patient safety, fostering innovation, and facilitating international collaboration.4,6 The following recommendations aim to create a more consistent, efficient, and effective global ecosystem for AI-SaMD development and deployment by aligning regulatory practices across jurisdictions.

## Section: Adoption of International Standards

Adopting international standards is essential for harmonizing global AI-SaMD regulation. Organizations like the International Organization for Standardization (ISO) and the International Electrotechnical Commission (IEC) are pivotal in this process.30 Key recommendations include ISO/IEC 27001 for information security, ISO 13485 for quality management in medical devices, IEC 62304 for software lifecycle processes, and ISO/IEC 29119 for software testing.31 These standards ensure quality, safety, and security in AI-SaMD development and deployment, enabling regulators and manufacturers to collaborate within a common framework and ease market entry across jurisdictions.

Beyond these foundational standards, emerging standards address AI’s unique challenges in medical devices. For example, ISO/IEC 42001 is being developed for AI management systems, and IEEE P2801 aims to establish ethical considerations for autonomous systems pertinent to AI-SaMD.27,30,31 Harmonizing regulation through international standards also promotes interoperability and data sharing, which is critical for developing and validating AI algorithms with large, diverse datasets. Adhering to common standards facilitates multicenter clinical trials and postmarket surveillance, enhancing evidence generation for AI-SaMD safety and efficacy. Standardized data governance, privacy protection, and cybersecurity foster trust among patients, health care providers, and regulatory bodies, which is crucial for the widespread adoption of AI-SaMD in clinical practice.6,27

## Section: Unified Risk Management Framework

A unified risk management approach for AI-SaMD is essential to maintain global safety and efficacy standards. This framework should include comprehensive guidelines addressing AI’s unique health care challenges. Integrating best practices from regulatory bodies like the FDA and the EU AI Act can establish a robust foundation for managing AI-SaMD risks across jurisdictions.13,16 Key components should include a standardized risk classification system to categorize AI-SaMD on the basis of potential impacts on patient safety and health outcomes, enabling appropriate scrutiny and control measures. Continuous risk assessment throughout the AI-SaMD lifecycle is crucial, given that these systems evolve and adapt over time.13,15 Ongoing evaluation would help identify and address emerging risks as the AI system learns from new data. The framework should also provide clear guidelines for identifying and mitigating bias in AI models, requiring diverse training data to ensure equitable performance across patient populations. Finally, real-world performance monitoring and reporting standards are essential for maintaining safety and efficacy.11 These protocols would facilitate collecting and analyzing postmarket data, enabling timely detection of adverse events or performance issues and supporting continuous improvement of AI-SaMD systems.

## Section: Global Data Security Standards

Establishing standard data security protocols and ensuring adherence across jurisdictions is vital for mitigating security risks associated with AI-SaMD. This requires a multifaceted strategy encompassing technical, regulatory, and operational measures. Robust data storage and transmission encryption standards, aligned with international best practices, are foundational.27 These standards should protect sensitive patient information from unauthorized access, interception, or manipulation throughout its lifecycle.11,27 Developing standards for implementing and auditing access controls in AI-SaMD systems is crucial to maintaining data integrity and confidentiality, ensuring only authorized personnel can access and modify critical information.

Global guidelines should be established for responding to and reporting data breaches and security incidents, facilitating rapid and coordinated responses to minimize security breaches’ impact and fostering trust in AI-SaMD systems. Moreover, adopting privacy-enhancing technologies in AI-SaMD development and deployment should be encouraged to protect patient data.18,27 Technologies such as differential privacy and federated learning can balance the need for data-driven insights with the imperative of protecting individual privacy.32 Implementing these measures can create a more secure, trustworthy global AI-SaMD ecosystem that safeguards patient information and enabling innovation in health care technology.

## Section: Standardized Clinical Evaluation Criteria

Establishing uniform clinical evidence criteria and enhancing transparency for AI-SaMD is vital for improving reliability and comparability across jurisdictions. Standardized performance metrics are crucial for evaluating AI-SaMD products, allowing for meaningful comparisons and informed decisions by regulatory bodies. These metrics should include accuracy, sensitivity, specificity, and robustness across diverse patient populations and clinical settings.15,27 In addition, harmonized guidelines for using real-world data in AI-SaMD evaluation must reflect realistic conditions and intended clinical use.1

Consistent requirements for reporting clinical performance enhance transparency in AI-SaMD evaluation.2,27 This includes clear communication of the device’s limitations, intended use, and potential biases, enabling informed decisions by health care providers and patients. Promoting standards for data interoperability is essential for facilitating multicenter evaluations and performance comparisons, leading to more comprehensive assessments across various health care settings and patient populations. By implementing these standardized clinical evaluation criteria, regulatory bodies and health care providers can ensure rigorous assessment of AI-SaMD, ultimately improving patient safety and health care outcomes.

## Section: Cross-Border Collaboration

Countries and organizations can collectively tackle regulatory challenges and unify standards for AI-SaMD with collaborative efforts.33 Creating a global ecosystem for responsible AI-SaMD development and deployment necessitates cross-border cooperation among regulators, manufacturers, nongovernmental organizations, multilateral institutions, researchers, and other stakeholders.34 This involves sharing best practices, harmonizing regulatory strategies, and jointly addressing emerging challenges and opportunities.5,6 Such collaboration ensures that AI-SaMD development prioritizes patient safety, efficacy, and ethical considerations. International working groups, conferences, workshops, and shared knowledge platforms can facilitate this process. These initiatives help develop common frameworks for risk assessment, performance evaluation, and postmarket surveillance. Cross-border collaboration addresses data privacy, security, and interoperability issues, essential for AI-SaMD implementation across different health care systems and regions. By fostering a global regulatory and standardization approach, stakeholders can promote innovation although ensuring AI-SaMD technologies meet consistent quality and safety standards worldwide (Figure).

Harmonized regulatory framework for AI-SaMD.

## Section: Discussion

Harmonizing regulations for AI-SaMD is crucial to ensure global safety, efficacy, and innovation in health care. This article outlined the varied regulatory approaches across important jurisdictions, each addressing the unique challenges posed by AI technologies in health care. The diversity in these frameworks underscores the urgent need for coordinated global standards to govern AI-SaMD development, deployment, and monitoring. Such harmonization is essential for fostering a global ecosystem that maximizes AI’s potential in health care whereas maintaining rigorous patient safety and data security safeguards. Although it may be impractical to expect all regions to possess identical regulatory structures, there exist essential components that can facilitate regulatory harmonization. Foremost among these is balancing innovation with patient safety and necessitating thoughtful calibration. Transparency and accountability in AI algorithms and decision-making processes are imperative for building trust among health care providers, patients, and regulatory bodies.27 Developing robust risk management frameworks tailored to AI’s adaptive nature and potential for bias is equally crucial. Robust data security standards protect patient information and maintain public trust in AI-SaMD. Standardized clinical evaluation criteria are also indispensable for assessing AI-SaMD performance across jurisdictions, facilitating global collaboration, and ensuring uniform safety and efficacy standards.11,27

The path to harmonizing AI-SaMD regulation requires ongoing adaptation to rapidly evolving AI technologies. This entails sustained collaboration among international regulators, manufacturers, and stakeholders to continually refine and update regulatory approaches. Building regulatory capacity, particularly in low-income and middle-income countries, ensures global participation in and adherence to harmonized standards. Addressing emerging ethical considerations and anticipating regulatory challenges posed by developments such as federated learning32 and edge AI35 will be critical as AI technologies advance. Of importance, involving patients and the public in developing and evaluating AI-SaMD regulatory frameworks will ensure these technologies serve the needs and respect the rights of those they are designed to benefit.27 Addressing these challenges and fostering robust international cooperation will create a regulatory environment that supports responsible AI-SaMD development and deployment, accelerates global health advancements, and improves patient outcomes worldwide.

## Section: Conclusion

AI-SaMD presents considerable potential to revolutionize health care delivery, offering unprecedented opportunities to enhance patient care and optimize the efficiency of health systems. However, realizing this potential necessitates addressing the fragmented regulatory landscape and fostering greater harmonization of standards and guidelines for AI-SaMD. Through the adoption of international standards, the establishment of a unified risk management framework, the implementation of robust data security protocols, and the prioritization of cross-border collaboration, regulators, manufacturers, and other stakeholders can collectively ensure that AI-SaMD is developed, deployed and utilized safely, effectively, and ethically on a global scale. By embracing a collaborative and forward-looking approach to AI regulation, it is possible to harness the transformative potential of these technologies to create a more equitable and health-oriented future for all.

## Section: Potential Competing Interest

The author report no competing interests.


---

# Global Regulatory Frameworks for the Use of Artificial Intelligence (AI) in the Healthcare Services Sector

- **Authors:** Kavitha Palaniappan, Elaine Yan Ting Lin, Silke Vogel
- **Issuer:** Healthcare (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2024-02-28
- **Language:** en
- **DOI:** 10.3390/healthcare12050562
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38470673/
- **Licence:** CC-BY

## Page 1 (Section: Introduction )

Citation: Palaniappan, K.; Lin, E.Y.T.;
Vogel, S. Global Regulatory
Frameworks for the Use of Artificial
Intelligence (AI) in the Healthcare
Services Sector. Healthcare 2024, 12,
562. https://doi.org/10.3390/
healthcare12050562
Academic Editor: Gang Kou
Received: 23 January 2024
Revised: 23 February 2024
Accepted: 26 February 2024
Published: 28 February 2024
Copyright: © 2024 by the authors.
Licensee MDPI, Basel, Switzerland.
This article is an open access article
distributed
under
the
terms
and
conditions of the Creative Commons
Attribution (CC BY) license (https://
creativecommons.org/licenses/by/
4.0/).
healthcare
Review
Global Regulatory Frameworks for the Use of Artificial
Intelligence (AI) in the Healthcare Services Sector
Kavitha Palaniappan *, Elaine Yan Ting Lin and Silke Vogel
Centre of Regulatory Excellence, Duke-NUS Medical School, Singapore 169857, Singapore
* Correspondence: kavitha@duke-nus.edu.sg
Abstract: The healthcare sector is faced with challenges due to a shrinking healthcare workforce
and a rise in chronic diseases that are worsening with demographic and epidemiological shifts.
Digital health interventions that include artificial intelligence (AI) are being identified as some of
the potential solutions to these challenges. The ultimate aim of these AI systems is to improve the
patient’s health outcomes and satisfaction, the overall population’s health, and the well-being of
healthcare professionals. The applications of AI in healthcare services are vast and are expected to
assist, automate, and augment several healthcare services. Like any other emerging innovation, AI in
healthcare also comes with its own risks and requires regulatory controls. A review of the literature
was undertaken to study the existing regulatory landscape for AI in the healthcare services sector in
developed nations. In the global regulatory landscape, most of the regulations for AI revolve around
Software as a Medical Device (SaMD) and are regulated under digital health products. However, it is
necessary to note that the current regulations may not suffice as AI-based technologies are capable of
working autonomously, adapting their algorithms, and improving their performance over time based
on the new real-world data that they have encountered. Hence, a global regulatory convergence for
AI in healthcare, similar to the voluntary AI code of conduct that is being developed by the US-EU
Trade and Technology Council, would be beneficial to all nations, be it developing or developed.
Keywords: regulatory frameworks; artificial intelligence; healthcare services
1. Introduction
The healthcare sector is currently facing several challenges that are not localised but
rather universal, such as manpower shortages and difficulties in chronic disease man-
agement [1]. The demand for and the size of the global health workforce are predicted
to rise to unprecedented levels because of population and economic growth [2]. Simul-
taneously, chronic, non-communicable diseases (NCDs) are reported to be the leading
cause of global death, at about 73%, with millions of individuals being continuously af-
fected [3]. The current shortage of labour in healthcare professionals is further exacerbated
by demographic and epidemiological shifts. The ageing population and rise in NCDs
in high-income countries (HICs), as well as low- and middle-income countries (LMICs),
means that healthcare delivery models have to expand to meet population needs, especially
in the areas of patient services and community care [2]. Nations around the world have
started to realise that health systems need to be built upon foundational models of care
that encompass preventive and rehabilitative services in conjunction with the tremendous
potential of digital technologies to meet the rising population demands [2].
Digital health interventions that include artificial intelligence (AI) have been recog-
nised to be capable of helping to fill these gaps in healthcare [4]. According to the En-
cyclopaedia Britannica, AI is defined as “the ability of a digital computer or computer-
controlled robot to perform tasks commonly associated with intelligent beings” [5]. While
AI is computer software that mimics the ways that humans think in order to perform
complex tasks, such as analysing, reasoning, and learning, machine learning (ML) on the
Healthcare 2024, 12, 562. https://doi.org/10.3390/healthcare12050562
https://www.mdpi.com/journal/healthcare

## Page 2 (Section: Role of AI in Healthcare Services )

Healthcare 2024, 12, 562
2 of 12
other hand is a subset of AI that uses algorithms trained on data to produce models that
can perform such complex tasks [6]. The rising attention and surge in AI applications are at-
tributed to the synergy between the significant advancement of computational powers and
the massive volume of data generated from health systems [7]. AI is increasingly playing a
significant role in redefining and revolutionising the existing healthcare landscape, from
the automation of administrative functions supporting diagnosis through evidence-based
clinical decision making to suggesting suitable treatments by analysing massive quantities
of health data at a rapid speed [8]. The application of AI in healthcare has been shown to
improve patient health outcomes and the well-being of healthcare professionals [9].
At the same time, it is necessary to note that AI-based technologies are still in a nascent
phase and hence require various actors, from AI researchers and developers to regulatory
authorities, to be informed on the developments of AI. Out of all these actors, regulatory
authorities play a crucial role as AI systems in healthcare make critical decisions that directly
impact individuals’ health, safety, and well-being, and regulations help to prevent errors
or malfunctions that could potentially harm patients. Additionally, regulations provide
a framework for the ethical use of AI in healthcare. They address issues such as patient
privacy, consent, and the responsible handling of sensitive medical data. Without proper
regulations, there is a risk of misuse or unauthorised access to personal health information.
Standardisation is another key aspect. Regulations help to establish common guide-
lines and standards for AI applications in healthcare, promoting interoperability and
compatibility among different systems, which is essential for seamless collaboration and
communication within the healthcare ecosystem. Furthermore, regulations can foster trust
among healthcare professionals, patients, and the public. When people are aware that the
AI systems adhere to established standards, it can increase confidence in their reliability
and effectiveness.
2. Role of AI in Healthcare Services
Healthcare services are rapidly expanding to include remote and mobile modes of
delivery, and hence, the incorporation of AI technologies to aid in the diagnosis, treatment,
and prevention is timely and crucial. Currently, the use of AI in healthcare services ranges
from prevention, diagnosis, and pharmacology to treatment. It is crucial to understand
its impact on healthcare services for effective healthcare delivery across the healthcare
continuum [10]. AI is mainly used for assisting and automating the existing healthcare
services as far as the diagnostics and pharmaceutical areas are concerned, and when it
comes to treatment aspects, it aims to augment the current healthcare services, as shown
in Figure 1.
2.1. AI for Diagnosis and Prevention
In the area of diagnosis, studies have shown that AI algorithms perform on the same
level or even better than clinicians, which may be partly due to the ability of AI algorithms
to achieve high speed and accuracy in data interpretation [11]. Currently, AI in diagnostics
is mainly used to read images and support clinicians in their decision-making process. For
example, in a study that involved more than 112,000 images of chest X-ray scans used for the
detection of pneumonia, AI algorithms showed better performance than radiologists [11].
In another study that involved the optical diagnosis of polyps at high magnification during
colonoscopy with 325 patients, the speed of optical diagnosis with the AI algorithm was
35 s, with 94% accuracy [12,13].
Currently, certain AI applications (apps) and devices are also directly available to
consumers for their personal use; these are known as direct-to-consumer (DTC) medical
AI/ML apps [14]. The majority of these apps are for prevention purposes, and consumers
use them to monitor their health status and prevent diseases before they can occur. As per
companies’ own validation, their predictive functions are mostly accurate. Some of the apps
have already been authorised by the United States (US) Food and Drug Administration
(FDA) to provide a screening decision independent of a healthcare professional [15]. Exam-

## Page 3 (Section: AI in Pharmacology )

Healthcare 2024, 12, 562
3 of 12
ples include the ECG app in the Apple Watch, which is marketed and used by consumers to
enable the personal screening of certain heart disorders, in particular atrial fibrillation [16].
Figure 1. Applications of AI in healthcare services.
Another example of the effective use of AI in preventive care involves healthcare
services that may include AI for personalised nutrition for the management of chronic
diseases well before their occurrence. There is also the possibility of patients managing
their own medical conditions, especially chronic conditions such as diabetes, hypertension,
and mental health issues with the help of AI [11].
2.2. AI in Pharmacology
In pharmaceutical research, AI is used for drug discovery and the prediction of
chemical and pharmaceutical properties [17]. For instance, the drug synthesis process
within the research and development (R&D) cycle could be shortened by using ML models
to automate chemical experiments, as these models are able to perform thousands of
chemical reactions simultaneously [18]. This will thus enable cost savings for conducting
experiments and help researchers to offload repeated work. AI, ML, and robotics are
currently paired with high-throughput screening and high-throughput experimentation to
develop new drugs for specific patients in need [19].
Digital twins are gaining traction for application in drug discovery and efficacy studies.
Digital twins are virtual representations of a particular object, and in healthcare research,
a digital twin can be created for a person’s specific organ such as heart, liver, and kidney,
or the entire person itself. The digital twin would be an exact replica down to the cellular
level. The bioactivity, chemical, and pharmacological properties of new drugs are studied
in such digital twins instead of actual organs [20].
2.3. AI for Treatment
AI is being integrated into treatment for patients. This includes the use of AI to
optimise the drug delivery system to make treatment more effective. A micro- or nanosensor
programmed with an AI algorithm is used to detect subtle changes in vivo and monitor
drug concentrations, thereby generating feedback systems [21]. Such feedback systems
can in turn be used for training the AI algorithm further, and once the AI algorithm
is fully trained, the delivery system can facilitate self-medication. This process enables
patients to adjust their drug dosage according to objective measures and, at the same time,

## Page 4 (Section: AI in Pharmacology )

Healthcare 2024, 12, 562
4 of 12
also allows them to transfer their data to their physician via the cloud in real time [22].
Physicians would also be able to monitor the changes and suggest modifications if required
via telemedicine. This would not only make treatment more precise, effective, and time-
sensitive but also solve the issues related to the manpower crunch that the healthcare
system is currently facing [23].
AI technologies are able to assist clinicians in evidence-based decision making with
high accuracy and speed and perform on the same level or even outperform clinicians.
Clinicians are currently using AI in a computer-aided system to better diagnose and treat
breast cancer and lung cancer [24].
The generation of treatment plans is another area where AI is currently being explored.
AI can generate treatment plans within a few minutes or even seconds, in comparison to
the duration taken by physical providers [25].
AI is valuable in supporting the increasing resource demands in healthcare services,
especially due to the ageing population. AI technologies may be deployed at nursing
homes and patients’ residences to assist them in monitoring their conditions regularly in
the form of robotic companions [26]. Such robotic companions may go beyond the scope of
a medical device; they can even be interactive to provide advice to the elderly about their
physical activities in their living space [27].
The shift towards home-based care from hospitals has largely been enabled by AI
technologies such as telemedicine [23]. Telemedicine refers to the delivery of healthcare
services at a distance by healthcare professionals using information and communication
technologies to diagnose, treat, and prevent diseases and injuries [23]. Remote monitoring
systems such as video-observed therapy and patient care made possible by virtual assistants
are commonly seen as part of this shift [25]. Clare&Me is an AI virtual chatbot that offers
support and guidance for mental health in Germany in a conversational manner via phone
calls and WhatsApp [28]. Ora is a telehealth platform based in Singapore with an emphasis
on healthcare delivery for the Southeast Asian population through a direct-to-patient
model on issues pertaining to men’s health, female reproductive healthcare, and skin care
treatment [29].
Several technology companies, including Alibaba, Tencent, Baidu, and Ping An, are
now getting increasingly involved in healthcare delivery by starting to offer healthcare ser-
vices directly to healthcare facilities and individuals [30–33]. While Alibaba is developing
AI-assisted diagnostic tools [30], Tencent is creating a “smart hospital” that provides online
services [31]. Baidu Health offers consultation and chronic disease management services,
whereas Ping An built an AI technology called AskBob in 2019, which is an AI-based diag-
nosis and treatment assistance tool for doctors [34,35]. DispatchHealth is another company
that serves as an urgent call centre on wheels and sends over help to online requesters
depending on the medical services needed, including on-site blood tests [36]. DearDoc
is yet another company that uses AI and automation to perform extensive research for
diagnostics [37]. Such companies may not come under the direct purview of the regulation
authorities of the healthcare system and hence may need to be regulated, especially when
they offer direct provisions of healthcare services to the public.
Another emerging concept is the “uberization” of healthcare. In this concept, AI
creates common healthcare platforms where various healthcare professionals can acquire
work on demand [38].
The economic perspective of the use of AI in healthcare seems to be hypothetically
positive. A study examining roughly 200 studies for AI in healthcare revealed that there
were tremendous cost savings using AI tools in both diagnosis and treatment when com-
pared to conventional methods. Cost savings in diagnosis in the range of USD 1666 per
day per hospital in the first year to about USD 17,881 per day per hospital in the tenth year
and cost savings in treatment in the range of USD 21,666.67 per day per hospital in the first
year to about USD 289,634.83 per day per hospital in the tenth year were observed [39].
Likewise, another study has also shown that cost savings due to the use of AI in treatment
are much more than cost savings due to the use of AI in diagnosis [40].

## Page 5 (Section: Methodology )

Healthcare 2024, 12, 562
5 of 12
Thus, based on the increased use of AI in various healthcare settings, as described
above, our goal is to examine the scope of the existing regulatory landscape in encompassing
the various risks associated with AI and its use in the healthcare sector.
3. Methodology
A review of the existing literature was conducted to scan the horizon for the reg-
ulations pertaining to AI in the healthcare sector. Based on a recent study conducted,
seven jurisdictions were identified to be pioneers in the area of regulating AI in healthcare,
namely the United States of America (USA), the United Kingdom (UK), Europe, Australia,
China, Brazil, and Singapore [41]. The regulatory frameworks and guidelines pertaining to
AI in healthcare in these seven jurisdictions were identified and downloaded from their
respective government websites pertaining to healthcare and analysed for the purpose of
this review. The key terms used for the search included regulatory frameworks, legislations,
laws, policies, and guidelines.
In terms of the policies presented in this review, a mixture of hard and soft laws was
considered. Hard laws refer to legislation or a set of rules that are legally binding [42].
Soft law comprises professional guidelines, voluntary standards, codes of conduct, recom-
mendations, agreements, national action plans, or policy documents, which are not legally
binding and adopted by governments and the industry [43]. The review also includes
national policies that are in draft or implementation stages developed by the government,
their agencies, and national standard bodies.
4. Existing Regulatory Landscape
Across the global regulatory landscape, the use of AI in healthcare is currently predom-
inantly regulated under the regulatory frameworks for medical devices, or more specifically,
under the frameworks of Software as a Medical Device (SaMD). Several articles have ad-
dressed the details, pros and cons of such regulations [44]. It is important to note that these
regulations do not apply to certain AI applications such as software intended to support
people in maintaining a healthy lifestyle, software used for administrative support, and
software that provides clinical support or recommendations to healthcare professionals.
This is mainly because the individual is expected to be qualified to make his or her own
rational decisions based on the recommendations provided by the AI application [45].
The analysis of global regulatory frameworks for the use of AI in healthcare shows
that regulations currently mostly adopt a soft-law approach. Examples of these soft-law
approaches include professional guidelines, voluntary standards, and codes of conduct
that are adopted by governments and the industry [43]. For AI in healthcare, considering
soft-law frameworks, there are substantial expectations for the relevant stakeholders to
consider during the development of AI’s technological innovations; however, they are not
directly enforced by governments [46]. The relevant stakeholders, in this case, refer to
developers and users. The term “developer” refers to a singular person or an organisation
that is involved in the planning, funding, developing, and/or maintaining AI-MDs; the
term “user” refers to a singular person or an organisation that uses AI-MDs in the delivery
of healthcare services [47].
The benefits of adopting a soft-law approach are that it can be easily amended given
the evolving landscape of AI technologies. The downside is that these approaches are
voluntary; thus, organisations have the option not to adopt these voluntary guidelines.
4.1. United States of America (USA)
Currently, there are no specific regulatory pathways for AI-based technologies in the
USA, but the FDA evaluates them under the existing regulatory framework for medical
devices [48]. In April 2019, the FDA implemented the “Proposed Regulatory Framework
for Modifications to AI/ML-based SaMD” according to which developers were accountable
for the real-world performance of their AI systems and needed to update the FDA on
the changes in terms of performance and input [49]. The proposal also emphasised that

## Page 6 (Section: United Kingdom (UK) )

Healthcare 2024, 12, 562
6 of 12
the approval process needs to restart if there is a change in the intended use of the AI
system [50]. Following this proposal, the FDA issued the “AI/ML-based SaMD Action
Plan” in January 2021, which outlined the following five actions based on the total product
life cycle (TPLC) approach for the oversight of AI-MDs [51,52]:
i.
Specific regulatory framework with the issuance of draft guidance on “Predeter-
mined Change Control Plan”;
ii.
Good machine learning practices;
iii.
Patient-centric approach, including the transparency of devices to users;
iv.
Methods for the elimination of ML algorithm bias and algorithm improvement;
v.
Real-world performance monitoring pilots.
The guidance to the “Predetermined Change Control Plan” is expected to be a frame-
work for modification to AI-MDs and would include the type of anticipated modifications,
known as “SaMD pre-specifications” (SPSs), and the associated methods used to implement
those changes in a controlled manner that would mitigate the risks to patients, known as the
“algorithm change protocol” (ACP) [52]. Good machine learning practices (GMLPs) were
also included as part of the TPLC approach for AI-MD developers. GMLP considerations
for SaMDs refer to good software engineering practices or quality system practices that
include the following features:
i.
High relevance of available data to the clinical problem and current clinical practice;
ii.
Consistency in data collection that does not deviate from the SaMD’s intended use;
iii.
Planned modification pathway;
iv.
Appropriate boundaries in the datasets used for training, tuning, and testing the
AI algorithms;
v.
Transparency of the AI algorithms and their output for users [50].
4.2. United Kingdom (UK)
UK’s National Institution for Health and Care Excellence (NICE) collaborated with the
National Health Service (NHS) England and published the “Evidence Standards Framework
for Digital Health Technologies” in 2019. This document provides the regulations for a
range of products such as apps, software, and online platforms that can be standalone or
combined with other health products [53].
In addition, The Regulatory Horizons Council of the UK, which provides expert advice
to the UK government on technological innovation, published “The Regulation of AI as
a Medical Device” in November 2022 [54]. This document considers the whole product
lifecycle of AI-MDs and aims to increase the involvement of patients and the public, thereby
improving the clarity of communication between regulators, manufacturers, and users.
In September 2021, the Medicines and Healthcare Products Regulatory Agency (MHRA)
established a regulatory reform programme known as the “Software and AI as a Medical
Device Change Programme” to provide a robust regulatory framework in the form of guid-
ance for the regulatory oversight of AI-MDs. The programme comprises two workstreams:
the first stream considers key reforms across the whole lifecycle of SaMDs, which includes
cybersecurity and data privacy risks, and a post-market evaluation of the medical device;
the second considers additional challenges that AI can pose to medical device regulation,
including evolving AI algorithms, bias, and the interpretability of AI [54].
4.3. Europe
The European Union (EU) began to establish its approach to AI with non-binding
guidelines, including the “Ethics Guidelines for Trustworthy AI” [55] and the “Policy
and Investment Recommendations”, which were published in 2019 [56]. Subsequently, in
May 2021, the EU took a regulatory stand by publishing the “European Medical Device
Regulation”, wherein the risk classification of SaMDs was based on diagnostic and thera-
peutic intentions. However, in April 2021, the EU proposed the AI Act, which laid down a
harmonised legal framework for AI products and services, from the development phase

## Page 7 (Section: Australia )

Healthcare 2024, 12, 562
7 of 12
to their application [57]. In that framework, Articles 9 to 15 address the requirements for
AI systems with respect to risk management, data governance, human oversight, trans-
parency, accuracy, robustness, and cybersecurity. In addition, the obligations of providers
to users of such AI systems are provided in Articles 16 to 29. Thus, it is evident that the
EU is currently moving from a soft-law approach towards a legislative approach for the
regulatory framework in AI [58].
The AI Act uses a risk-based approach to regulate AI systems. In the healthcare sector,
high-risk AI systems include those that utilise biometric identification, sort patients based
on their medical history, and use software for the management of public healthcare services
and electronic health records [59]. The main requirements for these high-risk AI systems
under the AI Act are data governance and risk management, which need to be addressed
by the manufacturer. For low- and minimal-risk AI systems such as chatbots that may
interact with humans as part of healthcare service, a voluntary code of conduct for safe and
reliable service needs to be in place [60]. Critics indicate that the AI Act is inflexible, as
there is currently no scope to include new AI applications in the “high-risk” category if
they emerge in an unforeseen sector and are dangerous [61].
4.4. Australia
The Royal Australian and New Zealand College of Radiologists published the “Ethical
Principles for AI in Medicine” in April 2019. This document highlights the importance of
upskilling medical practitioners and the development of standards and practices in the
deployment of AI in Medicine and research [62].
The regulation of SaMDs falls under the Therapeutic Goods Administration (TGA).
In August 2021, the Therapeutic Goods (Medical Devices) Regulation 2002 was amended,
and a guideline entitled “Regulatory changes for software-based medical devices” was
published to explain the amendments [63]. This guidance has been effective since February
2021 and includes a risk-based classification approach [63]. Areas exempt from the guidance
are consumer health products for prevention and management; enabling technologies for
telehealth, healthcare, and pharmaceutical dispensing; certain electronic medical records;
population-based analytics; and laboratory information management systems [63]. This
shows that the TGA has recognised the need for the regulation of AI-MDs at the national
level, but it is also trying to harmonise at the international level by focusing on SaMDs with
high-risk factors that have a high impact on patient safety.
4.5. China
The National Medical Products Administration (NMPA) of China, which provides
regulatory oversight on medical products, published the “Technical Guideline on AI-aided
Software” in June 2019. This guideline highlighted the characteristics of deep learning
technology, controls for software data quality, valid algorithm generation, and methods
to assess clinical risks. On 8 July 2021, the NMPA released the “Guidelines for the Clas-
sification and Definition of Artificial Intelligence-Based Software as a Medical Device”,
which includes information on the classification and terminology of AI-MDs, the safety
and effectiveness of AI algorithms, and whether AI-MDs provide assistance in decision
making such as clinical diagnosis and the formulation of patient treatment plans [64]. On
7 March 2022, the Centre for Medical Device Evaluation under the NMPA published the
“Guidelines for Registration and Review of Artificial Intelligence-Based Medical Devices”.
These guidelines provide standards for the quality management of software and cybersecu-
rity of medical devices taking into consideration the entire product’s lifecycle [64,65]. This
shows that the NMPA has not only started to standardise the regulation of AI-MDs at the
national level, but it is also trying to harmonise at the international level by focusing on
risk factors and TPLC management through the publication of these guidelines [65].

## Page 8 (Section: Brazil )

Healthcare 2024, 12, 562
8 of 12
4.6. Brazil
In September 2021, the Brazilian Legal Framework for AI, aiming to regulate the devel-
opment and use of AI technology within Brazil, was approved by the Brazilian Chamber of
Deputies. This legislation also prescribes a risk-based approach, but only for the develop-
ment of AI solutions, and does not take into consideration the various applications of those
AI solutions that may actually differ in terms of their risk [66]. Following this, the Brazilian
Senate drew inspiration from regulatory plans for AI in OECD countries and received
inputs from various stakeholders and the public to draft an AI law in December 2022. The
draft AI law classifies health applications as high-risk AI systems, and hence they need to
be maintained in a publicly accessible database that provides the details of the completed
risk assessments of such systems [67]. The providers also need to conduct periodically
repeated algorithmic impact assessments and must establish governance structures that
facilitate the various rights of individuals. The rights to information, explanation, challenge,
human intervention, non-discrimination, the correction of discriminatory bias, privacy, and
the protection of personal data are included in those rights of individuals, irrespective of
the risk classification of the AI system. The draft AI law also indicates that providers are
strictly liable for any damages caused by their AI system [67].
4.7. Singapore
Singapore’s National AI Strategy aims to (i) identify areas to focus on and resources
at the national level; (ii) set out how various stakeholders can work together to realise the
positive impact of AI; and (iii) address areas where attention is needed to manage changes
in and new forms of risk that arise when AI becomes more pervasive [68]. Further to this, on
25 May 2022, the Infocomm Media Development Authority (IMDA) launched the world’s
first AI Governance Testing Framework and Toolkit called “AI Verify” for companies in Sin-
gapore that wish to demonstrate responsible AI in an objective and verifiable manner [69].
The testing framework consists of 11 AI ethics principles that jurisdictions around the world
coalesce around and that are consistent with internationally recognised AI frameworks
such as those from the EU, OECD, and Singapore’s Model AI Governance Framework.
The 11 governance principles are transparency, explainability, repeatability/reproducibility,
safety, security, robustness, fairness, data governance, accountability, human agency and
oversight, inclusive growth, and societal and environmental well-being.
Specifically, with respect to the healthcare sector, the Health Sciences Authority (HSA)
of Singapore released a second revision of its “Regulatory Guidelines for SaMD—A Lifecy-
cle Approach” in April 2022, highlighting that the developers need to provide intended
purpose, input data details, specifications of performance, control measures, and post-
market monitoring and reporting. Good practices for AI developers and AI implementers
are provided in “AI in Healthcare Guidelines” (AIHGIe), which was established by Singa-
pore’s Ministry of Health (MOH) and published in October 2021. The recommendations in
AIHGIe are based on the principles adapted from the AI Governance Framework estab-
lished by the Personal Data Protection Commission (PDPC).
5. Limitations of This Study
The regulatory frameworks for AI in healthcare vary significantly across different
jurisdictions, and this review may not have captured all the nuances and differences in the
regulations. As this is a new and rapidly evolving area, there are very few studies that
empirically evaluate the impact of specific regulations on AI in healthcare.
6. Conclusions
AI technologies have unmasked promising new solutions with tremendous potential
to assist healthcare professionals in the navigation of the dynamic healthcare landscape with
pressing healthcare challenges. In addition, there is also a need for regulatory frameworks
and health system infrastructure to be agile as AI technologies evolve at a rapid pace.
While most countries are regulating AI-MDs under traditional medical device software,

## Page 9 (Section: References)

Healthcare 2024, 12, 562
9 of 12
provisions are being made to include good ML practices, holistic life cycle approaches,
and strategies for the mitigation of risks associated with AI. The apps, software, and
online platforms that can be combined with other health products or used standalone
for healthcare purposes are also being included in regulatory frameworks. While most
countries provide national guidelines for AI, the EU and Brazil aim to regulate it via a risk-
based approach. Policy decisions are usually made based on clinical trials and published
research outcomes. It is essential for regulators to factor in that published research may
be biased towards positive outcomes or successful implementations of AI in healthcare.
Negative experiences, challenges, or failures may be underreported, leading to a skewed
perspective. The lack of standardised terminologies and definitions in the field of AI in
healthcare may result in inconsistencies, thereby making it challenging to compare and
synthesise information effectively.
The regulatory guidelines in AI have not yet converged, but there are ongoing dis-
cussions among the different governmental bodies. In June 2023, the US-EU Trade and
Technology Council (TTC) came to a consensus for the development of a voluntary AI code
of conduct, acting as an interim measure as the EU gears towards the passage of the AI Act.
The US-EU TTC consensus established the building of trust and the fostering of cooperation
in areas of technology governance and trade. The cornerstones of the draft voluntary AI
code of conduct rely on transparency, risk auditing, and other technical details pertaining to
the development of AI systems [70]. Fast-tracking the development of the US-EU AI code
of conduct would be a step towards alignment between the US and Europe in AI legislation
and policy. Thus, whether the global regulatory convergence would eventually occur
remains unclear; however, it would be beneficial, given the shared healthcare challenges
across countries and the country-agnostic nature of AI technologies.
Author Contributions: Conceptualization, K.P. and S.V.; methodology, K.P.; writing—original draft
preparation, K.P. and E.Y.T.L.; writing—review and editing, S.V. All authors have read and agreed to
the published version of the manuscript.
Funding: This research was supported by the Ministry of Health (MOH), Singapore (Reference
Number: MH 114:63/5), and the authors would like to acknowledge and thank the MOH for
its support.
Institutional Review Board Statement: Not applicable.
Informed Consent Statement: Not applicable.
Data Availability Statement: The original contributions presented in this study are included in the
article, further inquiries can be directed to the corresponding author.
Conflicts of Interest: The authors declare no conflicts of interest.
References
1.
Aung, Y.Y.M.; Wong, D.C.S.; Ting, D.S.W. The Promise of Artificial Intelligence: A Review of the Opportunities and Challenges of
Artificial Intelligence in Healthcare. Br. Med. Bull. 2021, 139, 4–15. [CrossRef]
2.
WHO. Global Strategy on Human Resources for Health: Workforce 2030; World Health Organization: Geneva, Switzerland, 2016;
ISBN 978-92-4-151113-1.
3.
Howse, E.; Rychetnik, L.; Marks, L.; Wilson, A. What Does the Future Hold for Chronic Disease Prevention Research? Aust. N. Z.
J. Public Health 2020, 44, 336–340. [CrossRef]
4.
Meskó, B.; Hetényi, G.; Gy˝orffy, Z. Will Artificial Intelligence Solve the Human Resource Crisis in Healthcare? BMC Health Serv.
Res. 2018, 18, 545. [CrossRef] [PubMed]
5.
Britannica, E. Artificial Intelligence (AI)|Definition, Examples, Types, Applications, Companies, & Facts. Available online:
https://www.britannica.com/technology/artificial-intelligence (accessed on 5 February 2024).
6.
Google Cloud AI vs. Machine Learning: How Do They Differ? Available online: https://cloud.google.com/learn/artificial-
intelligence-vs-machine-learning (accessed on 13 February 2024).
7.
Loh, H.W.; Ooi, C.P.; Seoni, S.; Barua, P.D.; Molinari, F.; Acharya, U.R. Application of Explainable Artificial Intelligence for
Healthcare: A Systematic Review of the Last Decade (2011–2022). Comput. Methods Programs Biomed. 2022, 226, 107161. [CrossRef]
8.
Meskó, B.; Topol, E.J. The Imperative for Regulatory Oversight of Large Language Models (or Generative AI) in Healthcare. npj
Digit. Med. 2023, 6, 120. [CrossRef] [PubMed]

## Page 10 (Section: References)

Healthcare 2024, 12, 562
10 of 12
9.
Reddy, S.; Allan, S.; Coghlan, S.; Cooper, P. A Governance Model for the Application of AI in Health Care. J. Am. Med. Inform.
Assoc. 2020, 27, 491–497. [CrossRef]
10.
Monlezun, D.J. Chapter 2—AI+healthcare Systems: Efficiency and Equity. In The Thinking Healthcare System; Monlezun, D.J., Ed.;
Academic Press: Cambridge, MA, USA, 2023; pp. 37–67; ISBN 978-0-443-18906-7.
11.
NHS The Topol Review—NHS Health Education England. Available online: https://topol.hee.nhs.uk/ (accessed on 28 February
2023).
12.
Mori, Y.; Kudo, S.; Misawa, M.; Saito, Y.; Ikematsu, H.; Hotta, K.; Ohtsuka, K.; Urushibara, F.; Kataoka, S.; Ogawa, Y.; et al.
Real-Time Use of Artificial Intelligence in Identification of Diminutive Polyps During Colonoscopy: A Prospective Study. Ann.
Intern. Med. 2018, 169, 357. [CrossRef]
13.
Holme, Ø.; Aabakken, L. Making Colonoscopy Smarter With Standardized Computer-Aided Diagnosis. Ann. Intern. Med. 2018,
169, 409. [CrossRef] [PubMed]
14.
Babic, B.; Gerke, S.; Evgeniou, T.; Cohen, I.G. Direct-to-Consumer Medical Machine Learning and Artificial Intelligence Applica-
tions. Nat. Mach. Intell. 2021, 3, 283–287. [CrossRef]
15.
Abràmoff, M.D.; Lavin, P.T.; Birch, M.; Shah, N.; Folk, J.C. Pivotal Trial of an Autonomous AI-Based Diagnostic System for
Detection of Diabetic Retinopathy in Primary Care Offices. npj Digit. Med. 2018, 1, 39. [CrossRef]
16.
Apple Take an ECG with the ECG App on Apple Watch. Available online: https://support.apple.com/en-us/HT208955 (accessed
on 25 July 2023).
17.
Lu, M.; Yin, J.; Zhu, Q.; Lin, G.; Mou, M.; Liu, F.; Pan, Z.; You, N.; Lian, X.; Li, F.; et al. Artificial Intelligence in Pharmaceutical
Sciences. Engineering, 2023; in press. [CrossRef]
18.
Ahneman, D.T.; Estrada, J.G.; Lin, S.; Dreher, S.D.; Doyle, A.G. Predicting Reaction Performance in C–N Cross-Coupling Using
Machine Learning. Science 2018, 360, 186–190. [CrossRef] [PubMed]
19.
Built in Merck. Available online: https://builtin.com/company/merck (accessed on 13 February 2024).
20.
Chen, Y.; Yang, O.; Sampat, C.; Bhalode, P.; Ramachandran, R.; Ierapetritou, M. Digital Twins in Pharmaceutical and Biopharma-
ceutical Manufacturing: A Literature Review. Processes 2020, 8, 1088. [CrossRef]
21.
Wang, Y.; Li, Z.; Hu, Q. Emerging Self-Regulated Micro/Nano Drug Delivery Devices: A Step Forward towards Intelligent
Diagnosis and Therapy. Nano Today 2021, 38, 101127. [CrossRef]
22.
Chen, C.; Cheng, C. Potential Next-Generation Medications for Self-Administered Platforms. J. Control. Release 2022, 342, 26–30.
[CrossRef] [PubMed]
23.
Pieczynski, J.; Kuklo, P.; Grzybowski, A. The Role of Telemedicine, In-Home Testing and Artificial Intelligence to Alleviate an
Increasingly Burdened Healthcare System: Diabetic Retinopathy. Ophthalmol. Ther. 2021, 10, 445–464. [CrossRef] [PubMed]
24.
Keane, P.A.; Topol, E.J. With an Eye to AI and Autonomous Diagnosis. npj Digit. Med. 2018, 1, 40. [CrossRef]
25.
Javaid, M.; Haleem, A.; Singh, R.P. ChatGPT for Healthcare Services: An Emerging Stage for an Innovative Perspective.
BenchCouncil Trans. Benchmarks Stand. Eval. 2023, 3, 100105. [CrossRef]
26.
Lee, C.-H.; Liu, C.-L.; Trappey, A.J.C.; Mo, J.P.T.; Desouza, K.C. Understanding Digital Transformation in Advanced Manufacturing
and Engineering: A Bibliometric Analysis, Topic Modeling and Research Trend Discovery. Adv. Eng. Inform. 2021, 50, 101428.
[CrossRef]
27.
Costa, A.; Martinez-Martin, E.; Cazorla, M.; Julian, V. PHAROS—PHysical Assistant RObot System. Sensors 2018, 18, 2633.
[CrossRef]
28.
Clare & Me Answering the Most Frequent Questions and Our AI Mental Health Solution. Available online: https://www.
clareandme.com/faq#faq-row-2 (accessed on 13 February 2024).
29.
David, P. ORA Raises $10 Million as Demand for Tele-Health in Asia Soars. Available online: https://www.forbes.com/sites/
davidprosser/2023/05/16/ora-raises-10-million-as-demand-for-tele-health-in-asia-soars/?sh=67968e4e4a13 (accessed on 13
February 2024).
30.
Jourdan, A. AI Ambulances and Robot Doctors: China Seeks Digital Salve to Ease Hospital Strain. Reuters Publication London.
2018. Available online: https://www.reuters.com/article/idUSKBN1JO1V1/ (accessed on 8 February 2023).
31.
Tencent Bridging Gaps in Healthcare Industry with Technology. Available online: https://www.tencent.com/en-us/articles/22
00933.html (accessed on 8 February 2023).
32.
Forkast How Baidu, Alibaba and Tencent Aim to Disrupt Chinese Health Care. Available online: https://forkast.news/baidu-
alibaba-tencent-china-health-care-blo/ (accessed on 8 February 2023).
33.
MobiHealthNews a Look Back at Alphabet’s Moves in 2019. Available online: https://www.mobihealthnews.com/news/look-
back-alphabets-moves-2019 (accessed on 8 February 2023).
34.
Ping an Healthcare Ecosystem. Available online: https://group.pingan.com/about_us/our_businesses/health-care-ecosystem.
html (accessed on 22 November 2023).
35.
Shijia, O. Baidu to Offer AI-Powered Patient-Doctor Matching Service. Available online: https://global.chinadaily.com.cn/a/20
2107/14/WS60eea64ea310efa1bd661e69.html (accessed on 22 November 2023).
36.
Built in DispatchHealth Careers, Perks + Culture. Available online: https://frontend.builtin.com/3cb8c7ae696a9e1ec4537e9df7c3
87cdb10f8ef7/company/dispatchhealth (accessed on 13 February 2024).
37.
Built in DearDoc. Available online: https://builtin.com/company/deardoc (accessed on 13 February 2024).

## Page 11 (Section: References)

Healthcare 2024, 12, 562
11 of 12
38.
Matheny, M.; Israni, S.T.; Ahmed, M.; Whicher, D. Artificial Intelligence in Health Care: The Hope, the Hype, the Promise, the Peril;
National Academy of Medicine: Washington, DC, USA, 2019.
39.
Khanna, N.N.; Maindarkar, M.A.; Viswanathan, V.; Fernandes, J.F.E.; Paul, S.; Bhagawati, M.; Ahluwalia, P.; Ruzsa, Z.; Sharma, A.;
Kolluri, R.; et al. Economics of Artificial Intelligence in Healthcare: Diagnosis vs. Treatment. Healthcare 2022, 10, 2493. [CrossRef]
40.
Blumen, H.; Fitch, K.; Polkus, V. Comparison of Treatment Costs for Breast Cancer, by Tumor Stage and Type of Service. Am.
Health Drug Benefits 2016, 9, 23–32.
41.
Markets and Markets Artificial Intelligence (AI) in Healthcare Market Size, Growth Report Analysis 2031. Available online:
https://www.marketsandmarkets.com/Market-Reports/artificial-intelligence-healthcare-market-54679303.html (accessed on 27
November 2023).
42.
Essén, A.; Stern, A.D.; Haase, C.B.; Car, J.; Greaves, F.; Paparova, D.; Vandeput, S.; Wehrens, R.; Bates, D.W. Health App Policy:
International Comparison of Nine Countries’ Approaches. npj Digit. Med. 2022, 5, 31. [CrossRef]
43.
Chatila, R.; Havens, J.C. The IEEE Global Initiative on Ethics of Autonomous and Intelligent Systems. In Robotics and Well-Being;
Aldinhas Ferreira, M.I., Silva Sequeira, J., Singh Virk, G., Tokhi, M.O., E. Kadar, E., Eds.; Intelligent Systems, Control and
Automation: Science and Engineering; Springer International Publishing: Cham, Switzerland, 2019; Volume 95, pp. 11–16; ISBN
978-3-030-12523-3.
44.
Jin, M.L.H.; Vogel, S.; Kitikiti, N.; Muthalagu, P.A. Artificial Intelligence in Healthcare: Landscape, Policies and Regulations in
Asia-Pacific; NUS Initiative to Improve Health in Asia (NIHA) Report; Duke-NUS Medical School: Singapore, 2020. Available
online: https://www.duke-nus.edu.sg/core/think-tank/news/publications/artificial-intelligence-in-healthcare-landscape-
policies-and-regulations-in-asia-pacific (accessed on 27 February 2023).
45.
Tsang, L.; Kracov, D.A.; Mulryne, J.; Strom, L.; Perkins, N.; Dickinson, R.; Wallace, V.M.; Jones, B. The Impact of Artificial
Intelligence on Medical Innovation in the European Union and United States. Intellect. Prop. Technol. Law J. 2017, 29, 3.
46.
Taeihagh, A. Governance of Artificial Intelligence. Policy Soc. 2021, 40, 137–157. [CrossRef]
47.
MOH; HSA. IHis MOH Artificial Intelligence in Healthcare Guidelines (AIHGle) 2021; MOH: Singapore, 2021. Available online:
https://www.moh.gov.sg/licensing-and-regulation/artificial-intelligence-in-healthcare (accessed on 31 August 2023).
48.
Muehlematter, U.J.; Daniore, P.; Vokinger, K.N. Approval of Artificial Intelligence and Machine Learning-Based Medical Devices
in the USA and Europe (2015–20): A Comparative Analysis. Lancet Digit. Health 2021, 3, e195–e203. [CrossRef]
49.
Harvey, H.B.; Gowda, V. How the FDA Regulates AI. Acad. Radiol. 2020, 27, 58–61. [CrossRef]
50.
FDA. Proposed Regulatory Framework for Modifications to Artificial Intelligence/Machine Learning-Based Software as a Medical Device
2019; FDA: Silver Spring, MD, USA, 2019. Available online: https://www.fda.gov/files/medical%20devices/published/US-
FDA-Artificial-Intelligence-and-Machine-Learning-Discussion-Paper.pdf (accessed on 27 February 2023).
51.
Chhaya, V.; Khambholja, K. The SaMD Regulatory Landscape in the US and Europe. Regul. Focus 2021. Available online:
https://www.raps.org/news-and-articles/news-articles/2021/8/the-samd-regulatory-landscape-in-the-us-and-eu-1 (accessed
on 27 February 2023).
52.
FDA. Artificial Intelligence/Machine Learning (AI/ML)-Based Software as a Medical Device (SaMD) Action Plan 2021; FDA: Silver Spring,
MD, USA, 2021. Available online: https://www.fda.gov/medical-devices/software-medical-device-samd/artificial-intelligence-
and-machine-learning-software-medical-device (accessed on 31 March 2023).
53.
Evidence Standards Framework (ESF) for Digital Health Technologies. Available online: https://www.nice.org.uk/about/what-
we-do/our-programmes/evidence-standards-framework-for-digital-health-technologies (accessed on 24 February 2023).
54.
Darzi, A. The Regulation of Artificial Intelligence as a Medical Device; Regulatory Horizons Council: London, UK, 2022.
55.
European Commission. Ethics Guidelines for Trustworthy AI|Shaping Europe’s Digital Future. Available online: https:
//digital-strategy.ec.europa.eu/en/library/ethics-guidelines-trustworthy-ai (accessed on 24 February 2023).
56.
European Commission. Policy and Investment Recommendations for Trustworthy Artificial Intelligence|Shaping Europe’s
Digital Future. Available online: https://digital-strategy.ec.europa.eu/en/library/policy-and-investment-recommendations-
trustworthy-artificial-intelligence (accessed on 24 February 2023).
57.
European Commission. Communication on Fostering a European Approach to Artificial Intelligence|Shaping Europe’s Digi-
tal Future. Available online: https://digital-strategy.ec.europa.eu/en/library/communication-fostering-european-approach-
artificial-intelligence (accessed on 24 February 2023).
58.
Meszaros, J.; Minari, J.; Huys, I. The Future Regulation of Artificial Intelligence Systems in Healthcare Services and Medical
Research in the European Union. Front. Genet. 2022, 13, 927721. [CrossRef] [PubMed]
59.
Díaz-Rodríguez, N.; Del Ser, J.; Coeckelbergh, M.; López de Prado, M.; Herrera-Viedma, E.; Herrera, F. Connecting the Dots in
Trustworthy Artificial Intelligence: From AI Principles, Ethics, and Key Requirements to Responsible AI Systems and Regulation.
Inf. Fusion 2023, 99, 101896. [CrossRef]
60.
European Commission. The Act. Available online: https://artificialintelligenceact.eu/the-act/ (accessed on 27 February 2023).
61.
The EU Newsletter. The Artificial Intelligence Act. 2021. Available online: https://artificialintelligenceact.eu/ (accessed on 27
February 2023).
62.
Kenny, L.M.; Nevin, M.; Fitzpatrick, K. Ethics and Standards in the Use of Artificial Intelligence in Medicine on Behalf of the
Royal Australian and New Zealand College of Radiologists. J. Med. Imaging Radiat. Oncol. 2021, 65, 486–494. [CrossRef] [PubMed]
63.
TGA. Regulatory Changes for Software Based Medical Devices; TGA: Woden, Australia, 2021. Available online: https://www.tga.gov.
au/resources/resource/guidance/regulatory-changes-software-based-medical-devices (accessed on 31 March 2023).

## Page 12 (Section: References)

Healthcare 2024, 12, 562
12 of 12
64.
Song, X.; Hu, M.; Li, B.; Zhang, K.; Zhang, X.; Wang, L. Advancing Medical Device Regulatory Reforms for Innovation, Translation
and Industry Development in China. J. Orthop. Transl. 2022, 37, 89–93. [CrossRef] [PubMed]
65.
Yu, T. Three Guidelines Published Today, Propelling China to Be World Leader in Digital Health; China Med Device: Cambridge, MA,
USA, 2022. Available online: https://chinameddevice.com/digital-health-nmpa-ai/ (accessed on 24 February 2023).
66.
da Conceição, L.H.M.; Perrone, C. The Brazilian Proposed Regulation of AI: Contextualization and Perspectives. MediaLaws 2022.
Available online: https://www.medialaws.eu/the-brazilian-proposed-regulation-of-ai-contextualization-and-perspectives/
(accessed on 27 February 2023).
67.
Quathem, E.S. Anna Oberschelp de Meneses, Nicholas Shepherd, Kristof Van Brazil’s Senate Committee Publishes AI Report and
Draft AI Law. Available online: https://www.insideprivacy.com/emerging-technologies/brazils-senate-committee-publishes-ai-
report-and-draft-ai-law/ (accessed on 27 February 2023).
68.
NRF. National Artificial Intelligence Strategy; Smart Nation and Digital Government Office: Singapore, 2019. Available online:
https://www.smartnation.gov.sg/files/publications/national-ai-strategy.pdf (accessed on 2 January 2024).
69.
PDPC. Singapore’s Approach to AI Governance. Available online: https://www.pdpc.gov.sg/Help-and-Resources/2020/01/
Model-AI-Governance-Framework (accessed on 2 January 2024).
70.
Murray, L.E.; Barnes, M. Policy Brief: Proposal for a US-EU AI Code of Conduct 2023; CED: New York, NY, USA, 2023. Available
online: https://www.ced.org/pdf/CED_Policy_Brief_US-EU_AI_Code_of_Conduct_FINAL.pdf (accessed on 4 December 2023).
Disclaimer/Publisher’s Note: The statements, opinions and data contained in all publications are solely those of the individual
author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to
people or property resulting from any ideas, methods, instructions or products referred to in the content.


---

# Identification and validation of platelet-related diagnostic markers and potential drug screening in ischemic stroke by integrating comprehensive bioinformatics analysis and machine learning

- **Authors:** Yifei Geng, Yuchen Liu, Min Wang, Xi Dong, Xiao Sun, Yun Luo, Xiaobo Sun
- **Issuer:** Frontiers in immunology
- **Type:** Scientific article
- **Published:** 2024-01-10
- **Language:** en
- **DOI:** 10.3389/fimmu.2023.1320475
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38268925/
- **Licence:** CC-BY

## Section: Abstract

BackgroundIschemic stroke (IS), caused by blood and oxygen deprivation due to cerebral thrombosis, has links to activated and aggregated platelets. Discovering platelet-related biomarkers, developing diagnostic models, and screening antiplatelet drugs are crucial for IS diagnosis and treatment.Methods and resultsCombining and normalizing GSE16561 and GSE22255 datasets identified 1,753 upregulated and 1,187 downregulated genes. Fifty-one genes in the platelet-related module were isolated using weighted gene co-expression network analysis (WGCNA) and other analyses, including 50 upregulated and one downregulated gene. Subsequent enrichment and network analyses resulted in 25 platelet-associated genes and six diagnostic markers for a risk assessment model. This model’s area under the ROC curve outperformed single genes, and in the peripheral blood of the high-risk group, immune infiltration indicated a higher proportion of CD4, resting CD4 memory, and activated CD4 memory T cells, along with a lower proportion of CD8 T cells in comparison to the low-risk group. Utilizing the gene expression matrix and the CMap database, we identified two potential drugs for IS. Finally, a rat MACO/R model was used to validate the diagnostic markers’ expression and the drugs’ predicted anticoagulant effects.ConclusionWe identified six IS platelet-related biomarkers (APP, THBS1, F13A1, SRC, PPBP, and VCL) for a robust diagnostic model. The drugs alpha-linolenic acid and ciprofibrate have potential antiplatelet effects in IS. This study advances early IS diagnosis and treatment.

## Section: Introduction

Stroke, the global second most prominent cause of death following ischemic heart disease, is an abrupt onslaught on the nervous system. Etiologically, it is traceable to cerebral vascular reperfusion damage, a subset of cerebrovascular ailments (1–3). Ischemic stroke (IS), characterized primarily by cerebral vascular thrombosis, precipitates an inadequate distribution of blood and oxygen to the brain (4). IS screening and diagnosis are conducted by employing facial, arm, and speech tests (FAST) and various advanced medical imaging techniques. Nevertheless, the potential for diagnostic failure or deferred imaging examination is introduced by factors such as atypical symptomatology in stroke patients, physical discomfort, emotional distress, and the limited sensitivity of diagnostic equipment (5).

In the therapeutic landscape, recombinant tissue plasminogen activator (tPA) thrombolysis is the sole FDA-endorsed IS treatment (6). Clinical outcomes show significant improvement when 0.9 mg/kg of alteplase is administered intravenously within a 4.5-h stroke onset (5). Concurrently, calcium antagonists administered intravenously and orally active antihypertensives regulate patients’ blood pressure, while active bleeding in patients with acute hemorrhagic stroke is meticulously managed. Severe cases may incline toward surgical interventions, such as craniotomy and neuroendoscopic surgeries (7). Despite these advancements, the efficacy of tPA therapy is hampered by the narrow time window within which the treatment can be administered, a situation further compounded by patient-related factors such as delayed hospital arrival (8). Furthermore, surgical intervention has not substantially improved mortality rates or patient prognosis (9).

Within the sphere of thrombotic disorders, platelets, being infinitesimal cell fragments, are cardinal actors in thrombus generation and are the core focus of antithrombotic therapy (10). Recent research has elucidated that platelets are activated through various agonists, such as reactive oxygen species, von Willebrand factor, and damage-associated molecular pattern molecules, in the wake of ischemia/reperfusion (I/R) damage (11). Preliminary stages of cerebral vessel thrombus formation involve the accumulation of platelet-bound red blood cells and certain coagulation factors at the injury site, thereby giving rise to a developing, porous, protein-scaffolded thrombus. However, subsequent accruement of platelets and fibrin metamorphoses the thrombus into a dense, stable, and high-occlusion structure. Such development amplifies the resistance of the thrombus to thrombolysis and diminishes tPA penetration, thereby presenting a significant clinical challenge to IS treatment (12). While antiplatelet agents (like aspirin and clopidogrel) are enlisted as secondary prevention treatments for stroke, alternative antithrombotic therapies not targeting platelets have comprehensively demonstrated efficacy only for atrial fibrillation (11). Consequently, the link between cerebral ischemic damage and platelets is gaining extensive scientific focus in the quest for viable diagnostic and therapeutic targets.

Over recent decades, the advent of multi-omics, sundry artificial intelligence mechanisms, and data-driven technologies has extensively propelled the discovery of medical diagnostic and prognostic markers and the screening of prospective drug candidates (13). Based on the intricate and high-dimensional nature of datasets related to cerebral ischemia, the imperative of employing machine learning—a suite of mathematical approaches devised to extract knowledge and insights from expansive datasets—has become more apparent (13) Computer-Assisted Drug Design (CADD), which utilizes computational technology and software to enhance the identification of potential drug candidates backed by the structural understanding of target molecules (structure-based) or established ligands with biological functions (ligand-based), is becoming fundamental (14). In recent years, there has been significant exploration of expression data pertaining to IS. Zhang et al. conducted a comprehensive analysis, determining that the differentially expressed genes within the IS patient dataset were notably enriched in two pathways, namely, oxidative phosphorylation and Alzheimer’s disease (15). Furthermore, the validation of key genes was performed using quantitative real-time polymerase chain reaction (qRT-PCR) (15). Additionally, Yang et al. employed a weighted co-expression network analysis to categorize patients with acute IS into three subgroups. This classification facilitates tailored treatment based on their peripheral blood immune status (16). Several studies have utilized weighted gene co-expression network analysis (WGCNA) to identify immune-related genes and cell death-related biomarkers, which play pivotal roles in the progression of IS (17, 18). Concurrently, the networks associated with ciRNA, miRNA-mRNA, and neutrophils have been established, shedding light on the pertinent gene biomarkers (19, 20). Despite the previous bioinformatics analyses reporting various cell death modes and immunophenotypes in IS, a systematic analysis of platelets, integral targets in the coagulation and antithrombotic processes of IS, and their related drugs, remains outstanding. This endeavor, processed through a meshwork of bioinformatics and machine learning, aims to establish a validated approach to drug screening premised on the genes associated with this model.

## Section: Materials and methods

Basic information about the datasets.

## Section: Materials and methods › Data sources and processing

The GSE16561 and GSE22255 datasets were retrieved from the Gene Expression Omnibus database (http://www.ncbi.nlm.nih.gov/geo/) (21). These cohorts include peripheral blood samples from IS patients. Comprehensive details regarding these datasets are briefly summarized in Table 1 . The inclusion criteria for the dataset in this study comprised the following: (a) the dataset needed to encompass a genome-wide mRNA expression profile. (b) The data source should originate from peripheral blood samples obtained from individuals within the IS group and samples from healthy population controls that had not been stimulated with drugs and transfected. (c) The dataset had to be original and complete. (d) The dataset type was specifically designated as “expression profiling by array.”

Moreover, the identifier conversion for expression profiling arrays of GSE22255 and GSE16561 was achieved employing the “hgu133plus2.db” Platform annotation file, alongside the “tidyverse” and “AnnoProbe” packages sourced from R. After their generation, the expression profiles were consolidated utilizing the Combat function derived from the “sva” package to neutralize potential batch discrepancies. An in-depth examination of the preprocessed data was conducted via principal component analysis (PCA), facilitated by applications of the “FactoMine” and “factoextra” R packages.

Basic information about the datasets.

## Section: Materials and methods › Analysis of differentially expressed genes and construction of the WGCNA network

The “limma” package, also a function of R, was utilized for screening differentially expressed genes (DEGs) within the IS patient pool and control group in the combat dataset. Threshold values for DEG identification were stringently established at P < 0.05 and |log2 fold change (FC)| ≥ 1, respectively. Following this procedure, the identified DEGs of blood samples were introduced for WGCNA using the “WGCNA” package in R (22).

Upon conducting the logarithmic transformation of expression profiles, the hclust function guided the clustering of DEGs into comparable modules. The enable WGCNA Threads function directed multithreaded operations juxtaposed with a scatter plot to distinguish the optimal threshold. In contrast, the urodynamic function was applied to meticulously analyze the gene hierarchical clustering tree, resulting in co-expression modules. Afterward, co-expression modules exhibiting close resemblance (r > 0.75) were grouped.

## Section: Materials and methods › Function enrichment of Gene Ontology and Kyoto Encyclopedia of Genes and Genomes and gene set enrichment analysis

The lightgreen module, which included 51 genes of WGCNA results, was considered the platelet-related module. We used the enrichGO and enrichKEGG functions of the “ClusterProfiler” package in Bioconductor (http://bioconductor.org/packages/release/bioc/html/clusterProfer.html) to perform Gene Ontology (GO) and Kyoto Encyclopedia of Genes and Genomes (KEGG) enrichment analysis on genes in the lightgreen module. Specifically, the identification of biological processes (BPs), cellular components (CCs), molecular functions (MFs), and KEGG pathways under the human genome was performed to identify platelet-related BPs and pathways. The P value cutoff was 0.05. To determine whether there were any remaining platelet-relevant gene (PRG)-enriched pathways in other modules, the expression profiles of all DEGs were subjected to gene set enrichment analysis (GSEA), and platelet-related GO entries or KEGG pathways and their enriched genes were screened out with adjusted P < 0.05 through GSEA function in the “ClusterProfiler” package.

## Section: Materials and methods › Construction and analysis of protein–protein interaction

STRING database (https://cn.string-db.org/) was used to conduct the protein–protein interaction (PPI) of 66 genes in platelet-related GO entries or KEGG pathways and the module. Organisms were chosen “Homo sapiens,” the minimum required interaction score corresponding to “high confidence (0.700)” and the “tsv” format of the result and then output into Cytoscape 3.9.0. Then, to identify highly interconnected gene modules, the “MCODE” plugin of Cytoscape was used according to the “K-core>2.” Hub genes were detected with the “cytiHubbvba” plugin of Cytoscape according to their network features. Hub genes and genes in core modules were merged, and duplicates were removed. Lastly, the subsequent establishment of the PPI biological function co-expression network of PRGs was realized by GeneMANIA (http://www.genemania.org/).

## Section: Materials and methods › Screening of diagnostic biomarkers via machine learning

Least absolute shrinkage and selection operator (LASSO) was used in this study to screen for significant platelet-associated prognostic genes (PAPGs). After removing genes with 0 coefficient, the “glmnet” package in R was used to perform LASSO and identify genes significantly associated with IS and control samples. The formula for calculating the LASSO risk score is as follows: Risk score = (ExpressionGENE1 × CoefficientGENE1) + (ExpressionGENE2 × CoefficientGENE2) +…+ (ExpressionGENEn × CoefficientGENEn) (23). LASSO coefficient maps and curves are presented in R using the plot function.

## Section: Materials and methods › Validation of diagnostic efficacy of signature genes in IS

The samples in the combined expression matrix of GSE16561 and GSE22255 were divided into high-risk groups and low-risk groups according to the risk score of LASSO. The risk scores of high- and low-risk groups for each gene set and the expression levels of PAPGs in IS patients and controls were presented as box plots using the “ggplot2” package in R. We further evaluated its diagnostic potential in GSE16561 and an outside validation group, GSE22255, respectively. The “ROCR” package in R was used to perform the receiver operating characteristic (ROC) curve and evaluate the diagnostic potential of the PAPGs. The value of the area under the curve (AUC) greater than 0.7 indicated favorable diagnostic performance.

## Section: Materials and methods › Immune cell infiltration

The Cell-type Identification By Estimating Relative Subsets Of RNA Transcripts (CIBERSORT), a computational method that can analyze the expression profile matrix by vector regression, can identify 22 human immune cell subtypes. We used the “CIBERSORT” package in R to explore the differences in immune cell composition between IS and normal patients. The “corrplot” package was used to draw the correlation between immune cell composition and PAPGs by the Spearman method.

## Section: Materials and methods › Construction of mRNA–miRNA interaction network

Two analytical tools, MiRTarBase and miRWalk database, were used to predict the pivotal miRNAs targeted by PAPGs. The results of the two databases were taken from the intersection of the miRNAs to screen out the miRNAs targeting more than two genes as the retention.

## Section: Materials and methods › Drug discovery in Connectivity Map

Connectivity Map (CMap) is an open database (https://www.broadinstitute.org). We used to predict small molecule compounds that may induce or reverse the altered expression of PAPGs in cell lines and to identify connections between potential drugs that share chemicals, physiological processes, and mechanisms of action (24). It came into service to screen potential drugs according to PRGs in IS patients.

## Section: Materials and methods › Molecular docking analysis

The obtained potential antiplatelet drugs of IS patients were docked with six proteins in PAPGs. Molecular docking was performed using AutoDockTools 1.5.6 and AutoDock Vina 4.2. Briefly, the docking is as follows. Firstly, the core compound structure files (mol2 format) were downloaded from the PubChem database. ChemDraw was used to minimize the structure energy and convert the structure into a 3D structure. Then, the target crystal structure was obtained from the PDB database (https://www.pdb.org/x) and imported into PyMOL 1.7.2.1 (https://pymol.org/2/x) for dehydration and hydrogenation for ligand separation. Docking grid boxes were subsequently constructed in AutoDockTools 1.5.6 at the active site of each target protein and then saved in pdbqt format. Molecular docking of putative targets and active compounds using AutoDock Vina 4.2 and evaluating free binding energies. Finally, visualize and analyze the interaction and critical patterns between drugs and proteins using PyMOL and Discovery Studio 2020.

## Section: Materials and methods › Materials

Linseed oil (purity ≥99%) was purchased from Aladdin (Shanghai, China). Ciprofibrate (molecular weight = 289.15; purity >98%) was obtained from Aladdin (Shanghai, China). Enteric-coated aspirin was purchased from Bayer Healthcare Co. Ltd. (Beijing, China). Rat ELISA kits for 6-keto-prostaglandin F1α (6-keto-PGF1α), thromboxane B2 (TXB2), tissue plasminogen activator (tPA), and plasminogen activator inhibitor (PAI) were acquired from RuiDaHengHui Science & Technology Development Co., Ltd. (Beijing, China). Human assay kits for fibrinogen (FIB) content were obtained from Mantino Medical Devices Co., Ltd. (Changchun, China). TRIzol (155960-18) was purchased from Ambin (Beijing, China). Triphenyltetrazolium chloride (TTC) Solution (2%) was purchased from Solarbio (Beijing, China). Red Blood Cell Lysis Buffer (C3702) and DEPC water (R0022) were provided by Beyotime (Shanghai, China). PrimeScript™ RT Master Mix (Perfect Real Time) (RR036A) and TB Green Premix Ex Taq II (Tli RNaseH Plus) (2X) (RR036A) were purchased from Takara (Beijing, China).

## Section: Materials and methods › Animals

In this experiment, healthy male Sprague-Dawley (SD) rats (230–270 g) were purchased from Beijing Vital River Laboratory Animal Technology Co., Ltd. (Beijing, China). All of the SD rats were adapted to ventilated cages (temperature: 20°C–25°C, relative humidity: 30%–50%) under a 12-h light/dark cycle and were given free access to food and water. All animal care and experimental protocols were approved by the Institutional Animal Care and Use Committee of the Chinese Academy of Medical Sciences & Peking Union Medical College (SYXK 2023–0008). All efforts were made to minimize the number of animals used and to ensure minimal suffering.

## Section: Materials and methods › Medial cerebral artery occlusion/reperfusion model

The SD rats were anesthetized with isoflurane (4% for initiating anesthesia in a chamber and 1.5% for maintaining anesthesia afterward), and the cerebral I/R was induced by medial cerebral artery occlusion/reperfusion (MCAO/R) operation. In a nutshell, the suture occlusion technique was used to occlude the middle cerebral artery, and the lines were then removed from the common carotid artery after 120 min (25). The sham-operated rats suffered from the same procedure apart from the sutures inserted into the internal carotid artery. A heating pad (Sunbeam, USA) was used to keep the body temperature of rats at 37°C ± 0.5°C. The groups of animals were blinded; the researchers did not know to which group each animal was assigned.

## Section: Materials and methods › Drug treatment

The drugs were dissolved in 5% carboxymethylcellulose sodium before administration. All of the drugs were chronically delivered into bodies by intragastric (i.g.) administration. The rats were randomly assigned to five experimental groups: the sham group, the MCAO/R group, the ciprofibrate + MCAO/R group, the linseed oil + MCAO/R group, and the aspirin + MCAO/R group. Linseed oil (3 mL kg-1), ciprofibrate (7.5 mg kg-1), or aspirin (positive control drug, 30 mg kg-1) were given 14 days before MCAO surgery.

## Section: Materials and methods › TTC staining

TTC staining was conducted 24 h after I/R to determine whether the cerebral infarction model was successfully established and the reduction of cerebellar infarction volume in the treatment groups. The rats’ brains were frozen at -20°C for 20 min, cut into 2-mm coronal slices, placed in TTC staining solution (2%), incubated at 37°C for 15 min, and overnight in 4% paraformaldehyde.

## Section: Materials and methods › Enzyme-linked immunosorbent assay

Plasma was collected from each sample. The expression level of FIB, 6-keto-PGF1α, TXB2, t-PA, and PAI was assessed using enzyme-linked immunosorbent assay (ELISA) kits according to the previous method (26).

## Section: Materials and methods › Blood total RNA extraction and real-time quantitative polymerase chain reaction

Real-time quantitative polymerase chain reaction (RT-qPCR) was used to assess mRNA expression. First, total RNA was isolated from arterial blood nucleated cells using TRIzol and red blood cell lysate. Complementary DNA was synthesized using PrimeScript™ RT Master Mix. PCR primer sequences are shown in Supplementary Table S1 . The prepared cDNA, GAPDH, and TB Green were used as a template and reference for RT-qPCR reactions on LightCycler96 Real time PCR System (Roche, USA). Amplification conditions were as follows: 95°C for 5 min, 95°C for 10 s, 60°C for 30 s, and 72°C for 30 s, for a total of 35 cycles. Eventually, the relative mRNA expression was analyzed using the 2−ΔΔCq method [ΔCq = Cq (target gene)-Cq (reference gene)] (27).

## Section: Materials and methods › Statistical analysis

The bioinformatics analysis was conducted with R software (Version 4.3.0). GraphPad Prism9.5 was used for statistical analysis in biological experiments. Data were analyzed using Student’s t-test or one-way ANOVA, followed by Tukey’s test or two-way ANOVA and Bonferroni’s multiple comparison test to determine whether the data were normally distributed. P < 0.05 was deemed statistically significant in all cases. ImageJ 1.44p software (National Institutes of Health, Bethesda, MD, USA) was used to quantify the cerebral infarct area.

## Section: Results

The experimental technical road map of the whole essay.

Normalization of the dataset and acquisition of differentially expressed genes. PCA plots for GSE16561 and GSE22255 samples (A). PCA plots for IS and control samples (B). Volcano plot of DEGs in IS patients and healthy individuals (|logFC| > 2, P < 0.05) (C). Differential fold plot of DEGs between IS patients and healthy individuals (D). PCA, Principal components analysis; DEGs, Differentially expressed genes; IS, Ischemic stroke; logFC, Log fold change.

Establishment of WGCNA network of DEGs. Cluster tree of 102 samples after clipping (A). Analysis of the scale-free exponent and the average connectivity of each soft threshold, the red line indicates the minimum soft threshold of 9 for constructing the scale-free network (B). Clustering of modular characteristic genes for all DEGs (C). Gene dendrogram for all DEGs (D).

GO and KEGG enrichment analysis of the lightgreen module. The top 5 GO entries (A) and KEGG pathways (B) of enriched genes and their enriched targets were identified. Platelet-related enrichment analysis entries (C) and their corresponding targets (D) in the lightgreen module.

Screening and recruitment of PRGs. GSEA of platelet-related KEGG gene set (A), platelet-related GO.CC gene set (B, E), platelet-related GO.MF gene set (C), and platelet-related GO.BP gene set for all genes (D). Protein–protein interaction (PPI) analysis of platelet-associated gene sets (F). The Top 15 Hub gene of the PPI network, and from yellow to orange to red, genes get higher and higher scores, the top 2 modules of this network, and K-core = 2, module 1 score = 7.429, module 2 score = 4.500 (G).

Development and validation of platelet-related diagnostic models. Distribution of LASSO regression coefficients for PADGs (A). The parametric plot of LASSO regression for PRGs (B). Risk scores of platelet-related diagnostic models for IS patients and healthy people in GSE16561 and GSE22255 (C). ROC curve analysis of individual factors and diagnostic models of GES16561 and GSE22255 (D). Relative mRNA levels of Vcl, Thbs1, F13a1, Src, and App in sham and MCAO/R groups (E). (* P < 0.05, ** P < 0.01, *** P < 0.001.).

Immune infiltration analysis. Correlation between high-risk and low-risk groups with 19 immune cells (A). Correlation analysis between PADGs and 19 kinds of immune cells (B). Scatter plot of association between APP and monocytes, F13A1 and monocytes, and PPBP and resting mast cells (C) (* P < 0.05, ** P < 0.01, *** P < 0.001).

Screening of antiplatelet-related small-molecule drugs in IS. Construction of the miRNA-mRNA-drug network (A). Scoring of the pharmacological similarities between the top 5 compounds and platelet inhibitors (B).

Docking binding energy of PADGs and small-molecule drugs.

Molecular docking of SRC and small-molecule drugs. Docking situation (A) and interaction (B) of SRC and alpha-linolenic acid. Docking situation (C) and interaction (D) of SRC and ciprofibrate.

Verification of the changes in coagulation function and diagnostic marker expression. TTC staining of brain slices (A) and the infarction percentage (B) statistics. The changes in body weight of rats in each group were calculated from the first day of administration to the 15th day before sacrifice (C). Relative mRNA levels of App, F13a1, Ppbp, SRC, Thbs1, and Vcl in sham, MCAO/R, MCAO/R + linseed oil, MCAO/R + ciprofibrate, and MCAO/R + aspirin groups (D-I). (* P < 0.05, ** P < 0.01, *** P < 0.001.).

The content of coagulation factors between the different groups. The FIB content of each group (A). The tPA content of each group (B). The TXB2 content of each group (C). The PAI content of each group (D). The 6-keto-PGF1αcontent of each group (E). (* P < 0.05, ** P < 0.01, *** P < 0.001.).

## Section: Results › Experimental design

The study’s workflow is depicted in Figure 1 , which outlines each step of the methodology. Initially, the data were processed to DEGs. Two datasets, GSE22255 and GSE16561, were amalgamated and normalized to create a comprehensive gene expression profile. The DEGs were subsequently applied to the WGCNA and PPI network to identify platelet-related modules and corresponding genes. A total of 25 PRGs were distinguished. Following this, the LASSO algorithm formulated a platelet-related diagnostic model, including six diagnostic molecular markers. Potential IS-related antiplatelet drugs were forecasted, and their molecular binding to platelet-related diagnostic genes (PADGs) was illustrated. The possibility of miRNAs that could modulate the expression of these markers was also projected. The final step involved validating the changes in the expression of these proposed diagnostic markers in rat blood samples pre- and post-IS. Additionally, predictions related to the potential drug’s effectiveness in preventing cerebral infarction and enhancing coagulation capacity were verified.

The experimental technical road map of the whole essay.

## Section: Results › Data processing and DEG identification

PCA between the two datasets and between IS patients and controls showed that normalized GSE16561 covered GSE22255, with apparent differences in samples between IS patients and management ( Figures 2A, B ). After differential analysis of the expression profile of GSE22255 and GSE16561 combination, 2,940 DEGs between IS patients and controls were obtained, of which 1,753 upregulated genes were shown in red, 1,187 downregulated genes were shown in blue, and the screening condition was P < 0.05 and |logFC| > 1(FC, fold change; adj.P: adjusted P value), black dots in the volcano plot represent undifferentiated genes ( Figures 2C, D ).

Normalization of the dataset and acquisition of differentially expressed genes. PCA plots for GSE16561 and GSE22255 samples (A). PCA plots for IS and control samples (B). Volcano plot of DEGs in IS patients and healthy individuals (|logFC| > 2, P < 0.05) (C). Differential fold plot of DEGs between IS patients and healthy individuals (D). PCA, Principal components analysis; DEGs, Differentially expressed genes; IS, Ischemic stroke; logFC, Log fold change.

## Section: Results › Establishment of the WGCNA network and identification of the platelet-related module

After removing missing values in the expression profile, we detected heterogeneity in each sample by hierarchical clustering trees, set the cut height to 4,500, used the “cutreeStatic” function to exclude outliers in the study, and included all samples after the cut in the subsequent research. A total of 12,773 genes and 102 representatives from the gene expression matrix were used for WGCNA analysis ( Figure 3A ). The “pickSoftThreshold” function guided the multithreaded work and filtered the soft thresholds ( Figure 3B ). The optimal soft threshold was set to 9. Based on the weighted network and the mutual co-expression of genes, we performed a hierarchical cluster tree analysis to cluster the genes that can interact with each other to generate modules with the most similar expression. Based on their expression profiles, a total of 18 modules were obtained ( Figure 3C ). Dendrogram branching indicated that the genes in each module were highly heterogeneous ( Figure 3D ).

We performed GO and KEGG enrichment analysis on the 18 modules obtained by WGCNA, respectively. Module 7, also known as the lightgreen module, was designated as the platelet-related module due to the significant enrichment of pathways and biological processes associated with platelets and coagulation exclusively within this module ( Supplementary Table S2 ). It consisted of 51 genes, among which 50 genes demonstrated upregulation, while one gene exhibited downregulation within the expression profile of IS patients. GO and KEGG enrichment analysis was performed on the genes in this module. The top 5 enriched genes in the biological processes of GO were blood coagulation, coagulation, hemostasis, regulation of body fluid level, and wound healing ( Figure 4A ). KEGG’s top 5 enriched pathways included platelet activation, TGF-β signaling pathway, etc. ( Figure 4B ). In addition, there are many biological processes and molecular functions related to platelets in this module, including platelet aggregation, platelet morphogenesis, platelet formation, platelet α-granule, platelet α-granule lumen, and platelet α-granule membrane ( Figure 4C ). The relationships between these platelet-related entries and the 14 genes enriched were plotted as a network ( Figure 4D ).

Establishment of WGCNA network of DEGs. Cluster tree of 102 samples after clipping (A). Analysis of the scale-free exponent and the average connectivity of each soft threshold, the red line indicates the minimum soft threshold of 9 for constructing the scale-free network (B). Clustering of modular characteristic genes for all DEGs (C). Gene dendrogram for all DEGs (D).

GO and KEGG enrichment analysis of the lightgreen module. The top 5 GO entries (A) and KEGG pathways (B) of enriched genes and their enriched targets were identified. Platelet-related enrichment analysis entries (C) and their corresponding targets (D) in the lightgreen module.

## Section: Results › Analysis of GSEA and PPI networks and integration of PRGs

Although the lightgreen module was identified as the most platelet-related module, GSEA was performed for all expressed genes to avoid missing PRGs in stroke patients in other modules. Indeed, numerous platelet-related gene sets were identified and were enriched for factors involved in megakaryocyte development and platelet production, platelet alpha granules, platelet-derived growth factor binding, platelet-derived growth factor receptor signaling, and platelet alpha granules ( Figures 5A-E ).

Deletion of duplicate values from these platelet-related gene sets resulted in 65 genes that were entered into STRING for protein–protein interaction analysis, with a confidence of greater than 0.700 ( Figure 5F ). The “cytohubba” plugin in Cytoscape 3.9.0 analyzed the above PPI network and screened the top 15 genes ( Figure 5G ). The “MCODE” plug-in was also used, and the genes with a degree value less than 2 were trimmed. Node Score Cutoff was selected as 0.2, K-core as 2, and Max. Depth was chosen as 100 to cluster the remaining genes. A total of two modules were obtained: module 1 had 8 nodes and 26 edges with a score of 7.429 ( Figure 5G ), and module 2 had 5 nodes and 9 edges with a score of 4.500 ( Figure 5G ). Finally, we summarized 15 Hub genes, 8 genes obtained by clustering 14 genes enriched in platelet-related entries in 14 lightgreen, and 25 genes were confirmed as PRGs ( Supplementary Table S3 ).

Screening and recruitment of PRGs. GSEA of platelet-related KEGG gene set (A), platelet-related GO.CC gene set (B, E), platelet-related GO.MF gene set (C), and platelet-related GO.BP gene set for all genes (D). Protein–protein interaction (PPI) analysis of platelet-associated gene sets (F). The Top 15 Hub gene of the PPI network, and from yellow to orange to red, genes get higher and higher scores, the top 2 modules of this network, and K-core = 2, module 1 score = 7.429, module 2 score = 4.500 (G).

## Section: Results › Identification of PADGs and validation of diagnostic models

We obtained the expression data of 25 PRGs from the combined expression profiles of GSE16561 and GSE22255 as the training set. We then applied the LASSO algorithm to derive coefficient profiles ( Figure 6A ) and partial 191 likelihood deviations ( Figure 6B ) using the “glmnet” package in R. From these analyses, we identified six labels with non-zero coefficients, namely, APP, THBS1, F13A1, SRC, PPBP, and VCL; these tags were used to construct the LASSO regression model and were identified as PADGs. The risk score formula was as follows: riskScore = 0.032435376×ExpressionMAPK3 + 0.000297749 × ExpressionPPBP + 0.015633334 ×ExpressionTHBS1 + 0.001329085× ExpressionF13A 1 + 0.118914685 × ExpressionSRC +0.015304202 × ExpressionVCL. The expression matrices of PRGs from each dataset of GSE16561 and GSE22255 were selected as two separate validation sets with forgeneralized cross-validation of the risk score model. Patients with IS in each cohort had significantly higher risk scores than the control samples ( Figure 6C ). ROC analysis was subsequently used to determine the diagnostic potential of our model. In the two validation sets, the AUC of the total risk screen was 0.841 and 0.791, respectively, which was larger than the AUC of any single variable screened by the LASSO model in the validation set ( Figure 6D ). Additionally, we conducted external validation using mRNA samples from the peripheral blood individuals affected by stroke and healthy individuals within the GSE202709 dataset. The risk score within the stroke population group was notably higher than that within the healthy group ( Supplementary Figure S1A ), and the ROC analysis illustrated an AUC value of 0.917 ( Supplementary Figure S1B ). This indicates that the diagnostic potential of the risk score model is greater than that of any single PADG.

In addition, to test the reliability of this model, we performed cerebral I/R in rats. The RT-qPCR findings showed that the relative mRNA levels of VCL, THBS1, F13A1, SRC, and APP in the MCAO/R group’s blood rose significantly (P < 0.05 or P < 0.0001) ( Figure 6E ). This trend aligns with the expression pattern these biomarkers showed in human peripheral blood in previous screenings.

Development and validation of platelet-related diagnostic models. Distribution of LASSO regression coefficients for PADGs (A). The parametric plot of LASSO regression for PRGs (B). Risk scores of platelet-related diagnostic models for IS patients and healthy people in GSE16561 and GSE22255 (C). ROC curve analysis of individual factors and diagnostic models of GES16561 and GSE22255 (D). Relative mRNA levels of Vcl, Thbs1, F13a1, Src, and App in sham and MCAO/R groups (E). (* P < 0.05, ** P < 0.01, *** P < 0.001.).

## Section: Results › Immune cell infiltration of PADGs

CIBERSORT represents a deconvolution computational algorithm designed to estimate the proportions of 22 immune cells within a given tissue based on the gene expression derived from RNA sequencing (28, 29). In this study, we employed the “CIBERSORT” tool within the R environment to assess the immunological profiles of peripheral blood samples obtained from both high-risk and low-risk individuals. Populations at high risk had higher naive CD4 T cells, resting CD4 memory T cells, activated CD4 memory T cells, activated natural killer (NK) cells, macrophages M0, and resting dendritic cells compared with the population at low risk. On the contrary, memory B cells, CD8 T cells, resting NK cells, monocytes, macrophages M2, activated mast cells, and activated neutrophils were lower ( Figure 7A ). All PADGs were positively correlated with monocytes and resting dendritic cells and negatively correlated with naive B cells and activated NK cells. APP and SRC were negatively correlated with neutrophils, while PPBP, THSB1, F13A1, and VCL were positively correlated with neutrophils. Only VCL was negatively correlated with macrophage M1 ( Figure 7B ). In addition, the correlation coefficients between APP and monocytes, F13A1 and monocytes, platelet basic protein (PPBP), and resting mast cells were large. All P values were less than 0.05 ( Figure 7C ). APP and F13A1 may cause changes in the immune microenvironment by regulating monocytes after IS.

Immune infiltration analysis. Correlation between high-risk and low-risk groups with 19 immune cells (A). Correlation analysis between PADGs and 19 kinds of immune cells (B). Scatter plot of association between APP and monocytes, F13A1 and monocytes, and PPBP and resting mast cells (C) (* P < 0.05, ** P < 0.01, *** P < 0.001).

## Section: Results › Screening of small-molecule drugs

The CMap was used to compare the reference gene expression profiles after drug treatment according to the upregulated or downregulated differential genes to find possible small-molecule drugs. The upregulated genes in the 22 PRGs were used to predict potential drugs, and 30 antiplatelet-related drugs were screened out, as shown in Supplementary Table S4 . We employed miRWalk 2.0 software to conduct mRNA-miRNA analysis on six genes within PADGs ( Supplementary Figure S2A ). Subsequently, 59 miRNAs were subjected to enrichment analysis using GeneCodies, revealing significant enrichment in biological functions pertaining to protein phosphorylation, negative regulation of transport processes, and signal transduction. Additionally, the enriched biological pathways encompassed signaling events in the FoxO signaling pathway, lipid and atherosclerosis, and the AMPK signaling pathway ( Supplementary Figures S2B, S2C ). The first five drugs (alpha-linolenic acid, ciprofibrate, SYK inhibitor, verapamil, and GR-206) were selected to construct a miRNA-mRNA-drug network ( Figure 8A ). The top 5 drugs were entered into the CMap touchstone database, which facilitates the exploration of connections between the genetic alterations of genes and the drug signatures, in order to identify compounds with similar pharmacological effects. Each predicted drug exhibited more than 90% similarity to at least one existing antiplatelet agent based on alterations in gene expression profiles: alpha-linolenic acid with platelet-activating factor receptor antagonist, GR-206 with platelet aggregation inhibitor, SYK inhibitor with phosphodiesterase inhibitor, verapamil with platelet growth factor receptor antagonist, ciprofibrate with platelet growth factor can be seen. Receptor antagonists are highly similar ( Figure 8B ).

Screening of antiplatelet-related small-molecule drugs in IS. Construction of the miRNA-mRNA-drug network (A). Scoring of the pharmacological similarities between the top 5 compounds and platelet inhibitors (B).

## Section: Results › Molecular docking of compounds with PADGs

In light of the structural formula of SKY inhibitors is not single, alpha-linolenic acid, and ciprofibrate were selected for molecular docking with six PADGs in Autoduck, each with 20 conformations. A total of 18 groups were docked, and the lowest binding energy of the docked conformation in each group was selected and shown in Table 2 . A binding energy of less than -5 indicates good docking in nine groups. The ligands in the other three groups were all alpha-linolenic acid, and the absolute values of binding energies were low. The binding of SRC to these two compounds to other proteins suggests that SRC may be an essential target for the pharmacological effects of these drugs. Subsequently, we conducted visualizations of the docking process involving SRC and these two compounds, employing Discovery Studio to illustrate a 2D map demonstrating the interaction between the receptor and the ligand. From the range of conformations, we selected the conformation displaying the best overlap for further analysis of the binding interaction. Specifically, α-linolenic acid was observed to form an alkyl bond with the 190th amino acid (LEU) of the A-chain of SRC (1us0). Conversely, ciprofibrate engaged in hydrogen bonds with the 191st (THR), 192nd (GLN), and 193rd (GLU) amino acids of the A chain of SRC (1us0), while establishing πσ bonds with the 194th amino acid (LYS) of the A chain. Additionally, it formed an alkyl bond with the 195th amino acid (LEU) of the A chain, as illustrated in Figures 9A-D .

Docking binding energy of PADGs and small-molecule drugs.

Molecular docking of SRC and small-molecule drugs. Docking situation (A) and interaction (B) of SRC and alpha-linolenic acid. Docking situation (C) and interaction (D) of SRC and ciprofibrate.

## Section: Results › Verification of the changes of coagulation function in rat MCAO/R model

Based on their highest scores, pharmacodynamic experiments and coagulation factor detection were performed using the top-ranked predicted drugs, ciprofibrate and linseed oil. The linseed oil utilized had an alpha-linolenic acid content of 53%. Results depicted in Figures 10A, B show that after I/R, the percentage of infarction stood at 23.10% ± 1.57%. Notably, this was reduced to 18.54% ± 1.44% following the prophylactic administration of ciprofibrate and to 18.76% ± 2.61% after the administration of linseed oil. This reduction was statistically significant when compared with the sham-operation group (P < 0.05). However, the body weight observed among the groups did not differ significantly, with the exception of the sham group, as illustrated in Figure 10C .

In Figures 10D–I , it was observed that the mRNA levels of App, F13a1, Ppbp, SRC, Thbs1, and Vcl exhibited a significant increase subsequent to MCAO induction (P < 0.05, P < 0.01, or P < 0.001). Notably, the two drugs foreseen by CMap—namely, linseed oil (a major component of α-linolenic acid) and ciprofibrate—nearly reversed the MCAO-induced elevation in mRNA levels of these six genes (P < 0.05, P < 0.01, or P < 0.001). Although aspirin did not lead to a significant reduction in the mRNA levels of Vcl and Thbs1 compared with the MCAO/R group, it effectively reversed the mRNA levels of the remaining four genes. These findings align closely with the earlier predicted alterations in gene expression profiles of the drugs.

Subsequent figures, specifically Figures 11A–C , indicate a significant increase in FIB, tissue tPA, and TXB2 levels in rats after MCAO (P < 0.05 or P < 0.001). While not as impactful as aspirin in returning the indices to normal levels, both ciprofibrate and linseed oil treatments resulted in substantial reductions in the plasma levels of these factors (P < 0.05, P < 0.01, or P < 0.001, respectively). These substantial trends evidence the valuable preventative impact of these two drugs on the enhancement of coagulation function post-IS by our initial predictions. Contrastingly, in Figures 11D, E, the levels of PAI and 6-keto-PGF1α declined significantly after MCAO (P<0.05 or P<0.001). However, more significant increases were recorded in the ciprofibrate group than in the aspirin group when compared to MCAO/R group (P<0.01 or P<0.001).

Verification of the changes in coagulation function and diagnostic marker expression. TTC staining of brain slices (A) and the infarction percentage (B) statistics. The changes in body weight of rats in each group were calculated from the first day of administration to the 15th day before sacrifice (C). Relative mRNA levels of App, F13a1, Ppbp, SRC, Thbs1, and Vcl in sham, MCAO/R, MCAO/R + linseed oil, MCAO/R + ciprofibrate, and MCAO/R + aspirin groups (D-I). (* P < 0.05, ** P < 0.01, *** P < 0.001.).

The content of coagulation factors between the different groups. The FIB content of each group (A). The tPA content of each group (B). The TXB2 content of each group (C). The PAI content of each group (D). The 6-keto-PGF1αcontent of each group (E). (* P < 0.05, ** P < 0.01, *** P < 0.001.).

## Section: Discussion

IS represents a gene-associated multivariate and heterogeneous circulatory system aberration characterized by a high mortality rate and protracted functional incapacitation. Prior peer-reviewed empirical investigations have explored the transcriptional profiles presented in the peripheral blood of IS patients or within murine (MCAO) and rat brain tissue to delineate biomarkers and therapeutic targets for IS. Notwithstanding, the DEGs revealed inconsistencies across separate studies (30–32).

The presented study is pioneering in employing a confluence of LASSO, WGCNA, and CIBERSORT algorithms, utilizing platelets as definitional tags to unearth novel biomarkers and diagnostic models germane to IS, grasping the diversity and intricacy of the immune microenvironment, and exploring prospective antiplatelet drugs. The current investigation proposes platelet-linked diagnostic markers in IS, specifically APP, SRC, PPBP, F13A1, VCL, and THSB1. Upon conducting a comprehensive bioinformatics analysis, Wicik Z and colleagues ascertained APP to be firmly tied to collective platelet activity, designating it as one of the genes most susceptible to noncoding regulation in diseases related to platelet reactivity (33), a conclusion in line with our findings. Furthermore, the probability prediction models integrating these PADGs proved highly accurate (with AUC > 0.7) in diagnosing IS within both cohorts.

The enrichment analysis of the 51 DGEs housed in the lightgreen module ascertains these genes’ participation in biological procedures including, but not limited to, “blood coagulation,” “coagulation,” and “hemostasis” following IS. They have salient correlations with the formation, activation, and aggregation of platelets in the bloodstream and platelet α particle genesis and release in the uterine cavity, thereby validating their engagement with IS onset and progression. Embolic stroke is fundamentally anchored in arterial thrombosis, with platelets first observed in blood over 130 years prior and acknowledged as the primary cell type regulating such thrombotic events (34). Post-trauma, platelets discharge contents like thrombin A2 and α particles to mobilize and activate a broader number of platelets, whereupon platelet accumulation occurs at the injury site, leading to primary thrombi formation. Moreover, following reperfusion injury, platelets mediate environmental alterations to the circulatory system, play a role in the detrimental T-cell reactions, and exacerbate and propagate neuroinflammation in I/R injury (35). Therefore, compiling platelet-specific biomarkers as diagnostic indicators or potential therapeutic targets for stroke demonstrates wide-ranging promise.

Our findings mirror the consistent motif in similar scholarly investigations identifying identical pivotal genes. In a significant revelation, SRC was observed to be substantially downregulated poststroke in human brain microvascular endothelial cells (HBMECs), contributing to vascular endothelial cell protection from ischemic and oxygen glucose deprivation/reoxygenation (OGD/R) injury. This was achieved by impairing the SRC signaling trajectory, subsequently realizing gentle inhibitory effects on platelet aggregation (36). Symmetrically, SRC is seen to execute a neuroprotective role in stroke (37). In a sophisticated proteomic analysis by George PM et al., PPBP emerged as a key biomarker in transient ischemic attack (TIA) patients’ serum. Substantial elevations in PPBP serum concentrations were noticed in TIA and minor stroke patients compared to counterparts with migraines and a healthy control group (38). Intriguingly, alterations in these crucial genetic regulators could exacerbate IS severity. Regarding this, it was discovered that the homozygous genotype of the F13A1 204Phe allele precipitously elevated IS risk in young females (39).

In analyzing the consolidated microarray gene expression data, differential landscapes of immune cell types were compared between two cohorts defined as high risk and low risk, utilizing the algorithmic approach provided by CIBERSORT. The analysis engaged 22 immune cell types, leading to the discernment of statistically significant disparities in the constitution of 15 immune cells when contrasting the high-risk group against the low-risk group. An elevation in the prevalence of immune cell groups—naive CD4 T cells CD4, resting CD4 memory T cells, activated CD4 memory T cells, activated NK cells, macrophages M0, and the arrangement of dendritic cells—was significantly noted in the high-risk group relative to that in the low-risk group. Conversely, concentrations of memory B cells, CD8 T cells, resting NK cells, monocytes, macrophages M2, activated mast cells, and neutrophils activated were significantly attenuated.

Significant differences were observed in the proportion of T-cell subsets infiltrating the high-risk group compared to the low-risk group. Notably, the immunomodulatory and hemostatic functions of platelets in IS potentially involve CD4 T cells. Our findings align with established evidence, indicating the pivotal role of CD4+ regulatory T cells in mitigating inflammation and reinstating immune homeostasis poststroke; activated platelets may further influence T-cell function through the secretion of diverse elements like PF4 or serotonin (34, 40). Investigations have revealed that memory CD4 T cells can reduce hemorrhagic transformation in murine IS by binding to platelet P-selectin glycoprotein ligand-1 (41). Moreover, the absence of CD84 on platelets impairs CD4+ T-cell motility and cellular infiltration, consequently reducing thrombus formation and neurological impairment (42). Furthermore, platelet GPIb inhibition diminishes the infiltration of immune cells such as T cells, thus mitigating the local inflammatory response in the ischemic brain (43). In contrast to CD4 T cells, CD8 T-cell infiltration was observed to be lower in the high-risk group following platelet activation compared to the low-risk group. Recent evidence has highlighted that platelet-derived TLT-1 acts as a direct immunosuppressant of CD8+ T cells (44). Platelets can also influence antigen presentation by CD8 T cells; they bind to antigen-specific CD8 T cells through major histocompatibility complex class I (MHC-I) processing and cross-presentation of antigens, thereby regulating CD8+ T-cell numbers, functional responses, and outcomes (45).

Additionally, other immune cells have been demonstrated to be closely associated with the onset or prognosis of IS. Postischemic pharmacological intervention has been shown to augment neuroprotection against ischemic cerebral damage, predominantly by curbing the seepage and activation of NK cells, thereby diminishing infarct dimensions (34). Furthermore, the circulating transfer cell platelets were observed to trigger the downregulation of NK G2D ligands with platelet transforming growth factor-β. This results in the mitigation of NK cell cytotoxicity and their capacity to release IFN-γ (46). Aligning with these findings, our data demonstrate the inverse correlation between activated NK cells and the expression of all six PADGs, in direct contrast with the positive correlation identified with monocytes (28). Monocytes, under specific conditions, tend to form aggregates with platelets in circulation. This phenomenon is frequently observed in patients suffering from cardiovascular and cerebrovascular ailments as a sequela of inflammatory provocation and infection (34). A deeper foray into immune infiltration corroborated the fidelity of our risk stratification model, hence fortifying our confidence therein.

The application of GSEA and PPI network examination using MCODE and CytoHubba plugin tools culminated in identifying an aggregate of 25 platelet-associated genes. Further scrutiny of the correspondent gene expression profile revealed potential antiplatelet therapeutics for IS, alpha-linolenic acid and ciprofibrate. These compounds have the potential to modulate the expression of 22 augmented genes. Alpha-linolenic acid, frequently incorporated into dietary regimens, exerts its effects by mitigating platelet activation, which in turn reduces the presence of pro-inflammatory cells and sickle cell quantities, as evidenced in patients with sickle cell disease (34). It has also been shown to curtail platelet clearance in the reticuloendothelial system in those with atherosclerosis and arterial thrombosis (47). Ciprofibrate, a historically prevalent lipid-lowering medicine, displays significant efficacy in decreasing blood lipid concentrations in patients with hypercholesterolemia (48). When applied in conjunction with aspirin for the management and treatment of patients co-diagnosed with atherosclerosis and hyperlipoproteinemia, an enhanced ability for aspirin to inhibit thromboxane A2 formation and exercise antiplatelet effects has been noted (49). Although these pharmaceutical interventions are currently excluded from declarative clinical guidelines for treating or preempting IS, they have promising platelet inhibitory effects in other thrombotic conditions. Their potential inclusion in the antithrombotic treatment of IS may offer significant financial savings in drug development. Subsequently, we utilized molecular docking to simulate the interaction of these three compounds with PADGs. The majority displayed docking binding energies less than 5, with some—such as SRC—indicating superior docking via traditional hydrogen bonds, hydrophobic bonds, or π bonds, suggesting a possible therapeutic target pertinent to the pharmacological efficacy of these compounds.

Lastly, pharmacodynamic experiments confirmed that both ciprofibrate and alpha-linolenic acid-rich linseed oil could significantly improve the elevation of blood coagulation function after IS and had a significant preventive effect on cerebral infarction. Furthermore, nearly all of them were able to substantially reverse the MCAO/R-induced elevation in mRNA levels of App, F13a1, Ppbp, SRC, Thbs1, and Vcl. Notably, the ability of ciprofibrate to modulate alterations in PAI and 6-keto-PGFα1 after IS was even greater than aspirin’s. This suggests that these two drugs can potentially improve cerebral vascular blockage. RT-qPCR also confirmed a significant increase in the expression of PADGs in blood after IS.

In summary, we identified platelet-related diagnostic markers and established a high-accuracy risk assessment model based on various bioinformatics algorithms and computer-aided drug design methods. Meanwhile, we screened and verified diagnostic markers’ expression and associated drugs’ preventive effects. This study contributes a transformative perspective for the diagnosis approach, prevention, and therapeutic intervention of IS and provides new ideas for the search for antithrombotic drugs with fewer side effects. However, we should underscore the importance of balanced control in managing thromboembolic and hemorrhagic risk when preventing and treating IS. Overenthusiastic thrombolysis, albeit effective in resolving the ischemic event, inadvertently enhances the propensity toward cerebral hemorrhage poststroke. Therefore, identifying the equilibrium point of thrombolysis and hemostasis presents a promising direction for future investigations.

## Section: Conclusion

In summarizing this study, we affirm that our risk assessment model, based on PADGs, specifically APP, THBS1, F13A1, SRC, PPBP, and VCL, presents robust diagnostic capabilities for stroke patients. The noteworthy antithrombus agents—alpha-linolenic acid and ciprofibrate—emerge as potential candidate drugs for preventing and treating cerebral thrombosis post-IS. This underlines a promising milieu for exploring antiplatelet therapy and IS management.

## Section: Data availability statement

Publicly available datasets were analyzed in this study. This data can be found here: https://www.ncbi.nlm.nih.gov/; GSE16561, GSE22255.

## Section: Ethics statement

Ethical approval was not required for the studies on humans in accordance with the local legislation and institutional requirements because only commercially available established cell lines were used. The animal study was approved by the Institutional Animal Care and Use Committee of the Chinese Academy of Medical Sciences & Peking Union Medical College (SYXK 2023–0008). The study was conducted in accordance with the local legislation and institutional requirements.

## Section: Author contributions

YG: Conceptualization, Data curation, Methodology, Writing – original draft, Writing – review & editing. YCL: Methodology, Writing – review & editing. MW: Formal analysis, Writing – review & editing. XD: Writing – review & editing. XS: Project administration, Writing – review & editing. YL: Conceptualization, Funding acquisition, Writing – review & editing. XBS: Formal analysis, Funding acquisition, Resources, Writing – review & editing.


---

# Identification of diagnostic markers and molecular clusters of cuproptosis-related genes in alcohol-related liver disease based on machine learning and experimental validation

- **Authors:** Jiangfa Li, Yong Wang, Zhan Wu, Mingbei Zhong, Gangping Feng, Zhipeng Liu, Yonglian Zeng, Zaiwa Wei, Sebastian Mueller, Songqing He, Guoqing Ouyang, Guandou Yuan
- **Issuer:** Heliyon
- **Type:** Scientific article
- **Published:** 2024-09-12
- **Language:** en
- **DOI:** 10.1016/j.heliyon.2024.e37612
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39315155/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackground and aimsAlcohol-related liver disease (ALD) is a worldwide burden. Cuproptosis has been shown to play a key role in the development of several diseases. However, the role and mechanisms of cuproptosis in ALD remain unclear.MethodsThe RNA-sequencing data of ALD liver samples were downloaded from the Gene Expression Omnibus (GEO) database. Bioinformatical analyses were performed using the R data package. We then identified key genes through multiple machine learning methods. Immunoinfiltration analyses were used to identify different immune cells in ALD patients and controls. The expression levels of key genes were further verified.ResultsWe identified three key cuproptosis-related genes (CRGs) (DPYD, SLC31A1, and DBT) through an in-depth analysis of two GEO datasets, including 28 ALD samples and eight control samples. The area under the curve (AUC) value of these three genes combined in determining ALD was 1.0. In the external datasets, the three key genes had AUC values as high as 1.0 and 0.917, respectively. Nomogram, decision curve, and calibration curve analyses also confirmed these genes’ ability to predict the diagnosis. These three key genes were found to be involved in multiple pathways associated with ALD progression. We confirmed the mRNA expression of these three key genes in mouse ALD liver samples. Regarding immune cell infiltration, the numbers of B cells, CD8 (+) T cells, NK cells, T-helper cells, and Th1 cells were significantly lower in ALD patient samples than in control liver samples. Single sample gene set enrichment analysis (ssGSEA) was then used to estimate the immune microenvironment of different CRG clusters and CRG-related gene clusters. In addition, we calculated CRG scores through principal component analysis (PCA) and selected Sankey plots to represent the correlation between CRG clusters, gene clusters, and CRG scores. Finally, the three key genes were confirmed in mouse ALD liver samples and liver cells treated with ethanol.ConclusionsWe first established a prognostic model for ALD based on 3 CRGs and robust prediction efficacy was confirmed. Our investigation contributes to a comprehensive understanding of the role of cuproptosis in ALD, presenting promising avenues for the exploration of therapeutic strategies.Keywords: Alcohol-related liver disease, Cuproptosis, Diagnostic, Immune infiltration, Machine learning

## Section: Introduction

Alcohol-related liver disease (ALD) is liver damage caused by prolonged heavy alcohol consumption and encompasses a range of diseases, such as alcoholic fatty liver disease, alcoholic hepatitis, cirrhosis, and complications of cirrhosis [[1], [2], [3]]. ALD is one of the leading causes of chronic liver disease worldwide, accounting for 48 % of cirrhosis-related deaths in the United States [4,5]. ALD, with a comparable incidence in China to that in the United States, is emerging as a significant contributor to the overall liver disease burden in China [6].

Copper is an extracellular element responsible for the precise functioning of the bone marrow and central nervous system and acts as a cofactor for many antioxidant enzymes, such as super oxide dismutase; thus, disorders of copper metabolism may cause organ dysfunction [[7], [8], [9], [10]]. Dysregulation of copper is significantly associated with liver disease [11]. Wilson disease is a classic example of copper overload, an autosomal recessive genetic disorder characterized by multiple mutations in the ATP7B gene [12]. Studies have shown a disturbance of copper metabolism in ALD patients [[13], [14], [15]]. Alcohol diet can cause liver damage and decrease the expression of HIF-1alpha, occludin, SOD1, and GPX1 genes. It was also shown that a lack of copper in the diet may exacerbate these changes, and supplementation with copper may improve these conditions [16]. Furthermore, in vitro cell experiments have shown that appropriate copper supplementation can promote cell growth and reduce the production of reactive oxygen species (ROS). Previous studies have shown that moderate ALD is closely related to oxidative stress, and copper deficiency will promote dyslipidemia and increase oxidative stress because copper is an essential cofactor of many antioxidant enzymes; thus, insufficient copper may further promote the damaging effects of alcohol [17]. Alcohol metabolism in the liver cells of patients with excessive alcohol consumption produces a large level of ROS, resulting in elevated lipid peroxidation, which disrupts mitochondrial function and causes liver cell death [18]. Cuproptosis is a new form of cell death associated with many diseases, such as non-ALD,Wilson disease, and hepatocellular carcinoma [[19], [20], [21]].

Research focused on uncovering the relationship between cuproptosis and the underlying pathophysiology of ALD is relatively limited. Therefore, we conducted a comprehensive study of the expression, diagnosis, immune correlation, and mechanism of cuproptosis-related genes (CRGs) in ALD is still needed. In this study, we downloaded ALD-related data from the Gene Expression Omnibus (GEO) database and conducted analysis and machine-learning analyses to explore the relationship between CRGs and ALD. We identified differentially expressed genes and the key genes among them and subsequently built and externally validated a prediction model. Finally, we performed immunoinfiltration analyses, assessed related drugs, and investigated associated competing endogenous RNAs (ceRNAs).

## Section: Materials and methods

Flowchart of the present study.

## Section: Materials and methods › Patients and datasets

The transcriptomic analysis of ALD and normal non-ALD liver specimens included two datasets, GSE28619 and GSE103580, downloaded from the GEO database. Specifically, GSE28619 (based on the GPL570 platform) contained 7 healthy control samples and 15 samples of alcoholic hepatitis. GSE103580 (GPL13667 platform) included 13 cases of alcoholic hepatitis and 1 healthy control. The battle function of the “sva” package was used to eliminate batch effects and potentially unknown variables. After combining data from GSE28619 and GSE103580, the final datasets included 28 cases of alcoholic hepatitis and 8 control cases. The flow chart of this study is shown in Fig. 1.

Flowchart of the present study.

## Section: Materials and methods › Expression of differentially expressed genes in ALD

The differential expression analysis was performed using the R package limma based on the GEO database. We identified differentially expressed genes (DEGs) between ALD and healthy samples. The screening criteria were as follows: P < 0.05. The intersection of DEGs related to CRGs was created using the “VennDiagram” R package and defined as DE-CRGs for subsequent analysis.

## Section: Materials and methods › Correlation analysis and protein-protein interaction network construction

The R software packages “RCircos” and “heatmap” were used to generate landscape maps of 23 chromosomes and heatmaps of 18 DE-CRGs, respectively. The “circlize” software package was used to create correlation Circos plots based on Pearson correlation analysis. Eighteen DE-CRGs protein-protein interaction (PPI) networks were constructed using the Search Tool for the Retrieval of Interacting Genes/Proteins (STRING; https://string-db.org/) database.

## Section: Materials and methods › Gene ontology and KEGG pathway enrichment analysis

The R package “clusterProfiler” was employed to analyze the biological function of genes through Gene Ontology (GO) and KEGG pathway enrichment analysis. GO annotation included biological processes (BP), cellular components (CC), and molecular functions (MF).

## Section: Materials and methods › Construction of the CRGs diagnostic model

Two datasets, GSE28619 and GSE103580, were integrated for modeling, and the GSE142530 and GSE155907 datasets were used as external validation sets for verification. Employing the “glmnet” package in R, we conducted the least absolute shrinkage and selection operator (LASSO) regression on the chosen linear model to decrease the data dimension while preserving valuable variables [22,23]. The main idea of recursive feature elimination (REF) was to build the model iteratively and then select the best (or worst) feature (selected according to the coefficient) [24]. The maximum interval principle of the support vector machine (SVM) was the foundation for the sequential reverse selection algorithm known as support vector machine recursive feature elimination (SVM-RFE) [[25], [26], [27]]. We used the “e1071” package in R to screen the best variable genes to establish the SVM-RFE model [28,29]. The random forest (RF) algorithms were combined to select the best genes. The RF model is a regression tree technique that uses bootstrap aggregation and randomization of predictors to achieve high prediction accuracy [30]. The “randomForest” R package was used for RF. The genes selected by three kinds of machine learning were intersected to obtain the final key genes.

## Section: Materials and methods › Verification of the model

First, we used the “rms” package in R to build a nomogram model to predict the occurrence of ALD. The “pROC” package in R [31] was employed to analyze the area under the curve (AUC), specificity, and sensitivity of diagnostic value for marker genes using a time-dependent ROC. Each central gene was assigned a score, which was then added to form a total score. Two external datasets, GSE142530 and GSE155907, were used to verify the diagnostic capability of the diagnostic model.

## Section: Materials and methods › Gene set enrichment analysis and gene set variation analysis

Gene set enrichment analysis (GSEA) was conducted using the “clusterProfiler” package to explore the potential functions of the hub genes [32]. In addition, differential expression genes (DEGs) and pathway enrichment analyses were executed with the “gene set variation analysis (GSVA)”, “clusterProfiler”, and “Limma” packages. Statistical significance was determined by enrichment analysis with p < 0.05.

## Section: Materials and methods › Evaluating immune infiltration

Using the “GSVA” package in R, a single-sample GSEA (ssGSEA) algorithm was employed to assess enrichment scores between various immune cells and functions or pathways between ALD and control groups. We downloaded reference gene collections from a public database (http://www.immport.org). Spearman correlation analysis was used to explore the relationship between the three key genes and the immune score. The Wilcoxon test was used to explore differences in immune cell and immune-related functional enrichment scores. The enrichment scores between the ALD and normal liver sample groups are represented by box plots.

## Section: Materials and methods › Detection of CRG clusters and gene clusters and their relationship with immune cells

The “ConsensusClusterPlus” package was used to distinguish CRG and Gene clusters according to CRG and gene regulatory factors, respectively. The number of clusters was determined based on a cumulative distribution function (CDF) curve and a specific k value [33]. Then, principal component analysis (PCA) was used to further validate the CRG modification pattern [34]. PCA method was applied to calculate the CRG scores of each sample [35]. The CRG scores of the two clusters were shown in a box graph. Finally, Sankey plots were selected to represent the correlation between CRG clusters, gene clusters, and CRG scores. The ssGSEA was used to estimate the extent of 23 immune cells across different CRG and Gene clusters to explore correlations between them.

## Section: Materials and methods › Drug-gene interaction analyses and ceRNA network construction

Drug-gene interactions were explored using the drug-gene interaction database (DGIdb, https://dgidb.genome.wustl.edu/) [36]. One can forecast the miRNA-mRNA relationship by utilizing the three essential genes in miRDB (http://www.mirdb.org/) and TargetScan (https://www.targetscan.org/vert_80). Evidence of a direct interaction between the miRNA and lncRNA was obtained using SpongeScan (http://spongescan.rc.ufl.edu/). Cytoscape software (version 3.9.0) was utilized to visualize mRNA‒miRNA-lncRNA interactions via the ceRNA network.

## Section: Materials and methods › ALD mouse model construction and histological procedure

Sixteen 8-week-old female C57BL/6 WT mice were used for this experiment. All mice were administered the Lieber-DeCarli diet for 5 days before feeding to adapt to the liquid diet. The experimental group was then freely administered the Lieber-DeCarli diet containing 5 % (v/v) ethanol for 10 days. The control group was provided with an equal calorie-controlled diet. On day 16, the experimental group was given a single dose of ethanol (6 g/kg body weight, 31.5 % ethanol), and the control group was given isocaloric dextrin-maltose [37]. All mice were euthanized 9 h later, and blood was taken from the inferior vena cava with a 1 ml syringe and centrifuged at 3000 rpm for 15 min. The supernatant was collected to obtain the mouse plasma. Serum aspartate aminotransferase (AST) and alanine aminotransferase (ALT) levels were measured using an automatic biochemical analyzer (ANTECH Diagnostics, Los Angeles, CA, USA). Liver tissue samples were also obtained from the mice. Part of each liver sample was placed in an EP tube and directly frozen in liquid nitrogen. The remaining tissue was fixed in formalin solution, embedded in paraffin, and stained with hematoxylin & eosin (HE) staining. A section of frozen fresh liver tissue was prepared with a thickness of 4 mm and stained with Oil Red O. Rabbit monoclonal antibodies were used for immunohistochemistry: anti-DBT (12451-1-AP), anti-DPYD (27662-1-AP), and anti-SLC31A1 (67221-1-Ig). All animal experiments were approved by the Animal Care and Use Committee of the First Affiliated Hospital of Guangxi Medical University (NO.2023-S606-01).

## Section: Materials and methods › Cell culture and treatments

The AML12 cell line was supplied by the Cell Bank of Type Culture Collection of the Chinese Academy of Sciences (Shanghai, China). It was cultured in mouse liver parenchymal cell AML12 complete culture medium with DMEM/F-12 (1:1) (Gibco, 11330-032) 89 mL ITS Liquid Media Supplement (Sigmadg, I3146) 1 mL Dexamethasone (Sigma, D4902-100 mg) 40 ng/mL FBS (Gibco) 10 mL at 37μC with 5 % CO2 using a cell incubator. When cells reached a confluence of 60–70 %, they were divided into 2 groups (n = 4), including [1] the control group (treated with NS) and [2] the ethanol group (treated with 200 mM ethanol). The treatment duration was 24 h. The dose selection of ethanol was based on a previous study on carbon tetrachloride-induced rat hepatocyte injury model.

## Section: Materials and methods › Protein extraction and western blotting

Liver samples were homogenized in lysis buffer (Solarbio R0010). Samples were then sonicated and incubated on ice for 30 min. Debris was removed by centrifugation at 12,000 rpm. Cellular total protein was extracted using a M-PER Mammalian Protein Extraction Reagent (Pierce, Rockford, IL). Samples were separated in a denaturing 10 % polyacrylamide gel and transferred to a 0.45 mm pore nitrocellulose membrane. Non-specific binding sites were blocked with 5 % nonfat milk (YAMEI PS112L) for 1 h at room temperature. Membranes were then incubated with appropriate primary antibodies in TBS with 0.1 % Tween 20 (TBST). Membranes were washed and incubated with secondary antibodies conjugated to horseradish peroxidase to show the bands with Omni-ECL buffer (YAMEI SQ201). Parallel blotting of GAPDH (Proteintech 10494-1-AP) was used as an internal control.

## Section: Materials and methods › Quantitative reverse transcription-polymerase chain reaction (qRT-PCR)

The RNA was extracted from mouse liver tissues and the AML12 cell line with TRIzol reagent (Thermo Fisher Scientific, USA). RNA was extracted and eluted using an RNA binding column, and purified total RNA samples were obtained. The RNA was reverse transcribed using the PrimeScript™ RT reagent Kit (Takara, Japan), and quantitative real-time PCR (qRT-PCR) was performed using the FX Connect system (Bio-Rad, USA) and SYBR® Green Supermix (Bio-Rad, USA). Hub genes expression levels were analyzed using 2−DDCT, and the outcomes were demonstrated using GAPDH as an internal control. To ensure the reliability and comparability of the data, the following normalization criteria were applied:1. We selected GAPDH as reference genes whose expression levels remain constant under different experimental conditions; 2, ΔCt Calculation: The Ct value of the target gene for each sample was normalized to the Ct value of the reference gene, resulting in a ΔCt value; 3. ΔΔCt Method: The ΔCt values of the experimental group were compared with those of the control group to calculate the ΔΔCt value (ΔΔCt = ΔCt (experimental group) - ΔCt (control group)); 4. Calculation of Relative Expression Levels: The relative mRNA expression levels were determined using formula 2^-ΔΔCt. Reverse transcription of the RNA was performed using the PrimeScript™ RT Reagent Kit (Takara, Japan), and qRT-PCR was conducted with an FX Connect system (Bio-Rad, USA) and SYBR® Green Supermix (Bio-Rad, USA). qRT-PCR was repeated three times. The primers used in this study are shown in Supplementary Table S1.

## Section: Materials and methods › Statistical analyses

Continuous variable data are presented as the mean ± standard deviation. Student's t-test was employed to compare two groups, while the Wilcoxon rank-sum test was used to examine non-normally distributed variables. A p value less than 0.05 was considered to indicate a significant difference. The symbols *, **, and *** indicate that the p values were less than 0.05, 0.01, and 0.001, respectively. R software (version 4.2.1) was utilized for all statistical analyses.

## Section: Results

Identification of cuproptosis-related genes in ALD. (A) Heatmap of DEGs was presented. (B) Venn diagrams showing the intersection between DEGs and CRGs. (C) Eighteen DE-CRGs were located on 23 chromosomes, with the boxplots illustrating the differential expression between ALD and control samples (D). (E) Heatmap showed the expression patterns of these 18 DE-CRGs. (F) Gene relationship network diagram of the 18 DE-CRGs. (G) Correlation analysis of the 18 DE-CRGs was conducted, with orange and blue representing positive and negative correlations, respectively. (H) GO analysis of DEGs associated with cuproptosis. (I) KEGG analysis of DEGs associated with cuproptosis. P values are displayed as follows: *p < 0.05; **p < 0.01; ***p < 0.001. ALD, alcohol-related liver disease; CRGs,cuproptosis-related genes; DEGs: Differentially expressed genes. DE-CRGs: differentially expressed cuproptosis-related genes; GO,gene ontology; KEGG, Kyoto Encyclopedia of Genes and Genomes.

Machine learning was utilized to identify diagnostic marker genes for ALD. (A) The adjusted parameter selection in the LASSO model was cross-validated 10 times, with each curve representing a gene. (B) LASSO coefficient analysis. (C) The SVM-RFE algorithm's feature selection accuracy and error reach a peak of 100 % at eight genes, with the lowest cross-validation error being 0 %. (D) The relationship between random forest tree number and error rate was also evident. (E) The ALD group's error was represented by a red line, the control group's by a green line, and the total sample error by a black line in random forest analysis. (F) Eighteen DG-CRGs were performed with random forest analysis, which three had an average Gini reduction greater than 2. (G) Venn diagram showing overlapping genes obtained using the three machine learning algorithms (LASSO, random forest, and SVM-RFE). ALD, alcohol-related liver disease; LASSO, least absolute shrinkage and selection operator; SVM-RFE, support vector machine‐recursive feature elimination; DE-CRGs, differential expression of cuproptosis-related genes.

Validation of marker genes expression. (A) Nomogram of marker genes. (B) Calibration curve. (C) The predictive efficiency of the nomogram model was illustrated by DCA. (D) The diagnostic ability of the nomogram model was further demonstrated by the clinical impact curve. (E) The ROC of the combination of the three key genes for the diagnosis of ALD was 0.704 (95 % CI 0.504–0.892). (F) ROC results showed that three marker genes separately diagnosed ALD. The AUC values of DPYD, SLC31A1, and DBT were 0.847, 0.913, and 0.832, respectively. (G) Boxplots of GSE142530 revealed that the three DE-CRGs between the ALD and control samples were significantly different. (H) The three-gene model, based on a threefold cross-validation process in GSE142530, yielded ROC results with an AUC value of 0.0.670. (I) The AUC values of DPYD, SLC31A1, and DBT were 0.825, 0.721, and 0.729, respectively, in GSE142530. (J) The box diagram shows that the three genes differed significantly in different groups of GSE155907 samples. (K) The three-gene model, based on threefold cross-validation in GSE155907, yielded ROC results of 0.800. (L) The AUC values of DPYD, SLC31A1, and DBT for the diagnosis of ALD in GSE155907 were 0.850, 1.0, and 0.750, respectively. DCA, decision curve analysis; ROC, receiver operating characteristics; ALD, alcohol-related liver disease; CI, confidence interval; AUC, area under curve; DE-CRGs, differential expression of cuproptosis-related genes.

An enrichment analysis of the three marker genes. GSEA analysis of the signature based on (A) ADBT, (B) DPYD, and (C) SLC31A1. KEGG pathway enrichment for (D) DBT, (E) DPYD, and (F) SLC31A1 was performed by GSVA, with the top 50 shown according to the enrichment score. The boxplots demonstrated the disparities in immune cells (G) and function (H) between ALD and non-ALD samples. (I) The correlations of immune cells and three genes were also shown (red: positive correlation, green: negative correlation). p values are indicated as *p < 0.05; **p < 0.01; ***p < 0.001. GSEA, gene set enrichment analysis; GSVA, gene set variation analysis; ALD, alcohol-related liver disease.

Correlation between CRG clusters and the immune microenvironment. (A) The three CRG hub genes were clustered into CRG clusters A and B under unsupervised consensus clustering (k = 2). (B) The consistent distribution of various k (ranging from 2 to 9) was described using the experience CDF graph. (C) Relative increase in cluster stability by delta area fraction. (D) The boxplots displayed the expression level of three CRG regulator genes between different CRG clusters. (E) The heatmap illustrated the transcriptional profile of CRG regulator genes in each cluster. (F) PCA further revealed a significant difference between CRG clusters A and B. (G) Different cells in immune microenvironment in both groups were presented in the boxplots. (H) Heatmap showed the correlation between CRG regulator genes and the different immune cells. (I–K) The correlations between three key genes and different immune cells. *p < 0.05, **p < 0.01, ***p < 0.001. CRGs, cuproptosis-related genes; CDF, cumulative distribution function; PCA, principal Component Analysis.

Generation of the CRGs signature and immune microenvironment. (A) 92 DEGs between CRG clusters A and B. (B) Consensus clustering matrix of 92 DEGs for k = 2. (C) The consensus CDF curve based on various k (k = 2–9). (D) Relative increase in cluster stability by delta area fraction. (E) The heatmap showed the distinct expression of CRGs in each gene cluster. (F) The boxplots displayed the expression levels of the three hub CRGs in their respective clusters. (G) Different immune cells in the two CRG clusters. The CRG score was calculated between the A and B groups in distinct CRG clusters (H) and gene clusters (I). (J) A Sankey diagram illustrated the correlations among the CRG clusters, gene clusters, and CRG scores. *p < 0.05, **p < 0.01, ***p < 0.001. DEGs, differential expression genes; CRG, cuproptosis-related gene; CDF, cumulative distribution function.

mRNA-drugs and ceRNA network. (A) The purple rectangle nodes symbolize the drugs, while the mRNA-drug interaction network is represented by orange dots. (A) The ceRNA network, based on marker genes, is depicted with blue dots for miRNA and purple dots for lncRNA.

Expression of CRGs in a mouse ALD model and cell alcohol intervention model. The NIAAA mouse ALD model was generated in C57BL/6J mice. Pair-fed mice were used as controls. Serum and liver tissues were collected on day 16 for further analysis. (A) HE and Oil Red O staining. (B) Serum ALT and AST levels. (C) The relative mRNA expression of the three hub genes was verified by qRT‒PCR. (D) The protein expression of the three hub genes was confirmed by Western blotting. (E) The relative protein expression of the three hub genes. (F) Nile red staining. (G) The mRNA levels of the three hub genes in cells with/without ethanol treatment. (H) The protein levels of the three hub genes in cells with/without ethanol treatment. N = 6–8, *p < 0.05, **p < 0.01, ***p < 0.001. CRGs, cuproptosis-related genes; ALD, alcohol-related liver disease; NIAAA, National Institute on Alcohol Abuse and Alcoholism; HE, Hematein & Eosin; ALT, alanine aminotransferase; AST, aspartate aminotransferase; qRT‒PCR, quantitative reverse transcription polymerase chain reaction.

## Section: Results › Identification of CRGs involved in ALD

A total of 6234 DEGs (p < 0.05) were identified using the “limma” package from two batch-normalized datasets comprising 28 ALD samples and 7 control samples (GSE28619 and GSE103580). Heatmap of DEGs was presented in Fig. 2A. The volcano plot of the DEGs was displayed in Fig. S1, GO analyses of the 6234 DEGs were shown in Fig. S2, and KEGG analyses were shown in Fig. S3.

In addition, 6234 DEGs overlapped with 38 CRGs, revealing 18 DE-CRGs (DLAT, ISCA2, GLRX5, NDUFV2, ACO2, NDUFA1, DPYD, DBT, LIPT1, NFE2L2, GLS, PDHB, PPAT, PLAT, CDKN2A, SLC31A1, NDUFA8, and LIPA) with significant differences between the ALD and control groups, as shown in Fig. 2B. The chromosomal locations of the 18 DE-CRGs were shown in a circular diagram (Fig. 2C). Twelve DE-CRGs (ISCA2, NDUFV2, ACO2, NDUFA1, LIPT1, GLS, PDHB, PPAT, PLAT, CDKN2A, NDUFA8 and LIPA) were upregulated in ALD, and six (DLAT, GLRX5, DPYD, DBT, NFE2L2, and SLC31A1) were downregulated in ALD (Fig. 2D and E). A PPI analysis using STRING was performed to explore potential crosstalk among these 18 DE-CRGs, as shown in Fig. 2F. The correlation among the 18 DE-CRGs was shown in Fig. 2G. We found that DE-CRGs were related to aerobic respiration, purine ribonucleotide biosynthetic, oxidoreductase, and iron-sulfur cluster binding and other pathways with Gene ontology (GO) enrichment analysis including cross gene enrichment in Biological Process (BP), Cellular Component (CC), and Molecular Function (MF). The results were displayed in Fig. 1H. Additionally, lipoic acid (LA) metabolism, citrate cycle, etc., in KEGG pathway analysis was depicted in Fig. 2I.

Identification of cuproptosis-related genes in ALD. (A) Heatmap of DEGs was presented. (B) Venn diagrams showing the intersection between DEGs and CRGs. (C) Eighteen DE-CRGs were located on 23 chromosomes, with the boxplots illustrating the differential expression between ALD and control samples (D). (E) Heatmap showed the expression patterns of these 18 DE-CRGs. (F) Gene relationship network diagram of the 18 DE-CRGs. (G) Correlation analysis of the 18 DE-CRGs was conducted, with orange and blue representing positive and negative correlations, respectively. (H) GO analysis of DEGs associated with cuproptosis. (I) KEGG analysis of DEGs associated with cuproptosis. P values are displayed as follows: *p < 0.05; **p < 0.01; ***p < 0.001. ALD, alcohol-related liver disease; CRGs,cuproptosis-related genes; DEGs: Differentially expressed genes. DE-CRGs: differentially expressed cuproptosis-related genes; GO,gene ontology; KEGG, Kyoto Encyclopedia of Genes and Genomes.

## Section: Results › Identification of diagnostic marker genes for ALD

Given the individual complexity and heterogeneity of patients with ALD and healthy controls, candidate CRGs were identified from 18 DE-CRGs using LASSO regression and two validated machine learning models (SVM-RFE and RF), which helped predict the diagnosis of ALD. Eight DE-CRGs were identified by the LASSO logistic regression algorithm (Fig. 3A and B). The number of SVM features was 8 (Fig. 3C). The minimum error of the classifier was 0.0, and the maximum accuracy was 1.0 (Fig. 3D). Eighteen DG-CRGs were performed with RF analysis, of which three had an average Gini reduction greater than 2 (Fig. 3E and F). A Venn diagram was then used to intersect the essential genes in the LASSO, SVM-RFE, and RF analyses. Finally, three key genes (DPYD, SLC31A1, and DBT) were identified for further analysis (Fig. 3G).

Machine learning was utilized to identify diagnostic marker genes for ALD. (A) The adjusted parameter selection in the LASSO model was cross-validated 10 times, with each curve representing a gene. (B) LASSO coefficient analysis. (C) The SVM-RFE algorithm's feature selection accuracy and error reach a peak of 100 % at eight genes, with the lowest cross-validation error being 0 %. (D) The relationship between random forest tree number and error rate was also evident. (E) The ALD group's error was represented by a red line, the control group's by a green line, and the total sample error by a black line in random forest analysis. (F) Eighteen DG-CRGs were performed with random forest analysis, which three had an average Gini reduction greater than 2. (G) Venn diagram showing overlapping genes obtained using the three machine learning algorithms (LASSO, random forest, and SVM-RFE). ALD, alcohol-related liver disease; LASSO, least absolute shrinkage and selection operator; SVM-RFE, support vector machine‐recursive feature elimination; DE-CRGs, differential expression of cuproptosis-related genes.

## Section: Results › Evaluation of the diagnostic performance of ALD diagnostic marker genes

A nomogram model of patients with ALD was constructed using the “rms” package to evaluate the predictive efficiency of the three central genes, DPYD, SLC31A1, and DBT (Fig. 4A). The nomogram model's numerical value for each biomarker was used to forecast the ALD risk, with a correction curve indicating an obvious connection between the predicted and actual probability (Fig. 4B). The DCA revealed that the net benefit from this model was significantly higher than 0, implying its remarkable accuracy and ability to provide physicians with a basis for decision-making (Fig. 4C). The clinical impact curve showed that this nomogram model has a very high diagnostic capability (Fig. 4D). The ROC curve analysis showed that the three marker gene features combined demonstrated high performance in diagnosing ALD (AUC = 0.704, Fig. 4E). ROC curves were generated for each of the three labeled genes, and the predictive value of each was assessed. The individual predictive ROC results for these three genes all exceeded 0.83 (Fig. 4F), and their expression was decreased in both datasets (Fig. 4G and J). The ROC curve for the combination of the three genes in the GSE142530 and GSE155907 sets were 0.670 and 0.800, respectively (Fig. 4H and K), and there were the ROC curve for the predicted performance of the three genes separately (Fig. 4I and L). These indications suggest that the model based on these three marker genes may have strong prediction efficacy for ALD.

Validation of marker genes expression. (A) Nomogram of marker genes. (B) Calibration curve. (C) The predictive efficiency of the nomogram model was illustrated by DCA. (D) The diagnostic ability of the nomogram model was further demonstrated by the clinical impact curve. (E) The ROC of the combination of the three key genes for the diagnosis of ALD was 0.704 (95 % CI 0.504–0.892). (F) ROC results showed that three marker genes separately diagnosed ALD. The AUC values of DPYD, SLC31A1, and DBT were 0.847, 0.913, and 0.832, respectively. (G) Boxplots of GSE142530 revealed that the three DE-CRGs between the ALD and control samples were significantly different. (H) The three-gene model, based on a threefold cross-validation process in GSE142530, yielded ROC results with an AUC value of 0.0.670. (I) The AUC values of DPYD, SLC31A1, and DBT were 0.825, 0.721, and 0.729, respectively, in GSE142530. (J) The box diagram shows that the three genes differed significantly in different groups of GSE155907 samples. (K) The three-gene model, based on threefold cross-validation in GSE155907, yielded ROC results of 0.800. (L) The AUC values of DPYD, SLC31A1, and DBT for the diagnosis of ALD in GSE155907 were 0.850, 1.0, and 0.750, respectively. DCA, decision curve analysis; ROC, receiver operating characteristics; ALD, alcohol-related liver disease; CI, confidence interval; AUC, area under curve; DE-CRGs, differential expression of cuproptosis-related genes.

## Section: Results › GSEA, GSVA, and ssGSEA analysis

We used ssGSEA to identify the major signaling pathways of the three genes in the above model. GSEA of the KEGG pathways demonstrated that these three genes are implicated in glycine, serine, threonine, and retinol metabolism (Fig. 5A–C). DPYD and SLC31A1 are involved in cytochrome p450 metabolism (Fig. 5B and C). DBT and SLC31A1 are related to hormone biosynthesis (Fig. 5A and C). DPYD is involved in tryptophan metabolism, and the influence of cytochrome p450 on genomics (Fig. 5B). Figs. S4–S6 shows the GSEA outcome for the GO enrichment analysis.

GSVA revealed distinct activity pathways between low- and high-expression subtypes determined according to the levels of the three hub genes. Our analysis revealed that DBT, DPYD, and SLC31A1 overexpression are involved in extracellular matrix-receptor interactions (Fig. 5D–F). Overexpression of DBT and SLC31A1 is involved in Leishmania infection, glycan biosynthesis, and viral myocarditis. In the high DPYD expression group, galactose metabolism globo-series base biosynthesis pathways were active (Fig. 5E). Low DBT, DPYD, and SLC31A1 expression levels were linked to lysine degradation, tryptophan metabolism, retinol metabolism, threonine metabolism, steroid hormone biosynthesis, and other pathways (Fig. 5D–F). The GSVA result for the GO enrichment analysis is shown in Figs. S7–S9.

In order to verify whether cuproptosis could promote ALD progression by mediating immune infiltration, we conducted ssGSEA analysis. ssGSEA analysis showed that significantly decreased B cells, CD8 (+) T cells, NK cells, T-helper cells, and Th1 cells were observed in ALD patients versus normal liver tissue (Fig. 5G). Regarding immune function, the APC coinhibition, cytolytic activity, and type II IFN response scores were lower in the ALD group than in the control group (Fig. 5H). Fig. 5F shows that DPYD was significantly connected with the type II IFN response, Th1 cells, and NK cells; DBT was significantly associated with MHC class 1, CCR, and aDCs. Whereas, SLC31A1 was significantly correlated with B cells, APC coinhibition, and CCR (Fig. 5I).

An enrichment analysis of the three marker genes. GSEA analysis of the signature based on (A) ADBT, (B) DPYD, and (C) SLC31A1. KEGG pathway enrichment for (D) DBT, (E) DPYD, and (F) SLC31A1 was performed by GSVA, with the top 50 shown according to the enrichment score. The boxplots demonstrated the disparities in immune cells (G) and function (H) between ALD and non-ALD samples. (I) The correlations of immune cells and three genes were also shown (red: positive correlation, green: negative correlation). p values are indicated as *p < 0.05; **p < 0.01; ***p < 0.001. GSEA, gene set enrichment analysis; GSVA, gene set variation analysis; ALD, alcohol-related liver disease.

## Section: Results › The correlation between CRG clusters and the immune microenvironment

The “Consensus Cluster Plus” package in R classified different CRG clusters according to three hub gene regulators. Taking 2 as the optimal k value, 28 ALD samples were divided into CRG clusters A and B (Fig. 6A–C). DBT, DPYD, and SLC31A1 expression levels were higher in CRG cluster A than in CRG cluster B (Fig. 6D). Heatmaps were used to illustrate the different gene expression profiles in the two CRG clusters (Fig. 6E). PCA was then used to verify the correction of the CRG clustering classification (Fig. 6F). A more in-depth analysis of immune cell infiltration was performed considering the association between ALD and the immune microenvironment. As shown in Figs. 6G and 10 types of immune cells showed significant differences between CRG clusters A and B, implying differences in immune responses between the two clusters. The association between immune cell infiltration and the expression profiles of three CRG regulators was confirmed by ssGSEA-based heatmaps (Fig. 6H). In addition, we investigated the relationship between immune cell infiltration and three CRGs by ssGSEA. As shown in Fig. 6I, DPYD was negatively correlated with activated dendritic cells, CD56 bright natural killer cells, CD56dim natural killer cells, and monocytes. SLC31A1 was negatively correlated with immature dendritic cells and positively correlated with monocytes (Fig. 6J). A negative correlation was observed between DBT and activated CD4 T cells, dendritic cells, gamma delta T cells, immature dendrites, MDSCs, macrophages, mast cells, plasmacytoid dendrites, regulatory T cells, T follicular helper cells, and type 1 helper cells (Fig. 6K).

Correlation between CRG clusters and the immune microenvironment. (A) The three CRG hub genes were clustered into CRG clusters A and B under unsupervised consensus clustering (k = 2). (B) The consistent distribution of various k (ranging from 2 to 9) was described using the experience CDF graph. (C) Relative increase in cluster stability by delta area fraction. (D) The boxplots displayed the expression level of three CRG regulator genes between different CRG clusters. (E) The heatmap illustrated the transcriptional profile of CRG regulator genes in each cluster. (F) PCA further revealed a significant difference between CRG clusters A and B. (G) Different cells in immune microenvironment in both groups were presented in the boxplots. (H) Heatmap showed the correlation between CRG regulator genes and the different immune cells. (I–K) The correlations between three key genes and different immune cells. *p < 0.05, **p < 0.01, ***p < 0.001. CRGs, cuproptosis-related genes; CDF, cumulative distribution function; PCA, principal Component Analysis.

## Section: Results › The correlation between the CRG cluster, gene cluster, and CRG score

Ninety-two DEGs overlapping between gene clusters A and B were shown in Fig. 7A. The optimal k value of the gene cluster was set to 2 to ensure compatibility with the number of gene clusters (Fig. 7B–D). Heatmaps were used to show the different expression profiles of CRGs between the two gene clusters (Fig. 7E). Compared with those in gene cluster A, the expression levels of DBT, DPYD, and SLC31A1 were increased in gene cluster B (Fig. 7F). We then identified six types of immune cells in gene cluster B was significantly higher in gene cluster A (Fig. 7G), indicating a significant feature of immune microenvironment infiltration. Box charts were used to observe the differences in CRG scores between CRG clusters and gene clusters. As shown in Fig. 7H, CRG cluster A had a lower CRG score than CRG cluster B. The CRG score in gene cluster A was also lower than that in gene cluster B (Fig. 7I). Therefore, the CRG scores of different CRG clusters and gene clusters differed significantly. The software package “ggalluvial” R was used to construct a Sankey chart to better display the correspondence between CRG scores, CRG clusters, and gene clusters (Fig. 7J).

Generation of the CRGs signature and immune microenvironment. (A) 92 DEGs between CRG clusters A and B. (B) Consensus clustering matrix of 92 DEGs for k = 2. (C) The consensus CDF curve based on various k (k = 2–9). (D) Relative increase in cluster stability by delta area fraction. (E) The heatmap showed the distinct expression of CRGs in each gene cluster. (F) The boxplots displayed the expression levels of the three hub CRGs in their respective clusters. (G) Different immune cells in the two CRG clusters. The CRG score was calculated between the A and B groups in distinct CRG clusters (H) and gene clusters (I). (J) A Sankey diagram illustrated the correlations among the CRG clusters, gene clusters, and CRG scores. *p < 0.05, **p < 0.01, ***p < 0.001. DEGs, differential expression genes; CRG, cuproptosis-related gene; CDF, cumulative distribution function.

## Section: Results › Identification of drug candidates and ceRNA networks based on marker genes

To further explore drug therapy options for ALD, we analyzed the interactions between key genes and drugs by DGIdb. Cytoscape analysis revealed the interaction between genetic markers and drugs (Fig. 8A). A ceRNA network was constructed with the three essential genes using the TargetScan, miRanda, and miRDB databases, revealing 170 miRNAs and 138 lncRNAs (Fig. 8B).

mRNA-drugs and ceRNA network. (A) The purple rectangle nodes symbolize the drugs, while the mRNA-drug interaction network is represented by orange dots. (A) The ceRNA network, based on marker genes, is depicted with blue dots for miRNA and purple dots for lncRNA.

## Section: Results › Expression of CRGs in a mouse ALD model and cell alcohol intervention model

H&E and Oil Red O staining suggested hepatic steatosis in the ALD group (Fig. 9A). AST and ALT levels were significantly higher in the ALD group than in the control group (Fig. 9B). The above results indicate that we successfully established the ALD model. qRT‒PCR measurement of mRNA levels indicated that the expression levels of the three key genes were reduced in the ALD group compared with those in the control group (Fig. 9C). Meanwhile, the expression of the protein amounts of the three genes in ADL and normal liver tissues was significantly different through Western blot (Fig. 9D–E). Nile red staining demonstrated substantial lipid deposition in the cell of the Ethanol group, characterized by the formation of much more fat droplets (Fig. 9F). Taken together, these results collectively indicate the successful establishment of the Cells alcohol intervention model. The mRNA levels of three CRG hub genes were also assessed using qRT-PCR. The results indicated that the expression of DPYD, DBT, and DPYD was significantly down-regulated in the ethanol group compared with the NS group (Fig. 9G). Immunoblot analysis also confirmed a similar decreased expression in the ethanol group (Fig. 9H). These results confirm that these three signature CRGs may play an important regulatory role in ALD development.

Expression of CRGs in a mouse ALD model and cell alcohol intervention model. The NIAAA mouse ALD model was generated in C57BL/6J mice. Pair-fed mice were used as controls. Serum and liver tissues were collected on day 16 for further analysis. (A) HE and Oil Red O staining. (B) Serum ALT and AST levels. (C) The relative mRNA expression of the three hub genes was verified by qRT‒PCR. (D) The protein expression of the three hub genes was confirmed by Western blotting. (E) The relative protein expression of the three hub genes. (F) Nile red staining. (G) The mRNA levels of the three hub genes in cells with/without ethanol treatment. (H) The protein levels of the three hub genes in cells with/without ethanol treatment. N = 6–8, *p < 0.05, **p < 0.01, ***p < 0.001. CRGs, cuproptosis-related genes; ALD, alcohol-related liver disease; NIAAA, National Institute on Alcohol Abuse and Alcoholism; HE, Hematein & Eosin; ALT, alanine aminotransferase; AST, aspartate aminotransferase; qRT‒PCR, quantitative reverse transcription polymerase chain reaction.

## Section: Discussion

Alcohol consumption, particularly when prolonged and intense, can cause alcoholic fatty liver disease, cirrhosis, and even liver cancer. ALD is a major burden worldwide [[38], [39], [40]]. Although many studies have been conducted on ALD, many related mechanisms are not completely clear, and treatment methods are limited. Exploring effective diagnostic biomarkers for ADL and related therapeutic drugs is of substantial clinical value. Cuprotosis is a newly discovered mechanism of copper-dependent cell death that plays an important role in many diseases [21,[41], [42], [43], [44]]. Menkes disease and Wilson disease are two typical genetic diseases caused by mutations in the copper transport ATPase gene [45,46]. Imbalances in the distribution and homeostasis of copper within cells have been linked to neurodegenerative diseases, mitochondrial myopathy, and some types of cancer [47]. In addition, abnormal copper metabolism may also affect the cholesterol biosynthesis pathway, as observed in fish models, where copper exposure leads to significant downregulation of genes in the cholesterol biosynthesis pathway [48]. However, the specific role of cuproptosis in the pathogenesis and regulation of ALD remains unclear. Here, we investigated the possible role of CRGs in ALD, identifying potential key genes and exploring possible target drugs.

We downloaded ALD and control liver data from the GEO database for statistical analysis to identify differentially expressed CRGs and obtained 18 DEGs associated with cuproptosis. These results suggested that CRGs may influence ALD progression. Our correlation analysis showed that the identified DE-CRGs were closely correlated with each other; however, some had no obvious correlation at the protein level. Thus, there was heterogeneity in the interaction of CRGs at the gene and protein levels.

The important role of CRGs in LA metabolism, 2-oxocarboxylic acid metabolism, and ROS production was revealed by GO and KEGG enrichment analyses. LA is an important cofactor of mitochondrial dehydrogenase [49], which is necessary for cell growth, metabolic fuel production, and antioxidant defenses [50]. LA binds well to copper and is also an endogenous membrane permeability metabolite that helps improve copper overload in human diseases [51,52]. LA reduces the toxic effects of copper elevation by altering the cellular redox environment [51]. Copper-dependent cell death occurs through the direct binding of copper to the fatty component of the tricarboxylic acid (TCA) cycle. The accumulation of fatty acylated proteins, resulting in the loss of iron-sulfur (Fe-S) tuftin and the production of protein-toxic stress, culminates in cell death [41]. GO MF analysis showed that the 18 DE-CRGs were significantly correlated with iron-sulfur cluster binding. Previous studies have demonstrated that Fe-S protein is significantly associated with copper deformities [41]. The biological production of cellular iron thionein (Fe/S) is the basic and minimal function of mitochondria [53]. Destabilization and an overall reduction in Fe-S cluster proteins cause proteotoxic stress and mitochondrial dysfunction, and the Fe-S cluster protein FDX1 and lipoylation are key regulators of cuproptosis [41].

LASSO, RF, and SVM-REE analyses of the 18 DE-CRGs revealed three key genes (DPYD, SLC31A1, and DBT) that can effectively predict ALD, with an AUC value of 0.704. Two external datasets were used to verify the validity of the three-gene model, with AUCs of 0.670 and 0.800. The AUC values for the three key genes in both validation datasets exceeded 0.670. The nomogram model, calibration curves, and DCA showed that this model had a good prediction ability and clinical application value. Thus, a predictive model combining these three key genes could serve as a reliable and robust biomarker for the effective prediction of ALD.

DPYD encodes dihydropyrimidine dehydrogenase (DPD), a key enzyme involved in fluoropyrimidine metabolism [54]. DPD is widely distributed in various normal tissues, especially in the liver and peripheral blood mononuclear cells [55]. DPD is the primary and rate-limiting enzyme in the uracil and thymine catabolic pathways [56]. Regulating pyrimidine catabolism protects against the occurrence and development of liver fibrosis [57]. SLC31A1 is a member of the copper transporter family with an extracellular copper ion binding domain and is considered the main transporter of copper ions into the cell [11]. SLC31A1 encodes the high-affinity copper uptake protein CTR1, which is essential for mammalian development and copper homeostasis [58]. Copper overload and deposition are likely related to SLC31A1 [59]. SLC31A1 is abnormally expressed in various cancers and is associated with cancer progression [60]. As a key gene associated with copper metabolism disorder, SLC31A1 is of great value in the prognostic prediction of pancreatic cancer and colorectal cancer [61,62]. The GSEA results indicated that SLC31A1 was involved in extracellular matrix-receptor interactions and O-type glycan biosynthesis. GSVA further showed that high SLC31A1 expression participated in extracellular matrix-receptor interaction and O-type glycan biosynthesis, and low SLC31A1 expression participated in retinol metabolism and steroid hormone biosynthesis. DBT is a subunit of branched-chain alpha-ketoate dehydrogenase and is essential for the second step in branched-chain amino acid catabolism [63,64]. DBT instability can lead to an accumulation of deleterious derivatives [65]. This imbalance in branched-chain amino acid metabolism has been linked to the emergence of ALD [66]. DBT can affect MAPK signaling [63], and regulating MAPK pathways can improve liver disease in mice with ALD [67]. Long-term drinking can cause lipid metabolism disorders and cause liver lesions [66]. Morrell et al. [68] proposed that lipid synthesis was associated with fatty liver disease and copper deficiency. The lipoacyl-binding domain of DBT interacts with annexin A2, activating Hippo signaling, inhibiting tumor progression, and correcting lipid metabolism disorders [69]. The GSEA results indicated that SLC31A1 was involved in amino acid metabolism and extracellular matrix-receptor interactions. ECM proteins affect ROS production [70]. ROS plays an important role in the clinical and pathological profile of ALD by affecting intracellular signaling pathways and disrupting transcriptional control [71].

Cuprotosis has been shown to regulate inflammation [21], and our results indicate that the three CRGs were significantly associated with immune inflammatory cells. Immune cells and inflammation play an important role in ALD; various inflammatory cells play a promoting role, especially interleukin-8 and neutrophils [72]. This study demonstrated a significant distinction between ALD patients and the control group in terms of B cells, CD8 (+) T cells, macrophages, NK cells, T helper cells, Th1 cells, APC coinhibition, CCR, cytolytic activity, accessory inflammatory response, and type II IFN responses. Oxidative stress and inflammation play an important role in ALD [73]. This study showed that DPYD was significantly associated with the type II IFN response, Th1 cells, and NK cells, DBT was significantly associated with MHC class 1, CCR, and aDCs, and SLC31A1 was significantly associated with B cells, APC coinhibition, and CCR. SLC31A1 and DBT were significantly associated with immune cells and immune function [74]. Previous studies have shown that SLC31A1 is significantly associated with immune cells [60,75]. DPYD is associated with immune cells and plays a role in the immune microenvironment [76]. Activated B-cell pathways and macrophages play an important role in ALD [[77], [78], [79]]. Enhanced CD8 (+) T cells mediate alcoholic liver injury [80]. MHC class 1 and NK cells induce hepatocyte apoptosis in ALD [81,82]. It is of substantial clinical significance to explore therapeutic methods for ALD. We conducted gene-targeting drug analysis based on the three key genes identified. Several drugs targeting the DPYD and SLC31A1 genes were antitumor chemotherapy drugs acting on cell biosynthesis. One of these drugs is leucovorin, a derivative of folate, which is a precursor for 5,10-methylene tetrahydrofolate [[83], [84], [85], [86]]. Leucovorin is the coenzyme of a carbon group transferase and is involved in many important reactions, such as purine and pyrimidine synthesis [83]. Folic acid is essential for the normal functioning of organisms. In cells, folic acid is a donor and acceptor of carbon metabolism and is involved in methylation, an important biological process [87]. Folic acid is also involved in the synthesis of nucleic acids, amino acids, and pantothenic acid [88]. Folic acid has been shown to reduce alcohol-induced liver damage, and folic acid supplementation may be useful for the prevention and treatment of ALD [89]. Therefore, leucovorin has the potential to be an effective preventive measure for ALD. Since lncRNAs, miRNAs, and mRNAs interact and affect cellular biosynthesis [[90], [91], [92]], we constructed an mRNA-miRNA-lncRNA regulatory network for ALD, revealing that lncRNAs could regulate the three key genes (DPYD, DBT, and SLC31A1). Therefore, gene-targeted drug analysis provides a new way to search for possible drugs to prevent and treat ALD further, and ceRNA network analysis provides a new avenue for further exploring ALD pathogenesis. These findings require further validation in cell and animal studies.

Based on these findings, therapeutic strategies, such as small interfering RNA (siRNA) or gene editing techniques, are designed and implemented to target genes involved in copper death, with a view to developing new therapies.

Our study has some limitations. First, we performed genetic analysis on data downloaded from the GEO database, and the datasets may have certain biases. Second, the total number of cases was relatively small. Furthermore, we have not yet performed cellular or animal validation of the gene-targeting drugs we discovered.

## Section: Conclusions

We identified three important genes, and by combining these three genes, we can accurately diagnose patients with ALD. Then, we explored the relationship between these genes and invasive immune cells and analyzed the significant heterogeneity in immune responses between ALD patients and control liver samples. Our research unveils the role of copper in ALD, providing a new theoretical foundation for the potential pathogenesis of ALD and therapeutic options.

## Section: Ethics approval and consent to participate

All animal experiments were approved by the Animal Care and Use Committee of the First Affiliated Hosputal of Guangxi Medical University (NO.2023-S606-01).

## Section: Consent for publication

Not applicable.

## Section: Data availability

The datasets in this study were enrolled from the GEO database (https://www.ncbi.nlm.nih.gov/geo/), with the following data accessions enrolled: GSE28619, GSE103580, GSE142530 and GSE155907. This data can be found here: https://www.jianguoyun.com/p/DT-bA08QjrmsDBjJ-bIFIAA.

## Section: Funding

This work was supported in part by the National Key Research and Development Program (2022YFE0131600); Guangxi Science and Technology Base and Talent Project (GuikeAA21220002); The 111 Project (D17011); Advanced Innovation Teams and Xinghu Scholars Program of Guangxi Medical University.

## Section: CRediT authorship contribution statement

Jiangfa Li: Writing – review & editing, Writing – original draft, Validation, Methodology, Formal analysis, Data curation. Yong Wang: Writing – original draft, Methodology, Formal analysis, Data curation. Zhan Wu: Methodology, Investigation. Mingbei Zhong: Methodology, Investigation. Gangping Feng: Methodology, Investigation, Formal analysis. Zhipeng Liu: Validation, Methodology. Yonglian Zeng: Supervision, Software, Data curation. Zaiwa Wei: Methodology, Formal analysis. Sebastian Mueller: Methodology, Investigation, Data curation. Songqing He: Visualization, Validation, Methodology, Investigation, Funding acquisition, Conceptualization. Guoqing Ouyang: Supervision, Software, Resources, Methodology, Investigation, Formal analysis, Data curation. Guandou Yuan: Writing – review & editing, Visualization, Supervision, Methodology, Investigation, Funding acquisition, Formal analysis, Data curation, Conceptualization.

## Section: Declaration of competing interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

## Section: Acknowledgements

We are grateful to the researchers who provided the datasets (GSE28619, GSE103580, GSE142530 and GSE155907).

## Section: Contributor Information

Songqing He, Email: dr_hesongqing@163.com.

Guoqing Ouyang, Email: Ouyangguoqing@stu.gxmu.edu.cn.

Guandou Yuan, Email: dr_yuangd@gxmu.edu.cn.

## Section: Supplementary data

The following are the Supplementary data to this article.

## Section: Associated Data › Data Availability Statement

The datasets in this study were enrolled from the GEO database (https://www.ncbi.nlm.nih.gov/geo/), with the following data accessions enrolled: GSE28619, GSE103580, GSE142530 and GSE155907. This data can be found here: https://www.jianguoyun.com/p/DT-bA08QjrmsDBjJ-bIFIAA.


---

# Identification of Potential Tryptase Inhibitors from FDA-Approved Drugs Using Machine Learning, Molecular Docking, and Experimental Validation

- **Authors:** Muhammad Yasir, Jinyoung Park, Eun-Taek Han, Won Sun Park, Jin-Hee Han, Wanjoo Chun
- **Issuer:** ACS omega
- **Type:** Scientific article
- **Published:** 2024-09-04
- **Language:** en
- **DOI:** 10.1021/acsomega.4c04886
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39310179/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

This study explores the innovative use of machine learning (ML) to identify novel tryptase inhibitors from a library of FDA-approved drugs, with subsequent confirmation via molecular docking and experimental validation. Tryptase, a significant mediator in inflammatory and allergic responses, presents a therapeutic target for various inflammatory diseases. However, the development of effective tryptase inhibitors has been challenging due to the enzyme’s complex activation and regulation mechanisms. Utilizing a machine learning model, we screened an extensive FDA-approved drug library to identify potential tryptase inhibitors. The predicted compounds were then subjected to molecular docking to assess their binding affinity and conformation within the tryptase active site. Experimental validation was performed using RBL-2H3 cells, a rat basophilic leukemia cell line, where the efficacy of these compounds was evaluated based on their ability to inhibit tryptase activity and suppress β-hexosaminidase activity and histamine release. Our results demonstrated that several FDA-approved drugs, including landiolol, laninamivir, and cidofovir, significantly inhibited tryptase activity. Their efficacy was comparable to that of the FDA-approved mast cell stabilizer nedocromil and the investigational agent APC-366. These findings not only underscore the potential of ML in accelerating drug repurposing but also highlight the feasibility of this approach in identifying effective tryptase inhibitors. This research contributes to the field of drug discovery, offering a novel pathway to expedite the development of therapeutics for tryptase-related pathologies.

## Section: Introduction

Mast cells are central to the body’s immune response to external antigens and are predominantly found in vascularized tissues such as the mucosal and epithelial layers of the gastrointestinal tract, skin, and respiratory tract.1−3 These cells, when activated by various stimuli, release a range of inflammatory mediators from their cytoplasmic granules.4 This release can lead to the development of various inflammatory disorders, including asthma, atopic dermatitis, and severe anaphylactic shock.5−7 Among the diverse molecules stored in these granules are histamine, heparin, cytokines, and a spectrum of proteases, with tryptase being the most abundant protease present in human mast cells.8

Tryptase, a member of the trypsin family of proteases, is a tetrameric enzyme. It is composed of four catalytic subunits that together form a distinctive ring-like structure, with the active sites facing an oval-shaped central pore.9 This unique structural arrangement is crucial for its biological function. The role of tryptase in inflammatory and allergic responses has been extensively documented, highlighting its significance as a potential therapeutic target for a variety of inflammatory diseases.10−12 Its involvement in biological processes such as fibrosis, angiogenesis, and immune response modulation further emphasizes its clinical importance.5,13 Despite the critical role of tryptase in these processes, the development of effective inhibitors has been a complex challenge, mainly due to the intricate mechanisms governing its activation and regulation.13 Addressing this challenge requires a nuanced understanding of tryptase’s structure and function, as well as innovative approaches to inhibit its activity.

Given the complexity and resource-intensive nature of developing new drugs, drug repurposing, also known as drug repositioning, emerges as a promising strategy.14,15 Drug repurposing involves identifying new therapeutic applications for already approved drugs beyond their original intended uses.16 This approach can significantly accelerate the drug development process, augmenting the value of existing drugs and potentially offering new treatment avenues for diseases that currently lack effective therapies.17,18 Importantly, in the context of tryptase inhibitors, drug repurposing can provide new treatments for inflammatory diseases, aligning with the need for efficient and rapid therapeutic development. This approach holds significant potential in addressing unmet medical needs related to tryptase-related conditions.

Computational study, or computer-aided drug design (CADD), is now a crucial component in drug discovery and development.19−21 CADD utilizes computational methods and software for rapid and efficient screening of large compound libraries, offering a more time- and cost-effective alternative to traditional experimental approaches.22,23 This approach dramatically reduces the need for synthesizing and experimentally testing numerous compounds, allowing for the virtual screening of thousands of compounds.

Machine learning (ML), a subset of artificial intelligence, is another transformative force in drug development.24 It enables computers to learn from data, predict outcomes, and make decisions autonomously.25 ML excels in analyzing vast and complex data sets, identifying new drug targets, predicting drug efficacy, and optimizing drug properties. Within the sphere of machine learning techniques utilized in drug discovery, the Random Forest regression algorithm stands out for its efficacy and reliability.26−28 This algorithm operates by constructing a multitude of decision trees during training and outputting the mean prediction of the individual trees. This ensemble approach makes it exceptionally good at handling large data sets with numerous input variables, a common scenario in drug development. Random Forest is particularly adept at identifying complex, nonlinear relationships within data, making it suitable for predicting drug efficacy and toxicity. Its robustness against overfitting, even with relatively small data sets, is a significant advantage in the early stages of drug discovery.29,30 Moreover, the algorithm provides insights into feature importance, enabling researchers to identify key molecular descriptors and biological properties that are most predictive of a drug’s performance.31

In this study, we employed an ML-based model, trained using a reference library of known tryptase inhibitors, to screen an FDA-approved drug library to identify potential tryptase inhibitors. The candidate compounds were further analyzed using molecular docking. Subsequent biological examination was conducted to validate these candidates. This approach, leveraging drug repositioning, has the potential to yield novel tryptase inhibitors, contributing significantly to the field of inflammatory disease treatment.

## Section: Results and Discussion

Figure 1 illustrates the workflow that integrates machine learning algorithms, molecular docking experiments, and experimental validation approaches for drug repurposing of novel tryptase inhibitors. The study followed a seven-step process: (1) Extraction of molecular features from the reference data set using RDKit, (2) Training of machine learning algorithm, (3) Screening of an FDA-approved drug library to identify lead compounds, (4) Retrieval of tryptase 3D structure and preparation of ligands, (5) Conducting molecular docking for ligand-protein complexes, (6) Experimental validation of candidates through cell culture studies, (7) Analysis of results to assess the performance of repositioning of FDA-approved drug candidates as novel tryptase inhibitors.

Workflow diagram of the predicted research study.

## Section: Machine Learning Regression Analysis of the Tryptase Reference Data Set

Utilizing the RDKit toolkit, nine distinct molecular descriptors were computed for a data set of 168 compounds, known as the tryptase reference data set. This data set was subsequently partitioned into a training set and a test set, with the training set comprising 80% of the data, and the remaining 20% split evenly between two test sets (8:1:1). The training set was then subjected to Random Forest Regression to develop a predictive model. The model’s performance was assessed by applying it to the test set of the tryptase reference data set. In Figure 2A, a visual representation is provided that illustrates the relationship between the experimentally determined pIC50 values and those predicted by a custom-built regression model. The assessment of this regression model’s accuracy was conducted by computing the Mean Squared Error (MSE) and the regression coefficient, utilizing the scikit-learn library. The analysis yielded an MSE of 0.806 and a regression coefficient of 0.83. Considering the inherent variability in pIC50 values, which stem from diverse experimental methodologies, these metrics were deemed acceptable.

(A) Correlation of experimental pIC50 values with predicted pIC50 values with the regression model. (B) Illustration of the feature importance values.

## Section: Molecular Descriptor’s Contribution in Regression Prediction

To gain insight into the influence of individual descriptors on the regression model, the Random Forest Regression tool was employed to determine the importance of each feature. Feature importance serves as an indicator of the extent to which each descriptor affects the model’s predictive accuracy. Descriptors with greater importance scores are deemed to have a more significant effect on the pIC50 prediction, whereas those with lower scores are considered to have a lesser impact. Among nine molecular descriptors evaluated, including molecular weight, LogP value, counts of hydrogen bond donors and acceptors, the proportion of sp3 hybridized carbon atoms (CSP3), the number of aromatic bonds, ring count, topological polar surface area (TPSA), and the number of aromatic rings, the CSP3 descriptor emerged as the most influential in predicting pIC50 values. Following closely in importance were the TPSA and molecular weight descriptors (Figure 2B).

## Section: Prediction of pIC50 Values of FDA-Approved Drug Library Data Set

Following the development of the regression model using the tryptase reference data set, the prediction of the pIC50 value of an FDA-approved drug library data set was carried out. The molecular descriptors of 3,105 drugs were computed utilizing the RDKit toolkit. The regression model was utilized to predict pIC50 values by applying the data set of molecular features from the FDA-approved drug library. The predictions for FDA-approved drugs ranged from 4.676 M to 8.926. Drugs predicted to have high pIC50 values, specifically those above 8.2, are detailed in Table 1. To delve deeper into the effectiveness of these compounds in inhibiting tryptase, molecular docking studies and molecular dynamics (MD) simulations were conducted with the compounds having predicted pIC50 values of greater than 8.0, which corresponds to 10 nM in IC50 values. Considering the absence of any FDA-approved tryptase inhibitors, APC-366, a compound currently under investigation as a tryptase inhibitor, was used as a positive reference in computational and experimental evaluations.

## Section: Structural Analysis of the Tryptase Protein

Tryptase holds the distinction of being the most abundant serine proteinase derived from secretory granules within mast cells. Its presence has been utilized as a marker for mast cell activation.32 It is made up of 245 amino acids forming a single chain (PDBID: 2GDD). The protein exhibits a complex structure involving loops, α-helices, and β-sheets, contributing to its overall conformation. Furthermore, a VADAR 1.8 structural study revealed that tryptase is made up of 8% α-helices, 45% β-sheets, 46% coils, and 30% turns. Based on the Ramachandran plots, 94.6% of amino acids were situated within the favored region, while 100% of residues fall within the allowed zone of dihedral angles phi (φ) and psi (ψ) (Figure S1).

## Section: The Binding Pocket Analysis

The functional attributes of a binding pocket are influenced not only by its geometry and position within a protein but also by the particular amino acid residues that encircle it.33 In this study, the binding pocket residues were identified using the Discovery Studio ligand interaction approach, and compared to already available data (PBID: 2GDD) revealing Val35, Phe41, Cys58, Lys60, Leu64, Asp189, Gln192, Gln195, Ser214, Trp215, Gly219, and Gly226 as the active site amino acid residues. The cocrystallized ligand was utilized to construct the binding sphere, focusing on our selected binding pocket residues the sphere was contracted. Therefore, the sphere’s dimensions were adjusted to X = 13.4387, Y = 57.5649, and Z = 70.0616, with a fixed radius of 11.3075. These parameters were set to investigate the interaction of screened compounds against the tryptase active site (Figure 3).

(A) This panel shows the spatial positioning of the tryptase active site. The enzyme’s structure is represented as a ribbon in aquamarine, with the binding site surface highlighted in coral. (B) This panel focuses on the key residues within the active region of tryptase, crucial for ligand binding. Notably, the catalytic triad, consisting of His57, Asp102, and Ser195, is highlighted to emphasize its role in the enzyme’s activity. Additional crucial amino acids for ligand binding, including Gly193, Ser195, Asp194, Ser214, Ser190, and Asp189, are also emphasized.

## Section: Molecular Docking Analysis

The CDocker module within Discovery Studio was employed to forecast negative energy values, specifically CDocker energy and CDocker interaction energy. CDocker energy encapsulates the overall docking energy, which is derived from the 3D structural and physiochemical attributes of both the ligand and the protein. In contrast, CDocker interaction energy focuses exclusively on the energy related to the interactions between the ligand and the receptor. This encompasses the contributions from various intermolecular forces, such as van der Waals forces, electrostatic complementarity, and hydrogen bonding, all of which contribute to the binding affinity. CDocker Interaction Energy provides a granular understanding of the strength and character of the individual interactions between the ligand and the receptor.34 During the docking analysis of all screened compounds with tryptase, each compound underwent individual scrutiny and scoring based on minimal docking energy values. This comprehensive evaluation aimed to identify compounds with favorable binding characteristics and promising interactions within the active site of tryptase (Table 2). The results revealed that several screened drugs demonstrate more negative docking energy scores as compared to the reference APC-366, emphasizing the potential superiority of the identified ligands. All the docket compounds are sorted according to the lowest docking energy values. Furthermore, these compounds already have known activities instead of tryptase and could be a possible inhibitor of tryptase too.

## Section: Selection of Highly Predicted Drugs

From the tryptase inhibitors identified through molecular docking analysis, the top seven drugs along with the reference compound APC-366 (Figure 4) were chosen for in-depth investigation. This included analyses of binding modes and experimental evaluation. Enalapril, a prodrug of enalaprilat, was also included in this selection. Although it did not rank highly in the predictive analysis, its selection was influenced by the practical consideration of enalaprilat’s limited availability for experimental analysis. Laninamivir, known for inhibiting influenza neuraminidase, also appears to block tryptase, suggesting dual action that may enhance its antiviral effects. While neuraminidase inhibitors like laninamivir prevent virus spread by stopping the release of new viruses from cells, tryptase, released from mast cells, activates influenza hemagglutinin. This is significant, although some deadly influenza strains activate hemagglutinin differently. Our hypothesis about laninamivir’s dual inhibition remains speculative, based on in vitro results, and requires further exploration to understand its full antiviral potential.

Structures of highly predicted tryptase inhibitors from molecular docking with the reference compound of APC-366.

## Section: Binding Interaction Analysis

The binding interaction analysis was conducted to discern the specific interactions and their types with the active region amino acid residues of the tryptase protein. This analysis aimed to determine whether the ligands bound effectively within the active binding pocket. Additionally, the identification of hydrogen bonds and salt bridges was part of this approach. The results indicated that APC-366, aliskiren, citocoline, cidofovir, enalaprilat, landiolol, and laninamivir successfully bound to the active binding pocket of the target protein, demonstrating favorable interactions as shown in Figure 5.

The APC-366 ligand–receptor complex demonstrates five hydrogen bonds with His57, Lys60, Cys58, Cys42, and Phe41. The oxygen atom of the ligand made a hydrogen bond with Lys60 with a bonding distance of 2.04 Å. A hydrogen atom of ligand formed two hydrogen bonds against His57 and Cys58 with bond lengths of 2.46 and 2.84 Å. Furthermore, another hydrogen atom formed two hydrogen bonds against Phe41 and Cys42 with bonding distances of 2.53 and 2.80 Å respectively. The aliskiren docking interaction analysis to the target protein exhibited that the ligand bind in the active region of the tryptase and manifested four hydrogen bonds with the active region amino acids. The four different hydrogen atoms of the ligand formed hydrogen bonds against Cys58, Cys42, and Phe41 with bonding distances of 2.06 Å, 2.06 Å, 2.27 Å, and 2.14 Å respectively.

The citocoline compound docked to tryptase demonstrated five hydrogen bonds against four different amino acids Lys60, His 57, Cys58, and Gly193. The two oxygen atoms of the ligand form 2 hydrogen bonds with the same Lys60 with bonding distances of 1.74 Å, and 1.86 Å. Furthermore, two other oxygen atoms of ligand formed hydrogen bonds against His57 and Gly193 with bond lengths of 2.15 and 2.32 Å respectively. Moreover, the hydrogen atom of the ligand forms a hydrogen bond against Cys58 with a bond length of 1.98 Å. The cidofovir compound docked to tryptase depicted three hydrogen bonds and one salt bridge against the target protein. Two oxygen atoms of ligand formed two hydrogen bonds against Phe41 and Ser195 with bond lengths of 2.08 and 2.16 Å respectively. Furthermore, another hydrogen atom of the ligand formed a hydrogen bond against the binding pocket residues Cys58 with a bonding distance of 2.14 Å. Moreover, an oxygen atom of ligand formed a salt bridge against Lys60 with a bonding distance of 1.83 Å.

The enalaprilat-tryptase docked complex demonstrated three hydrogen bonds in the docking interaction analysis. Two different oxygen atoms of ligand formed two hydrogen bonds with different amino acid residues of binding pocket Ala97 and Lys60 with bond lengths of 2.25 and 2.35 Å respectively. Furthermore, a hydrogen atom of ligand formed a hydrogen bond against His57 with a bonding distance of 1.87 Å. Landiolol with a molecular weight of 509.6 g/mol occupied the extensive space in the active binding pocket of tryptase and exhibited four hydrogen bonds against the active region amino acids of the target protein. Three hydrogen atoms of landiolol formed hydrogen bonds against Ser195, Gln192, and Gly216 with bonding distances of 2.43 Å, 2.38 Å, and 2.43 Å respectively. Moreover, the oxygen atom of landiolol formed a hydrogen bond against Gly216 with a bonding distance of 2.43 Å. Laninamivir binds in the active region of tryptase and forms four hydrogen bonds against the active region of the target protein. The hydrogen atom of the ligand formed a hydrogen bond against Gly60 with a bond length of 1.79 Å. Furthermore, two hydrogen atoms formed two hydrogen bonds with the same amino acid residue His57 with bonding distances of 2.26 and 2.12 Å. Moreover, an oxygen atom of the ligand establishes a hydrogen bond with the aforementioned His57, with a bonding distance of 3.05 Å.

The 3D interactions between the ligand and the active region amino acids of tryptase. The hydrogen bond interaction and interacting amino acids are colored red, the salt bridges and salt bridge forming amino acids are colored cyan, and the other interacting amino acids are colored black.

## Section: Experimental Validation

RBL-2H3 cell line, derived from rat basophilic leukemia cells, possess key characteristics with mast cells, notably the capacity to degranulate and release inflammatory mediators such as histamine and cytokines upon specific stimulation. This makes RBL-2H3 cells an optimal model for studying mast cell activation, signaling pathways, and the effects of various agents on mast cell functionality.35,36 To induce mast cell activation, we exposed RBL-2H3 cells to known mast cell activators; phorbol myristate acetate (PMA) and calcium ionophore A23187. The effectiveness of activation was quantitatively assessed by measuring two primary markers of mast cell degranulation: the activity of β-hexosaminidase and the release of histamine. These markers are indicative of the degranulation process and the inflammatory response of mast cells. Additionally, in our experiments, we included nedocromil, an FDA-approved mast cell stabilizing agent, as a reference compound. The exact mechanism of action of nedocromil is not fully understood, but its established role in mast cell stabilization makes it a suitable reference. This was particularly pertinent given that APC-366 is an investigational tryptase inhibitor and there are currently no FDA-approved tryptase inhibitors available. Highly predicted drugs demonstrated significant suppression of both β-hexosaminidase activity (Figure 6A) and histamine release (Figure 6B) in RBL-2H3 cells challenged with PMA/A23187. These effects were observed to be similar in extent to those achieved by APC-366 and nedocromil. Most notably, the highly predicted drugs also significantly inhibited tryptase activity to the same extent as APC-366 and nedocromil (Figure 6C). Notably, tryptase inhibitors significantly reduced the release of histamine and β-hexosaminidase, in addition to inhibiting tryptase activity. Previous studies have demonstrated that tryptase inhibitors, such as APC366-also used in our study-effectively decrease not only tryptase activity but also other markers of mast cell activation.37,38 These findings suggest that tryptase may amplify mast cell activation, and its inhibition can consequently attenuate the overall mast cell response. However, additional research is needed to elucidate the specific mechanisms by which tryptase influences the degranulation process during mast cell activation. Nedocromil demonstrated a reduction in tryptase activity, which is likely attributable to its mast cell stabilizing properties, leading to decreased tryptase release, as opposed to a direct inhibitory effect on tryptase. This contrasts with other tested compounds that directly inhibited released tryptase during the mast cell activation process. These results are particularly significant as they suggest that these highly predicted drugs have the potential to serve as novel tryptase inhibitors.

Inhibition of PMA/A23187-induced β-hexosaminidase activity (A), histamine release (B), and tryptase activity (C) in RBL-2H3 cells.

## Section: Structural Evaluation and Similarity Comparison

To evaluate the structural resemblance among the drugs that were highly predicted by both experimental and computational data, the Tanimoto similarity measure was applied using RDKit. This metric is crucial for comparing the similarity and diversity among compounds. The Tanimoto coefficient ranges from 0 to 1, where 0 indicates no similarity and 1 indicates complete similarity. Although there is no universally accepted threshold for similarity, a Tanimoto coefficient of 0.4 generally signifies a moderate level of similarity. This means the compounds share certain features but also possess significant differences (Figure S2A, and S2B)). With a Tanimoto similarity value around 0.4 certain drug groups were identified: APC-366, agatroban, and enalaprilat formed one group; laninamir and agatroban another; and citocholine, agatroban, and cidofovir yet another. Despite these groupings, no overarching similarity was found across all highly predicted drugs (Table S1).

Despite the limited overall similarity of the highly predicted drugs to APC-366, the possibility of shared specific structural features is still present. To investigate this further, the Maximum Common Substructure (MCS) algorithm was employed within RDKit, with a threshold of 0.5 set for the analysis. This led to the identification of common substructures among APC-366, agatroban, aliskiren, enalapril, and enalaprilat, which were highlighted in green color (Figure S2A). Notably, APC0366, argatroban, enalapril, and enalaprilat shared an N-(3-phenylproppyl) methylamine group in their structures, a feature absent in other drugs. This suggests that inhibitory activity against tryptase may involve factors beyond structural motifs, potentially including spatial arrangement or specific conformations. Additionally, similarity maps generated using RDKit’s fingerprints assessed if the highly predicted drugs shared structural motifs with APC-366 (Figure S2B). The similarity maps revealed the extent to which APC-366’s structural motif was present in the chemical structures of the highly predicted drugs. The insights gained from both MCS and similarity map analyses are instrumental in guiding further optimization of the drugs.

## Section: Methodology › Tryptase Inhibitor Reference Data Set and FDA-Approved Drug Library

The reference data set of human tryptase inhibitor consists of 168 compounds, each with experimentally determined IC50 values. This data set was sourced from the ChEMBL database (https://www.ebi.ac.uk/chembl), specifically under the ChEMBL ID CHEMBL2095193. ChEMBL is a manually curated database known for its collection of bioactive molecules with drug-like properties. In the data set, all molecules are represented as canonicalized SMILES strings and IC50 values. For more efficient data representation and analysis, the IC50 values were converted to pIC50 values. The pIC50, which is the negative logarithm of the IC, ranges from 4.48 to 9.40. This corresponds to an IC range from 33,000 nM to 0.4 nM. Furthermore, an FDA-approved drug library was obtained from Selleck Chemicals (https://www.selleckchem.com). This library is comprised of 3,105 compounds. These FDA-approved drug molecules were initially in SDF (structure-data file) format and were converted to SMILES strings using RDKit.

## Section: Methodology › Molecular Descriptor Generation Using RDKit

To evaluate the molecular properties of compounds, the RDKit (https://www.rdkit.org) platform was utilized. This open-source cheminformatics and machine learning framework, developed in Python, is adept at handling small molecule data. It offers a suite of features for processing and interpreting chemical structures, including tools for generating molecular descriptors, chemical features, and visualizing chemical data.39 Therefore, the RDKit was employed to compute a set of nine molecular descriptors for both a tryptase reference data set and an FDA-approved drug library. These descriptors encompassed a range of molecular properties such as molecular weight, LogP value, number of hydrogen bond donors and acceptors, the proportion of sp3 hybridized carbon, the total number of aromatic bonds, ring count, topological polar surface area (TPSA), and the count of aromatic rings.

## Section: Methodology › Machine Learning Architecture

The analysis of the tryptase reference data set incorporated machine learning techniques via scikit-learn (https://scikit-learn.org), a Python-based, open-source library designed for efficient and straightforward data analysis and mining. This library encompasses various algorithms for tasks such as regression, classification, clustering, dimensionality reduction, and model selection.40 For this study, The data set was split into a training set and a test set in an 8:2 proportion. The molecular descriptors within the test set underwent training using the Random Forest Regression algorithm from the scikit-learn toolkit. Random Forest Regression, an ensemble learning approach, aggregates the outputs of numerous decision trees to enhance the model’s precision and reliability (https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestRegressor.html). Upon completion of the training phase with the training data set, the model’s accuracy was evaluated using the test data set, focusing on metrics like mean squared error and the regression coefficient. Additionally, the relative influence of each descriptor was quantified through feature importance values.41,42 To predict pIC50 values for the FDA-approved drug data set, we calculated its molecular descriptors using RDkit as with the tryptase reference data set and then applied these molecular descriptors to the Random Forest Regression model.

## Section: Methodology › Tryptase Structure Retrieval

Human beta 2 tryptase (TPSB2) exists in a tetrameric form, composed of four identical subunits. The 3D structure of tryptase protein was examined using the A subunit from the crystal structure identified as PDBID: 2GDD, which has a resolution of 2.35 Å, from the Protein Data Bank (PDB) (https://www.rcsb.org/structure/2GDD). To refine the structure for the analyses, energy minimization was employed using UCSF Chimera software. The tryptase protein, composed of α-helices, β-sheets, and turns, underwent a quantitative analysis of its structure using the VADAR (http://vadar.wishartlab.com/) Internet server.43 Additionally, the Ramachandran plots were generated using Discovery Studio.44 Moreover, the same tool was utilized to investigate the 3D structure of the protein.

## Section: Methodology › Prediction of Active Binding Site

The placement of a ligand within the protein’s holo-structure is a strong indicator of the targeted protein’s binding pocket.45,46 The tryptase inhibitor complex was obtained from the PDB (PDB ID: 2GDD). To ensure the precision of binding site selection, interacting amino acids were chosen using the ligand interaction feature of Discovery Studio. As a result, the cocrystallized ligand was selected, and the binding sphere was established using the current selection method within the define binding site window of Discovery Studio. Subsequently, the binding sphere was reduced to be confined to the chosen amino acids.

## Section: Methodology › Molecular Docking

Molecular docking stands as one of the most extensively employed methods for assessing the interactions and conformations of ligands with target proteins.47,48 Certainly, scoring algorithms in molecular docking enable the estimation of association strength or binding affinity between two molecules by assessing their preferred orientation. This predictive capability enhances our understanding of molecular interactions and aids in identifying potential ligands for target proteins.33 The protein underwent preparation steps before molecular docking, involving the removal of water molecules and the cocrystallized ligand by UCSF Chimera. Additionally, hydrogen atoms were added to the protein using Discovery Studio’s protein preparation approach. Ligand preparations for both screened and reference compounds were conducted, involving tautomer generation, ionization adjustments, and addressing bad valencies through Discovery Studio’s ligands preparation module. Subsequently, the CDOCKER module of Discovery Studio was utilized to carry out molecular docking of the screened FDA candidate compounds against tryptase, with default orientation and conformation settings at 10/10. Each chosen compound underwent molecular docking against tryptase, and the top hits were selected based on the lowest binding energy values (in kcal/mol) to identify the best-docked complexes.

## Section: Methodology › Binding Interaction Analysis

The top docked complexes, along with APC-366 as a reference drug, were subjected to three-dimensional (3D) graphical analysis using UCSF Chimera49 and Discovery Studio. This analysis aimed to comprehensively study the interactions between ligands and the target protein, providing insights into the spatial arrangement and binding characteristics of the compounds within the protein’s active site.

## Section: Methodology › Experimental Reagents and Cell Culture

Cidofovir dihydrate was acquired from GLPBIO (#GC13936, MONTCLAIR, USA). All other chemicals required for the experiment were procured from Sigma-Aldrich, located in St. Louis, MO, USA. The RBL-2H3 cells were acquired from the Korea cell line bank (KCLB), with the catalog number 22256 (RBL-2H3). The RBL-2H3 cells were cultured in RPMI 1640 medium (Hyclon Laboratories), supplemented with 10% heat-inactivated fetal bovine serum and 100 U/ml of penicillin-streptomycin (Gibco). The cells were maintained at 37 °C in an atmosphere containing 5% CO2.

## Section: Methodology › β-Hexosaminidase (β-HEX) Activity and Histamine Release Assay

To assess the impact of chemicals on degranulation, we quantified the levels of β-HEX activity and histamine release. This enzyme is found within the granules of mast cells and is commonly used as a marker for granule content.50 RBL-2H3 cells were grown in 12-well plates for a duration of 24 h. The medium was then discarded, and the cells were treated with 0.1 μM of inhibitors diluted in PIPES buffer for 1 h at 37 °C. Following this pretreatment, the cells were washed twice with PIPES buffer and subsequently stimulated with 50 nM of PMA and 1 μM of A23187 for 30 min at 37 °C. A 20 μL aliquot of the supernatant was then allowed to react with 80 μL of substrate buffer (containing 2 mM 4-p-nitrophenyl-N-acetyl-β-d-glucosaminide in 0.05 M sodium citrate buffer, pH 4.5) for 30 min at 37 °C. The reaction was halted by the addition of 200 μL of stop buffer (0.1 M NaHCO3, pH 10). The absorbance was measured at 405 nm using a microplate spectrophotometer (SpectraMax M5, Molecular Devices, USA). The concentration of histamine was determined using the o-phthalaldehyde (OPT) spectrofluorometric method.51 To each well’s 0.5 mL of supernatant, 0.1 mL of 1 M NaOH and 25 μL of OPT (1% weight/volume in methanol) were added. The mixture was then incubated for 4 min at room temperature. The reaction was terminated by adding 50 μL of 3 M HCl. The absorbance was measured at excitation and emission wavelengths of 360 and 450 nm, respectively, using a microplate spectrophotometer (SpectraMax M5, Molecular Devices, USA).

## Section: Methodology › Tryptase Inhibition Activity Assay

Tryptase activity was measured using the Tryptase Activity Assay kit from Tribioscience (#TBS2101, Tribioscience, USA) following the manufacturer’s instructions. To prepare cellular tryptase, RBL-2H3 cells were detached from the culture plate. After detaching the cells, wash them and adjust the cell concentration to 1.0 × 107 cells/mL with 1X assay buffer. The suspended cells were incubated in the presence of the 0.1 μM of inhibitors for 1 h and then stimulated with 50 nM of PMA and 1 μM of A23187 for 30 min at 37 °C in a 5% CO2 incubator. The cell suspension was centrifuged at 700 X g, and the supernatant was carefully collected. For the tryptase inhibition activity assay, the assay mixture was made by adding 50 μL of supernatant to 130 μL of assay buffer. The colorimetric reaction was initiated by adding 20 μL of the tryptase substrate. The reactions were observed at 405 nm in kinetic mode for a duration of 60 min at 37 °C using a microplate spectrophotometer (Molecular Devices, San Jose, CA, USA). Each assay was conducted in triplicate.

## Section: Methodology › Statistical Analysis

All values presented in the figures are depicted as the mean ± standard deviation (SD), derived from a minimum of three independent experiments. Statistical significance was determined using a two-tailed Student’s t test. Data with p-values less than 0.05 were considered statistically significant. Single (*) and double (**) asterisks indicate statistical significance at p < 0.05 and p < 0.01, respectively.

## Section: Conclusion

The increasing duration and cost of drug development necessitate the exploration of emerging techniques to streamline this process. Machine learning (ML) has emerged as a particularly effective tool in identifying lead compounds with high potential for successful drug development. Our study demonstrates the distinct advantages of ML-based screening in terms of efficiency and high throughput performance in drug design.

In our research, compounds predicted by ML to be effective were selected from FDA-approved drugs. These compounds were shown to fit well within the active region of tryptase, effectively blocking its active site in computational models. Further validation was provided through biological assessment of these compounds. The activities of these highly predicted drugs were comparable to the reference compound APC-366, underscoring their potential efficacy as tryptase inhibitors. Although numerous tryptase inhibitors have been previously reported, it is important to note that these are largely in investigational stages and have not yet received FDA approval. Notably, the fact that these compounds are already FDA-approved adds feasibility and safety to their potential use. Therefore, our study concludes that ML-based drug screening, particularly in the context of drug repurposing, presents a promising approach for the development of novel tryptase inhibitors, offering a significant contribution to the field of drug discovery.


---

# Identification of STAT3 phosphorylation inhibitors using generative deep learning, virtual screening, molecular dynamics simulations, and biological evaluation for non-small cell lung cancer therapy

- **Authors:** Weiji Cai, Beier Jiang, Yichen Yin, Lei Ma, Tao Li, Jing Chen
- **Issuer:** Molecular diversity
- **Type:** Scientific article
- **Published:** 2024-12-23
- **Language:** en
- **DOI:** 10.1007/s11030-024-11067-5
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39715975/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractThe development of phosphorylation-suppressing inhibitors targeting Signal Transducer and Activator of Transcription 3 (STAT3) represents a promising therapeutic strategy for non-small cell lung cancer (NSCLC). In this study, a generative model was developed using transfer learning and virtual screening, leveraging a comprehensive dataset of STAT3 inhibitors to explore the chemical space for novel candidates. This approach yielded a chemically diverse library of compounds, which were prioritized through molecular docking and molecular dynamics (MD) simulations. Among the identified candidates, the HG110 molecule demonstrated potent suppression of STAT3 phosphorylation at Tyr705 and inhibited its nuclear translocation in IL6-stimulated H441 cells. Rigorous MD simulations further confirmed the stability and interaction profiles of top candidates within the STAT3 binding site. Notably, HG106 and HG110 exhibited superior binding affinities and stable conformations, with favorable interactions involving key residues in the STAT3 binding pocket, outperforming known inhibitors. These findings underscore the potential of generative deep learning to expedite the discovery of selective STAT3 inhibitors, providing a compelling pathway for advancing NSCLC therapies.Supplementary InformationThe online version contains supplementary material available at 10.1007/s11030-024-11067-5.Keywords: NSCLC, Drug design, Signal transducer and activator of transcription 3, Molecular dynamics, Apoptosis

## Section: Introduction

Non-small cell lung cancer (NSCLC) is the predominant form of lung cancer [1], constituting approximately 85% of all cases [2]. Although it generally exhibits a slower progression compared to small cell lung cancer (SCLC), NSCLC remains a leading cause of cancer-related mortality worldwide [3, 4]. Traditional treatment modalities, including surgery, chemotherapy [5, 6], and radiotherapy [1], often encounter limitations due to adverse side effects and the development of resistance [3, 7, 8]. In recent years, targeted therapies have emerged as a promising strategy for NSCLC [9], particularly for tumors with specific mutations in genes such as EGFR [10], ALK, and ROS1 [11]. Agents targeting these mutations, including EGFR inhibitors like Gefitinib and ALK inhibitors such as Crizotinib, have shown significant efficacy in patients with these genetic alterations. However, challenges persist, including resistance to targeted therapies and limited options for patients lacking targetable mutations. Ongoing research aims to identify new molecular targets, including MET, RET [12], and KRAS [13], alongside immune checkpoint inhibitors like PD-1/PD-L1 inhibitors [14], which have demonstrated promise in clinical trials and represent an expanding area of therapeutic development for NSCLC.

Signal transducer and activator of transcription 3 (STAT3) has emerged as a critical therapy target for NSCLC, due to its role in enhancing cancer cell proliferation, survival, and immune evasion [15]. Dysregulated STAT3 signaling is commonly observed in various cancers [16], including NSCLC [17], where it is associated with poor prognosis and resistance to conventional therapies. Therefore, STAT3 has become a pivotal target in the development of novel cancer treatments [18, 19]. Several small-molecule inhibitors with diverse chemical scaffolds have been developed to inhibit STAT3 activity (Fig. 1). For instance, napabucasin, a quinolone derivative, inhibits STAT3-driven transcriptional activity and has shown anticancer effects in clinical trials. Another compound, stattic, selectively inhibits the SH2 domain of STAT3, obstructing its dimerization and activation. Benzimidazole-based inhibitors, such as BP-1-102 [20], effectively bind to the STAT3 SH2 domain, preventing its interaction with phosphotyrosine residues on activated receptors. Additionally, OPB-51602 [21], a novel STAT3 inhibitor featuring a piperazine scaffold, has demonstrated promising anticancer activity in both preclinical and clinical studies. These varied chemical scaffolds highlight the potential of STAT3 inhibitors as viable therapeutic options, particularly for cancers characterized by STAT3 overactivation [22]. Despite these advances, the clinical utility of STAT3 inhibitors has been limited by challenges such as poor bioavailability, off-target effects, and resistance mechanisms. Hence, there is a need for the development of more potent and selective inhibitors that can overcome these barriers and be translated into effective therapies for NSCLC.

Generative deep learning (GDL)-aided drug design is an innovative approach that leverages advanced algorithms to accelerate the discovery of new drug candidates by generating novel chemical structures with desired biological properties [23–25]. In GDL, algorithms such as generative adversarial networks (GANs) [26], recurrent neural networks (RNNs) [27], and variational autoencoders (VAEs) [28] are commonly used to create virtual libraries of potential drug molecules. GDL enables the design of novel compounds by learning from existing datasets of known drugs and predicting new chemical structures optimized for specific biological targets, such as STAT3 [29]. The process begins with the design of a target library, which typically involves selecting molecular scaffolds or fragments that are known to interact with the target protein or pathway of interest [30]. By integrating structure-based design principles [31] and applying GDL, researchers can expand this library to generate novel molecules. Virtual screening follows, where the designed molecules are computationally assessed for their ability to bind to the target using techniques like molecular docking or molecular dynamics simulations [32, 33]. By enhancing the chemical diversity and optimizing lead compounds early in the drug discovery process, GDL significantly accelerates the identification of promising therapeutic candidates. This innovative approach has the potential to overcome many of the limitations associated with traditional drug discovery methods and offers a pathway for the development of more effective STAT3 inhibitors for the treatment of NSCLC.

A comprehensive analysis of protein complexes using molecular dynamics and quantum calculations can provide deeper insights into their interactions. In this study, we employed generative deep learning to create customized virtual compound libraries aimed at discovering novel STAT3 inhibitors (Fig. 2). The libraries were generated using a conditional recurrent neural network (cRNN) model [34], which learned distribution patterns to synthesize diverse molecular structures. These compounds underwent a rigorous virtual screening process that included drug-like filtering, molecular docking studies, and synthesis of selected molecules. Ultimately, 95 small molecules were chosen for biological evaluation across H1299 and H441 cell lines. Among these, compounds HG106 and HG110 were subjected to further analysis using colony formation assays and apoptosis assays, alongside characterization of caspase-3-dependent apoptosis biomarkers. Furthermore, we assessed the in vivo inhibition of STAT3 (Tyr705) phosphorylation through immunoblotting and cellular immunofluorescence techniques. Our results demonstrated that HG106 and HG110 exhibited significant efficacy as STAT3 inhibitors, highlighting their potential for therapeutic applications in NSCLC.

Chemical structures of STAT3 inhibitors with different scaffolds

The flowchart for generative deep learning model, virtual screening, and biological assays to identify merging STAT3 inhibitors

## Section: Materials and methods › Cell lines and cell culture

NSCLC cell lines NCI-H1299, A549, NCI-H522, and NCI-H441 were obtained from the American Type Culture Collection. MRC-5 and GES-1 cell lines were donated to Prof. Ming-Yao Liu’s group at the Shanghai Institute of Key Regulated Life Sciences, East China Normal University, Shanghai, China. NCI-H441, NCI-H522, MRC-5, A549, NCI-H1299, and GES-1 cell lines were cultured in DMEM or RPMI-1640 with 10% fetal bovine serum (Gibco). All cells were cultured in an incubator with 5% CO2 at a constant temperature of 37 °C.

## Section: Materials and methods › Generative deep learning to generate virtual molecular library

The generative deep learning model was implanted from previous report. The package was obtained from the Yueshan Li et al. paper [35]. All the parameters were set as default without changing except especial mention in the paper (see Supplementary Table S1). Briefly, the generative model was built to convert molecular SMILES strings into reconstructed SMILES strings using a two-part structure: a feature extractor and a generative layer. The feature extractor is a one-layer bi-directional LSTM with 512 dimensions, converting input molecules into an initial state vector for the model. This state vector and a one-hot encoded SMILES string feed into a one-layer LSTM with 256 dimensions, followed by a dense layer and a SoftMax activation function. This structure enables a probability distribution over possible grammar production rules, which allows the model to generate chemically valid molecules in each step of SMILES generation. After training, generated molecules were generated with 39,477, and then filtered to remove the duplicate, unstable, and other molecules which cannot transform into 3D molecules (n = 27,863).

For the pretraining procedure, we collected STAT3 inhibitors from ChEMBL database (https://www.ebi.ac.uk/chembl/, update Sept 1st, 2024), in which IC50 is less than 1000 nM, and there were 411 molecules obtained and further transformed as SMILES for the following training. The source data were obtained from ZINC database (https://zinc.docking.org/, update to Sep 1st, 2024) with drug-like pre-set. The molecular structures retrieved from the ZINC database were initially represented in SMILES (Simplified Molecular Input Line Entry System) notation. Subsequently, these SMILES strings underwent a process of standardization and normalization. This involved the elimination of stereochemical details, the removal of counterions associated with salts, and the identification and exclusion of duplicate entries. The aforementioned operations were facilitated by employing the RDKit software package, version 2024.3.2, which is accessible at https://github.com/kuelumbus/rdkit-pypi. As a result of this meticulous curation, a comprehensive dataset comprising approximately 12 million unique molecular entities was assembled for subsequent analysis.

## Section: Materials and methods › Molecular docking

Molecular docking simulations were performed to predict the binding mode and affinity of the ligand to the target protein STAT3 using AutoDock 4.0. The docking protocol was designed to comprehensively explore the conformational space and provide reliable interaction profiles suitable for a high-impact publication.

Protein Preparation: The three-dimensional structure of the target protein was obtained from the Protein Data Bank (PDB ID: 6nuq), which was reported by Longchuan Bai et al. [36]. The protein structure was prepared using AutoDockTools (ADT) version 1.5.6 following these steps:

The prepared protein structure was saved in PDBQT format required by AutoDock.

## Section: Materials and methods › Molecular docking › Ligand preparation

The ligand structure was drawn using Kindraw and converted to a three-dimensional conformation using Accelrys ViewerLite 5.0 and further optimizing using openbabel (Version 3.0.0, https://pypi.org/project/openbabel/3.0.0a1/).

## Section: Materials and methods › Molecular docking › Grid preparation

The grid box was centered at the coordinates of the co-crystallized ligand (13.711, 54.024, − 0.083). The grid box size was set to 62 × 70 × 70 points with a grid spacing of 0.375 Å, ensuring sufficient space for the ligand to explore conformational freedom. AutoGrid 4.0 was used to pre-calculate the grid maps for all atom types present in the ligand, including electrostatic and desolvation maps.

Docking parameters: Docking simulations were performed using the Lamarckian Genetic Algorithm (LGA), which combines genetic algorithm search with local optimization, enhancing the efficiency of the docking process.

Number of runs: 100 independent docking runs were conducted to ensure thorough sampling.

Population size: Set to 150 individuals per generation.

Maximum number of evaluations: 2,500,000 energy evaluations per run.

Maximum number of generations: 27,000.

Mutation rate: 0.02.

Crossover rate: 0.8.

Elitism: The top individual was carried over to the next generation.

Local search: Solis and Wets local search method was applied with a probability of 0.06.

Analysis of docking results: The docking results were analyzed using ADT and visualized with UCSF Chimera 1.15. High-resolution images of the protein–ligand complex were generated to illustrate the binding interactions.

Computational Resources: All computations were performed on a workstation equipped with an Intel(R) Xeon(R) CPU E5-2678 processor, 32 GB RAM, and running Ubuntu 20.04 LTS operating system.

## Section: Materials and methods › Molecular dynamics simulation

Molecular dynamics (MD) simulations were performed using the OpenMM software package (version 7.7) to investigate the structural dynamics of the STAT 3 protein–ligand complex. The following protocol was employed to ensure a comprehensive and reproducible simulation process [37].

## Section: Materials and methods › Molecular dynamics simulation › Protein preparation

The crystal structure of the target protein was retrieved from the Protein Data Bank (PDB ID: 6nuq). Missing residues and side chains were modeled using PDBFixer and pdb2qpr package, and protonation states were assigned appropriate for pH 7.4 using the PropKa algorithm. Hydrogen atoms were added using the pdb2pqr module in OpenMM.

## Section: Materials and methods › Molecular dynamics simulation › Ligand preparation

The ligand structure was obtained by preparing using Kindraw software (HG106 and HG110). Geometry optimization and partial charge assignment were performed using the AM1-BCC method implemented in the OpenEye Quacpac toolkit 666. Ligand force field parameters were generated using the LigParGen (https://zarbi.chem.yale.edu/ligpargen/, CM1A with neutral charge). The PDB file of ligand and relative force field were downloaded and prepared for the next step.

## Section: Materials and methods › Molecular dynamics simulation › System assembly

The prepared protein and ligand were combined to form the protein–ligand complex using ChimeraX. The complex was then solvated in an explicit water box using the TIP3P water model, with a padding distance of 10 Å from the protein surface to the box edges. Sodium and chloride ions were added to neutralize the system and achieve a physiological ionic strength of 0.15 M using the Modeller module of openmm.

## Section: Materials and methods › Molecular dynamics simulation › Force field parameters

The AMBER99SB force field was employed for the protein, while the ligand was parameterized with GAFF2 parameters. The system’s topology and parameters were generated using the ForceField class in OpenMM, integrating both protein and ligand parameters seamlessly.

## Section: Materials and methods › Molecular dynamics simulation › Energy minimization

Energy minimization was conducted to relieve any steric clashes and optimize the initial geometry of the system. The conjugate gradient algorithm in OpenMM was used with a maximum of 5,000 steps or until the energy gradient converged below 0.01 kJ/mol/Å.

## Section: Materials and methods › Molecular dynamics simulation › Production MD simulation

An unrestrained production MD simulation was executed for 200 ns under NPT conditions at 300 K and 1 atm. The Langevin integrator was used with a time step of 4 fs. All covalent bonds involving hydrogen atoms were constrained using the SHAKE algorithm, allowing for the larger integration time step. Long-range electrostatic interactions were computed using the Particle Mesh Ewald (PME) method with a real-space cutoff of 10 Å. van der Waals interactions were smoothly switched off between 8.0 Å and 10.0 Å to reduce cutoff artifacts.

## Section: Materials and methods › Molecular dynamics simulation › Data collection

Coordinates were saved every 20 ps, resulting in 10,000 frames for analysis. The simulation was monitored by recording the energy components, temperature, pressure, and volume at regular intervals to ensure system stability.

## Section: Materials and methods › Molecular dynamics simulation › Software and hardware

All simulations were performed using OpenMM on a workstation equipped with an NVIDIA V100 GPU 16 GB, leveraging GPU acceleration for efficient computation.

## Section: Materials and methods › Calculations of molecular properties

The physicochemical properties of the obtained molecules were computed using RDKit (Version 2024.3.2, https://github.com/kuelumbus/rdkit-pypi), a cheminformatics toolkit. A set of critical molecular descriptors were calculated to evaluate the drug-likeness and other relevant properties of the compounds. The following properties were assessed:

## Section: Materials and methods › Calculations of molecular properties › Molecular weight (MW)

The molecular weight of each compound was calculated as the sum of the atomic weights of all atoms in the molecule, including isotopes and charge contributions, to determine the overall size of the molecule.

## Section: Materials and methods › Calculations of molecular properties › Water–octanol partition coefficient (LogP)

The LogP value was computed using the Crippen method to estimate the hydrophobicity of the compound. This coefficient indicates the compound’s ability to partition between the water phase and the octanol phase, which correlates with its lipophilicity and drug absorption potential.

## Section: Materials and methods › Calculations of molecular properties › Qualitative estimate of drug-likeness (QED)

The drug-likeness of each compound was evaluated using the Quantitative Estimate of Drug-likeness (QED), which ranges from 0 to 1. This descriptor combines several molecular properties, including molecular weight, rotatable bonds, hydrogen bond donors/acceptors, and more, to predict how “drug-like” a compound is based on its physicochemical features.

## Section: Materials and methods › Calculations of molecular properties › Topological polar surface area (TPSA)

TPSA was calculated to estimate the polar surface area of the molecule, which plays a significant role in predicting intestinal absorption, blood–brain barrier penetration, and overall bioavailability. This descriptor helps to determine the molecule’s ability to cross biological membranes.

## Section: Materials and methods › Calculations of molecular properties › Water solubility (LogS)

The water solubility (LogS) was predicted using the Ali method, which correlates molecular features with experimental solubility data. LogS is an important factor influencing drug absorption, distribution, and excretion.

## Section: Materials and methods › Calculations of molecular properties › Hydrogen bond donors (HBD)

The number of hydrogen bond donors was calculated by counting the number of hydrogen atoms attached to electronegative atoms (like oxygen or nitrogen) that can participate in hydrogen bonding interactions.

## Section: Materials and methods › Calculations of molecular properties › Hydrogen bond acceptors (HBA)

The number of hydrogen bond acceptors was determined by counting the number of electronegative atoms (oxygen, nitrogen, etc.) that have lone pairs of electrons capable of accepting a hydrogen bond from donors.

To ensure accurate predictions, all compounds were first converted into standard SMILES (Simplified Molecular Input Line Entry System) strings using RDKit, followed by the calculation of the above properties. Each descriptor was obtained by running the appropriate RDKit functions that are designed to handle different molecular types, such as aromatic rings, heteroatoms, and functional groups.

## Section: Materials and methods › Uniform manifold approximation and projection (UMAP)

To elucidate the relational similarities among the source data, target data, and generated data, we employed UMAP (umap-learn 0.4.6, https://pypi.org/project/umap-learn/) to create two-dimensional projections of high-dimensional data distributions. This analysis involved 3,000, 1,000, and 2,000 randomly selected molecules from the source, target, and generated datasets, respectively. All the images were generated using Python = 3.8 with scipy package (Version 1.10.1).

## Section: Materials and methods › Tree maps (TMAPs)

Scaffold and fingerprint diversity were assessed and visualized utilizing the Platform for Tree maps (tmap, https://tmap.gdb.tools/), based on a random selection of 15,678 molecules from the source data, target data, generated data, and filtered molecules, respectively.

## Section: Materials and methods › Cell viability assay

Cells were collected from culture dishes, counted, resuspended, and seeded into 96-well plates. After allowing them to adhere overnight, we replaced the medium with fresh medium containing various concentrations of the drug and incubated the cells for an additional 72 h. To fix the cells, we added 25 μL of 50% trichloroacetic acid (Sangon Biotech, China) to each well and refrigerated the plates at 4 °C overnight. Following fixation, the plates were washed and dried before adding 50 μL of 0.4% sulforhodamine B solution (A426137, Sangon Biotech, China) to each well for staining. After a 10-min incubation, excess dye was removed by washing the plates several times with 1% glacial acetic acid (A501931, Sangon Biotech, China) until the wash solution was clear. The plates were then air-dried, and 100 μL of 10 mM Tris buffer (T8060, Solarbio, China) was added to each well to dissolve the dye. Absorbance was measured at 515 nm using a plate reader.

## Section: Materials and methods › Colony-forming assay

Non-small cell lung cancer cell lines NCI-H441, NCI-H1299, NCI-H522, and A549 were seeded into 6-well plates at densities ranging from 1,000 to 3,000 cells per well and cultured for 24 h to allow for cell attachment. The following day, the cells were treated with HG106 and HG110 at given concentrations of 0.5 μM and 1 μM, respectively, for a period of 7 to 10 days, with three replicate wells for each group. The culture medium was refreshed and the drugs were re-applied every three days. After the treatment period, cells were fixed with 4% paraformaldehyde (P1110, Solarbio, China) for 30 min. The plates were washed three times with running water and air-dried. Cells were then stained with 0.1% crystal violet (A600331, Sangon Biotech, China), washed with ultrapure water, dried, and photographed. Colonies containing more than 50 cells were counted.

## Section: Materials and methods › Soft-agar colony formation assay

A 1.2% agar solution (A8190, Solarbio, China) was combined with growth medium and poured into the wells of a 6-well plate at a volume of 2 mL per well. The mixture was allowed to solidify at room temperature. Once the first agar layer had set, a second layer containing 0.5% agar and 2000 cells per well were added, using 1 mL per well. Fresh medium was then added on top of the second layer, and the cells were incubated for approximately 4 weeks. During this period, the medium supplemented with the specified drugs was refreshed every 3 days. At the end of the incubation period, the colonies were photographed for further analysis.

## Section: Materials and methods › Western blotting analysis

Cells were seeded into 60 mm culture dishes and allowed to adhere. After adhesion, different concentrations of the target compound drugs were added to the medium, and the cells were incubated for an additional 24 h. The medium was then removed, and the cells were washed three times with pre-chilled 1 × PBS (P1010, Solarbio, China). Next, 150 µL of cell lysis buffer (HY-K1001, MCE, USA) was added to each dish, and the protein lysate was collected into EP tubes (615,601, NEST, China) using a spatula. The lysates were kept on ice for 30 min, with gentle shaking for 15–20 s every 10 min to ensure complete lysis. Protein concentrations were measured using a BCA assay kit (23,235, Thermo, USA), and each sample was adjusted to approximately 50 µg of protein. The protein samples were mixed with 5X protein loading buffer (C516031, Sangon Biotech, China) and heated at 100 °C for 10 min to denature the proteins. The denatured proteins were then separated by electrophoresis until the bromophenol blue dye reached about 1 cm from the bottom of the gel. After electrophoresis, the proteins were transferred to a membrane, which was then incubated with the primary antibody overnight at 4 °C on a shaker. The following day, the membrane was incubated with a secondary antibody diluted in skimmed milk for 1 h on a shaker to complete the detection process.

The membrane was visualized using an Odyssey infrared two-color laser scanning imaging system. Reagents and antibodies: STAT3 (cat. no. 9139), antibodies against phosphorylated (p)-STAT3 (Tyr705; 9145), Bcl-2 (4223), Caspase-3 (4691), Bax (Ser465; 467) were purchased from Cell Signaling Technology. GAPDH and β-actin (cat. no. M1210-2) were purchased from Hangzhou Huaan Biotechnology. Other reagents, such as dimethyl sulfoxide, were obtained from Sigma-Aldrich (Merck KGaA).

## Section: Materials and methods › Apoptotic assay

NCI-H441 cells were treated with the specified drugs in 6-well plates for 24 h. After treatment, the cells were detached using EDTA-free trypsin (T1350, Solarbio, China) and collected into labeled EP tubes. Following centrifugation, the supernatant was removed. The cell pellet was resuspended gently in 500 µL of Binding Buffer (KGA1102, KeyGEN, China) to create a single-cell suspension. Next, 5 µL of Annexin V-FITC (KGA1102, KeyGEN, China) was added to each sample and mixed thoroughly, followed by the addition of 5 µL of propidium iodide (KGA1102, KeyGEN, China). The samples were incubated at room temperature in the dark for 5 to 10 min. Flow cytometry (BD Accuri™ C6 Plus, USA) analysis was then performed, examining 20,000 cells per sample. Early apoptotic cells were identified as those positive for Annexin V-FITC but negative for propidium iodide, while late apoptotic cells were positive for both Annexin V-FITC and propidium iodide. The results were expressed as the percentage of each apoptotic population relative to the total number of cells analyzed (FlowJo 10.8.1).

## Section: Materials and methods › Immunofluorescence

Cell slides were first soaked in 75% ethanol for 1 h and then dried by holding them with forceps approximately 2–3 cm from an alcohol lamp. The prepared slides were placed into a 24-well plate, and cells were seeded onto the slides and incubated until they adhered to the surface. After cell adhesion, the medium was replaced with fresh medium containing varying concentrations of the target compounds, and the cells were incubated for an additional 24 h. Subsequently, the cells were treated with interleukin-6 (PeproTech, USA)) for 2 h. The cells were then fixed on ice using 4% paraformaldehyde (P1110, Solarbio, China) for 20 min. Following fixation, the cells were permeabilized with 0.3% Triton X-100 (T8200, Solarbio, China) for 30 min and washed three times with PBS, each wash lasting 10 min. Blocking was performed using 1% bovine serum albumin (A8020, Solarbio, China) for 1 h to prevent non-specific antibody binding. After blocking, 100 µL of diluted primary antibody was added to each slide and incubated overnight at 4 °C on a shaker. The next day, the slides were washed with 1 × PBS for 10 min to remove any unbound antibody.

## Section: Materials and methods › DFT calculation

The optimization of the compounds was performed by using PySCF. For this process, B3LYP/6-311G + (d,p) level basic set of DFT was used. Afterward, the Frontier Molecular Orbitals (FMO) which were the highest occupied molecular orbital (HOMO) and lowest unoccupied molecular orbital (LUMO) were extracted and the energy gap was calculated by the difference between HOMO and LUMO energy values. Furthermore, quantum chemical parameters were calculated in order to predict the behavior of compounds and to get information about the transition state energies.

## Section: Materials and methods › Virtual screening strategies

Virtual screening was performed to identify potential small-molecule inhibitors for the target protein using a combination of drug-like filtering, molecular docking, and binding affinity calculations. Initially, a compound library was screened based on revised Lipinski’s Rule of Five (Molecular weight ≤ 700 Da; LogP ≤ 5; Hydrogen bond donors ≤ 5; Hydrogen bond acceptors ≤ 10) to select drug-like candidates with favorable pharmacokinetic properties.

To optimize the enrichment of active compounds, a hierarchical two-step pipeline was implemented for the structure-based virtual screening of potential inhibitors. Initially, AutoDock Vina was employed to dock a large compound library into the target protein’s binding site, which allowed for the rapid elimination of inactive or poorly binding compounds. The compounds were ranked according to their predicted binding affinities, and the top 10% were selected for further analysis.

In the second step, an in-house developed scoring function, CYSCORE [38], was used to refine the selection of compounds based on their predicted binding energies and other physicochemical properties. The top 10% of compounds from the AutoDock Vina docking were further analyzed using FitDock [39], a compound alignment and docking program. This tool assessed the structural similarities between the compounds, clustering them into groups based on common chemical scaffolds and binding modes. This two-step virtual screening strategy allowed for the identification of high-affinity inhibitors of MDM2, streamlining the selection of promising candidates for further experimental validation.

Additionally, Molecular Mechanics, General Born Surface Area (MM/GBSA) calculations (gmx_MMPBSA package with the GROMACS, 100 ps) were performed to refine the binding affinity predictions and assess the stability of the ligand–protein complexes. The final selection of top-ranked molecules was based on their docking scores, ligand efficiency, drug-likeness, with compounds that demonstrated favorable results proceeding to experimental validation.

## Section: Materials and methods › Statistical analysis

All experiments in this study were repeated three times independently, and all data were analyzed using GraphPad Prism 9.0. One-way analysis of variance (ANOVA) was used to compare the drug treatment group, positive control group, and blank control group. The results were expressed as mean ± standard deviation (SD). Differences were considered statistically significant at P < 0.05.

## Section: Results

Generation of a virtual compound library against STAT3 using the cRNN-ased generative model. A schematic illustration of library using GDL methods. B chemical space of generated space (gray dot), source space (red dot), and target space (blue dot) by transfer learning. C the distributions of molecular weight, logP, QED, and logS of targeted data and the generated data by GDL generation methods

HG106 and HG110 efficiently suppress cancer cell growth. A representative image (left panels) and quantification (right panels) of concentration-manner colony formation assays of cancer cells treating with HG106 and HG110, respectively. B bright-field images of soft agar colony formation of A549 cells treated with HG106 and HG110, respectively. All the data were presented as Mean±S.D. Statistical analysis was conducted by one-way ANOVA (***p < 0.001)

A The percentage of apoptotic cells quantitatively measured by using flow cytometry for the H441 cells stained by Annexin V/PI. Cells were treated with HG106 and HG110 at concentration of 5 uM for 24 h, respectively. DMSO was selected as control. B Immunoblot bands and quantitative measurement revealed apoptosis-associated protein expression levels after dose-dependent treatment against H441 cells. C Immunoblot analysis reveals the effect of HG110 on the phosphorylation levels of STAT3 at Tyr705 compared with HG106 at 24 h in H411 and H1299 cells. GAPDH was selected as inner standard. D HG110 suppressed phosphorylation levels of STAT3 at 24 h. E Immunofluorescent staining revealed the impacts of HG110 on IL6-promoted nucleus translocation of STAT3 in H441 cells. Scale bar is XX um. All the data were presented as Mean±S.D. Statistical analysis was conducted by one-way ANOVA (*p < 0.05, **p < 0.01, ***p < 0.001)

Molecular dynamic simulation to reveal the binding model of HG106 and HG110 with STAT3. A Molecular structure, binding model, and planar residue–ligand interaction of HG106. B Analysis of residue root mean square deviation (RMSD) in compound HG106 and STAT3 complex for protein (STAT3) stability. C Profile of hydrogen bonds between HG106 and STAT3 among molecular dynamic simulation. D Molecular structure, binding model, and planar residue–ligand interaction of HG110. E Analysis of residue root mean square deviation (RMSD) in compound HG110 and STAT3 complex for protein (STAT3) stability. F Profile of hydrogen bonds between HG110 and STAT3 among molecular dynamic simulation

## Section: Results › Generation of molecular libraries using generative deep learning

We employed a generative deep learning approach to construct a diverse library of molecular structures specifically designed to target the active site of STAT3 (Fig. 3A). Initially, we curated a dataset of STAT3 inhibitors exhibiting high biological activity (IC50 < 1000 nM) from the ChEMBL database (n = 411) as the target dataset. The AlogP value of STAT3 was selected as standard criteria for the subsequential and crude screening (Supplementary Fig. S1). Additionally, approximately 12.0 million compounds from the ZINC database were utilized as the source dataset, providing a broad spectrum of pharmacophoric fragments for model training (Supplementary Fig. S2). Using these datasets, we generated a library of 15,678 unique molecular structures, with any duplicates meticulously removed to ensure novelty.

The generated molecules were visualized using Uniform Manifold Approximation and Projection (UMAP) to assess their distribution in the chemical space relative to both the source and target datasets. UMAP is a dimensionality reduction technique that visualizes high-dimensional data by preserving both local and global structures, enabling a more interpretable representation of complex data distributions [40]. It was used in this study to assess the distribution of generated molecules, as it effectively reduces the high-dimensional molecular feature space into two dimensions, allowing for a clear visualization of the relationships between source, target, and generated data, and providing insights into the diversity and similarity of the molecular structures [41]. As shown in Fig. 3B, the generated molecules (represented by gray dots) demonstrate a clear transition from the chemical space of the source data (red dots) towards that of the target data (blue dots). This distribution indicates that the generative model effectively captured and transferred the relevant features from the source data to the target dataset, creating novel molecular entities aligned with the desired chemical properties of STAT3 inhibitors.

Further analysis of the physicochemical properties of the generated molecules, presented in Fig. 3C, revealed that 98.3% of the molecular scaffolds in the generated library were structurally distinct from those in both the source and target datasets. This substantial scaffold diversity suggests the successful generation of novel chemical space, providing a robust foundation for subsequent molecular docking and virtual screening efforts aimed at identifying promising STAT3 inhibitors.

Generation of a virtual compound library against STAT3 using the cRNN-ased generative model. A schematic illustration of library using GDL methods. B chemical space of generated space (gray dot), source space (red dot), and target space (blue dot) by transfer learning. C the distributions of molecular weight, logP, QED, and logS of targeted data and the generated data by GDL generation methods

## Section: Results › Virtual screening and molecular docking

After generation the library, we then conducted the virtual screening to obtain the potential STAT3 inhibitors (Fig. 2) with STAT3 protein structure (Supplementary Fig. S3) with optimized method (Supplementary Fig. S4). The screened molecules were presented using tree maps (TMAPs) according to the following features, including RECP-based structural similarity, molecular properties, and docking scores (Supplementary Fig. S5). These TMAPs well presented the unsupervised visualization of high-dimensional data with creating a 2D layout of spanning tree in the chemical space. From the top-ranked 95 molecules (Supplementary Fig. S6), we selected the molecules from the current library containing benzotriazole scaffold, and further conducted the biological screening to identify higher anticancer activity.

## Section: Results › HG106 and HG110 inhibits the viability of NSCLC cells

Following the outcomes of the virtual screening, we selected 90 novel small-molecule compounds for synthesis. These synthesized compounds were subsequently evaluated for their cytotoxic effects against NSCLC cell lines NCI-H441 and NCI-H1299. Among them, two compounds, i.e., HG106 and HG110, exhibited a significantly enhanced inhibitory effect on the proliferation of both H441 and H1299 cells (Supplementary Fig. S7A), thus identifying HG106 and HG110 as a lead candidate for further investigations. Subsequently, HG106 and HG110 were tested on a panel of four NSCLC cell lines (NCI-H441, NCI-H1299, NCI-H522, A549) and two normal cell lines (GES-1, MRC-5) over a 72-h incubation, and IC50 values were determined using the SRB assay. The results demonstrated that HG106 and HG110 markedly suppressed the viability of A549, NCI-H522, NCI-H441, and NCI-H1299 cells (Supplementary Fig. S7B). Furthermore, HG106 and HG110 exhibited minimal cytotoxicity towards normal human cell lines, including MRC-5 fibroblasts and GES-1 gastric epithelial cells, indicating a favorable safety profile.

## Section: Results › HG106 and HG110 inhibits the proliferation of NSCLC cells

HG106 and HG110 can efficiently suppress proliferation of lung cancer cells (A549, H522 H441, and H1299) compared with normal cells (MRC-5 and GES-1). To further evaluate cancer cell growth, colony formation assays was conducted. As given in Fig. 4A, NSCLC cell lines NCI-H441, NCI-H1299, NCI-H522, and A549 were dosage-dependent (0.5 and 1.0 μM) exposed to HG106 and HG110 for 7 to 10 days. The results demonstrated that HG106 and HG110 significantly suppressed colony formation in all tested NSCLC cell lines at a concentration of 1 μM Fig. 4A. This inhibitory effect was further corroborated by a soft agar colony formation assay, which yielded consistent results (Fig. 4B). Collectively, these findings indicate that HG106 and HG110 effectively inhibits the proliferation of NSCLC cells in vitro.

HG106 and HG110 efficiently suppress cancer cell growth. A representative image (left panels) and quantification (right panels) of concentration-manner colony formation assays of cancer cells treating with HG106 and HG110, respectively. B bright-field images of soft agar colony formation of A549 cells treated with HG106 and HG110, respectively. All the data were presented as Mean±S.D. Statistical analysis was conducted by one-way ANOVA (***p < 0.001)

## Section: Results › HG106 and HG110 promotes apoptosis in NSCLC cells

Flow cytometric analysis revealed that HG106 and HG110 significantly enhanced apoptotic cell death in H441 cells compared to the control group (Fig. 5A). This pro-apoptotic effect was further substantiated by western blot analysis, which demonstrated an upregulation of the pro-apoptotic protein Bax and the effector protein caspase-3, alongside a concurrent downregulation of the anti-apoptotic protein Bcl-2 following HG106 and HG110 treatment (Fig. 5B, C). These findings suggest that HG106 and HG110 induce apoptosis in H441 cells through the modulation of key apoptotic regulators.

A The percentage of apoptotic cells quantitatively measured by using flow cytometry for the H441 cells stained by Annexin V/PI. Cells were treated with HG106 and HG110 at concentration of 5 uM for 24 h, respectively. DMSO was selected as control. B Immunoblot bands and quantitative measurement revealed apoptosis-associated protein expression levels after dose-dependent treatment against H441 cells. C Immunoblot analysis reveals the effect of HG110 on the phosphorylation levels of STAT3 at Tyr705 compared with HG106 at 24 h in H411 and H1299 cells. GAPDH was selected as inner standard. D HG110 suppressed phosphorylation levels of STAT3 at 24 h. E Immunofluorescent staining revealed the impacts of HG110 on IL6-promoted nucleus translocation of STAT3 in H441 cells. Scale bar is XX um. All the data were presented as Mean±S.D. Statistical analysis was conducted by one-way ANOVA (*p < 0.05, **p < 0.01, ***p < 0.001)

## Section: Results › HG106 and HG110 exert anti-tumor activity by suppressing the activation of STAT3

Western blot analysis was employed to evaluate the inhibitory effect of HG106 and HG110 on STAT3 activation in H441 and H1299 cells following treatment with various concentrations of HG106 or HG110 for 24 h. The results indicated that HG106 and HG110 at a concentration of 5 μM significantly suppressed the phosphorylation of STAT3 (Fig. 5D–F). Additionally, immunofluorescence staining demonstrated that HG106 and HG110 treatment led to a notable reduction in nuclear STAT3 levels, suggesting an inhibition of STAT3 nuclear translocation (Fig. 5G).

## Section: Results › Binding model analysis and molecular dynamics simulations

As above-mentioned analysis, HG106 and HG110 presented the excellent anti-proliferation and suppression phosphorylation of STAT3 in vitro. In order to analyze the binding model between STAT3 and HG106 or HG110, we obtained the potential binding conformation of STAT3-HG106 and STAT3-HG110 by molecular docking.

As given in Fig. 6A, HG106 molecules well docked into the STAT3 bioactive pocket, which was widely used to design STAT3 inhibitors [36], and docking score was − 8.5 kcal/mol. By presenting using LigPlot software, we can observe that residue of STAT3, including Trp623, Gln635, Ser636, Val637, Tyr640, Tyr657, and Ile659 were interacted with HG106 by the hydrophilic interaction. Moreover, the amino group of Glu638 interacted with nitrogen atom of triazole ring by hydrogen bond, and NH2 of Gln644 amide group interacted with oxygen of methoxyl of HG106 by hydrogen bond. To further analyze the structure of STAT3-HG106, molecular dynamic simulation was conducted to evaluate the stabilization in 200 ns. Among the 200 ns simulation, system fast achieved the equilibrium at around 10 ns (Supplementary Fig. S8A), and HG106 molecule can stabilize to bind with the pocket of STAT3. To determine the fluctuating residues, we analyzed the RMSD of residue of residues among the 200 ns simulation, and alignment between RMSD and RMSF of residues (Fig. 6B) clearly revealed that the HG106 molecules can strongly interact with the residue of active pockets. The profile of hydrogen bonds altered during the simulation, and the hydrogen bond (Fig. 6C) between methoxyl group and Gln644 was stable.

The free energy landscape was conducted to determine the collective atomic motions during the simulation process with principal component analysis (PCA). As given in Supplementary Fig. S8B, C, the dark blue indicated the minimum valley of system energy, while the difference between top point and lower point is only 1.35 kcal/mol. Additionally, there are three minimum points during the simulation process, and difference is very small. These results may be caused by the weak hydrogen bonds between STAT3 and HG106, consistent with fluctuations of hydrogen bonds (Fig. 6C).

Similarly, HG110 molecules also well docked into the STAT3 bioactive pocket consistent with HG106. By analysis of binding model (Fig. 6D), we can observe that residue of STAT3 including Gln635, Trp623, Val637, Glu638, Pro639, Tyr640, Ile659, and Ser636 were interacted with HG110 by the hydrophilic interaction. Additionally, the NH2 of Gln644 amide part strongly interacted with two methoxyl groups of HG110 by forming hydrogen bonds, while hydroxyl of Tyr657 interacted with nitrogen atom of triazole ring by hydrogen bond. Among the 200 ns simulation (Supplementary Fig. S9A), we can observe that the RMSD of ligand (Fig. 6E) was more stable compared with HG106, and the comparison between RMSD and RMSF of residues also validated that HG110 molecule strongly interacted with STAT3 active pocket (Fig. 6E). Compared with HG106, hydrogen bonds (Gln644 and Tyr657) between HG110 and STAT3 were far more and stable than HG106, implying that the HG110 molecule was more strongly interacted with STAT3 compared with HG106, which is consistent with the above-mentioned biological activities (Fig. 5C). Moreover, the free energy landscape of STAT3-HG110 (Supplementary Fig. S9B, C), only one minimum point was observed compared with STAT3-HG106 complex (Supplementary Fig. S8B, C). This result also validated that stronger hydrogen bonds can stabilize the protein–ligand complex.

By further analysis of RMSD of HG106 and HG110 molecules during the 200 ns simulation, we observed that average RMSD value of HG106 and HG110 were 0.19 Å and 0.16 Å, respectively. This lower average RMSD value of these ligands indicated higher stability. Subsequentially, we also conducted the quantum calculation to obtain the frontier molecular orbitals of HG106 and HG110. The energy gap between the LUMO and HOMO is often used to determine the kinetic stability. As shown in Supplementary Fig. S10A, B, the energy gap of HG110 (9.6300 eV) was higher than HG106 (9.4757 eV), implying that lower reactivity of HG110 and suppression of STAT3 may be originated from the stronger binding, not irreversible covalent binding.

Molecular dynamic simulation to reveal the binding model of HG106 and HG110 with STAT3. A Molecular structure, binding model, and planar residue–ligand interaction of HG106. B Analysis of residue root mean square deviation (RMSD) in compound HG106 and STAT3 complex for protein (STAT3) stability. C Profile of hydrogen bonds between HG106 and STAT3 among molecular dynamic simulation. D Molecular structure, binding model, and planar residue–ligand interaction of HG110. E Analysis of residue root mean square deviation (RMSD) in compound HG110 and STAT3 complex for protein (STAT3) stability. F Profile of hydrogen bonds between HG110 and STAT3 among molecular dynamic simulation

## Section: Discussion

The aberrant activation of STAT3 in vivo plays a pivotal role in driving cancer cell proliferation and regulating multiple tumor-associated pathways, including cell cycle [36], apoptosis resistance [42], angiogenesis [43], and immune evasion [44]. Targeting the overactivation of STAT3, particularly its phosphorylation at Tyr705, is therefore a promising therapeutic strategy for cancer treatment. In this study, we employed a generative deep learning model to design and synthesize a library of potential STAT3 inhibitors. From this library, two lead compounds, HG106 and HG110, were identified, both derived from a benzotriazole scaffold. Notably, HG110 demonstrated superior efficacy compared to HG106 in inhibiting STAT3 phosphorylation at Tyr705, leading to enhanced induction of apoptosis in NSCLC cells.

In vivo experiments further confirmed the therapeutic potential of HG110, showing its ability to effectively inhibit IL6-induced translocation of phosphorylated STAT3 (p-STAT3) to the nucleus, thereby disrupting STAT3-mediated transcriptional activity. Upon IL6 binding to its receptor, gp130, JAK1 and JAK2 kinases are activated, leading to phosphorylation of STAT3 at Tyr705 [45, 46]. This phosphorylation triggers the dimerization of STAT3, which subsequently translocates to the nucleus to initiate the transcription of genes involved in cell survival, proliferation, and immune evasion [47]. Our studies indicate that HG110 effectively inhibits this phosphorylation step, thereby preventing the nuclear translocation of STAT3 and its downstream transcriptional activity. Molecular dynamics simulations provided additional insights, revealing that HG110 forms stable interactions with key residues in the active pocket of STAT3, thus stabilizing the STAT3-HG110 complex and enhancing its inhibitory effect. These findings collectively highlight HG110 as a potent and selective STAT3 inhibitor with the capability to suppress STAT3 phosphorylation and promote apoptosis, underscoring its potential application in cancer therapy. Further preclinical and clinical studies are warranted to validate these results and explore the full therapeutic potential of HG110 in STAT3-driven malignancies.

Direct binding to the active site of STAT3 can interfere with its phosphorylation at Tyr705, subsequently affecting cellular activities. In cancer cells, receptor-bound JAK kinases, primarily JAK1 and JAK2, are activated upon cytokine signaling and phosphorylate the cytoplasmic domain of the receptor [47]. This phosphorylation generates docking sites for STAT3, allowing it to bind via its SH2 domain. The receptor-associated JAKs then phosphorylate STAT3 at Tyr705, which induces its dimerization and translocation to the nucleus [48]. Once in the nucleus, STAT3 modulates the expression of various target genes involved in inflammatory responses, cancer progression, and immune evasion [47]. Several studies have demonstrated the potential of targeting STAT3 phosphorylation as a therapeutic strategy: Zhang et al. reported [49] that S3I-201.1066 binds to the STAT3 SH2 domain and disrupts STAT3 phosphorylation in vivo; Gabriele et al. [50] found that thiosulfonic compounds selectively bind the STAT3 SH2 domain, effectively inhibiting cancer cell proliferation; and He et al. [51] described the use of oral STAT3 inhibitors to suppress gastric cancer proliferation by downregulating STAT3 phosphorylation at Tyr705. These findings highlight the growing promise of targeting the STAT3 active site with emerging inhibitors as a therapeutic strategy for cancer.

Traditional drug discovery methodologies have often been hindered by high costs, low efficiency, and a dependence on the experience and intuition of medicinal chemists, which can limit the exploration of chemical space. Consequently, scaffold designs and structural modifications are typically constrained to well-known chemical entities. In contrast, the advent of machine learning (ML)-aided drug design has revolutionized the field by enabling a more extensive exploration of chemical space and enhancing the hit rate of targeted compounds. By leveraging sophisticated algorithms and comprehensive chemical datasets, ML models can predict the biological activities and physicochemical properties of molecules with high accuracy, significantly expediting the drug discovery process.

Various machine learning architectures, including Deep Neural Networks (DNNs), Convolutional Neural Networks (CNNs), Recurrent Neural Networks (RNNs), and Generative Adversarial Networks (GANs), have demonstrated remarkable potential in drug design. These models can efficiently handle complex chemical data, predict molecular properties, and forecast interactions with biological targets. In particular, generative models have introduced novel approaches to drug discovery by learning the probability distribution of training data, extracting key structural features, and generating novel compounds with the desired properties. This capability allows for the generation of new molecules that resemble known active compounds but possess unique structural variations that could lead to improved efficacy and reduced toxicity. In our investigation, we introduced the GDL to build the potential STAT3 inhibitors, which were trained from ZINC database and fine-tuned by current STAT3 inhibitors (Fig. 3A). This virtual molecular library contained the enough chemical space exploration and provided more insights to develop emerging chemical entities as potential STAT3 inhibitors. After screening, we selected the potential molecules, which contained the benzotriazole scaffold and modification with various chemical space exploration.

The application of machine learning extends beyond molecule generation and encompasses a wide range of drug discovery activities, including predicting drug–protein interactions, assessing drug efficacy, and identifying safety biomarkers. These capabilities streamline complex workflows and increase the throughput of drug discovery pipelines. However, despite the significant advancements, several challenges persist. The success of ML models is contingent on the quality and diversity of training data, and there is an ongoing need to enhance the interpretability and transparency of these models to facilitate their integration into conventional drug discovery workflows.

The newly identified STAT3 inhibitors, including HG110, offer a promising therapeutic strategy for NSCLC by targeting the pivotal STAT3 signaling pathway, which plays a critical role in tumorigenesis, immune evasion, and metastasis [47]. These inhibitors work by directly binding to the SH2 domain or the active site of STAT3, preventing its phosphorylation at Tyr705, a crucial step for STAT3 activation and its subsequent nuclear translocation [50]. This inhibition disrupts STAT3’s ability to regulate gene expression involved in cell proliferation, survival, and immune modulation, offering a novel therapeutic approach. In comparison to current standard therapies, such as chemotherapy, EGFR inhibitors, and immune checkpoint inhibitors, STAT3 inhibitors provide several potential advantages. Chemotherapy, while effective, is often associated with significant off-target toxicity and limited efficacy in advanced or metastatic NSCLC [52]. EGFR inhibitors and ALK inhibitors target specific mutations but are limited by the development of resistance [53]. Immune checkpoint inhibitors, though revolutionary in treating NSCLC, are not effective in all patients and may result in immune-related adverse events [54]. STAT3 inhibitors, by targeting a central oncogenic pathway implicated in both tumor progression and resistance mechanisms, may overcome some of these limitations. Moreover, preliminary studies suggest these inhibitors are well tolerated with a manageable safety profile, presenting fewer systemic side effects compared to chemotherapy and fewer immune-related adverse events compared to checkpoint inhibitors. However, challenges remain, including the potential for resistance to STAT3 inhibition and the need for further clinical validation. When used in combination with other therapies, such as immune checkpoint inhibitors, STAT3 inhibitors could potentially enhance therapeutic outcomes, particularly in patients with resistant or refractory disease. Overall, while current therapies have provided significant survival benefits, the emerging STAT3 inhibitors represent a promising addition to the therapeutic armamentarium for NSCLC, with the potential to improve patient outcomes, especially in cases of resistance to traditional treatment modalities.

## Section: Conclusion

This study demonstrates that HG110, a novel small-molecule inhibitor, effectively suppresses NSCLC cell proliferation and induces apoptosis in vitro by targeting STAT3 phosphorylation. Mechanistically, HG110 inhibits STAT3 phosphorylation at Tyr705, disrupting STAT3-mediated oncogenic signaling pathways critical to tumor progression. In vivo, HG110 significantly reduces tumor growth in NSCLC xenograft models, underscoring its potential as an antitumor agent. These findings highlight HG110 as a promising therapeutic candidate for NSCLC treatment. Future research should prioritize optimizing its pharmacokinetic and pharmacodynamic properties to improve clinical applicability. Additionally, investigating the synergistic effects of HG110 in combination with current standard therapies—such as targeted therapies and immune checkpoint inhibitors—may further elucidate its broader therapeutic potential. In conclusion, this study provides a robust foundation for the continued development of HG110 as a novel and effective STAT3 inhibitor, addressing an important unmet need in NSCLC management.

## Section: Supplementary Information

Below is the link to the electronic supplementary material.

Supplementary file1 (DOCX 2306 KB)

## Section: Acknowledgements

We are grateful to Professor Chen Yihua’s research group for providing us with the small-molecule compounds. This work was supported by the National Natural Science Foundation of China (82060663, 82260716), Regional Key R&D Program of Ningxia Hui Automous Region(2023BEG02010).

## Section: Author contributions

Weiji Cai, Beier Jiang, Yichen Ying, Lei Ma, Jing Chen, and Tao Li designed and performed in vivo experiments; Beier Jiang contributed to machine learning- and molecular dynamics simulation-associated experiments; Weiji Cai, Beier Jiang, Yichen Ying, and Lei Ma provided cell lines and assisted with in vitro experiments; Beier Jiang and Weiji Cai analyzed the data and discussed the results; Jing Chen and Tao Li conceived and co-supervised the overall project and wrote the paper with contributions from all authors.

## Section: Data availability

No datasets were generated or analysed during the current study.

## Section: Declarations › Conflict of interest

The authors declare no competing interests.

## Section: Contributor Information

Tao Li, Email: lit1979@163.com.

Jing Chen, Email: chenjing1979@163.com.

## Section: Associated Data

Supplementary file1 (DOCX 2306 KB)

## Section: Associated Data › Supplementary Materials

Supplementary file1 (DOCX 2306 KB)

## Section: Associated Data › Data Availability Statement

No datasets were generated or analysed during the current study.


---

# Identifying molecular subtypes and tumor microenvironment infiltration signatures in kidney renal clear cell carcinoma based on stemness-associated disulfidptosis genes by integrating machine learning, single-cell analyses and experimental validation

- **Authors:** Hongquan Liu, Xiaoqing Liang, Gonglin Tang, Xiaofeng Wang, Zhen Wang, Leijie Tong, Qiancheng Mao, Jian Ma, Jitao Wu
- **Issuer:** Heliyon
- **Type:** Scientific article
- **Published:** 2024-02-13
- **Language:** en
- **DOI:** 10.1016/j.heliyon.2024.e26094
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38390172/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Clear cell renal cell carcinoma (ccRCC) is an aggressive malignant tumor. Disulfidptosis is a new programmed cell death mechanism, which is characterized by the abnormal accumulation of intracellular disulfides that are highly toxic to cells. However, the contribution of disulfidptosis to ccRCC progression has not been fully clarified. In this study, two different molecular subtypes related to disulfidptosis were identified in ccRCC patients by the non-negative matrix factorization (NMF) algorithm. The cluster 1 was characterized by a worse prognosis and higher mRNAsi levels. Then, difference analysis and weighted gene co-expression network analysis (WGCNA) were conducted to search modular genes that are highly associated with tumor stemness and tumor microenvironment. Subsequently, a SADG signature containing nine genes was constructed stepwise by WGCNA and least absolute shrinkage and selection operator (LASSO) Cox regression analysis. The high-risk score group had a worse outcome, and immune regulation and metabolic signatures might be responsible for cancer progression in the high-risk group. After that, a predictive nomogram was constructed, and the predicting power of the risk model was verified using inter and three independent external validation datasets. Nine SADGs were shown to significantly correlate with immune infiltration, tumor mutation burden (TMB), microsatellite instability (MSI) and immune checkpoint. In addition, based on the single-cell RNA sequencing dataset (GSE139555), the distribution and expression of nine hub genes in various types of immune cells were analyzed. Finally, the expression level of the nine genes was verified in clinical samples by qRT-PCR.

## Section: Introduction

Renal cell carcinoma (RCC) is a malignant solid tumor with a high prevalence. In 2023, it is estimated that more than 70,000 new cases of RCC will be diagnosed, along with 13,780 deaths, according to the survey of US statistics [1]. RCC consists of three important histological subtypes—clear cell RCC (ccRCC), papillary RCC, and chromophobe RCC. Among these, ccRCC accounts for more than 70% of RCC incidence [2,3]. Surgery remains the primary therapy for early-stage localized ccRCC patients, yet more than 30% of them suffer from post-surgery recurrence or develop metastases [4,5]. Radiotherapy and chemotherapy are not effective enough in treating advanced metastatic renal cancer, so the clinical management for those patients is extremely limited with a 5-year survival rate of 13% [6]. Recently, targeted therapy and immunotherapy have brought encouraging hope for advanced-stage ccRCC. Current treatments, however, lack specificity, and drug resistance often occurs. Traditional targeted treatment and immunotherapy remain to be ineffective for some patients, leading to generally poor prognoses [7,8]. Thus, exploring the mechanism and prognostic markers of ccRCC is a promising direction for further kidney cancer research.

Tumorigenesis and progression are regulated by the active and controlled cell death process known as programmed cell death (PCD), which is driven by genes [9]. Disulfidptosis, a novel mechanism of cell death, is mediated by the susceptibility of the actin cytoskeleton to disulfide stress, which occurs with the unusual accumulation of disulfides and can be harmful to cells, inhibiting the survival and proliferation of cancer cells [10]. In glucose-starved cells with overexpressed SLC7A11, disulfidptosis is triggered by the accumulation of intracellular disulfides. Liu et al. found that increased SLC7A11 expression in renal cancer cells under glucose deprivation promotes the depletion of nicotinamide adenine dinucleotide phosphate (NADPH) in the cytoplasm [11]. NADPH often offers reducing power to combat disulfide stress and keep cells in a state of equilibrium. However, in the absence of glucose, the pentose phosphate pathway (PPP)'s ability to produce NADPH from glucose is constrained. High rates of cystine uptake mediated by overexpressed SLC7A11 further depletes intracellular NADPH, causing its depletion, which induces multiple intermolecular disulfide-bond formation between actin cytoskeleton proteins and filament (F-actin) contraction, inducing disulfide stress and triggering disulfidptosis, which is toxic to cells [12]. These studies illustrated the significance of disulfidptosis to tumor progression, which may be a focus of cancer immunotherapy in the future. Besides, one of the most important characteristics influencing cancer metastasis is cancer stemness. A particularly promising strategy for cancer treatment is to target cancer stemness [13]. Meanwhile, the development and proliferation of malignant tumors are related to features of the tumor microenvironment, and systemic therapy responses may be impacted by these characteristics [14].

As a new cell death, disulfidptosis holds importance in exploring potentially powerful therapeutic strategies for cancer. The relationship between disulfidptosis and ccRCC patients remains unknown. In our study, we sought to thoroughly explore the molecular characteristics of disulfidptosis-related genes (DRGs) in renal cancer. This study demonstrates the significance of DRGs in the progression of renal cancer and establishes a basis for the therapeutic application of disulfidptosis regulators in kidney cancer. We established and validated a stemness-associated disulfidptosis gene (SADG) signature, which demonstrated high accuracy in estimating the long-term survival of ccRCC patients and response to immunotherapy with independent cohorts. This study holds great potential to provide a unique understanding of the significance of SADG in ccRCC progression and paves the way for the therapeutic application of disulfidptosis regulators in renal cancer.

## Section: Materials and methods

External cohorts used for model validation.

## Section: Materials and methods › Data download and processing

The RNA-seq and clinical data of TCGA-KIRC patients were downloaded from the cancer genome atlas (TCGA) website (https://portal.gdc.cancer.gov/). External validation datasets were downloaded from IMVIGOR210 (http://research-pub.gene.com/), ICGC-RECA (https://dcc.icgc.org/) and E-MTAB-1980 (https://www.ebi.ac.uk/biostudies/). The characteristics of eligible ccRCC patients included in this study were summarized in Supplementary Table 1. Single-cell sequencing data of ccRCC comes from the GEO database (https://www.ncbi.nlm.nih.gov/geo/, GSE139555). Before analysis, all TCGA RNA-seq data was normalized into transcripts per million (TPM) data. The patients with incomplete clinical survival information and expression were excluded from our study. A total of 88 disulfidptosis-related genes were obtained based on published literature (Supplementary Table 2) [11]. Genetic mutation data, including single-nucleotide variants (SNVs) and copy number variation (CNV), was downloaded from the UCSC Xena database (https://xena.ucsc.edu/).

## Section: Materials and methods › NMF clustering and survival analysis

Using the R package “coxph” to conduct univariate Cox analysis to find prognosis-related genes (p < 0.05). The non-negative matrix factorization (NMF) clustering was conducted based on expression data of 44 disulfidptosis-related genes (DRGs) to clustering TCGA-RCC samples (rank = 2:10, method = “brunet, nrun = 10”). After considering indicators such as cophenetic, dispersion, and silhouette, the best K value (K = 2) was determined. Kaplan-Meier (KM) survival analysis was conducted to identify the Overall survival (OS) difference between different NMF clusters.

## Section: Materials and methods › Prognostic risk model construction

All differential expression analysis was performed using the R package “DEseq2” with the following thresholds: adjusted p-value <0.01, |log2 fold change |> 1. The study initially conducted a difference analysis between two groups, NMF-cluster C1 and C2. Subsequently, the researchers employed weighted gene co-expression network analysis (WGCNA) to identify the co-expression module correlated with tumor stemness and tumor microenvironment [15]. Candidate module genes were identified by intersecting the key module genes obtained through WGCNA analysis with the differential genes of cancer and para-cancer in ccRCC patients. Subsequently, genes associated with ccRCC patients' overall survival were screened using univariate analysis. Finally, a stemness-associated disulfidptosis gene (SADG) signature for ccRCC patients was built using the Least Absolute Shrinkage and Operator (LASSO) Cox regression analysis. The risk score is evaluated according to the following formula:

Riskscore = ∑i=xnCoe(genei)*Exp(genei).

Coe(genei): the coefficient of each gene in the SADG signature.

Exp (genei): the relative expression level of each gene in this study.

After that, ccRCC patients were divided into high- and low-risk groups based on the optimal cut-off value for risk score. Kaplan-Meier analysis was conducted to compare the survival rate between high- and low-risk score groups. A nomogram was developed after LASSO and multivariate Cox regression analysis, which integrated the SADG signature and clinicopathological characteristics to predict survival probability. Next, using the R package “ggDCA” to draw decision curve analysis (DCA) and evaluate the predicting power and clinical benefit of the nomogram.

## Section: Materials and methods › Internal and external validation of the prognostic model

Patients with ccRCC from the TCGA were randomly allocated to training and test cohorts at a 7:3 ratio. In our study, in order to compare the overall survival (OS) and progression-free survival (PFS) in low- and high-risk cohorts, we conducted the survival analysis using the R packages "survminer" and "survival". Furthermore, clinical information correlated with the prognosis of patients was combined with riskscore to draw forest charts. Additionally, external datasets were used to validate the SADG signature. As shown in Table 1, three independent external cohorts were used for validating the SADG model.Table 1External cohorts used for model validation.Table 1NameWebsiteIMVIGOR210http://research-pub.gene.com/ICGC-RECAhttps://dcc.icgc.org/E-MTAB-1980https://www.ebi.ac.uk/biostudies/According to the same standards mentioned above, patients in the external cohorts were divided into high- and low-risk score groups. Survival analysis and ROC curve were drawn in these three validation cohorts.

External cohorts used for model validation.

## Section: Materials and methods › Functional enrichment analysis of differentially expressed genes

The R package “ClusterProfiler” was utilized to conduct GSEA analysis between high- and low-risk score groups. The annotation files were downloaded from MSigDB (https://www.gsea-msigdb.org/gsea/msigdb) and ConsensusPathDB (http://cpdb.molgen.mpg.de/) database.

## Section: Materials and methods › Immune infiltration analysis

In this study, the R package “ESTIMATE” was utilized for the estimation of tumor purity and stromal components in the tumor microenvironment (TME) between NMF-cluster C1 and C2 [16]. Moreover, we identified the different infiltrated immune cells between the high- and low-risk score groups based on the CIBERSORT algorithm (https://cibersort.stanford.edu/).

## Section: Materials and methods › Exploring of hub genes by single-cell sequencing

The Tumor Immune Single-Cell Hub (TISCH) (http://tisch.comp-genomics.org) is a scRNA-seq database that attempts to characterize TME at single-cell resolution. With corresponding clinical data, TISCH has more than 70 high-quality single-cell transcriptome datasets of 27 cancers. Based on this database, we analyzed the GSE139555 dataset to explore the heterogeneous expression pattern of nine prognostic genes in ccRCC cells and different immune cells at the single-cell level [17].

## Section: Materials and methods › Validation of nine SADGs by GEPIA

The Gene Expression Profiling Interactive Analysis (GEPIA) database (http://gepia2.cancer-pku.cn/index.html) was utilized for further validation and survival analysis. Based on the TCGA and GTEx databases, the information of gene expression for ccRCC and normal samples was gathered. Survival analysis was conducted based on the survival data of the TCGA database.

## Section: Materials and methods › Collection of human tissue specimens and quantitative real-time polymerase chain reaction (qRT-PCR)

Authorized by the ethics committee of the affiliated Yantai Yuhuangding Hospital of Qingdao University (No.2023-314), ccRCC tissues and adjacent normal samples from eight patients who underwent radical or partial nephrectomy were gathered. Two different pathologists independently verified the pathological specimens. Using SteadyPure Quick RNA Extraction Kit (Accurate Biology, China), we extracted total RNA from clinical samples. Subsequently, The SYBR Green Premix Pro Taq HS qPCR Kit and Rox Reference Dye (Accurate Biology, China) were used for the qRT-PCR procedure. Based on the 2®−ΔΔCT calculation method, we calculated the mRNA expression of core genes. For each experiment, three multiple holes were set. The primer sequences used can be found in Supplementary Table 3.

## Section: Materials and methods › Statistics

All of the bioinformatics analyses were conducted using the software R version 4.2.0. For comparisons between two independent samples and comparisons among multiple samples for non-parametric data, respectively, we utilized the Wilcoxon test and the Kruskal–Wallis test. For parametric data, t-tests and one-way ANOVA were utilized. We conducted the survival study using the Kaplan-Meier method and the log-rank test. For each analysis, p < 0.05 was considered statistically significant.

## Section: Results

Workflow of this study.

Identification of disulfidptosis -related genes related NMF-cluster.

(A) TCGA-KIRC patients were divided into two distinct gene cluster by using non-negative matrix factorization (NMF) based on disulfidptosis -related genes.

(B) Survial analysis of OS between NMF-cluster 1 and NMF-cluster 2 in TCGA-KIRC patients.

(C) Expression profile of disulfidptosis-related genes and the relationship with clinical information shaped by NMF-cluster 1 and NMF-cluster 2.

(D) The mDNAsi and EREG-mDNAsi difference between NMF-cluster 1 and NMF-cluster 2.

(E) The mRNAsi and EREG-mRNAsi difference between NMF-cluster 1 and NMF-cluster 2.

(F) The stromal score, immune score and ESTIMATE score difference between NMF-cluster 1 and NMF-cluster 2.

Construction of the stemness-associated disulfidptosis gene (SADG) signature.

(A) Difference expressed genes between NMF-cluster C1 and NMF-cluster C2.

(B) Module-trait associations based on the WGCNA.

(C) The relationship between WGCNA gene modules with stemness index and tumor microenvironment.

(D) Volcano plot showed the DEGs between cancer and para-cancer tissue in TCGA-KIRC patients.

(E) Venn plot showed intersection of gene lists between up-expressed genes in tumor tissue and hub genes in WGCNA.

(F) Forest map showed univariate Cox regression analysis result of 71 cell stemness and TME associated disulfidptosis-related DEGs.

(G, H) Least absolute shrinkage and selection operator (LASSO) regression analysis.

The coefficient of each gene in SADG signature.

Kaplan-Meier analysis of PFS and OS between low- and high-risk score subgroup in the entire, internal training sets and validation sets.

(A) K-M plot of PFS of entire TCGA-KIRC set.

(B) K-M plot of OS of entire TCGA-KIRC set.

(C) K-M plot of PFS of TCGA-KIRC test set.

(D) K-M plot of OS of TCGA-KIRC test set.

(E) K-M plot of PFS of TCGA-KIRC training set.

(F) K-M plot of OS of TCGA-KIRC training set.

(K–M: Kaplan-Meier analysis, OS: overall survival, PFS: progression-free survival).

Kaplan-Meier analysis of OS between low- and high-risk score subgroup in the external validation sets.

(A) Survival curve for OS in the IMvigor210.

(B) 1-,3-,5-year ROC curves of SADG signature in the IMvigor210.

(C) Survival curve for OS in the ICGC-RECA.

(D) 1-,3-,5-year ROC curves of SADG signature in the ICGC-RECA.

(E) Survival curve for OS in the E-MTAB-1980.

(F) 1-,3-,5-year ROC curves of SADG signature in the E-MTAB-1980.

Development of a clinical practicability nomogram.

(A) Development of a nomogram based on TNM stage, gender, age, stage and riskscore in internal training dataset.

(B) Calibration curves for 1-, 3-, and 5-year survival rates in the internal training dataset.

(C) DCA curves of the internal training dataset.

(D) The nomogram based on TNM stage, gender, age, stage and riskscore in internal test dataset.

(E) Calibration curves for 1-, 3-, and 5-year survival rates in the internal test dataset.

(F) DCA curves of the internal test dataset.

(DCA: decision curve analysis, (*p-value <0.05; **p-value <0.01; ***p-value <0.001).

Univariate and multivariate Cox analyses of SADG and clinical factors.

(A) Univariate Cox analysis of SADG and clinical factors (Age, gender and stage).

(B) Multivariate Cox analysis of SADG and clinical factors (Age, gender and stage).

(C, D, E) The ROC curves for 1-, 3-, and 5-year prediction of the nomogram, and AUC values are calculated.

Immune infiltration analysis associated with SADG signature.

(A) Immune checkpoints expression profile shaped by SADGs in TCGA-KIRC patients.

(B) Box plot showed tumor immune subtype influenced by SADGs.

(C, D, E) The difference of Immune score, stromal score and tumor purity between low- and high-riskscore group in TCGA-KIRC patients.

Immune infiltration analysis associated with SADG signature.

(A) Box plot display the ssGSEA analysis result of SADG in TCGA-KIRC patients.

(B) Immune cell infiltration difference between low- and high-risk score group.

Gene set enrichment analysis result.

(A) GSEA functional enrichment analysis of high-risk group.

(B) GSEA functional enrichment analysis of low-risk group.

Expression patterns of nine key SADGs in single-cell RNA sequencing of ccRCC.

(A) Clusters for ccRCC cases.

(B) UMAP plot of 11 predominant cell types in the ccRCC tumor microenvironment. (C)Visualization of percentage of cell number distribution of each cell type in all ccRCC cases.

(D) The distribution of cells in each ccRCC case in GSE139555.

(E) UMAP plots for visualizing the distribution of nine DRGs in various types of cells.

(F) Violin plot for displaying the expression levels of nine DRGs in each cell types.

The expression of nine SADGs at the single-cell level after stratification based on stage. The expression of (A) MYO1F, (B) FMNL1, (C) FCGR1B, (D) TNFAIP8L2, (E) CYTH4, (F) NCF4, (G) TNFSF13B, (H) POU2F2 and (I) SLAMF1 at the single-cell level after stratification based on stage.

Somatic mutation landscape.

(A) The waterfall plot showed the top 15 most mutated genes individually in high-risk group.

(B) The waterfall plot showed the top 15 most mutated genes individually in low-risk group.

(C) Scatter diagram showed the relationship between risk score and tumor Mutations burden.

(D–E) Association between risk score and MSI (D) as well as TIDE (E).

Expression pattern validation and the relationship between the expression of the nine SADGs and the prognosis of ccRCC patients.

(A) Expression levels of the nine SADGs in ccRCC and normal tissues from the GEPIA database.

(B) The prognostic value of the nine SADGs expression ccRCC overall survival (OS).

The relative expression levels of the nine SADGs in ccRCC tumor tissues and para-cancerous tissues. The relative expression levels of (A) MYO1F, (B) FMNL1, (C) FCGR1B, (D) TNFAIP8L2, (E) CYTH4, (F) NCF4, (G) TNFSF13B, (H) POU2F2 and (I) SLAMF1 in ccRCC tumor tissues and para-cancerous tissues.

## Section: Results › NMF clustering based on disulfidptosis-related genes (DRGs) in patients with ccRCC

The whole workflow of our study is presented in Fig. 1. Firstly, the “coxph” function in the R package “survival” was performed to conduct univariate Cox regression analysis, and 44 OS-related DRGs were found (p < 0.05). Next, using NMF clustering, we discovered two ccRCC subtypes associated with DRGs according to the filter standard (Fig. 2A and Supplementary Fig. 1). The KM curves showed that the OS of patients in cluster 1 was better than in cluster 2 (Fig. 2B). The DRGs expression profile of ccRCC patients is divided into two clusters (Fig. 2C).Fig. 1Workflow of this study.Fig. 1Fig. 2Identification of disulfidptosis -related genes related NMF-cluster.(A) TCGA-KIRC patients were divided into two distinct gene cluster by using non-negative matrix factorization (NMF) based on disulfidptosis -related genes.(B) Survial analysis of OS between NMF-cluster 1 and NMF-cluster 2 in TCGA-KIRC patients.(C) Expression profile of disulfidptosis-related genes and the relationship with clinical information shaped by NMF-cluster 1 and NMF-cluster 2.(D) The mDNAsi and EREG-mDNAsi difference between NMF-cluster 1 and NMF-cluster 2.(E) The mRNAsi and EREG-mRNAsi difference between NMF-cluster 1 and NMF-cluster 2.(F) The stromal score, immune score and ESTIMATE score difference between NMF-cluster 1 and NMF-cluster 2.Fig. 2

During cancer progression, cancer cells lose their differentiated phenotype and acquisition of characteristics similar to progenitor cells and stem cells. Tumor stem cells undergo a loss of their various differentiation phenotypes while simultaneously acquiring the ability of self-renewal and differentiation [18,19]. The stemness index (SI) is a commonly used metric in stemness research, and tumor stem cell-like features (mRNAsi) were used to describe it based on the mRNA expression file [18]. EREG-mRNAsi is a stemness index that is created through the use of a panel of genes that are associated with stemness and regulated by epigenetics. Upon comparing the two NMF-clusters, it was observed that cluster-c2 had higher mDNAsi, ERGE-mDNSsi, and EREG-mRNAsi, whereas cluster 1 exhibited higher mRNAsi levels (as illustrated in Fig. 2D and E). The TME represents a complex ecosystem and is comprised of stromal cells, endothelial cells, pericytes, and innate and adaptive immune cells [20]. Illustrating the interactions between cancer cells and TME will help improve therapeutic targets since contact-dependent communication may promote immune evasion and tumor progression [21,22]. In this study, the TME score (comprised of stromal score, immune score and ESTIMATE score) was compared between NMF-cluster 1 and NMF-cluster 2. The cluster 1 showed a lower stromal score but a higher immune score and ESTIMATE score, indicating that the patients in cluster 1 got more immunosuppressive cells and had a relatively worse prognostic outcome (Fig. 2F).

Workflow of this study.

Identification of disulfidptosis -related genes related NMF-cluster.

(A) TCGA-KIRC patients were divided into two distinct gene cluster by using non-negative matrix factorization (NMF) based on disulfidptosis -related genes.

(B) Survial analysis of OS between NMF-cluster 1 and NMF-cluster 2 in TCGA-KIRC patients.

(C) Expression profile of disulfidptosis-related genes and the relationship with clinical information shaped by NMF-cluster 1 and NMF-cluster 2.

(D) The mDNAsi and EREG-mDNAsi difference between NMF-cluster 1 and NMF-cluster 2.

(E) The mRNAsi and EREG-mRNAsi difference between NMF-cluster 1 and NMF-cluster 2.

(F) The stromal score, immune score and ESTIMATE score difference between NMF-cluster 1 and NMF-cluster 2.

## Section: Results › Identification and vilification of SADG signature

Firstly, differentially expressed genes (DEGs) analysis was conducted between NMF-cluster 1 and NMF-cluster 2, and 11509 DEGs were obtained (Fig. 3A, Supplementary Table 4). WGCNA is a systems biology method used to describe gene association patterns between different samples, which can be used to identify gene sets with highly synergistic changes and to identify candidate organisms based on the interconnection of gene sets and the relationship between gene sets and phenotypes marker genes or therapeutic targets. In our study, we used WCGNA to screen the DEGs related to cell stemness and TME by obtaining the most relevant modules (Fig. 3B). As shown in Fig. 3C, the co-expression pink module was significantly positively associated with cell stemness and TME (Supplementary Table 5). Next, differentially expressed analysis was carried out in cancer and para-cancer tissues in TCGA-KIRC transcriptome data (Fig. 3D). By taking the intersection of the up-expressed genes in tumor tissues and hubgenes from WGCNA, we obtained 71 stemness and TME associated disulfidptosis-related DEGs. After that, we screened genes that were closely correlated with OS based on univariate Cox regression analysis (Fig. 3E and F). Finally, LASSO and multiCox analysis identified nine signature genes: MYO1F, FMNL1, FCGR1B, TNFAIP8L2, CYTH4, NCF4, TNFSF13B, POU2F2 and SLAMF1 (Fig. 3G and H). The coefficient of each gene in the prognostic signature is shown in Table 2.Fig. 3Construction of the stemness-associated disulfidptosis gene (SADG) signature.(A) Difference expressed genes between NMF-cluster C1 and NMF-cluster C2.(B) Module-trait associations based on the WGCNA.(C) The relationship between WGCNA gene modules with stemness index and tumor microenvironment.(D) Volcano plot showed the DEGs between cancer and para-cancer tissue in TCGA-KIRC patients.(E) Venn plot showed intersection of gene lists between up-expressed genes in tumor tissue and hub genes in WGCNA.(F) Forest map showed univariate Cox regression analysis result of 71 cell stemness and TME associated disulfidptosis-related DEGs.(G, H) Least absolute shrinkage and selection operator (LASSO) regression analysis.Fig. 3Table 2The coefficient of each gene in SADG signature.Table 2Gene idEnsemble idcoefficientHazard ratioMYO1FENSG00000142347−0.83801.245(1.002–1.548)FMNL1ENSG000001849220.81041.488(1.171–1.890)FCGR1BENSG000002911350.35801.407(1.155–1.713)TNFAIP8L2ENSG00000163154−0.45911.245(1.001–1.549)CYTH4ENSG00000100055−0.51841.275(1.023–1.589)NCF4ENSG000001003650.49041.374(1.093–1.726)TNFSF13BENSG000001025240.29881.386(1.144–1.681)POU2F2ENSG000000282770.56201.486(1.214–1.819)SLAMF1ENSG00000117090−0.28111.216(1.016–1.455)Riskscore = (−0.8380 * exp MYO1F) + (0.8104 * exp FMNL1) + (0.3580 * exp FCGR1B) + (−0.4591 * exp TNFAIP8L2) + (−0.5184* exp CYTH4) + (0.4904 * exp NCF4) + (0.2988 * exp TNFSF13B) + (0.5620 * exp POU2F2) + (−0.2811 * exp SLAMF1).

In the end, we divided the patients from the TCGA-KIRC cohort into high- and low-risk groups based on the median of the riskscore. Longer OS and PFS were found in the low-risk group in the entire TCGA-KIRC set, internal training set and test set (Fig. 4A–F). The prognosis evaluation of the risk model was verified in external validation datasets IMVIGOR210, ICGC-RECA and E-MTAB-1980 (Fig. 5A–F).Fig. 4Kaplan-Meier analysis of PFS and OS between low- and high-risk score subgroup in the entire, internal training sets and validation sets.(A) K-M plot of PFS of entire TCGA-KIRC set.(B) K-M plot of OS of entire TCGA-KIRC set.(C) K-M plot of PFS of TCGA-KIRC test set.(D) K-M plot of OS of TCGA-KIRC test set.(E) K-M plot of PFS of TCGA-KIRC training set.(F) K-M plot of OS of TCGA-KIRC training set.(K–M: Kaplan-Meier analysis, OS: overall survival, PFS: progression-free survival).Fig. 4Fig. 5Kaplan-Meier analysis of OS between low- and high-risk score subgroup in the external validation sets.(A) Survival curve for OS in the IMvigor210.(B) 1-,3-,5-year ROC curves of SADG signature in the IMvigor210.(C) Survival curve for OS in the ICGC-RECA.(D) 1-,3-,5-year ROC curves of SADG signature in the ICGC-RECA.(E) Survival curve for OS in the E-MTAB-1980.(F) 1-,3-,5-year ROC curves of SADG signature in the E-MTAB-1980.Fig. 5

Construction of the stemness-associated disulfidptosis gene (SADG) signature.

(A) Difference expressed genes between NMF-cluster C1 and NMF-cluster C2.

(B) Module-trait associations based on the WGCNA.

(C) The relationship between WGCNA gene modules with stemness index and tumor microenvironment.

(D) Volcano plot showed the DEGs between cancer and para-cancer tissue in TCGA-KIRC patients.

(E) Venn plot showed intersection of gene lists between up-expressed genes in tumor tissue and hub genes in WGCNA.

(F) Forest map showed univariate Cox regression analysis result of 71 cell stemness and TME associated disulfidptosis-related DEGs.

(G, H) Least absolute shrinkage and selection operator (LASSO) regression analysis.

The coefficient of each gene in SADG signature.

Kaplan-Meier analysis of PFS and OS between low- and high-risk score subgroup in the entire, internal training sets and validation sets.

(A) K-M plot of PFS of entire TCGA-KIRC set.

(B) K-M plot of OS of entire TCGA-KIRC set.

(C) K-M plot of PFS of TCGA-KIRC test set.

(D) K-M plot of OS of TCGA-KIRC test set.

(E) K-M plot of PFS of TCGA-KIRC training set.

(F) K-M plot of OS of TCGA-KIRC training set.

(K–M: Kaplan-Meier analysis, OS: overall survival, PFS: progression-free survival).

Kaplan-Meier analysis of OS between low- and high-risk score subgroup in the external validation sets.

(A) Survival curve for OS in the IMvigor210.

(B) 1-,3-,5-year ROC curves of SADG signature in the IMvigor210.

(C) Survival curve for OS in the ICGC-RECA.

(D) 1-,3-,5-year ROC curves of SADG signature in the ICGC-RECA.

(E) Survival curve for OS in the E-MTAB-1980.

(F) 1-,3-,5-year ROC curves of SADG signature in the E-MTAB-1980.

## Section: Results › Nomogram construction and clinicopathological characteristic based on SADG prognostic signature

We constructed a clinical utility nomogram to explore the relationship between SADG and the clinicopathological characteristics of ccRCC patients. Clinical factors and riskscore were incorporated in the nomogram in the internal training set and test set (Fig. 6A–D). The prediction power of the nomogram was close to the ideal curve (Fig. 6B–E). The nomogram in this study has outstanding performance in predicting 1-,3- and 5- year OS, as shown in DCA curves (Fig. 6C–F). Using univariate and multivariate Cox analysis, we can find that the riskscore has independent predicting power in ccRCC patients (Fig. 7A and B). As shown in the receiver operating characteristic (ROC) curve (Fig. 7C–E), this nomogram that combined riskscore and clinicopathological characteristics has better predictive effectiveness in predicting 1-,3- and 5-yeas OS in patients with ccRCC than riskscore alone.Fig. 6Development of a clinical practicability nomogram.(A) Development of a nomogram based on TNM stage, gender, age, stage and riskscore in internal training dataset.(B) Calibration curves for 1-, 3-, and 5-year survival rates in the internal training dataset.(C) DCA curves of the internal training dataset.(D) The nomogram based on TNM stage, gender, age, stage and riskscore in internal test dataset.(E) Calibration curves for 1-, 3-, and 5-year survival rates in the internal test dataset.(F) DCA curves of the internal test dataset.(DCA: decision curve analysis, (*p-value <0.05; **p-value <0.01; ***p-value <0.001).Fig. 6Fig. 7Univariate and multivariate Cox analyses of SADG and clinical factors.(A) Univariate Cox analysis of SADG and clinical factors (Age, gender and stage).(B) Multivariate Cox analysis of SADG and clinical factors (Age, gender and stage).(C, D, E) The ROC curves for 1-, 3-, and 5-year prediction of the nomogram, and AUC values are calculated.Fig. 7

Development of a clinical practicability nomogram.

(A) Development of a nomogram based on TNM stage, gender, age, stage and riskscore in internal training dataset.

(B) Calibration curves for 1-, 3-, and 5-year survival rates in the internal training dataset.

(C) DCA curves of the internal training dataset.

(D) The nomogram based on TNM stage, gender, age, stage and riskscore in internal test dataset.

(E) Calibration curves for 1-, 3-, and 5-year survival rates in the internal test dataset.

(F) DCA curves of the internal test dataset.

(DCA: decision curve analysis, (*p-value <0.05; **p-value <0.01; ***p-value <0.001).

Univariate and multivariate Cox analyses of SADG and clinical factors.

(A) Univariate Cox analysis of SADG and clinical factors (Age, gender and stage).

(B) Multivariate Cox analysis of SADG and clinical factors (Age, gender and stage).

(C, D, E) The ROC curves for 1-, 3-, and 5-year prediction of the nomogram, and AUC values are calculated.

## Section: Results › Immune infiltration analysis associated with SADG signature

Shaped by SADGs, patients in the low- and high-risk groups showed different expression patterns of immune checkpoints. In the high-risk score subgroup, IFNG, PTPRC, LAG3, CD86, TNFRSF9, LGALS9, CD8A, CD40LG, TNFSF9, IL23A and CD80 are highly expressed (Fig. 8A). Previous studies have analyzed tumor samples in TCGA and identified six immune subtypes to characterize the immune landscape. Six immune subtypes were clustered, namely C1 (wound healing), C2 (IFN-g dominant), C3 (inflammatory), C4 (lymphocyte depleted), C5 (immunologically quiet) and C6 (TGF-β dominant) [23]. Among the six tumor immune subtypes, subtype C1 got the highest risk score (Fig. 8B). Furthermore, the high-risk subgroup had a higher immune score and stromal score but lower tumor purity (Fig. 8C–E). In addition, ssGSEA analysis showed that the high-risk score subgroup had a higher score in Inflammation−promoting, Tfh and Inflammation−promoting (Fig. 9A). The high-risk score group had more infiltration of CD8 cells, Treg cells, T cells CD4 memory resting and NK cells resting, which mainly conducted anti-tumor immunity (Fig. 9B).Fig. 8Immune infiltration analysis associated with SADG signature.(A) Immune checkpoints expression profile shaped by SADGs in TCGA-KIRC patients.(B) Box plot showed tumor immune subtype influenced by SADGs.(C, D, E) The difference of Immune score, stromal score and tumor purity between low- and high-riskscore group in TCGA-KIRC patients.Fig. 8Fig. 9Immune infiltration analysis associated with SADG signature.(A) Box plot display the ssGSEA analysis result of SADG in TCGA-KIRC patients.(B) Immune cell infiltration difference between low- and high-risk score group.Fig. 9

Immune infiltration analysis associated with SADG signature.

(A) Immune checkpoints expression profile shaped by SADGs in TCGA-KIRC patients.

(B) Box plot showed tumor immune subtype influenced by SADGs.

(C, D, E) The difference of Immune score, stromal score and tumor purity between low- and high-riskscore group in TCGA-KIRC patients.

Immune infiltration analysis associated with SADG signature.

(A) Box plot display the ssGSEA analysis result of SADG in TCGA-KIRC patients.

(B) Immune cell infiltration difference between low- and high-risk score group.

## Section: Results › SADGs-associated different functional pathways

In order to quest potential biological processes influenced by the SADGs, we used GSEA to explore the significant signaling pathway that high- and low-risk patients enriched in. As shown in Fig. 10A and B, high-risk patients were correlated with immune-associated processes, such as the chemokine signaling pathway, Nod-like receptor signaling pathway and primary immunodeficiency, etc. Meanwhile, the low-risk group was mainly enriched in the fatty acid metabolism, oxidative phosphorylation, PPAR signaling pathway, etc.Fig. 10Gene set enrichment analysis result.(A) GSEA functional enrichment analysis of high-risk group.(B) GSEA functional enrichment analysis of low-risk group.Fig. 10

Gene set enrichment analysis result.

(A) GSEA functional enrichment analysis of high-risk group.

(B) GSEA functional enrichment analysis of low-risk group.

## Section: Results › Correlation between hub genes and tumor immune microenvironment of ccRCC

The cellular heterogeneity of tumors and their surroundings are essentially mapped by single-cell RNA-sequencing (scRNA-seq), which offers transcript abundance of individual cells with high sensitivity. In the study, we analyzed the ccRCC data (GSE139555) using the TISCH database. UMAP-based cell clustering results in the identification of 25 significant clusters after dimensionality reduction (Fig. 11A). These clusters were designated as B cells, conventional CD4+ T cells (CD4Tconv), CD8 T+ cells, exhausted CD8+ T cells (CD8Tex), Dendritic Cells (DC), Mast Cells, endothelial cells, monocytes or macrophages (Mono/Macro), Natural Killer Cells (NK), plasmocytes, and Tprolif cells based on the lineage markers (Fig. 11B). As shown in Fig. 11 C, D, we visualized the proportion of cell numbers in all patients of GSE139555 and the distribution of cells in each case. Of the nine genes in our constructed model, MYO1F was mainly distributed in monocytes/macrophages, NK cells and DC cells. FMNL1 and TNFAIP8L2 were mainly expressed in monocytes/macrophages, DC cells and Tprolif cells. FCGR1B was mainly enriched in monocytes/macrophages and Tprolif cells. CYTH4 and TNFSF13B were mainly expressed in monocytes/macrophages and DC cells. NCF4 was mainly distributed in plasmocytes, Mast Cells, monocytes/macrophages, DC cells and B cells. POU2F2 was mainly enriched in monocytes/macrophages and B cells. SLAMF1 was mainly distributed in plasmocytes (Fig. 11E and F). Furthermore, we compared the expression of nine DRGs in various immune cell types of ccRCC patients stratified based on the TNM stage, and we found the expression of these hub genes in specific immune cells was statistically different in patients with different stages. As shown in Fig. 12A, the expression of MYO1F in conventional CD4+ T cells, CD8 T+ cells, exhausted CD8+ T cells, and NK cells was statistically different in patients with different TNM stages. FMNL1 expression was shown to be statistically different in B cells, conventional CD4+ T cells and monocytes/macrophages (Fig. 12B). No statistical difference was discovered in FCGR1B expression in immune cell types was discovered (Fig. 12C). There were statistically different TNFAIP8L2 expression levels in B cells, conventional CD4+ T cells, and monocytes/macrophages (Fig. 12D). And we discovered that the CYTH4 expression in various immune cell types was statistically significant, such as in conventional CD4+ T cells, CD8 T+ cells, exhausted CD8+ T cells, NK cells and Tprolif cells (Fig. 12E). NCF4 expression in DC cells, monocytes/macrophages, and Tprolif cells was different (Fig. 12F). Likewise, the expression level of TNFSF13B expression in plasmocytes and Tprolif cells was significantly different (Fig. 12G). POU2F2 expression was shown to be statistically different in B cells, conventional CD4+ T cells, exhausted CD8+ T cells, monocytes/macrophages and Tprolif cells (Fig. 12H). And we found that the expression of SLAMF1 in B cells, conventional CD4+ T cells and monocytes/macrophages was statistically different (Fig. 12I). Overall, the findings showed that the nine SADGs were highly related to the tumor immune microenvironment.Fig. 11Expression patterns of nine key SADGs in single-cell RNA sequencing of ccRCC.(A) Clusters for ccRCC cases.(B) UMAP plot of 11 predominant cell types in the ccRCC tumor microenvironment. (C)Visualization of percentage of cell number distribution of each cell type in all ccRCC cases.(D) The distribution of cells in each ccRCC case in GSE139555.(E) UMAP plots for visualizing the distribution of nine DRGs in various types of cells.(F) Violin plot for displaying the expression levels of nine DRGs in each cell types.Fig. 11Fig. 12The expression of nine SADGs at the single-cell level after stratification based on stage. The expression of (A) MYO1F, (B) FMNL1, (C) FCGR1B, (D) TNFAIP8L2, (E) CYTH4, (F) NCF4, (G) TNFSF13B, (H) POU2F2 and (I) SLAMF1 at the single-cell level after stratification based on stage.Fig. 12

Expression patterns of nine key SADGs in single-cell RNA sequencing of ccRCC.

(A) Clusters for ccRCC cases.

(B) UMAP plot of 11 predominant cell types in the ccRCC tumor microenvironment. (C)Visualization of percentage of cell number distribution of each cell type in all ccRCC cases.

(D) The distribution of cells in each ccRCC case in GSE139555.

(E) UMAP plots for visualizing the distribution of nine DRGs in various types of cells.

(F) Violin plot for displaying the expression levels of nine DRGs in each cell types.

The expression of nine SADGs at the single-cell level after stratification based on stage. The expression of (A) MYO1F, (B) FMNL1, (C) FCGR1B, (D) TNFAIP8L2, (E) CYTH4, (F) NCF4, (G) TNFSF13B, (H) POU2F2 and (I) SLAMF1 at the single-cell level after stratification based on stage.

## Section: Results › SADG signature influenced somatic mutation landscape of ccRCC patients

We conducted somatic mutation analysis between the two groups in TCGA-KIRC patients. There was a difference in the frequency of mutations. The mutation frequency of gene VHL, PBRM1, SETD2, BAP1 and MTOR was higher in the high-risk group, which mainly were missense mutations (Fig. 13A and B). Then, we found that the tumor mutation burden increased with the increasing risk score (Fig. 13C). Furthermore, the high-risk score group had higher microsatellite instability (MSI) (Fig. 13D). The predictive markers and mechanisms of immunotherapy resistance are the focus of current research. TIDE (Tumor Immune Dysfunction and Exclusion) analysis is usually used to estimate the effectiveness of immune checkpoint blocking (anti-PD-1/anti-CTLA-4) therapy. A higher TIDE score means a higher likelihood of immune surveillance evasion and a lower immunotherapy success rate. In this study, the high-risk group in the SADG signature showed a higher TIDE score, which indicates the SADG signature has good performance in predicting the immunotherapy response [24] (Fig. 13E).Fig. 13Somatic mutation landscape.(A) The waterfall plot showed the top 15 most mutated genes individually in high-risk group.(B) The waterfall plot showed the top 15 most mutated genes individually in low-risk group.(C) Scatter diagram showed the relationship between risk score and tumor Mutations burden.(D–E) Association between risk score and MSI (D) as well as TIDE (E).Fig. 13

Somatic mutation landscape.

(A) The waterfall plot showed the top 15 most mutated genes individually in high-risk group.

(B) The waterfall plot showed the top 15 most mutated genes individually in low-risk group.

(C) Scatter diagram showed the relationship between risk score and tumor Mutations burden.

(D–E) Association between risk score and MSI (D) as well as TIDE (E).

## Section: Results › Expression verification of nine SADGs between ccRCC samples and normal samples and survival analysis by GEPIA

In our study, the GEPIA database was utilized to confirm the differential expression of nine SADGs between ccRCC and normal samples. As shown in Fig. 14A, in comparison to normal samples, mRNA expression levels of MYO1F, FMNL1, FCGR1B, TNFAIP8L2, CYTH4, NCF4, TNFSF13B and POU2F2 were significantly higher in ccRCC. Although not significantly, SLAMF1 was also highly expressed in ccRCC compared with para-cancer samples. Furthermore, utilizing the GEPIA online database, a survival analysis was also carried out. Patients were grouped based on the median gene expression levels. High expression of FMNL1 (P = 0.048, HR = 1.4), NCF4 (P = 0.0053, HR = 1.5), TNFSF13B (P = 0.0097, HR = 1.5) and POU2F2 (P = 0.024, HR = 1.4) was related to poor prognosis (Fig. 14B).Fig. 14Expression pattern validation and the relationship between the expression of the nine SADGs and the prognosis of ccRCC patients.(A) Expression levels of the nine SADGs in ccRCC and normal tissues from the GEPIA database.(B) The prognostic value of the nine SADGs expression ccRCC overall survival (OS).Fig. 14

Expression pattern validation and the relationship between the expression of the nine SADGs and the prognosis of ccRCC patients.

(A) Expression levels of the nine SADGs in ccRCC and normal tissues from the GEPIA database.

(B) The prognostic value of the nine SADGs expression ccRCC overall survival (OS).

## Section: Results › Experimental verification of the expression of nine SADGs in clinical samples

To verify the reliability of the nine SADGs that made up the risk model, eight paired tissues of cancer and adjacent normal tissues from ccRCC patients were used to explore the expression level of 9 SADGs by qRT-PCR. As shown in Fig. 15, high expression of FMNL1, TNFAIP8L2, CYTH4, NCF4, TNFSF13B and POU2F2 was found in ccRCC based on the qRT-PCR analysis. Besides, there was a trend of upregulation of MYO1F, FCGR1B and SLAMF1 in tumor tissues, but it was not statistically significant, which may be attributed to the small sample size and excessive individual differences.Fig. 15The relative expression levels of the nine SADGs in ccRCC tumor tissues and para-cancerous tissues. The relative expression levels of (A) MYO1F, (B) FMNL1, (C) FCGR1B, (D) TNFAIP8L2, (E) CYTH4, (F) NCF4, (G) TNFSF13B, (H) POU2F2 and (I) SLAMF1 in ccRCC tumor tissues and para-cancerous tissues.Fig. 15

The relative expression levels of the nine SADGs in ccRCC tumor tissues and para-cancerous tissues. The relative expression levels of (A) MYO1F, (B) FMNL1, (C) FCGR1B, (D) TNFAIP8L2, (E) CYTH4, (F) NCF4, (G) TNFSF13B, (H) POU2F2 and (I) SLAMF1 in ccRCC tumor tissues and para-cancerous tissues.

## Section: Discussion

As the most common subtype of all renal cancers, ccRCC is highly aggressive [25]. Immune blockade and targeted therapy have shown remarkable outcomes. However, not all patients respond well to such therapies [26,27]. Therefore, it is crucial to explore novel therapeutic targets or adjuvants to enhance immune therapy for renal cancer. The occurrence of tumors is a dynamic process influenced by a wide range of factors, multiple stages and multiple genes. And the dysregulation of programmed cell death is closely correlated with the occurrence and prognosis of tumors [28]. Disulfidptosis exhibits an unusual accumulation of intracellular disulfides, which sets it apart from other forms of PCD processes. In the condition of high SLC7A11 expression, limiting NADPH synthesis from the PPP by glucose deprivation results in a significant buildup of small molecule disulfides, a number of redox abnormalities, as well as rapid cell death [11,29]. That's to say, disulfidptosis has the potential to be applied to a novel effective therapy method for ccRCC patients. Besides, a subgroup of tumor cells known as cancer stem cells (CSCs) has the ability to initiate tumors and trigger relapses. Due to the primary characteristics of cancer stem cells, it is claimed that cancer stemness is the primary reason for metastasis and tumor relapse following conventional therapy. In addition to genetic modification, TME may play a role in facilitating the acquisition of stemness characteristics [30,31].

Currently, there is limited research on the impact of disulfidoptosis-related genes on the prognosis of ccRCC. In our study, we collected 88 DRGs. Using univariate Cox regression analysis, we obtained 44 prognostic genes in ccRCC. Then, we discovered two ccRCC subtypes associated with DRG from the TCGA through the NMF algorithm. Compared to the C1 subtype, ccRCC patients in cluster 2 had a better clinical outcome, which confirmed the significance of DRGs in ccRCC prognosis. Next, differential genes related to cell stemness and TME were obtained through WGCNA analysis with the differential genes between the two clusters. And we obtained 71 cell stemness and TME associated disulfidptosis-related DEGs by taking the intersection up-expressed genes in tumor samples and hub genes in WGCNA. After univariate Cox analysis, we used LASSO regression analysis based on the expression matrix of genes highly related to outcome (p < 0.05) to establish a prognostic signature including nine genes (MYO1F, FMNL1, FCGR1B, TNFAIP8L2, CYTH4, NCF4, TNFSF13B, POU2F2 and SLAMF1) from the training set, which shown great efficiency in predicting survival outcome and immunotherapeutic response. Additionally, the disulfidptosis risk score was identified as an independent prognostic factor in ccRCC patients. Subsequently, a nomogram was developed, integrating the risk score and clinical features, to predict the survival outcome of ccRCC patients.

Of the nine genes in our constructed model, MYO1F is associated with the mitochondrial network and promotes tumor growth in thyroid cancer [32]. Low expression of FMNL1 may prevent the proliferation of kidney cancer cells, which is a potential KIRC-specific neoantigen candidate for KIRC mRNA vaccine development. FCGR1B is the Fc fragment of immunoglobulin G and is related to the poor prognostic of ccRCC patients [33]. TNFAIP8L2 is highly expressed in various tumors and is related to the process of immunological homeostasis [34]. According to a recent study, TNFAIP8 may be correlated with tumor-associated microbiota in colorectal cancer [35]. CYTH4 belongs to the PSCD family, regulating protein sorting and membrane dynamics. In glioma, the overexpression of CYTH4 is a biomarker for predicting a poor prognosis by affecting pyroptosis [36]. NCF4 is a component of the NAPDH complex, correlated with immune activation and immunological regulation [37]. TNFSF13B, commonly known as BAFF, is a member of the tumor necrosis factor (TNF) ligand family. It could serve as a crucial communication channel between the tumor cell and the tumor microenvironment for KIRC [38]. As a marker of prognosis in cancer, POU2F2 is highly expressed in various solid tumors. POU2F2 has been implicated in promoting the glycolysis and progression of glioblastoma by the activation the AKT pathway [[39], [40], [41], [42]]. SLAMF1 has been described as a vital molecule in regulating autophagy in chronic lymphocytic leukemia cells. In choriocarcinoma, SLAMF1 promotes resistance to MTX by activating autophagy-related pathways [43]. These key genes' differential expression was strongly correlated with the prognosis of tumors. Further research on these molecules may provide a reference for exploring novel therapeutics and prognostic indicators for renal cancer.

TME is a dynamic system and is characterized by various components, including immune cells, stromal cells and cytokines, which is not only closely correlated with the occurrence, growth and metastasis of tumors, but also vital to the treatment of tumors [44,45]. TME plays a crucial part in malignant progression, immune escape and treatment resistance. TME relies largely on CD8 T cells, which are essential for recognising and eliminating tumor cells [46]. Besides, neutrophils play a crucial role as a significant component of immune cells infiltrating the TME. Recent research has revealed that the infiltration of neutrophils plays a role in promoting lymphangiogenesis and lymph node metastasis, which was associated with poor prognosis [47,48]. Both CD8 T cell and Treg cell expression were found to be significantly higher in the high-risk group of our study. A significant number of immunosuppressive substances may be present in TME, inhibiting the antitumor activity of CD8 T cells, which may explain why the high-risk group with poor prognosis showed an abundant infiltration of CD8 T cells. Tregs are a unique subgroup of T cells, which have the function of suppressing the immune response, thereby maintaining homeostasis and self-tolerance. Inhibiting T cell growth and cytokine production, as shown by studies, is one way that Tregs help to avoid autoimmunity [49]. High Tregs infiltration was significantly correlated with shorter OS of renal cancer and breast cancer [50,51]. This may explain why we found a negative correlation between the infiltration of Tregs and prognosis in the high-risk group. M1 macrophages are considered as tumor-killing macrophages [52], and the infiltration of M1 macrophages was significantly increased in the low-risk group in our analysis. In the microenvironment of solid malignant tumors, various inflammatory cells contribute to innate and acquired immune responses. Among these cells, neutrophils constitute a significant portion. Recent evidence suggests that tumor-associated neutrophils (TAN) may exhibit either a N1 anti-tumor or N2 pro-tumor phenotype. Neutrophils can undergo a transformation into tumor-promoting cells in the microenvironment. Apart from their cytotoxic effects, they have the ability to facilitate tumor cell dissemination by releasing elastase and matrix metalloproteinases. Moreover, T cell-mediated anti-tumor immune responses are restricted by the tumor-promoting state's regulation of immunosuppression through the secretion of arginase-1 and reactive oxygen species. Targeting these tumor-promoting effects could hold promise for cancer therapy. Neutrophils also contribute to tumor promotion through the formation of neutrophil extracellular traps (NETs) within the tumor, a process called NETosis. Existing evidence predominantly supports the tumor-promoting role of neutrophils, with the degree of neutrophil infiltration correlating with a poorer prognosis. In our study, we observed higher levels of neutrophil infiltration in the high-risk group. Notably, the depletion of neutrophils is related to the significant reduction in lung carcinogenesis. These findings suggest that the SADG-related risk score model may have the potential to guide personalized immunotherapy for patients with ccRCC [[53], [54], [55], [56]].

Immune checkpoint inhibitors (ICIs) are gradually being suggested as first-line adjuvant treatment for diverse tumors due to their impressive therapeutic outcomes [26,57,58]. The immune checkpoint-associated genes were also found to be substantially different between the two risk groupings and to be more strongly expressed in the high-risk group, suggesting that high-risk patients may respond to ICI immunotherapy better. The TIDE approach has been applied to forecast the ICB response in ccRCC patients. TIDE score predicts the likelihood of immune evasion. According to our findings, patients in the high-risk group may be more likely to experience an immunological escape since their TIDE scores were higher than those of the low-risk group. Overall, the findings imply that the patients' different immunological states may have contributed to the differences in prognosis between the high- and low-risk groups.

Although this study performed a genomics analysis of disulfidptosis, and this SADG-related risk score model showed great capacity to predict the prognosis of patients with ccRCC, several limitations should be noted. First, although the expression of nine core genes was verified in TCGA and a small number of clinical samples collected by us, prospective studies with a significant sample size and prognostic information are essential for further verification. Second, the results were obtained by bioinformatics analyses from public databases, which need to be validated by further biological evidence from experimental studies. Furthermore, the underlying mechanisms between the SADGs and the immune microenvironment in ccRCC deserve further research.

## Section: Conclusion

In conclusion, we thoroughly explored the differences among biological processes, the immune states and the survival outcomes between the two molecular subtypes of disulfidoptosis. Furthermore, we established a novel signature based on nine stemness-associated disulfidptosis genes with excellent validity and potential clinical applications. This study will improve our understanding of the function of disulfidptosis in ccRCC, which offers a new reference for identifying prognostic markers and contributes to the improvement of therapeutic approaches.

## Section: Data availability statement

The datasets researched in this study are available in online repositories. The names of the repositories and accession numbers can be found in the article.

## Section: Ethics statement

This study was authorized by the ethics committee of the affiliated Yantai Yuhuangding Hospital of Qingdao University (No. 2023-314), and all patients signed relevant informed consent forms during their hospitalization.

## Section: Funding

This work was supported by grants from the National Nature Science Foundation of China (Nos. 82370690 and Nos. 82073131) and the Taishan Scholars Program of Shandong Province (No. tsqn201909199).

## Section: CRediT authorship contribution statement

Hongquan Liu: Writing – original draft, Formal analysis, Data curation. Xiaoqing Liang: Writing – original draft, Formal analysis, Data curation. Gonglin Tang: Writing – original draft, Visualization, Supervision, Methodology, Data curation. Xiaofeng Wang: Writing – original draft, Visualization, Supervision, Methodology, Data curation. Zhen Wang: Visualization, Supervision, Methodology, Data curation. Leijie Tong: Writing – original draft, Visualization, Supervision, Methodology, Conceptualization. Qiancheng Mao: Writing – review & editing, Visualization, Validation, Methodology, Data curation. Jian Ma: Writing – review & editing, Visualization, Formal analysis. Jitao Wu: Writing – review & editing, Project administration, Methodology, Funding acquisition, Conceptualization.

## Section: Declaration of competing interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.


---

# Integrating Artificial Intelligence and PET Imaging for Drug Discovery: A Paradigm Shift in Immunotherapy

- **Authors:** Jeremy P McGale, Harrison J Howell, Arnaud Beddok, Mickael Tordjman, Roger Sun, Delphine Chen, Anna M Wu, Tarek Assi, Samy Ammari, Laurent Dercle
- **Issuer:** Pharmaceuticals (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2024-02-06
- **Language:** en
- **DOI:** 10.3390/ph17020210
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38399425/
- **Licence:** CC-BY

## Section: Abstract

The integration of artificial intelligence (AI) and positron emission tomography (PET) imaging has the potential to become a powerful tool in drug discovery. This review aims to provide an overview of the current state of research and highlight the potential for this alliance to advance pharmaceutical innovation by accelerating the development and deployment of novel therapeutics. We previously performed a scoping review of three databases (Embase, MEDLINE, and CENTRAL), identifying 87 studies published between 2018 and 2022 relevant to medical imaging (e.g., CT, PET, MRI), immunotherapy, artificial intelligence, and radiomics. Herein, we reexamine the previously identified studies, performing a subgroup analysis on articles specifically utilizing AI and PET imaging for drug discovery purposes in immunotherapy-treated oncology patients. Of the 87 original studies identified, 15 met our updated search criteria. In these studies, radiomics features were primarily extracted from PET/CT images in combination (n = 9, 60.0%) rather than PET imaging alone (n = 6, 40.0%), and patient cohorts were mostly recruited retrospectively and from single institutions (n = 10, 66.7%). AI models were used primarily for prognostication (n = 6, 40.0%) or for assisting in tumor phenotyping (n = 4, 26.7%). About half of the studies stress-tested their models using validation sets (n = 4, 26.7%) or both validation sets and test sets (n = 4, 26.7%), while the remaining six studies (40.0%) either performed no validation at all or used less stringent methods such as cross-validation on the training set. Overall, the integration of AI and PET imaging represents a paradigm shift in drug discovery, offering new avenues for more efficient development of therapeutics. By leveraging AI algorithms and PET imaging analysis, researchers could gain deeper insights into disease mechanisms, identify new drug targets, or optimize treatment regimens. However, further research is needed to validate these findings and address challenges such as data standardization and algorithm robustness.

## Section: 1. Introduction

The discovery, development, and clinical application of immunotherapy have radically impacted therapeutic approaches to numerous cancers, resulting in a significant impact on survival outcomes for many patients. By exploiting a number of innate biological mechanisms, including regulation of cytotoxic T-cells via checkpoint molecules (e.g., PD-1, PD-L1, CTLA-4, and LAG-3), specifically directed oncolytic viruses, and engineered immunocytokines and T-cells, clinicians have been able to divert from the traditional but highly morbid approaches of chemotherapy and radiation. These treatments are inherently more selective for cancer cells, and they seek to target and overcome the mechanisms by which tumors can evade a patient’s natural defense mechanisms. However, the development of novel immunotherapies is an incredibly intricate process, impeded by challenges not only at the bench-top during target identification and molecular development, but also once a drug has left the lab and entered human trials. Clinical deployment of new immunotherapies is complicated by atypical response patterns previously unseen with chemotherapy, including pseudoprogression, in which a tumor initially appears to grow or spread before eventually regressing, as well as various treatment-related inflammatory conditions that can appear in nearly any organ system. Additionally, only a subset of patients exhibit partial or complete responses with immunotherapy, emphasizing the need for better a priori candidate selection.

Positron emission tomography (PET), an imaging modality that provides information about tissue metabolic function, is already widely used for initial cancer diagnosis and staging. Further, the combination of PET and artificial intelligence (AI), which provides high-throughput computation and specifically trained pattern recognition, may help improve efficiency at each step of the development pipeline, ultimately allowing for quicker evaluation and implementation of effective therapeutics in patient care.

This review aims to highlight current studies examining the combination of PET and AI for use in patients treated with immunotherapy. We first provide general background information on immunotherapy, as well as its therapeutic counterpart, targeted molecular therapy, in addition to describing the basics of PET imaging and AI. We then discuss the results of our subgroup analysis with a focus on pain points in the drug development process, including target validation, safety, biomarkers for prognostication and response evaluation, and generalizability to clinical application. For each topic area, we describe current challenges and relevant AI/PET studies from our focused review, as well as other related and current advances. We conclude by describing promising developments that could incite future research and impact the field moving forward.

## Section: 2. Background › 2.1. Targeted Molecular Therapy

While traditional cytotoxic chemotherapy is non-selective and affects both neoplastic and normal host cells, targeted molecular therapies were developed with the goal of improving treatment specificity. This type of therapy generally involves small molecules designed to target mutated proteins or biochemical pathways that allow for unregulated growth and development in tumor cells. The first example in this class was imatinib, a BCR-ABL tyrosine kinase inhibitor found to induce high response rates in chronic myelogenous leukemia [1]. Additional tyrosine kinase inhibitors have since become mainstays of non-small cell lung cancer (NSCLC) treatment, including erlotinib for patients with epidermal growth factor receptor (EGFR) mutations and crizotinib for those with anaplastic lymphoma kinase-positive (ALK+) disease [2]. The former is now part of first-line treatment protocols for NSCLC, and the latter was shown to result in superior survival over first- and second-line cytotoxic chemotherapy regimens [3]. Countless other molecular targets, such as KRAS, BRAF, KIT, HER2, CDK 4/6, and PARP, have been approached with small molecules, but while improved selectivity overall results in fewer off-target effects, these treatments are highly susceptible to resistance through de novo mutations at the target moiety of interest [4,5,6].

## Section: 2. Background › 2.2. Immunotherapy

Immunotherapy represents an alternative approach for blunting the tumorigenic properties of cancer and addressing the aforementioned mechanisms of targeted therapy resistance. This type of treatment focuses on immune pathways, inhibiting tumor-mediated processes for immune downregulation while simultaneously amplifying host response against malignancy. As a result, modern approaches to immunotherapy development greatly diverge from the traditional methods of chemotherapeutic drug discovery and are more similar to those employed for targeted therapy. When creating a novel immunotherapy, researchers first identify a suitable or theoretically relevant target via cell lines, animal models, or bioinformatics before subsequently exploiting cellular machinery to develop antibodies highly specific for proteins expressed on cancer cells. As an example, ipilimumab, one of the earliest FDA-approved immunotherapies, was developed after the identification of the CTLA-4 cell surface receptor, a protein that functions as an immune checkpoint inhibitor (ICI), suppressing host immune defenses [7]. In theory, blocking this receptor on cancer cells would reduce inhibition of the host immune response, leading to the destruction of malignant cells. By utilizing a transgenic mouse model and capitalizing on the natural processes of class-switching and somatic mutation, researchers were able to generate a massive library of IgG antibodies, subsequently identifying those that were most selective for CTLA-4 [8]. The isolated antibodies were then validated in both in vitro and in vivo mouse models to ensure selectivity and efficacy against tumors.

It is important to note that combinations of immunotherapy with cytotoxic chemotherapy or small molecule inhibitors may beget even more significant responses, and tandem therapy remains an active area of research [9,10].

## Section: 2. Background › 2.3. PET Imaging

Positron emission tomography (PET) is a medical imaging technique that quantifies the distribution of radioactive molecules throughout the human body. The most commonly employed radiotracer, 18F-FDG, is composed of a radioactive fluorine atom paired with a glucose moiety, allowing clinicians to visualize in vivo glucose metabolism. For years, 18F-FDG PET imaging has been the standard of care in oncology for the initial assessment and staging of cancerous lesions. PET has also been employed in response assessment, allowing clinicians to track the regression, malignant spread, and recurrence of cancer by analyzing changes in metabolic activity over time [11]. Recently, the scope of PET has widened in light of new developments in radiotracer technology, generally involving the linkage of radiolabels and highly targeted monoclonal antibodies. PET imaging is primed to play a role in future oncologic drug development due to its current status as the gold standard for diagnosis and staging, wide availability, and ease of technical modification and development.

## Section: 2. Background › 2.4. AI and Radiomics

Fundamentally, medical images are made up of two-dimensional pixels (or three-dimensional voxels) that each have a corresponding brightness (or intensity/gray-level) value. The amalgamation of many different individual pixels of varying brightness values creates a macroscopic image from which a radiologist generates an interpretation. However, there is an immense amount of potentially valuable data buried in the micro-scale relationships between individual pixels that may hold clues to underlying biological processes imperceptible to the human eye. Additionally, these relationships cannot be reproducibly quantified by clinicians (due to inter- and intra-observer variability) and are difficult to compare and combine into complex decision algorithms. Artificial intelligence, and in particular the subcategory of radiomics (i.e., extracting textural information from medical imaging through mathematical processes), could be used to address these challenges by quantifying relationships between pixel intensities through discrete imaging “features”. These features describe patterns such as the maximum, mean, and distribution of brightness values in a certain image, as well as symmetry, heterogeneity, and geometric co-occurrences (i.e., spatial relationships of all pixels with identical intensities) of pixels in a region of interest. In theory, by using radiomics and a large dataset of medical images for model training, researchers could identify a precise combination of imaging features and relative weights to create an “imaging phenotype” that is correlated to a particular disease process or patient outcome. Model outputs are generally binary, classifying patients as likely or not likely to have a particular outcome, but even this information can be essential to progressing care or facilitating clinical trials.

## Section: 3. AI and Immunotherapy: Current Landscape

A 2022 scoping review surveyed three databases, MEDLINE (PubMed), CENTRAL (Cochrane Central Register of Controlled Trials), and EMBASE, for all studies through 26 February 2022, using search terms related to artificial intelligence and radiomics applied to the medical imaging of immunotherapy-treated cancer patients [12]. There was one additional relevant study added that was identified in references but did not appear in the original search. Studies were included if they involved the immunotherapeutic treatment of human cancers or models of human cancers and if they employed radiomics with PET, CT, or MRI imaging. Case reports, systematic reviews or meta-analyses, perspectives, editorials, book chapters, workshop reports, conference abstracts, and non-English language reports were excluded. In total, 87 studies were recorded.

To survey the current state of artificial intelligence specifically applied to PET imaging, we performed a focused second-look analysis of this review, examining studies that involved the extraction of imaging features from 18F-FDG PET and CT images in combination (9 of the 87 total studies, 10.3%) and those utilizing only PET images (n = 6, 6.9%). The complete study selection process, including that of the original review, is displayed in Figure 1.

We explored this subsection of 15 articles for the cancer of interest, the primary (and if applicable, secondary) predictive task of the radiomics model (e.g., prognosis, treatment response, tumor phenotyping, etc.), the data collection strategy employed (prospective or retrospective and single- or multi-center), and the validation method used to stress-test each radiomics model. The primary cancers of interest were NSCLC (n = 11, 73.3%), melanoma (n = 3, 20.0%), and lymphoma (diffuse-large B-cell lymphoma, n = 1, 6.7%), with the former two diseases also representing the most common indications for immunotherapy overall. The median [interquartile range] size of aggregated patient cohorts was 132 [148], with the largest number of patients (n = 697) having been recruited in a study of NSCLC. Summaries of these articles are displayed in Table 1 and Figure 2.

## Section: 4. Target Validation

Medical imaging and AI can help researchers and clinicians identify the presence and distribution of specific molecular targets, aiding in the deployment of patient-tailored treatments.

## Section: 4. Target Validation › 4.1. Challenges

Immunotherapy works by targeting very specific mechanisms exploited by tumor biology to either suppress or evade the host immune system. Characteristics of individual tumors, such as PD-L1 and CTLA-4 expression, as well as tumor immune cell infiltration, indicate that a patient’s specific disease may be particularly susceptible to certain types of treatment. The current standard for molecular assessment involves using immunohistochemistry to analyze a tissue sample collected via biopsy. Acquiring these samples is invasive and not without risk, leading clinicians to minimize their use of the procedure, typically only performed before treatment initiation or at disease relapse. Biopsies are also limited in both time and space, leading to a chance of mischaracterizing disease. Additionally, tumors are innately heterogeneous, with different cells possessing varying combinations of mutations, allowing for evolution as treatment is applied [28,29]. Cells with more susceptible phenotypes will die, while those less specifically targeted by a treatment will live on, changing the distribution of molecular expression within a tumor over time. Lastly, even at a single time point, a simple biopsy may fail to capture all cell phenotypes represented within a tumor and would not account for inter-tumoral heterogeneity if only the primary tumor was sampled [29].

## Section: 4. Target Validation › 4.2. State of the Art

In the 15 original studies reviewed, AI was used for classification of either tumor phenotype (n = 4, 26.7%), primarily in describing PD-1/PD-L1 expression, or tumor immune microenvironment (TME, e.g., tumor infiltration by host immune cells, n = 2, 13.3%). The former studies built radiomics models using medical imaging for prediction of PD-L1 overexpression in a certain percentage of cells, i.e., a model would generate a binary output that roughly translated to a prediction that over or under 1% of cells within an analyzed tumor had increased expression of PD-L1. Importantly, these models were built using radiomics features extracted from the primary tumor alone and correlated to known PD-L1 expression confirmed by histologic analysis, which remains the current ground truth for comparison. In describing TME, studies sought to quantify the infiltration and distribution of CD8+ T-cells within a tumor, as well as describe immune cell transcriptomic signatures as a proxy for immune activity.

These classifications correlate with a tumor’s likelihood of treatment response—a tumor with high PD-L1 expression or increased infiltration by host immune cells is more likely to respond to immune-activating or checkpoint-inhibitor therapy. In clinical trials, quantifying tumor character a priori may allow for more directed recruitment of patients, facilitating the identification of populations for which the efficacy of novel therapeutics is likely to be high. In other words, response rates of a PD-L1-inhibiting monoclonal antibody will be much higher in a cohort of highly PD-L1-expressing patients than in a mixed cohort with unknown PD-L1 expression, overall increasing the effect size and lowering the recruitment requirements necessary for a positive trial.

An additional approach aimed at resolving the time scale limitations of traditional tissue biopsies is the evaluation of free circulating tumor DNA (ctDNA), so-called “liquid biopsies.” ctDNA is a subdivision of circulating free DNA (cfDNA, or genetic material shed into general circulation by any cell, especially those undergoing apoptosis) that is specific to cancer. Detecting these ctDNA fragments in patient plasma can allow for non-invasive time-dependent monitoring of tumor genetic profiles, responses to treatment, and metastases, among many other metrics. A full discussion of ctDNA application is beyond the scope of this review, but has been covered extensively by other groups [30,31,32,33,34].

## Section: 5. Safety

Imaging can help clinicians evaluate immunotherapy-induced toxicity and perform risk stratification, allowing for careful decision making on whether or not to proceed with further treatment.

## Section: 5. Safety › 5.1. Challenges

Establishing standard dosing regimens for new immunotherapeutic agents remains challenging. Insufficient dosing may fail to stimulate a patient’s native immune system, resulting in little or no clinical effect, while supratherapeutic doses may precipitate side effects severe enough to dramatically increase morbidity and mortality or lead to treatment interruption [35]. By definition, some classes of immunotherapy, specifically ICI, release the “brakes” of a patient’s immune system, often resulting in the collateral damage of native tissues and the induction of a number of inflammatory conditions such as pneumonitis, colitis, hepatitis, and pancreatitis [36]. These side effects are known as immune-related adverse events (irAEs) and are feared complications in immunotherapy due to their ability to derail the application of treatment. irAEs are also difficult to track as they may be delayed compared to the adverse events associated with more traditional therapies, potentially necessitating longer trial durations [37]. Lastly, there is an intricate differential for in-treatment inflammatory changes on imaging (e.g., pneumonitis must be differentiated from cancer progression or radiation therapy toxicity), which must be fully explored in order to make the most appropriate judgment on ongoing treatment plans.

## Section: 5. Safety › 5.2. State of the Art

Prediction of sequelae from treatment (e.g., irAEs) was facilitated by AI in 2 studies (13.3%). Both studies utilized pretreatment imaging; one predicted the development of colitis, pneumonitis, Guillain–Barré syndrome, hepatitis, myalgia, or rash, while the other predicted the development of cancer-related cachexia in patients treated with ICI. Both studies utilized weighted multivariate logistic regression analysis to build models correlating radiomics features to specific adverse events, and one of the studies validated its model on a prospectively collected cohort of patients. Even without AI, some groups have previously demonstrated that PET imaging has the capacity to capture 75% of irAEs [38,39].

Identification of adverse events at the earliest possible moment, or prediction of which patients will likely experience adverse events due to innate, baseline physiology, is crucial to avoid delaying the administration of life-prolonging treatment. Having an accurate read of irAE risk would improve clinical agility in switching patients between therapeutic regimens. Additionally, ending negative trials, or those in which patients are at risk for high-morbidity adverse events, would promote patient safety. This could reduce barriers to patient enrollment and improve trial retention, while also helping to address disparities in communities traditionally underrepresented in clinical trials.

## Section: 6. Biomarkers for Prognostication and Response Evaluation

Artificial intelligence allows for the creation of patient-specific imaging “phenotypes”, which can be analyzed before, during, or after treatment. In this model, textural features extracted from images act as biomarkers for the patient’s disease, allowing clinicians to not only prognosticate by using large patient populations with similar phenotypes and known outcomes, but also monitor changes in the imaging manifestations of underlying biological processes during treatment.

## Section: 6. Biomarkers for Prognostication and Response Evaluation › 6.1. Challenges

There is a high bar for the approval of new drugs entering clinical trials; new therapies must demonstrate clear evidence of clinical benefit, defined as an improvement in survival, quality of life, or physical functioning. Beyond this, additional endpoints that have been used in accelerated approvals include the demonstration of more rapid tumor size reduction or longer delay in growth than with traditional therapy, as well as improved progression-free survival (PFS) or complete response (CR) in the absence of treatment-related side effects. Trials are designed around achieving these goals, and any tools that can facilitate this process are invaluable in accelerating approval or preventing setbacks.

A factor complicating clear demonstrations of benefit is that traditional methods of monitoring disease response to treatment using medical imaging (e.g., RECIST, RANO, Cheson, PERCIST, among others) have proven insufficient in capturing the novel tumor behavior seen with immunotherapy. This includes pseudoprogression (initial apparent growth of a tumor before eventual response), mixed responses (certain lesions respond more than others), and hyperprogression (accelerated growth after treatment administration) [40,41,42]. Pseudoprogression may lead to early termination of treatment due to perceived progression, while a true mixed response might compel clinicians to continue treating with the same regimen instead of appropriately switching therapy to address intrinsic tumor heterogeneity. Hyperprogression is far more sinister and may lead to disastrous outcomes from rapid disease progression of unknown origin if not recognized at the earliest possible moment [43].

## Section: 6. Biomarkers for Prognostication and Response Evaluation › 6.2. State of the Art

Per our review, AI was most commonly employed for prognostication (n = 6, 40%), either for predicting overall survival (OS) at a specific time point, progression-free survival (PFS, i.e., time from onset of treatment until disease progression or relapse), or durable clinical benefit (DCB, i.e., progression-free survival past a certain predefined time point). One study utilized AI to make baseline predictions about treatment response compared with eventual PERCIST outcomes. No studies specifically examined the differential classification of atypical response patterns discussed above, and thus this remains an area of potential exploration.

At baseline, evaluating the quality of a patient’s tumor and utilizing imaging to predict the likelihood and estimated time frame of survival is crucial for informed decision-making and the selection of a proper course of treatment. More hostile tumors, signified by a lower estimated OS, require more aggressive therapeutic strategies, influencing the treatment outcomes of clinical trials they are involved in. Trial length, an important factor for cost and time considerations in drug development, could also be shortened via early termination if patients displayed imaging phenotypes indicating a low probability of a good outcome with the continuation of a particular treatment. Furthermore, saving money by avoiding failed trials could open the door for the evaluation of additional new drugs, including those for orphan conditions.

In addition to the biomarkers mentioned above, a modified version of the RECIST consensus guidelines has been developed, termed iRECIST, with the intent of addressing atypical tumor behavior observed in response to immunotherapy [44]. A major improvement of iRECIST is its ability to more precisely discriminate instances of progression by including definitions for unconfirmed and confirmed progressive disease (iUPD and iCPD, respectively). When an increase in size or novel lesions are first observed on imaging after treatment initiation, the patient is noted to have iUPD until subsequent assessment, at which time persistence of growth or spread would indicate iCPD. Importantly, patients with iUPD that eventually regresses are eligible for partial response, complete response, or stable disease designations, whereas in standard RECIST, any degree of observed progression precludes attainment of these statuses.

## Section: 7. Challenges to Clinical Application

As discussed, medical imaging helps clinicians monitor the therapeutic effects of a drug and can help guide decision-making during different stages of clinical testing and implementation. However, in order for AI to be applied in more widespread clinical settings, extensive validation must be performed to ensure that simulated performance will be maintained in new populations.

## Section: 7. Challenges to Clinical Application › 7.1. Generalizability

While individual studies may report impressive performances for AI models in isolation, the interpretation of these results must be carried out with caution. The applicability and generalizability of models beyond the initial study populations depend on the quality of patient cohorts used for model training and the rigor of subsequent model validation. Per our review, nearly all studies (n = 14, 93.3%) recruited patients retrospectively, and most were based at single institutions (n = 11, 73.3%). One study included a prospective testing cohort for model validation. In general, training predictive algorithms on patients from multiple institutions allows the model to be exposed to more heterogeneity between patients and imaging acquisition techniques. Additionally, collecting data prospectively helps to eliminate the bias of retrospective analysis, further supporting the internal and external validity of results.

Model validation is a crucial step in AI development and represents the first real test of predictive ability: applying an algorithm to data separate from what was used for training. Validation methodology can be graded based on the quality of the cohorts used, with the lowest quality validation cohort involving reuse and reorganization of the training set, known as cross-validation. The use of a validation set involves splitting recruited patients into two buckets, one for model training and the other for validation. Alternatively, a validation set can be defined as a cohort of patients recruited separately from the training set, but at the same institution using similar inclusion criteria. In this way, and regardless of the approach, both training and validation sets will have similar patient distributions and characteristics, but the model is being tested on patients that it has not previously been exposed to. A more rigorous validation method involves testing models using a validation set immediately followed by a test set (denoted by us as “validation set; test set”), with the latter defined as a cohort of patients independent from the training/validation sets (i.e., patients were recruited from a different database/institution, recruited using different criteria, or received a different treatment). This strategy provides the highest external validity for AI, as model performances are observed in truly independent cohorts, indicating potential for broad application. Test sets, as defined above, could also be used in isolation, independent of validation sets. Per our review, most studies used validation strategies involving either a “validation set; test set” (n = 4, 26.7%) or a “validation set” alone (n = 4, 26.7%). Surprisingly, four (26.7%) studies reported no validation whatsoever, while two (13.3%) reported only cross-validation on the training set. One study used a test set in isolation. The relative absence of substantive validation is a trend observed previously in the field, with a 2019 meta-analysis finding that only 6% of studies surveyed in a pool of 516 performed any sort of external validation, while none validated radiomics models with prospective, multicenter external cohorts [45].

## Section: 7. Challenges to Clinical Application › 7.2. Radiomics Quality Score

While scrutinizing the rigor of validation allows for some ability to judge the quality of an AI model, there is a need for a more standardized approach to evaluation in order to properly recognize the relevance, predictive ability, and potential for application of each individual algorithm. Lambin et al. proposed a 16-point scoring system that accounts for, among other metrics, thoroughly described research methods, quality of validation, and description of biological correlates [46]. Although this measure, called the radiomics quality score (RQS), does not take into account sample size or discrete model performance, it allows for standardized assessment and comparison of AI studies. Overall, higher scores (with a maximum score of 36) indicate higher quality studies that can be more easily translated into practice. Of the 15 studies reviewed, the median [interquartile range] radiomics quality score was 15 [10], and the highest score achieved was 24.

## Section: 8. Future Directions: PET-Specific Radiotracers

An emerging technique, immunoPET, seeks to circumvent the use of imaging feature proxies for biological phenomena by more directly interrogating tumor biology through radiotracers appended to monoclonal antibodies (mAbs). The primary molecular targets of these highly specific mAbs are markers on CD8+ T-cells, as well as PD-L1 proteins. Cancers with low levels of CD8+ T-cell infiltration, indicating a lack of immune access to a tumor, or high PD-L1 expression, signaling a blunting of the host immune response, are less likely to respond to immune mobilization via immunotherapy. As previously discussed, a precise description of these variables, based on the pattern and intensity of radiotracer uptake as measured by PET, would allow for a curated selection of patients for trials, identifying those most likely to achieve durable clinical benefit.

Building on a decade of in vivo experimental studies using targeted radiotracers, recent proof-of-concept and Phase I trials have deployed a radiotracer comprised of an 89Zr atom tethered to a minibody (engineered antibody) specific for human CD8 protein to evaluate whole-body cytotoxic T-cell distribution and tumor infiltration [47,48,49,50]. Additionally, and perhaps more widely investigated at present, are agents targeting the PD-L1 co-receptor. Radiotracers built from 64Cu-, 89Zr-, 18F-, 111In-, and 99mTc-containing scaffolds with high-affinity PD-L1-specific peptides are being used in pre-clinical studies to precisely define tumor surface protein expression [51,52,53,54,55]. Human studies are also underway, with a recent trial of 22 patients demonstrating that PD-L1-specific 89Zr PET tracer uptake was more strongly correlated with outcomes than immunohistochemistry or RNA sequencing-based biomarkers [56]. Another trial used an 18F-labeled anti-PD-L1 Adnectin protein and demonstrated higher tracer uptake in treatment-responsive NSCLC [57]. A potential future avenue of investigation involves using radiomics or AI not as surrogate measurements for tumor microenvironment, as was performed in many of the studies described in this literature survey, but instead as a means to more thoroughly describe the behavior of these highly specific radiotracers. AI could be used to quantify patterns of radiotracer uptake and distribution that can be compared inter- or intra-patient in a longitudinal series, ultimately correlating them to clinical endpoints specifically chosen for a particular clinical trial.

## Section: 9. Conclusions

The modern development of immunotherapy is marked by significantly higher throughput, cost, and complexity than ever before. Tools are constantly being developed to improve efficiency at each step in the process, and AI may represent a solution for predicting treatment efficacy and minimizing side effects, thereby streamlining the clinical trial portion of novel pharmaceutical testing [42]. When paired with PET imaging, which is already widely used for staging purposes in oncology, AI could allow clinicians to appreciate and quantify the microscopic imaging biomarkers that define a patient’s disease. Even prior to trial onset, researchers could use AI for non-invasive, radiographic tumor phenotyping in order to assess susceptibility to treatment (e.g., evaluating PD-L1 status for patients prior to a trial for anti-PD-L1 monoclonal antibodies) and select patients most likely to achieve clinical benefit. Additionally, while an investigative treatment is being administered, radiographic changes could be used to predict prognosis or signal the insidious development of adverse reactions or atypical response patterns, allowing for increasingly swift reflexes from clinical trial teams. In theory, if a new drug trial were to be associated with poor radiographic phenotypes at first follow-up, it could be terminated at an earlier time point than is currently possible. Further development of AI, combined with high-specificity radiotracers to fully illuminate tumor cell microenvironments, could precipitate a paradigm shift in immunotherapy drug development, dramatically increasing efficiency and decreasing potential morbidity, ultimately facilitating bench-to-bedside transitions for novel therapeutics.


---

# Integrating Artificial Intelligence for Drug Discovery in the Context of Revolutionizing Drug Delivery

- **Authors:** Anita Ioana Visan, Irina Negut
- **Issuer:** Life (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2024-02-07
- **Language:** en
- **DOI:** 10.3390/life14020233
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38398742/
- **Licence:** CC-BY

## Section: Abstract

AbstractDrug development is expensive, time-consuming, and has a high failure rate. In recent years, artificial intelligence (AI) has emerged as a transformative tool in drug discovery, offering innovative solutions to complex challenges in the pharmaceutical industry. This manuscript covers the multifaceted role of AI in drug discovery, encompassing AI-assisted drug delivery design, the discovery of new drugs, and the development of novel AI techniques. We explore various AI methodologies, including machine learning and deep learning, and their applications in target identification, virtual screening, and drug design. This paper also discusses the historical development of AI in medicine, emphasizing its profound impact on healthcare. Furthermore, it addresses AI’s role in the repositioning of existing drugs and the identification of drug combinations, underscoring its potential in revolutionizing drug delivery systems. The manuscript provides a comprehensive overview of the AI programs and platforms currently used in drug discovery, illustrating the technological advancements and future directions of this field. This study not only presents the current state of AI in drug discovery but also anticipates its future trajectory, highlighting the challenges and opportunities that lie ahead. Keywords: artificial intelligence, drug discovery, machine learning, deep learning, drug repurposing, pharmaceutical AI

## Section: 1. Introduction

Drug discovery is a highly intricate and lengthy process that requires the identification of potential drug candidates that can effectively treat various diseases. The use of AI has brought a significant shift in the approach to drug discovery. AI has fundamentally transformed the pharmaceutical industry by speeding up the drug discovery process, improving precision, and decreasing costs. In this review, we will explore the different types of AI techniques used in drug discovery, including ML (to predict drug properties, identify potential drug candidates, and optimize chemical structures), DL (to analyze large-scale biological data, predict drug properties, and identify potential drug candidates), NLP (to analyze the scientific literature for potential drug candidates and to generate drug summaries), GM (to generate new molecules that could potentially be drug candidates), and network-based approaches (to identify potential targets for drug development).

Digital survey (2010–2023) justifying the importance of the subject.

## Section: 1. Introduction › 1.1. Historical Background and the Concept of AI in Medicine

The use of artificial intelligence techniques, algorithms, and technologies in medicine and healthcare is referred to as AI in medicine. It involves the use of computer systems and specialized software to analyze medical data, make decisions, and perform tasks that are usually completed by human healthcare professionals. AI in medicine aims to improve the accuracy, efficiency, and effectiveness of medical diagnosis, treatment, and patient care by leveraging ML, NLP, and other AI methodologies.

AI in medicine includes its diverse applications in areas such as medical image analysis, drug discovery, personalized treatment planning, disease diagnosis and prediction, virtual health assistants, electronic health record management, and patient monitoring. By processing vast amounts of patient data and medical literature, AI systems can assist healthcare professionals in making more up-to-date decisions, detecting patterns, and predicting patient outcomes, leading to better patient care and medical outcomes. The field of AI in medicine is rapidly advancing and making an impact in areas such as drug discovery, virtual health assistants, and remote patient monitoring. The use of AI-driven tools is expected to improve medical diagnoses, disease prevention, and treatment outcomes, ultimately leading to a more patient-centric and efficient healthcare system. The history of AI in medicine dates back several decades, with significant developments in both AI and medical sciences contributing to its evolution. Key milestones and events in the historical development of AI in medicine include the establishment of the field of AI in the 1950s by researchers like Alan Turing, who proposed the idea of intelligent machines [1]. Early work in AI involved attempts to mimic human problem-solving abilities through formal logic and rule-based systems [1]. In the 1960s, the concept of “expert systems” emerged, where the knowledge and expertise of human experts was encoded into computer programs to aid decision-making in specific domains [1]. This laid the foundation for AI applications in medicine. The development of early expert systems, such as Dendral and MYCIN, further advanced the use of AI in medicine. The 1970s saw an increase in AI applications in medicine, including computer-aided diagnosis (CAD) systems for medical imaging AI [1]. MYCIN, an expert system for diagnosing bacterial infections, demonstrated the potential of AI in healthcare [1]. In the 1980s, AI-based image recognition algorithms began to be applied in medical imaging, aiding in the interpretation of X-rays, CT scans, and MRIs [1]. AI techniques, such as pattern recognition and ML, were integrated into medical imaging systems [1]. The 1990s witnessed progress in NLP, enabling AI systems to “understand” and process medical text data [1]. Robotic surgery systems, such as the da Vinci Surgical System, were developed, combining AI and robotics for minimally invasive procedures [1]. With the advent of electronic health records (EHRs) and the growth of big data in healthcare, AI applications expanded to handle vast amounts of patient data [1]. AI in medicine began contributing to personalized medicine, predicting patient responses to treatments based on their individual characteristics [1]. DL, a subset of ML, revolutionized AI applications, including medical image analysis and disease diagnosis [1]. AI in medicine played a crucial role in advancing precision medicine, tailoring treatments based on genetic and molecular data [1]. These developments highlight the significant progress made in AI applications in medicine over the years, paving the way for improved healthcare outcomes and personalized treatment approaches.

## Section: 1. Introduction › 1.2. Statement of Significance

The historical background of AI in medicine shows a progressive journey from early explorations to the current era of sophisticated AI applications in various aspects of healthcare. As AI technologies continue to advance, they hold the potential to reshape the future of medicine and revolutionize healthcare practices for the benefit of patients and healthcare professionals alike. Overall, the number of published papers on AI has been increasing rapidly over time, with a peak of 348,684 papers being published in 2023. The number of published papers on AI-assisted material discovery in drug delivery has also been increasing in recent years, with a peak of 1234 papers being published in 2022. The number of published papers on AI in medicine has also been increasing in recent years, with a peak of 188,845 papers being published in 2021. The increase in the number of published papers on AI suggests that there is a growing interest in this technology and that more research is being conducted in this area. The number of published papers on AI in medicine has also been increasing in recent years but at a slower pace (Figure 1). The increase in the number of published papers on AI-assisted material discovery in drug delivery suggests that there is also a growing interest in the potential use of AI in this field. This suggests that there is still some way to go before AI is widely adopted into this field.

While the specific focus on AI-assisted material discovery in drug delivery is not extensively covered in the literature, the literature highlights the potential of AI in advancing pharmaceutical product development, including formulation design and drug discovery [2,3]. These insights suggest that AI can be a valuable tool in accelerating the discovery and optimization of materials for drug delivery. However, for a more detailed review specifically focusing on AI-assisted material discovery in drug delivery, it would be beneficial to explore additional research articles or publications that specifically address this topic.

Digital survey (2010–2023) justifying the importance of the subject.

## Section: 2. AI in Discovering New Drugs

In the field of medicine, there are two types of AI applications: physical and virtual. Physical applications include the following: robot-assisted surgery, AI-enhanced prosthetics, real-time patient monitoring, and automated laboratory processes.

For example, AI in robot-assisted surgery can provide medical professionals with relevant information to assist them in making more informed decisions. While AI cannot replace human doctors, it can enhance their capabilities and improve patient care. Thus, AI-powered surgical robots enable surgeons to perform complex procedures with greater precision, control, and flexibility. These robots can reduce the risk of complications, minimize invasiveness, and shorten recovery times, leading to better surgical outcomes [4]. On the other hand, AI-driven prosthetics are designed to adapt to the user’s movements and respond to their neural signals. These advanced prosthetics significantly improve the quality of life for amputees, allowing them to perform complex tasks with greater ease and naturalness. AI-based monitoring systems continuously analyze patient data, such as their vital signs and electronic health records, to identify potential signs of deterioration or complications. This enables healthcare providers to intervene on time and avert adverse events. Studies have also shown that AI-based algorithms can outperform human doctors in certain diagnostic tasks, such as detecting certain types of cancer or interpreting pulmonary function tests [5]. Some automated laboratory processes, such as AI-powered robotic systems that streamline and automate laboratory processes, include sample analysis, sorting, and preparation. This reduces the workload for laboratory staff and minimizes the risk of human errors, ensuring more accurate results.

Drug Discovery and Development belong to the Virtual Applications category, together with diagnostic assistance, personalized treatment plans, and virtual health assistants. Virtual AI applications aid healthcare professionals in diagnosing diseases more accurately and efficiently. AI algorithms can analyze medical imaging data, such as X-rays, CT scans, and MRI images, to detect abnormalities and assist in early disease detection [6]. This capability translates to a significantly reduced chance of misdiagnosis and leads to better patient outcomes. The power of AI lies in its ability to process and analyze large amounts of medical data, spotting patterns that may not be immediately visible to humans. In doing so, AI can help improve diagnostic accuracy and develop personalized treatment plans. In particular, DL algorithms can identify anomalies or potential diseases in medical images, which can assist radiologists in their interpretations [6]. For instance, AI has proven useful in the field of gastroenterology by detecting abnormal structures in endoscopy and ultrasound images, such as colonic polyps [7]. Additionally, AI-powered wearable devices can remotely monitor patients and provide real-time data to healthcare professionals, offering early intervention opportunities. These devices have even been developed to detect and notify caregivers about seizures in epilepsy-suffering patients [8]. Also, AI-powered virtual applications can analyze an individual’s health data, including their genetics [9], medical history [10], lifestyle factors [11], and current health status, to create personalized treatment plans. These plans can optimize their medication dosage, predict their treatment response, and recommend targeted therapies, ensuring more effective and personalized patient care. AI can also contribute to precision medicine by analyzing a patient’s genetic data and medical history to predict their disease risk, determine optimal treatment plans, and identify potential drug targets. Moreover, virtual health assistants, powered by AI, offer patients 24/7 support and personalized health advice [12]. They can answer medical queries, remind patients about medication schedules, and provide lifestyle recommendations, promoting patient engagement and proactive healthcare management.

Regarding drug discovery and development, AI algorithms assist researchers in identifying potential drug candidates by analyzing vast databases of molecular structures, biological interactions, and clinical trial data. This accelerates the drug discovery process and holds promise for a faster development of new medications.

AI in drug discovery implies:

AI has significantly impacted the field of drug discovery, particularly in the areas of target identification and validation. This process involves identifying potential biological targets and elucidating their roles in diseases, followed by validating these targets to ensure they are directly involved in a disease mechanism and that the modulation of the target is likely to have a therapeutic effect and plays a crucial role in identifying potential drug targets by analyzing the genomic, proteomic, and metabolomic data (Figure 2). ML algorithms sift through large datasets to pinpoint the proteins or biological pathways implicated in specific diseases, offering researchers valuable insights for drug development [13].

For instance, ML-based approaches, such as Kronecker regularized least squares (KronRLS), evaluate the similarities between drugs and protein molecules to determine DTBA. Correspondingly, SimBoost utilizes regression trees to predict DTBA, and considers both feature-based and similarity-based interactions [14].

AI also aids in the selection of the target. An optimal target should be druggable, safe, efficient, and able to fulfill commercial requirements. However, emerging modalities for disease treatment include previously less tractable targets. Target validation is a crucial step in drug discovery because it ensures that a molecular target is directly involved in a disease mechanism and that the modulation of the target is likely to have a therapeutic effect [15]. Target validation may involve determining the structure–activity relationship, the genetic manipulation of target genes (knockdown or overexpression), generating a drug-resistant mutant of the presumed target, using degradation-based tools to anticipate the effects of the target, and monitoring the signaling pathways downstream of the presumed target [16]. AI has been used to predict drug–target interactions [17], measure the binding affinity of a drug [18], and select and validate targets [19].

AI-powered virtual screening tools analyze the three-dimensional structures of target proteins and predict how potential drug molecules would interact with them. This speeds up the process of drug designing and allows researchers to identify promising drug candidates for further testing [20].

Virtual drug screening is a computational approach that uses AI to predict the activity of potential drugs by fitting chemical structures to targets (Figure 3). This method allows researchers to rapidly test a library of compounds for their potential to bind and inhibit specific receptor or enzyme targets [21]. AI algorithms can analyze molecular structures, predict binding affinities, and prioritize compounds for further experimental testing [21]. Also, AI techniques, such as Bayesian docking approximations and RL, can be used in molecular docking simulations [22]. Molecular docking involves predicting the preferred orientation of a small molecule (drug candidate) when it is bound to a target protein. AI algorithms can explore the conformational space and predict the binding affinity between the drug and the target protein [22]. ML algorithms for drug design can be trained on/with large datasets of known drug–target interactions to envisage new drug–target pairs or optimize the properties of existing drugs. These algorithms can learn the patterns and relationships between chemical structures and biological activities, enabling the discovery of novel drug candidates [23]. For example, graph neural networks (GNNs) have been used to predict molecular properties and optimize drug design [24]. GNNs have been increasingly utilized in drug discovery for their ability to accurately predict molecular properties. These advanced AI models excel in understanding the complex structures of molecules, enabling a more efficient and targeted drug design. By representing molecules as graphs with atoms as nodes and chemical bonds as edges, GNNs effectively analyze and predict how these molecular structures will behave, leading to optimized drug design processes. AI can enhance high-throughput virtual screening, which involves screening large databases of compounds to identify potential drug candidates. ML algorithms can analyze chemical features, structure–activity relationships, and other molecular properties to prioritize compounds with high potential for further investigation [25].

AI techniques, such as DL and quantum chemistry, can be used for predictive modeling and optimization in drug design. DL models can analyze vast amounts of data, including chemical structures, biological activities, and pharmacokinetic properties, to predict the efficacy and safety of potential drugs [26]. Quantum chemistry combined with AI can accelerate the exploration of chemical space and guide the design of new drug candidates [25]. It is important to note that while AI has shown promising results in virtual screening and drug designing, experimental validation is still necessary for the identified drug candidates. AI is a powerful tool that can assist researchers in the early stages of drug discovery, but it should always be complemented with traditional experimental methods and rigorous testing [23]. Overall, AI has the potential to significantly accelerate the drug discovery process, improve the efficiency of virtual screening, and enable the design of novel drug candidates with optimized properties. As research in AI and ML continues to advance, we can expect further advancements in virtual screening and drug design methodologies.

AI algorithms can predict the physicochemical properties of drug candidates, such as the solubility, bioavailability, and toxicity [16]. This helps in optimizing drug development by focusing on compounds with a higher chance of success, thus reducing costs and time. ML algorithms can be trained to predict drug properties using a database of known compounds. These algorithms learn to recognize patterns and correlations between the chemical structure of a compound and its physicochemical properties [20]. Once trained, these models can predict the physicochemical properties of new, untested compounds, aiding in the early stages of drug development [20]. For instance, ML models have been used to predict solubility, a crucial property for drug candidates [27]. Similarly, ML algorithms have been used to predict bioavailability, another critical property for drug candidates [28]. Toxicity prediction is another area where AI has shown promise. ML models have been used to predict the toxicity of compounds based on their chemical structures [29]. These models can help in early-stage drug discovery by identifying compounds that are less likely to be toxic, thereby reducing the risk of harm to humans during the testing phase [14].

AI enables researchers to identify new therapeutic applications for existing drugs by analyzing vast databases of drug–target interactions and disease pathways. This drug repurposing approach can significantly reduce the time and cost required to bring a drug to market (Figure 4) [30].

AI used in drug combination identification implies enhanced synergy detection, combination optimization, personalized combination therapies, and prediction of adverse drug interactions.

AI algorithms analyze high-dimensional biological data to identify potential synergistic drug combinations. By exploring interactions between drugs and their targets, AI can predict combinations that exhibit enhanced therapeutic effects while minimizing adverse reactions [31]. AI can optimize drug dosage and scheduling within a combination to maximize its efficacy and reduce side effects [32]. This fine-tuning ensures that the combination’s therapeutic benefits are fully realized, making it a more viable treatment option. AI-driven precision medicine allows the identification of patient-specific drug combinations based on individual molecular profiles and disease characteristics [33]. This personalized approach aims to achieve better treatment outcomes and minimize the risk of drug resistance. AI models can predict potential adverse interactions between drugs in a combination, ensuring the safety of patients and avoiding potential harm [34].

Drug development process: target deconvolution vs. target discovery.

Virtual screening ML model in the drug development process.

Drug repurposing approach.

AI methods that are frequently utilized in drug discovery.

Collaborations between pharmaceutical companies and AI providers.

## Section: 2. AI in Discovering New Drugs › 2.1. AI Techniques Used in Material Discovery

AI techniques, particularly in materials science, focus on discovering and designing new materials with desirable properties. This is directly applicable to drug discovery, as the process often requires the identification of novel compounds with specific biological activities. AI algorithms that excel in predicting the properties of new materials can similarly predict the pharmacological profiles of drug candidates. This crossover allows for the more efficient screening and optimization of potential drugs, leveraging AI’s predictive capabilities to streamline both the material and drug discovery processes.

AI techniques in materials discovery include supervised and unsupervised learning. Supervised learning uses labeled data to train models that can classify or predict outcomes of new data. Unsupervised learning, on the other hand, deals with unlabeled data and aims to develop models that can identify recurring patterns and clusters of the input data without prior knowledge. In contrast, in drug discovery, AI techniques are used at various stages, including in data collection and curation, compound representation, and AI methods and their applications. Data resources, data representation schemes, and AI methods are the three key components of applying AI to drug discovery and evaluation. AI techniques used in drug discovery include regression analysis, the decision tree, logistic regression, the support vector machine, the convolution neural network, the recurrent neural network, the generative adversarial network, k-means clustering, hierarchical clustering, principal component analysis, and t-distributed stochastic neighbor embedding.

In drug discovery, the selection and application of AI techniques are problem-oriented to ensure they are ideal. Two commonly used types of AI techniques in the realm of drug discovery are supervised and unsupervised learning [35].

Table 1 lists the widely used AI techniques in drug discovery, which are briefly discussed in the following sections.

AI methods that are frequently utilized in drug discovery.

Collaborations between pharmaceutical companies and AI providers.

## Section: 2. AI in Discovering New Drugs › 2.1. AI Techniques Used in Material Discovery › 2.1.1. Supervised Learning Methods

Supervised learning involves using input-labeled data to train models capable of classifying and/or predicting outcomes for new data, e.g., where the output is its corresponding property (e.g., band gap, thermal conductivity) [46]. Supervised learning models can then predict the properties of new materials based on the patterns learned during training [47]. In contrast, unsupervised learning deals with unlabeled data and aims to advance models which identify recurring patterns and clusters within the input data without prior knowledge [48]. They can help identify novel material classes that might not be apparent through manual analysis [49]. Supervised learning techniques are further split into classification and regression algorithms, while unsupervised learning techniques include clustering and dimensionality reduction algorithms.

Linear regression models the relationship between a dependent variable and one or more independent variables by fitting a linear equation to the observed data. In drug discovery, linear regression can be used to predict a physicochemical property of a compound based on its molecular descriptors. Ridge regression and lasso regression are types of linear regression that use shrinkage, which is a technique for reducing the complexity of a model. SVR is a type of regression analysis that uses the concept of support vectors. It is a flexible method for regression and can handle both linear and non-linear problems. It can also handle high-dimensional data and is effective in high-noise situations. In material discovery, reinforcement learning (RL) can be applied to optimize the synthesis process [50]. Reinforcement Learning (RL) is an area of ML where an agent learns to make decisions by performing actions in an environment to achieve some goals. The agent receives feedback in the form of rewards or penalties, guiding it to learn the best strategy, known as a policy. RL involves trial and error, where the agent explores various actions and learns from the outcomes to optimize its behavior. This method is particularly useful in scenarios where explicit instructions on how to achieve a goal are not available, allowing the agent to autonomously discover effective strategies through iterative learning and adaptation. This approach is gaining traction in various fields, including robotics, gaming, and autonomous vehicles, due to its ability to adapt and improve through experience [50]. Two common RL algorithms are Q-learning and deep Q-Networks (DQNs). Q-learning is a model-free reinforcement learning algorithm that learns the value of an action in a particular state without requiring a model of the environment. A DQN combines deep learning with Q-learning to allow the agent to learn directly from raw pixels or other raw input. One of the key advantages of RL is that it focuses on the problem as a whole rather than dividing it into subproblems. It is capable of trading off short-term rewards for long-term benefits, and it does not require a separate data collection step, as training data are obtained via the direct interaction of the agent with the environment. To facilitate the application of these AI techniques, various open-source packages and frameworks have been developed, such as Scikit-learn [51], PyTorch [52], and Keras [53]. These packages provide access to a range of algorithms for users to practice using in drug discovery. Regression analysis algorithms play a crucial role in drug discovery, particularly in the prediction of the physicochemical properties of compounds. These algorithms can help optimize the drug development process by identifying compounds with desirable properties and reducing the time and cost of testing.

Regression analysis is a statistical method used in drug discovery to predict the outcome of an experiment based on the values of predictor variables [54]. In the context of drug discovery, the outcome could be a physicochemical property of a compound, such as its solubility, bioavailability, or toxicity [54]. Linear regression is a basic and commonly used regression analysis method. It models the relationship between a dependent variable and one or more independent variables by fitting a linear equation to the observed data [55]. In drug discovery, linear regression can be used to predict a physicochemical property of a compound based on its molecular descriptors [56]. Ridge regression is a type of linear regression that uses shrinkage, which is a technique for reducing the complexity of a model [57]. The shrinkage parameter (or tuning constant) determines the amount of the shrinkage: the larger the value of the shrinkage parameter, the greater the amount of the shrinkage [58]. Lasso regression is another type of linear regression that uses shrinkage and can also handle high-dimensional data [59]. The main difference between ridge and lasso regression is that lasso can result in sparse solutions, where some of the feature coefficients are exactly zero, excluding those features from the model [60]. SVR is a type of regression analysis that uses the concept of support vectors [38]. It is a flexible method for regression and can handle both linear and non-linear problems. It can also handle high-dimensional data and is effective in high-noise situations [38].

Classification involves assigning data points to one of several possible categories. In drug discovery, classification algorithms can be used to predict whether a compound is likely to be effective or not.

A support vector machine (SVM) is a type of supervised learning algorithm used for classification and regression analysis. It works by finding a hyperplane in a high-dimensional space that distinctly classifies the data points. In drug discovery, SVM can be used to classify compounds based on their properties and predict their effectiveness.

A convolutional neural network (CNN) is a type of deep learning algorithm that is primarily used for image processing. However, it can also be used in drug discovery for tasks such as predicting the properties of new molecules. A CNN can automatically learn and extract features from raw data, making it suitable for handling complex and high-dimensional data.

A recurrent neural network (RNN) is a type of deep learning algorithm that is particularly suited for processing sequential data. In drug discovery, an RNN can be used to predict the properties of new molecules based on their sequence data.

A generative adversarial network (GAN) is a type of deep learning algorithm that consists of two neural networks, the generator and the discriminator, which are trained in an adversarial manner to generate realistic data samples. In drug discovery, GANs are applied to generate new molecular structures with desired properties.

## Section: 2. AI in Discovering New Drugs › 2.1. AI Techniques Used in Material Discovery › 2.1.2. Unsupervised Learning Methods

Unsupervised learning involves using unlabeled data to identify patterns and relationships within the data. In drug discovery, unsupervised learning techniques can be used to identify novel material classes or to explore the chemical space of potential drug candidates.

Clustering (k-means) is a type of unsupervised learning technique that groups data points based on their similarity. In drug discovery, clustering can be used to identify groups of compounds with similar properties, which can help in identifying novel drug candidates.

Hierarchical clustering is a type of clustering technique that builds a hierarchy of clusters through either a bottom-up or top-down approach. In drug discovery, hierarchical clustering can be used to identify groups of compounds with similar properties at different levels of granularity.

Dimensionality reduction (PCA, t-SNE) techniques are used to reduce the number of variables in a dataset while retaining its essential characteristics. Principal component analysis (PCA) and t-distributed stochastic neighbor embedding (t-SNE) are two common dimensionality reduction techniques. In drug discovery, dimensionality reduction can be used to visualize high-dimensional data and identify patterns or trends that might not be apparent in the original data.

## Section: 2. AI in Discovering New Drugs › 2.1. AI Techniques Used in Material Discovery › 2.1.3. AI Algorithms Used in Drug Discovery

While traditional approaches used in drug discovery rely heavily on manual research, experimentation, and testing, AI-driven methods/algorithms leverage data-driven analysis, ML, and rapid simulation.

Collaborations between pharmaceutical companies and AI providers.

## Section: 2. AI in Discovering New Drugs › 2.1. AI Techniques Used in Material Discovery › 2.1.3. AI Algorithms Used in Drug Discovery

ML and DL are subsets of AI that have found applications in drug discovery. While they share some similarities, they have distinct differences in terms of their approach, architecture, and capabilities [61].

ML is a broad field that encompasses various algorithms that can learn patterns and make predictions based on data. These algorithms typically work with structured data, and they require feature engineering, where relevant features are selected or engineered before feeding the data into the model [61,62,63]. Feature engineering is a critical step in preparing the data for ML models [63]. Traditional ML algorithms require well-structured and labeled data for training. ML algorithms are generally simpler and require less computational power compared to DL models [61,62]. They can perform well on certain tasks with limited data but may struggle with highly complex and non-linear problems. Traditional ML models may require a substantial amount of labeled data to achieve good performance, especially in complex tasks. Traditional ML models are generally more interpretable, meaning it is easier to understand how the model arrived at its predictions based on the selected features and parameters [61,62].

On the other hand, DL is a specialized form of ML that uses artificial neural networks to learn representations of data [64]. These neural networks have multiple layers, allowing them to learn hierarchical features from raw data. Unlike traditional ML, DL models can automatically learn features from data, eliminating the need for extensive feature engineering [65]. DL models can handle unstructured data, such as images, texts, and sequences, without the need for extensive feature engineering. They learn hierarchies of representations directly from raw data, making them more suitable for handling complex and high-dimensional data [65]. DL models are more complex and require significant computational resources, especially when dealing with large datasets. They excel at handling complex patterns and non-linear relationships in data, making them particularly suitable for tasks like image and language processing [65]. DL models can often achieve better performance with less-labeled data due to their ability to automatically learn features and representations from the data. DL models are often considered less interpretable due to their multiple layers and complex learned representations. Understanding the decision-making process of DL models can be challenging. Gong D. et al. demonstrated how ML technology can be used to screen polymers for gene delivery in silico [66]. This work reported the application of state-of-the-art ML algorithms to a dataset of synthetic biodegradable polymers, PBAEs, which have shown promise for therapeutic gene delivery in vitro and in vivo [66]. The dataset included polymer properties as inputs as well as polymeric nanoparticle transfection performance and nanoparticle toxicity in a range of cells as outputs. These data were used to train and evaluate several state-of-the-art ML algorithms for their ability to predict transfection and understand structure–function relationships [66]. By developing an encoding scheme for vectorizing the structure of a PBAE polymer in a machine-readable format, the authors demonstrated that a random forest model can satisfactorily predict DNA transfection in vitro based on the chemical structure of the constituent PBAE polymer in a cell line-dependent manner [66]. Thus, a computational approach that encoded the chemical descriptors of polymers was able to demonstrate that the in silico computational screening of polymeric nanomedicine compositions had utility in predicting de novo biological experiments.

DL is a branch of AI that employs both supervised and unsupervised learning techniques, depending on the problem and data being analyzed [67].

High-throughput density functional theory (DFT) calculations are computationally expensive but vital for understanding material properties at the atomic level [68]. High-throughput DFT involves using efficient algorithms and parallelization to predict the properties of a large number of materials rapidly [68]. DFT has become increasingly relevant in drug discovery, where it plays a crucial role in understanding and predicting the interactions between drug molecules and biological targets.

High-throughput DFT can be used to calculate the binding energies and binding affinities between drug molecules and their target proteins [69]. These calculations help identify potential drug candidates with strong binding interactions, leading to a more efficient screening and selection of promising compounds. High-throughput DFT can be used in virtual screening to predict the binding affinities of a large library of drug-like compounds toward a specific target [70]. By virtually screening large numbers of compounds, researchers can prioritize the most promising candidates for further experimental validation. With the help of high-throughput DFT, researchers can investigate the nature of drug–target interactions at the molecular level [71]. It can identify key residues involved in binding and analyze the effects of ligand modifications on the binding affinity, which helps in the rational development of effective and selective drugs [72]. Algorithm high-throughput DFT can also predict physicochemical properties such as solubility, lipophilicity, and metabolic stability, which are crucial for assessing the pharmacokinetics and toxicity of a drug candidate [73]. These predictions guide the selection of compounds with favorable ADMET profiles and reduce the likelihood of failure in later stages of drug development. Also, high-throughput DFT can be used to study drug metabolisms by predicting the energy of various metabolic reactions such as hydroxylation or oxidation [74,75]. These predictions help identify potential metabolic sites and understand the metabolic pathways of drug candidates. On the other hand, high-throughput DFT can explore the conformational flexibility of ligands and identify the most stable conformers [76]. This information is critical for accurately representing ligand flexibility in molecular docking and molecular dynamics simulations and leads to more reliable binding predictions. High-throughput DFT can be used in fragment-based drug designing to analyze the binding of small fragments to a target protein. These calculations help select fragments that can be assembled into larger, more potent drug-like molecules [77].

NLP is a key AI technique used in text mining for drug discovery. NLP algorithms can process and interpret human language to extract relevant information from scientific literature, patents, clinical trial data, and other textual sources [78]. NLP-powered AI models can identify drug names, target proteins, chemical entities, and disease-related information, aiding researchers in gathering crucial data for drug discovery [78].

Text mining enables the identification of existing drugs with potential applications in different therapeutic areas [79]. By analyzing the literature, AI models can suggest drug candidates that have a demonstrated efficacy against specific diseases or targets, leading to drug repurposing opportunities and exploring the concept of polypharmacology [79]. AI models can integrate diverse data sources, such as clinical trial results, genomic data, and chemical databases, to build knowledge graphs [80]. Knowledge graphs represent complex relationships between drugs, targets, diseases, and biological pathways, facilitating comprehensive analysis and hypothesis generation [80]. Also, AI models can mine the literature to identify the adverse drug reactions reported in clinical studies and post-marketing surveillance. Extracting adverse drug reaction information from scientific literature helps improve drug safety assessments and informs decision-making in clinical trials [81]. Text mining by AI models can uncover the potential biomarkers associated with specific diseases or drug responses [82]. These biomarkers play a crucial role in personalized medicine, aiding in patient stratification and the development of targeted therapies.

Various text mining-based tools have been harnessed through AI-driven techniques to leverage their capabilities. For instance, Jang et al. introduced PISTON (http://databio.gachon.ac.kr/tools/PISTON/ (accessed on 1 February 2024)), a tool that employs NLP and topic modeling to predict drug side effects and indications [83]. DisGeNET (https://www.disgenet.org/ (accessed on 1 February 2024)) is a text mining-driven database offering a wealth of information on gene–disease and variant–disease relationships [84]. DisGeNET’s data analysis encompasses diverse biological processes, including adverse drug reactions, molecular pathways involved in diseases, and drug actions on targets. Another tool is STRING (https://string-db.org/ (accessed on 1 February 2024)), which represents a text mining-driven database. It offers an abundance of information on protein–protein interactions across various organisms [85]. In addition, STITCH (http://stitch.embl.de/ (accessed on 1 February 2024)) provides valuable information on interactions between proteins and chemicals–small molecules [86]. STITCH’s information is also utilized to determine drug binding affinities and drug–target associations.

GANs are a class of ML algorithms that consist of two neural networks, the generator and the discriminator, which are trained in an adversarial manner to generate realistic data samples [87]. In drug discovery, GANs are applied to generate new molecular structures [88] and optimize lead compounds [89], among other applications.

For example, GANs can generate novel molecular structures with certain desired properties. The generator network learns to produce realistic chemical structures, while the discriminator network evaluates their authenticity based on a training dataset. This process encourages the generator to produce new molecules that resemble the properties of known drugs, making GANs useful in de novo drug design [90].

Also, it was found that GANs can be employed to optimize lead compounds by generating modifications or analogs of existing drug candidates. By using the discriminator’s feedback to guide the generation of new chemical structures, GANs can propose modifications that are more likely to be biologically active and have improved pharmacological properties [91].

A number of studies have also shown that GANs can be used for multi-objective drug designing, where the goal is to optimize multiple drug properties simultaneously [41]. By adjusting the loss function of the GAN, researchers can balance various factors, such as the binding affinity, solubility, and selectivity, to generate molecules with desirable multi-objective profiles [41,89]. It should be noted that previous studies [92] have indicated that GANs can optimize specific molecular properties, such as the lipophilicity, molecular weight, or solubility. This capability allows researchers to fine-tune lead compounds or design molecules with the desired physicochemical properties [93].

According to the evidence to date, GANs can explore rare chemical space and identify molecules that are not commonly found in traditional drug databases. This capacity is valuable for discovering novel chemical entities with unique properties, potentially leading to the development of innovative drugs [94].

Studies show that GANs can be integrated into virtual screening pipelines to propose novel drug candidates. By generating diverse sets of molecules, GANs can expand the chemical diversity of virtual screening libraries and increase the chances of identifying hits against specific targets [95].

It should be noted that GANs can augment small datasets of known active compounds, enabling better generalization and improving the performance of predictive models by generating additional data samples [88]. Also, GANs enhance the efficiency and accuracy of the ML models used in drug discovery [96].

Present day science indicates that GANs can be used to predict drug–target interactions by generating molecular structures that are likely to interact with specific protein targets. The generated compounds can then be experimentally validated to identify potential novel drug–target interactions [94,97].

The other two AI algorithms used in drug discovery are transfer learning and active learning.

Transfer Learning makes it possible to fine-tune models that have been pre-trained on a larger dataset to cater to a specific material class or property using a smaller dataset. This is especially useful when there is a scarcity of labeled data. Transfer learning in drug discovery is an ML method that leverages knowledge gained from one task and applies it to another related task with limited data. This approach has shown great promise in addressing the challenge of sparsely labeled data in in silico drug discovery efforts [98]. In transfer learning, a pre-trained model developed for a specific task, such as image recognition, is used as a starting point for a new model targeting a different task, such as predicting drug–target interactions or identifying high-efficacy drug compounds [99]. By transferring the learned representations from the pre-trained model, the new model can benefit from the knowledge and generalization capabilities of the pre-trained model, even with a small amount of labeled data. In the past, quantitative structure–activity relationship (QSAR) models utilized regression models to establish links between molecule descriptors and biological properties [100].

In the field of drug discovery, ML techniques such as support vector machine algorithms and decision trees have been utilized for drug-like classification and the prediction of absorption, distribution, metabolism, excretion, and toxicity (ADME/T) properties [101,102,103]. Significant progress has been made in various areas through the use of AI technology, including predicting molecular properties and activities [104,105,106], virtual screening [107,108], retrosynthetic analysis [109,110], and generating new drugs [111,112]. Deep transfer learning, which involves using deep neural networks, is the most commonly used type of transfer learning in drug discovery [113]. Deep learning models, such as convolutional neural networks (CNN) and recurrent neural networks (RNN), have been applied to various drug discovery tasks, including compound activity prediction, virtual screening, and de novo drug designing [113]. These models can learn complex representations of chemical structures or biological data and transfer that knowledge to related drug discovery tasks. DL utilizes deep neural networks with multiple hidden layers to grasp and analyze complex knowledge, in contrast to traditional “shallow” ML approaches. Big data refers to datasets that are voluminous, diverse (i.e., originating from multiple sources), rapidly updated (i.e., in real-time), comprehensive (i.e., capturing the entirety of the system’s features rather than just samples), valuable (i.e., yielding numerous insights and potential for repurposing the data), and possess other defining characteristics [114]. Transfer learning offers a significant advantage in drug discovery by overcoming the challenge of limited and diverse datasets. Researchers can leverage pre-trained models to gain insights from vast and varied datasets in related fields [98]. For example, a pre-trained CNN model that has been trained on a large dataset of images can be fine-tuned and applied to analyze chemical structures or molecular fingerprints, enabling the prediction of compound activity or identifying potential drug–target interactions [98]. One useful application of transfer learning is its potential to speed up the process of discovering new drugs and enhance the effectiveness of identifying potent drug compounds. Through utilizing the knowledge stored in pre-existing models, researchers can decrease the amount of time and resources needed to train models from the ground up [98]. The method of using transfer learning in drug discovery enables faster testing and experimentation, which leads to speedy identification of promising drug candidates. Nevertheless, it is important to keep in mind that transfer learning in drug discovery is still an area of research with ongoing challenges and limitations to consider. One of these challenges is selecting the right pre-trained models and then fine-tuning them correctly. When choosing a pre-trained model, it is crucial to consider its relevance to the target task and the availability of appropriate datasets [35]. It is important to note that transfer learning does not always lead to better performance. This is particularly true when the source and target tasks are quite different. It is crucial to carefully assess how transferable the knowledge is between the tasks to ensure that the transferred representations are relevant and useful for the desired target task [98]. To sum up, transfer learning is a hopeful strategy in drug discovery which tackles the problem of insufficient labeled data and speeds up the detection of effective drug compounds. It involves using pre-trained models and applying knowledge from similar tasks to enhance the drug discovery process. This method can help researchers obtain useful representations and improve the efficiency of the process. However, there is still a need for more research to optimize the selection and fine-tuning of pre-trained models, and to explore the broader possibilities of transfer learning in drug discovery.

On the other hand, through the active selection of informative samples, active learning can determine which materials to test or simulate next, significantly reducing the number of experiments required. The use of AI techniques in material discovery has led to impressive advancements in drug discovery. By leveraging the power of computation and data-driven insights, researchers can more efficiently design and discover materials with customized properties for various applications. This ultimately accelerates innovation across industries [98]. Active learning is an ML technique used in drug discovery. Its goal is to improve the selection of compounds for experimental testing by iteratively selecting the most informative samples to label. This approach reduces the need for the exhaustive screening of large compound libraries and focuses on areas of chemical space with the highest potential for success while also considering structural novelty [115]. Active learning involves starting with a small group of labeled compounds and continuously choosing more compounds to label based on the model’s predictions. The selected compounds are then tested and the results are used to update the model and improve the selection process for future cycles [115]. By actively choosing which compounds to label, active learning algorithms can effectively navigate and utilize the chemical space, resulting in more efficient and cost-effective drug discovery processes. These algorithms strive for greater predictive accuracy using fewer labeled samples than traditional passive learning methods [115]. There are many drug discovery tasks that can benefit from active learning methods. These include predicting compound activity, optimizing leads, and virtual screening. Active learning can be used with various ML models, such as SVM, RF, and neural networks [115]. Active learning in drug discovery offers several benefits, including saving costs and resources. This is achieved by selecting a targeted subset of compounds for experimental testing, thereby reducing the need for extensive screening and saving time and resources [115]. Active learning algorithms can efficiently explore chemical space by choosing compounds that are likely to yield valuable information. This approach leads to a more targeted and effective drug discovery process [115]. Active learning can enhance the model’s predictive accuracy by regularly updating it with experimental feedback. This process leads to more precise predictions of compound activities over time [115]. When it comes to implementing active learning in drug discovery, there are some challenges and factors to consider. One of the biggest is choosing the right ML model and optimizing its parameters, which is crucial for success. It is important to find a model that can comprehend the complex connections between the chemical structures and activities, and the optimization process itself should be thoughtfully designed to balance exploration and exploitation. The selection of compounds for labeling is another vital step in active learning, and there are various strategies to consider, including uncertainty sampling, querying by committee, and diversity-based sampling. The best approach will depend on the task at hand and the data available. Finally, integrating active learning into existing drug discovery workflows may require some adjustments and considerations. The infrastructure, experimental design, automation, and data management should all be aligned with the active learning process to maximize its benefits [115]. To summarize, active learning is an effective method in drug discovery that leads to faster and more precise compound selection for testing. This is achieved by repeatedly selecting compounds based on the model’s predictions and experimental results. Active learning lowers expenses, enhances the exploration of chemical space, and improves predictive precision. However, it is crucial to thoughtfully select the models, data selection strategies, and workflow integration in order to successfully integrate active learning into drug discovery pipelines.

In the end of Section 2, we have centralized in Table 2 some collaborations between pharmaceutical companies and AI providers.

Collaborations between pharmaceutical companies and AI providers.

## Section: 3. Studies of AI-Assisted Drug Discovery

AI offers a powerful tool for drug discovery, with applications ranging from predicting drug properties to generating new chemical structures and optimizing drug properties (Figure 5). One of the most common applications of AI in drug discovery is through the use of ML algorithms. These algorithms can learn from large datasets of chemical structures and biological data to predict the properties of new compounds, such as their ability to bind to a target protein (affinity prediction) or their toxicity (toxicity prediction). This can help to identify potential drug candidates that can be tested in the lab. Another application of AI in drug discovery is through the use of GANs that can be used to generate new chemical structures that are likely to bind to a target protein based on the chemical structures of known active and inactive compounds. AI can also be used in drug discovery for multi-objective optimization, where the goal is to optimize a drug for multiple desirable properties, such as high efficacy, low toxicity, and good solubility.

Applications of artificial intelligence in drug discovery.

AI tools/platforms already used in drug discovery.

## Section: 3. Studies of AI-Assisted Drug Discovery › 3.1. AI Programs and Platforms Used for Drug Discovery

Different AI tools/platforms are already used in drug discovery (Table 3).

For example, an MLP model uses a Python-based AI system to find a suitable candidate in drug discovery (DeepChem) and can be accessed at [116].

Another Python-based system driven by computational tools can aid the detection of the molecular activity of compounds (DeepNeuralNetQSAR) and can be found at [117].

On the other hand, there exists a program that helps to report the procedure for chemical synthesis in a standardized format (Chemputer) [118].

The Tox21 Data Challenge tested 12,000 chemicals for toxic effects using specially designed assays. DL was used in this example to predict toxicity. DeepTox software outperformed other methods, proving DL to be a superior method for toxicity prediction [119].

AlphaFold is an AI program developed by DeepMind, a subsidiary of Alphabet, that predicts the 3D structures of proteins. The program utilizes deep learning techniques and has been highly successful in protein structure prediction. AlphaFold participated in the Critical Assessment of Structure Prediction (CASP) competition and achieved remarkable accuracy in predicting protein structures, outperforming other groups [120]. AlphaFold has undergone two major versions: AlphaFold 1 (2018) and AlphaFold 2 (2020). In both versions, the program demonstrated exceptional performance in predicting protein structures. AlphaFold 2, in particular, achieved a level of accuracy much higher than any other group in the CASP competition. It scored above 90 for approximately two-thirds of the proteins in the global distance test (GDT), a measure of how closely the predicted structure aligns with the experimentally determined structure.

The success of AlphaFold has been regarded as a significant breakthrough in the field of structural bioinformatics. However, it is important to note that while AlphaFold has achieved remarkable accuracy, there are still challenges to be addressed, and the protein folding problem is not considered completely solved. Nonetheless, the technical achievement of AlphaFold has garnered widespread respect and has the potential to accelerate the advancement of structural bioinformatics.

AlphaFold utilizes an AI-based approach called Evoformer, which treats protein structure prediction as a graph inference problem in 3D space. This approach involves updated operations applied in series within each block of the network. The pair representation in AlphaFold encodes information about the relationships between the residues, while the MSA (multiple sequence alignment) representation encodes individual residues and the sequences in which they appear. The MSA representation updates the pair representation through an element-wise outer product, allowing continuous communication between the evolving MSA representation and the pair representation. This approach enables the accurate prediction of protein structures [121]. The development of AlphaFold has the potential to revolutionize structural bioinformatics and accelerate the advancement of our understanding of protein structures. By combining AI techniques with curated structure and sequence databases, it can help bridge the gap between genomics and experimental structure determination, leading to a deeper understanding of biological processes and the development of new therapies [121].

ORGANIC [122] is a molecular generation tool that helps create molecules with certain desired properties. It utilizes generative ML approaches and deep neural networks to enable the design of novel molecular materials. The goal-directed generative model powered by deep neural networks and high-throughput simulations allow for a more directed design approach, minimizing design bias and enabling the exploration of specific material’s property spaces [123]. One of the key applications of ORGANIC is in the design of organic electronic materials, such as those used in organic light-emitting diodes (OLEDs). By leveraging generative ML frameworks, such as recurrent neural networks (RNNs) and deep RL, ORGANIC can rapidly identify new materials for OLED applications. This approach accelerates the development of novel organic electronic materials while also enabling expansion into other domains like catalyst design, aerospace, life science, and petrochemicals [123].

Another area where ORGANIC can be applied is in the virtual design of organic semiconductors based on metal–organic frameworks (MOFs). MOFs offer a supramolecular approach to modulate the arrangement of organic semiconductor molecules, allowing for the tailoring of the material properties. ORGANIC can automate the design process by generating MOF structures, sampling their structural dynamics, and predicting properties such as the conduction properties, absorption, and interaction with light. This automated workflow tool enhances the modeling and characterization of a wide variety of MOFs [124].

The development of ORGANIC provides researchers with a powerful tool for molecular generation and property optimization. By leveraging ML techniques and high-throughput simulations, it enables the rapid exploration of chemical space and the design of molecules with the desired properties. The availability of user-friendly interfaces and its integration with existing computational chemistry software, such as VASP and Gaussian, further enhances its usability and applicability in various research domains [125].

PotentialNet [126] is a program that utilizes neural networks to predict the binding affinity of ligands in protein–ligand complexes. It employs deep attention mechanisms and descriptor embeddings to improve the accuracy of binding affinity prediction [127]. The program focuses on intermolecular interactions within the molecular complex to capture important descriptors for an accurate prediction [127]. The approach used in PotentialNet involves representing the molecular complex as a 1D vector based on the descriptor information obtained from the training dataset. The descriptors are generated for the contacted protein and ligand atom pairs in the complex. The distance between the protein atom and the ligand atom pair is calculated using the Euclidean distance, with a cutoff value typically set at 12 Å [127]. The program considers various intermolecular interactions, including steric interactions, hydrophobic interactions, and hydrogen bonding.

The model architecture of PotentialNet incorporates an attention mechanism, which highlights important descriptors for a binding affinity prediction [128]. This mechanism helps capture the binding sites in the protein–ligand complex and improves the overall prediction performance. The program also utilizes a deep neural network model, specifically a PUResNet architecture, which consists of encoder and decoder blocks with skip connections [128].

To evaluate the performance of the binding affinity models, several metrics are used, including the mean absolute error (MAE), root mean square error (RMSE), Pearson’s correlation coefficient (PCC), Spearman’s correlation coefficient (SCC), and the standard deviation in regression (SD) [127]. The selection of an optimal number of descriptors is conducted by training a random forest model and sorting the descriptors according to their priorities. The model is then trained using different numbers of descriptors, and the performance is evaluated to determine the optimal number [127].

Hit Dexter is an ML technique used for predicting molecules that might respond to biochemical assays. It is an ML model specifically designed for hit discovery in the drug discovery process. Hit discovery involves identifying small molecules that have the potential to bind to a target and alter its function. By applying diverse algorithms and multivariate parameters, Hit Dexter aims to identify hits against specific biological targets or neurological complications [35].

One of the key components of Hit Dexter is the utilization of deep learning techniques to extract and analyze the chemical and physical properties of molecules. For example, deep learning models have been used to predict properties such as the absorption, distribution, metabolism, and excretion (ADME) of drug candidates. These models incorporate molecular graphs and utilize concepts like CNNs and ANNs to predict properties such as oral drug absorption. By considering various molecular descriptors and using ML algorithms like SVM regression and boosting, accurate predictions can be made [35].

Another aspect of Hit Dexter is the use of QSAR models. QSAR models leverage deep learning techniques to extract features from chemical strings and automatically extract relevant molecular descriptors. These models have shown promising results in hit-to-lead optimization research, providing predictions for binding affinities and aiding in the selection of potential drug candidates [35].

The application of Hit Dexter extends beyond drug discovery. It can also be used in the prediction of bioactivity, prognosis of prote–protein interactions, homology modeling/prediction of protein folding, and digital pathology [35].

DeltaVina [129] is a scoring function used for rescoring the binding affinity between proteins and ligands. It incorporates ML techniques and diverse algorithms to improve the accuracy of binding affinity predictions [130]. DeltaVina is designed to improve the accuracy of scoring the protein–ligand binding affinity. It utilizes various ML algorithms, including XGBoost and random forest, to incorporate different molecular descriptors and features. The performance of DeltaVina has been evaluated on benchmark datasets and compared to classical scoring functions, demonstrating its effectiveness in predicting binding affinities and identifying potential drug candidates. The scoring function and its code are available for use and further research [131].

The neural graph fingerprint [132] is a technique used to predict the properties of novel molecules. It involves generating molecular sentences and encoding them using a language model, such as BERT, to obtain high-dimensional embeddings of the substructures. These embeddings represent the molecules in vector form, which can be used for downstream tasks like molecular property prediction [133].

Once the molecular sentences are constructed, they are encoded using a language model, such as BERT. This pre-trained model can generate high-dimensional embeddings of the substructures, representing the molecules in vector form. These embeddings capture important features and structural information of the molecules, which can be used for predicting their various molecular properties [133]. To evaluate the performance of the prediction model, different metrics are used. For example, for classification tasks, the cross-entropy loss function is used, and the prediction performance is evaluated using the ROC-AUC (the area under the receiver operating characteristic curve) [133]. The ROC-AUC represents the ability of the model to distinguish between positive and negative samples. On the other hand, for regression tasks, the mean squared error (MSE) loss function is used, and the prediction performance is evaluated using the root mean squared error (RMSE) and the coefficient of determination (R2) [133]. The RMSE measures the average squared difference between the predicted and real property values, while the R2 reflects the goodness of fit and prediction. The neural graph fingerprint, with its molecular sentence generation and language model-based encoding, offers a powerful approach for predicting the properties of novel molecules. By leveraging deep learning techniques and molecular embeddings, it enables accurate predictions and the analysis of various molecular properties [133].

GastroPlus [134] is a platform that utilizes AI and predictive modeling to aid in the design and optimization of drug formulations. This software is used for pharmaceutical products (dosage form) in many animal models, including rats, primates, and animals, allowing researchers to predict the drug absorption, distribution, metabolism, and excretion [135]. GastroPlus’s AI-driven approach aids in the development of more effective and bioavailable drug formulations, streamlining the drug development process.

AI tools/platforms already used in drug discovery.

## Section: 3. Studies of AI-Assisted Drug Discovery › 3.2. Example of AI in Drug Design

Next, we will present some examples which cover a range of topics related to AI in drug design, including the integration of AI in drug discovery, the prediction of drug–protein interactions, and practical guidelines for using ML algorithms. They provide valuable insights into the use of AI in the pharmaceutical industry and offer potential solutions to challenges in drug design and development.

For example, Paul D. et al. discusses the integration of artificial intelligence in drug discovery and development, including the tools and techniques used. They also highlight ongoing challenges and ways to overcome them [14].

Dara S. et al. explores various applications of artificial intelligence in drug design, including in the prediction of drug–protein interactions, the discovery of drug efficacy, and ensuring safety biomarkers [35].

Jiménez-Luna et al. focuses on explaining compound activity predictions using a substructure-aware loss for graphing neural networks. They explore the use of deep learning in predicting molecular properties [24]. They also provide practical guidelines for using gradient boosting in molecular property prediction. They offer insights into the application of ML algorithms in drug design.

Schneider et al. discuss the foundation of artificial intelligence in therapeutic science, including its applications in drug design. They explore adaptive graph learning methods for automated molecular interactions and property predictions [136].

The iterative process to design the 3D structures of receptors to generate a novel molecule is termed de novo drug designing, which is intended to produce new dynamics. Researchers utilized the indolent space portrayal to prepare a model dependent on the quantitative estimate of the drug likeness and drug similarity scores, and the manufactured availability score and synthetic accessibility score [137].

## Section: 3. Studies of AI-Assisted Drug Discovery › 3.3. Examples Cases of AI Used in Polypharmacology

Next, we present some examples of papers that shed light on the application of AI in polypharmacology and drug discovery. They discuss how AI can be used to predict drug–protein interactions and design safer drug molecules. Understanding polypharmacology is crucial in developing drugs that are effective against multiple targets while minimizing off-target effects. These papers provide valuable insights into the advancements and challenges in this field and offer potential strategies for improving drug design and development. Chauhari et al. explain the concept of polypharmacology, which refers to the tendency of a drug molecule to interact with multiple receptors, leading to off-target effects. They explore how artificial intelligence can aid in the design of safer drug molecules by considering polypharmacology [138].

Reddy et al. [139] provide an overview of polypharmacology studies and the challenges involved. They discuss the potential of a rational design using polypharmacology to develop more effective and less toxic therapeutic agents. The review outlines the latest progress in this field. Other authors [140] explore polypharmacy using AI and data analysis. The AI axis focuses on defining and detecting polypharmacy using algorithms to predict health outcomes based on medication combinations.

The use of AI in pharmaceutical product development is also discussed in a review [14]. The review suggests that AI can replace the traditional trial-and-error method in designing formulations. Computational tools, including quantitative structure–relationship (QSPR) models and decision-support tools, can help address issues related to formulation design such as stability, dissolution, and porosity. Furthermore, the integration of AI with mathematical models like computational fluid dynamics (CFD) can speed up the production of pharmaceutical products [14].

The involvement of AI in the development of a pharmaceutical product from the bench to the bedside can be imagined given that it can aid rational drug design [141]; assist in decision making; determine the right therapy for a patient, including personalized medicines; and manage the clinical data generated and use it for future drug development [142]. E-VAI is an analytical and decision-making AI platform, developed by Eularis, which uses ML algorithms along with an easy-to-use user interface to create analytical roadmaps based on the competitors, key stakeholders, and currently held market share to predict key drivers in the sales of pharmaceuticals [143], thus helping marketing executives allocate resources for the maximum market share gain, reversing poor sales and enabling them to anticipate where to make investments.

## Section: 3. Studies of AI-Assisted Drug Discovery › 3.4. Example Cases of AI in Drug Chemical Synthesis

The following example cases of AI in drug chemical synthesis highlight the use of artificial intelligence and ML in drug chemical synthesis. They explore the application of DL models in de novo drug design, the prediction of reaction outcomes, and the optimization of synthetic routes. The integration of AI with chemical knowledge and data-driven approaches has the potential to accelerate the drug discovery process and facilitate the design of new drug molecules. The paper by Paul D. et al. [14] is focused on the application of DL in drug discovery and medicinal chemistry, including the synthesis of new drug molecules. It explores the use of generative models and RL for de novo drug design and optimization.

Jiménez-Luna et al. [24] describe the use of AI in synthetic organic chemistry, specifically in reaction prediction, retrosynthesis, and reaction optimization. They discuss the integration of ML algorithms with chemical knowledge for efficient and automated synthesis planning. Their paper introduces DeepChem, a deep learning toolkit designed for drug discovery tasks. It covers various applications, including the generation of novel chemical structures, predicting chemical properties, and optimizing synthetic routes. The paper highlights the potential of deep learning in accelerating the drug discovery process. It also presents ML models for predicting the outcomes of organic reactions, including the yield and regioselectivity. It discusses the use of reaction fingerprints and molecular descriptors as input features for predicting reaction outcomes. The study demonstrates the potential of ML in guiding synthetic chemistry efforts.

## Section: 3. Studies of AI-Assisted Drug Discovery › 3.5. Case Examples of AI Used in Drug Screening

These examples provide insights into the application of AI in drug screening and discovery. They highlight the use of AI algorithms for identifying novel compounds, designing new drug candidates, and predicting protein structures. The integration of AI in drug screening processes can help accelerate the discovery of potential drug candidates and optimize the drug discovery pipeline.

Paul D et al. [14] discuss the integration of AI in various sectors of the pharmaceutical industry, including drug discovery and development. They highlight the use of AI in drug screening and repurposing, reducing the human workload, and accelerating the achievement of targets. Their paper also discusses the ongoing challenges and the potential ways to overcome them, along with the future of AI in the pharmaceutical industry.

Blanco-González et al. [3] present case studies demonstrating the successful application of AI in drug discovery. They showcase examples where AI algorithms have been used to identify novel compounds for cancer treatment, inhibitors for specific proteins involved in diseases like Alzheimer’s, and potential drugs for combating COVID-19. Their paper highlights the ability of AI to accelerate the drug discovery process and enable the development of more effective medications. It explores the impact of AI on the drug discovery process, with a focus on the design of novel compounds. It discusses how AI-based approaches, such as deep learning algorithms, can rapidly and efficiently design new drug candidates with desirable properties and activities. The paper also mentions the use of AI in structural biology, such as the development of AlphaFold, a software platform that uses AI to predict protein structures. This advancement has the potential to revolutionize personalized medicine and drug discovery.

Discovering drugs through AI models is a topic discussed on nexocode.com [144]. By analyzing large amounts of data, AI models can detect correlations that were previously unknown. This technology is being utilized in drug discovery to identify new drugs, design drug candidates, and assist in preclinical testing. AI is also being used to screen chemical repositories, identify new drug targets, and aid in computer-assisted molecular design.

A recent study showcased the use of AI in material discovery, as seen on unibas.ch [145]. The study’s author, a doctoral student, utilized quantum mechanics to generate predictions for thousands of crystals that had randomly determined chemical compositions. These predictions served as training data for statistical ML models. The ML models demonstrated an accuracy level equivalent to standard quantum mechanical approaches, but with the added benefit of speed. In a day, ML models can provide predictions, while quantum mechanical calculations would take a supercomputer over 20 million hours.

An interesting example is found on popularmechanics.com [146], where researchers used AI to develop a new type of compressible material. They did not have to rely on trial-and-error experimentation because they used existing research and AI algorithms to create new designs. This approach made the material discovery process much faster and allowed scientists to explore more design possibilities. The research also showed how important data-driven methods are in materials science. AI can suggest new approaches and designs as long as there are enough accurate data available.

The use of AI in the field of medicine goes beyond discovering new materials. According to ibm.com [147], AI has the potential to support precision medicine by providing patients with real-time recommendations that are tailored to their medical history, preferences, and needs. AI-powered virtual assistants are available 24/7 to provide healthcare information and address patient queries. Furthermore, AI is employed in medical imaging to detect diseases like breast cancer with comparable accuracy to human radiologists. Additionally, AI can help clinicians make sense of vast numbers of medical images and data, making them more manageable and enhancing patient care.

Healthcare is an ever-evolving field that is exploring the potential of AI in various medical domains. A comprehensive overview of AI in healthcare can be found on en.wikipedia.org [148]. In oncology, AI is used for cancer diagnosis, risk stratification, the molecular characterization of tumors, and drug discovery. For instance, AI algorithms have shown high accuracy in identifying breast cancer and prostate cancer. AI techniques such as artificial neural networks and Bayesian networks are used to diagnose and classify diseases. With the assistance of electronic health records, AI can analyze large amounts of data and help doctors with a patient’s diagnosis and treatment. Physics-inspired ML approaches are also being explored to enhance medical diagnostic approaches and perform biomarker analysis.

To benchmark and test AI applications in the health domain, the United Nations (WHO/ITU) has established the ITU-WHO Focus Group on Artificial Intelligence for Health (FG-AI4H). They are working on various cases for its use such as in assessing breast cancer risk, guiding antivenom selection, and diagnosing skin lesions.

The market potential of AI applications in drug discovery and development is immense. AI has emerged as a powerful tool in the pharmaceutical industry, revolutionizing the way new drugs are discovered, developed, and brought to market. With its ability to analyze vast amounts of data, AI offers the potential to accelerate the drug development process, reduce costs, and improve the success rate of bringing new medicines to patients.

Pharmaceutical companies, research institutions, and startups are increasingly investing in AI technologies to streamline drug discovery processes and gain a competitive edge in the market. Partnerships between AI companies and pharmaceutical giants are becoming more common, fostering the development of innovative drug discovery platforms.

## Section: 3. Studies of AI-Assisted Drug Discovery › 3.6. AI in Drug Discovery and Repurposing

In this section we provide information on different drugs discovered by means of AI, highlighting AI’s significant role in drug discovery, accelerating the identification of potential drug candidates and optimizing drug development processes. In the following, we present some drugs that have been discovered or aided by AI.

Zong et al. [149] explore a computational drug repurposing application by using electronic health records (EHRs) to discover new applications for approved or investigational drugs. Their review identified four themes: publication venues, data types and sources, data processing and prediction methods, and targeted diseases, validation, and released tools. The utilization of EHRs in drug repurposing is hindered by validation, accessibility, and understanding issues.

Yadi et al. [150] introduce guidelines on how to use AI for accelerating drug repurposing or repositioning. They present how to use AI models in precision medicine, and as an example, how AI models can accelerate COVID-19 drug repurposing.

In the paper by Wang et al. [151], a novel scoring algorithm, DrugRepo, uses chemical and genomic data to repurpose drugs for various diseases. In total, 516 approved drugs have been repurposed for 545 diseases using DrugRepo. Hundreds of novel predicted compounds have the potential for matching ongoing clinical trials.

Different research groups used AI algorithms to discover that naproxen, a commonly used pain reliever, has potential antiviral properties. An excellent illustration of an in silico and target-based technique for finding novel antivirals is naproxen. Lejal et al. used the X-ray structure of the RNA-free NP of H1N1 as a prototype to develop a structural-based modeling technique to find potential medications that target the nucleoprotein (NP) of the influenza A virus [152]. The non-steroidal anti-inflammatory medication naproxen, a well-known inhibitor of inducible cyclooxygenase type 2 (COX-2), was discovered using an in silico screening that was concentrated on a selected particular location of the NP structure. AI models identified this drug as potential inhibitors of a viral enzyme, providing valuable insights for future antiviral drug development [152]. In another study, naproxen demonstrated antiviral properties against SARS-CoV-2 using an in silico molecular docking analysis (using Autodock Vina) [153].

By using molecular modeling and virtual screening studies, Mostafa et al. tested the antiviral activity of anti-microbial and anti-inflammatory FDA-approved drugs, commonly prescribed to relieve respiratory symptoms, against SARS-CoV-2 [154]. The docking study was performed using OpenEye scientific software version 2.2.5. A virtual screening study illustrated that Azithromycin, Niclosamide, and Nitazoxanide bind to the main protease of SARS-CoV-2.

Baricitinib is an oral Janus kinase (JAK)1/JAK2 inhibitor approved for the treatment of rheumatoid arthritis. The Eli Lilly and Incyte Corporation used AI algorithms to analyze large-scale datasets to predict its usefulness on COVID-19 infection through planned anti-cytokine effects and as an inhibitor of host cell viral propagation [155].

DSP-1181 was Developed by Sumitomo Dainippon Pharma and Exscientia. It is a drug designed using AI algorithms [156]. It became the first AI-designed drug to enter human clinical trials for the treatment of obsessive-compulsive disorder (OCD). DSP-1181 is a long-acting, potent serotonin 5-HT1A receptor agonist [156]. AI played a pivotal role in the drug’s discovery by rapidly analyzing vast datasets, identifying potential drug candidates, and optimizing the molecular structures to enhance their therapeutic effects. The successful progression of DSP-1181 to clinical trials showcases the potential of AI in expediting drug development for challenging neurological disorders [156].

DSP-2230 was also Developed by Sumitomo Dainippon Pharma and Exscientia, by means of AI-design, and is being investigated for the treatment of OCD. AI algorithms were utilized to analyze biological data and identify the novel compounds that can modulate the specific brain receptors implicated in the disorder [157].

Berzosertib (formerly M6620, VX-970), developed by Merck KGaA and C4X Discovery [158], is a promising drug investigated for its applications in targeting the DNA repair mechanisms in various cancers. AI played a significant role in identifying Berzosertib as a potential candidate for cancer treatment [159]. Through the AI-driven analysis of genetic and molecular data, researchers could pinpoint specific DNA repair pathways that the drug could effectively target, making it a promising addition to cancer therapy.

Halicin is a revolutionary antibiotic discovered by MIT researchers through the application of AI models [160]. It demonstrated remarkable effectiveness against a wide range of bacterial infections, including drug-resistant strains [161]. AI enabled the screening of a vast number of chemical compounds to identify Halicin as a potent antibiotic. The discovery of Halicin highlights the potential of AI in quickly identifying new classes of antibiotics to combat the growing problem of antibiotic resistance.

Evinacumab is a drug developed by Regeneron Pharmaceuticals using AI [162]. The drug was identified as a potential therapy for homozygous familial hypercholesterolemia (a rare genetic disorder characterized by extremely high cholesterol levels), refractory hypercholesterolemia (both familial and non-familial), and severe hypertriglyceridaemia [162]. AI algorithms were utilized to analyze vast datasets of genetic and biochemical information to identify the specific targets and pathways involved in cholesterol regulation. This helped researchers identify evinacumab as a monoclonal antibody that binds to and blocks an enzyme called ANGPTL3, thereby reducing cholesterol levels in affected individuals [162].

The Amarin Corporation developed Icosapent Ethyl to reduce cardiovascular risk [163]. The AI-driven analysis of clinical trial data helped demonstrate the drug’s effectiveness in reducing cardiovascular events in patients with high triglyceride levels, leading to its approval by regulatory authorities. Icosapent Ethyl is a high-purity prescription form of EPA ethyl ester approved by the US Food and Drug Administration at a dose of 4 g/day as an adjunct to diet to reduce plasma triglyceride levels in adults with severe hypertriglyceridemia [164].

LegoChem Biosciences, using AI models, developed Delpazolid (LCB-010371) as a potential antibiotic with effectiveness against drug-resistant bacteria, including Methicillin-resistant Staphylococcus aureus (MRSA) and Vancomycin-resistant Enterococci (VRE) [165]. AI-driven drug discovery methods were employed to identify Delpazolid as a novel antibiotic candidate. LegoChem Biosciences utilizes its ConjuAll and Legochemisty platform technologies to discover and develop drugs.

InSilico Medicine has used their AI platform Pharma.AI™ to develop INS018-055 to help treat idiopathic pulmonary fibrosis [166]. Targeting the discoidin domain receptor 1 (DDR1) is how INS-08055 works. DDR1, an epithelial cell-expressed pro-inflammatory receptor tyrosine kinase involved in fibrosis, is activated by collagen and inhibited by INS-08055. The medication candidate, which is delivered orally and intravenously, improves illness symptoms by inhibiting DDR1 [166].

Developed by Merck & Co., Pembrolizumab (Keytruda) is an AI-discovered drug used for the treatment of various cancers, including melanoma, lung cancer, and head and neck cancers [167].

The UK Medicines and Healthcare Products Regulatory Agency (MHRA) has received a clinical trial application from BenevolentAI for BEN-8744, a small molecule phosphodiesterase 10 (PDE10) inhibitor that is intended to treat ulcerative colitis [168].

Sotorasib (AMG 510), developed by Amgen, is an AI-optimized drug used for the treatment of non-small cell lung cancer with specific genetic mutations. AI algorithms were used to analyze cancer genomic data and identify potential compounds that selectively inhibit the mutated protein responsible for tumor growth [169].

The above-mentioned drug examples highlight the diverse applications of AI in drug discovery and development, from optimizing drug structures and formulations to identifying novel targets and repurposing existing drugs for new indications. AI technologies continue to revolutionize the pharmaceutical industry, enabling more efficient and targeted drug development processes that hold the potential to transform patient care and treatment outcomes.

## Section: 4. The Market Prospects of AI-Based Drug Development

Pharmaceutical companies are converting to AI solutions to reduce the financial costs and potential losses connected with virtual screening. Between 2015 and 2018, the AI market grew from USD 200 to USD 700 million, and by 2024, it is expected to reach USD 5 billion [170]. An expected 40% increase from 2017 to 2024 suggests that AI may reshape the pharmaceutical and medical industries. Many pharmaceutical companies have invested in AI or are continuing to do so, as well as collaborating with AI service providers to develop critical medical equipment. Examples of collaboration are given in Table 4.

Collaborations of pharmaceutical companies with AI providers/developers for various applications.

## Section: 5. Challenges and Limitations in AI-Assisted Drug Discovery

The use of AI to aid in the discovery of new materials holds immense potential in developing materials with specific properties for diverse applications. However, there are challenges and limitations that need to be acknowledged and addressed to ensure its effective implementation [3].

One of the main challenges highlighted in our paper is related to the quality and quantity of data. AI models require a large volume of high-quality data for training. In materials science, obtaining comprehensive and dependable datasets can be difficult due to the vast number of materials and properties that can be taken into consideration. Incomplete or inaccurate data can result in biased or erroneous predictions.

Therefore, reliable and high-quality data are the foundation of AI-assisted research. Industries must ensure that the data used for training AI models are precise, representative, and related to the specific research objectives. It is crucial to address data limitations, such as biases or incomplete datasets, to avoid skewed results and unreliable conclusions.

When it comes to discovering new materials, there are several important factors to consider. Firstly, data representation is key. This involves transforming complex material data, like crystal structures or chemical compositions, into formats that AI models can understand. It is important to develop representations that capture essential features while remaining interpretable [171].

Algorithm selection and development is also crucial. The appropriate AI algorithms for a material’s discovery will depend on the specific problem at hand. Developing custom algorithms that can handle the unique challenges of material data, such as high dimensionality and non-linear relationships, requires expertise in both AI and materials science.

While AI models can predict material properties with impressive accuracy, interpreting the underlying reasons for these predictions remains a challenge. Understanding the relationship between the input features and output properties is essential for guiding further research and design.

Finally, effective material discovery often requires the integration of domain-specific knowledge, such as quantum mechanics or thermodynamics. Combining AI techniques with specialized scientific insights is essential to ensure accurate predictions and meaningful discoveries [14].

When training data are biased, AI models may not perform well when presented with new materials or conditions. It is crucial to ensure diversity and representativeness in the training dataset to avoid this issue. However, researchers may face limitations in accessing a powerful computing infrastructure, which is often necessary for resource-intensive tasks, such as simulating material properties at different scales or conducting high-throughput calculations. Additionally, the vast and intricate search space of potential materials can pose a challenge when trying to find the optimal candidate. Advanced optimization techniques are required to explore this space efficiently [172].

It is also important to validate AI model predictions through experimental testing, which can be a time-consuming and costly process. Moreover, discovering new materials with advanced properties raises ethical and safety concerns. AI-assisted discoveries must be safe, environmentally friendly, and compliant with regulations. Industries must establish ethical guidelines that ensure responsible data usage, transparent algorithms, and the fair treatment of all stakeholders to address these concerns. Overall, AI-assisted research presents exciting opportunities but also requires the careful consideration of these issues [173]. When incorporating AI tools into the material discovery process, researchers must adjust their workflows and thinking. Cooperation between materials scientists and AI specialists is crucial for the optimal usage of these tools. AI-assisted material discovery offers exciting possibilities for revolutionizing the field by speeding up the identification of materials with the desired properties. However, the challenges and limitations mentioned above stress the importance of interdisciplinary collaboration, better data organization, innovative algorithms, and ethical and scientific considerations. Overcoming these obstacles will lead to the successful integration of AI in material discovery and ultimately fuel innovation across various industries [174].

Industries that handle sensitive or proprietary data should prioritize data security and implement strong measures to safeguard information against unauthorized access and breaches. It is crucial to balance the benefits of AI-powered insights with data security concerns. To ensure the reliability and applicability of AI-generated insights across various contexts, rigorous validation procedures are essential. Since AI-assisted research often requires significant computational resources, including powerful hardware and significant energy consumption, industries need to assess their computational needs and allocate resources effectively. Industries should implement strategies to identify and mitigate biases in AI models that may inadvertently perpetuate the biases present in the training data. In regulated industries, AI-assisted research must comply with relevant regulations and standards. To reap the full benefits of AI-driven research outcomes, industries must commit to long-term strategies that require continuous investment in updating models, refining algorithms, and adapting to evolving research needs. In fostering a collaborative environment, industries must encourage researchers to work alongside AI systems, leveraging their strengths to make more informed decisions and discoveries, and augmenting human capabilities [3]. To sum up, utilizing AI in research can lead to groundbreaking discoveries and drive innovation in various industries. However, it is crucial to carefully consider important factors such as data quality, ethics, expertise, security, and collaboration to ensure successful implementation. By thoughtfully addressing these considerations, industries can fully utilize the potential of AI to revolutionize their research practices and achieve unprecedented levels of discovery and innovation [3].

## Section: 6. Future Directions and Opportunities in AI-Assisted Drugs Discovery

The global AI-in-drug discovery market is projected to witness significant growth in the coming years. Advancements in AI technologies, such as ML, natural language processing, and deep learning, have led to the development of sophisticated algorithms capable of analyzing complex biological data and predicting the interactions between drugs and their targets.

AI-driven platforms are being used for the virtual screening of large compound libraries, identifying potential drug candidates with higher accuracy and efficiency than traditional methods. These platforms can also optimize lead compounds and predict their pharmacokinetic and toxicity profiles, aiding in the selection of the most promising candidates for further development.

Furthermore, AI is transforming drug design by enabling the generation of novel molecular structures with specific properties. AI-generated molecules can be tailored to target specific diseases and biological pathways, offering new opportunities for precision medicine.

As regulatory agencies, such as the FDA, continue to embrace AI applications in drug development, the market potential of AI in the pharmaceutical industry is expected to grow further. However, challenges remain, including data privacy concerns, the validation of AI models, and the integration of AI with existing drug development processes.

Moreover, AI’s potential extends beyond drug discovery and development. It also plays a critical role in clinical trials, patient stratification, and the real-time monitoring of treatment responses, enabling personalized medical approaches that enhance patient outcomes.

The use of advanced simulation and modeling techniques in AI has the potential to revolutionize the drug discovery process, making it more efficient and effective. With AI, it is possible to model and simulate biological networks, which deepens our understanding of disease mechanisms and helps in the discovery of new drugs [175].

The use of AI in drug discovery has many benefits. Traditional approaches face obstacles such as high costs, inefficiency, and lengthy timelines. AI can address these issues by automating and optimizing processes, resulting in more efficient and effective drug discovery. This enables the discovery of novel drug candidates that may have been overlooked using traditional approaches. AI leverages advancements in biology and computing to develop cutting-edge algorithms for drug discovery, leveling the playing field and enabling more researchers to access powerful computational tools for drug development. Furthermore, AI models have a higher predictive power, reducing the potential for false positives in drug screening. By carefully designing the assay parameters, AI can identify meaningful interactions and prioritize promising targets for further investigation [176].

The use of AI in drug discovery shows potential by moving drug screening from the lab to a virtual environment, resulting in faster screening and the ability to identify promising targets without extensive effort and manpower. However, implementing advanced simulation and modeling techniques in AI for drug discovery poses challenges such as the data quality, interpretability of AI models, and the need for validation and reproducibility. Despite these challenges, AI has the potential to improve drug discovery efficiency, enable unbiased exploration, and enhance its predictive power, leading to reduced costs and an increased likelihood of successful drug candidates. To successfully integrate AI in drug discovery, addressing these challenges and ensuring the reliability and interpretability of AI models is crucial.

## Section: 7. Conclusions

The future of AI in drug discovery involves a closer integration with automation, which would allow AI systems to make decisions on compound design and synthesis without human input. This shift from an augmented drug design paradigm to an autonomous one has the potential to accelerate the drug discovery process and yield better starting points for drug development. Ultimately, the goal is to develop fully autonomous laboratories that can iterate through the design–make–test–analyze cycle of drug discovery on their own. This could lead to faster and more efficient drug discovery processes, with AI systems suggesting and testing new compounds autonomously. However, there are challenges to overcome, such as proving the reliability and reproducibility of AI-assisted findings. Furthermore, the availability of robust datasets and investments in AI technology are important considerations for the future adoption and success of AI in drug discovery.

The major challenge for the medical industry while developing a new drug is its increased costs and reduced efficiency. ML approaches and recent developments in DL come with great opportunities to reduce this cost, increase efficiency, and save time during the drug discovery and development process. Even though there are some obstacles and a tremendous amount of work to be conducted to incorporate AI tools in the drug discovery cycle, concretely, despite these challenges, AI has already demonstrated promising results in discovering new combinations of materials for drug discovery, accelerating the search for drug candidates, optimizing drug formulation and delivery, improving target identification, and enhancing virtual screening. The future outlook for AI in drug discovery is promising, with advancements expected in autonomous decision-making and the integration of AI with automation.

## Section: Author Contributions

Conceptualization, A.I.V.; methodology, A.I.V.; software, I.N.; validation, A.I.V.; formal analysis, I.N.; investigation, A.I.V. and I.N.; resources, I.N.; data curation, I.N.; writing—original draft preparation, A.I.V. and I.N.; writing—review and editing, A.I.V.; visualization, I.N.; supervision, A.I.V.; project administration, I.N.; funding acquisition, I.N. All authors have read and agreed to the published version of the manuscript.

## Section: Institutional Review Board Statement

Not applicable.

## Section: Informed Consent Statement

Not applicable.

## Section: Data Availability Statement

Not applicable.

## Section: Conflicts of Interest

The authors declare no conflicts of interest.

## Section: Funding Statement

This work was supported by the Romanian Ministry of Education and Research, under Romanian National Nucleu Program LAPLAS VII—contract no. 30N/2023. A.I.V. acknowledges the financial support of the Romanian Ministry of Education and Research, CNCS-UEFISCDI, project no. PN-III-P4-ID-PCE-2020-2273 (11/2020, RENERI), within PNCDI III. I.N. acknowledges the support of a grant of the Ministry of Research, Innovation and Digitization, CNCS—UEFISCDI, project no. PN-III-P2-2.1-PED-2021-3178 within PNCDI III.

## Section: Associated Data › Data Availability Statement

Not applicable.


---

# Integrating machine learning algorithms and multiple immunohistochemistry validation to unveil novel diagnostic markers based on costimulatory molecules for predicting immune microenvironment status in triple-negative breast cancer

- **Authors:** Chao Zhang, Wenyu Zhai, Yuyu Ma, Minqing Wu, Qiaoting Cai, Jiajia Huang, Zhihuan Zhou, Fangfang Duan
- **Issuer:** Frontiers in immunology
- **Type:** Scientific article
- **Published:** 2024-06-28
- **Language:** en
- **DOI:** 10.3389/fimmu.2024.1424259
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39007147/
- **Licence:** CC-BY

## Section: Abstract

AbstractIntroductionCostimulatory molecules are putative novel targets or potential additions to current available immunotherapy, but their expression patterns and clinical value in triple-negative breast cancer (TNBC) are to be clarified. MethodsThe gene expression profiles datasets of TNBC patients were obtained from The Cancer Genome Atlas and the Gene Expression Omnibus databases. Diagnostic biomarkers for stratifying individualized tumor immune microenvironment (TIME) were identified using the Least Absolute Shrinkage and Selection Operator (LASSO) and Support Vector Machine-Recursive Feature Elimination (SVM-RFE) algorithms. Additionally, we explored their associations with response to immunotherapy via the multiplex immunohistochemistry (mIHC). ResultsA total of 60 costimulatory molecule genes (CMGs) were obtained, and we determined two different TIME subclasses (“hot” and “cold”) through the K-means clustering method. The “hot” tumors presented a higher infiltration of activated immune cells, i.e., CD4 memory-activated T cells, resting NK cells, M1 macrophages, and CD8 T cells, thereby enriched in the B cell and T cell receptor signaling pathways. LASSO and SVM-RFE algorithms identified three CMGs (CD86, TNFRSF17 and TNFRSF1B) as diagnostic biomarkers. Following, a novel diagnostic nomogram was constructed for predicting individualized TIME status and was validated with good predictive accuracy in TCGA, GSE76250 and GSE58812 databases. Further mIHC conformed that TNBC patients with high CD86, TNFRSF17 and TNFRSF1B levels tended to respond to immunotherapy. ConclusionThis study supplemented evidence about the value of CMGs in TNBC. In addition, CD86, TNFRSF17 and TNFRSF1B were found as potential biomarkers, significantly promoting TNBC patient selection for immunotherapeutic guidance.Keywords: triple-negative breast cancer, costimulatory molecules, diagnostic biomarker, tumor immune microenvironment, machine learning algorithm

## Section: Introduction

Triple-negative breast cancer (TNBC) accounts for nearly 15% of all breast cancers (1). Due to its paucity of definitive targets and the intrinsic aggressiveness, most TNBC-related deaths occur, and it remains a grave life-threatening disease among women worldwide (2–5). In view of lacking estrogen receptor (ER), progesterone receptor (PR), and human epidermal growth factor receptor 2 (HER2), TNBC can’t benefit from endocrine and targeted treatments, and depend on traditional chemotherapy with little clinical benefits realized, a median overall survival (OS) about 12 to 18 months (6–9).

In recent years, immune-checkpoint inhibitors (ICIs) have revolutionized the therapeutic landscape of multiple tumors, such as nasopharyngeal carcinoma, melanoma, and lung cancer, wherein, ICIs generated durable responses, resulted in substantial survival progress, and have been recommended as a part of standardized treatments (10). Compared with other breast cancer subtypes, TNBC exhibits stronger immunogenicity, abundant tumor-infiltrating lymphocytes (TILs), higher programmed cell death ligand 1 (PD-L1) expression and tumor mutation burden (TMB) (2, 11, 12), numerous explorations on adding ICIs to the therapeutic arsenal of TNBC have acquired inspiring feedback (13–15). While survival benefits derived from ICIs in TNBC are relatively minimal as compared to other tumors (2, 16, 17). Therefore, identifying and developing optimal biomarkers have become a hot area. Currently, PD-L1 and TMB are most used predictors for patient selection in clinical practice, but absence of standardized criteria for the methodology and expression cutoff values leads to their inconsistency predictive value in different clinical trials and therapeutic regimes (16, 18, 19). Although a possible association between higher TILs and improved pCR rates from an immunotherapeutic perspective has been examined, it is confined to the early stage of TNBC (20). Hence, novel predictors of immunotherapeutic response are necessary and meaningful to appropriately select ideal patients who can benefit from ICIs with the aim to design individualized strategies.

The tumor immune microenvironment (TIME), composed of various immune cells, stromal cells, mesenchymal cells, cytokines, and chemokines, plays a crucial role in the processes of tumor initiation, progress, development, and metastasis (21). A deep parsing of the diversity and complexity of TIME is valuable for improving anti-tumor immune responses and patient stratification according to their unique TIME classes and subclasses, thereby greatly improving therapeutic benefits from ICIs and unraveling novel targets (22). Increasing evidence suggests that features associated with the “hot” tumor, including abundant TILs in TIME, markers related to T cell activation, as well as signatures for adhesion, are potential factors for predicting responses to ICIs (23). Costimulatory molecules, comprising the B7-CD28 family with 13 molecules and the tumor necrosis factor (TNF) family with 48 molecules, are vital for the differentiation, proliferation, maturation, survival, activation, and functions of immune cells. The former includes the most common PD-1 and PD-L1 axis of ICIs, the latter includes 19 members belong to the TNF ligand superfamily (TNFSF) and 29 members to the TNF receptor superfamily (TNFRSF) (22, 24, 25). Moreover, they are putative novel targets or potential additions to current available immunotherapeutic strategies (26, 27). The predictive model based on costimulatory molecule genes (CMGs) have been explored in lung adenocarcinoma (28), while their functions and clinic value in TNBC are little illustrated.

Herein, we aimed to systematically dissect the expression pattern and clinical value of costimulatory molecules in TNBC. Using the transcriptional profiles of TNBC patients from The Cancer Genome Atlas (TCGA) and the Gene Expression Omnibus (GEO) databases, we stratified patients into two different TIME status (“cold” and “hot”) through the K-means clustering method and compared their difference in immune cell infiltrations via the CIBERSORT algorithm (29). Subsequently, Least Absolute Shrinkage and Selection Operator (LASSO) (30) and Support Vector Machine-Recursive Feature Elimination (SVM-RFE) (31) were utilized to identify diagnostic markers from CMGs. Following, a diagnostic signature for stratifying individualized TIME status of TNBC patients was stablished, and its predictive performance was further validated. Moreover, we conducted a small-sample exploratory analysis via the multiplex immunohistochemistry (mIHC) to explore the correlation between the expression level of identified CMGs biomarkers and response to immunotherapy.

## Section: Materials and methods › Data acquisition and preparation

We downloaded the gene expression profile datasets of TNBC patients from TCGA (https://tcga-data.nci.nih.gov/tcga/) and GEO databases (https://www.ncbi.nlm.nih.gov/geo/) (GSE76250 and GSE58812 datasets) using the “GEO query” package (32). All microarray datasets were standardized via the “SVA” and “limma” R packages. TCGA, GSE76250, and GSE58812 datasets consisted of 168, 165, and 107 tumor samples, respectively. A total of 60 CMGs, including 13 members of B7-CD28 family and 47 members of TNF family, were obtained from a previously published study ( Supplementary Table 1 ) (28).

## Section: Materials and methods › Patient-clustering based on CMGs

To investigate the potential value and functions of abovementioned 60 CMGs in the TIME of TNBC, we classified patients into different clusters after the k-means machine learning algorithm, an unsupervised consensus clustering method, using the “Cluster” package. First, we determined the corresponding optimal cluster numbers in three datasets via the “factoextra” package. After k-means clustering, we performed the principal component analysis (PCA) with the “factoextra” package. Next, we utilized the “ESTIMATE” package (33) to calculate and compare the tumor purity, immune, and stromal scores among different clusters in TCGA, GSE76250, and GSE58812 datasets. TNBC patients in three datasets were further stratified into the “hot” and “cold” tumor groups according to their immune and stromal scores.

## Section: Materials and methods › Estimation of the immune cell infiltration landscape in TIME

The standardized gene expression profiles of TNBC patients in TCGA, GSE76250, and GSED58812 datasets were performed by the CIBERSORT algorithm with perm set to 1000 to analyze the characteristics of 22 immune cells infiltration (29) between patients belonging to the “hot” and “cold” tumor groups.

## Section: Materials and methods › Functional annotation and pathway enrichment analyses

Gene set enrichment analysis (GSEA, https://www.gsea-msigdb.org/gsea/index.jsp) was performed for patients in “hot” vs “cold” tumors through the Java GSEA (version4.0.1) and the Kyoto Encyclopedia of Genes and Genomes (KEGG) pathway in C2 and Gene Ontology (GO) terms in C5 to evaluate potential functional pathways and biological mechanisms enriched in patients (34). False discovery rate (FDR) < 0.25 and normalized P < 0.05 were set as cutoffs to obtain significant enrichment.

## Section: Materials and methods › Screening and identification of the diagnostic CMGs biomarkers

In the TCGA and GSE76250, to avoid possible influence of multicollinearity, we firstly conducted the LASSO logistic regression analysis through the “glmnet” package to screen out biomarkers from above all 60 CMGs at the optimal value of log lambda with the smallest classification error (30). Besides, the SVM-RFE machine learning algorithm based on the support vector machine was utilized to identify the most valuable biomarkers from all 60 CMGs by subtracting the feature vector determined using SVM with the “e1071” and “caret” R packages (31). Next, we merged identified CMGs from above-mentioned machine learning algorithms via the “scMerge” package to further narrow the number of markers. These overlapped CMGs markers were finally input for the logistics regression analysis to identify the final diagnostic biomarkers.

## Section: Materials and methods › Conduction and validation of the diagnostic nomogram based on CMGs biomarkers

Based on abovementioned final CMGs biomarkers, a diagnostic signature for individualized TIME status was constructed and visually presented as nomogram via the “rms” R package. Then, we evaluated and validated the predictive accuracy and clinical value of the CMG-based nomogram using the receiver operating characteristic (ROC) curves, calibration curves, and decision curve analysis (DCA) in both training and validation datasets.

## Section: Materials and methods › Tissue multiplex immunohistochemistry

We stained TNBC samples using the multiplex fluorescence immunohistochemical kit, PDOne four-color TSA-RM-275 (20 T) (cat 10001100020 Panovue, Beijing, China) according to the manual provided. Paraffin-embedded samples were sequentially incubated with primary antibodies and horseradish peroxidase (HRP)-conjugated secondary antibodies. Then, we performed the tyrosine signal amplification (TSA) to label antigens, after each TSA labeling step, we removed the primary and secondary antibodies through a microwave treatment for heat-induced antigen retrieval. After the sample was eluted, the next antigen was labeled, and this procedure was repeated for all four antigen markers. Anti-CD86 (E2G8P, dilution 1:200, Rabbit, Cell Signaling Technology, Danvers, MA, USA), TNFRSF17 (ab245940, dilution 1:100, Rabbit, Abcam, Cambridge, UK) and TNFRSF1B (28746–1-AP, dilution 1:200, Proteintech, Rosemont, USA) were utilized as primary antibodies. The dyes Opal520, Opal570, Opal650 and 4′-6′-diamidino-2-phenylindole (DAPI, Sigma-Aldrich) were utilized for staining. We scanned TNBC samples and obtained their fluorescence images at ×20 magnification with a PanoVIEW VS200 slide scanner (Panovue, Beijing, China) and an Olympus 20× lens. Image recognition and analysis were performed with QuPath image analysis software (Version 0.3.0, Queen’s University of Belfast, Northern Ireland, UK). The images were quantized into data by tissue segmentation and cell segmentation using the positive threshold settings and phenotypic recognition. By means of an R script (Version 4.0.1), we assumed the quantitative data and basic data such as the positive cell number, positive staining rate and density for subsequent analysis.

## Section: Materials and methods › Statistical analysis

In current study, the expression levels of CMGs in TNBC patients were presented as raw and standardized data. We conducted this study in two phases. During the first phase, we classified TNBC patients into the “hot” and “cold” tumors according to their immune and stromal scores. During the second phase, TCGA dataset was used as the training cohort, TCGA and the GSE76250 datasets were utilized as internal validation cohorts, and the GSE58812 dataset was as external validation cohort. A diagnostic signature based on identified CMGs biomarkers for predicting individualized TIME subclasses in TNBC was constructed and validated.

All statistical analyses herein were performed using the R software (version 4.0.1, Vanderbilt University, Nashville, TN). The Mann-Whitney U test and Kruskal-Wallis H test were utilized to compare the immune score, stromal score, and tumor purity among different clusters. The unpaired Student’s t test was performed to compare differences in responses to immunotherapy among patients with TNBC. A P-value <0.05 was considered statistically significant unless specified.

## Section: Results

Flowchart of the study design.

TNBC patient-clustering based on costimulatory molecule genes (CMGs). (A) The curve of the total within the sum of squared error curve for the corresponding cluster number k in TCGA dataset; (B) The principal component analysis (PCA) plot of clustered patients in TCGA dataset; (C) The curve of the total within the sum of squared error curve for the corresponding cluster number k in GSE76250 dataset; (D) The PCA plot of clustered patients in GSE76250 dataset; (E) The curve of the total within the sum of squared error curve for the corresponding cluster number k in GSE58812 dataset; (F) The PCA plot of clustered patients in GSE58812 dataset.

Calculation and comparison of tumor-stromal and immune scores between different TIME subclasses in TNBC, where red represents patients in the “hot” tumor and green shows patients in the “cold” tumor. The comparison of stromal scores (A) and immune scores (B) between “hot” (clusters 2 to 5) and “cold” (cluster 1) tumor groups in TCGA dataset; The comparison of stromal scores (C) and immune scores (D) between “hot” (clusters 4 and 5) and “cold” (clusters 1,2,3,6 and 7) tumor groups in GSE76250 dataset; The comparison of stromal scores (E) and immune scores (F) between “hot” (clusters 1 and 2) and “cold” (clusters 3 and 4) tumor groups in GSE58812 dataset.

Evaluation and visualization of 22 immune cell type infiltration landscape between different TIME status. The violin plot depicts infiltration disparities among immune cell types between the “hot” tumor (red) and the “cold” tumor (blue) in TCGA (A), GSE76250 (B), and GSE58812 datasets (C).

Functional analysis for the “hot” tumor and the “cold” tumor based on costimulatory molecule genes (CMGs). (A, C, E) The Kyoto Encyclopedia of Genes and Genomes (KEGG) enrichment analysis in TCGA, GSE76250, and GSE58812 datasets, respectively; (B, D, F) Gene Ontology (GO) analysis for biological processes in TCGA, GSE76250, and GSE58812 datasets, respectively.

The selection of diagnostic biomarkers from candidate costimulatory molecule genes (CMGs). The lower abscissa is the log lambda value, while the upper abscissa is the number of CMGs with non-zero coefficient; the vertical axis represents the Least Absolute Shrinkage and Selection Operator (LASSO) coefficient of CMGs, and each curve shows the variation trajectory of the coefficients of each gene. (A) Determination of the number of CMGs with non-zero coefficients at the optimal value -5.830026 of log lambda in TCGA dataset; (B) LASSO coefficient profiles of 27 candidate CMGs after the 10-fold cross-validation in TCGA dataset; (C) Support Vector Machine-Recursive Feature Elimination (SVM-RFE) method to identify markers in TCGA dataset; (D) Definition of the number of CMGs with non-zero coefficients at the optimal value -3.836916 of log lambda in GSE76250 dataset; (E) LASSO coefficient profiles of 35 candidate CMGs after the 10-fold cross-validation in GSE76250 dataset; (F) SVM-RFE method to identify markers in GSE76250 dataset; (G) Venn diagram presents the overlapping diagnostic markers identified by LASSO and SVM-REF algorithms.

Development and validation of the diagnostic nomogram. (A) A nomogram for diagnosing individualized tumor immune environment subclass. The receiver operating characteristic (ROC) curve of the diagnostic efficacy verification in TCGA (B), GSE76250 (C), and GSE58812 datasets (D); The calibration plots of the diagnostic accuracy validation in three datasets (E–G); The decision curve analysis (DCA) of the clinical value for therapeutic guidance in TCGA (H), GSE76250 (I), and GSE58812 datasets (J).

Expression of CMGs biomarkers are positively related to the efficacy of immunotherapy in TNBC. Representative multiplex immunofluorescence images demonstrating the protein expression of CD86 (blue), TNFRSF1B (red) and TNFRSF17 (purple) in samples from nonresponders (A) and responders (B); (C) Correlation analysis showed that TNFRSF1B, CD86 and TNFRSF17 were significantly associated with the immune response.

## Section: Results › Data extraction and processing

The flow chart for the study design is presented in Figure 1 . All microarray matrixes of three publicly available datasets were annotated, following which, TCGA dataset consisted of 168 TNBC samples (46999 genes), GSE76250 and GSE 58812 datasets included 165 TNBC samples (30906 genes) and 107 TNBC samples (20161 genes), respectively. Next, 60 CMGs were overlapped with TCGA dataset, except for the TNFRSF6B gene due to its low expression, a total of 59 CMGs were identified. Similarly, 60 CMGs were merged with GEO datasets, wherein, only 57 CMGs in the GSE76250 dataset and 58 CMGs in the GSE58812 dataset were eligible. Then, we standardized the expression levels of CMGs in three datasets using the “SVA” and “limma” R packages. Finally, a total of 56 CMGs were used for subsequent analysis.

Flowchart of the study design.

## Section: Results › Patient-clustering based on CMGs

To explore the clinical value and functions of above CMGs in TNBC, an unsupervised consensus clustering analysis was performed to stratify patients. Figures 2A, C, E show the curves of the total within the sum of squared error for the corresponding cluster numbers of k. These suggested that a k value of 5, 7, and 4 were the most optimal in TCGA, GSE76250, and GSE58812 datasets, respectively. The PCA was performed to evaluate the credibility of these cluster numbers, and it demarcated five clusters at k = 5 in TCGA dataset ( Figures 2B ). Similarly, patients were distinguished at k = 7 in the GSE76250 dataset ( Figure 2D ), and k = 4 in the GSE58812 dataset ( Figures 2F ).

Next, we used the “ESTIMATE” R package (33) to estimate the tumor purity, and to calculate the percentages of stromal and immune cells infiltrations in TIME of TNBC patients based on their CMGs expression profiles. It showed that the tumor purity among patient clusters was significantly different for TCGA, GSE76250 and GSE58812 datasets ( Supplementary Figure 1 ). Besides, significant differences among multiple clusters for tumor stroma and immune scores in TCGA ( Supplementary Figures 2A, B ), GSE76250 ( Supplementary Figures 2C, D ), and GSE58812 ( Supplementary 2E, F ) datasets were also observed. Accordingly, we classified the TNBC patients in cluster 1 of TCGA dataset into the “cold” tumor group, while those in clusters 2 to 5 were in the “hot” tumor group. In the GSE76250 dataset, we categorized patients in clusters 4 and 5 as the “hot” tumor group and patients in other clusters formed the “cold” tumor group. In the GSE58812 dataset, TNBC patients in clusters 1 and 2 were divided into the “hot” tumor, while the remaining patients were in the “cold” tumor group.

Next, we used the “ESTIMATE” R package (33) again to calculate and compare the tumor purity, stromal, and immune cells infiltrations between “cold” and “hot” tumors. There were significant differences in the stromal and immune cell types among TCGA ( Figures 3A, B ), GSE76250 ( Figures 3C, D ), and GSE58812 datasets ( Figures 3E, F ). A significantly higher tumor purity in the “cold” tumor relative to the “hot” tumor in TCGA, GSE76250, and GSE58812 datasets ( Supplementary Figure 3 ) was observed.

TNBC patient-clustering based on costimulatory molecule genes (CMGs). (A) The curve of the total within the sum of squared error curve for the corresponding cluster number k in TCGA dataset; (B) The principal component analysis (PCA) plot of clustered patients in TCGA dataset; (C) The curve of the total within the sum of squared error curve for the corresponding cluster number k in GSE76250 dataset; (D) The PCA plot of clustered patients in GSE76250 dataset; (E) The curve of the total within the sum of squared error curve for the corresponding cluster number k in GSE58812 dataset; (F) The PCA plot of clustered patients in GSE58812 dataset.

Calculation and comparison of tumor-stromal and immune scores between different TIME subclasses in TNBC, where red represents patients in the “hot” tumor and green shows patients in the “cold” tumor. The comparison of stromal scores (A) and immune scores (B) between “hot” (clusters 2 to 5) and “cold” (cluster 1) tumor groups in TCGA dataset; The comparison of stromal scores (C) and immune scores (D) between “hot” (clusters 4 and 5) and “cold” (clusters 1,2,3,6 and 7) tumor groups in GSE76250 dataset; The comparison of stromal scores (E) and immune scores (F) between “hot” (clusters 1 and 2) and “cold” (clusters 3 and 4) tumor groups in GSE58812 dataset.

## Section: Results › Estimation of the immune cell infiltration landscape in TIME

The landscape of 22 immune cell type infiltrations in TNBC tissues were estimated based on the gene expression profiles via the CIBERSORT algorithm (29), and we also evaluated the correlation between the immune cells in the TIME of TNBC patients. In TCGA dataset, the distribution of immune cells between “cold” and “hot” tumors were significantly different, including CD8 T cells (P = 0.001), CD4 memory activated T cells (P < 0.001), resting NK cells (P = 0.028), monocytes (P = 0.011), M0 macrophages (P = 0.005), M1 macrophages (P < 0.001), and M2 macrophages (P = 0.001). Among them, the proportion of M0 and M2 macrophages were higher in the “cold” tumor (P < 0.05), while that of others was higher in the “hot” tumor (P < 0.05) ( Figure 4A ). Significant differences in the proportion of immune cells between the “cold” and “hot” tumors were also found in GSE76250 dataset, namely, memory B cells (P < 0.001), CD8 T cells (P < 0.001), resting CD4 memory T cells (P < 0.001), CD4 memory activated T cells (P < 0.001), follicular helper T cells (P = 0.001), regulatory T cells (Tregs) (P < 0.001), activated NK cells (P = 0.028), monocytes (P = 0.011), M0 macrophages (P = 0.017), and M1 macrophages (P < 0.001). Among them, the distributions of memory B cells, resting CD4 memory T cells, CD4 memory activated T cells, and M1 macrophages were higher, while CD8 T cells, follicular helper T cells, Tregs, activated NK cells, monocytes and M0 macrophages were lower in the “hot” tumor (P < 0.05) ( Figure 4B ). In GSE58812 dataset, multiple immune cell types infiltrating the “cold” and “hot” tumors showed significantly different distributions, including the naïve B cells (P < 0.001), CD8 T cells (P < 0.001), CD4 naïve T cells (P < 0.001), resting CD4 memory T cells (P < 0.001), CD4 memory activated T cells (P < 0.001), M0 macrophages (P = 0.003), and M2 macrophages (P = 0.006). Among them, the proportions of naïve B cells, CD8 T cells, CD4 naïve T cells, and CD4 memory-activated T cells were higher in the “hot” tumor (P < 0.05) ( Figure 4C ).

Additionally, the correlation matrix for the 22 immune cells in TNBC tissues was constructed ( Supplementary Figure 4 ). For example, a positive correlation between CD4 memory-activated T cells and M1 macrophages (Cor = 0.37), and CD4 memory-activated T cells and CD8 T cells (Cor = 0.31) was observed in TCGA dataset ( Supplementary Figure 4A ). Likewise, a positive correlation between CD8 T cells and activated NK cells (Cor = 0.66) in GSE76250 dataset ( Supplementary Figure 4B ), a positive correlation between CD4 memory activated T cells and M1 macrophages (Cor = 0.31) in the GSE58812 dataset ( Supplementary Figure 4C ) were observed.

Evaluation and visualization of 22 immune cell type infiltration landscape between different TIME status. The violin plot depicts infiltration disparities among immune cell types between the “hot” tumor (red) and the “cold” tumor (blue) in TCGA (A), GSE76250 (B), and GSE58812 datasets (C).

## Section: Results › Functional annotation and pathway enrichment analyses

We performed GO and KEGG enrichment analyses for the “cold” and “hot” tumors to reveal potential functions and pathways. It demonstrated that “hot” tumor group was enriched in the chemokine signaling pathway, cytokine-cytokine receptor signaling pathway, JAK-STAT signaling pathway, nature killer cell-mediated signaling pathway, B cell receptor, and T cell receptor signaling pathway in TCGA ( Figure 5A ), GSE76250 ( Figure 5C ), and GSE58812 datasets ( Figure 5E ). As for the biological processes (BP), the “hot” tumor was mainly associated with the T cells activation and the regulation of immune responses in all three datasets ( Figures 5B, D, F ).

Functional analysis for the “hot” tumor and the “cold” tumor based on costimulatory molecule genes (CMGs). (A, C, E) The Kyoto Encyclopedia of Genes and Genomes (KEGG) enrichment analysis in TCGA, GSE76250, and GSE58812 datasets, respectively; (B, D, F) Gene Ontology (GO) analysis for biological processes in TCGA, GSE76250, and GSE58812 datasets, respectively.

## Section: Results › Screening and identification of the diagnostic CMGs biomarkers

In TCGA dataset, we performed the LASSO logistic regression analysis and screened out 27 CMGs from 56 candidates, having zero coefficients at the optimal value -5.830026 of log lambda ( Figures 6A, B ). 26 CMGs from 56 candidates were recognized as diagnostic biomarkers based on the result of SVM-RFE algorithm ( Figure 6C ). Diagnostic biomarkers identified using above two algorithms were overlapped and 13 CMGs remained to be biomarkers ( Figure 6G ). Similarly, in GSE76250 dataset, 11 CMGs and 46 CMGs from 56 candidates were identified as putative diagnostic biomarkers via the LASSO (a value -3.836916 of the optimal log lambda) ( Figures 6D, E ) and SVM-RFE ( Figures 6F ) machine learning algorithms. Among these, 11 CMGs were overlapping ( Figure 6G ). Next, we merged candidate CMGs identified from above two datasets and performed the logistic regression analysis to further narrow the number of diagnostic biomarkers, three CMGs (CD86, TNFRSF17, and TNFRSF1B) were determined as final diagnostic biomarkers ( Figure 6G ). All CMGs analyzed in this phase were listed in Supplementary Table 2 .

The selection of diagnostic biomarkers from candidate costimulatory molecule genes (CMGs). The lower abscissa is the log lambda value, while the upper abscissa is the number of CMGs with non-zero coefficient; the vertical axis represents the Least Absolute Shrinkage and Selection Operator (LASSO) coefficient of CMGs, and each curve shows the variation trajectory of the coefficients of each gene. (A) Determination of the number of CMGs with non-zero coefficients at the optimal value -5.830026 of log lambda in TCGA dataset; (B) LASSO coefficient profiles of 27 candidate CMGs after the 10-fold cross-validation in TCGA dataset; (C) Support Vector Machine-Recursive Feature Elimination (SVM-RFE) method to identify markers in TCGA dataset; (D) Definition of the number of CMGs with non-zero coefficients at the optimal value -3.836916 of log lambda in GSE76250 dataset; (E) LASSO coefficient profiles of 35 candidate CMGs after the 10-fold cross-validation in GSE76250 dataset; (F) SVM-RFE method to identify markers in GSE76250 dataset; (G) Venn diagram presents the overlapping diagnostic markers identified by LASSO and SVM-REF algorithms.

## Section: Results › Construction and validation of the diagnostic nomogram based on CMGs

To develop a practical tool for individually predicting TIME subclass in patients with TNBC, we constructed the diagnostic nomogram incorporating above three final CMGs biomarkers, including CD86, TNFRSF17, and TNFRSF1B, based on findings in TCGA ( Figure 7A ). Each biomarker could be scored in points line according to its expression, and after summation, every TNBC patient could have a total score, based on which, the probability of “hot” tumor could be predicted by locating the total score on the probability of the hot tumor scale. For example, TNBC patients with high expression of above three CMGs were more likely to be recognized as “hot” tumor. We further assessed the diagnostic efficiency of this nomogram in three datasets by calculating the area under the ROC curve (AUC), which suggested a satisfactory diagnostic accuracy in TCGA ( Figure 7B ), GSE76250 ( Figure 7C ), and GSE58812 datasets ( Figure 7D ). Moreover, a favorable agreement between actual and predicted probability through the diagnostic nomogram in all three datasets was observed via the calibration curves ( Figures 7E–G ). Additionally, the DCA results demonstrated a good clinical value of this diagnostic nomogram in predicting TIME status ( Figures 7H–J ).

Development and validation of the diagnostic nomogram. (A) A nomogram for diagnosing individualized tumor immune environment subclass. The receiver operating characteristic (ROC) curve of the diagnostic efficacy verification in TCGA (B), GSE76250 (C), and GSE58812 datasets (D); The calibration plots of the diagnostic accuracy validation in three datasets (E–G); The decision curve analysis (DCA) of the clinical value for therapeutic guidance in TCGA (H), GSE76250 (I), and GSE58812 datasets (J).

## Section: Results › Expression of CMGs markers positively related to efficacy of immunotherapy

To further verify the associations between the expression level of these three CMGs biomarkers in tumor tissues of TNBC patients receiving immunotherapy and patients’ response to treatment, we collected 27 patients’ paraffin-embedded samples and performed the mIHC assays. Figures 8A , B showed the representative mIHC images of DAPI and three CMGs biomarkers in tumor tissues of responders and no-responders, i.e., DAPI (blue), CD86 (green), TNFRSF17 (purple) and TNFRSF1B (red). Further statistical analysis demonstrated that there were significant associations between high expression of CMGs biomarkers and patients’ positive response to immunotherapy ( Figure 8C ).

Expression of CMGs biomarkers are positively related to the efficacy of immunotherapy in TNBC. Representative multiplex immunofluorescence images demonstrating the protein expression of CD86 (blue), TNFRSF1B (red) and TNFRSF17 (purple) in samples from nonresponders (A) and responders (B); (C) Correlation analysis showed that TNFRSF1B, CD86 and TNFRSF17 were significantly associated with the immune response.

## Section: Discussion

In recent years, the therapeutic landscape of TNBC patients has broadened owing to the rapid development of immunotherapy, but only a few patients benefit from ICIs treatment unlike the excellent therapeutic responses achieved in other tumors (16). Effective biomarkers for predicting responses to ICIs in TNBC are lacking in the clinical setting (19). Increasing evidence demonstrated that understanding the unique subsets of personalized TIME is meaningful for identifying novel therapeutic targets and guiding immunotherapeutic strategies (21). In current study, we creatively classified TNBC patients into the “hot” and “cold” tumors according to their TIME clusters determined by CMGs. Further, we executed two machine learning algorithms and identified three CMGs (CD86, TNFRSF17, and TNFRSF1B) as diagnostic biomarkers, based on which, a diagnostic nomogram for predicting TIME subclasses in TNBC in TCGA dataset was constructed, which presented satisfactory predictive accuracy and good clinical value in both the training and validation datasets. Moreover, exploratory analysis in a real-world clinic cohort of patients with TNBC via mIHC also revealed an apparently positive association between the expression level of these three CMGs biomarkers with responses to immunotherapy. This suggest that these CMGs biomarkers might be promising tool for TNBC patients’ stratification to immunotherapeutic guidance.

The failure of current immunotherapy targeting CTLA-4 or PD-1 may be caused by intratumor T cell exhaustion (2), therefore increasing interests revolve around costimulatory molecules residing in the TIME in TNBC tumors. The costimulatory molecules mainly include the B7-CD28 family and the TNF family of proteins (24, 25). Their expressions on tumor cell and lymphocyte surfaces play important roles in regulating the anti-tumor immune responses (22). The immune surveillance function of the immune system in the human body helps to distinguish malignant from normal cells and initiates subsequent attacks. During this process, the naïve T cells should be activated through two indispensable signals, one of which is the costimulatory signal (35), so the activation of T cells could be blocked without costimulatory signals (28). Generally, malignant cells deliver incorrect messages to T cells and prevent the recognition of costimulatory signals by altering their structures and expressions in TIME, and further inducing an immunosuppressive TIME, thereby helping tumor cells to evade immune-induced elimination (36). A single-cell RNA profile analysis of B cells in breast cancer showed that tumors elicited immune-suppressive B cells owing to their failure in extracting costimulatory signals from them, which facilitated further breast tumor cell evasion of immune surveillance (37). ICIs, by blocking the PD1-PD-L1 and the CD86/CTLA4 axes, prevent tumor cells from releasing wrong messages to T cells, thereby restoring tumor-induced immuno-deficiency in TIME (38). While except for common realized PD1/PD-L1 and CD86/CTLA4 axes, many costimulatory members are still poorly understood. To explore the clinical value of costimulatory molecules in TNBC, we obtained 56 CMGs from public databases in this study. Utilizing the unsupervised consensus clustering algorithm, we clustered patients into two different TIME subclasses, namely the “cold” tumor and the “hot” tumor. TIME, composed of several immune cells, carcinoma-associated fibroblasts, stromal cells, and tumor endothelial stromal cells, plays a crucial role in multiple biological processes, including tumor initiation, angiogenesis, and immune regulation (21, 22). Classifying the immune contexts within a TIME represents the first level of cognizing immunological composition and status (activated or suppressed), their influence on survival outcomes and responses possibilities to anti-tumor treatment. Moreover, TIME classifications might also promote to understand its principle of affecting the establishment and maintenance of specific immunological compositions (21).

Tumors were generally classified as “cold” with immune deficiency if their TIME population included immune cells but lacked activation, which could promote metastasis and disease progression as adaptive immunity could not recognize extrinsic antigens or malignancies (39). Whereas, a high expression of activation biomarkers, such as PD-L1, on activated immune cells or tumor cells within a tumor, are the key characteristics of an immunological “hot” tumor, which is likely to initiate anti-tumor immune responses to attack tumors (21). Herein, we simultaneously examined the immune cells infiltrations in the “hot” and “cold” tumors to elucidate the differences in their TIME. The findings demonstrated that immunosuppressive cells, such as M0 and M2 macrophages, had significant infiltration in the “cold” tumor. Typically, M1 macrophages secret cytokines to activate T cells and exert antitumoral effects, while M2 macrophages are pro-tumorigenic factors via angiogenesis and the chemotaxis of Tregs (40). Therefore, the presence of poor immunogenic TIME in patients with “cold” tumors was reasonably speculated. The “hot” tumor exhibited significantly higher infiltrations of various activated immune cells, including CD4 memory activated T cells, resting NK cells, M1 macrophages, and CD8 T cells, which demonstrated that TNBC patients with “hot” tumors had an immuno-active TIME. Similarly, our functional enrichment analysis presented that B cell and T cell receptor-signaling pathways were significantly enriched in “hot” tumors. Significant associations with the activation of T cells and the regulation of immune responses were found in “hot” tumors. Complex interactions between immunosuppressive cells cooperate to suppress the anti-tumor immune responses and promote disease progression. Hence, our findings might provide a reference for guiding combinatorial immunotherapy strategies. For example, a patient with “hot” TNBC tumors might respond to a single ICI, resulting in the intensification of the preexisting anti-tumor benefits and further prolonging survival. However, in TNBC patients with “cold” tumors, a single-agent ICI might not be sufficient. Thus, radiotherapy, chemotherapy, or novel therapeutic strategies, such as inducible T cells co-stimulator (ICOS) agonist, NCT03829501, transforming growth factor-beta (TGF-β) inhibitor, NCT04429542, along with ICIs might unleash the silent anti-tumor immunity and further generate promising clinical prognosis by transforming the “cold” tumor into a “hot” tumor (2, 16, 41).

Different predictive models focus on the TIME and immune landscape for TNBC clinical prognosis and therapeutic sensitivity, but most of them only emphasized clusters and characteristics of intratumoral immunes cells, mRNA panels, and/or protein signatures, and their clinical applications remain to be clarified (42–45). Given the current unsatisfactory immunotherapeutic benefits in patients with TNBC, patient selection using reliable biomarkers for predicting responses is necessary (2). PD-L1, TILs, and TMB are commonly used to guide treatment, but they were subjected to inconsistent results and low predictive accuracy in different clinical trials (16, 18–20). Herein, we highlighted the comprehensive landscape and diagnostic value of CMGs, for the exploration of novel biomarkers. Moreover, traditional prognostic signatures were established through an individual-based model, which required the recognition of survival event information a priory, i.e., it was “supervised”. In current study, we executed the unsupervised consensus clustering algorithm based on expression profiles of CMGs to evaluate the characteristic subclasses of TIME, which could maximize the homogeneity of immune composition within the same cluster and the heterogeneity among different clusters (46). In addition, we identified candidate CMGs rigorously by integrating LASSO regression analysis with the SVM-RFE machine learning algorithm to reinforce the statistical power of the results.

Subsequently, we identified three CMGs (CD86, TNFRSF17, and TNFRSF1B) as diagnostic markers by numerous bioinformatics. CD86, also termed as B70 (B7–2), exerts a suppressive role through CTLA-4 on T cells activation. Thus, its competitive stimulation signal by binding to CD28 is crucial in immune responses, survival of T lymphocytes, and generation of cytokines (47). In the stimulatory status, CD86 can up-regulate its expression via antigen-presenting cells (APCs), and further combine with CD28 delivering stimulation signals to promote anti-tumor immune and enhance activating T cells (48, 49). TNFRSF17, a transmembrane glycoprotein, also known as B cell maturation antigen, is preferentially expressed by mature B lymphocytes and critically regulate B cell proliferation and survival, as well as maturation and differentiation into plasma cells. Previous studies indicated that TNFRSF17 has a dispensable role in overall B cells homeostasis and is an important surface protein supporting the survival of multiple myeloma cells (50, 51). Preclinical models found that the overexpression and activation of TNFRSF17 was associated with multiple myeloma, supporting its potential utility as a therapeutic target. And significant clinical responses in patients with refractory multiple myeloma who failed at least three prior treatments had been achieved by the anti-TNFRSF17 antibody-drug conjugate (52). TNFRSF1B or TNFR2, a member of the TNF receptor superfamily, is expressed by T cells, deliver activating signals, which are largely dependent on antigen recognition and participate in activation, clonal expansion, and differentiation of T cells. Accumulating evidence in recent years indicates that costimulatory signals via TNFR2 plays indispensable roles in protective immunity, inflammatory, autoimmune diseases, and tumor immunotherapy (53).

Based on above three diagnostic markers, we developed a diagnostic nomogram for TNBC patients, which showed that patients with high expressions of CD86, TNFRSF17, and TNFRSF1B had a high probability of “hot” tumor. Besides, satisfactory predictive performance of this nomogram was validated in three independent datasets, including the TCGA, GSE76250, and GSE58812. The “hot” TNBC tumors were mainly related to the BPs of T cell activation and immune response regulation, which implied that patients with “hot” tumors might likely respond to immunotherapy. In consistent with above presumption, the mIHC results showed that responders to immunotherapy were significantly associated with high expressions of CD86, TNFRSF17 and TNFRSF1B in TNBC patients. Hence, our diagnostic nomogram has the potential to aid identifying ideal TNBC patients who may benefit from ICIs, thereby providing immunotherapeutic guidance.

There were some limitations in this study. First, although we included three different independent datasets in current study, it is a retrospective analysis and all data were obtained from public databases, so practical bias might be unavoidable. Second, the underlying mechanism of these three diagnostic markers (TNFRSF17, CD86 and TNFRSF1B) remain poorly understood. Third, we performed this research by means of bioinformatics, further experimental validation of their predictive ability and clinical value are needed in future. Finally, although we constructed our diagnostic model based on CMGs from TCGA data consisting of samples from the United States and validated it using GEO datasets comprising of populations from France and China, prospective studies in different populations are warranted to further validate these results.

## Section: Conclusions

In summary, we comprehensively parse the expression patterns and clinical value of costimulatory molecules in TNBC patients and further clustered patients into two TIME subclasses (“hot” and “cold”) for patients’ stratification. In addition, we identified three CMGs (CD86, TNFRSF17 and TNFRSF1B) as putative diagnostic markers, based on which, a novel diagnostic nomogram for predicting TIME status were constructed and validated with good predictive accuracy and clinical value. This may provide a new insight into the value of CMGs in stratifying TIME status of patients with TNBC, which might serve as a tool to identify ideal candidates and tailor rational immunotherapeutic strategies for TNBC patients.

## Section: Data availability statement

The datasets presented in this study can be found in online repositories. The names of the repository/repositories and accession number(s) can be found in the article/ Supplementary Material .

## Section: Ethics statement

The studies involving humans were approved by the Ethics Committee of Sun Yat-Sen University Cancer Center. The studies were conducted in accordance with the local legislation and institutional requirements. The ethics committee/institutional review board waived the requirement of written informed consent for participation from the participants or the participants’ legal guardians/next of kin because Written informed consent from all participants was waived due to its retrospective nature.

## Section: Author contributions

CZ: Writing – review & editing, Writing – original draft, Formal analysis, Data curation. WZ: Methodology, Writing – review & editing, Writing – original draft, Formal analysis. YM: Data curation, Writing – review & editing, Writing – original draft. MW: Writing – review & editing, Data curation. QC: Writing – review & editing, Data curation. JH: Project administration, Funding acquisition, Writing – review & editing. ZZ: Writing – original draft, Conceptualization, Writing – review & editing, Project administration. FD: Methodology, Formal analysis, Data curation, Writing – review & editing, Writing – original draft, Conceptualization.

## Section: Acknowledgments

Thanks to all researchers who participated in this work.

## Section: Funding Statement

The author(s) declare financial support was received for the research, authorship, and/or publication of this article. This study was supported by the cultivation foundation for the junior teachers in Sun Yat-sen University (No.20ykpy164).

## Section: Conflict of interest

The authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.

## Section: Publisher’s note

All claims expressed in this article are solely those of the authors and do not necessarily represent those of their affiliated organizations, or those of the publisher, the editors and the reviewers. Any product that may be evaluated in this article, or claim that may be made by its manufacturer, is not guaranteed or endorsed by the publisher.

## Section: Supplementary material

The Supplementary Material for this article can be found online at: https://www.frontiersin.org/articles/10.3389/fimmu.2024.1424259/full#supplementary-material

Comparison of tumor purity among different TNBC patient clusters. The comparison of tumor purity in TCGA (A); GSE76250 (B); and GSE58812 datasets (C).

Comparison of tumor-stromal and immune scores among different TNBC patient clusters. The comparison of stromal scores (A) and immune scores (B) among different clusters in TCGA dataset; The comparison of stromal scores (C) and immune scores (D) among different clusters in GSE76250 dataset; The comparison of stromal scores (E) and immune scores (F) among different clusters in GSE58812 dataset.

Comparison of tumor purity between different immune environment subclasses. Significant differences in tumor purity between the “cold” and the “hot” tumor groups in TCGA (A); GSE76250 (B); and GSE58812 datasets (C).

The correlation heat map shows the correlation of 22 immune cells between two TIME subclasses in TCGA (A), GSE76250 (B), and GSE58812 datasets (C). The number within colored squares represents the strength of the correlation; the larger is the number, the stronger is the correlation. Blue represents a negative correlation and red represents a positive correlation.

## Section: Associated Data

Comparison of tumor purity among different TNBC patient clusters. The comparison of tumor purity in TCGA (A); GSE76250 (B); and GSE58812 datasets (C).

Comparison of tumor-stromal and immune scores among different TNBC patient clusters. The comparison of stromal scores (A) and immune scores (B) among different clusters in TCGA dataset; The comparison of stromal scores (C) and immune scores (D) among different clusters in GSE76250 dataset; The comparison of stromal scores (E) and immune scores (F) among different clusters in GSE58812 dataset.

Comparison of tumor purity between different immune environment subclasses. Significant differences in tumor purity between the “cold” and the “hot” tumor groups in TCGA (A); GSE76250 (B); and GSE58812 datasets (C).

The correlation heat map shows the correlation of 22 immune cells between two TIME subclasses in TCGA (A), GSE76250 (B), and GSE58812 datasets (C). The number within colored squares represents the strength of the correlation; the larger is the number, the stronger is the correlation. Blue represents a negative correlation and red represents a positive correlation.

## Section: Associated Data › Supplementary Materials

Comparison of tumor purity among different TNBC patient clusters. The comparison of tumor purity in TCGA (A); GSE76250 (B); and GSE58812 datasets (C).

Comparison of tumor-stromal and immune scores among different TNBC patient clusters. The comparison of stromal scores (A) and immune scores (B) among different clusters in TCGA dataset; The comparison of stromal scores (C) and immune scores (D) among different clusters in GSE76250 dataset; The comparison of stromal scores (E) and immune scores (F) among different clusters in GSE58812 dataset.

Comparison of tumor purity between different immune environment subclasses. Significant differences in tumor purity between the “cold” and the “hot” tumor groups in TCGA (A); GSE76250 (B); and GSE58812 datasets (C).

The correlation heat map shows the correlation of 22 immune cells between two TIME subclasses in TCGA (A), GSE76250 (B), and GSE58812 datasets (C). The number within colored squares represents the strength of the correlation; the larger is the number, the stronger is the correlation. Blue represents a negative correlation and red represents a positive correlation.

## Section: Associated Data › Data Availability Statement

The datasets presented in this study can be found in online repositories. The names of the repository/repositories and accession number(s) can be found in the article/ Supplementary Material .


---

# Integrating Traditional Machine Learning and Deep Learning for Precision Screening of Anticancer Peptides: A Novel Approach for Efficient Drug Discovery

- **Authors:** Meiqi Xu, Jiefu Pang, Yangyang Ye, Ziyi Zhang
- **Issuer:** ACS omega
- **Type:** Scientific article
- **Published:** 2024-04-01
- **Language:** en
- **DOI:** 10.1021/acsomega.4c01374
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38617603/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractThe rapid and effective identification of anticancer peptides (ACPs) by computer technology provides a new perspective for cancer treatment. In the identification process of ACPs, accurate sequence encoding and effective classification models are crucial for predicting their biological activity. Traditional machine learning methods have been widely applied in sequence analysis, but deep learning provides a new approach to capture sequence complexity. In this study, a two-stage ACPs classification model was innovatively proposed. Three novel coding strategies were explored; two mainstream Natural Language Processing (NLP) models and 11 machine learning models were fused to identify ACPs, which significantly improved the prediction accuracy of ACPs. We analyzed the correlation between peptide chain amino acids and evaluated the relevant performance of the model by the ROC curve and t-SNE dimensionality reduction technique. The results indicated that the deep learning and machine learning fusion models of M3E-base and KNeighborsDist models, especially when considering the semantic information on amino acid sequences, achieved the highest average accuracy (AvgAcc) of 0.939, with an AUC value as high as 0.97. Then, in vitro cell experiments were used to verify that the two ACPs predicted by the model had antitumor efficacy. This study provides a convenient and effective method for screening ACPs. With further optimization and testing, these strategies have the potential to play an important role in drug discovery and design.

## Section: Introduction

Cancer is a significant global public health issue, with a rapid increase in cancer incidence and mortality rates worldwide.1,2 It is estimated that by 2025, the annual number of new cancer cases globally will exceed 20 million.3 Common cancer treatment modalities include surgery, chemotherapy, and radiotherapy.4 Among these, chemotherapy is one of the primary approaches to cancer treatment. However, the major challenge faced by traditional chemotherapy is the lack of specificity of chemotherapeutic drugs, making it difficult to target tumor sites for localized treatment. This leads to collateral damage to healthy tissues and a range of complications, often necessitating discontinuation of treatment. Therefore, there is a pressing need for breakthroughs in cancer drug therapy.

Anticancer peptides (ACPs) represent a class of peptides with anticancer activity and are found in various organisms, including mammals, plants, birds, amphibians, fish, insects, and microorganisms.5 Compared to traditional chemotherapy drugs, proteins, monoclonal antibodies and other agents, ACPs possess several distinctive characteristics, such as high specificity, ease of synthesis and modification, strong tumor penetration capabilities and diverse administration methods.6 As an emerging anticancer therapy, ACPs have received widespread attention in recent years. In terms of clinical applications, although ACPs are still in the early stages of development, a small number of peptide drugs have successfully entered clinical trials, demonstrating their potential in treating specific cancers. With the in-depth research on ACPs and the advancement of related technologies, we have reason to believe that ACPs will play an increasingly important role in future cancer treatment and bring new hope to cancer patients.

Ideally, anticancer peptides can selectively target cancer cells without harming normal tissue cells, inducing cancer cell death by altering cell membrane permeability, or interacting with intrinsic targets within cancer cells. The mechanisms of action of ACPs from different sources and their modified peptides have become a recent focus of research in anticancer drug development.7−9 Some ACP-based drugs have already entered clinical trials or been approved for use.10 Therefore, the rapid identification of potential ACPs holds significant importance for the development of cancer treatments. However, traditional methods of identifying ACPs through wet laboratory experiments are relatively costly and time-consuming. Computational techniques in the field of bioinformatics provide a solution to the rapid and accurate identification of ACPs. Among various computational methods, machine learning has emerged as a promising approach to efficiently identifying ACPs.

Traditional machine learning methods for ACP identification involve manually designing features for classifying protein sequences, followed by the use of classification models such as Support Vector Machines (SVM), Random Forest (RF), K-Nearest Neighbors (KNN), Extra Trees and Gradient Boosting Trees.11−14 However, relying solely on handcrafted features may not fully capture the complexity and diversity of data features.15,16 Deep learning methods, known for their ability to efficiently handle unstructured data, have increasingly been applied in ACP identification.17 Yi et al. introduced a deep learning Long Short-Term Memory (LSTM) neural network model, ACP-DL, which automatically learned how to identify anticancer peptides and nonanticancer peptides by integrating binary profile features and a simplified amino acid alphabet sparse matrix.18 However, this method still fundamentally used handcrafted features as inputs, limiting the neural network’s ability to acquire raw information. Yang et al. proposed the CACPP model, which employed a convolutional neural network (CNN) to extract high-potential features from peptide sequences and a contrastive learning module to learn more distinguishable feature representations in a deep learning framework.19 However, due to the restricted receptive field of the CNN network, it was challenging to capture the interactions between amino acids that are distant from each other in long peptide chains. Sun et al. proposed an ACP-BC model, which uses a bidirectional long short-term memory network (BiLSTM) to extract features from the original sequence and obtains deep abstract features through a bidirectional encoder representation converter (BERT), achieving an accuracy of 87%.20 However, handcrafted features also limited the neural network’s ability to acquire raw information, and using chemical formulas as inputs for the BERT network made it prone to truncation when peptide chains were too long. Currently, it appears that neural networks commonly used in computer vision, such as CNNs, and sequence-based neural networks, such as LSTMs, are more prevalent in ACP identification models. However, we believe that models related to Natural Language Processing (NLP) are more suitable for ACP screening.

In this study, we employed four different feature representation and encoding methods, and trained and compared various deep learning and machine learning models to screen peptide sequences with anticancer potential. First, we performed bigram processing on amino acid sequences to generate overlapping matrices and conducted relevant statistical analysis and t-SNE dimensionality reduction visualization. This aided in exploring the co-occurrence relationships and correlations between amino acids, providing support for the design and prediction of peptide sequences with anticancer potential. In the feature engineering phase, we utilized three encoding methods: (1) encoding considering only the amino acid letter information, (2) encoding considering both amino acid letter information and amino acid position information, and (3) encoding the amino acid sequence as if it were a sentence. In the third encoding method, we used two different NLP sequence representations, with or without splitting amino acids, and performed transfer training using two NLP models, BERT and M3E. We employed a greedy soup strategy to enhance network generalization and trained various machine learning models on top of deep learning. The results for each method included peptide sequence classification as well as performance evaluation using tools such as ROC curves and t-SNE dimensionality reduction plots. We identified the model combination of the m3e-base and KNeighborsDist with the highest average accuracy (ValACC and TestACC) of 93.85%. Using this model, we screened peptide sequences effectively validated by both the original NLP model and the comprehensive model, followed by synthesis and in vitro antitumor efficacy validation. The results indicated that the peptides validated by the model demonstrated significant anticancer cell cytotoxicity. Overall, our innovative approach combining NLP language models and machine learning models for ACP screening achieved high accuracy and ease of implementation compared with traditional screening methods. Through in vitro experiments, we confirmed that the peptides selected by our model possess effective anticancer activity, which could aid researchers in discovering more potential ACPs and promoting the development of ACP-based drugs. The workflow of this study was illustrated in Figure 1.

Workflow of this study.

## Section: Materials and Methods › Data Collection

The data for this study were collected from various publicly available anticancer peptide databases, including APD3 (https://aps.unmc.edu/database/anti), BioPepDB (http://bis.zju.edu.cn/biopepdbr/index.php?p=search&field=category&query=anticancer), DPL (http://www.peptide-ligand.cn/search/?csrfmiddlewaretoken=PSqYxvTcUbmCHIAOCjLDJa0tzZky9MoQ6YR9NrAVsHHqeUB6uBkdMNyrmIJ1o2Zf&q0=&q1=&q2=&q4=Anticancer+&q3=&q5=&submit=Search), PlantPepDB (http://14.139.61.8/PlantPepDB/pages/browse_result.php), and FeptideDB (http://www4g.biotec.or.th/FeptideDB/peptide_search.php). These diverse databases provided comprehensive data support by offering a wide range of anticancer peptide sequence information. To ensure data integrity, duplicate peptides within individual databases and between databases were removed, and the anticancer activity of each peptide was rigorously validated. The integrated database consists of 859 anticancer peptides. Additionally, to balance the data set, an equal number of random peptides were generated using a randomization process to serve as control samples for training and testing.

## Section: Materials and Methods › Data Preprocessing

Data preprocessing played a critical role in this study to ensure the quality and suitability of the amino acid sequence data. Strategies employed included identifying inconsistent or unexpected format data within sequences and correcting or removing them to ensure data set consistency and reliability. Furthermore, techniques such as imputation, deletion, or interpolation were applied to address missing values or blank data, ensuring data completeness and usability. In addition, noise data were also processed during data cleaning using filtering or other denoising methods to reduce random interference in the data, ensuring the stability and reliability of subsequent analyses.

After data cleaning, the Bigram method for processing amino acid sequences was a key step in this study.21 By applying Bigram processing to amino acid sequences, we generated an overlapping matrix. This matrix recorded the pairwise occurrences of amino acids in the sequences and, through statistical analysis methods, explored co-occurrence relationships and correlations between amino acids. Through the analysis of these relationships, we identified potential patterns and feature sequences with anticancer potential.

## Section: Materials and Methods › Peptide Sequence Feature Extraction and Representation

In this study, the feature extraction methods covered three novel encoding methods aiming to better capture the features of amino acid sequences. First, the first method considered only the encoding of the amino acid letters themselves, mapping different amino acids to specific symbols or numbers. Second, the second method comprehensively considered the letter and position information on amino acids for a more comprehensive representation of amino acid sequence features. Lastly, the third method viewed amino acid sequences as natural language texts, employing two different NLP sequence representation methods: one split the amino acid sequence into individual amino acids as words and the other treated the entire amino acid sequence as a sentence. Both methods used models from NLP (e.g., BERT and M3E) to represent amino acid sequences in vectorized form, facilitating understanding and processing by deep learning models.

## Section: Materials and Methods › Screening Model Construction › Construction of Screening Models Based on Machine Learning

In this study, for screening anticancer peptides, the research team chose a variety of machine learning algorithms for comparative analysis. These algorithms included LightGBMLarge, LightGBMXT, XGBoost, LightGBM, CatBoost, KNeighborsDist, KNeighborsUnif, RandomForestEntr, RandomForestGini, ExtraTreesEntr and ExtraTreesGini.

For model training and optimization, exhaustive parameter adjustments and optimizations were conducted for the machine learning models. For gradient boosting tree models such as LightGBM, XGBoost, and CatBoost, key parameters such as learning rate, tree depth, and number of leaf nodes were adjusted to improve model generalization and predictive performance. In KNN models, parameters such as the number of neighbors and distance measurement methods were adjusted. For ensemble learning methods such as Random Forests and Extra Trees, parameters such as the number of trees and maximum number of features were optimized to achieve the best model effect. During the training process, methods such as grid search were used to further enhance model stability and performance.

## Section: Materials and Methods › Screening Model Construction › Construction of Screening Models Based on Deep Learning

Specifically, two main deep learning models, BERT (Bidirectional Encoder Representations from Transformers) and M3E (Multiscale 3D Epitope Prediction), were chosen and explored in this study. BERT, a milestone in the NLP field with a Transformer structure, excels in capturing sequence features and context. M3E, a multitask model, has been enhanced for text classification tasks, allowing it to process multiscale features between sequences, which is advantageous for protein function prediction.

Moreover, in addition to the deep learning models, machine learning models were also incorporated to enhance the model performance. Specifically, comparative experiments were conducted in the BERT and M3E models, including using only NLP models and combining them with various machine learning models. These machine learning models include the ones listed above, such as LightGBMLarge, XGBoost, KNeighbors, etc., used to further enhance predictive performance on top of deep learning models.

During the model training and optimization process, this study conducted exhaustive tuning for different deep learning models and strategies. For BERT and M3E models, key hyperparameters such as learning rate, number of layers, and number of hidden units were adjusted, and techniques like pretraining and fine-tuning were used to improve model performance. In the model combination stage, parameters of different machine learning models were adjusted, and optimization methods such as grid search were used. Throughout the training process, appropriate loss functions and evaluation metrics were used to obtain more robust models with stronger generalization capabilities.

## Section: Materials and Methods › Experimental Design

In the experimental design of this study, a strict validation and test data set division approach was adopted (60% of the data for training, 20% for validation and tuning model parameters, and the final 20% for the ultimate model testing and evaluation). For the optimization of model parameters, methods like grid search were used to determine the best combination of hyperparameters, thereby enhancing the model’s generalizability. Regarding computational equipment and configuration, the experiment utilized high-performance computing servers equipped with high-memory GPUs (NVIDIA GeForce RTX 2070 graphics cards) to accelerate the model training and optimization process. The experimental environment was based on the Python programming language, employing relevant deep learning frameworks (such as PyTorch) and machine learning libraries (such as Scikit-learn), ensuring stability and efficiency of the experimental platform.

## Section: Materials and Methods › Model Evaluation

In the model evaluation process of this study, the performance metrics used covered multiple aspects, including Accuracy, Recall, Precision, F1 Score, and Area Under the Curve (AUC). These metrics were capable of comprehensively assessing the model’s performance in various aspects.

Accuracy intuitively reflects the overall predictive accuracy of the model, that is, the proportion of correctly predicted samples, and is a key indicator of the model’s basic performance. Recall measures the proportion of anticancer peptides identified by the model out of the total actual anticancer peptides, focusing on the model’s coverage capability. Precision assesses the proportion of samples correctly identified as anticancer peptides by the model out of the total samples predicted as anticancer peptides, reflecting the model’s accuracy. The F1 Score, which is the harmonic mean of precision and recall, provides an evaluation of comprehensive performance, particularly suitable for imbalanced data sets. Lastly, the AUC value measures the model’s overall performance at different thresholds, serving as an important indicator of the model’s predictive capacity. Together, these evaluation metrics enable us to understand and assess the model’s performance from multiple dimensions comprehensively, ensuring the model’s effectiveness and reliability in practical applications.

## Section: Materials and Methods › In Vitro Antitumor Efficacy of Synthetic Peptides

The model with the best effect was selected to predict two peptides with a high antitumor efficacy for synthesis. The two peptide sequences were purchased from Jill Biochemical Co., Ltd. (Shanghai, China) and synthesized by the synthesis method of fluorenylmethyloxy carbonyl chloride protective amino acids. The purity of the synthetic peptide was detected by high-performance liquid chromatography (HPLC) to be more than 95%. The in vitro cytotoxicity of peptides was evaluated in 4T1 cells (mouse breast cancer cells) using the sulfonyl rhodamine B (SRB) assay (Sigma-Aldrich, St. Louis, MO, USA).22,23 4T1 cells (6 × 103 cells/well) were seeded in 96-well plates, incubated for 24 h, and then treated with peptides at 37 °C for 24 h. The cell viability was determined using SRB, which allowed quantification of the living cells by measuring absorbance at 540 nm with a 96-well plate reader (model 680; Bio-Rad Laboratories Inc., Hercules, CA, USA). The half-maximal inhibitory concentration (IC50) was calculated according to the dose–effect curves using GraphPad Prism 8 software.

## Section: Results

Overlapping matrix visualization.

Visual analysis of encoding based on amino acid letters only. (a) ROC curves and AUC values. ROC: receiver operating characteristic; AUC: area under the ROC curve. (b) T-SNE dimensionality reduction diagram.

Visual analysis of encoding considering both amino acid letter and position information. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

Visual analysis of deep learning models. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

Visual analysis of fusion models of deep learning and machine learning. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

ROC curves and AUC values of the highest AvgAcc models and comparisons with other ACP predictors.

## Section: Results › Distribution Statistics Display

The activity of ACPs is influenced by the composition of amino acids and their structure. Previous studies mostly considered the frequency of individual amino acids in ACPs.24 However, we believed that the co-occurrence relationships and correlations between amino acids are more meaningful in the search for and exploration of peptides with anticancer activity. Therefore, we processed the amino acid sequences through bigram processing, generated overlapping matrices, and conducted a statistical analysis of the results.

As shown in the context matrix plot (Figure 2), lysine (Lys, K), alanine (Ala, A), and leucine (Leu, L) had the highest frequency in ACPs. This may be attributed to the positively charged nature of these amino acids or their hydrophobic properties. When ACPs interact with cancer cell membranes, the positively charged hydrophilic regions effectively bind to the negatively charged surface of cancer cell membranes through electrostatic adsorption. Simultaneously, the hydrophobic regions bind to the membrane lipids. This laid the foundation for the selective action of ACPs on cancer cells, and the results were consistent with the findings reported in the literature.25 It was noteworthy that the top three amino acid pairs in terms of occurrence frequency are K-K, A-K, and K-L, with frequencies of 617, 485, and 457, respectively (Table 1). Identifying amino acid pairs with higher occurrence frequencies was more helpful in designing amino acid sequences with anticancer activity based on contextual relationships, which could not be achieved by only counting individual amino acids.

Overlapping matrix visualization.

## Section: Results › Machine Learning Model Performance Evaluation Results

Visual analysis of encoding based on amino acid letters only. (a) ROC curves and AUC values. ROC: receiver operating characteristic; AUC: area under the ROC curve. (b) T-SNE dimensionality reduction diagram.

Visual analysis of encoding considering both amino acid letter and position information. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

## Section: Results › Machine Learning Model Performance Evaluation Results › Results of Encoding Based on Amino Acid Letters Only

We first explored the impact of encoding based on amino acid letters on the performance of machine learning models. This encoding strategy maps different amino acids to a set of unique symbols or numbers, serving as the basis for training and predicting machine learning models. To comprehensively assess the effectiveness of this encoding method, we employed a series of advanced machine learning algorithms, including but not limited to LightGBMLarge, XGBoost, CatBoost, etc. Each algorithm was evaluated on multiple dimensions including precision (Pre), recall (Rec), F1 score, and accuracy (ACC). The specific results are shown in Table 2. In the comparative analysis, we observed that the XGBoost model achieved a high score of 0.873 in average ACC, and its precision, recall, and F1 scores were also impressive at 0.909, 0.851, and 0.879, respectively. Furthermore, by conducting ROC curve analysis for the top 6 models ranked by ACC (Figure 3a), both XGBoost and LightGBMLarge models demonstrated outstanding performance with AUC values reaching 0.93, highlighting their excellence in classification tasks.

We further performed visual analysis of features using the t-SNE dimensionality reduction technique. Despite the simplicity and intuitiveness of this encoding method, the results in Figure 3b revealed a challenge. There seemed to be a difficulty in distinguishing between ACPs and non-ACPs using features extracted by this encoding method. This might be attributed to the fact that this encoding strategy overlooks spatial positions and contextual information in amino acid sequences, which often play crucial roles in biological sequence analysis.

Visual analysis of encoding based on amino acid letters only. (a) ROC curves and AUC values. ROC: receiver operating characteristic; AUC: area under the ROC curve. (b) T-SNE dimensionality reduction diagram.

## Section: Results › Machine Learning Model Performance Evaluation Results › Results of Encoding Considering Both Amino Acid Letter and Position Information

Next, we delved into a more complex encoding strategy that not only included the letter information on amino acids but also integrated their positional information in the sequence to achieve a comprehensive representation of amino acid sequence features. By introducing positional information, we aimed to capture the spatial structural characteristics of amino acid sequences, thereby enhancing the model’s classification ability for ACPs and non-ACPs. As shown in Table 3, we evaluated various machine learning models, including but not limited to XGBoost, LightGBM, etc. The results indicated that when positional information is introduced, the top-performing models remained comparable to the first encoding method across all metrics. XGBoost and LightGBMLarge models continued to exhibit the best performance. Furthermore, we conducted a comparative analysis of model performance through ROC curves (Figure 4a), and the results corroborated the numerical indicators in the table, demonstrating that the overall performance of the models was maintained.

To further analyze the impact of encoding on classification performance, we applied the t-SNE technique for dimensionality reduction and visualized the model’s classification results (Figure 4b). Despite the introduction of positional information, there was an improvement in the separation of the models in distinguishing ACPs from non-ACPs. However, the results suggested that this improvement was not significant, and the models still faced challenges in clearly distinguishing between the two sequence classes. This might indicate that simply adding positional information had limitations in enhancing the model’s ability to recognize ACPs, or it might suggest the need for further optimization of feature expression and model structure to fully leverage positional information. In conclusion, while the second encoding method provided a more complex and comprehensive feature representation by considering both amino acid letters and positional information, its practical application did not significantly improve model performance.

Visual analysis of encoding considering both amino acid letter and position information. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

## Section: Results › Deep Learning Model Performance Evaluation Results

Visual analysis of deep learning models. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

Visual analysis of fusion models of deep learning and machine learning. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

ROC curves and AUC values of the highest AvgAcc models and comparisons with other ACP predictors.

## Section: Results › Deep Learning Model Performance Evaluation Results › Results without Adding Machine Learning Models

In an effort to improve the results of traditional machine learning models, we experimented with two NLP deep learning models—BERT and M3E. Simultaneously, we employed a third encoding method that treats amino acid sequences as natural language text and utilized two different NLP sequence representation approaches: one treating the entire amino acid sequence as a single sentence and the other splitting the amino acid sequence into individual amino acids as words. This was done to vectorize the amino acid sequences for understanding and processing by deep learning models. As shown in Table 4, in the first NLP sequence representation method (treating the entire amino acid sequence as a single sentence), the BERT model performed better with test set ACC, Pre, Rec, and F1 scores of 0.904, 0.961, 0.851, and 0.903, respectively. The average ACC for the test and validation sets was 0.904. In the second NLP sequence representation method (splitting the amino acid sequence into individual amino acids as words), the M3E model showed superior performance, surpassing the optimal results of the first representation method. The test set ACC, Pre, Rec, and F1 scores reached 0.919, 0.925, 0.920, and 0.923, respectively, with the average ACC for the test and validation sets reaching 0.915. The ROC curve demonstrated an AUC value of 0.96 for the first representation method and a remarkable AUC value of 0.98 for the second representation method (Figure 5a). The t-SNE dimensionality reduction plot also indicated that the second representation method combined with the M3E model had better discriminability for the ACPs (Figure 5b). This aligns with reality as splitting amino acids in the sequence into individual words with a natural order is more consistent with the natural distribution of amino acids in the sequence. Therefore, transforming amino acid sequences into vector representations with semantic information can better capture advanced features and relationships in the sequence, leading to a noticeable improvement in model accuracy.

Visual analysis of deep learning models. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

## Section: Results › Deep Learning Model Performance Evaluation Results › Results of Fusion Models of Machine Learning and Deep Learning

In this study, to enhance the accuracy of deep learning models, we not only independently utilized NLP deep learning models, but also attempted to combine them with traditional machine learning models using the Greedy Soup strategy to achieve a superior performance. Through this fusion approach, we could leverage the ability of deep learning models to extract complex features from amino acid sequences and enhance the final classification accuracy by using machine learning models. We selected the model with the highest ACC from numerous combinations for detailed evaluation, and the results were listed in Table 5. The findings indicated that the overall performance of the model improved after incorporation of machine learning models. In particular, the combination of the M3E-base and KNeighborsDist models exhibited the highest accuracy in all tests, reaching an impressive 93.9%.

On the other hand, we visually presented the experimental results of this fusion strategy. The ROC curve graph clearly illustrated the classification performance of the fusion model (Figure 6a). We observed that when not considering the semantic information on amino acids, the combination of M3E-base and KNeighborsDist achieved an AUC value of 0.95, demonstrating excellent classification capability. In the presence of semantic information, the combination of M3E-base and KNeighborsDist increased the AUC value to 0.97, while the combination of bert_base_uncased and LightGBMXT reached an AUC value of 0.98. This highlighted the significance of semantic information in enhancing model performance.

Furthermore, the t-SNE dimensionality reduction plot revealed the separation of the model in handling different categories of data (Figure 6b). Comparing the dimensionality reduction results of different model combinations, we found that considering spatial information significantly improved the model’s ability to differentiate between ACPs (label = 1) and non-ACPs (label = 0). In particular, the combination of bert_base_uncased and LightGBMXT exhibited a higher category separation in the dimensionality reduction plot, corroborating its high AUC value in the ROC curve graph.

These results not only confirmed the effectiveness of NLP deep learning models in handling amino acid sequences but also indicated that traditional machine learning models could effectively enhance the performance of deep learning models, especially when incorporating semantic information into the sequence. Through this hybrid model, we could more accurately identify and classify ACPs, thereby applying them more effectively in drug design and related fields of bioinformatics.

Visual analysis of fusion models of deep learning and machine learning. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

## Section: Results › Deep Learning Model Performance Evaluation Results › Comprehensive Results and Performance Comparison

This study conducted a comprehensive comparison of the impact of different encoding methods and model combinations on the task of identifying ACPs. By contrasting various encoding strategies and deep learning (DL) models with or without the inclusion of machine learning (ML) models, our determined the optimal model configuration for achieving high-precision recognition of ACPs. In addition, we compared the performance of our models with several currently known excellent ACP predictors. In Table 6, we compared six different encoding and model combination strategies, recording their average accuracy (AvgAcc). XGBoost models based on integer encoding (intEncode) and integer encoding considering amino acid position information (intPositionEncode) both demonstrated an AvgAcc of 0.873, providing a stable baseline performance. However, when transitioning to NLP deep learning models, we noted that bert-base-uncased achieved an AvgAcc of 0.904 without semantic information and without combining ML models. Furthermore, the m3e-base model, when considering semantic information and not combining ML models, reached an AvgAcc of 0.922. When combining DL models with ML models, performance showed a significant improvement. In particular, when not considering semantic information, the combination of the m3e-base and KNeighborsDist increased AvgAcc to 0.915. In the presence of semantic information, the same combination achieved the highest AvgAcc value in this study, reaching 0.939.

The ROC curve graph in Figure 7 provided an intuitive way to compare performance. From the graph, we observed that the combination of m3e-base and KNeighborsDist, which incorporated semantic information, demonstrated the most outstanding classification ability among all of the models, with an AUC value of 0.97. This further emphasized the importance of semantic information in enhancing model accuracy and the potential of ML models to effectively boost the performance of DL models.

Then, we selected two currently known excellent ACP predictors, iACP-FSCM26 and ACPred-FL,27 tested them with our data set, and compared their ROC curves and AccAvg values with our models. The performance comparison results showed that our models were significantly higher than the iACP-FSCM and ACPred-FL models in terms of the AUC value and AccAvg value. It proved that our models were advanced compared to existing ACP predictors.

ROC curves and AUC values of the highest AvgAcc models and comparisons with other ACP predictors.

## Section: Results › Model Prediction and In Vitro Antitumor Efficacy of Peptides

We randomly selected 741 peptides as test peptides in the database and predicted them using the model m3e-base+KNeighborsDist with the highest comprehensive evaluation. Two peptides with potentially high anticancer activity were predicted, namely, KEWLE and KRLAFA. Mass spectrometry results showed that the two peptides were successfully synthesized, and HPLC results confirmed that the purity of both peptides was above 95% (Figures S1–S4). Mouse breast cancer cell 4T1 cells were selected to validate the in vitro antitumor efficacy of the two peptides. The experimental results are shown in Table 7, and the IC50 values of the two peptides were, respectively, 47.46 ± 12.14 and 39.99 ± 9.744 μM, and both had in vitro antitumor efficacy.

## Section: Discussion

This study aimed to construct a precise and automated model for the screening of ACPs using machine learning methods. Initially, three different feature representation and encoding methods were employed, with the third encoding method combining two different NLP sequence representations, utilizing NLP models such as BERT and M3E, and introducing a combination strategy of machine learning models. By integration of various machine learning and deep learning models, a model combination with higher accuracy was ultimately selected. In vitro anticancer efficacy validation was performed, demonstrating that the peptides validated by the model exhibited potent anticancer cell toxicity. Overall, this study innovatively incorporated NLP into the screening of anticancer peptides, achieving higher and more achievable accuracy compared to traditional methods and confirming the practical and effective anticancer activity of the selected peptides.

The machine learning methods employed in this study, such as LightGBM, XGBoost, etc., demonstrated good generalization performance in terms of model efficiency, especially when dealing with high-dimensional features and large-scale data, exhibiting high efficiency and prediction accuracy. These machine learning models effectively screened anticancer peptides through traditional feature engineering and model fusion strategies, confirming their reliability in peptide sequence analysis. In contrast, deep learning methods such as BERT, M3E, etc., showed advantages in capturing sequence features and contextual information. These models could better utilize the sequential information and global context in the sequences, enhancing the model’s predictive capabilities through learning advanced features. Particularly, the BERT model, as an advanced model in the natural language processing field, successfully applied the Transformer structure to learn representations of protein sequences, offering new possibilities for the screening of anticancer peptides. In summary, traditional machine learning models have advantages in efficiency, while deep learning models excel in learning and representing sequence features. Therefore, combining machine learning and deep learning methods may become a new trend in the future for screening anticancer peptides. It is worth noting that compared with the studies by Wei et al.27 and Charoenkwan et al.,26 this study focuses on predicting the activity of ACP using a combination of deep learning and efficient feature expression, achieving the highest prediction accuracy of 0.939. The above comparative studies construct effective sequence feature expressions and achieve prediction through traditional machine learning, and the prediction accuracy is slightly lower than that in this study.

It was noteworthy that this experiment demonstrated significant practical value in the screening of anticancer peptides. By application of a combination of machine learning and deep learning models, the efficiency of anticancer peptide screening was improved. Traditional methods of anticancer peptide screening typically required extensive experimentation and human resources. The model constructed in this study could rapidly and accurately predict peptide sequences with potential anticancer activity, significantly shortening the screening cycle. This precise screening method effectively reduced the cost of developing new anticancer drugs, accelerating the drug development process. This is also in line with the future development trend in this field using advanced computational methods to discover functional peptides to aid drug screening.28

From a longer-term perspective, ACPs have emerged as a promising alternative due to their specificity, lower toxicity, and ability to circumvent drug resistance mechanisms that often limit the effectiveness of traditional therapies. Traditional chemotherapy indiscriminately targets rapidly dividing cells, leading to significant side effects, whereas ACPs offer a more targeted approach, potentially leading to more effective and less harmful treatments. Moreover, advancements in peptide engineering and drug delivery systems have significantly enhanced the stability, bioavailability, and tumor-targeting capabilities of ACPs, making them a viable option in the arsenal against cancer. However, despite these advantages, the clinical application of ACPs still faces several challenges such as their rapid degradation in the bloodstream, potential immunogenicity, and the complexity of large-scale synthesis. These issues necessitate further research and innovation to overcome. Additionally, while ACPs show promise in preclinical studies, their efficacy and safety in human trials must be rigorously tested. The possibility of replacing traditional anticancer drugs with peptides depends not only on overcoming these technical hurdles but also on demonstrating superior clinical outcomes.

While this study has made significant progress in anticancer peptide screening, there are limitations that need to be considered. First, the quality and quantity of the data set have a crucial impact on the training and prediction of machine learning and deep learning models, and the data set used in this study may have limitations. The size and coverage of the data set may influence the generalization ability and predictive performance of the model. Therefore, a more extensive and representative data set could further enhance the robustness of the model. Second, the choice of feature representation and encoding methods has a significant impact on the performance of the model. Although the feature engineering methods used in this study are diverse, there may still be a potential optimization space. Further exploration of more effective feature representation and encoding methods may improve the model’s ability to abstractly represent peptide sequences, thereby enhancing predictive performance. Lastly, despite the in vitro experiments validating the anticancer activity of the peptides screened by the model, more experimental data and further clinical trials are needed to verify the feasibility and effectiveness of their clinical application. There is a certain difference between laboratory conditions and actual treatment environments, necessitating more clinical data to support the experimental results obtained in this study.

## Section: Conclusions

This study successfully integrated different encoding methods with multiple machine learning approaches to construct a precise screening model for anticancer peptides. Through rigorous model training and comparison, the study accurately screened peptide sequences with anticancer potential and confirmed the effectiveness of the model’s predictions in in vitro experiments. Particularly, the introduction of NLP language models into the screening of anticancer peptides in this study, compared with traditional methods, significantly improved both the accuracy and efficiency of screening. This opened up new possibilities and avenues for the discovery and research of anticancer drugs. However, despite the relatively outstanding results achieved in this study, there were still some suggestions for improvement to consider. In future research, we will continue to explore and incorporate the latest technologies and theoretical advancements to continuously enhance the performance and practicality of the model, promoting the development and application of anticancer drugs.

## Section: Acknowledgments

Authors gratefully acknowledge the financial support from the Zhejiang City University Research and Incubation Fund (J-202326).

## Section: Data Availability Statement

All code used in data analysis and preparation of the manuscript, alongside a description of necessary steps for reproducing results, can be found in a GitHub repository: https://github.com/Keda0411/acps.

## Section: Supporting Information Available

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acsomega.4c01374.

## Section: Author Contributions

M.X. conceived the basic idea and designed the framework. M.Q. and J.P. performed the experiments. M.X., J.P., and Z.Z. wrote the manuscript. Y.Y. revised the manuscript.

## Section: Text

The authors declare no competing financial interest.

## Section: Supplementary Material

ao4c01374_si_001.pdf

## Section: Associated Data

ao4c01374_si_001.pdf

## Section: Associated Data › Supplementary Materials

ao4c01374_si_001.pdf

## Section: Associated Data › Data Availability Statement

All code used in data analysis and preparation of the manuscript, alongside a description of necessary steps for reproducing results, can be found in a GitHub repository: https://github.com/Keda0411/acps.
