# Construction of the miRNA/Pyroptosis-Related Molecular Regulatory Axis in Abdominal Aortic Aneurysm: Evidence From Transcriptome Data Combined With Multiple Machine Learning Approaches Followed by Experiment Validation

- **Authors:** Yongchao Su, Chuangang Lu, Shuchen Chen
- **Issuer:** Journal of immunology research
- **Type:** Scientific article
- **Published:** 2024-10-30
- **Language:** en
- **DOI:** 10.1155/2024/1429510
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39512836/
- **Licence:** CC-BY

## Section: Abstract

Abstract Background: Abdominal aortic aneurysm (AAA) represents a permanent and localized widening of the abdominal aorta, posing a potentially lethal risk of aortic rupture. Several recent studies have highlighted the role of pyroptosis, a pro-inflammatory programed cell death, as critical molecular regulators in AAA occurrence, progression, and rupture. However, the potential effects of pyroptosis in AAA and its upstream microRNA (miRNA) have not been comprehensively clarified. Methods: Through a search of the gene expression omnibus (GEO) database, the expression profiles of mRNAs (GSE7084, GSE57691, and GSE98278) and miRNAs (GSE62179) and corresponding clinical features were downloaded, respectively. Expression profiles of 15 AAA and 10 normal vascular samples were consecutively collected for in vitro experimentation and subsequent analysis. Various machine learning techniques were employed to identify hub pyroptosis-related genes (PRGs), leading to the development of a predictive model termed the PRG classifier. Quantitative real-time-polymerase chain reaction (qRT-PCR), western blot (WB), and enzyme-linked immunosorbent assay (ELISA) were used to confirm the expression of the hub PRGs. The diagnostic and predictive capabilities of the model were comprehensively evaluated in GEO and hospital cohorts. Then, the crucial immune cell infiltration and molecular pathways implicated in the initiation and rupture of AAA and their association with pyroptosis were explored. Lastly, a miRNA/hub pyroptosis-related molecular regulatory axis was constructed using the TargetScan dataset, which was further explored through loss-of-function assays. Results: Differential analysis, enrichment score analysis, and principal component analysis (PCA) revealed that pyroptosis-related molecules were significantly involved in the occurrence of AAA. Utilizing multiple machine learning algorithms, eight key PRGs (cysteinyl aspartate specific proteinase [CASP]1, infiltrating lymphocyte [IL]1B, IL18, IL6, NOD-, LRR- and pyrin domain-containing protein [NLRP]1, NLRP2, NLRP3, and tumor necrosis factor [TNF]) were integrated to establish a PRG classifier. Demonstrating robust diagnostic capabilities (area under curve [AUC] > 0.90), the PRG classifier provided clinical insights across two GEO datasets and effectively differentiated small AAA from large AAA, elective stable AAA (eAAA), and ruptured AAA (rAAA), respectively. qRT-PCR, WB, and ELISA verified the mRNA and protein expression of the hub PRGs. Notably, in hospital cohorts, a substantial positive link was unveiled between the PRG classifier and AAA risk factors (hypertension history, diastolic pressure, triglyceride levels, and aneurysm diameter). Furthermore, immune cell infiltration and functional enrichment analysis revealed significant associations of the PRG classifier/PRGs with M2 macrophage infiltration, activated dendritic cells, and enrichment scores of the cytosolic deoxyribonucleic acid (DNA) sensing pathway and tryptophan metabolism, potentially mediating AAA onset and rupture. Finally, based on 90 differentially expressed miRNAs (DEmiRNAs) and eight hub PRGs through TargetScan dataset, a hsa-miR-331-3p/TNF regulatory axis was constructed, wherein upregulation of hsa-miR-331-3p expression significantly reduced TNF and CASP1 protein levels. Conclusion: A predictive model (PRG classifier) incorporating eight PRGs through multiple machine learning algorithms was developed and validated. This model may stand as a potent tool for diagnosing AAA and assessing disease severity. The identification of the cytosolic DNA sensing pathway and the hsa-miR-331-3p/TNF interaction axis may represent crucial targets for AAA treatment, offering deeper insights into its potential pathogenesis.Keywords: abdominal aortic aneurysm, cytosolic DNA sensing pathway, hsa-miR-331-3p, machine learning algorithms, pyroptosis, TNF

## Section: 1. Introduction

Abdominal aortic aneurysm (AAA) presents as a prevalent vascular ailment marked by localized dilation and weakening of the abdominal aorta, reaching a diameter of 3 cm or greater, surpassing the normal diameter by over 50% [1]. AAA naturally progresses, posing a significant risk of irreversible aneurysmal growth and unpredictable rupture, often resulting in mortality rates reaching 80% [2]. Global reports indicate a 12% increase in AAA-related mortality over the last 20 years, presently claiming around 200,000 lives annually [3]. Typically asymptomatic until enlargement occurs, AAA remains difficult to treat promptly before rupture or mortality [4]. Early diagnosis of AAA prior to rupture, along with continuous monitoring of its biological activity, holds the potential to mitigate associated mortality risks. Currently, open surgical repair and endovascular stent graft therapies are the primary treatment modalities available. Due to the surgical risks involved, clinical practice typically reserves open surgery for patients with AAAs exceeding 5.5 cm and at risk of rupture [5]. Research indicates that by slowing down the increase in aortic diameter by 50%, the annual rates of aortic reconstruction surgery for AAA could potentially be halved [6]. However, an approved and effective pharmacotherapy for limiting and preventing AAA progression and rupture is lacking. Thus, there is a pressing need to identify novel biomarkers in the diagnosis of AAA, determination of individualized risk, discovery of therapeutic targets, and improvement of the understanding of pathogenesis.

Pathophysiologically, progressive depletion, and dysfunction of vascular smooth muscle cells (VSMCs), essential components of the vascular wall responsible for maintaining vessel function, are central to AAA formation and development [7, 8]. VSMC loss, attributed to various forms of cell demise, such as apoptosis, autophagy, and necrosis, has been involved in mediating AAA formation [9]. In recent years, pyroptosis, a programed cell death specifically dependent on Caspase activity, accompanied by the release of multiple inflammatory cytokines, has also been found to contribute to AAA [10]. Observational studies found that compared with non-AAA patients, the mRNA expression levels of NOD-, LRR- and pyrin domain-containing protein (NLRP)3, Caspase-1, and infiltrating lymphocyte (IL)-1β in the circulating white blood cells of AAA patients were increased [11]. Gao et al. [12] demonstrated that gastrin D (GSDMD), an essential protein in pyroptosis, exhibits upregulation in VSMCs within aortic aneurysms and vascular dissections. This upregulation promotes the synthesis of putrescine, exacerbating AAA progression. These findings indicate a significant involvement of pyroptosis in AAA occurrence and progression. Nonetheless, the potential effects of many pyroptosis molecules in AAA remain largely unclear. Therefore, a thorough comprehension of the potential functions of pyroptosis molecules is profoundly significant for advancing early AAA diagnosis, personalized management, and the development of potentially applicable drugs for AAA patients.

Prior genomic investigations have revealed that more than 98% of the human genome is actively transcribed as noncoding ribonucleic acids (ncRNAs) [13]. Traditionally, this ncRNA family is broadly categorized into two groups according to molecular size: small ncRNA (e.g., microRNA [miRNA]; length <200 nt) and long noncoding RNA (lncRNA; length >200 nt) [14]. Unlike protein-coding RNAs, miRNAs exhibit more specific expression patterns, offering a vast yet largely unexplored reservoir of potential molecular drivers of human diseases. They represent a promising new class of biomarkers for conditions like AAA. Accumulating evidence has revealed that miRNA can regulate pyroptosis-related molecules in various ways and contribute to the onset and progression of cardiovascular diseases. Using oxidized low-density lipoprotein-stimulated human THP-1 derived macrophage, Wang et al. [15] found that miRNA-9 suppresses NLRP3 inflammasome activation and mitigates pyroptosis via the JAK1/STAT signaling pathway, thus attenuating atherosclerosis-related inflammation. Li et al. [16] experimentally demonstrated that miRNA-30c-5p can alleviate the pyroptosis of human aorta epithelial cells by inhibiting FOXO3 expression. However, the specific miRNAs implicated in the regulation of AAA pyroptosis remain ambiguous. Hence, it is crucial to investigate the upstream miRNAs that regulate pyroptosis molecular pathways in AAA to advance the development of novel pharmacological therapies.

The availability of high-throughput RNA-sequencing (RNA-seq) datasets provides an unprecedented opportunity to apply advanced machine learning algorithms to discover novel diagnostic, predictive, and therapeutic biomarkers. In the present study, available transcriptomic profiling in gene expression omnibus (GEO) datasets was systematically reviewed to identify hub pyroptosis-related genes (PRGs) and construct a PRG classifier using multiple machine learning algorithms. Fifteen AAA and 10 normal vascular samples were consecutively collected for in vitro experiments. Then, the diagnostic and predictive capacities of the model were thoroughly assessed in GEO and hospital cohorts. The pivotal immune cells infiltrating and underlying pathways implicated in the onset and rupture of AAA, as well as their relationship with pyroptosis, were investigated. Finally, a miRNA/hub pyroptosis-related molecular regulatory axis was constructed based on the TargetScan dataset, and this regulatory axis was further investigated through loss-of-function assays.

## Section: 2. Materials and Methods › 2.1. Dataset Collection, Sample Selection, and Preprocessing

A systematic search was carried out in the GEO (http://www.ncbi.nlm.nih.gov/geo) database to discern relevant microarray data of AAA. During the retrieving process, the species type Homo sapiens was set as a filter, resulting in the inclusion of four datasets (GSE7084, GSE57691, GSE98278, and GSE62179) for both qualitative and quantitative analysis. As for the three expression profiling datasets, 19 samples (10 normal and 9 AAA samples) were obtained in GSE7084, 59 samples in GSE57691 (normal [n = 10], small AAA [n = 20, mean maximum aortic diameter = 54.3 ± 2.3 mm], and large AAA samples [n = 29, mean maximum aortic diameter = 68.4 ± 14.3 mm]), and 48 samples in GSE98278 (elective stable AAA [eAAA] [n = 31] vs. ruptured AAA [rAAA] [n = 17] AAA and intermediate size AAA [n = 15, mean maximum aortic diameter ≤55 mm] vs. large AAA [n = 16, mean maximum aortic diameter >70 mm]). In terms of the miRNA profiling dataset, six samples (two normal and four AAA SMC) were retained in GSE62179. Robust multiarray average analysis was used for microarray data, encompassing background correction, quantile normalization, and summarization [17]. Furthermore, 33 PRGs were compiled from published studies [18] (Supporting Information 1).

## Section: 2. Materials and Methods › 2.2. Landscape of Expression Variation in PRGs in AAA

Differential analysis was executed on the expression of PRGs in the GSE7084 and GSE57691 datasets, comparing control and AAA groups, respectively. The results were visualized using box plots. The single-sample gene set enrichment analysis (ssGSEA) algorithm [19] was employed to calculate enrichment scores of pyroptosis, comparing the scores between the control and AAA groups. Finally, principal component analysis (PCA) [20], utilizing PRGs expression levels, was executed on the GSE7084 and GSE57691 datasets.

## Section: 2. Materials and Methods › 2.3. Discovery of Hub PRGs and Development of a PRG Classifier

To identify robust hub PRGs, machine learning techniques with fivefold cross-validation based on disease status were applied to the GSE7084 and GSE57691 datasets. This included modified least absolute shrinkage and selection operator (LASSO) penalized regression, random forest (RF), and support vector machine (SVM) to choose feature variables. The hub PRGs were derived from the overlapping of the results obtained from SVM, RF, and LASSO.

Artificial neural network (ANN) models were constructed and trained, comprising input, hidden, and output layers. Within each hidden node, the ReLU (rectified linear unit) activation function was employed. The output layer consisted of two nodes (O1 and O2, representing normal and AAA, respectively). A softmax function was applied to each node, designating y2 (probability of AAA; i.e., the O2 node) as Y. Cross-entropy error was utilized as the loss function (E), and the weight values were optimized using the Adam method (learning rate, 0.001; epochs, 1000) [21]. Following training, the weights of the nodes (“NeuralNetworkWeight”) were utilized to compute the PRG score. The formula for calculating the PRG score based on hub PRGs is as follows:

## Section: 2. Materials and Methods › 2.4. Diagnostic Value, Risk Stratification, and Clinical Usefulness of PRG Classifier

Receiver operating characteristic (ROC) analysis was executed to examine the diagnostic capability of the PRG classifier with AAA as the endpoint in the GSE7084 and GSE57691 datasets. Furthermore, the PRG score was compared between small AAA and large AAA in the GSE57691 cohort, between eAAA and rAAA in the GSE98278 cohort, and between intermediate AAA and large AAA in the GSE98278 cohort. ROC analyses were also conducted to evaluate the ability of the PRG classifier to distinguish small AAA from large AAA, eAAA from rAAA, and intermediate AAA from large AAA, respectively. Ultimately, decision curve analysis (DCA) was employed to determine the clinical practicality of the PRG classifier.

## Section: 2. Materials and Methods › 2.5. Design, Study Setting, and Population

A prospective cohort study was conducted among 15 patients with AAA after open surgery at the Department of Vascular Surgery from March 9, 2022, to December 24, 2023. Criteria for inclusion in this study are as follows: (1) participants aged over 18 years and; (2) diagnosis of AAA confirmed via computer tomography angiography. Ethical approval was acquired from the Ethical Guideline of the Committee on Human Experimentation of The Third People's Hospital of Hainan Province (reference: 2023-10-22). Prior to sample and data collection, written informed consent was acquired from the relatives of eligible patients.

## Section: 2. Materials and Methods › 2.6. Tissue Samples and Quantitative Real-Time-Polymerase Chain Reaction (qRT-PCR)

Human AAA and normal samples were acquired from surgical patients and preserved at −80°C for subsequent in vitro experiments. Total RNA was isolated from AAA and normal samples, as well as MOVAS cells, as per the provided guidelines using Trizol (Invitrogen). Reverse transcription of RNA was executed utilizing the RevertAid RT Reverse Transcription Kit (Thermo Scientific). Quantitative PCR was conducted utilizing PowerUp SYBR Green Master Mix (Thermo Scientific), with GAPDH serving as the internal standard. Quantitative reverse transcription-PCR was executed utilizing the ABI 7500 real-time PCR system (Applied Biosystems, Foster City, CA, United States). Fold change in gene expression was examined using the 2−ΔΔCt method. Gene-specific PCR primers are provided in Supporting Information 2.

Following the expression levels of hub PRGs determined through qRT-PCR testing, the PRG score was calculated. Using the median score of PRGs as a threshold, each case was then classified into either the low or high PRG groups.

## Section: 2. Materials and Methods › 2.7. Data Collection and Correlation of PRG Classifier With Clinical Characteristics

Clinical data were collected from electronic medical records. These data encompass age, height, sex, body mass index (BMI), weight, hypertension history, diabetes history, smoking history, fasting blood glucose (FBG), systolic pressure at admission, diastolic pressure at admission, triglyceride at admission, cholesterol at admission, and aneurysm diameter. The link between the PRG classifier and clinical features in hospital cohorts was investigated.

## Section: 2. Materials and Methods › 2.8. Analyses of Immune Cell Infiltration in AAA and Its Relationship With Hub PRGs/PRG Classifier

The CIBERSORTx tool and ssGSEA algorithm [22] were utilized to infer the relative abundance of infiltrating immune cells. The differential composition of immune cells between the normal and AAA groups, as well as between the eAAA and rAAA subgroups, was examined. Spearman's correlation analyses were executed to explore the link between hub PRGs/PRG classifier and immune cells.

## Section: 2. Materials and Methods › 2.9. Discovery of Potential Mechanisms in the Development and Progression of AAA and Its Relationship With Hub PRGs/PRG Classifier

ssGSEA analysis was performed on several representative gene sets (immune-related pathways) [23]. Then, the gene set variation analysis (GSVA) [24] was carried out to discern the signaling pathways according to the Kyoto Encyclopedia of Genes and Genome (KEGG) gene sets (c2.cp.kegg.v7.4.symbols.gmt) obtained from the Molecular Signatures Database. In the analysis of signaling pathways, the differential enrichment score between the normal and AAA groups, as well as between the eAAA and rAAA subgroups, was investigated. Following this, correlation analysis was executed to further elucidate the link between the PRG classifier/hub PRGs and some key biological pathways.

## Section: 2. Materials and Methods › 2.10. Construction of the miRNA/Pyroptosis-Related Molecular Regulatory Axis

Differentially expressed miRNAs (DEmiRNAs) (GSE62179 dataset) between individuals with AAA and healthy control samples were identified. Pairs of DEmiRNAs and hub PRGs were predicted utilizing target miRNA data obtained from the TargetScan databases.

## Section: 2. Materials and Methods › 2.11. Cell Culture and Treatment

The mouse smooth muscle cell (SMC) line MOVAS was sourced from the American Type Culture Collection (ATCC, Manassas, VA, United States). Cells were grown in Petri dishes with Dulbecco's Modified Eagle's Medium (DMEM) comprising 10% fetal bovine serum. Ang II is a commonly utilized stimulant for inducing AAA formation. Cultures were treated with DMEM containing 15 µM Ang II (Sigma–Aldrich, St. Louis, MO, United States) and incubated for 24 h.

## Section: 2. Materials and Methods › 2.12. Cell Transfection

Transfectants, including miR-331-3p mimic and negative control (NC), were sourced from RiboBio (Guangzhou, China). MOVAS were seeded into 96-well plates and underwent transfection with miR-331-3p mimic and NC vectors utilizing Lipofectamine 2000 (Invitrogen) following the provided guidelines.

## Section: 2. Materials and Methods › 2.13. Enzyme-Linked Immunosorbent Assay (ELISA)

Total protein extraction was executed utilizing the Total Protein Extraction Kit (Beyotime). Following centrifugation at 3000× g for 8 min within 40 min, the expression levels of inflammatory cytokines IL1B, IL18, IL6, and tumor necrosis factor (TNF) were measured in the homogeneous supernatants of samples. This was achieved using the corresponding ELISA kits following the provided guidelines.

## Section: 2. Materials and Methods › 2.14. Western Blotting (WB) Analysis

Total proteins were isolated and the protein concentration was examined utilizing the BCA Protein Assay Kit (Thermo Fisher Scientific). Subsequent to this, protein samples (30 μg) underwent 10% SDS-PAGE gel electrophoresis, followed by transfer onto nitrocellulose membranes (Invitrogen). These membranes underwent incubation with anti-cysteinyl aspartate specific proteinase (CASP)1 (1 : 1000; Abcam), anti-NLRP1 (1 : 1000; Abcam), anti-NLRP2 (1 : 1000; Abcam), anti-NLRP3 (1 : 1000; Abcam), anti-TNF (1 : 1000; Abcam), and anti-GAPDH (1 : 5000; Proteintech, Wuhan, China) at 4°C for 12 h. The membranes were exposed to HRP-IgG antibody (1:5000; Proteintech).

## Section: 2. Materials and Methods › 2.15. Statistical Analysis

Statistical analysis was executed utilizing GraphPad Prism 9, SPSS 22, and R software (R v4.3.1). Continuous variables were compared utilizing Student's t-tests, Mann–Whitney, Wilcoxon, or Kruskal–Wallis tests with two-tailed analyses based on the distribution of the variables. Categorical variables were tested utilizing the χ2 or Fisher's exact tests. The threshold for statistical significance was established at p < 0.05 unless specific p-values were provided.

## Section: 3. Results

Landscape of expression variation in PRGs in AAA. (A and B) Differential expression of PRGs between AAA samples and healthy control patient samples in two GEO datasets. (A) GSE7084 datasets; (B) GSE57691 datasets. The asterisks indicate a significant statistical p value calculated using the Wilcoxon test (⁣∗p < 0.05; ⁣∗∗p < 0.01; ⁣∗∗∗p < 0.001). (C and D) Comparison of PRGs score between AAA samples and healthy control patient samples in two GEO datasets. (C) GSE7084 datasets; (D) GSE57691 datasets. The asterisks indicate a significant statistical p value calculated using the Wilcoxon test (⁣∗p < 0.05; ⁣∗∗p < 0.01; ⁣∗∗∗p < 0.001). (E and F) Principal component analysis for the expression profiles of PRGs to distinguish AAA patients from healthy control patients in two AAA cohorts. (E) GSE7084 datasets; (F) GSE57691 datasets. AAA, abdominal aortic aneurysm; GEO, gene expression omnibus; IL, infiltrating lymphocyte; PCA, principal component analysis; PRGs, pyroptosis-related genes; TNF, tumor necrosis factor.

Identification of hub PRGs and construction of a PRG classifier based on machine learning algorithms (including LASSO, RF, and SVM, ANN) with fivefold cross-validation. (A and D) Modified LASSO was used to identify candidate PRGs in two AAA datasets. The Y-axis shows mean square error and the X-axis is log (λ). Dotted vertical lines represent minimum and 1 standard error values of λ. The genes selected at minimum standard error values of λ were finally used for further analysis. (A) GSE7084 datasets (N = 3); (D) GSE57691 datasets (N = 17). (B and E) RF was used to select candidate PRGs with in two AAA datasets and ranked important variables by IncNodePurity. (B) GSE7084 datasets; (E) GSE57691 datasets. SVM algorithm was applied to screen candidate PRGs. (C and F) SVM algorithm was applied to screen candidate PRGs. The blue dots indicated the lowest error rate and the highest precision when genes are this number in GSE57691 (C) and GSE57691 (F) datasets. (G) An UpSet diagram exhibited the interaction result of LASSO, RF, and SVM in two AAA datasets. (H) The visualization of ANN. The neural network contains six input layers, three hidden layers, and two output layers. AAA, abdominal aortic aneurysm; ANN, artificial neural network; LASSO, least absolute shrinkage and selection operator; PRGs, pyroptosis-related genes; RF, random forest; SVM, support vector machine.

Diagnostic value, risk stratification, and clinical usefulness of PRG classifier in GEO cohorts. ROC analysis was executed to examine the diagnostic capability of the PRG classifier with AAA as the endpoint in the GSE7084 (A) and GSE57691 (D) datasets. (B and E) The distribution of AAA occurrence in PRG different subgroups in two AAA datasets. (B) GSE7084 datasets; (E) GSE57691 datasets. Decision curve analysis was applied to evaluate the clinical usefulness of PRG classifier in GSE7084 (C) and GSE57691 (F) datasets. The Y-axis represents the net benefit. The black line represents the hypothesis that no patients treatment. The X-axis represents the threshold probability. The threshold probability is where the expected benefit of treatment is equal to the expected benefit of avoiding treatment. Comparison of the PRG scores between small AAA and large AAA in the GSE57691 cohort (G), between eAAA and rAAA in the GSE98278 cohort (H), and between intermediate AAA and large AAA in the GSE98278 cohort (I). The asterisks indicate a significant statistical p value calculated using the Wilcoxon test (⁣∗p < 0.05; ⁣∗∗∗p < 0.001). ROC analyses were conducted to evaluate the ability of the PRG classifier to distinguish small AAA from large AAA in GSE57691 cohort (J), eAAA from rAAA in GSE98278 cohort (K), and intermediate AAA from large AAA in GSE98278 cohort (L), respectively. AAA, abdominal aortic aneurysm; AUC, area under curve; eAAA, elective stable AAA; GEO, gene expression omnibus; PRG, pyroptosis-related gene; rAAA, rupture AAA; ROC, receiver operating characteristic.

Demographic and clinical characteristics of abdominal aortic aneurysm patients.

Correlation of PRG classifier with clinical characteristics in hospital cohort. (A) Comparison of the aneurysm diameter in PRG different subgroups. The asterisks indicate a significant statistical p value calculated using the Wilcoxon test (⁣∗p < 0.05; ⁣∗∗p < 0.01; ⁣∗∗∗p < 0.001). (B) Correlation between PRG score and aneurysm diameter. Correlation coefficient and p value were calculated by Spearman's correlation analysis. (C) The ROC curve was used to evaluate the effectiveness of PRG in diagnosing aneurysm diameter. Comparison of the PRG scores based on different clinical features, including female vs. male (D), smoking history (E), hypertension history (F). Comparison of the diastolic pressure (G) and triglyceride (I) in PRG different subgroups. The asterisks indicate a significant statistical p value calculated using the Wilcoxon test (⁣∗p < 0.05; ⁣∗∗p < 0.01; ⁣∗∗∗p < 0.001). Correlation between PRG score and diastolic pressure (H) and triglyceride (J). Correlation coefficient and p value were calculated by Spearman's correlation analysis. PRG, pyroptosis-related gene; ROC, receiver operating characteristic.

Analyses of immune cell infiltration in AAA and its relationship with hub PRGs/PRG classifier in GSE57691 cohort. Comparison of the immune cell infiltration between normal and AAA groups based on CIBERSORTx (A) and ssGSEA (B) algorithms. (C) Correlation between hub PRGs/PRG classifier and immune cells. AAA, abdominal aortic aneurysm; IL, infiltrating lymphocyte; MDSCs, myeloid-derived suppressor cells; NK, natural killer; PRG, pyroptosis-related gene; ssGSEA, single-sample gene set enrichment analysis; Tfh, T cells follicular helper; TNF, tumor necrosis factor.

Analyses of immune cell infiltration in AAA and its relationship with hub PRGs/PRG classifier in GSE98278 cohort. Comparison of the immune cell infiltration between eAAA and rAAA subgroups based on CIBERSORTx (A) and ssGSEA (B) algorithms. (C) Correlation between hub PRGs/PRG classifier and immune cells. AAA, abdominal aortic aneurysm; eAAA, elective stable AAA; IL, infiltrating lymphocyte; NK, natural killer; PRG, pyroptosis-related gene; rAAA, rupture AAA; ssGSEA, single-sample gene set enrichment analysis; Tfh, T cells follicular helper; TNF, tumor necrosis factor.

Comprehensive analysis of molecular characteristics during AAA and its relationship with hub PRGs/PRG classifier in GSE57691 and GSE98278 datasets. Comparison of predefined biological processes between normal and AAA groups in GSE57691 dataest (A), as well as eAAA and rAAA subgroups in GSE98278 dataset (B) based on ssGSEA algorithm. p value was calculated using the Wilcoxon test. Comparison of KEGG gene sets from Molecular Signatures Database between normal and AAA groups in GSE57691 dataest (C), as well as eAAA and rAAA subgroups in GSE98278 dataset (D) based on gene set variation analysis (GSVA). t value and p value was calculated using the limma R package. The heatmap plot depicted correlation between hub PRGs/PRG classifier and critical biological pathways in GSE57691 (E) and GSE98278 (F) datasets. Correlation coefficient and p value were calculated by Spearman's correlation analysis. The asterisks indicate a statistically significant p value calculated using the Spearman's correlation analysis (⁣∗p < 0.05; ⁣∗∗p < 0.01; ⁣∗∗∗p < 0.001). AAA, abdominal aortic aneurysm; CCR, cytokine–cytokine receptor interaction; eAAA, elective stable AAA; IL, infiltrating lymphocyte; KEGG, Kyoto Encyclopedia of Genes and Genome; PRG, pyroptosis-related gene; rAAA, rupture AAA; ssGSEA, single-sample gene set enrichment analysis; TNF, tumor necrosis factor.

Detection of expression level of the hub PRGs by qRT-PCR, WB, and ELISA as well as construction and validation a miRNA/hub pyroptosis-related molecular regulatory axis. (A) Differential mRNA expression of hub PRGs between AAA patients and control by qRT-PCR. The asterisks indicate a significant statistical p value calculated using the Wilcoxon test (⁣∗p < 0.05; ⁣∗∗p < 0.01; ⁣∗∗∗p < 0.001). (B) The protein expression levels of CASP1, NLRP1, NLRP2, and NLRP3 between AAA patients and control were assessed by WB. Comparison of the protein expression levels of IL1B (C), IL18 (D), IL6 (E), and TNF (F) between AAA patients and control using ELISA detection. The asterisks indicate a significant statistical p value calculated using the Wilcoxon test (⁣∗p < 0.05; ⁣∗∗p < 0.01; ⁣∗∗∗p < 0.001). (G) Comparison of the mRNA expression levels of hsa-miR-331-3p between AAA SMC and control. The asterisks indicate a significant statistical p value calculated using the Wilcoxon test (⁣∗p < 0.05; ⁣∗∗p < 0.01; ⁣∗∗∗p < 0.001). (H) Venn diagrams presents the genes shared by 90 DEmiRNAs target genes and 8 hub PRGs. (I) Measurement of miR-331-3p expression in MOVAS cells transfected with miR-331-3p mimic and NC vectors by RT-qPCR. The asterisks indicate a significant statistical p value calculated using the Wilcoxon test (⁣∗p < 0.05; ⁣∗∗p < 0.01; ⁣∗∗∗p < 0.001). (J) TNF-1 and CASP1 protein level were measured by WB assay in MOVAS cells transfected with miR-331-3p mimic and NC vectors. The asterisks indicate a significant statistical p value calculated using the Wilcoxon test (⁣∗p < 0.05; ⁣∗∗p < 0.01; ⁣∗∗∗p < 0.001). AAA, abdominal aortic aneurysm; DEmiRNAs, differentially expressed microRNAs; ELISA, enzyme-linked immunosorbent assay; IL, infiltrating lymphocyte; NC, negative control; PRG, pyroptosis-related gene; qRT-PCR, quantitative real-time-polymerase chain reaction; TNF, tumor necrosis factor; WB, western blot.

## Section: 3. Results › 3.1. Landscape of Expression Variation in PRGs in AAA

The mRNA expression levels of PRGs between control and AAA groups were examined, revealing that most PRGs exhibited differential expression in the GSE7084 (Figure 1A) and GSE57691 datasets (Figure 1B). ssGSEA results demonstrated that the enrichment scores of pyroptosis were notably increased in the AAA group than in the control group (Figure 1C,D). PCA demonstrated that the expression of these PRGs could effectively differentiate between AAA patients and control patients in both the GSE7084 (Figure 1E) and GSE57691 datasets (Figure 1F). These analyses underscored the pivotal role of PRG expression imbalance in the occurrence of AAA.

Landscape of expression variation in PRGs in AAA. (A and B) Differential expression of PRGs between AAA samples and healthy control patient samples in two GEO datasets. (A) GSE7084 datasets; (B) GSE57691 datasets. The asterisks indicate a significant statistical p value calculated using the Wilcoxon test (⁣∗p < 0.05; ⁣∗∗p < 0.01; ⁣∗∗∗p < 0.001). (C and D) Comparison of PRGs score between AAA samples and healthy control patient samples in two GEO datasets. (C) GSE7084 datasets; (D) GSE57691 datasets. The asterisks indicate a significant statistical p value calculated using the Wilcoxon test (⁣∗p < 0.05; ⁣∗∗p < 0.01; ⁣∗∗∗p < 0.001). (E and F) Principal component analysis for the expression profiles of PRGs to distinguish AAA patients from healthy control patients in two AAA cohorts. (E) GSE7084 datasets; (F) GSE57691 datasets. AAA, abdominal aortic aneurysm; GEO, gene expression omnibus; IL, infiltrating lymphocyte; PCA, principal component analysis; PRGs, pyroptosis-related genes; TNF, tumor necrosis factor.

## Section: 3. Results › 3.2. Identification and Validation of Hub PRGs and Development of a PRG Classifier

To identify hub PRGs during AAA in the training cohort (GSE7084 and GSE57691), the expression data of 33 PRGs were input into multiple machine learning models. The LASSO was utilized to shrink and select candidate PRGs in the GSE7084 (Figure 2A) and GSE57691 datasets (Figure 2D). RF, an ensemble of tree-based classifiers, was constructed, and feature variables were selected by means of a “randomForest” package, employing a minimum error regression tree. IncNodePurity was utilized to rank the importance of variables (Figure 2B,E). SVM was then employed to identify candidate PRGs according to minimum root mean square error (RMSE; Figure 2C,F). By intersecting the results of LASSO, RF, and SVM, eight hub genes (CASP1, IL1B, IL18, IL6, NLRP1, NLRP2, NLRP3, and TNF) were identified, shared by four or more algorithms (Figure 2G). Utilizing these eight hub PRGs, a prognostic model named the PRG classifier was constructed.

Utilizing the expression transformation of eight hub PRGs, an ANN model was built to optimize the weights of each gene. The ANN model contains eight input layers, three hidden layers, and two output layers (Figure 2H). The PRG score was computed by the summation of “GeneExpression” × “NeuralNetworkWeight” for nine hub PRGs. The potential values ranged from 0 to 1, with detailed data available in Supporting Information 3.

Identification of hub PRGs and construction of a PRG classifier based on machine learning algorithms (including LASSO, RF, and SVM, ANN) with fivefold cross-validation. (A and D) Modified LASSO was used to identify candidate PRGs in two AAA datasets. The Y-axis shows mean square error and the X-axis is log (λ). Dotted vertical lines represent minimum and 1 standard error values of λ. The genes selected at minimum standard error values of λ were finally used for further analysis. (A) GSE7084 datasets (N = 3); (D) GSE57691 datasets (N = 17). (B and E) RF was used to select candidate PRGs with in two AAA datasets and ranked important variables by IncNodePurity. (B) GSE7084 datasets; (E) GSE57691 datasets. SVM algorithm was applied to screen candidate PRGs. (C and F) SVM algorithm was applied to screen candidate PRGs. The blue dots indicated the lowest error rate and the highest precision when genes are this number in GSE57691 (C) and GSE57691 (F) datasets. (G) An UpSet diagram exhibited the interaction result of LASSO, RF, and SVM in two AAA datasets. (H) The visualization of ANN. The neural network contains six input layers, three hidden layers, and two output layers. AAA, abdominal aortic aneurysm; ANN, artificial neural network; LASSO, least absolute shrinkage and selection operator; PRGs, pyroptosis-related genes; RF, random forest; SVM, support vector machine.

## Section: 3. Results › 3.3. Diagnostic Value, Risk Stratification, and Clinical Usefulness of PRG Classifier

ROC curves revealed that the PRG classifier exhibited a superior diagnostic capacity, with an area under curve (AUC) of 0.900 in the GSE7084 cohort (Figure 3A) and an AUC of 0.943 in the GSE57691 cohort (Figure 3D). As per the median PRG score, each case was sorted into low or high PRG groups. Individuals in the high-risk group highlighted a considerably elevated AAA incidence relative to the low-risk group (p < 0.001 for χ2 test) in GSE7084 (Figure 3B) and GSE57691 cohorts (Figure 3E). Notably, the DCA chart showed that within the threshold probability range of 0–1.0, the net benefit rate derived from employing the PRG classifier (predictive model) exceeded that obtained by either not intervening in all patients or intervening in all patients in GSE7084 (Figure 3C) and GSE57691 cohorts (Figure 3F).

Furthermore, in the GSE57691 cohort, the PRG score exhibited a considerable increase in large AAA compared to small AAA (p < 0.001, Figure 3G), while in the GSE98278 cohort, it was higher in rAAA than in eAAA (p < 0.001, Figure 3H), and in GSE98278, it was higher in large AAA relative to intermediate AAA (p < 0.05, Figure 3I). The PRG classifier effectively discriminated large AAA from small AAA with an AUC of 0.847 in the GSE57691 datasets (Figure 3J), rAAA from eAAA with an AUC of 0.863 in the GSE98278 datasets (Figure 3K), and large AAA from intermediate AAA with an AUC of 0.750 in the GSE98278 datasets (Figure 3L).

Diagnostic value, risk stratification, and clinical usefulness of PRG classifier in GEO cohorts. ROC analysis was executed to examine the diagnostic capability of the PRG classifier with AAA as the endpoint in the GSE7084 (A) and GSE57691 (D) datasets. (B and E) The distribution of AAA occurrence in PRG different subgroups in two AAA datasets. (B) GSE7084 datasets; (E) GSE57691 datasets. Decision curve analysis was applied to evaluate the clinical usefulness of PRG classifier in GSE7084 (C) and GSE57691 (F) datasets. The Y-axis represents the net benefit. The black line represents the hypothesis that no patients treatment. The X-axis represents the threshold probability. The threshold probability is where the expected benefit of treatment is equal to the expected benefit of avoiding treatment. Comparison of the PRG scores between small AAA and large AAA in the GSE57691 cohort (G), between eAAA and rAAA in the GSE98278 cohort (H), and between intermediate AAA and large AAA in the GSE98278 cohort (I). The asterisks indicate a significant statistical p value calculated using the Wilcoxon test (⁣∗p < 0.05; ⁣∗∗∗p < 0.001). ROC analyses were conducted to evaluate the ability of the PRG classifier to distinguish small AAA from large AAA in GSE57691 cohort (J), eAAA from rAAA in GSE98278 cohort (K), and intermediate AAA from large AAA in GSE98278 cohort (L), respectively. AAA, abdominal aortic aneurysm; AUC, area under curve; eAAA, elective stable AAA; GEO, gene expression omnibus; PRG, pyroptosis-related gene; rAAA, rupture AAA; ROC, receiver operating characteristic.

## Section: 3. Results › 3.4. Clinical Information From the Hospital Cohort: Validation Cohort Analysis

Detailed clinical data of AAA patients included in this research is summarized in Table 1. The differential analysis observed that relative to the low PRG subgroup, patients in the high PRG subgroup indicated larger aneurysm diameter (p < 0.001, Figure 4A), higher triglyceride level (p < 0.01, Figure 4I), higher height (p < 0.05, Supporting Information 4: Figure S1), and heavier weight (p < 0.05, Supporting Information 4: Figure S1). Other clinical indicators, such as diastolic pressure (Figure 4G), age (Supporting Information 4: Figure S1), BMI (Supporting Information 4: Figure S1), systolic pressure (Supporting Information 5: Figure S2), cholesterol (Supporting Information 5: Figure S2), and FBG (Supporting Information 5: Figure S2), did not yield significant statistical differences, but diastolic pressure showed a significant trend. Moreover, correlation analysis demonstrated a substantial positive association between PRG and aneurysm diameter (R = 0.57, p = 0.026; Figure 4B), diastolic pressure (R = 0.3, p = 0.049; Figure 4H), and triglyceride level (R = 0.56, P = 0.028; Figure 4J). Other clinical features were not significantly correlated with PRG (Supporting Information 4: Figure S1 and Supporting Information 5: Figure S2). Furthermore, higher PRG scores were observed in males (p < 0.05, Figure 4D) and hypertensive patients (p < 0.01, Figure 4F), while smokers (p > 0.05, Figure 4E) displayed elevated PRG scores that did not reach statistical significance. The ROC curve confirmed the effectiveness of PRG in diagnosing aneurysm diameter with an AUC of 0.839 (Figure 4C).

Demographic and clinical characteristics of abdominal aortic aneurysm patients.

Correlation of PRG classifier with clinical characteristics in hospital cohort. (A) Comparison of the aneurysm diameter in PRG different subgroups. The asterisks indicate a significant statistical p value calculated using the Wilcoxon test (⁣∗p < 0.05; ⁣∗∗p < 0.01; ⁣∗∗∗p < 0.001). (B) Correlation between PRG score and aneurysm diameter. Correlation coefficient and p value were calculated by Spearman's correlation analysis. (C) The ROC curve was used to evaluate the effectiveness of PRG in diagnosing aneurysm diameter. Comparison of the PRG scores based on different clinical features, including female vs. male (D), smoking history (E), hypertension history (F). Comparison of the diastolic pressure (G) and triglyceride (I) in PRG different subgroups. The asterisks indicate a significant statistical p value calculated using the Wilcoxon test (⁣∗p < 0.05; ⁣∗∗p < 0.01; ⁣∗∗∗p < 0.001). Correlation between PRG score and diastolic pressure (H) and triglyceride (J). Correlation coefficient and p value were calculated by Spearman's correlation analysis. PRG, pyroptosis-related gene; ROC, receiver operating characteristic.

## Section: 3. Results › 3.5. Analyses of Immune Cell Infiltration in AAA and Its Relationship With Hub PRGs/PRG Classifier

To explore the involvement of those key immune cells in the progression of AAA, the composition of immune cells between normal and AAA groups, as well as eAAA and rAAA subgroups, was compared receptively. In GSE57691 cohort, the CIBERSORTx results suggested that relative to the control group, naive CD4 T cells (p = 0.033), T cells follicular helper (Tfh) (p = 0.007), and activated dendritic cells (p = 0.004) were more abundant in AAA group, while memory resting CD4 T cells (p = 0.015), and M2 macrophages (p = 0.041) were more prevalent in control group than in AAA group (Figure 5A). Similar results (activated dendritic cells [p < 0.001], M2 macrophages [p = 0.02]) were also observed in the GSE98278 cohort (eAAA subgroup vs. rAAA subgroup) (Figure 6A).

The ssGSEA results demonstrated that activated dendritic cells (p = 0.007), immature dendritic cells (p = 0.013), Tfh (p = 0.013), and IL (p = 0.01) were relatively richer in AAA group than control subgroup, while macrophages (p = 0.048) were lower in AAA group (Figure 5B). Similar results (activated dendritic cells [p = 0.036], macrophages [p = 0.014]) were also observed in the GSE98278 cohort (eAAA subgroup vs. rAAA subgroup) (Figure 6B).

Moreover, correlation analysis further demonstrated a significant positive association between PRG and activated dendritic cells (p < 0.001), whereas a considerable negative link was found with M2 macrophages (p < 0.05) in the GSE57691 cohort (control vs. AAA) (Figure 5C). Notably, hub PRGs TNF and CASP1 exhibited significant associations with multiple infiltrating immune cells (Figure 5C). These findings were consistent with those observed in the GSE98278 cohort (eAAA subgroup vs. rAAA subgroup) (Figure 6C).

Analyses of immune cell infiltration in AAA and its relationship with hub PRGs/PRG classifier in GSE57691 cohort. Comparison of the immune cell infiltration between normal and AAA groups based on CIBERSORTx (A) and ssGSEA (B) algorithms. (C) Correlation between hub PRGs/PRG classifier and immune cells. AAA, abdominal aortic aneurysm; IL, infiltrating lymphocyte; MDSCs, myeloid-derived suppressor cells; NK, natural killer; PRG, pyroptosis-related gene; ssGSEA, single-sample gene set enrichment analysis; Tfh, T cells follicular helper; TNF, tumor necrosis factor.

Analyses of immune cell infiltration in AAA and its relationship with hub PRGs/PRG classifier in GSE98278 cohort. Comparison of the immune cell infiltration between eAAA and rAAA subgroups based on CIBERSORTx (A) and ssGSEA (B) algorithms. (C) Correlation between hub PRGs/PRG classifier and immune cells. AAA, abdominal aortic aneurysm; eAAA, elective stable AAA; IL, infiltrating lymphocyte; NK, natural killer; PRG, pyroptosis-related gene; rAAA, rupture AAA; ssGSEA, single-sample gene set enrichment analysis; Tfh, T cells follicular helper; TNF, tumor necrosis factor.

## Section: 3. Results › 3.6. Discovery of Potential Mechanisms in the Development and Progression of AAA and Its Relationship With Hub PRGs/PRG Classifier

To explore possible biological pathways between normal and AAA groups, as well as eAAA and rAAA subgroups, ssGSEA and GSVA were executed to examine the enrichment score of predefined biological processes and KEGG gene sets, respectively. As for predefined biological processes, it was revealed that antigen-presenting cells (APCs) costimulation, cytokine–cytokine receptor interaction (CCR), human leukocyte antigen (HLA), T cell costimulation, checkpoint, and major histocompatibility complex (MHC) class I exhibited enrichment in the AAA group than in the control group (Figure 7A). Moreover, CCR, HLA, parainflammation, and Type I interferon (IFN) responses exhibited enrichment in the rAAA subgroup relative to the eAAA subgroup (Figure 7B). In terms of KEGG gene sets, the analysis revealed that compared to the normal group, several KEGG gene sets were primarily involved in the AAA group, including mismatch repair, hematopoietic cell lineage, CCR, adipocytokine signaling pathway, cytosolic deoxyribonucleic acid (DNA) sensing pathway, and tryptophan metabolism (Figure 7C). Furthermore, sulfur metabolism, glycosphingolipid biosynthesis globo series, RIG I like receptor signaling pathway, valine, leucine, and isoleucine degradation, as well as tryptophan metabolism and cytosolic DNA sensing pathway were primarily involved in the rAAA subgroup (Figure 7D).

Furthermore, correlation analysis revealed significant positive associations between PRG and CCR, HLA, tryptophan metabolism, and the cytosolic DNA sensing pathway in the GSE57691 cohort (control vs. AAA) (Figure 7E), as well as in the GSE98278 cohorts (eAAA subgroup vs. rAAA subgroup) (Figure 7F). It is noteworthy that eight hub PRGs were considerably linked to these pivotal molecular pathways, suggesting that pyroptosis may interact with them to mediate the occurrence and development of AAA.

Comprehensive analysis of molecular characteristics during AAA and its relationship with hub PRGs/PRG classifier in GSE57691 and GSE98278 datasets. Comparison of predefined biological processes between normal and AAA groups in GSE57691 dataest (A), as well as eAAA and rAAA subgroups in GSE98278 dataset (B) based on ssGSEA algorithm. p value was calculated using the Wilcoxon test. Comparison of KEGG gene sets from Molecular Signatures Database between normal and AAA groups in GSE57691 dataest (C), as well as eAAA and rAAA subgroups in GSE98278 dataset (D) based on gene set variation analysis (GSVA). t value and p value was calculated using the limma R package. The heatmap plot depicted correlation between hub PRGs/PRG classifier and critical biological pathways in GSE57691 (E) and GSE98278 (F) datasets. Correlation coefficient and p value were calculated by Spearman's correlation analysis. The asterisks indicate a statistically significant p value calculated using the Spearman's correlation analysis (⁣∗p < 0.05; ⁣∗∗p < 0.01; ⁣∗∗∗p < 0.001). AAA, abdominal aortic aneurysm; CCR, cytokine–cytokine receptor interaction; eAAA, elective stable AAA; IL, infiltrating lymphocyte; KEGG, Kyoto Encyclopedia of Genes and Genome; PRG, pyroptosis-related gene; rAAA, rupture AAA; ssGSEA, single-sample gene set enrichment analysis; TNF, tumor necrosis factor.

## Section: 3. Results › 3.7. Validation Expression of the Hub PRGs by qRT-PCR, WB, and ELISA

To further confirm the eight hub PRGs expression levels, qRT-PCR, WB, and ELISA were executed in human AAA and normal specimens. The mRNA expression levels of CASP1, IL1B, IL18, IL6, NLRP1, NLRP2, NLRP3, and TNF were significantly upregulated in AAA than in normal specimens (Figure 8A). WB and ELISA also revealed significant increases in the protein expression levels of CASP1, NLRP1, NLRP2, NLRP3 (Figure 8B), IL1B (Figure 8C), IL18 (Figure 8D), IL6 (Figure 8E), and TNF (Figure 8F) in AAA tissues compared to normal tissues.

Detection of expression level of the hub PRGs by qRT-PCR, WB, and ELISA as well as construction and validation a miRNA/hub pyroptosis-related molecular regulatory axis. (A) Differential mRNA expression of hub PRGs between AAA patients and control by qRT-PCR. The asterisks indicate a significant statistical p value calculated using the Wilcoxon test (⁣∗p < 0.05; ⁣∗∗p < 0.01; ⁣∗∗∗p < 0.001). (B) The protein expression levels of CASP1, NLRP1, NLRP2, and NLRP3 between AAA patients and control were assessed by WB. Comparison of the protein expression levels of IL1B (C), IL18 (D), IL6 (E), and TNF (F) between AAA patients and control using ELISA detection. The asterisks indicate a significant statistical p value calculated using the Wilcoxon test (⁣∗p < 0.05; ⁣∗∗p < 0.01; ⁣∗∗∗p < 0.001). (G) Comparison of the mRNA expression levels of hsa-miR-331-3p between AAA SMC and control. The asterisks indicate a significant statistical p value calculated using the Wilcoxon test (⁣∗p < 0.05; ⁣∗∗p < 0.01; ⁣∗∗∗p < 0.001). (H) Venn diagrams presents the genes shared by 90 DEmiRNAs target genes and 8 hub PRGs. (I) Measurement of miR-331-3p expression in MOVAS cells transfected with miR-331-3p mimic and NC vectors by RT-qPCR. The asterisks indicate a significant statistical p value calculated using the Wilcoxon test (⁣∗p < 0.05; ⁣∗∗p < 0.01; ⁣∗∗∗p < 0.001). (J) TNF-1 and CASP1 protein level were measured by WB assay in MOVAS cells transfected with miR-331-3p mimic and NC vectors. The asterisks indicate a significant statistical p value calculated using the Wilcoxon test (⁣∗p < 0.05; ⁣∗∗p < 0.01; ⁣∗∗∗p < 0.001). AAA, abdominal aortic aneurysm; DEmiRNAs, differentially expressed microRNAs; ELISA, enzyme-linked immunosorbent assay; IL, infiltrating lymphocyte; NC, negative control; PRG, pyroptosis-related gene; qRT-PCR, quantitative real-time-polymerase chain reaction; TNF, tumor necrosis factor; WB, western blot.

## Section: 3. Results › 3.8. Construction of the miRNA/Pyroptosis-Related Molecular Regulatory Axis and Validation In Vitro

Differential expression analysis revealed a total of 90 DEmiRNAs in the GSE62179 dataset, among which hsa-miR-331-3p exhibited significant downregulation in AAA SMC compared to normal specimens (Figure 8G). Furthermore, predictions from the TargetScan database identified 656 mRNAs as potential targets of the 90 DEmiRNAs. By intersecting the target genes of DEmiRNAs with the eight hub PRGs (Figure 8H), only TNF was identified, establishing its corresponding miRNA as hsa-miR-331-3p. Gain-of-function assays were conducted to validate the reliability of the hsa-miR-331-3p/TNF interaction axis in AAA. Given the reduced expression levels of miR-331-3p in AAA, the miR-331-3p mimic and NC were transfected into MOVAS cells. Results indicated an approximately 2.5-fold increasing in miR-331-3p levels in the mimic groups than the NC groups (Figure 8I). Moreover, the protein expression levels of pyroptosis-related molecules (TNF and CASP1) were assessed via WB. The mimic group exhibited lower protein levels of TNF and CASP1 than the NC group (Figure 8J).

## Section: 4. Discussion

The present research integrated datasets of mRNAs (GSE7084, GSE57691, and GSE98278) and miRNAs (GSE62179) to comprehensively investigate the potential implications of PRGs and their upstream miRNA in the formation and rupture of AAA. Utilizing four machine learning algorithms, the PRG classifier was developed, incorporating eight hub PRGs (CASP1, IL1B, IL18, IL6, NLRP1, NLRP2, NLRP3, and TNF). Validation through qRT-PCR, WB, and ELISA experiments confirmed the mRNA and protein expression of these hub PRGs in human AAA samples. The PRG classifier exhibited excellent diagnostic values, clinical decision, and discrimination performance and displayed substantial positive associations with the risk factors of the AAA (hypertension history, diastolic pressure, triglyceride, and aneurysm diameter) in GEO and clinical cohorts. Moreover, PRG classifier/PRGs showed significant correlations with M2 macrophage infiltration, dendritic cell activation, cytosolic DNA sensing pathway, and tryptophan metabolism, suggesting their potential roles in mediating AAA occurrence and rupture. Importantly, this study elucidated a hsa-miR-331-3p/TNF regulatory axis, demonstrating that overexpression of miR-331-3p led to a considerable downregulation of TNF and CASP1 protein levels. These outcomes offer novel insights into the potential pathological mechanisms underlying AAA formation and rupture, shedding light on the roles of pyroptosis and miRNA in AAA pathogenesis, along with their potential clinical implications.

Pyroptosis, recognized as an inflammatory type of programed cell death, has become a central area of research focus. Its crucial involvement has been noted across various domains, including infectious diseases, tumor immunity, neurological diseases, and cardiovascular diseases [25]. Recently, increasing research has demonstrated that pyroptosis (such as, NLRP3, Caspase-1, GSDMD) mediates the formation of AAA by leading to the loss of VSMC [11, 12]. Nonetheless, the potential roles of pyroptosis molecules, such as NLRP1, NLRP2, TNF, and so on, in AAA are still largely unknown. The present study collected 33 PRGs and comprehensively evaluated their expression pattern, biological functions, and clinical application in the formation and development of AAA. Interestingly, preliminary explorations revealed a predominant upregulation of PRGs in AAA, along with a considerable enrichment of the pyroptosis pathway. Furthermore, the distinct expression patterns of these PRGs allowed for the complete differentiation of AAA patients from control subjects. These findings underscore the pivotal role of dysregulated PRG expression in the onset of AAA. Considering these results, there has been a strong interest in an in-depth understanding of pyroptosis molecules in AAA. Crucially, the specific miRNAs involved in regulating pyroptosis in AAA have yet to be elucidated. To our knowledge, this research represents the first comprehensive investigation into pyroptosis-related molecules across multiple AAA transcriptomes, combined with a clinical cohort analysis. Leveraging a combination of four machine learning approaches, this study aimed to identify and validate novel biomarkers and predictive models with potential clinical significance. It elucidated the crosstalk between pyroptosis and immune cell infiltration, molecular pathways, and upstream miRNA to provide new insight into AAA formation and rupture.

In recent years, machine learning techniques have gained prominence as a novel approach for analyzing large-scale medical data [26], capturing nonlinear relationships, and extracting nuanced information from continuous variables, thereby facilitating the identification of critical factors and improving prediction accuracy. This capability is lacking in traditional predictive models based on Cox or logistic regression analysis in AAA [27]. Recently, Fu et al. [28] applied RF and SVM to construct models based on m6A RNA methylation regulators, respectively. However, their approach lacked the meticulous screening of feature variables, optimization of model coefficients, and external verification of models. This study applied a more rigorous variable selection approach, incorporating LASSO, RF, and SVM in two GEO cohorts to identify the most relevant predictors to construct a model in order to avoid data leakage and overfitting. This research introduced ANN to optimize the weight of variables in AAA, which is a methodology previously used in tumor prediction models to improve predictive power [29]. This strategy enables precise quantification for individual AAA patients, thereby enhancing the predictive performance and generalizability of the model and facilitating tailored treatment strategies.

By integrating multiple machine learning approaches, eight key PRGs were identified, which were used to develop a PRG classifier. The findings from qRT-PCR, WB, and ELISA experiments confirmed that the mRNA and protein expression levels of the hub PRGs (CASP1, IL1B, IL18, IL6, NLRP1, NLRP2, NLRP3, and TNF) were considerably upregulated in human AAA samples compared to normal samples. These results align with several observational studies that have reported elevated mRNA expression levels of NLRP3, Caspase-1, and IL-1β in circulating leukocytes of AAA patients in contrast to non-AAA patients [11, 30]. The PRG classifier exhibited outstanding predictive performance with AUC exceeding 0.90 in both GEO datasets. Moreover, it effectively differentiated between large and small AAA, as well as between rAAA and eAAA, along with distinguishing between large and intermediate AAA. DCA results demonstrated that treatment decisions based on the PRG classifier yielded greater net benefits than those based on the approach of treating either all patients or none. This suggests that the PRG classifier holds promise for diagnosing AAA, assessing its severity, and informing clinical decision-making. Commonly recognized risk factors for AAA encompass male gender, age over 65, smoking, hypertension, and dyslipidemia [31]. In the clinical cohorts, individuals in the high PRG subgroup exhibited a trend toward larger aneurysm diameter, higher triglyceride levels, greater height, increased weight, and elevated diastolic pressure, although these differences did not reach statistical significance. Moreover, elevated PRG scores were observed in male and hypertensive patients, while smokers tended to exhibit higher PRG scores, although this trend did not reach statistical significance. These negative results are attributed to the small sample size and need to be explored in a large multicenter cohort. Taken together, the present PRG classifier could serve as an effective tool for the diagnosis and determination of risk stratification in AAA. The superior performance of the model in this study can be attributed to several factors. First, the effective combination of multiple biological markers proved more effective than relying on a single biomarker alone. Second, considering the inherent heterogeneity of AAA, machine learning techniques coupled with transcriptomics allow for a comprehensive understanding and management of disease heterogeneity. Lastly, the selection of biomarkers from a pathophysiological standpoint enhances the predictive power of the model, ensuring its clinical relevance and applicability.

The pathophysiological processes of AAA encompass inflammatory cell infiltration, degradation of elastic and collagen fibers, heightened oxidative stress, arterial wall defects, and death of smooth muscle cells (SMCs) [32]. In the initial phases of the disease, immune cells like lymphocytes, macrophages, neutrophils, and natural killer (NK) cells infiltrate and accumulate in the blood vessels and surrounding tissues. This leads to a cascade of inflammatory responses within the vascular wall, diminishing its stability and ultimately triggering VSMC death [32]. In this study, during AAA formation and rupture, a considerable elevation in dendritic cell activation and a notable decrease in M2 macrophage infiltration were observed. As AAA progresses, M1 macrophages instigate chronic inflammation, hindering the repair of the injured aorta. Conversely, M2 macrophage polarization diminishes inflammation, facilitating wound healing and leading to the downregulation of M1 macrophages [33]. In the Ang II-induced AAA mouse model, the chemokine C–C motif ligand has been observed to contribute to AAA development and pathogenesis by facilitating the polarization of macrophages from M2 to M1 [34]. These findings align with our study, which suggests that the reduced infiltration of M2 macrophages might play a role in the formation and rupture of AAA. However, the impact of dendritic cell activation on AAA remains relatively understudied compared to other immune cell types. Yan et al. [35] demonstrated that in the aneurysmal process, DNA–cathelicidin-related antimicrobial peptide (CRAMP) complexes released along with neutrophil extracellular traps (NETs) could potentially be internalized by dendritic cells. This uptake may trigger dendritic cell activation, leading to the production of type I IFN and instigating inflammatory responses. Notably, their study showed that depletion of dendritic cells abolished T cell recruitment and activation, matrix metalloproteinases activity, and ultimately hindered aneurysm development. These findings strongly suggest that NET-dependent priming of dendritic cell activation is essential for AAA formation in their model. Notably, this study revealed a notable correlation between the PRG classifier/hub PRGs and M2 macrophage infiltration, as well as dendritic cell activation. This suggests that the interplay between pyroptosis and these immune processes might be involved in the onset and rupture of AAA. Currently, the precise mechanisms underlying how pyroptosis interacts with macrophage polarization and dendritic cell activation to lead to AAA formation and rupture remain elusive. Further investigation in this direction is warranted to unveil new therapeutic avenues for treating AAA.

ssGSEA and GSVA functional enrichment analyses were performed to elucidate the underlying biological mechanisms of AAA. The ssGSEA results revealed that immune and inflammation-related pathways (CCR, HLA, T cell costimulation, parainflammation, and Type I IFN response) were predominantly enriched in AAA formation and rupture, consistent with previous studies [36]. Furthermore, GSVA results utilizing KEGG gene sets revealed significant involvement of tryptophan metabolism and the cytosolic DNA sensing pathway in the formation and rupture of AAA. Tryptophan, as an essential amino acid, is critically involved in protein synthesis, thereby contributing to normal cellular homeostasis. Growing evidence suggests that dysregulated tryptophan metabolism contributes to aortic inflammation and aortic disease phenotypes [37]. In studies utilizing both apolipoprotein e (Apoe–/–) and indoleamine 2,3-dioxygenase (IDO) (/IDO–/–) AAA mice models, researchers established a causative relationship between aberrant tryptophan metabolism and AAA. Specifically, 3-HAA, a metabolite of tryptophan, activated the nuclear factor-kB transcription factor, resulting in the upregulation of matrix metallopeptidase 2 expression in VSMCs, thereby promoting the formation of AAA [38]. Cytosolic DNA sensors constitute a group of pattern recognition receptors (PRRs) with a shared function of detecting intracellular microbial DNA, thus initiating the innate immune response. These sensors have been shown to be pivotal in various biological processes, including microbial infection, chronic inflammation, cancer progression, and organ degeneration. They represent a promising area of investigation for elucidating the underlying mechanisms of multiple disease pathogenesis [39]. Nonetheless, the involvement of the cytosolic DNA sensing pathway in AAA formation and rupture is nascent. A recent investigation revealed a substantial increase in DNA damage and the activation of the cytosolic DNA sensing adaptor STING (stimulator of IFN genes) signaling pathway in aortic tissues obtained from patients diagnosed with sporadic thoracic aortic aneurysm and dissection [40]. Crucially, this study uncovered a significant association between the PRG classifier/hub PRGs and the tryptophan metabolism and cytosolic DNA sensing pathway. This suggests that pyroptosis and their interplay could potentially drive the onset and rupture of AAA. At present, the specific mechanism underlying AAA formation and rupture mediated by the interaction between pyroptosis and pathways such as tryptophan metabolism and the cytosolic DNA sensing pathway remains unclear. Further research in this direction is imperative to unveil novel strategies for the treatment of AAA.

One significant discovery of this study was the identification of the miR-331-3p/TNF regulatory axis, which holds promise as a novel therapeutic target for AAA. TNF, known for its inflammatory properties, is recognized for its pivotal role in linking various types of programed cell death due to its intricate signaling pathways [41]. TNF exerts complex cell death signaling by interacting with TNF receptor 1 [42], leading to diverse outcomes such as apoptosis, pyroptosis, and necroptosis, depending on the assembly of TNF complexes (TNF Complex IIa, IIb, and IIc). Previous research has shown that inhibiting TNF-α can impede AAA progression by diminishing the expression of pro-inflammatory cytokines and adhesion molecules, thereby restricting macrophage infiltration [43]. In our study, TNF, identified as a pyroptosis-related molecule, exhibited significantly increased mRNA expression and protein levels across two GEO datasets and clinical cohorts. Elevated TNF expression showed a significant positive correlation with dendritic cell activation and the cytosolic DNA sensing pathway. The regulatory role of its upstream miRNA in the regulation of AAA pyroptosis is yet to be elucidated. Based on 90 DEmiRNAs and eight hub PRGs in AAA through the TargetScan dataset, a hsa-miR-331-3p/TNF regulatory axis was constructed. miR-331-3p, a member of the miR-331 family, is situated on chromosome 12q22 and has predominantly been studied in the context of cancer research. miR-331-3p has been implicated in regulating cellular progression in multiple cancer types, encompassing hepatocellular carcinoma, prostate cancer, and non-small cell lung cancer (NSCLC) [44–46]. The increased expression of miR-331-3p has been shown to eliminate the tumor-suppressing function of circRASSF5 and sponge 3′UTR of PHLPP and enhance the protein level of PHLPP, ultimately leading to the promotion of HCC cell growth [44]. miR-331-3p has been proven to be a promoting tumor regulator in prostate cancer, which acts as a mediator of ErbB-2 expression and PI3K/AKT signaling [45]. Moreover, miR-331-3p overexpression has been shown to counteract the inhibitory effect of AC005332.7 on ferroptosis in OGD-induced AC16 cells, exacerbating cardiomyocyte injury in acute myocardial infarction [47]. In this study, a notable upregulation of hsa-miR-331-3p expression was observed in AAA SMCs relative to normal specimens. However, the regulatory impact of miR-331-3p on AAA pyroptosis remained unclear. Through loss-of-function assays conducted in vitro using MOVAS cells, it was observed that increasing miR-331-3p expression led to a substantial reduction in the protein levels of TNF and CASP1. These outcomes highlight that miR-331-3p might alleviate AAA pyroptosis and could potentially serve as a novel therapeutic target for AAA treatment.

In comparison to earlier studies, this research introduces several distinctive features. First, a comprehensive assessment and validation of the expression patterns, biological functions, and clinical relevance of 33 PRGs in both GEO datasets and clinical cohorts were conducted, shedding light on their involvement in AAA formation and progression. Second, a novel approach was employed by integrating four machine learning techniques (LASSO, RF, SVM, and ANN) in two independent AAA GEO cohorts. This facilitated the identification of robust hub genes and optimization of model coefficients, ultimately enhancing the predictive performance of the models. Third, the study uncovered the intricate crosstalk between pyroptosis and key biological pathways such as macrophage polarization, dendritic cell activation, tryptophan metabolism, and the cytosolic DNA sensing pathway, offering new insights into the mechanisms underlying AAA pathogenesis. Lastly, the regulatory axis of hsa-miR-331-3p/TNF was elucidated and validated, potentially opening up new avenues for AAA treatment and deepening our comprehension of its pathogenesis. Despite the considerable outcomes, this research also has limitations. First, the small sample size in both the GEO and clinical cohorts suggests that the generalizability of the model needs to be verified in larger prospective cohorts. Second, while various algorithms and datasets were employed to validate the findings, methods like CIBERSORTx deconvolution, ssGSEA, and GSVA with metagenes may not accurately assess immune cell subpopulations and biological pathways. Future studies could benefit from single-cell RNA-Seq methods or fluorescence-activated cell sorting for more precise evaluations. Lastly, additional in vitro and in vivo investigations are warranted to elucidate the molecular mechanism and confirm the role of miR-331-3p in regulating AAA pyroptosis.

## Section: 5. Conclusion

Utilizing eight PRGs identified through four machine learning algorithms, a PRG classifier was developed and clinically validated for potential diagnosing and assessing the severity of AAA. Furthermore, the identification of the cytosolic DNA sensing pathway and the hsa-miR-331-3p/TNF regulation axis could represent crucial targets for AAA treatment, offering insights into the underlying pathogenesis of the disease.

## Section: Acknowledgments

We thank Bullet Edits Limited for the linguistic editing and proofreading of the manuscript.

## Section: Data Availability Statement

The original data presented in the study are included in the article/supporting information. Further inquiries can be directed to the corresponding author. The codes underlying this article are available in GitHub at https://github.com/GenglongLiu/AAA-codes.

## Section: Ethics Statement

The studies involving human samples were reviewed and approved by the Research Ethics Committee of Third People's Hospital of Hainan Province and complied with the Declaration of Helsinki (No. 2023-10-22). Prior to sample and data collection, written informed consent was obtained from the relatives of eligible patients.

## Section: Consent

The authors have nothing to report.

## Section: Conflicts of Interest

The authors declare no conflicts of interest.

## Section: Author Contributions

Yongchao Su and Shuchen Chen conceived and designed the study. Yongchao Su, Chuangang Lu, and Shuchen Chen drafted the manuscript. Yongchao Su and Shuchen Chen analyzed and interpreted all the data. Yongchao Su and Shuchen Chen prepared the figures and tables. Yongchao Su, Chuangang Lu, and Shuchen Chen reviewed and revised the manuscript. All authors have read and approved the manuscript for publication.

## Section: Funding

The authors received no specific funding for this work.

## Section: Supporting Information

Additional supporting information can be found online in the Supporting Information section.

Thirty-three pyroptosis-related genes (PRGs) were compiled from published studies.

Gene-specific polymerase chain reaction (PCR) primers are provided in the present study.

Detailed PRG scores are provided for the GSE7084 and GSE57691 datasets.

Figure S1. Correlation of PRG classifier with clinical characteristics in hospital cohort.

Figure S2. Correlation of PRG classifier with clinical characteristics in hospital cohort.

## Section: Associated Data

Thirty-three pyroptosis-related genes (PRGs) were compiled from published studies.

Gene-specific polymerase chain reaction (PCR) primers are provided in the present study.

Detailed PRG scores are provided for the GSE7084 and GSE57691 datasets.

Figure S1. Correlation of PRG classifier with clinical characteristics in hospital cohort.

Figure S2. Correlation of PRG classifier with clinical characteristics in hospital cohort.

## Section: Associated Data › Supplementary Materials

Thirty-three pyroptosis-related genes (PRGs) were compiled from published studies.

Gene-specific polymerase chain reaction (PCR) primers are provided in the present study.

Detailed PRG scores are provided for the GSE7084 and GSE57691 datasets.

Figure S1. Correlation of PRG classifier with clinical characteristics in hospital cohort.

Figure S2. Correlation of PRG classifier with clinical characteristics in hospital cohort.

## Section: Associated Data › Data Availability Statement

The original data presented in the study are included in the article/supporting information. Further inquiries can be directed to the corresponding author. The codes underlying this article are available in GitHub at https://github.com/GenglongLiu/AAA-codes.


---

# Coupling quantitative systems pharmacology modelling to machine learning and artificial intelligence for drug development: its pAIns and gAIns

- **Authors:** Núria Folguera-Blasco, Florencia A T Boshier, Aydar Uatay, Cesar Pichardo-Almarza, Massimo Lai, Jacopo Biasetti, Richard Dearden, Megan Gibbs, Holly Kimko
- **Issuer:** Frontiers in systems biology
- **Type:** Scientific article
- **Published:** 2024-07-12
- **Language:** en
- **DOI:** 10.3389/fsysb.2024.1380685
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40809115/
- **Licence:** CC-BY

## Section: Abstract

AbstractQuantitative Systems Pharmacology (QSP) has become a powerful tool in the drug development landscape. To facilitate its continued implementation and to further enhance its applicability, a symbiotic approach in which QSP is combined with artificial intelligence (AI) and machine learning (ML) seems key. This manuscript presents four case examples where the application of a symbiotic approach could unlock new insights from multidimensional data, including real-world data, potentially leading to breakthroughs in drug development. Besides the remarkable benefits (gAIns) that the symbiosis can offer, it does also carry potential challenges (pAIns) such as how to assess and quantify uncertainty, bias and error. Hence, to ensure a successful implementation, arising pAIns need to be acknowledged and carefully addressed. Successful implementation of the symbiotic QSP and ML/AI approach has the potential to serve as a catalyst, paving the way for a paradigm shift in drug development.Keywords: quantitative systems pharmacology (QSP), machine learning (ML), artificial intelligence (AI), drug development, real world data (RWD), mathematical modelling, data heterogeneity, precision medicine

## Section: Introduction

Mathematical modelling of biological processes has traditionally been performed by integrating observations from in-house experiments and/or published literature; understanding the physiological/pathological/pharmacological mechanisms of action; and, under simplifying assumptions, translating such processes into equations that can represent the observed dynamics. Due to their mechanistic underpinnings, these models do not necessitate extensive datasets for development: they leverage scientific knowledge of the underlying processes, as opposed to being data-driven. Moreover, they can be used to fill in a gap when data is lacking or scarce, as they provide a means to test hypotheses in a less costly manner. Once built, model exploration can predict how biological systems will behave under distinct conditions, characterising mechanisms not observed experimentally. The pharmaceutical industry has been using mathematical modelling to support many phases of drug development, and nowadays, Quantitative Systems Pharmacology (QSP) modelling has become a popular approach in multiple facets: helping to make go/no-go decisions for drug development investment, finding optimal doses and dosing schedules for monotherapies and/or combination therapies, providing valuable input in regulatory decisions, and so forth (Azer et al., 2021; Jane et al., 2021; Verma et al., 2023).

QSP model development requires a lot of time and effort commitment as it involves extensive literature curation and a deep understanding of the underlying biology/pharmacology, normally spanning multiple scales, which also challenges data integration during its validation. However, novel approaches based on machine learning (ML) and artificial intelligence (AI) are expected to facilitate such a process. ML/AI-based models, normally used for rich/large datasets, apply relevant algorithms to learn/identify patterns in the data. By exhaustively exploring such comprehensive datasets, even in the absence of a priori mechanistic knowledge—a requisite for QSP approaches—ML/AI may narrow down plausible mechanistic options which can then be further validated by a QSP model. This process holds significant potential for uncovering the mechanisms behind unreported phenomena, such as emerging side effects associated with novel therapies.

Therefore, current efforts are focused on creating a mutualistic symbiosis between the QSP and ML/AI fields [see (Procopio et al., 2023) for some examples], aiming to achieve improved overall results, more informative than either approach alone. Since QSP and ML/AI have different data requirements and data-integration capacities, their symbiotic relationship can consist in: (i) consecutive application, where one approach tackles a specific stage, and the (partial) results are used by the other methodology, or (ii) simultaneous application, where both approaches work together on the same data. In the consecutive case, a ML/AI approach followed by QSP could yield mechanism discovery when mechanistic knowledge is lacking, whilst using a QSP model first could help to improve performance accuracy of ML/AI algorithms, by generating training data. When applying QSP and ML/AI simultaneously, researchers can leverage the strengths of each method to integrate diverse data sources. This is particularly beneficial because a single approach might not be able to handle all the data types (e.g., imaging data, quantitative and/or qualitative data), but the combined approach can utilise the full potential of this rich data landscape.

This paper shows current cases being explored at AstraZeneca that highlight the prospective benefits (gAIns) of combined QSP-ML/AI approaches, followed by a discussion around some of the concerns (pAIns) that this symbiosis may bring (Figure 1). At the current early stage of this collaboration, the balance between gAIns and pAIns seems to be tilted towards the former. However, acknowledging and addressing the pAIns will ensure that the ML/AI and QSP symbiosis becomes truly a beneficial one.

Major gAIns and pAIns arising from the QSP and ML/AI symbiotic implementation (contextualised with examples discussed).

## Section: gAIns of combined QSP-ML/AI approaches

This section describes 4 case examples which highlight how the QSP and ML/AI symbiotic approach presents an advantage versus using just one single methodology. The scenarios described have been selected to span a wide spectrum in the drug research landscape, ranging from implications at the cellular level to clinical stages (Figure 2). Therefore, the symbiotic approach may have significance both for patients and for pharmaceutical industries, as it may help designing better disease treatments, and ultimately, improve patients’ quality of life.

Schematic representation of how the symbiotic QSP and ML/AI approach can help the pharmacological healthcare continuum (drug discovery, drug development, disease diagnosis, and clinical management). PKPD, pharmacokinetics and pharmacodynamics.

## Section: gAIns of combined QSP-ML/AI approaches › Cellular level: multi-omics data integration

Omics data capture multiple facets of cell signalling, including gene transcription (transcriptomics), translation (proteomics), and metabolism (metabolomics). Technological advancements have led to a remarkable accumulation of these data, which has spurred the development of ML methods for processing each data layer (Li and Li, 2018; Liebal et al., 2020; Neely et al., 2023). Despite the advances in ML and QSP methods, it is challenging to leverage omics data in QSP modelling (Zhang et al., 2022; Uatay et al., 2023). These challenges include both technological (e.g., scarcity of information on kinetic aspects of cell signalling) and methodological (e.g., how to interpret multi-layered data) limitations.

Combined ML and QSP approaches often involve dimensionality reduction (e.g., principal component analysis) and identification of enriched genes (or proteins, metabolites), which are overlayed on pre-built signalling networks or used to construct a model of the relevant pathways (Zhang et al., 2022). Some of the limitations of this approach are due to the static nature of the data (only a snapshot of cellular signalling is captured) and/or limited (if not absent) utilisation of complementary information, which integrated analysis of several layers of omics data can provide. Since QSP describes dynamics across multiple layers of cell signalling simultaneously (transcription, translation, and metabolism are interlinked processes), advances in ML methods capable of extracting real time-course information about these processes [as opposed to latent-time approaches (Bergen et al., 2021)] may provide a new impetus for the development of the QSP field. While latent-time approaches can infer kinetics of gene expression on a (relative) timescale determined by a given (single cell RNA-seq) dataset, such data is not directly compatible with pharmacokinetics data—a critical input for QSP. Therefore, inference of cell-signalling dynamics on an absolute timescale may facilitate integration of molecular scale processes into a QSP model.

In the last years, numerous methods, including ML-based ones, have been developed to integrate multiple omics layers to generate mechanistic hypotheses about the overall state of cell signalling (Garrido-Rodriguez et al., 2022). However, the development of such ML methods for multi-omics integration is challenging due to limited data availability and incomplete knowledge about “ground truth.” Nonetheless, incorporation of prior knowledge can facilitate reconstruction of the (perturbed) signalling network and can potentially enhance the predictive power (Dugourd et al., 2021). As QSP integrates prior knowledge with contextual data (e.g., disease, efficacy, and safety) in a quantitative and mechanistic manner, which can then be used to generate synthetic but realistic training data for ML models, there is a synergistic potential between QSP and ML-based methods for multi-omics analysis. Such synergy may become especially useful in ML models such as deep neural networks (e.g., via a framework provided by physics/biology-informed neural networks), where incorporating prior knowledge is particularly challenging.

Recently, an ML approach was developed to model the dynamics of gene regulatory networks during haematopoiesis by leveraging technological advancements in single-cell RNA-seq (scRNA-seq) (Qiu et al., 2022). Such a work showcased how technological (ability to resolve temporal aspects of transcription) and methodological (ML/modelling) advancements facilitated overcoming one of the limitations of scRNA-seq—i.e., lack of temporal information. Combining this methodology with a QSP model to characterise the effect of drug- or disease-induced perturbation could be an excellent example of ML/AI-powered gAIn for QSP because the ML approach is unbiased, comprehensive, and amenable to mechanistic modelling via traditional QSP tools such as ODEs.

Advances in single-cell omics technologies also include inferences of spatially resolved information (Alexandrov et al., 2023). Development of ML/AI methods to process spatiotemporal aspects of cell signalling, as well as different omics layers, has the potential to enhance QSP predictions by removing key limitations (e.g., snapshot of a regulatory network and/or a single signalling layer) of omics-powered modelling and/or by improving accuracy via an additional layer of validation of the predictions. One such method might involve combining AI-powered cell segmentation on tissue slices with mass spectrometry imaging, which may ease single-cell level omics analysis, and facilitate its utilisation in QSP models.

## Section: gAIns of combined QSP-ML/AI approaches › Tissue level: quantification of imaging data for QSP modelling

Biological samples are extremely valuable in R&D departments, as they provide a means to better understand disease and assess therapy efficacy or safety. However, those samples tend to be scarce, might involve invasive treatments for patients and incur high costs. Therefore, to gain the most insights, it is needed to optimise both what information to be extracted from those samples and the timing of their collection.

Complex image segmentation tasks for the analysis of pathology images rely on advanced deep learning algorithms, where deep convolutional neural networks (CNNs) excel at learning and extracting intricate cellular patterns. The usefulness of processing pathology images by CNNs lies in its ability to consistently, efficiently, and precisely distinguish among different cell types under a variety of imaging conditions, such as staining density and illumination variability (Hosny et al., 2018). Additionally, the segmented images are perfectly suited for the derivation of quantitative measurements essential for downstream QSP models. Such quantification could be done manually, but AI has been proven successful in outperforming hand-crafted techniques. Furthermore, such a pipeline can generate much larger volumes of data than manual approaches, which allows AI to optimise QSP model parameters to best match the imaging data, as well as permit QSP models to be validated on very large imaging datasets.

A clear application of such a tool is in the development of a stem cell therapy for heart failure, where human ventricular progenitor cells are injected into infarcted myocardial tissue with the aim of regenerating the damaged muscle (Timmer and van Rooij, 2002; Foo et al., 2018; Poch et al., 2022). A key step in the development of this therapy is the reliable quantification of ventricular progenitor cell engraftment, i.e., how many cells are retained in the injured myocardium and connect with the host tissue. Moreover, given the limitation in the quantity of longitudinal data points that can be collected, a QSP model of host-graft tissue evolution is needed to predict efficacy and safety of the therapy.

Thus, to support therapy development, an imaging-driven systems model of host-graft tissue evolution can be developed. First, slices of cardiac tissue from preclinical studies are stained and digitised. The images then need to be labelled at the cellular level by an expert to allow cell segmentation and identification. Such labels should be used to train a ML model to detect host and graft cells based on their shape and stain colour. Since individual cell labelling is very time consuming, methods to fine-tune existing models [e.g., able to identify more cell types or capable of using the labels of the whole image for training (Mokhtari et al., 2023)] hold great promise. The use of such a ML model on newly generated pathology images provides a means to reliably obtain data on tissue cellular composition and its spatial characterisation (e.g., tissue size, shape, relative position). Such data is then used for subsequent QSP modelling of tissue evolution.

The described AI-based pipeline for data extraction from cardiac pathology images shows the relevance of obtaining quantifiable measurements, which can then be integrated in QSP approaches, to understand complex cardiac behaviours. More generally, this case example highlights the key role that an integrated approach may play in the development of predictive models for cell therapy strategies, as it may provide additional insights which can inform optimal times for future sample collection.

## Section: gAIns of combined QSP-ML/AI approaches › Clinical level: modelling heterogeneous data types

Continuous progresses in ML/AI tools are easing the use of real-world data, which holds promising potential to unveil relevant information for treatment discovery and development. Despite such technical advances, the use of clinical data is not straightforward. Clinical data is highly heterogeneous as it encompasses, among other data types, patient’s clinical records (e.g., demographics, family health history, previous diagnoses, medications, patient-reported outcome measures) and biomarker/imaging data (e.g., genetic sequences, lab chemistry results, X-rays, CT scans). The difficulty in integrating such data is well exemplified when trying to connect qualitative clinical endpoints (e.g., symptoms, functional status, or disease severity) to quantitative measurements (e.g., blood cell count time-series). Current efforts are focused on trying to draw a link between such data, aiming to obtain some (mechanistic) understanding of clinical response to treatment.

For complex biological therapies such as those involving T-cell engagers, predicting potential side effects, like cytokine release syndrome (CRS), remains a challenge. While QSP models can effectively predict continuous quantitative biomarkers (e.g., cytokines), their limited understanding of CRS mechanisms often hinders their ability to directly predict such a critical outcome (presence/absence of CRS and its severity grade). This is where a symbiotic QSP and ML/AI approach may provide a reasonable bridging strategy; by harnessing the power of real-world data, ML/AI approaches can fill the knowledge gap in CRS prediction by revealing the relationship between patient features and CRS incidence. A QSP model, although unable to predict CRS by itself, can provide quantitative data, such as predicted biomarker levels based on estimated T-cell engager trimer exposure (e.g., longitudinal IL-6 profiles) (Chen et al., 2019; Hosseini et al., 2020; Weddell, 2023). Quantitative predictions from the QSP model can then be fed into a ML/AI-driven risk prediction model built from real-world patient clinical characteristics and CRS observations, to establish a predictive model for CRS risk. This integrated approach holds significant promise for improving patient safety and optimising treatment regimens (Irons et al., 2023).

## Section: gAIns of combined QSP-ML/AI approaches › Bench-to-bed translation: from drug development to precision medicine

To progress towards better disease understanding and treatment, untangling disease intricacies is a requisite, for which QSP modelling may become helpful, as it allows to simulate different hypothetical scenarios. The increased understanding can help in identifying novel therapeutic mechanisms/targets. Once identified, the targets can then be leveraged by ML/AI algorithms to design effective diagnostics, optimise clinical trials, and personalise treatment regimens. Therefore, a symbiotic QSP and ML/AI approach may offer a powerful engine for personalised healthcare, spanning from drug development to precision medicine implementation. To exemplify this, an outline on how such a combined approach could comprehensively help in the research and treatment of Alzheimer’s disease (AD) is presented (see Figure 2 for a graphical representation).

## Section: gAIns of combined QSP-ML/AI approaches › Bench-to-bed translation: from drug development to precision medicine › Drug discovery and development

QSP and AI approaches have both been used for AD drug development. For example, an AD progression mechanistic model to capture the complex interplay between amyloid aggregation, pharmacokinetics, and biomarker dynamics has been developed (Geerts et al., 2023). The QSP model supported clinical trial design, helping to define optimal schedules based on understanding biomarker response variability. On the ML/AI side, AI-powered algorithms have been used to analyse patient data to both identify the most promising drug targets and predict how patients will respond to different treatments (Myszczynska et al., 2020), which may facilitate decisions on subject enrolment criteria to improve the probability of success in clinical studies. Therefore, the QSP and AI/ML symbiotic approach can help to understand and compare the efficacy/safety of drug candidates addressing different targets by analysing the dynamics of relevant biomarkers and incorporating the inherent heterogeneity observed in AD patients.

## Section: gAIns of combined QSP-ML/AI approaches › Bench-to-bed translation: from drug development to precision medicine › Disease diagnosis

AI-powered algorithms can analyse brain imaging data to detect AD earlier and more accurately than traditional methods can, reaching 99% accuracy levels (Odusami et al., 2021). They can also be used to understand face recognition deficits (Singh and Ramanathan, 2023). Face recognition datasets can be used to train AI models, whose recognition accuracy decreases as they are perturbed to emulate brain tissue dysfunction. Such results indicate that, despite neural networks not being an exact representation of biological neuronal activity, an AI framework could potentially mimic the loss of cognitive function in AD patients. However, such AI-based models did not include time as an explicit predictor, which makes them unable to capture disease progression. To fill in this gap, QSP models can be used (Bloomingdale et al., 2022), as they allow to estimate the temporal evolution of AD biomarkers (e.g., Aβ42, sAPP, tau) (Clausznitzer et al., 2018; Geerts et al., 2018; Rollo et al., 2023) and clinical endpoints (e.g., integrated Alzheimer’s Disease Rating Scale, iADRS) (Gueorguieva et al., 2023). Therefore, the combined QSP-ML/AI modelling approach may open new opportunities to diagnose and study cognitive function in AD patients.

## Section: gAIns of combined QSP-ML/AI approaches › Bench-to-bed translation: from drug development to precision medicine › Clinical management

AI-powered devices can offer support and companionship to patients (e.g., chatbots), as well as help caregivers track their patients and identify potential problems (e.g., monitoring systems). Physicians are often required to make treatment decisions based on limited objective information (e.g., biopsy or imaging) about individual patient’s disease status. A computational digital twin platform integrating a mechanistic model of disease with a responder classifier to predict temporal changes in the organ of interest (Venkatapurapu et al., 2022) could help treatment guidance, by providing valuable information (e.g., temporal) about disease progression, drug efficacy and potential adverse effects.

## Section: pAIns of combined QSP-ML/AI approaches

As showcased above, there are several opportunities to combine QSP and ML/AI to address meaningful questions in quantitative drug development. However, to guarantee a successful and long-lasting symbiosis, it is important to highlight some of the associated risks and, where possible, how to mitigate them.

## Section: pAIns of combined QSP-ML/AI approaches › Right Problem, Right Tool

Choosing the right combined ML/AI and QSP approach requires careful consideration of the specific problem being addressed. Moreover, combined methods are not always a guaranteed improvement over using either ML/AI or QSP alone, or even simpler techniques. Studies have shown instances where predictions by ML alone were no better than basic linear regression (Christodoulou et al., 2019), and where simple ODE models provide reasonable insight and predictive ability compared to QSP models (Stein and Looby, 2018).

## Section: pAIns of combined QSP-ML/AI approaches › Defining Workflows

While both ML/AI and QSP share some tools and terminology, successfully combining them requires more than just common ground. Specialised workflows that choose the best software and programming languages for this integration need to be developed. Furthermore, the underlying assumptions of each component/algorithm should be communicated and understood by all. Poor communication can make it difficult to spot technical problems and hidden biases that can emerge when combining these workflows (McComb et al., 2022). To ensure that results are reproducible, the developed workflows should be transparent and explainable (Shelmerdine et al., 2021).

## Section: pAIns of combined QSP-ML/AI approaches › Error propagation

Error propagation concerns the transfer of uncertainty and artifacts between QSP and ML/AI. QSP models can be developed with the knowledge of complex biological processes to “fill in the blanks” from limited data, and they can generate valuable data that can be fed into ML algorithms (Bogatu et al., 2023). However, QSP models themselves contain uncertainties, especially in parameter estimates. Uncertainty assessment in QSP models is an area of active research (Ribba et al., 2017), and it is yet unclear how QSP-based uncertainty can be measured and ultimately mitigated when QSP model outputs are subsequently incorporated into ML approaches.

Future research may include (i) quantification of the uncertainty “chain reaction” by developing methods to track and understand how uncertainty propagates from QSP parameters to the final ML outputs and (ii) mitigation of the propagation impact by designing strategies to reduce or manage the uncertainty within the QSP-ML pipeline, potentially by improving parameter estimation or incorporating uncertainty information into the ML training itself (Fan et al., 2023). An additional instance where error propagation may occur is when ML-derived measurements from 2D images are used in 3D QSP models.

## Section: pAIns of combined QSP-ML/AI approaches › Data leakage

Data leakage during ML/AI modelling occurs when training datasets contain additional information about the system under study, often leading to an inflated performance on training data and, consequently, to an overestimation of the model’s performance accuracy when applied to other data. Such an ML/AI model may generate incidental and artefactual correlations irrelevant to the underlying mechanisms (Yeo and Selvarajoo, 2022). The source of these circumstantial associations can be technical (Kaufman et al., 2011), due to data pre-processing (Bouke and Abdullah, 2023), or inherent noise. Therefore, before integrating any results into QSP models, careful identification, quantification, and communication of potential sources of error is essential, especially when they cannot be completely mitigated.

## Section: pAIns of combined QSP-ML/AI approaches › Data bias

Data bias arises when certain subsets are systematically more likely to be selected than others in a sample (Shelmerdine et al., 2021). For example, historically, pre-clinical/clinical data are predominantly from males (Sandberg et al., 2015). QSP predictions stemming from such data will inevitably reproduce such bias, resulting in potential adverse effects and/or loss of efficacy in the underrepresented subpopulation (Zusterzeel et al., 2014; Ganapathi et al., 2022). To avoid such bias, data should be curated to be as diverse and representative as possible. Where this is not possible, models should only be evaluated in scenarios that adequately reflect how they were constructed, and a well-documented description of the datasets used should be provided.

## Section: pAIns of combined QSP-ML/AI approaches › Appropriate model validation

Technical issues arising from data selection for ML/AI and QSP modelling include the need for effective validation, which is already a central component in both ML/AI and QSP. As such, when applying a symbiotic approach, appropriate validation datasets need to meet both fields’ requirements, which will likely be challenging. For instance, to minimise data leakage in ML/AI, datasets should attempt to counteract the potentially incidental correlations present in the training dataset (Vokinger et al., 2021), whilst any dataset used for QSP model construction should provide complementary perturbations of the system to allow discrimination among models describing distinct mechanisms (Ribba et al., 2017).

## Section: pAIns of combined QSP-ML/AI approaches › Data collection and curation

Lack of standardised practices for data collection and handling makes meaningful dataset comparisons from different sites/labs difficult. For example, thrombin generation assays used to assess haematological disorders lacked a standardised protocol for sample handling, leading to methodological inconsistencies between testing sites, which complicated (if not invalidated) quantitative comparisons (De Laat Kremers et al., 2020).

Similarly, clinical datasets often suffer from a lack of completeness and consistency (e.g., missing data, inconsistent structure/formatting), which makes their use in QSP models challenging. Data integration from multiple sources and/or data-sharing between different institutions requires extensive and labour-intensive curation before the data can be confidently used: trained and experienced data annotators are needed to meticulously label large complex datasets for ML algorithms, a challenging task that demands precision and expertise in the field (Ohmann et al., 2011).

When handling longitudinal data, a key question to address is how to handle new information. As more accurate measurements or with higher detection levels are acquired, should the models be retrained using a fixed time window of past data? Or should the window be dynamic? Such a choice would have an impact on how much weight is given to potentially inaccurate older data, ultimately affecting the accuracy of the QSP-ML/AI model outputs. Furthermore, due to the long timescale of drug development, data that is regulation-compliant at the time of dataset creation or algorithm training may need to be curated again to fulfil the requirements of a changing regulatory landscape that restricts information access (Lugg-Widger et al., 2018). Therefore, such systematic model and dataset updates necessitate efficient processing pipelines and storage solutions.

## Section: Discussion

While the potential drawbacks (pAIns) associated with the symbiotic QSP and ML/AI approach should not be disregarded, the preliminary successes outlined in the gAIns section suggest its feasibility and potential. To fully realise its capacity for drug development, QSP modellers and data scientists in the pharmaceutical industry and in academia should work together with drug regulatory agencies. Such interaction should further highlight gAIns and make a concerted effort to identify and overcome pAIns arising when applying the symbiotic approach, with the ultimate goal of developing useful drugs efficiently and treating patients effectively.

Both the FDA (U.S. Food and Drug Administration) and the European Medicines Agency (European Medicines Agency, 2023) are already implementing risk-based approaches to regulate AI use in drug development. The proposed framework considers the intended purpose of the AI tool and the potential risk it poses to patients. Under such regulatory guidance, AI systems used to identify potential drug targets or to predict the efficacy/safety of a drug candidate may be subject to less stringent regulations than those directly involved in clinical trial decision-making and drug approval. While the FDA’s regulations for AI in drug development are evolving, the core principles outlined in their guidance echo the points raised in this paper. These principles emphasise the importance of (i) utilising high-quality data for training AI systems; (ii) employing transparent and explainable AI algorithms; (iii) monitoring AI system performance in real-world settings; and (iv) guaranteeing the protection of patient data used in the process.

In summary, the presented examples showcase the vast potential of combined QSP and ML/AI approaches in tackling relevant problems in drug discovery and drug development. We have also emphasised the importance of proactively identifying and mitigating potential risks (pAIns) associated with this integration. The clear benefits (gAIns) achieved through this symbiosis highlight the need to update the adage “no pain, no gain” to a more nuanced perspective: “some pAIn, greater gAIn.” This shift reflects the understanding that while challenges exist, the rewards of this combined approach far outweigh them, paving the way for significant advancements in drug discovery, efficient drug development, and improved patient outcomes.

## Section: Funding Statement

The author(s) declare that no financial support was received for the research, authorship, and/or publication of this article.

## Section: Data availability statement

The original contributions presented in the study are included in the article/Supplementary Material, further inquiries can be directed to the corresponding author.

## Section: Ethics statement

Written informed consent was obtained from the individual(s) for the publication of any potentially identifiable images or data included in this article.

## Section: Author contributions

NF: Writing–review and editing, Writing–original draft, Investigation, Conceptualization. FB: Writing–review and editing, Writing–original draft, Investigation, Conceptualization. AU: Writing–review and editing, Writing–original draft, Investigation, Conceptualization. CP-A: Writing–review and editing, Writing–original draft, Investigation, Conceptualization. ML: Writing–review and editing, Writing–original draft, Investigation, Conceptualization. JB: Writing–review and editing, Writing–original draft, Investigation, Conceptualization. RD: Writing–review and editing. MG: Writing–review and editing. HK: Writing–review and editing, Writing–original draft, Investigation, Conceptualization.

## Section: Conflict of interest

All authors were employed by AstraZeneca.

## Section: Publisher’s note

All claims expressed in this article are solely those of the authors and do not necessarily represent those of their affiliated organizations, or those of the publisher, the editors and the reviewers. Any product that may be evaluated in this article, or claim that may be made by its manufacturer, is not guaranteed or endorsed by the publisher.

## Section: Associated Data › Data Availability Statement

The original contributions presented in the study are included in the article/Supplementary Material, further inquiries can be directed to the corresponding author.


---

# Critical Appraisal and Future Challenges of Artificial Intelligence and Anticancer Drug Development

- **Authors:** Emmanuel Chamorey, Jocelyn Gal, Baharia Mograbi, Gérard Milano
- **Issuer:** Pharmaceuticals (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2024-06-21
- **Language:** en
- **DOI:** 10.3390/ph17070816
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39065667/
- **Licence:** CC-BY

## Page 1 (Section: Introduction )

Citation: Chamorey, E.; Gal, J.;
Mograbi, B.; Milano, G. Critical
Appraisal and Future Challenges of
Artiﬁcial Intelligence and Anticancer
Drug Development. Pharmaceuticals
2024, 17, 816. https://doi.org/
10.3390/ph17070816
Academic Editor: Jinxiang Xi
Received: 30 April 2024
Revised: 13 June 2024
Accepted: 17 June 2024
Published: 21 June 2024
Copyright:
© 2024 by the authors.
Licensee MDPI, Basel, Switzerland.
This article is an open access article
distributed
under
the
terms
and
conditions of the Creative Commons
Attribution (CC BY) license (https://
creativecommons.org/licenses/by/
4.0/).
pharmaceuticals
Opinion
Critical Appraisal and Future Challenges of Artiﬁcial
Intelligence and Anticancer Drug Development
Emmanuel Chamorey 1
, Jocelyn Gal 1
, Baharia Mograbi 2 and Gérard Milano 3,*
1
Epidemiology and Biostatistics Department, Centre Antoine Lacassagne, University Côte d’Azur,
33 Avenue de Valombrose, 06189 Nice, France; emmanuel.chamorey@nice.unicancer.fr (E.C.);
jocelyn.gal@nice.unicancer.fr (J.G.)
2
FHU OncoAge, IHU RespirERA, IRCAN, Inserm, University Côte d’Azur, CNRS 7284, U1081,
06000 Nice, France; mograbi@unice.fr
3
Oncopharmacology Unit, Centre Antoine Lacassagne, University Côte d’Azur, 33 Avenue de Valombrose,
06189 Nice, France
*
Correspondence: gerard.milano@nice.unicancer.fr
Abstract: The conventional rules for anti-cancer drug development are no longer sufﬁcient given
the relatively limited number of patients available for therapeutic trials. It is thus a real challenge
to better design trials in the context of new drug approval for anti-cancer treatment. Artiﬁcial
intelligence (AI)-based in silico trials can incorporate far fewer but more informative patients and
could be conducted faster and at a lower cost. AI can be integrated into in silico clinical trials to
improve data analysis, modeling and simulation, personalized medicine approaches, trial design
optimization, and virtual patient generation. Health authorities are encouraged to thoroughly review
the rules for setting up clinical trials, incorporating AI and in silico methodology once they have been
appropriately validated. This article also aims to highlight the limits and challenges related to AI and
machine learning.
Keywords: drug discovery; oncology; artiﬁcial intelligence; clinical trials
1. Introduction
Artiﬁcial intelligence (AI) is a general term encompassing computer programs capable
of thinking like humans [1]. The main component of AI is machine learning (ML), which
involves inputting data into machines and using algorithms such as Naïve Bayes, XgBoost,
and Hidden Markov models [1]. Hardware has evolved to accompany the constant progress
in ML. There is growing evidence to support the implementation of AI in healthcare,
especially in the context of an increasingly aging population. AI has the potential to reduce
the cost of current healthcare systems.
When applied to cancer, AI can potentially radically transform clinical trial design
and signiﬁcantly impact preclinical drug development in several respects [2]. Its impact
in this ﬁeld is wide and includes the ability to more rigorously validate the hypotheses
emerging from tumor proﬁling, deﬁne molecular mechanisms, and lead to innovative
therapies. Core attributes of AI in preclinical drug development are molecular screening
and target identiﬁcation, thanks to the use of traditional machine learning and neural
networks. More precisely, and regarding drug design, AI may generate in silico-designed
molecules and analogs with speciﬁc properties [3]. We previously described the timeline
for the implication of AI in anticancer drug development [4]. AI can optimize dosages,
as reported by Paul et al. [5], for the use of capecitabine. These authors conducted AI-
based clinical trial simulations (CTSs) to reduce toxicity while maintaining the efﬁcacy
of capecitabine. AI can also predict drug activity, as demonstrated by Claret et al. [6] in
small-cell lung cancer, where a prediction of Phase III survival outcome was made using
a drug–disease model framework and phase II data. CTS was also shown to be capable
Pharmaceuticals 2024, 17, 816. https://doi.org/10.3390/ph17070816
https://www.mdpi.com/journal/pharmaceuticals

## Page 2 (Section: Breaking the Dogma of Traditional Clinical Trial Designs )

Pharmaceuticals 2024, 17, 816
2 of 7
of designing a model representing the tumor size dynamics of gliomas under treatment
with chemotherapy plus radiotherapy [7]. To date, more than 300 clinical trials have been
completed or are underway that involve the application of AI to cancer treatment [8]. The
main objective of this short review-position paper is not to cover the aspects related to the
role of AI in drug design but rather to focus, with a critical eye, on the clinical contribution
of AI in anticancer drug development (Figure 1).
Figure 1. Contribution of AI in anticancer drug development.
2. Breaking the Dogma of Traditional Clinical Trial Designs
It is worth noting that the conventional rules for drug development are becoming inad-
equate, especially when dealing with a limited number of patients available for therapeutic
trials, such as in the active and productive ﬁeld of immunotherapy. In this context, there is
a wide range of regimens to test, including several potentially active drug combinations
where we must continue to develop biologically diverse strategies as recently reported
by Perurena and coworkers for combinatorial strategies in order to target RAS-driven
cancers [9]. The achievement of these objectives poses signiﬁcant difﬁculties when applied
in conventional prospective and controlled therapeutic trials, as they may miss, for instance,
active drug combinations due to the limited number of patients included in the trials.
Placebo-controlled studies are, for health agencies, the central pillar for validating cancer
therapeutic innovations. However, these prospective therapeutic trials may face at least
two major challenges. The ﬁrst difﬁculty is the placebo itself, which can raise some ethical
concerns. This could be the case when a new drug evaluated through a phase III placebo-
controlled trial has already demonstrated a marked antitumor efﬁcacy during phase II trials.
This does not mean that a placebo-control add-on design should not remain applicable. The
second difﬁculty arises when dealing with an under-represented patient population. For
instance, colorectal tumors (CRC) with a microsatellite instability (MSI), may beneﬁt from
immunotherapy, as suggested by the KEYNOTE-177 trial [10]. However, under 5% of cases
fall into this speciﬁc, rare group of patients, which makes it difﬁcult to prove the beneﬁt
and implement immunotherapy in this limited population. It is thus a real challenge to
improve prospective controlled therapeutic trials. This could be achieved through better
designs, better selection criteria, or larger effect sizes. A promising alternative illustrated by

## Page 3 (Section: In Silico Clinical Trials )

Pharmaceuticals 2024, 17, 816
3 of 7
a recent study in MSI CRC has pointed to the possibility of using databases and performing
retrospective analysis with strong statistical foundations [11]. This study used a statistical
tool, called the propensity score, which considers all the co-variables that could impact
survival rates. This score allowed the authors to accurately compare patient subgroups
who received ICIs with those who did not. This work underscores the value of AI-based
propensity score methods, which encompass a variety of techniques, including machine
learning algorithms such as random forests, gradient boosting machines, and neural net-
works [12]. These methods offer automated variable selection to mitigate the risks of
overﬁtting and enhance the generalizability of propensity score models. On these bases,
the authors reported that patients receiving third-line therapy (1813 patients) had a median
overall survival that was not reached for patients on CPIs as compared to 3.5 months for
those on a placebo (589 patients, HR = 0.20; 95%CI = 0.10–0.41, p < 0.001) and 6.5 months for
those on the reference treatment (1175 patients, HR = 0.30, 95% CI = 0.15–0.60, p = 0.001).
The application of robust statistical tools supported by AI should thus become more
and more prevalent as discussed above, with the use of propensity scores on large retro-
spective datasets. However, it should be kept in mind that the use of the propensity score
has its proper limits. For instance, the process of propensity matching may change the
population being studied. This can lead to estimates about the effects of the intervention on
a different population than the initial one [13]. The central aim remains to suggest solutions
to health agencies to shorten delays for patients in accessing innovative treatment. This
should also signiﬁcantly reduce the costs of pharmaceutical development, and also, the
ethical pitfalls related to strict compliance with the prospective controlled trial strategy can
be avoided.
3. In Silico Clinical Trials
By analogy with the expressions in vivo and in vitro, the term in silico was introduced
to describe the numerical methods involving a mathematical approach to models that
simulate biological phenomena using computers [4]. In silico trials aim to predict patient
responses and outcomes using an AI-designed model. In silico clinical trials and AI
technologies are distinct yet complementary concepts. AI technologies encompass a wide
range of techniques (machine learning, deep learning, reinforcement learning, natural
language processing) and machine learning itself includes unsupervised and supervised
learnings. These computer facilities enable complex calculations to be performed quickly
and automatically. In silico clinical trials involve the use of computer models, simulations,
and virtual patients to predict clinical trial outcomes, as recently highlighted in the context
of cancer immunotherapy [14]. These trials aim to simulate various aspects of clinical trials,
such as drug effectiveness, safety, and patient responses, in a computerized environment.
Altogether, AI can be integrated into in silico clinical trials to improve data analysis,
modeling and simulation, personalized medicine approaches, trial design optimization,
and virtual patient generation [1].
Models are generally built using data from previous trials of similar drugs, capturing
individual critical parameters from a limited number of patients. Unlike conventional
trial designs, in silico trials need far fewer but more informative patients and could be
carried out more quickly and at a lower cost [15]. This has spawned great enthusiasm
in terms of the development and clinical implementation of cancer immunotherapy. The
development of kinase inhibitors for the main oncogenic drivers is also particularly active
and productive [16]. However, this context may generate many similar drugs, known as
“me-too” drugs, where it is difﬁcult to distinguish the beneﬁts for the patient versus those
for drug companies. AI has the potential to markedly improve this situation and provide
innovative solutions, as previously underlined by our group [4]. Clearly, in silico clinical
trials can take advantage of the modeling of cumulated clinical experience and biological
data generated by previously developed compounds belonging to the same category of
drugs. Globally, there are two approaches to conducting in silico clinical trials for predicting
outcomes of real clinical trials.

## Page 4 (Section: Critical Appraisal (Table 1) )

Pharmaceuticals 2024, 17, 816
4 of 7
The ﬁrst approach is to simulate patients by adjusting biological constants or tumor
characteristics. In such a setting, Novadiscovery’s jink¯o trial simulation platform [17],
through a retrospective approach, successfully predicted AstraZeneca’s phase III clinical
trial FLAURA2 [18]. The investigators applied a previously validated knowledge-based
mechanistic model which accurately reproduced the time to progression of a clinical trial for
targeted therapy of lung cancer [19]. It is interesting to note that the simulation performed
with Novadiscovery’s platform took only one month to set up, while the clinical trial
lasted 3 years. In particular, the simulation was able to predict that adding chemotherapy
to osimertinib signiﬁcantly increased progression-free survival in patients with EGFR-
mutated, non-small cell lung cancer. Creemers and colleagues [14] utilized in silico can-
cer immunotherapy trials to construct virtual patient cohorts receiving immunotherapy,
chemotherapy, or combination therapies. They successfully designed simulation models
that predicted the distinct survival curves commonly associated with immunotherapies.
However, it must be borne in mind that simulation remains a simulation and does not
replace prospective clinical trials.
The second approach to developing in silico clinical trials is to retrospectively use big
data and artiﬁcial intelligence algorithms to identify patients eligible for clinical trials and
achieving this by aggregating and structuring data from patients’ medical records [20,21].
A concrete illustration of this strategy comes from the study by Eckardt and coworkers [22].
The authors demonstrated the feasibility of two different technologies of generative AI
to develop synthetic clinical trial data for patients with acute myeloid leukemia and that
closely mimic disease biology and clinical behaviors. The approach is particularly promis-
ing but, in reality, a speciﬁc part dedicated to real-world evidence will remain necessary in
order to confront original data with AI-generated data.
Globally, in silico clinical trials hold promise for accelerating the drug development
process, reducing costs, and ultimately improving patient outcomes. For instance, the use
of AI provided an interesting answer to the investigators who recently questioned the real
beneﬁts of radiation therapy in gastrointestinal cancers [23].
It becomes necessary for health authorities to comprehensively revise the rules for set-
ting up clinical trials, taking into account the potential advancements provided by AI and in
silico methodology [24]. Such a strategy should maintain the notion of result reproducibil-
ity as a key criterion for acceptability by the medical and scientiﬁc community [25]. As
recently stressed by Cobanaj and coworkers [26], the role of the FDA regarding AI should
also be the promotion of health equity by asking investigations to transparently disclose
the patient dataset composition and mandate validation on diverse patient populations.
4. Critical Appraisal (Table 1)
AI-designed models, primarily based on machine learning and deep-learning algo-
rithms, offer greater ﬂexibility in analyzing large volumes of data compared to traditional
models. Although AI and machine learning approaches are promising, they are not without
limitations and challenges in drug development [27,28]. For instance, the algorithms used
may require large sample sizes, including labeled datasets. The development of databases
across different institutions involving large network groups may be complex to set up.
Interoperability standards are necessary to ensure secure and scalable data transfer. Ad-
ditionally, machine learning models reach a high level of complexity and may constitute
impenetrable “black boxes” with the output difﬁcult to interpret. There is also a risk for
an unavoidable widening gap between how fast technologies like AI are devised and how
quickly regulatory agencies may establish legal rules for safe implementation [22].

## Page 5 (Section: Future Challenges )

Pharmaceuticals 2024, 17, 816
5 of 7
Table 1. Strengths and limits of AI-based clinical trials in oncology.
Strengths [14]
•
Avoids repeated development programs.
•
Preserves resources for true innovation.
•
Speeds up the development of new trials.
Limits and potential deﬁciencies [27,28]
•
Necessitates large sample sizes with a strict control of data quality.
•
Creates complications in terms of implementing databases across institutions
(transferability), with a risk of hidden biases.
•
May constitute impenetrable « black boxes » (interpretability).
•
Develops virtual patients that are limited in terms of explaining complex interactions
(generalizability for biology, disease, treatment).
5. Future Challenges
Clinical researchers, whether in industry or academia, are increasingly aware of the
beneﬁts of incorporating AI into their strategies for developing anticancer drugs. With AI,
it is possible to avoid repeated development programs and thereby preserve the resources
necessary for true innovation [29]. Leary and coworkers [30] have pointed out that there
is a current expectation for other types of clinical research when facing the complexity of
biotherapeutics and achieving this in the context of the administrative burden of regulatory
requirements for new anti-cancer drug development. Interestingly, the authors proposed
promoting pragmatic and affordable clinical trials. Notably, according to the authors, the
tested intervention, patient selection, and follow-up could be integral parts of routine care.
On the other hand, there is growing evidence that lower doses of anticancer drugs or shorter
courses of precision therapy could reduce toxicity and save money [31]. To achieve this
objective, the use of AI-guided clinical trials could potentially expedite the process. Due to
continuous and intense changes in the clinical practice of cancer treatment, there will be the
necessity to recalibrate the performance of AI-based models. As critically considered in the
present position paper, AI has the potential to enable and speed up the development of new
trials, through the creation of “digital” patients, which reduces the risks to human health.
This does not, however, spell the end of pharmaceutical trials on humans, which remain
essential and should be reformatted and not replaced by AI. In particular, all stakeholders
will have to see a consistent pattern of such success before embarking on the adoption
of such solutions as an alternative to prospective clinical trials. The development of AI
must not constitute a source of apprehension among practitioners [28] but should lead
to refocusing medical practice on guidance and support. In brief, the aim of this paper
was principally to display the new possibilities offered by AI for conducting new drug
development in the cancer area. However, numerous challenges and limitations do remain
that we must keep in mind to provide faithful guidance that can lead to success stories.
Author Contributions: G.M., J.G., E.C. and B.M. participated in writing and critically revising the
important intellectual content of this manuscript. All authors have read and agreed to the published
version of the manuscript.
Funding: IHU Respira University Nice Cote d’Azur (ANR-23-IAHU-007).
Conﬂicts of Interest: The authors declare no conﬂicts of interest.
References
1.
Gupta, R.; Srivastava, D.; Sahu, M.; Tiwari, S.; Ambasta, R.K.; Kumar, P. Artiﬁcial intelligence to deep learning: Machine
intelligence approach for drug discovery. Mol. Divers. 2021, 25, 1315–1360. [CrossRef]
2.
Gerstberger, S.; Jiang, Q.; Ganesh, K. Metastasis. Cell 2023, 186, 1564–1579. [CrossRef]
3.
Kortemme, T. De novo protein design-from new structures to programmable functions. Cell 2024, 187, 526–544. [CrossRef]

## Page 6 (Section: Future Challenges )

Pharmaceuticals 2024, 17, 816
6 of 7
4.
Gal, J.; Milano, G.; Ferrero, J.M.; Saada-Bouzid, E.; Viotti, J.; Chabaud, S.; Gougis, P.; Le Tourneau, C.; Schiappa, R.; Paquet, A.;
et al. Optimizing drug development in oncology by clinical trial simulation: Why and how? Brief. Bioinform. 2018, 19, 1203–1217.
[CrossRef]
5.
Paule, I.; Tod, M.; Henin, E.; You, B.; Freyer, G.; Girard, P. Dose adaptation of capecitabine based on individual prediction of
limiting toxicity grade: Evaluation by clinical trial simulation. Cancer Chemother. Pharmacol. 2012, 69, 447–455. [CrossRef]
6.
Claret, L.; Lu, J.F.; Bruno, R.; Hsu, C.P.; Hei, Y.J.; Sun, Y.N. Simulations using a drug-disease modeling framework and phase II
data predict phase III survival outcome in ﬁrst-line non-small-cell lung cancer. Clin. Pharmacol. Ther. 2012, 92, 631–634. [CrossRef]
7.
Mazzocco, P.; Honnorat, J.; Ducray, F.; Ribba, B. Increasing the Time Interval between PCV Chemotherapy Cycles as a Strategy to
Improve Duration of Response in Low-Grade Gliomas: Results from a Model-Based Clinical Trial Simulation. Comput. Math.
Methods Med. 2015, 2015, 297903. [CrossRef]
8.
Zhang, Z.; Wei, X. Artiﬁcial intelligence-assisted selection and efﬁcacy prediction of antineoplastic strategies for precision cancer
therapy. Semin. Cancer Biol. 2023, 90, 57–72. [CrossRef]
9.
Perurena, N.; Situ, L.; Cichowski, K. Combinatorial strategies to target RAS-driven cancers. Nat. Rev. Cancer 2024, 24, 316–337.
[CrossRef]
10.
Diaz, L.A., Jr.; Shiu, K.K.; Kim, T.W.; Jensen, B.V.; Jensen, L.H.; Punt, C.; Smith, D.; Garcia-Carbonero, R.; Benavides, M.; Gibbs, P.;
et al. Pembrolizumab versus chemotherapy for microsatellite instability-high or mismatch repair-deﬁcient metastatic colorectal
cancer (KEYNOTE-177): Final analysis of a randomised, open-label, phase 3 study. Lancet Oncol. 2022, 23, 659–670. [CrossRef]
11.
Cohen, R.; Raeisi, M.; Chibaudel, B.; Yoshino, T.; Shi, Q.; Zalcberg, J.R.; Adams, R.; Cremolini, C.; Grothey, A.; Mayer, R.J.; et al.
Efﬁcacy of immune checkpoint inhibitors for metastatic colorectal cancer with microsatellite instability in second or latter line
using synthetic control arms: A non-randomised evaluation. Eur. J. Cancer 2024, 199, 113537. [CrossRef]
12.
Ferri-García, R.; Rueda, M.D.M. Propensity score adjustment using machine learning classiﬁcation algorithms to control selection
bias in online surveys. PLoS ONE 2020, 15, e0231500. [CrossRef]
13.
Beaulieu-Jones, B.K.; Finlayson, S.G.; Yuan, W.; Altman, R.B.; Kohane, I.S.; Prasad, V.; Yu, K.H. Examining the Use of Real-World
Evidence in the Regulatory Process. Clin. Pharmacol. Ther. 2020, 107, 843–852. [CrossRef]
14.
Creemers, J.H.A.; Ankan, A.; Roes, K.C.B.; Schröder, G.; Mehra, N.; Figdor, C.G.; de Vries, I.J.M.; Textor, J. In silico cancer
immunotherapy trials uncover the consequences of therapy-speciﬁc response patterns for clinical trial design and outcome. Nat.
Commun. 2023, 14, 2348. [CrossRef]
15.
Chopra, H.; Annu; Shin, D.K.; Munjal, K.; Priyanka; Dhama, K.; Emran, T.B. Revolutionizing clinical trials: The role of AI in
accelerating medical breakthroughs. Int. J. Surg. 2023, 109, 4211–4220. [CrossRef]
16.
Swanson, K.; Wu, E.; Zhang, A.; Alizadeh, A.A.; Zou, J. From patterns to patients: Advances in clinical machine learning for
cancer diagnosis, prognosis, and treatment. Cell 2023, 186, 1772–1791. [CrossRef]
17.
jink¯o: A Complete Solution for Trial Simulation & Design Optimization. Available online: https://www.novadiscovery.com/
jinko/ (accessed on 15 April 2024).
18.
EGFR-Mutant NSCLC: Chemo-TKI Bests TKI Alone. Cancer Discov. 2023, 13, 2298. [CrossRef]
19.
L’Hostis, A.; Palgen, J.L.; Perrillat-Mercerot, A.; Peyronnet, E.; Jacob, E.; Bosley, J.; Duruisseaux, M.; Toueg, R.; Lefevre, L.; Kahoul,
R.; et al. Knowledge-based mechanistic modeling accurately predicts disease progression with geﬁtinib in EGFR-mutant lung
adenocarcinoma. NPJ Syst. Biol. Appl. 2023, 9, 37. [CrossRef]
20.
Schiappa, R.; Contu, S.; Culie, D.; Chateau, Y.; Gal, J.; Pace-Loscos, T.; Bailleux, C.; Haudebourg, J.; Ferrero, J.M.; Barranger, E.;
et al. Validation of RUBY for Breast Cancer Knowledge Extraction From a Large French Electronic Medical Record System. JCO
Clin. Cancer Inf. 2023, 7, e2200130. [CrossRef] [PubMed]
21.
Schiappa, R.; Contu, S.; Culie, D.; Thamphya, B.; Chateau, Y.; Gal, J.; Bailleux, C.; Haudebourg, J.; Ferrero, J.M.; Barranger, E.; et al.
RUBY: Natural Language Processing of French Electronic Medical Records for Breast Cancer Research. JCO Clin. Cancer Inform.
2022, 6, e2100199. [CrossRef] [PubMed]
22.
Eckardt, J.N.; Hahn, W.; Rollig, C.; Stasik, S.; Platzbecker, U.; Muller-Tidow, C.; Serve, H.; Baldus, C.D.; Schliemann, C.; Schafer-
Eckart, K.; et al. Mimicking clinical trials with synthetic acute myeloid leukemia patients using generative artiﬁcial intelligence.
NPJ Digit. Med. 2024, 7, 76. [CrossRef] [PubMed]
23.
Sanford, N.N.; Hong, T.S.; Hall, W.A. Elucidating the Beneﬁt of Radiation Therapy in GI Cancers: Rethinking Trial End Points
and Patient Selection. J. Clin. Oncol. 2024, 42, 868–871. [CrossRef] [PubMed]
24.
Musuamba, F.T.; Skottheim Rusten, I.; Lesage, R.; Russo, G.; Bursi, R.; Emili, L.; Wangorsch, G.; Manolis, E.; Karlsson, K.E.;
Kulesza, A.; et al. Scientiﬁc and regulatory evaluation of mechanistic in silico drug and disease models in drug development:
Building model credibility. CPT Pharmacomet. Syst. Pharmacol. 2021, 10, 804–825. [CrossRef] [PubMed]
25.
Karr, J.; Malik-Sheriff, R.S.; Osborne, J.; Gonzalez-Parra, G.; Forgoston, E.; Bowness, R.; Liu, Y.; Thompson, R.; Garira, W.; Barhak,
J.; et al. Model Integration in Computational Biology: The Role of Reproducibility, Credibility and Utility. Front. Syst. Biol. 2022, 2.
[CrossRef] [PubMed]
26.
Cobanaj, M.; Corti, C.; Dee, E.C.; McCullum, L.; Boldrini, L.; Schlam, I.; Tolaney, S.M.; Celi, L.A.; Curigliano, G.; Criscitiello, C.
Advancing equitable and personalized cancer care: Novel applications and priorities of artiﬁcial intelligence for fairness and
inclusivity in the patient care workﬂow. Eur. J. Cancer 2024, 198, 113504. [CrossRef] [PubMed]
27.
Poweleit, E.A.; Vinks, A.A.; Mizuno, T. Artiﬁcial Intelligence and Machine Learning Approaches to Facilitate Therapeutic Drug
Management and Model-Informed Precision Dosing. Ther. Drug Monit. 2023, 45, 143–150. [CrossRef] [PubMed]

## Page 7 (Section: Future Challenges )

Pharmaceuticals 2024, 17, 816
7 of 7
28.
Kolanska, K.; Chabbert-Buffet, N.; Darai, E.; Antoine, J.M. Artiﬁcial intelligence in medicine: A matter of joy or concern? J.
Gynecol. Obs. Hum. Reprod. 2021, 50, 101962. [CrossRef] [PubMed]
29.
Beaver, J.A.; Pazdur, R. The Wild West of Checkpoint Inhibitor Development. N. Engl. J. Med. 2022, 386, 1297–1301. [CrossRef]
[PubMed]
30.
Leary, A.; Besse, B.; André, F. The need for pragmatic, affordable, and practice-changing real-life clinical trials in oncology. Lancet
2024, 403, 406–408. [CrossRef] [PubMed]
31.
Moutinho, S. Dozens of precision cancer drugs tested at lower doses to reduce side effects and cut costs. Nat. Med. 2024, 30,
611–614. [CrossRef]
Disclaimer/Publisher’s Note: The statements, opinions and data contained in all publications are solely those of the individual
author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to
people or property resulting from any ideas, methods, instructions or products referred to in the content.


---

# Cyto-Safe: A Machine Learning Tool for Early Identification of Cytotoxic Compounds in Drug Discovery

- **Authors:** Francisco L Feitosa, Victoria F Cabral, Igor H Sanches, Sabrina Silva-Mendonca, Joyce V V B Borba, Rodolpho C Braga, Carolina Horta Andrade
- **Issuer:** Journal of chemical information and modeling
- **Type:** Scientific article
- **Published:** 2024-12-11
- **Language:** en
- **DOI:** 10.1021/acs.jcim.4c01811
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39661446/
- **Licence:** CC-BY

## Section: Abstract

Cytotoxicity is essential in drug discovery, enabling early evaluation of toxic compounds during screenings to minimize toxicological risks. In vitro assays support high-throughput screening, allowing for efficient detection of toxic substances while considerably reducing the need for animal testing. Additionally, AI-based Quantitative Structure–Activity Relationship (AI-QSAR) models enhance early stage predictions by assessing the cytotoxic potential of molecular structures, which helps prioritize low-risk compounds for further validation. We present a freely accessible web application designed for identifying potential cytotoxic compounds utilizing QSAR models. This application utilizes machine learning techniques and is built on a data set of approximately 90,000 compounds, evaluated against two cell lines, 3T3 and HEK 293. Users can interact with the app by inputting a SMILES representation, uploading CSV or SDF files, or sketching molecules. The output includes a binary prediction for each cell line, a confidence percentage, and an explainable AI (XAI) analysis. Cyto-Safe web-app version 1.0 is available at http://insightai.labmol.com.br/.

## Section: Introduction

Cell viability and cytotoxicity assays are fundamental tools used in biomedical research to measure the cytotoxic effects of various substances on living cells. Cytotoxicity specifically refers to the detrimental impacts these substances have on cellular health, often leading to cell death.1 These assays are critical for drug screening, identifying compounds that demonstrate cytotoxic effects which are then typically excluded in both target-based and cell-based phenotypic screenings. This is particularly vital in the context of oncology and neurodegenerative diseases, where understanding substance toxicity is crucial for drug development.2

A significant advantage of in vitro assays is their ability to perform high-throughput screening, allowing researchers to efficiently identify toxic compounds or potential therapeutic agents from large numbers of samples. Additionally, these assays align with the growing emphasis on ethical research by reducing the need for animal testing, making them increasingly valuable in the scientific community.3,4 They operate by measuring various cellular functions that indicate cytotoxicity, such as cell membrane permeability, enzyme activity, cell adherence, ATP production, coenzyme production, and nucleotide uptake activity.5 Accurately predicting chemical-induced cytotoxicity early in the drug development process (preferably before the compounds are even synthesized) is essential. Early detection of cytotoxicity can help prevent costly failures in later stages of development and ensures that only the most promising candidates advance.

The increasing costs associated with ADME/Tox (Absorption, Distribution, Metabolism, Excretion, and Toxicity) studies have spurred the development of in silico methods, particularly within large pharmaceutical companies that possess extensive and internally consistent data sets. While initial computational efforts outside the pharmaceutical sector faced limitations due to smaller data sets, the growing availability of larger data sets in public repositories has significantly improved the potential for successful model development.6 The use of artificial intelligence (AI) to build cytotoxicity models shows great promise for enhancing early stage cytotoxicity prediction. By predicting the cytotoxic potential of chemical compounds based on their molecular structures, these computational models can support virtual screening campaigns, helping to prioritize compounds with lower cytotoxic risks for further experimental validation. This approach streamlines the identification of viable drug candidates.

Building on insights from our previous research,7−10 we have developed QSAR models using a diverse data set of compounds tested on 3T3 and HEK-293 cell lines. We present a new web-accessible application designed to predict the cytotoxicity potential of chemicals, integrating a carefully curated database of 3T3 and HEK-293 cytotoxicity data. The web app features novel models for predicting cytotoxicity, developed exclusively with open-source tools. Available as a web version (version 1.0), it facilitates efficient virtual screening of chemical libraries, aiding in the identification of potential cytotoxic compounds for further investigation. The result includes a binary prediction for each cell line, a confidence percentage, and an explainable AI (XAI) analysis for visual interpretation of the results. This tool can be freely accessed at LabMol Insight AI portal http://insightai.labmol.com.br/.

## Section: CYTO-SAFE › Data Collection

Cytotoxicity data was sourced from a data set provided by the National Center for Advancing Translational Sciences (NCATS).11 This data set includes the results of approximately 90,000 compounds tested for cytotoxicity using the luciferase assay, commercially known as CellTiter-Glo, in a 48 h of incubation time, across two different cell lines: 3T3 and HEK 293. The original data can be accessed via PubChem under AID 1345082 and AID 1345083.

## Section: CYTO-SAFE › Data Cleaning and Curation

Initially, both data sets comprised 93,781 records. However, after eliminating entries with inconclusive outcomes and incomplete chemical structure information, the analysis yielded 67,041 compounds from the 3T3 series and 64,508 compounds from the HEK 293 series.

Subsequently, we implemented a rigorous data curation protocol as described by Fouches et al.,12,13 resulting in 66,620 unique compounds for the 3T3 series. According to the threshold stablished of EC50 value of ≤10 μM,11 62,613 compounds were labeled as noncytotoxic, and 4,007 records were considered cytotoxic for the 3T3. In the HEK data set, a total of 64,094 records were analyzed, with 6,141 compounds labeled as cytotoxic.

To tackle potential data unbalancing that might introduce bias into the classification models, we strategically applied the NearMiss v.3 under sampling method14 executed on Imbalanced-learn package (https://imbalanced-learn.org), setting the sampling strategy as 0.2 and number of near neighbors to 50. This method enabled to get compounds in the majority class (noncytotoxic) with the minimum distance from minority class examples (cytotoxic) maintaining a balanced proportion between cytotoxic and noncytotoxic samples. By adopting this approach, our primary objective was to establish a more equitable and representative data set, thereby enhancing the effectiveness of our classification model training process. The entire processed data is available in Supporting Information.

## Section: CYTO-SAFE › QSAR Modeling

Classification QSAR models were generated and validated in accordance with the established standards and principles of QSAR modeling.15,16 The molecules were converted into a binary language, based on Extended Connectivity Fingerprints17 with radius 2 (ECPF4) and 1024 bits, using the open-source library RDKit.18 ECFP was chosen to capture detailed atomic environments without relying on predefined features. Light Gradient Boosting machine learning algorithm (LGBM)19 was executed in Python 3.10. The data set was stratified split into training (80%) and external (20%) sets. The external set was held out entirely during hyperparameter optimization to ensure unbiased evaluation. Bayesian optimization was conducted using the scikit-optimize, with 100 iterations and 10-fold cross-validation, optimized by balanced accuracy. Class weights were applied to handle class imbalance in the data set. The selected hyperparameters for the best models are provided in the Supporting Information. For all models, we calculated the following metrics on the external set: Balanced Accuracy (BACC), Matthew’s correlation coefficient (MCC), Precision, Recall, F1 score, and plotted the confusion matrix.

## Section: CYTO-SAFE › Y-Randomization

We performed 50 rounds of Y-randomization to assess the robustness and validity of our predictive models. Y-randomization involves shuffling the dependent variable (Y; cytotoxicity outcomes) while keeping the independent variables (X; molecular fingerprints) intact.

## Section: CYTO-SAFE › Deployment

The Cyto-Safe web application was deployed on a cloud-based platform, utilizing a Flask backend and a Jinja2 template-driven frontend to ensure scalability and responsive user interfaces. Machine learning models were then integrated within the Flask framework to facilitate both individual and batch predictions of up to ten compounds via CSV or SDF file inputs. The application incorporates the Ketcher molecular editor (version 2.10.0; EPAM), an open-source web-based chemical structure editor, to provide an intuitive interface for drawing and editing chemical structures, enhancing user experience and data accuracy. Prediction results can be exported as spreadsheets for detailed analysis or as web-based reports for immediate review.

## Section: CYTO-SAFE › Explainable AI (XAI)

In this study, we employed an Explainable AI (XAI) framework to interpret our model’s binary classification predictions regarding the cytotoxicity of compounds in 3T3 and HEK-293 cell lines. We used the methodology proposed by Riniker and Landrum20 that systematically removes bits in the molecular fingerprints that correspond to specific atoms or functional groups and assess how these changes influenced the model’s predictions. We normalized these contributions and visualized them using similarity maps and heatmaps analogous to topographical representations.

In these visualizations, structural fragments predicted to increase toxicity were highlighted in red, while those predicted to decrease toxicity were highlighted in green. This approach allowed us to identify key structural features affecting the model’s decisions, providing deeper insights into the patterns and potential biases related to the predicted outcome.

## Section: Results and Discussion

General scheme of usage, outcome and XAI of Cyto-Safe web app.

Explainable AI (XAI) molecular diagrams illustrating the model’s predictions for Doxorubicin on the 3T3 (A) and HEK-293 (B) models, and for Ibuprofen on the 3T3 (C) and HEK-293 (D) models. Red contoured regions highlight areas with a strong positive influence on predicted cytotoxicity, whereas green contoured regions indicate a strong positive influence on predicted nontoxicity. The intensity of the contour colors reflects the magnitude of their influence, with darker shades representing a greater impact on the model’s predictions.

## Section: Results and Discussion › Modeling

The under-sampling technique was applied to the majority class (noncytotoxic) using two different proportions: 1:1 and 1:5, relative to the minority class, cytotoxic. As a result, the balanced 3T3 data set comprised 8,014 records for the 1:1 ratio and 24,042 for the 1:5 ratio. For the HEK 293 balanced data sets, the corresponding records were 12,282 and 36,846, respectively.

Further analysis was conducted using clustering to identify groups of structurally similar compounds that exhibit contrasting outcomes (cytotoxic versus noncytotoxic), with the goal of simulating potential activity cliffs within the training set. The results revealed that only 11.8% of the clusters from the 3T3 data set and 13.2% from the HEK293 data set contained compounds with differing outcomes. These findings indicate a high level of data reliability while also highlighting the challenges that the algorithm must navigate to learn effectively from the training set (see Supporting Information - Supplementary Methods and Results).

Following training, all models were evaluated on the test set. The models exhibited satisfactory performance across both under-sampling proportion ratios, indicating their proficiency in distinguishing between cytotoxic and noncytotoxic compounds. Notably, the models demonstrated robust generalization capabilities by accurately classifying samples not encountered during the training phase.

When comparing overall metrics, the models trained with the 1:5 ratio showed a slight improvement over those using the 1:1 ratio. This was particularly evident in the Matthews Correlation Coefficient (MCC), where the average values increased from 0.61 to 0.86, underscoring the reliability and informativeness of the predictions. Sensitivity (Se) also improved significantly, with average values rising from 0.65 to 0.83, indicating that the models retained their ability to correctly identify cytotoxic compounds despite the increased under-sampling. These results, detailed in Table 1, support the decision to adopt the 1:5 ratio in Cyto-Safe’s back-end prediction algorithm.

The t-SNE plots for each balanced approach (see Supporting Information) reflect the statistical improvements observed with a 1:5 ratio compared to both the 1:1 ratio and the unbalanced set. Unlike the 1:1 ratio, which excludes highly similar compounds and risks misleading predictions, the 1:5 ratio better captures the chemical space of the original unbalanced data set.

Moreover, we applied the Y-randomization method to determine if the correlations identified by the model between molecular fragments and cytotoxic effects are genuine or simply artifacts of random associations. As a result of the 50 rounds on each data set, we observed an average ACC of 0.5 for both data sets and MCC of 0.02 and 0.01 for 3T3 and HEK 293, respectively, confirming the robustness of the models.

## Section: Results and Discussion › Usability

As mentioned previously, users can easily draw a molecule for testing or upload a batch of molecules for prediction using a CSV or SDF file, with a limit of ten SMILES per request. The results are displayed in a list format for each model (3T3 and HEK 293), indicating whether each molecule is predicted to be toxic or nontoxic. Additionally, the predicted probabilities (representing the model’s confidence) are provided as percentages, calculated using the predict_proba method from the LightGBM library. A dedicated button also allows users to initiate Explainable Artificial Intelligence (XAI) analysis (Figure 1).

Furthermore, in accordance with the best practices established by the Organization for Economic Co-operation and Development (OECD),16 we have defined the applicability domain of the model’s predictions to ensure their reliability. The threshold was set at 0.09, corresponding to the fifth percentile of the Tanimoto similarity distribution among compounds in the training set.21 This relatively low threshold reflects the high structural diversity within the training set. A similarity distribution analysis is provided in Figure S3 (Supporting Information). The information regarding whether the tested compound is within or outside the applicability domain is available on the prediction results page, helping users understand the limitations of the model’s outputs.

General scheme of usage, outcome and XAI of Cyto-Safe web app.

## Section: Results and Discussion › Explainable AI (XAI) with Molecular Diagrams and Heatmaps

Cyto-Safe 1.0 is equipped with explainable AI molecular diagrams and heatmaps to help users better understand the model’s output. The molecular diagram displays the molecule contoured in either red or green, where red represents a strong influence on the model’s prediction of “cytotoxic” and green indicates a strong influence on the prediction of “non-cytotoxic.” As a case study, we evaluated the structures of two established drugs: Doxorubicin, a well-known chemotherapeutic agent with a cytotoxic mechanism of action, and Ibuprofen, a widely used nonsteroidal anti-inflammatory drug. Importantly, neither of these molecules was included in the training sets for the models.

Both models classified Doxorubicin as “cytotoxic,” as anticipated, and the molecular diagram reinforced this classification by coloring almost the entire molecule in red in both predictions. In contrast, Ibuprofen was classified as “non-cytotoxic,” with its molecular diagram predominantly highlighted in green, indicating the model’s strong confidence in this prediction (Figure 2). This concordance between the molecular diagrams and the known pharmacological profiles of these compounds underscores the robustness and interpretability of the models.

The atom influence is further illustrated in heatmaps provided in Figures S4–S7 (Supporting Information). These heatmaps employ the same color coding, with red contours indicating atoms that have a strong influence on the model’s prediction of cytotoxicity and green contours representing atoms that have strong influence on the prediction of noncytotoxicity. The intensity of the color contours reflects the strength of the influence, providing users with a detailed understanding of the factors affecting the model’s predictions at both the fragment and atom levels.

The XAI feature of Cyto-Safe is essential for understanding the underlying mechanisms of both models’ predictions. By offering molecular diagrams and atom-wise heatmaps, it identifies specific molecular regions that contribute to either “cytotoxic” or “non-cytotoxic” outcomes. This capability allows users to analyze structural fragments influencing toxicity, facilitating applications in drug design, safety assessments, and compound optimization.

Explainable AI (XAI) molecular diagrams illustrating the model’s predictions for Doxorubicin on the 3T3 (A) and HEK-293 (B) models, and for Ibuprofen on the 3T3 (C) and HEK-293 (D) models. Red contoured regions highlight areas with a strong positive influence on predicted cytotoxicity, whereas green contoured regions indicate a strong positive influence on predicted nontoxicity. The intensity of the contour colors reflects the magnitude of their influence, with darker shades representing a greater impact on the model’s predictions.

## Section: Results and Discussion › Limitations

It is important to mention that the Cyto-Safe 1.0, developed to predict cytotoxicity using data from 3T3 and HEK 293 cell lines with the CellTiter-Glo assay, has limitations related to data set characteristics and generalizability. The reliance on only two cell lines - 3T3 (derived from mouse fibroblasts) and HEK 293 (from human embryonic kidney cells) - restricts the model’s applicability to other biological contexts, as these cell lines may not accurately reflect the behaviors of a broader range of cell types. Furthermore, variations in cytotoxicity responses among different cell types - including differences between permanent cell lines and primary cells - underscore the necessity of considering cell type-specific nuances when interpreting cytotoxicity data.22

In addition to the cell line limitations, the specificity of the CellTiter-Glo assay complicates the model’s predictions. Different cytotoxicity assays, such as Lactate Dehydrogenase (LDH) release and MTT reduction, may detect varying aspects of cell viability, leading to divergent toxicological profiles. Additionally, variability in experimental conditions - such as cell density, culture medium, and incubation durations - further impacts reproducibility and the model’s reliability across different settings.23 The model’s training data are confined to specific incubation times, limiting its applicability for different exposure durations. To enhance the model’s robustness and generalizability, it would be necessary to incorporate a more diverse range of data sets, expanding beyond the current parameters under which it was developed.24 Until such advancements are made, users should approach the model’s predictions with a clear understanding of these constraints.

## Section: Results and Discussion › Comparative Analysis of QSAR Models for Cytotoxicity Prediction

Numerous QSAR models have been developed to predict cytotoxicity, each offering distinct strengths and facing particular challenges. Langdon et al.25 employed Bayesian models to achieve cross-assay predictivity; however, the reliance on heterogeneous assay data introduces variability, potentially affecting the consistency and reliability of predictions, and their models lack an interpretability feature.

ProTox 3.026 excels in providing multiend point toxicity predictions by leveraging molecular similarity and machine learning. Its computational efficiency makes it suitable for large-scale screening. However, the model operates as a black box, limiting interpretability and hindering its application in guiding molecular modifications. Yin et al.27 addressed the challenge of imbalanced data sets by implementing ensemble learning methods, which deliver strong predictive performance. Despite this, these models are not openly available to the community.

Other notable contributions include the work by Liu et al.,28 which focused on predicting microglial cytotoxicity using machine learning models integrated with feature selection and Shapley Additive Explanations. This method provided detailed substructure-level insights, enabling a deeper understanding of toxicological mechanisms. However, its requirement for local installation and computational skills limits its accessibility to users without a strong technical background, and it is limited by only predicting microglial cytotoxicity.

Sun et al.29 constructed predictive models based on multiple cell lines using support vector machines (SVMs). While these models achieved high predictive accuracy, they lack an explainable AI feature. Webel et al.30 explored the use of deep learning to identify cytotoxic substructures, offering mechanistic insights via Deep Taylor Decomposition. Although their work is promising, it remains exploratory and does not provide a readily available tool for broader use.

Cyto-Safe offers a distinctive approach by integrating prediction accuracy with interpretability and accessibility. Its web-based interface eliminates the need for installations, allowing users from diverse backgrounds to easily conduct predictive analyses. Moreover, Cyto-Safe incorporates Explainable AI (XAI), which generates atom-level heatmaps that elucidate the structural features contributing to toxicity predictions. This transparency not only enhances user confidence but also provides valuable guidance for structural optimization. By supporting multiple data input formats, Cyto-Safe ensures a streamlined experience, catering to both expert and nonexpert users.

In summary, Cyto-Safe bridges the gap between advanced predictive capabilities and practical usability, offering a comprehensive solution for cytotoxicity prediction while addressing the interpretability and accessibility limitations of existing models.

## Section: Conclusions

The Cyto-Safe web application demonstrates substantial efficacy in the binary classification of compounds based on cytotoxicity assessments in 3T3 and HEK 293 cells. Cyto-Safe is distinguished by its user-friendly interface, requiring no programming expertise, and its readiness for immediate deployment. Additionally, it offers transparent explanations of prediction outcomes, representing a significant advancement in the accessibility and usability of cytotoxicity assessment tools. The ongoing development of Cyto-Safe will include the expansion of predictive capabilities to encompass additional cell lines as new, high-quality data becomes available.

However, it is important to recognize the limitations of the model’s predictive capabilities, as they are influenced by the specific experimental conditions used during training. The reliance on 3T3 and HEK 293 cell lines, along with defined incubation times, restricts the model’s generalizability to other cell lines, assays, and exposure durations. To improve its robustness and generalizability, the model should be expanded to include a broader range of data sets, cell lines, assays, and incubation times.

In conclusion, Cyto-Safe is a valuable resource for both the scientific community and industry, facilitating the toxicity evaluation of drug candidates. The tool is freely accessible at http://insightai.labmol.com.br/, enabling users to leverage its capabilities to optimize drug development processes.


---

# Deep learning for low-data drug discovery: Hurdles and opportunities

- **Authors:** Derek van Tilborg, Helena Brinkmann, Emanuele Criscuolo, Luke Rossen, Rıza Özçelik, Francesca Grisoni
- **Issuer:** Current opinion in structural biology
- **Type:** Scientific article
- **Published:** 2024-04-25
- **Language:** en
- **DOI:** 10.1016/j.sbi.2024.102818
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38669740/
- **Licence:** CC-BY

## Section: Abstract

Deep learning is becoming increasingly relevant in drug discovery, from de novo design to protein structure prediction and synthesis planning. However, it is often challenged by the small data regimes typical of certain drug discovery tasks. In such scenarios, deep learning approaches-which are notoriously 'data-hungry'-might fail to live up to their promise. Developing novel approaches to leverage the power of deep learning in low-data scenarios is sparking great attention, and future developments are expected to propel the field further. This mini-review provides an overview of recent low-data-learning approaches in drug discovery, analyzing their hurdles and advantages. Finally, we venture to provide a forecast of future research directions in low-data learning for drug discovery.


---

# DigFrag as a digital fragmentation method used for artificial intelligence-based drug design

- **Authors:** Ruoqi Yang, Hao Zhou, Fan Wang, Guangfu Yang
- **Issuer:** Communications chemistry
- **Type:** Scientific article
- **Published:** 2024-11-11
- **Language:** en
- **DOI:** 10.1038/s42004-024-01346-5
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39528759/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractFragment-Based Drug Design (FBDD) plays a pivotal role in the field of drug discovery and development. The construction of high-quality fragment libraries is a critical step in FBDD. Conventional fragmentation approaches often rely on rigid rules and chemical intuition, limiting their adaptability to diverse molecular structures. The rapid development of Artificial Intelligence (AI) technology offers a transformative opportunity to rethink traditional methods. Here, we present DigFrag, a digital fragmentation method that highlights important substructures by focusing locally within the molecular graph. In addition, we feed the fragments segmented by machine intelligence and human expertise into the deep generative model to compare the preference for data from different sources. Experimental results show that the structural diversity of fragments segmented by DigFrag is higher, and more desirable compounds are generated based on these fragments. These results also demonstrate that data generated based on AI methods may be more suitable for AI models. Moreover, a user-friendly platform called MolFrag (https://dpai.ccnu.edu.cn/MolFrag/) is developed based on various fragmentation techniques to support molecular segmentation.Subject terms: Virtual screening, Cheminformatics, Computational chemistry

## Section: Introduction

Fragment-based drug design (FBDD) is the process of screening for favorable fragments and combining them to create drug molecules1,2. Compared to traditional high-throughput screening methods, FBDD allows the exploration of a much broader chemical space and the discovery of active compounds with a higher hit rate3. A high-quality fragment library is a prerequisite for FBDD. Typically, the segmentation of a molecule in accordance with predefined guidelines stands as a highly effective means of obtaining these structural fragments, and is of paramount importance in the field of FBDD4. However, it is noteworthy that few innovative studies on fragmentation methods have been reported. Conventional fragmentation methods, exemplified by the likes of RECAP5 and BRICS6, predominantly hinge on the principles of retrosynthesis, where a set of rules govern the breaking of chemical bonds, often emphasizing the selective cleavage of acyclic bonds. As eloquently elucidated by Diao et al., this restriction has its rationale, but it greatly reduces the novelty of the obtained fragments, especially for macrocyclic compounds7,8. Furthermore, these methods do not allow a reasonable selection of fragment size. To elaborate, the diminution of fragment size to an extreme extent may inadvertently disrupt the pharmacophores, while an excessively large fragment may not efficiently extract smaller substituents9.

Over the past decade, artificial intelligence (AI) technologies have achieved great success in many fields. With the increasing abundance of biomedical data, many AI-driven predictive models have been introduced into the field of drug discovery and development, including convolutional neural networks (CNNs)10, recurrent neural networks (RNNs)11, and graph neural networks (GNNs)12. In particular, GNNs consider the input molecules as graphs with attributes, and obtain graph embeddings through the three steps of message passing, aggregation, and updating13. Studies have shown that the attention mechanism serves to improve both the efficiency and accuracy of the model by directing its focus towards feature information that is more relevant to the given task14,15. Combining attention mechanisms with GNNs can better reveal the relative importance of structural fragments within a compound.

Typically, chemists with extensive expertise segment molecules based on chemical rules. In contrast, machine intelligence-oriented perspective, while lacking domain knowledge, provide a distinctive paradigm by segmenting molecules based on mathematical logic (i.e., statistics). Through a comparative analysis of these fragmentation methods, our investigation illuminates that AI-based models segments unique fragments that are feasible in the virtual world but may not be applicable in the real world. This discrepancy between reality and virtuality underscores the intrinsic advantage of AI-based methods, as they enable the exploration of uncharted territories and overcome the limitations of traditional methods. Consequently, the potential of AI to transcend the boundaries of established chemical paradigms becomes manifest, opening frontiers in the field of molecular segmentation.

On this basis, we propose DigFrag, a digital fragmentation method based on the graph attention mechanism, which gets rid of the constraints of traditional chemical rules and segments drug/pesticide molecules with attention weights (i.e., contribution to the prediction task) oriented to ultimately obtain the drug/pesticide-like fragments from the perspective of machine intelligence rather than human expertise. Comparison results show that the structural diversity of the fragments segmented by DigFrag is higher. In addition, the application of these fragments to deep generative models yields desirable compounds, highlighting the potential of DigFrag in FBDD. The scheme of this work is depicted in Fig. 1. We believe that DigFrag is a more applicable fragmentation method for AI drug discovery.

A Flowchart of molecular fragmentation using the DigFrag method. B Framework of actor-critic model applied to a fragmented molecule. C Establishment of an online platform to facilitate researchers.

## Section: Results

Average properties of drug fragments segmented by the four methods (BRICS, RECAP, MacFrag and DigFrag)

Average properties of pesticide fragments segmented by the four methods (BRICS, RECAP, MacFrag and DigFrag)

A Similarity cutoff = 0.2. B Similarity cutoff = 0.4. C Similarity cutoff = 0.6. D Similarity cutoff = 0.8. Each type of fragment was obtained by the four methods (BRICS, RECAP, MacFarg and DigFrag), respectively.

Performance evaluation of different metrics for the generated drug molecules using the four fragment-based deep generative models

Performance evaluation of different metrics for the generated pesticide molecules using the four fragment-based deep generative models

A, C Distributions of Quantitative Estimation of Drug-likeness (QED) for the generated drug molecules and pesticide molecules. B, D Distributions of Synthetic Accessibility (SA) for the generated drug molecules and pesticide molecules.

Four desirable molecules are shown in green, yellow, blue and pink stick form and yellow dashed lines are hydrogen bonds.

Four desirable molecules are shown in green, yellow, blue and pink stick form and yellow dashed lines are hydrogen bonds.

A Different fragmentation methods are available to users to segment the uploaded molecules. If users have no data, MolFrag provides FDA-approved drugs and commercial pesticides. B In the jobs page, users can view the fragment information obtained after segmentation of the molecules, including physicochemical property, drug/pesticide-like evaluation and synthetic accessibility.

## Section: Results › Comparison of the property distributions of segmented fragments

Prior to comparison, we trained the models to segment drug/pesticide fragments. The results of the five-fold cross-validation are presented in Supplementary Table 1. It can be seen that these models demonstrated excellent and robust performance across the three key metrics, with accuracy, area under the curve (AUC), and Matthews correlation coefficient (MCC) exceeding 0.90, 0.96, and 0.80, respectively.

Next, we conducted an in-depth evaluation of the fragments obtained by the proposed method (DigFrag), the conventional methods (RECAP5 and BRICS6), and the latest method (MacFrag8), focusing on the property distributions as a critical metric of comparison. As shown in Table 1 and Supplementary Fig. 1, for drug fragments, the DigFrag fragments were much closer to the BRICS fragments in terms of property distributions. For example, the differences in molecular weight and the number of hydrogen bond acceptors between the two groups of fragments were not significant. Interestingly, we found that the DigFrag fragments had a significantly higher number of rotatable bonds compared to the BRICS fragments, which may be attributed to their unique cleavage of cyclic bonds. However, for pesticide fragments, the properties of the DigFrag fragments were distributed in lower regions (Table 2 and Supplementary Fig. 2). Taking molecular weight as an example, the average molecular weight of DigFrag fragments was 137.07, signifying a substantial reduction in comparison with the other three fragments. It should be noted that all properties of the DigFrag fragments showed a similar trend, whether they were drugs or pesticides. In addition, we calculated the number of fragments obtained following the segmentation of each drug/pesticide molecule by the four methods. As shown in Supplementary Fig. 3, none of these methods, except MacFrag, segmented the molecule into more than 20 fragments. In terms of distributions, DigFrag displayed greater similarity to BRICS, and both methods tended to segment smaller fragments.

Average properties of drug fragments segmented by the four methods (BRICS, RECAP, MacFrag and DigFrag)

Average properties of pesticide fragments segmented by the four methods (BRICS, RECAP, MacFrag and DigFrag)

## Section: Results › Comparison of the structural diversity of segmented fragments

We then performed a rigorous analysis of the four methods, with a primary focus on the structural diversity of the segmented fragments. As shown in Supplementary Table 2, our findings demonstrated a remarkable disparity. Specifically, for both drugs and pesticides, the number of duplicates between the fragments segmented by the DigFrag method and the other three methods was low (9.97–21.37% for drugs and 8.94–15.20% for pesticides). In contrast, the fragments segmented by the MacFrag method almost covered the BRICS fragments (96.42% for drugs and 99.05% for pesticides) and the RECAP fragments (76.59% for drugs and 76.31% for pesticides). This suggests that the MacFrag method is only an extension of the conventional methods, while the proposed DigFrag method is able to obtain more unique fragments. In addition, we counted the occurrence numbers of each fragment in the four fragmentation methods and visualized their spatial distribution using the t-distributed Stochastic Neighbor Embedding (t-SNE) algorithm. As illustrated in Supplementary Figs. 4–5, over 75% of the drug/pesticide fragments occurred in only one method. The proportion of drug/pesticide fragments shared by two methods (mainly MacFrag) was approximately 20%, while less than 5% of the remaining fragments occurred in three or four methods. It is noteworthy that despite the small number of fragments shared by the four methods, these had a more dispersed distribution in chemical space compared to the fragments shared by the three methods.

To provide a more comprehensive insight into the assessment of structural diversity, we employed the fragment cluster ratio as a quantitative measure, which provides a more intuitive reflection of the overall structural diversity within the fragment sets. As shown in Fig. 2 and Supplementary Tables 3–4, the DigFrag method consistently yielded higher fragment cluster ratios than other methods. In particular, for the most commonly used similarity thresholds (0.4 and 0.6), the fragments segmented by the DigFrag method exhibited greater structural diversity.

A Similarity cutoff = 0.2. B Similarity cutoff = 0.4. C Similarity cutoff = 0.6. D Similarity cutoff = 0.8. Each type of fragment was obtained by the four methods (BRICS, RECAP, MacFarg and DigFrag), respectively.

## Section: Results › Comparison of the qualities of generated molecules

Subsequently, we conducted a comparative analysis of generative models utilizing distinct sets of fragments on the MOSES benchmarking platform16. As shown in Tables 3–4, the drug molecules generated by the MacFrag-based model achieved optimal results in terms of uniqueness and diversity, but the Filters score was significantly lower than that of the other models, which suggests that these compounds are unsatisfactory in terms of safety. In contrast, the Filters score of the drug molecules generated by the DigFrag-based model was 0.828, indicating the improved safety of compounds modified by digital fragments compared to other fragments. We speculate that this observed superiority may be attributed to the inherent capacity of deep learning models to incorporate considerations of toxicity risk, stability, and other pertinent factors during the fragmentation process, which is not possible with the other three methods. Similarly, except for a slightly higher proportion of duplications, the pesticide molecules generated by the DigFrag-based model achieved superior performance in terms of SMILES validity, novelty, scaffold diversity, and structure alerts. Moreover, an examination of the average Quantitative Estimation of Drug-likeness (QED)17 and Synthetic Accessibility (SA)18 revealed that drug/pesticide molecules generated by the DigFrag-based model outperformed those generated by the other models, as illustrated in Fig. 3. To quantitatively compare the similarity between the property distributions of the generated molecules and the MOSES dataset, the Wasserstein-1 distance provided by the platform was utilized. As shown in Supplementary Tables 5–6, the drug/pesticide molecules generated by the DigFrag model exhibited the highest similarity in terms of three property distributions (molecular weight, QED, and SA). Taken together, these results demonstrate that FBDD employing DigFrag fragments yields molecules of higher quality. Furthermore, the findings suggest a preference within AI-based models for AI-sourced data, reinforcing the potential advantages of leveraging AI in molecular design.

Performance evaluation of different metrics for the generated drug molecules using the four fragment-based deep generative models

Performance evaluation of different metrics for the generated pesticide molecules using the four fragment-based deep generative models

A, C Distributions of Quantitative Estimation of Drug-likeness (QED) for the generated drug molecules and pesticide molecules. B, D Distributions of Synthetic Accessibility (SA) for the generated drug molecules and pesticide molecules.

## Section: Results › Binding affinity calculation of generated molecules to specific targets

Considering that the DeepFMPO architecture does not incorporate information about the target during the optimization of molecular structures, we performed molecular docking to assess the binding strength of the modified drug/pesticide molecules to the dopamine receptor D2 (DRD2)/4-hydroxyphenylpyruvate dioxygenase (HPPD). As anticipated, marginal disparities in binding affinity were observed between the drug/pesticide molecules generated by the four methods. Specifically, the binding free energy ranges of the generated compounds were −9.16 to −9.36 Kcal/mol (DRD2) and −8.37 to −8.53 Kcal/mol (HPPD), respectively (Supplementary Fig. 6). It is noteworthy that, despite the lack of a pronounced advantage for the drug/pesticide molecules generated by the DigFrag method, they manifested an acceptable level of binding to the corresponding targets, indicating the preservation of desired properties and high affinities.

## Section: Results › Binding mode analysis of selected molecules to specific targets

Through the application of refined filters, we identified 24 desirable drug molecules and 20 desirable pesticide molecules that satisfy QED values greater than 0.75, SA values less than 3, and binding free energies less than the positive drug Domperidone (−10.7 Kcal/mol)19/positive pesticide Mesotrione (−8.4 Kcal/mol)20. The chemical structures of these selected molecules are presented in Supplementary Figs. 7–8. Subsequently, an in-depth analysis of the interaction between several desirable drug/pesticide molecules and the corresponding targets was performed. As shown in Figs. 4–5, all drug ligands were effectively docked into the active pocket of DRD2 and formed hydrogen bonds with amino acid residues SER-193, TYR-416, THR-119, VAL-115, TRP-413, and GLU-95. Similarly, all pesticide ligands were stably bound to HPPD through hydrogen bonding interactions with amino acid residues SER-65, SER328, ASP-211, ASP-387, TYR-88, TYR-103, and LEU-78. Intriguingly, the generated compounds exhibited a distinct binding mode compared to the positive drug, suggesting a potential pharmacological mechanism that warrants further exploration in future investigations.

Four desirable molecules are shown in green, yellow, blue and pink stick form and yellow dashed lines are hydrogen bonds.

Four desirable molecules are shown in green, yellow, blue and pink stick form and yellow dashed lines are hydrogen bonds.

## Section: Results › Web server construction and application

Although several fragmentation methods have been reported, no easy-to-use web server is available. Therefore, an innovative platform called MolFrag (https://dpai.ccnu.edu.cn/MolFrag/) was constructed that seamlessly combines four molecular fragmentation approaches, ensuring accessibility to researchers with varying levels of expertise (Fig. 6). We believe that the application of MolFrag streamlines the process of molecular segmentation, making it an invaluable resource for the scientific community.

A Different fragmentation methods are available to users to segment the uploaded molecules. If users have no data, MolFrag provides FDA-approved drugs and commercial pesticides. B In the jobs page, users can view the fragment information obtained after segmentation of the molecules, including physicochemical property, drug/pesticide-like evaluation and synthetic accessibility.

## Section: Discussion

In recent years, the field of drug discovery and development has been profoundly revolutionized by advances in AI technology10–12. In this work, we introduced DigFrag, an intuitive fragmentation method that segments molecular structures based on AI-driven models, thereby circumventing the constraints inherent in traditional bond-breaking rules. We comprehensively compared the fragments obtained by machine intelligence with those obtained by human expertise. The results demonstrate the superior efficacy of DigFrag in the segmentation of diverse molecular fragments. Furthermore, we fed two initial sets of compounds with the four sets of drug/pesticide fragments into an existing deep generative model. The outcomes of this experiment exhibited the propensity of the DigFrag-derived model to generate molecules characterized by desired properties, thereby substantiating that AI-based models may be more compatible with AI-sourced data.

When we review conventional fragmentation methods, it becomes evident that they are limited in certain contexts. Chemists have successfully refined these methods through extensive experience and domain knowledge. However, in the evolving scientific environment, we are faced with increasingly complex molecular systems. Therefore, we want to explore how we can leverage the power of AI to drive the evolution of molecular fragmentation methods. In addition, we focus not only on the limitations of traditional methods, but also on the differences in data adaptability between machine intelligence and human expertise.

In the FBDD study, we integrated the fragments segmented by the four methods (BRICS, RECAP, MacFrag and DigFrag) into the DeepFMPO framework. To our surprise, AI-based models appeared to be more effective in utilizing the data derived from AI-based methods, and the generated molecules exhibited remarkable excellence in most of the evaluation metrics. Moreover, conventional fragmentation methods tended to ignore target-related information, while DigFrag was able to incorporate this information, which facilitated the segmentation of the same molecular entities into distinct fragments, thereby leading to more personalized molecular design.

However, it is imperative to acknowledge that there is discernible room for improvement within the proposed method. Firstly, an important direction for future research lies in conducting a comprehensive investigation to explore the underlying reasons why data from AI-based methods exhibit increased compatibility with AI-based models. Secondly, recognizing the limitations associated with the two-dimensional graph, which inherently neglects the geometric space of compounds, we aspire to segment molecules based on the three-dimensional graph. This endeavor is expected to yield richer conformational information about the fragments. Furthermore, since the development of fragment-based deep generative models is still in its infancy, we are committed to developing more deep learning frameworks for specific targets, thus expanding the practical application of this method.

Overall, our findings demonstrate that data generated based on AI methods may be more applicable to AI models. We strongly believe that this idea establishes a versatile research paradigm with far-reaching implications in various scientific domains (e.g., materials). For future work, we will strive to extend this idea to a broader range of subtasks, thereby generating more expansive data available for AI-based model exploitation.

## Section: Methods › Dataset curation

The modeling dataset utilized in this study was sourced from our self-constructed database called PADFrag21. This database primarily contains 1652 United States Food and Drug Administration (FDA)-approved drugs cataloged in DrugBank and 1259 commercial pesticides listed in Alan Wood. To improve data consistency, structurally non-standard compounds were systematically excluded. The dataset was then partitioned into distinct subsets for the purposes of training, validation, and testing in an 8:1:1 ratio.

## Section: Methods › AI-based fragmentation method › Construction of molecular graph

In the field of drug discovery and development, GNN-based architectures have been shown to achieve excellent predictive performance for various subtasks12,22. The molecular graph, serving as the input representation of GNNs, is defined as G = (V, E), where V stands for nodes (atoms) and E stands for connecting edges (chemical bonds). In this work, the featurization of these elements was executed using the AttentiveFPAtomFeaturizer and AttentiveFPBondFeaturizer modules of the open-source toolkit DGL-LifeSci23 (Supplementary Table 7).

## Section: Methods › AI-based fragmentation method › Model architecture

In this study, we employed the AttentiveFP framework introduced by Xiong et al. to capture the structural information of molecules24. This architecture represents a feature extraction network based on the graph attention mechanism. Specifically, the original molecular graph is initially fed into a series of attention layers to obtain individual atomic embeddings. Subsequently, these embeddings are combined into a unified vector, commonly referred to as a super node. Finally, the entire molecular embedding is obtained through multiple attention layers. It is noteworthy that the attention layer consists of two essential components: the aggregation module (Eqs. 1–3) based on the attention mechanism and the update module (Eqs. 4–5) based on the gated recurrent unit (GRU).

where hv and hu represent the vector of node v and the neighbor node u, and W is a trainable weight matrix.

where k represent iteration number, and M is the message function.

## Section: Methods › AI-based fragmentation method › Segmentation of molecules

Considering the latent relationship between structural fragments and drug/pesticide-likeness, DigFrag was used to leverage the graph attention mechanism to segment the molecular graph into subgraphs of different sizes (i.e., structural fragments). Consecutively, the fragments with relatively diminished relevance were filtered out by setting an attention weight threshold, while the fragments closely related to the drug/pesticide-likeness were retained. Moreover, the conventional fragmentation method (BRICS and RECAP) was implemented in RDKit, and the latest fragmentation method (MacFrag) was implemented through the source code released by the authors.

## Section: Methods › Comparative analysis of the fragments obtained by the four methods

In the present study, we conducted a comparative assessment of segmented fragments from two aspects. At the structural level, we generated the corresponding Morgan fingerprint for each fragment using the GetMorganFingerprintAsBitVect module of RDKit. For a more rigorous quantitative evaluation, we executed Butina clustering based on the Tanimoto Coefficient25 for distinct groups of fragments using the BulkTanimotoSimilarity and ClusterData modules of RDKit and then calculated the fragment cluster ratio, which is denoted as the ratio of fragment clusters to the total number of fragments. Higher values of this metric indicate greater diversity in the structural landscape. At the property level, we used the open-source software PaDEL-Descriptor26 to calculate several attributes related to the drug/pesticide-likeness rules, including molecular weight, LogP, topological polar surface area, number of hydrogen bond donors, number of hydrogen bond acceptors, number of rotatable bonds27,28. It should be noted that the calculation of fingerprints and attributes did not consider the breaking position of the fragments, mainly due to the fact that these representations are not relevant to the broken bond information.

## Section: Methods › Fragment-based molecular generation

To further elucidate the influence of digital and traditional fragments on fragment-based deep generative models, we undertook an investigation utilizing the DeepFMPO29 architecture developed by Ståhl et al. with a specific focus on its application in de novo drug design. DeepFMPO is an actor-critic reinforcement learning model that acquires the ability to generate compounds with desired properties by replacing fragments within a compound. Therefore, the generation of molecules using DeepFMPO requires a balanced binary tree library and an initial set of lead molecules. In this study, the former are the fragments segmented by different methods, and the latter are the molecules collected from the ChEMBL database30 that did not fulfill the sweet spot criteria (561 molecules for DRD2 and 221 molecules for HPPD). The model architecture used a bidirectional long short-term memory (LSTM) network, with the number of neurons in the hidden layer being 128, 64, and 32, respectively. The learning rate and batch size were set to 1e-4 and 512, respectively. Model training was executed until 4000 epochs were reached, after which all molecules generated in the last 100 epochs were compiled and a random selection of 1000 molecules was sampled as representatives for subsequent analysis. Performance evaluation of each model was conducted on the MOSES benchmarking platform16.

## Section: Methods › Molecular docking of the generated molecules

Docking studies were performed to assess the protein-ligand binding affinity of representative molecules with DRD2 (drug) and HPPD (pesticide). The three-dimensional structures of the targets were obtained from the Protein Data Bank database31 (ID: 6CM432 and 5YWG33) and subsequently subjected to dehydration, hydrogenation, and charge calculation using AutoDockTools software. The three-dimensional structures of representative drug/pesticide molecules were constructed using ChemOffice software34. Binding free energy calculations were performed using Autodock Vina software35. Furthermore, the visualization of protein-ligand interactions was achieved through the utilization of PyMOL software36.

## Section: Supplementary information

Supplementary Information

Description of Additional Supplementary Files

Supplementary Data 1

## Section: Acknowledgements

This work is supported by the National Key Research and Development Program of China (2023YFD1700500) and the National Natural Science Foundation of China (No. 21837001).

## Section: Author contributions

F.W. and G.Y. conceived the project. R.Y. and H.Z. performed the computational experiments. F.W. and R.Y. collected and analyzed the data. R.Y. wrote the manuscript. F.W. and G.Y. provided evaluation and suggestions.

## Section: Peer review › Peer review information

Communications Chemistry thanks the anonymous reviewers for their contribution to the peer review of this work.

## Section: Data availability

The data required to reproduce our results are available at 10.5281/zenodo.13997755. The numerical source data of main figures are available in Supplementary Data 1. All other data are available from the corresponding authors upon reasonable request.

## Section: Code availability

The source code implemented in this study is available at https://github.com/yang1rq/MolFrag.

## Section: Competing interests

The authors declare no competing interests.

## Section: Contributor Information

Fan Wang, Email: fwang@ccnu.edu.cn.

Guangfu Yang, Email: gfyang@ccnu.edu.cn.

## Section: Supplementary information

The online version contains supplementary material available at 10.1038/s42004-024-01346-5.

## Section: Associated Data

Supplementary Information

Description of Additional Supplementary Files

Supplementary Data 1

## Section: Associated Data › Supplementary Materials

Supplementary Information

Description of Additional Supplementary Files

Supplementary Data 1

## Section: Associated Data › Data Availability Statement

The data required to reproduce our results are available at 10.5281/zenodo.13997755. The numerical source data of main figures are available in Supplementary Data 1. All other data are available from the corresponding authors upon reasonable request.

The source code implemented in this study is available at https://github.com/yang1rq/MolFrag.


---

# Does artificial intelligence need companionship to assist in drug discovery? The Kirsten rat sarcoma virus study

- **Authors:** Mourad Stitou, John M Koomen, Denis J Imbody, Yi Liao, Andrii Monastyrskyi, Uwe Rix, Derek R Duckett, Eric B Haura, Aleksandra Karolak
- **Issuer:** BJR artificial intelligence
- **Type:** Scientific article
- **Published:** 2024-03-04
- **Language:** en
- **DOI:** 10.1093/bjrai/ubae001
- **Source:** https://pubmed.ncbi.nlm.nih.gov/42064400/
- **Licence:** CC-BY

## Section: Abstract

AbstractIn this Opinion article, we confront the role of artificial intelligence (AI) in targeting and understanding resistance to targeted therapy using the most frequently mutated oncoprotein family in human cancer, rat sarcoma virus guanosine triphosphate hydrolases (RAS GTPases), here Kirsten RAS (KRAS), as an example. Aberrant regulation of the active GTP-bound state of KRAS is associated with tumourigenesis, aggressive disease, and poor prognosis. KRAS mutations (eg, G12C, G12D, G12V, G13D, inter al.) are drivers of numerous cancer types, including non-small cell lung, colorectal, and pancreatic cancers. These mutations have shown to play a significant role in cell behaviour and response to treatment. Since its discovery in the 1980s, it has been recognized that over-expression of KRAS and other RAS family members induces resistance to radiotherapy. Moreover, over the years preclinical and clinical studies showed that tumours with KRAS mutations exhibit different treatment sensitivities compared to tumours with wild-type KRAS.Keywords: AI, drug discovery, fragment-based drug discovery, acquired resistance

## Section: The conventional wisdom of undruggable KRAS

Until this decade, KRAS was considered undruggable.1,2 The featureless character of KRAS at the molecular level including smooth and spherical shape and lack of evident binding sites or pockets stalled many research initiatives. KRAS acts as guanine diphosphate/triphosphate GDP/GTP switch responsible for signal transduction between activated receptors on the membrane and cellular components.3 GTP binding induces conformational change that triggers KRAS activation, while KRAS mutations lock the mutant in its active GTP-bound state.4 Therefore, higher cellular concentrations of GTP over GDP, higher (picomolar) affinity of KRAS towards GTP, and altered off-rates of KRAS mutants towards GTP increased the ‘drugging challenge’.3–5

## Section: The promising prospects

With the development of KRAS G12C small molecule irreversible inhibitors, overcoming these challenges became a reality.6 In 2021, the Food and Drug Administration (FDA) approved AMG510 (sotorasib),7 an allele-specific covalent inhibitor of the KRAS G12C mutant. MRTX849 (adagrasib, approved in 20228) displayed clinical responses across multiple tumour types and showed promising activity against cancers harbouring this KRAS mutation. Unfortunately, tumours with KRAS mutations eventually develop resistance to monotherapy following either ‘on-target’ or ‘off-target’ resistance mechanisms. The ‘on-target’ resistance is characterized by secondary KRAS mutations affecting binding of the inhibitor, while other isoforms of KRAS or MAPK signalling pathway members become activated in the ‘off-target’ resistance.4 Several KRAS secondary mutations might interfere with key protein-drug interactions (eg, Y96D, Y96C) and trigger resistance to KRAS G12C inhibitors.1,9 Even though a distinct KRAS G12C active-state inhibitor, RM-018, demonstrated the ability to overcome resistance by targeting KRAS G12C/Y96D double mutation in the binding sites10 (other tricomplex inhibitors targeting KRAS G12C are now in clinical trials11), such development of novel mutations following treatment or radiotherapy presents an even more formidable challenge.

To address the challenges posed by resistance to first-generation KRAS monotherapy by acquired KRAS mutations, researchers have been actively exploring various possibilities and therapies that could advance KRAS targeting either through development of optimized drugs or radiation. Current leading strategies to sensitize tumours to radiation and enhancement of treatment efficacy focus on combined therapies targeting signalling pathways of mutated KRAS;12 however, it remains unclear whether the combination therapies will work in patients.

## Section: Call for cross-disciplinary collaborations

In our opinion, understanding the mechanisms and dynamics of specific KRAS mutations is the key to (i) guide treatment decisions in chemotherapy, targeted therapy, and radiation oncology, (ii) predict secondary mutational processes that may appear, and (iii) develop strategies to overcome the resulting drug resistance. However, no progress can be made without cross-disciplinary collaborative initiatives that integrate various scientific perspectives, including structural biology, functional genomics, and pharmacology. Despite constraints of limited data and bottlenecks of high-throughput screening (HTS)13 (eg, target validation, candidate optimization, and constraints in experimental testing), recent artificial intelligence (AI)-based studies present promising opportunities to transform drug discovery14 with several examples reaching clinical testing (NCT05154240 and published studies15,16). AI techniques can learn and self-correct, improving their performance with each new dataset. As AI technologies gain experience, the quality of the data used becomes crucial, adhering to the principle of ‘garbage in, garbage out' and the paradox of acquiring large sample size versus high-quality data.16 This challenge impacts their ability to enhance accuracy and making them powerful tools to analyse data to evaluate complex clinical scenarios, like secondary resistance to KRAS inhibitors in patients’ tumours.

Artificial intelligence-guided drug discovery may encounter failures due to various reasons, including the lack of sufficient high-quality data and the black-box nature of certain AI models (especially observed for neural network architectures of multiple hidden layers, high dimensionality of the features, and utilization of nonlinear functions), hindering interpretability or understanding of their predictions, and limiting their acceptance in critical decision-making processes. To overcome these challenges, researchers should prioritize building comprehensive databases and repositories to capture emerging mutations and therapeutic responses. Data sharing initiatives and open-access repositories could create a vast and accessible pool of data to fuel AI-guided drug discovery. Additionally, development of specialized AI models capable of handling the complexities of drug-protein interactions and the complex pathways is essential. AI architectures, such as graph-based models, show potential to better interpret complex biological data and analyse complex biological processes that could address drug resistance. Furthermore, to be successful, drug discovery requires integration of AI model strengths with experimental HTS data. In our opinion, by verifying AI-guided predictions through experiments and iteratively improving AI techniques based on experimental feedback, researchers can further optimize and automate drug discovery. Overall, through interdisciplinary collaboration, innovative methodologies, and an emphasis on interpretability and validation, AI can become an invaluable tool in drug discovery.17

In conjunction with experimental efforts, genomic analyses, histologic evaluations, and molecular simulations, AI holds tremendous promise in overcoming drug resistance in KRAS mutant cancers. Here, we provide our perspective on top key strategies incorporating AI, which can create successful novel therapeutic strategies:

## Section: Potential of human and machine intelligence

In summary, AI can serve as a bridge, facilitating interdisciplinary research by integrating expertise from medicinal chemistry, molecular and computational biology, bioinformatics, and pharmacology.22,23 The synergy of these fields, combined with AI-driven analyses, allows for a comprehensive understanding of resistance mechanisms and the development of effective therapeutic strategies and translation to the clinic.16 The collaborative efforts between AI, other computational, and experimental research are crucial for translating these discoveries into clinical applications and advancing personalized medicine approaches for patients in need.24 Further identification of specific biomarkers associated with KRAS mutations may help predict mutations and tumour response to therapy, enabling clinicians to select the most effective treatment strategy. We believe that only through collaborative efforts and communication across disciplines we can unlock the full potential of human and machine intelligence against oncogenic mutations, leading to personalized and effective treatments for patients with resistant tumours.

## Section: Contributor Information

Mourad Stitou, Department of Machine Learning, Moffitt Cancer Center, Tampa, FL 33612, United States.

John M Koomen, Department of Molecular Oncology, Moffitt Cancer Center, Tampa, FL 33612, United States.

Denis J Imbody, Department of Thoracic Oncology, Moffitt Cancer Center, Tampa, FL 33612, United States.

Yi Liao, Department of Drug Discovery, Moffitt Cancer Center, Tampa, FL 33612, United States.

Andrii Monastyrskyi, Department of Drug Discovery, Moffitt Cancer Center, Tampa, FL 33612, United States.

Uwe Rix, Department of Drug Discovery, Moffitt Cancer Center, Tampa, FL 33612, United States.

Derek R Duckett, Department of Drug Discovery, Moffitt Cancer Center, Tampa, FL 33612, United States.

Eric B Haura, Department of Thoracic Oncology, Moffitt Cancer Center, Tampa, FL 33612, United States.

Aleksandra Karolak, Department of Machine Learning, Moffitt Cancer Center, Tampa, FL 33612, United States.

## Section: Funding

None declared.

## Section: Conflicts of interest

None declared.


---

# Drug Discovery in the Age of Artificial Intelligence: Transformative Target-Based Approaches

- **Authors:** Akshata Yashwant Patne, Sai Madhav Dhulipala, William Lawless, Satya Prakash, Shyam S Mohapatra, Subhra Mohapatra
- **Issuer:** International journal of molecular sciences
- **Type:** Scientific article
- **Published:** 2024-11-14
- **Language:** en
- **DOI:** 10.3390/ijms252212233
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39596300/
- **Licence:** CC-BY

## Section: Abstract

AbstractThe complexities inherent in drug development are multi-faceted and often hamper accuracy, speed and efficiency, thereby limiting success. This review explores how recent developments in machine learning (ML) are significantly impacting target-based drug discovery, particularly in small-molecule approaches. The Simplified Molecular Input Line Entry System (SMILES), which translates a chemical compound’s three-dimensional structure into a string of symbols, is now widely used in drug design, mining, and repurposing. Utilizing ML and natural language processing techniques, SMILES has revolutionized lead identification, high-throughput screening and virtual screening. ML models enhance the accuracy of predicting binding affinity and selectivity, reducing the need for extensive experimental screening. Additionally, deep learning, with its strengths in analyzing spatial and sequential data through convolutional neural networks (CNNs) and recurrent neural networks (RNNs), shows promise for virtual screening, target identification, and de novo drug design. Fragment-based approaches also benefit from ML algorithms and techniques like generative adversarial networks (GANs), which predict fragment properties and binding affinities, aiding in hit selection and design optimization. Structure-based drug design, which relies on high-resolution protein structures, leverages ML models for accurate predictions of binding interactions. While challenges such as interpretability and data quality remain, ML’s transformative impact accelerates target-based drug discovery, increasing efficiency and innovation. Its potential to deliver new and improved treatments for various diseases is significant.Keywords: drug discovery, graph neural networks, random forests, general adversarial networks, target-based approaches, phenotypic approaches

## Section: 1. Introduction

For centuries, the quest to discover life-saving medications has been a relentless pursuit fraught with challenges and uncertainties. The intricate journey from identifying a disease target to delivering a safe and effective drug remains a marathon, often hampered by limited speed, efficiency, and success. However, recent advancements in artificial intelligence (AI) have ignited a spark of hope, injecting a transformative force into the drug discovery landscape.

The complexities that are inherent in drug development are multi-faceted. Targets, often intricate proteins or enzymes, may harbor hidden mechanisms or allosteric sites, making intervention difficult. The vast chemical space, with an astronomical number of potential molecules, poses a daunting challenge when it comes to identifying the right drug candidate. Ensuring drug safety, efficacy, and affordability also requires navigating regulatory hurdles. These unmet needs have fueled the search for innovative solutions, and AI has emerged as a powerful tool to revolutionize the drug discovery process.

Numerous reviews have explored the potential of AI in drug discovery, focusing on specific aspects like virtual screening, target identification, or deep learning applications. While valuable, these reviews often lack a comprehensive overview encompassing the diverse range of AI-driven approaches within target-based and phenotypic strategies.

This review aims to bridge this gap by offering a holistic perspective on the transformative impact of AI in drug discovery. We delve into the intricacies of target-based approaches, exploring advancements in small-molecule, fragment-based, and structure-based methods. We then shed light on the potential of phenotypic approaches, leveraging AI to analyze cell-based assays and genetic screens. Beyond these specific strategies, we examine the broader contributions of AI in drug repurposing, computational predictions, and personalized medicine.

## Section: 2. Methods

Machine learning (ML) is an emerging field derived from AI, an idea that began with Alan Turing in the 1940s and has accompanied the computer revolution over the last four decades. The discovery of carbon nanomaterials, including carbon nanotubes and graphene, in 2004 provided impetus for early AI algorithms for the game of checkers, facial image recognition, and self-driving cars [1]. In short, ML encompasses the study and training of various types of algorithms that use input from datasets to predict an output independently [2]. Through several trials, a user improves the set of algorithms, known as a model, to make more accurate predictions [3]. The intricate complexities of disease targets and the vast chemical landscape have long burdened the relentless pursuit of effective medications. Traditional target-based approaches, while revolutionizing drug discovery, have also faced limitations. High-throughput screening (HTS) offered rapid lead identification, but false positives and neglect of drug-like properties hampered progress. Fragment-based and structure-based approaches and virtual screening (VS) provided finesse, but challenges remained. Fortunately, the dawn of AI involving ML and deep learning approaches has ignited a transformative era, empowering each approach with unprecedented capabilities.

In the context of ML, the field can be broadly categorized into supervised and unsupervised learning. Supervised learning involves training algorithms on labeled data to predict new, unseen data, while unsupervised learning identifies patterns and structures within unlabeled data. Common examples of supervised learning tasks include classification and regression, while clustering and dimensionality reduction are typical unsupervised learning tasks, as shown in Figure 1.

Example of algorithms and classifiers in ML models [4,5].

Example of algorithms and classifiers in ML models for small molecule-based approach drug discovery [9].

A select list of SVM models and applications.

Example of algorithms and classifiers in ML models for a fragment-based approach to drug discovery [24].

Example of Algorithms and Classifiers in ML Models for Structure-Based Approach Drug Discovery [46].

Examples of ML’s role in drug discovery by increasing the speed and efficacy of bioinformatics.

## Section: 2. Methods › 2.1. Small Molecule-Based Approach (SMA)

The traditional workhorse of target-based drug discovery was HTS. This approach initially involved physical testing of vast libraries of small molecules against specific biological targets, like proteins or enzymes, to identify potential lead candidates. These physical assays were later automated by machine pipetting and computer tracking, which increased speed and validation while reducing labor and material costs. While HTS revolutionized drug discovery by accelerating lead identification, it faced significant limitations. Many screened compounds often resulted into higher false-positive rates, requiring further validation and optimization. Additionally, HTS predominantly focused on ligand binding without considering crucial aspects like drug-like properties, pharmacokinetics, and toxicity, potentially leading to failures later in development [6].

These limitations were addressed with the development of computational-based VS methods, which precede experimental verification. VS is performed on thousands or even millions of compounds to create a top-ranking small-molecule interaction derived from physics-based computational calculations that measure predicted binding free energy. Analysis can be performed as either a structure-based drug design, which employs the biomolecular structure, or as a ligand-based design, which does not require a structure. VS also faces several challenges, such as the need for user knowledge about the binding target structure to avoid high computational costs, increase binding accuracy, and avoid erroneous assumptions. The computational cost in terms of both time and machine investment can be high, and calculations based on poorly established coordinates for binding pockets or overly large binding pockets can increase the computational time exponentially.

ML solves several problems associated with traditional VS and can augment structure- and ligand-based drug design with remarkable accuracy. ML incorporates training data into an analytical method and utilizes a separate set of validation data that assess a given model’s prediction accuracy and precision, determining the best possible ML model for a specific demand. Figure 2 elaborates on the small molecule-based approaches divided into supervised and unsupervised learning and various models, methods, input, and output using ML.

Recent advancements in ML have ignited a transformative era in target-based drug discovery [7]. ML models, empowered with vast datasets of chemical and biological information developed originally for VS, can predict small molecules’ potential binding affinity and selectivity with remarkable accuracy without any initial physical assay, dramatically reducing the number of compounds that require experimental validation. Furthermore, generative models can design novel small molecules with desirable properties, expanding the search space for promising lead candidates [8].

Example of algorithms and classifiers in ML models for small molecule-based approach drug discovery [9].

A select list of SVM models and applications.

## Section: 2. Methods › 2.1. Small Molecule-Based Approach (SMA) › 2.1.1. SMA-Supervised Learning

Supervised learning algorithms leverage established knowledge (also called test data) to make predictions. In supervised methods, we can use a controlled approach with large datasets to develop confidence in known relationships or work on meta-relationships to identify leads from big datasets. Some prominent examples used in the small-molecule approach are listed below.

## Section: 2. Methods › 2.1. Small Molecule-Based Approach (SMA) › 2.1.2. SMA-Support Vector Machines (SVMs)

This model finds the optimal hyperplane, a decision boundary used to maximize the margin between different data points, which helps filter the noise of the data and increase prediction accuracy. Interdependent training sets—including random, closely related, highly active, and boundary molecules—can be used to improve small molecule-binding predictions. The project stage at which ML models are applied dictates the choice of training set. Some of the examples of SVM models and their applications are shown in Table 1. One study investigated the difference between active and passive training methods and showed that the iterative selection of the model improved hit prediction accuracy by 29% for the thrombin dataset. This study also observed the advantages of exploitation using only the highest positive scores over exploration near a decision boundary for fewer data points, and the near equal efficiency of both when there are more data points [10]. Meanwhile, some studies used SVMs for predicting and scoring optimal docking poses. These studies showed predictions of consistent RMSD values (>0.9) and low prediction error (0.25), indicating high predictivity with minimal overfitting [11]. Studies working with novel protein targets without known 3D structures trained the vector machine models on 2D fingerprints of the chemical structure of a protein sequence. They utilized the linear combination method to yield a significant improvement in the prediction of compound activity compared to homology modeling-based predictions, as evidenced by the recovery rates of the projections. SVMs built using the linear combination method showed a 50% improvement in recovery rates for all target molecules [12].

A select list of SVM models and applications.

## Section: 2. Methods › 2.1. Small Molecule-Based Approach (SMA) › 2.1.3. Random Forests (RFs)

In this model, random subsets of data are organized as nodes, and these subsets are used to “grow” the tree. A prediction is made by aggregating all these trees. These models have proven to be very efficient with docking pose predictions [15]. The Matthews Correlation Coefficient (MCC) has been used to evaluate prediction model performance by considering true and false positives and negatives [16]. Higher MCC values, indicating better predictions, were achieved, with models reaching MCC values of 0.8 within 2000 to 3000 iterations and 0.6 within 3000 iterations. RF implementations combine the output of decision trees to handle classification and regression problems, predicting IC50 values of drug interactions and demonstrating statistical significance in two-tailed t-tests [17]. RDKit generates 2D depictions in PDBe CCDUtils, aiding RF regression to predict drug sensitivity with high accuracy [18]. These examples show the relevance and advantage of RF methods, which, even with minimal parameter tuning, demonstrate faster learning and balanced selection strategies when dealing with high-scale multivariate data.

## Section: 2. Methods › 2.1. Small Molecule-Based Approach (SMA) › 2.1.4. Convolutional Neural Networks (CNNs)

These models were designed to use image data. They use some layers to extract features from images and some layers to reduce dimensionality. Then, all layers are combined to make the final predictions. These models work best in applications with minimal feature engineering and image data. They have been used in studies to analyze graphs built upon preliminary sequential data or fingerprints [19]. In pharmacokinetics, the Area Under the Curve (AUC) refers to the definite integral of the concentration of a drug in blood serum as a function of time, serving as an essential predictor of drug bioavailability. One study explored CNN architectures for classifying ligands of cannabinoid receptors, achieving impressive results with AUC values ranging from 0.693 to 0.944 across different datasets, with the LeNet-5 architecture consistently outperforming others, as demonstrated by AUC scores peaking at 0.942 for AtomPair fingerprints on the CB1 test set [20]. Another study predicts electrostatic potential (ESP) surfaces for proteins and ligands using graph-convolutional deep neural network (DNN) models. ESP maps account for the overall strength of adjacent charges to a given point within a molecule and can predict molecular interactions with target residues within binding pockets. Trained against density functional theory (DFT) ESP surfaces, the ligand deep neural network fingerprint (DNN-fp) model outperforms AM1-BCC, providing fast, high-quality predictions that correlate strongly with experimental molecular properties, enabling interactive drug design [21]. Currently, the biggest challenges associated with supervised learning methods are the requirement of larger datasets and the possibility of bias in parameter selection in various approaches.

## Section: 2. Methods › 2.1. Small Molecule-Based Approach (SMA) › 2.1.5. SMA-Unsupervised Learning

Unsupervised learning algorithms can draw patterns within data without predetermined labels. This makes them particularly valuable for exploring novel chemical spaces and identifying promising lead candidates for targets without known actives. However, unsupervised learning can also contribute significantly to targets with known binders. In contrast to supervised methods, these frameworks require a smaller database and are more suitable for establishing new relationships and hidden patterns between parameters.

## Section: 2. Methods › 2.1. Small Molecule-Based Approach (SMA) › 2.1.5. SMA-Unsupervised Learning

Clustering is suitable for identifying patterns by grouping similar data naturally without drastically affecting the data size [22]. This method is particularly useful when dealing with incomplete input data, such as parts of input sequences or sections of structural fingerprint ensembles, where parts of the dataset are unavailable [23]. There are three prominent frameworks for clustering models: K-means, bisecting k-means, and Ward’s algorithm. K-means has been applied in deep clustering methods for proteins with no known active agents. By identifying leads for target proteins based on similarity and structure–activity relationships, k-means has shown impressive accuracy in predicting potential targets [24]. For example, in some applications, clusters have successfully predicted the binding affinity of protein–ligand interactions, making it a valuable tool in drug discovery. Bisecting k-means improves upon traditional k-means by recursively splitting lower-level clusters into subclusters [25]. This approach is particularly effective for irregular datasets, outperforming randomized k-means initialization by detecting significant motif patterns. For instance, bisecting k-means has been used to identify rare but important structural motifs in protein–ligand binding sites, improving the precision of lead identification over standard k-means methods. Ward’s method, which is commonly employed for quantitative variables when binary variables do not exist, minimizes variance within clusters. It excels in applications with consistent compound families, eventually form a single cluster. Ward’s method has been utilized to implement the Székely–Rizzo clustering approach to determine compound structures based on 2D fingerprints [26]. This has been instrumental in grouping compounds with similar chemical properties, and aiding the design of novel compounds in drug discovery.

## Section: 2. Methods › 2.1. Small Molecule-Based Approach (SMA) › 2.1.5. SMA-Unsupervised Learning

These models use an encoder to compresses the input data and a decoder to reconstructs new data from the compressed data. They have a high prediction accuracy, particularly when dealing with large datasets [27]. For example, TensorFlow-based autoencoders have improved predictions and overall accuracy in the context of the breast cancer gene GL50, spurring the development of comprehensive datasets for other ML models used in drug discovery [28].

Another study utilizes SMILES structures from the CHEMBL database to prepare a low-dimensional latent space representation and generate topographic maps. These maps could be used to prepare a compound library with insights into accessibility based on potential synthesis process complexity and latent descriptors. Data-driven latent vectors provided a much better representation of the compounds due to flexibility with input data, bringing nuance to the library [29].

One study displayed a direct advantage of unsupervised methods during pre-training, as demonstrated by very high prediction accuracy when a restricted Boltzmann machine-based implementation of a deep belief network built on key fingerprints from the molecular access system (MACCS) [30].

However, the source of those hidden relationships from the above-mentioned unsupervised models can be difficult to deduce, as they are built upon themselves with low-dimensionality input data. This can lead some fundamental supervised methods to outperform the unsupervised methods downstream.

## Section: 2. Methods › 2.2. Fragment-Based Approach (FA)

The fragment-based approach differs from the small-molecule approach by utilizing partial segments of pre-established structures. This is more useful for understanding structure–activity relationship studies [22]. The smaller fragments simplify the optimization of lead compounds, exponentially expediting the drug discovery process by eliminating the need to calculate all chemical interactions using various methods, as described in Figure 3 [23].

AI plays a similar role to the previous approach in advancing fragment-based drug discovery, contributing to various tasks crucial for optimizing lead compounds. The ML algorithms utilized in this context are significantly different, with projects using AI in a fragment-based approach have a broader-range of parameter selection—Such as binding affinity, energy, or entropy.

Example of algorithms and classifiers in ML models for a fragment-based approach to drug discovery [24].

## Section: 2. Methods › 2.2. Fragment-Based Approach (FA) › 2.2.1. FA-Supervised Learning

These algorithms have been used to analyze the relationship between fragment data and binding pocket interactions by predicting fragment structure based on the SMILES format sequence or by including characteristics like chemical properties [25]. One study factored in the free energy of the fragments to predict docking poses [26]. This technique has been used to form a shrinkage logistic regression model to predict the fragment interaction [31]. Some frameworks of neural networks have been modeled based on the Monte Carlo dropout method, trained mostly on the binding affinity and binding energy of different compounds to estimate uncertainty and improve predictability. One study employed molecular dynamics (MD) simulations to predict the free energies of 15,000 small molecules transferred between water and cyclohexane using a 3D-CNN. The results demonstrate the prediction of 2.5–5 KJ/Mol, aligning with experimental models [32].

## Section: 2. Methods › 2.2. Fragment-Based Approach (FA) › 2.2.2. FA-Support Vector Machines (SVMs)

As stated in Shahab et al.’s study which predicted binding pockets and fragment properties, SVMs can classify and analyze large datasets of fragments to identify those with specific characteristics relevant to drug development. For instance, they have been used to predict the binding modes of kinase inhibitors based on X-ray structures as templates and have proved to be a reliable method for building large libraries [33]. It is important to note that SVMs were suggested to be more suitable for downstream validation or precision predictions of structures over preliminary fingerprint-based predictions until selectivity parameters like IC50 were utilized during training, yielding 92% prediction accuracy [34].

## Section: 2. Methods › 2.2. Fragment-Based Approach (FA) › 2.2.3. Reinforcement Learning

Reinforcement learning is more suitable for iterative scoring in training stages of the model; the greater the number of iterations, the better the model’s scoring performance and results [35]. One recent study utilized molecular graph transformers based on compounds from CHMEBL and LIGAND databases [36]. The researchers iteratively reinforced the model with scoring based on interactive parameters of small fragments, such as drugs’ similarities to and affinity towards their study target protein A2AAR, to generate structures using the SMILES format, with an exploitation-focused approach [37]. These models could generate fragments that were highly compatible with A2AAR [38]. Another study explored structural characteristics like fragment length, branching, and bond flexibility. This study focused on the scoring strategy based completely on the raw potential of fragments. The scoring for this model focused more on exploration. The generated fragment libraries have a range just as vast as the input libraries [39]. Thus, this approach would be more advantageous for compound synthesis than the case-/disease-specific transformer application.

## Section: 2. Methods › 2.2. Fragment-Based Approach (FA) › 2.2.4. FA-Unsupervised Learning

Studies show high prediction accuracy for the construction of molecular fingerprints based on two Word2vec models (with skip-gram (SG) and continuous bag of words (CBOW) implementation), developing t-distributed stochastic neighbor embedding (t-SNE) plots and QSAR modeling [40]. Specifically, kinase inhibitors and anti-HIV compounds showed sensitivity of 77% and specificity of 87% for distributed fingerprints, with sensitivity of 67% and specificity of 91% for fragment fingerprints [41]. The clustering approach shines in these studies, achieving high-accuracy predictions despite the lack of labeled data [39]. It shows a demonstrable advantage over conventional QSAR modeling approaches using supervised models like CNNs. It might also be better than other unsupervised approaches like autoencoders due to their efficiency in capturing complex relationships without encoding or decoding, which might be more relevant to the small-molecule approach [40].

## Section: 2. Methods › 2.3. Structure-Based Approach (SA)

The structure-based approach leverages high-resolution protein structures, allowing scientists to design ligands with exquisite specificity. Recent advancements in ML are further empowering this technique, particularly with regard to challenging targets for which crystal structures are elusive; some of the relevant techniques are mentioned in Figure 4 [42]. Predictions based on previous templates from various databases using homology modeling [43], threading [44], or ab initio [45] prediction of folding confirmations have proved to be intuitive applications for ML in a structure-based approach.

Example of Algorithms and Classifiers in ML Models for Structure-Based Approach Drug Discovery [46].

## Section: 2. Methods › 2.3. Structure-Based Approach (SA) › 2.3.1. SA-Supervised Learning

The ProteinGAN model, trained on a diverse dataset of 16,706 unique sequences of bacterial malate dehydrogenase enzymes, yielded significant predictive outcomes. It achieved a median sequence identity of 61.3% for natural sequences and identified 119 novel structural motifs [47]. Another study used GAN with spectral normalization to achieve tight backbone distribution of the sequences and stability [48]. GANs significantly increased the accuracy of protein folding predictions, helping researchers identify binding pocket more accurately and select suitable ligands for compounds that bind with kinase and dopamine receptors [49].

## Section: 2. Methods › 2.3. Structure-Based Approach (SA) › 2.3.2. SA-Support Vector Machines

The SWISS-MODEL uses multiple sequence alignments, interface geometry, and residue entropy distribution to identify templates that maximize high-quality estimates based on inter-chain contact scores [50]. The model uses Monte Carlo sampling with Pro-Mod3 [51], which employs a library of parameters for energy minimization. Each developed model is scored based on its evolutionary significance [52]. SVMs can find optimal decision boundaries in high-dimensional feature spaces (here, interface conservation and geometric properties), effectively separating suitable templates from unsuitable ones.

## Section: 2. Methods › 2.3. Structure-Based Approach (SA) › 2.3.3. Structure Networks

Sequence alignment Networks have been used to establish evolutionary relationships, and an encoding module is trained based on previous structures to predict contacts in amino acids and, as a result, their folding pattern [53]. These networks are particularly useful here, as they can identify long-range dependencies [54], so they can identify amino acid interactions by using the attention mechanism [55] with local alignments when electron densities and ion spheres are factored into the implementation of these models’ parallel processing. The attention modules showed a Pearson coefficient of 0.78 with precision scores for all targets, demonstrating their relevance to larger and more complex databases without the high data requirements of GANs or feature engineering required by SVMs.

## Section: 2. Methods › 2.3. Structure-Based Approach (SA) › 2.3.4. SA-Unsupervised Learning

Some projects, like Omegafold, which applies PLMs based mostly on unaligned and unlabeled sequences [56], use residue pairs to create embeddings [57]. These embeddings are refined by geometric consistency, mostly to improve distance predictions [58]. One study used the harmonic mean of true positives and recall to observe the class distributions (F1 score) of predictions of molecular function, biological process, and cellular component-specific relation with the sequence using two protein language models: K-sep and SeqVec. Both models performed well in terms of molecular function prediction, with F1 scores of 916 and 914, respectively [59]. This approach is significantly different from that of Alphafold2, where predictions depend less on comparative parameters like evolutionary significance or deviation and more on spontaneous metadata derived directly from the sequence, outperforming Alphafold2 when model training data do not extend beyond the sequence [60].

## Section: 2. Methods › 2.3. Structure-Based Approach (SA) › 2.3.4. SA-Unsupervised Learning

In a novel decoy selection-based clustering model, computer-developed decoys are used to organize decoys and original structures to identify noise. This is implemented using a k-means framework in which decoy region identification receives greater focus than the folding confirmation selection, which makes this type of model very flexible as it can be used as a refinement method for structures predicted by other models [61].

## Section: 2. Methods › 2.4. Examples of ML Affecting Bioinformatics Drug Discovery

ML has significantly advanced the field of bioinformatics, a major facet of bio-nanotechnology involving the interaction of nanomaterials with biological systems comprising DNA, RNA, proteins, and metabolism, by enabling the analysis of complex biological data in previously impossible ways. Some key areas where machine learning has had a substantial impact include the fields of genomics, proteomics, transcriptomics, systems biology, and drug discovery. Some examples of ML’s contributions to bioinformatics are shown in Table 2.

ML algorithms can analyze vast amounts of genomic data to identify patterns and mutations associated with diseases. This helps further our understanding of genetic predispositions and assists with the development personalized medicine [71]. Additionally, ML techniques help us to analyze RNA sequencing data to understand gene expression patterns, which is vital for studying how genes are regulated and how they respond to different conditions [72]. By integrating data from various biological sources, ML aids in complex modeling scenarios.

Traditional methods of protein network analysis can be time-consuming and computationally intensive. ML algorithms can process large datasets more quickly, helping us understand the behavior of biological systems under different conditions [73]. By analyzing protein structures and functions, ML aids in the prediction of protein interactions and functions, which is crucial for drug discovery and understanding cellular processes [74]. This efficiency makes it feasible to analyze complex networks on a larger scale [75]. Further, ML can model the dynamic behavior of protein networks under different conditions, such as changes in the environment or disease states, helping us understand how protein interactions change over time [76]. These advancements have accelerated research and enhanced our understanding of cellular processes, leading to potential breakthroughs in drug discovery and personalized medicine.

ML algorithms have been used to reconstruct metabolic networks by integrating various types of omics data (e.g., genomics, transcriptomics, and proteomics). ML has significantly improved the efficiency of protein network analyses in several ways. First, ML models can predict interactions between proteins by analyzing large datasets of known interactions, aiding in the construction of more accurate and comprehensive protein interaction networks [77]. Second, by analyzing patterns in protein sequences and structures, ML can predict the functions of unknown proteins, aiding in the annotation of protein networks [78]. Additionally, ML algorithms can integrate various types of biological data (e.g., genomic, transcriptomic, and proteomic data) to reconstruct protein interaction networks, providing a more holistic view of cellular processes [79]. Thus, ML models can predict how different compounds will interact with biological targets, speeding up the drug discovery process and reducing costs [80]. These advancements have not only accelerated research but have also opened new avenues for personalized medicine, making treatments more effective and tailored to individual patients.

Despite the progress made in bioinformatics, applying ML to biology comes with several challenges. First and foremost, biological systems are incredibly complex and dynamic [81] making it difficult to create accurate models that can predict biological behavior. Successful ML application requires high-quality, annotated datasets that are essential for training ML models. However, biological data often contain noise, missing values, and inconsistencies, which can hinder a model’s performance. Additionally, the effective application of ML in biology requires expertise in both fields. Bridging the gap between computational scientists and biologists can be challenging due to differences in terminology, methodologies, and objectives [82]. Furthermore, biological datasets can be enormous, requiring significant computational resources for processing and analysis. Ensuring that ML models can handle these large datasets is a major challenge [83]. Another challenge is that many ML models, especially deep learning models, are often seen as “black boxes”. Understanding how these models make predictions is crucial for gaining biological insights and ensuring trust in the results. Finally, handling sensitive biological and medical data raises ethical and privacy issues. Ensuring data security and patient confidentiality is paramount [84]. Despite these challenges, the potential benefits of applying ML to biology are immense, driving ongoing research and innovation in this exciting field.

Examples of ML’s role in drug discovery by increasing the speed and efficacy of bioinformatics.

## Section: 3. Conclusions

The integration of ML into target-based drug discovery represents a monumental leap in the pharmaceutical industry. By enhancing traditional methods such as HTS and VS, ML models have significantly improved the prediction accuracy of binding affinities and selectivity, thereby reducing the need for extensive experimental screening. The application of deep learning techniques, such as CNNs and RNNs, shows great promise in virtual screening, target identification, and de novo drug design. Additionally, fragment-based and structure-based approaches have benefited from ML algorithms that predict fragment properties and binding affinities with remarkable precision.

The advent of GANs and other advanced techniques has further empowered researchers to explore and expand the chemical space, enabling the discovery of novel molecules with desired properties. Despite challenges such as interpretability and data quality, the transformative impact of ML is undeniable, accelerating the drug discovery process and fostering innovation.

Given the widespread use of computational algorithms in predicting experimental protein structures and the increasing reliance on virtual screening for lead selection, it is conceivable that the efficiency of computational methods will eventually rival or surpass traditional experimental methods in terms of resolution and accuracy. This could potentially address the limitations inherent in each of these approaches.

In summary, the application of ML in target-based drug discovery is paving the way for more efficient and effective identification of therapeutic candidates and significantly improves upon methods traditionally established by HTS and VS. As ML models continue to evolve, they have the potential to revolutionize the development of new and improved treatments for various diseases, enhancing patient outcomes and advancing medicine.

## Section: Acknowledgments

Figures in this article were created using BioRender (BioRender.com).

## Section: Abbreviations

AI—Artificial intelligence; CNNs—Convolutional neural networks; DL—Deep learning; FA—Fragment-based approach; GANs—Generative adversarial networks; HTS—High-throughput screening; ML—Machine learning; MCC—Matthews Correlation Coefficient; PLMS—Protein language models; RF—Random Forest; RNNs—Recurrent neural networks; VS—Virtual screening; SMILES—Simplified molecular-input line-entry system; ASCII—Sequences that describe the structure of a compound; SMA—Small molecule-based approach; SA—Structure-based approach; SVMs—Support Vector Machines.

## Section: Author Contributions

Conceptualization, A.Y.P., S.M. and S.S.M.; Writing—Original draft preparation, A.Y.P. and S.M.D.; writing—Review and editing, S.M., W.L., S.S.M. and A.Y.P.; visualization, A.Y.P., S.M., S.S.M. and S.P.; funding acquisition, S.M. and S.S.M. All authors have read and agreed to the published version of the manuscript.

## Section: Data Availability Statement

All other data generated or analyzed during this study are included in this published article.

## Section: Conflicts of Interest

The authors declare no conflict of interest.

## Section: Funding Statement

This research was funded by the US Dept. of Veterans Affairs Research Career Scientist (RCS) awards IK6BX004212 to S.M., and IK6BX006032 to S.S.M. The views expressed in this article are those of the authors and do not necessarily reflect the position or policy of the Department of Veterans Affairs, or the United States government.

## Section: Associated Data › Data Availability Statement

All other data generated or analyzed during this study are included in this published article.


---

# Drug Repositioning via Graph Neural Networks: Identifying Novel JAK2 Inhibitors from FDA-Approved Drugs through Molecular Docking and Biological Validation

- **Authors:** Muhammad Yasir, Jinyoung Park, Eun-Taek Han, Won Sun Park, Jin-Hee Han, Wanjoo Chun
- **Issuer:** Molecules (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2024-03-19
- **Language:** en
- **DOI:** 10.3390/molecules29061363
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38542998/
- **Licence:** CC-BY

## Section: Abstract

The increasing utilization of artificial intelligence algorithms in drug development has proven to be highly efficient and effective. One area where deep learning-based approaches have made significant contributions is in drug repositioning, enabling the identification of new therapeutic applications for existing drugs. In the present study, a trained deep-learning model was employed to screen a library of FDA-approved drugs to discover novel inhibitors targeting JAK2. To accomplish this, reference datasets containing active and decoy compounds specific to JAK2 were obtained from the DUD-E database. RDKit, a cheminformatic toolkit, was utilized to extract molecular features from the compounds. The DeepChem framework’s GraphConvMol, based on graph convolutional network models, was applied to build a predictive model using the DUD-E datasets. Subsequently, the trained deep-learning model was used to predict the JAK2 inhibitory potential of FDA-approved drugs. Based on these predictions, ribociclib, topiroxostat, amodiaquine, and gefitinib were identified as potential JAK2 inhibitors. Notably, several known JAK2 inhibitors demonstrated high potential according to the prediction results, validating the reliability of our prediction model. To further validate these findings and confirm their JAK2 inhibitory activity, molecular docking experiments were conducted using tofacitinib—an FDA-approved drug for JAK2 inhibition. Experimental validation successfully confirmed our computational analysis results by demonstrating that these novel drugs exhibited comparable inhibitory activity against JAK2 compared to tofacitinib. In conclusion, our study highlights how deep learning models can significantly enhance virtual screening efforts in drug discovery by efficiently identifying potential candidates for specific targets such as JAK2. These newly discovered drugs hold promises as novel JAK2 inhibitors deserving further exploration and investigation.

## Section: 1. Introduction

Drug repositioning involves identifying novel therapeutic uses for medications that have previously gained approval for different medical purposes [1]. It can notably accelerate the drug development process, enhance the utility of established drugs, and reveal novel treatments for ailments lacking effective remedies [2]. Accordingly, drug repurposing is becoming an increasingly important area of research in drug development. Computer-aided drug design (CADD) has become an essential tool in the domain of drug discovery and development [3]. Utilizing computational algorithms and software, CADD enables efficient screening of large compound libraries, offering a faster and more cost-effective alternative to traditional experimental approaches [4]. A primary strength of CADD is its capacity to swiftly assess a large number of compounds, minimizing the extensive laboratory testing in traditional experimental studies, which can be time consuming and expensive [5].

Artificial intelligence is rapidly expanding and possesses significant promise in transforming the drug development process [6]. Deep learning (DL), a subset of artificial intelligence, enables its models to assimilate data and formulate predictions or decisions without explicit programming [7]. DL plays a pivotal role in drug development by analyzing vast datasets encompassing genetic and clinical data. This analysis aids in discovering new drug targets, predicting drug effectiveness with accuracy, and fine-tuning drugs [8,9]. One of its primary advantages is the capability to analyze large and complex datasets [10]. Whereas traditional data analysis methods, like manual examination and statistical techniques, can be labor intensive and time consuming, DL models offer swift and adept data analysis, discerning patterns and forecasting outcomes, which in turn fast-tracks the drug development process [11]. An additional strength of DL in drug development is its capability to predict the potency and toxicity of compounds [12]. By analyzing extensive datasets, DL models can discern trends suggesting drug effectiveness and potential toxicity, enabling the prediction of these attributes before the synthesis and laboratory evaluation. Therefore, integrating DL within CADD can markedly improve the speed, efficiency, and success of the drug discovery, making it significant in drug discovery and development.

Janus kinases (JAKs) belong to a family of non-receptor tyrosine kinases crucial for cellular signaling, especially within the immune system [13,14,15]. Disruption in JAK function is associated with various inflammatory disorders, such as rheumatoid arthritis, psoriasis, and inflammatory bowel disease [16,17]. Four main members constitute the JAK family: JAK1, JAK2, JAK3, and TYK2 [18]. Each has unique traits and distinct cellular roles. Specifically, JAK1 is associated with signaling via the interferon-α receptor, while JAK3 primarily operates through the common gamma chain receptor [19,20,21]. JAK2, however, interfaces with a multitude of cytokines, including erythropoietin, thrombopoietin, and interleukin-6 [14,22], positioning it with a more expansive signaling capability compared to JAK1 and JAK3. Notably, JAK2’s involvement has been identified in conditions like polycythemia vera, essential thrombocythemia, and myelofibrosis [23]. While certain JAK1 and JAK3 mutations are reported in acute lymphoblastic leukemia [24], JAK2’s role appears more central in the onset of diverse diseases [25,26,27]. Given this context, our study focuses on the development of novel JAK2 inhibitors. In this study, we employed a graph neural network algorithm to train on datasets containing active and decoy JAK2 inhibitors. Subsequently, we screened an FDA-approved drug library to identify potential JAK2 inhibitors for drug repurposing. We further assessed the selected compounds using molecular docking techniques and their biological activity was validated using a JAK2 kinase assay kit to discover novel JAK2 inhibitors.

## Section: 2. Results and Discussions

The process of integrating deep-learning, molecular docking, and experimental evaluation for drug repurposing of novel JAK2 inhibitors is illustrated in Figure 1. The process comprised seven distinct phases: (1) data acquisition and preparation from the DUD-E database, (2) configuration of the graph convolutional network model, (3) training and evaluation of the deep learning model, (4) predictive assessment of FDA-approved drugs, (5) molecular docking for the top-predicted drugs, (6) experimental validation of potential candidates through JAK2 kinase assay, and (7) analysis of results to confirm the validity of repurposing FDA-approved drugs as novel JAK2 inhibitors.

## Section: 2. Results and Discussions › 2.1. JAK2 Active and Decoy Datasets and Its Preprocessing Using RDKit

The DUD-E (Database of Useful Decoys: Enhanced) database is an open-access database that hosts benchmark sets of protein–ligand complexes. It encompasses a set of experimentally confirmed active compounds, their affinities against diverse targets, and associated decoys that are confirmed not to bind with the target. Though these decoys share similar physicochemical properties with the active compounds, their two-dimensional topology differ [28]. The DUD-E database has frequently served as a benchmark for the creation and evaluation of computational docking techniques [29,30]. The JAK2 dataset in the DUD-E database (https://dude.docking.org/targets/JAK2) (accessed on 15 January 2024) features 107 active compounds, curated from an initial set of 246 compounds, paired with 6500 decoy compounds. Figure 2A provides illustrative images of the structures of both active and decoy compounds, with labels in the legend to distinguish them. To evaluate the physicochemical distinctions between active and decoy compounds, we used RDKit (Version 2023.09.6), a free chemoinformatics software toolkit, to calculate their molecular attributes. Upon comparison, we observed minimal variations in the distribution patterns of molecular features such as weight, LogP, the number of hydrogen bond donors/acceptors, topological polar surface area (TPSA), and number of rotatable bonds (Figure 2B).

## Section: 2. Results and Discussions › 2.2. Deep-Learning Model Setup, Training, and Evaluation

DeepChem is an open-source Python library designed for deep learning applications within drug discovery and cheminformatics. It offers a comprehensive suite of tools for managing molecular data and harnessing various deep learning techniques for tasks like molecular attribute forecasting, virtual ligand screening, and molecule optimization [31,32]. In this research, we employed the GraphConvMol model from DeepChem to discern differences between active and decoy compounds within the JAK2 dataset. This model, an integral part of the DeepChem suite, uses a form of graph convolutional neural network to process molecular graphs, turning them into fixed-size representation vectors. Each atom is denoted as a node, and covalent bonds become edges in this molecular graph. The algorithm involves a series of message-passing phases, during which each atom communicates its unique features to adjacent atoms. After collecting messages from neighboring atoms, the data are synthesized to update the current atom’s attributes. The final representation of the molecule is formulated by combining the individual atom representations and further refining them through feed-forward neural networks. As GraphConvMol facilitates the end-to-end learning of molecular structures, it stands as a robust asset in cheminformatics endeavors, specifically in predicting molecular properties and drug discovery [33,34]. The JAK2 dataset was split into training, validation, and test sets at a ratio of 8:1:1, and then subjected to the GraphConvMol model using cross-validation with a fold of 5. To assess the model’s performance, the AUC (Area Under the Curve) of the ROC (Receiver Operating Characteristic) curve was computed for the training, validation, and test datasets. The ROC curve, generated from a five-fold cross-validation on the training dataset, illustrated a True Positive Rate (TPR) value of 1 at an exceptionally low False Positive Rate (FPR) with an AUC value of 0.992 (Figure 3A). This suggests that the GraphConvMol model exhibits high sensitivity in identifying positive instances while effectively minimizing false positives.

To evaluate the performance of GraphConvMol on DUD-E datasets, metrics such as precision, recall, F1 score, sensitivity, accuracy, and specificity were calculated across training, validation, and test datasets (Table 1). The training dataset showed reliable performances, with only 2 out of 94 positive instances misclassified as negative (recall: 0.98). In the validation dataset, there was one false positive out of 652 negatives (precision: 0.83) and 3 false negatives out of 8 instances (recall: 0.63). The lower performance metrics in the validation dataset may be due to the limited number of active compounds. However, the model demonstrated optimal performance in the test dataset, achieving a score of 1 in all metrics (Table 1).

Due to the disproportionate number of decoys relative to active compounds in the dataset, the Matthews correlation coefficient (MCC) was utilized to assess the performance of the GraphConvMol model. This metric is particularly effective for datasets with such imbalances. The averaged MCC values from five-fold cross-validation processes were 0.96 for the training set and 0.76 for the validation set. A perfect prediction accuracy is indicated by an MCC of 1, highlighting that those scores of 0.96 and 0.76 demonstrate the model’s robustness and dependability. It is generally expected for the MCC value of the test set to surpass that of the validation set since the model, after being trained on the training set, is then tested on the novel and unencountered data of the validation set. Furthermore, the variation in MCC values observed across the five-fold cross-validation suggests that the model is not overly fitted to the training data.

## Section: 2. Results and Discussions › 2.3. Prediction of JAK2 Inhibitory Potential from FDA-Approved Drugs

Repositioning FDA-approved drugs offers distinct advantages. Given that these drugs have already undergone rigorous pre-clinical and clinical evaluations for safety, dosage, and pharmacokinetics, their repositioning often means shorter development periods, reduced costs, and a higher probability of success. The trained model, utilizing the GraphConvMol algorithm from DeepChem, processed SMILES strings of FDA-approved drugs to assess their potential for JAK2 inhibitory activity. Predictions on JAK2 inhibitory capability for these drugs spanned a range from 0 (inactive) to 1 (highly active). While a majority of the compounds were deemed inactive, a small subset was identified as potential actives (Figure 4A). Figure 4B presents structures of select compounds that were predicted to have high activity, with labels showcasing their anticipated values.

Noticeably, several of top-ranked compounds such as ruxolitinib, baricitinib, tofacitinib, and upadacitinib (listed in Table 2) are well-known JAK2 inhibitors. This strongly indicates the high robustness and reliability of the present model. From the set of drugs highly predicted by the GraphConvMol model, we selected several candidates for further evaluation regarding their potential JAK2 inhibitory actions through molecular docking and experimental assessment. Gefitinib, a tyrosine kinase inhibitor used in acute lymphoblastic leukemia [35], ribociclib, a CDK kinase inhibitor employed in the treatment of metastatic breast cancer [36], amodiaquine, an inhibitor of heme polymerase inhibitor used for malaria [37], and topiroxostat, an inhibitor of xanthine oxide used for gout [38], were among the chosen drugs. These drugs have not been previously reported to be associated with JAK2 inhibition.

## Section: 2. Results and Discussions › 2.4. Structural Analysis of the JAK2 Protein

A non-receptor tyrosine kinase JAK2 belongs to the Janus kinase family and has been linked to signaling by the single chain receptors (Epo-R, Tpo-R, GH-R, and PRL-R), the GM-CSF receptor family’s (IL-3R, IL-5R, and GM-CSF-R), and the type II cytokine receptor family’s (interferon receptor) [39]. It was constructed by 311 amino acids forming a single chain (PDBID 3JY9). Loops, α-helices, and β-sheets are present in the overall structure of JAK2 (Figure 4). Furthermore, a VADAR 1.8 structural assessment demonstrated that JAK2 was constructed by 40% α-helices, 22% β-sheets, 37% coils, and 23% turns. Moreover, the Ramachandran plots analysis revealed that 95.1% of amino acids occur in the favored region, while 98.6% of residues were in the allowed zone of dihedral angles phi (φ) and psi (ψ) (Figure 5B).

## Section: 2. Results and Discussions › 2.5. The Binding Pocket Analysis

Along with its structure and position inside a protein, a binding pocket’s function is influenced by the group of amino acid residues that surround it [40]. Using the Discovery Studio ligand interaction method, the binding pocket residues of JAK2 were obtained from the interaction of JAK2 and co-crystalized ligand and mentioned as Leu14, Gly15, Val22, Ala39, Leu142, Glu57, Val70, Met88, Tyr90, Leu91, Gly152, and Asp153. Therefore, the co-crystalized ligand was chosen by the current selection approach to define the CDocker binding sphere. Furthermore, the binding sphere was subjected to contraction to limit it to the accurate position respective to our selected binding pocket residues. The binding sphere values were X = 12, Y = 13, Z = 2.6, and the radius value was fixed as 7.8 to study the interaction of selected compounds in the active region of JAK2 (Figure 6A,B).

## Section: 2. Results and Discussions › 2.6. Molecular Docking Analysis

The top 20 screened compounds were docked against JAK2. The docked complexes were evaluated and examined independently and scored based on the minimal docking energy and interaction energy values. The Discovery Studio CDocker module forecasts two types of energy values (CDocker energy and CDocker interaction energy). The terms CDocker energy and CDocker interaction energy are used to describe the energy involved in the various interactions between the ligand and the receptor. CDocker energy displays the overall docking energy based on the 3D structural and physiochemical features of the ligand and protein, whereas the strength and nature of each individual contact between the ligand and the receptor are revealed by CDocker interaction energy. It calculates how much the overall binding strength is affected by intermolecular forces such Van der Waals forces, electrostatic interactions, and hydrogen bonds [41,42,43]. The top 20 docking results concerning the CDocker interaction energy score were depicted in Table 3. Therefore, ribociclib demonstrate the lowest interaction energy values. Moreover, the gefitinib and amodiaquine came up in the top 10 docked compounds, although they exhibit a high CDocker interaction energy as compared to ribociclib, they exhibit a lower interaction energy than the reference compound tofacitinib (gefitinib, amodiaquine, and tofacitinib manifest −50.6 kcal/mol, −44.4 kcal/mol, and −40.0 kcal/mol, respectively). Topiroxostat comparatively revealed a high interaction energy (−28.8 kcal/mol) compared to the reference compound.

## Section: 2. Results and Discussions › 2.7. Binding Interaction Analysis against JAK2

The top 20 screened compounds that were docked against the JAK2 protein were further analyzed by Discovery studio and UCSF Chimera to examine and confirm the binding interaction of ligands with the active site amino acid residues of JAK2.

Ribociclib compounds, which manifest the lowest interaction energy molecular docking energy, manifest the strongest interaction against JAK2 (Figure 7). The ribociclib-JAK2 docked complex expressed eight hydrogen bonds which include the residues Glu57, Asp153, Glu89, Leu91, Leu14, and Asp98. Two oxygen atoms of ribociclib form hydrogen bonds against Glu57 and Asp153 with a bond length of 2.28 Å and 1.93 Å, respectively. Another two oxygen atoms of ligand exhibit two hydrogen bonds with the same Asp98 with a bonding distance of 2.49 Å and 2.05 Å. Moreover, the other two oxygen atoms also formed two hydrogen bonds with the same Leu14 with a bonding distance of 2.97 Å and 2.71 Å. Another solo oxygen atom of ribociclib revealed a hydrogen bond with Glu89 with a bond length of 2.48 Å. Furthermore, a nitrogen atom of ligand expresses a hydrogen bond against Leu91 with a bonding distance of 2.30 Å.

The ligand–protein docking analysis of Amodiaquine showed that the ligand binds within the active region of the target protein as shown in Figure 7. The Amodiaquine-Jak2 docked complex exhibits three hydrogen bonds and one halogen bond. A halogen bond is formed when there is evidence of a net attractive interaction between an electrophilic region associated with a halogen atom in one chemical entity and a nucleophilic region in another or the same molecular entity [44]. The hydrogen atom of Amodiaquine formed a hydrogen bond with Arg139 with a bonding distance of 2.97 Å. Additionally, two other hydrogen atoms of ligand formed hydrogen bonds with Leu91 and Leu14 with bond lengths of 2.16 Å and 2.03 Å, respectively. Furthermore, the chlorine atom of ligand formed a halogen bond with Phe19 with a bonding distance of 3.17 Å. Topiroxostat was confined in the active binding pocket of the JAK2 protein and formed three hydrogen bonds with active region amino acid residues (Figure 7). The topiroxostat-JAK2 docked complex showed a hydrogen atom of formed hydrogen bonds with Leu91 with a bond length of 2.67 Å. Furthermore, a nitrogen atom of topiroxostat also formed a hydrogen bond with Leu91 with a bond length of 2.42 Å. Moreover, another hydrogen atom of ligand formed a hydrogen bond with Phe19 with a bonding distance of 2.78 Å.

The ligand–protein docking analysis of tofacitinib showed that ligands become docked within the active region of the target protein, as shown in Figure 7. The tofacitinib-JAK2 docked complex forms three hydrogen bonds which include the residues Lue91 and Arg139. The oxygen atom of tofacitinib forms a hydrogen bond against Leu91 with a bond length of 2.64 Å. Furthermore, the nitrogen atom of the ligand also forms a hydrogen bond with Leu91 with a bonding distance of 2.35 Å. Moreover, the oxygen atom of ligand exhibits a hydrogen bond against Arg139 with a bonding distance of 2.78 Å. The gefitinib compound also manifests high interactions following ribociclib. The ribociclib-JAK2 docked complex exhibit six hydrogen bonds (Figure 7). The oxygen atom of ligand formed a hydrogen bond with Asp154 with bond length of 2.12 Å. An oxygen atom of ligand revealed two hydrogen bonds with the same Asp153 with bond length of 2.32 Å and 2.75 Å. Moreover, the other two oxygen atoms of gefitinib showed two hydrogen atoms with the same Leu91 with the bond length of 2.68 Å and 2.33 Å. Furthermore, an oxygen atom of ligand revealed a hydrogen bond against Leu14 with a bonding distance of 2.52 Å.

These interactions strongly suggest that the predicted drugs block the active region of JAK2 by hindering with the active region amino acid residues.

## Section: 2. Results and Discussions › 2.8. Experimental Validation

JAK2 inhibitory activity of highly predicted drugs and tofacitinib, a reference drug, was experimentally evaluated using a JAK2 kinase assay kit. Both tofacitinib and the other drugs exhibited significant inhibition of the JAK2 enzymatic activity at 25 nM. This concentration is consistent with the previously documented IC50 values for the inhibitory activity of tofacitinib against JAK2 [45]. Remarkably, each of the test drugs demonstrated significant JAK2 inhibition, with their effectiveness closely paralleling that of tofacitinib (Figure 8). This suggests that these drugs hold promise as potential novel JAK2 inhibitors.

## Section: 2. Results and Discussions › 2.9. Structural Evaluation and Similarity Comparison

To evaluate the structural similarity among the top-ranked drugs, the Tanimoto similarity measure in RDKit was utilized. Tofacitinib and several top-ranked drugs in JAK2 inhibitory potential prediction exhibit structural characteristics. Each of these drugs incorporates one or more heterocyclic rings along with aromatic moieties (Figure 9). Further, these compounds possess diverse substituents attached to their primary scaffolds, which likely influence their interactions with JAK2 proteins. However, despite these structural motifs, an assessment using the Tanimoto similarity coefficient showed that their overall structural similarity was not notably high (Table 4). In general, while no exact threshold exists for defining similarity, a Tanimoto similarity value below 0.5 is often regarded as indicative of dissimilarity in a range from 0 to 1. On this scale, a value of 0 denotes no similarity at all, and a value of 1 represents complete similarity.

While the top-ranked drugs exhibited limited overall similarity to tofacitinib, it is still possible that these drugs share specific structural features. To explore this, the Maximum Common Substructure (MCS) algorithm in RDKit was applied. Tofacitinib and the four top-ranked drugs were analyzed using the MCS algorithm in RDKit with the threshold of 0.5. This analysis grouped tofacitinib, ribociclib, and gefitinib together, with their common substructures highlighted in red color (Figure 10A). This result implies that factors other than the structural motif, such as the spatial arrangement of specific conformations, might contribute to the inhibitory activity on JAK2 protein. Furthermore, similarity maps using fingerprints in RDKit were employed to illustrate whether the top-ranked drugs possessed the structural motif of tofacitinib (Figure 10B). The similarity maps of the top-ranked drugs revealed the presence of structural motif of tofacitinib in their chemical structures. These findings from the MCS and similarity map findings provide valuable information to guide further optimization of the selected compounds.

The highly predicted compounds, including tofacitinib, ribociclib, topiroxostat, amodiaquine, and gefitinib, are characterized by their LogP, solubility, gastrointestinal (GI) absorption, blood–brain barrier (BBB) permeation, CYP2D6 inhibition, and Lipinski violation (Table 5). Notably, tofacitinib exhibits moderate lipophilicity and solubility with high GI absorption but lacks BBB permeation. Ribociclib and topiroxostat, despite their high GI absorption, demonstrate contrasting BBB permeation abilities, with ribociclib showing the potential inhibition of CYP2D6. Amodiaquine and gefitinib, with high lipophilicity, solubility, and GI absorption, showcase BBB permeation and CYP2D6 inhibition. These data provide a comprehensive overview of the ADME profiles, aiding in the assessment of these compounds’ potential suitability for drug development.

## Section: 3. Methodology › 3.1. JAK2 Datasets and FDA-Approved Drug Library

JAK2 active and decoy datasets were obtained from the DUD-E website (https://dude.docking.org/) (accessed on 15 January 2024). The active dataset contained 107 compounds, while the decoy dataset had 6500 compounds. All molecules were expressed as canonicalized SMILES strings with DUD-E ID and ChEMBL ID numbers. Compounds were labeled as active and decoy in legend. The FDA-approved drug library was downloaded from the website of Selleck Chemicals (https://www.selleckchem.com) (accessed on 16 January 2024). FDA-approved drug molecules, totaling 3105 in number, were represented in SDF (structure-data file) format and transformed into SMILES strings using RDKit.

## Section: 3. Methodology › 3.2. Molecular Descriptor Generation Using RDKit

Molecular descriptors for the compounds were generated using RDKit. RDKit is an open-source, high-performance cheminformatics and machine learning toolkit written in Python (https://www.rdkit.org) (accessed on 20 January 2024). The toolkit offers features for calculating molecular descriptors, producing chemical attributes, and visualizing chemical data.

## Section: 3. Methodology › 3.3. Deep Learning Architecture

The JAK2 active and decoy datasets were split for training, validation, and test sets in 8:1:1 ratio. The GraphConvMol model from DeepChem (https://deepchem.io/models) (accessed on 22 January 2024) was employed as the deep learning algorithm. The GraphConvMol, being a graph convolutional neural network, adeptly processes graph-structured inputs like molecular graphs. A concise overview of its architecture is as follows: Initially, the molecular structures are transformed into graphs where atoms represent nodes and bonds acting as edges. Following this, several graph convolutional layers are employed to derive hierarchical features from these molecular graphs. These layers are equipped with adaptable parameters that have varying weights, fine-tuning the model’s learning to precisely grasp the nuances of molecular structures. During the training phase, the model refines its performance by minimizing a loss function in relation to the input molecular datasets. This optimization adjusts the convolutional layers’ weights through backpropagation. Ultimately, the model seeks to predict specific attributes of molecules, such as solubility, bioactivity, and potential toxicity, grounded on their structures.

## Section: 3. Methodology › 3.4. JAK2 Structure Retrieval

The X-ray structure of human JAK2 protein (PDB ID: 3JY9 with 2.10Å resolution) was obtained from the Protein Data Bank (PDB) (https://www.rcsb.org) (accessed on 25 January 2024), and minimized Discovery studio and UCSF Chimera [46,47]. The JAK2 protein, made up of helices, sheets, coils, and turns, was subjected to further analysis like quantitative protein structural analysis using the online freely accessible server VADAR 1.8 (http://vadar.wishartlab.com/) (accessed on 25 January 2024). Additionally, Discovery Studio was employed to analyze and compute the Ramachandran graphs [46].

## Section: 3. Methodology › 3.5. Prediction of Active Binding Site

The interacting site in the protein’s holo-structure most likely determines the binding pocket of the protein where the active ligand binds [48]. The JAK2 X-ray structure was retrieved from PDB (PDB ID: 3JY9). The co-crystalized ligand was selected and the binding sphere was constructed by the current selection technique in the binding site window of Discovery Studio to define the active pocket. The interacting amino acids were chosen by the ligand interaction approach of Discovery Studio for the accuracy of the binding site generation. Consequently, the binding sphere was contracted to become restricted to our selected amino acids.

## Section: 3. Methodology › 3.6. Molecular Docking

Molecular docking is the most commonly used method for the evaluation of the interactions and conformations of ligands against the target proteins [49]. It anticipates the association strength or binding compatibility between ligand and protein based on preferred orientation by using scoring algorithms [40,50]. The waters and the ligand molecule were removed from the receptor and the hydrogens were added by Discovery Studio’s protein preparation module, prior to docking. The ligand preparations were also carried out for reference and candidate compounds, tautomerization was carried out, ionization was changed, and bad valences were fixed by Discovery Studio’s ligand preparation module. Furthermore, the conformation prediction was to the top 10. Therefore, the Discovery Studio’s CDocker module was employed to perform molecular docking of the screened ligands against JAK2 with the default orientation and conformation. The lowest CDocker interaction energy values (in kcal/mol) were utilized to estimate the best-docked complexes.

## Section: 3. Methodology › 3.7. Binding Interaction Analysis

The 3D graphical evaluations were carried for the docked complexes using UCSF Chimera 1.10.1 [47] and Discovery Studio to study the interactions of screened drugs against JAK2 protein.

## Section: 3. Methodology › 3.8. JAK2 Kinase Inhibitory Activity Assay

Tofacitinib, topiroxostat, and gefitinib were obtained from Sigma (St. Louis, MO, USA), and ribociclib and amodiaquine were obtained from Selleck Chemicals (Houston, TX, USA). The compounds were dissolved in DMSO. JAK2 kinase activity was measured using the JAK2 Assay Kit from BPS Bioscience (#79520, San Diego, CA, USA) following the manufacturer’s instructions. The reactions were incubated at 30 degrees Celsius for 45 min. Then, 50 µL of the Kinase-Glo MAX reagent (Promega, Madison, WI, USA, #V6071) was added and covered the plate with aluminum foil, and incubated at room temperature for 15 min. Finally, luminescence measurements of the ATP product were obtained using a microplate spectrophotometer (Molecular Devices, San Jose, CA, USA). All assays were performed in triplicate.

## Section: 3. Methodology › 3.9. Statistical Analysis

All values shown in the figures were expressed as the mean ± SD obtained from at least three independent experiments. Statistical significance was analyzed by two-tailed Student’s t-test. Data with values of p < 0.05 were considered as statistically significant.

## Section: 4. Conclusions

As the landscape of drug development evolves, becoming more intricate and expensive, it is imperative to leverage cutting-edge techniques that streamline the process. The integration of artificial intelligence into this process offers a fast-track approach to pinpointing potential candidate compounds that might be the next therapeutic breakthroughs. The research outlined in this study underscores the compelling advantages of such a strategy and its efficiency in drug discovery. This study innovates drug discovery by integrating graph convolutional networks (GCN) with molecular docking, surpassing traditional methods. GCN captures complex three-dimensional molecular structures, enhancing predictive accuracy for binding affinities. Combined with molecular docking, it offers a more comprehensive screening, efficiently identifying potential drug candidates. It marks a significant step forward in drug screening, potentially applicable to a wide range of molecular targets. By deploying the graph neural network algorithm within the DeepChem library’s deep learning module, we identified compounds that efficiently fit the active region of the target JAK2, effectively obstructing its active site at a computational level. Several of the top predicted drugs are recognized JAK2 inhibitors, attesting to the solidity of our methodology. Additionally, several compounds, including ribociclib, amodiaquine, topiroxostat, and gefitinib, previously not linked with JAK2 inhibition, exhibited a promising JAK2 inhibitory potential. Experimental validation confirmed the deep learning and molecular docking results. As a result, we propose these compounds as prospective novel JAK2 inhibitors. In conclusion, a deep learning-centric approach to drug repositioning emerges as a pivotal strategy in advancing drug discovery, not just for JAK2 inhibitors but for a broad spectrum of therapeutic targets.

## Section: 5. Limitations

In this study, the datasets were primarily derived from FDA-approved drugs and the DUD-E database. While these sources are valuable, they may not fully represent the extensive diversity of molecular structures, which could impact the generalizability of our model. Consequently, the performance of our model might vary when applied to datasets with different chemical spaces, potentially limiting its broader applicability. Future research directions will focus on incorporating a wider range of chemical libraries to enhance dataset diversity. Additionally, we plan to explore advanced computational algorithms to address potential biases in the data and improve the robustness of our model. These steps are crucial for adapting our methodology to other protein targets and assessing its utility across diverse therapeutic areas.


---

# Eco-Technological Evaluation of Natural Phytochemicals Potential Drug Molecules Against Main Protease: A Machine Learning Algorithm

- **Authors:** Silambarasan Tamil Selvan, Mukesh Kumar Dharmalingam Jothinathan
- **Issuer:** Cureus
- **Type:** Scientific article
- **Published:** 2024-03-28
- **Language:** en
- **DOI:** 10.7759/cureus.57151
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38681365/
- **Licence:** CC-BY

## Section: Abstract

AbstractIntroduction: The global viral pandemic has rapidly spread, leading to many individuals experiencing the infection. Coronaviruses (CoVs) are among many viral families that infect different types of mammals. They can spread to humans and cause gastrointestinal, neurological, and respiratory problems. The present investigation has discovered flavonoid compounds as promising molecular agents with potential antiviral activity against virus proteins, specifically main protease (Mpro).Methodology: A comprehensive in silico screening of natural compounds derived from medicinal plants was performed in the present study. It included parameter assessments such as drug-likeness, pharmacokinetics, molecular docking, toxicity evaluations, bioavailability assessments, and molecular target exploration. In this systematic approach, the primary objective was to identify potential lead compounds. These phytochemicals were investigated as drug candidates to provide a detailed understanding of their molecular properties.Results: The Mpro binding energy values were -10.637, -12.752, -7.813, -15.732, -6.449, -5.578, -8.037, and -8.52 kcal/mol for isoquercetin, narirutin, myricetin, hesperidin, silibinin, baicalein, taxifolin, and petunidin. Molecular simulations were conducted on two flavonoid compounds - hesperidin and narirutin - stable over 100 nanoseconds in the Coronavirus protein.Conclusions: The computational study we conducted is promising, but to validate the action of these compounds, further experimental studies are needed, with a critical component of the research being the conduct of in vitro and in vivo experiments.Keywords: free energy binding, toxicity, density functional theory, molecular simulation, molecular docking, flavonoids, main protease, coronavirus

## Section: Introduction

Coronaviruses (CoVs) are among many viral families that infect different types of mammals. They can spread to humans and cause gastrointestinal, neurological, and respiratory problems. Before this, two pandemic epidemics caused by the Middle East respiratory syndrome CoV (MERS-CoV) and SARS-CoV-2 seriously infected the human population [1]. Similar to SARS-CoV-2, which is currently responsible for deadly viral pneumonia and raising concerns about global health [2,3], the CoV has enormous viral RNA genomes and is characterized by positive-sense, single-stranded RNA viruses. The main protease (Mpro), a widely recognized CoV protein, has been identified as a potential therapeutic target. Mpro plays a crucial role in transcribing viral RNA, leading to the synthesis of polyproteins. Mpro, a widely recognized CoV protein, has been identified as a potential therapeutic target [4,5].

The South Indian medicinal plants contain various potential bioactive compounds, viz., flavonoids, polyphenols, therphiniods, phenolic acids, anthocyanins, and tannins [6-8]. The medicinal plant-derived bioactive compounds have demonstrated various pharmacological and biological activities, including anti-proliferative, anti-inflammatory, anti-atherogenic, anti-allergic, antimicrobial, immunomodulatory, and antiviral properties for human health [9,10]. They are also nontoxic, natural compounds that are friendly to the environment.

This study focused on identifying potential natural bioactive drug molecules from medicinal plant-derived flavonoid compounds. Compounds were used to investigate the suppression of corona viral protease and replication receptors, viz., Mpro protein using molecular docking, silicon toxicity, binding free energy calculations, molecular dynamics simulation, and density functional theory (DFT) analysis. The study opens further avenues for the development of functionally improved drug molecules.

## Section: Materials and methods

Selection of ligand and preparation

The eight flavonoid ligand compounds were selected from various medicinal plants and the flavonoid compounds selected, viz., taxifolin, narirutin, hesperidin, baicalein, isoquercetin, myricetin, petunidin, and silibinin. The compound structures were derived from the PubChem database. The ligands were prepared and screened against the predicted CoV. The Mpro structure used Maestro v11 (Schrödinger, JSS University, Ooty) software. The design was developed with the Schrödinger protein preparation wizard. Protein optimization was performed at a neutral pH, and then the building structure with optimized liquid simulated force field potentials for all atoms was reduced. A 10 x 10 Å to 10 Å receptor grid was generated with Glide v7.1 (Schrödinger, New York, NY) in the Mpro-defined retention site residuals. The ligand was modified for chemical accuracy (protonation), stereochemical variations, ionization, neutral pH 7.0 ± 2.0, and energy using LigPrep modules [11].

Evaluation of silicon toxicity

The Swiss ADME online software was used to analyze the toxicity of the chosen flavonoid compounds, and the cytotoxicity, immunogenicity, hepatotoxicity, mutagenicity, and carcinogenicity toxicity parameters were evaluated. In this study, animal models were analyzed to identify the hazardous dose and reduce the number of models tested on animals [11].

Drug molecules and protein interaction analysis

The Maestro v11 software (Schrödinger, version 11) was used to do a molecular docking study of the active sites of the CoV Mpro protein with ligands. The polar H-atoms and Gasteiger charges were added to the protein amino acid atoms, and the appropriate protonation forms were assigned to the crystal Mpro protein structure. The protein structure's water (H2O) molecules were eliminated, and the protein's ligand and receptor bins (-0.28 to 0.55), outline bins (-0.22 to 0.44), and ligand and receptor sphere (1.3 to 1.55) were fixed. For Mpros, the outside of active sites remained unaltered, while partially active sites were kept flexible for the docking process. The compounds' competency docking score and binding hit were assessed and reported [11,12].

Molecular dynamics (MD) simulations

The Desmond v. 4.2 software program (Schrödinger, JSS University) examined the MD simulation evaluation to confirm prospective flavonoid compounds' ligand-receptor binding energy, interactions, and stability behavior. Explicit MD simulations were analyzed to run 100 ns MD simulations and neutralize water molecules. Ions were chosen to form solvating complexes. Energy minimization and periodic boundary conditions with an acceptable 1,000 kJ/mol/nm value were utilized. The outcomes of MD simulations of protein-ligand complexes were examined and documented [11].

Analysis of DFT

Gaussian 09W software (Schrödinger, JSS University) was used to analyze the interactions between receivers and ligands in electronic structures were examined using DFT. The most occupied homo molecular orbital and the least occupied lowest unoccupied molecular orbital (LUMO), electron affinity, and electrophilicity indicator are the estimated parameters used to describe the electronic and structural characteristics of the five best-hit compounds. According to the study, molecular electrostatic possible surfaces (MEPs) were calculated using population analysis calculations and depicted using Gauss View 5.0. These parameters account for the magnitude of the ligand interactions at the binding site of CoV Mpro [11].

Analysis of binding free energy calculation

In the prime MMGBSA (molecular mechanics with generalized Born and surface area solvation) approach, the free energy binding of the ligand and protein was calculated. This method was used to show and guess the correlated free energy of binding (ΔGbind ) for each group of ligand molecules to the protein. The docking poses were made as small as possible using the OPLS-AA2005 force field, and the Generalized Born/Surface Area (GB/SA) continuum solvent approach was utilized to determine the free energy of binding for the ligands. The MMGBSA model and Surface Generalized Born (SGB) design used Desmond software to perform the simulation analysis [13].

## Section: Results

Selection and preparation of ligands

The eight flavonoid ligand compounds were selected from different medicinal plants. The molecular docking was analyzed for the chosen flavonoid ligands. The selected ligands were obtained in SDF format, and their two-dimensional (2D) structures were generated from the PubChem database. The ligand compound files in SDF format were converted to protein database (PDB) format using Discovery Studio software. The isoquercetin, followed by narirutin and myricetin, effectively interacted with the CoV Mpro protein. The Mpro demonstrated particularly efficient binding to the hesperidin flavonoid, followed by narirutin, isoquercetin, taxifolin, and petunidin.

Evaluation of silicon toxicity

The chosen flavonoid compounds were subjected to analysis using the SWISS-ADME database to enable the prediction of their toxicity. The findings of the absorbent analysis (A), which provided a summary of the ADME prediction, indicated that taxifolin, narirutin, hesperidin, baicalein, isoquercetin, myricetin, petunidin, and silibinin were predicted to exhibit high permeability (Table 1). The expression of low absorption in human intestinal absorption (HIA) value was less than 30%. The results indicated that the human gut's absorption of all flavonoid compounds was extensively investigated. Medications and other chemical substances that entered the body were eliminated by a transmembrane glycoprotein known as P-glycoprotein, which is involved in ATP binding [14,15]. The results of the study indicated that taxifolin, hesperidin, isoquercetin, myricetin, silibinin, and narirutin, which are nonsubstrate inhibitors of P-glycoprotein, exhibited either substrate or inhibitory properties toward P-glycoprotein. In the distribution (D) study, it was expected that the BBB permeability, with a logBBB value greater than 0.3, would have a high capacity to cross the blood-brain barrier [16]. All the flavonoids in this study were predicted to be BBB-permeable. CYP2D6 and CYP3A4 were the two crucial cytochrome P450 (CYP) liver enzyme subtypes in the metabolism (M) study [17]. The results demonstrated that taxifolin, narirutin, hesperidin, isoquercetin, myricetin, petunidin, and flavonoids did not support CYP2D6. Baicalein and silibinin were the only compounds that supported CYP2D6 and CYP3A4. These findings suggested that the liver might metabolize these flavonoids. The hepatocytes' basolateral membranes facilitate the absorption of drugs such as atorvastatin and metformin by using organic cation transporter 1 (OCT1), organic anion-carrying polypeptide 1B1 (OATP1B1), and organic cation transporter 1B3 (OATP1B3).

Molecular docking studies

In the molecular docking experiments, the active residues in the binding cavity of proteins and ligand interactions were investigated for their known binding affinities. By adjusting the grid size to 3 Å, the active residues in the binding pocket of the protein (Mpro) were identified concerning the ligands. The docking score was considered to predict better interactions [18]. The flavonoids are listed in Table 2 based on the docking score. Based on the binding energy, the ranges for the eight individual flavonoids tested against Mpro were -3 to -15 kcal/mol, respectively. Isoquercetin had the highest docking score (-11.68 kcal/mol) against the Mpro complex out of all the examined compounds. Isoquercetin exhibited six bonds, including five hydrogen bonds (THR6854, CYS7007, and SER7074) and one pi-pi stacking (TRP6987) to the active residues (Figure 1; Table 2). Hesperidin (-15.73 kcal/mol) had the highest docking score for the Mpro, followed by narirutin and isoquercetin. Hesperidin and active residues of the major protease were shown to have about five active interactions. The Glu166 residue was a crucial amino acid implicated in the dimerization of Mpro and the development of the substrate binding pocket, and HIS41, GLU166, GLN189, and ARG188 residues were said to operate as active sites for the ligand binding site.

MD simulations

The highest docked complexes (isoquercetin and narirutin) received 100 ns of MD simulations. The findings of the MD simulations demonstrated that the ligand binds steadily to the active site residues Mpro. Figure 2 displays the root-mean-square deviations (RMSDs) of the backbone atoms of the Mpro and associated ligands. The docking experiments based on interactions with residues such as His41, His 164, Glu166, Asp187, Thr190, and Gln192 demonstrated minor RMSD variations in the MD results of Mpro residues. It suggests that both drugs (isoquercetin and narirutin) were closer to the Mpro active site and had a stronger affinity. Similar to this, the MD findings revealed low RMSD variations in Mpro residues in connection with docking residues such as Asn6853, Thr6854, Thr6856, Trp6987, and Cys7007 [19].

Analysis of DFT

The DFT calculations in the gas phase were performed using the B3LYP-311 G (d,p) method. A molecule with a higher HOMO value has a more potent electron donor, whereas one with a lower HOMO value has a weaker electron acceptor. Additionally, intermolecular charge transfer and molecular bioactivity have been significantly impacted by the smaller energy gap between LUMO and HOMO energies. Therefore, a significant energy difference in the hit molecules harms the electron's transition from HOMO to LUMO. It eventually contributes to the Mpro inhibitor's low affinity. The following electronic band gap values were obtained: 0.20525 a.u. for isoquercitrin, 0.13454 a.u. for silibinin, 0.13994 a.u. for baicalein, 0.12717 a.u. for taxifolin, 0.05562 a.u. for petunidin, 0.17683 a.u. for narirutin, 0.1287 a.u. for myricetin, and 0.13768 a.u. for hesperidin (Figure 3). The cloud density of the HOMO and LUMO boundary orbital states was established in the red and green regions, respectively. Recent studies have demonstrated that frontier molecular orbitals must be considered when examining organized activity relations [20].

Analysis of binding free energy (MMPBSA)

The interaction-binding free energy (MMPBSA) between the Mpro protein and flavonoid compounds was calculated using Desmond software. Additionally, per-residue energy decomposition (MMGBSA) was analyzed from the MD simulations. The binding free energy for individual components, namely, H-bond, coulomb, and Van der Waals forces, was calculated using the Desmond software tool (MMPBSA/MMGBSA). Table 3 shows that these values were attributed to energy bonding with flavonoid compounds and CoV proteins. The Gibbs binding free energy for the interaction between flavonoid compounds and Mpro proteins was recorded as -32.13 kcal/mol for narirutin and -36.37 kcal/mol for isoquercetin [21-23].

RMSD, root mean square deviation

## Section: Discussion

The medicinal plant-derived bioactive compounds have demonstrated a variety of pharmacological and biological activities, including antiproliferative, anti-inflammatory, antiatherogenic, antiallergic, antimicrobial, immunomodulatory, and antiviral properties for human health [9,10]. They are also nontoxic, natural compounds that are friendly to the environment. Flavonoid chemicals from medicinal plants have been shown to have antiviral action against the H1N1, Ebola, influenza, and dengue viruses [10]. One of the crucial novel therapeutic strategies for viral infections and an inhibitor of viral proteases is flavonoid chemicals found in natural medicinal plants [11]. The benefits of flavonoids include being active even at low medication concentrations, being highly accessible to nature, being varied, and having no or very few negative effects. The main resource for discovering and developing a large number of new potential antiviral medicines are natural medicinal herbs that modulate flavonoids [12,13]. The group of phenyl benzopyrones, known as flavonoids, has a low molecular weight and many pharmacological effects, such as anti-inflammatory, antiviral, and antioxidant activities [14,15]. Flavonoids inhibit the release of viral particles from being executed, which disrupts viral replication. Their effectiveness in reducing viral amplification in the human body [16,17]. The process of medication excretion is subject to the effect of two key factors, namely, the hydrophilicity and molecular weight of the medicine [24,25].

As reported by Jain et al. [26], 10 natural flavonoid compounds were analyzed for docking scores with the spike protein of SARS-CoV-2 virus, including apigenin at -7.8 kcal/mol, chrysin at −8.1 kcal/mol, fisetin at -8.3 kcal/mol, galangin at -8.2 kcal/mol, hesperetin at -7.7 kcal/mol, luteolin at -8.0 kcal/mol, morin at -8.1 kcal/mol, naringin at -9.8 kcal/mol, quercetin at -8.2 kcal/mol, rutin at- 9.2 kcal/mol, and dexamethasone at -7.9 kcal/mol. Molecular simulation analysis was conducted on 10 flavonoid compounds, and their stability was determined at 0.2 to 0.4 ns.

Imran et al. [27] investigated the flavonoid compounds' activity against SARS-CoV-2 Mpro protein and docking score, namely, -9.9 kcal/mol of amentoflavone, -8.0 kcal/mol of kaempferol, -8.0 kcal/mol of baicalein, -7.6 kcal/mol of catechin, -8.2 kcal/mol of naringin, -7.7 kcal/mol of naringenin, -7.8 kcal/mol of galangin, -8.1 kcal/mol of kuwanon C, -8.0 kcal/mol of morin, -8.3 kcal/mol of morusin, -8.3 kcal/mol of scutellarein, -8.2 kcal/mol of wogonin, -8.3 kcal/mol of apigenin, and -8.0 kcal/mol of fisetin, respectively.

The primary transporters responsible for the elimination of cationic medications into the urine are organic cation transporters (OCTs) and multi-drug- and toxin-extrude proteins (MATEs) [4]. The findings of this study indicate that the flavonoids examined in this study are not expected to hinder the activity of MATE-1, OCT-1, and OCT-2. This suggests that the flavonoids have a safe disposal profile. The findings from the experiment on toxicity (T) indicated that all quinolones have induced ocular corrosion and carcinogenicity. In their study, Imran et al. [26] showed that amentoflavone, kaempferol, baicalein, catechin, naringin, naringenin, galangin, kuwanon C, morin, morusin, scutellarein, wogonin, apigenin, and fisetin flavonoids had good intestinal absorption, with absorption rates between 96% and 98%. The low absorption rate of the molecules is correlated with their high molecular weight. Ninety-seven percent of the high-molecular-weight amentoflavone compound was absorbed in the intestine. According to our test, flavonoids are solubilized in water between -1 and -5, with the aqueous solubility of flavonoids ranging from 3.78 to 2.77, which is moderate to high. Finally, the results of the prediction analysis revealed that the ADMET properties of flavonoids closely resemble those of established anti-CoV and anti-SARS-CoV-2 drugs. It provides evidence to consider the repurposing of specific pharmaceuticals for the therapeutic management of CoV. Flavonoids have been observed to inhibit the function of drug transporters, leading to a decrease in the efficacy of pharmaceutical substances, thereby giving rise to drug-drug interactions that hold therapeutic significance [26,27]. Thus, this study investigated the effects of taxifolin, narirutin, hesperidin, baicalein, isoquercetin, myricetin, petunidin, and silibinin. The outcome demonstrated that all the chosen flavonoids seemed to be OATP1B1-OATP1B3 inhibitors.

According to Imran et al. [26], Mpro complexes with Amentoflavone and morusin were simulated for 100 ns with the stability and fluctuation of the receptor-ligand complexes analyzed during simulations, and a backbone RMSD was used to calculate the resulting trajectory. Throughout the entire simulation, the protein-ligand complex remained stable. During the first 10 ns, a few fluctuations in protein were seen, but then it remained stable for 90 ns. Between Thr24 and Leu50, Asn142 and Cys145, His163 and Thr169, and Val186 to Gln192, 27 ligand contacts were observed with residues in proteins. In addition to hydrogen bonds, these residues also formed ionic bonds, hydrogen bonds, hydrophobic bonds, and water bridges. The active residues of ligands are in hydrophobic interaction with the polar-forming ligands, resulting in ligand stability.

Limitations and future recommendations

This study marks a promising start for developing plant-based antiviral compounds; however, inherent limitations must be acknowledged. A predictive model and a computational analysis were used to obtain the results of our study. Consequently, experimental validation is crucial since it provides concrete evidence of a compound's safety and effectiveness.

## Section: Conclusions

The COVID-19 Mpro complex proteins were docked with eight compounds. Mpro showed high docking scores on hesperidin, narirutin, and isoquercetin. This study evaluated essential antiviral action from plant-mediated flavonoid compounds. These flavonoids could be used as antiviral medications to control the CoV. As a result, plant flavonoid derivatives may shortly produce a fresh development in synthesizing natural drugs and various biological applications

## Section: Acknowledgments

The authors would like to thank the Centre for Global Health Research, Saveetha Medical College and Hospitals, Saveetha Institute of Medical and Technical Sciences (SIMATS), Saveetha University, Chennai, Tamil Nadu, India.


---

# Edridge Green Lecture 2022-demystifying clinical trials and regulatory approvals in drug development

- **Authors:** Victor Chong
- **Issuer:** Eye (London, England)
- **Type:** Scientific article
- **Published:** 2024-12-05
- **Language:** en
- **DOI:** 10.1038/s41433-024-03520-4
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39639153/
- **Licence:** CC-BY

## Section: Abstract

AbstractThis article provides a comprehensive overview of clinical trial design and regulatory pathways essential for drug development, specifically in the context of retinal diseases. Key concepts include trial structure, efficacy and safety endpoints, and regulatory expectations from agencies like the FDA. It delves into recent regulatory advancements, such as the inclusion of low-luminance vision as a secondary endpoint and analyses case studies from age-related macular degeneration (AMD) trials. Approvals for key retinal drugs, such as ranibizumab and aflibercept, treatments for AMD and diabetic macular oedema, are discussed highlighting criteria like the 15-letter gain/loss in visual acuity as approvable/clinical meaningful efficacy endpoints. Insights into geographic atrophy (GA) and diabetic retinopathy trials showcase the evolving landscape, where anatomical endpoints and new drugs bring fresh challenges and opportunities. It also emphasizes the importance of academic-industry collaboration, citing instances of gene therapy development and innovative endpoint measures like the Multi-Luminance Mobility Test for retinal dystrophies. The overarching aim of this lecture was to demystify the process that spans the design of clinical trials to regulatory approval of drugs so that clinicians understand these complexities. In particular, it is important to understand the reasons behind selection of trial design, inclusion and exclusion criteria, primary and secondary efficacy endpoints and safety endpoints. Since this lecture, there have been important changes in this field including new guidance from the Food and Drug Administration (FDA) as well as lessons learnt from recent drug approvals that are included in this manuscript.Subject terms: Predictive markers, Outcomes research

## Section: Understanding the rules of engagement with the FDA and similar regulatory agencies

For a drug to be approved by the FDA or other regulatory agencies, the pivotal study must define a primary efficacy endpoint which shows a clinically meaningful benefit in a well-controlled study with adequate statistical power. In a common disease, two parallel studies are planned, which are usually similar in design. The primary endpoints and/ or the comparator used in the trials can be slightly different but to gain approval, the results from both studies need to be positive.

## Section: Wet AMD trials

In retina, only a handful of endpoints have been used for drug approval [1]. The most commonly used is the change of best corrected visual acuity (BCVA). It can be the proportion of patients with a 15-letter gain or prevention of a 15-letter loss in the treated group vs the control group. For instance, ranibizumab was approved for neovascular age-related macular degeneration (nAMD) based on the proportion of eyes that lost less than 15 letters. In the ranibizumab group, 91–98%, met this endpoint compared with 60–66% of the control group over 12 months [2].

For diabetic macular oedema (DMO), the endpoint was the proportion of eyes that gained 15 letters. For the ranibizumab arms, 34–45% achieved this endpoint as compared to 12–18% in the control groups over 2 years [3]. The reason that 15 letters was chosen is that this change is considered clinically meaningful and also not likely to occur due to measuring errors. A study in Moorfields showed that a patient can have a six to seven letters difference in BCVA ETDRS score on the same day by different certified visual acuity assessors [4]. This should not be confused with the often-reported mean visual gains of about 10 letters improvement in patients treated with anti-VEGF in wet AMD and more often in DMO patients. These are easier to understand but were not used as approvable primary endpoints until recently. The aflibercept approval for DMO was based on non-inferiority of the proportion of eyes that did not lose more than 15 letters compared to ranibizumab, which was achieved by about 95% in both aflibercept and ranibizumab groups [5].

The concept of non-inferiority for comparing treatment with different anti-VEGF agents for wet AMD using mean BCVA changes from baseline was probably first introduced in the CATT study [6] and also adopted in the IVAN study [7]. The statistical concept of non-inferiority came from the generic and biosimilar world where equivalence has to be proven to the originator drug. It is beyond the scope of this paper to discuss the principle in detail, but non-inferiority using mean change from baseline in BCVA letter score has only been used in the most recent approvals, of brolucizumab, faricimab and aflibercept high dose. In a recent FDA draft guidance on neovascular AMD development, a 4.5 letter margin was set against on label ranibizumab or aflibercept [8].

It is important to understand that if superiority study design is to be used in the future, it might be insufficient to show statistical significance of superiority alone, there is also a need for the change to be clinical meaningful. For the FDA, that would be 15 letters of BCVA. In other words, if “mean change from baseline” is used, the study drug has to be 15 letters superior to the comparator. The alternative would be to have a statistically significant proportion of patients with 15 letters loss or gain. In wet AMD, if the new drug is to be compared with the current standard of care (aflibercept 2 mg being the most common anti-VEGF comparator), it would be challenging for many patients to have 15 letters loss on aflibercept 2 mg, so it would be likely that the sponsor (drug company) would go for an endpoint of 15 letter gain. However, to achieve 15 letters gain, further considerations need to incorporated to the eligibility criteria. For example, it would be challenging to achieve 15-letter gain if the baseline vision is good, so the inclusion criteria need to be restricted to only allowing patients with poorer baseline vision that have a better chance to obtain a 15-letter gain. Nonetheless, there are caveats in this assumption as patients with poorer baseline vision might also have irreversible structural changes such as fibrosis that would not permit a gain in BCVA.

However, the FDA has clarified that the new drugs do not need to be compared against the standard of care. In fact, a new drug could be compared to no treatment, sham or a much lower dose of the new drug (which is practically non-effective). In wet AMD, that would be difficult as vision loss is rapid and probably not reversible after a period of no treatment. Furthermore, the study period for wet AMD for approval is usually at least 9 months, so abstaining from treatment in this potentially blinding condition would raise ethical issues in conducting such a study. There are ways to get around this, by adding rescue therapy. Rescue therapy means if the patient has lost significant amounts of vision, the investigator can then treat the patient with standard of care (an approved anti-VEGF agent). However, this leads to variations, as the amount of vision loss that is acceptable to one investigator could be very different from another. In addition, if the primary endpoint is the proportion of patients with 15 letters loss, then the data could be messy when different investigators apply rescue treatment to patients at varying levels of vision loss before a 15-letter loss occurs.

It is also acceptable for BCVA to be measured in different light conditions. Recently, low luminance VA (LLVA) has been studied and considered at least as a secondary endpoint. LLVA is the BCVA after refraction with a 2+ neutral density filter placed in front of the patient’s eye. In general, LLVA is lower than BCVA, and the difference between BCVA and LLVA is called the low luminance deficit (LLD). The importance of LLD is not clear but there are some data to suggest that it has a potential in the prediction of treatment outcomes [9]. Therefore, if a drug developer believes that their drug can improve LLVA without improving BCVA, the FDA appears to be willing to accept that as the primary efficacy endpoint, providing the difference in outcome between the trial arms is 15 or more letters.

In addition to efficacy requirements, the FDA has also provided safety guidance for wet AMD trials. This being that at least 300 patients with safety data should have been treated to the primary endpoint (usually more than 9 months) at the intended marketed dose or higher. This means that the sample size needs to consider drop-outs to obtain a final sample of at least 300. This safety data does not include patients who were treated with a lower dose in the study. In addition, there should be “enough” patients treated for 2 years, the exact number is not given. This explains why there are parallel Phase 3 clinical trials on an intervention that report primary outcomes at 9–12 months. At least one of these two studies has to continue for 2 years and have a final sample size of 300 patients. This guidance is limited to small molecules and biologics. The rules for gene therapy are also different, and the duration of safety data collection is likely to be much longer.

## Section: Geographic atrophy

In 2022, at the time of this lecture, two anti-complement trials were undergoing regulatory approval [10]. At that time, the FDA had agreed in principle to the use of differences in the slope of the mean rate of GA lesion growth as an approved endpoint. At the time of writing this manuscript in September 2024, anti-C3 had been approved by the FDA, but not by the European Medicines Agency (EMA). It is also interesting that both anti-C3 and anti-C5 were given a label of ‘geographic atrophy’ despite the anti-C3 trials including both foveal and non-foveal involving lesions whilst in the anti-C5 trials, only non-foveal involving lesions were included. This has significant implications for future GA study designs. Foveal involving lesions have less opportunity for visual change, so only including non-foveal lesions in a study means a better chance of showing functional / vision benefit (i.e. less visual loss over time). Based on the anti-C3 trials, the treatment benefit of anti-C3 appears to be higher in non-foveal involving lesions, partly explained by the slower growth rate of foveal involving lesions.

In drug development, being the first in class and particularly the first ever treatment for a condition, is very challenging. However, compounds that are considered to be followers have the advantage of learning from the lead molecule. It is not uncommon that the third molecule in the class ends up being the market leader, an example being aflibercept, the third anti-VEGF approved for retinal vascular diseases.

## Section: Diabetic retinopathy

Diabetic retinopathy (DR) is another retinal condition with an FDA-approved anatomical endpoint. The diabetic retinopathy severity scale (DRSS) score [11] was used for approval of intravitreal (IVT) anti-VEGF injections for the treatment of DR by the FDA. The proportion of eyes with a 2 or more step improvement of DRSS score was used for the approval of ranibizumab [12] and aflibercept [13]. It was somewhat surprising that faricimab did not receive approval for DR based on their DMO study. One interpretation is that there is no agreed non-inferiority margin accepted by the FDA for DRSS, and faricimab did not show superiority to a control group but rather showed similarity to aflibercept in their pivotal DMO studies [14]. Similarity does not equate to non-inferiority. Recently, a company suggested that for an oral compound, a person level (combining the scoring of 2 eyes) 3 step DRSS score deterioration can also be accepted by FDA. This unsurprising as this was already used by an oral Protein Kinase C inhibitor (ruboxistaurin) some years ago [15]. Currently, anti-VEGF agents are not approved for DR in Europe other than ranibizumab for proliferative diabetic retinopathy (PDR). The exact reason for this decision is not clear. The PDR approval might have been based on data from DRCR.net Protocol S [16], which showed some improvement of visual function. For DR in general, regulatory authorities in Europe might be looking for different endpoints rather than a 2 steps DRSS improvement.

Returning to the discussion on study design, although ranibizumab and aflibercept are approved for diabetic retinopathy in the US, for a new drug, the sponsor can conduct a superiority study against no treatment or sham treatment or placebo. This is more acceptable to the community as despite ranibizumab and aflibercept being approved for this condition, in real-life, their use for this indication is low. Therefore, the standard of care for this condition is still observation despite the approval of these anti-VEGF agents. It would not be an issue in countries that have not approved their use for diabetic retinopathy.

It is also important to understand that the new drug does not need to be better than historic efficacy data of ranibizumab or aflibercept. It has to be statistically significantly and clinical meaningfully better than the comparator (sham treatment or placebo). Clinically meaningful has been established by ranibizumab and aflibercept but the definition of the minimum level of efficacy based on DRSS score that would be acceptable is unclear.

Other considerations such as the invasiveness of the treatment or the adverse event rate of the treatment may also need to be taken into account. For instance, gene therapy given through one single suprachoroidal injection might be different from another intravitreal drug given every 8 weeks. Similarly, oral therapy may have different endpoints. Although oral compounds might appear attractive to ophthalmologists, effective oral compounds often have significant risks of systemic adverse events. Finally, the convenience of oral treatment for patients also needs to be compared to repeated intravitreal injections, which although relatively safe, have a large treatment burden for both patients and the health care system. Topical therapy such as eyedrops could potentially provide a good solution and ophthalmologists look forward to such advancements in retinal diseases.

## Section: Masking to eliminate bias

It is common practice in almost all clinical trials for oral or topical treatments to use a placebo. However, for intravitreal development, it is considered unethical to perform an intravitreal injection with a placebo or saline. Recently, the FDA stated [17] that an intravitreal sham injection is not generally considered good enough for masking as the agency believes patients can tell the difference between an intravitreal injection and a sham injection. The exact reason for this decision is unknown as intravitreal sham injections have been standard for most intravitreal retinal drug approval studies including the most recent approvals of faricimab and high-dose aflibercept 8 mg. It is probably true that patients might have some visual disturbance when the drug is injected into the eye.

In subretinal gene therapy, there is no masking as it is unethical to perform surgery without injecting the gene. Similarly, when injecting intravitreal small molecules within bioerodible or bioresorbable implants, the patients can potentially see the implant or experience floaters. It is challenging to understand the issue of masking in these cases. It will be interesting to see how regulatory agencies handle these approvals when the time comes.

## Section: Uveitis

The approval of intravitreal dexamethasone implants for uveitis was based on the percent of patients reaching a vitreous haze score of 0 (i.e. no inflammation) [18]. At week 8 this was 47% vs 12% in the control group. In addition, the percentage of patients achieving a BCVA improvement of 15 letters from baseline was 43% vs 7% in the control group. The FDA, in general, accepts 2 steps reduction of vitreous haze score, so theoretically from score 3 to score 1. However, it might be difficult to recruit a lot of patients with vitreous haze score more than grade 2. In recent communication, the FDA was willing to accept patients achieving a reduction of vitreous haze score to 0, if all included patients have a vitreous haze score of at least 1.5. The study endpoint is week 8 but addition safety data is likely to be needed.

## Section: MacTel and EZ loss

Using anatomical endpoints for drug approval is gaining more traction. Encapsulated cell therapy producing CNTF implant (NT-501), in two Phase 3 studies, has demonstrated the rate of change of ellipsoid zone (EZ) loss as the primary endpoint in macular telangiectasia (MacTel) Type 2 [19]. At the time of writing, it is not yet approved by the FDA. Nonetheless, if it were to be approved, this would mean another anatomical endpoint could potentially be used for other retinal diseases when the central vision or BCVA might not be affected until late in the disease process. There is a suggestion that EZ loss might be acceptable for intermediate AMD.

In addition, the FDA had suggested that the onset of nAMD or GA can be potentially used as an approvable endpoint, but so far this approach has yet to be tried. The main reason is probably the relatively low event rate. On average, the conversion to nAMD of the fellow eye of patients with unilateral nAMD is about 10% per year [20]. The rate of conversion to GA is even lower. Nonetheless, using OCT and AI, we might be able to improve the prediction. However, if the accuracy of prediction is improved, it remains to be seen whether eyes with high conversion rates are eyes that might be too advanced for treatment or too rare to find. For instance, Lad and colleagues [21], identified one subgroup of GA with a 75% risk of converting to GA in 1 year but this group comprises only 1% of the study population. When we consider that this study used images from participants in the AREDS2 study [22], which only included patients with large drusen and/or pigmentary changes, the proportion of these patients in the whole population with intermediate AMD population is likely to be even lower.

## Section: Collaboration between academia and industry is critical

Lastly, collaboration between academia and industry is important to take novel interventions through the approval process to translation to clinical practice. As an example, Nightstar was born out of academics and was bought by Biogen for 810 million US dollars. It was a time of triumph, however, both programs subsequently failed the pivotal study despite showing positive trends on secondary endpoints. This resulted in Biogen deprioritising Ophthalmology and the development of those assets were terminated [23]. So why would a promising research project such as this fail to get to patients?

The first gene therapy in the history of the FDA was for a retinal inherited disease (RPE65 mutation). The approval of this gene therapy for RPE65 mutation-associated retinal dystrophy was based on the multi-luminance mobility testing (MLMT) score change from baseline to year 1 as an endpoint [24]. The MLMT [25] was designed to measure changes in functional vision, as assessed by the ability of a subject to navigate a course accurately and at a reasonable pace at different levels of environmental illumination. The MLMT was assessed using both eyes and each eye separately at one or more of seven levels of illumination, ranging from 400 lux (corresponding to a brightly lit office) to 1 lux (corresponding to a moonless summer night). Each light level was assigned a score code ranging from 0 to 6. A higher score indicated that a subject was able to pass the MLMT at a lower light level. A score of −1 was assigned to subjects who could not pass MLMT at a light level of 400 lux. The MLMT of each subject was videotaped and assessed by independent graders. The MLMT score was determined by the lowest light level at which the subject was able to pass the MLMT. The MLMT score change was defined as the difference between the score at baseline and the score at Year 1. A positive MLMT score change from baseline to Year 1 visit indicated that the subject was able to complete the MLMT at a lower light level [26]. This is a combination of assessing improvements in visual acuity and visual field in different light intensity allowing a clinically meaningful benefit to be demonstrated in a controlled but pseudo-real-life activity.

However, in the Biogen/Nightstar study, the retinal sensitivity improvement using microperimetry was chosen as the primary efficacy endpoint, which is much more difficult to demonstrate, in particular, the level of gain needed by the agency (7 dB on average and in at least pre-defined 5 points). It is therefore important to understand both the regulatory requirements as well as the ability to achieve a primary endpoint within the time frame of the study period (which is usually one or 2 years).

Functional endpoints are often difficult to demonstrate, particularly in patients with highly variable vision and/or using a test such as microperimetry, which are challenging to perform consistently.

## Section: Acknowledgements

My mentors, Prof Alan Bird, Prof Phil Luthert, and Prof Sue Lightman in Moorfields and UCL; Prof Ed Stone in Iowa city; Prof Greg Hageman in Iowa City and Salt Lake City; Liz Pearce, my wife.

## Section: Author contributions

VC conceived, designed and wrote the manuscript.

## Section: Competing interests

Johnson and Johnson Stock Options Holder. Clearside Biomedical, employee, stock owner and stock option holder.


---

# Elucidating the role of artificial intelligence in drug development from the perspective of drug-target interactions

- **Authors:** Boyang Wang, Tingyu Zhang, Qingyuan Liu, Chayanis Sutcharitchan, Ziyi Zhou, Dingfan Zhang, Shao Li
- **Issuer:** Journal of pharmaceutical analysis
- **Type:** Scientific article
- **Published:** 2024-11-14
- **Language:** en
- **DOI:** 10.1016/j.jpha.2024.101144
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40099205/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Drug development remains a critical issue in the field of biomedicine. With the rapid advancement of information technologies such as artificial intelligence (AI) and the advent of the big data era, AI-assisted drug development has become a new trend, particularly in predicting drug-target associations. To address the challenge of drug-target prediction, AI-driven models have emerged as powerful tools, offering innovative solutions by effectively extracting features from complex biological data, accurately modeling molecular interactions, and precisely predicting potential drug-target outcomes. Traditional machine learning (ML), network-based, and advanced deep learning architectures such as convolutional neural networks (CNNs), graph convolutional networks (GCNs), and transformers play a pivotal role. This review systematically compiles and evaluates AI algorithms for drug- and drug combination-target predictions, highlighting their theoretical frameworks, strengths, and limitations. CNNs effectively identify spatial patterns and molecular features critical for drug-target interactions. GCNs provide deep insights into molecular interactions via relational data, whereas transformers increase prediction accuracy by capturing complex dependencies within biological sequences. Network-based models offer a systematic perspective by integrating diverse data sources, and traditional ML efficiently handles large datasets to improve overall predictive accuracy. Collectively, these AI-driven methods are transforming drug-target predictions and advancing the development of personalized therapy. This review summarizes the application of AI in drug development, particularly in drug-target prediction, and offers recommendations on models and algorithms for researchers engaged in biomedical research. It also provides typical cases to better illustrate how AI can further accelerate development in the fields of biomedicine and drug discovery.

## Section: Introduction

The drug development process is a complex and multifaceted journey that spans several stages, including discovery, preclinical testing, clinical trials, and regulatory approval [1,2]. This endeavor, characterized by high costs and a significant time investment, is driven by the urgent need to address a myriad of diseases and health conditions [[3], [4], [5]]. Despite advances in technology and a greater understanding of biological systems, the success rate of bringing a new drug to market remains low, with only a small fraction of compounds progressing through the entire pipeline. In recent years, there has been a surge of innovative approaches, such as high-throughput screening, computational drug design, and the integration of artificial intelligence (AI), which have the potential to revolutionize the landscape of drug development. However, the industry still faces considerable challenges, including high attrition rates in clinical trials, regulatory hurdles, and the need for substantial financial resources. Addressing these challenges is crucial for accelerating the development of effective and safe therapeutics, ultimately improving global health outcomes.

In recent years, AI has emerged as a transformative force in biomedical research, particularly in drug development, which has historically faced significant challenges in both efficiency and effectiveness. Traditional drug discovery methods, such as high-throughput screening and the one-drug-one-target paradigm, often struggle with the complexity of biological systems and the multifactorial nature of diseases. These methods are time-consuming, costly, and frequently result in high attrition rates during clinical trials, highlighting a critical need for more innovative approaches. The introduction of AI offers a compelling solution to these challenges by providing powerful algorithms capable of analyzing and interpreting complex biological data with unprecedented speed and accuracy [[6], [7], [8]]. The capacity of AI to process vast amounts of information has opened new avenues for understanding intricate biological processes and disease mechanisms, providing insights that were previously unattainable [[9], [10], [11]]. By leveraging machine learning (ML) and deep learning techniques, AI can identify patterns and relationships within large datasets, predict potential drug-target interactions, and optimize drug design, thus significantly reducing the time and cost associated with traditional drug discovery [12,13]. This ability to process vast amounts of information has rapidly and accurately provided new approaches for understanding intricate biological processes and disease mechanisms [14,15]. This technological advancement is not just an improvement but represents a paradigm shift in how we approach drug development. Simultaneously, network pharmacology has gained prominence as a complementary approach to AI in drug discovery. Network pharmacology focuses on the complex interactions within biological networks and offers a holistic framework for studying the interconnectedness between genes, proteins, and metabolic pathways [[16], [17], [18]]. This approach emphasizes the importance of systems-level insights, which are critical for understanding complex diseases and developing multitargeted therapies. By integrating AI and network pharmacology, researchers can overcome traditional barriers, generate comprehensive models of biological systems, uncover novel biomarkers, and gain deeper insights into the molecular underpinnings of health and disease. This integration not only represents a significant shift toward a more interconnected and predictive understanding of biology but also lays the groundwork for future scientific breakthroughs, potentially transforming the landscape of drug development.

The integration of AI and network pharmacology into drug development is transforming the landscape of therapeutic discovery and design [[19], [20], [21]]. AI-driven tools are being utilized to streamline various stages of drug development, from the identification of novel drug targets to the optimization of lead compounds [[22], [23], [24]]. ML and deep learning algorithms can sift through extensive biological data to predict potential drug candidates and their interactions with biological targets, significantly reducing the time and cost associated with traditional drug discovery methods [2,25,26]. On the other hand, network pharmacology [[27], [28], [29]] offers a systems-level perspective by mapping out the complex interactions within biological networks, enabling researchers to identify multitarget strategies and potential side effects early in the development process. This holistic approach is particularly valuable in addressing multifactorial diseases such as cancer and neurodegenerative disorders, where traditional single-target therapies often fall short. By leveraging the predictive power of AI and providing comprehensive insights into network pharmacology, researchers can develop more effective and safer drugs, ultimately accelerating the transition from bench to bedside. The synergy of these technologies holds great promise for the future of personalized medicine, offering tailored therapeutic solutions on the basis of the intricate biological profiles of individual patients.

A key application of AI and network pharmacology in drug development is the prediction of drug-target interactions [19,30,31], which is crucial for identifying potential therapeutic targets and understanding drug mechanisms. AI algorithms, particularly deep learning and ML models, can analyze large-scale biological and chemical data to predict which molecules are likely to interact with specific targets. This capability accelerates the identification of promising drug candidates and reduces the reliance on traditional high-throughput screening methods, which are often time-consuming and costly. Network pharmacology complements this approach by providing a comprehensive view of the biological networks involved in disease processes, highlighting potential multitarget interactions and off-target effects [32,33]. By integrating AI’s predictive power with the systems-level insights of network pharmacology, researchers can more accurately pinpoint viable drug targets and anticipate possible side effects, addressing the longstanding challenges of inefficiency and unpredictability in drug development. This synergy not only enhances the efficiency of the drug discovery process by reducing time and cost but also presents new strategies for tackling complex diseases through multi-targeted strategies. Ultimately, this integration contributes to the development of more effective, safer, and personalized medical treatments, representing a crucial advancement in the pursuit of precision medicine.

## Section: Association-based drug target prediction

Association-based drug target prediction plays a pivotal role in AI-driven drug development [34]. By leveraging advanced ML algorithms and large-scale biological data, this approach identifies potential drug targets through the analysis of complex biological networks and associations between drugs, targets, and diseases (Fig. 1). This method enhances our understanding of drug mechanisms and facilitates the discovery of novel therapeutic targets. In the realm of AI drug development, association-based predictions provide a robust framework for identifying key interactions, streamlining the drug discovery process, and ultimately contributing to the development of more effective and targeted therapies.Fig. 1End-to-end prediction and application in artificial intelligence (AI)-assisted drug development, guiding drug target discovery, drug-disease relationship prediction, drug repurposing, and drug optimization. 1D: one-dimensional; SMILES: simplified molecular input line entry system; ML: machine learning; CNN: convolutional neural network; GNN: graph neural network; Add: addition; Norm: normalization.Fig. 1

End-to-end prediction and application in artificial intelligence (AI)-assisted drug development, guiding drug target discovery, drug-disease relationship prediction, drug repurposing, and drug optimization. 1D: one-dimensional; SMILES: simplified molecular input line entry system; ML: machine learning; CNN: convolutional neural network; GNN: graph neural network; Add: addition; Norm: normalization.

Studies for drug-target prediction.

## Section: Association-based drug target prediction › Biological network-based association algorithms for drug target prediction

Network pharmacology aims to elucidate the mechanisms of drugs and their complex combinations by leveraging biological networks from the perspectives of systems biology and systems medicine. Network target [[6], [7], [8]] is a theory originating from network pharmacology and has been widely used in traditional Chinese medicine (TCM) research [20,35]. Algorithms based on network pharmacology have inherent advantages in solving zero-sample and few-sample problems by utilizing network information such as biomolecular networks (Table 1) [36–41]. In the early stage of “network target”, methods composed of statistics and similarities in features made great improvements in the prediction of disease‒gene associations and drug-target associations. As a pioneering algorithm in “network target”, the correlating protein interaction network and phenotype network to predict disease genes (CIPHER) [36] has achieved great performance in few-shot or zero-shot gene-phenotype predictions. The core idea of this algorithm is to take already known phenotype-phenotype networks, phenotype-gene networks, and protein-protein networks as inputs, use a regression model to construct associations at both the macro- and micro-levels, and establish similarity associations between query phenotypes, reference phenotypes, and genes via known associations as bridges. This method is particularly advantageous for predicting genetically uncharacterized phenotypes. On the basis of CIPHER, CIPHER-like algorithms in different research areas have been gradually developed. For drug‒gene association prediction, DrugCIPHER [37] takes already known drug-drug networks, drug‒gene networks, and protein-protein networks as inputs and was proposed to construct unknown associations between compounds and genes via a regression model, thereby enabling high-precision prediction of drug targets across the entire genome.Table 1Studies for drug-target prediction.Table 1TypeModelNameInputRefs.Association-basedNetwork-basedCIPHERPhenotype-phenotype, phenotype-gene, and protein-protein networks[36]DrugCIPHERDrug-drug, drug-target, and protein-protein networks[37]–Drug-target, disease-gene, and protein-protein networks[38]–Drug-target, protein-protein networks, and gene expression data[39]DREAMwalkDrug-gene-disease network[40]DTINetDrug-related network[41]CNN and GCN-basedDLEPSGene expression profile and compound structure[42]DEEPScreenCompound structure image[43]3D-KINEssenceProtein 3D-structure and compound descriptor[44]GCN-DTIDrug-target network[45]GADTIDrug-target network[46]DrugAICompound structure, compound-target network, and protein sequence[47]GLIMTissue-cell-molecule network[48]Transformer-basedMolTransDrug descriptor and protein sequence[49]MRBDTADrug descriptor and protein sequence[50]MDCT-DTAProtein sequence and compound graph structure[51]TDGraphDTAProtein sequence and compound graph structure[52]BERT-GCNDrug descriptor, protein sequence, and drug-target network[53]GeneformerSingle-cell transcriptomes[54]Molecular collision-basedML-based–Protein 3D-structure and compound descriptor[[55], [56], [57]]CNN-basedDeepBindBCProtein 3D-structure and compound descriptor[58]–Protein 3D-structure and compound descriptor[59]KDEEPProtein 3D-structure and compound 3D-structure[60]–Protein 3D-structure and compound 3D-structure[61]–3D protein-ligand and complexes-structure[62]GCN-based–Protein 3D-structure and compound graph structure[63]PIGNetProtein graph structure and compound graph structure[64]Transformer-basedViTScoreProtein 3D-structure and compound 3D-structure[65]ETDockProtein graph structure and compound graph structure[66]–3D point clouds of protein-ligand complexes[67]MT-DTAProtein sequence and compound descriptor[68]−: model without name. CIPHER: correlating protein interaction network and phenotype network to predict disease genes; DTINet: drug target interaction (DTI)Net; CNN: convolutional neural network; GCN: graph convolutional network; DLEPS: deep learning-based efficacy prediction system; 3D: three-dimensional; GADTI: graph autoencoder approach for DTI prediction; GLIM: graph local infoMax; MRBDTA: molecule representation block-based drug-target binding affinity (DTA) prediction; MDCT: multi-scale diffusion and interactive learning with CNN-transformers; BERT-GCN: bidirectional encoder representations from transformers-GCN; ML: machine learning; MT-DTA: mutual transformer-DTA.

There are also several network pharmacology algorithms that focus on the attributes of nodes in biological networks. On one hand, many methods for estimating distances in biological networks have been promoted. By quantifying the network proximity of disease genes and drug targets within the human protein-protein interactome, Cheng et al. [38] identify hundreds of new drug-disease associations for over 900 U.S. Food and Drug Administration (U.S. FDA)-approved drugs. The researchers selected four network-predicted associations to test their causal relationships using extensive healthcare databases containing data from over 220 million patients, applying state-of-the-art pharmacoepidemiologic analyses and propensity score matching. Kong et al. [39] introduced a ML framework designed to identify robust predictive biomarkers for anticancer drug responses, leveraging network-based analyses of pharmacogenomic data derived from three-dimensional (3D) organoid culture models. The framework first filters out pathways most closely related to drug response by calculating the distances between pathways and drug targets. Next, the gene expression data of these pathways are used as features input into the ML model to predict the drug half-maximal drug inhibitory concentration (IC50). Pathways with a high predictive performance are potential drug response biomarkers. The framework aims to overcome the limitations of current ML methods, which often fail to identify translational biomarkers from preclinical models.

On the other hand, random walk-based methods have also been developed to predict drug-target associations. Bang et al. [40] proposed DREAMwalk, an innovative algorithm designed for computational drug repurposing by leveraging high-throughput biomedical knowledge graphs. Traditional approaches face challenges due to the dominance of genes and the relatively small number of drug and disease entities, leading to less effective representations. DREAMwalk addresses these issues by employing a “semantic multilayer guilt-by-association” approach, which is based on the principle that “similar genes share similar functions” at the drug–gene–disease level. The algorithm uses a teleport-guided random walk method, where drugs and diseases are mapped into a unified embedding space via a heterogeneous skip-gram model. The final output, which represents drug‒disease association probabilities, is predicted via an XGBoost classifier and leads to more accurate predictions of drug‒disease associations. Luo et al. [41] proposed drug target interaction (DTI)Net, a computational pipeline designed to predict novel drug-target interactions. It constructs a heterogeneous network that integrates diverse types of drug-related information. The core of DTINet involves learning a low-dimensional vector representation of features, which accurately captures the topological properties of individual nodes within the heterogeneous network. Predictions are then made on the basis of these representations via a vector space projection scheme.

Studies for drug-target prediction.

## Section: Association-based drug target prediction › Convolutional neural network (CNN)- and graph convolutional network (GCN)-based association algorithms for drug target prediction

With the development of AI and multiomics technologies, high-dimensional data suitable for constructing deep learning models have accumulated. Deep learning algorithms, such as CNNs and GCNs, were subsequently promoted to solve many problems in this field, such as mechanism revealing and drug development (Table 1) [[42], [43], [44], [45], [46], [47], [48]].

Compared with network-based approaches, drug-target prediction algorithms based on drug and protein structures operate on the basis of the intrinsic properties of these molecules. These methods typically follow a process of feature extraction followed by prediction. Common techniques in this category include methods based on CNNs. Zhu et al. [42] proposed deep learning-based efficacy prediction system (DLEPS), which uses 1D-CNNs and gene expression profiles for predicting drug efficacy. The method first encodes chemical structures via the simplified molecular input line entry system (SMILES) and divides them into grammar trees, which are then encoded into a high-dimensional latent space through a 1D-CNN. The latent vector then passes through a five-layer dense network for the prediction of chemically induced transcriptional profiles of 978 landmark genes, facilitating drug repurposing and discovery across a wide range of diseases, particularly those lacking well-defined targets. Rifaioglu et al. [43] proposed a system called DEEPScreen, which uses a 2D-CNN for predicting drug targets. Unlike traditional methods that rely on descriptors, DEEPScreen employs 2D structural images of compounds as input data. This image-based representation captures complex features of the compounds, naturally reflects their molecular states, and significantly enhances the prediction accuracy. Another method, 3D-KINEssence [44], uses a 3D-CNN to predict the potency and target profile of kinase inhibitors. The approach involves training the 3D-CNN on the biomolecular structures of kinases, allowing the model to learn essential structural features that distinguish individual kinases. The learned 3D fingerprints encapsulate these unique features and are combined with molecular Morgan fingerprints of kinase inhibitors to predict the potency and target profile of kinase inhibitors.

GCNs can perform exceptionally well in network-based prediction tasks. By continuously aggregating neighboring nodes, GCNs can capture information at different scales around each node. In the drug-target network, this allows GCNs to not only focus on the direct interactions between drugs and targets but also consider other indirect associations. Zhao et al. [45] proposed GCN-DTI, a combination approach including a GCN and deep neural networks (DNNs). The method first involves constructing a drug-protein pair (DPP) network in which nodes represent drug-protein pairs and edges represent their interactions. The GCN is then used to extract features from each DPP on the basis of the network topology, capturing both the structural information of the network and the intrinsic properties of the drugs and proteins involved. These features, comprising the combined characteristics of drugs and proteins, are input into a DNN, which classifies each DPP as a true or false interaction. Another GCN model, graph autoencoder approach for DTI prediction (GADTI) [46], predicts drug-target interactions by constructing a heterogeneous network that integrates multiple drug- and target-related datasets. The model then uses a graph autoencoder with an encoder consisting of a GCN and a random walk with a restart model to generate node embeddings. The decoder, DistMult, is a matrix factorization model that reconstructs the original network from the embeddings. By reconstructing the connections in a heterogeneous graph, potential drug-target interactions can be predicted.

As a representative deep learning algorithm for drug-gene association predictions, DrugAI [47] is a multiview deep learning model designed to understand the mechanisms of candidate drugs, particularly with a focus on activating and inhibiting interactions between drugs and their targets. It integrates multimodal information, including compound structure information extracted by a GCN, compound similarity networks, and multidimensional representations of targets extracted by a CNN, to achieve directed prediction of drug-target associations. Another algorithm that integrates multimodal information, graph local infoMax (GLIM) [48], is designed to systematically uncover associations among multilevel biological elements, including disease phenotypes, tissues, cell types, and molecules; this addresses the challenges posed by their heterogeneity and incompleteness. GLIM operates within a human multilevel network (HMLN), which incorporates multiple tissues and cell types in addition to molecular networks. By embedding the features of the HMLN through the GCN and contrastive learning, the GLIM algorithm can systematically mine potential relationships between these elements.

## Section: Association-based drug target prediction › Transformer-based association algorithms for drug target prediction

The transformer model is a state-of-the-art deep learning architecture primarily used for natural language processing tasks (Table 1) [[49], [50], [51], [52], [53], [54]]. It leverages a self-attention mechanism to weigh the influence of different parts of the input data, allowing it to capture complex relationships and dependencies more effectively than traditional sequence models such as recurrent neural networks (RNNs) or long short-term memory networks (LSTMs). By adopting the transformer model, the significance between molecular structures can be better incorporated in the drug-target interaction prediction task. For example, Huang et al. [49] proposed MolTrans, a transformer-based method for drug-target interaction prediction. This method decomposes molecular sequences into substructures, which identify and merge frequent subsequences to generate high-quality, interpretable substructures. These substructures are then embedded through an augmented transformer module that captures the complex chemical relationships among them via self-attention mechanisms. Finally, the interaction prediction module pairs drug and protein substructures, applying a CNN to model higher-order interactions and predict the likelihood of drug-target interactions. Similarly, the molecule representation block-based drug-target binding affinity (DTA) prediction (MRBDTA) model [50] predicts DTA by first encoding the original protein fast-alignment search tool for amino acid sequences (FASTA) and drug SMILES sequences into embedding spaces and adding positional information. The molecule representation block, which improves the transformer encoder and introduces skip connections, extracts features from these encoded sequences. Finally, the interaction learning module integrates the features extracted from proteins and drugs and predicts their binding affinities via fully connected layers and a linear layer. Zhu et al. [51] proposed the multi-scale diffusion and interactive learning with CNN-transformer (MDCT)-DTA model, which improves DTA prediction by integrating multiscale graph diffusion convolution and CNN-transformer networks. The model processes protein sequences with CNNs to extract local features, followed by a transformer to capture global relationships. Simultaneously, drug molecules, represented as SMILES strings, are converted into molecular graphs and processed to extract structural features. After these features are obtained, a local interlayer interaction mechanism refines them to facilitate the exchange of information between drug and protein features. Finally, the combined data are fed into a fully connected layer for affinity prediction, allowing the model to accurately capture the intricate interactions between drugs and their targets. Another TDGraphDTA model proposed by Zhu et al. [52] predicts drug-target affinity by integrating multiscale information interactions and graph optimizations to achieve superior accuracy and interpretability. The model begins by preprocessing protein sequences into graph representations and drug molecules into SMILES-encoded molecular graphs. It then employs multilevel cascaded CNNs to extract both global and local features from protein sequences, while a diffusion-based graph optimization block enhances the drug molecular graphs by capturing intricate relationships between nodes. A cross-attention mechanism within the multi-scale interaction block further integrates features from both drug and protein inputs, effectively capturing contextual information between molecular substructures. These optimized features are then combined and processed through fully connected layers to predict DTA.

In recent years, with advancements in computational power and data availability, large language models (LLMs) have demonstrated exceptional performance in various areas, including content comprehension and reasoning. They have also been applied in the discovery of drug and disease targets. Lennox et al. [53] presented a novel approach for predicting DTA by combining pretrained bidirectional encoder representations from transformers (BERT) models and GCNs. Specifically, they used a pretrained BERT model to encode protein sequences and a pretrained RoBERTa model to encode drug SMILES strings, generating robust representations for each drug and protein. These representations are then fed into a GCN, which models the interactions between the drugs and proteins. Theodoris et al. [54] proposed Geneformer, a context-aware, attention-based deep learning model pretrained on ∼30 million single-cell transcriptomes. This model uses a self-supervised masked learning objective to learn gene network dynamics and is fine-tuned for various tasks, including drug-target interaction prediction. Geneformer excels in predicting dosage-sensitive genes and identifying candidate therapeutic targets, significantly enhancing drug discovery by modeling gene deletions and activations in specific cellular contexts. Its ability to perform accurate predictions with limited data demonstrates its potential in uncovering novel drug targets and optimizing therapeutic strategies.

## Section: Molecular collision-based drug target prediction

On the basis of principles of molecular interactions, drug target prediction models focus primarily on identifying ligands that can activate or inhibit specific proteins. By predicting the interactions between drugs and their targets, these models help elucidate the mechanisms of action at the molecular level. Leveraging computational techniques, they efficiently identify promising drug candidates and provide insights into their molecular effects.

## Section: Molecular collision-based drug target prediction › ML-based molecular collision algorithms for drug target prediction

In traditional ML approaches for predicting drug targets, there are two main methodologies (Table 1) [[55], [56], [57]]. The first approach involves the use of molecular docking results as inputs for ML models to predict the efficacy of potential ligands. For example, Marchetti et al. [55] integrated molecular dynamics simulations, molecular docking, and ML to predict the functional effects of allosteric ligands on the heat shock protein 90 (HSP90) protein. First, representative protein conformations are generated from simulations. Next, a library of ligands is docked to these structures. Finally, ML algorithms, specifically support vector machines, classify the ligands as activators or inhibitors based on features extracted from the docking results, achieving highly balanced accuracy in distinguishing the functional categories. The second approach involves prescreening ligands based on their molecular features via ML models and then employing molecular docking methods to refine and predict their interactions with the target protein. Salimi et al. [56] proposed a method to identify potential vascular endothelial growth factor receptor 2 (VEGFR2) kinase inhibitors. The method begins by gathering data from chemical databases and computing molecular descriptors. A random forest classifier is used to screen compounds with high prediction probabilities, followed by similarity screening to known inhibitors. The selected compounds are then subjected to molecular docking and molecular dynamics simulations to evaluate their binding affinity and to assess the stability of the ligand-protein complexes, respectively. Finally, adsorption, distribution, metabolism, excretion, and toxicity (ADMET) properties are predicted to confirm favorable pharmacokinetic profiles and low toxicity. Similarly, Yasir et al. [57] employed a multistep approach to identify potential Janus kinase 2 (JAK2) inhibitors. Initially, a reference dataset of known JAK2 inhibitors is gathered, and molecular descriptors are generated via RDKit tools. Next, a random forest regression model is constructed using Scikit-learn to predict the pIC50 values of a large chemical library. The compounds with high prediction scores are then subjected to molecular docking to evaluate their binding affinities. Subsequently, molecular dynamics simulations are used to assess the stability of the ligand-protein complexes. Finally, ADMET properties are predicted, and selected compounds are experimentally validated for their JAK2 inhibitory activity.

## Section: Molecular collision-based drug target prediction › CNN- and GCN-based molecular collision algorithms for drug target prediction

Models based on CNNs and GCNs have advantages in expanding the receptive field, preserving structural information, and extracting more meaningful data (Table 1) [[58], [59], [60], [61], [62], [63], [64]]. DeepBindBC [58] is a deep learning method for identifying native-like protein-ligand complexes through a virtual screening. The approach begins by collecting binding structures, removing complexes with rare atom types, and generating potential negative data by cross-docking nonnative ligands. Using these data, a ResNet (2D-CNN)-based model is constructed. Input data are generated by encoding the atomic types with one-hot encoding and calculating the Euclidean distances between atomic pairs. The ResNet model is trained on these structured data to distinguish binding interactions from nonbinding interactions. By using DeepBindBC, Zhang et al. [59] proposed a multistep approach that combines deep learning and molecular dynamics simulations to identify novel inhibitors of the cancer drug target tumor necrosis factor alpha (TNF-α)-induced protein-8 like2 (TIPE2). Initially, the TIPE2 protein structure is modeled, and a large chemical library is prepared. A deep learning-based dense fully connected neural network (DFCNN) was developed to predict protein-ligand binding probabilities. Preliminary screening is conducted with this DFCNN. Structural-based screening by DeepBindBC is followed, which incorporates physicochemical and spatial information. High-potential candidates are then subjected to molecular docking and stability assessments through molecular dynamics simulations. Finally, the binding affinities of the selected candidates are experimentally validated. For the 3D-CNN model, Jiménez et al. [60] proposed KDEEP to predict protein-ligand binding affinity. The approach represents protein and ligand atoms in a 3D grid, capturing their physicochemical properties as voxel features. A simplified SqueezeNet architecture is employed for the 3D-CNN, which processes these voxelized representations to learn complex interaction patterns. Other methods, such as those proposed by Ragoza et al. [61] and Stepniewska-Dziubinska et al. [62], also use a similar 3D-CNN approach for drug-target prediction.

GCN models can better preserve spatial structural information in molecular collision models. By combining CNN and GCN models, Jones et al. [63] predicted protein-ligand binding affinity by integrating deep learning models with structural analysis. After essential atomic features such as element type, hybridization state, and structural properties are extracted, two main models are built: a 3D-CNN and a spatial graph CNN (SG-CNN). The 3D-CNN captures 3D atomic features and interactions via voxel grid representations, thereby learning spatial information without predefined pairwise interactions. The SG-CNN, on the other hand, models both covalent and noncovalent interactions explicitly via graph-based representations, leveraging adjacency matrices to define atomic neighborhoods. After independent training, these models are combined in the prediction module via mid-level and late fusion techniques, which harness their complementary strengths, leading to increased prediction accuracy and computational efficiency. Another GCN model is PIGNet [64], a physics-informed deep learning model. PIGNet leverages a neural network graph to represent protein-ligand complexes as molecular graphs, incorporating node features and adjacency matrices to capture covalent and intermolecular interactions. The model uses physics-based equations parameterized by neural networks to calculate interaction energies, thereby embedding the underlying physics of protein-ligand binding into the learning process. Data augmentation strategies, including generating random binding poses, are employed to increase the diversity of the training set, improving the model’s generalizability. Compared with traditional methods and previous deep learning models, the performance of PIGNet shows superior docking and screening powers.

## Section: Molecular collision-based drug target prediction › Transformer-based molecular collision algorithms for drug target prediction

By utilizing transformer models (Table 1) [[65], [66], [67], [68]], Guo et al. [65] proposed ViTScore, a novel method for predicting protein-ligand docking poses via a vision transformer (ViT). ViTScore voxelizes the protein-ligand interaction pocket into a 3D grid, where each voxel encodes the occupancy of atoms on the basis of their physicochemical properties. This voxelized representation is then processed by a ViT model, which processes the 3D grid through a series of transformer blocks. These blocks leverage self-attention mechanisms to capture intricate spatial and energetic patterns between atoms, enabling the ViTScore to distinguish between near-native and nonnative docking poses effectively. Another transformer method, ETDock [66], uses an equivariant transformer for predicting protein-ligand docking poses by integrating atomic-level and graph-level features through a feature processing module and a TAMformer module. The ligand is represented as a molecular graph, with node embeddings learned via a graph isomorphism network (GIN), whereas protein embeddings are obtained via geometric vector perception (GVP). These features are fused via a learnable outer product to capture protein-ligand interactions. The TAMformer module, consisting of triangle, attention, and message layers, processes these features to predict a protein-ligand distance matrix and iteratively refines the ligand pose, significantly enhancing docking accuracy by enforcing geometric constraints and improving information exchange. From the perspective of 3D point clouds, Wang et al. [67] proposed a method that involves generating 3D point clouds, with each point representing an atom’s coordinates, van der Waals radius, atomic weight, and source. These data are then processed by PointTransformer, a model that incorporates hierarchical spatial structures and self-attention mechanisms to predict binding affinity. This approach allows the model to accurately predict binding affinity by preserving the original geometric information of the protein-ligand complex. Zhu et al. [68] proposed the mutual transformer (MT)-DTA model, which innovatively combines a CNN and transformer-based molecular sequence encoded with a self-attention mechanism; this combination leads to accurate and consistent drug-target affinity predictions. The model first uses CNN and transformer blocks to effectively encode drug and protein sequences, capturing both local and global molecular features. In addition, it introduces a self-attention mechanism to simulate detailed interactions between these sequences, addressing the need to capture complex intermolecular relationships. Finally, these interaction features are fed into a fully connected network to accurately predict drug-target affinity.

## Section: Drug combination target prediction

Drug combination target prediction is also a crucial component of AI-driven drug development [69,70]. This approach uses advanced computational models to identify synergistic interactions between multiple drugs and their targets. By analyzing large datasets and leveraging ML algorithms, drug combination target prediction helps uncover complex biological interactions that single-drug treatments may miss (Fig. 2). This method not only aids in understanding the combined effects of drugs but also enhances the efficacy and safety profiles of therapeutic regimens. In the context of AI drug development, predicting drug combination targets has accelerated the discovery of novel, more effective treatment strategies, paving the way for personalized and precision medicine.Fig. 2This comprehensive diagram illustrates the multifaceted approach to artificial intelligence (AI)-driven drug combination development, focusing on the integration of various methodologies for target discovery, drug repurposing, understanding mechanisms of traditional Chinese medicine (TCM), new combination therapies, and new drug development. CNN: convolutional neural network; Add: addition; Norm: normalization; C: contextual representation; T: tokens (Toks) of the input sentences; E: embedding representations; BERT: bidirectional encoder representations from transformers; CLS: classification Tok; SEP: separator Tok; Trm: transformer block; GPT: generative pre-trained transformer.Fig. 2

This comprehensive diagram illustrates the multifaceted approach to artificial intelligence (AI)-driven drug combination development, focusing on the integration of various methodologies for target discovery, drug repurposing, understanding mechanisms of traditional Chinese medicine (TCM), new combination therapies, and new drug development. CNN: convolutional neural network; Add: addition; Norm: normalization; C: contextual representation; T: tokens (Toks) of the input sentences; E: embedding representations; BERT: bidirectional encoder representations from transformers; CLS: classification Tok; SEP: separator Tok; Trm: transformer block; GPT: generative pre-trained transformer.

Studies for drug combination-target prediction.

## Section: Drug combination target prediction › Biological network-based algorithms for drug combination target prediction

Modern medicine has gradually transformed from “one drug, one target” to “multiple drugs, multiple targets”. Therefore, developing algorithms for predicting the efficacy and mechanism of drug combinations is crucial for drug development (Table 2) [[71], [72], [73], [74], [75], [76], [77], [78]]. Network pharmacology is suitable for predictions related to drug combinations owing to its hypothesis on biological networks. Li et al. [71] introduced a virtual screening paradigm based on “network target”, which is different from the traditional “single target” concept. The proposed algorithm, termed network target-based identification of multicomponent synergy (NIMS), is designed to prioritize synergistic agent combinations in a high-throughput manner. Candidate agents labeled as “n” are used as inputs for NIMS and can be translated into network interactions among molecular entities such as targets or responsive gene products within the network pharmacology theory. The model then computes the synergy scores between a specified agent and every candidate agent and ranks the effective agent pairs. In biological networks, nodes representing biomolecules might play different roles with different functions. Identifying communities or modules in a biological network could help determine the synergistic relationships among drug combinations and thus increase the accuracy of the prediction of drug combinations. From a network perspective, Li et al. [72] developed the distance-based mutual information model (DMIM) to identify significant relationships among herbs in various herbal formulae. DMIM combines mutual information entropy with “between-herb-distance” to score herb interactions and construct an herb network. The effectiveness of the model has been validated on a case study of the Liu-Wei-Di-Huang formula. The comCIPHER [73] algorithm introduces a novel representation of drug-gene-disease relationships called a “comodule”, which characterizes closely related drugs, diseases, and genes. The method begins by defining a network-based gene closeness profile to establish connections between drugs and diseases. A Bayesian partition method was subsequently developed to identify these drug-gene-disease comodules on the basis of gene closeness data. Finally, the comodules established through comCIPHER can be used for new drug applications.Table 2Studies for drug combination-target prediction.Table 2ModelNameInputRefs.Biological network-basedNIMSAgent and candidate agents[71]DMIMCandidate herbal formulae and herb pairs[72]comCIPHERProtein interaction, drugs and their targets, drug-disease associations, and chemical-drug associations[73]–Drug A, drug B, disease, and protein[74]SRWRTCM[75]–Protein-metabolite network[76]MatchMakerGene expression profile and drug chemical structure[77]SynPathyDrug feature based on pathway, chemical structure, and cell line feature[78]CNN and GCN-basedCNN-DDIDrug categories, targets, pathways, and enzymes[85]CNN-SiamChemical substructures, targets, and enzymes[86]–Patient records[87]DRSPRINGChemical structure, genetic interactions, drug-target information, and gene expression profiles of cell lines[88]MK-GNNMedical records (diagnosis, treatment procedure, medications, and drug network)[89]GCN-BMPCanonical SMILES strings[90]Transformer-basedSynergyXDrug substructure and multiomics cell features[91]SynergyGTNSMILES and cell-line gene expression profiles[92]DeepPSEPolypharmacy side effects, mono side effects information, and drug-protein interactions[93]MDF-SA-DDISubstructures, targets, and enzymes[94]LaGATKnowledge graph[95]EGFIEach sentence has a pair of drugs with an annotated relation (advise, effect, mechanism, int, and negative)[96]CancerGPTDrug pair synergy data[97]−: model without name. NIMS: network target-based identification of multicomponent synergy; DMIM: distance-based mutual information model; CIPHER: correlating protein interaction network and phenotype network to predict disease genes; SRWR: signed random walk with restart; TCM: traditional Chinese medicine; CNN: convolutional neural network; GCN: graph convolutional network; DDI: drug–drug interaction; DRSPRING: drug synergy prediction by integrated GCN; MK: medical-knowledge-based; GNN: graph neural network; BMP: bond-aware message propagation; SMILES: simplified molecular input line entry system; MDF: multi-source drug fusion, multi-source feature fusion; SA: self-attention; LaGAT: link-aware graph attention; EGFI: extraction and generation with fusion of enriched entity and sentence information; int: DDIs are provided without any information.

Many algorithms based on the attributes of biological networks for drug combinations have also been developed. Cheng et al. [74] proposed a network-based methodology to identify clinically effective drug combinations for treating complex diseases, addressing the challenge of combinatorial explosion due to numerous drug pairs and dosage combinations. The methodology quantifies the network-based relationships between drug targets and disease-related proteins within the human protein-protein interactome. Their analysis revealed six distinct classes of drug-drug-disease combinations. Among these classes, only one is correlated with therapeutic effects: when the targets of both drugs hit the disease module but target separate neighborhoods. In addition, to understand the molecular mechanisms of herbal medicines used in TCM for treating complex diseases, a novel computational systems pharmacology approach was proposed by Zhao et al. [75]. This approach includes transcriptome profiling, data collection, statistical analysis, network algorithms, bioinformatics analysis, and pharmacological validation. Central to this method is the network algorithm called signed random walk with restart (SRWR), which simulates the propagation of drug effects on networks. SRWR identifies proteins as either positively or negatively regulated (activated or inhibited) by drugs within human signaling networks. Casas et al. [76] proposed a mechanism-based disease definition within the framework of network pharmacology. This method begins by identifying a primary causal target and extends to a secondary target via guilt-by-association analysis. Predictions have been validated and explored for synergy through in vitro and in vivo mouse models. MatchMaker [77], a deep learning framework for drug combination prediction, consists of two drug-specific networks and a synergy prediction network. Drug-specific networks are designed to extract the hidden biological information between drug chemical structures and cell line gene expression profiles so that the prediction network can precisely predict and present novel drug combinations. Tang and Gottlieb [78] proposed a biological network-based deep learning model named SynPathy, which utilizes pathway-level drug features and cell line molecular data as inputs to suggest potential strategies for drug combination therapy. By testing the DrugComb benchmark, SynPathy performs better than existing methods do and provides explainable pathways for synergy prediction.

The numerous applications of network pharmacology methods in drug discovery demonstrate the potential of AI to address specific challenges. For example, do Valle et al. [79] developed a network medicine framework to understand how polyphenols influence health by analyzing interactions between polyphenol protein targets and disease-associated proteins. Their study revealed that these targets cluster in specific regions of the human interactome, with their proximity to disease proteins predicative of known therapeutic effects, which highlights AI’s ability to integrate complex biological data and predict therapeutic outcomes that traditional methods might miss [79]. In addition, in complex drug combinations or TCM fields, network target theory and techniques have also been applied in drug development and repositioning [80,81]. For example, AI revealed that Weifuchun and Moluodan, both of which are used for treating chronic atrophic gastritis, have distinct mechanisms of action: Weifuchun primarily modulates immune responses, whereas Moluodan affects lipid metabolism [82,83]. These findings underscore the role of AI in refining therapeutic strategies. Additionally, in biomarker prediction, AI combines network analysis with clinical trials and animal studies to identify key biological modules regulated by the Yiqi Tongqiao pill. This analysis revealed pathways related to immune regulation, epithelial barrier disorders, and cell adhesion, centered on biomarkers such as interleukin 4 (IL-4), interferon gamma (IFN-γ), TNF-α, and IL-13 [84], and demonstrated AI’s capacity to predict clinically relevant biomarkers and guide therapeutic development.

Studies for drug combination-target prediction.

## Section: Drug combination target prediction › CNN- and GCN-based association algorithms for drug combination target prediction

Unlike most network-based pharmacological approaches, some studies utilize advanced deep learning methods to extract drug-related features and apply these features to tasks such as combination drug therapies, drug synergy score predictions, and IC50 predictions for drug combinations. CNNs and GCNs are commonly used to extract both the global and local features of drugs, demonstrating their strengths, particularly in drug-drug interaction (DDI) prediction tasks (Table 2) [[85], [86], [87], [88], [89], [90]].

The CNN-DDI method [85] incorporates multiple drug-related features, such as drug categories, targets, pathways, and enzymes, and then uses a CNN to extract features for DDI prediction. The fusion of diverse features of this method and the use of the Jaccard similarity have been validated to improve the prediction ability in the drug-drug-interaction events predicted by a multimodal deep learning framework (DDIMDL) task. The CNN-Siam model [86], which employs a Siamese network architecture, is recognized for its effective prediction of DDIs via multimodal drug data. This model leverages twin convolutional networks and sophisticated optimization algorithms, achieving significant accuracy improvements over the state-of-the-art methods. Although many studies have focused mainly on drug synergistic effects or the prediction of DDIs, Küçükosmanoglu et al. [87] proposed an innovative method for analyzing adverse events in combination therapies by using real-world data from the U.S. FDA’s reporting system. By employing a CNN autoencoder to visualize complex adverse event patterns from millions of patient records, this research provided novel insights into the predominantly additive nature of drug interactions. This approach not only enhances understanding but also supports safer implementation of combination therapies in clinical settings, marking a significant advancement in predictive health care analytics.

In addition to network pharmacology methods, research on drug combination prediction also encompasses numerous studies leveraging GCNs. These studies employ GCNs to extract structural features of compounds and network-related features of drugs, which include associations among drugs, cells, genes, and pathways. By utilizing GCNs, these approaches can effectively capture the intricate relationships and interactions within biological networks, thereby enhancing the accuracy and comprehensiveness of drug combination predictions. By incorporating a GCN to integrate chemical structures, genetic interactions, and drug-target information, a deep-learning model called drug synergy prediction by integrated GCN (DRSPRING) [88] was established to predict drug synergy effects by innovatively utilizing pharmacogenomic profiles alongside molecular properties. The model has demonstrated good performance on the DrugComb database and can be extended to arbitrary drug pairs and cell lines. The medical-knowledge-based (MK)-GNN model [89] effectively integrates patient representations derived from historical medical records with essential medical knowledge, including prior knowledge and medication knowledge, to enhance medication combination prediction (MCP). Finally, the researchers performed a case study to show the application value of the MK-GNN. In addition to research on drug combinations, GCNs are also suitable for predicting DDIs. The GCN-BMP method [90] for predicting DDIs uses GCNs with a focus on bond-aware message propagation. Unlike several methods that consider various drug-related features that may cause noise, this model addresses this limitation by employing an end-to-end graph representation learning technique and achieves superior performance.

## Section: Drug combination target prediction › Transformer-based association algorithms for drug combination target prediction

While CNNs/GCNs have significantly advanced research, such as DDI prediction, the field of drug combination research is looking toward more sophisticated models, such as transformers (Table 2) [[91], [92], [93], [94], [95], [96], [97]].

SynergyX [91] has emerged as a groundbreaking tool in the domain of antitumor drug synergy prediction. This model is trained on features of drug substructures and multiomics data and uses a multimodality mutual attention network to capture information on intricate biological interactions, which excels in DrugComb task testing. The SynergyGTN [92] model represents a significant advancement in predicting synergistic drug combinations for cancer treatment. By leveraging graph transformer networks and integrating comprehensive drug and cell line features, SynergyGTN achieves notable improvements, with a receiver operating characteristic curve improvement of 5% over the state-of-the-art methods in terms of five-fold cross-validation. DeepPSE [93] presents a novel deep learning method to predict polypharmacy side effects by integrating multiple neural network types and a transformer encoder block for feature extraction. The model then applies feed-forward layers to predict polypharmacy side effects of drug pairs. Transformers also play an important role in the field of DDI prediction. The multi-source drug fusion, multi-source feature fusion (MDF)-self-attention (SA)-DDI model [94] introduces a sophisticated approach for predicting DDI events by employing a combination of multisource drug fusion and feature fusion with a transformer self-attention mechanism. This method distinguishes itself by not only predicting whether drugs interact but also detailing the nature of those interactions, providing a deeper understanding of drug interaction mechanisms. LaGAT [95] introduces a novel approach for DDI prediction by utilizing a link-aware graph attention mechanism that customizes attention pathways on the basis of different drug pair links. This method enhances the model’s ability to capture meaningful semantic relationships between drugs, leading to improved performance and interpretability over both traditional and contemporary models.

The emergence of large-scale deep learning models has revolutionized various fields, including pharmacology. Following the development of BERT, the advent of generative pretrained transformers (GPTs) and other LLMs has significantly propelled research in drug combination studies. These models, which leverage vast textual descriptions, offer novel insights and methodologies for predicting effective drug synergies, thus enhancing the potential for breakthroughs in personalized drug and treatment strategies. Huang et al. [96] proposed an innovative approach using the extraction and generation with fusion of enriched entity and sentence information (EGFI) model, which integrates BioBERT and BioGPT-2 to enhance DDI extraction from the biomedical literature. This framework significantly improves DDI prediction by fusing enriched entity and sentence information, demonstrating its utility in identifying unrecorded drug interactions and potential novel relationships and providing a valuable tool for biomedical research. Li et al. [97] explored a novel application of LLMs to predict drug pair synergy in rare cancerous tissue with limited data. Leveraging the advanced capabilities of LLMs for few-shot learning, the study demonstrates that CancerGPT, a model tailored for this specific task, significantly enhances prediction accuracy compared with traditional data-driven models, especially in contexts where data are scarce. This approach opens new avenues for the use of AI in personalized medicine and highlights the potential of LLMs in biomedical applications.

## Section: Conclusion

Drug-target interactions are crucial in AI-assisted drug development. By leveraging advanced deep learning techniques such as CNNs, GCNs, and transformers, along with network-based models and traditional ML methods, these approaches have significantly improved prediction accuracy and broadened the generalization capabilities of models. These advancements are particularly useful for identifying single drug-target interactions and understanding the complex dynamics of drug combination‒target interactions. As a result, they accelerate the drug discovery process and contribute to the development of more effective and personalized therapies. The significance of these advancements lies in their ability to process and learn from vast amounts of biological data, overcoming the limitations of traditional methods that often struggle with the complexity of molecular interactions. For example, CNNs excel at identifying spatial patterns and structural features of molecules, which are critical for predicting potential drug-target interactions. GCNs offer a detailed representation of molecular structures and their related data, providing a comprehensive understanding of how individual drugs interact with specific targets. Owing to their powerful attention mechanisms, transformers further increase prediction accuracy by capturing intricate dependencies within biological sequences. Network-based models add to this predictive framework by offering a systems-level perspective, integrating various data sources to reveal complex biological interactions. Traditional ML techniques complement these approaches by efficiently handling large datasets and extracting relevant features, thereby increasing overall predictive accuracy and reliability.

Predicting drug combination-target interactions presents additional challenges owing to the increased complexity of multidrug interactions. Deep learning methods, such as CNNs, GCNs, and transformers, have shown promise in addressing these challenges by modeling the combined effects of multiple drugs on biological targets. GCNs, in particular, excel at representing and analyzing the relational data inherent in drug combinations, providing insights into synergistic and antagonistic effects. The ability of transformers to handle complex sequential data is instrumental in predicting the outcomes of drug combinations on specific targets. Network-based models offer a holistic approach, which is crucial for understanding the broader implications of drug combinations within biological systems, enabling the identification of multitarget strategies and potential side effects. The integration of molecular collision models further enhances these predictions by simulating the physical interactions between drug combinations and targets, offering detailed insights into binding affinities and specificities.

However, the application of AI in drug development is not without its limitations. Despite the promise shown by these techniques, challenges remain in ensuring the interpretability of AI models, especially when dealing with the complex nature of biological systems. The “black-box” nature of deep learning models can obscure the mechanistic understanding of how predictions are made, which is critical for regulatory approval and clinical adoption. Additionally, the quality and diversity of the training data significantly influence the performance of AI models. Biases in the data can lead to inaccurate predictions, potentially resulting in serious implications for drug development. In the context of drug combination-target interactions, this increased complexity presents additional challenges. While deep learning methods such as GCNs and transformers have shown promise in modeling the combined effects of multiple drugs, the potential for unforeseen interactions and side effects remains a significant concern. Moreover, the ability of these models to predict synergistic and antagonistic effects is still limited by the availability of comprehensive training datasets that capture the full range of possible drug interactions.

Despite these challenges, the integration of deep learning, network-based models, and traditional ML provides a robust framework for advancing drug discovery. These approaches not only accelerate the identification of promising drug candidates but also have the potential to revolutionize the development of personalized therapies. As these technologies continue to evolve, their impact on drug development is likely to grow, offering new possibilities for the treatment of complex diseases. However, addressing current limitations, such as improving model interpretability, enhancing data quality, and ensuring the ethical use of AI, will be essential to fully comprehend the potential of AI in drug development and clinical applications.

## Section: CRediT authorship contribution statement

Boyang Wang: Writing – review & editing, Writing – original draft, Visualization, Data curation. Tingyu Zhang: Writing – original draft, Visualization, Data curation. Qingyuan Liu: Writing – original draft, Visualization, Data curation. Chayanis Sutcharitchan: Writing – original draft, Data curation. Ziyi Zhou: Writing – original draft, Data curation. Dingfan Zhang: Data curation. Shao Li: Writing – review & editing, Project administration, Conceptualization.

## Section: Declaration of competing interest

The authors declare that there are no conflicts of interest.


---

# Enhancing drug discovery and patient care through advanced analytics with the power of NLP and machine learning in pharmaceutical data interpretation

- **Authors:** Nagalakshmi R, Surbhi Bhatia Khan, Ananthoju Vijay Kumar, Mahesh T R, Mohammad Alojail, Saurabh Raj Sangwan, Mo Saraee
- **Issuer:** SLAS technology
- **Type:** Scientific article
- **Published:** 2024-12-24
- **Language:** en
- **DOI:** 10.1016/j.slast.2024.100238
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39722407/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

This study delves into the transformative potential of Machine Learning (ML) and Natural Language Processing (NLP) within the pharmaceutical industry, spotlighting their significant impact on enhancing medical research methodologies and optimizing healthcare service delivery. Utilizing a vast dataset sourced from a well-established online pharmacy, this research employs sophisticated ML algorithms and cutting-edge NLP techniques to critically analyze medical descriptions and optimize recommendation systems for drug prescriptions and patient care management. Key technological integrations include BERT embeddings, which provide nuanced contextual understanding of complex medical texts, and cosine similarity measures coupled with TF-IDF vectorization to significantly enhance the precision and reliability of text-based medical recommendations. By meticulously adjusting the cosine similarity thresholds from 0.2 to 0.5, our tailored models have consistently achieved a remarkable accuracy rate of 97 %, illustrating their effectiveness in predicting suitable medical treatments and interventions. These results not only highlight the revolutionary capabilities of NLP and ML in harnessing data-driven insights for healthcare but also lay a robust groundwork for future advancements in personalized medicine and bespoke treatment pathways. Comprehensive analysis demonstrates the scalability and adaptability of these technologies in real-world healthcare settings, potentially leading to substantial improvements in patient outcomes and operational efficiencies within the healthcare system.


---

# Ethical and regulatory challenges of large language models in medicine

- **Authors:** Jasmine Chiat Ling Ong, Shelley Yin-Hsi Chang, Wasswa William, Atul J Butte, Nigam H Shah, Lita Sui Tjien Chew, Nan Liu, Finale Doshi-Velez, Wei Lu, Julian Savulescu, Daniel Shu Wei Ting
- **Issuer:** The Lancet. Digital health
- **Type:** Scientific article
- **Published:** 2024-04-23
- **Language:** en
- **DOI:** 10.1016/s2589-7500(24)00061-x
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38658283/
- **Licence:** CC-BY-NC

## Section: Abstract

With the rapid growth of interest in and use of large language models (LLMs) across various industries, we are facing some crucial and profound ethical concerns, especially in the medical field. The unique technical architecture and purported emergent abilities of LLMs differentiate them substantially from other artificial intelligence (AI) models and natural language processing techniques used, necessitating a nuanced understanding of LLM ethics. In this Viewpoint, we highlight ethical concerns stemming from the perspectives of users, developers, and regulators, notably focusing on data privacy and rights of use, data provenance, intellectual property contamination, and broad applications and plasticity of LLMs. A comprehensive framework and mitigating strategies will be imperative for the responsible integration of LLMs into medical practice, ensuring alignment with ethical principles and safeguarding against potential societal risks.


---

# Ethical and social reflections on the proposed European Health Data Space

- **Authors:** Ciara Staunton, Mahsa Shabani, Deborah Mascalzoni, Signe Mežinska, Santa Slokenberga
- **Issuer:** European journal of human genetics : EJHG
- **Type:** Scientific article
- **Published:** 2024-02-14
- **Language:** en
- **DOI:** 10.1038/s41431-024-01543-9
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38355959/
- **Licence:** CC-BY

## Page 1 (Section: Ethical and social reflections on the proposed European Health DataSpace)

REVIEW ARTICLE
OPEN
Ethical and social reﬂections on the proposed European Health
Data Space
Ciara Staunton
1,2✉, Mahsa Shabani
3, Deborah Mascalzoni
1,4, Signe Mežinska
5 and Santa Slokenberga6
© The Author(s) 2024
The COVID-19 pandemic demonstrated the beneﬁts of international data sharing. Data sharing enabled the health care policy
makers to make decisions based on real-time data, it enabled the tracking of the virus, and importantly it enabled the development
of vaccines that were crucial to mitigating the impact of the virus. This data sharing is not the norm as data sharing needs to
navigate complex ethical and legal rules, and in particular, the fragmented application of the General Data Protection
Regulation (GDPR). The introduction of the draft regulation for a European Health Data Space (EHDS) in May 2022 seeks to address
some of these legal issues. If passed, it will create an obligation to share electronic health data for certain secondary purposes.
While there is a clear need to address the legal complexities involved with data sharing, it is critical that any proposed reforms are
in line with ethical principles and the expectations of the data subjects. In this paper we offer a critique of the EHDS and offer some
recommendations for this evolving regulatory space.
European Journal of Human Genetics (2024) 32:498–505; https://doi.org/10.1038/s41431-024-01543-9
INTRODUCTION
As we emerge from the COVID-19 pandemic, the beneﬁts of
global data sharing to address a global pandemic are evident.
Data sharing enabled health care policy makers to make decisions
based on real-time data, it enabled the tracking of the virus, and
importantly it enabled the development of vaccines that were
crucial to mitigating the impact of the virus. This could only have
been achieved through local, national, and crucially international
data sharing. This global data sharing, however, was the exception
and not the norm. Efforts to share data for research are
challenging due to legal and ethical issues that include privacy,
personal data protection, consent, risk of discrimination and
stigmatization [1–3]. In recent years, researchers have cited the
General Data Protection Regulation (GDPR) as hampering the
sharing of personal data for research [4]. This is in part due to the
fragmented implementation of the GDPR across the European
Union (EU) Member States and lack of clarity in legal bases for
secondary uses of data [5, 6].
In May 2022, the draft regulation for the European Health Data
Space (EHDS) was published. As part of the European Commis-
sion’s plans to build a strong European Health Union and to realize
the potential that data holds for the economy [7], the draft
regulation is proposing one legal framework to facilitate access to
electronic health data across all Member States for eight speciﬁed
purposes that, as described in Recital 1 “would beneﬁt society
such as research, innovation, policy-making, patient safety,
personalized medicine, ofﬁcial statistics or regulatory activities”.
The aim is that this will address some of the elements of the GDPR
that are perceived to hamper data sharing [4]. The ambition is that
enabling access to data will improve research, policy making, and
innovation, leaving the EU and Member States better able to
respond to health crises and future pandemics, improve treatment
and care, and increase the competitiveness of the EU, amongst
other purposes.
A framework that facilitates data sharing is without a doubt
needed. Such a framework must provide for data sharing through
processes that respect the preferences and values of participants,
have oversight mechanisms in place, and processes to ensure the
equitable beneﬁts arising from such data sharing. This data
sharing framework also needs to account for the multitude of risks
that arise in the secondary use of data. This may be due to the
risks associated with the type of data itself (e.g., there are greater
risks associated with the use of genetic data), but also risks
associated with data use (e.g., data can discriminate certain
groups or populations based on prevalence of a condition or if
they have certain characteristics that correlates with unhealthy
conditions). Concerns such as stigmatization, discrimination,
exploitation, and other data driven harms are often contextual
depending on the use, including the entity using that data, and a
framework on data sharing must have processes in place to
account for these concerns.
The EHDS is a real opportunity to introduce such a framework. A
legally sound and ethically robust data sharing process for
secondary use should result in a social licence for the secondary
use of data [8]. A social licence refers to the fulﬁlling expectations
of society in certain activities that go beyond the requirements set
out in formal regulation [8, 9]. In the context of the secondary use
of data, this would require not only compliance with the
applicable laws, but also ensuring that the use of this data is in
line with the expectations of society. However, from the draft
Received: 28 March 2023 Revised: 8 November 2023 Accepted: 15 January 2024
Published online: 14 February 2024
1Institute for Biomedicine, Eurac Research, Bolzano, Italy. 2School of Law, University of Kwazulunatal, Durban, South Africa. 3Faculty of Law and Criminology, Ghent University,
Gent, Belgium. 4Department of Public Health and Caring Science, Uppsala University, CRB, P.O. Box 256, 751 05 Uppsala, Sweden. 5Institute of Clinical and Preventive Medicine,
University of Latvia, Riga, Latvia. 6Faculty of Law, Uppsala University, Uppsala, Sweden. ✉email: Ciara.staunton@eurac.edu
www.nature.com/ejhg
1234567890();,:

## Page 2 (Section: Ethical oversight and the secondary use of data under the relevant ethics guidelines and theGDPR)

EHDS text, it does not appear that sufﬁcient consideration has
been given to the ethical, legal and social issues (ELSI) that must
be addressed in data sharing [1, 10–14]. The secondary use
framework is a data access regime put forward by the European
Commission that is anchored in the GDPR model and the right to
data protection. Data protection is critical but only one issue to be
considered in data sharing. Other factors, speciﬁcally the right to
autonomy, a right that in the context of data driven methods
relates to the right to decide over what will be done with ones’
own data, and the need to guard against discrimination and
stigmatization that can occur on a group level must be
considered, in addition to the potential beneﬁts that can accrue
in beneﬁt sharing.
Changes to the draft EHDS text that are to be proposed by the
European Parliament in the legislative process address to some
degree issues related to the right to autonomy (e.g., the proposed
inclusion of an opt-out provision for those who do not wish their
data to be shared in certain contexts), but do not address the
wider ELSI concerns in this domain. At this time, there is a
potential for improvements to the text and the purpose of this
paper is to offer some critiques and propose solutions. In this
paper, when discussing the draft EHDS, we refer to the draft text
and the proposed amendments, unless otherwise stated. We ﬁrst
brieﬂy discuss the current ethical processes in the secondary use
of data and the changes brought about by the introduction of the
GDPR. Second, we set out the EHDS and the proposed framework
on the secondary use of electronic health data. We then turn to
critically reﬂect on the proposed framework demonstrating the
problems in three areas: risks to natural persons, restriction of
right to autonomy, the lack of ELSI informed approach to two new
proposed processes. We conclude by offering proposals on how a
revised regulation can enable an ethical approach to the
secondary use of data under the EHDS.
ETHICAL OVERSIGHT AND THE SECONDARY USE OF DATA
UNDER THE RELEVANT ETHICS GUIDELINES AND THE GDPR
Research ethics is an important mechanism to balance the
protection of the rights of research participants with the public
value of science for society. Informed consent is a critical
component of the ethical conduct of human subject research,
but equally so is research ethics committee (REC) oversight. The
REC provides an independent review to help ensure that research
is scientiﬁcally and ethically sound with a fair balance between the
risks to the participants and the beneﬁt to society [15]. Informed
consent and independent ethical review continue to be followed
in the context of interventional research, but the development of
data driven research methods has brought about changes to
some of the procedures and governance of research ethics, as
they have emerged from the Nuremberg Code, the Declaration of
Helsinki, and the Belmont Report [16–18]. The reason for this
change is that the risk to individual in data driven research is
different. Interventional research carries physical risk, but the risks
in the use of data for research relate to personal autonomy,
privacy, and data protection. Beyond the individual, there is a risk
that the use of data can lead to group level discrimination and
stigmatization, due to the presence of certain conditions but also
the correlation of characteristics with certain behavior [19, 20].
Data, however, can be collected, stored, used, and re-used with
minimal physical risk to participants. Due to this minimal physical
risk to participants, there have been changes in some of our long-
standing ethical rules, particularly in relation to informed consent.
These new research avenues have also identiﬁed new ethical
challenges such as the return of results and incidental ﬁndings
[21–27].
In the context of data driven research methods, we have seen a
push to move from a paradigm that gives speciﬁc informed
consent to one study, to broad consent that provides consent to
certain unspeciﬁed research [28]. Due to concerns that broad
consent is not informed consent, tiered consent that provides
participants with a range of consenting preferences, and dynamic
consent which uses information technology to facilitate consent
to projects, change, and up-date their consenting preferences
have emerged as potential new forms of consent for data
intensive research [11, 23, 29, 30]. In most cases, consent alone is
insufﬁcient to protect participants and new governance models
have emerged. For example, data access committees (DACs), are
mechanisms through which data access requests are considered
and can
balance the competing rights and interests of the
participants, the data holder, and the interests of science
[13, 31, 32]. In light of these new ethical challenges and
governance processes, new guidance has been developed for
data intensive research methods, such as the Declaration of Taipei
which evolved from the Declaration of Helsinki [33].
Perhaps the most signiﬁcant change in the regulation of data
intensive research methods, has been the introduction of the
GDPR. Introduced to harmonize rules and principles on the
protection of personal data across the EU, key principles must now
be met in the processing of personal data and data subjects have
certain rights in the processing of their personal data. In
recognition of the importance of scientiﬁc research, the GDPR
provides for certain exceptions or derogations for research [5].
While often the primary concern in the regulation of data
intensive research methods, the GDPR is not a research regulatory
instrument. Recital 33 makes reference to “recognized ethical
standards for scientiﬁc research” in the context of consent, but
beyond this, the GDPR does not take account of or integrate other
ethical norms, standards and practices. The purpose of GDPR is
the protection and free movement of personal data thus the GDPR
does not account for the other ethical concerns and challenges
that need to be addressed in data intensive research.
When collecting data from individuals for the ﬁrst time for
research, the principles of research ethics require REC approval
and informed consent. Under the GDPR, data subjects have the
right to be informed about aspects of the use of their data,
including the purposes for which the data can be used. This right
ensures transparency and provides data subjects with the right to
object to the use of their data in research. This is not always
the case for the secondary use of data. Due to derogations
provided for research under the GDPR, the right to information
can be derogated from if the personal data is not collected directly
from the participant. If a participant is not aware that their data is
being processed for research, they are not able to exercise their
right to object, leaving a participant with a limited ability to
exercise their autonomous choice in what their data will be used
for [34].
Despite the legal acceptability of the derogation of the right to
information, there is considerable ELSI work that has looked at
participants perspectives on the use of their data in research.
While participants are often motivated by altruism to give their
data for research and this should continue to be encouraged, they
often have clear preferences on the use of their data and concerns
that must be considered and addressed when their data is used
for research [19, 35]. In other contexts, stigmatization and
discrimination has emerged as concerns, particularly in the use
of genetic and other health related data [19]. Thus it is important
that there are checks in place to guard against data harms. It is for
this reason that some of us have called for an integrated ethics
approach to the interpretation and application of the GDPR for
research by which we mean the safeguards required under Article
89 when personal data is being processed for research should be
informed by safeguards required as part of the ethical conduct of
research [36]. This could ensure that the primary and secondary
use of personal data in research follows current ethical practices
and principles of human rights that go beyond just data
protection concerns in data intensive research methods.
C. Staunton et al.
499
European Journal of Human Genetics (2024) 32:498 – 505

## Page 3 (Section: Accessing electronic health data for secondary purposes under theEHDS)

ACCESSING ELECTRONIC HEALTH DATA FOR SECONDARY
PURPOSES UNDER THE EHDS
In part response to the fragmented implementation of the GDPR,
the proposed EHDS is seeking to create a legal obligation on data
holders to share electronic health data for secondary purposes if
certain conditions are met. Slokenberga has comprehensively
detailed the process for accessing electronic health data for
secondary purposes, but key elements are worth noting [37].
Any natural or legal person can apply for access to the
electronic health data (called a “data user”) from a data holder
(“any natural or legal person, which is an entity or a body in the
health or care sector, or performing research in relation to these
sectors”). Electronic health data is broadly deﬁned and includes
electronic health records, genetic data, and population-based
health data. Most of the data that is available to be accessed, will
by and large, be data that has been collected in the context of
clinical care or research. The data user can use this data for one of
the currently eight proposed secondary uses under Article 34(1)
that includes public health activities in the public interest,
scientiﬁc research related to the health or care sector, training
and testing of AI, providing personalized care, amongst others.
There are currently two proposed avenues for accessing
electronic health data. If access is sought from one data holder
from one Member State, access can be applied directly to the data
holder themselves under Article 49. For all other cases, access is
decided by a Health Data Access Body (HDAB), a new entity to be
established in each Member State. Under Article 36(1), a Member
State may establish one or more new public sector bodies to fulﬁll
the role, or rely on either an existing public sector bodies or an
internal services of public sector bodies.
The many duties of the HDAB include approving data access
applications, issuing data permits, process electronic health data for
secondary purpose, including the collection, combination, prepara-
tion and disclosure of those data for secondary use on the basis of a
data permit, and making public a national dataset catalog (Article
37). The HDAB must cooperate with bodies that includes supervisory
authorities under the GDPR, and other stakeholders, including
patient organizations, representatives from natural persons, health
professionals, researchers, and ethical committees, where applicable
in accordance with EU and national law.
An access application should include a detailed explanation of
the purpose of the data use; description of the requested data; a
justiﬁcation why anonymous data would not sufﬁce if access to
pseudonymized data is sought; (undeﬁned) safeguards to prevent
unauthorized use and protect the rights and interests of the data
holder and natural persons; estimated time period data is
required; details on a secure processing environment. If personal
data is requested, the applicant must describe how they comply
with the GDPR and information on any ethical aspects that are
applicable. Article 44 also makes it clear the importance of the
principle of data minimization and purpose limitation in the
HDAB’s assessment.
The HDAB must make an assessment within two months of
receiving an application, extendable by two months for complex
applications. If the criteria are met, the HDAB requests the data
from the data holder. The HDAB makes the data available to the
data user through a secure processing environment within two
months. A data permit is then issued to the data holder specifying
the terms and conditions of the data use.
CRITICAL REFLECTION OF THE EHDS AND THE PROPOSED
AMENDMENTS THROUGH AN ETHICAL LENS
The draft EHDS should enable the sharing of electronic health data
for secondary purposes. Our concern is that the current proposed
process would result in incursions on some of our ethical
principles in research. Speciﬁcally we highlight four concerns:
under the proposed EHDS data protection is the principle data
harm that is considered; the special regime for research under the
GDPR would apply to all stated purposes for secondary use under
the EHDS; the proposed new process is a further erosion of the
right to autonomy; and some of the purposed new processes
need to be supported by ethical oversight and guidance before
they are implemented.
ASSUMPTION THAT DATA PROTECTION IS THE ONLY
CONCERN IN SECONDARY USE OF DATA
The proposed EHDS is seeking to drive forward and streamline the
data sharing agenda within Europe. It creates an obligation to
share electronic health data, and Article 43 gives the HDABs the
power to issue ﬁnes and penalties if data is not shared.
A reading of the EHDS would lead one to assume that data
protection is the only concern in the secondary use of data. It
establishes that, as a rule, the data should be released in an
anonymized format unless pseudonymized data are necessary for
the stated purpose. For pseudonymized data, the code key
remains with the HDAB, and, as provided for in Article 44(3), any
attempt by the data user to attempt reidentiﬁcation “shall be
subject to appropriate penalties”. In its application the data user
must also describe safeguards to protect (amongst others) the
rights and interests of the natural person (Article 45(2)(f)), without
any consideration of what these rights are. Considering the tenor
of the proposed regulation, it is most likely that this will be
interpreted to mean rights and interests as they relate to data
protection.
The European Data Protection Board (EDPB) and the European
Data Protection Supervisor (EDPS) have issued a joint opinion
critiquing the proposed regulation and demonstrating where, in
their view, it does not conform the GDPR requirements [38]. We
echo many of these critiques and do not restate them here.
However, even if these critiques are addressed, they would not
account for the inherent assumption throughout the proposed
regulation that data protection is the only concern. Even if data is
anonymized, the data can be misused, used beyond what an
individual consented to or reasonably expected the data to be
used for, and lead to group discrimination and stigmatization.
REC approval is one such mechanism that can guard against
data misuse and other potential risks. It is for this reason that the
Declaration of Taipei, the CIOMS guidelines and other ethical
guidance, as well as some jurisdictions in Europe (e.g, Sweden)
require REC review for the secondary use of data. The EHDS leaves
the requirement of ethical assessment to Member States. Thus
while the EHDS will introduce a harmonized legal framework that
will streamline the legal process, but there is no such harmoniza-
tion
of
ethical
processes
in
the
secondary
use
of
data.
Fragmentation will continue until both legal and ethical processes
are harmonized across Member States.
Second, there is a duty on the data user only to assess the
ethical aspects. If the data user is applying from a jurisdiction that
is different to that of the data holder, differing ethical rules may
apply. The data holder may be bound by ethical rules that restrict
the sharing of the data without ethical review, but the EHDS does
not provide an avenue for the data holder to object to the sharing
of data on ethical grounds. For example, if a population biobank
has obtained the consent of its participants to use the data for
speciﬁed research purposes only, will they be forced to share the
data for other purposes without going back to its population to
recontact as per the consent? Without clarity, it is likely that this
will create complex questions regarding the different ethical rules
in each jurisdiction.
Third, ethical approval is generally only required where data is
being accessed for research purposes. Thus, for data use that does
not fall under research regulatory frameworks, national research
ethics frameworks will not apply and no other avenue for
potential oversight of these other potential data harms. Yet the
C. Staunton et al.
500
European Journal of Human Genetics (2024) 32:498 – 505

## Page 4 (Section: Disproportionate extension of special research regime to other secondary purposes)

concerns on the secondary use of data apply irrespective of
whether the data is to be used for research, training and
development of AI or other secondary purposes. This leaves us
with a gap on how these ethical issues on data use should be
addressed for data use outside of research going forward.
DISPROPORTIONATE EXTENSION OF SPECIAL RESEARCH
REGIME TO OTHER SECONDARY PURPOSES
The GDPR has provided for certain derogations for research,
including derogation from the right to information. Without this
right, data subjects will be unaware that their data is being
processed and thus unable to exercise their other rights. However
due to the importance of scientiﬁc research in society, a
derogation to this right (and the associated downstream impact
on other rights) is considered proportionate if the processing of
the personal data is for research.
Under Article 38 of the proposed EHDS, the derogation to the
right to information now applies to all proposed secondary
purposes. Derogating from rights under the GDPR research regime
can only be acceptable if certain conditions are met, determined on
a case-by-case assessment. Under the proposed EHDS this deroga-
tion is now autonomatic [5]. The use of the data outside of research
does not have any such protections in place such as REC oversight,
nor is the derogation of the right to information to the seven other
purposes balanced with any other standards or safeguards. While
we welcome that Articles 38 and 39 mandate the Health Data
Access Bodies to make available certain information to the public,
this information is on a general level only and in no way remedies
this wide extension of the derogation of right to information. Any
extension of the erosion of data subjects’ rights must be justiﬁed
with other mechanisms in place to ensure that the rights and
interests of data subjects continue to be safeguarded.
CONSENT, AUTONOMY, TRUST, AND SOCIAL JUSTICE
Consent is one of a number of lawful bases for the processing of
personal
data
and
sensitive data
under
the
GDPR.
Some
jurisdictions, such as Italy, have taken a restrictive approach to
the implementation of the GDPR for research and require consent
as the lawful basis for processing of genetic data for research. In
other countries consent may not be mandated as the lawful basis
of the processing of data, but required as part of the national
ethical rules [39].
The draft EHDS is seeking to address this fragmented approach to
the requirement of consent as a lawful basis and under Article 33(5)
if consent is required by national law, “health data access bodies
shall rely on the obligations laid down in this Chapter to provide
access to electronic health data”. In the explanatory memorandum,
this is justiﬁed on the basis that it is replacing it with “with a trusted
governance and at lower costs than relying on consent”.
An appropriate consent process is an ongoing challenge for the
data driven research community. Risks relate to privacy, stigma-
tization, and discrimination, but the potential use of data,
particularly genetic data, impacts the individual, their family,
community, and wider population from which the individual
comes from. There is also a risk if appropriate governance
processes are not put in place and data cannot be reused.
Governance processes also need to account for beneﬁt, particu-
larly ensuring equity of beneﬁt.
New governance models, particularly models that are premised
on participatory governance, have been proposed. Prainsack’s
model of solidarity is advocating for governance models whereby
there are equitable harms and beneﬁts across society and we
share our data on this premise [20, 40–42]. Data trusts have been
proposed whereby data subjects give their data to be managed by
data trustees. The trustees are then responsible for stewarding the
data for the beneﬁt of others, known as the beneﬁciaries [43, 44].
While the beneﬁt may not be for the data subjects themselves
(and so would speak to data driven research methods), the data
subjects decide on their involvement in the data trust and that
there is ongoing stakeholder and public engagement [45]. Other
proposed governance models include data commons and data
cooperatives [46–48]. The legal framework proposed under the
EHDS is thus somewhat similar to these proposals in that it is
seeking to enable the secondary use of data. There are two
notable differences: ﬁrst, as discussed, the measures under the
EHDS focus exclusively on the individual data protection concerns,
and second is the treatment of consent under the EHDS.
Despite changes to the process of consent, consent remains a
fundamental requirement in research ethics and in these other
proposed models, the data subject does have a role in deciding on
whether their data is to be part of the data trust (for example). Our
concern is that in the original proposed text, the Commission is
considering the current model of informed consent only, a model
that is indeed burdensome, costly, and challenging to continu-
ously go back and ask for consent. Broad consent and tiered
consent while suitable options, do require re-consent if the
purpose is beyond that what is speciﬁed in the consent, a process
that may frustrate the data users as the technology and potential
data use constantly changes. What is needed is a consent that is
not static but can change in accordance with the data subject’s
preferences and also potential data uses. What is not needed are
legal frameworks that provide access to data without consent.
The UK and Australia are examples where there was a public
push back to schemes that sought to share data without the
consent of the patients [8]. Such proposed schemes failed for
several reasons including poor public engagement, but they serve
as a stark reminder that a social licence and public acceptance to
access data for research cannot be assumed simply by having a
legal framework in place. The EHDS is undoubtedly introducing
new governance process for the secondary use of electronic
health data. Public trust is also critical, but legal legitimacy alone
does not automatically equate to trusted governance [49–51].
Lessons must be learned from the ELSI work in this domain to
consider how it can become a trusted governance. Empirical
research has demonstrated the importance of ongoing informa-
tion about data use, and that individuals have preference on how
their data will be used, preferences that must be respected.
This is of particular importance when one considers that under
the proposed EHDS, data can be used for purposes that the
individual did not consent, nor would have expected their data to
be used. Once passed, a general information campaign should
alert patients that their electronic health record may be used for
secondary purposes. However, at the time that they provided their
data, a patient is unlikely to have expected that their data
collected as part of their individual electronic health record will be
used for the development and training of AI, for example. Equally
participants who have donated their data to a biobank, will expect
that their data will only be used in accordance with that consent.
Undoubtedly, they would not expect that their data will be used
for purposes other than research. The EDPB/EDPS Joint Opinion on
the EHDS has pointed out that this provision on consent is
incompatible if consent has been the ground for the lawful
processing of data under the GDPR. However, this issue extends
beyond a conﬂict of laws situation as it could impact trust. Indeed,
we would have concerns about the impact this could have on
participant trust in biobank research if a biobank, for example, is
obliged to share data for secondary purposes that go beyond the
participants’ consent. The reputational damage and loss of trusted
position that likely have in their community could be untold.
The draft Report from the European Parliament raises this point
and draft amendment 13 recommends that patients can opt-out
to the secondary use of their electronic health data and to inform
them of this possibility to opt-out. This is expanded further in draft
amendment 84 that states:
C. Staunton et al.
501
European Journal of Human Genetics (2024) 32:498 – 505

## Page 5 (Section: EHDS and the return of results)

“Natural persons that are subjects to secondary use of health
data shall have the right to decline the processing of their health
data. Health data access bodies shall provide for an accessible and
easily
understandable
opt-out
mechanism,
whereby
natural
persons must be offered the possibility to explicitly express their
wish not to have all or part of their personal electronic health data
processed for some or all secondary use purposes. In situation
where natural persons explicitly express their wish to use opt-out
mechanism to data holders, data holders shall direct natural
persons to the health data access bodies.”
We endorse this position sketched out by the European
Parliament. This opt-out mechanism, if embedded in an appro-
priate thick information process [52] would provide a more equal
balance between providing access to electronic health data for
secondary purposes while also providing individuals with control
over their electronic health data. It will also ensure that patients
are empowered to have control over their electronic health data,
which is one of the aims of the EHDS.
To realize this amendment, however, conversations now need
to turn to how to manage this opt-out process. A system that
facilitates communication with individuals to describe the purpose
for which access to their data will be used and enable a response
will be required. As an opt-out system is being envisaged, a
dynamic interface that enables the provision of information to
data subjects on data use and a process to enable them to actively
opt-out will need to be developed. As this must be developed, we
would also call for consideration to extend this provision beyond
opt-out only to enable the selection of an opt-in process also for
those who would wish to have to opt-in only i.e., the default that
their data not be used unless they actively consent to the use of
their data for the proposed purpose if they so wish. Let us pause
to consider that for one moment. There have been discussions
and considerations on whether citizens have an ethical duty to
share their health information for research without consent
[12, 53]. There have also been calls for solidarity (understood in
this context as a wiliness to share data for the beneﬁt of others) to
underpin the governance of data driven research [40, 50].
However to realize solidarity-based approaches, the beneﬁts and
costs of the access to and use of data should be borne collectively.
Under the draft EHDS, the focus is on access to the data only, with
no consideration of access to the down-stream beneﬁts in
possible outputs of the use of the data. Can we really guarantee
that any downstream beneﬁts will be equally shared amongst
citizens? Leaving the issue of beneﬁt to one side, there is research
demonstrating concerns about commercial bodies having access
to data [35, 54, 55]. While we recongise the important role of
industry in the development of therapeutics and treatments,
citizens’ concerns must be adequately accounted for. Citizens who
have concerns on data sharing may be frustrated that they
constantly must opt-out of a system that they do not want to opt-
in to, except in limited circumstances. If we are designing a system
that provides for opt-out, it can also facilitate opt-in. The system
could give citizens the possibility to select opt-in, opt-out, or
indeed indicate that they are happy to share their data for any
purposes that has been approved by the new governance process.
Increasingly there are examples of the application of dynamic
consent and e-consent being integrated into research [23, 56].
Critiques of dynamic consent have raised concerns that there would
be many withdrawals leading to high drop-out rates, that the system
would be difﬁcult to manage, particularly for those who are not
digitally literate, or that the system is not scalable. Dynamic consent
does require investment in the setting up of the system, both in
terms of infrastructure and personnel. It also requires expertize in
participant engagement and communication. This is a system,
however, that will need to be built to support and manage the opt-
out and can be adapted to support an opt-in. As to the concerns
that it will lead to high dropout rates, this has not transpired in the
experience of two of the authors of this paper in the practical
application of dynamic consent in a population biobank [11].
Furthermore, high dropout rates would be more likely due to
concerns around the data use or system and not the consent
process. The solution to managing high drop out rates is not an
erosion of the choice, but an unpacking of why there are such rates
and identifying solutions to address those concerns. Participants will
also need to be informed about their responsibilities for keeping
their contact information up to date so that they can opt out or opt
in (depending on their preferences). They should also be informed
about the importance of the use of their data and the risks for
development and innovation if their data is not use. In this way,
discussions on consent, autonomy, opt-in, and opt-out, can be
presented in the context of the role of their data in wider society.
It is worth noting that although the Parliament’s draft proposal
addresses the issue of the right to autonomy of the individual, it is
not clear whether Article 33(5) also applies when consent is required
as part of national ethical requirements (as distinct from when
consent is the lawful basis of processing). If the ethical assessment
that may be required (depending on Member State law) as part of
the secondary use of data requires the use of the data to be in line
with consent, can this override the EHDS provisions on consent?
Once again there is uncertainty in the interplay between national
ethical rules and proposals under the EHDS.
EHDS AND THE RETURN OF RESULTS
In addition to creating an obligation to share data, the draft EHDS
introduces the possibility of return of results to individuals for data
that is not anonymous. Article 46(12) provides that a condition of
the data permit is that data users are to inform the HDAB of
“clinically signiﬁcant ﬁndings that may inﬂuence the health status
of the natural persons whose data are included in the dataset”. We
very much welcome this proposal as returning results to
individuals that arise in the secondary use of their data signiﬁes
respect to the participant and enables the individual to be more
fully informed about their health. However, this provision as
currently framed in the EHDS is in its infancy and we currently see
two major issues that needs to be addressed.
First, there is emerging ethical consensus that clinically
signiﬁcant and actionable research results should be returned to
participants, although there is not always clear consensus on what
clinically signiﬁcant results means in research ﬁelds such as
genetics and genomics and for various age groups. Under the
current proposal, the decision on whether to return will rest with
the HDAB alone. It is generally accepted that the return of results
should be in line with the preferences of the participants [27]. Yet,
under the current proposal, there is no role for the individual in
the decision making process on what and when to return. The
data user must share the results to the HDAB, and it is this body
that will decide on whether results shall be returned. This brings
the danger that differences in approach will arise between health
data access bodies and whether individuals obtain clinically
relevant information could depend on the relevant HDAB.
Second, for those health data access bodies who decide to
require the return of such data, this is a process that is fraught
with ethical complexities and is not as simple as just informing the
individual [26, 27, 57]. Numerous guidelines from research bodies
and consortia have attempted to ethically manage this process
and they generally centre on key principles that respects the
autonomy of the participant and their right to know or not to
know in a clear and transparent process. They may have
preferences on the type of ﬁndings to be returned, but there is
no place here for the individuals autonomous preference. It is
critical that the person returning the results has the necessary
training and skills to understand, communicate, and explain the
results and their impact. This is a process that should be included
in the ﬁnal EHDS, but it is critical that it is supported by ethical
best practice.
C. Staunton et al.
502
European Journal of Human Genetics (2024) 32:498 – 505

## Page 6 (Section: Recommendations on the way forward: enabling an ethical approach to the secondary use ofdata)

RECOMMENDATIONS ON THE WAY FORWARD: ENABLING AN
ETHICAL APPROACH TO THE SECONDARY USE OF DATA
We very much welcome the move towards furthering data sharing.
Data sharing for certain secondary purposes will likely have an
important role in protecting and promoting a healthy population.
However, it must be done in a manner that understands and actively
works to maintain the social licence and public trust in the
secondary use of data. This is particularly critical in the context of the
EHDS as the electronic health data that it is anticipated will be
shared come from areas traditionally vested in high levels of trust:
healthcare and scientiﬁc research. Any system that creates a legal
obligation to share data must be crafted in a way that does not risk
undermining trust. Loss of trust can have far-reaching implications
for medical care, deterring people from disclosing important
information. Loss of trust in scientiﬁc research risks impairing
willingness to participate in research, ultimately negatively affect
scientiﬁc research, and risks upending one of the stated purposes of
the EHDS. Currently there is insufﬁcient regard to individual rights
and interests, beyond some data protection considerations, but the
proposals do not also consider the risks beyond the individual. It
must be remembered that while data sharing may be beneﬁcial and
bring about public beneﬁt in the form of therapies or new
treatments, data can also be used to stigmatize and discriminate
[19]. Furthermore, simply because a beneﬁt is available it does not
follow necessarily that there is a fair distribution of beneﬁts resulting
from access to data. Data sharing during the COVID pandemic did
indeed lead to the quick development of vaccines, but the reality is
that once the vaccines were developed economic interests and not
need or public beneﬁt determined access [58–61].
We argue that the framework on the secondary use of data
proposed under the EHDS is contingent on an ethically sound
approach that protects the rights of participants and has oversight
mechanisms in place to mitigate against data harms beyond data
protection. Such an approach would ensure that public trust is
maintained. To achieve this, there is ﬁrst the need to shift the power
asymmetry. Under the initial proposal, the power asymmetry
between the data subject and those deciding on their data access
has widened to the point that the individual has no power. There is
scope to change this by incorporating some of the Parliament’s draft
recommendations. Processes and ultimately technical infrastructure
are needed to support the Parliament’s draft proposals and the
solution may be found in Chapter III. Chapter III is seeking to build a
system of interoperable electronic health records system. This will be
transformative and enable individuals to exercise more control over
their health data, but it currently applies to primary use (i.e.,
healthcare) only. There is a real opportunity now to incorporate the
secondary use of data as part of this system and develop an
interactive and dynamic infrastructure. Such a system can enable
individuals to express their consenting preferences, change them,
and withdraw. It can also ensure transparency and enable
individuals to be informed, thus preserving their right to information
and ability to exercise their other rights.
Second, Article 36(3) and Article 37(2)(c) provides that health
data access bodies should cooperate with stakeholders that
includes patient organizations, researchers, and ethics committees
in the exercise of their tasks, but the level of cooperation or
engagement is unclear. We argue that this should be a
requirement to involve patient representatives and ethics experts
in the composition of health data access bodies. This can ensure
that there is ethical oversight and reﬂection as part of the process
and would also be a more participatory form of governance.
Health data access bodies should also have the power to mandate
when they consider it necessary to seek REC approval as part of a
data access request process.
Third, a revised draft needs to account for the additional ELSI
concerns that go beyond data protection and re-identiﬁability in
the secondary use of data and consider how these concerns can
be addressed in the secondary use of data. Importantly the right
to autonomy, guarding against discrimination and stigmatization
for the individual as well as the risks to others in the use of data.
Equally if it is introducing a proposal on the return of results, this
should be developed in line with emerging ethical consensus on
how these results should be returned.
Finally, the reality of the proposals needs to be fully understood.
One legal framework for the secondary use of electronic health
data will bring some clarity, but differences in ethical rules remain
at a Member State level. Currently it is unclear what will occur
when the proposals under the EHDS and national ethical rules are
in conﬂict. Guidance on how to navigate these issues will be
needed, otherwise confusion could result in a deadlock in
accessing data, and the EHDS may not be operationalizable.
Changes to resolve these issues are needed to make the dream of
the EHDS a reality. In its revision we call for a legal framework that
enables access to data for secondary use in a manner that balances
the rights and interests of all stakeholders. An appropriate consent
process is only one element in this governance framework, but it is a
process that must be maintained.
REFERENCES
1. Hallinan D. Broad consent under the GDPR: an optimistic perspective on a bright
future. Life Sci Soc Policy. 2020;16:1.
2. Shabani M, Marelli L. Re-identiﬁability of genomic data and the GDPR: assessing
the re-identiﬁability of genomic data in light of the EU general data protection
regulation. EMBO Rep. 2019;20:e48316.
3. Chawinga WD, Zinn S. Global perspectives of research data sharing: a systematic
literature review. Libr Inf Sci Res. 2019;41:109–22.
4. Peloquin D, DiMaio M, Bierer B, Barnes M. Disruptive and avoidable: GDPR
challenges to secondary research uses of data. Eur J Hum Genet. 2020; http://
www.nature.com/articles/s41431-020-0596-x.
5. Staunton C, Slokenberga S, Mascalzoni D. The GDPR and the research exemption:
considerations on the necessary safeguards for research biobanks. Eur J Hum
Genet. 2019;27:1159–67.
6. Slokenberga S, Tzortzatou O, Reichel J. GDPR and biobanking - individual rights,
public interest and research regulation across Europe [Internet]. Springer. 2020.
https://www.springer.com/gp/book/9783030493875.
7. A European Strategy for data | Shaping Europe’s digital future. 2023. Available
from: https://digital-strategy.ec.europa.eu/en/policies/strategy-data.
8. Carter P, Laurie GT, Dixon-Woods M. The social licence for research: why care.
Data ran into trouble. J Med Ethics. 2015;41:404–9.
9. Muller SHA, Kalkman S, van Thiel GJMW, Mostert M, van Delden JJM. The social
licence for data-intensive health research: towards co-creation, public value and
trust. BMC Med Ethics. 2021;22:110.
10. Budin-Ljøsne I, Teare HJA, Kaye J, Beck S, Bentzen HB, Caenazzo L, et al. Dynamic
consent: a potential solution to some of the challenges of modern biomedical
research. BMC Med Ethics. 2017;18:4.
11. Mascalzoni D, Melotti R, Pattaro C, Pramstaller PP, Gögele M, De Grandi A, et al.
Ten years of dynamic consent in the CHRIS study: informed consent as a dynamic
process. Eur J Hum Genet. 2022;30:1391–7.
12. Ballantyne A. Adjusting the focus: a public health ethics approach to data
research. Bioethics. 2019;33:357–66.
13. Cheah PY, Piasecki J. Data access committees. BMC Med Ethics. 2020;21:12.
14. Staunton C, Tindana P, Hendricks M, Moodley K. Rules of engagement: per-
spectives on stakeholder engagement for genomic biobanking research in South
Africa. BMC Med Ethics. 2018;19:13.
15. Emanuel EJ, Wendler D, Grady C. What makes clinical research ethical? JAMA.
2000;283:2701–11.
16. Shuster E. Fifty years later: the signiﬁcance of the Nuremberg code. N Engl J Med.
1997;337:1436–40.
17. HHS.gov. The Belmont Report. 2010. Available from: https://www.hhs.gov/ohrp/
regulations-and-policy/belmont-report/index.html.
18. WMA - The World Medical Association-Declaration of Helsinki. 2023. Available
from: https://www.wma.net/what-we-do/medical-ethics/declaration-of-helsinki/.
19. Forzano F, Genuardi M, Moreau Y, European Society of Human Genetics. ESHG
warns against misuses of genetic tests and biobanks for discrimination purposes.
Eur J Hum Genet EJHG. 2021;8984-896.
20. Prainsack B, El-Sayed S, Forgó N, Szoszkiewicz Ł, Baumer P. Data solidarity: a
blueprint for governing health futures. Lancet Digit Health. 2022;4:e773–4.
21. Sheehan M. Can broad consent be informed consent? Public Health Ethics.
2011;4:226–35.
C. Staunton et al.
503
European Journal of Human Genetics (2024) 32:498 – 505

## Page 7 (Section: Author contributions)

22. Wendler D. Broad versus blanket consent for research with human biological
samples. Hastings Cent Rep. 2013;43:3–4.
23. Biasiotto R, Pramstaller PP, Mascalzoni D. The dynamic consent of the Coopera-
tive Health Research in South Tyrol (CHRIS) study: broad aim within speciﬁc
oversight and communication. BioLaw J. 2021;21:277–87.
24. Johnson SB, Slade I, Giubilini A, Graham M. Rethinking the ethical principles of
genomic medicine services. Eur J Hum Genet. 2020;28:147–54.
25. Caulﬁeld T, McGuire AL, Cho M, Buchanan JA, Burgess MM, Danilczyk U, et al.
Research ethics recommendations for whole-genome research: consensus
statement. PLoS Biol. 2008;6:e73.
26. Fiallos K, Applegate C, Mathews DJ, Bollinger J, Bergner AL, James CA. Choices for
return of primary and secondary genomic research results of 790 members of
families with Mendelian disease. Eur J Hum Genet EJHG. 2017;25:530–7.
27. Staunton C, Kösters M, Pramstaller PP, Mascalzoni D. Return of research results
(RoRR) to the healthy CHRIS cohort: designing a policy with the participants. J
Community Genet. 2021;12:577–92.
28. Tindana P, de Vries J. Broad consent for genomic research and biobanking:
perspectives from low- and middle-income countries. Annu Rev Genomics Hum
Genet. 2016;17:375–93.
29. Kaye J, Whitley EA, Lund D, Morrison M, Teare H, Melham K. Dynamic consent: a
patient interface for twenty-ﬁrst century research networks. Eur J Hum Genet.
2015;23:141–6.
30. Nembaware V, Johnston K, Diallo AA, Kotze MJ, Matimba A, Moodley K, et al. A
framework for tiered informed consent for health genomic research in Africa. Nat
Genet. 2019;51:1566–71.
31. Shabani M, Borry P. “You want the right amount of oversight”: interviews with
data access committee members and experts on genomic data access. Genet
Med. 2016;18:892–7.
32. Shabani M, Knoppers BM, Borry P. From the principles of genomic data sharing to
the practices of data access committees. EMBO Mol Med. 2015;7:507–9.
33. WMA - The World Medical Association-WMA Declaration of Taipei on Ethical
Considerations regarding Health Databases and Biobanks. 2023. Available from:
https://www.wma.net/policies-post/wma-declaration-of-taipei-on-ethical-
considerations-regarding-health-databases-and-biobanks/.
34. Staunton C individual rights in biobank research under the GDPR. In: Slokenberga
S, Tzortzatou O, Reichel J, editors. GDPR and biobanking: individual rights, public
interest and research regulation across Europe. Cham: Springer International
Publishing. 2022. 91–104. (Law, Governance and Technology Series). https://
doi.org/10.1007/978-3-030-49388-2_6.
35. Middleton A, Milne R, Almarri MA, Anwer S, Atutornu J, Baranova EE, et al. Global
public perceptions of genomic data sharing: what shapes the willingness to
donate DNA and health data? Am J Hum Genet. 2020;107:743–52.
36. Staunton C, Slokenberga S, Parziale A, Mascalzoni D. Appropriate safeguards and
Article 89 of the GDPR: considerations for biobank, databank and genetic research.
Front Genet. 2022;13. https://www.frontiersin.org/article/10.3389/fgene.2022.719317.
37. Slokenberga S. Scientiﬁc research regime 2.0? Transformations of the research
regime and the protection of the data subject that the proposed EHDS regulation
promises to bring along. Technol Regul. 2022;2022:135–47.
38. EDPB-EDPS Joint Opinion on the Proposal for a Regulation on the European
Health Data Space | European Data Protection Supervisor. 2022. Available from:
https://edps.europa.eu/data-protection/our-work/publications/edps-edpb-joint-
opinions/european-health-data-space
39. Assessment of the EU Member States’ rules on health data in the light of GDPR.
2023. Available from: https://health.ec.europa.eu/publications/assessment-eu-
member-states-rules-health-data-light-gdpr_en.
40. Prainsack B, Buyx A. A solidarity-based approach to the governance of research
biobanks. Med Law Rev. 2013;21:71–91.
41. Prainsack B. The “We” in the “Me”: solidarity and health care in the era of per-
sonalized medicine. Sci Technol Hum Values. 2018;43:21–44.
42. Prainsack B, Buyx A. Solidarity in biomedicine and beyond. Cambridge: Cam-
bridge
University
Press.
2021.
Cambridge
Bioethics
and
Law.
https://
www.cambridge.org/core/books/solidarity-in-biomedicine-and-beyond/
067DC974D204F6EDE679816213433456.
43. Delacroix S, Lawrence ND. Bottom-up data trusts: disturbing the ‘one size ﬁts all’
approach to data governance. Int Data Priv Law. 2019;9:236–52.
44. Milne R, Sorbie A, Dixon-Woods M. What can data trusts for health research learn
from participatory governance in biobanks? J Med Ethics. 2022;48:323–8.
45. Paprica PA, Sutherland E, Smith A, Brudno M, Cartagena RG, Crichlow M, et al.
Essential requirements for establishing and operating data trusts: practical gui-
dance co-developed by representatives from ﬁfteen Canadian organizations and
initiatives. Int J Popul Data Sci. 2020;5:1353.
46. Cook-Deegan R, Ankeny RA, Maxson Jones K. Sharing data to build a medical
information commons: from Bermuda to the global alliance. Annu Rev Genomics
Hum Genet. 2017;18:389–415.
47. Deverka PA, Majumder MA, Villanueva AG, Anderson M, Bakker AC, Bardill J, et al.
Creating a data resource: what will it take to build a medical information com-
mons? Genome Med. 2017;9:84.
48. van Roessel I, Reumann M, Brand A. Potentials and challenges of the health data
cooperative model. Public Health Genomics. 2018;20:321–31.
49. Hawkins AK, O’Doherty K. Biobank governance: a lesson in trust. N Genet Soc.
2010;29:311–27.
50. Horn R, Kerasidou A. Sharing whilst caring: solidarity and public trust in a data-
driven healthcare system. BMC Med Ethics. 2020;21:110.
51. Tindana P, Molyneux S, Bull S, Parker M. ‘It is an entrustment’: broad consent for
genomic research and biobanks in Sub-Saharan Africa. Dev World Bioeth.
2019;19:9–17.
52. Giesbertz NAA, Bredenoord AL, van Delden JJM. A thick opt-out is often sufﬁ-
cient. Am J Bioeth. 2013;13:44–6.
53. Ballantyne A, Schaefer GO. Consent and the ethical duty to participate in health
data research. J Med Ethics. 2018;44:392–6.
54. Trinidad SB, Fullerton SM, Bares JM, Jarvik GP, Larson EB, Burke W. Genomic
research and wide data sharing: views of prospective participants. Genet Med.
2010;12:486–95.
55. Kalkman S, van Delden J, Banerjee A, Tyl B, Mostert M, van Thiel G. Patients’ and
public views and attitudes towards the sharing of health data for research: a
narrative review of the empirical evidence. J Med Ethics. 2022;48:3–13.
56. Teare HJA, Prictor M, Kaye J. Reﬂections on dynamic consent in biomedical
research: the story so far. Eur J Hum Genet. 2021;29:649–56.
57. Knoppers BM, Zawati MH, Sénécal K. Return of genetic testing results in the era of
whole-genome sequencing. Nat Rev Genet. 2015;16:553–9.
58. Staff TPFC. Bill of Health. Taking data sharing seriously: public interest and solidarity
as principles for an international pandemic treaty. 2021. Available from: https://
blog.petrieﬂom.law.harvard.edu/2021/12/20/taking-data-sharing-seriously-public-
interest-and-solidarity-as-principles-for-an-international-pandemic-treaty/.
59. McMahon A. Patents, access to health and COVID-19 – The role of compulsory
and government-use licensing in Ireland. North Irel Leg Q. 2020;71:331–58.
60. McMahon A. Global equitable access to vaccines, medicines and diagnostics for
COVID-19: the role of patents as private governance. J Med Ethics. 2021;47:142–8.
61. Zohny H. Journal of Medical Ethics blog. Solidarity, trust and the governance of
data sharing during a public health emergency. 2021. Available from: https://
blogs.bmj.com/medical-ethics/2021/05/12/solidarity-trust-and-the-governance-
of-data-sharing-during-a-public-health-emergency/.
AUTHOR CONTRIBUTIONS
CS, DM, SS conceptualized the paper. CS, SS developed the texts in the paper. SS, MS,
DM provided comments and edits on all drafts of the paper. All authors approved the
ﬁnal paper.
FUNDING
CS & DM are funded by the Innovative Medicines Initiative (IMI) – FACILITATE project,
grant agreement No 101034366. Work on this article was supported by the U.S.
National Institute of Mental Health and the U.S. National Institutes of Health (award
number U01MH127690) under the Harnessing Data Science for Health Discovery and
Innovation in Africa (DS-I Africa) program. The content of this article is solely the
author’s responsibility and does not necessarily represent the ofﬁcial views of the U.S.
National Institute of Mental Health or the U.S. National Institutes of Health. SS is
funded by the Marianne and Marcus Wallenberg Foundation, project “AI and
Automated Systems and the Right to Health – Revisiting Law Accounting for the
Exploitation of Users Preferences and Values”. The authors thank the Department of
Innovation, Research and University of the Autonomous Province of Bozen/Bolzano
for covering the Open Access publication costs.
COMPETING INTERESTS
The authors declare no competing interests.
ADDITIONAL INFORMATION
Correspondence and requests for materials should be addressed to Ciara Staunton.
Reprints and permission information is available at http://www.nature.com/
reprints
Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims
in published maps and institutional afﬁliations.
C. Staunton et al.
504
European Journal of Human Genetics (2024) 32:498 – 505

## Page 8 (Section: Author contributions)

Open Access This article is licensed under a Creative Commons
Attribution 4.0 International License, which permits use, sharing,
adaptation, distribution and reproduction in any medium or format, as long as you give
appropriate credit to the original author(s) and the source, provide a link to the Creative
Commons licence, and indicate if changes were made. The images or other third party
material in this article are included in the article’s Creative Commons licence, unless
indicated otherwise in a credit line to the material. If material is not included in the
article’s Creative Commons licence and your intended use is not permitted by statutory
regulation or exceeds the permitted use, you will need to obtain permission directly
from
the
copyright
holder.
To
view
a
copy
of
this
licence,
visit
http://
creativecommons.org/licenses/by/4.0/.
© The Author(s) 2024
C. Staunton et al.
505
European Journal of Human Genetics (2024) 32:498 – 505


---

# Evaluating and Enhancing Large Language Models' Performance in Domain-Specific Medicine: Development and Usability Study With DocOA

- **Authors:** Xi Chen, Li Wang, MingKe You, WeiZhi Liu, Yu Fu, Jie Xu, Shaoting Zhang, Gang Chen, Kang Li, Jian Li
- **Issuer:** Journal of medical Internet research
- **Type:** Scientific article
- **Published:** 2024-07-22
- **Language:** en
- **DOI:** 10.2196/58158
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38833165/
- **Licence:** CC-BY

## Section: Abstract

BackgroundThe efficacy of large language models (LLMs) in domain-specific medicine, particularly for managing complex diseases such as osteoarthritis (OA), remains largely unexplored.ObjectiveThis study focused on evaluating and enhancing the clinical capabilities and explainability of LLMs in specific domains, using OA management as a case study.MethodsA domain-specific benchmark framework was developed to evaluate LLMs across a spectrum from domain-specific knowledge to clinical applications in real-world clinical scenarios. DocOA, a specialized LLM designed for OA management integrating retrieval-augmented generation and instructional prompts, was developed. It can identify the clinical evidence upon which its answers are based through retrieval-augmented generation, thereby demonstrating the explainability of those answers. The study compared the performance of GPT-3.5, GPT-4, and a specialized assistant, DocOA, using objective and human evaluations.ResultsResults showed that general LLMs such as GPT-3.5 and GPT-4 were less effective in the specialized domain of OA management, particularly in providing personalized treatment recommendations. However, DocOA showed significant improvements.ConclusionsThis study introduces a novel benchmark framework that assesses the domain-specific abilities of LLMs in multiple aspects, highlights the limitations of generalized LLMs in clinical contexts, and demonstrates the potential of tailored approaches for developing domain-specific medical LLMs.

## Section: Introduction

The rapid development of large language models (LLMs) has shown promising potential in the medical field, as demonstrated by their ability to pass the United States Medical Licensing Examination and diagnose clinical conditions [1-3]. The promising performance of LLMs in the general medical field warrants further research and exploration of their clinical performance in domain-specific medical scenarios [4,5].

Osteoarthritis (OA) is one of the most prevalent and debilitating diseases that causes pain, disability, and loss of function [6]. The global prevalence of OA is approximately 7.6% (595 million people) as of 2020 [7]. The management of OA requires complex strategies that encompass a variety of pharmacological treatments, lifestyle alterations, rehabilitation, and surgical interventions across multiple disciplines. Effective management of this condition necessitates the integration of extensive evidence-based medical data and the consideration of individual circumstances [6].

Although some LLMs have achieved commendable results in general medical question-answer (QA) tasks, substantial limitations persist in their clinical capability, particularly in complex and multifaceted diseases such as OA [8]. However, the data sets used to train LLMs are predominantly composed of general medical knowledge and lack in-depth, domain-specific content. Existing research indicates that current training data and benchmarking methodologies may be inadequate for LLMs to acquire the necessary domain-specific knowledge and clinical capabilities [4].

Additionally, LLMs may lack the ability to translate their knowledge into clinical proficiency. Despite possessing sound knowledge about certain diseases, effectively applying this knowledge to disease diagnosis remains challenging for LLMs [9]. This observation highlights the need to train and evaluate LLMs using data sets that are more closely aligned with clinical applications, thereby bridging the gap between theoretical knowledge and practical clinical usage.

To address these challenges, we proposed to build a data set that focuses on specific medical diseases, which should encompass updated evidence-based medical knowledge capable of providing both physicians and patients with expert disease-related information. In addition, real-world cases featuring patient information and treatment decisions encountered in clinical practice should be included. This repository can serve as a benchmark for testing the performance of LLMs in specific medical domains, such as OA management.

Moreover, despite the fact that LLMs have demonstrated impressive capabilities, their internal mechanisms remain unclear. This lack of transparency poses unnecessary risks to downstream applications [10], which is particularly crucial in the medical field and constitutes a significant ethical consideration [11]. Retrieval-augmented generation (RAG) offers a solution for explainability, as the RAG technique enables large models to identify the source of their answers when responding to questions. RAG is an AI framework that improves LLMs by integrating relevant information from external knowledge bases, thus enhancing the accuracy and reliability of the model's responses while also providing efficient and cost-effective access to updated external data [12]. Therefore, the integration of RAG and prompt engineering could enable the model to assimilate external knowledge bases and adhere to instructions to respond in a predetermined manner.

In general, we propose a data set framework that encompasses updated evidence-based medical knowledge, and real-world cases may effectively examine the capabilities of LLMs in clinical practice. The integration of RAG and prompt engineering may allow trained LLMs such as GPT-4 to acquire domain-specific abilities. Moreover, the management of OA serves as an ideal example in terms of its clinical significance and data volume on this research topic. Therefore, this study aimed to curate a data set for OA management, evaluate knowledge of updated evidence-based medicine for LLMs and their capabilities in clinical scenarios, and adopt RAG and instruction prompts to enhance these capabilities.

## Section: Methods

Study flow diagram. GIQA: guideline-item question-answer; MOQA: management options question-answer; QA: question-answer; real-case QA; TSQA: treatment strategy QA.

Workflow.

## Section: Methods › Overview

This study curated an OA management data set based on clinical guidelines and real-world cases. A benchmark was developed to evaluate the clinical knowledge and capabilities of LLMs for OA management. DocOA was built with instruction prompts and RAG and was tested along with other LLMs. Figure 1 illustrates the flow diagram of the study.

Study flow diagram. GIQA: guideline-item question-answer; MOQA: management options question-answer; QA: question-answer; real-case QA; TSQA: treatment strategy QA.

## Section: Methods › Data Set

This data set was developed based on key clinical guidelines and real-world patients. After the panel discussion, 6 well-acknowledged guidelines and data from 80 real-world patients were selected that included various aspects of OA management. The following guidelines were included: American Academy of Orthopedic Surgeons management of OA of the knee (Nonarthroplasty) [13]; NICE (National Institute for Health and Care Excellence) guideline for OA in over 16s [14]; Osteoarthritis Research Society International (OARSI) guidelines for the nonsurgical management of knee, hip, and polyarticular OA [15]; Royal Australian College of General Practitioners Guideline for the management of knee and hip OA [16]; American College of Rheumatology/Arthritis Foundation (ACR) Guideline for the Management of Osteoarthritis of the Hand, Hip, and Knee [17]; European League Against Rheumatism (EULAR) recommendations for the nonpharmacological core management of hip and knee OA [18]. Between April 1, 2023, and October 1, 2023, a total of 80 patients diagnosed with OA and who had received OA management at our hospital were randomly selected. The patient information, including age, sex, height, weight, BMI, laterality of knee involvement, medical history, level of pain, mechanical symptoms, physical examination results, and radiographic findings, was retrieved. All identifiable information was concealed to maintain confidentiality.

The OA benchmark aims to test the clinical capabilities of LLMs at 4 levels within the context of evidence-based medicine, ranging from domain-specific knowledge to clinical capabilities. The benchmark assesses the performance of LLMs pertaining to OA knowledge, summarizing the knowledge to formulate recommendations for specific management options, providing tailored management options for different patient populations, and formulating personalized management plans for real-world cases.

## Section: Methods › Assistant With RAG and Instruction Prompting

DocOA, a specialized assistant, was developed based on the GPT-4-1106-preview model, which integrates instruction prompts and RAG to enhance performance. The instruction prompt emphasized its role in providing evidence-based medical insights and personalized management programs guided by evidence-based medicine. The DocOA strictly adheres to facts, avoids speculation, and clearly states its limitations. Moreover, it maintains a professional and informative tone suitable for medical discussions.

RAG has been used to respond to various OA-related queries. The RAG integrates a model's language generation capabilities with a retrieval system, enabling access to specific information from external sources [19]. Of the several RAG techniques and data structures tested, the retrieval function from OpenAI was adopted, and the most optimal data structure was selected and converted into the JSON format for optimal retrieval accuracy. In response to OA-related queries, the RAG enables the assistant to dynamically pull relevant data from the external data set as it generates responses. The workflow of the assistant is illustrated in Figure 2.

The assistant block details the core of the DocOA system, using a base model of GPT-4-1106-preview. The description within the block serves as an instruction prompt that outlines the system's role. The assistant’s functionality includes a retrieval tool that accesses external data set.

The system receives input from thread blocks in the form of questions about OA management and requests evaluation. This includes user messages with specific queries regarding OA treatment and detailed instructions for the system to follow.

The execution command then triggers the processing of input data through the DocOA system. Through RAG, DocOA incorporates external information from the knowledge database and follows the instructions to generate the final output. Simultaneously, based on instructional prompts, DocOA is capable of providing final outputs tailored to the user, whether they are patients or professional doctors, in the corresponding style.

Workflow.

## Section: Methods › Models Testing

DocOA and the 2 base models, GPT-3.5 and GPT-4, were tested against the OA benchmark. Each question was presented 5 times to each model to assess the robustness of its performance. Additionally, the zero-shot chain of thoughts prompt technique was tested for GPT-3.5 and GPT-4 to determine whether it outperformed the input-output technique.

Evaluation of LLMs’ Performance

## Section: Methods › Objective Evaluation

The model-generated responses were compared with predefined correct answers for each subset of the benchmark. An answer was considered accurate if LLM provided correct knowledge (recommendation status and recommendation strength) about the treatment option and predicted the correct treatment recommendation (treatment appropriateness) for a specific patient profile or individual patient.

The human evaluation framework is an effective approach for identifying the gap between LLMs and clinical experts [3]. In this study, human evaluation was performed by both physicians and patients. A total of 80 items from the OA benchmark were randomly selected for a detailed human evaluation framework.

A panel of 5 experienced physicians evaluated the outputs from LLMs. The sequence of answers was randomized and the generating models were anonymized to ensure that the evaluation was conducted without any knowledge of the model that generated them. Specifically, each evaluator independently assessed the sampled responses. All sampled responses were compiled into an Excel (Microsoft Corp) spreadsheet. The model labels corresponding to the responses were concealed. The evaluation metrics were established based on a previous study with modifications [3]. The physician assessed the quality of the responses in the following domains: inaccurate content, relevance, hallucinations, missing content, likelihood of possible harm, extent of possible harm, and possibility of bias. The ability of LLM to achieve correct comprehension, retrieval, and reasoning was assessed using the method described in a previous study [20]. Patient evaluation was conducted by assessing the user intent fulfillment and helpfulness of the content. The detailed descriptions of each human evaluation metric are provided in Multimedia Appendix 1.

## Section: Methods › Statistical Analysis

All statistical analyses were performed using the SPSS 25.0 software (IBM Corp) and GraphPad Prism (version 8; GraphPad Software). Discontinuous data are expressed as incidence and rate and analyzed using the chi-square test for differences. A P value less than .05 indicated statistical significance.

## Section: Methods › Ethical Considerations

Real-case QA (RCQA) includes treatment recommendations for 80 real cases. The study have obtained approval from the Medical Ethics Committee of Sichuan University (approval number: 2023; review number 2277). Participants were informed that the study would need to use relevant data including clinical symptoms, imaging reports and physical examination data, but they would not receive any intervention measures and their personal identifiable information was anonymized. This study does not involve compensation.

## Section: Results

Results of objective evaluation. (A) Accuracy of each model against each subset of benchmark. (B) Inaccuracy analysis for DocOA due to wrong answer and failure to access external data. GIQA: guideline item question-answer (QA); MOQA: management option QA; TSQA: treatment strategy QA; RCQA: real-case QA.

Accuracy of each model against the osteoarthritis benchmark.

Accuracy of different prompt techniques against the osteoarthritis benchmark.

Results of human evaluation for LLMs’ comprehension, retrieval, and reasoning ability. (A) Evidence of correct comprehension. (B) Evidence of correct retrieval. (C) Evidence of correct reasoning.

Results of human evaluation by patients. (A) Patient intent fulfillment. (B) Patient helpfulness.

## Section: Results › OA Benchmark

The benchmark comprised 4 subsets of QA evaluations designed to test the performance of LLMs across a spectrum ranging from domain-specific knowledge to practical capability. Guideline-item QA (GIQA), which was developed based on specific items extracted from the clinical guidelines, evaluates the LLMs’ knowledge of these well-established standards. The GIQA comprised 337 items. Management options QA (MOQA) included summarized recommendations for specific treatments from the included clinical guidelines. The MOQA, which comprised 145 items, evaluated LLMs’ knowledge of specific treatment options as well as their ability to summarize medical evidence. Treatment strategy QA (TSQA), which included treatment recommendations for different patient populations, provided treatment recommendations based on the patient’s age, clinical presentation, and other factors. The TSQA, which comprised 216 items, evaluated the capability of LLMs to derive treatment recommendations for specific patient types. RCQA included treatment recommendations for 80 real-world patients. The RCQA, which comprised 80 items, evaluated LLMs’ capability in formulating treatment recommendations in a more complicated scenario in which individual information is provided, mirroring real-world clinical decision-making. This data set is available on GitHub [21]. Examples of each QA type are shown in Multimedia Appendix 2.

## Section: Results › Objective Evaluation

The accuracy of GPT-3.5 in GIQA, MOQA, TSQA, and RCQA was 0.26, 0.22, 0.01, and 0.03, respectively. The accuracy of GPT-4 in GIQA, MOQA, TSQA, and RCQA was 0.38, 0.30, 0.07, and 0.01, respectively. The accuracy of DocOA in GIQA, MOQA, TSQA, and RCQA was 0.92, 0.87, 0.88, and 0.72, respectively. The accuracy of each model against the benchmark is presented in Table 1 and Figure 3A. As shown in Figure 3A, the degree of accuracy significantly decreased: GIQA˃MOQA˃TSQA˃RCQA. As shown in Figure 3B, DocOA reported 111 failures in accessing the external data set, which accounted for 12.4% of the inaccurate answers generated.

Zero-shot chain of thoughts prompt techniques were adopted for GPT-3.5 and GPT-4. Compared with the input-output prompt technique, no significant improvements in model performance were observed. The results are summarized in Table 2.

Results of objective evaluation. (A) Accuracy of each model against each subset of benchmark. (B) Inaccuracy analysis for DocOA due to wrong answer and failure to access external data. GIQA: guideline item question-answer (QA); MOQA: management option QA; TSQA: treatment strategy QA; RCQA: real-case QA.

Accuracy of each model against the osteoarthritis benchmark.

Accuracy of different prompt techniques against the osteoarthritis benchmark.

## Section: Results › Human Evaluation Results

From each of the GIQA, MOQA, TSQA, and RCQA, 20 items were randomly selected along with the corresponding responses generated by each model. A total of 1200 outputs were evaluated by physicians and patients. The results of the human evaluations of GPT-3.5, GPT-4, and DocOA revealed distinct outcomes across several aspects. A few examples have been selected and summarized in Multimedia Appendix 3, demonstrating how to apply the human evaluation framework to assess sampled responses.

Multimedia Appendix 4 shows the human evaluation results for the models’ output. The rate of inaccuracy was the highest for GPT-3.5 (57%, n=1200), followed by GPT-4 and DocOA at 50% (n=1200) and 19.3% (n=1200), respectively. All the models achieved high relevance and infrequently produced hallucinatory content in their responses. GPT-3.5 had a higher proportion of responses with missing content (22%, n=1200) than GPT-4 (16.4%, n=1200) or DocOA (16.5%, n=1200). GPT-3.5 presented a higher likelihood of generating harmful content (20%, n=1200) than GPT-4 (11.3%, n=1200) and DocOA (8.3%, n=1200). Moreover, GPT-3.5 was associated with a higher risk of causing severe harm (10.5%, n=1200) than GPT-4 (5.5%, n=1200) and DocOA (3.5%, n=1200). The likelihoods of potentially biased content were 13.3% (n=1200), 9.5% (n=1200), and 2.8% (n=1200) for GPT-3.5, GPT-4, and DocOA, respectively. The results of the human evaluation for each subset benchmark are listed in Multimedia Appendices 5-7. The results showed a substantial decrease in performance in terms of inaccurate content and missing content (GIQA˃MOQA˃TSQA˃RCQA).

Figure 4 shows the results of the LLMs’ ability to assess correct comprehension, correct retrieval, and correct reasoning. Regarding the correct comprehension of the question, the response rate of DocOA was 91% (n=1200), followed by GPT-4 (86%, n=1200) and GPT-3.5 (82.5%, n=1200). DocOA was able to correctly recall and present complete, relevant information in 65.8% (n=1200) of the responses, followed by GPT-4 (14.3%, n=1200) and GPT-3.5 (12.0%, n=1200). In terms of subset evaluation, the results showed comparable performance in comprehension and reasoning among the different models, whereas a substantial performance decrease was found in correct retrieval across GIQA, MOQA, TSQA, and RCQA.

The results of patient evaluations are shown in Figure 5. DocOA achieved a success rate of 71.3% in fulfilling patient intention, with GPT-4 at 39.8% (n=1200) and GPT-3.5 at 36.5% (n=1200). Of the responses generated by DocOA, 75.8% (n=1200) were considered to be at least somewhat helpful, compared to 47% (n=1200) for GPT-3.5 and 47.75% (n=1200) for GPT-4. For GPT-3.5 and GPT-4, the subset evaluation showed a substantial decrease in intent fulfillment and helpfulness as the tasks shifted from domain-specific knowledge to personalized treatment recommendations.

Results of human evaluation for LLMs’ comprehension, retrieval, and reasoning ability. (A) Evidence of correct comprehension. (B) Evidence of correct retrieval. (C) Evidence of correct reasoning.

Results of human evaluation by patients. (A) Patient intent fulfillment. (B) Patient helpfulness.

## Section: Discussion

This study introduced a benchmark framework to assess the performance of LLMs in specific medical domains. Using OA as a case study, this framework is the first to evaluate LLMs across a spectrum, from domain-specific knowledge to clinical applications in specific disease management. The incorporation of human evaluation provides multiple dimensions of assessment that are of considerable interest to clinical practitioners and patients, making it an essential tool for evaluating the clinical capabilities of LLMs.

The study found that the integration of RAG and instructional prompts substantially improved the domain-specific capabilities and explainability of general-purpose LLMs without additional training. By contrast, general-purpose models such as GPT-3.5 and GPT-4 exhibit unsatisfactory performance when benchmarked against OA management. Additionally, both models demonstrated a marked decline in performance as tasks shifted from domain-specific knowledge to personalized treatment recommendations. Overall, the findings of this study demonstrate a cost-effective method for evaluating and enhancing the capabilities of LLMs in specialized medical fields.

Examples of clinical practice. (A) How DocOA provides exercise guidance for patients with OA. (B) How DocOA provides doctors with clinical evidence for exercise guidance in OA, as well as the clinical evidence the answer is based on.

## Section: Discussion › Domain-Specific Medical Benchmark

Although benchmarks targeting general medical knowledge have been previously developed [22-24], recent research has suggested that these benchmarks are only preliminary indicators of medical knowledge. The absence of tailored benchmarks in specific domains remains a potential challenge for evaluating the clinical effectiveness of LLMs [4,25]. Therefore, we developed a domain-specific benchmark focused on disease management for OA, which was selected for its prevalence, substantial disease burden, and complexity of its management strategies [6,7]. This benchmark was designed to test the domain-specific knowledge and clinical capabilities of LLMs. The benchmark comprised 4 parts, each testing the ability of LLMs at different levels, including the ability to provide evidence-based knowledge, summarizing knowledge to formulate recommendations, providing management recommendations for different patient populations, and formulating personalized management plans for real-world patients. The benchmark was constructed based on established clinical guidelines and real-world patient information. Clinical guidelines offer comprehensive reviews of updated evidence and expert opinions, making them reliable sources of domain-specific medical knowledge. Through panel discussions involving physicians and data scientists, the questions were designed in a hybrid format, integrating both definitive and interpretative elements. Using this benchmark, we confirmed that general-purpose LLMs exhibit suboptimal performance in specialized domains. A significant performance gap was observed between domain-specific knowledge and clinical proficiency. This highlights the challenges faced by general-purpose LLMs in effectively applying specialized knowledge to clinical scenarios.

## Section: Discussion › Human Evaluation Framework

Human evaluation is a crucial component in assessing the medical capabilities of LLMs and offers a multidimensional assessment of their clinical capabilities. In this study, the human evaluation framework was modified based on a previous study, and hallucinations and relevance were added as additional criteria [3,4]. The evaluation criteria included accuracy, relevance, hallucinations, omissions, potential harm, and biased content. Moreover, the performance of LLMs in question comprehension, information retrieval, and medical reasoning was evaluated, as these are crucial abilities in tailoring patient-specific treatment. Patient evaluations primarily determine how responses address the user’s intent and helpfulness. Although previous studies indicate a notable gap between objective benchmarking and human evaluation, our findings reveal a smaller discrepancy [3]. This could be attributed to the different knowledge domains and designs of the QA structure in this benchmark. The results of our study suggest that the GPT-3.5, GPT-4, and DocOA performed well in terms of hallucinations, comprehension, reasoning, and relevance. DocOA outperformed the other models in terms of accurate information, correct retrieval, and helpfulness as perceived by patients. This indicates that although generalized models are proficient in some areas, they remain inadequate in delivering the qualified responses required in a clinical context.

## Section: Discussion › Augmenting LLM With Domain-Specific Ability

Several techniques are available for developing medical LLMs, which primarily include integrating domain-specific knowledge during the training phase through techniques such as reinforcement learning with human feedback [26-28]. However, in this study, we focused on enhancing already-trained LLMs, such as GPT-4, by using a suite of techniques, including RAG and instruction-based prompts. Similar methodologies have been applied to the development of specialized LLMs for chemical domains [29].

This approach was adopted for the following reasons: first, augmenting an existing model such as GPT-4 is more cost-effective than training a new model from scratch; second, advanced general-purpose models have been trained on diverse data sets, providing a broad base of general knowledge that can be beneficial for understanding and contextualizing domain-specific information; third, techniques such as RAG and specialized prompting offer the convenience of being adjustable and refined over time, enabling easy adaptability to new evidence in the fast-evolving field of medicine.

Among these reasons, the role of RAG in this study needs to be emphasized. Explainability has always been a problem to be addressed in the application of LLMs, and it is also one of the ethical considerations in their application in the medical field. RAG enables the model to identify the source on which the generated answer was based, which significantly improves the explainability of the model. In this study, the knowledge base was structured in a way that allows RAG to identify the clinical evidence that the answer was based on. When DocOA generates an OA-relevant answer, it identifies the evidence on which the answer is based and makes it clear for professionals to evaluate the rationale and accuracy of its response. In general, provided with reliable and professional sources, RAG significantly improved the explainability and accuracy of LLMs in medical care.

Our results demonstrated that GPT-4 can effectively acquire domain-specific knowledge and clinical capabilities in the management of OA through a combination of approaches, including RAG and instruction prompts. This strategy can also be applied cost-effectively to other medical domains.

Nonetheless, the efficacy of the RAG is contingent upon factors such as the size and quality of the data, retrieval techniques used, and the underlying architecture of the LLM in use [30]. The evaluation results showed that DocOA was able to correctly understand the clinical question and avoid hallucinations. The fundamental reason for the errors stems from the inherent limitations of the RAG technology, where the retrieved information may sometimes be incomplete or may not adequately address the question.

In RAG, the query process is the key determinant of the information retrieved from the external knowledge base. In the query process, text is converted into an array of floating points. The entire array corresponds to a point in an n-dimensional space, which is known as the text vector, also referred to as an embedding [31,32]. The distance between vectors, which corresponds to semantic similarity, can be calculated. Therefore, by calculating semantic similarity, the query process retrieves the information from the external knowledge base that is considered most relevant to the query posted by the LLM. However, this process is sometimes uncertain because the most appropriate answer does not necessarily yield the highest similarity score. For example, in GIQA, the question is, “Is Walking aids, assistive technology and adaptations at home and at work recommended for Physical Treatment of Knee osteoarthritis according to 2013 EULAR recommendations for the nonpharmacological core management of hip and knee osteoarthritis?” For this question, out of the 5 responses generated by LLM, 4 incorrectly state “recommend” when the correct answer should be “may be used.” The error occurred because only a portion of the information was retrieved. However, neither the complete information nor the key information, which contains the answer, was retrieved. More specifically, if the retrieved information was “The frequent use of assistive technology and the high satisfaction rates with its use indicate that walking aids, assistive technology, and adaptations are important and useful for people with hip or knee OA.” The model might be misled to generate the incorrect answer.

Generally, enhancing the effectiveness of RAG is an ongoing effort in the field of computer science, and the effectiveness of RAG is likely to keep increasing with the rapid development of LLMs and RAG technologies.

## Section: Discussion › The Potential Value of DocOA in Future Clinical Practice

DocOA has shown promising potential in clinical practice due to its proficient OA management knowledge and the ability to explain its answer. Previous studies have shown general-purpose LLMs to be limited in medical specialties such as nephrology, ophthalmology, and OA. The versatile and unverified training data could contain misleading medical information, which led to inaccurate answers. On the other hand, DocOA has shown good results in providing evidence-based OA management knowledge and formulating personalized treatment plans. To adopt DocOA in clinical practice, it is designed to answer patient queries and doctor queries differently, as shown in Figure 6. When generating answers for medical professionals, it is able to generate answers based on selected high-quality clinical evidence and accurately identify the corresponding references, thus providing explainable and evidence-based answers.

Examples of clinical practice. (A) How DocOA provides exercise guidance for patients with OA. (B) How DocOA provides doctors with clinical evidence for exercise guidance in OA, as well as the clinical evidence the answer is based on.

## Section: Discussion › Limitations

This study has several potential limitations that need to be addressed. First, OA management is highly complex, and our current data set remains limited and requires continuous supplementation and updating. Therefore, establishing specialized groups dedicated to building and updating these LLM databases is imperative for diverse medical applications. Second, our reliance on English sources could restrict the applicability and inclusivity of our findings across different linguistic and cultural contexts. Third, although there have been human evaluations of clinical case data, the augmented model has not yet been tested in a real-world clinical setting. These limitations highlight the necessity for ongoing development and a comprehensive, multidimensional approach for evaluating LLMs in the medical field.

## Section: Discussion › Conclusions

In this study, we introduce a novel benchmark framework designed to evaluate the capabilities of LLMs in specific medical domains, with OA serving as a case study. This framework assesses LLMs in terms of medical knowledge, evidence summarization, and clinical capabilities. Through a combination of objective measures and human evaluations, we identified the limitations of generalized LLMs in clinical contexts. Furthermore, our study demonstrated that DocOA, which integrates RAG and instructional prompts, significantly improves both the domain-specific performance and the explainability of LLMs. This approach is a potentially cost-effective strategy for developing domain-specific medical LLMs.


---

# Evaluating Molecular Complexity with Open-Source Machine Learning Approaches to Predict Process Mass Intensity

- **Authors:** Nicole Tin, Mandeep Chauhan, Kennedy Agwamba, Yibai Sun, Astrid Parsons, Philippa Payne, Remus Osan
- **Issuer:** ACS omega
- **Type:** Scientific article
- **Published:** 2024-06-24
- **Language:** en
- **DOI:** 10.1021/acsomega.4c02427
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38973894/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractThe application of green chemistry is critical for cultivating environmental responsibility and sustainable practices in pharmaceutical manufacturing. Process mass intensity (PMI) is a key metric that quantifies the resource efficiency of a manufacturing process, but determining what constitutes a successful PMI of a specific molecule is challenging. A recent approach correlated molecular features to a crowdsourced definition of molecular complexity to determine PMI targets. While recent machine learning tools show promise in predicting molecular complexity, a more extensive application could significantly optimize manufacturing processes. To this end, we refine and expand upon the SMART-PMI tool by Sheridan et al. to create an open-source model and application. Our solution emphasizes explainability and parsimony to facilitate a nuanced understanding of prediction and ensure informed decision-making. The resulting model uses four descriptors—the heteroatom count, stereocenter count, unique topological torsion, and connectivity index chi4n—to compute molecular complexity with a comparable 82.6% predictive accuracy and 0.349 RMSE. We develop a corresponding app that takes in structured data files (SDF) to rapidly quantify molecular complexity and provide a PMI target that can be used to drive process development activities. By integrating machine learning explainability and open-source accessibility, we provide flexible tools to advance the field of green chemistry and sustainable pharmaceutical manufacturing.

## Section: Introduction › Process Mass Intensity

Process mass intensity (PMI) is a key metric for measuring the efficiency of chemical processes, as benchmarked by the ACS Green Chemistry Institute Pharmaceutical Roundtable.1 As drug candidates advance throughout the drug development lifecycle, PMI calculations are often used to capture progress toward more sustainable manufacturing and to drive further development.

PMI for a given synthesis is calculated as

Forecasting what constitutes a “successful” PMI for the manufacturing process for a given molecule is an unresolved industry challenge. In the absence of a “target” PMI, it is challenging for chemists to gauge if the resource efficiency of the process is on target, exceeding expectations, or in need of additional optimization. The comparison of the PMI of a process under development to an ambitious target PMI will help drive the incorporation of green chemistry and deliver sustainable manufacturing processes.

Despite not having a precise theoretical way to predict this feature, its estimates are extremely important in decision-making and process sustainability evaluation. Recently, it has been shown that a “target” PMI can be set for a given molecule through the molecular weight (mw) and the calculation of its estimated molecular complexity (c).2 This is given by

The two variables, overall PMI and molecular complexity, share a positive linear correlation, where it is generally known that complex molecules have worse resource efficiency. Thus, the complexity of an active pharmaceutical ingredient (API) has far-reaching implications in terms of the challenges and efficiency of its manufacturing.

## Section: Introduction › Molecular Complexity

Molecular complexity is commonly agreed to be an attribute intrinsic to a molecule that can affect chemical, material, and biological processes such as synthetic ease3−8 and sustainability.9,10 Generally the term refers to the intricacy and interactions in the internal structure of a molecule, however, the multidimensional nature of molecules represent a challenge to creating one summary metric of complexity.

Creating a definition of molecular complexity is a multidisciplinary problem, with applications and solutions coming from domains in math, physics, chemistry, and biology. While many solutions exist, none have been universally adopted.11 Molecules are naturally viewed as graphs; approaches in graph theory analyze topology to develop graph invariants, such as the Zagreb or Weiner Indices, that can determine the structural properties of molecules.12 Information theoretic measures, such as Shannon entropy, are also widely used in complexity science to capture diversity or degree of uniformity.13−16

In pharmaceutical chemistry, linear combinations of factors have been used as a proxy for complexity. Those factors usually include molecular weight and counts of attributes, such as stereocenters, rings, and functional groups.3,5,10,17 Increases in computational power and advances in AI/ML have enabled researchers to develop data-driven approaches that can model these complex intuitions. A pivotal method by Sheridan et al. proposed one such model based on crowdsourced votes on a diverse set of molecules.18 From the votes of 386 chemists, they found that the notion of complexity is independent of the chemistry subfield (i.e., process, analytical, medicinal, computational, etc.). A different approach focused on creating a model that is time dependent, asserting that complexity changes over time with respect to the available synthetic technology.19

There is a gap between the former theoretical and latter data-driven approaches to complexity. Theoretical models like those developed by Bertz, Bonchev, and Proudfoot use our inherent understanding of graphs or information theory to create explicit and transparent solutions.13−15,20 The need for similar transparency in data-driven models is increasingly being recognized, with suggested standards for AI/ML in pharmaceutical development emerging recently from the FDA.21 There is a need for data-driven algorithms to be secure, reliable, and interpretable; when used in decision-making, the model should be informative of the mechanisms that drive the nature of prediction.22−24 Most powerful methods in machine learning are not interpretable, still some are more interpretable than others. Posthoc “explainable” wrapper methods have been developed to approximate the learned mechanisms under the black box. Reducing the input dimension space can also dramatically increase understanding while also improving learning.

## Section: Introduction › Molecular Descriptors

Experimental and theoretical molecular descriptors have been used to capture information about a molecule related to its biological or physical properties.25,26 Representing a molecule as a vector of descriptors, rather than as a graph or raw fingerprint, allows for a clear interpretation of the weighing schemes of contributing factors.

Zero-dimensional (0D) descriptors are easily observed features of a molecule derived from the chemical formula. They include molecular weight or number of heteroatoms and ring types.

One-dimensional (1D) descriptors encode attributes or substructures into a binary or hashed vector, known as a fingerprint. Unlike human fingerprints, however, this representation is not unique and can instead represent several molecules.

Two-dimensional (2D) descriptors use the molecular graph (topology) as a representation or as an input to a computation that yields a value. Some 2D descriptors, like the Weiner Index, also align with experimental measures.27

Three-dimensional (3D) descriptors capture geometric or topographical information. One such descriptor is the polar surface area (PSA) that uses the 3D molecular conformation to evaluate the surface area of polar atoms.28,29 Since these are inherently sensitive to the conformation of the molecule, they are less common but are powerful measures containing higher information content.

Overall, using these descriptors to understand the factors that define molecular complexity can improve decision-making and understanding for goal-setting PMI.

## Section: Introduction › Open SMART-PMI

In this paper, we evaluate the SMART-PMI and compound complexity tools developed by Sherer and Sheridan and adapt them for wider community use in support of green chemistry and process development acceleration.9,18 The importance of making open-source tools to support computational green chemistry’s framework cannot be overstated, as it benefits the broader community by publicizing previous advancements, encourages embracing uniform standards in the pharmaceutical industry, and facilitates the development of cost-efficient and flexible solutions.

Here, we relate machine learning principles to the retro-application of molecular complexity and make this knowledge open source alongside the source code. While we are not the first to model molecular complexity, we have initiated open-source collaboration and added interpretability to build upon the foundations of this important model. We show that the most successful algorithms, namely, random forest models, can succinctly model molecular complexity and can provide clear explainability to the user. The resulting models have different levels of complexity, with the simplest one using only four descriptors.

## Section: Methods › Background

The code for SMART-PMI reported by Sheridan et al. is publicly available on their GitHub repository (https://github.com/Merck/compoundcomplexity/).9 The crowdsourced information for compound complexity published by Sherer et al. includes 1775 nonproprietary drug-like molecules in the Supporting Information.18 The votes on compound complexity from chemists range from 1 to 5, with 1 representing the simplest and 5 indicating a highly complex compound. The votes are summarized by the average score per molecule, denoted as mean complexity. The reported metrics for their random forest model had an 88% R2 and RMSE of 0.27, while the standard deviation of votes agreement was 0.75. A four-term linear model was also shown as a simpler alternative, though with an 80% CV-R2. As the random forest model is the focal point of both papers and has higher performance, we use it as the primary point of comparison. There were two primary complications in using this model. 186 of their 207 descriptors are sourced from the licensed Molecular Operating Environment (MOE) software, and the compound complexity package was written in several languages including Perl, which has waning influence in the field. The dataset and model were a pivotal step forward in understanding the makeup of molecular complexity.

## Section: Methods › Data Preparation

RDKit and Mordred are free and open-source cheminformatics libraries written in Python that enable easy calculation of many 0D–3D descriptors.30,31 Inputs require the simplified molecular-input line-entry (SMILES) ASCII string representation, which can be transformed from a molecule’s SDF file. RDKit and Mordred were used to generate a set of over 1500 initial descriptors. Throughout this work, the terms “descriptor” and “feature” are used synonymously.

Of the annotated 1775 molecules from Sheridan et al., 44 (2.5%) were unable to be sanitized by RDKit due to inconsistent valence electrons and were excluded from preprocessing and training. Of these molecules, 39/44 came from the MDL Drug Data Report (MDDR) database. This dataset was split into a 70:30 training and test set, and the model would be evaluated with 5-fold cross-validation. To reduce collinearity and improve model performance, features were pruned through several preprocessing steps. Mordred uses a specialized error object encoding; thus, any descriptor that comprised largely of the latter was removed. All of the above steps were performed on the entire dataset to capture the largest set of descriptors that would be unable to be performed on an incoming molecule. Then, to prevent leakage, where information from the hold-out dataset is used in training the model, the following preprocessing involving statistics of interest was only performed on the training set. The resulting statistics derived from the training set are later applied to transformations on the test set and future molecules. Each feature was scaled using min-max normalization. Normalization is a standard procedure for preparing ML inputs but is also crucial for comparing coefficients across models. Features with low information content (defined as variance) less than 10–5 were removed. Post-processing, the dataset consisted of 1196 descriptors.

## Section: Methods › Model Selection

Several architectures were tested to find the optimal algorithm for learning complexity (y) from a set of descriptors (X). In accordance with the original SMART-PMI paper, linear and ensemble methods were tested. Spatial methods and neural networks were additionally evaluated. Each model takes a different approach to learning the behavior of mean complexity, and each comes with trade-offs. While it is important to find a well-performing model, model simplicity is highly valued, as it is paramount to understanding the mechanisms driving prediction. A further discussion of the models and trade-offs can be found in the Supporting Information.

## Section: Methods › Feature Selection

To refine the model and reduce dimensionality, embedded and wrapper methods were used to select features. The methods used are complementary to each other and paint a picture of how features contribute to prediction. Toward the aim of understanding the modeling behavior and the contributing factors, we selected descriptors as chosen by high-performing models and their feature importance rankings.

Machine learning models typically optimize coefficients for each descriptor, which can be scrutinized to determine feature importance. Random forest measures a feature’s mean decrease in impurity (MDI), which is an implicit method the model uses to evaluate its importance. Permutation importance calculates the decrease in model performance when a feature is randomized and is helpful as it can be computed across models.

Another method, SHAP (Shapley additive explanations), is widely employed to add interpretability to a model.32,33 Features are analyzed as players within a game, where the features compete to influence prediction. SHAP is then able to allocate the contributions of each feature toward the predicted value for a particular instance. SHAP values can be aggregated across all instances to create average absolute scores for each feature. We can compare model coefficients and SHAP rankings to identify consensus important descriptors and eliminate features with little to no effect on modeled complexity.

## Section: Methods › Interaction Terms

Introducing interaction between terms is another way of modeling nonlinearity. Without interaction terms, independent variables could be interpreted as having a unique effect on the dependent variable, each with its own contribution. As we have a mix of physiochemical and topographical attributes, we would expect that the effect of one descriptor varies for different values of another descriptor. To maintain low computation times, we did not consider all possible interaction terms. Rather, we focus on product and quadratic terms that were generated for features filtered through selection.

## Section: Methods › Model Evaluation

It is expected that labeling molecules at the extreme ends of complexity would be the most difficult for the model, as the surveyed values of Sheridan et al.’s mean complexity follow a right-tailed normal distribution, and so there are the fewest ratings of 1, 4, 4.5, and 5 (Figure S1). Thus, negative root mean square error (denoted as −RMSE) was targeted as the primary metric when comparing models and methods, which gives sensitivity to large errors. We take the negative RMSE to standardize interpretation, where higher values indicate better fit, and the maximum theoretical value is 0. For comparing standard linear goodness-of-fit, the coefficient of determination R2 is used. However, R2 increases with the number of dimensions in the model, which is an important consideration in our modeling. Accordingly, adjusted R2 was additionally considered as it corrects for the number of dimensions in the model, where R2 increases accordingly. R2 is given by

where ŷ is the predicted value and adjusted R2 is

Fivefold cross-validation was further applied to each metric to generalize model performance.

## Section: Results

In summary, we focus on the evaluation of the three models: our replication of the benchmark model and feature set by Sheridan et al. (MK-207); the initial model using the full set of open-source descriptors (GS-1196); a parsimonious model using only four open-source descriptors (GS-04) (Figure 1). The model’s naming convention is described by the developer and the number of features used. Each of the three models is high performing, with an average squared prediction error that is lower than the chemists’ vote variability (0.75). Still, each model comes with unique advantages and trade-offs, and each informs our understanding in different ways. The initial model is used to rank the full set of features specifically by their contribution to the predicted y variable, mean complexity. To improve accuracy and simplicity, additional interaction terms are generated for those top features and are used in evaluating a suite of models. The final parsimonious model has comparable error to the high-performing baseline and uses only four molecular descriptors.

The benchmark random forest model shared by Sheridan et al. was replicated using attributes generated from Merck’s Compound Complexity repository and a temporary MOE software license. In a Python environment and hyperparameter tuning, we were only able to achieve cross-validated R2 scores around 84%, as opposed to the 88% reported. While differences could be attributed to the former factors, hyperparameters such as the optimization function for node splitting, in conjunction with cross-validation, should be sufficient for reproducing results. Under the given environment, the accuracy of the model appears very similar, accounting for random deviation.

Test set predictions vs true mean complexity for the random forest model trained on each of the three datasets. (a) Our replication of the benchmark model and feature set by Sheridan et al. (MK-207), (b) the initial model using the full set of open-source descriptors (GS-1196), and (c) a parsimonious model using only four open-source descriptors (GS-04). The underlying contour plot represents the kernel density estimate, where the darkness of the rings increases with the density of points.

Coverage of feature sets. (a) Bar chart of open-source features that have over 94% correlation coefficient with an original descriptor. Several original descriptors can be summarized by an open-source feature. (b) Histogram of the original descriptors from Sheridan et al. Each bar measures the maximum correlation of an original descriptor with any open-source descriptor. (c) Histogram measuring the maximum correlation coefficients of an open-source descriptor to any original descriptor. The new set of open-source descriptors represents a larger search space that is largely independent of the original set.

Ranking feature importance. (a) Mean decrease in impurity (MDI) across random forest trees. MDI is measured with the Gini index or the homogeneity of the resulting nodes and leaves created by a split at a specific feature. (b) Distribution of values contributing to SHAP feature importance values. The list is sorted by average absolute SHAP value, with the highest contributing feature at the top. The distribution of feature values is shown next to each, with colors showing the relationship between feature-instance value and the individual SHAP value.

Principal component analysis. (a) Full training dataset for the left figure and (b) top 15 features in the right figure. The first three axes explain (a) 47% and (b) 90% of the total variance, respectively.

Comparison of model error. (a) Cumulative density functions for absolute error of each model. 80% of predictions are under 0.35 for MK-207 and 0.42 for GS-04. (b) Corresponding probability densities for the error of each model. The area of each curve integrates to 1, and so the y-axis represents the probability density of the error rate.

Architecture diagram of the browser and command line applications.

## Section: Results › Feature Selection and Model Initialization

Once the new feature space was established and processed, we measured the correlation between descriptors in each of the previous and open-source spaces to evaluate similarities. Of the original 207 descriptors, 51 have a correlation coefficient of over 94% with a new open-source descriptor (Figure 2a). These include licensed descriptors deemed important in the work by Sheridan (Figure S2). Further, many of these highly correlated features map to the same open-source descriptors, where the 51 original descriptors can be represented by 20 open-source descriptors, as shown in Figure 2a. The larger set of open-source descriptors brings more variance and measurements, while also representing features important for the original model.

To select meaningful descriptors and initialize model tuning, we trained a random forest model tuned with grid search. For the training set of 1384 molecules and 1196 descriptors with 5-fold cross-validation, the R2 stabilizes around 78% with an −RMSE = −0.39. Random forest significantly outperformed other models, despite high dimensionality and limited feature selection, which served as a useful baseline. SHAP values were calculated for each instance-descriptor value and aggregated to summarize each descriptor’s average absolute score.

The SHAP summary plot illustrates a feature’s potential to raise or lower the predicted complexity (Figure 3a). The chiral and stereocenter counts, which are similar descriptors, have a similar influence on the model. Low values (or counts) of these measures influence a low prediction, whereas very high counts increase the predicted value. The summary plot is especially helpful in allocating (the estimated) predictive power to each contributing feature’s distribution. The most important descriptors calculated by random forests’ implicit MDI are shown in Figure 3b. Few features meaningfully contribute to predicted complexity, and the same features stand out from both metrics of importance, indicating that the optimal model for molecular complexity would be relatively consistent. While permutation importance shows a different ranking, the high dimension of the input dataset obscures significant decreases in accuracy (Figure S3).

While it is important to note that these methods are inherently model-dependent, the results were similar across several iterations of the model initialization phase, and SHAP shows a direct relationship of a descriptor to molecular complexity. The highest ranked 13 of 17 features are in agreement (spearman ρ = 0.65). Furthermore, all descriptors selected in this stage show a correlation of above 50% to mean complexity (Figure S4a). Very few other features have a clear significant impact on the model, indicating that a parsimonious model is reasonable. These contributors, a combination of physiochemical, topological, and graph descriptors, align with the historical approaches taken by both mathematicians and domain experts. Since descriptor effects may be magnified in their interaction with another feature, the highest 15 SHAP-ranked features are selected for further modeling.

To visualize the variance captured by the descriptors present in the dataset, we plot the first three principal components of the normalized training set and color each instance by its associated mean complexity. We use this plot to screen for linear and clustering modeling options and to determine the amount of noise contributed by extra features. Once the feature set is reduced to the top 15, we can see the selected features contain a large amount of variation associated with molecular complexity. The total explained variance improves from 47% (Figure 4a) to 90% (Figure 4b).

Coverage of feature sets. (a) Bar chart of open-source features that have over 94% correlation coefficient with an original descriptor. Several original descriptors can be summarized by an open-source feature. (b) Histogram of the original descriptors from Sheridan et al. Each bar measures the maximum correlation of an original descriptor with any open-source descriptor. (c) Histogram measuring the maximum correlation coefficients of an open-source descriptor to any original descriptor. The new set of open-source descriptors represents a larger search space that is largely independent of the original set.

Ranking feature importance. (a) Mean decrease in impurity (MDI) across random forest trees. MDI is measured with the Gini index or the homogeneity of the resulting nodes and leaves created by a split at a specific feature. (b) Distribution of values contributing to SHAP feature importance values. The list is sorted by average absolute SHAP value, with the highest contributing feature at the top. The distribution of feature values is shown next to each, with colors showing the relationship between feature-instance value and the individual SHAP value.

Principal component analysis. (a) Full training dataset for the left figure and (b) top 15 features in the right figure. The first three axes explain (a) 47% and (b) 90% of the total variance, respectively.

## Section: Results › Model Selection

In summary, for each dataset, we trained five algorithms, including partial least-squares, k-nearest neighbors, support vector machine, multilayer perceptron, and random forest. This was done for each of the three open-source datasets: the full descriptor set, the set of top descriptors, and interaction terms generated from the latter. Inputs were normalized before training for all models except for the random forest, where it is not necessary beyond comparing coefficients. The cross-validated performance metrics are listed in Table 1.

Reducing the descriptor set increased model performance across the board, though this is hardly surprising. The high R2 and the negative adjusted R2 in the models trained on the full feature set suggest that many predictors do not significantly contribute toward prediction. For the latter two training sets, the R2 and Adj-R2 are comparable, showing a reasonable ratio between the R2 and the number of predictors. Interaction terms from the top feature set, however, decreased model performance in PLS and SVM. This might suggest that the nonlinearities are of a different nature than the product and quadratic terms evaluated here. For the reduced feature sets, the neural network and k-NN matched the random forest algorithm’s performance. However, since random forest models possess more interpretability, explainability, and model robustness, we continue to use them as the model of choice.

## Section: Results › Parsimonious Model

Our work shows that a parsimonious ML model of complexity is possible. Using the four highest-ranked descriptors, two physiochemical 0D and two topological 2D descriptors, a random forest model can predict molecular complexity with MSE = −0.349 and R2 = 82.7% (Table 2). This model, GS-04, has a comparable error to the licensed MSD-207 model and improves significantly on GS-1196 while reducing the number of descriptors (Figure 5a). However, MK-207 still has a lower incidence of errors larger than ±1 as compared to the GS models (Figure 5b). The physiochemical descriptors included the number of stereocenters and the number of heteroatoms (nonhydrogen or noncarbon atoms). Unique topological torsion was the foremost ranked feature in every model and seed used. Topological torsion was developed by Nilakantan et al., to be a short-range descriptor, capturing information about the number of substructures containing unique atomic types, nonhydrogen branches, and pi electron pairs.34 The unique topological torsion then refers to the number of unique fragments within a molecule. The last descriptor, chi4n, is a structural descriptor derived from a set of connectivity indexes developed by Hall and Kier.35 The several Chi Index variants capture increasing information about the connectivity of bonds or atoms. While chi4n was used here, other chi indices were also effective. Cross-validated performance using other chi indices in its place differed by a few decimal places.

Comparison of model error. (a) Cumulative density functions for absolute error of each model. 80% of predictions are under 0.35 for MK-207 and 0.42 for GS-04. (b) Corresponding probability densities for the error of each model. The area of each curve integrates to 1, and so the y-axis represents the probability density of the error rate.

## Section: Results › App Development

Two applications were developed to make the final model accessible to both scientists and modelers. The architecture is summarized in Figure 6. For rapid estimates of molecular complexity and Open SMART-PMI, a user-friendly online application requires only the molecule’s SDF file. The resulting outputs also include the values of each descriptor factored into the model. The application uses a one-time installation and can subsequently be run locally and therefore does not track molecule entries or results. We have also created a package and command line application (CLI) in Python for model experimentation, allowing for changes in training data, simplified model retraining, and predictions. Like the web app, the CLI can be locally installed by the user and is stateless to prioritize user privacy. We encourage users to augment the model and explore diverse datasets to continue understanding molecular complexity. All materials, including the model and associated apps, can be found at https://github.com/Gilead-IT-GCDM-PDM/Open-SMART-PMI. Programmed entirely in Python, the standard for many cheminformatics and machine learning tools, open-source accessibility is at the forefront of our approach.

In this work, we have made three primary improvements: adding explainability to the search over a large descriptor space, reducing the number of descriptors while maintaining performance, and making the model open source in the language of choice for developers.

Architecture diagram of the browser and command line applications.

## Section: Discussion

While our findings contribute to refining the calculation of molecular complexity for SMART-PMI, the remaining challenges and directions merit discussion. Future progress involves addressing biases in modeling, exploring the efficacy of linear models, leveraging graph networks, and refining PMI estimates for broader industry applications, particularly in multistep processes. Future research in these directions will undoubtedly contribute to the landscape of molecular informatics.

Our effort to select descriptors postmodel training was done cautiously, as the described approach may introduce bias and artificially inflate goodness-of-fit. While our evaluation encompassed both selected and rejected descriptors, mean complexity, and model building, we acknowledge the inherent bias of data-driven models toward the training set. Despite the diversity of the training set, this study is relevant mainly to pharmaceutical contexts, and more work could be done to connect molecular complexity across domains.

Surprisingly, introducing nonlinearity with interaction terms did not improve predictions and, in some cases, may have done the opposite. This observation suggests the viability of linear models, and that the complexity of molecular structures may be effectively captured in a simpler computation. Unique topological torsion and a chirality measure were similarly used in Sheridan et al.’s four-term linear model of mean complexity with an 80% CV-R2. Given the subjectivity inherent in mean complexity as an average of chemists’ assessment, it is not expected for model predictions to be 100% accurate. While they note that mean complexity is a nonlinear variable, this further suggests that a regression model may still yet be able to achieve better fit and low error, enabling a better understanding of the physical implications of molecular complexity.

For this application, where the molecule is represented as a set of molecular descriptors, the multilayer perceptron had comparable performance to the selected interpretable model and thus presented no discernible advantage. In similar use cases with complex relationships between numeric input and output variables, deep learning remains a powerful option with the potential to capture complicated data trends. However, large amounts of training data are typically necessary, which can be an obstacle for chemistry tasks. For more complex tasks, more powerful algorithms are often necessary. Graph networks, which can use a graph-structured compound as input, are also being explored for tasks such as chemical structure prediction and may translate well to understanding molecular complexity. This, coupled with an explaining layer, could also be powerful in identifying molecular features. However, while explainability approaches like Grad-CAM output annotated molecule mappings, it may be difficult to discern long-range topological patterns. More research is currently being done to explore the viability and interpretability of these models.36,37 Overall, deep learning remains an attractive option for continuing future work.

To increase the usage and accuracy of PMI targets for widespread adoption in industry, more can be done to advance the utility and ease of tracking the PMI of a manufacturing process back to the simplest raw material building blocks. This can be especially challenging in early development where estimates must be made for the PMI of outsourced materials, such as simple starting materials. It may be possible to apply the same model for starting materials and estimate overall PMI as a linear combination of outsourced and in-house materials. Vendors could be further encouraged to track and share the process mass intensity of their materials.

## Section: Conclusions

Sustainability is paramount in manufacturing processes. Process chemists throughout the industry are working toward this goal by aiming to reduce the raw materials needed for processing and the waste produced as a byproduct of this process. Molecular complexity is one of the main indicators of the resource efficiency of a process, but without a clear definition, it is difficult to create good estimators for this parameter. Machine learning tools have recently emerged as a viable method to assist experts with decisions in complicated domains. While these tools have had success, more is needed in terms of explaining the basis of the decisions or predictions generated by complex models.

We have used an existing approach to evaluate molecular complexity and generated an open-source model with emphasis on robustness, simplicity, and interpretability. While our tool builds on the original compound complexity and SMART-PMI papers, we have made improvements in terms of interpretability and developed a new model as an open-source tool available to the larger community. We have focused on an open-source approach to develop a cost-effective tool for both internal and external use, as having these kinds of tools available for use to the larger community fosters rapid evaluation and selection of best solutions toward setting common standards.

## Section: Acknowledgments

We are grateful to Chris Foti, Victor Rucker, Jeremy Zhang, Mehul Chhatrapati, and Peter Huang for supporting this project. We kindly thank Kevin Chu for the discussion regarding linear models as well as Shikhar Mohan and Wei-Ting Liu for their thoughtful guidance and feedback.

## Section: Data Availability Statement

The Open SMART-PMI package, including the code, stored models, and applications, can be found online at https://github.com/Gilead-IT-GCDM-PDM/Open-SMART-PMI.

## Section: Supporting Information Available

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acsomega.4c02427.

## Section: Author Present Address

∇ Department of Biology, Stanford University, Stanford, California 94305–6104, United States

## Section: Author Contributions

# P.P. and R.O. contributed equally to this work.

## Section: Text

The authors declare no competing financial interest.

## Section: Supplementary Material

ao4c02427_si_001.pdf

## Section: Associated Data

ao4c02427_si_001.pdf

## Section: Associated Data › Supplementary Materials

ao4c02427_si_001.pdf

## Section: Associated Data › Data Availability Statement

The Open SMART-PMI package, including the code, stored models, and applications, can be found online at https://github.com/Gilead-IT-GCDM-PDM/Open-SMART-PMI.
