# Evaluating Use of Artificial Intelligence for Drug Exposure and Effect Prediction

- **Authors:** Olivier Le Tilly, Jean-Baptiste Woillard
- **Issuer:** Kidney international reports
- **Type:** Scientific article
- **Published:** 2023-11-11
- **Language:** en
- **DOI:** 10.1016/j.ekir.2023.11.006
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38312781/
- **Licence:** CC-BY-NC-ND

## Section: Text

See Clinical Research on Page 134

Rituximab is a monoclonal antibody targeting CD20-positive cells, that is, B cells, with both antibody-dependent cellular cytotoxicity and complement-dependent cytotoxicity. It is thus commonly used to treat antibody-mediated autoimmune diseases such as membranous nephropathy (MN).1 However, this off-label use raises the question of inadequate dosing regimens. Indeed, an increased clearance of rituximab is expected in patients with proteinuria, leading to lower drug levels, which can be more immunogenic, with neutralizing antidrug antibodies also reducing the drug levels and its efficacy. Rituximab underdosing and irreversible chronic glomerular injuries are associated with rituximab-refractory MN, with nonquantifiable rituximab levels after 3 months of treatment as a risk factor for treatment failure (i.e., levels below 2 mg/l in papers studying this relationship).2 However, therapeutic drug monitoring (TDM) of rituximab might be difficult to set up in some centers, leading some researchers to try to identify patients at risk of refractory disease early.

Destere et al.3 developed a machine-learning algorithm based on polynomial support vector machine in a cohort of 73 patients with primary MN to predict whether a given patient would be at low, moderate, or high risk of rituximab underdosing 3 months after the first infusion. This prediction was based on easily collected patients’ baseline and 15-day characteristics (age, gender, body surface area, anti-PLA2R1 antibody titer, serum albumin at baseline and day 15, and serum creatinine at baseline and day 15). Surprisingly, proteinuria at baseline or day 15 did not improve the accuracy of the model, although it is a major cause of rituximab underdosing. The algorithm performed well in the validation set, with an accuracy of 75% (well-classified patients), a sensitivity of 78.7%, and a specificity of 81%. The authors showed that their model performed better than a random model. The methodology used in this article for the analysis is strong, and the results were well-evaluated. The implications of this algorithm were then evaluated on a relatively small number of patients, and the results were promising. Indeed, the algorithm could be used to identify patients at high risk of rituximab underdosing, which could improve treatment outcomes for patients with primary MN.

By extension, applications of artificial intelligence (AI) in routine TDM and model-informed precision dosing have a promising future, but the path forward is challenging. Some of the challenges and opportunities have been recently reviewed.4

In a standard statistical or mechanistic approach, the type of model is chosen based on physiological or biological mechanisms, and the data are used in addition to the model to predict some results. Machine learning (ML) algorithms, even though they are based on statistical and mathematical principles, follow a different paradigm: there is no explicitly defined model, and a large number of parameters (or hyperparameters, corresponding to parameters that cannot be estimated from the data) must be estimated. The algorithm is built by feeding data and results into an algorithm that will build a model to minimize the error between observations and predictions using a loss function. No prior knowledge of the underlying biological mechanism is required, leading to the term “data-driven.” It is very important to have representative data to develop such algorithms and to use a robust approach, such as the one used by the authors in the present paper.

Some examples of AI applications in drug individualization in renal transplantation, especially for immunosuppressant drugs, have shown improved estimation of drug exposure with fewer samples required.5 In addition, recent examples of hybrid algorithms combining mechanistic models and data-driven models have shown improved prediction of drug exposure6 or drug toxicity7 compared to ML or mechanistic models used alone. Finally, some recent work by a leading group in the field has shown that it is possible to incorporate expert knowledge through mechanistic ordinary differential equation models into complex deep learning neural networks,8 allowing for the development of more plausible and explainable algorithms. This last point is particularly important, because an algorithm without a way to use it is nothing more than another publication. Therefore, it is essential to develop tools to use the algorithm, such as the shiny app developed by the authors for demonstration (https://lecteurs.shinyapps.io/Rituximab/). This also allows us to “get out of the black box,” as ML algorithms are often called.

Although AI and ML hold promise as novel patients profiling tools, it might be detrimental to focus AI research on using them as surrogates to TDM, which is itself a surrogate to predict a clinical outcome. TDM of biologics is still lacking in nephrology because proteinuria adds another layer of complexity to the dose-concentration-response relationship. Furthermore, the management of primary MN relying on TDM may also depend on antidrug antibody detection,2 which varies significantly depending on assays, especially since some assays only detect free antidrug antibody and are “drug-sensitive,” leading to false negative results if drug levels are quantifiable.9 Therefore, using a combination of both ML and TDM data could be more promising to predict the patients’ fate more accurately than employing a single isolated approach (Figure 1).Figure 1Although machine learning can be used as an novel alternative to pharmacometric modeling and model-informed precision dosing (a), it can also be used conjointly with “traditional” modeling approaches for (hopefully) better performances for precision dosing and precision medicine (b). The figure was made using BioRender (app.biorender.com). PK-PD, pharmacokinetic-pharmacodynamic.

In conclusion, the introduction of AI to drug exposure and effect prediction is rapidly expanding; however, it should be evaluated prospectively and carefully in clinical trials using the dedicated CONSORT AI guidelines. This is what the authors propose as future work in their manuscript.

## Section: Disclosure

All the authors declared no competing interests.


---

# Evaluation of Molecular Simulations and Deep Learning Prediction of Antibodies' Recognition of TRBC1 and TRBC2

- **Authors:** Xincheng Zeng, Tianqun Wang, Yue Kang, Ganggang Bai, Buyong Ma
- **Issuer:** Antibodies (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2023-09-17
- **Language:** en
- **DOI:** 10.3390/antib12030058
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37753972/
- **Licence:** CC-BY

## Section: Abstract

AbstractT cell receptor β-chain constant (TRBC) is a promising class of cancer targets consisting of two highly homologous proteins, TRBC1 and TRBC2. Developing targeted antibody therapeutics against TRBC1 or TRBC2 is expected to eradicate the malignant T cells and preserve half of the normal T cells. Recently, several antibody engineering strategies have been used to modulate the TRBC1 and TRBC2 specificity of antibodies. Here, we used molecular simulation and artificial intelligence methods to quantify the affinity difference in antibodies with various mutations for TRBC1 and TRBC2. The affinity of the existing mutants was verified by FEP calculations aided by the AI. We also performed long-time molecular dynamics simulations to reveal the dynamical antigen recognition mechanisms of the TRBC antibodies.Keywords: antibody, artificial intelligence, antibody design, free energy perturbation, molecular dynamics simulations

## Section: 1. Introduction

The TCRα/β recognizes foreign (peptide) antigens peptide-loaded MHC (pMHC) and then activates many signal transduction cascade reactions, regulating cell survival, proliferation, differentiation, and cytokines generation. TCR activation is fundamental to the immune response and plays essential roles not only in the protection against invading microorganisms but also in the suppression of cancer. Like antibodies, TCR diversity is generated by somatic recombination of variable (V), diversity (D), joining (J), and constant (C) regions. There are two β-chain constant region genes, TRBC1 and TRBC2. While each TCRα/β carries either TRBC1 or TRBC2 in a mutually exclusive manner, the normal T cell population comprises a mixture of individual cells, either expressing TRBC1 or TRBC2. However, the cancer T-cell population exclusively expresses either TRBC1 or TRBC2. Using antibodies to specifically target TRBC1 (TCRαβ1) or TRBC2 (TCRαβ2) (in the case of a TRBC1+ T cell malignancy or the case of a TRBC2+ malignancy, respectively) has been proposed to be a strategy to eradicate all cells of malignant cancer [1].

TRBC1 and TRBC2 differ in four residues located in three different structural regions (Figure 1): NK or KN in positions 3-4; F or Y in position 35; and V or E in 134. Since F35 is buried and V134 is in the transmembrane domain, the only possible epitope to differentiate TCRαβ1 or TCRαβ2 is the N3K4/K3N4. The trivial change in epitope tests the sensitivity and specificity of antibodies to bind TCRαβ1 or TCRαβ2 selectively. Using a transgenic mouse line expressing a human V beta 3 C beta 1 TcR, monoclonal antibody JOVI-1 was obtained [2] and found to recognize only TRBC1-TCR (TCRαβ1) and not TRBC2-TCR (TCRαβ2) [2,3]. The JOVI-1 can be used as anti-TRBC1 antibody-based flow cytometric detection of T-Cell clonality [4,5,6] and, more importantly, to construct anti-TRBC1 CAR-T cells that kill TRBC1 expressing normal and malignant T cells while sparing TRBC2 restricted cells [3]. Other CAR-T targeting TRBC1 [7] or similar TRBV family members [8] expressed in malignant T cells were also reported. Interestingly, based on computational structure-guided specificity redirection of JOVI-1, three mutations of the JOVI-1 VH chain (T28K, Y32F, A96N) successfully switched JOVI-1 to bind the highly homologous target TRBC2-TCR (TCRαβ2) [9], opening another opportunity for the T-cell malignancy treatments.

Computational antibody designs have been developed to help antibody designs [10,11,12,13,14,15,16], including molecular mechanical energy-based de novo design [11], molecular dynamics simulations [14,17,18,19], structure-based antibody prediction and similarity measure of antibody–antigen interfaces [20,21]. Molecular docking and subsequent MD simulation have also been used to predict the binding mode of JOVI-1 with TRBC1 [19]. Recently, various deep learning-based machine learning approaches have pushed the advances of the antibody engineering [22,23,24,25,26].

In this study, we used sequence-based antibody affinity prediction, molecular dynamics simulation, and free energy perturbation to analyze the family of antibody JOVI-1 and their selective bindings to TCRαβ1 and TCRαβ2. While training on vast variations in antibody–antigen sequence and mutations, our machine learning model can predict the trend of change in binding affinity; however, it does not have the precision to distinguish epitope switch of N3K4/K3N4 in TRBC1 and TRBC2, respectively. Molecular dynamics simulations of fourteen variations in JOVI-1 mutant TRBC1/2 complexes indicated that the antibody–antigen complex with a binding affinity of less than 8 kcal/mol tends to disassociate in simulation. Finally, our free energy perturbations of amino acid mutation reproduced the selective binding trend of JOVI-1 family antibodies.

(Upper panel): sequence alignment of TRBC1 and TRBC2 constant regions. (Lower left panel): JOVI-1 antibodies recognize the N3K4/K3N4 region. (Lower right panel): crystal structures of JOVI-1-TRBC1/2 complexes have similar conformations.

## Section: 2. Materials and Methods

Performance of several models in antibody affinity ΔΔG prediction 1.

List of simulated antibody–antigen complexes 1.

The thermodynamic cycle to calculate free energy change.

## Section: 2. Materials and Methods › 2.1. AI Model Training and Prediction of Antibody–Antigen Binding Affinity

We designed a listwise ranking model specifically for predicting changes in affinity based on mutations. This model is trained on SKEMPI [27] Antibody–Bind (AB-Bind) [28] datasets, both curated antibody–antigen complexes with single-site and multi-site mutations and corresponding free energy change values (∆∆G). The training dataset comprises a total of 1413 antibody–antigen pairs, each annotated by binding free energy values (affinity). Our approach involves training the transformer encoder layers using antibody and antigen sequences as inputs. The pre-processed training data comprise wild-type antibody–antigen pairs and their corresponding mutant, organized into separate lists. Each list consists of antibody variants binding to the same antigen. The binding affinity changes are normalized to (0,1) as the “relevance score”, akin to the idea of “relevance” in searching problems.

Our model, therefore, focuses on fitting the relevance scores rather than actual ∆∆G values with the use of normalized discounted cumulative gain (NDCG) loss function. Pre-trained language models AntiBERTy [29] and ProtBert [30] are utilized to generate embeddings for antibody and antigen sequences. The ranking model is expected to capture the enabling features that contribute to binding affinity changes at the amino acid level.

The correlation between experimental measurements and predicted ranking scores was evaluated with the Pearson correlation coefficient (for linear correlation) and the Spearman coefficient (for ranking correlation) in Table 1. The proposed Digiwiser model yields Pearson correlations ranging from 0.71 to 0.89 on five-fold validations, outperforming most conventional (structure-based) in silico approaches [28].

Performance of several models in antibody affinity ΔΔG prediction 1.

## Section: 2. Materials and Methods › 2.2. Molecular Dynamics Simulations and Analysis

The initial structures of simulations were taken from crystal structures listed in Table 2, with disulfide bonds constructed accordingly. For the chains of antibody and antigen, the N termini and C termini were charged (NH3+ and COO− groups, respectively). The missing residues in crystal structures were added using the CHARMM-GUI input generator [31]. The systems were then solvated by TIP3 water molecules with a minimal distance of 15 Ǻ from any protein atom to any edge of the water box. Sodium and chloride ions were added to neutralize the system to a total concentration of ~150 mM. The resulting solvated systems were energy-minimized for 50,000 steepest descent steps:q. In the heating stage, each system was gradually heated to 50 K and then to 250 K. In the production stage, all simulations were performed using the NPT ensemble at 300 K, with a timestep of 2 fs. The particle mesh Ewald (PME) method was used to calculate the electrostatic interaction, and the van der Waals interactions were calculated using a cutoff of 12 Å. All MD simulations were performed using the amber20 software (University of California, San Francisco, CA, USA) [32] with CHARMM36 force field [33]. MD trajectories were saved by every 0.1 ns for analysis. A summary of all simulation systems is given in Table 2.

RMSD/RMSF calculation and Correlation analysis: The root mean squared deviation (RMSD) and root mean square fluctuation (RMSF) for the backbone of each structure were calculated by VMD. Correlations between all the residues were analyzed for the stable MD trajectory using the normalized covariance of the motion of protein residues [34], ranging from −1 to 1. If two residues moved in the same (opposite) direction in most of the frames, the motion was considered (anti-)correlated, and the correlation value was close to 1 or −1. If the correlation value between two residues was close to zero, they were generally uncorrelated. The correlation evaluation was performed using the program CARMA [35]

List of simulated antibody–antigen complexes 1.

## Section: 2. Materials and Methods › 2.3. NAMD-Free Energy Perturbation Protocol

Free energy perturbation (FEP) calculations were performed starting from four different crystal binding poses (7amp, 7amq, 7amr, 7ams). In total, two kinds of systems were set up by using the CHARMM-GUI program. One was the antibody (light and heavy chain) in solvent (unbound state). The others were the TRBC and TCR-bound with antibody (bound state), both at 298 K and 1 atm. The system was solvated and ionized with the same condition described in the MD simulation section. The mutation of antibodies was conducted using the VMD program. NAMD all-atom molecular dynamics simulations [36] with CHARMM36 force field [33] were performed to equilibrate both kinds of systems using an NVT ensemble after a brief energy minimization. The dual-topology methodology and the soft-core potentials were applied to overcome endpoint singularities in the FEP simulation. The FEP method uses a thermodynamic coupling parameter λ, which is in the range of 0 to 1, to scale the potential energy change in mutating a residue on the antibody. In this study, one FEP calculation included 16 windows, ranging from λ values of zero to 1 (with a gap of 0.0625) for a total of 32 simulations per mutation since we ran both forward and backward simulations in each window to check the consistency of each simulation. The time step was 2.0 fs. During the FEP simulations, each window was equilibrated for 0.2 ns before collecting the FEP data based on the subsequent 0.8 ns simulations. After that, the change in free energy is calculated with Scheme 1 and Equation (1).

The thermodynamic cycle to calculate free energy change.

## Section: 3. Results

Antibody mutation effects on antibody–antigen affinity (kcal/mol) rank.

Free energy perturbation of antibody mutation effects (kcal/mol).

Dynamics hydrogen bond network formed between TRBC1 b-chain and JOVI-1 antibody at different simulation times. (A) Starting crystal structure. (B) Snapshot at 50 ns. (C) Snapshot at 100 ns. (D) Snapshot at 200 ns.

Trajectories of key hydrogen bonds from MD simulations of JOVI-1 TRBC1 (7amp, green line), JOVI-1/T28K TRBC1 (mut1a, purple line), and JOVI-1/KFN TRBC2 (7ams, red line). Residues in TRBC1 are in red font, and antibody residues are in black font. (A): distance trajectory between K120/N120 and T28/K28 residues. (B): distance trajectory between E116 and T28/K28 residues. (C): distance trajectory between N185 and T28/K28. (D): distance trajectory between N119 and Y32residues. (E): distance trajectory between D117 and Y32/F32 residues. (F): distance trajectory between Q226 and R55 residues.

Trajectories of structural fluctuations during MD simulations. (A) RMSD of TCR a chain. (B) RMSD of TCR b chain. (C) RMSF of TCR a chain. (D) RMSF of TCR b chain; (E) RMSD of JOVI-1 antibodies. (F) RMSF of JOVI-1 antibodies.

Covariance matrixes for stable complexes (upper panels) and unstable complexes (lower panel). TCR-a and TCR-b are two TCR chains. H-Ab is an antibody heavy chain, and L-Ab is an antibody light chain.

## Section: 3. Results › 3.1. AI Prediction of Mutation Effects on JOVI-1’s Recognition of TRBC1 and TRBC2

The training of our listwise ranking model for predicting affinity change (ΔΔG) was described in the Methods section. Using our trained prediction model, we tested the sequence-based antibody binding affinity change upon point mutations. In the prediction of TRBC1 binding ranking, we used the HuJovi-1 Fab TRBC1 complex and the HuJovi-1/KFN TRBC2 complex as references to probe TRBC1 and TRBC2 binding ranking, respectively. Table 3 lists experimental binding affinity changes and AI model-predicted mutation ranking scores. The lower number responds to mutation with higher binding affinity. As can be seen from Table 3, this model has a better Pearson correlation for TRBC1 binding than binding to TRBC2. However, as for Spearman ranking correlation, those antibody bindings to TRBC2 have a better ranking correlation between experimental binding affinity and AI model-predicted preference. In the TRBC1 group, this model produces a notable correlation (Pearson = 0.543), with a comparatively weaker correlation (Pearson = 0.272) for the TRBC2 group. The Spearman score for the TRBC2 group demonstrates robust ranking performance (Spearman = 0.899), whereas the TRBC1 group exhibits a relatively lower correlation (Spearman = 0.143). The overall correlation coefficient of the ranking score for all entries in Table 2 has an R2 value of 0.1. We explored the potential explanations for this observation in the Discussion and Conclusions. This ΔΔG ranking prediction model was trained from a dataset with different antibody–antigen pairs, but for comparable antibody mutations, the antigens have identical sequences. Therefore, it seems that this model has a better ability to rank antibody mutations with the same antigens. However, for the system with a slightly changed antigen sequence, these models have difficulty recognizing the small variation. This is the reason that for a given antibody, the rank scores for TRBC1 and TRBC2 are almost identical (Table 3). Thus, in future training of antibody–antigen AI models, it is important to include similar antigens as well.

Antibody mutation effects on antibody–antigen affinity (kcal/mol) rank.

## Section: 3. Results › 3.2. Prediction of Mutation Effects on JOVI-1’s Recognition of TRBC1 and TRBC2 with Free Energy Perturbation

Free energy perturbation simulations of key mutations controlling the binding preference of TRBC1 and TRBC2 were performed based on the protocol detailed in the Methods section. The results are listed in Table 4. These three mutations represent four types of amino acid changes. T28K switches a neutral residue to a positively charged Lys; K28R has a small mutation effect since it switches between similar amino acids Lys and Arg. Y32F removes the hydroxyl group from Tyr, and A96N allows for the addition of hydrogen bonding with TRBC1/TRBC2. Due to charge repulsion between TCRβ1 and K120, the T28K mutation decreases binding affinity with TRBC1 by 0.56 kcal/mol but increases TRBC2 binding by 0.33 kcal/mol since the position now is N120 in TRBC2. Generally speaking, the free energy perturbation calculations involving charged residues usually have larger errors. In our FEP calculations, the error for the T28K mutation in TRBC1 binding is 0.1 kcal/mol but larger in TRBC2 binding (1.85 kcal/mol).

The Y32F mutation calculations have different simulation behaviors. The seemingly small change in Tyrosine-to-Phenylalanine mutation has normal accuracy in the single mutation system of Mut5a, which directly mutates Tyr32 to Phe from the 7AMP structure. The experimentally free energy change is 3.04 kcal/mol, and the FEP number is 2.24 kcal/mol, with an error of 0.80 kcal/mol. However, the combination of T28K and Y32F in mut2a/mut2b systems caused large errors in our FEP calculations (not listed). The T28/Y32 are the most important residues to maintain Jovi-1’s selective binding of TRBC1/TRBC2. T28K/Y32F mutations cause large-scale reorganization of the hydrogen bonding network between Jovi-1 and TRBC’s interfaces (see next section for details). Therefore, we changed our FEP protocol to run the reversed mutation of N96A from the KFN mutant, and that mutation was equivalent to T28K/Y32F mutations from the original Jovi-1 antibody. As a result, the FEP energy changes for mut2a/2b systems are satisfactory.

K28R mutation has very little effect on Jovi-1’s binding of TRBC1/TRBC2. Our FEP calculation fairly reproduced the experimental result of −0.32 kcal/mol in TRBC1 binding, with an error of only 0.13 kcal/mol. However, the error for TRBC2 binding of this mutation is larger (2.58 kcal/mol).

The FEP energies for A96N (A100N in our residue numbering) mutations in both Mut6a (direct A96N mutation from 7AMP) and mut6b (A96N mutation from 7AMQ) have normal accuracies, with errors of 0.72 kcal/mol and 2.01 kcal/mol, respectively.

A close look at Table 4 reveals that our FEP calculations for the TRBC1 system have smaller errors (average 1.28 kcal/mol) than the TRBC2 system (average error 2.09 kcal/mol). This could reflect that JOVI-1’s binding to TRBC2 is more sensitive to mutation than TRBC1 binding. Indeed, JOVI-1 was initially generated against the TRBC1 [2] and engineered to bind the TRBC2 [9].

Free energy perturbation of antibody mutation effects (kcal/mol).

## Section: 3. Results › 3.3. Dynamic Features of JOVI-1 and Mutants’ Recognition of TRBC1 and TRBC2

We have systematically studied 18 complexes of JOVI-1 (and mutants) with TRBC1/TRBC2 using MD simulations up to 1000 ns, and we listed the simulation system and simulated antibody–antigen stabilities in Table 2. Interestingly, three complexes with the lowest binding affinities (JOVI-1 TRBC2, mut1b JOVI-1/T28 TRBC2, and mut3a JOVI-1/KFN TRBC1) disassociated at different simulation times (Table 2). Mut6b (JOVI-1/A96N TRBC2) also disassociated at around 600 ns. The stability of these complexes during our MD simulation is consistent with switching selectivities from TRBC1 to TRBC2 with the mutations that occurred.

The crystal structures of JOVI-1 antibodies’ complexes with TRBC1/TRBC2 explain many structural features for JOVI-1’s selectivities [9]. However, there are several results that are not obvious from the crystal structures only. For example, one of JOVI-1’s preferences for TRBC1 over TRBC2 is that the heavy chain T28 of JOVI-1 forms a hydrogen bond with L120 in TRBC1 (Figure 2A), which is absent in TRBC2. However, the JOVI-1 T28K mutant (mut1a and mut1b), which cannot form hydrogen bonds with the L120, still maintains a high affinity with TRBC1 and has a decreased binding affinity with TRBC2, in comparison to the parent wt JOVI-1 (Table 2).

Our simulations revealed the remarkable dynamical nature of JOVI-1’s binding with TRBC1/TRBC2 for stable complexes as well. As can be seen in Figure 2, the hydrogen bonds network formed between the TRBC1 b-chain and JOVI-1 antibody changes at different simulation times. The hydrogen bonds observed in the crystal structures fluctuated or disappeared, while new hydrogen bonds that were not seen in the crystal structure formed during MD simulations. One of the most striking features is that the hydrogen bond between K120 in TRBC1 and T28 in JOVI-1 is subjected to the competition from nearby E116’s interaction with T28 (with both side chain and backbone amide NH; Figure 2 and Figure 3A,B). After stabilizing for around 400 ns, the E116-T28 becomes highly flexible; however, its interactions with T28 in mut1a and TRBC2 binding frequently form and leave (Figure 3A). N185 in TRBC forms dynamic hydrogens with T28/K28 residue in antibodies, even for the T28 with a shorter side chain and an initial 9 Å separation in the crystal structure (Figure 2B and Figure 3C).

N119 forms a hydrogen bond with Y32 in the crystal structure; the JOVI-1 can maintain the hydrogen bonding interaction with N119 frequently during simulation (Figure 2B and Figure 3D). Interestingly, this hydrogen bond is very stable in the JOVI-1/T28K TRBC1 complex (mut1a, purple line in Figure 3D). As initially observed in the crystal structure, Y32 forms a strong hydrogen bond with D117. Again, this interaction is stronger in mut1a and in the parent wt complex (Figure 4E). With the Y32F mutation in the KNF mutant, the F32 can stay near D117, mainly due to the hydrophobic part of the L119 sidechain in TRBC2.

There is one specific interaction between light chain Y37 and TRBC D227 in the JOVI-1 crystal structures. This is also a very dynamic interaction since the D227 is within the most flexible FG loop in the TCR b chain [37,38]. Not surprisingly, during MD simulations, we have observed that other FG loop residues, E223, W224, and Q226, form hydrogen bonds with Y54, R55, R59, and G62. Figure 2 highlights hydrogen bonds between Q226-R55 and E223-R59, and Figure 3F shows the trajectories of R55 binding with the backbone carbonyl group of Q226.

We compared the structural changes during simulation for four systems with known crystal structures (Figure 4). Two of the systems disassociated during simulation, corresponding to the preferred antibody–TRBC selectivity, i.e., JOVI-1 TRBC2 (7amq) and JOVI-1/KFN TRBC1 systems. As can be seen in Figure 4, there is no trend for RMSD of TCR a chain (Figure 4A), but RMSDs of TCR b chain are smaller for unstable complex (Figure 4B), indicating that the weak antibody–antigen interactions cause smaller perturbation of TRBC1/2. Examining antibodies shows the opposite trend; weak binding antibodies have larger RMSD and RMSF than stable complexes (JOVI-1 TRBC1 7amp and JOVI-1/KFN TRBC2 7ams systems). The underlying mechanism could be that the JOVI-1 antibodies have high fluctuating entropy, and the entropy can be effectively transferred to the TRBC antigen in the strong complex, while in the weak complex, antibodies maintain their high entropy.

Our previous work [14] indicated that the communication between antibody and antigen could be reflected in the amino acid residue covariance matrix, which measures the motion correlations between any two residues in a protein complex. Figure 5 compares the covariance matrixes for the antibody–TRBC system with higher affinities (upper panel) and lower affinities (lower panel). While there are notable differences in correlations between antibodies and antigens, one can see that the correlations within antibodies have different features for the stronger binders and weaker ones: (1) the correlations between the constant domain and variable domain for both heavy and light chains (red squares corresponding to H-Ab/H-Ab and L-Ab/L-Ab) are more positive in the upper panel than in the lower panel; and (2) the correlations between heavy and light chain (blue and yellow squares corresponding to H-Ab/L-Ab and L-Ab/H-Ab) are more negative in the upper panel than in the lower panel.

Dynamics hydrogen bond network formed between TRBC1 b-chain and JOVI-1 antibody at different simulation times. (A) Starting crystal structure. (B) Snapshot at 50 ns. (C) Snapshot at 100 ns. (D) Snapshot at 200 ns.

Trajectories of key hydrogen bonds from MD simulations of JOVI-1 TRBC1 (7amp, green line), JOVI-1/T28K TRBC1 (mut1a, purple line), and JOVI-1/KFN TRBC2 (7ams, red line). Residues in TRBC1 are in red font, and antibody residues are in black font. (A): distance trajectory between K120/N120 and T28/K28 residues. (B): distance trajectory between E116 and T28/K28 residues. (C): distance trajectory between N185 and T28/K28. (D): distance trajectory between N119 and Y32residues. (E): distance trajectory between D117 and Y32/F32 residues. (F): distance trajectory between Q226 and R55 residues.

Trajectories of structural fluctuations during MD simulations. (A) RMSD of TCR a chain. (B) RMSD of TCR b chain. (C) RMSF of TCR a chain. (D) RMSF of TCR b chain; (E) RMSD of JOVI-1 antibodies. (F) RMSF of JOVI-1 antibodies.

Covariance matrixes for stable complexes (upper panels) and unstable complexes (lower panel). TCR-a and TCR-b are two TCR chains. H-Ab is an antibody heavy chain, and L-Ab is an antibody light chain.

## Section: 4. Discussion and Conclusions

We have studied JOVI-1 family antibodies recognition of TRBC1 and TRBC2 using molecular simulations and deep learning prediction. The MD simulations have revealed the strong dynamical nature of antibody–antigen interaction in these systems.

Our Digiwiser AI model harnessed deep learning techniques for predicting affinity changes upon antibody mutations. We observed an improved correlation between the predicted score and experimental measurements when compared to traditional in silico approaches, which is attributed to the network design of the listwise ranking model.

When applied to TRBC1/2 antibody variants, we observed distinct correlation patterns on model predictions. For the TCBR1 group, this model yields a better Pearson correlation (Pearson = 0.543) compared to the weaker correlation (Pearson = 0.272) of TRBC2. Conversely, the Spearman score for the TRBC2 group demonstrates robust ranking performance (Spearman = 0.899) compared to TRBC1 (Spearman = 0.143). Due to the inherent antibody–antigen pairs of our training data, we hypothesized that such disparity between TRBC groups might be due to this model’s heightened sensitivity for differences in antibodies rather than antigens, and therefore, leads to similar scores for identical antibody mutants binding with TRBC1 and TRBC2, two identical antigens. It is also important to acknowledge that the small sample size of TRBC1/2 may also lead to the difference between groups.

A common difficulty in antibody machine-learning training is the limited availability of experimental data. It is possible to overfit a model on small training datasets with a limited diversity of protein families. From a modeling perspective, it is important to note that our approach involves constructing the model with a listwise strategy, which entails treating each group of antibodies and mutations that bind to a specific antigen as separate, independent lists during the training process. This design is particularly effective when it comes to ranking tasks involving a single antigen and multiple antibody mutations. Yet, it could also result in reduced sensitivity when dealing with antibodies that bind to different antigens, leading to a weak correlation when combining all antibodies’ affinities toward TRBC1 and TRBC2. In addition, while this approach exclusively incorporated complex sequence information and eliminated the need for structural data, we found that other structural approaches are needed to complementarily detect small variations in antigens.

Previously, Mason et al. used deep-sequenced libraries of the therapeutic antibody trastuzumab to improve antibodies’ specificity to HER2 and used more than 10,000 variants as a training set to optimize a neural network [39]. Similarly, Makowski and colleagues developed an ML model to optimize the affinity and specificity of antibodies [40], with a dataset generated in-house by sorting and deep sequencing of a mutation antibody library. This type of approach still requires a tremendous amount of experimental involvement, and more accurate and less experimentally dependent methods are needed, with possible promises for the improvement of antibody activity and properties using protein language models [41].

The free energy perturbation results reflect the effects of different types of amino acid mutations, although the errors are larger for TRBC2. It should be noted that the NAMD-FEP sampling time window here is only 1 ns, and a longer simulation time can help improve the accuracy of FEP calculation. In addition, there are several systems with charge changes in this FEP, such as T28K. For systems with charge changes, in order to maintain the electroneutrality of the system, it is necessary to change the charges of the corresponding number and sign of count ions (such as Na+ or Cl−) in FEP so that the total charge of the system in each window is zero. In order to avoid sudden changes in Coulomb interaction energy during FEP, soft-core potentials need to be used in FEP. At the same time, using smaller lambda windows near 0 and 1 can also achieve a smoother transition.

The hydrogen bond network between TRBC1 β-chain and JOVI-1 antibody changes at different simulation times, and the most obvious feature is that the hydrogen bond between K120 in TRBC1 and T28 in JOVI-1 is affected by the competition of the interaction between E116 and T28 nearby. The different hydrogen bonding network changes are presented in the simulations as differences in the dynamic binding of the individual antibodies to TRBC1 and TRBC2. Prolonged molecular dynamics simulations also observed a number of antibodies and TRBCs separating from each other from the binding site after a period of time, with poorer binding stability correlating with a poorer affinity of the antibody–antigen. The entropy effect could explain the dynamics of the different antibodies. The high fluctuation entropy of the JOVI-1 antibody has different entropy shifts in strongly and weakly bound complexes, which is ultimately reflected in a decrease in the fluctuation of the antibody itself.

In conclusion, the current model exhibits significant potential in predicting the impact of single/multiple amino acid changes, and it would be beneficial to incorporate antigens with high identity in the training set for better robustness and broader applicability. Still, our work suggests that the AI method needs to be combined with molecular simulations to computationally provide comprehensive pictures of antibody–antigen interaction, especially for systems with high dynamic interactions. For the protein–protein with large conformation dynamics contribution, more accurate free energy perturbation protocols are also needed.

## Section: Acknowledgments

The computational simulations are supported by the Center for High-Performance Computing at Shanghai Jiao Tong University and Shanghai Digiwiser’s computer clusters.

## Section: Author Contributions

B.M. and X.Z. designed this study and performed conceptualization; T.W., X.Z., Y.K. and G.B. conducted simulations and analysis; B.M., X.Z. and Y.K. co-wrote this manuscript. All authors have read and agreed to the published version of this manuscript.

## Section: Institutional Review Board Statement

Not applicable.

## Section: Informed Consent Statement

Not applicable.

## Section: Data Availability Statement

The data used to support the findings of this study can be made available by the corresponding author upon request.

## Section: Conflicts of Interest

Author Yue Kang and Tianqun Wang were employed by the company Shanghai Digiwiser Biological Inc. The remaining authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.

## Section: Funding Statement

This research was funded by the Natural Science Foundation of China (Grant No. 32171246) and Shanghai Municipal Government Science Innovation Grant 21JC1403700.

## Section: Associated Data › Data Availability Statement

The data used to support the findings of this study can be made available by the corresponding author upon request.


---

# Extracting prime protein targets as possible drug candidates: machine learning evaluation

- **Authors:** Subhagata Chattopadhyay, Nhat Phuong Do, Darren R Flower, Amit K Chattopadhyay
- **Issuer:** Medical & biological engineering & computing
- **Type:** Scientific article
- **Published:** 2023-08-23
- **Language:** en
- **DOI:** 10.1007/s11517-023-02893-0
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37608081/
- **Licence:** CC-BY

## Section: Abstract

Extracting “high ranking” or “prime protein targets” (PPTs) as potent MRSA drug candidates from a given set of ligands is a key challenge in efficient molecular docking. This study combines protein-versus-ligand matching molecular docking (MD) data extracted from 10 independent molecular docking (MD) evaluations — ADFR, DOCK, Gemdock, Ledock, Plants, Psovina, Quickvina2, smina, vina, and vinaxb to identify top MRSA drug candidates. Twenty-nine active protein targets (APT) from the enhanced DUD-E repository (http://DUD-E.decoys.org) are matched against 1040 ligands using “forward modeling” machine learning for initial “data mining and modeling” (DDM) to extract PPTs and the corresponding high affinity ligands (HALs). K-means clustering (KMC) is then performed on 400 ligands matched against 29 PTs, with each cluster accommodating HALs, and the corresponding PPTs. Performance of KMC is then validated against randomly chosen head, tail, and middle active ligands (ALs). KMC outcomes have been validated against two other clustering methods, namely, Gaussian mixture model (GMM) and density based spatial clustering of applications with noise (DBSCAN). While GMM shows similar results as with KMC, DBSCAN has failed to yield more than one cluster and handle the noise (outliers), thus affirming the choice of KMC or GMM. Databases obtained from ADFR to mine PPTs are then ranked according to the number of the corresponding HAL-PPT combinations (HPC) inside the derived clusters, an approach called “reverse modeling” (RM). From the set of 29 PTs studied, RM predicts high fidelity of 5 PPTs (17%) that bind with 76 out of 400, i.e., 19% ligands leading to a prediction of next-generation MRSA drug candidates: PPT2 (average HPC is 41.1%) is the top choice, followed by PPT14 (average HPC 25.46%), and then PPT15 (average HPC 23.12%). This algorithm can be generically implemented irrespective of pathogenic forms and is particularly effective for sparse data.Graphical Abstract

## Section: Introduction

Drug design is a key aspect of healthcare that relies on accurate identification of biologically active substances from protein targets (PT) [1]. Ligands (Ls) comprise such biologically active substances that control PTs, which are the functional biomolecules used in the processes of cellular transduction, transformation, and conjugation [2], and hence pharmacokinetic response of the active ligands [3]. PTs can be composed of ion channels, receptors, enzymes, or porter molecules with which drugs-like-ligands bind [2]. Detecting successful L-PT combinations, or more specifically high affinity ligands (HALs) with prime protein targets (PPTs), is still a challenge as new diseases are continuously emerging that require fast responding, high efficacious new drugs with lower adverse effects that are budget conducive as well. The present extensively interdisciplinary study combines tools drawn from molecular biology, probabilistic mathematics, and computer science to automate the detection of HAL and PPTs from the best ligand–protein combinations to identify next-generation MRSA drug candidates.

MRSA is a bacterial infection that is resistant to several antibiotics, making it difficult to treat. The development of AI-powered drugs has offered new hope in the fight against MRSA. Current state of MRSA drugs using artificial intelligence (AI): AI-powered drugs have shown great promise in the fight against MRSA. AI have been used to identify new compounds that can attack MRSA bacteria, and these compounds have been tested in clinical trials. One such compound is called LFF571, which has shown promising results in treating MRSA infections. AI-powered drugs have the potential to revolutionize the way we treat MRSA and other antibiotic-resistant infections. By using AI to identify new compounds, scientists can develop drugs that are more effective and have fewer side effects. AI can also help to identify new drug targets, which can lead to the development of more targeted therapies.

The present study targets three key areas of MRSA drug designing: (i) computational extraction or detection of HAL for PTs, (ii) computational extraction of PPT for HALs, and (iii) probabilistic prediction of interactions of new PTs and Ls [4]. This work primarily focuses on identifying the top PPTs for the corresponding HALs. The novelty lies in stockpiling molecular docking data from 10 different architecture (ADFR; DOCK; Gemdock; Ledock; Plants; Psovina; Quickvina2; smina; vina; and vinaxb) that independently analyze different biochemical pathways, and then combining them using machine learning, first to dimensionally reduce the key elements and then to regress towards probabilistic predictive models.

The study combines information from several machine learning (ML) algorithms to identify correct L, PT candidates, and combinations of two (popularly called as structure–activity-relationship or SAR or quantitative structure–activity-relationship or QSAR) at the outset of a drug design [5]. In SAR, from the structural features of the compound, its biological activities are predicted. SAR is also able to predict the combinatorial strength of the new composite compound benchmarked on a set of pre-trained compounds whose activities are already tested. However, its limitation is noted in L-PT interactions. SAR is unable to predict PT if the Ls are unknown [4]. Therefore, efforts have been made to solve this issue with L-PT 3-D modeling [6]. This approach is not free of its own limitation either. Firstly, L-PT-3D requires knowledge of the full 3-D protein structure, which is not always feasible. Secondly, it relies on an extensive chemical library, and relatively heavy computation [4]. To address these issues, researchers used a sequence of supervised learning algorithms, known as “proteochemometrics,” that outline classifiers that can predict Ls and PTs individually and jointly in a combined formation [7]. These classifiers are support vector machines (SVMs), regressions, artificial neural networks (ANN), fuzzy classifications, and so forth as promising predictors for successful identification of drug targets [8, 9]. K-means clustering (KMC) has also been tried in several studies to discover candidate proteins and its corresponding high affinity agents, particularly in functionality mapping of candidate proteins [10]. Given that we have a phenomenological idea as to the number of clusters and the cluster centers, K-means is an ideal choice for us initially, and then, we validate the performance of KMC with two more clustering techniques, Gaussian mixture model (GMM) and density-based spatial clustering of applications with noise (DBSCAN).

This study automates the extraction of PPTs for a given sample with HALs, initially using data mining and data modeling (DDM), called “forward modeling” (Approach I), and then using a KMC-based “reverse modeling” approach (Approach II) to automate and validate the observations from forward modeling. We later validate the performance of KMC with GMM and DBSCAN, as mentioned. This allows for a statistical estimation within the constraints of sparse data, an approach that can substantially reduce the time needed to find PPTs, thus substituting rigorous laboratory experiments, and hence in optimizing the resources involved with wet-lab experiments.

The next sections illustrate the methodology adopted, demonstration and explanation of the results, and generic implementations of the methodology in drug development studies.

## Section: Methodology

In this section, we first explain the composition of the DUD-E data (http://dude.docking.org/), and how approaches I and II detailed below can be used to analyze these data.Approach I: DMM called “forward modeling.” The aim is to mine HALs and its corresponding PTs.Approach II: K-means clustering as machine learning (ML) technique to automate the prediction of PPTs and validate the HAL-PT combinatorial models thus obtained from the experiments of Approach I (called “reverse modeling”). The performance of KMC is further validated by GMM and DBSCAN clustering methods.

Sample of a DB

ADFR

DOCK

Gemdock

Ledock

Plants

Psovina

Quickvina2

Smina

Vina

Vinaxb

Final set of PPTs obtained based on HALs

Correlation heatmap

Distribution plot

Inertia values to predict correct number of clusters

Iterations versus number of clusters. Iteration 0th, 5 clusters (0–4) and its corresponding number of Ls (total 400):

Centroids based on affinity magnitudes of 400 HALs corresponding to 29 PTs

Euclidean distances of each of the 26 test Ls of test data ‘A’ from centroids of each cluster

Mapping HALs to the corresponding PPTs — ‘reverse modeling’

Three distinct clusters with centroids obtained with KMC

Validation of relationships among HAL test data “A” and PPTs based on clusters

Validation of relationships among HAL test data “B” and PPTs based on clusters

Validation of relationships among HAL test data “C” and PPTs based on clusters

Three distinct clusters with centroids obtained by GMM method

The ‘eps’ value obtained by DBSCAN method

Number of clusters and noise for the dataset printed on Python 3.11.1 IDLE Shell installed on 06/12/2022 in the win32 64 bits system

## Section: Methodology › DUD-E data

Tier 1 involves docking data from the enhanced DUD-E repository (http://dude.docking.org/) using 10 popular and easily accessible (open access) docking programs — ADFR, DOCK6, Gemdock, Ledock, PLANTS, PSOV-ina, QuickVina2, Smina, Autodock Vina, and VinaXB. The choice is governed by reported individual success rates, e.g., DOCK6 at 73.3% [11], Autodock Vina at 80% [12], Gemdock at 79% [13], ADFR at 74% [14], Ledock at 75% [15], PLANTS 72% [16], PSOVina 63% [17], QuickVina2 63% [18], Smina more than 90% [19], and VinaXB 46% [20]. Tier 2 combines data from all 10 scores using statistical (linear and nonlinear) models belonging to four universality classes (detailed later). Tier 3 is about normalizing VS enhancement data from Tier 2 through a novel calibration of the individual best score (Smina in our case) against the respective probability density functions (PDF); existence of Tier 2 PDF points beyond the best individual score defining the improved docking performance from the algorithm in Tier 2. PDF data being non-dimensional, normalization is guaranteed and that too without any information loss. A recent statistical study from our group [21], structured on the ubiquitous consensus scoring (CS) approach, has analyzed the same docking data [11–20] to outline a substantially less computationally demanding structure to identify top PPT candidates, starting from a statistical mechanics-based universality class approach. Apart from establishing improved ligand–protein docking fidelity through this approach, the study will also serve as a validity benchmark of the ML-based present approach. As shown later, the ML approach compares favorably with its CS counterpart.

Each DUD-E database (DB) consists of 1040 ligands (L) × 29 protein target (PT). Out of 1040, 1000 are decoy ligands (DL), i.e., inactive, and 40 are active ligands (AL). “Decoys” are therefore discarded, and “actives” are considered for the study. Each L has its “affinity” towards a corresponding PT. Ligand–protein binding (LPB) or docking occurs only when the change in the Gibbs free energy of the system is “negative” when the system reaches its thermodynamic equilibrium at a constant pressure and temperature. Therefore, “negative” affinities denote successful LPB/docking. As the extent of LPB/docking is determined by the magnitude of the said negative energy, it can be safely suggested that the magnitude of the negative affinity determines the stability of any ligand protein complex (LPC).

Each ligand in a DB is considered “unique,” that is, the same ligand (similar affinities to corresponding PTs) never recurs in any other DB under consideration.

A representative data matrix is shown in Table 1 below. It shows the affinity strengths (cell values) of the first 4 Ls corresponding to the 29 PTs in ADFR. Note that affinities are “negative” in numbers, indicating attractive potential. Similar AL-PT combinations for the remaining 9 DBs are extracted.Table 1Sample of a DB

Sample of a DB

## Section: Methodology › Approach I: data mining and data modeling (DDM) — ‘forward Modeling’

The key objective here is to extract HALs from the unlabeled cluster data and identify the probabilistically matching PPT for successful molecular docking with respect to successful drug design.

ADFR

DOCK

Gemdock

Ledock

Plants

Psovina

Quickvina2

Smina

Vina

Vinaxb

Final set of PPTs obtained based on HALs

Correlation heatmap

Distribution plot

## Section: Methodology › Approach I: data mining and data modeling (DDM) — ‘forward Modeling’ › Data mining steps (carried out for each DB)

A)Identification of HALs and extracting the corresponding PTs based on affinity maxima. Essentially, it is the measure/magnitude of HALs.B)Grouping proximal HAL candidates based on Euclidean distance (ED) separation of similar or close to maximum affinity within each DB.C)Finding ligands (Ls) with highest overall affinities by calculating the maximum of the mean affinity across all PTs and its spread (maximum of the standard deviation across PTs. It can be stated that such an L or a group of Ls show high affinity towards all PTs and thereby accommodate maximum PTs during DOCKING.D)Finding most receptive PTs that can bind with the maximum number of HALs, computing column-wise high affinities.E)Tabulating percentages of HALs amongst total ligands.

Details of the observations are mentioned below.

## Section: Methodology › Approach I: data mining and data modeling (DDM) — ‘forward Modeling’ › Summary steps of DDM (DB-wise)

Table 2 shows the HALs, their respective high affinities, corresponding PPTs, the (global) maximum of the mean affinities of HALs, affinity standard deviation, and percentages of HAL contributions in tabular format for the given DB. Maximum of the mean affinities identifies the L with the overall highest binding capacity calibrated against the dispersion (i.e., standard deviation) of the affinities around mean. The highest ranked HALs are marked in blue.Table 2ADFR

HAL1013, 1014, and 1017 (3/40, i.e., 7.5%) have affinities close to each other and therefore considered as effective Ls. While HAL1013 and HAL1014 show closer affinity towards PT27, the HAL 1017 affinity maps against PT2. PT27 and PT2 are thus called prime PTs (PPTs). HAL1003 and HAL1006 show most overall affinities to bind with all PTs. The HPC, mean, and standard deviations for the remaining DB are shown below in Tables 3, 4, 5, 6, 7, 8, 9, 10 and 11.Table 3DOCKTable 4GemdockTable 5LedockTable 6PlantsTable 7PsovinaTable 8Quickvina2Table 9SminaTable 10VinaTable 11Vinaxb

In the plants DB, HALs show redundancies in the magnitude of affinities. In the final ranking, such redundancies are removed.

ADFR

DOCK

Gemdock

Ledock

Plants

Psovina

Quickvina2

Smina

Vina

Vinaxb

## Section: Methodology › Approach I: data mining and data modeling (DDM) — ‘forward Modeling’ › Summary of DDM

A)HALs (blue font) with “high” affinities to the corresponding PTs are obtained DB-wise and shown in Tables 2, 3, 4, 5, 6, 7, 8, 9, 10 and 11. Highest affinity can be seen in Gemdock (HAL1001, affinity magnitude − 110.98, showing affinity to bind with PPT22). Due to its high magnitude, it is an outlier. Discarding it will amount to key information loss. Hence, we use a machine learning (ML) technique (KMC) to accommodate such extremal values on scalar data.B)DB that is able to provide maximum information on HPC is Smina (62.50%), followed by Quickvina2 (42.5%). Plants (22%) is the third rank holder.C)AL with the highest overall affinity (mean affinity across its values) is 1002.D)Ligand with the highest overall affinity towards all 29 target proteins is 1013 (mean 77.51).E)Ligand with the highest accommodation across all 29 target proteins is 1006 (standard deviation 62.88).F)Ligand 1029 is the most versatile as it can bind with target proteins 2 (affinity − 11), 14 (affinity − 11), and 15 (affinity − 11.33).G)Total number of ligands with high affinity is 76 out of 400, i.e., 19%. After redundancy check (i.e., eliminating ligands with similar affinities), final number of ligands with high affinity is 22 out of 400, i.e., 5%. After redundancy check, the relative percentage of HALs against the PPTs show as follows — with PPT2 (55%), PPT14 (19%), PPT15 (4%), PPT27 (18%), and PPT22 (4%). Overall, out of 29, only 5 PTs (17%) show high receptiveness towards these ligands. This information is crucial to create the DUD-E data mining and data modeling (DDM). After redundancy check, DB that have contributed in extracting maximum information are ADFR (rank1), DOCK (rank2), Gemdock (rank3), Ledock (rank4), Plants (rank5), Psovina (rank 6), Quickvina2 (rank 7), and Vina (rank 8).H)After max–min normalization, the affinities are shown under “Norm_Affinity” column in Table 12 below.Table 12Final set of PPTs obtained based on HALs

It is evident that the PPTs are PPT2 (Rank 1), PPT 14 and PPT27 (Rank 2), and PPT15 and PPT22 (Rank 3) as three independent clusters. Ideally, the clustering should affect three big clusters — 2, 14, and 27, as is attempted in ML application below. It is important to note that ranking of PPTs need to be validated also. Hence, KMC, which is one of the most popular clustering techniques, is chosen as an efficient ML technique.

Final set of PPTs obtained based on HALs

## Section: Methodology › Approach I: data mining and data modeling (DDM) — ‘forward Modeling’ › Dependency

It seems that target proteins are “dependent” on each other (Pearson’s correlation test = 0.970, p-value < 0.05), i.e., mostly linearly correlated (refer to Fig. 1).Fig. 1Correlation heatmap

Correlation heatmap

Distribution plot

## Section: Methodology › Approach I: data mining and data modeling (DDM) — ‘forward Modeling’ › Dependency

In Fig. 1, most PTs (indicated by Ts in the figure) show positive correlations with values close to 1 (0.970) as seen in the color trackers (heat map equivalent).

Figure 2 is representative of PTs distributed over a normal distribution profile.Fig. 2Distribution plot

Distribution: None of the target proteins have symmetrical Gaussian distributions (Shapiro–Wilk test stat (W) = 0.560, p value < 0.05, CI = 95%).

Next, three clustering techniques, e.g., KMC, GMM, and DBSCAN, are used as the efficient and popular unsupervised machine learning (ML) techniques to cross-validate the results, especially the number of clusters obtained and noise (outlier) handling through the above-mentioned rigorous data mining exercise on HPC.

Distribution plot

## Section: Methodology › Approach II: machine learning (ML) — for ‘automation’ and ‘reverse modeling’

The objective here is to test the correctness of manual data mining (DDM) results, accommodate the PPT outliers (PPT15 and PPT22 in Table 12), and then automate the process of predicting possible PPTs for a given set of test HALs. For this purpose, ML has been considered; more specifically, KMC has been chosen as one of the most popular clustering techniques [22–24]. From KMC, 3 good clusters (note, as indicated earlier, we already expected 3 clusters from max–min normalization) are targeted in line with the same number from DDM (refer to Table 12). Good clusters are defined as the ones with spherical conformation, that do not overlap, and have no outliers; i.e., all Ls can be accommodated within the clusters. Moreover, in this framework, KMC (an unsupervised ML method as the DUD-E data is unlabeled) can automate the PPT prediction process with reasonable accuracy. As mentioned above, two other clustering techniques, such as GMM and DBSCAN, are used to validate the output of KMC.

Inertia values to predict correct number of clusters

Iterations versus number of clusters. Iteration 0th, 5 clusters (0–4) and its corresponding number of Ls (total 400):

Centroids based on affinity magnitudes of 400 HALs corresponding to 29 PTs

Euclidean distances of each of the 26 test Ls of test data ‘A’ from centroids of each cluster

Mapping HALs to the corresponding PPTs — ‘reverse modeling’

Three distinct clusters with centroids obtained with KMC

Validation of relationships among HAL test data “A” and PPTs based on clusters

Validation of relationships among HAL test data “B” and PPTs based on clusters

Validation of relationships among HAL test data “C” and PPTs based on clusters

Three distinct clusters with centroids obtained by GMM method

The ‘eps’ value obtained by DBSCAN method

Number of clusters and noise for the dataset printed on Python 3.11.1 IDLE Shell installed on 06/12/2022 in the win32 64 bits system

## Section: Methodology › Approach II: machine learning (ML) — for ‘automation’ and ‘reverse modeling’ › KMC: the steps are given below.

Step 1: Data scaling is done for 40 × 10, i.e., 40 APs each from 10 DB under study. Hence, 400 AP L-set is taken as the step for data wrangling/preprocessing.

Step 2: Calculating inertia to find the initial number of clusters. Essentially, it is the sum of squared error (SSE) for each cluster. Hence, the denser the cluster, the smaller is the inertia. Because inside the desired cluster data points are closest to each other, low values for inertia are meaningful.

In Fig. 3, the calculated value of inertia, obtained iteratively over 3 clusters, shows up as 494.5 that is adequately low. However, across all 3 clusters, the step counts are monotonous with not much difference in inertia values. Therefore, the initial number of clusters is considered to be 5 and the aim is to further iterate towards a suitable convergence when all the data points are accommodated inside the final (reduced) number of clusters. The iterative convergence shown below assumes 5 initial clusters. Table 4 below shows the convergence rate of the clusters against the number of iterations performed (Fig. 4).Fig. 3Inertia values to predict correct number of clustersFig. 4Iterations versus number of clusters. Iteration 0th, 5 clusters (0–4) and its corresponding number of Ls (total 400):1 3202 400 313 84 1

Observation: One plus eight, i.e., total 9 data points, are considered as the outliers as because in comparison to other clusters, its counts are very low. Hence, the aim is to accommodate these outliers within their neighboring clusters.

Iteration 96th, 4 clusters:1 3202 400 393 1

Observation: 8 earlier outliers are accommodated inside the first cluster. The fourth cluster still has one data point and is considered as an outlier. Our aim is to accommodate this into the neighboring cluster to get compact clusters without any outlier, an accepted quality assurance of any good clustering technique.

Iteration 105th, 3 clusters:1 321 (80.25%)2 40 (10.00%)0 39 (09.75%)

Observations: Remaining data points at the fourth cluster have been successfully accommodated into cluster 2. After this iteration, no further change in the number of clusters and corresponding Ls is found.

Summary: A set of 400 × 29 data matrix of “ligands affinity (LA)” (rows) and “active protein target (APT)” (columns) can be partitioned efficiently into 3 distinct (un-overlapped) spherical clusters without any outlier. Therefore, the quality of clustering is good.

Step 3: Centroid calculation (training data): These are final centroids as with further iterations, its values are not changing anymore (refer to Table 13):Table 13Centroids based on affinity magnitudes of 400 HALs corresponding to 29 PTsPT1PT2PT3PT4PT5…PT25PT26PT27PT28PT29C10.41950.41670.43990.43260.4417…0.37120.28730.41200.22840.4381C2 − 2.8644 − 2.8335 − 2.7851 − 2.8103 − 2.7481… − 2.3875 − 2.7718 − 2.1523 − 2.3501 − 2.7525C3 − 0.5149 − 0.5237 − 0.7641 − 0.6784 − 0.8172… − 0.60650.4779 − 1.18330.5301 − 0.7832

Table 3 shows distinct values such as (− 2.***), (− 0.***), and (0.4***) for three clusters (Tables 14 and 15).Table 14Euclidean distances of each of the 26 test Ls of test data ‘A’ from centroids of each clusterTable 15Mapping HALs to the corresponding PPTs — ‘reverse modeling’

Step 4 (Visualization): 3 distinct clusters with centroids as black dots in Fig. 5. Here, “0” denotes cluster 1, “1” refers to cluster 2, and “2” signifies cluster 3.Fig. 5Three distinct clusters with centroids obtained with KMC

It is interesting to see from the centroids thus obtained that cluster 2 contains most of the ligands (80.25%), followed by cluster 3 (10%) and cluster 1 (9.75%). This observation can be logically mapped to the findings from data mining that predict “high” affinity ligands with tendency to bind with APT2 (63%), APT14 (19%), and APT27 (18%). Hence, it can be safely concluded that cluster 2 is probabilistically expected to contain the maximum number of high affinity ligands (HALs) towards APT2. Cluster 3 is the next candidate with the maximum number of high affinity ligands pointing towards APT14, while cluster 1 data points are high affinity ligands targeted for APT27. We can conclude that of the 29 APTs considered, these three are the prime protein targets (PPTs). This observation needs to be validated by going back to the original test data set, which has been performed below (refer to Tables 16, 17 and 18). It should be borne in mind that for other L-sets, these PPTs may vary. Table 16Validation of relationships among HAL test data “A” and PPTs based on clustersTable 17Validation of relationships among HAL test data “B” and PPTs based on clustersTable 18Validation of relationships among HAL test data “C” and PPTs based on clusters

Step 5: Validation on test L-sets (A, B, C), i.e., the reverse modeling:

Test L-sets have been selected from the given 400 HAL DB randomly — first 26 Ls from the “tail” of HAL test data (L-set A), second set of 26 Ls from the “middle” portion of the HAL test data (L-set B), and third set of 26 Ls are taken from the “head” of the HAL test DB (L-set C).

Euclidean distances (ED) of each of the ligands from the centroids have been computed. Each ligand is clustered (refer to Table 14) based on minimum distance (red colored cells) from the centroid. Using maximum affinity as the descriptor, HALs are mapped against the original data to identify the corresponding PPTs (refer to Table 15) and then evaluated for possible PPTs within the cluster, as shown in Tables 14 through 16. Table 15 shows corroborating HPC obtained by clustering (refer to Table 16).

Other HPC obtained by test data “B” and “C have also been corroborated in the similar way.

From the above experiments, we conclude that PPT2 (average HPC is 41.1%) is the highest ranked protein target as most HALs show high affinity towards it. PPT2 is followed by PPT14 (average 25.46%), and then PPT15 (average 23.12%).

Prime HAL information: (test set “A” — 26 data (375–400) picked from the tail of 400 total ligands; test set “B” — 26 data (251–276) picked from the middle portion of 400 total ligands; and test set “A” where 26 data (1–26) picked from the head of 400 total ligands.

Test set “A”: Ligand numbers 379, 380, 381, and 392 (15%) have maximum affinity towards PPT 14 (11%) and 15 (4%), respectively.

Test set “B”: Ligand numbers 259, 260, and 261 (11%) have maximum affinity towards PPT 14.

Test set “C”: Ligand numbers 12, 14, and 17 (11%) have maximum affinity towards PPTs 27, 27, and 2, respectively.

Therefore, out of 26 × 3 = 72 test ligands, 14% are found to be HALs, which gives a clue to the percentage of HALs that can be obtained from any number of ligands, which is another outcome of this work. For obvious reasons, though, the percentage may vary with the dataset.

It is important to note that the above analysis cannot qualify for the ranking of HALs as well as PPTs. It can only predict the key HPCs numerically and cannot argue for qualitative ranking, which requires domain expertise and in-vitro/vivo experimental analysis of individual HPCs.

Below, we validate the performance of KMC using two other clustering methods, GMM and DBSCAN.

Inertia values to predict correct number of clusters

Iterations versus number of clusters. Iteration 0th, 5 clusters (0–4) and its corresponding number of Ls (total 400):

Centroids based on affinity magnitudes of 400 HALs corresponding to 29 PTs

Euclidean distances of each of the 26 test Ls of test data ‘A’ from centroids of each cluster

Mapping HALs to the corresponding PPTs — ‘reverse modeling’

Three distinct clusters with centroids obtained with KMC

Validation of relationships among HAL test data “A” and PPTs based on clusters

Validation of relationships among HAL test data “B” and PPTs based on clusters

Validation of relationships among HAL test data “C” and PPTs based on clusters

## Section: Methodology › Approach II: machine learning (ML) — for ‘automation’ and ‘reverse modeling’ › The GMM clustering method

Working principle: It assumes that all data points originate from a finite number of Gaussian distributions with unlabeled/unknown parameters. Hence, it is a probabilistic unsupervised ML model.

Observation: The clusters are plotted similarly as KMC to retain visual uniformity (see below figure). The blue colored dataset makes cluster 1 (contains 321 datasets), while clusters 2 and 3 are represented in yellow and green colors, respectively, containing 40 and 39 datasets. The centroid properties are also identical to KMC. It is important to note that similar to the KMC method, cluster 2 is probabilistically expected to contain the maximum number of HALs towards APT2. Cluster 3 is the next candidate with the maximum number of HALs pointing towards APT14, while cluster 1 data points are high affinity ligands targeted for APT27. We can conclude that of the 29 APTs considered, these three are the prime protein targets (PPTs) as already identified by KMC.

Summary: A set of 400 × 29 data matrix of LA (rows) and APT (columns) can be partitioned efficiently into 3 distinct (un-overlapped) spherical clusters without any outlier using GMM method (Fig. 6).Fig. 6Three distinct clusters with centroids obtained by GMM method

Three distinct clusters with centroids obtained by GMM method

## Section: Methodology › Approach II: machine learning (ML) — for ‘automation’ and ‘reverse modeling’ › The DBSCAN clustering method

Working principle: The algorithm identifies the group of data points based on the assumption that the data points inside the respective cluster belong to distinct contiguous density of higher priority points that are separated from a distinct contiguous density of relatively lower priority points. The algorithm can cluster a high-volume dataset having errors and noise within the dataset and thus algorithmically superior to KMC and GMM algorithms. Moreover, DBSCAN does not require initialization of cluster number and thus do not come across over and under-fitting issues of clustering and faster than that of KMC and GMM. Since KMC and GMM may cluster low-priority data points, alongside GMM, we have implemented DBSCAN for cross-validation of KMC and GMM-based outputs.

DBSCAN requires two parameters: (i) “epsilon (eps),” the least distance between two neighboring points, and (ii) “MinPoints (Mpt),” the minimum number of data points required to construct a cluster. For our data points, “‘Mpt” is calculated as 2* data dimension, i.e., 2 * 29 = 58, while “eps” is calculated from the distance plots (refer to Fig. 7). From the figure, it is noted that maximum curvature (least distance) occurs at 96 (refer to the y-axis), which is our “eps” to run the algorithm.Fig. 7The ‘eps’ value obtained by DBSCAN method

Observation: With the above “eps” and “‘Mpt” values, DBSCAN can yield one cluster but there are 80 outliers. It is most probably due to varying density among the data points within our high-dimensional data. Hence, we have discarded DBSCAN in this work (see Fig. 8).Fig. 8Number of clusters and noise for the dataset printed on Python 3.11.1 IDLE Shell installed on 06/12/2022 in the win32 64 bits system

The ‘eps’ value obtained by DBSCAN method

Number of clusters and noise for the dataset printed on Python 3.11.1 IDLE Shell installed on 06/12/2022 in the win32 64 bits system

## Section: Discussions

Ten years is a typical gestation time for a new drug to hit the market. Clinical trials alone take six to seven years on average. The average cost towards each successful drug is estimated at $2.6 billion [23] (http://phrma-docs.phrma.org/sites/default/files/pdf/rd_brochure_022307.pdf). The failure rate of a new drug to reach the market is around 88%, which means only 12% of projected drug candidates are eventually marketed as genuine drugs (http://phrma-docs.phrma.org/sites/default/files/pdf/rd_brochure_022307.pdf), notwithstanding such high expense. Failure can happen due to various causes starting from a wrong choice of PTs and Ls and its combinations at the experimental stage in the laboratory to regulatory stringencies and finally adoption by the healthcare workers and the end users. Any successful new drug must have high efficacy, low dosing, rapid actions, and only a few side effects. It should also be able to reduce the morbidity load, cost of hospitalization, and curb mortality. The key to time and cost conducive delivery is thus fast and accurate identification and validation of PPTs and the HALs that can efficiently combine with each other to give a stable molecule that helps designing an effective drug. This is where intelligent, machine learned, molecular docking can make the crucial difference between success and failure, and certainly in taming cost.

This work is an attempt to detect PPTs for a given sample of HALs on 10 L-sets, each obtained from standard DOCKING programs. The approach complements a recent benchmark [21] where a novel statistical combination, popularly called consensus scoring (CS), was used to predict the PPTs for the same dataset. The present independent approach provides a validation of the outcomes from that work as also in terms of being risk validated itself from this verification. DDM is done on ALs (decoys are discarded), and based on their individual receptiveness to Ls or agents, our probabilistic model predicts PPT2 (55%), PPT14 (19%), PPT27 (18%), PPT15 (4%), and PPT22 (4%) as the most promising PTs out of 29 choices; i.e., only 17% of the PTs show high receptiveness as prime targets to the agents.

As the DB is unlabeled, KMC has been applied as an ML technique to test the efficiency of the above DDM approach. KMC can produce 3 distinct clusters. To validate the observations of DDM, the neighborhood of each ligand in all three test samples is measured from the centroids of each cluster. It is evident that PPT2 (average possibility of getting stable HPC is 41.1%) is the highest ranked among all, as most HALs show high affinity towards it; followed by PPT14 (rank-2 average 25.46%), and then PPT15 (rank-3 average 23.12%), respectively. The result is further validated by GMM and found to be similar as KMC. Thus, KMC provides a rigorous DDM approach that can be automated to generate faster and accurate drug prediction routines. Importantly, for pursuing this approach, large training samples are not necessary as this is a “sparse classifier.” This method can be used in new sets of Ls-PTs from DB to identify PPTs towards successful laboratory tasting of real drugs.

## Section: Discussions › Advantages of the method:

The algorithm does not require large training (macro-supervised learning not needed) of DB due to its efficient redundancy handling algorithm around the maximum of the mean affinity.DDM and KMC-based ML complement each other in terms of accuracy and speed, thus, reducing the time taken to discover right PTs/drug candidates.The method does not require complex computations.This method can efficiently handle sparse unlabeled data having noise.This method is also cost-efficient as it only requires moderate computation, not chemical samples.

## Section: Discussions › Limitations of the work and hence the targeted future research are as follows:

This work focuses only on ALs; decoys are discarded. In future, similar approaches can be adopted even for the decoys to validate whether these agents are genuine decoys.Other clustering techniques (such as fuzzy C-means clustering (FCM) technique) could also be used in identifying PPTs, which have overlapping binding features with Ls.


---

# Federated electronic health records for the European Health Data Space

- **Authors:** René Raab, Arne Küderle, Anastasiya Zakreuskaya, Ariel D Stern, Jochen Klucken, Georgios Kaissis, Daniel Rueckert, Susanne Boll, Roland Eils, Harald Wagener, Bjoern M Eskofier
- **Issuer:** The Lancet. Digital health
- **Type:** Scientific article
- **Published:** 2023-09-21
- **Language:** en
- **DOI:** 10.1016/s2589-7500(23)00156-5
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37741765/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

The European Commission's draft for the European Health Data Space (EHDS) aims to empower citizens to access their personal health data and share it with physicians and other health-care providers. It further defines procedures for the secondary use of electronic health data for research and development. Although this planned legislation is undoubtedly a step in the right direction, implementation approaches could potentially result in centralised data silos that pose data privacy and security risks for individuals. To address this concern, we propose federated personal health data spaces, a novel architecture for storing, managing, and sharing personal electronic health records that puts citizens at the centre-both conceptually and technologically. The proposed architecture puts citizens in control by storing personal health data on a combination of personal devices rather than in centralised data silos. We describe how this federated architecture fits within the EHDS and can enable the same features as centralised systems while protecting the privacy of citizens. We further argue that increased privacy and control do not contradict the use of electronic health data for research and development. Instead, data sovereignty and transparency encourage active participation in studies and data sharing. This combination of privacy-by-design and transparent, privacy-preserving data sharing can enable health-care leaders to break the privacy-exploitation barrier, which currently limits the secondary use of health data in many cases.


---

# Generalizability of machine learning methods in detecting adverse drug events from clinical narratives in electronic medical records

- **Authors:** Md Muntasir Zitu, Shijun Zhang, Dwight H Owen, Chienwei Chiang, Lang Li
- **Issuer:** Frontiers in pharmacology
- **Type:** Scientific article
- **Published:** 2023-07-12
- **Language:** en
- **DOI:** 10.3389/fphar.2023.1218679
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37502211/
- **Licence:** CC-BY

## Section: Abstract

AbstractWe assessed the generalizability of machine learning methods using natural language processing (NLP) techniques to detect adverse drug events (ADEs) from clinical narratives in electronic medical records (EMRs). We constructed a new corpus correlating drugs with adverse drug events using 1,394 clinical notes of 47 randomly selected patients who received immune checkpoint inhibitors (ICIs) from 2011 to 2018 at The Ohio State University James Cancer Hospital, annotating 189 drug-ADE relations in single sentences within the medical records. We also used data from Harvard’s publicly available 2018 National Clinical Challenge (n2c2), which includes 505 discharge summaries with annotations of 1,355 single-sentence drug-ADE relations. We applied classical machine learning (support vector machine (SVM)), deep learning (convolutional neural network (CNN) and bidirectional long short-term memory (BiLSTM)), and state-of-the-art transformer-based (bidirectional encoder representations from transformers (BERT) and ClinicalBERT) methods trained and tested in the two different corpora and compared performance among them to detect drug–ADE relationships. ClinicalBERT detected drug–ADE relationships better than the other methods when trained using our dataset and tested in n2c2 (ClinicalBERT F-score, 0.78; other methods, F-scores, 0.61–0.73) and when trained using the n2c2 dataset and tested in ours (ClinicalBERT F-score, 0.74; other methods, F-scores, 0.55–0.72). Comparison among several machine learning methods demonstrated the superior performance and, therefore, the greatest generalizability of findings of ClinicalBERT for the detection of drug–ADE relations from clinical narratives in electronic medical records. Keywords: adverse drug events, electronic health records, machine learning, natural language processing, relation extraction

## Section: 1 Introduction

Adverse drug events (ADEs) are unintended harmful effects of taking medication (Hohl et al., 2018), which is a leading cause of death in the United States (Classen et al., 1997; Binkheder et al., 2022) and responsible for the hospitalization of 9,440,757 patients from 2008 to 2011, with an increasing trend over time (Poudel et al., 2017). The estimated annual cost of drug-related morbidity and mortality resulting from non-optimized medication therapy was $528.4 billion, equivalent to 16% of total US healthcare expenditures, in 2016 (Watanabe et al., 2018). Patients with ADEs have demonstrated significantly longer hospital stays and an almost two-fold greater risk of death than patients without ADEs (Classen et al., 1997). Nevertheless, ADEs are mostly preventable (Rommers et al., 2007), and early detection can substantially reduce morbidity and, thereby, decrease associated healthcare costs (Classen et al., 1997; Kaushal et al., 2006; Handler et al., 2007).

ADEs are largely detected after marketing, so timely surveillance at this time is important for patient safety (Botsis et al., 2011; Polepalli Ramesh et al., 2014). Pharmacovigilance has traditionally employed spontaneous reporting systems (SRSs), but as many as 90% of ADEs may remain unreported in this voluntary scheme (Hazell and Shakir, 2006). In contrast, electronic health records (EHR) represent a potentially great source for post-marketing surveillance of drug safety, accommodating real-time clinical data gathered from routine clinical care (Coloma et al., 2013). One study revealed relevant ADE information, for example, in the structured data of 9,020 of 31,531 patients (28.6%) with side effects of statin documented in provider notes (Skentzos et al., 2011). Furthermore, clinical notes in EHRs provide longitudinal information related to drug-induced adverse events, but the manual review and extraction of ADEs from enormous clinical narratives is labor intensive, and clinical notes in EHRs vary from patient to patient, physician to physician, and hospital to hospital. Therefore, an automated system that utilizes artificial intelligence (AI) is needed to extract ADEs from clinical notes, and attempts have been made to build such a system.

The Medication and Adverse Drug Events Challenge (MADE1.0) (Jagannatha et al., 2019) aimed to automatically identify clinical concepts and relations from clinical narratives that included ADEs. The Challenge included three tasks: 1) naming the recognized entity (NER) and identifying the medication and its route, dosage, duration, frequency, and indication, as well as associated ADEs and their severity; 2) identifying relations (RI) of medications with ADEs, indications, and other entities; and 3) performing the NER and RI tasks jointly. The Challenge released 1,089 fully de-identified clinical notes from 21 randomly selected patients with cancer at the University of Massachusetts Memorial Hospital that included 2,612 drug–ADE relations. Methods used to classify relations ranged from statistical machine learning (ML)-based methods, such as support vector machine learning (SVM), random forest, and others, to neural-network-based bidirectional long short-term memory (BiLSTM). The best-performing model for the classification of ADE–drug name relations achieved an F-score of 0.72.

Another effort, the n2c2 Shared Task Challenge (Henry et al., 2020), mirrored MADE1.0 and included similar tasks. The n2c2 dataset comprised 505 discharge summaries taken from the Medical Information Mart for Intensive Care-III (MIMIC-III) clinical care database (Johnson et al., 2016). Records were selected by searching ADEs in the International Classification of Diseases (ICD) code descriptions of the records, which yielded a total of 1,840 ADE-drug relations. Methods used for the relation-classification task ranged from SVM to attention-based BiLSTM, with the best-performing model for ADE-drug name relation yielding an F-score of 0.85.

The use of data from a single EHR source in the two challenges allowed NLP approaches developed from these models to be data-specific. The model that performed the best (Wei et al., 2020) in relation extraction for the n2c2 Shared Task, for example, contained a post-processing technique that was dependent on the n2c2 annotation guideline to improve the performance of their BiLSTM conditional random field (CRF) algorithm. This n2c2 paper (Wei et al., 2020) also suggested that language models like BERT (Devlin et al., 2018) in the biomedical domain may further improve the NLP performance, and it remains to be an interesting topic for future research. In the best-performing model (Chapman et al., 2019) from the MADE 1.0 Challenge, the best model was random forest. The paper (Chapman et al., 2019) stated that generalizability of the best-performing model was unclear.

Though transformer-based methods like BERT (Devlin et al., 2018), BioBERT (Lee et al., 2020), and ClinicalBERT (Alsentzer et al., 2019) have become popular in recent years, they have not been applied to identify ADEs from the clinical notes of EHRs. Therefore, it is critical to implement the same model on data from different data sources to assess the generalizability of a model. No study has been conducted yet that used EHRs from different data sources to address the issue of generalizability. BERT-based methods have performed better than other machine and deep learning methods (Sun et al., 2019; González-Carvajal and Garrido-Merchán, 2020; Minaee et al., 2022) in mining biomedical texts, and methods that integrate biomedical corpora, such as ClinicalBERT, outperformed BERT models (Huang et al., 2019). In this article, we investigate the performance of deep learning (CNN, BiLSTM) and transformer-based (BERT and ClinicalBERT) methods, as well as classical SVM, in clinical notes of two different EHR systems.

The preprocessing of data is important in NLP in clinical text and challenged by the inherent variations in EHRs, and the preprocessing of clinical text in EHRs, such as tokenization, which breaks the text into meaningful elements and detects sentence boundaries, is different and more challenging than the processing of data in the literature (Griffis et al., 2016). Publications often inadequately present the end-to-end data preprocessing method, but in this paper, we sufficiently detail the end-to-end data preprocessing for all NLP methods used.

Our primary goal is to address whether and how ADE NLP algorithms developed from the n2c2 Shared Task can be generalized to a drug-specific ADE in a different EHR. There are two types of generalizability in the NLP algorithm development for detecting drug-induced ADEs. First, we want to know whether the NLP model developed in one dataset maintains a comparable performance in a different dataset. Second, if one NLP method has a better performance than the others, will it maintain its supreme performance in a different dataset? In this paper, we study both types of generalizability for NLP algorithms designed for drug–ADE relationship detection. We will use ADEs induced by immune checkpoint inhibitors (ICI) (Nashed et al., 2021) as recorded in clinical notes as examples for analysis. MADE1.0 (Jagannatha et al., 2019) data were not available to us when we conducted this study.

## Section: 2 Materials and methods

Annotation example for different entities in the ICI-OSU corpus.

ICI-OSU data processing pipeline. Python and C++ programming were used at different steps to automate the process.

List of drug names and adverse drug events. We used all possible mentions of these drugs and ADEs in our study.

(A) Input text processing from single-sentence drug–ADE relation. (B–F) Implementation details of (B) SVM, (C) BiLSTM, (D) CNN, (E) BERT, and (F) clinicalBERT models.

## Section: 2 Materials and methods › 2.1 Datasets

We used two datasets to analyze the generalizability of ADE detection from EHRs; one was developed from the EHR system of The Ohio State University James Cancer Hospital, and the second was that of the n2c2 Shared Task (Henry et al., 2020).

## Section: 2 Materials and methods › 2.2 ICI-OSU corpus

We built the ICI-OSU corpus by manually annotating 1,394 clinical notes of 47 randomly selected patients who received immune checkpoint inhibitors (ICIs) from 2011 to 2018 at The Ohio State University James Cancer Hospital. Supplementary materials contain a detailed annotation guideline that we developed to assist the annotators with manual annotation. Supplementary Table S1 contains the annotation guideline for entity annotation, whereas Supplementary Table S2 contains the guideline for relation annotation. Figure 1 shows different types of entity tags and relation annotations.

The entities included drug names, mentions of ADEs, dates drugs were taken, dates of ADEs, terms drawing causal relation between a drug and an ADE, and grades of ADE intensity. It is worth mentioning that reasons for drug administration were not considered as ADEs. Supplementary Figure S1 shows the difference between ADE and reason for drug administration with an example. Relations were annotated for entities located within a single sentence and across sentences. Two annotators with informatics skills and knowledge in cancer clinical trials independently annotated each note, and a third annotator performed the validation for inconsistent annotations between the two annotators. One annotator was a resident physician with hands-on experience with EHRs; the second had a master’s degree in biology with 7 years of experience in corpus development and annotation; the third annotator, who performed the validation, was a graduate student in biomedical informatics. The institutional review board of The Ohio State University approved this study (#2020C0145).

Annotation example for different entities in the ICI-OSU corpus.

## Section: 2 Materials and methods › 2.3 ICI-OSU data processing pipeline

Figure 2 illustrates the data processing pipeline we built that feeds processed data to the ADE NLP models for generalizability analysis.

In the first step, we collected the clinical notes of the targeted patient. The ICI-OSU corpus contains the patient’s notes for the first 12 months from the date of the first ICI dose in the structured data. The order of note dates is maintained to keep track of longitudinal data, such as the date of first drug use, date of first ADE, and date of drug discontinuation.

In the second step, we cleaned data using regular expression techniques (Wang et al., 2019), which included but were not limited to normalizing uneven spaces and drug names and manipulating abbreviations. For drug name normalization, we used the DrugBank database (Wishart et al., 2008) as our primary source, and we built a lookup table that contained all possible mentions (such as the generic and brand name) of a drug. Supplementary Figure S2 shows a raw original clinical note, and Supplementary Figure S3 shows the cleaned data.

In the third step, we performed automatic screening for drugs and ADEs, tagging predefined drug and ADE terms for follow-up manual annotation. Table 1 delineates the drug names and the ADE list of our study. We used the Common Terminology Criteria for Adverse Events (CTCAE) (Freites-Martinez et al., 2021) and the DrugBank database as our primary guidelines for ADE and drug mentions, respectively. Then, we built a lookup table for screening that contained all possible mentions of these drugs and ADEs found in EHRs. We discussed with a physician and annotators who had hands-on experience working with EHRs, thus enriching and verifying our lookup table to ensure accuracy.

In the fourth step, we used the Apache clinical Text Analysis and Knowledge Extraction System (cTAKES)™ (Savova et al., 2010), an open-source NLP tool, to segment sentences in the EHRs, which is one of the most challenging tasks because of variations, such as in use of punctuation and abbreviations, that are unique to the recorder (Griffis et al., 2016). To optimize cTAKES™ performance on sentence segmentation, we also encrypted the unexpected line breakers to be consistent with the cTAKES™ segmentation rules. After segmentation, we decrypted the data to preserve their originality. Supplementary Figure S4 shows the data’s appearance after sentence segmentation in cTAKES™.

In the fifth step, we performed automatic de-identification using de-identification software (Neamatullah et al., 2008) from PhysioNet (Goldberger et al., 2000) followed by manual de-identification by the annotators to ensure accuracy. The recall value of PhysioNet was over 98% in the de-identification task on our dataset. Supplementary Figure S5 shows the data after de-identification.

In the sixth step, we performed automatic tagging, annotating the drug name, mention of ADE, and date of ADE, to reduce the burden of subsequent manual annotation. For drug and ADE annotation, we performed exact matching of the data with our predefined drug and ADE lists. We used a rule-based method to annotate the dates in the clinical text automatically, and this annotation was consistent with that of the web-based brat rapid annotation tool (BRAT) (Stenetorp et al., 2012), which we used later for manual annotation. Though automatic annotation greatly reduced the burden of manual annotation, the annotators were free to annotate any new form of a drug name, mention of ADE, or date of ADE. The annotators could also correct anything incorrectly tagged in automatic tagging. Supplementary Figure S6 shows the automatically annotated notes.

In the seventh step, our annotators performed manual annotation in BRAT following the well-defined guideline mentioned previously and included in the supplementary materials. Supplementary Figure S7 shows the manually annotated notes.

In the eighth and final step, we extracted relevant annotation information automatically after manual annotation to build our corpus. Information extracted to prepare the data for machine learning models included drug–ADE relations, drug–ADE pairs, and neighboring words. We built an automatic system to extract that information from the annotated corpus based on the input format of the ML models. Due to the repetitive nature of EHRs, several drug–ADE relations were repeated when the text between a drug and an ADE, as well as the context, were exactly the same. We removed those duplicates in the automatic extraction.

ICI-OSU data processing pipeline. Python and C++ programming were used at different steps to automate the process.

List of drug names and adverse drug events. We used all possible mentions of these drugs and ADEs in our study.

## Section: 2 Materials and methods › 2.4 n2c2 Shared Task corpus

The n2c2 data consisted of information from 505 discharge summaries taken originally from the MIMIC-III clinical care database (Johnson et al., 2016). The data provider described their process as first searching for ADEs in the ICD code description of each record and then manually screening the records with at least one ADE and dividing the data into a training set comprising 303 annotated files and a testing set that included 202 files (Henry et al., 2020). The n2c2 data contained several clinical concepts and relations as well as drug and ADE annotations, and we performed preprocessing as described previously to prepare the data for the ML models, first cleaning the n2c2 data, then segmenting sentences using cTAKES™, and finally using our automatic system to extract relevant annotations.

## Section: 2 Materials and methods › 2.5 The definition of positive and negative drug–ADE relations in the n2c2 and ICI-OSU corpora

Like other researchers (Wei et al., 2020), we considered all possible combinations of drugs and ADEs to build positive and negative data for training and validating NLP models. Our generalizability analysis focused on drug–ADE relations within a single sentence; so, for example, for a sentence containing the drugs d1 and d2 and the ADEs a1 and a2, the four possible drug–ADE combinations are (d1, a1), (d1, a2), (d2, a1), and (d2, a2). A drug–ADE relation was considered positive if the drug induced the ADE. We collected the positive samples directly from annotation to build the positive dataset. A relation was considered negative if the drug did not induce the ADE and was, therefore, not annotated in the corpus. We derived the negative dataset from all the drug–ADE combinations by subtracting the annotated positive set from the corpus. After removing duplicates, we obtained 189 positive samples and 698 negative samples from our annotated ICI-OSU data. The default n2c2 training and test data yielded 1,355 positive and 865 negative samples after duplicates were removed.

## Section: 2 Materials and methods › 2.6 Machine learning deep learning models

We implemented several machine learning, deep learning, and transformer-based models, including SVM (Joachims, 1998), CNN (Kim, 2014), BiLSTM (Sherstinsky, 2018; Xu et al., 2019), BERT (Devlin et al., 2018), and ClinicalBERT (Alsentzer et al., 2019), to analyze the n2c2 and ICI-OSU datasets, and we trained these models on one dataset and validated them on the other to analyze the generalizability of their findings.

(A) Input text processing from single-sentence drug–ADE relation. (B–F) Implementation details of (B) SVM, (C) BiLSTM, (D) CNN, (E) BERT, and (F) clinicalBERT models.

## Section: 2 Materials and methods › 2.6 Machine learning deep learning models › 2.6.1 Training and validation data

Training and validation data were speculated under the intra- and inter-dataset settings. The intra-dataset setting comprised training and validation data allocated from the same data source, either n2c2 or ICI-OSU. When training and validating the model on the same n2c2 dataset in the intra-set setting, we used the default training and validation data of the n2c2 dataset given by the data providers. Because the ICU-OSU dataset was relatively smaller, we applied five-fold cross-validation to avoid overfitting when we trained and validated our model on the same ICU-OSU dataset in the intra-set setting. In the inter-set setting, training was performed on one dataset, and its validation was performed in the other. We also withheld 30 percent of the data from the training set to serve as the internal validation set in the inter-dataset setting.

## Section: 2 Materials and methods › 2.6 Machine learning deep learning models › 2.6.2 Hyperparameter selection and embedding

In the deep learning and transformer-based models, we studied different dropout rates ranging between 0.1 and 0.8 and learning rates (0.1, 0.01, 0.001, and 0.0001) with batch sizes of 16, 32, and 64. In those models, we used embedding (Mikolov et al., 2013) techniques and pre-trained word-embedding models, such as Stanford’s global vectors for word representation (GloVe) (300-dimensional) (Pennington et al., 2014). In our transformer-based model, we also incorporated biomedical domain knowledge.

## Section: 2 Materials and methods › 2.6 Machine learning deep learning models › 2.6.3 Preparation of input data, feature selection, and model implementation

We focused on the contextual features while building the models. Because the text between a drug and an ADE contains most of the contextual information regarding a drug–ADE relation, we considered the drug name, the ADE, and the text between them as the input for all models. However, feature selection varied from model to model. Our SVM model, for example, used character-level n-grams, whereas the CNN model considered n-grams at the token level. Figure 3A shows how we extracted the input text from a drug–ADE relation.

(A) Input text processing from single-sentence drug–ADE relation. (B–F) Implementation details of (B) SVM, (C) BiLSTM, (D) CNN, (E) BERT, and (F) clinicalBERT models.

## Section: 2 Materials and methods › 2.7 Implementation of the support vector machine model

We generated character n-grams from the first character of a sample to the last character of the input text using a range of values for n, converted those n-grams in term frequency (TF)-inverse document frequency (IDF) (Qaiser and Ali, 2018) vectorization, and then finally fed the feature vector into the model to predict the output y (0 or 1). We searched a range of values for c and gamma to obtain the best hyperparameter set and used the radial basis function (RBF) kernel in our SVM model. Figure 3B details the implementation of our SVM model with an example bigram.

## Section: 2 Materials and methods › 2.8 Bidirectional long short-term memory (BiLSTM)

Understanding the context of a sentence is critical and requires that classification of the sentence includes information in both directions, from the beginning of the sentence to its end and from its end to its beginning. Previous studies showed promising results using BiLSTM to extract contextual information (Xu et al., 2019). BiLSTM algorithms can learn long-term dependencies and work in both directions of text and learn contextual features in a given time stamp. For our model, the input was a sequence from the start to the end of an entity of a sample. Figure 3C shows the architecture of the BiLSTM model. We performed text vectorization on the input and then used the pre-trained word embedding of GloVe (300d) (Pennington et al., 2014) in the embedding layer. The BiLSTM layer was used over the embedding layer, and finally, the dense layer was used, producing the output, y.

## Section: 2 Materials and methods › 2.9 Convolutional neural network (CNN)

We implemented the standard CNN model (Kim, 2014), in which we focused on contextual information while extracting features. The CNN model applies a filter to extract features from text and uses those features to classify the text. As mentioned earlier, we used the text between the start of an entity and its end to analyze sequential words to learn features to extract. We used multiple filters of different sizes (2, 3, and 4) to examine different n-grams within the text. Figure 3D shows the architecture of the CNN model. We built a sentence matrix, with rows indicating the tokens of a sentence and columns indicating the features in which we implemented pre-trained word embedding. S n is the number of tokens in a sentence; S d is the feature dimension of a token; W h is the kernel size. We then applied weight filters for the convolution operation and feature mapping and, finally, applied max pooling and fully connected the output layer to generate output. We used the rectified linear unit (ReLU) activation function and the pre-trained word embedding of GloVe (300d) in the embedding layer (Pennington et al., 2014).

## Section: 2 Materials and methods › 2.10 Bidirectional encoder representations from transformers (BERT)

The BERT (Lee et al., 2020) model is based on a transformer encoder that uses a self-attention mechanism for sequence modeling (Vaswani et al., 2017). For our classification task, the sequential information of the text could be important. We selected a segment from the start to the end of an entity of a sample and then used the tokenized segment as input in the BERT model. The class token cls was added with the input. To obtain embeddings for our text, we used the pre-trained transformer model rather than an embedding layer. For our analysis, we used BERT-base, which consists of transformer blocks of 12 layers with 12 self-attention heads, a hidden size of 768, and 110 M trainable parameters (Lee et al., 2020). Figure 3E shows the architecture of the BERT model.

## Section: 2 Materials and methods › 2.11 ClinicalBERT

The implementation of the ClinicalBERT (Alsentzer et al., 2019) model was similar to that of our BERT model, but ClinicalBERT incorporated pre-trained biomedical domain knowledge. We used the model that was initialized on BioBERT (Lee et al., 2020) and trained on all notes of the MIMIC-III dataset (Johnson et al., 2016). The model had a batch size of 32 and a maximum sequence length of 128 (Alsentzer et al., 2019). Figure 3F shows the architecture of the ClinicalBERT model.

## Section: 3 Results

Annotation performance: we performed annotation in two rounds. In round one, we annotated 118 single-sentence positive drug–ADE relations and 24 cross-sentence positive drug–ADE relations. In round two, we labeled 163 single-sentence positive drug–ADE relations and 27 cross-sentence positive drug–ADE relations. Table 2 shows the average inter-annotator agreement (IAA) results of our two rounds of annotations. We calculated Cohen’s kappa (McHugh, 2012) to measure IAA. The results indicate considerable disagreement between the two annotators regarding the identification of drug–ADE relations, which is probably attributable to the diverse nature of ADE mentions in clinical notes. Supplementary Table S3 shows more annotation results and findings details of our corpus. Our OSU-ICI corpus is the first drug class-specific drug–ADE corpus. By specifically targeting ICIs, it also becomes a golden standard for developing immunotherapy-induced adverse event phenotypes.

Agreement between annotators.

Comparison of precision, recall, and F-score among different models in intra- and inter-dataset settings. (A, B) show the performance of the different machine learning models when trained and tested on the same data source (intra dataset). (C, D) show the performance of the different machine learning models when trained and tested on different data source (inter dataset).

Cluster maps of results comparing predicted labels with true labels for every sample of positive and negative classes in inter dataset settings. Yellow: predicted and true label matched; blue: labels did not match. (A, C) shows the results for positive class. (B, D) shows the results for negative class.

## Section: 3 Results › 3.1 Performance evaluation and error analysis

To analyze the generalizability of findings among the models, we trained and tested each model on the dataset of the same data source (intra-data) and a different source (inter-data). Figures 4A, B show the performance of the different models in the intra-dataset setting. The CNN-based deep learning model performed the best, with an F-score of 80% for the ICI-OSU dataset, whereas the transformer-based ClinicalBERT model achieved the best F-score (87%) for the n2c2 data. The SVM model was also competitive and showed stable performance in the intra-dataset setting. Our results demonstrate that we did not get the best performance from either the BERT or ClinicalBERT model when training and testing on the ICI-OSU dataset. This is probably because the transformer models usually perform better on a large dataset, and the ICI-OSU dataset is small. Figures 4C, D show the performance of the different models in the inter-dataset setting, with the transformer-based models showing superior performance. The ClinicalBERT model achieved the highest F-score in both combinations of inter-data training and testing, probably because of the incorporation of domain knowledge as ClinicalBERT was trained on the MIMIC-III dataset. These performances indicate the importance of incorporating domain knowledge in models. Figure 5 shows the cluster map for the results of different models in the inter-dataset setting. In this NLP analysis of four combinations of training sets and test sets from n2c2 and ICI-OSU datasets, it is evident that ClinicalBERT has the best performance in three out of four combinations.

Figures 5A, B show the cluster map while training on the n2c2 dataset and testing on the ICI-OSU dataset. The BERT and ClinicalBERT models performed similarly for positive sample prediction, whereas the SVM and BiLSTM models clustered together with similar results. BiLSTM and ClinicalBERT models performed similarly for negative sample prediction. Figures 5C, D show the cluster map while training on the ICI-OSU dataset and testing on the n2c2 dataset. The BERT and ClinicalBERT models performed similarly for both positive and negative sample prediction, and the SVM and BiLSTM models clustered together with similar results. Comparison of the results of Figures 4 and 5 demonstrates the better performances of the machine learning and deep learning models in the intra-dataset setting and of the transformer-based models in the inter-dataset settings. Along with the internal capacity of the models to recognize patterns, the variable length of the datasets might contribute to such performance. Supplementary Tables S4 and S5 further detail the results.

Comparison of precision, recall, and F-score among different models in intra- and inter-dataset settings. (A, B) show the performance of the different machine learning models when trained and tested on the same data source (intra dataset). (C, D) show the performance of the different machine learning models when trained and tested on different data source (inter dataset).

Cluster maps of results comparing predicted labels with true labels for every sample of positive and negative classes in inter dataset settings. Yellow: predicted and true label matched; blue: labels did not match. (A, C) shows the results for positive class. (B, D) shows the results for negative class.

## Section: 3 Results › 3.2 Factors contributing to error 1 (differences in data sources)

The n2c2 dataset was the more general of the two sets and looked for all drug mentions in a clinical note, whereas the ICI-OSU dataset focused on ICI drugs and annotated a specific set of ADEs. The use of these differing types of data challenged training on one source and testing on the other.

## Section: 3 Results › 3.3 Factors contributing to error 2 (differences in annotation guidelines and causal terms)

The annotation guidelines for the two datasets differed. The guideline for the n2c2 dataset, for example, looked for the closest entity rather than causation to draw a relation, whereas the guideline for the ICI-OSU dataset looked for the presence of causal terms to identify a causal relation between entities.

## Section: 4 Discussion › 4.1 Incorporation of domain knowledge

We attempted to analyze the generalizability of ADE detection from clinical notes using several machine learning, deep learning, and transformer-based models and observed promising performance, particularly when we applied state-of-the-art transformer-based models. The superior performance of ClinicalBERT indicated the importance of incorporating domain knowledge when using pre-trained data. Thus, future studies should incorporate more domain knowledge to further enhance the performance of the models.

## Section: 4 Discussion › 4.2 Cross-sentence relation

Our study focused on single-sentence drug–ADE relations, in which the drug and ADE occurred in the same sentence, and after sentence segmentation and annotation, we ended with only a few cross-sentence relations. However, it is also important to identify cross-sentence relations. Our primary challenge in identifying cross-sentence relations was the imbalance within a dataset that could pose a very large number of negative relations against a very small number of positive relations. In addition, our experience in manual annotation showed that a drug and ADE could be distantly related across sentences with numerous sentences in between. Nevertheless, limiting the number of sentences between two entities to draw a relation could help limit the search space to accommodate most of the positive relations across sentences. It would also keep the number of negative relations considerably low.

## Section: 4 Discussion › 4.3 Variation in sentence length

Variations in sentence lengths, some only a few words and some extraordinarily long, made it difficult to train the model and contributed greatly to the error. The ICI-OSU dataset included two positive samples consisting of 30 tokens each, where every single model except BERT classified them incorrectly. BERT was able to predict the true label of one of those two samples correctly. A lack of similar training data probably contributed to the error. Having more training data of similar length or building a separate rule-based approach could facilitate the management of extraordinarily long sentences.

## Section: Acknowledgments

We would like to acknowledge and thank Andrew Nashed for his support in this work.

## Section: Data availability statement

The datasets presented in this article are not readily available because the clinical notes of EHRs were used in this study. Therefore, data could not be published at this point. Requests to access the datasets should be directed to LL, Lang.Li@osumc.edu.

## Section: Ethics statement

The studies involving human participants were reviewed and approved by the institutional review board of The Ohio State University (#2020C0145). Written informed consent for participation was not required for this study in accordance with the national legislation and the institutional requirements.

## Section: Author contributions

MZ and LL were responsible for the overall study design and writing the manuscript. MZ and SZ performed the end-to-end annotation task from the definition of annotation guidelines to the validation of manual annotation. MZ performed the implementation task, which included data processing and modeling. DO provided, enriched, and validated the drug and ADE lists. CC provided logistic support and made the original data available for study with the environmental setup. LL supervised the overall study. All authors contributed to the article and approved the submitted version.

## Section: Conflict of interest

The authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.

## Section: Publisher’s note

All claims expressed in this article are solely those of the authors and do not necessarily represent those of their affiliated organizations, or those of the publisher, the editors, and the reviewers. Any product that may be evaluated in this article, or claim that may be made by its manufacturer, is not guaranteed or endorsed by the publisher.

## Section: Supplementary material

The supplementary material for this article can be found online at: https://www.frontiersin.org/articles/10.3389/fphar.2023.1218679/full#supplementary-material

Click here for additional data file.

## Section: Associated Data

Click here for additional data file.

## Section: Associated Data › Supplementary Materials

Click here for additional data file.

## Section: Associated Data › Data Availability Statement

The datasets presented in this article are not readily available because the clinical notes of EHRs were used in this study. Therefore, data could not be published at this point. Requests to access the datasets should be directed to LL, Lang.Li@osumc.edu.


---

# Generative Models Should at Least Be Able to Design Molecules That Dock Well: A New Benchmark

- **Authors:** Tobiasz Ciepliński, Tomasz Danel, Sabina Podlewska, Stanisław Jastrzȩbski
- **Issuer:** Journal of chemical information and modeling
- **Type:** Scientific article
- **Published:** 2023-05-24
- **Language:** en
- **DOI:** 10.1021/acs.jcim.2c01355
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37224003/
- **Licence:** CC-BY

## Section: Abstract

AbstractDesigning compounds with desired properties is a key element of the drug discovery process. However, measuring progress in the field has been challenging due to the lack of realistic retrospective benchmarks, and the large cost of prospective validation. To close this gap, we propose a benchmark based on docking, a widely used computational method for assessing molecule binding to a protein. Concretely, the goal is to generate drug-like molecules that are scored highly by SMINA, a popular docking software. We observe that various graph-based generative models fail to propose molecules with a high docking score when trained using a realistically sized training set. This suggests a limitation of the current incarnation of models for de novo drug design. Finally, we also include simpler tasks in the benchmark based on a simpler scoring function. We release the benchmark as an easy to use package available at https://github.com/cieplinski-tobiasz/smina-docking-benchmark. We hope that our benchmark will serve as a stepping stone toward the goal of automatically generating promising drug candidates.

## Section: Introduction

Designing compounds with some desired chemical properties is the central challenge in the drug discovery process.1,2De novo drug design is one of the most successful computational approaches that involves generating new potential ligands from scratch, which avoids enumerating explicitly the vast space of possible structures. Recently, deep learning has unlocked new progress in drug design. Promising results using deep generative models have been shown in generating soluble,3 bioactive,4 and drug-like5 molecules. The history of de novo compound design dates back to the 1980s.6 Since then, numerous other approaches emerged, from both ligand- and structure-based path.7,8 Despite existing cheminformatic approaches to new compounds generation, it was the introduction of machine learning (ML) into the field of the computer-aided drug design that revolutionized also the task of de novo ligand design. In recent years, the combination of ML with the information on the target is gaining significant popularity.

A key challenge in the field of drug design is the lack of realistic benchmarks.2 Ideally, the generated molecule by a de novo method should be tested in the wet lab for the desired property. In practice, typically, a proxy is used. For example, the octanol–water partition coefficient or bioactivity is predicted using a computational model.3,4 However, these models are often too simplistic.2 This is aptly summarized by Coley et al.10 who notice that the current generative model benchmarks fail to capture the complexity of real discovery problems. In contrast to drug design, more realistic benchmarks have been used in the design of photovoltaics11 or in the design of molecules with certain excitation energies,12 where a physical calculation was carried out both to train models and to evaluate generated compounds. A huge step toward unifying chemical benchmark was made by Huang et al.13 who introduced an open-source benchmark, Therapeutics Data Commons, and showed that current algorithms are yet not primed to solve all the key therapeutic challenges. Despite this, the recent advances in deep learning have already led to numerous successful applications in drug discovery projects.14

Recently, an increasing number of methods adopts molecular docking as a means of evaluation for generative models in drug design.15−17 More specifically, in computer-aided drug discovery pipelines, docking scores are often used to preliminarily assess proposed drug candidates before reaching for costly laboratory experiments.18−20 With an advent of geometric deep learning for molecular graphs, the structure-based generative models, often employing roto-translationally equivariant neural networks, began to develop rapidly.21−24 Many of these methods use molecular docking to guide the generative process, so the docking scores are the most natural way of the compound evaluation.

Our main contribution is a realistic benchmark for de novo drug design (Figure 1). We base our benchmark on docking, a popular computational method for predicting molecule binding to a protein. Concretely, the goal is to generate molecules that are scored highly by SMINA.25 We picked Koes et al.25 due to its popularity and being available under a free license. While we focus on de novo drug design, our methodology can be extended to evaluate retrospectively other approaches to designing molecules. Code to reproduce results and evaluate new models is available online at https://github.com/cieplinski-tobiasz/smina-docking-benchmark. Notably, our benchmark26 was already adopted by Nigam et al.27 to demonstrate the effectiveness of their genetic algorithm for molecular design.

Our second contribution is exposing the limitation of currently popular de novo drug design methods for generating bioactive molecules. When trained using a few thousands compounds, a typical training set size, the tested methods fail to generate highly active structures according to the docking software. The highest scoring molecules in most cases did not outperform the top 10% molecules found in either the ZINC database or the training set. This suggests we should exercise caution when applying them in drug discovery pipelines, where we seldom have a larger number of known ligands. We hope our benchmark will serve as a stepping stone to further improve these promising models.

The paper is organized as follows. We first discuss prior work and introduce our benchmark. Next, we use our benchmark to evaluate two popular models for de novo drug design. Finally, we analyze why the tested models fail on the most difficult version of the benchmark.

Visualization of the proposed docking-based benchmark for de novo drug design methods. First, the generative model is trained for a selected drug target and generates 250 ligand proposals. The model score is a combination of the mean docking score (or single docking score component, e.g., repulsion or hydrogen bonding) of the generated compounds and their diversity. As a reference value, we use the scores of the top K% of a random ZINC subset (depicted on the right side).

## Section: Docking-Based Benchmark

We begin by briefly discussing prior work and motivation. Next, we introduce our benchmark.

## Section: Docking-Based Benchmark › Why Do We Need Yet Another Benchmark?

Standardized benchmarks are critical to measure progress in any field. Development of large-scale benchmarks such as the ImageNet was critical for the recent developments in artificial intelligence.28,29 Many new methods for de novo drug design are conceived every year, which motivates the need for a systematic and efficient way to compare them.30

De novo drug design methods are typically evaluated using proxy tasks that circumvent the need to test the generated compounds experimentally.3,5,31−33 Optimizing the octanol–water partition coefficient (log P) is a common example. The log P coefficient is commonly computed using an atom-based method that involves summing contribution of individual atoms,5,34 which is available in the RDKit package.35 Due to the fact that it is easy to optimize the atom-based method by producing unrealistic molecules,36 a version that heuristically penalizes hard to synthesize compounds is used in practice.5 This example illustrates the need to develop more realistic ways to benchmark these methods. Another example is QED score,37 which is designed to capture the drug likeliness of a compound. Finally, some approaches use a model (e.g., a neural network) to predict bioactivity of the generated compounds.4 Similarly to log P, these two tasks are also possible to optimize while producing unrealistic molecules. This is aptly summarized in Coley et al.10 as

Interestingly, besides the aforementioned proxy tasks, more realistic proxy tasks are rarely used in the context of evaluating de novo drug design methods. This is in contrast to evaluation of generative models for generating photovoltaics11 or molecules with certain excitation energies.12 One notable exception is Aumentado-Armstrong38 who try to generate compounds that are active according to the DrugScore39 and then evaluate the generated compounds using rDock.40 This lack of the overall diversity and realism in the typically used evaluation methods motivates us to propose our benchmark, which uses molecular docking as a more realistic proxy task.

Arguably, docking-based scoring of compounds has serious limitations,41 and similarity-based models36 are often chosen in commercial projects over molecular docking.42 However, the idea of our benchmark is that docking, even if simplistic, proves to be challenging for generative models. Our setup aims to imitate real drug discovery scenarios by employing this simple docking proxy.

## Section: Docking-Based Benchmark › Docking-Based Benchmark

Our docking-based benchmark is defined by (1) docking software that computes for a generated compound its pose in the binding site, (2) a function that scores the pose, and (3) a training set of compounds with an already computed docking score.

The goal is to generate 250 molecules that achieve the maximum possible docking score. We find this number of compounds large enough to make the optimization of diversity nontrivial, but small enough to make testing feasible in practice (in terms of either computational resources or the cost of ordering compounds for wet lab experiments). For the sake of simplicity, we do not impose limits on the distance of the proposed compounds to the training set. Thus, a simple baseline is to return the training set. Finding similar compounds that have a higher docking score is already prohibitively challenging for current state-of-the-art methods. As the field progresses, our benchmark can be easily extended to account for the similarity between the generated compounds and the training set.

Finally, we would like to stress that the benchmark is not limited to de novo methods. The benchmark is applicable to any other approaches such as virtual screening. The only limitation required for a fair comparison is that docking is performed only on the supplied training set.

## Section: Docking-Based Benchmark › Instantiation

As a concrete instantiation of our docking-based benchmark, we use SMINA v. 2017.11.925 due to its widespread use and its being offered under a free license. To create the training set, we download from the ChEMBL43 database molecules tested against selected drug targets: 5-HT1B, 5-HT2B, ACM2, and CYP2D6. In the extended variant of our benchmark, we include four additional drug targets: ADRB1, MOR, A2A, and D2. For instance, the final 5-HT1B data set consists in 1,878 molecules, out of which 1,139 are active (Ki < 100 nM) and 739 are inactive molecules (Ki > 1,000 nM). Only molecules that dock successfully are retained. We list the resulting data set sizes in Table 1.

We dock each molecule using default settings in SMINA to a manually selected binding site coordinate. Protein structures were downloaded from the Protein Data Bank, cleaned and prepared for docking using Schrödinger modeling package. The resulting protein structures are provided in our code repository. We describe further details on the preparation of the data sets in the Supporting Information.

Starting from the above, we define the following three variants of the benchmark. In the first variant (Docking Score Function), the goal is to propose molecules that achieve the smallest Vinardo docking score44 (based on the Vina docking score45) used in the score_only mode of the SMINA package, defined as follows:

where all terms are computed based on the final docking pose. The first three terms measure the steric interaction between ligand and the protein. The fourth and the fifth terms look for hydrophobic and hydrogen bonds between the ligand and the protein. We include a detailed description of all the terms in the Supporting Information.

Next, we propose two simpler variants of the benchmark based on individual terms in the Vinardo scoring function. We select optimization targets that have clear interpretations: repulsion that minimizes clashes with protein and hydrogen bonding that maximizes interactions stabilizing the compound pose in the binding site. In the Repulsion task, the goal is to only minimize the repulsion component, which is defined as

where ddiff(a1, a2) is the distance between the atoms minus the sum of their van der Waals radii. The distance unit is Angstrom (10–10 m).

The third task, Hydrogen Bonding, is to maximize the non_dir_h_bond term:

To make the results more stable, we average the score over the top 5 best-scoring binding poses. Finally, to make the benchmark more realistic, we filter the generated compounds using the Lipinski rule and discard molecules with molecular weights lower than 100.

## Section: ZINC Baseline

The premise behind de novo drug discovery is that it enables access to structurally novel and potent molecules. To contextualize results in the benchmark, we included as the baseline sampling from the subset of ZINC database containing 9,204,719 molecules.46 We selected molecules having the following properties: 3D representation, standard reactivity, in-stock purchasability, ref pH, charges from −2 to +2 inclusive, and a used drug-like preferred subset. For each protein we have sampled a set of molecules from aforementioned ZINC subset of the protein’s training set size. In each task, we compare to the mean value of the top 50%, 10%, and 1% of scores.

t-SNE maps of compound fingerprints (ECFP) for each protein. Each point is a molecule, and the distances between points are proportional to the dissimilarity of compounds. The training set is marked with red dots, and the compounds generated by REINVENT by enhancing different optimization targets are colored in blue (Docking Score Function), orange (Hydrogen Bonding), and green (Repulsion).

## Section: ZINC Baseline › Diversity

To better understand the performance of each model, besides the mean score, we also evaluate the diversity of the proposed molecules. Concretely, we compute the mean Tanimoto distance between all pairs of molecules in the generated sample. We use the 1024-bit ECFP representation47 with radius 2. The diversity score is reported in the benchmark along with the docking score results. We observe that the optimized models narrow down to a less diverse subspace of compounds that are dissimilar to the training set. This can also be observed in the t-SNE plots of the generated compounds compared to the training set (Figure 2). In this figure, compounds are grouped together based on their structural similarity. The small focused clouds of compounds generated using different optimization targets always concentrate at one side of the map. This suggests that there is similar bias of the model independent of the optimization target, which can be the ChEMBL prior to the REINVENT model48 (described below as one of the compared generative models). The separation between the optimized compounds and the training set suggests that these are novel molecules (similar structures are rarely present in the training set). Besides that observation, we note that the generated compounds are less diverse, creating one dense blob instead of multiple clusters, where all compounds are similar to each other inside one optimization target.

t-SNE maps of compound fingerprints (ECFP) for each protein. Each point is a molecule, and the distances between points are proportional to the dissimilarity of compounds. The training set is marked with red dots, and the compounds generated by REINVENT by enhancing different optimization targets are colored in blue (Docking Score Function), orange (Hydrogen Bonding), and green (Repulsion).

## Section: ZINC Baseline › When Is a Task Solved?

In the experiments, we compare to two baselines: (i) random compounds from ZINC as the baseline and (ii) compounds from the training set. In each case we report the mean score, the top 10% of scores, and the top 1% of scores. We also report diversity of the results.

Roughly speaking, we consider a given optimization task solved by a generative model if the molecules generated by this model achieve a mean score that exceeds the score of top 1% compounds in the ZINC subset (the values provided in theResultssection), while achieving at least the same diversity as observed in the training set of activity data extracted from ChEMBL (also provided below for each protein). This criterion is necessarily arbitrary. It is inspired by a natural baseline—comparing against a random sample of several thousands of drug-like compounds from the ZINC database.

## Section: ZINC Baseline › Model Evaluation Workflow

Below, we summarize all the steps necessary to evaluate a generative model and compare it with our benchmark. A general overview of this workflow is depicted in Figure 1, and the step-by-step evaluation procedure is shared in our code repository in the Python notebook named getting-started.ipynb.

## Section: Results and Discussion

In this section, we evaluate three popular models for de novo drug design on our docking-based benchmark.

Best scoring molecules generated by REINVENT in each of the three tasks composing the benchmark.

Best scoring molecules generated by CVAE in each of the three tasks composing the benchmark. Missing compounds correspond to the failed optimizations.

Best scoring molecules generated by GVAE in each of the three tasks composing the benchmark. Missing compounds correspond to the failed optimizations.

Correlation between docking score and molecular weight. The training set is marked with red dots, and the compounds generated by REINVENT by enhancing different optimization targets are colored in blue (Docking Score Function), orange (Hydrogen Bonding), and green (Repulsion).

Correlation between docking score and the number of rotatable bonds. The training set is marked with red dots, and the compounds generated by REINVENT by enhancing different optimization targets are colored in blue (Docking Score Function), orange (Hydrogen Bonding), and green (Repulsion).

## Section: Results and Discussion › Models

We compare three popular models for de novo drug design. Chemical Variational Autoencoder (CVAE)49 applies Variational Autoencoder50 by representing molecules as strings of characters (using SMILES encoding). This approach was later extended by Grammar Variational Autoencoder (GVAE),3 which ensures that generated compounds are grammatically correct. The third model, REINVENT,48 is a recurrent neural network that generates SMILES strings. It is first trained in a supervised manner to produce correct drug-like compounds similar to the ChEMBL data set (prior). Next, it is trained using reinforcement learning to optimize docking scores, which are provided as a training reward.

We note that CVAE and GVAE were not designed for small sample sizes, so they may not fully exploit their potential in our benchmark since they are used out of context. On the other hand, it was shown that REINVENT is a representative method in terms of achieving high sample efficiency.51

## Section: Results and Discussion › Experimental Details

To generate active compounds, we follow an approach similar to the one in Jin et al.,5 disregarding the penalty for insufficient similarity. Analogous methods using the sparse Gaussian Process instead of a multilayer perceptron are also employed in Gómez-Bombarelli et al.49 and Kusner et al.3 The exact algorithm for training our generative models is described below.

First, we fine-tune a given generative model for 5 epochs on the training set ligands, starting from weights made available by the authors. All hyperparameters are set to default values used in Gómez-Bombarelli et al.49 and Kusner et al.3 Additionally, we use the provided scores to train a multilayer perceptron (MLP) to predict the optimization target (e.g., the SMINA scoring function) based on the latent space representation of the molecule.

For CVAE and GVAE, to generate compounds, we first take a random sample from the latent space by sampling from a Gaussian distribution with the standard deviation of 1 and the mean of 0. Starting from this point in the latent space, we take 50 gradient steps to optimize the output of the MLP. Based on this approach we generate 250 compounds from the model.

For the REINVENT model, we use pretrained weights on the ChEMBL database provided by Olivecrona et al.48 As there is no latent space in this model, we train a random forest model to predict the optimization target directly from the molecule structure. We use the ECFP fingerprint to encode the molecule.47 The reward is computed based on the random forest prediction multiplied by the QED score calculated using RDKit.

The key limitation of all the generative methods above is the use of an ML model, either an MLP or a random forest, to predict docking scores. This is an important design decision in this study. Our benchmark aims to simulate a setting in which a drug discovery campaign involves designing a small batch of compounds to be tested for biological activity based on prior biological data. This is different from searching for a highly docking compound, in which case a reasonable approach would be to compute docking scores for a large number of test compounds.

All other experimental details, including hyperparameter values used in the experiments, can be found in the appendix.

## Section: Results and Discussion › Optimization of Docking Objectives

Tables 2 and 3 summarize the results on all three tasks. Recall that we generally consider a given task solved if the generated molecules exceed the top 1% score found in the ZINC database, while achieving at least the same diversity as in the training set. Below we make several observations.

Best scoring molecules generated by REINVENT in each of the three tasks composing the benchmark.

Best scoring molecules generated by CVAE in each of the three tasks composing the benchmark. Missing compounds correspond to the failed optimizations.

Best scoring molecules generated by GVAE in each of the three tasks composing the benchmark. Missing compounds correspond to the failed optimizations.

Correlation between docking score and molecular weight. The training set is marked with red dots, and the compounds generated by REINVENT by enhancing different optimization targets are colored in blue (Docking Score Function), orange (Hydrogen Bonding), and green (Repulsion).

Correlation between docking score and the number of rotatable bonds. The training set is marked with red dots, and the compounds generated by REINVENT by enhancing different optimization targets are colored in blue (Docking Score Function), orange (Hydrogen Bonding), and green (Repulsion).

## Section: Results and Discussion › Optimization of Docking Objectives › Docking Score Function Task

The key task in the benchmark is Docking Score Function. We observe that CVAE and GVAE models fail to generate compounds that achieve a higher docking score compared to the mean docking score in the ZINC data set (−8.785 for 5-HT1B compared to −4.647 and −4.955 achieved by CVAE and GVAE, respectively). The REINVENT model achieves much better performance (−9.774 for 5-HT1B). However, while docking scores attained by the molecules generated by REINVENT generally outperform the mean docking in the ZINC data set and the training set, they fall short of outperforming the top 10% molecules found in ZINC (−9.894 for 5-HT1B, with the exception of ACM2). We also draw attention to the fact that the generated molecules by REINVENT are markedly less diverse than the diversity of the training set (0.506 mean Tanimoto distance compared to 0.787 in the training set).

These results suggest that generative models applied to de novo drug discovery might require substantial more data to generate well-binding compounds than is typically available for training. In the key Docking Score Function task, models generally fail to outperform the top 10% from the ZINC database. It should worry us that optimizing for the docking score, which seems to be a simpler optimization target than true biological binding affinity, is already challenging given realistically sized training sets (between 1,193 and 10,225 molecules).

## Section: Results and Discussion › Optimization of Docking Objectives › Repulsion Task

Interestingly, REINVENT performs significantly worse than GVAE and CVAE on the Repulsion task. All models fail to outperform the top 10% found in the ZINC data set. We observe markedly lower diversity of molecules generated by REINVENT compared to the training set.

## Section: Results and Discussion › Optimization of Docking Objectives › Hydrogen Bonding Task

The Hydrogen Bonding task is the simplest, and both GVAE and REINVENT generate molecules that almost match the top 1% molecules found in the ZINC database and the training set. We again observe relatively low diversity of molecules generated by REINVENT.

## Section: Results and Discussion › Optimization of Docking Objectives › Generated Molecules

Figure 3 shows the best scoring molecules generated by REINVENT. We observe that optimizing each objective promotes different structural motifs. For example, the best scoring molecules in the Repulsion task are small, which intuitively enables them to easily fit into the binding pocket, achieving lower repulsion values than the top 1% molecules in the training set.

Similarly, there are clear patterns visible in the top molecules of CVAE and GVAE (Figures 4 and 5). For example, CVAE generates macrocycles in the task of docking score optimization, while GVAE generates long chains with no cycles when optimizing the same objective. These models also create oxygen or nitrogen chains when optimizing Hydrogen Bonding, and very small molecules (often less than 3 heavy atoms) for the Repulsion task.

We noticed a moderately strong correlation between docking scores and the number of rotatable bonds or molecular weight. Figures 6 and 7 show that, with the increasing number of rotatable bonds or molecular weight, the docking scores improve. For the number of rotatable bonds, the generated compounds are well mixed with the training data marginal distribution. On the other hand, the distribution of generated compounds is shifted toward better docking scores and smaller molecular weights in the case of the weight-to-docking-score relation. In other words, molecules achieve better docking scores at the same molecular weight after the optimization. The correlations are weaker for CYP2D6, which may be caused by a bigger binding site of this enzyme. However, the last observation about molecular weights holds.

From the chemical point of view, REINVENT produced the most consistent ligands with the highest possibility of desired biological activity. When different optimization approaches are considered, the best results were produced during the docking score optimization. Nondir h-bond optimization produced compounds with sometimes a high number of moieties able to produce a hydrogen bond. In the repulsion task, the produced compounds are correct from the chemical point of view. The drug-likeliness of compounds produced by CVAE and GVAE is lower (although they still meet criteria included in the Lipiski Rule of Five), but they still can be used in the docking benchmark task. The poor quality of the generated compounds is not surprising, as this issue was previously observed for other unrestricted de novo generative models.36

Best scoring molecules generated by REINVENT in each of the three tasks composing the benchmark.

Best scoring molecules generated by CVAE in each of the three tasks composing the benchmark. Missing compounds correspond to the failed optimizations.

Best scoring molecules generated by GVAE in each of the three tasks composing the benchmark. Missing compounds correspond to the failed optimizations.

Correlation between docking score and molecular weight. The training set is marked with red dots, and the compounds generated by REINVENT by enhancing different optimization targets are colored in blue (Docking Score Function), orange (Hydrogen Bonding), and green (Repulsion).

Correlation between docking score and the number of rotatable bonds. The training set is marked with red dots, and the compounds generated by REINVENT by enhancing different optimization targets are colored in blue (Docking Score Function), orange (Hydrogen Bonding), and green (Repulsion).

## Section: Conclusion

As concluded by Coley et al.,10 “the current evaluations for generative models do not reflect the complexity of real discovery problems”. Motivated by this, we proposed a new, more realistic, benchmark tailored to de novo drug design, using docking score as the optimization target. Code to evaluate new models is available at https://github.com/cieplinski-tobiasz/smina-docking-benchmark.

Our results suggest that generative models applied to de novo drug discovery pipelines might require substantially more data to generate realistic compounds than is typically available for training. Despite using over 1,000 compounds for training (between 1,074 and 3,780), the best docking scores generally do not outperform the top 10% docking scores in the ZINC data set. The docking score is only a simple proxy of the actual binding affinity, and as such, it should worry us that it is already challenging to optimize.

On a more optimistic note, the tested models achieved much better performance on the simplest task in the benchmark, which is to optimize a single term in the SMINA scoring function involving the number of hydrogen bonds to the binding site. This suggests that producing compounds that optimize the docking score based on the provided data set is an attainable, albeit challenging, task. We hope our benchmark better reflects the complexity of real discovery problems and will serve as a stepping stone toward developing better de novo models for drug discovery.

## Section: Acknowledgments

The work of Tomasz Danel is supported by National Centre of Science (Poland) Grant No. 2020/37/N/ST6/02728. Stanisław Jastrzȩbski thanks FNP START stipend and IPUB project at Jagiellonian University for supporting this work.

## Section: Data Availability Statement

The data and code used in this project are available at https://github.com/cieplinski-tobiasz/smina-docking-benchmark.

## Section: Supporting Information Available

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acs.jcim.2c01355.

## Section: Text

The authors declare no competing financial interest.

## Section: Supplementary Material

ci2c01355_si_001.pdf

## Section: Associated Data

ci2c01355_si_001.pdf

## Section: Associated Data › Supplementary Materials

ci2c01355_si_001.pdf

## Section: Associated Data › Data Availability Statement

The data and code used in this project are available at https://github.com/cieplinski-tobiasz/smina-docking-benchmark.


---

# [Guidelines for clinical trial protocols for interventions involving artificial intelligence: the SPIRIT-AI extensionDiretrizes para protocolos de ensaios clínicos com intervenções que utilizam inteligência artificial: a extensão SPIRIT-AI]

- **Authors:** Samantha Cruz Rivera, Xiaoxuan Liu, An-Wen Chan, Alastair K Denniston, Melanie J Calvert, Grupo de Trabajo SPIRIT-AI y CONSORT-AI, Grupo Directivo SPIRIT-AI y CONSORT-AI, Grupo de Consenso SPIRIT-AI y CONSORT-AI
- **Issuer:** Revista panamericana de salud publica = Pan American journal of public health
- **Type:** Scientific article
- **Published:** 2023-12-08
- **DOI:** 10.26633/rpsp.2023.149
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38361499/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

ABSTRACTObjective.To determine if there was an association between intrapartum stillbirths and both traveled distance for delivery and delivery care accessibility, assessing periods before and during the COVID-19 pandemic.Methods.This is a population-based cohort study. Patients had birth occurring after the onset of labor; the primary outcome was intrapartum stillbirth. City of residence was classified according to the ratio between deliveries performed and total births among its residents; values lower than 0.1 indicated low delivery care accessibility. Travel distance was calculated using the Haversine formula. Education level, maternal age, and birth sex were included. In each period, relative risk was assessed by generalized linear model with Poisson variance.Results.There were 2 267 534 deliveries with birth occurring after the onset of labor. Most patients were between age 20 and 35 years, had between 8 and 11 years of education, and resided in cities with high delivery care accessibility. Low delivery care accessibility increased risk of intrapartum stillbirth in the pre-pandemic (relative risk [RR] 2.02; 95% CI [1.64, 2.47]; p < 0.01) and the pandemic period (RR 1.69; 95% CI [1.09, 2.55]; p = 0.015). This was independent of other risk-increasing factors, such as travel distance and fewer years of education.Conclusions.Low delivery care accessibility is associated with the risk of intrapartum stillbirths, and accessibility reduced during the pandemic. Delivery of patients by family physicians and midwives, as well as official communication channels between primary care physicians and specialists, could improve patient healthcare-seeking behavior.

## Section: Text

During pregnancy, the intrapartum period brings increased risk for both mother and fetus. The most severe complication is intrapartum perinatal death, which is the sum of neonatal deaths and stillbirths attributable to asphyxia (1). Both share similar precursors (2), albeit not identical, as accessibility and adequacy of delivery room resuscitation techniques impact neonatal deaths (1, 3).

Globally, more than 1 million stillbirths occur in the intrapartum period each year (2, 3). Precise rates vary substantially, as the definition of intrapartum death changes in low- and high-resource settings (3). Nevertheless, it has been demonstrated that stillbirth rates are higher in resource-poor countries (1, 4), and the percentage of those stillbirths attributable to asphyxia is higher in most socially vulnerable localities (4, 5).

Brazil has a stillbirth rate of 10.97 per 1 000 births, which sets it at an intermediate level when considering the rate of 34 per 1 000 births in Pakistan, while developed countries reach rates as low as 2 per 1 000 births (1, 4, 6). Depending on methodology and location, between 7.5% and 22% of such stillbirths would be attributable to intrapartum asphyxia (5, 7). In Brazil, stillbirth rates dropped between 1996 and 2010 (4) but have since become relatively stable (5). Both the rate of this reduction and the percentage of asphyxia-attributable intrapartum deaths are not homogeneous. Poorer regions display higher rates and slower rate reductions compared to richer regions (5).

Even within the State of São Paulo, asphyxia-related perinatal deaths are not homogenously distributed: those residing in the rural areas more often had birthweights of 2 500 grams or greater, as well as gestational age of 37 weeks or over, when compared to deaths of residents of the metropolitan area (7).

While significant focus has been dedicated to the role of medical care, it has been demonstrated that sociodemographic and economic factors substantially impact the patient’s healthcare-seeking behavior and ability to reach proper care (1, 4, 5). Thaddeus and Maine (8) proposed the Three Delays Model, which encompasses delays in the decision to seek care in its Phase I, delays in reaching the appropriate health facility in its Phase II, and delays in receiving adequate medical care in its Phase III (8). Importantly, patients expecting delays in Phases II and III could have their behavior modified and delay even further in seeking medical attention in Phase I. Further research has brought attention to new variables, either by incorporating them into the existing framework or by changes in the perceived interconnection between these variables (9–11).

The range of variables acting upon each phase is significant, ranging from awareness regarding symptoms, women’s autonomy, cost of care, perceived quality of healthcare services, distance traveled for care, and availability of transportation, among others (8, 11, 12). How these variables interact with one another depends on several factors, such as the country studied, education level, and socioeconomic status. Research in Brazil found adverse obstetric outcomes were associated with Phase I and Phase II delays; however, these variables were not separately studied to understand if they act independently of each other (13).

The complex social system that dictates patient behavior and impacts timely access to health care was further impacted by COVID-19, which was declared a pandemic in March 2020 (14). The first case in Brazil was described in February 2020, followed by rapid spread (15, 16). Brazil has significant focus on hospital-based obstetric care, high cesarean rates, and inequality of access associated with ethnicity and education level (17). The impact of the pandemic on obstetric care is not fully understood and could deepen inequalities in access to obstetric health care (18).

This study aims to identify if there is a higher risk of intrapartum death among patients who began labor with a live fetus in the State of São Paulo from 2015 to 2021, independently assessing the distance traveled for delivery and the accessibility of delivery care provided by the city of the residence itself. Analysis was performed separately for pre-pandemic and pandemic groups.

## Section: MATERIALS AND METHODS › Study design and data sources

This study is a retrospective population-based cohort study. It is based on the Ministry of Health of Brazil databanks of all live births (SINASC) and all deaths (SIM), both publicly accessible. The cohort included all patients with a city of residence and delivery in the State of São Paulo who went into labor with a live fetus, and the primary outcome assessed was intrapartum fetal death. We downloaded publicly available files from SINASC and SIM containing live birth and fetal death records in the State of São Paulo from 2015 to 2021. All variables come from the SINASC and SIM databases. These databases provide individual-level, anonymized data for each delivery for all variables used in this research.1

## Section: MATERIALS AND METHODS › Setting

São Paulo, one of the 27 states of Brazil, is divided into 645 municipalities with a total area of 248 219.481 km2 and a population of 44 420 459 people. Its Human Development Index value is 0.806 (19).

## Section: MATERIALS AND METHODS › Participants

We included data of patients if their cities of residence and delivery were in São Paulo State, considering that some patients may seek medical assistance in another state when their city of residence is close to the border with neighboring states. We did not consider them eligible for the study if the gestational age at the end of pregnancy was less than 20 weeks, or if there was missing information regarding gestational age, maternal age, sex, and city of residence or delivery. All patients who fulfilled these conditions were used to calculate the delivery accessibility ratio for each municipality.

We classified patients according to the city of residence and date of delivery; events occurring from March 2020 onwards were classified as the pandemic group, as opposed to the pre-pandemic group.

We proceeded with further exclusion criteria to develop the cohort of patients who delivered after starting labor with a live fetus. Among live births, we excluded patients with cesarians happening before the beginning of labor or without information. Stillbirth death certificates classify the moment of death as antepartum, intrapartum, postpartum, or unknown; we excluded those with an antepartum or unknown moment.

## Section: MATERIALS AND METHODS › Delivery care accessibility ratio

Using the first step described in the participants section, we were able to determine two values for each municipality. First, the total number of hospital deliveries occurring in each city, regardless of these patients’ residences. Secondly, for each city, the total number of patients residing there who gave birth in a hospital in any city of the State. The ratio of hospital deliveries in a given city over the total deliveries among that same city’s residents was named the delivery care accessibility ratio. Cities with ratios less than 0.1 were classified as having low delivery care accessibility, since even though some deliveries were performed there, most patients residing there would need to seek medical attention elsewhere. Those with ratios equal to or greater than 0.1 were classified as high accessibility. The decision for a value of 0.1 was taken considering the rates of public healthcare coverage in Brazil (20) and percentage of dual-use of both public and private health care (21), as to reflect a local level of delivery care that, while existent, might be either the result of sporadic and unexpected events, or expensive and widely unavailable for the majority of patients.

## Section: MATERIALS AND METHODS › Distance from residence to the delivery unit

We calculated the distance traveled from the city of residence to the city of delivery. It was determined by the Haversine formula as a straight line, using publicly available coordinates for the city of residence and city of delivery. If they were the same city, travel distance was zero.

## Section: MATERIALS AND METHODS › Study size

When designing the study, we estimated that more than 1 000 000 patients would be included in this population study. We considered the rate of the outcome, stillbirth, which is 8.34 cases per 1 000 deliveries in the southeast region of Brazil (22), where São Paulo State is located. Sample size was adequate because the logistic regression adjustment comprised fewer than 10 factors.

## Section: MATERIALS AND METHODS › Statistical methods

Descriptive statistics were used to display the results. Categorical variables were compared using the Chi-square test, and continuous variables used the Wilcoxon–Mann–Whitney test. To assess the relative risk of intrapartum fetal death, we used a generalized linear model with Poisson distribution and log link, using delivery care accessibility, travel distance, education level, maternal age, and birth sex. The alpha value was used as 0.05 for the significance of all tests.

As an exploratory analysis, we focused on the population of residents of low delivery care accessibility cities. We compared the characteristics of those who delivered in that city and all others who traveled to another city for delivery. We restricted this analysis to live births, since the live birth database has more sociodemographic information, such as ethnicity and place of delivery. Ethnicity could be classified as White, Mixed-race, Black, Asian, or Indigenous. Place of delivery could be hospital, another healthcare service, home, another, or unknown. Groups were compared with the same statistical tests as described above.

All analyses were performed separately for each time period. Data manipulation and statistical analysis were conducted using the software RStudio version 4.2.2 (2022-10-31).

## Section: MATERIALS AND METHODS › Ethics

All data are publicly available and anonymized. According to the Brazilian National Commission of Ethics in Research, research employing public domain data that does not identify participants does not require ethics board approval.

## Section: RESULTS

The initial data included 2 895 045 live births and 63 981 stillbirths. Exclusion criteria regarding gestational age, birth sex, unspecified city of residence or delivery, and maternal age led to inclusion of 2 886 947 live births and 42 392 stillbirths, which were used to calculate the delivery care accessibility ratio in each period. Of this total, 697 109 occurred during the COVID-19 pandemic, and 2 232 230 happened in the pre-pandemic period. These allowed us to classify all municipalities in the state according to their delivery care accessibility ratio. In the pre-pandemic period, 274 were classified as high accessibility and 371 as low accessibility; during the pandemic, 248 cities were classified as high accessibility and 397 as low accessibility.

The cohort itself included only patients who underwent delivery after starting labor with a live fetus. After excluding 619 707 cesareans without prior labor and 532 live birth deliveries without information regarding type of birth, there were 2 266 708 live births. As for stillbirths, 27 526 were excluded due to fetal demise occurring antepartum, and 14 040 did not have information about moment of death, thus leading to 826 stillbirths. When adding live births and stillbirths who began labor with a live fetus, there were 2 267 534 deliveries, with 1 717 399 patients in the pre-pandemic period and 550 135 during the COVID-19 pandemic.

Patients in the pre-pandemic period mostly lived in high delivery care accessibility cities, had predominantly 8 to 11 years of education, and had a mean age of 27.7 years, while the median was 28 years, with a standard deviation of 6.7 years. When comparing both outcomes, patients with intrapartum fetal death in the pre-pandemic period had a higher proportion of residents in cities with a low delivery care accessibility ratio, traveled longer distances for delivery, were younger, had fewer years of education, and had a higher proportion of male fetuses. All tests had a p-value < 0.01. Chi-square post hoc analysis for education level had all categories being statistically significant with a p-value < 0.01; the same analysis for age group revealed statistically significant differences in the proportion of patients aged younger than 20 years (p = 0.04) and from 20 to 35 years (p < 0.01). These results are summarized in Table 1. During the pandemic, only differences in the proportion of low delivery care accessibility ratio, travel distance for delivery, and education level remained statistically significant (p < 0.01), with a higher proportion of patients with intrapartum fetal deaths residing in cities classified as low accessibility. Post hoc analysis of education level differences found significant results (p < 0.01) solely among the unknown education level group. These findings are detailed in Table 2.

In the pre-pandemic period, an unadjusted relative risk (RR) of 2.58 for intrapartum fetal death (95% CI [2.12, 3.11]; p < 0.01) and an adjusted RR of 2.02 (95% CI [1.64, 2.47]; p < 0.01) was found among patients residing in cities with a low delivery care accessibility ratio. Other variables produced significant relative risks as well, such as travel distance, with both an unadjusted and adjusted RR of 1.01 per kilometer in a straight line (95% CI [1.01, 1.01], p < 0.01 for the unadjusted model; 95% CI [1.00, 1.01], p < 0.01 for the adjusted model). Maternal age above 35 years, fewer years of education, and male birth sex all had statistically significant RR in the adjusted model. A summary of these results can be found in Table 3.

The overall characteristics of patients in the pandemic period were similar to the pre-pandemic period. Most patients lived in municipalities with high delivery care accessibility, had between 8 and 11 years of education, and had a mean age of 28.3 years and a median age of 28 years, with standard deviation of 6.7 years. When considering both outcomes, residents in a low delivery care accessibility ratio city displayed an unadjusted RR for intrapartum fetal death of 2.47 (95% CI [1.62, 3.65]; p < 0.01) and an adjusted RR of 1.69 (95% CI [1.09, 2.55]; p = 0.015). Each kilometer of travel distance in a straight line had an impact of an RR of 1.01 for both the unadjusted and adjusted analysis (95% CI [1.01, 1.01], p < 0.01 for the unadjusted model; 95% CI [1.00, 1.01], p < 0.01 for the adjusted model). Only fewer years of education yielded statistically significant RR in the adjusted model. These results are shown in Table 4.

In the exploratory analysis, in both periods, live birth patients residing in a low delivery care accessibility city who had their delivery in a different city had a higher proportion of White ethnicity, had more years of education, and had higher proportions of hospital birth. The proportion of hospital births among low delivery care accessibility city residents who had their live birth delivery in the same city was 49.2% in the pandemic period and 59.8% in the pre-pandemic period. In comparison, patients who went to another city for delivery had 99.5% proportion of hospital births in both periods. This relationship is shown in Figure 1.

## Section: DISCUSSION › Main findings

We identified a higher risk of intrapartum fetal death among pregnant patients who began labor with a live fetus when residing in cities with low delivery care accessibility ratios. Notably, this result was also independent of and more clinically impactful than the distance between the city of residence and childbirth.

During the COVID-19 pandemic, hospital deliveries among patients both residing and giving birth in low delivery care accessibility cities reduced even further. There was also an increase in the number of cities with low delivery care accessibility compared to the previous period.

## Section: DISCUSSION › Interpretation

Travel distance may hold ambiguous and divergent meanings in retrospective studies, mainly when analyzed in the context of the superposition of private and public healthcare providers. Patients may face long distances between their hometowns and cities of delivery due to the inexistence of adequate care nearby or as part of a planned approach to receive the best possible private care in the state, even if reasonable care was provided closer to their residence. Conversely, a patient might display low travel distance if they were incorrectly diagnosed as not requiring specialized care in the public sector or if they had enough resources to access private care in cities that do not have equally specialized public services. Distance is a component of the Phase II delay in the Three Delays Model proposed by Thaddeus and Maine (8); it is contextual and requires consideration regarding the origin’s conditions.

We interpret these results as evidence favoring a Phase I delay among patients residing in low delivery care accessibility ratio, resulting in intrapartum fetal death. Patients could be less motivated to seek care when presenting symptoms if their hometowns are not equipped well enough to judiciously select which patients require further assessment in a maternity hospital and which can safely wait for the next prenatal visit. Patients could be discouraged from seeking their local health service if they are frequently referred to nearby cities, just to be discharged hours later without needing further intervention, spending significant time on what could potentially be solved at the primary care level. This hypothesis is partially corroborated by research in Brazil, which observed high rates of nonurgent or low-priority cases among pregnant patients of all gestational ages in obstetric emergency departments (23, 24) or high discharge rates from the specialized obstetric emergency department after clinical assessment and verbal orientation (25).

A study from the Netherlands found regional differences in perinatal mortality rates (26). A subsequent study from the same country identified a higher risk of neonatal and perinatal mortality among patients with travel time to the hospital equal to or greater than 20 minutes (27). The Dutch obstetric healthcare system significantly differs from the Brazilian system; patients are described as beginning labor at home, even when hospital birth is planned. This matter obscures the comparison regarding healthcare-seeking behavior and Phase I delays and further reflects the importance of the overall healthcare structure in which patients are inserted.

These differences in overall structural conditions are seen not only between countries but also between regions within countries. A study from Benin found that while travel distance impacted both antenatal care and delivery service utilization, the magnitude of this impact was higher in the northern part of the country, reflecting local conditions beyond the simple measurement of travel distance (28). These findings concur with our results, demonstrating travel distance and accessibility conditions as independent variables inside the region of the study.

A study in the Republic of Korea aimed to assess the impact of residence in areas underserved in obstetric care. This research found higher rates of adverse obstetric outcomes in these regions, such as abortion, obstetric hemorrhage, and pyelonephritis (29). These results concur with our own, as they describe the negative impact that could arise from living in cities with suboptimal access to medical services. As the Republic of Korea has a single public healthcare insurance system, their definition of underserved areas ends up being different than the delivery care accessibility ratio described in this research; when both private and public health care coexist, the presence of care does not equate to accessibility, as deep socioeconomic divisions segregate healthcare access.

Available research is not unanimous regarding how the COVID-19 pandemic might have impacted medical-seeking behavior among pregnant patients. A report from the beginning of the outbreak demonstrated a reduction in visits and births in a tertiary center (30). Conversely, a cross-sectional study using web-based surveys in California did not find a reduction in perinatal healthcare access between the first and second COVID-19 waves (31). Our findings suggest reduced delivery care accessibility during the pandemic. Differences in the COVID-19 response, previous healthcare structure, and outcome definition could be associated with these divergences.

## Section: DISCUSSION › Strengths and limitations

This study has several strengths. It utilizes databases with individual-level data from birth and death certificates, which are mandatory in Brazil, reducing the chance of data loss. It also includes a large number of patients during a significant period. Limitations include the retrospective nature of the study. Linear distance, as calculated, does not consider terrain and is likely to underestimate actual distance traveled; furthermore, it does not consider in-city distance from home to hospital. There are also limitations inherent in using administrative databases, such as potential errors or missing information. Notably, of all variables, moment of death for stillbirths was the most impacted, with about one-third of stillbirths being excluded for this reason. However, there is no indication this failure to record would happen more often in one group than another, representing an inherent deficiency in the recording system as a whole. Thus, missing information and exclusion should not, on its own, change the overall results. Analysis comparing live births and stillbirths was also limited due to differences in how both are recorded; stillbirths in Brazil follow a death certificate model very similar to the adult death certificate model, with little additional information. For example, the current system does not record the mother’s ethnicity in stillbirths. Despite these limitations, these do not seem to invalidate the current findings.

## Section: DISCUSSION › Conclusion

In summary, pregnant patients residing in low delivery care accessibility cities have a higher risk for intrapartum fetal death in the State of São Paulo, independently of the distance traveled for delivery. This represents a delayed decision to seek medical care due to a possible combination of disincentives caused by the known travel distance and perceived efficacy of care. The COVID-19 pandemic seems to have reduced delivery care accessibility.

Delivery care accessibility could be improved by reconsidering the hospital-based delivery system and increasing focus on family physicians or midwives for low-risk pregnant patients. Another option to reduce Phase I delays and improve primary care in these cities could be investment in official communication channels between primary care physicians and specialists in tertiary centers. This could potentially avoid unnecessary time spent traveling to and from tertiary centers and improve efficacy as perceived by patients, thus increasing the likelihood the patient will actually seek medical care when necessary. Finally, stillbirth death certificate models should be revised in order to register more obstetric information, such as the mother’s ethnicity.

## Section: Disclaimer.

Authors hold sole responsibility for the views expressed in the manuscript, which may not necessarily reflect the opinion or policy of the RPSP/PAJPH and/or the Pan American Health Organization (PAHO).


---

# Harnessing the power of synthetic data in healthcare: innovation, application, and privacy

- **Authors:** Mauro Giuffrè, Dennis L Shung
- **Issuer:** NPJ digital medicine
- **Type:** Scientific article
- **Published:** 2023-10-09
- **Language:** en
- **DOI:** 10.1038/s41746-023-00927-3
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37813960/
- **Licence:** CC-BY

## Section: Abstract

Data-driven decision-making in modern healthcare underpins innovation and predictive analytics in public health and clinical research. Synthetic data has shown promise in finance and economics to improve risk assessment, portfolio optimization, and algorithmic trading. However, higher stakes, potential liabilities, and healthcare practitioner distrust make clinical use of synthetic data difficult. This paper explores the potential benefits and limitations of synthetic data in the healthcare analytics context. We begin with real-world healthcare applications of synthetic data that informs government policy, enhance data privacy, and augment datasets for predictive analytics. We then preview future applications of synthetic data in the emergent field of digital twin technology. We explore the issues of data quality and data bias in synthetic data, which can limit applicability across different applications in the clinical context, and privacy concerns stemming from data misuse and risk of re-identification. Finally, we evaluate the role of regulatory agencies in promoting transparency and accountability and propose strategies for risk mitigation such as Differential Privacy (DP) and a dataset chain of custody to maintain data integrity, traceability, and accountability. Synthetic data can improve healthcare, but measures to protect patient well-being and maintain ethical standards are key to promote responsible use.

## Section: Introduction

Data is the lifeblood of modern healthcare bearing the potential to improve patient care by powering clinical research, and advancing public health initiatives. However, the promise of real-world data to enable personalized medical care, to guide policymaking, and to respond to rapidly changing conditions is tempered by the significant challenges inherent in accessing high-quality datasets. Synthetic data offers an attractive alternative that addresses privacy concerns, streamlines data utility agreements, protocol submissions, and ethics review approvals, and decreases costs. In light of this potential, synthetic data has been utilized in other fields such as finance and economics to evaluate risk management, to optimize complex portfolios, and to enhance algorithmic trading particularly when access to real-world financial data is limited or privacy concerns are raised by financial agencies1. However, the use of synthetic clinical data to evaluate risk in clinical decision-making is modulated by the following challenges: the liability with modeling error is more consequential and the stakes for patients and providers are high2,3. Healthcare stakeholders are typically risk-averse and prefer precise replication of the original healthcare records and have decreased trust in clinical diagnosis derived from AI-based prediction models using synthetic datasets3,4. In this article we review the generation techniques, applications, and definitions of synthetic data in the context of healthcare and explore associated privacy issues. We highlight these concerns and propose strategies to mitigate harm, aiming to harness the full potential of synthetic data in advancing medical research and patient care.

## Section: What is synthetic data?

Despite the interest in synthetic data, the field is still developing and has no clear consensus regarding a unified definition. The absence of a universally accepted definition of synthetic data leads to inconsistent use of the term and interpretations that vary across contexts, thereby affecting reproducibility and transparency in research involving synthetic data. A working definition has been recently proposed by the Royal Society and The Alan Turing Institute, where synthetic data is “data that has been generated using a purpose-built mathematical model or algorithm, with the aim of solving a (set of) data science task(s)”5. This proposed definition is particularly interesting when compared to the alternative definitions emphasizing the creation of new data values mirroring the original data’s statistical characteristics6. This new working definition stresses the functional and intentional aspects of synthetic data, shifting focus from mere replication of statistical properties to the strategic use of these artificial constructs in addressing complex scientific challenges. The main types of synthetic data in clinical settings include tabular, time-series, or text-based synthetic data. Additional categories also include synthetic images, video, or audio simulation.

## Section: What is synthetic data? › Synthetic data generation and types

The concept of using synthetic data, originating from computer-based generation, to solve specific tasks is not novel. This approach traces back to the foundational work of Stanislaw Ulam and John von Neumann in the 1940s, focusing on Monte Carlo simulation methods7. Modern synthetic data generators range from deep learning structures like Generative Adversarial Networks (GANs)8 and Variational Auto-encoders (VAEs)9, to agent-based econometric models10, or stochastic differential equations simulating physical or economic systems11. The growing interest in the medical use of synthetic data has led companies to develop open source (e.g., Synthea)12 or commercial (e.g., MDClone’s Synthetic Data Engine)13 tools that can automate the generation of high-quality and clinically realistic synthetic datasets.

Regardless of the methodology, the classification of synthetic data is not rigid and often represents a spectrum that ranges from partially to fully synthetic. Partially synthetic data incorporates real-world data with synthetic data14. In healthcare, partially synthetic data has been used as a proxy for real-world data to protect patient privacy while still allowing researchers to conduct analyses. For example, Loong et al.15 investigated the use of partially synthetic data as a proxy for real-world data in large-scale health surveys. The study reviewed inferential methods for partially synthetic data, including the selection of high disclosure risk variables for synthesis, specification of imputation models, and identification of disclosure risk assessment. The results showed that partially synthetic data can be used to protect patient privacy while still allowing researchers to conduct analyses.

Fully synthetic data is created entirely de novo based on predefined rules, models, or simulations16. It does not rely on or represent real-world data but is instead designed to replicate the kinds of complexity and variability that might be seen in real-world scenarios. Other than data quality, fully synthetic data can address the issue of data scarcity that may affect both linear and non-linear models as well as the rapidly proliferating large language models by creating supplementations to the available datasets.

## Section: Applications of synthetic data in healthcare

Synthetic data has the potential to estimate the benefit of screening and healthcare policies, treatments, or clinical interventions, augment machine learning algorithms (e.g., image classification pipelines), pre-train machine learning models that can then be fine-tuned for specific patient populations, and improve public health models to predict outbreaks of infectious diseases17–27.

Building upon the potential uses of synthetic data mentioned earlier, the study by Davis et al.28 serves as a tangible example of how these datasets can be generated and utilized to investigate healthcare policy implications, particularly in the context of demographic aging. The authors explored the use of micro-simulation techniques to create a synthesized dataset and test policy options, focusing on the case of health service effects under demographic aging. The study integrates multiple data sources, including the New Zealand Health Survey (NZHS), Australian Health Survey (ANHS), and National Primary Medical Care Survey (NPMCS) to create a synthetic dataset for microsimulation in healthcare policy analysis. The process involved imputation techniques to enrich the representative sample from NZHS with data from ANHS and NPMCS. Subsequently, the synthesized dataset could be used to evaluate the impact of various policy scenarios on health service outcomes, such as variations in morbidity and disability, community support, and doctor behavior. These scenarios are presented as binary alternatives, enabling the exploration of both optimistic and pessimistic policy outcomes on healthcare demand and resource utilization. Furthermore, the authors analyzed the impact of demographic aging by re-weighting the 2002 population to a 2021 projection based on medium birth, mortality, and migration rates. The average number of visits increased slightly from 6.7 to 6.9 per year for general practitioner (GP) users. The researchers tested three components: morbidity, social support, and practitioner behavior. For the 65+ age group, average GP visits doubled from 8.8 to 15.3 for higher morbidity scenarios, while social support remained unaffected. The authors also found that prescription rates for more interventionist GPs were nearly double compared to least interventionist colleagues. Referral rates for the most interventionist GPs were six times higher than the most conservative (30% vs. 5%). The use of synthetic data in this example is an approach that could allow policymakers to make decisions on resource allocation after analyzing a range of possible scenarios to gain insights into healthcare demand and resource utilization.

The broad applicability and adaptability of synthetic datasets extend beyond their use in policy simulation and across multiple data modalities. A different but equally innovative approach to using synthetic data is illustrated in a study by Julia et al. in 2020 leveraged a Natural Language Processing (NLP) model by training it with synthetic datasets created from patient discharge reports29. The model effectively targets mental health diseases to predict the corresponding diagnosis and phenotypes. Electronic Health Records (EHRs) provide NLP data that can be utilized for specifying the critical aspects of a patient’s disease and anticipated pathways. For patients with mental health issues, the EHRs are typically based on an unstructured text that can be generated synthetically for training language models to classify complex diseases. Since mental health information is considered particularly sensitive, the use of synthetic text mitigates the risk for compromising sensitive information for individual patients. Synthetic datasets can also be useful in clinical challenges that involve large populations and epidemiological phenomenon, such as in the COVID-19 pandemic. Synthetic datasets were useful in improving the challenge of improving data scarcity in augmenting data volume in imaging studies in the COVID-19 pandemic30. In particular, Das et al.31 created conditional synthetic datasets for chest CT scans to classify COVID-19 patients from a population of normal individuals and pneumonia patients. The authors demonstrated that using synthetic datasets could improve the accuracy COVID-19 detection process compared to the original datasets. The discussed studies illustrate the multifaceted potential and adaptability of synthetic data in healthcare. Whether for probing healthcare policy impacts in an aging demographic, enhancing NLP models for mental health diagnoses, or bolstering COVID-19 detection in CT scans, synthetic datasets provide invaluable tools for researchers. By bolstering the volume and variability of available data, synthetic datasets facilitate more robust and comprehensive analyses, thereby informing and improving healthcare strategies, machine learning models, and disease detection methods.

## Section: Applications of synthetic data in healthcare › Synthetic data and digital twins

Synthetic data is also helpful for digital twins, which are virtual replicas of physical systems or processes that can be used to simulate and predict their behavior in real time. The use of digital twins in healthcare is still underdeveloped, but synthetic data could be used to create personalized models of patients, needed to optimize treatment plans, and improve patient outcomes. One area where digital twins are being increasingly used is in hospital efficiency and operations, where synthetic data is used to create realistic models that can simulate different scenarios and predict outcomes. In the creation of a hospital digital twin, synthetic data can be used to simulate different scenario, such as changes in patient volume, staff level of training, and equipment availability, thus hypothetically allowing administrators to optimize staffing levels and resource allocation, reducing cost and improve patient outcomes32,33. Synthetic data can also be used to create digital twins of patients and their trajectories, which can be used to optimize treatment plans and improve patient outcomes34–37. By creating a personalized model of a patient, synthetic data can be employed to simulate different treatment options and predict their effectiveness, thus improving patient outcomes and possibly reducing costs.

## Section: Applications of synthetic data in healthcare › Potential pitfalls: bias and interpretability

The incorporation of synthetic data in healthcare has been lauded for its potential to circumvent the challenges surrounding data scarcity and privacy. However, this potential carries concerns such as the risk of bias amplification, low interpretability, and an absence of robust methods for auditing data quality.

Bias is defined as a systematic discrepancy or persistent deviation that originates during the data sampling or testing process. This can lead to an overestimation or underestimation of the risks associated with specific clinical outcomes. Consequently, if the primary dataset used to generate synthetic data carries inherent biases, the synthetic data could unintentionally magnify these biases. This can result in misinformed or discriminatory outcomes in medical research and practice, further perpetuating existing inequalities and placing vulnerable populations at heightened risk of harm and discrimination38,39. This bias could originate from the population under study, the techniques employed to collect data, or the methods used to derive the new dataset40–42.

For instance, if a synthetic dataset is trained on a dataset of facial images that majorly includes people from a certain ethnicity, the synthetic images generated will naturally reflect this imbalance, thus perpetuating the initial bias. This leads to AI systems being “blind” to data beyond their training sets, unable to accurately represent or make fair decisions about the unrepresented categories. This is known as the “out-of-distribution” (OOD) problem, a key challenge for AI systems working with synthetic data43. Despite synthetic data may potentially solve this limitation by oversampling under-represented characteristics, the danger lies in the risk of overgeneralization and potential creation of non-existent or incorrect correlations. This artificial augmentation may in fact worsen the out-of-distribution issue, by falsely representing certain demographics and their associated medical profiles. Hence, it is crucial that the generation of synthetic data is accompanied by scrutiny and consistent evaluations to minimize these biases. Automatic AI-based methods can be used to address the OOD problem, such as the incorporation of anomaly detection techniques which can identify instances that deviate significantly from the training data distribution, helping to detect and handle OOD examples44. By flagging or rejecting such examples, AI systems can avoid making unreliable predictions or decisions.

Bias can also be derived from the generative methods used to derive the synthetic dataset. There are considerable challenges associated with interpreting synthetic data generation models, including the black-box nature of generation algorithms, limitations in the evaluation metrics, and the potential for overfitting or underfitting. This lack of transparency can erode trust in the generated synthetic data, making it difficult for healthcare professionals and researchers to make reliable conclusions or informed decisions based on the data45. Explainable AI (XAI) techniques play a crucial role in ensuring the interpretability and transparency of AI systems, particularly when dealing with synthetic data. XAI methods enable users to understand the underlying mechanisms and decision-making processes of AI models, providing insights into the input-output relationships and the presence of biases46. In the context of healthcare, XAI techniques such as SHAP (SHapley Additive exPlanations) have been used to interpret the predictions made by machine learning models, ensuring transparency and accountability in decision-making47. XAI methods allow users to scrutinize and understand the decisions made by AI systems, which is particularly crucial in domains where decision-making should be transparent, such as healthcare47. In the context of synthetic data, XAI techniques can help assess if the synthetic data maintains the desired input-output relationships similar to those found in real data46. By using XAI methods, it becomes possible to identify biases and assess the extent to which the synthetic data represents real-world scenarios. However, it is important to note that XAI methods are not without challenges. The interpretability of AI models and the explanations provided by XAI techniques can be subjective and context-dependent48. Different stakeholders may have different requirements and interpretations of what constitutes a satisfactory explanation48. Additionally, the trade-off between accuracy and interpretability should be carefully considered, as more interpretable models may sacrifice some level of predictive performance49.

A significant challenge that arises in the realm of synthetic data pertains to the necessity for robust auditing methods, particularly when XAI methods prove insufficient in evaluating the accuracy and representativeness of the data. The crux of the issue lies in the fact that conventional techniques used to generate synthetic data may inadequately capture the rich complexity and diverse array of real-world medical scenarios. Consequently, the development of novel auditing methods becomes imperative to ensure the true representativeness of synthetic data. One potential approach to auditing methods involves leveraging advanced statistical techniques and machine learning models to accurately assess the similarity between synthetic and real-world datasets. Techniques such as distribution matching50, correlation analysis51, and dimensionality reduction52 can capture the intricate correlations and patterns inherent in real-world medical scenarios, enhancing the data’s representativeness.

Another strategy would involve creating domain-specific evaluation metrics and benchmark datasets, particularly tailored for healthcare applications. By curating benchmarks that accurately represent a wide spectrum of real-world medical scenarios, researchers and practitioners can effectively compare the performance of various synthetic data generation techniques53. It’s also important to involve patients and healthcare professionals in the development and validation of synthetic data to ensure its relevance and representation of real-world medical scenarios. By involving human input, AI systems can learn from the expertize and domain knowledge of humans to improve their performance. This human-in-the-loop approach can help address the challenges posed by synthetic data scenarios and enhance the reliability and robustness of generative models54.

Lastly, transparency in the form of clear documentation of the data generation process, potential limitations, and data biases can help identify actual and potential errors. In balancing the benefits of synthetic data with the challenges of bias, interpretability, and the need to audit data quality, it becomes crucial to prioritize patient well-being and maintain ethical standards in healthcare.

## Section: Privacy concerns and regulatory agencies

Synthetic data poses serious risks to data privacy and protection. As argued in a recent scoping review55, privacy is not something to be considered on as an afterthought once a system has already been designed and deployed; a “privacy-by-design” mindset should proactively be applied, particularly when working with clinical data. The key challenge is to ensure that synthetic data derived from sensitive medical information does not unintentionally disclose identifiable details about individuals or lead to re-identification, violating privacy and data protection principles.

## Section: Privacy concerns and regulatory agencies › Regulatory blind spots and proposals

At present, there is no clear legislation surrounding the use of synthetic data56 and current data protection regulations such as the General Data Protection Regulation (GDPR) and the Health Insurance Portability and Accountability Act (HIPAA) are limited in their ability to address all the potential risks associated with synthetic data57. The two sets of regulations follow the principle that all patients must give their consent before their data are processed or shared, with exceptions when data processing is mandatory, such as for payment or treatment purposes. The simplest method of privacy protection is to remove all fields that could directly and uniquely identify an individual as recommended by HIPAA, which identified 18 such items (e.g., name, social security number, phone number). This was deemed sufficient to de-identify data until the middle of the 2000s, and following the HIPAA Privacy Rule 45 CFR 164, such data is no longer considered Protected Health Information (PHI)58. The underlying premise was that the disclosure did not pose a material risk to privacy once these 18 types of information were deleted, and the disclosing entity did not actually know that the data in the de-identified dataset could be used to identify an individual. However, it has recently become evident that a variety of other data fields can be used to identify people59. GDPR expands the scope of protected information beyond the definition of PHI, using the term “personal data”, which relates to any information related to an identified or identifiable natural individual. While HIPAA is limited to information generated by healthcare providers related to the medical treatment of patients, the GDPR refers to a natural individual as an entity that can be identified directly or indirectly by other indicators such as physiological, genetic, mental, and cultural identity58. The GDPR delineates two forms of data de-identification: pseudonymization and anonymization. Data pseudonymized under GDPR, which is still subject to its legal constraints, often resembles de-identified data under HIPAA. Encrypted with a patient key, data could be de-identified under HIPAA, but it would only be pseudonymized under GDPR, and thus still subject to its regulations. Full anonymization under GDPR is hard to achieve and offers minimal analytical value. Using GDPR-protected data necessitates substantial legal compliance, especially for non-EU entities60. Identifying what constitutes “identifiable” data is complicated by re-identification potential. Recent studies have disproved the that de-identification definitively prevents re-identification, citing examples of predictability using accessible personal details. While the challenges of synthetic data regulation are not confined to the field of medical research alone, they also permeate into other facets of healthcare, like the development of medical devices. The work by Chen et al.61 sheds light on this broader perspective, underscoring the crucial role of regulatory bodies in facilitating the judicious application of synthetic data in healthcare, specifically within the arena of medical devices incorporating artificial intelligence and machine learning algorithms. The Artificial Intelligence Synthetic Data for Medical Devices (AISAMD) program, a joint venture between the US Food and Drug Administration (FDA) and Standards and Technology (NIST), endeavors to create a framework for the utilization of synthetic data for evaluating such medical devices62. This initiative underscores the potential of synthetic data in machine learning for medical applications while stressing the need for stringent validation methods and guidelines for responsible usage in regulatory submissions. This regulation of synthetic data, bears implications not just for patient privacy and data security, but also for the advancement of technological innovation in healthcare. However, incorporating the ethical and legal challenges63 associated with synthetic data sharing and usage often straddle the definitions set by existing data protection regulations, thereby creating a regulatory blind spot. This loophole could potentially be exploited by malicious entities, leading to discriminatory use of synthetic data and exacerbating health disparities, undermining efforts to improve patient outcomes. Given this regulatory ambiguity, it behooves systems to revise current data protection legislation with precise definitions and more stringent controls for synthetic data. The proposed measures include updating data protection regulations to encompass synthetic data, establishing a centralized regulatory body for oversight, and promoting transparency and accountability in the development and application of synthetic data. Additionally, it is equally important that future research continues to explore potential privacy risks associated with synthetic data and devise strategies for mitigating these risks. This research should also scrutinize the technical, social, and ethical implications of synthetic data usage in healthcare, offering a holistic examination of this emergent field.

## Section: Privacy concerns and regulatory agencies › Regulatory blind spots and proposals › The opportunity of differential privacy

Brauneck et al.63 recently reviewed privacy-enhancing technologies (PETs) from a legal standpoint to engage in a thoughtful discussion of how GDPR legislation in the European Union (EU) relates to commonly used PETs including federated learning (FL), secure multiparty computation (SMPC), and differential privacy (DP). DP a concept first proposed in 2006 by Dwork et al.64, is gaining broad acceptance as a solid, practical, and trustworthy privacy framework and its application has been also explored with synthetic data65–67. DP is a precise mathematical constraint that ensures the privacy of individual pieces of information in a database while answering queries about the aggregate. The concept of DP is based on the notion of adding noise to the data to protect the privacy of individuals. This noise introduction is governed by two parameters—epsilon and delta. Epsilon is a parameter that controls the amount of noise added to the data by varying the privacy budget, which represents the maximum amount of privacy loss that can be tolerated. A smaller value of epsilon indicates a higher level of privacy protection, but it also results in a higher level of noise in the data. Delta is a parameter that controls the probability of a privacy breach. It is a measure of the probability that the privacy of an individual is compromised. A smaller value of delta indicates a lower likelihood of a privacy breach but also results in higher noise in the data. The choice of the Epsilon parameter to achieve a balance between privacy and statistical utility may result difficult, with researchers proposing the institution of an “Epsilon Registry” to help make informed implementation choices68. As argued by Ficek et al.69 despite its robust protections, DP has not yet seen widespread adoption in the health sector. The focus so far has been primarily on creating predictive algorithms, sanitized data publishing, and training machine learning algorithms, particularly in the areas of genomics, neuroimaging, and personal device-derived health data streams. However, significant gaps are crucial for epidemiology and clinical research, especially for explanatory modeling and statistical inference. Another challenge is the privacy-utility trade-off; hence, experimental deployment and real-world case studies are required to understand this better.

Bridging this gap between the theoretical robustness of differential privacy and its practical implementation in the health sector, groundbreaking efforts such as the one by Jordon et al.70 have started to emerge, utilizing differential privacy in the context of synthetic data generation. Their novel approach incorporates a modification to the Private Aggregation of Teacher Ensembles (PATE) methodology, incorporating it into GANs for the creation of privacy-preserving synthetic data. Named PATE-GAN, this system utilizes a generator network for synthetic data production from random noise, which is then appraised by a discriminator network. This innovative approach replaces the single discriminator network with multiple teacher networks. Each network is trained on a separate segment of the initial dataset and provides feedback to the generator. This aggregation ensures a balance in model influence and upholds robust differential privacy. PATE-GAN has proven superior to conventional, yet outdated benchmarks, such as Differential Private-GAN (DP-GAN)71 and excels in generating synthetic data that closely resemble the original dataset. To evaluate the similarity of synthetic samples with the original data, the authors propose a new metric, termed “synthetic similarity.” This cutting-edge technique offers enhanced performance and a unique evaluation metric, making it adaptable across a variety of datasets and applications. In essence, PATE-GAN constitutes a significant stride forward in the realms of machine learning and privacy. In summary, PATE-GAN, through its innovative approach to differential privacy and the introduction of a unique “synthetic similarity” metric, represents a major advancement in the intersection of machine learning and data privacy, enabling the production of high-quality synthetic data that balances privacy protection with utility across various datasets and applications.

In conclusion, as privacy-enhancing technologies evolve to meet the challenges posed by data privacy regulations and the need for practical implementation in health research, differential privacy emerges as a robust, reliable, and promising approach. Despite its current limitations, particularly in the context of explanatory modeling and statistical inference, its adoption in cutting-edge frameworks such as PATE-GAN highlights its versatility and potential. PATE-GAN’s innovative approach, the introduction of the “synthetic similarity” metric, and the ability to generate high-fidelity synthetic data show a significant advancement in the delicate balance between data privacy and utility.

## Section: Privacy concerns and regulatory agencies › Establishing a digital chain-of-custody

Despite the promise of DP to mitigate risk, it is not a panacea. The healthcare community must consider safeguards on the diffusion of synthetic datasets by developing and implementing appropriate regulations. For example, it is crucial to establish a robust digital chain of custody to ensure the integrity, security, and privacy of data throughout its lifecycle and it must encompass data sharing, storing, and disposal to provide transparency, traceability, and accountability at each stage.

The application of a digital chain of custody in data sharing is crucial for ensuring the integrity, security, and accountability of shared data. The digital chain of custody refers to the process and documentation that tracks the custody and movement of data from its collection to its final destination72,73. Digital chain of custody applications and software have been developed to document and track digital evidence, ensuring its integrity and providing a verifiable record of its custody72,73. Blockchain technology has also been utilized to enhance the chain of custody in data sharing. Blockchain-based systems provide a decentralized and immutable ledger that records the transactions and movements of data74. For example, Wang et al.75 proposed a chain-of-custody system is needed to document the sequence of custody of sensitive big data. They designed a prototype of a block-chain big-data sharing system (BBS), where a user can register a dataset with BBS for sharing. To acquire the shared file an authenticated and authorized recipient must use transactions and interacts with BBS across four stages including file transfer request, encrypted data transfer, file key retrieval, and file decryption. Each transaction is recorded in the ledger and serve as chain of custody to document the trail of the data.

This example, among others, has been previously employed to share real-world data, but there is no current process in place for synthetic datasets. The digital chain of custody should begin with generating synthetic data, outlining the methodologies and techniques used to create the data, as well as any privacy-preserving measures implemented, such as differential privacy. This information should be documented and accompany the synthetic data as it moves through various stages of its lifecycle. During data sharing, a secure and controlled process should be established for transferring synthetic data between different parties, such as healthcare providers, researchers, and policymakers. This process should include the use of encryption, secure authentication, and access control mechanisms to protect the data from unauthorized access or tampering. Furthermore, each data-sharing transaction should be logged, detailing the data transfer’s sender, receiver, timestamp, and purpose. For data storage, the chain of custody should ensure that synthetic data is securely stored using encryption and access control mechanisms to protect it from unauthorized access, modification, or leakage. Data storage locations and associated security measures should be documented and regularly audited to confirm compliance with established data protection standards and regulations. Finally, when it comes to data disposal, a clear protocol should be in place for the secure deletion or destruction of synthetic data once it is no longer needed. It involves using secure erasure methods to prevent the recovery of deleted data and maintaining disposal records that detail the time, method, and reason for data destruction.

In addition to these measures, it is vital to implement regulations that mandate a comprehensive research proposal evaluation before granting access to synthetic data. It ensures that the research plan is robust, genuine, and has a clear data analysis objective. Furthermore, researchers should be required to provide timed-release updates on the progress of their analysis and usage of the synthetic data, fostering transparency and allowing for better monitoring and evaluation of the data’s impact. Implementing these regulatory requirements makes it possible to mitigate potential risks associated with the misuse of synthetic data while promoting responsible research practices and maximizing the benefits of synthetic data in healthcare.

## Section: Discussion & conclusion

AI applications in medicine can improve research capabilities and create cost-effective solutions but require careful consideration of potential biases in synthetic data to ensure accurate representation and adequate safeguards for privacy such as differential privacy and a digital chain of custody. As summarized by Fig. 1, the creation and application of synthetic data should be tailored to specific use cases. In healthcare, significant privacy concerns underscore the need for the implementation of privacy-preserving techniques to protect sensitive medical data. We propose the concept of a digital chain of custody for synthetic data to ensure data integrity, security, and confidentiality throughout its lifecycle. To navigate these intricacies, collaborative efforts between the healthcare community and regulatory agencies are imperative in developing and implementing laws and regulations governing synthetic data. Moreover, to establish comprehensive guidelines and best practices for the responsible use of synthetic data in medicine and healthcare, it is crucial for healthcare providers, researchers, technology developers, and patients to be actively engaged and collaboratively involved.Fig. 1Highlights on Synthetic Data and their application in healthcare research, reviewing bias, quality, and privacy concerns.Despite the first attempt to generate synthetic data dates bate to the 1940s, current state of the art methods use Generative Adversarial Networks (GANs) or Variational Auto-encoders (VAEs). In terms of classification, synthetic data encompasses a spectrum that ranges from partially to fully synthetic. While partially synthetic incorporates real-world data, fully synthetic data are generated de novo. As reported in the text, synthetic data can have several applications in healthcare research, including imaging, infective disease prevention and outbreaks prediction, and digital twins. However, the lack of robust methods to audit the perpetration of bias, accuracy, and representativeness of real-world medical scenarios, has severely limited interpretability, use and trust from the healthcare sector. One of the greatest concerns related to synthetic data involves patients’ privacy. Current regulations from General Data Protection Regulation (GDPR) and the Health Insurance Portability and Accountability Act (HIPAA) are not sufficient or up-to-date to cover possible leakage of patients’ information from synthetic dataset. In this context, differential privacy may result valuable, but its usage has been limited by the privacy-utility trade-off. The definition of a clear chain of custody, can ensure integrity, security, and data privacy throughout data lifecycle providing transparency, traceability, and accountability at each stage.

In conclusion, while synthetic data possess the potential to revolutionize healthcare by offering improved research capabilities and cost-effective solutions, overcoming the challenges related to biased information, data quality concerns, and potential privacy risks are of paramount importance. This calls for the healthcare community’s active participation in discussions and collaborations with regulatory bodies, technology developers, and patients, thus fostering a proactive approach to harness the transformative power of synthetic data. Such a process will prioritize patient well-being and uphold ethical standards in medicine and healthcare.

Despite the first attempt to generate synthetic data dates bate to the 1940s, current state of the art methods use Generative Adversarial Networks (GANs) or Variational Auto-encoders (VAEs). In terms of classification, synthetic data encompasses a spectrum that ranges from partially to fully synthetic. While partially synthetic incorporates real-world data, fully synthetic data are generated de novo. As reported in the text, synthetic data can have several applications in healthcare research, including imaging, infective disease prevention and outbreaks prediction, and digital twins. However, the lack of robust methods to audit the perpetration of bias, accuracy, and representativeness of real-world medical scenarios, has severely limited interpretability, use and trust from the healthcare sector. One of the greatest concerns related to synthetic data involves patients’ privacy. Current regulations from General Data Protection Regulation (GDPR) and the Health Insurance Portability and Accountability Act (HIPAA) are not sufficient or up-to-date to cover possible leakage of patients’ information from synthetic dataset. In this context, differential privacy may result valuable, but its usage has been limited by the privacy-utility trade-off. The definition of a clear chain of custody, can ensure integrity, security, and data privacy throughout data lifecycle providing transparency, traceability, and accountability at each stage.


---

# Hybrid quantum-classical machine learning for generative chemistry and drug design

- **Authors:** A I Gircha, A S Boev, K Avchaciov, P O Fedichev, A K Fedorov
- **Issuer:** Scientific reports
- **Type:** Scientific article
- **Published:** 2023-05-22
- **Language:** en
- **DOI:** 10.1038/s41598-023-32703-4
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37217521/
- **Licence:** CC-BY

## Section: Abstract

AbstractDeep generative chemistry models emerge as powerful tools to expedite drug discovery. However, the immense size and complexity of the structural space of all possible drug-like molecules pose significant obstacles, which could be overcome with hybrid architectures combining quantum computers with deep classical networks. As the first step toward this goal, we built a compact discrete variational autoencoder (DVAE) with a Restricted Boltzmann Machine (RBM) of reduced size in its latent layer. The size of the proposed model was small enough to fit on a state-of-the-art D-Wave quantum annealer and allowed training on a subset of the ChEMBL dataset of biologically active compounds. Finally, we generated 2331 novel chemical structures with medicinal chemistry and synthetic accessibility properties in the ranges typical for molecules from ChEMBL. The presented results demonstrate the feasibility of using already existing or soon-to-be-available quantum computing devices as testbeds for future drug discovery applications.Subject terms: Quantum information, Quantum simulation, Computational biophysics, Medicinal chemistry

## Section: Introduction

Drug design is the process of identifying biologically active compounds and relies on the efficient generation of novel, drug-like, and yet synthetically accessible compounds. So far, only about 108 substances have ever been synthesized1, whereas the total number of realistic drug-like molecules is estimated to be in the range between 1023 and 10602. This is why deep learning3 and particularly deep generative models4–7 are believed to be helpful in generative chemistry and computational drug discovery applications involving sampling and scoring novel chemical structures from the very large and hitherto unknown distributions of possible drug-like molecules (see examples and benchmarks in Refs.8–10).

A fully developed generative model should implicitly estimate the fundamental molecular properties, such as stability and synthetic accessibility for each generated compound and its intermediate products. All those features depend on the ability of the network architecture to approximate the solutions of the underlying quantum mechanical problems, which is computationally hard for molecules of realistic size. Quantum computers are naturally good for solving complex quantum many-body problems11 and thus may be instrumental in applications involving quantum chemistry12–15. Moreover, quantum algorithms can speed up machine learning14,16. Therefore, one can expect that quantum-enhanced generative models17, including quantum GANs18, may eventually be developed into ultimate generative chemistry algorithms.

Exploring the full potential of quantum machine-learning algorithms requires the development of fault-tolerant hardware16, which is not yet accessible. Meanwhile, readily available noisy intermediate-scale quantum (NISQ) devices19 provide a test-bed for the development and testing of quantum machine-learning algorithms for practical problems of modest size. For example, quantum annealing processors20 could potentially enable more efficient solving quadratic unconstrained binary optimization problems and approximating sampling from the thermal distributions of transverse Ising systems. These applications are attractive in the context of machine learning as tools both for solving optimization problems21–24 and sampling25–28. Gate-based architectures are also of interest for machine learning16, in particular, in the context of quantum GANs, which are a subject of intensive research29–33 including recent demonstration of learning and generation of hand-written digit images on a quantum processor33.

In this work, we prototyped a discrete variational autoencoder (DVAE, see Ref.34), whose latent generative process is implemented in the form of a Restricted Boltzmann Machine (RBM) of a small enough size to fit readily available annealers. We trained the network on D-Wave annealer and generated 2331 novel chemical structures with medicinal chemistry and synthetic accessibility properties in the ranges typical for molecules from ChEMBL. Hence, we demonstrated that the hybrid architecture might allow practical machine-learning applications for generative chemistry and drug design. Once the hardware matures, the RBM could be turned into Quantum Boltzmann Machine (QBM), and the whole system might be transformed into a Quantum VAE (QVAE34) and sample from richer non-classical distributions.

## Section: Results

We proposed and characterized a generative model (see Fig. 1) in the form of a combination of a Discrete Variational Autoencoder (DVAE) model with a Restricted Boltzmann Machine (RBM) in the latent space34,35 and the Transformer model36. The model learns good representations of chemical structures from ChEMBL, which is the manually curated database of biologically active molecules with drug-like properties37.

Following Ref.4, we used common SMILES38 encoding for organic molecules and trained the system to encode and subsequently decode molecular representations via optimizing evidence lower bound (ELBO) for DVAE log-likelihood34:

Here, E denotes the expectation value, DKL is the Kullback–Leibler (KL) divergence, and pθ(z) is the prior distribution in the latent variable space and is encoded by RBM as in Ref.34 (see MM). The two layers of RBM contain 128 units each. An RBM of this size can be sampled on readily available quantum annealers. We used the spike-and-exponential transformation34 as a smoothing probability distribution between the discrete z and continuous ζ variables and employed the standard reparameterization trick to avoid calculating derivatives over random variables.

The respective encoder and decoder functions, qϕ(z|x) and pθ(x|ζ), are approximated by the deep neural networks with Transformer layers each depending on its own set of adjustable parameters ϕ and θ. We modified the KL divergence term with β=0.1 to avoid posterior collapse39.

We trained the network for 300 epochs until apparent convergence using Gibbs sampling (see the red and yellow lines in Fig. 2 representing the total loss over the validation and train sets, respectively). In what follows, we discuss the two checkpoints: the fully trained (Gibbs-300) and, for reference purposes, the intermediate model (Gibbs-75) appearing by the end of the 75th epoch. We expect that with improvements in quantum hardware (in particular, coherence times of qubits), training the DVAE with quantum annealing technique could be comparable to or overcome existing techniques.

VAE is a probabilistic model. In particular, this means that each of the discrete states in the latent variables is decoded into a probability distribution of SMILES-encoded molecules. On top of Fig. 1 we provide an example of encoding a particular molecule (diaveridine) and its reconstruction by the Gibbs-300 network (see the structures at the bottom). In this case, the target molecule was reconstructed exactly in 46% runs (see the reconstruction probabilities and Tanimoto similarities to the target molecule next to the reported structures).

DVAE is a generative model that can produce novel molecules with properties that presumably match those in the training set. In Fig. 3 and Table 1, we compare the distributions of the basic biochemical properties of the molecules in the training set and among molecules generated by each of the models with discrete latent variables trained and discussed in this work. The novel molecules were mainly valid (55% and 69% in Gibbs-75 (10k molecules) and Gibbs-300 (50k molecules) models, respectively). We kept track of molecular weight (MW), the water-octanol partition coefficient (logP), the synthetic accessibility (SA40) score, and the quantitative estimation of drug-likeness (QED41) score, which are common physico-chemical properties for benchmarking molecular generative models9.

Aside from the biochemical and drug-likeness properties, we also measured the novelty of generated molecules. Less than 1% of the generated molecules (0.36% and 0.22% in Gibbs-75 and Gibbs-300 models, respectively) had Tanimoto similarity larger than 0.9 to any molecule in the training set , and less than 10% of the generated molecules are similar to any molecule in the training set with T>0.7 in both models. Extra training time improved both the validity of the generated molecules and brought the molecular properties closer to those found in the training set (see the relevant Gibbs-75 and Gibbs-300 columns in Table 1).

The proposed network architecture is sufficiently compact to fit the D-Wave hardware. Hence, we were able to train the network using the annealer instead of Gibbs sampling. The learning of the hybrid model on D-Wave progressed slower than that on a classical computer using Gibbs sampling (see the blue solid and cyan dashed lines in Fig. 2 corresponding to the total loss of the model on the validation and the training sets). We had, however, to stop the training before reaching convergence at the 75th epoch due to the limited performance of the available quantum hardware. With its further improvements, we expect to have the ability to prolong the training. Eventually, we used D-Wave to generate 4290 molecular structures (2331 of which are grammatically correct, see Fig. 3 and the corresponding column in Table 1). As expected, the distributions of basic properties of the generated molecules were close to those obtained from the Gibbs-75 model and could be improved if more training time were available.

Scheme of the DVAE learning a joint probability distribution over the molecular structural features x and their latent variable-representations (discrete z and continuous ζ). Here, qϕ(z|x) and pθ(x|ζ) are the encoder and decoder distributions, respectively, whereas pθ(z) is the prior distribution in the latent variable space and is encoded by RBM. We provide an example of the reconstruction of a target molecule (diaveridine) using the Gibbs-300 model saved after 300 epochs of training (here t∈[0,1] is the Tanimoto similarity between the initial molecule and its reconstruction, t=1.0 corresponds to perfect reconstruction, p is the output probability).

Learning curves of DVAE trained with classical Gibbs sampling (red, yellow) and samples from D-Wave annealer (blue, cyan). Training on D-Wave was suspended before reaching convergence due to resource limitations. Also, the learning curve of a simpler model with continuous latent variables is shown (magenta, green).

Distributions of physico-chemical properties of the molecules produced by the proposed generative models (same as in Table 1).

The parameters of distributions of physico-chemical properties of the molecules produced by the generative models discussed in this work.

## Section: Discussion and outlook

VAEs are powerful generative machine learning models capable of learning and sampling from the unknown distribution of input data43,44. As a first step towards building a hybrid quantum generative model, we prototyped the DVAE (along the lines of Ref.34) with the RBM in its latent space34,35. If provided with a large dataset of drug-like molecules, such a system should learn implicit rules governing the stability and synthetic accessibility of small molecules and produce useful representations of molecular structure, which could be used to generate novel and still drug-like molecules for drug design applications such as virtual screening.

As a proof of concept, we built a DVAE involving transformer layers36 in the encoder and decoder components along with additional preprocessing layers that allowed our model to operate at the character-level (rather than on the word-level) to parse SMILES, the textual representations of the input molecules. Using SMILES is not necessarily the best option since these strings are not 100% valid. The only property of SMILES that is essential in our approach is that it is a representation of molecules in terms of character strings and hence we believe that DVAEs can be built to operate with alternative character string representations of molecules, such as SELFIES45.

We trained a compact DVAE with the RBM consisting of two layers of just 128 units each on a small subset containing almost 200,000-random molecules from the ChEMBL database of manually curated and biologically active molecules as the training set. On classical hardware, the system could be trained with Gibbs sampling. We were able to show that the training converged and used the network to generate molecules with the distribution of the basic properties, such as logP, and QED, closely matching those in the training set. Simultaneously, the average size of the molecules increased as the training of the network was progressing. There are relatively harder-to-synthesize compounds among the molecules generated by the network4.

Our generative model outputs drug-like molecules and may be deployed on already existing quantum annealing devices (such as D-Wave Advantage processor). Training of the same architecture network on the quantum annealer proceeded slower per epoch than on the classical computer, most probably due to noise. Nevertheless, the distributions of the molecular properties of generated molecules were sufficiently close to those in the training set or among the molecules generated by classical counterparts Gibbs-75 and 300. While certain discrepancies between distributions were present, these results have been computed only after a limited number of training epochs due to the restrictions on public access to the quantum computer.

Computational drug design applications depend on but are not limited to the generation of novel and synthetically accessible molecules, which is the focus of this work. The authors of the original paper4 have already proposed training additional properties, such as the prediction of the binding constant to a particular target on top of the autoencoder loss. Although a direct extension of VAE for these tasks may be challenging and require further refinements6, in such a form, the network could be used in problems involving actual drug design, i.e., for generating of novel compounds binding specific medically relevant targets. We did not attempt to demonstrate such a capability. However, we have no doubts that DVAE and, eventually, its hybrid implementations, such as QVAE, can be appropriately refitted by adding the extra loss.

The RBM could be turned into Quantum Boltzmann Machine (QBM) so that the whole system might be transformed into a Quantum VAE (QVAE,34) and sample from potentially richer non-classical distributions. Using genuine QBMs should speed up the training of the system (O(logN) vs. O(N) with N being the size of the network16). There was a demonstration in Ref.34, where “quantum” samplers with the non-vanishing transverse fields outperformed DVAE if assessed by metrics achieved at the same number of training cycles (epochs). Construction of QVAE with the controllable non-zero transverse field can, in principle, be performed on the existing generation of D-Wave chips. However, it would require additional hardware tuning and applying a combination of extra tricks such as reverse anneal schedule, pause-and-quench, etc46.

We demonstrated that a useful VAE can be built and trained to generate drug-like molecules while keeping the size of latent representation small and hence practically attainable on already existing quantum annealing devices. We expect that with further developments in the engineering of quantum computing devices, hybrid architectures similar to QVAE would surpass their classical counterparts. More specifically, the network architecture proposed in this work may provide the baseline for further refinements required for running genuinely quantum generative models. The benefit may be especially large in problems potentially involving rules of quantum chemistry, such as learning efficient representations of molecular structures for applications related to generative chemistry and drug design.

## Section: Methods

We proposed and characterized classical and quantum annealer models, which are a combination of Discrete Variational Autoencoder (DVAE) with Restricted Boltzmann Machine (RBM) in the latent space34,35 and the Transformer model36. Original Transformer model was proposed for word-level natural language processing tasks and has encoder-decoder architecture. We used original Transformer layers and developed additional preprocessing layers that allowed us to process character-level SMILES descriptions of molecules. We trained the proposed models on a subset of the ChEMBL dataset by optimizing evidence lower bound (ELBO) for DVAE log-likelihood34, modified with additional coefficient β that multiplies KL divergence term39, see Eq. (1). The sketch of the architecture of our models is illustrated in Fig. 1.

Below we describe in details the dataset, the network architecture, the training parameters, and the training schedule of the classical and quantum annealer models. Also, we describe a simpler classical model with continuous latent variables, which we used in the experiment shown in Fig. 2.

## Section: Methods › Dataset

We used a subset of molecules from the ChEMBL (release 26) database47,48. Our dataset consisted of the 192,000 structures encoded by SMILES strings of the maximum length of 200 symbols and containing the atoms from the organic subset only (B, C, N, O, P, S, F, Cl, Br, I). To focus on the relevant biologically active compounds, we removed salt residuals. Finally, we converted all SMILES into the canonical format with the help of RDKit42.

The processed molecules were randomly assigned into train and validation sets each containing 80% and 20% of all samples (153,600 and 38,400 molecules), respectively.

## Section: Methods › Training DVAE using Gibbs-sampling

Molecular SMILES strings are tokenized with the regular expression from Ref.49, which produced 42 unique tokens. Standard trainable embedding layer and positional encoding from Ref.36 are used. Our implementation utilized a combination of embedding and positional encoding, in which positional encoding is multiplied by an additional correction factor:

where xemb is embedding tensor, pe is positional encoding tensor and demb is the dimensionality of the embedding. This factor is required to make the proportion between embedding tensor and positional encoding closer to that in the original model36. The dimension of embeddings is a model hyperparameter which was set to 32.

We employed a layer of one-dimensional convolutions and a highway layer50 as additional preprocessing layers between the embedding layer and the encoder component. The convolution layer with 160 filters and the kernel size equal to 5 was developed based on Ref.51. We used highway layers since such layers have been shown to improve the quality of character-level models51,52.

The preprocessed 160-dimensional tensor is passed from the highway layer to the encoder, consisting of the stack of 5 Transformer encoder layers. The width of the feed-forward part of the layers is equal to 320. The number of heads in Multi-Head attention is 10. We used GeLU activation53 functions and Dropout with the rate of 0.1.

Original Transformer encoder layers produce output tensor of variable length. The length of the tensor is equal to the size of the input string. In order to further reduce the dimensionality of the latent space layer in the model, we construct a fixed-length tensor from the Transformer encoder output tensor u by calculating the fixed number of vectors from u, which we then concatenate in one tensor. The first two of these vectors are the vector with index 0 from Transformer layers output u and the vector equal to the arithmetic mean of all vectors along the length of the tensor u. Next, we consider the subsets Snm, each consisting of vectors with indices that have the same remainder after division by n for n=2,3,4,5:

For each Snm, we compute the arithmetic mean and concatenate all calculated vectors into the fixed-length output tensor.

Restricted Boltzmann machine (RBM) is implemented in the latent space as presented in papers34,35. The probability distribution of RBM is

where hl are bias weights for units zl and each Wlm is the weight associated with the connection between units zl and zm. The effective temperature is supposed to be equal to 1.0 and is not presented in the formulas. RBM in the proposed model consists of two layers of 128 units each. RBM of this size can be sampled using existing quantum annealing devices. It is worth noting that all the units of RBM in DVAE are latent variables and connected to the rest of the model. Hence, there is no distinction between “hidden” and “visible” units as for standalone RBM34,35.

An informal description of the internal working of the model in the latent space is as follows. The output of the encoder is the vector of probabilities of the discrete latent variables zi being equal to 1, which are conditioned on the input x of the model. These probabilities are sampled to obtain latent binary vector z. Continuous variables ζ are sampled using spike-and-exponential smoothing probability distribution r(ζ|z)34. Vector ζ is used as an input to the decoder module. During training, the parameters of the RBM are adjusted in order to memorize the statistics of the binary vectors z that appear in the latent space. The calculation of the gradient of the parameters of the RBM consists of two parts: the so-called “positive” and “negative” phases. The “positive” phase is calculated using the backpropagation algorithm after the application of the reparameterization trick, which is used to avoid calculating of derivatives over random variables. The “negative” phase of the gradient is estimated using sampling from the RBM distribution.

For molecule reconstruction or generation of similar molecules to a given molecule, the preprocessed SMILES description of the given molecule is passed to the input of the encoder and the whole model is executed. An example of molecule reconstruction and generation of similar molecules is depicted in Fig. 1. For generation of an entirely new molecule the encoder is not used, the trained RBM is sampled to obtain latent binary vector z. This vector is then used to calculate the latent vector of continuous variables ζ, which is given as an input to the decoder. Table 1 and Fig. 3 show results for newly generated molecules.

RBM is sampled by performing 30 steps of Gibbs updates using persistent contrastive divergence (PCD)54.

The decoder works in two modes: training and inference (generation). In the inference mode, decoder uses preprocessing layers. The main part of data processing in both training and inference modes of the decoder consists of Transformer decoder layers. Altogether, we used 5 Transformer decoder layers of the size dmodel=160 (GeLU activation, dropout = 0.1). The width of the feed-forward part of the layers was equal to 320, and the number of heads in Multi-Head attention was 10.

To train the model, we used the rebalanced objective function, in which the KL divergence term is multiplied by the additional coefficient β=0.139 to avoid the posterior collapse problem, and employed the Adam optimizer.

In contrast to the original Transformer model, we used a different learning rate schedule: we trained the model for 300 epochs using the MultiStep learning rate schedule with the initial learning rate equal to 6×10-5. The learning rate was subsequently reduced by the factor of 0.5 at points corresponding to 50%, 75%, and 95% of the length of the training process.

For estimation of the logarithm of the partition function of Boltzmann distribution, we used annealed importance sampling (AIS) algorithm55 during the evaluation of the model at the end of each epoch using 10 intermediate distributions and 500 samples.

Due to resource constraints, we did not have a chance to optimize the hyperparameters or too many architectural variants of the model. The presented variant of the network just worked and can be considered the first step toward a real and effective solution.

## Section: Methods › Training DVAE on a quantum annealer

We used exactly the same network architecture on the quantum annealer with the only difference from the classical case being that the RBM in the latent space was sampled using D-Wave Advantage processor. Also, the quantum model was trained during 75 epochs with constant learning rate equal to 6×10-5.

For estimating the logarithm of the partition function of the Boltzmann distribution during the evaluation of the model, we used a different version of annealed importance sampling (AIS; see Ref.56) with the same parameters as in the classical case.

## Section: Methods › Training model with continuous latent variables

The model with continuous variables in the latent space has similar architecture to the discrete one but is smaller in size. The latent space contains 32+32 normally distributed continuous random variables.

The preprocessing convolution layer consists of 100 filters with kernel size equal to 5. The encoder/decoder consists of 2 Transformer encoder/decoder layers with the width of feed-forward part equal to 200.

The fixed length tensor is calculated in the similar way as in the discrete model. The model is trained using the same initial learning rate and learning rate schedule as in the discrete case.

## Section: Methods › Calculation of molecular similarity with fingerprint

Fingerprints for each molecule are generated using a default function RDKFingerprint in RDKit42. This algorithm produces a topological fingerprint represented by a bit vector with the size of 2048 bits. The Tanimoto similarity is known as a reasonable metric for matching molecules sharing similar fragments57 and is defined for two fingerprints a, b as:

where C is a number of common non-zero bits in a and b; A and B are numbers of non-zero bits that are present in a and b, respectively. The Tanimoto distance could be defined as D(a,b)=1-T(a,b). From the definition, it follows that completely similar molecules (shared identical set of fragments) have Tanimoto similarity equal to 1, while dissimilar molecules (no common fragments) have T=0.

## Section: Acknowledgements

We thank S. Usmanov for help in performing the experiment. P.O.F and A. K. would like to thank Dr. A. Tarkhov from Gero and Daria Orhunova for fruitful discussion and help with the data analysis. We acknowledge online cloud access to the quantum annealing device produced by D-Wave Systems (all experiments with D-wave hardware were performed within the program of global response to COVID-19 and completed in 2021). A.K.F. thanks Russian Science Foundation grant (19-71-10092). P.O.F. and K. A. are supported by Gero PTE. LTD. (Singapore).

## Section: Author contributions

All the authors jointly developed the problem statement and analyzed existing state-of-the-art techniques. A.I.G. and A.S.B. implemented the considered methods and performed the simulation of molecules. All the authors contributed to discussions of the results and writing the manuscript. P.O.F. and A.K.F. supervised the project.

## Section: Code availability

The code that is deemed central to the conclusions is available from the corresponding author upon reasonable request. The data that supports the findings of this study (generated molecules) are available at 10.5281/zenodo.7827952

## Section: Competing interests

Owing to the employments and consulting activities of A.I.G., A.S.B., and A.K.F., they have financial interests in the commercial applications of quantum computing. P.O.F. and K.A. are employees of (P.O.F. is a stake holder in) Gero PTE. LTD. and hence may have financial interests in commercial applications of quantum or hybrid AI/ML systems for drug discovery.

## Section: Contributor Information

P. O. Fedichev, Email: peter.fedichev@gero.ai

A. K. Fedorov, Email: akf@rqc.ru

## Section: Associated Data › Data Availability Statement

The code that is deemed central to the conclusions is available from the corresponding author upon reasonable request. The data that supports the findings of this study (generated molecules) are available at 10.5281/zenodo.7827952


---

# [Identification of Characteristic lncRNA Molecular Markers in Osteoarthritis by Integrating GEO Database and Machine Learning Strategies and Experimental Validation]

- **Authors:** Qiao Zhou, Jian Liu, Ling Xin, Yanyan Fang, Yajun Qi, Yuedi Hu
- **Issuer:** Sichuan da xue xue bao. Yi xue ban = Journal of Sichuan University. Medical science edition
- **Type:** Scientific article
- **Published:** 2023-09-01
- **DOI:** 10.12182/20230960101
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37866944/
- **Licence:** CC-BY-NC

## Section: Abstract

Abstract目的利用GEO（Gene Expression Omnibus）数据库联合机器学习筛选骨关节炎（osteoarthritis, OA）特征性的长链非编码RNA（lncRNA）分子标志物。方法纳入185例OA及76例正常健康人样本，GEO数据库筛选数据集得出差异表达lncRNA，通过随机森林（randomforest, RF）、最小绝对收缩和选择算子（LASSO）逻辑回归、支持向量机递归特征消除（SVM-RFE）3种算法筛选候选的lncRNA模型，绘制受试者操作特征曲线评价模型。收集临床OA患者30例和正常对照15例的外周血，测定免疫炎症指标，RT-PCR定量分析外周血单核细胞lncRNA分子标志物的表达，Pearson分析lncRNA与免疫炎症指标的相关性。结果LASSO得出14个关键标志物，SVM-RFE算法确定6个基因，RF算法确定24个基因。Venn图筛选得出3种算法的重叠基因，包括HOTAIR、H19、MIR155HG和NKILA。受试者工作特征曲线显示这4个lncRNA的曲线下面积均大于0.7。RT-PCR法发现与正常对照组相比，HOTAIR、H19、MIR155HG在OA患者外周血单核细胞中相对表达量升高，NKILA表达量下降（均P<0.01），结果与生物信息学预测结果相一致。Pearson相关性分析表明选定的lncRNA与临床免疫炎症指标相关。结论HOTAIR、H19、MIR155HG和NKILA可作为OA临床诊断分子标志物，且与临床免疫炎症指标相关。Keywords: 骨关节炎, 长链非编码RNA, 机器学习策略, 诊断标志物, 免疫炎症

## Section: Text

骨关节炎（osteoarthritis, OA）是慢性关节疼痛和残疾的主要原因之一[1]。OA早期诊断困难，目前对OA的治疗限于症状缓解药物和全膝关节置换术，故寻找新的、可行的生物标志物对OA的早期诊断和治疗具有重要意义[2]。

长链非编码RNA（long non-coding, lncRNA）是长度超过200个核苷酸非编码内源RNA，参与OA的发病[3]。lncRNA H19在OA患者外周血[4]中和软骨细胞[5]中高表达，参与炎症反应和软骨细胞代谢；lncRNA HOTAIR在OA患者的外周血单核细胞（peripheral blood mononuclear cell, PBMC）[6]和软骨细胞[7]中均高表达；lncRNA GAS5参与骨疾病的发生发展[8]。这些lncRNA参与OA关节内或外周血免疫炎症细胞浸润过程。免疫浸润的枢纽基因和调控机制是OA研究的热点。文献研究也揭示了外周免疫细胞比值在OA中的预后价值[9]。但鲜有文献研究OA免疫炎症细胞浸润相关的lncRNA分子标志物，及其与OA患者免疫炎症指标的相关性。机器学习则是从大数据中进行算法模型的构建，在疾病亚型识别、生物标志物发现等方面有广泛的应用空间[10]。

本研究从GEO（Gene Expression Omnibus）数据库中获取OA的RNA测序数据，结合机器学习，对差异表达lncRNA进行深度筛选。受试者工作特征（receiver operating characteristic, ROC）曲线评估算法的准确性，以鉴定候选的lncRNA分子诊断标志物。临床试验中加以验证，分析候选lncRNA与OA患者免疫炎症的相关性，以期发现OA中可行的免疫炎症相关生物标志物，为临床OA的早期诊断和治疗提供新的方向。

## Section: 资料和方法

基因数据集信息

特异基因引物序列

## Section: 资料和方法 › 数据收集和数据处理

数据集（GEO）数据库（https://www.ncbi.nlm.nih.gov/geo/）的搜索关键词: “Osteoarthritis” “Homo sapiens” “Expression profiling by array”。筛选标准如下：微阵列数据集参考骨关节炎RNA测序数据；包括OA患者样本和健康正常人样本。最终，筛选出5个数据集：GSE43270[11]、GSE51588[12]、GSE117999[13]、GSE169077和GSE48556[14]，下载芯片中矩阵及平台文件，共有261个组织样本，包括72个软骨组织（GSE43270、GSE117999和GSE169077），50个胫骨平台样本（GSE51588）和139个外周血单核细胞样本（GSE48556），共包括76个正常健康人样本和185个OA患者样本，具体数据见表1。基于R语言的combat消除多个数据的批次效应[15]，RMA（robust multichip average）[16]对数据进行预处理（如表达式计算、归一化、背景校正）。

基因数据集信息

## Section: 资料和方法 › 差异表达的lncRNA筛选

使用R软件（4.2.0版本）中的Limma包筛选整合的基因表达矩阵中OA的差异表达的lncRNA。以矫正后的adj.P<0.05和|log2FC(fold change)|≥1作为筛选条件，筛选上调和下调的差异基因，基于R中的“RobustRankAggreg, RRA”包对差异表达的lncRNA进行进一步识别，得到稳定的lncRNA分子标志物。这种RRA方法可以最小化多个数据集的偏差。

## Section: 资料和方法 › 候选的lncRNA分子标志物的筛选与验证

3种算法被用于筛选候选的lncRNA，包括随机森林（randomforest, RF）[17]、最小绝对收缩和选择算子（LASSO）逻辑回归[18]、支持向量机递归特征消除（SVM-RFE）[19]。RF算法运用R包“randomForest”（包含mtry和trees参数）构建RF分类识别模型，其中mtry参数的取值方法为输入变量数量开平方根，trees为RF中包含的决策树数目（默认为500）。使用R包“glmnet”进行LASSO逻辑回归调查。该法有赖于交叉验证（cross validation）方法筛选参数，方法如下：用训练集（正常健康人数据）算参数及系数，用验证集（OA患者数据）来算对应的残差平方和，然后根据10次交叉验证结果的残差平方和的平均值选取LASSO中参数，binomial回归算法得最优模型，最小lambda被认为是最优的。SVM-RFE算法是采用5倍交叉验证的方法，对插入符号包中具有RFE功能的特征基因进行筛选。利用训练数据集训练SVM，得到相应的参数；选择公式(1)的排序准则计算所有特征在该准则下的排序准则分数；在验证集中剔除对应于最小得分的特征。执行上述过程进行5次交叉验证。这种特征选择的过程实际上是一个序列后向选择（sequence backward selection, SBS）的过程。排序准则公式如(1)，其中和分别表示完整SVM的权重和假设剔除第P个特征后SVM的权重，的表示形式如(2)，i、j表示循环变量；y表示类别标记；N表示样本数目；表示核函数；和由解算SVM对偶优化问题得到。绘制SVM-error和SVM-Accuracy图形。上述过程都是基于R包构建。然后，维恩图（venn diagram, Venn）绘制上述3种分类模型中的重叠基因。为了深入检测重叠基因的功性，在ROC曲线调查的基础上进行评估，并计算曲线下面积（area under the curve, AUC），评估算法的预测效果。双侧P<0.05为差异有统计学意义。

## Section: 资料和方法 › 临床标本收集

本研究选取安徽中医药大学第一附属医院风湿免疫科于2022年11月–2023年2月确诊的30例未接受药物治疗的OA患者。诊断标准参考2018年中华医学会风湿病学分会修订的《骨关节炎诊断及治疗指南》[20]。X线检查根据Kellgren-Lawrence标准[21]符合1、2、3级的患者。其中11名男性，19名女性，平均年龄为（56.63±12.06）岁。此外，还招募了同期体检中心健康个体作为对照组，排除标准：①合并骨关节炎、类风湿关节炎等风湿病的患者；②合并循环系统、呼吸系统、造血系统等疾病的患者；③孕妇或哺乳期女性的患者；④精神病患者。对年龄、性别进行一对一倾向性匹配，纳入15例作为对照组，其中8例男性，12例女性，平均年龄为（53.60±7.72）岁。两组一般资料差异无统计学意义。安徽中医药大学附属第一医院伦理委员会对这项工作进行了评审和批准（伦理号：No. 2022MCZQ01）。

## Section: 资料和方法 › 免疫炎症指标测定

采用全自动生化分析仪（日立HITACHI7600）检测全血生化指标，包括免疫球蛋白A（immunoglobulin A, IgA）、C反应蛋白（C-reactive protein, CRP）、白细胞介素6（interleukin 6, IL-6）、补体4（complement 4, C4）、补体3（complement 3, C3）、免疫球蛋白M（immunoglobulin M, IgM）、红细胞沉降率（erythrocyte sedimentation rate, ESR）、免疫球蛋白E（immunoglobulin E, IgE）、免疫球蛋白G（immunoglobulin G, IgG）。

## Section: 资料和方法 › RT-PCR定量分析

采用密度梯度离心法分离两组样本PBMC。收集细胞沉淀，用Trizol法提取RNA。RNA的数量使用Nano Drop分光光度计（NanoDrop Technologies, Wilmington, NC, USA）测量。RT试剂盒中使用gDNA Eraser（TaKaRa, Shiga, Japan）生成cDNA。表2列出了qRT-PCR中使用的引物。内参基因为GAPDH。相对表达值均计算为2−ΔΔCt。

特异基因引物序列

## Section: 资料和方法 › 统计学方法

计量资料采用表示，所有样本均用Kolmogorov-Smirnov检验正态性，若符合正态性和方差齐的数据，组间比较采用两独立样本t检验，不符合则选取非参数检验。相关性分析采用Spearman或Pearson分析。一对一倾向性匹配法运用SPSS中倾向匹配得分工具实现。 P<0.05为差异有统计学意义。

## Section: 结果

Eliminating the batch effect of the data with combat function

Combat函数消除数据的批次效应

A, Five data sets before normalization. B, After normalization of the five data sets.

Volcano plot of differentially expressed lncRNAs in the five datasets

5个数据集差异表达lncRNA火山图

Black represents all differentially expressed lncRNAs, red represents lncRNAs with log2FC>0, and green represents lncRNAs with log2FC<0.

差异表达最显著的前10个lncRNA

LASSO algorithm was used to screen out 14 lncRNAs

LASSO算法筛选14个lncRNA

A, Each curve in the figure represents the change trajectory of each independent variable coefficient, the vertical coordinate is the value of the coefficient, the lower horizontal coordinate is log (λ), and the upper horizontal coordinate is the number of non-zero coefficients in the model at this time. B, The vertical coordinate is Binomial Deviance (dichotomous anomaly), which can be interpreted as the magnitude of the error of the model. There are two dashed lines of values in the figure, the left is the line with the lowest error and the right is the line with fewer features.

Support vector machine recursive feature elimination (SVM-RFE) algorithm was used to screen out 6 key lncRNAs

SVM-RFE算法筛选出6个关键lncRNA

Graph A is SVM error and graph B is SVM accuracy. 5×CV represents 5-fold cross-validation. The number 6-0.173 in Fig 4A indicates that the error rate for the six trait genes screened out was 0.173. The number 6-0.827 in Fig 4B indicates that the accuracy rate of the six trait genes screened out was 0.827.

Random forest (RF) algorithm was used to screen out 24 feature lncRNAs

RF算法筛选24个特征lncRNA

A, The dynamics of the random forest prediction error versus the number of random trees, with the vertical axis of error representing the error; the horizontal axis of trees representing the tree number. The black, red, and green lines show how the false positive rate varies with the number of decision trees for all samples, samples from osteoarthritis patients, and samples from normal healthy people in the five datasets, respectively. B, The 24 genes sorted by importance.

Screening and validation of key lncRNAs

关键lncRNA的筛选及验证

A, Venn diagram was used to screen for overlapping genes identified by the three algorithms. B, ROC curves for validating diagnostic efficacy after fitting key lncRNA to one variable.

两组免疫炎症指标的变化

RT-PCR to detect the expression of lncRNAs molecular markers

RT-PCR检测lncRNA分子标志物的表达

lncRNA分子标志物与免疫炎症指标的Pearson分析

## Section: 结果 › 差异表达的lncRNA识别

对5组数据集进行了标准化处理，从图1A看出不同的批次之间各自成团，批次之间有比较明显的差别，存在一定的批次效应。图1B不同批次的样品重叠在一起，表明批次效应校正成功。使用OriginLab构建整合基因集中差异表达lncRNA的火山图，见图2。进一步通过R语言RRA法筛选出105个差异lncRNA，包括30个上调和75个下调的lncRNA。将所得差异表达lncRNA对应统计量进行汇总，按校正后的P值即adj.P.Val从小到大进行排序，一般认为adj.P.Val值越小代表差异表达越显著，依据adj.P.Val值选择差异表达最显著的前10个lncRNA，见表3。

Eliminating the batch effect of the data with combat function

Combat函数消除数据的批次效应

A, Five data sets before normalization. B, After normalization of the five data sets.

Volcano plot of differentially expressed lncRNAs in the five datasets

5个数据集差异表达lncRNA火山图

Black represents all differentially expressed lncRNAs, red represents lncRNAs with log2FC>0, and green represents lncRNAs with log2FC<0.

差异表达最显著的前10个lncRNA

## Section: 结果 › 候选的lncRNA分子标志物的筛选与验证

运用3种算法对候选的105个差异lncRNA进行识别，其中LASSO算法得出14个关键的生物标志物（图3）。SVM-RFE算法确定了6个基因作为必要的生物标志物（图4），图4A是5倍交叉验证后曲线变化的错误率，图中6-0.173表示筛选出的6个特征性基因的错误率是0.173，越接近0，表明错误率越低；图4B是5倍交叉验证后曲线变化的准确率，图中6-0.827表示筛选出6个特征性基因的准确率是0.827，越接近1，表明准确率越高。除此之外，RF算法认为24个基因是重要的生物标志物（图5A，5B）。Venn图绘制3种算法的重叠基因（图6A），最终得到4个lncRNA，其中HOTAIR、H19、MIR155HG上调（log2FC≥1），NKILA下调（ log2FC<−1）。ROC曲线显示，它们可能是有价值的生物标志物，AUC分别为0.9415〔95%置信区间（confidence interval, CI）：0.9010～0.9820〕（HOTAIR）、0.8016（95%CI：0.7244～0.8788）（H19）、0.9751（95%CI：0.9475～0.9991）（MIR155HG）、0.7957（95%CI：0.7165～0.8748）（NKILA）（图6B）。

LASSO algorithm was used to screen out 14 lncRNAs

LASSO算法筛选14个lncRNA

A, Each curve in the figure represents the change trajectory of each independent variable coefficient, the vertical coordinate is the value of the coefficient, the lower horizontal coordinate is log (λ), and the upper horizontal coordinate is the number of non-zero coefficients in the model at this time. B, The vertical coordinate is Binomial Deviance (dichotomous anomaly), which can be interpreted as the magnitude of the error of the model. There are two dashed lines of values in the figure, the left is the line with the lowest error and the right is the line with fewer features.

Support vector machine recursive feature elimination (SVM-RFE) algorithm was used to screen out 6 key lncRNAs

SVM-RFE算法筛选出6个关键lncRNA

Graph A is SVM error and graph B is SVM accuracy. 5×CV represents 5-fold cross-validation. The number 6-0.173 in Fig 4A indicates that the error rate for the six trait genes screened out was 0.173. The number 6-0.827 in Fig 4B indicates that the accuracy rate of the six trait genes screened out was 0.827.

Random forest (RF) algorithm was used to screen out 24 feature lncRNAs

RF算法筛选24个特征lncRNA

A, The dynamics of the random forest prediction error versus the number of random trees, with the vertical axis of error representing the error; the horizontal axis of trees representing the tree number. The black, red, and green lines show how the false positive rate varies with the number of decision trees for all samples, samples from osteoarthritis patients, and samples from normal healthy people in the five datasets, respectively. B, The 24 genes sorted by importance.

Screening and validation of key lncRNAs

关键lncRNA的筛选及验证

A, Venn diagram was used to screen for overlapping genes identified by the three algorithms. B, ROC curves for validating diagnostic efficacy after fitting key lncRNA to one variable.

## Section: 结果 › 临床患者免疫炎症指标变化

与正常对照组相比，OA患者中炎症指标（ESR、CRP、IL-6）、免疫球蛋白（IgA、IgE）、补体C4升高，差异有统计学意义（P<0.05）。见表4。

两组免疫炎症指标的变化

## Section: 结果 › RT-PCR法检测lncRNA分子标志物的表达和相关性分析

RT-PCR结果显示，与正常人相比，OA患者PBMC中HOTAIR、H19、MIR155HG相对表达量升高（P<0.01），NKILA相对表达量下降（P<0.01），与生物信息学分析结果一致（图7）。Pearson相关性分析表明，H19与IgA（r=0.439，P=0.018）呈正相关，MIR155HG与CRP（r=0.785，P<0.001）、IgM（r=0.454，P=0.008）、IL-6（r=0.610，P<0.001）呈正相关，NKILA与ESR（r=−0.425，P=0.021）呈负相关，与IL-6（r=0.650，P<0.001）呈正相关，HOTAIR与CRP（r=0.589，P=0.001）、IL-6（r=0.492，P=0.006）和IgE（r=0.445，P=0.014）呈正相关。表明筛选出的4个特征性lncRNA与免疫炎症指标存在相关性（表5）。

RT-PCR to detect the expression of lncRNAs molecular markers

RT-PCR检测lncRNA分子标志物的表达

lncRNA分子标志物与免疫炎症指标的Pearson分析

## Section: 讨论

OA的发生发展涉及复杂的生物学反应[22]。由于缺乏早期检测和评估治疗结果的有效方法，目前，生物标志物的发现成为辅助疾病监测的前瞻性方法。本研究基于GEO测序数据集，结合机器学习策略，寻找OA新的免疫炎症相关的分子标志物，并在OA患者外周血标本中进行验证，为OA的早期诊断和治疗提供新的思路和研究方向。

在本研究中，通过筛选5个OA软骨细胞全基因组基因表达谱，整合差异表达的lncRNA，确定了105个差异lncRNA，包括30个上调和75个下调的lncRNA。根据adj.P.Val值从小到大排序，表3列出前10的lncRNA，包括下调的NKILA、MEG3和C15orf54（log2FC<-1），上调的MIR155HG、HOTAIR、H19、LINC00973、MEG9、PART1和C3orf79（log2FC≥1）。 还有一些lncRNA值得关注，如上调的XIST[23]、TUG1[24]、DANCR[25]、MIAT[26]，下调的MEG3[27]、THRIL[28]、GAS5[8]、ATB[29]。这些lncRNA可能与OA的发病机制有关。

通过集成3种不同的算法，得到3种算法的重叠基因，分别是HOTAIR、H19、MIR155HG和NKILA。ROC曲线结果也表明，4个生物标志物AUC均大于0.7，表明预测结果具有较强的准确性。HOTAIR在OA组织中高表达，通过抑制软骨细胞增殖，促进细胞凋亡和细胞外基质降解导致软骨细胞的功能障碍[30]。lncRNA NKILA通过与核因子κB/核因子κB的抑制蛋白（nuclear factor kappa-B/inhibitor of NF-κB, NF-κB/IκB）复合物结合来覆盖IκB的磷酸化位点，从而抑制NF-κB的过度活化[31]。lncRNA MIR155HG也称为B细胞整合簇。MIR155HG的表达与免疫细胞、分子和免疫检查点分子的浸润水平显著相关[32]。MIR155HG参与破骨细胞的调节。在骨质疏松小鼠中，MIR155HG通过AMP依赖的蛋白激酶（AMP-activated protein kinase, AMPK）途径靶向瘦素受体基因来抑制破骨细胞活化[33]。MIR155HG上调可能是OA炎症过程的重要因素。lncRNA H19在OA中高度表达，可能通过白介素(Interleukin，IL)-38和IL-36之间的相互作用促进OA中的炎症反应[5]。综上所述，基于3种算法的机器学习组合模型和文献调研，均表明HOTAIR、H19、MIR155HG和NKILA与OA中免疫炎症存在相关性，可作为特征性诊断的标志物，但其诊断意义还需要大量的实验来验证。

临床样本验证结果显示，与正常健康组相比，HOTAIR、H19、MIR155HG相对表达量升高，NKILA相对表达量下降，结果与生物信息学预测结果相一致，表明本研究整合预测策略的可行性。相关性分析显示4个特征性lncRNA与免疫炎症指标的相关性。IL-6在软骨病理的发展中起着关键作用，OA患者血清或滑液中IL-6水平的增加与疾病的严重程度相关；然而，IL-6也增加了抗分解代谢因子的表达，具有保护作用；表明IL-6在OA中起双重作用，可能是由IL-6经典与反式信号传导的不同效应引起的[34]。IgE介导的肥大细胞通过高亲和力IgE受体（FcεRI），导致促炎细胞和降解介质（包括类胰蛋白酶）的释放，导致组织损伤、炎症和肥大细胞活化，导致OA的发展和进展[35]。CRP和ESR可作为炎症反应的非特异性指标[36]。研究发现CRP是影响OA诊断和严重程度分级的独立因素[37]。免疫球蛋白亚型在OA患者血清中表达升高，参与了OA发病过程[38]。例如，IgA[39]和 IgM[40]作为机体内高亲和力抗体，参与免疫应答反应。相关性分析也表明，MIR155HG、NKILA、HOTAIR与炎症指标（CRP、ESR和IL-6）、免疫指标（IgE、IgA和IgM）存在相关性，表明特征性的lncRNA参与了OA的免疫炎症反应，在OA临床患者应用中有重要意义。

本研究预测的结果来源于GEO数据库多个实验测序数据的组合，多个算法整合机器学习策略来识别特征性基因，信息利用度方面较单个数据集和小样本的实验验证更全面和完善。然而，本研究存在一定的局限性：样本量相对较小，软骨标本难获取，因此选择外周血标本进行验证。此外，OA患者之间的个体差异，包括社会经济地位、疾病严重程度和疾病持续时间，可能会影响结果的准确性。因此，进一步大样本的体内外实验验证特征性的lncRNA在OA免疫炎症中的确切机制将是我们下一步研究的目标。

* * *

作者贡献声明 刘健负责论文构思，忻凌负责正式分析，周巧和齐亚军负责调查研究，周巧、方妍妍和胡月迪负责可视化，周巧负责初稿写作和审读与编辑写作。所有作者已经同意将文章提交给本刊，且对将要发表的版本进行最终定稿，并同意对工作的所有方面负责。

利益冲突 所有作者均声明不存在利益冲突

## Section: Funding Statement

安徽省高等学校科学研究项目（自然科学类）重点项目（No. 2022AH050449）、安徽省第12批“115”创新团队（皖人才办〔2019〕1号）、安徽省名中医刘健工作室建设项目（中医药发展秘〔2018〕11号）和安徽省中医药领军人才项目（中医药发展秘〔2018〕23号）资助

## Section: Contributor Information

巧 周 (Qiao ZHOU), Email: 780149795@qq.com.

健 刘 (Jian LIU), Email: liujianahzy@126.com.


---

# iEdgeDTA: integrated edge information and 1D graph convolutional neural networks for binding affinity prediction

- **Authors:** Natchanon Suviriyapaisal, Duangdao Wichadakul
- **Issuer:** RSC advances
- **Type:** Scientific article
- **Published:** 2023-08-24
- **Language:** en
- **DOI:** 10.1039/d3ra03796g
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37636509/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractArtificial intelligence has become more prevalent in broad fields, including drug discovery, in which the process is costly and time-consuming when conducted through wet experiments. As a result, drug repurposing, which tries to utilize approved and low-risk drugs for a new purpose, becomes more attractive. However, screening candidates from many drugs for specific protein targets is still expensive and tedious. This study aims to leverage computational resources to aid drug discovery by utilizing drug-protein interaction data and estimating their interaction strength, so-called binding affinity. Our estimation approach addresses multiple challenges encountered in the field. First, we employed a graph-based deep learning technique to overcome the limitations of drug compounds represented in string format by incorporating background knowledge of node and edge information as separate multi-dimensional features. Second, we tackled the complexities associated with extracting the representation and structure of proteins by utilizing a pre-trained model for feature extraction. Also, we employed graph operations over the 1D representation of a protein sequence to overcome the fixed-length problem typically encountered in language model tasks. In addition, we conducted a comparative analysis with a baseline model that creates a protein graph from a contact map prediction model, giving valuable insights into the performance and effectiveness of our proposed method. We evaluated the performance of our model using the same benchmark datasets with a variety of matrices as other previous work, and the results show that our model achieved the best prediction results while requiring no contact map information compared to other graph-based methods.

## Section: Introduction

The typical drug development process is expensive, time-consuming, and requires considerable time to confirm a drug's safety. Over the past few years, COVID-19 has had direct and indirect effects worldwide. We could treat it quickly through drug repurposing, using the existing medicines with safety approval for purposes different than their original intent.1–3

With the evolution of machine learning, several computational techniques and strategies demonstrated their effectiveness for various applications, including predicting drug-target binding affinity (DTA),4,5 which is a task predicting a score that indicates the strength of drug-target pair interaction and can be used to estimate how well a candidate drug can bind with a target protein. As a result, binding affinity has become a criterion for selecting candidate compounds and sped up the entire drug development process. Furthermore, the predicted compounds from DTA can be used in further experiments to obtain a final result rather than developing a new drug whose time cost and financial expenses are incredibly high.6,7

Although early computational models for predicting drug-protein interactions were developed by manually extracting drug and target properties, they required much biological and chemical knowledge. Because drugs and proteins are represented as text sequences by manual extraction, some information, such as structural information, was lost. While known structural proteins having crucial information, such as docking sites, can use computational techniques to carry out the results, unknown-structural proteins, which have less information except for the sequence, become challenging.

In earlier research, DTA prediction is often treated as a binary classification task8–10 by predicting whether a drug and target protein interact. However, to make it more realistic, most recent works predict a value of affinity score to determine the strength of interaction and switching to a regression task.

Recently, several machine learning models have shown remarkable results in DTA prediction. For example, the early work DeepDTA11 took an advancement of convolution neural network (CNN) applied to DTA prediction by using a 1-dimensional (1D) convolution technique to capture the patterns of data from drug and protein sequences, then passed those representations through several hidden layers and regressed to get the DTA scores. On the other hand, MT-DTI12 took advantage of a natural language processing (NLP) technique called “Transformer” to extract molecular representation by treating a molecule sequence as a text and applying the same method as DeepDTA to get a prediction result.

To acquire a better representation of data, GraphDTA13 proposed a graph-based representation learning of drug molecules capable of extracting the structural information and enhancing the predictive performance while representing a protein in a 1D-CNN network. The DGraphDTA14 was an extension of the GraphDTA in which drug molecules and protein sequences were defined as a 2D graph, employing a protein structure prediction approach called contact map to predict protein structure. The authors of GraphDTA also proposed GEFA,15 an early fusion method that combined drug and protein features in the early stage before extracting their representations. The authors contrasted GEFA with GraphDTA, a late fusion method that learned the representations of drug and protein separately. In addition to DGraphDTA, the same authors also released a new work called WGNN,16 which improved the representation using weighted graphs with the weights determined from the contact strength of the contact map prediction.

Another graph-CNN method called MGraphDTA17 used a technique called multi-scale to help a model learn to capture the local and global structures of a compound or a protein simultaneously by learning a variety of scales from shallow to deep and aggregating features from all scales to get a multi-scale feature for each drug and protein. Apart from the graph-based method, SMT-DTA18 achieved a promising result for this task using a transformer-based model trained with a semi-supervised technique by setting one task as a masked language model and another as a DTA task where both shared parameters.

However, these models frequently describe drug and protein structures but ignore the relationship and information between nodes, which is not a natural way to represent compounds or proteins formed by atoms and bonds. In this paper, we propose an approach called iEdgeDTA to predict binding affinity by utilizing one of the variants of graph neural network (GNN) known as graph convolutional network (GCN)19 and improve it by including a multi-dimensional edge feature in an encoding space of the compound. We also considered using a pre-trained model for extracting a node embedding to use as a protein node (an amino acid) representation fed to GNN by constructing a 1D graph from the sequence and incorporating the global feature of the protein. It is noteworthy that the whole process used only SMILES and protein sequences.

The main contribution of this study can be summarized as follows.

• We enhanced drug molecular representation by adding edge information between each node of a drug molecule into graph operation.

• We introduced a 1D sequential graph and pseudo structure to represent the protein sequence and utilized GNN to overcome a fix-length problem.

• We extracted protein features from a sizeable pre-trained model and used it to obtain a global feature. So our method uses both node-level and sequence-level features to learn a variety of scales and get a better representation.

## Section: Materials and methods › Benchmark datasets

To compare the performance of our model with other previous works, we followed DeepDTA to use the same benchmark datasets, Davis11,20 and KIBA.11,21

Davis dataset contains 30 056 drug-target interactions of 68 inhibitors and 442 kinase proteins that cover more than 80% of the human catalytic protein kinome. It uses the dissociation constant (Kd) value to describe the strength of the interaction. Similar to DeepDTA and other works, we transformed the Kd value into a log scale called pKd (see DeepDTA11).

KIBA dataset also comprises interactions of kinase inhibitors but constructed from a different bioactivity source, including Ki, Kd, and IC50. The KIBA score was made by optimizing these values, and we used this score to determine the binding affinity for this task. The original KIBA database contains a bioactivity matrix comprising 52 498 compounds and 467 targets, including 246 088 observations, and He et al.22 removed all drugs and proteins with fewer than ten interactions to get a filtered dataset, which we used in this work. The filtered KIBA dataset comprises 118 254 drug-target interactions of 2111 and 229 unique drugs and proteins.

## Section: Materials and methods › Drug representation

Provided by the benchmark datasets, our input drug compound is in SMILES format, and we utilized TorchDrug23 and RDKit library24 to extract node feature, edge features, and adjacency lists from drug SMILES to generate a graph as illustrated in Fig. 1. We represented node and edge features as shown in Table 1 with one-hot vectors (see ESI Table S1† for detailed features). Edge features make our data more elaborate and informative. In contrast, earlier work only used edges to connect nodes or weighted edges to express an edge's importance. Other work, for example, RGCN,25 proposed using independent weight computation for different edge types.

We employed a multidimensional edge feature in this study to pass additional information to each convolution layer. The edge characteristics comprise bond type, bond stereo, and stereo atom, and the drug compound graph is a symmetric network representing a bidirectional graph for our configuration. To capture comprehensive information, including both the neighborhood and the individual node itself, we incorporated self-loops for all nodes in the graph. This self-loop ensures that the model learns the state embedding, which contains the surrounding nodes' context and the node's features.

## Section: Materials and methods › Protein representation

One of the most difficult protein-related issues is how we can extract helpful protein features based on only its sequence. In contrast to drugs, whose structure information is given in SMILES format, proteins are considerably more complex. Although we can independently extract protein characteristics based on each amino acid property, such as residue-symbol, aliphatic, and polarity, the function is altered when amino acids link together and form a complex structure. Therefore, in this study, we adopted a pre-trained model known as “Evolutionary Scale Modeling” or ESM,26 a transformer protein language model, to extract valuable and dependable protein features from its sequence (details in Pre-trained protein language section).

Many proteins have unknown structures. To extract structural information, we require a very complex model, such as AlphaFold,27 which is resource-intensive to yield a precise result. In addition, prior work learned patterns from protein sequences using CNN or NLP, whereas other structural models used the predicted protein structure of other trained models. This paper proposes a novel way to solve the fixed-length problem of CNN and NLP using a GNN. First, we establish a pseudo-structure in which each amino acid represents a node and create an edge from its adjacency node in the sequence. This pseudo-structure allows us to utilize graph message-passing operations in a sequence string. We illustrate the process of protein graph construction in Fig. 2.

With the constrained sequence length to be fewer than 1024 amino acids of the ESM, while about 20–25% of our protein sequences comprise more than 1024 amino acids (ESI Fig. S1†), we must introduce a way to approximate long-sequence protein feature. Our approach divided a protein sequence into several pieces to make sub-sequences, where one sub-sequence with a fixed length of 500 (windows) and a step of 5 (stride), having 495 amino acids overlapping with the consecutive sub-sequence for a better approximation, and the final sequence feature being the average of all sub-sequences as described in Algorithm 1 and depicted in Fig. 3.

## Section: Materials and methods › Pre-trained protein language

To achieve a more accurate representation of a protein sequence than its amino acid features, we employed a model that has been pre-trained with a vast amount of protein data and can predict a node feature from a protein sequence.

In our study, we conducted experiments using two pre-trained models, namely ProtTrans28 and Evolutionary Scale Modeling (ESM).26 The findings of these experiments are presented in the Module analysis section. Both pre-trained models employ a self-supervised transformer-based model with masking, in which each input token is corrupted by randomly substituting an amino acid with a unique token. Then, they were trained to predict the missing token from the corrupted sequence to learn a pre-training task.

ProtTrans28 is a language model taken from the NLP technique. It has many variants, and the one we experimented on was the T5-XL model, an encoder-decoder model trained on the BFD dataset29,30 and fine-tuned on the UniRef50 dataset,31 which contains 2122 and 45 million protein sequences, respectively. The T5-XL model extracts protein features by employing a transformer model and predicting token-level and protein-level classification tasks. We extracted the embedding features with 1024 dimensions per residue from the last hidden layer before predicting both tasks of the transformer model.

ESM26 is also a transformer-based language model developed by Facebook research, trained on only the UniRef90 dataset32 comprising 98 million diverse protein sequences with 1280 dimensions of embedded features per residue. However, ESM has a restriction on sequence length, as it was trained with a fixed context size of 1024 tokens for positional embedding. Therefore, for protein sequences that are longer than 1024 amino acids, they used the random crop to reduce the protein sequence length to 1024 tokens for every training epoch to get sample sequences.

## Section: Materials and methods › Model architecture

The model used in our study takes both inputs, a protein sequence and a drug compound in SMILES format, and transforms them into graph structures (Fig. 4). The drug branch (Edge-GCN layer) creates a graph using an actual contact, e.g., the graph's edges representing bonds between two atoms. On the other hand, the protein branch (GCN layer) creates a 1D graph from its sequence by sequentially connecting each amino acid to its adjacent neighbors instead of an actual contact, which is a complex piece of information. Instead of employing a fixed-length technique, such as padding or truncating, which is necessary for CNN and NLP, we used the whole sequence for feature extraction and model calculation with the GNN technique, which accepts an arbitrary-length input. Furthermore, due to the potentially extensive length of protein sequences, which requires a vast number of GCN layers to acquire information from the entire sequence (a single GCN layer can only gather information from neighboring nodes within one hop), we introduced an additional branch (Linear layer) for extracting a global feature, a sequence level feature. This feature is achieved by averaging the node-level features from the sub-sequences of the entire sequence and passing them through a linear layer to learn a comprehensive representation.

In this study, our focus is on predicting affinity scores, which are continuous values. To accomplish this, we employed GCN as a layer for feature extraction to produce the node-level representation of both drug and protein, using sequence-level features to create the whole protein sequence representation and a fully connected layer to gather information and produce the predicted affinity scores.

## Section: Materials and methods › Model architecture › Graph neural network

Convolutional Neural Network (CNN) is widely used in many tasks involving data in Euclidean space, such as 1D (sequence) or 2D (grid) data, but in a task with non-euclidean data like a graph, we need a new method to handle this. Due to their capacity to handle graph structure data, GNN have recently garnered a great deal of attention, and several graph data types, such as social networks and drug-protein graphs, have become popular. This paper focuses on one of the variations of GNN that apply convolution over a graph, the Graph Convolutional Network (GCN),19 initially developed to address semi-supervised tasks like node classification. In this work, we will use GCN for graph-level feature extraction. The propagation rule of GCN consists of message passing, aggregate, and feature update, formulated as eqn (1),19 and illustrated in Fig. 5A.

where Ã is an adjacency matrix of a graph with a self-loop connection. D̃ is the diagonal node degree matrix of Ã in measuring the degree of each node to maintain the scale of the output feature vector, while H(l) is a previous hidden layer output. W(l) represents learnable parameters, and σ is an activation function such as the Rectified Linear Unit (ReLU).

## Section: Materials and methods › Model architecture › Graph convolutional network with edge feature

To better represent a drug graph with a multi-dimensional edge feature from the preprocessing stage, we improved a graph message passing by including an edge feature in every convolution step as part of the GCN propagation rule in eqn (2) called Edge-GCN illustrated in Fig. 5B.

In which H(l) in eqn (1) is replaced with H(l) + EW(l)e, where E is a multi-dimensional edge feature and W(l)e is a learnable parameter that transforms the dimension of an edge feature into the dimension of a node feature. Note that the edge in the drug graph is undirected, which means that the connected nodes utilize the same edge feature for message propagation.

In our architecture, we transformed drug SMILES and protein sequences into a graph before giving them to two GCNs, each consisting of a three-layer convolutional network for extracting a representation from a graph. A global pooling layer is placed after the two GCNs to ensure that a graph-level representation with the same dimension is obtained. Each operation may be regarded as a hyperparameter when calculating a global pooling layer as a sum, mean, or max. In this work, we used the global mean pooling layer, eqn (3), where x is a feature matrix for each node in the GCN output. N is the number of nodes in the sequence, and r is the pooling output representation with a size of (1, F), where F is the number of output channels for the last layer.

## Section: Materials and methods › Model architecture › Protein global feature

Since a protein is a highly complicated substance, it is challenging to discern its general function from node-level data. Since a pre-trained model learned from an extensive model and dataset, we considered extracting the global feature by averaging a node feature from a pre-trained to obtain a per-sequence feature with 1280 dimensions for each sequence, which then passed through three fully connected layers before being concatenated to the structural representation of drug and protein.

We added batch normalization (BatchNorm)33 after every output layer in fully connected layers and graph normalization (GraphNorm)34 for GCN layers, each activated by the Rectified Linear Unit (ReLU) function. We then concatenated the representation of the drug's latent feature, protein's latent feature, and protein's global feature to two fully connected layers to predict an affinity score.

## Section: Materials and methods › Model architecture › Loss function and hyperparameter tuning

Our task is to minimize the affinity score difference between our model prediction and ground truth label during training. Since our task is a regression task, we use mean square error (MSE) as a loss function, which is calculated as the summed square of the difference between the predicted value (P) and ground truth label (Y), as shown in eqn (4).

We optimized our model via AdamW35 optimization algorithm, which improves regularization in Adam by decoupling the weight decay from the gradient update. We set a weight decay parameter as 0.01 for both datasets to prevent overfitting. In addition, we used the learning rate decay, starting from 0.001 and decaying by scaling down to 80% for every 100 epochs to improve the learning of complex patterns in the late iteration process.

We tuned most of the hyperparameters manually and selected some others from the prior work, as shown in Table 2 as we employed cross-validation techniques, and the training process took a significant amount of time to complete.

## Section: Results and discussion

We used Nvidia DGX A100 for training and testing and built our model with PyTorch and PyTorch Geometric (PyG),36 conducted model comparisons and selections based on five-fold cross-validation, and chose a candidate model to evaluate the performance over the independence test set. First, we selected the candidate model with the best result averaged from the validation set result of each fold and then evaluated the candidate model by using each fold's weight for predicting the independent test set (unseen data). Then, we calculated the final result by averaging the test results obtained from each fold. Note that we used the training part of each fold, excluding the validation part, to train the model for final evaluation (see ESI Fig. S2†).

## Section: Results and discussion › Evaluation metrics

We implemented the same metrics used by the baseline and state-of-the-art methods to make our work comparable. Since we are working on a regression problem, we used MSE and Concordance Index (CI) as the primary metrics of the DTA task. MSE is a prevalent metric used in regression tasks. It measures the difference between the predicted and actual values. A smaller MSE means the predicted value from our model is closer to the true value. Unlike MSE, the CI score is interested in the order of predictions, not the prediction value itself, and calculated by eqn (5), where bi is the prediction value for the larger affinity di, bj is the prediction value for the smaller affinity dj, Z is a normalization constant, and h(x) is the step function as shown in eqn (6).

Another metric used by some work is the Pearson correlation coefficient, eqn (7), which measures the strength of the linear relationship between two variables, predicted and ground truth in our case, where cov is the covariance between the predicted value p and the actual value y, and σ(p), σ(y) indicates the standard deviation of the predicted p and actual y respectively.

## Section: Results and discussion › Benchmarking with the state-of-the-art models

We compared our method with the previous works. To make a fair comparison, we tested the performance with the unseen data on the independent test set and reported the same evaluation metrics, including MSE, CI, and Pearson correlation coefficient with standard deviation. Note that due to different evaluation settings, we reproduced the final result of some previous work in this benchmarking section and also provided the original results reported in their papers along with the modified evaluation of our model based on their setting in ESI Table S2.†

Tables 3 and 4 show the benchmarking results of our model compared with other methods, differently representing drug compounds and proteins, including CNN-based, graph-based, and transformer. Our technique combining Edge-GCN and 1D-GCN achieved considerable improvements in MSE and CI on the Davis dataset, reaching 0.216 for MSE, 0.897 for CI, and 0.855 for Pearson correlation on the independence test set. The KIBA dataset showed that our model outperformed other methods by having the lowest MSE and highest Pearson correlation. It also had the highest CI score among other graph-based methods (same rank as MGraphDTA), while SMT-DTA, a transformer-based model, had the highest CI score at 0.894. Our model is highly effective compared to the graph-based methods, e.g., GEFA, which previously got the lowest MSE of 0.228 on Davis. Notably, our model does not use protein structure compared to existing graph-based methods that extract protein graphs from contact map prediction, and our model still gets a better result. Therefore, it may imply that the pre-trained model, i.e., ESM, learned how proteins are formed or learned some structural information.

## Section: Results and discussion › Module analysis › Batch normalization

The implementation of batch normalization was an additional effective strategy we utilized to improve the regularization of our model. Deep learning commonly uses batch normalization to normalize the input data within each mini-batch during training. By normalizing the activations, batch normalization reduces the internal covariate shift, which is the phenomenon of a shift in the distribution of layer inputs as model parameters change. This stabilization effect helps the model converge more quickly. In addition, estimating expectations and variance from many small data subsets also provides a model's regularization effect.

We illustrate the impact of batch normalization in Fig. 6. During the early epochs before the red dashed line, the model incorporating batch normalization exhibits faster convergence than the model without. However, in the later epochs, the model's mean squared error (MSE) without batch normalization decreases, indicating a better fit to the training set. Nevertheless, the results on the validation set depicted in Fig. 7 reveal that the model without batch normalization performs worse than the other models, suggesting the presence of an overfitting issue and showing how the batch normalization helps generalize the model. In summary, we achieved additional regularization without a dropout layer by incorporating batch normalization into our model, expedited the training process, and improved overall performance (see ESI Fig. S3† for the performance of the dropout layer).

## Section: Results and discussion › Module analysis › Pre-trained models

This study aims to apply graph neural network to a protein based on the protein's sequence, assuming that we cannot obtain the actual or predicted protein structure. Therefore, it would be best to utilize a pre-trained model because it has learned a massive dataset and might implicitly store some information about the protein structure. Consequently, we chose two pre-trained models to create a protein input feature for our model and evaluated their prediction performance on the Davis dataset, as shown in Table 5.

The findings indicated that both pre-trained models performed better than the baseline model (DGraphDTA), which relied on manually crafted features for protein representation. However, ESM-1v provided superior performance to PortT5, where the MSE value was 0.201, and the CI value was 0.898. As a result, we selected ESM-1v as our pre-trained model for final evaluation.

## Section: Results and discussion › Module analysis › Edge and global features

Since we could extract an edge feature of the drug compound, we also passed it to our modified GNN model to include the edge feature for every message-passing process. However, extracting an edge feature for protein is still challenging. Hence, we instead pulled out an independent global feature by averaging its pre-trained node-level feature and learning to draw out a latent property via three dense layers. The performance of introducing the compound's edge and protein's global features into the model is shown in Table 5.

The results indicated that edge features on only the drug branch could improve the performance to achieve 0.198 for the MSE value and 0.899 for the CI value. Then, we assessed the performance of the protein's global feature, and the findings indicated that this feature also helped improve the prediction result, with MSE lowering to 0.195 and CI score increasing to 0.901 for the optimal iteration.

Besides, we compared our edge feature integration method to existing methods such as RGCN, which improves prediction by employing independent weights for each relation type rather than sharing weights across all nodes and edges. In this task, the bond type is passed as a relation type consisting of a single bond, double bond, triple bond, aromatic, and self-loop, resulting in five distinct weights. As shown in Table 6, utilizing RGCN does not increase model performance on a five-fold cross-validation set. This result may be related to our approach leveraging multidimensional edge features, whereas RGCN can only accept a single feature as the relation type.

Furthermore, we incorporated our Edge-GCN approach into our baseline model, DGraphDTA, to assess the efficacy of integrating an edge feature into drug representations. In this experiment, we replaced the original GCN layers with our Edge-GCN layers in the drug branch, using the same edge feature introduced in this paper. The results are shown in Table 7, revealing that introducing an edge feature to the graph neural network improves both MSE and CI scores.

To assess the impact of individual contributions of node-level and sequence-level features for protein feature extraction, we selected a CNN architecture as our baseline due to its prevalence in prior studies and its suitability for assessing the effectiveness of our 1D-GCN in addressing the fixed-length problem. We set the hyperparameters of the CNN following GraphDTA13 work. Specifically, we fixed the protein sequence length at 1000 amino acids, padded shorter sequences, and truncated longer sequences. In Table 8, we present the results obtained from the experiment, showing the performance of the individual node-level and sequence-level features as standalone versions. These results demonstrate the improvement achieved by each feature independently and highlight their respective contributions. Moreover, integrating both node-level and sequence-level features within the 1D-GCN model yielded significant enhancements, surpassing the performance of the baseline model. This outcome shows the benefits of combining these features, further improving prediction accuracy.

## Section: Results and discussion › Module analysis › Contact map performance

Lastly, we conducted an additional analysis to investigate the influence of protein structure on our model. Specifically, we replaced a 1D sequence graph with a contact map obtained from various contact map model predictions. For this experiment, we selected three works: pconsc4,14,37 utilized by our baseline model DGraphDTA, RaptorX38 employed by GEFA, and the ESM26 contact map prediction model. These models provide a probability indicating the likelihood of an amino acid pair being in contact, where contact determination is based on a threshold set as 0.5. To conduct this analysis, we maintained consistent model architecture and froze all hyperparameters while modifying the construction of the protein graph. Additionally, we employed our 1D sequence graph in the DGraphDTA model to assess the impact of 1D-GCN in a different model setting. The results of this analysis are presented in Table 9.

Our findings revealed that the performance of the 1D-GCN setting is on par with that of a model utilizing a contact map. Furthermore, the 1D-GCN approach exhibited slightly superior performance in our work and the DGraphDTA experiment compared to the contact maps derived from other prediction models. These results indicated that the structural information obtained from contact map predictions might contain noise that could potentially degrade model performance, suggesting that achieving enhanced performance requires either a genuine contact map or highly accurate predictions. Nonetheless, our comparative evaluation highlights that the 1D-GCN approach delivers similar performance without using contact maps. Moreover, given that actual protein contact maps are a limited resource, generating experimentally determined contact maps for proteins can be difficult and time-consuming, requiring specific equipment, specialized knowledge, and substantial resources, making them less accessible and limited to specific research facilities. Many strategies employ machine learning algorithms or statistical methods to infer residue–residue contacts based on the available protein sequence. However, due to the complexity of the nature of proteins, accurately predicting contact maps remains a challenging problem that requires substantial computational resources. Our model holds promise for real-world applications, such as high-throughput virtual screening, using only protein sequences.

However, iEdgeDTA does have limitations. First, using a 1D representation poses a drawback, as the protein's folding determines the binding pocket, and the 1D model does not guarantee that the binding pocket will correspond to a series of adjacent amino acids in the sequence string. Therefore, visualizing or predicting the binding pocket solely from the 1D representation remains a challenging problem. Second, a limitation lies in the pre-trained model, which may generate noise during extracting long protein sequences, as estimated in Algorithm 1. Using a more accurate pre-trained model that can handle arbitrary sequence lengths will reduce the model's sensitivity to noise, which may improve its performance.

## Section: Conclusions

Accurate drug target affinity prediction is essential for identifying promising candidates in developing and optimizing the design of new drugs. It can also help reduce drug discovery costs and time via drug repositioning to assess if existing drugs can bind to a specific protein target. In this study, we introduced a graph-based deep learning model that enhanced the prediction performance by incorporating background knowledge, adding a multidimensional edge feature, and using a more complicated node feature of proteins from the pre-trained model. By comparing the performance of our model to other recent research employing a range of methodologies, we found that our method improves prediction accuracy. In addition, we evaluated the effectiveness of our model when we included protein structure based on a contact map, and the results indicated that protein structure is optional for our model to achieve good prediction accuracy. As our model only incorporates an edge feature in the drug branch, future work could improve the model's accuracy by enhancing the protein node and edge feature extraction.

## Section: Author contributions

N. N. primarily designed the study and supervised model development and testing. D. W. supervised the overall research project and reviewed and provided valuable feedback on the manuscript, contributing to its improvement. The original draft was written by N.N. and reviewed/edited by D. W.

## Section: Data availability

https://github.com/cucpbioinfo/iEdgeDTA.

## Section: Conflicts of interest

There are no conflicts to declare.

## Section: Acknowledgments

This work was partially supported by the National Research Council of Thailand (NRCT) under contract number N34A640454 and the Program Management Unit for Competitiveness (PMU-C), Office of National Higher Education Science Research and Innovation Policy Council, Thailand, under contract number C10F640366. We want to thank Chulalongkorn University Technology Center (UTC) for facilitating the GPU infrastructure for our model development and testing.

## Section: Associated Data › Data Availability Statement

https://github.com/cucpbioinfo/iEdgeDTA.


---

# Integrated Molecular Modeling and Machine Learning for Drug Design

- **Authors:** Song Xia, Eric Chen, Yingkai Zhang
- **Issuer:** Journal of chemical theory and computation
- **Type:** Scientific article
- **Published:** 2023-10-26
- **Language:** en
- **DOI:** 10.1021/acs.jctc.3c00814
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37883810/
- **Licence:** CC-BY

## Section: Abstract

AbstractModern therapeutic development often involves several stages that are interconnected, and multiple iterations are usually required to bring a new drug to the market. Computational approaches have increasingly become an indispensable part of helping reduce the time and cost of the research and development of new drugs. In this Perspective, we summarize our recent efforts on integrating molecular modeling and machine learning to develop computational tools for modulator design, including a pocket-guided rational design approach based on AlphaSpace to target protein–protein interactions, delta machine learning scoring functions for protein–ligand docking as well as virtual screening, and state-of-the-art deep learning models to predict calculated and experimental molecular properties based on molecular mechanics optimized geometries. Meanwhile, we discuss remaining challenges and promising directions for further development and use a retrospective example of FDA approved kinase inhibitor Erlotinib to demonstrate the use of these newly developed computational tools.

## Section: Introduction

The cost of research and development of new drugs has risen over the past decade.1−3 There is great interest in advancing computational methods, including molecular modeling and machine learning (ML), to greatly accelerate the process of drug discovery and development.4−10 The goal of drug discovery is to find small molecules that inhibit the disease-related target and, therefore, modulate the disease. Meanwhile, the pharmacokinetic properties including absorption, distribution, metabolism, excretion, and toxicity (ADME/T) of small molecules also need to be considered in the drug development process.11 The success of drug development requires both good efficacy and the desired pharmacokinetic properties of the drug molecules. Computer-aided drug design (CADD) offers valuable tools in finding candidate compounds in all stages of drug discovery and development.

It should be noted that a modern therapeutic development process often involves multiple nonlinearly interconnected stages.12Figure 1A shows a simplified “pipeline” of therapeutic development where CADD tools are playing important roles. Hit identification is the first step which involves finding the compounds with desired bioactivity.13 Ligand based methods use prior knowledge to predict new drug compounds with similar bioactivities (Figure 1B).14 Similarity search,15 pharmacophore modeling,16,17 and quantitative structure–activity relationships18,19 are common tools for ligand based drug screening. Structure based methods such as molecular docking20−26 and molecular dynamics simulations27−32 are common computational tools used to predict the binding affinity between the protein and ligand (Figure 1C). Binding site prediction tools33−39 offer information on the protein surface where a ligand molecule binds to produce the desired output (activation, inhibition, or modulation).5 If the structure of the protein is not solved experimentally, homology modeling40−43 and ab initio protein structure modeling44−47 approaches can be used to predict the protein structure.

After discovering the hit compounds, subsequent steps involve producing more potent and selective compounds with desirable physicochemical properties.13 It is estimated that over 40% of drug candidates are withdrawn in preclinical tests due to ADME/T concerns.48 To address the problem, a number of computational models have been developed to predict the ADME/T properties of small molecules.49−60 The accurate prediction of molecular properties requires models to learn more robust molecular representations for 1D SMILES,61 2D graph,62 and 3D geometry.63

As computational tools at all stages of drug discovery and development have been extensively reviewed recently,64,65 in this perspective, we focus on the recent progress related to our group. Specifically, we first summarize protein pocket identification and analysis methods based on fragment-centric topographical mapping. Subsequently, we discuss recent advances and promising directions in developing ML and deep learning (DL)-based molecular docking models. Finally, we describe our recent efforts to improve small molecule representation learning and explore chemical space66 more efficiently.

Roles of computational models at the stages of drug discovery and development.

## Section: Protein Pocket Identification and Representation

Workflow of AlphaSpace to optimize a ligand to bind to a protein begins with a selected PDB structure and follows the purple arrows until the optimization is validated experimentally. The additions introduced by AlphaSpace2.0 follow the orange arrows.

## Section: Protein Pocket Identification and Representation › Protein Pocket Identification: Fragment-Centric Topographical Mapping

In contemporary approaches to structure-based drug design, focus is placed on the analysis of concave regions found on biomolecular surfaces. These regions can vary from well-defined small-molecule binding sites to extensive protein–protein interaction (PPI) interfaces.67 Gaining a deeper understanding of concave biomolecular surfaces holds immense potential for various applications in modulator design, such as lead optimization, enhanced ligand screening, and even the identification of previously undiscovered druggable sites.67−69 Furthermore, comparisons of these surfaces investigate ligand selectivity, off-target effects, and polypharmacological activity.70,71

One of the main tasks in analyzing the protein surfaces is identifying binding sites. There are a number of algorithms that do this, and these can be broadly classified as geometry-35,37,72−76 or energy-based methods.68,77−81 Geometry-based methods map out the concavities on the surface using grids or alpha-spheres, while energy-based methods calculate the interaction energy or surface accessibility between the protein and diverse small-molecule probes. The next step usually requires ML methods to characterize the binding site. For example, some methods use clustering to agglomerate data points into binding pockets and others use regression to score the concavities on the protein surface for their ligandability.82 Most methods can correctly predict and rank the voluminous and well-defined ligand binding pockets in holo structures.72,83,84

The alpha-sphere geometry-based representation of the concavities is an established strategy that relies on Voronoi diagrams.34,35,73,74,85−87 Voronoi diagrams form polyhedra defined by the planes that bisect adjacent atoms, resulting in a tessellation of the concave region. Alpha-spheres are placed at the vertices of the Voronoi diagram. These alpha-spheres are then clustered to represent binding pockets. Rooklin et al. developed a python program named AlphaSpace, an alpha-sphere-based method developing on the popular method fpocket,35 that leverages concepts of fragment-based drug discovery and caters to the analysis of PPI (Figure 2).34 To this aim, AlphaSpace uses a tuned clustering method to demarcate pockets that reflect on average one fragment per pocket and defines alpha-atoms, a theoretical ligand atom whose properties reflect a docked fragment. It represents entire PPI surfaces by retaining shallower fragment-centric pockets during the evaluation stage and suggests targetable pockets near the binding partner for ligand optimization. Furthermore, Katigbak et al. developed AlphaSpace 2.0, a python package that clusters the alpha-atoms to a β-cluster, a pseudomolecular representation of the concave site comprised of β-atoms (Figure 2).33 Each β-atom is replaced with a probe atom that iterates through different Vina atom types. The AutoDock Vina score is calculated for each atom type of each probe atom. Then the best Vina score for each probe atom is summed to generate the overall β-score. This β-score reflects the maximum theoretical docking score of the β-cluster.

Both AlphaSpace and AlphaSpace2 offer alignment-free and alignment-based pocket matching protocols, respectively, allowing for comparisons of binding sites between structures within the alpha-sphere framework.33,34 Both methods assess the change in the inhibitor binding site of PPI interfaces using the curated 2P2I database, which provides structures of a protein in the apo, PPI complex, or inhibitor bound PPI complex states. In both cases they can observe the binding pockets on the apo structure that corresponds to the inhibitor binding site, and AlphaSpace2 reports similar ligand-ability estimates of that binding site across structures. However, on the CryptoSite database consisting of structures where a pocket forms in the holo state but not the apo state, AlphaSpace2 reports differences in ligand-ability estimates.

DL methods are also gaining prominence due to their ability to learn complex relationships from raw protein data and predict binding surfaces.82,88 DL architectures can learn the representation and functional roles of the binding pockets without first preprocessing the data to explicitly detect the pockets. Mylonas et al. developed DeepSurf, a 3D-convolutional neural network (CNN) trained on voxels placed on the protein surface.89 It had superior performance compared to other methods tested in the SHREC 2022 contest at identifying druggable sites on diverse data sets of apo and holo structures.83,89 Gainza et al. proposed MaSIF, a surface representation framework that uses overlapping radial patches characterized by a chemical and geometric fingerprint.90,91 These patches can be input into geometric neural network architectures and trained to perform particular tasks, including predicting PPI and ligand sites. Most recently, Smith et al. developed Graph Attention Site Prediction (GrASP) which uses a graph attention network (GAT) architecture to encode the binding site from a protein structure graph. This model is trained on a modified version of sc-PDB to predict the likelihood of an atom to be part of the binding site. These atoms are then clustered and aggregated into binding sites with ligand-ability scores.92 This results in superior precision and recall compared to another graph neural network (GNN)-based method, P2Rank, on the COACH420 and HOLO4K benchmarks.92

Workflow of AlphaSpace to optimize a ligand to bind to a protein begins with a selected PDB structure and follows the purple arrows until the optimization is validated experimentally. The additions introduced by AlphaSpace2.0 follow the orange arrows.

## Section: Protein Pocket Identification and Representation › Experimentally Validating Predictions of Underutilized but Targetable Regions › AlphaSpace has guided the optimization of minimal protein mimetics that target PPIs by expanding mimetics to target secondary binding sites and incorporating noncanonical amino acids to reach untargeted binding pockets

(93−95) Guided by the binding pocket analysis, researchers introduced a terminal tryptophan of a p53 mimetic to interact with a previously untargeted secondary site which resulted in an ∼10-fold improvement of binding affinity to MdmX and Mdm2.95 This interaction was verified to bind to the secondary site through NMR. In another case, optimization steps were able to reverse the loss of binding affinity resulting from truncating the full length protein to a minimal mimetic. The truncated helical MML-mimetic bound poorly to the KIX domain of the p300/CBP coactivator (Kd: >100 μm), but a MML mimetic mutated with noncanonical amino acids was optimized to a similar binding affinity (Kd: 3.3 ± 0.5 μm) as the full-length wildtype MML (Kd: 1.0 ± 0.3 μm).93 Moreover, suggested mutations to the cross-linked helix dimers of the NEMO coiled coil reversed the binding affinity loss due to the aforementioned. These mimetics were also able to inhibit the native PPI in vivo.94 In these cases, the role of AlphaSpace was to suggest initial fragments for improvement, but expertise and further experimental optimization were necessary to generate stable mimetics and maximize protein–ligand binding affinity.93−96

AlphaSpace has also guided the analysis of protein structures for targetable binding sites to design small molecule inhibitors and understand their binding mechanisms. Some computational experiments qualitatively studied the interaction mechanisms and binding modes by docking inhibitors to the most targetable pockets of the transmembrane protein ABCG2 and by running molecular dynamics (MD) simulations of the complexes.97,98 Other binding pocket analyses led to successful prospective docking studies. Hou et al. detected a cryptic pocket in a metastable state of the apo striatal-enriched protein tyrosine phosphatase (STEP) from MD simulations. Ensemble docking to this state at the cryptic pocket resulted in 11 novel inhibitors (IC50 = 9.7–47.7 μm).99 These experimental validations highlight the utility and role that AlphaSpace can play in identifying pockets to develop ligands with improved binding.

## Section: Protein–Ligand Docking in the Machine-Learning Era

Employing computational methods to discover bioactive compounds is becoming an indispensable technique to accelerate the process of drug discovery,100−107 leading to the successful discovery of several approved drugs.104,108−110 The drug discovery process encompasses two major categories: ligand-based drug discovery (LBDD) and structure-based drug discovery (SBDD). LBDD is an indirect approach that employs quantitative structure–activity relationship methods, molecular similarity, and pharmacophore modeling to predict various properties of compounds.14 On the other hand, SBDD involves using the three-dimensional structures of the protein and small molecule to identify or optimize drug compounds.101,111 SBDD focuses on recognizing binding sites and essential interactions crucial to the biological functions of the target. By doing so, it suggests therapeutic compounds that can compete with these crucial interactions, thereby disrupting biological pathways effectively.

Virtual screening (VS) is a method within SBDD where extensive libraries of commercially available, druglike chemical compounds are computationally screened against target proteins with known or predicted 3D structures in a high-throughput manner. The primary goal of VS is to identify potential compounds that exhibit a high predicted binding affinity for the target protein. These selected compounds are then subjected to experimental testing to validate their actual binding capabilities.112,113

Molecular docking is a widely used computational procedure in VS protocols.114−117 It operates based on the lock-and-key118 model of drug action and predicts the noncovalent interactions between the target and small molecules. In structure-based VS, molecular docking methods are commonly used to assess large libraries of molecules.26

Biased protein pockets when evaluating the docking power and screening power on the CASF-2016 data set. (A) Protein and ligand structures. (B) The biased protein pocket resulting from using the binder ligand structure to cut the protein. (C) The unbiased protein pocket without using the binding structure.

## Section: Protein–Ligand Docking in the Machine-Learning Era › Protein–Ligand Scoring Functions

Molecular docking programs rely on a scoring function to evaluate the binding affinity and optimize the binding orientation between protein and ligand.21−23,25,119−121 The scoring function plays a pivotal role in accurately predicting how well the ligand binds to the target protein. Consequently, developing a robust, efficient, and accurate scoring function is a critical component of molecular docking.107

A rigorous theoretical prediction of protein–ligand binding affinity requires the calculation of the free energy difference between the bound and unbound state. However, existing methods for free energy calculation, such as free energy perturbation122,123 and thermodynamic integration,124,125 are computationally expensive, making them impractical for virtual screening over a large set of compounds. To overcome this limitation, scoring functions serve as fast and approximate computational methods to evaluate the strength of noncovalent interactions between proteins and ligands, based on their 3D binding poses.126−128 They are widely used in SBDD to determine the binding mode of ligands (docking power), predict the binding affinity between proteins and ligands (scoring power), identify hits from a large compound library for given protein targets (screening power), and perform structure–activity relationship analyses for hit-to-lead and lead optimization.105,129,130 It is important to note that scoring functions provide estimations of ligand binding affinity, and these predicted scores may not align closely with binding affinities determined through rigorous methods, such as free energy perturbation. For an in-depth understanding of terms such as “scoring power”, “docking power”, and “screening power”, we direct readers to the comprehensive definitions provided in the paper “Comparative Assessment of Scoring Functions: The CASF-2016 Update”.131

Classical scoring functions use a linear combination of force-field or interaction descriptors to evaluate the binding affinity between proteins and ligands. They can be categorized into different types based on their underlying principles. Physics-based scoring functions use the fundamental molecular physics terms derived from experimental data and/or QM calculations;21,119,121 knowledge-based scoring functions use the statistical potentials derived from experimentally determined protein–ligand structures;132−135 and empirical scoring functions make predictions by fitting experimentally measured binding affinity data using linear regression on a set of physical descriptors.21−23,120,136−139

In recent years, ML-based scoring functions have garnered increasing attention due to the rapid growth of experimental data and advancements in computational infrastructure.140,141 Unlike classical scoring functions that adopt linear forms, ML-based scoring functions have the capability to learn more complex functional forms using ML algorithms such as support vector machine (SVM),142 random forest (RF),143 and extreme gradient boosting (XGB).144 In 2010, Ballester et al. introduced RF-score which is the first ML-based scoring function that outperforms classical scoring functions in terms of scoring power.145 In 2013, Zillian et al. developed SFCscoreRF which achieved significantly higher scoring power on common benchmarks.146 However, both models performed much worse when performing docking and screening tasks compared to classical scoring functions.147,148 The reader is directed to this review by Chao et al.107 for more in-depth discussion on scoring functions.

Biased protein pockets when evaluating the docking power and screening power on the CASF-2016 data set. (A) Protein and ligand structures. (B) The biased protein pocket resulting from using the binder ligand structure to cut the protein. (C) The unbiased protein pocket without using the binding structure.

## Section: Protein–Ligand Docking in the Machine-Learning Era › Protein–Ligand Scoring Functions › The Δ-ML strategy improves the scoring-ranking-docking-screening power of ML-based scoring functions

To address this problem, Wang et al. applied a Δ-ML strategy, which involves using ML to predict the correction between experimental binding affinity and computationally predicted binding affinity. The final predicted score is obtained by adding this ML correction to classical scoring functions. The first model to employ this strategy is ΔVinaRF20,149 a random forest model that predicts the corrections to the Vina score. It uses pharmacophore-based solvent-accessible surface area descriptors and AutoDock Vina features as input. ΔVinaRF20 demonstrated superior performance in all power tests on both CASF-2013 and CASF-2007 benchmarks compared to classical scoring functions.150,151 Subsequently, Lu et al. have proposed the ΔVinaXGB model which uses XGB trees.152,153 This model incorporates features from explicit water molecules, metal ions, and ligand conformational stability in addition to the ΔVinaRF20 features.152 The ΔVinaXGB model outperformed other scoring functions on the CASF-2016 benchmark data set.131 Recently, Yang et al. have developed the ΔLin_F9XGB model154 based on a classical scoring function named Lin_F9.139 Lin_F9 is a linear empirical scoring function that builds on AutoDock Vina, overcoming some of Vina’s limitations by introducing new empirical terms for better scoring accuracy. By applying the Δ-ML strategy to the Lin_F9 scoring function, and improving feature selection and the training set, ΔLin_F9XGB achieves superior scoring, ranking, and screening performance on the CASF-2016 benchmark.154

In addition to the CASF-2016 benchmark data set, previous models have undergone extensive testing on the LIT-PCBA data set, specifically designed for virtual screening and ML purposes.155 Preliminary results have shown that the LIT-PCBA data set is challenging due to the high imbalance of active/inactive compounds, common molecular properties shared between active and inactive compounds, and weak potencies of the active compounds.154,156 The average top 1% enrichment factor achieved by ΔLin_F9XGB is 5.55, which outperforms other scoring methods such as AutoDock Vina, ΔVinaRF20, and Lin_F9.

## Section: Protein–Ligand Docking in the Machine-Learning Era › Protein–Ligand Scoring Functions › Learning distance likelihood potential boosts the docking and screening performance of DL-based scoring functions

Aside from traditional ML-based scoring functions, the emergence of DL methods has introduced new strategies for developing scoring functions in drug discovery. Neural network-based models use hand-crafted features as input, including protein–ligand interactions and ligand-dependent descriptors.147,157,158 Convolutional neural network (CNN)-based scoring functions adopt a different approach by using vectorized 3D grids that cover the protein–ligand binding region as input. These grids are processed through CNN layers, followed by readout layers to make predictions about the binding affinity.159−164 Graph neural networks (GNNs) represent molecules as graphs and can learn on the protein–ligand binding system through graph convolutions.165−169 However, despite the increasing popularity of DL-based scoring functions, it is worth noting that these models have not significantly outperformed traditional ML-based scoring functions on well-established benchmark data sets like CASF.107

Recently, Méndez-Lucio et al. proposed a geometric DL-based model named DeepDock170 which learns the probability density distribution of the distance between ligand atom and the protein surface. This approach showed competitive performance in docking and screening tasks when compared to those with well-established scoring functions. Building on the concept of distance likelihood, Shen et al. developed RTMScore.171 Unlike DeepDock, RTMScore overcomes the need for protein surface triangulation by using the probability density distribution of distances between ligand atoms and protein amino acids at the residue level. To achieve this, RTMScore represents proteins as undirect graphs at the residue level and leverages graph transformers to learn the representation of both proteins and ligands. As a result, RTMScore achieves top docking and screening power on the CASF-2016 data set, outperforming state-of-the-art ML- and DL-based scoring functions.

However, RTMScore utilizes biased protein pockets generated from known binder structures as the input protein structure. For example, when evaluating the binding score of the ligand 1A30 on the protein 1E66 (Figure 3A), only the protein structure within 10 Å of the binder ligand 1E66 is used along with the docked ligand 1A30 structure as model input (Figure 3B). This selection method may lead to two potential problems. First, this method requires the binder structure to cut the protein, while in real world virtual screening scenarios, the protein may not have a known binder, or the binder structure may be unknown. Second, the selected pocket is biased toward the binder ligand, potentially neglecting essential interactions between the decoy ligands and the protein when the decoy structures are far from the binder ligand (Figure 3B and C).

The influence of the biased pocket selection was investigated by using docked decoy structures to cut the proteins (Figure 3C) and retesting RTMScore on the CASF-2016 data set. The results, as presented in Table 1, revealed a performance drop when the unbiased pocket was used as the model input for RTMScore models. Despite this drop in performance, the unbiased model still outperformed most of the state-of-the-art models in terms of docking and screening power. This finding highlights the importance of addressing the issue of biased pocket selection in DL-based scoring functions. Although the performance of RTMScore was affected by the unbiased pocket, the fact that it still outperformed many state-of-the-art models indicates that learning distance likelihood potential is a promising direction to improve the docking and screening performance of DL scoring functions.

The very recent work by Shen et al. extends the RTMScore model to the GenScore framework.177 By introducing an adjustable binding affinity term during the training of the probability density distribution, GenScore successfully addresses the issue of low scoring and ranking power experienced by RTMScore, achieving balanced scoring, ranking, docking, and screening power on the CASF-2016 data set. Furthermore, the evaluation of GenScore on the LIT-PCBA data set for real-world screening power is particularly noteworthy. Their best-performing GenScore model exhibits an impressive average top 1% enhancement factor of 6.80 among all targets, demonstrating an excellent screening power.

However, it is important to acknowledge that the biased pocket problem, as mentioned earlier, is not explicitly addressed by GenScore. The reliance on pocket selection using binder ligand structures limits its applicability in real-world virtual screening protocols, especially for novel targets for which binder ligands might not be known or available. Addressing the biased pocket problem would undoubtedly enhance the utility and versatility of RTMScore, GenScore, and other DL-based scoring functions in real-world virtual screening scenarios, making them more effective in identifying potential drug candidates for novel targets with unknown binder structures. Future research in this direction may help overcome this limitation and further establish DL-based scoring functions as valuable tools in drug discovery efforts.

Biased protein pockets when evaluating the docking power and screening power on the CASF-2016 data set. (A) Protein and ligand structures. (B) The biased protein pocket resulting from using the binder ligand structure to cut the protein. (C) The unbiased protein pocket without using the binding structure.

## Section: Protein–Ligand Docking in the Machine-Learning Era › Molecular Docking in the Deep Learning Era

Traditional molecular docking methods such as AutoDock Vina22 and Lin_F9139 rely on the scoring functions and optimization algorithms that search for the global maximum of the scoring functions. The optimization algorithm rotates the rotatable bonds in the molecule, translates the molecule, and rotates the whole molecule until it finds the best conformation with the highest score predicted by the scoring function. In principle, the optimization algorithms can also be applied to DL-based scoring functions. However, in practice, the optimization algorithms often fail to converge when using DL-based scoring functions, especially for those compounds with a high number of rotatable bonds.170 Recently, researchers have developed DL-based docking models to predict binding poses in one shot by treating molecular docking as a regression task.178,179 Although these models are faster than traditional docking methods, they do not significantly outperform traditional docking methods in terms of accuracy.

In late 2022, Corso et al. introduced DiffDock,180 a diffusion generative model which learns the ligand pose distribution from ligand and protein structures. The model employs a diffusion process over the ligand center position, orientation, and torsional angles of each rotatable bond. By iteratively refining ligand poses through updates of translations, rotations, and torsion angles, DiffDock can sample binding poses from random initial ligand conformations.

On the PDBBind blind docking task, DiffDock achieves a 38% top-1 accuracy, significantly outperforming state-of-the-art molecular docking models.180 This success demonstrates the potential of DL methods in improving the ligand binding pose prediction. By combination of DiffDock with modern DL-based scoring functions, a more robust virtual screening protocol can be developed for real-world drug discovery applications.

## Section: Molecular Representation Learning with Deep Learning Methods

Overall workflow using sPhysNet-MT-ens5 for energetics prediction. (A) MMFF geometry generation protocol. (B) The prediction of electronic energies and transfer free energies with sPhysNet-MT-ens5.

Model performance comparison between sPhysNet-MT and other state-of-the-art models on the experimental hydration free energy and logP prediction. Results are adapted from the sPhysNet-MT manuscript.51

## Section: Molecular Representation Learning with Deep Learning Methods › Exploring Chemical Space Efficiently with Force-Field Optimized 3D Geometry and 2D Molecular Graphs

In theoretical chemistry, the Schrödinger equation (SE) serves as the “standard model” because it represents the physics of the charged particles that make up almost all of the molecules and materials. Unfortunately, the analytical solution to SE is only available for systems with a few degrees of freedom. Numerical solutions such as high-accurate quantum mechanics (QM) calculations impose prohibitive computational cost.181−184 To overcome this challenge, ML approaches to predict molecular energies have been crafted to circumvent the task of solving SE of the system by learning the mapping from the geometry to the energy through supervised learning.185−191 With advances in computer infrastructure and the availability of organized chemistry data sets, DL192 methods are gaining popularity. DL methods utilize the atomic coordinates {RI} and atom types {ZI} to predict molecular energetics directly, avoiding the need for hand-crafted molecular descriptors used in ML methods.193−203 In the past few years, many DL models204−213 with distinct model architectures have been developed for the prediction of molecular energetics with better performance on the QM9 benchmark data set.214−216 This data set contains minimized structures and molecular properties calculated using the density functional theory217 (DFT) method for 133,885 molecules composed of H, C, N, O, and F atoms with up to nine heavy atoms. However, despite the progress, many DL models developed on the QM9 data set still require DFT-optimized geometries as input for prediction, which leads to the original problem of computational expense not being fully addressed.

Overall workflow using sPhysNet-MT-ens5 for energetics prediction. (A) MMFF geometry generation protocol. (B) The prediction of electronic energies and transfer free energies with sPhysNet-MT-ens5.

## Section: Molecular Representation Learning with Deep Learning Methods › Exploring Chemical Space Efficiently with Force-Field Optimized 3D Geometry and 2D Molecular Graphs › Force-field optimized geometries can be used to predict DFT-level molecular energetics

In 2019, Lu et al. have demonstrated the feasibility of using Merck Molecular Force Field (MMFF)183 optimized geometry for gas phase DFT-level electronic energy prediction.209 They first train a model called DTNN_7ib on the QM9 data set using DFT-optimized geometries as input and then retrain the readout layer of the model on their prepared MMFF-optimized geometries. The trained DTNN_7ib achieves a mean-absolute-error (MAE) of 0.79 kcal/mol on DFT-level electronic energy by using MMFF-optimized geometry.

In 2021, Lu et al. extended the effectiveness of MMFF-optimized geometry beyond the QM9 benchmark data set by constructing the Frag20 data set.63 These data consisted of DFT-calculated properties for over half a million molecules, with both MMFF and DFT-optimized geometries, and consisted of elements H, B, C, O, N, F, P, S, Cl, and Br, with no more than 20 heavy atoms. They train a model named sPhysNet on the Frag20 data set and achieve better than or close to chemical accuracy (1 kcal/mol) on multiple test sets, including two external test sets based on experimental crystal structures. The work indicated the potential of using MMFF-optimized geometries as a more computationally efficient alternative to explore chemical space66 compared to solely relying on DFT-optimized geometries.

## Section: Molecular Representation Learning with Deep Learning Methods › Exploring Chemical Space Efficiently with Force-Field Optimized 3D Geometry and 2D Molecular Graphs › MMFF geometry also proves useful for predicting experimental properties

In 2022, Xia et al.51 developed a DL model named sPhysNet-MT-ens5 for predicting experimental hydration free energy and octanol/water partition coefficient (logP) using MMFF optimized geometry. Figure 4 shows the overall workflow using the model for prediction. For each compound, up to 300 conformations are generated using EDKTG218 implemented in RDKit219 and then optimized with MMFF. The conformation with the lowest MMFF energy is then selected as the input geometry for the prediction of experimental hydration free energy and logP, as well as other properties of the compound. An ensemble of five independently trained sPhysNet-MT models is used for prediction, and the average of the five predictions is used as the ensemble prediction. The model achieves a root-mean-square error (RMSE) of 0.620 kcal/mol on the FreeSolv220 data set for experimental hydration free energy prediction, as well as an RMSE of 0.393 on the PHYSPROP18,221−223 data set for experimental logP prediction.

Overall workflow using sPhysNet-MT-ens5 for energetics prediction. (A) MMFF geometry generation protocol. (B) The prediction of electronic energies and transfer free energies with sPhysNet-MT-ens5.

## Section: Molecular Representation Learning with Deep Learning Methods › Exploring Chemical Space Efficiently with Force-Field Optimized 3D Geometry and 2D Molecular Graphs › Spatial information computed from MMFF geometry enhances 2D molecular representations

Unlike models that use 3D molecular geometry as input, many DL models use 2D molecular graphs to predict various chemical properties.224−231 While they have shown success in these tasks, their limitations in representing molecules with 2D graphs have been widely discussed.232−236 This is because models based solely on 2D connection graphs may not distinguish between molecules with 3D spatial structures. For example, message passing GNNs cannot distinguish decaprismane237 C20H20 from dodecahedrane238 C20H20 purely based on their 2D graphs.235

To address this limitation, models that incorporate geometry information can achieve better performance.52,239 In 2022, Zhang et al. developed A3D-PNAConv52 which uses both 2D and 3D information on molecules. They demonstrate that incorporating 3D atomic features obtained from MMFF-optimized geometries enhances the learning power of GNN models in predicting calculated solvation free energies. The 3D atomic features are calculated by atom-centered symmetry functions (ACSFs),200 which are sets of many-body interaction functions encoding atomic environments in 3D structures. The GNNs use the 3D atomic features as the initial atomic embedding and then perform several iterations of message passing on the 2D molecular graphs. In comparison, they have also trained GNNs without 3D atomic features. The GNNs with 3D atomic features as initialization outperform their 2D counterpart for predicting calculated water solvation free energy on their Frag20-Aqsol-100k data set. This indicates that using 3D atomic features obtained from MMFF geometries can enhance the learning capability of GNN-based models.

## Section: Molecular Representation Learning with Deep Learning Methods › Enhancing Downstream Tasks through Transfer Learning with Pretrained Molecular Modeling Data

In the early stages of the drug discovery process, data scarcity is the most common issue for DL models in the prediction of experimental physicochemical properties. DL models heavily rely on the size and quality of the training data, and they tend to overfit on small data sets, leading to poor generalizability and performance.240 In contrast, molecular modeling data can be obtained in larger quantities within a reasonable time frame, thanks to advancements in high-performance computing. As shown in Table 2, publicly available data sets generated using molecular modeling methods are significantly larger than experimental data sets in terms of size. To address the scarcity of experimental values, calculated data sets should be fully utilized when training DL models on experimental data.

Model performance comparison between sPhysNet-MT and other state-of-the-art models on the experimental hydration free energy and logP prediction. Results are adapted from the sPhysNet-MT manuscript.51

## Section: Molecular Representation Learning with Deep Learning Methods › Enhancing Downstream Tasks through Transfer Learning with Pretrained Molecular Modeling Data › Pretraining on DFT-calculated energetics aids in improving the prediction of downstream tasks on related experimental properties

The fine-tuning strategy is commonly employed in training DL models. First, a model is pretrained on a source task, and then, its trained weights are transferred as the initialization for a related target task. This fine-tuning approach often yields better performance compared to random initialization.243 For instance, Zhang et al. developed a data set named Frag20-Aqsol-100k which contains 100k diverse molecules sampled from Frag20 and CSD20 data sets, along with their calculated hydration free energy using their SMD_B3LYP protocol.52 They pretrained DL models on the Frag20-Aqsol-100k data set and fine-tuned the models on the FreeSolv data set, which contains 640 compounds with experimentally measured hydration free energy. Their fine-tuned model achieved state-of-the-art performance and can even achieve chemical accuracy with a very small training data size of just 100 molecules.52

Xia et al.51 extended the work and develop Frag20-solv-678k which contains 678,916 conformations and their calculated energetics in gas, water, and octanol phases. They pretrained a DL model on all three electronic energetics and the transfer free energies between the three phases, and fine-tuned the model on a combined data set composed of molecules from FreeSolv with experimental hydration free energy and PHYSPROP with experimental logP. The fine-tuned model predicts experimental hydration free energy with an RMSE of 0.620 kcal/mol on the FreeSolv data set, as well as experimental logP with an RMSE of 0.393 on the PHYSPROP data set, achieving state-of-the-art performance on both tasks simultaneously (Figure 5).

Model performance comparison between sPhysNet-MT and other state-of-the-art models on the experimental hydration free energy and logP prediction. Results are adapted from the sPhysNet-MT manuscript.51

## Section: Molecular Representation Learning with Deep Learning Methods › Improving Molecular Representations through Mutual Learning with Multitask Training

There are a wide range of ML and DL models that have been developed for a variety of chemical tasks. Although some chemical tasks are related, they are treated by different models with distinct model architectures. For example, the models developed for the prediction of high-level QM calculated molecular energetics204−212 and the models for predicting of experimental transfer free energies52,225,228,229,239,244,245 are often developed separately. While separate models may be more effective for accurate predictions for weakly related tasks,210,211 multitask models can be advantageous when tasks are well-related.246,247

## Section: Molecular Representation Learning with Deep Learning Methods › Improving Molecular Representations through Mutual Learning with Multitask Training › Multitask training on related tasks leads to more robust molecular representation learning

Motivated by the fact that many molecular modeling methods use the direct relationship between absolute energies and transfer energies to predict experimental properties with satisfactory results,248−251 Xia et al. developed a multitask DL model named sPhysNet-MT.51 This model simultaneously predicts electronic energies of molecules in gas, water, and octanol as well as the transfer free energies between these phases. On their calculated data set, which includes molecules with energetics computed at the DFT-level, the sPhysNet-MT model achieves chemical accuracy on all tasks. Additionally, on the experimental data set containing molecules with experimental hydration free energy and logP, the model achieves state-of-the-art performance on both tasks simultaneously (Figure 5).

Similarly, Lu et al. developed the T5Chem model for multitask reaction prediction, which encompasses forward reaction prediction, reactant prediction, reagent prediction, reaction yield prediction, and reaction type classification.252 On the test set of their reaction prediction data set called USPTO_500_MT, T5Chem achieves top-1 accuracy of 97.5%, 72.9%, and 24.9% for forward prediction, retrosynthesis, and reagents prediction, respectively. The model also achieves an accuracy of 99.4% in reaction type classification, R2 of 0.22, and MAE of 17.8 in reaction yield prediction, showing competitive performance compared to models trained solely on individual tasks.

## Section: Case Study: 1M17

To illustrate the computational tools described in this paper, we show a case study using the crystal structure of the FDA approved inhibitor Erlotinib bound to the kinase domain of the epidermal growth factor receptor (EGFR) from PDB 1M17 (Figure 6).

We first use AlphaSpace to analyze the binding of Erlotinib to EGFR kinase. The crystal receptor and crystal ligand are the inputs for AlphaSpace and AlphaSpace2.0 analysis. To calculate the AlphaSpace 2.0 β-score, hydrogens and partial charges are added to the ligand and protein input files. The AlphaSpace output characterizes the pockets that are in contact with the ligand, provides a binding score, and suggests undertargeted pockets (Figure 6A). The alpha-atoms and β-atoms are colored by the pockets which they belong to.

We then apply ΔLin_F9XGB for the prediction of the binding affinity. Similarly to the preparation of the AlphaSpace 2.0 input files, we add hydrogens and generate the partial charges to the crystal ligand and crystal protein input files. We apply Lin_F9 local optimization on the ligand binding orientation and get the Lin_F9 binding score. The Vina, solvent accessible surface area, water, metal, and ligand descriptors are calculated for the optimized geometry. These are input to an ensemble of 10 XGB models, the average output of which is used as correction of the Lin_F9 binding affinity. The sum of the Lin_F9 and XGB correction is the final ΔLin_F9XGB score or the predicted binding affinity. The predicted binding affinity of Erlotnib to EGFR kinase from the structure 1M17 (pKdpred = 8.46, Kdpred = 3.5 nM, Figure 6B) closely matches the experimental binding affinity found in BindingDB (with an average of pKdexp and pKiexp = 8.9 ± 0.9).253 It is worth noting that BindingDB contains 45 entries for Ki (ranging from 0.1 to 136 nM) and Kd (ranging from 0.35 to 190 nM), indicating a wide range of experimentally measured binding affinities. Our predicted Kd value of 3.5 nM falls comfortably within this spectrum of binding affinities.

Finally, we use sPhysNet-MT to predict the physicochemical properties of the ligand molecule Erlotinib. Starting from the SMILES of Erlotinib, we first generate up to 300 conformations using EDKTG and optimize them with MMFF. 291 conformations are successfully generated, and the one with the lowest MMFF energy is selected as the input geometry for sPhysNet-MT. The average output of an ensemble of 5 independently trained sPhysNet-MT models is used as the final prediction. The model predicts the logP of the molecule to be 2.76 which is close to the experimental measured value queried from the DrugBank database, 2.7 (Figure 6C).254 The detailed scripts to carry out these calculations and analysis can be found at: https://github.com/SongXia-NYU/drug_discovery_perspective.

Case study of PDB 1M17 with models mentioned in the paper. (A) AlphaSpace and AlphaSpace 2.0 binding pocket analysis. (B) Binding affinity prediction was done using Lin_F9 and ΔLinF9XGB. (C) Prediction of physicochemical properties of the ligand molecule using sPhysNet-MT.

## Section: Concluding Remarks and Perspective

The success of developing computational tools for drug design requires the integration of both molecular modeling and ML techniques. Models for small molecules, protein surfaces, and protein–ligand interactions are all required during different stages of the drug design process, and there is still room for development and research in these methods.

The AlphaSpace methods can be more robust and applicable. Further improvements can account for the role of protein conformational stability in pocket ligand-ability. This can make pocket comparisons more robust, especially when large conformational changes or comparisons between apo and holo structures are involved. When apo structures result in lower ligand-ability estimates, it limits confidence in using apo structures for downstream structure-based design. Quantified comparisons between different proteins and between orthosteric and allosteric pockets can also provide insights into ligand selectivity and off-target effects. Future versions can address these limitations by leveraging deep learning approaches to learn the representation of these relationships and improve ligand-ability estimates. Smith et al. suggest that there are opportunities to apply advanced deep learning image vision techniques to this research question.92 AlphaSpace2 and future versions can be tested on recently developed benchmarks for protein–ligand binding site prediction such as SHREC,83 HOLO4K, COACH420,78 and for binding site comparisons such as ProSPECCTs.70,255 Additionally, a Web server can be developed to give medicinal chemists a more user-friendly experience.

Despite the improved performance of ML- and DL-based molecular docking and scoring methods on the CASF-2016 data set, these methods tend to have a high false positive rate and lack generalizability on real-world VS data sets. More consideration should be given to the curation of the training data sets and to introducing regularization techniques to current VS protocol. Computationally generated decoy poses and training data sets should be generated carefully to prevent the model from having noncausal bias, an issue where the model learns specific data patterns instead of meaningful ligand–protein interactions.256,257 Training data sets tend to have many positive labels that lack diversity and have few or biased negative labels.83,88,258,259 Non- and poor-binders are under-reported, and computationally selected nonbinders should be verified experimentally.260,261 There is a lack of quality and standardized data for some targets. Methods such as data set debiasing262 and introducing specific models to classify and rank actives from inactives171,263−265 are promising regularization techniques to tackle this problem. Furthermore, it is necessary to test models in fair benchmarking data sets akin to real-world conditions.155,266

The size and quality of the training data are also important considerations for the prediction of molecular properties with DL models. More diverse data sets are required to further explore the chemical space. The Frag20 data preparation protocol63 can be used to carefully select diverse molecules, and modern high performance computing platforms can with the help generate labels for DFT calculations for calculated data sets. Collaboration with experimental groups is needed to enlarge and standardize experimental training sets. More careful pretraining protocols and model architecture designs should be developed to fully take advantage of the existing experimental data. Another disadvantage of sPhysNet-MT as well as many other DL-based models is that they can run into problems when considering charged molecules, because they do not explicitly express molecular charge in the model. For example, when predicting pKa, the molecule may be ionized and the model may have problems learning the molecular representation without knowing the total charge of the system.

Additionally, structure-based drug design methods are limited by the exclusion of protein dynamics in most current protein–ligand representations. Protein flexibility can range from slight perturbation of the ligand binding pockets to reconstitution of the binding site to large-scale conformational changes. In the case of binding site prediction, the introduction of the protein dynamics to the model can lead to the detection of cryptic pockets that are not seen in the static crystal structures and to better predictors of binding site ligandability.82 Cryptic pockets can be teased out using standard MD simulations or specialized MD simulations where the solvent molecules are altered to act as probes to tease out these pockets.80 Researchers are also using ML models that have learned the aspects of protein flexibility that lead to cryptic pockets from MD simulations to predict cryptic sites.267,268

Researchers have addressed this limitation of protein flexibility within the context of docking and binding affinity prediction as well.269 Some methods introduce side chain flexibility to the receptor binding pocket,270 others include MD simulations to probe the stability of the predicted binding pose,271 while some DL methods learn the features that drive protein–ligand interactions in MD simulations to predict binding affinity.272 The most common method is ensemble docking, which performs docking on a diverse selection of static receptor structures.273,274 Although rigorous in concept, ensemble docking can actually lead to a decrease in performance when using too many structures and thus researchers propose additional ML methods to select the best subset of structures.275−277 The use of technology, like cryo-EM that can determine diverse receptor structures, enhanced sampling MD simulations that speed conformational sampling, and DL protein structure prediction methods that can predict previously undetermined protein structures and conformations will drive the research in understanding the role of protein conformation in ligand binding. The decision to introduce protein flexibility to structure-based drug design comes with additional computational cost, a factor that must be aligned with the scope and goals of every screening campaign and currently does not guarantee improved performance.

## Section: Acknowledgments

This work was supported by the U.S. National Institutes of Health (R35-GM127040). S.X. and E.C. were also partially supported by a graduate fellowship from the Simons Center for Computational Physical Chemistry (SCCPC) at NYU. We thank NYU-ITS for providing computational resources.

## Section: Author Contributions

∥ S.X. and E.C. contributed equally.

## Section: Text

The authors declare no competing financial interest.


---

# Integration of Machine Learning and Structural Analysis for Predicting Peptide Antibiofilm Effects: Advancements in Drug Discovery for Biofilm-Related Infections

- **Authors:** Fatemeh Ebrahimi Tarki, Mahboobeh Zarrabi, Ahya Abdiali, Mahkame Sharbatdar
- **Issuer:** Iranian journal of pharmaceutical research : IJPR
- **Type:** Scientific article
- **Published:** 2023-09-30
- **Language:** en
- **DOI:** 10.5812/ijpr-138704
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38450220/
- **Licence:** CC-BY

## Section: Abstract

The rise of antibiotic resistance has become a major concern, signaling the end of the golden age of antibiotics. Bacterial biofilms, which exhibit high resistance to antibiotics, significantly contribute to the emergence of antibiotic resistance. Therefore, there is an urgent need to discover new therapeutic agents with specific characteristics to effectively combat biofilm-related infections. Studies have shown the promising potential of peptides as antimicrobial agents. This study aimed to establish a cost-effective and streamlined computational method for predicting the antibiofilm effects of peptides. This method can assist in addressing the intricate challenge of designing peptides with strong antibiofilm properties, a task that can be both challenging and costly. A positive library, consisting of peptide sequences with antibiofilm activity exceeding 50%, was assembled, along with a negative library containing quorum-sensing peptides. For each peptide sequence, feature vectors were calculated, while considering the primary structure, the order of amino acids, their physicochemical properties, and their distributions. Multiple supervised learning algorithms were used to classify peptides with significant antibiofilm effects for subsequent experimental evaluations. The computational approach exhibited high accuracy in predicting the antibiofilm effects of peptides, with accuracy, precision, Matthew's correlation coefficient (MCC), and F1 score of 99%, 99%, 0.97, and 0.99, respectively. The performance level of this computational approach was comparable to that of previous methods. This study introduced a novel approach by combining the feature space with high antibiofilm activity. In this study, a reliable and cost-effective method was developed for predicting the antibiofilm effects of peptides using a computational approach. This approach allows for the identification of peptide sequences with substantial antibiofilm activities for further experimental investigations. Accessible source codes and raw data of this study can be found online (hiABF), providing easy access and enabling future updates.


---

# Machine learning and drug discovery for neglected tropical diseases

- **Authors:** William Breslin, Doan Pham
- **Issuer:** BMC bioinformatics
- **Type:** Scientific article
- **Published:** 2023-04-24
- **Language:** en
- **DOI:** 10.1186/s12859-022-05076-0
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37095460/
- **Licence:** CC-BY

## Section: Abstract

AbstractNeglected tropical diseases affect millions of individuals and cause loss of productivity worldwide. They are common in developing countries without the financial resources for research and drug development. With increased availability of data from high throughput screening, machine learning has been introduced into the drug discovery process. Models can be trained to predict biological activities of compounds before working in the lab. In this study, we use three publicly available, high-throughput screening datasets to train machine learning models to predict biological activities related to inhibition of species that cause leishmaniasis, American trypanosomiasis (Chagas disease), and African trypanosomiasis (sleeping sickness). We compare machine learning models (tree based models, naive Bayes classifiers, and neural networks), featurizing methods (circular fingerprints, MACCS fingerprints, and RDKit descriptors), and techniques to deal with the imbalanced data (oversampling, undersampling, class weight/sample weight).Keywords: Machine learing, Drug discovery, Tropical disease

## Section: Introduction

Leishmaniasis, African trypanosomiasis (sleeping sickness), and American trypanosomiasis (Chagas disease) have been listed in the top list of global burden diseases by the World Health Organization. Leishmaniasis affects 12 million people worldwide, and is considered to be one of the world’s most neglected diseases [1–3]. It is caused by a Trypanosomatid protozoan parasite from the genus Leishmania. American trypanosomiasis, also known as Chagas disease, affects more than 7 million people worldwide and is caused by the protozoan parasite Trypanosoma cruzi [2–4]. African Trypanosomiasis, also known as sleeping sickness, affects 300,000 people worldwide and is caused by the parasite Trypanosoma brucei.

The only approved therapeutics for the treatment of these diseases are expensive, not very effective and have adverse side effects [5–7]. Thus it is important to keep searching for new treatments. Target-based drug discovery involves “screening a library of compounds against a protein and then optimizing the compounds for potency against the enzyme, selectivity, cellular activity, and pharmacokinetic properties” [8]. As the screening process can involve tens of thousands of compounds, it is often costly and time-consuming. We hope to save time and cut costs by using machine learning in the screening process and only testing compounds in the lab which are predicted to be useful by the models. In this study, we train machine learning models (using data from high-throughout screenings) to predict whether a compound will inhibit a disease-causing parasite. Different models, types of features, and techniques to deal with imbalance datasets are compared. For more on using machine learning in drug discovery for neglected tropical diseases, see [5, 6, 9–12].

## Section: Methods › Bioassays and data sources

The three datasets used were downloaded from PubChem, a database collecting information on small molecules and datasets on high throughput biological assays and maintained by the National Center for Biotechnology Information.

Leishmaniasis The assay used to train models for Leishmaniasis has PubChem AID 1721. The target is the enzyme pyruvate kinase from Leishmania mexicana. Of the 292,732 compounds tested, only 1088 are active (≈0.37% active).

African trypanosomiasis The assay used to train models for African trypanosomiasis has PubChem AID 485367. The target is the enzyme phosphofructokinase from T. brucei. Of the 330,677 compounds tested, only 557 are active (≈0.17% active).

American trypanosomiasis The assay used to train models for American trypanosomiasis has PubChem AID 1885. Of the 303,218 compounds tested, only 4394 are active (≈1.45% active).

All three assays were luminescence-based assays. Decreased luminescence indicates inhibition of the target and therefore the corresponding compound may kill the parasite.

## Section: Methods › Preprocessing and featurizing

The structure of each compound was downloaded from PubChem in the Structural Data Format (SDF). We then used the python packages DeepChem [13] and RDKit [14] to generate descriptors for each compound.

Circular fingerprints Circular fingerprints are a type of hashed fingerprint. All substructures up to a given diameter are enumerated and converted to numeric values using a hash function. These values are used to indicate bit positions in the fingerprints. Thus each compound is represented by a vector of 0s and 1s, with the 1s indicating presence of a substructure. Each position in the vector corresponds to more that one possible substructure (leading to possible “bit collisions”), with longer fingerprints having fewer bit collisions [15]. We used fingerprints of sizes 256 and 1024 in this study.

MACCS fingerprints The MACCS (Molecular ACCess System) fingerprints are similar to circular fingerprints because they are vectors of 0s and 1s with each 1 indicating presence of a substructure. MACCS fingerprints are generated using a fixed list of 166 substructures and were developed by Molecular Design Limited, Inc. [16].

RDKit descriptors The python package RDKit has a module RDKit.Chem.Descriptors that calculates 208 chemical properties of each compound. A list can be found at [17].

Concatenations of different descriptors We also trained our models using concatenations of different features. We used the concatenation of MACCS fingerprints with RDKit features, the concatenation of 1024 fingerprints with RDKit features, and the concatenation of MACCS fingerprints, 1024 fingerprints, and RDKit features.

Since the data is so imbalanced, we used a random stratified splitter to split the entire set of compounds into 80% training set and 20% test set. This preserves the ratio of active to inactive. We used three different splits for training and testing and averaged the results.

## Section: Methods › Machine learning models

We trained our machine learning models using the scikit-learn (sklearn) library in python [18] and used the default parameters from sklearn. It should be noted that the performance of the models will most likely improve with hyperparameter tuning. The Keras library was used for neural networks. Early stopping with a patience of 2 was used for the neural network models. A 10% validation set was split from the training set for this.

Naive Bayes classifiers The Naive Bayes classifier (NB) is based on Bayes’ Theorem. The “naive” assumption we make is that the descriptors are independent.

Tree based classifiers Both of the tree-based models we used are examples of “boosting”. In machine learning, boosting is used to convert many weak models into a single strong model. Gradient Boosted Decision Tree (GBDT) models are based on a method introduced by Friedman [19]. The idea is to use gradient descent to adjust the parameters of a tree in order to decrease a differentiable loss function. The default loss function for GBDT in sklearn is Friedman mean squared error. Adaboost can be thought of as a special case of GBDT in which the loss function is the exponential loss function. It was introduced by Freund and Schapire [20].

Neural networks Artificial Neural Networks are models that (very roughly) mimic the complex structure and functioning of the brain [21]. A fully connected neural network can be described by the number of neurons in each hidden layer. We used two different networks, one with a single hidden layer of 100 neurons and one with five hidden layers: 100–100–100–100–20.

## Section: Methods › Imbalanced data

The three datasets used to train our models are all very imbalanced. The ratio of active to inactive compounds is very low (ranging from 0.17 to 1.45%), This presents difficulties in both training and evaluation of the models.

## Section: Methods › Imbalanced data › Measuring success of a model

A common metric for measuring success of a classifier is accuracy score:

If a model were to predict all 330,677 compounds in PubChem AID 485367 are inactive, then the accuracy of that model would be ≈0.9983. However, we would miss all 557 active compounds and we are interested in identifying active compounds. A metric better suited to imbalanced data sets is the balanced accuracy score (BA). It is the average of the true positive rate TPR (also known as sensitivity) and true negative rate TNR (also known as specificity):

where TPR=TPP and TNR=TNN. The balanced accuracy score of a model predicting all compounds in PubChem AID 485367 to be inactive would only be 0.5. We use the balanced accuracy as our primary measure of success of our models, but also report accuracy, true positive rate and false positive rate (FPR=FPN).

## Section: Methods › Imbalanced data › Training models with imbalanced data

We used three techniques to adjust our models to perform better with imbalanced data: oversampling, undersampling, and sample weights.

When we train models using oversampling, active compounds in the training dataset are randomly duplicated until the dataset has the same number of actives and inactives. When using undersampling, a subset with the same size as the set of active compounds is randomly selected from the set of inactive compounds in order to create a balanced training set.

If the sample weights of active compounds are higher than that of inactive compounds, then a misclassified active compound results in a greater contribution to the loss function than a misclassified inactive compound. This also causes the model to predict more active compounds. In our study, all inactive compounds had weight 1. We started with (# of compounds)/(# of active compounds) and experimented to find a range of weights for the active compounds to test.

It should be noted that models trained using oversampling, undersampling, or class weights (with actives weighted more than inactives) also tend to predict more false positives. We stopped increasing the class weights of the actives when the false positive rate exceeded 20%.

## Section: Results and discussion

For each of the three PubChem datasets, we trained five different types of models: Two neural networks (NN1: one hidden layer with 100 neurons, NN2: five hidden layers 100–100–100–100–20), naive Bayes classifier (NB), adaboost tree model (Adaboost), and gradient boosted decision tree (GBDT). Each of these models was trained using five different types of features: Circular fingerprints of size 256 (256FP), circular fingerprints of size 1024 (1024FP), MACCS fingerprints (MACCS), RDKit descriptors (RDKit), and the concatenations (MACCS/RDKit, 1024FP/RDKit, 1024FP/MACCS/RDKit). For each model-feature combination, we trained a model using no imbalance technique, one using oversampling, one using undersampling, and six using different sample weights. Every combination was trained three times using different train-test splits, giving a total of 2520 trained models.

Overall model performance

Top model performance on AID 1721

Top model performance on AID 1885

Top model performance on AID 485367

Performance of models on different assays

Using imbalance techniques versus not. These plots were created using the entire set of trained models

Using oversampling (OS), undersampling (US), or sample weights (SW) versus not

Comparison of imbalance techniques

Performance of each feature type when using different models

Same scores as shown in Fig. 5, grouped by model

Top performing models (highest balanced accuracy score) by model and feature type

Mean training and prediction times by model

Mean training and prediction times by feature type

## Section: Results and discussion › Models

Figure 1 shows overall performance of the models, with balanced accuracy score shown on the vertical axis. This includes all 2520 models, including training without oversampling, undersampling, or sample weights. Overall, the highest median and mean balanced accuracy score is achieved by GBDT models, with a median balanced accuracy score of 0.762 and mean of 0.738. The neural networks have the highest individual scores but also have higher variance. NN2 has the lowest median balanced accuracy score of 0.705 while NN2 has the second lowest at 0.708.

Tables 1, 2 and 3 show the top model of each type for each of the three assays. The top models for both AID 1721 and AID 1885 are the neural networks. The neural networks had the second and third highest balanced accuracy scores on AID 485367 behind GBDT. The best performance among the three assays is achieved by NN1 on AID 1721 with a balanced accuracy score of 0.875, TPR 0.844, and FPR 0.094.

Figure 2 shows model performance on each of the three bioassays.

Overall model performance

Top model performance on AID 1721

Top model performance on AID 1885

Top model performance on AID 485367

Performance of models on different assays

## Section: Results and discussion › Imbalance techniques

Without oversampling, undersampling, or using sample weights, the performance of all the models is poor. Over 80% of these models have TPR<0.1 and over 44% have TPR=0 (i.e., predicting every compound is inactive). Of the Adaboost models without oversampling, undersampling, or sample weights, over 60% have TPR=0. Only two models trained without oversampling, undersampling, or sample weights have balanced accuracy score above 0.70. Both are Naive Bayes classifiers.

Figure 3 shows the effect of using imbalance techniques for each model. The performance increases significantly for all models. Table 4 shows mean scores for models trained with oversampling, undersampling, or sample weights versus those trained without oversampling, undersampling, or sample weights.

In Fig. 4, oversampling, undersampling, and class weights are compared for each model type. The boosts in performance of the Naive Bayes models and decision tree classifiers are similar for the three imbalance techniques, while the same is not true for the neural networks. Oversampling does not work as well as using class weights or undersampling for the neural networks.

Using imbalance techniques versus not. These plots were created using the entire set of trained models

Using oversampling (OS), undersampling (US), or sample weights (SW) versus not

Comparison of imbalance techniques

## Section: Results and discussion › Features

Figure 5 shows performance of the models, grouped by type of features used. The 1024 circular fingerprints outperform the 256 circular fingerprints, but the results are similar in terms of which models perform better or worse when using circular fingerprints. The 1024FP/RDKit and 1024FP/MACCS/RDKit features have a similar pattern to the circular fingerprints. For these feature types, gradient boosted decision trees are the top performer, followed by naive Bayes classifier and then adaboost. The neural networks were the worst performers when using circular fingerprints, 1024FP/RDKit, or 1024FP/MACCS/RDKit.

However, the neural networks outperformed all other models when using RDKit descriptors, MACCS fingerprints, or the MACCS/RDKit features. It is interesting to note that dropping 1024FP from 1024FP/RDKit or 1024FP/MACCS/RDKit significantly improves performance of the neural networks.

Figure 6 is another look at how the different models perform when using different types of features. The highest median and overall highest balanced accuracy score were obtained when using MACCS/RDKit features with NN1.

Table 5 shows the top balanced accuracy scores by model and feature type.

Performance of each feature type when using different models

Same scores as shown in Fig. 5, grouped by model

Top performing models (highest balanced accuracy score) by model and feature type

## Section: Results and discussion › Training and prediction time

Table 6 shows mean training and prediction times by model. The decision tree models take much longer to train than the neural networks or Naive Bayes classifier. Training the gradient boosted decision trees is very time-intensive, taking 10 times longer than the neural networks and over 4000 times longer than the Naive Bayes classifier. On the other hand, the neural networks take longer during the inference stage.

Table 7 shows mean training and prediction times by feature type. It is not surprising that combined features take the longest for training and predicting, while the times were shortest for MACCS fingerprints (the shortest fingerprints used).

Using undersampling is fast compared to using class weights or oversampling. The mean training time for a model using undersampling is 3.8 s. The mean training times when using class weights and oversampling are 314.9 s and 551.6 s respectively.

Mean training and prediction times by model

Mean training and prediction times by feature type

## Section: Conclusion

Neglected tropical diseases affect millions of people worldwide and there is an urgent need to develop new treatments. Identifying compounds that interact with appropriate drug targets is an important part of the drug discovery process. In this project, we trained machine learning models to predict biological activity of drug compounds and compared the results using test data. We used publicly available data to train and test our models. All three datasets are very imbalanced with many more inactive compounds than active. We compared different models, feature types, and ways to deal with the data imbalance.

Without using oversampling, undersampling, or class weights, the models did not perform well, with balanced accuracy scores not much higher than 0.5. After either using class weights or oversampling, many of the models were quite accurate. Oversampling, undersampling, and class weights resulted in a similar boost in performance for the Naive Bayes, Adaboost, and gradient boosted decision tree models, while oversampling did not perform as well as undersampling and class weights for the neural networks. Undersampling has the additional advantage of using less time and memory.

The gradient boosted decision tree models were consistently accurate while using different feature types, but took far longer to train than the other models. The Naive Bayes classifiers have an acceptable performance and are much faster to train. Several of the best single models were neural networks, but the neural networks had a larger range of balanced accuracy scores and more worse performing models.

Overall, training with concatenations of the RDKit features, 1024 fingerprints, and MACCS fingerprints yielded more accurate models than using a single type of feature, but also lead to longer training times. The neural networks performed better when using only MACCS/RDKit features while other models performed better when using all three 1024FP/MACCS/RDKit features. Among the single feature types, the RDKit descriptors produced the best models.

These models can used to prioritize compounds in screening experiments and we hope such techniques lead to a more efficient drug discovery process.

## Section: Acknowledgements

Not applicable.

## Section: Author contributions

WB wrote the code to process the data and train/test the models. DP and WB found and collected the data, and wrote the manuscript. Both authors approved the manuscript and agree with its submission to BMC Bioinformatics.

## Section: Funding

Partial financial support was provided by Pacific University.

## Section: Availability of data and materials

The unprocessed datasets are available from PubChem (https://pubchem.ncbi.nlm.nih.gov/): AID 1721, AID 1885, AID 485367. The code and processed data will be available for research purposes upon request. Interested readers can contact William Breslin at breslin@pacificu.edu.

## Section: Declarations › Ethics approval and consent to participate

Not applicable.

## Section: Declarations › Consent for publication

Not applicable.

## Section: Declarations › Competing interests

The authors declare that they have no competing interests.

## Section: Contributor Information

William Breslin, Email: breslin@pacificu.edu.

Doan Pham, Email: doan.pham.gr@dartmouth.edu.

## Section: Associated Data › Data Availability Statement

The unprocessed datasets are available from PubChem (https://pubchem.ncbi.nlm.nih.gov/): AID 1721, AID 1885, AID 485367. The code and processed data will be available for research purposes upon request. Interested readers can contact William Breslin at breslin@pacificu.edu.


---

# Machine learning model for anti-cancer drug combinations: Analysis, prediction, and validation

- **Authors:** Jing-Bo Zhou, Dongyang Tang, Lin He, Shiqi Lin, Josh Haipeng Lei, Heng Sun, Xiaoling Xu, Chu-Xia Deng
- **Issuer:** Pharmacological research
- **Type:** Scientific article
- **Published:** 2023-06-19
- **Language:** en
- **DOI:** 10.1016/j.phrs.2023.106830
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37343647/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Drug combination therapy is a highly effective approach for enhancing the therapeutic efficacy of anti-cancer drugs and overcoming drug resistance. However, the innumerable possible drug combinations make it impractical to screen all synergistic drug pairs. Moreover, biological insights into synergistic drug pairs are still lacking. To address this challenge, we systematically analyzed drug combination datasets curated from multiple databases to identify drug pairs more likely to show synergy. We classified drug pairs based on their MoA and discovered that 110 MoA pairs were significantly enriched in synergy in at least one type of cancer. To improve the accuracy of predicting synergistic effects of drug pairs, we developed a suite of machine learning models that achieve better predictive performance. Unlike most previous methods that were rarely validated by wet-lab experiments, our models were validated using two-dimensional cell lines and three-dimensional tumor slice culture (3D-TSC) models, implying their practical utility. Our prediction and validation results indicated that the combination of the RTK inhibitors Lapatinib and Pazopanib exhibited a strong therapeutic effect in breast cancer by blocking the downstream PI3K/AKT/mTOR signaling pathway. Furthermore, we incorporated molecular features to identify potential biomarkers for synergistic drug pairs, and almost all potential biomarkers found connections between drug targets and corresponding molecular features using protein-protein interaction network. Overall, this study provides valuable insights to complement and guide rational efforts to develop drug combination treatments.


---

# Machine Learning Scoring Functions for Drug Discovery from Experimental and Computer-Generated Protein-Ligand Structures: Towards Per-Target Scoring Functions

- **Authors:** Francesco Pellicani, Diego Dal Ben, Andrea Perali, Sebastiano Pilati
- **Issuer:** Molecules (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2023-02-09
- **Language:** en
- **DOI:** 10.3390/molecules28041661
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36838647/
- **Licence:** CC-BY

## Page 1 (Section: Introduction)

Citation: Pellicani, F.; Dal Ben, D.;
Perali, A.; Pilati, S. Machine Learning
Scoring Functions for Drug
Discovery from Experimental and
Computer-Generated Protein–Ligand
Structures: Towards Per-Target
Scoring Functions. Molecules 2023, 28,
1661. https://doi.org/10.3390/
molecules28041661
Academic Editors: Chung F. Wong
and Alessandro Pedretti
Received: 7 December 2022
Revised: 5 February 2023
Accepted: 6 February 2023
Published: 9 February 2023
Copyright:
© 2023 by the authors.
Licensee MDPI, Basel, Switzerland.
This article is an open access article
distributed
under
the
terms
and
conditions of the Creative Commons
Attribution (CC BY) license (https://
creativecommons.org/licenses/by/
4.0/).
molecules
Article
Machine Learning Scoring Functions for Drug Discovery from
Experimental and Computer-Generated Protein–Ligand
Structures: Towards Per-Target Scoring Functions
Francesco Pellicani 1
, Diego Dal Ben 2
, Andrea Perali 3
and Sebastiano Pilati 1,4,*
1
Physics Division, School of Science and Technology, University of Camerino, I-62032 Camerino, MC, Italy
2
Medicinal Chemistry Unit, School of Pharmacy, University of Camerino, I-62032 Camerino, MC, Italy
3
Physics Unit, School of Pharmacy, University of Camerino, I-62032 Camerino, MC, Italy
4
INFN-Sezione di Perugia, I-06123 Perugia, PG, Italy
*
Correspondence: sebastiano.pilati@unicam.it
Abstract: In recent years, machine learning has been proposed as a promising strategy to build
accurate scoring functions for computational docking ﬁnalized to numerically empowered drug
discovery. However, the latest studies have suggested that over-optimistic results had been reported
due to the correlations present in the experimental databases used for training and testing. Here, we
investigate the performance of an artiﬁcial neural network in binding afﬁnity predictions, comparing
results obtained using both experimental protein–ligand structures as well as larger sets of computer-
generated structures created using commercial software. Interestingly, similar performances are
obtained on both databases. We ﬁnd a noticeable performance suppression when moving from
random horizontal tests to vertical tests performed on target proteins not included in the training data.
The possibility to train the network on relatively easily created computer-generated databases leads
us to explore per-target scoring functions, trained and tested ad-hoc on complexes including only one
target protein. Encouraging results are obtained, depending on the type of protein being addressed.
Keywords: molecular docking; scoring functions; machine learning
1. Introduction
Scoring functions (SFs) are popular models often adopted by medicinal chemists to
perform computational docking and to score poses of candidate ligands in the pockets of
target proteins [1,2]. They are expected to attribute the best score to the correct pose, to ac-
curately predict the binding afﬁnity (or a score proportional to the afﬁnity), and to prioritize
active ligands over inactive ones. The latter task, in particular, plays a pivotal role in virtual
screening [3]. It allows for identifying the most promising drug molecules, thus reducing
the time and the cost otherwise spent for in vitro screening [4]. Due to their importance in
drug discovery [5], the development of SFs has been the focus of intense research endeavors
for decades. Modern SFs are often grouped [6] into empirical [7], knowledge based [8],
and force ﬁelds [9] SFs. More recently, SFs have been implemented also using data-based
approaches via machine-learning (ML) techniques [10–12]. This strategy is favored by
the increasing amount of crystallographic protein–ligand structures [13], and it aims at
exploiting the effectiveness of ML techniques in extracting useful information from big
databases. An inﬂuential article was published in 2010 [14]. Therein, the authors adopted
a relatively simple ML model, namely, random forest regression [15], and they trained it
to predict binding afﬁnities using about 1200 protein–ligand complexes extracted from
the PDBBind databases [16,17]. They reported a promising Pearson correlation coefﬁcient
Rp = 0.776, which indicates a strong correlation between predicted and experimental
binding afﬁnities [18]. Notably, the ML-based SF outperformed all considered classic ones.
Later, a similar ML-based SF was specialized to virtual screening tasks, thus also addressing
Molecules 2023, 28, 1661. https://doi.org/10.3390/molecules28041661
https://www.mdpi.com/journal/molecules

## Page 2 (Section: Introduction)

Molecules 2023, 28, 1661
2 of 15
the comments of Ref. [19] on the poor performance of ML-based SFs in this task. Various
subsequent studies have adopted more advanced ML models, such as dense neural net-
works (NNs) [20], convolutional NNs [21–24], and graph NNs [25], often further increasing
the performance in binding afﬁnity prediction. For a recent review on neural networks
and deep learning techniques, see, e.g., Ref. [26]. Different complex representations have
been explored, ranging from distance-counts of protein–ligand atomic pairs (combined
with kernel ridge regression) [14,27] to three-dimensional (3D) grids of atomic features
(combined with convolutional NNs) [21–24]. However, very recent studies have put these
optimistic results into question [28]. They reported a drastic performance reduction when
ML SFs are subjected to more stringent benchmarks. Noticeable examples are so-called
vertical tests, whereby predictions are made for proteins not included in the training set,
as opposed to the more common and less stringent horizontal tests, whereby a protein
might be present both in the training and in the test sets, albeit bound to a different ligand.
Along this line, Refs. [22,27] considered scaffolding tests designed to quantify how the
prediction accuracy varies with the degree of structural similarity between the proteins
in the training and in the test sets. Notably, Ref. [28] reported that the performance of an
exemplary ML-based SF did not change when it was fed with only the protein structure, or
only the ligand structure (as opposed to the whole complex). The authors thus suggested
that the ML-based SF had not learned any information about the actual protein–ligand
binding mechanism.
A critical problem for the development of ML techniques for computational docking
is the limited number of experimental structures available for model training [18,29].
From the most relevant database, namely, the PDBBind repository, one may extract a
few thousand complex structures, depending on the required resolution [29]. While this
number is steadily increasing, it is still orders of magnitude smaller than the amount of data
typically used in other ﬁelds where ML has proven astonishingly successful, such as, e.g.,
computer vision. For example, state-of-the-art NNs for object detection are usually trained
on databases including millions of images, e.g., the ImageNet database [30]. This issue is
particularly relevant for deep NNs. These are often preferred to simpler ML regression
models, such as kernel ridge regression or support vector machines, due to their superior
generalization properties. However, in general, they require larger training databases to
avoid overﬁtting problems. Beyond the small size, training databases might be affected
by anthropogenic factors, leading to a biased selection towards particularly favourable
instances, as recently found in studies on chemical reactions [31]. The contrasting ﬁndings
discussed above call for further quantitative performance analyses on ML-based SFs,
considering in particular the role of the training set and of the test type. One of the main
questions we aim to address in this article is whether ML-based SFs can be trained using
computer-generated complex structures created using docking software, providing access
to larger and more tunable databases.
In this Article, we implement an SF using an NN with fully connected layers (FCNN).
Following Refs. [14,27], the descriptors used to represent the complex structures are counts
of atomic pairs, one belonging to the protein and the other to the ligand, within various
distance intervals. Two databases are used for training and testing. The ﬁrst includes 2408
crystallographic structures extracted from the PDBBind database. Notably, we carefully
check and prepare these structures with the inclusion of hydrogen atoms, in contrast to
previous related studies that only considered heavy atoms. The second database includes
28,200 computer-generated structures created using the CCDC Gold docking engine within
the MOE (Molecular Operating Environment) software interface [32–34]. In both databases,
the complex structures are associated with the corresponding experimental binding afﬁni-
ties. The FCNN is trained to predict binding afﬁnities of previously unseen complexes via a
supervised learning algorithm. One of our goals is to quantify the performance of a FCNN
combined with a distance-count description of protein–ligand complexes. Chieﬂy, we
compare the performances reached using experimental and computer-generated databases,
considering in both cases both horizontal as well as more challenging vertical tests. Fi-

## Page 3 (Section: Materials and Methods)

Molecules 2023, 28, 1661
3 of 15
nally, taking advantage of the creation of computer-generated databases, we explore the
development of per-target SFs designed to predict binding afﬁnities for a speciﬁc target
protein. We consider 17 exemplary targets, training a speciﬁc SF for each of them using
computer-generated databases including many complexes with different ligands docked
into the same target protein. The performances obtained on the exemplary targets are
analysed, also varying the size of the training set. In general, the obtained performances
are encouraging, with noticeable variations depending on the target. To shed some light on
these different performances, we make a comparison against basic linear regression models
based on the molecular weight, optimized for each target.
2. Materials and Methods
2.1. Experimental Database
The ﬁrst database includes 2408 complex structures obtained through X-ray crystal-
lography [35] and deposited into the Protein Data Bank [36,37] . With this experimental
technique, the positions of the heavy atoms, i.e., excluding hydrogen atoms, are estimated
with a ﬁnite resolution. We select structures with a resolution degree lower than 3 Å and
whose ligand–target interaction information is available from the PDBbind database [16,17].
The 3D structures are manually checked for possible inconsistencies and curated with the
addition of the hydrogen atoms, using the MOE software. This process is time consuming,
thus limiting the size of the experimental database. However, it allows us to adopt a more
complete representation, as opposed to various previous related studies that considered
only heavy atoms. Furthermore, the inclusion of hydrogen atoms allows for performing
a more direct comparison against the computer-generated complexes described below.
The target–ligand structures are associated with the corresponding dissociation constant
Kd. In fact, we consider the values of pKd ≡−log10(Kd). These values are retrieved
from the PDBbind database. For completeness, we report here the formal deﬁnition of
dissociation constant:
pKd = −log10(Kd) = −log10
[P][L]
[C]

,
(1)
where [P], [L], and [C] represent the concentrations of the protein, of the ligand, and of the
complex, respectively. Some relevant details on our databases are summarized in Table 1.
Table 1. Brief description of the experimental and the computer-generated databases. (*) The sign of
the docking score is changed from negative to positive for consistency with the afﬁnity values. These
databases are freely accessible using the link in Ref. [38].
Database
Number of Complexes
Mean Afﬁnity
Mean Docking Score (*)
Experimental
2408
5.98 (pKd)
Computer generated
28,200
7.48 (pKi)
11.43
2.2. Computer-Generated Database
The second database includes structures generated via computer simulations. We
refer to it as the computer-generated database. To build it, the 3D structures of 17 selected
target proteins are retrieved from the PDB repository. The selection focuses on diverse
targets with many ligands deposited in the BindingDB database [39–41]. Only complexes
with a single ligand at the binding site and no cofactors are considered. For each target,
a numerous set of ligands is retrieved. The choice of ligands is restricted among those
whose experimental binding afﬁnity for each selected target is available as expressed by
the pKi score. This score measures the target–ligand afﬁnity using a reference radio-ligand.
Its value is generally close to pKd. These ligands are docked into the respective target
using the GOLD docking engine through the MOE software. Our simulations produce
ten poses for each target–ligand pair using the GOLD docking engine. These poses are

## Page 4 (Section: Complex Representation)

Molecules 2023, 28, 1661
4 of 15
then rescored within MOE by the GBVI/WSA dG scoring function, following the protocols
of previous studies; see., e.g., Refs. [42,43]. The target–ligand pose assigned of the best
docking score is selected. The ﬁnal computer-generated database includes only the poses
corresponding to the best score for each ligand at the respective target, totalling 28,200
protein–ligand complexes. It is worth pointing out that, due to the possible inaccuracy of
the classical SF, the best pose does not necessarily match the correct experimental one. Still,
avoiding mediocre scores likely increases the chances of excluding odd poses featuring
clear inconsistencies, which might prevent the NN from learning to predict the correct
afﬁnity. The number of pairs per target ranges from 384 for the PIM2 protein, to 6568 for
the D2 protein. The selected target proteins and the corresponding number of complexes
are summarized in Table 2. Evidently, the computer-generated database is signiﬁcantly
larger than the experimental one. This allows us to better analyse the learning speed of
NNs. However, it is worth emphasizing that the docking pose created by the docking
software is affected by the possible inaccuracy of the chosen docking engine. Instead, the 3D
crystallographic structures are expected to correspond to the actual spatial conﬁguration.
It is worth pointing out that, in fact, spurious distortions might be present also in the
crystallographic structures, but this is believed to rarely happen. Clearly, while the binding
afﬁnity information present in the computer-generated database is, in fact, experimental,
the 3D complex structure is affected by the choice of the SF used by the docking engine
and, henceforth, by its possible inaccuracies. It should be noted, however, that this does
not necessarily represent a drawback. Indeed, in virtual screening campaigns, SFs are often
used to select promising ligands from software-generated poses. Therefore, training the SF
on the type of structures it will be asked to rank might actually be instrumental.
Table 2. Breakdown of the protein–ligand complexes included in the computer-generated database.
The following legend deﬁnes the protein acronyms: 5HT2A: human 5-HT2A receptor (pdbcode: 6A94);
A2A: human A2A Adenosine receptor (pdbcode: 5NM4); ACE: Human acetylcholinesterase (pdbcode:
4EY5); BACE1: human BACE-1 enzyme (pdbcode: 6UVP); D2: human D2 dopamine receptor
(pdbcode: 6CM4); DOP: human delta opioid receptor (pdbcode: 4N6H); FAAH: humanized variant of
fatty acid amide hydrolase (pdbcode: 3PPM); GR: human glucocorticoid receptor (pdbcode: 4UDD);
H1: human histamine H1 receptor (pdbcode: 3RZE); JAK1: human Janus kinase 1 (pdbcode: 6N7A);
JAK2: human Janus kinase 2 (pdbcode: 6VN8); KOP: human kappa opioid receptor (pdbcode: 4DJH);
M1: human M1 muscarinic acetylcholine receptor (pdbcode: 5CXV); MCL1: human Mcl-1 (pdbcode:
6UDV); OX2: human orexin 2 receptor (pdbcode: 5QWC); PI3K: human Phosphatidylinositol 4,5-
bisphosphate 3-kinase catalytic subunit alpha isoform (pdbcode: 6PYS); PIM2: human PIM2 kinase
(pdbcode: 4X7Q).
Protein
5HT2A
A2A
BACE1
DOP
FAAH
GR
H1
JAK1
PI3K
N. of complexes
2763
2914
1413
1243
508
843
1070
1213
1064
Protein
PIM2
ACE
KOP
M1
MCL1
JAK2
OX2
D2
N. of complexes
384
488
2431
1056
688
1394
2160
6568
2.3. Complex Representation
The input provided to the FCNN must be designed to represent, with good approx-
imation, the 3D structure of the protein–ligand complexes. The description we adopt
follows the archetypes proposed in previous studies [14,27]. Speciﬁcally, each descriptor
corresponds to the count of atom pairs within a speciﬁed distance interval, whereby the
ﬁrst atom belongs to the target, the second to the ligand. We consider the following 10
atomic species: H, C, N, O, F, P, S, Cl, Br, and I. This choice follows the study of Ref. [14]
(apart for hydrogen). See also the following studies of Refs. [23,24,27]. For the ligands, only
the species H, C, N, O, P, and S are considered here. This restriction is due to our choice of
addressing only ligands not including halogens and metallic atoms. While this is a possible
limitation of our analysis, the selected atomic species are sufﬁcient to describe many drug

## Page 5 (Section: Target Values)

Molecules 2023, 28, 1661
5 of 15
molecules and, therefore, we expect that our ﬁndings concerning training and testing proto-
cols and per-target SFs are sufﬁciently general. The above choices lead to 60 descriptors per
distance interval. Notice that halogens could be avoided also for proteins. However, NNs
quickly learn to ignore constant descriptors. Notably, our representation takes into account
H atoms. Furthermore, originally, Ref. [14] considered only one distance interval, namely,
0–12 Å. Subsequently, Ref. [27] adopted a more detailed representation, dividing the 12 Å
range into six intervals. In this article, we explore different representations, varying both
the number of intervals and their width. The goal is to identify the optimal compromise
between representation accuracy and conciseness. We point out that the original training
matrix includes descriptors which might differ by orders of magnitudes. For this reason,
a normalization operation is helpful. Our analysis on the experimental database shows
that the most effective operation is dividing by the maximum value of all descriptors. To
formally deﬁne this normalization procedure and, more in general, the descriptor vector, it
is useful to introduce the following notation: the (unnormalized) number of pairs of atomic
species A ∈(H, C, N, O, F, P, S, Cl, Br, I) (for the target) and A′ ∈(H, C, N, O, P, S) (for the
ligand) that lie in the distance interval labeled by the index k = 1, 2, . . . , kmax, where kmax is
the chosen number of intervals, is denoted as NAA′
k
. Therefore, we have 60 pairs of atomic
species, meaning that each complex is characterized by 60kmax descriptors. The interval
widths we consider are ℓ= 1.5 Å, ℓ= 2 Å, or ℓ= 3 Å. The intervals are deﬁned by the
following minimum and maximum distances: rmin = (k −1)ℓand rmax = kℓ. Different
numbers of intervals kmax are addressed. The smallest value is kmax = 1 for all three inter-
val widths. Instead, the largest number differs depending on the interval width, namely,
kmax = 6 for ℓ= 1.5 Å, kmax = 7 for ℓ= 2 Å, and kmax = 5 for ℓ= 3 Å. The normalized
descriptors are NAA′
k
/max{NAA′
k
}, where the maximum value is taken over all descriptors
of all instances in the corresponding database. This normalization is adopted for all results
reported below.
2.4. Target Values
SFs are designed to predict a score proportional to the binding afﬁnity. As already
mentioned, we train and test our FCNN SFusing, as regression target, the pKd and the pKi
values, for the experimental and the computer-generated databases, respectively. For the
latter database, in only one analysis aiming at verifying if and to what extent a ML-based
SF can mimic a classic SF, we also consider the docking score. For convenience, we adopt
as a target value the negative of the docking score, so that higher values correspond to
putatively higher afﬁnities. The mean target values of our databases are summarized in
Table 1.
Notice that, during training, we adopt the standardized targets d′ = d−µ
σ , where d is
the original value of binding afﬁnity (pKd or pKi, depending on the considered database)
or negative docking score (only when the FCNN SFis trained to reproduce the prediction
of the classic SF), µ the database mean, and σ the corresponding standard deviation. This
(linear) standardization does not affect the correlation coefﬁcient Rp, and it is introduced
only to allow us to better compare the phenomenology of the training processes on different
databases. Furthermore, to favor comparison with other studies, the mean squared error
(MSE) values reported below are computed considering un-normalized predictions and
targets d, obtained by inverting the standardization formula.
2.5. Regression Model and Training Protocol
The goal of supervised learning is to train a regression model to map the complex
descriptors to the target value, namely, the binding afﬁnity (or the negative docking score).
The regression model adopted in this article is an FCNN, namely, a dense NN with all-to-all
interlayer connectivity. The numbers of (hidden) layers Nl and of hidden neurons per
layer Nh are chosen through the analysis described in Section 3. Note that Nl does not
count the descriptor layer, nor the output layer featuring a single neuron. The activation
function in the hidden layers is the hyperbolic tangent. The network weights and biases

## Page 6 (Section: Results)

Molecules 2023, 28, 1661
6 of 15
are optimized by minimizing the loss function, namely, the MSE between the network’s
predictions and the ground-truth target values. To contrast possible overﬁtting phenomena,
the loss function is augmented with a standard L2 regularization term [44]. However,
this does not lead to signiﬁcant beneﬁts, and the results we report hereafter correspond
to a negligibly small regularization parameter. Our neural networks are implemented
and trained using a very popular framework for deep learning, namely, the Keras Python
library [45]. Furthermore, we provide the code with the trained model corresponding to
one of our most relevant SFs (see Section 3.3) at the repository of Ref. [38]. The optimization
is performed using a variant of stochastic gradient descent, named ADAM [? ]. An
adequate mini-batch size turns out to be around 50 and 200, for the experimental and the
computer-generated databases, respectively.
The training epochs are iterated until the prediction accuracy on the test set stops
improving, i.e., before entering the regime where overﬁtting phenomena dominate. Due to
the small size of the experimental database, introducing a validation set is not practical.
For consistency, the same protocol is adopted also for the computer-generated database.
This is intended to estimate the optimal potential performance. While, in principle, it might
lead to a slight overestimation, this effect is found not to be important. In particular, in
the most critical per-target FCNN SFtests, the prediction accuracy is found to be quite
stable as a function of the training epochs. To monitor the prediction accuracy, two metrics
are considered, namely, the Pearson correlation coefﬁcient Rp and the MSE. These are
computed on a test set which includes around 20% of the whole database, while the
remaining instances are used for training. The training and testing process is repeated
ten times, considering just as many different random splittings between training and test
instances, or simply different (random) selections of training data and mini-batches for
gradient descent. The accuracy scores reported hereafter correspond to the average of the
test scores, while error bars correspond to the estimated standard deviation of the average.
This averaging procedure avoids spurious ﬂuctuations due to accidentally favourable or
adverse selections of the test instances, providing a more reliable estimate of the prediction
accuracy in a realistic scenario.
3. Results
3.1. Selection of Descriptors and Network Structure
To identify the optimal choice for the complex–structure representation, we analyse
the prediction accuracy on test sets of 300 randomly chosen experimental complexes,
as a function of the number of distance intervals of atom-pair counts. The choice of
considering 300 complexes (randomly selected from the whole experimental database)
for testing is a trade off between the need of the largest possible training set and the
minimal number required for a reliable test. As discussed in Section 2.5, 10 random non-
overlapping splittings are considered to reduce the role of statistical ﬂuctuations due to
particularly favourable or adverse testing complexes. Notice that, while the test protein–
ligand complexes are distinct from those used for the optimization of weights and biases,
some target proteins might occur in both training and test sets, albeit bound to a different
ligand. This is what we refer to as a horizontal test. The results are shown in Figure 1,
considering the three interval widths, namely, ℓ= 1.5 Å, ℓ= 2 Å, and ℓ= 3 Å. For a
complete deﬁnition of the descriptor vector, we refer the reader to Section 2.3. One notices
that the maximum Rp score, which corresponds to the optimal representation, is obtained
using kmax = 4 intervals of width ℓ= 2 Å, meaning that atom pairs are counted only
if the two atoms are less than 8 Å apart. Considering that 60 pairs of atom species are
considered, the total number of descriptors is 240. This representation is adopted for all
results reported hereafter.

## Page 7 (Section: Results)

Molecules 2023, 28, 1661
7 of 15
Figure 1. Pearson correlation coefﬁcient Rp for the predictions of binding afﬁnity provided by the
FCNN SF, as a function of the number of descriptors Nf . This FCNN SFis trained and tested on the
experimental database. The protein–ligand complex structure is represented by atomic-pair counts
within a variable number of distance intervals. The three datasets correspond to different interval
widths. Sixty pairs of atomic species are considered, including pairs with hydrogen.
We identify the optimal depth and width of the neural network by analysing the Rp
score on the experimental test set. The results are shown in Figure 2 as a function of the
number of training instances Nt. Different numbers of layers Nl and of neurons per (hidden)
layer Nh are considered. The highest performance is obtained for Nl × Nh = 2 × 20. An
analogous analysis performed on the computer-generated data (not shown) indicates that,
in that case, the optimal network structure is Nl × Nh = 4 × 40. The need of a deeper
network can be attributed to the larger size of the computer-generated database. Indeed, it
is known that deeper NNs are more effective in extracting useful information from larger
databases, while they are more susceptible to overﬁtting phenomena when the database
is sparse. These two NN structures are adopted for all results reported below, unless
otherwise speciﬁed.
Figure 2. Rp score for binding afﬁnity prediction as a function of the size Nt of the (experimental)
training set. Each dataset corresponds to a choice Nl × Nh for the number of hidden layers Nl and of
neurons per layer Nh in the fully connected neural network (FCNN). The complex representation
includes Nd = 60 descriptors, with four distance intervals of width 2A.

## Page 8 (Section: Horizontal Tests on Experimental and Computer-Generated Structures)

Molecules 2023, 28, 1661
8 of 15
3.2. Horizontal Tests on Experimental and Computer-Generated Structures
One of our main goals is to compare the performances of ML-based SFs trained and
tested on experimental and on computer-generated databases. The two learning curves
for our FCNN SFare compared in Figure 3, where the Rp score for the binding afﬁnity
prediction is plotted as a function of the training set size Nt. As a term of comparison, the
Rp value obtained when the (negative) docking score is used as target value, both during
training and testing phases, is also shown. Noticeably, remarkably high performances are
obtained in this latter test, namely, Rp ≃0.82. This indicates that the chosen combination
of representation and regression models is capable of learning, within good approximation,
the function corresponding to the docking score. Clearly, while this result suggests that
a ML-based SF can at least imitate a classic SF, it does not imply a good performance for
binding afﬁnity prediction since, as already discussed, classic SFs do not always perform
well in this task. Indeed, the maximum Rp score corresponding to the binding afﬁnity
prediction is somewhat smaller, namely, Rp ≃0.55 and Rp ≃0.60, for the experimental
and the computer-generated databases, respectively. These scores still correspond to
moderately strong correlations between predictions and ground-truth (i.e., experimental)
binding afﬁnities. The lower score at the maximum Nt on the experimental database can be
attributed to the larger size of the computer-generated one. Actually, it appears that the
learning is faster on the experimental database, since higher accuracies are in fact obtained
when the training set size Nt is comparable. To further inspect this effect, the same Rp
scores are plotted in Figure 4 as a function of the percentage of training instances compared
to the size N of the whole database. One observes an approximately linear increase. The
slopes corresponding to the experimental and to the computer-generated databases are
comparable. This suggests that the performance improves due to the increasing probability
of ﬁnding the same or similar proteins in both the training and the test sets. In concord with
this supposition, the Rp score is consistently higher on the computer-generated database,
whereby the number of proteins is lower. A similar supposition has been put forward in
Ref. [28], and it is supported also by the vertical tests discussed below.
Figure 3. Rp prediction–accuracy score as a function of the training set size Nt. The green squares
and the red rhombi correspond to the binding afﬁnity prediction by the FCNN SFtrained on the
experimental complexes and on the computer-generated databases, respectively. The blue triangles
correspond to the predictions of the docking score by the FCNN SFtrained on the computer-generated
database. The network structure is described in Figures 1 and 2.

## Page 9 (Section: Vertical Tests)

Molecules 2023, 28, 1661
9 of 15
Figure 4. Rp prediction–accuracy score as a function of the percentage of the training set size Nt
compared to the whole database size N, namely, 100Nt/N. The red rhombi and the blue squares
correspond to the FCNN SFtrained on the experimental complexes and on the computer-generated
complexes, respectively.
3.3. Vertical Tests
The horizontal tests described above provide encouraging results. As anticipated,
however, these might be over-optimistic, being biased by the similarities among the com-
plexes present in the training and in the test sets. In a real-case scenario, universal SFs
are expected to describe the binding strength of candidate ligands into novel proteins
under investigation. Quite likely, these proteins are dissimilar from those included in the
databases available at the time of model deﬁnition. A fairer performance assessment is
therefore provided by so-called vertical tests, whereby complexes made from proteins
present in the test set are excluded from the training set. The ﬁrst vertical test we consider
is performed on computer-generated complexes made from the four proteins FAAH, PIM2,
ACE, and MCL1, totaling 2068 complexes. The FCNN SFis trained on Nt complexes made
from the remaining 13 proteins of our computer-generated database (see Table 2). The
Rp score is shown in Figure 5 as a function of Nt. One notices a signiﬁcantly reduced
performance compared to the horizontal test. The accuracy score, Rp ≈0.4, corresponds to
an only moderate correlation between predicted and experimental binding afﬁnities. It is
worth mentioning that a similar vertical test on computer-generated complex structures
was performed also in Ref. [27] using a random-forest regression model. That study reports
an even lower score, namely, Rp ≃0.2. We attribute the better performance of our FCNN
SFto the use of an FCNN, which is more suited for extracting useful information from
large databases. It is also worth comparing the performance of our FCNN SFwith the one
displayed by a popular classic SF. We consider the GBVI/WSA dG scoring function of
the MOE software. Since the corresponding docking score is negative, with lower values
corresponding to more favourable poses, we consider the negative of the docking score.
Its correlation with the binding afﬁnity turns out to be only marginal, corresponding to
Rp ≃0.2. To favor further comparative studies, the code with our FCNN SF, trained on
the whole subset including the 13 groups of complexes discussed above, is provided via
the repository of Ref. [38]. While our FCNN SFseems to perform relatively better than
the two considered benchmarks, its performance is not fully satisfactory. Chieﬂy, one
notices that the performance does not improve with the training set size Nt. To further
elucidate this ﬁnding, we perform a series of per-target vertical tests. Seventeen FCNN
SF’s are trained on just as many computer-generated databases obtained by excluding
all complexes made from each of the 17 proteins. The excluded complexes are used as

## Page 10 (Section: Vertical Tests)

Molecules 2023, 28, 1661
10 of 15
test sets for the corresponding SF. The 17 corresponding Rp scores are shown in Figure 6.
Again, the performance is, on average, appreciably lower compared to the horizontal test
discussed above. This corroborates the claim that horizontal tests provide over-optimistic
performance measures, probably due to the correlations and similarities among training
and test complexes. In addition, the large performance ﬂuctuations among the 17 FCNN
SF’s corresponding to the different targets are noteworthy. For example, remarkably high
scores are obtained for the JAX1 and JAX2 proteins. These might be attributed to the
similarity between these two proteins, meaning that including in the training set complexes
derived from one of them allows the FCNN SFlearning how to predict binding afﬁnities
for the other. However, the close relationship between binding afﬁnity and the ligand
molecular weight might also play a role. This is further discussed below.
Figure 5. Mean squared error (MSE, upper panel) and Rp score (lower panel) for binding afﬁnity
prediction in the vertical test, as a function of the training set size Nt. The FCNN SFis trained on a
computer-generated database including complexes made from 13 proteins, and tested on complexes
made from four proteins not included in the training set.
Figure 6. Accuracy scores Rp for binding afﬁnity afﬁnity predictions for 17 FCNN SF’s in per-target
vertical tests. Each SF is trained on the computer-generated database excluding the complexes
made from the protein indicated on the horizontal axis, and tested on the excluded complexes. The
horizontal red line indicates the average score.

## Page 11 (Section: Per-Target Scoring Functions)

Molecules 2023, 28, 1661
11 of 15
3.4. Per-Target Scoring Functions
The unremarkable performances displayed by the universal ML-based SF in the verti-
cal tests lead us to explore different strategies. As discussed in Section 3.2, the experimental
and the computer-generated databases appear to be comparably effective for training
SFs for binding afﬁnity predictions. Clearly, the computer-generated complexes can be
relatively easily generated. This suggests the idea of developing per-target SFs on-demand,
whenever a novel protein is targeted. Such a SF would be trained on a purposely created
database including only complexes made from the target protein. To explore this direction,
we consider the six proteins with more complexes in our computer-generated database,
namely, D2, A2A, 5HT2A, KOP, OX2, and JAX2. Six per-target FCNN SF’s are trained
and tested only on complexes made from one protein. Motivated by the sizes of the six
databases, we adopt FCNNs with Nl × Nh = 2 × 20, apart for the D2 target, for which the
parameters Nl × Nh = 3 × 20 are expected to be more adequate. The corresponding Rp
scores for binding afﬁnity prediction are shown in Figure 7, as a function of the training
set size Nt. The tests are performed on 300 complexes. The performances are relatively
high. The average Rp obtained using, for each target, Nt = 900 training instances, is
Rp = 0.44. When the largest available Nt for each target is employed, the average score
is Rp = 0.52. These scores are to be compared with the average vertical test on these six
targets, corresponding to Rp = 0.30. Chieﬂy, in all six tests, the Rp score systematically
increases with Nt, suggesting that sufﬁciently performant per-target SFs can be obtained
when adequately large computer-generated training databases are available. There are
also noticeable performance differences among the six targets, ranging from Rp ≈0.4
for D2, to Rp ≈0.67 for JAK2. To shed some light on these differences, we compare the
per-target FCNN SF’s to simple linear regression models. Speciﬁcally, we assume the linear
law pKi = A + mB, where m is the ligand molecular weight (MW), and A and B are the
ﬁtting coefﬁcients. These are ﬁxed via MSE minimization on the whole per-target database.
The comparison between the per-target FCNN SFand the corresponding MW SF is shown
in Figure 8, for two exemplary targets, namely the JAK2 and OX2 proteins. Notice that the
corresponding scores in the per-target vertical tests are also shown. One notices that, for
the JAK2 protein, even the simple MW SF provides a remarkable performance, namely,
Rp ≃0.62. Tentatively, this effect might be attributed to the large pocket size at the binding
site for this particular protein, meaning that the binding strength is simply proportional
to the ligand size. Clearly, additional analyses would be required to further corroborate
this tentative explanation. Assuming this explanation is indeed sound, it not so surprising
that both the per-target FCNN SFand the universal FCNN SFin the per-target vertical test
provide comparable (but still superior) scores. Instead, for the OX2 protein, the predictions
of the MW SF have essentially zero correlation with the binding afﬁnity, corresponding
to Rp ≈0. The per-target FCNN SFreaches an encouraging Rp ≃0.53 at the largest Nt.
Notably, this per-target FCNN SFsigniﬁcantly overcomes the score of the universal FCNN
SFin the corresponding per-target vertical test (Rp ≃0.18). These ﬁndings suggest that
per-target FCNN SF’s are able to learn non-trivial mappings from computationally feasible
computer-generated databases.

## Page 12 (Section: Discussion)

Molecules 2023, 28, 1661
12 of 15
Figure 7. Rp score for binding afﬁnity predictions from six per-target FCNN SF’s, as a function of the
training set size Nt. Each SF is trained and tested on computer-generated complexes made from the
protein indicated in the legend.
Figure 8. Rp accuracy scores as a function of the training set size Nt, for two exemplary target proteins,
namely, JAK2 (cyan) and OX2 (red). The performances of the per-target FCNN SF’s (cyan triangles
for JAK2 and red circles for OX2) are compared to the corresponding scores of the FCNN SFin the
vertical test (cyan full diamond and red full square) and of the molecular weight linear regression
(cyan empty diamond and red empty square). The large green x’s correspond to the universal FCNN
SFin the horizontal test on the experimental database, while the small blue x’s correspond to the
analogous test of the computer-generated database. The horizontal gray line represents the average
score on the 17 per-target vertical tests.
4. Discussion
We have analysed the performance of scoring functions (SFs) based on fully-connected
neural networks (dubbed FCNN SF’s) in predicting the binding afﬁnities of protein–ligand
complexes from a representation of the 3D complex structure. Our choice for the structure
representation is based on atomic-pair counts within suitably chosen distance intervals, and
we investigated the optimal number and width of such intervals. The effectiveness of crys-

## Page 13 (Section: Discussion)

Molecules 2023, 28, 1661
13 of 15
tallographic 3D structures for SF training has been compared to that of computer-generated
structures created with popular commercial docking-simulation software. Notably, the
two types of data turn out to be comparably effective, suggesting that more accessible
computer-generated database can be used for SF development, rather than the less copious
experimental structures. Importantly, our FCNN SF’s have been assessed in horizontal
tests as well as in vertical tests, whereby no protein is included both in the training and in
the test databases. A signiﬁcant performance degradation is found in the latter, as in fact
reported also in the study of Ref. [27] using different regression models compared to the
neural networks adopted here. This corroborates the contention of the authors of Ref. [28],
who argued that SFs based on machine learning might not learn the ligand–target binding
mechanism, but rather the correlations among complexes present in the training and in
the test sets. These ﬁndings indicate that vertical tests represent fairer assessments for the
performances of SFs in real-case scenarios. The relative easy of creating computer-generated
databases led us to explore the development of per-target FCNN SF’s. Six exemplary targets
have been considered, obtaining encouraging results. Chieﬂy, a systematic performance
improvement with the training set size was observed. Furthermore, we found instructive
results by comparing the FCNN SF’s to linear-regression models based on the molecular
weights. Interestingly, in some cases, even such simple theories reach high correlation with
experimental binding afﬁnities.
SFs are an important tool to accelerate drug discovery. Massive research endeavours
have been devoted to implementing different families of SFs. However, the development
of SFs based on machine learning is still in an early stage. The variable and sometimes
contrasting results reported in the literature indicate that more research is due to establish
reliable benchmarking protocols. We argue that the ease of generating training data via
computer simulations, together with the ﬁrst encouraging ﬁndings reported in this article,
will favour further research endeavours aiming at developing per-target SFs based on
machine learning, tailored at speciﬁc proteins or protein families. Additional techniques
borrowed from the ﬁeld of artiﬁcial intelligence might help with facing the problems
associated with sparse, possibly biased training databases [47]. Along this line, generative
neural networks have been employed to implement de-novo molecular design, avoiding
virtual screening of excessively large databases [? ]. Further research should also consider
the use of additional complex descriptors, taking into account, e.g., entropic contributions,
hydrogen-bond information, and/or pharmacophore models. Extending the considered
atomic species, addressing, e.g., halogens, is also important; indeed, halogens species are
included in many drug-like molecules. To facilitate future comparative studies, we provide
our databases (experimental and computer-generated) via the link available in Ref. [38],
including the 3D structures, deposited in PDB ﬁles, as well as the binding afﬁnities and
the docking scores. This repository also stores the code with one of our FCNN SF’s. The
provided SF is trained on a subset of our computer-generated database, as discussed in
Section 3.3.
Author Contributions: Conceptualization, F.P., D.D.B., A.P. and S.P.; methodology, F.P., D.D.B., A.P.
and S.P.; software, F.P., D.D.B. and S.P.; formal analysis, F.P., D.D.B., A.P. and S.P.; validation, F.P.,
D.D.B., A.P. and S.P.; investigation, F.P. and S.P.; data curation, F.P., D.D.B. and S.P.; writing—original
draft preparation, F.P., D.D.B. and S.P.; writing—review and editing, F.P., D.D.B., A.P. and S.P.; funding
acquisition, D.D.B., A.P. and S.P. All authors have read and agreed to the published version of the
manuscript.
Funding: This research was funded by the University of Camerino under the FAR2018 project
titled “Supervised machine learning for quantum matter and computational docking” and by the
Italian MIUR under the project PRIN2017 CEnTraL 20172H2SC4. S.P. acknowledges PRACE for
awarding access to the Fenix Infrastructure resources at Cineca, which are partially funded by the
European Union’s Horizon 2020 research and innovation program through the ICEI project under
Grant Agreement No. 800858.
Institutional Review Board Statement: Not applicable.

## Page 14 (Section: Discussion)

Molecules 2023, 28, 1661
14 of 15
Informed Consent Statement: Not applicable.
Data Availability Statement: The databases employed in this study are available from the Zenodo
repository using the link at Ref. [38].
Acknowledgments: Fruitful discussions with Pierbiagio Pieri and Andrea De Simone are acknowl-
edged. We also thank Andrea Spinaci for support during data preparation. We also acknowledge 6
Tour S.r.l for the fruitful interactions in the initial phase of this work.
Conﬂicts of Interest: The authors declare no conﬂict of interest.
References
1.
Kulharia, M.; Goody, R.S.; Jackson, R.M. Information Theory-Based Scoring Function for the Structure-Based Prediction of
Protein- Ligand Binding Afﬁnity. J. Chem. Inf. Model. 2008, 48, 1990–1998. [CrossRef] [PubMed]
2.
Jain,
A.N.
Scoring functions for protein–ligand docking.
Curr.
Protein Pept.
Sci.
2006,
7, 407–420.
. [CrossRef] [PubMed]
3.
Walters, W.P.; Stahl, M.T.; Murcko, M.A. Virtual screening—An overview. Drug Discov. Today 1998, 3, 160–178. . [CrossRef]
4.
Wienkers, L.C.; Heath, T.G. Predicting in vivo drug interactions from in vitro drug discovery data. Nat. Rev. Drug Discov. 2005,
4, 825–833. [CrossRef] [PubMed]
5.
Drews, J. Drug discovery: A historical perspective. Science 2000, 287, 1960–1964. . [CrossRef] [PubMed]
6.
Liu,
J.;
Wang,
R.
Classiﬁcation of current scoring functions.
J. Chem.
Inf.
Model.
2015,
55, 475–482.
. [CrossRef]
7.
Gohlke, H.; Klebe, G. Statistical potentials and scoring functions applied to protein–ligand binding. Curr. Opin. Struct. Biol. 2001,
11, 231–235. . [CrossRef]
8.
Gohlke, H.; Hendlich, M.; Klebe, G. Knowledge-based scoring function to predict protein–ligand interactions. J. Mol. Biol. 2000,
295, 337–356. [CrossRef]
9.
Yin, S.; Biedermannova, L.; Vondrasek, J.; Dokholyan, N.V. MedusaScore: An accurate force ﬁeld-based scoring function for
virtual drug screening. J. Chem. Inf. Model. 2008, 48, 1656–1662. [CrossRef]
10.
Ain, Q.U.; Aleksandrova, A.; Roessler, F.D.; Ballester, P.J. Machine-learning scoring functions to improve structure-based binding
afﬁnity prediction and virtual screening. Wiley Interdiscip. Rev. Comput. Mol. Sci. 2015, 5, 405–424. [CrossRef]
11.
Li, H.; Sze, K.H.; Lu, G.; Ballester, P.J. Machine-learning scoring functions for structure-based drug lead optimization. Wiley
Interdiscip. Rev. Comput. Mol. Sci. 2020, 10, e1465. [CrossRef]
12.
Li, H.; Sze, K.H.; Lu, G.; Ballester, P.J. Machine-learning scoring functions for structure-based virtual screening. Wiley Interdiscip.
Rev. Comput. Mol. Sci. 2021, 11, e1478. [CrossRef]
13.
Palmer, R.A.; Niwa, H. X-ray crystallographic studies of protein–ligand interactions. Biochem. Soc. Trans. 2003, 31, 973–979.
[CrossRef]
14.
Ballester, P.J.; Mitchell, J.B.O. A machine learning approach to predicting protein–ligand binding afﬁnity with applications to
molecular docking. Bioinformatics 2010, 26, 1169–1175. [CrossRef] [PubMed]
15.
Svetnik, V.; Liaw, A.; Tong, C.; Culberson, J.C.; Sheridan, R.P.; Feuston, B.P. Random forest: A classiﬁcation and regression tool for
compound classiﬁcation and QSAR modeling. J. Chem. Inf. Comput. Sci. 2003, 43, 1947–1958. [CrossRef] [PubMed]
16.
Wang, R.; Fang, X.; Lu, Y.; Wang, S. The PDBbind database: Collection of binding afﬁnities for protein- ligand complexes with
known three-dimensional structures. J. Med. Chem. 2004, 47, 2977–2980. [CrossRef] [PubMed]
17.
Wang, R.; Fang, X.; Lu, Y.; Yang, C.Y.; Wang, S. The PDBbind database: Methodologies and updates. J. Med. Chem. 2005,
48, 4111–4119. [CrossRef]
18.
Liu, Z.; Su, M.; Han, L.; Liu, J.; Yang, Q.; Li, Y.; Wang, R. Forging the basis for developing protein–ligand interaction scoring
functions. Accounts Chem. Res. 2017, 50, 302–309. [CrossRef]
19.
Gabel, J.; Desaphy, J.; Rognan, D. Beware of Machine Learning-Based Scoring Functions: On the Danger of Developing Black
Boxes. J. Chem. Inf. Model. 2014, 54, 2807–2815. [CrossRef]
20.
Zhu, F.; Zhang, X.; Allen, J.E.; Jones, D.; Lightstone, F.C. Binding afﬁnity prediction by pairwise function based on neural network.
J. Chem. Inf. Model. 2020, 60, 2766–2772. [CrossRef]
21.
Jiménez, J.; Skalic, M.; Martinez-Rosell, G.; De Fabritiis, G. Kdeep: Protein–ligand absolute binding afﬁnity prediction via
3d-convolutional neural networks. J. Chem. Inf. Model. 2018, 58, 287–296. [CrossRef]
22.
Gomes, J.; Ramsundar, B.; Feinberg, E.N.; Pande, V.S. Atomic convolutional networks for predicting protein–ligand binding
afﬁnity. arXiv 2017, arXiv:1703.10603.
23.
Seo, S.; Choi, J.; Park, S.; Ahn, J. Binding afﬁnity prediction for protein–ligand complex using deep attention mechanism based on
intermolecular interactions. BMC Bioinform. 2021, 22, 542. [CrossRef] [PubMed]
24.
Stepniewska-Dziubinska, M.M.; Zielenkiewicz, P.; Siedlecki, P. Development and evaluation of a deep learning model for
protein–ligand binding afﬁnity prediction. Bioinformatics 2018, 34, 3666–3674. [CrossRef] [PubMed]

## Page 15 (Section: Discussion)

Molecules 2023, 28, 1661
15 of 15
25.
Li, S.; Zhou, J.; Xu, T.; Huang, L.; Wang, F.; Xiong, H.; Huang, W.; Dou, D.; Xiong, H. Structure-aware interactive graph
neural networks for the prediction of protein–ligand binding afﬁnity. In Proceedings of the 27th ACM SIGKDD Conference on
Knowledge Discovery & Data Mining, Virtual Event, 14–18 August 2021; pp. 975–985. [CrossRef]
26.
Emmert-Streib, F.; Yang, Z.; Feng, H.; Tripathi, S.; Dehmer, M. An Introductory Review of Deep Learning for Prediction Models
With Big Data. Front. Artif. Intell. 2020, 3, 4. [CrossRef]
27.
Wójcikowski, M.; Ballester, P.J.; Siedlecki, P. Performance of machine-learning scoring functions in structure-based virtual
screening. Sci. Rep. 2017, 7, 46710. [CrossRef] [PubMed]
28.
Yang, J.; Shen, C.; Huang, N. Predicting or pretending: Artiﬁcial intelligence for protein–ligand interactions lack of sufﬁciently
large and unbiased datasets. Front. Pharmacol. 2020, 11, 69. [CrossRef]
29.
Warren, G.L.; Do, T.D.; Kelley, B.P.; Nicholls, A.; Warren, S.D. Essential considerations for using protein–ligand structures in drug
discovery. Drug Discov. Today 2012, 17, 1270–1281. [CrossRef]
30.
Deng, J.; Dong, W.; Socher, R.; Li, L.J.; Li, K.; Fei-Fei, L. ImageNet: A large-scale hierarchical image database. In Proceedings of the
2009 IEEE Conference on Computer Vision and Pattern Recognition, Miami, FL, USA, 20–25 June 2009; pp. 248–255. [CrossRef]
31.
Jia, X.; Lynch, A.; Huang, Y.; Danielson, M.; Lang’at, I.; Milder, A.; Ruby, A.E.; Wang, H.; Friedler, S.A.; Norquist, A.J.; et al.
Anthropogenic biases in chemical reaction data hinder exploratory inorganic synthesis. Nature 2019, 573, 251–255. [CrossRef]
32.
Molecular Operating Environment (MOE), 2022.02 Chemical Computing Group ULC, 1010 Sherbooke St. West, Suite #910,
Montreal, QC, Canada, H3A 2R7, 2023. Available online: https://www.chemcomp.com/index.htm (accessed on 1 February
2020).
33.
Jones, G.; Willett, P.; Glen, R.C.; Leach, A.R.; Taylor, R. Development and validation of a genetic algorithm for ﬂexible docking. J.
Mol. Biol. 1997, 267, 727–748. [CrossRef]
34.
Greenidge, P.A.; Lewis, R.A.; Ertl, P. Boosting Pose Ranking Performance via Rescoring with MM-GBSA. Chem. Biol. Drug Des.
2016, 88, 317–328.
35.
Drenth, J. Principles of Protein X-ray Crystallography; Springer Science & Business Media: Berlin/Heidelberg, Germany, 2007.
36.
Berman, H.M.; Westbrook, J.; Feng, Z.; Gilliland, G.; Bhat, T.N.; Weissig, H.; Shindyalov, I.N.; Bourne, P.E. The Protein Data Bank.
Nucleic Acids Res. 2000, 28, 235–242. [CrossRef]
37.
The Protein Data Bank. Available online: https://www.rcsb.org/ (accessed on 1 February 2020).
38.
Pellicani, F.; Dal Ben, D.; Perali, A.; Pilati, S. Data for “Machine Learning Scoring Functions for Drug Discovery from Experimental
and Computer-Generated Protein–Ligand Structures: Towards Per-Target Scoring Functions”. Available online: https://zenodo.
org/record/7514055#.Y-SoVEFBxD8 (accessed on 1 December 2022).
39.
Chen, X.; Liu, M.; Gilson, M.K. BindingDB: A web-accessible molecular recognition database. Comb. Chem. High Throughput
Screen. 2001, 4, 719–725. [CrossRef] [PubMed]
40.
Chen, X.; Lin, Y.; Liu, M.; Gilson, M.K. The Binding Database: Data management and interface design. Bioinformatics 2002,
18, 130–139. [CrossRef] [PubMed]
41.
Liu, T.; Lin, Y.; Wen, X.; Jorissen, R.N.; Gilson, M.K. BindingDB: A web-accessible database of experimentally determined
protein–ligand binding afﬁnities. Nucleic Acids Res. 2007, 35, D198–D201. [CrossRef] [PubMed]
42.
Falsini, M.; Catarzi, D.; Varano, F.; Dal Ben, D.; Marucci, G.; Buccioni, M.; Volpini, R.; Di Cesare Mannelli, L.; Ghelardini, C.;
Colotta, V. Novel 8-amino-1,2,4-triazolo[4,3-a]pyrazin-3-one derivatives as potent human adenosine A1 and A2A receptor
antagonists. Evaluation of their protective effect against β-amyloid-induced neurotoxicity in SH-SY5Y cells. Bioorganic Chem.
2019, 87, 380–394. [CrossRef]
43.
Ceni, C.; Catarzi, D.; Varano, F.; Ben, D.D.; Marucci, G.; Buccioni, M.; Volpini, R.; Angeli, A.; Nocentini, A.; Gratteri, P.; et al.
Discovery of ﬁrst-in-class multi-target adenosine A2A receptor antagonists-carbonic anhydrase IX and XII inhibitors. 8-Amino-
6-aryl-2-phenyl-1,2,4-triazolo [4,3-a]pyrazin-3-one derivatives as new potential antitumor agents. Eur. J. Med. Chem. 2020,
201, 112478. [CrossRef]
44.
Goodfellow, I.; Bengio, Y.; Courville, A. Deep Learning; MIT Press: Cambridge, MA, USA, 2016.
45.
Chollet, F. Keras. 2015. Available online: https://keras.io (accessed on 1 June 2020).
48.
Kingma, D.P.; Ba, J. Adam: A Method for Stochastic Optimization. arXiv 2014,
47.
Brown, N.; Cambruzzi, J.; Cox, P.J.; Davies, M.; Dunbar, J.; Plumbley, D.; Sellwood, M.A.; Sim, A.; Williams-Jones, B.I.; Zwierzyna,
M.; et al. Big Data in Drug Discovery. Prog. Med. Chem. 2018, 57, 277–356. [CrossRef]
48.
Brown, N.; Fiscato, M.; Segler, M.H.; Vaucher, A.C. GuacaMol: Benchmarking Models for de Novo Molecular Design. J. Chem. Inf.
Model. 2019, 59, 1096–1108. . [CrossRef]
Disclaimer/Publisher’s Note: The statements, opinions and data contained in all publications are solely those of the individual
author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to
people or property resulting from any ideas, methods, instructions or products referred to in the content.
