# Evaluation of Artificial Intelligence in Participating Structure-Based Virtual Screening for Identifying Novel Interleukin-1 Receptor Associated Kinase-1 Inhibitors

- **Authors:** Jinxin Che, Ruiwei Feng, Jian Gao, Hongyun Yu, Qinjie Weng, Qiaojun He, Xiaowu Dong, Jian Wu, Bo Yang
- **Issuer:** Frontiers in oncology
- **Type:** Scientific article
- **Published:** 2020-09-03
- **Language:** en
- **DOI:** 10.3389/fonc.2020.01769
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33014870/
- **Licence:** CC-BY

## Section: Abstract

Interleukin-1 receptor associated kinase-1 (IRAK1) exhibits important roles in inflammation, infection, and autoimmune diseases; however, only a few inhibitors have been discovered. In this study, at first, a discriminatory structure-based virtual screening (SBVS) was employed, but only one active compound (compound 1, IC50 = 2.25 μM) was identified. The low hit rate (2.63%) which derives from the weak discriminatory power of docking among high-scored molecules was observed in our virtual screening (VS) process for IRAK1 inhibitor. Furthermore, an artificial intelligence (AI) method, which employed a support vector machine (SVM) model, integrated information of molecular docking, pharmacophore scoring and molecular descriptors was constructed to enhance the traditional IRAK1-VS protocol. Using AI, it was found that VS of IRAK1 inhibitors excluded by over 50% of the inactive compounds, which could significantly improve the prediction accuracy of the SBVS model. Moreover, four active molecules (two of which exhibited comparative IC50 with compound 1) were accurately identified from a set of highly similar candidates. Amongst, compounds with better activity exhibited good selectivity against IRAK4. The AI assisted workflow could serve as an effective tool for enhancement of SBVS.

## Section: Introduction

In the process of drug discovery, hunting for lead compounds is not only a starting point, but also a very challenging task. With the emergence of comprehensive chemical databases, high throughput screening (HTS), and virtual screening (VS) have been employed for finding lead compounds from known chemicals (1). As a complementary approach to HTS (2), VS filters chemicals through ligand- or structure-based approaches by taking advantages of high-performance computers, overcomes some shortcomings of HTS, and remarkably reducing the time, money, and resources involved (3, 4). However, some problems still exist in the individual VS method. For example, the scoring functions of virtual screening are not accurate enough to predict the protein-ligand binding affinity and this leads to a high rate of false results, which needs combined strategies to improve prediction accuracy in a sequential or parallel manner (5, 6).

In recent years, artificial intelligence (AI) has offered new opportunities in drug discovery. The AI techniques that have displayed superior performances (7, 8) in finding new active chemicals include Naive Bayes, support vector machine (SVM), random forest (RF), feed-forward artificial neural networks (ANNs), and deep neural network approaches. It has been reported that the hit rate of VS can be significantly improved by combining AI methods. For example, Leong et al. developed an accurate ensemble docking scheme, which established a SVM based on combinatorial docking features and molecular descriptors to predict N-methyl-D-aspartate-receptor GluN1-ligand binding affinity (9). Tian et al. integrated ensemble molecular docking and complex-based pharmacophore searching using Naive Bayesian classification and recursive partitioning, which were of great significance in the discovery of novel ROCK inhibitors and increased the VS hit rate to 28.95% (10). Hence, the application of AI in VS seems promising.

Interleukin receptor associated kinase-1 (IRAK1) is a downstream member of the serine-threonine kinase interleukin receptor associated kinase (IRAK) family. Once the IL1-Rs and toll-like receptors (TLRs) are activated, IRAK4 is recruited to form the signaling complex with myeloid differentiation primary-response gene 88 (MyD88) and then IRAK1 is phosphorylated, which plays a crucial role in inflammation, infection, and autoimmune diseases (11). Researchers found that the suppression of IRAK1, either by inhibitors or RNAi, has potent activity against Waldenström’s macroglobulinemia (12), myelodysplastic syndrome (13), and certain subtypes of acute myeloid leukemia (14). However, IRAK1 selective inhibitors are rare, and most of the compounds that inhibit IRAK1 are also IRAK4 inhibitors. The benzimidazole derivative 1 shown in Figure 1 is commonly used in bio-experiment (15). In addition, researchers found that the anaplastic lymphoma kinase (ALK) inhibitor 2 (16), and Pacritinib (17), the JAK/FLT3 inhibitor 3, could be potent inhibitors of IRAK1.

As a continuation of our virtual screening work which identified new inhibitors targeting NIK, CHK1, Akt, etc. (18–24). In this study, we performed a traditional VS procedure to identify potential inhibitors of IRAK1. Using a well-designed screening process, only one compound (compound 1, IC50 = 2.25 μM) was discovered, which was far from satisfactory. Considering the advantages of AI in VS, we further established a machine-learning model that combines multiple docking, complementary pharmacophore mapping, and molecular descriptors on the basis of a traditional VS workflow to increase the enrichment rate among high- scoring compounds. Training data consisted of IRAK1 inhibitors and decoys that were prepared for SVM, XGBOOST, and LGBM models. Finally, we used the SVM model that exhibited the best accuracy, to validate the activities of molecules in the post-docking stage and found that it significantly improved the performance of traditional VS and excluded over half of the false positive candidates which was predicted positive in VS but showed no activities in bioassay. Moreover, four other active compounds (compound 2, IC50 = 2.32 μM; compound 3, IC50 = 2.48 μM; compound 4 IC50 = 18.04 μM; and compound 5 IC50 = 23.75 μM) were identified from a series of highly similar compounds by utilizing this model, which demonstrated that the integrated VS strategy enhanced by AI was promising in the process of drug discovery.

Examples of compounds with IRAK1 inhibitory activity.

## Section: Materials and Methods › Evaluation of the Docking Method

Crystal structure of human wild type IRAK1 (PDB ID: 6BFN) with its inhibitor (DL1) was downloaded from RCSB Protein Data Bank. Each chain of the protein was prepared separately including the removal of water, alternate position of residues, the addition of hydrogens, the assignment of bond orders, the optimization of H-bonds and the restrained minimization of energy using Schrödinger’s Protein Preparation Wizard. The receptor grids were generated using the Receptor Grid Generation module and all preparation parameters were set to default. The inhibitors were re-docked into their receptors to calculate the root mean square deviation (RMSD) value and compared with their original structure. Furthermore, 594 inhibitors with known IC50 values were collected from the ChEMBL database (Supplementary Table S1) and 150 potent inhibitors were selected after structural clustering to generate a decoy dataset using the DUD-E database (25). All 150 inhibitors and 9200 decoys were prepared using the Ligprep module to generate the possible ionization states and three-dimensional conformations. Lastly, the compounds were docked separately to the prepared chains of 6BFN using the SP and XP patterns in the Ligand Docking module. Similarly, the compounds and proteins were docked using AutoDock after preparation via AutoDockTools with a grid size of 54 points. The docking scores were collected to calculate the p-value after the docking process.

## Section: Materials and Methods › Pharmacophore Construction

The best conformation of 6BFN_B re-docking complex was applied to construct the pharmacophore model for ligand-based VS. The pharmacophore containing at most 7 features and a receptor-based excluded volume shell was created using Develop Pharmacophore Model in the Schrödinger module, with the method set to E-Pharmacophore.

## Section: Materials and Methods › Virtual Screening

A database containing 1.5 million compounds was downloaded from ChemDiv and was filtered using Lipinski’s Rule-of-Five before commencing the process of VS. Molecules which passed the filter were further aligned to the established pharmacophore model in the Ligand Screening module of Schrödinger so that all compounds with similar structural features could be considered for the next step. After the preparation in Ligprep, the molecules preserved were docked in Ligand Docking module under standard precision (SP) and default parameters. The top-scoring compounds were subjected to extra precision (XP) docking in order to exclude the molecules that were low-ranking in the XP mode. The compounds which underwent the entire screening protocol were clustered based on their structural similarity and selected manually for the bioactivity test.

## Section: Materials and Methods › IRAK1 Bioactivity Test

Mobility shift assay was applied to test the bioactivity of the candidates at a concentration of 20 μM using Staurosporine as the positive control. All compounds were dissolved in 100% DMSO to yield a final concentration of 2 mM. IRAK1 kinase and kinase substrate (including ATP) were dissolved in 1 × Kinase buffer. A mixture of 250 nL of the test compound and 10 μL kinase solution were centrifuged at 1000 rpm for 30 s and incubated for 10 min at 25°C in a 384-well white plate. The plate was centrifuged at 1000 rpm and incubated for 60 min after the addition of 15 μL kinase solution (including ATP). Finally, 30 μL stop buffer was added to terminate the reaction and the conversion rate was evaluated using ELIASA (Caliper EZ Reader, Perkin Elmer) to calculate the rate of inhibition.

## Section: Materials and Methods › SVM-Assisted Selection and Bioactivity Test › Machine Learning Dataset

An inhibitor dataset and a decoy dataset made up the training set of the machine- learning model. The inhibitors of IRAK1 were collected from ChEMBL Database and 150 potent inhibitors were extracted after a structural clustering. For the decoy dataset, 150 chemicals were randomly selected from the single-target compounds database of ChEMBL. Compounds in the training set were prepared and docked into each chain of 6BFN using Glide-SP, Glide-XP, and AutoDock. All docking parameters used were the same as those in the evaluation process.

A group of novel pharmacophore models were generated using the 3D QSAR Pharmacophore Generation module of Discovery Studio Client 2.5 using the 594 inhibitors found in the ChEMBL Database. H-bond acceptors, H-bond donors, hydrophobic molecules, and aromatic compounds were considered and the upper limit of each feature was set to 5. For every molecule, at most 255 conformations were generated to find the best conformation and the maximum pharmacophores was set to 10. Since the pharmacophore models were built, the best conformations of compounds in the training dataset were generated and mapped to the pharmacophores flexibly in the Ligand Pharmacophore Mapping module of Discovery Studio Client 2.5. The fit value of each molecule was extracted. The compounds that failed to map onto the pharmacophore model were assigned fit values that were set to 0 uniformly.

PaDEL v2.20 was used to calculate the 1D and 2D descriptors of the compounds in the inhibitor and decoy sets. Salts were removed and the nitro groups were standardized before the calculation.

## Section: Materials and Methods › SVM-Assisted Selection and Bioactivity Test › Data Preprocessing

In this study, we conducted data pre-processing including index elimination and data normalization. We collected almost 1460 indices to represent each molecule, which is large for any machine learning model to analyze. Thus, we used several approaches to eliminate some indices. This process mainly consisted of the following 4 steps:

After conducting these four steps, only 244 of the 1460 indices remained. Then, the normalization on the basis of mean and standard deviation of a batch was conducted.

## Section: Materials and Methods › SVM-Assisted Selection and Bioactivity Test › Model Construction

In this paper, we constructed three traditional machine learning models including SVM, LGBM, and XGBoost using Scikit-learn package.

## Section: Materials and Methods › SVM-Assisted Selection and Bioactivity Test › Metrics

In this study, to compare the performance of different models, we utilized the area under the curve (AUC) and accuracy (ACC) as metrics. AUC was defined as the area of the receiver operating characteristic (ROC) Curve, which was defined by true positive rate (TPR) and false positive rate (FPR). The TPR and FPR are given by:

Where TP, FP, TN, and FN were true positives, false positives, true negatives and false negatives, respectively. AUC and ACC were computed using the following equations.

## Section: Materials and Methods › SVM-Assisted Selection and Bioactivity Test › Prediction and Bioassay

Similarity search was carried out using the MolPort database. Ten chemicals, whose Tanimoto similarity was larger than 0.8 compared with compound 1, were collected along with their multiple docking scores, pharmacophore scores, and molecular descriptors. These data were processed using the best model to predict their inhibition toward IRAK1. Candidates in the last stage of virtual screening procedure were also predicted similarly.

Lastly, compounds derived using the similarity search were bought from TargetMol and their inhibition rate was tested using the method described above. The dose-effect curve (all compounds were dissolved in DMSO and diluted 10-fold from 100 μM to 1 nM) was fitted to calculate the IC50 value.

## Section: Materials and Methods › Molecular Dynamics Simulation

The binding mode of compound 1 was confirmed using molecular dynamics simulation. The parameter files of compound 1 were generated in antechamber module of Amber and was combined with 6BFN_B under ff99SB and gaff force field. After six chloride ions were added, the neutralized system was solvated in a tetrahedral box of TIP3P and the distance between box boundary and IRAK1 protein was set to 10.0 Å. At first, the energy of the entire system was relaxed using three steps: the hydrogen atoms, chloride ions, and water were optimized using 2500 steps of steepest descent minimization and 2500 steps of conjugate gradient minimization; the side chains of the protein, chloride ions, and waters were relaxed using 2500 steps of steepest descent minimization and 2500 steps of conjugate gradient minimization; the system was minimized using 2500 steps of steepest descent minimization and 2500 steps of conjugate gradient minimization. The system was heated to 300 K in 100 ps and equilibrated for 100 ps in NPT mode (temperature = 300 K; pressure = 1 atm) with the heavy atoms of the complex being restrained. Then, the whole system was equilibrated in NPT mode for 100 ps. Lastly, a five nanosecond MD simulation was carried out and the binding energy was decomposed.

## Section: Results

Evaluation of docking methods.

ROC curve of different combination of receptors (6BFN_A, 6BFN_B) and docking software (Glide SP, XP, and AutoDock).

(A) Binding mode of the ligand (DL1) in 6BFN_B; (B) Pharmacophore model; and (C) Work flow of virtual screening.

Construction of training dataset.

Comparison of our three traditional machine-learning models for activity prediction.

ROC curves of different combination of models and input data. (A) corresponds to feed model with data containing DS, PS, and MD; (B) for PS and MD; and (C) for data with MD only.

SVM model performance on IRAK1 VS candidates (top scoring compounds derived from Glide SP docking, Glide XP docking, visual selection, and SVM prediction).

Detailed information of compounds predicted by SVM model (compound ID; docking scores from Glide SP, Glide XP, and AutoDock; average docking scores; predicted labels and IC50 values).

Structure of compound 1 and those predicted using SVM (compounds 2–11).

Analysis of MD simulation. (A) root mean square deviation (RMSD) and root mean square fluctuation (RMSF) of the IRAK1 backbone during MD simulation; (B) 3D-plot of the complex; (C) length of the hydrogen bond (compound 1_O-Leu_291_H, compound 1_C = O-Lys_239_N); and (D) plot of free energy decomposition.

## Section: Results › Virtual Screening

In order to select the most effective screening method, we evaluated the performance of different proteins and molecular-docking software. For each monomer of the IRAK1 crystal structure (6BFN_A and 6BFN_B from protein data bank) (27), we docked the original ligand into the binding pocket to evaluate the reproducibility of several frequently-used docking methods. We then shortlisted 150 potent IRAK1 inhibitors and used 9200 random decoys to judge whether the docking methods and protein chains could distinguish the inhibitors from decoys effectively. As seen in Table 1, the RMSD value for each docking approach was less than 1, which indicated that all approaches could reproduce the structure of each complex accurately. The best capabilities of discrimination power were exhibited by 6BFN_B coupling with Glide SP and Glide XP, which reached the smallest p-value of 10–32 (Supplementary Figure S1). The ROC curve and the AUC are shown in Figure 2. Since the performances of the docking methods used in our study were not adequately satisfactory, we established a pharmacophore model to filter out molecules that we did not wish to pursue beyond the docking process. According to the conformation of the 6BFN_B re-docking results, we analyzed the binding mode of the IRAK1 inhibitor (Figure 3A) and constructed a pharmacophore, which contained a hydrogen-bond donor, a hydrogen-bond acceptor, and an aromatic ring, using the Develop Pharmacophore Model of Schrödinger which is suitable for the preliminary virtual screening and saving the time costs of calculation (Figure 3B).

We collected 1.5 million chemicals from the ChemDiv database. Firstly, compounds in the database were pre-processed using a filter which could exclude chemicals that did not conform to the Lipinski’s rule of five (28). Next, we screened the remaining 1.2 million compounds in the established pharmacophore model and 56,000 molecules having a structure similar to that of the IRAK1 inhibitor were preserved. Glide SP docking was applied and all docked compounds were ranked by their docking scores. We selected the first 506 molecules for Glide XP docking in order to eliminate the compounds with lower docking scores. Thus, we obtained 353 molecules that possessed both, high docking scores and different docking precision. These compounds were clustered according to their molecular fingerprints. The most representative 43 candidates (38 compounds were purchasable) from each cluster were selected for biological assay (Figure 3C).

Evaluation of docking methods.

ROC curve of different combination of receptors (6BFN_A, 6BFN_B) and docking software (Glide SP, XP, and AutoDock).

(A) Binding mode of the ligand (DL1) in 6BFN_B; (B) Pharmacophore model; and (C) Work flow of virtual screening.

## Section: Results › Biological Evaluation

To test whether the selected molecules were active, kinase activity experiments were carried out using the mobility shift assay, in which staurosporine was chosen as the positive control. Each compound was dissolved in DMSO at a concentration of 20 μM and used in the assay (Supplementary Table S2). Compound 1 (Y041-8246) showed a moderate inhibition rate (85.5% at 20 μM) compared to staurosporine (IC50 = 59.29 nM; Supplementary Figure S2). The screening hit rate was 2.63% (1/38). The Tanimoto similarities between compound 1 and the known IRAK1 inhibitors were below 0.34, thus indicating that this was a new structure which bears benzofuran scaffold for IRAK1 inhibition. Moreover, structure clustering of IRAK1 inhibitors collected from ChEMBL was performed, the result indicated that benzofuran derivatives were different from any of these scaffolds (Supplementary Figure S3).

## Section: Results › Establishment of Machine Learning Model

Considering the unsatisfactory performance of the traditional VS method with a hit rate of 2.63% in this study, which could not completely meet the demand of drug discovery, we attempted to find a better approach to discriminate lead compounds from a set of high-scored compounds. Ten molecules from the MolPort database1 whose Tanimoto similarities were higher than 0.8, when compared with compound 1, were chosen to be further studied. In order to take the pharmacophore and structural information into consideration, we calculated multiple docking scores, complementary pharmacophore mapping scores, and molecular descriptors (Figure 4). The molecules in the training set consisted of 150 potent IRAK1 inhibitors and 150 decoys (Supplementary Table S3). Their docking scores were obtained using AutoDock (29), Glide SP, and Glide XP toward 6BFN_A and 6BFN_B, respectively. In this model, since it was need to construct different pharmacophore models according to known ligands, Discovery Studio was employed and all selected molecules were then mapped to pharmacophores to calculate their fit values, which demonstrated their extent of conformity to the pharmacophore models. The one- and two-dimensional molecular descriptors were calculated using PaDEL (30) to complement the physicochemical properties. Lastly, 6 docking scores, 9 fit values, and 1444 molecular descriptors were obtained for each compound.

Based on the characteristics of the data, we employed several traditional machine learning methods for activity prediction. In this section, we describe how data pre-processing was performed and the three machine-learning models for activity prediction was constructed. Considering the inactivity of most molecules, we used ACC and AUC to measure the performance of each model. For a fair comparison, we divided the 300 molecules into 5 groups to conduct a 5-fold cross validation. For the final test, all parameters were selected based on the best ACC performance of models on validation sets. All models were developed using python 3.7.3 with TensorFlow deep learning library and all experiments were constructed on an NVIDIA GeForce GTX 1080Ti GPU.

In this study, we compared the performance of each model using data with different inputs. The mean AUC and ACC scores of different models on 5-fold validation sets are shown in Table 2, different inputs (docking scores, pharmacophore mapping scores, and molecular descriptors) are presented in the first column and simply denoted as DS, PS, and MD, respectively. That is to say, the AUC and ACC results of different models in the first row are obtained by models receiving docking scores, pharmacophore mapping scores and molecular descriptors at the same time, while results in the last row are obtained by models merely receiving molecular descriptor. Obviously, a slight improvement of AUC or ACC is observed when docking and pharmacophore information were taken into consideration. Besides, it is notable in each row that SVM outperforms all the other two models. Therefore, we use SVM with all the three kind of inputs as the final model, denoted as SVM (DS+PS+MD). Table 2 and Figure 5 illustrate the performance of each combination of model and input data.

Construction of training dataset.

Comparison of our three traditional machine-learning models for activity prediction.

ROC curves of different combination of models and input data. (A) corresponds to feed model with data containing DS, PS, and MD; (B) for PS and MD; and (C) for data with MD only.

## Section: Results › SVM-Model Can Identify Active Compounds Accurately

To verify the practicality of the SVM (DS+PS+MD) model, we predicted the activity of molecules at later stages of VS (Figure 6). Among the molecules exhibiting superior docking scores in Glide SP and Glide XP, our model identified 51.78% selected from Glide SP, and 56.66% from Glide XP docking as inactive. Among the 38 candidates whose inhibitory had been tested, 21 inactive chemicals were accurately identified. Although there also existed several inactive candidates that were classified as active, compound 1 was picked precisely.

Ten compounds in the MolPort database with a Tanimoto similarity greater than 0.8 as compared to compound 1 were collected. Since almost all multiple docking scores appeared similar and very close (Table 3), the docking software was unable to yield accurate results. When the training information of these compounds was fed into the SVM model, the results classified two compounds as inactive, although one of them had the best average docking score. The decrease in the exclusion rate from 50 to 20% indicated that this model was competent to identify the structural features of IRAK1 inhibitors, which could thus help computational chemists select lead compounds more accurately.

Next, the activities of these compounds were tested. Ten candidates were bought from TargetMol and their IC50s were determined. The initial concentration was set to 100 μM and a serial 10-fold dilution was made to 1 nM. Compounds 2 (Y041-7950) and 3 (Y041-6433) exhibited similar IRAK1 inhibition and their IC50 values were determined to be approximately 2 μM. Additionally, two other chemicals showed weaker inhibition and their IC50 values were determined to be 18.04 μM (compound 4: 11570480 from Otava Database) and 23.75 μM, (compound 5: Y041-7951), respectively (Figure 7 and Supplementary Figure S2). We further tested the activity against IRAK4 of the three most potent IRAK1 inhibitors such as compound 1, 2, and 3. The result indicated that all the compounds showed extreme low inhibitory activities against IRAK4, which IC50s were > 100 μM (Supplementary Figure S4). The compounds bearing benzofuran scaffold were demonstrated an over 40-fold selectivity to IRAK4, showing its potential to be developed as selective IRAK1 inhibitor. When these compounds were used in our model, it accurately predicted the results that were determined earlier in the similarity search results. The AI model proved to be an effective tool in this prediction.

SVM model performance on IRAK1 VS candidates (top scoring compounds derived from Glide SP docking, Glide XP docking, visual selection, and SVM prediction).

Detailed information of compounds predicted by SVM model (compound ID; docking scores from Glide SP, Glide XP, and AutoDock; average docking scores; predicted labels and IC50 values).

Structure of compound 1 and those predicted using SVM (compounds 2–11).

## Section: Results › Molecular Dynamics Simulation

Since the active compounds share same scaffold, the most potent compound 1 was chosen for the analysis of binding mode with IRAK1. In order to analyze the most stable binding pattern, we performed 5 ns molecular dynamics simulation of compound 1 using AmberTools (31). As seen in Figure 8, the RMSD value of the IRAK1 backbone and the ligand reached equilibration after 3 ns and 1 ns simulation, respectively. The average RMSF value of compound 1 was 2.47 Å, indicating a stable binding pattern. Compound 1 formed two hydrogen bonds with the H-bond donors from LYS_239 and LEU_291, and also formed stable Van der Waals interaction through hydrophobic or hydrophilic amino acid residues such as ILE_218, PHE_294, LEU_347, and ASP_358. The lengths of the H-bonds and MM-GBSA free energy confirmed that the hydrogen bond between compound 1 and LYS_239 was more stable and contributed significantly to the formation of the complex.

Analysis of MD simulation. (A) root mean square deviation (RMSD) and root mean square fluctuation (RMSF) of the IRAK1 backbone during MD simulation; (B) 3D-plot of the complex; (C) length of the hydrogen bond (compound 1_O-Leu_291_H, compound 1_C = O-Lys_239_N); and (D) plot of free energy decomposition.

## Section: Discussion and Conclusion

In this study, we discovered a novel IRAK1 inhibitor (compound 1) through traditional virtual screening and also obtained four similar compounds which exhibited good to moderate IRAK1 activity in the AI-aided selection process. As the screening power of docking-based virtual screening was significantly weak (hit rate = 2.63%) to select hit compounds from highly scored molecules, an AI-based discriminatory virtual screening protocol was conducted to assist the final selection procedure of virtual screening.

The major strength of this protocol is a comprehensive integration of activity-related factors through machine learning. Comparing with other machine learning studies (9, 10), this research integrated both protein-ligand binding information, ligand-based pharmacophore information and molecular physiochemical properties into an SVM classifier which can yield satisfactory performance without the requirement of a great deal of known inhibitors. Since diverse receptor structures and pharmacophores were considered, more reliable judgments can be made after dimension reduction and model training. Whereas, there still exists some limitations in the screening process. For example, since the virtual screening targeted a specific binding pocket, it was possible that some positive compounds showing different interaction mode would be excluded. It is necessary to further combine virtual screening with different AI methods for improving its prediction ability more accurately.

Experiments showed that this SVM model can effectively exclude over 50% of the inactive compounds in virtual screening and retain the most promising candidates, which can improve the hit rate prominently in the last phase of VS. Moreover, four molecules were successfully predicted using this model, from a set of compounds that were similar to compound 1. The model displayed better discriminatory power among highly similar candidates.

The identified compounds all bear benzofuran scaffold, which was different from other IRAK1 inhibitors. The acetamide group seems important in maintaining the inhibitory activity of compounds, such as the IC50 values of compound 1 vs compound 7, compound 2 vs compound 9, and compound 4 vs compound 11. Moreover, compound 1, 2, and 3 were demonstrated an over 40-fold selectivity to IRAK4, showing its potential to be developed as selective IRAK1 inhibitor. The results provide valuable knowledge for further optimization and development of IRAK1 inhibitors and demonstrate that AI can assist VS strategy in a sequential manner for identifying new IRAK1 inhibitors.

## Section: Data Availability Statement

All datasets presented in this study are included in the article/Supplementary Material.

## Section: Author Contributions

JC, RF, JG, and HY processed the data, built the models, analyzed the results, and drafted the manuscript. QW and QH assisted in the design of this study. XD, JW, and BY conceived and designed this research. All authors contributed to the article and approved the submitted version.

## Section: Conflict of Interest

The authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.


---

# Guidelines for clinical trial protocols for interventions involving artificial intelligence: the SPIRIT-AI extension

- **Authors:** Samantha Cruz Rivera, Xiaoxuan Liu, An-Wen Chan, Alastair K Denniston, Melanie J Calvert, SPIRIT-AI and CONSORT-AI Working Group, SPIRIT-AI and CONSORT-AI Steering Group, SPIRIT-AI and CONSORT-AI Consensus Group
- **Issuer:** Nature medicine
- **Type:** Scientific article
- **Published:** 2020-09-09
- **Language:** en
- **DOI:** 10.1038/s41591-020-1037-7
- **Source:** https://pubmed.ncbi.nlm.nih.gov/32908284/
- **Licence:** CC-BY

## Page 1 (Section: Guidelines for clinical trial protocols for interventions involving artificial intelligence: the SPIRIT-AI extension)

Consensus Statement
https://doi.org/10.1038/s41591-020-1037-7
1Centre for Patient Reported Outcomes Research, Institute of Applied Health Research, University of Birmingham, Birmingham, UK. 2Institute of Applied 
Health Research, University of Birmingham, Birmingham, UK. 3Birmingham Health Partners Centre for Regulatory Science and Innovation, University 
of Birmingham, Birmingham, UK. 4Academic Unit of Ophthalmology, Institute of Inflammation and Ageing, University of Birmingham, Birmingham, 
UK. 5University Hospitals Birmingham NHS Foundation Trust, Birmingham, UK. 6Health Data Research UK, London, UK. 7Moorfields Eye Hospital NHS 
Foundation Trust, London, UK. 8Department of Medicine, Women’s College Research Institute, Women’s College Hospital, University of Toronto, Ontario, 
Canada. 9National Institute of Health Research Biomedical Research Centre for Ophthalmology, Moorfields Hospital London NHS Foundation Trust and 
University College London, Institute of Ophthalmology, London, UK. 10National Institute of Health Research Birmingham Biomedical Research Centre, 
University of Birmingham and University Hospitals Birmingham NHS Foundation Trust, Birmingham, UK. 11National Institute of Health Research Applied 
Research Collaborative West Midlands, Coventry, UK. 12National Institute of Health Research Surgical Reconstruction and Microbiology Centre, University 
of Birmingham and University Hospitals Birmingham NHS Foundation Trust, Birmingham, UK. *A list of authors and their affiliations appears at the end of 
the paper. ✉e-mail: a.denniston@bham.ac.uk
A 
clinical trial protocol is an essential document produced by 
study investigators detailing a priori the rationale, proposed 
methods and plans for how a clinical trial will be conducted1,2. 
This key document is used by external reviewers (funding agencies, 
regulatory bodies, research ethics committees, journal editors, peer 
reviewers, institutional review boards and, increasingly, the wider 
public) to understand and interpret the rationale, methodological 
rigor and ethical considerations of the trial. Additionally, trial pro-
tocols provide a shared reference point to support the research team 
in conducting a high-quality study.
Despite their importance, the quality and completeness of pub-
lished trial protocols are variable1,2. The SPIRIT statement was 
published in 2013 to provide guidance for the minimum reporting 
content of a clinical-trial protocol and has been widely endorsed 
as an international standard3–5. The SPIRIT statement published in 
2013 provides minimum guidance applicable for all clinical trial 
interventions but recognizes that certain interventions may require 
extension or elaboration of these items1,2. AI is an area of enormous 
interest, with strong drivers to accelerate new interventions through 
to publication, implementation and market6. While AI systems have 
been researched for some time, recent advances in deep learning 
and neural networks have gained considerable interest for their 
potential in health applications. Examples of such applications of 
these are wide ranging and include AI systems for screening and 
triage7,8, diagnosis9–12, prognostication13,14, decision support15 and 
treatment recommendation16. However, in most recent cases, the 
majority of published evidence has consisted of in silico, early-phase 
validation. It has been recognized that most recent AI studies are 
inadequately reported and existing reporting guidelines do not fully 
cover potential sources of bias specific to AI systems17. The welcome 
emergence of randomized controlled trials seeking to evaluate the 
clinical efficacy of newer interventions based on, or including, an 
Guidelines for clinical trial protocols for 
interventions involving artificial intelligence:  
the SPIRIT-AI extension
Samantha Cruz Rivera1,2,3, Xiaoxuan Liu   3,4,5,6,7, An-Wen Chan8, Alastair K. Denniston   1,3,4,5,6,9 ✉, 
Melanie J. Calvert   1,2,3,6,10,11,12, The SPIRIT-AI and CONSORT-AI Working Group*, SPIRIT-AI and 
CONSORT-AI Steering Group and SPIRIT-AI and CONSORT-AI Consensus Group
The SPIRIT 2013 statement aims to improve the completeness of clinical trial protocol reporting by providing evidence-based 
recommendations for the minimum set of items to be addressed. This guidance has been instrumental in promoting transpar-
ent evaluation of new interventions. More recently, there has been a growing recognition that interventions involving artifi-
cial intelligence (AI) need to undergo rigorous, prospective evaluation to demonstrate their impact on health outcomes. The 
SPIRIT-AI (Standard Protocol Items: Recommendations for Interventional Trials–Artificial Intelligence) extension is a new 
reporting guideline for clinical trial protocols evaluating interventions with an AI component. It was developed in parallel with 
its companion statement for trial reports: CONSORT-AI (Consolidated Standards of Reporting Trials–Artificial Intelligence). 
Both guidelines were developed through a staged consensus process involving literature review and expert consultation to 
generate 26 candidate items, which were consulted upon by an international multi-stakeholder group in a two-stage Delphi 
survey (103 stakeholders), agreed upon in a consensus meeting (31 stakeholders) and refined through a checklist pilot (34 par-
ticipants). The SPIRIT-AI extension includes 15 new items that were considered sufficiently important for clinical trial protocols 
of AI interventions. These new items should be routinely reported in addition to the core SPIRIT 2013 items. SPIRIT-AI recom-
mends that investigators provide clear descriptions of the AI intervention, including instructions and skills required for use, the 
setting in which the AI intervention will be integrated, considerations for the handling of input and output data, the human–AI 
interaction and analysis of error cases. SPIRIT-AI will help promote transparency and completeness for clinical trial protocols 
for AI interventions. Its use will assist editors and peer reviewers, as well as the general readership, to understand, interpret 
and critically appraise the design and risk of bias for a planned clinical trial.
Nature Medicine | VOL 26 | September 2020 | 1351–1363 | www.nature.com/naturemedicine
1351

## Page 2 (Section: Methods)

Consensus Statement
NATuRe MeDICIne
AI component (called ‘AI interventions’ here)15,18–23 has similarly 
been met with concerns about design and reporting17,24–26. This has 
highlighted the need to provide reporting guidance that is ‘fit for 
purpose’ in this domain.
SPIRIT-AI (as part of the SPIRIT-AI and CONSORT-AI initia­
tive) is an international initiative supported by SPIRIT and the 
EQUATOR (Enhancing the Quality and Transparency of Health 
Research) Network to extend or elaborate on the existing SPIRIT 
2013 statement where necessary, to develop consensus-based 
AI-specific protocol guidance27,28. It is complementary to the 
CONSORT-AI statement, which aims to promote high-quality 
reporting of AI trials. This Consensus Statement describes the 
methods used to identify and evaluate candidate items and gain 
consensus. In addition, it also provides the full SPIRIT-AI checklist, 
including new items and their accompanying explanations.
Methods
The SPIRIT-AI and CONSORT-AI extensions were simultaneously 
developed for clinical trial protocols and trial reports. An announce-
ment for the SPIRIT-AI and CONSORT-AI initiative was published 
in October 2019 (ref. 27), and the two guidelines were registered as 
reporting guidelines under development on the EQUATOR library 
of reporting guidelines in May 2019. Both guidelines were devel-
oped in accordance with the EQUATOR Network’s methodological 
framework29. The SPIRIT-AI and CONSORT-AI Steering Group, 
consisting of 15 international experts, was formed to oversee the 
conduct and methodology of the study. Definitions of key terms are 
provided in the glossary (Box 1).
Ethical approval
This study was approved by the ethical review committee at the 
University of Birmingham, UK (ERN_19-1100). Participant infor-
mation was provided to Delphi participants electronically before 
survey completion and before the consensus meeting. Delphi par-
ticipants provided electronic informed consent, and written consent 
was obtained from consensus meeting participants.
Literature review and candidate item generation
An initial list of candidate items for the SPIRIT-AI and 
CONSORT-AI checklists was generated through review of the 
published literature and consultation with the Steering Group and 
known international experts. A search was performed on 13 May 
2019 using the terms ‘artificial intelligence’, ‘machine learning’ and 
‘deep learning’ to identify existing clinical trials for AI interventions 
listed within the US National Library of Medicine’s clinical trial reg-
istry (ClinicalTrials.gov). There were 316 registered trials, of which 
62 were completed and 7 had published results22,30–35. Two studies 
were reported with reference to the CONSORT statement22,34, and 
one study provided an unpublished trial protocol34. The Operations 
Team (X.L., S.C.R., M.J.C. and A.K.D.) identified AI-specific consid-
erations from these studies and reframed them as candidate report-
ing items. The candidate items were also informed by findings from 
a previous systematic review that evaluated the diagnostic accuracy 
of deep-learning systems for medical imaging17. After consulta-
tion with the Steering Group and additional international experts 
(n = 19), 29 candidate items were generated, 26 of which were rel-
evant for both SPIRIT-AI and CONSORT-AI and 3 of which were 
relevant only for CONSORT-AI. The Operations Team mapped 
these items to the corresponding SPIRIT and CONSORT items, 
revising the wording and providing explanatory text as required to 
contextualize the items. These items were included in subsequent 
Delphi surveys.
Delphi consensus process
In September 2019, 169 key international experts were invited to 
participate in the online Delphi survey to vote upon the candidate 
items and suggest additional items. Experts were identified and 
contacted via the Steering Group and were allowed one round of 
‘snowball’ recruitment in which contacted experts could suggest 
additional experts. In addition, individuals who made contact fol-
lowing publication of the announcement were included27. The 
Steering Group agreed that individuals with expertise in clini-
cal trials and AI and machine learning (ML), as well as key users 
of the technology, should be well represented in the consultation. 
Stakeholders included healthcare professionals, methodologists, 
statisticians, computer scientists, industry representatives, journal 
editors, policy makers, health ‘informaticists’, experts in law and 
ethics, regulators, patients and funders. Participant characteristics 
are described in Supplementary Table 1. Two online Delphi sur-
veys were conducted. DelphiManager software (version 4.0), devel-
oped and maintained by the COMET (Core Outcome Measures in 
Effectiveness Trials) initiative, was used to undertake the e-Delphi 
surveys. Participants were given written information about the 
study and were asked to provide their level of expertise within the 
fields of (i) AI/ML, and (ii) clinical trials. Each item was presented 
for consideration (26 for SPIRIT-AI and 29 for CONSORT-AI). 
Participants were asked to vote on each item using a 9-point 
scale, as follows: 1–3, not important; 4–6, important but not critical; 
and 7–9, important and critical. Respondents provided separate 
ratings for SPIRIT-AI and CONSORT-AI. There was an option 
to opt out of voting for each item, and each item included space 
for free text comments. At the end of the Delphi survey, partici-
pants had the opportunity to suggest new items. 103 responses 
were received for the first Delphi round, and 91 responses (88% of 
participants from round one) were received for the second round. 
The results of the Delphi surveys informed the subsequent inter-
national consensus meeting. 12 new items were proposed by the 
Delphi study participants and were added for discussion at the 
consensus meeting. Data collected during the Delphi survey were 
anonymized, and item-level results were presented at the consensus 
meeting for discussion and voting.
The two-day consensus meeting took place in January 2020 and 
was hosted by the University of Birmingham, UK, to seek consensus 
on the content of SPIRIT-AI and CONSORT-AI. 31 international 
stakeholders from among the Delphi survey participants were 
invited to discuss the items and vote on their inclusion. Participants 
were selected to achieve adequate representation from all the stake-
holder groups. 38 items were discussed in turn, comprising the 26 
items generated in the initial literature review and item-generation 
phase (these 26 items were relevant to both SPIRIT-AI and 
CONSORT-AI; 3 extra items relevant only to CONSORT-AI were 
also discussed) and the 12 new items proposed by participants dur-
ing the Delphi surveys. Each item was presented to the consensus 
group, alongside its score from the Delphi exercise (median and 
interquartile ranges) and any comments made by Delphi partici-
pants related to that item. Consensus meeting participants were 
invited to comment on the importance of each item and whether 
the item should be included in the AI extension. In addition, partic-
ipants were invited to comment on the wording of the explanatory 
text accompanying each item and the position of each item relative 
to the SPIRIT 2013 and CONSORT 2010 checklists. After open dis-
cussion of each item and the option to adjust wording, an electronic 
vote took place, with the option to include or exclude the item. An 
80% threshold for inclusion was pre-specified and deemed reason-
able by the Steering Group to demonstrate majority consensus. Each 
stakeholder voted anonymously using Turning Point voting pads 
(Turning Technologies, version 8.7.2.14).
Checklist pilot
Following the consensus meeting, attendees were given the oppor-
tunity to make final comments on the wording and agree that the 
updated SPIRIT-AI and CONSORT-AI items reflected discussions 
Nature Medicine | VOL 26 | September 2020 | 1351–1363 | www.nature.com/naturemedicine
1352

## Page 3 (Section: Glossary)

Consensus Statement
NATuRe MeDICIne
from the meeting. The Operations Team assigned each item as an 
extension or elaboration item on the basis of a decision tree and 
produced a penultimate draft of the SPIRIT-AI and CONSORT-AI 
checklists (Supplementary Fig. 1). A pilot of the penultimate check-
lists was conducted with 34 participants to ensure clarity of word-
ing. Experts participating in the pilot included the following: (a) 
Delphi participants who did not attend the consensus meeting, 
and (b) external experts who had not taken part in the develop-
ment process but who had reached out to the Steering Group after 
the Delphi study commenced. Final changes were made on word-
ing only to improve clarity for readers, by the Operations Team 
(Supplementary Fig. 2).
Recommendations
SPIRIT-AI checklist items and explanation. The SPIRIT-AI 
extension recommends that, in conjunction with existing SPIRIT 
2013 items, 15 items (12 extensions and 3 elaborations) should 
be addressed for trial protocols of AI interventions. These items 
were considered sufficiently important for clinical-trial proto-
cols for AI interventions that they should be routinely reported 
in addition to the core SPIRIT 2013 checklist items. Table 1 lists 
the SPIRIT-AI items.
All 15 items included in the SPIRIT-AI Extension passed the 
threshold of 80% for inclusion at the consensus meeting. SPIRIT-AI 
6a (i), SPIRIT-AI 11a (v) and SPIRIT-AI 22 each resulted from 
the merging of two items after discussion. SPIRIT-AI 11a (iii) 
did not fulfil the criteria for inclusion on the basis of its initial 
wording (73% vote to include); however, after extensive discus-
sion and rewording, the consensus group unanimously supported 
a re-vote, at which point it passed the inclusion threshold (97% 
to include).
Administrative information
SPIRIT-AI 1 (i) Elaboration: Indicate that the intervention 
involves artificial intelligence/machine learning and specify the 
type of model. Explanation. Indicating in the protocol title and/or 
abstract that the intervention involves a form of AI is encouraged, as 
it immediately identifies the intervention as an AI/ML intervention 
and also serves to facilitate indexing and searching of the trial proto-
col in bibliographic databases, registries and other online resources. 
The title should be understandable by a wide audience; therefore, a 
broader umbrella term such as ‘artificial intelligence’ or ‘machine 
learning’ is encouraged. More precise terms should be used in the 
abstract, rather than the title, unless they are broadly recognized as 
Box 1 | Glossary
Artificial intelligence
The science of developing computer systems that can perform tasks normally requiring human intelligence.
AI intervention
A health intervention that relies upon an AI/ML component to serve its purpose.
CONSORT
Consolidated Standards of Reporting Trials.
CONSORT-AI extension item
An additional checklist item to address AI-specific content that is not adequately covered by CONSORT 2010.
Class-activation map
Class-activation maps are particularly relevant to image classification AI interventions. Class-activation maps are 
visualizations of the pixels that had the greatest influence on predicted class, by displaying the gradient of the predicted 
outcome from the model with respect to the input. They are also referred to as ‘saliency maps’ or ‘heat maps’.
Health outcome
Measured variables in the trial that are used to assess the effects of an intervention.
Human–AI interaction
The process of how users (humans) interact with the AI intervention, for the AI intervention to function as intended.
Clinical outcome
Measured variables in the trial that are used to assess the effects of an intervention.
Delphi study
A research method that derives the collective opinions of a group through a staged consultation of surveys, 
questionnaires, or interviews, with an aim to reach consensus at the end.
Development environment
The clinical and operational settings from which the data used for training the model is generated. This includes all 
aspects of the physical setting (such as geographical location, physical environment), operational setting (such as 
integration with an electronic record system, installation on a physical device) and clinical setting (such as primary, 
secondary and/or tertiary care, patient disease spectrum).
Fine-tuning
Modifications or additional training performed on the AI intervention model, done with the intention of improving its 
performance.
Input data
The data that need to be presented to the AI intervention to allow it to serve its purpose.
Machine learning
A field of computer science concerned with the development of models/algorithms which can solve specific tasks by 
learning patterns from data, rather than by following explicit rules. It is seen as an approach within the field of AI.
Operational environment
The environment in which the AI intervention will be deployed, including the infrastructure required to enable the AI 
intervention to function.
Output data
The predicted outcome given by the AI intervention based on modeling of the input data. The output data can 
be presented in different forms, including a classification (including diagnosis, disease severity or stage, or 
recommendation such as referability), a probability, a class activation map, etc. The output data typically provide 
additional clinical information and/or trigger a clinical decision.
Performance error
Instances in which the AI intervention fails to perform as expected. This term can describe different types of failures, 
and it is up to the investigator to specify what should be considered a performance error, preferably based on prior 
evidence. This can range from small decreases in accuracy (compared to expected accuracy) to erroneous predictions 
or the inability to produce an output, in certain cases.
SPIRIT
Standard Protocol Items: Recommendations for Interventional Trials.
SPIRIT-AI
An additional checklist item to address AI-specific content that is not adequately covered by SPIRIT 2013.
SPIRIT-AI elaboration item
Additional considerations to an existing SPIRIT 2013 item when applied to AI interventions.
Nature Medicine | VOL 26 | September 2020 | 1351–1363 | www.nature.com/naturemedicine
1353

## Page 4 (Section: Table 1 SPIRIT-AI checklist.)

Consensus Statement
NATuRe MeDICIne
Table 1 | SPIRIT-AI checklist
Section
Item
SPIRIT 2013 itema
SPIRIT-AI item
Addressed 
on page 
numberb
Administrative information
Title
1
Descriptive title identifying the study design, 
population, interventions, and, if applicable, trial 
acronym
SPIRIT-AI 1 (i) 
Elaboration
Indicate that the intervention involves 
artificial intelligence/machine 
learning and specify the type of 
model.
SPIRIT-AI 1 (ii) 
Elaboration
Specify the intended use of the AI 
intervention.
Trial registration
2a
Trial identifier and registry name. If not yet 
registered, name of intended registry
2b
All items from the World Health Organization 
Trial Registration Dataset
Protocol version
3
Date and version identifier
Funding
4
Sources and types of financial, material, and other 
support
Roles and 
responsibilities
5a
Names, affiliations, and roles of protocol 
contributors
5b
Name and contact information for the trial 
sponsor
5c
Role of study sponsor and funders, if any, in study 
design; collection, management, analysis, and 
interpretation of data; writing of the report; and 
the decision to submit the report for publication, 
including whether they will have ultimate 
authority over any of these activities
5d
Composition, roles, and responsibilities of the 
coordinating center, steering committee, endpoint 
adjudication committee, data management 
team, and other individuals or groups overseeing 
the trial, if applicable (see Item 21a for data 
monitoring committee)
Introduction
Background and 
rationale
6a
Description of research question and justification 
for undertaking the trial, including summary of 
relevant studies (published and unpublished) 
examining benefits and harms for each 
intervention
SPIRIT-AI 6a (i) 
Extension
Explain the intended use of the AI 
intervention in the context of the 
clinical pathway, including its purpose 
and its intended users (for example, 
healthcare professionals, patients, 
public).
SPIRIT-AI 6a (ii) 
Extension
Describe any pre-existing evidence 
for the AI intervention.
6b
Explanation for choice of comparators
Objectives
7
Specific objectives or hypotheses
Trial design
8
Description of trial design including type of trial 
(for example, parallel group, crossover, factorial, 
single group), allocation ratio, and framework (for 
example, superiority, equivalence, noninferiority, 
exploratory)
Methods: participants, interventions and outcomes
Study setting
9
Description of study settings (for example, 
community clinic, academic hospital) and list of 
countries where data will be collected. Reference 
to where list of study sites can be obtained
SPIRIT-AI 9 
Extension
Describe the onsite and offsite 
requirements needed to integrate the 
AI intervention into the trial setting.
Eligibility criteria
10
Inclusion and exclusion criteria for participants.  
If applicable, eligibility criteria for study  
centers and individuals who will perform 
the interventions (for example, surgeons, 
psychotherapists)
SPIRIT-AI 10 (i) 
Elaboration
State the inclusion and exclusion 
criteria at the level of participants.
SPIRIT-AI 10 (ii) 
Extension
State the inclusion and exclusion 
criteria at the level of the input data.
Continued
Nature Medicine | VOL 26 | September 2020 | 1351–1363 | www.nature.com/naturemedicine
1354

## Page 5 (Section: Table 1 SPIRIT-AI checklist.)

Consensus Statement
NATuRe MeDICIne
Section
Item
SPIRIT 2013 itema
SPIRIT-AI item
Addressed 
on page 
numberb
Interventions
11a
Interventions for each group with sufficient detail 
to allow replication, including how and when  
they will be administered
SPIRIT-AI 11a (i) 
Extension
State which version of the AI 
algorithm will be used.
SPIRIT-AI 11a (ii) 
Extension
Specify the procedure for acquiring 
and selecting the input data for the AI 
intervention.
SPIRIT-AI 11a 
(iii) Extension
Specify the procedure for assessing 
and handling poor-quality or 
unavailable input data.
SPIRIT-AI 11a 
(iv) Extension
Specify whether there is human–AI 
interaction in the handling of the 
input data, and what level of expertise 
is required for users.
SPIRIT-AI 11a (v) 
Extension
Specify the output of the AI 
intervention.
SPIRIT-AI 11a 
(vi) Extension
Explain the procedure for how the AI 
intervention’s output will contribute 
to decision-making or other elements 
of clinical practice.
11b
Criteria for discontinuing or modifying allocated 
interventions for a given trial participant (for 
example, drug dose change in response to harms, 
participant request, or improving/worsening 
disease)
11c
Strategies to improve adherence to intervention 
protocols, and any procedures for monitoring 
adherence (for example, drug tablet return, 
laboratory tests)
11d
Relevant concomitant care and interventions that 
are permitted or prohibited during the trial
Outcomes
12
Primary, secondary, and other outcomes, 
including the specific measurement variable 
(for example, systolic blood pressure), analysis 
metric (for example, change from baseline, final 
value, time to event), method of aggregation (for 
example, median, proportion), and time point 
for each outcome. Explanation of the clinical 
relevance of chosen efficacy and harm outcomes 
is strongly recommended
Participant 
timeline
13
Time schedule of enrollment, interventions 
(including any run-ins and washouts), assess­
ments, and visits for participants. A schematic 
diagram is highly recommended (Fig. 1)
Sample size
14
Estimated number of participants needed 
to achieve study objectives and how it was 
determined, including clinical and statistical 
assumptions supporting any sample size 
calculations
Recruitment
15
Strategies for achieving adequate participant 
enrollment to reach target sample size
Methods: assignment of interventions (for controlled trials)
Sequence 
generation
16a
Method of generating the allocation sequence 
(for example, computer-generated random 
numbers), and list of any factors for stratification. 
To reduce predictability of a random sequence, 
details of any planned restriction (for example, 
blocking) should be provided in a separate 
document that is unavailable to those who enroll 
participants or assign interventions
Continued
Table 1 | SPIRIT-AI checklist (Continued)
Nature Medicine | VOL 26 | September 2020 | 1351–1363 | www.nature.com/naturemedicine
1355

## Page 6 (Section: Table 1 SPIRIT-AI checklist.)

Consensus Statement
NATuRe MeDICIne
Section
Item
SPIRIT 2013 itema
SPIRIT-AI item
Addressed 
on page 
numberb
Allocation 
concealment 
mechanism
16b
Mechanism of implementing the allocation 
sequence (for example, central telephone; 
sequentially numbered, opaque, sealed 
envelopes), describing any steps to conceal the 
sequence until interventions are assigned
Implementation
16c
Who will generate the allocation sequence, 
who will enroll participants, and who will assign 
participants to interventions
Blinding 
(masking)
17a
Who will be blinded after assignment to interven­
tions (for example, trial participants, care 
providers, outcome assessors, data analysts),  
and how
17b
If blinded, circumstances under which unblinding 
is permissible, and procedure for revealing a 
participant’s allocated intervention during the trial
Methods: data collection, management and analysis
Data collection 
methods
18a
Plans for assessment and collection of outcome, 
baseline, and other trial data, including any 
related processes to promote data quality (for 
example, duplicate measurements, training of 
assessors) and a description of study instruments 
(for example, questionnaires, laboratory tests) 
along with their reliability and validity, if known. 
Reference to where data collection forms can be 
found, if not in the protocol
18b
Plans to promote participant retention and 
complete follow-up, including list of any outcome 
data to be collected for participants who 
discontinue or deviate from intervention protocols
Data management 19
Plans for data entry, coding, security, and storage, 
including any related processes to promote data 
quality (for example, double data entry; range 
checks for data values). Reference to where 
details of data management procedures can be 
found, if not in the protocol
Statistical 
methods
20a
Statistical methods for analyzing primary and 
secondary outcomes. Reference to where other 
details of the statistical analysis plan can be 
found, if not in the protocol
20b
Methods for any additional analyses (for example, 
subgroup and adjusted analyses)
20c
Definition of analysis population relating to protocol 
non-adherence (for example, as randomized 
analysis), and any statistical methods to handle 
missing data (for example, multiple imputation)
Methods: monitoring
Data monitoring
21a
Composition of data monitoring committee 
(DMC); summary of its role and reporting 
structure; statement of whether it is independent 
from the sponsor and competing interests; 
and reference to where further details about 
its charter can be found, if not in the protocol. 
Alternatively, an explanation of why a DMC is not 
needed
21b
Description of any interim analyses and stopping 
guidelines, including who will have access to 
these interim results and make the final decision 
to terminate the trial
Continued
Table 1 | SPIRIT-AI checklist (Continued)
Nature Medicine | VOL 26 | September 2020 | 1351–1363 | www.nature.com/naturemedicine
1356

## Page 7 (Section: Table 1 SPIRIT-AI checklist.)

Consensus Statement
NATuRe MeDICIne
Section
Item
SPIRIT 2013 itema
SPIRIT-AI item
Addressed 
on page 
numberb
Harms
22
Plans for collecting, assessing, reporting, and 
managing solicited and spontaneously reported 
adverse events and other unintended effects of 
trial interventions or trial conduct
SPIRIT-AI 22 
Extension
Specify any plans to identify and 
analyze performance errors. If there 
are no plans for this, justify why not.
Auditing
23
Frequency and procedures for auditing trial 
conduct, if any, and whether the process will be 
independent from investigators and the sponsor
Ethics and dissemination
Research ethics 
approval
24
Plans for seeking research ethics committee/
institutional review board (REC/IRB) approval
Protocol 
amendments
25
Plans for communicating important protocol 
modifications (for example, changes to eligibility 
criteria, outcomes, analyses) to relevant parties 
(for example, investigators, REC/IRBs, trial 
participants, trial registries, journals, regulators)
Consent or ascent
26a
Who will obtain informed consent or assent 
from potential trial participants or authorized 
surrogates, and how (see Item 32)
26b
Additional consent provisions for collection and 
use of participant data and biological specimens 
in ancillary studies, if applicable
Confidentiality
27
How personal information about potential and 
enrolled participants will be collected, shared, 
and maintained in order to protect confidentiality 
before, during, and after the trial
Declaration of 
interests
28
Financial and other competing interests for 
principal investigators for the overall trial and 
each study site
Access to data
29
Statement of who will have access to the final  
trial dataset, and disclosure of contractual 
agreements that limit such access for 
investigators
SPIRIT-AI 29 
Extension
State whether and how the AI 
intervention and/or its code can be 
accessed, including any restrictions to 
access or re-use.
Ancillary and 
post-trial care
30
Provisions, if any, for ancillary and post-trial care, 
and for compensation to those who suffer harm 
from trial participation
Dissemination 
policy
31a
Plans for investigators and sponsor to 
communicate trial results to participants, 
healthcare professionals, the public, and other 
relevant groups (for example, via publication, 
reporting in results databases, or other data 
sharing arrangements), including any publication 
restrictions
31b
Authorship eligibility guidelines and any intended 
use of professional writers
31c
Plans, if any, for granting public access to the  
full protocol, participant-level dataset, and 
statistical code
Appendices
Informed consent 
materials
32
Model consent form and other related 
documentation given to participants and 
authorized surrogates
Biological 
specimens
33
Plans for collection, laboratory evaluation, and 
storage of biological specimens for genetic or 
molecular analysis in the current trial and for 
future use in ancillary studies, if applicable
aIt is strongly recommended that this checklist be read in conjunction with the SPIRIT 2013 Explanation & Elaboration for important clarification on the items. bIndicates page numbers to be completed by 
authors during protocol development.
Table 1 | SPIRIT-AI checklist (Continued)
Nature Medicine | VOL 26 | September 2020 | 1351–1363 | www.nature.com/naturemedicine
1357

## Page 8 (Section: SPIRIT-AI 1 (ii) Elaboration: State the intended use of the AI intervention. )

Consensus Statement
NATuRe MeDICIne
being a form of AI/ML. Specific terminology relating to the model 
type and architecture should be detailed in the abstract.
SPIRIT-AI 1 (ii) Elaboration: State the intended use of the AI 
intervention. Explanation. The intended use of the AI intervention 
should be made clear in the protocol’s title and/or abstract. This 
should describe the purpose of the AI intervention and the disease 
context19,36. Some AI interventions may have multiple intended uses, 
or the intended use may evolve over time. Therefore, documenting 
this allows readers to understand the intended use of the algorithm 
at the time of the trial.
Introduction
SPIRIT-AI 6a (i) Extension: Explain the intended use of the AI 
intervention in the context of the clinical pathway, including its 
purpose and its intended users (for example, healthcare profes-
sionals, patients, public). Explanation. In order to clarify how the 
AI intervention will fit into a clinical pathway, a detailed description 
of its role should be included in the protocol background. AI inter-
ventions may be designed to interact with different users, includ-
ing healthcare professionals, patients and the public, and their 
roles can be wide-ranging (for example, the same AI interven-
tion could theoretically be replacing, augmenting or adjudicating 
components of clinical decision-making). Clarifying the intended 
use of the AI intervention and its intended user helps readers 
understand the purpose for which the AI intervention will be 
evaluated in the trial.
SPIRIT-AI 6a (ii) Extension: Describe any pre-existing evidence 
for the AI intervention. Explanation. Authors should describe in 
the protocol any pre-existing published evidence (with supporting 
references) or unpublished evidence relating to validation of the 
AI intervention or lack thereof. Consideration should be given to 
whether the evidence was for a use, setting and target population 
similar to that of the planned trial. This may include previous devel-
opment of the AI model, internal and external validations and any 
modifications made before the trial.
Participants, interventions and outcomes
SPIRIT-AI 9 Extension: Describe the onsite and offsite require-
ments needed to integrate the AI intervention into the trial set-
ting. Explanation. There are limitations to the generalizability of 
AI algorithms, one of which is when they are used outside of their 
development environment37,38. AI systems are dependent on their 
operational environment, and the protocol should provide details of 
the hardware and software requirements to allow technical integra-
tion of the AI intervention at each study site. For example, it should 
be stated if the AI intervention requires vendor-specific devices, 
if there is a need for specialized computing hardware at each site, 
or if the sites must support cloud integration, particularly if this 
is vendor specific. If any changes to the algorithm are required at 
each study site as part of the implementation procedure (such as 
fine-tuning the algorithm on local data), then this process should 
also be clearly described.
SPIRIT-AI 10 (i) Elaboration: State the inclusion and exclusion 
criteria at the level of participants. Explanation. The inclusion and 
exclusion criteria should be defined at the participant level as per 
usual practice in protocols of non-AI interventional trials. This is 
distinct from the inclusion and exclusion criteria made at the input 
data level, which are addressed in item 10 (ii).
SPIRIT-AI 10 (ii) Extension: State the inclusion and exclusion 
criteria at the level of the input data. Explanation. ‘Input data’ 
refers to the data required by the AI intervention to serve its pur-
pose (for example, for a breast cancer diagnostic system, the input 
data could be the unprocessed or vendor-specific post-processing 
mammography scan upon which a diagnosis is being made; for an 
early-warning system, the input data could be physiological mea-
surements or laboratory results from the electronic health record). 
The trial protocol should pre-specify if there are minimum require-
ments for the input data (such as image resolution, quality metrics 
or data format) that would determine pre-randomization eligibility. 
It should specify when, how and by whom this will be assessed. For 
example, if a participant met the eligibility criteria for lying flat for 
a CT scan as per item 10 (i), but the scan quality was compromised 
(for any given reason) to such a level that it is no longer fit for use by 
the AI system, this should be considered as an exclusion criterion at 
the input-data level. Note that where input data are acquired after 
randomization (addressed by SPIRIT-20c), any exclusion is consid-
ered to be from the analysis, not from enrollment (Fig. 1).
SPIRIT-AI 11a (i) Extension: State which version of the AI algo-
rithm will be used. Explanation. Similar to other forms of software 
as a medical device, AI systems are likely to undergo multiple itera-
tions and updates in their lifespan. The protocol should state which 
version of the AI system will be used in the clinical trial and whether 
this is the same version that was used in previous studies that have 
been used to justify the study rationale. If applicable, the protocol 
should describe what has changed between the relevant versions 
and the rationale for the changes. Where available, the protocol 
should include a regulatory marking reference, such as an unique 
device identifier, that requires a new identifier for updated versions 
of the device39.
SPIRIT-AI 11a (ii) Extension: Specify the procedure for 
acquiring and selecting the input data for the AI intervention. 
Explanation. The measured performance of any AI system may be 
critically dependent on the nature and quality of the input data40. 
The procedure for how input data will be handled, including data 
acquisition, selection and pre-processing before analysis by the AI 
system, should be provided. Completeness and transparency of this 
process is integral to feasibility assessment and to future replication 
of the intervention beyond the clinical trial. It will also help to iden-
tify whether input-data-handling procedures will be standardized 
across trial sites.
SPIRIT-AI 11a (iii) Extension: Specify the procedure for assess-
ing and handling poor-quality or unavailable input data. 
Explanation. As with SPIRIT-AI 10 (ii), ‘input data’ refers to the data 
required by the AI intervention to serve its purpose. As noted in 
item 10 (ii), the performance of AI systems may be compromised as 
a result of poor quality or missing input data41 (for example, exces-
sive movement artifact on an electrocardiogram). The study proto-
col should specify if and how poor quality or unavailable input data 
will be identified and handled. The protocol should also specify a 
minimum standard required for the input data and the procedure 
for when the minimum standard is not met (including the impact 
on, or any changes to, the participant care pathway).
Poor quality or unavailable data can also affect non-AI interven-
tions. For example, sub-optimal quality of a scan could affect a radi-
ologist’s ability to interpret it and make a diagnosis. It is therefore 
important that this information is reported equally for the control 
intervention, where relevant. If this minimum quality standard is 
different from the inclusion criteria for input data used to assess 
eligibility pre-randomization, this should be stated.
SPIRIT-AI 11a (iv) Extension: Specify whether there is human–
AI interaction in the handling of the input data, and what level 
of expertise is required for users. Explanation. A description of the 
human–AI interface and the requirements for successful interaction 
when input data are handled should be provided. Examples include 
Nature Medicine | VOL 26 | September 2020 | 1351–1363 | www.nature.com/naturemedicine
1358

## Page 9 (Section: SPIRIT-AI 11a (v) Extension: Specify the output of the AI intervention. )

Consensus Statement
NATuRe MeDICIne
clinician-led selection of regions of interest from a histology slide 
that is then interpreted by an AI diagnostic system42, or an endos-
copist’s selection of a colonoscopy video clips as input data for an 
algorithm designed to detect polyps21. A description of any planned 
user training and instructions for how users will handle the input 
data provides transparency and replicability of trial procedures. 
Poor clarity on the human–AI interface may lead to a lack of a stan-
dard approach and may carry ethical implications, particularly in 
the event of harm43,44. For example, it may become unclear whether 
an error case occurred due to human deviation from the instructed 
procedure, or if it was an error made by the AI system.
SPIRIT-AI 11a (v) Extension: Specify the output of the AI inter-
vention. Explanation. The output of the AI intervention should 
be clearly defined in the protocol. For example, an AI system may 
output a diagnostic classification or probability, a recommended 
action, an alarm alerting to an event, an instigated action in a 
closed-loop system (such as titration of drug infusions) or another 
output. The nature of the AI intervention’s output has direct impli-
cations on its usability and how it may lead to downstream actions 
and outcomes.
SPIRIT-AI 11a (vi) Extension: Explain the procedure for how 
the AI intervention’s outputs will contribute to decision-making 
or other elements of clinical practice. Explanation. Since health 
outcomes may also critically depend on how humans interact with 
the AI intervention, the trial protocol should explain how the out-
puts of the AI system are used to contribute to decision-making or 
other elements of clinical practice. This should include adequate 
description of downstream interventions that can impact outcomes. 
As with SPIRIT-AI 11a (iv), any effects of human–AI interaction 
on the outputs should be described in detail, including the level 
of expertise required to understand the outputs and any training 
and/or instructions provided for this purpose. For example, a skin 
cancer detection system that produces a percentage likelihood as 
output should be accompanied by an explanation of how this out-
put should be interpreted and acted upon by the user, specifying 
both the intended pathways (for example, skin lesion excision if the 
diagnosis is positive) and the thresholds for entry to these pathways 
(for example, skin lesion excision if the diagnosis is positive and 
the probability is >80%). The information produced by comparator 
interventions should be similarly described, alongside an explana-
tion of how such information was used to arrive at clinical decisions 
for patient management, where relevant.
Monitoring
SPIRIT-AI 22 Extension: Specify any plans to identify and ana-
lyze performance errors. If there are no plans for this, explain 
why not. Explanation. Reporting performance errors and failure 
case analysis is especially important for AI interventions. AI sys-
tems can make errors that may be hard to foresee but that, if allowed 
to be deployed at scale, could have catastrophic consequences45. 
Therefore, identifying cases of error and defining risk-mitigation 
strategies is important for informing when the intervention can be 
safely implemented, and for which populations. The protocol should 
specify whether there are any plans to analyze performance errors. 
If there are no plans for this, a justification should be included in 
the protocol.
Assessed for elibibility at participant level
Assessed for elibibility at input data level
Excluded (n = )
• Not meeting participant level inclusion criteria (n = )
• Declined to participate (n = )
• Other reasons (n = )
Excluded (n = )
• Not meeting participant level inclusion criteria (n = )
• Declined to participate (n = )
• Other reasons (n = )
Allocated to intervention (n = )
• Received allocated intervention (n = )
• Did not receive allocated intervention
  (give reasons) (n = )
• Missing or inadequate input data (n = )
Allocated to intervention (n = )
• Received allocated intervention (n = )
• Did not receive allocated intervention
  (give reasons) (n = )
• Missing or inadequate input data (n = )
Randomisation (n = )
10 (i)
10 (ii)
13
Enrollment
Allocation
Follow-up
Lost to follow-up (give reasons) (n = )
• Discontinued intervention
  (give reasons) (n = )
• Missing or inadequate input data (n = )
Lost to follow-up (give reasons) (n = )
• Discontinued intervention
  (give reasons) (n = )
• Missing or inadequate input data (n = )
13
Analysis
Lost to follow-up (give reasons) (n = )
• Discontinued intervention
  (give reasons) (n = )
Lost to follow-up (give reasons) (n = )
• Discontinued intervention
  (give reasons) (n = )
13
Fig. 1 | CONSORT 2010 flow diagram — adapted for AI clinical trials. SPIRIT-AI 10 (i): State the inclusion and exclusion criteria at the level of participants. 
SPIRIT-AI 10 (ii): State the inclusion and exclusion criteria at the level of the input data. SPIRIT 13 (core CONSORT item): Time schedule of enrollment, 
interventions (including any run-ins and washouts), assessments, and visits for participants. A schematic diagram is highly recommended.
Nature Medicine | VOL 26 | September 2020 | 1351–1363 | www.nature.com/naturemedicine
1359

## Page 10 (Section: Ethics and dissemination)

Consensus Statement
NATuRe MeDICIne
Ethics and dissemination
SPIRIT-AI 29 Extension: State whether and how the AI inter-
vention and/or its code can be accessed, including any restric-
tions to access or re-use. Explanation. The protocol should make 
clear whether and how the AI intervention and/or its code can be 
accessed or re-used. This should include details about the license 
and any restrictions to access.
Discussion
The SPIRIT-AI extension provides international consensus-based 
guidance on AI-specific information that should be reported 
in clinical trial protocols, alongside SPIRIT 2013 and other 
relevant SPIRIT extensions4,46. It comprises of 15 items: 3 elabo-
rations to the existing SPIRIT 2013 guidance in the context of 
AI trials, and 12 new extensions. The guidance does not aim to 
be prescriptive about the methodological approach to AI trials; 
instead, it aims to promote transparency in reporting the design and 
methods of a clinical trial to facilitate understanding, interpretation 
and peer review.
A number of extension items relate to the intervention (items 
11 (i)–11 (vi)), its setting (item 9) and intended role (item 6a (i)). 
Specific recommendations were made pertinent to AI systems 
related to algorithm version, input and output data, integration 
into trial settings, expertise of the users and protocol for act-
ing upon the AI system’s recommendations. It was agreed that 
these details are critical for independent evaluation of the study 
protocol. Journal editors reported that despite the importance 
of these items, they are currently often missing from trial proto-
cols and reports at the time of submission for publication, which 
provides further weight to their inclusion as specifically listed 
extension items.
A recurrent focus of the Delphi comments and consensus group 
discussion was the safety of AI systems. This is in recognition that 
these systems, unlike other health interventions, can unpredictably 
yield errors that are not easily detectable or explainable by human 
judgement. For example, changes to medical imaging that are invis-
ible, or appear random, to the human eye may change the likeli-
hood of the resultant diagnostic output entirely47,48. The concern 
is that given the theoretical ease with which AI systems could be 
deployed at scale, any unintended harmful consequences could 
be catastrophic. Two extension items were added to address this. 
SPIRIT-AI item 6a (ii) requires specification of the prior level of 
evidence for validation of the AI intervention. SPIRIT-AI item 22 
requires specification of any plans to analyze performance errors, to 
emphasize the importance of anticipating systematic errors made by 
the algorithm and their consequences.
One topic that was raised in the Delphi survey responses and 
consensus meeting that is not included in the final guidelines is 
‘continuously evolving’ AI systems (also known as ‘continuously 
adapting’ or ‘continuously learning’ AI systems). These are AI 
systems with the ability to continuously train on new data, which 
may cause changes in performance over time. The group noted 
that, while of interest, this field is relatively early in its develop-
ment without tangible examples in healthcare applications, and 
that it would not be appropriate for it to be addressed by SPIRIT-AI 
at this stage49. This topic will be monitored and revisited in future 
iterations of SPIRIT-AI. It is worth noting that incremental software 
changes, whether continuous or iterative, intentional or uninten-
tional, could have serious consequences on safety performance after 
deployment. It is therefore of vital importance that such changes are 
documented and identified by software version and that a robust 
post-deployment surveillance plan is in place.
This study is set in the current context of AI in health; therefore, 
several limitations should be noted. First, at the time of SPIRIT-AI 
development, there were only seven published trials and no pub-
lished trial protocols in the field of AI for healthcare. Thus, the 
discussion and decisions made during the development of 
SPIRIT-AI are not always supported by existing real-world examples. 
This arises from our stated aim of addressing the issues of poor pro-
tocol development in this field as early as possible, recognizing the 
strong drivers in the field and the specific challenges of study design 
and reporting for AI. As the science and study of AI evolves, we 
welcome collaboration with investigators to co-evolve these report-
ing standards to ensure their continued relevance. Second, the lit-
erature search of AI randomized controlled trials used terminology 
such as ‘artificial intelligence’, ‘machine learning’ and ‘deep learning’, 
but not terms such as ‘clinical decision support systems’ and ‘expert 
systems’, which were more commonly used in the 1990s for techno­
logies underpinned by AI systems and share risks similar to those of 
recent examples50. It is likely that such systems, if published today, 
would be indexed under ‘artificial intelligence’ or ‘machine learn-
ing’; however, clinical decision support systems were not actively 
discussed during this consensus process. Third, the initial candi-
date items list was generated by a relatively small group of experts 
consisting of Steering Group members and additional international 
experts. However, additional items from the wider Delphi group 
were taken forward for consideration by the consensus group, and 
no new items were suggested during the consensus meeting or 
post-meeting evaluation.
As with the SPIRIT statement, the SPIRIT-AI extension is 
intended as a minimum reporting guidance, and there are addi-
tional AI-specific considerations for trial protocols that may war-
rant consideration (Supplementary Table 2). This extension is 
aimed particularly at investigators planning or conducting clinical 
trials; however, it may also serve as useful guidance for develop-
ers of AI interventions in earlier validation stages of an AI system. 
Investigators seeking to report studies developing and validating the 
diagnostic and predictive properties of AI models should refer to 
TRIPOD-ML (Transparent Reporting of a Multivariable Prediction 
Model for Individual Prognosis or Diagnosis–Machine Learning)24 
and STARD-AI (Standards For Reporting Diagnostic Accuracy 
Studies–Artificial Intelligence)51, both of which are currently under 
development. Other potentially relevant guidelines, which are 
agnostic to study design, are registered with the EQUATOR net-
work52. The SPIRIT-AI extension is expected to encourage careful 
early planning of AI interventions for clinical trials and this, in con-
junction with CONSORT-AI, should help to improve the quality of 
trials for AI interventions.
There is widespread recognition that AI is a rapidly evolving 
field, and there will be the need to update SPIRIT-AI as the technol-
ogy, and newer applications for it, develop. Currently, most appli-
cations of AI/ML involve disease detection, diagnosis and triage, 
and this is likely to have influenced the nature and prioritization 
of items within SPIRIT-AI. As wider applications that utilize ‘AI as 
therapy’ emerge, it will be important to re-evaluate SPIRIT-AI in 
the light of such studies. Additionally, advances in computational 
techniques and the ability to integrate them into clinical workflows 
will bring new opportunities for innovation that benefits patients. 
However, they may be accompanied by new challenges of study 
design and reporting to ensure transparency, minimize potential 
biases and ensure that the findings of such a study are trustworthy 
and the extent to which they may be generalizable. The SPIRIT-AI 
and CONSORT-AI Steering Group will continue to monitor the 
need for updates.
Data availability
Data requests should be made to the corresponding author and 
release will be subject to consideration by the SPIRIT-AI and 
CONSORT-AI Steering Group.
Received: 24 April 2020; Accepted: 23 July 2020;  
Published online: 9 September 2020
Nature Medicine | VOL 26 | September 2020 | 1351–1363 | www.nature.com/naturemedicine
1360

## Page 11 (Section: Acknowledgements)

Consensus Statement
NATuRe MeDICIne
References
	1.	 Chan, A.-W. et al. SPIRIT 2013 statement: defining standard protocol items 
for clinical trials. Ann. Intern. Med. 158, 200–207 (2013).
	2.	 Chan, A.-W. et al. SPIRIT 2013 explanation and elaboration: guidance for 
protocols of clinical trials. Br. Med. J. 346, e7586 (2013).
	3.	 Sarkis-Onofre, R. et al. Use of guidelines to improve the quality and 
transparency of reporting oral health research. J. Dent. 43, 397–404 (2015).
	4.	 Calvert, M. et al. Guidelines for inclusion of patient-reported outcomes in 
clinical trial protocols: The SPIRIT-PRO Extension. J. Am. Med. Assoc. 319, 
483–494 (2018).
	5.	 Dai, L. et al. Standard protocol items for clinical trials with traditional 
Chinese medicine 2018: recommendations, explanation and elaboration 
(SPIRIT-TCM Extension 2018). Chin. J. Integr. Med. 25, 71–79 (2019).
	6.	 He, J. et al. The practical implementation of artificial intelligence technologies 
in medicine. Nat. Med. 25, 30–36 (2019).
	7.	 McKinney, S. M. et al. International evaluation of an AI system for breast 
cancer screening. Nature 577, 89–94 (2020).
	8.	 Abràmoff, M. D. et al. Improved automated detection of diabetic retinopathy 
on a publicly available dataset through integration of deep learning.  
Invest. Ophthalmol. Vis. Sci. 57, 5200–5206 (2016).
	9.	 De Fauw, J. et al. Clinically applicable deep learning for diagnosis and referral 
in retinal disease. Nat. Med. 24, 1342–1350 (2018).
	10.	Esteva, A. et al. Dermatologist-level classification of skin cancer with deep 
neural networks. Nature 542, 115–118 (2017).
	11.	Rajpurkar, P. et al. Deep learning for chest radiograph diagnosis: A retrospective 
comparison of the CheXNeXt algorithm to practicing radiologists. PLoS Med. 
15, e1002686 (2018).
	12.	Fleuren, L. M. et al. Machine learning for the prediction of sepsis: a systematic 
review and meta-analysis of diagnostic test accuracy. Intensive Care Med. 46, 
383–400 (2020).
	13.	Yim, J. et al. Predicting conversion to wet age-related macular degeneration 
using deep learning. Nat. Med. 26, 892–899 (2020).
	14.	Kim, H., Goo, J. M., Lee, K. H., Kim, Y. T. & Park, C. M. Preoperative 
CT-based deep learning model for predicting disease-free survival in patients 
with lung adenocarcinomas. Radiology 296, 216–224 (2020).
	15.	Wang, P. et al. Real-time automatic detection system increases colonoscopic 
polyp and adenoma detection rates: a prospective randomised controlled 
study. Gut 68, 1813–1819 (2019).
	16.	Tyler, N. S. et al. An artificial intelligence decision support system for the 
management of type 1 diabetes. Nat. Metab. 2, 612–619 (2020).
	17.	Liu, X. et al. A comparison of deep learning performance against health-care 
professionals in detecting diseases from medical imaging: a systematic review 
and meta-analysis. Lancet Digit. Health 1, e271–e297 (2019).
	18.	Wu, L. et al. Randomised controlled trial of WISENSE, a real-time quality 
improving system for monitoring blind spots during 
esophagogastroduodenoscopy. Gut 68, 2161–2169 (2019).
	19.	Wijnberge, M. et al. Effect of a machine learning-derived early warning 
system for intraoperative hypotension vs standard care on depth and duration 
of intraoperative hypotension during elective noncardiac surgery: The HYPE 
randomized clinical trial. J. Am. Med. Assoc. 323, 1052–1060 (2020).
	20.	Gong, D. et al. Detection of colorectal adenomas with a real-time 
computer-aided system (ENDOANGEL): a randomised controlled study. 
Lancet Gastroenterol. Hepatol. 5, 352–361 (2020).
	21.	Wang, P. et al. Effect of a deep-learning computer-aided detection system on 
adenoma detection during colonoscopy (CADe-DB trial): a double-blind 
randomised study. Lancet Gastroenterol. Hepatol. 5, 343–351 (2020).
	22.	Lin, H. et al. Diagnostic efficacy and therapeutic decision-making capacity  
of an artificial intelligence platform for childhood cataracts in eye clinics:  
a multicentre randomized controlled trial. EClinicalMedicine 9,  
52–59 (2019).
	23.	Su, J.-R. et al. Impact of a real-time automatic quality control system  
on colorectal polyp and adenoma detection: a prospective randomized 
controlled study (with videos). Gastrointest. Endosc. 91, 415–424.e4 (2020).
	24.	Collins, G. S. & Moons, K. G. M. Reporting of artificial intelligence 
prediction models. Lancet 393, 1577–1579 (2019).
	25.	Gregory, J., Welliver, S. & Chong, J. Top 10 reviewer critiques of radiology 
artificial intelligence (AI) articles: qualitative thematic analysis of reviewer 
critiques of machine learning/deep learning manuscripts submitted to JMRI. 
J. Magn. Reson. Imaging 52, 248–254 (2020).
	26.	Nagendran, M. et al. Artificial intelligence versus clinicians: systematic  
review of design, reporting standards, and claims of deep learning studies.  
Br. Med. J. 368, m689 (2020).
	27.	CONSORT-AI and SPIRIT-AI Steering Group. Reporting guidelines for 
clinical trials evaluating artificial intelligence interventions are needed.  
Nat. Med. 25, 1467–1468 (2019).
	28.	Liu, X., Faes, L., Calvert, M. J. & Denniston, A. K. Extension of the CONSORT 
and SPIRIT statements. Lancet 394, 1225 (2019).
	29.	Moher, D., Schulz, K. F., Simera, I. & Altman, D. G. Guidance for developers 
of health research reporting guidelines. PLoS Med. 7, e1000217 (2010).
	30.	Caballero-Ruiz, E. et al. A web-based clinical decision support system for 
gestational diabetes: Automatic diet prescription and detection of insulin 
needs. Int. J. Med. Inform. 102, 35–49 (2017).
	31.	Kim, T. W. B., Gay, N., Khemka, A. & Garino, J. Internet-based exercise 
therapy using algorithms for conservative treatment of anterior knee pain:  
a pragmatic randomized controlled trial. JMIR Rehabil. Assist. Technol. 3,  
e12 (2016).
	32.	Labovitz, D. L., Shafner, L., Reyes Gil, M., Virmani, D. & Hanina, A. Using 
artificial intelligence to reduce the risk of nonadherence in patients on 
anticoagulation therapy. Stroke 48, 1416–1419 (2017).
	33.	Nicolae, A. et al. Evaluation of a machine-learning algorithm for treatment 
planning in prostate low-dose-rate brachytherapy. Int. J. Radiat. Oncol. Biol. 
Phys. 97, 822–829 (2017).
	34.	Voss, C. et al. Effect of wearable digital intervention for improving 
socialization in children with autism spectrum disorder: a randomized 
clinical trial. JAMA Pediatr. 173, 446–454 (2019).
	35.	Mendes-Soares, H. et al. Assessment of a personalized approach to predicting 
postprandial glycemic responses to food among individuals without diabetes. 
JAMA Netw. Open 2, e188102 (2019).
	36.	Choi, K. J. et al. Development and validation of a deep learning system for 
staging liver fibrosis by using contrast agent-enhanced CT images in the liver. 
Radiology 289, 688–697 (2018).
	37.	Kelly, C. J., Karthikesalingam, A., Suleyman, M., Corrado, G. & King, D. Key 
challenges for delivering clinical impact with artificial intelligence. BMC Med. 
17, 195 (2019).
	38.	Pooch, E. H. P., Ballester, P. L. & Barros, R. C. Can we trust deep learning 
models diagnosis? The impact of domain shift in chest radiograph 
classification. arXiv http://arxiv.org/abs/1909.01940 (2019)
	39.	International Medical Device Regulators Forum. Unique device identification 
system (UDI System) application guide. http://www.imdrf.org/documents/
documents.asp (2019).
	40.	Sabottke, C. F. & Spieler, B. M. The effect of image resolution on deep 
learning in radiography. Radiology: Artif. Intell. 2, e190015 (2020).
	41.	Heaven, D. Why deep-learning AIs are so easy to fool. Nature 574,  
163–166 (2019).
	42.	Kiani, A. et al. Impact of a deep learning assistant on the histopathologic 
classification of liver cancer. NPJ Digit. Med. 3, 23 (2020).
	43.	Wiens, J. et al. Do no harm: a roadmap for responsible machine learning for 
health care. Nat. Med. 25, 1337–1340 (2019).
	44.	Habli, I., Lawton, T. & Porter, Z. Artificial intelligence in health care: 
accountability and safety. Bull. World Health Organ. https://www.who.int/
bulletin/online_first/BLT.19.237487.pdf (2020).
	45.	Oakden-Rayner, L., Dunnmon, J., Carneiro, G. & Ré, C. Hidden stratification 
causes clinically meaningful failures in machine learning for medical imaging. 
arXiv http://arxiv.org/abs/1909.12475 (2019).
	46.	SPIRIT. Publications & Downloads. https://www.spirit-statement.org/
publications-downloads/ (accessed 24 March 2020).
	47.	Zech, J. R. et al. Confounding variables can degrade generalization 
performance of radiological deep learning models. arXiv http://arxiv.org/
abs/1807.00431 (2018).
	48.	Finlayson, S. G. et al. Adversarial attacks on medical machine learning. 
Science 363, 1287–1289 (2019).
	49.	Lee, C. S. & Lee, A. Y. Clinical applications of continual learning machine 
learning. Lancet Digit. Health 2, e279–e281 (2020).
	50.	Sutton, R. T. et al. An overview of clinical decision support systems: benefits, 
risks, and strategies for success. NPJ Digit. Med. 3, 17 (2020).
	51.	Sounderajah, V. et al. Developing specific reporting guidelines for diagnostic 
accuracy studies assessing AI interventions: The STARD-AI Steering Group. 
Nat. Med. 26, 807–808 (2020).
	52.	Talmon, J. et al. STARE-HI–Statement on reporting of evaluation studies in 
Health Informatics. Int. J. Med. Inform. 78, 1–9 (2009).
Acknowledgements
We thank the participants who were involved in the Delphi study and Pilot study 
(Supplementary Note); E. Marston (University of Birmingham, UK) for strategic 
support; and C. Radovanovic (University Hospitals Birmingham NHS Foundation Trust, 
UK) and A. Walker (University of Birmingham, UK) for administrative support. The 
views expressed in this publication are those of the authors, Delphi participants and 
stakeholder participants and may not represent the views of the broader stakeholder 
group or host institution. This work was funded by a Wellcome Trust Institutional 
Strategic Support Fund: Digital Health Pilot Grant Research England (part of UK 
Research and Innovation), Health Data Research UK and the Alan Turing Institute. 
The study was sponsored by the University of Birmingham, UK. The study funders and 
sponsors had no role in the design and conduct of the study; collection, management, 
analysis and interpretation of the data; preparation, review or approval of the manuscript; 
or decision to submit the manuscript for publication. M.J.C. is a National Institute for 
Health Research (NIHR) Senior Investigator and receives funding from the National 
Institute for Health Research (NIHR) Birmingham Biomedical Research Centre; the 
NIHR Surgical Reconstruction and Microbiology Research Centre and NIHR ARC West 
Nature Medicine | VOL 26 | September 2020 | 1351–1363 | www.nature.com/naturemedicine
1361

## Page 12 (Section: Acknowledgements)

Consensus Statement
NATuRe MeDICIne
SPIRIT-AI and CONSORT-AI Steering Group
Alastair K. Denniston1,3,4,5,6,9, An-Wen Chan8, 
Ara Darzi13,14, Christopher Holmes15,16, Christopher Yau15,17, David Moher18,19, Hutan Ashrafian13,14, 
Jonathan J. Deeks2,10, Lavinia Ferrante di Ruffano2, Livia Faes20, Melanie J. Calvert1,2,3,6,10,11,12, 
Pearse A. Keane1, Samantha Cruz Rivera1,2,3, Sebastian J. Vollmer15,21 and Xiaoxuan Liu3,4,5,6,7
13Patient Safety Translational Research Centre, Imperial College London, London, UK. 14Institute of Global Health Innovation, Imperial College London, 
London, UK. 15Alan Turing Institute, London, UK. 16Department of Statistics and Nuffield Department of Medicine, University of Oxford, Oxford, UK. 
17University of Manchester, Manchester, UK. 18Centre for Journalology, Clinical Epidemiology Program, Ottawa Hospital Research Institute, Ottawa, 
Canada. 19School of Epidemiology and Public Health, Faculty of Medicine, University of Ottawa, Ottawa, Canada. 20Department of Ophthalmology, 
Cantonal Hospital Lucerne, Lucerne, Switzerland. 21University of Warwick, Coventry, UK. 
SPIRIT-AI and CONSORT-AI Consensus Group
Aaron Y. Lee22, Adrian Jonas23, Andre Esteva24, Andrew L. Beam25, An-Wen Chan8, 
Maria Beatrice Panico26, Cecilia S. Lee22, Charlotte Haug27, Christophe J. Kelly28, Christopher Yau15,17, 
Cynthia Mulrow29, Cyrus Espinoza30, John Fletcher31, David Moher18,19, Dina Paltoo32, Elaine Manna33, 
Gary Price34, Gary S. Collins35, Hugh Harvey36, James Matcham37, Joao Monteiro38, 
M. Khair ElZarrad39, Lavinia Ferrante di Ruffano2, Luke Oakden-Rayner40, Melanie J. Calvert1,2,3,6,10,11,12, 
Melissa McCradden41, Pearse A. Keane1, Richard Savage42, Robert Golub43, Rupa Sarkar44 and 
Samuel Rowley45
22Department of Ophthalmology, University of Washington, Seattle, WA, USA. 23The National Institute for Health and Care Excellence, London, UK. 
24Salesforce Research, San Francisco, CA, USA. 25Harvard T.H. Chan School of Public Health, Boston, MA, USA. 26Medicines and Healthcare products 
Midlands at the University of Birmingham and University Hospitals Birmingham NHS 
Foundation Trust; Health Data Research UK; Innovate UK (part of UK Research and 
Innovation); the Health Foundation; Macmillan Cancer Support; and UCB Pharma.  
A.D. and J.D. are also NIHR Senior Investigators. The views expressed in this article 
are those of the author(s) and not necessarily those of the NIHR, or the Department 
of Health and Social Care. S.J.V. receives funding from the Engineering and Physical 
Sciences Research Council, UK Research and Innovation (UKRI), Accenture, Warwick 
Impact Fund, Health Data Research UK and European Regional Development Fund. 
S.R. is an employee of the Medical Research Council (UKRI). D.M. is supported by a 
University of Ottawa Research Chair. A.B. is supported by a National Institutes of Health 
(NIH) award (7K01HL141771-02). M.K.E. is supported by the U.S. Food and Drug 
Administration (FDA), and D.P. is supported in part by the Office of the Director at 
the National Library of Medicine (NLM), US National Institutes of Health (NIH). This 
article may not be consistent with NIH and/or FDA’s views or policies. It reflects only the 
views and opinions of the authors.
Author contributions
Concept and design, and acquisition, analysis and interpretation of data, all authors; 
drafting of the manuscript, X.L., S.C.R., A.W.C., M.J.C. and A.K.D.; obtaining of funding, 
A.K.D., M.J.C., C.Y. and C.H. The SPIRIT-AI and CONSORT-AI Working Group 
consists of two groups that have been key in the development of the guidelines: the 
SPIRIT-AI and CONSORT-AI Steering Group, which was responsible for overseeing  
the consensus process and guidelines development methodology (Alastair K. Denniston, 
An-Wen Chan, Ara Darzi, Christopher Holmes, Christopher Yau, David Moher,  
Hutan Ashrafian, Jonathan J. Deeks, Lavinia Ferrante di Ruffano, Livia Faes, Melanie J. 
Calvert, Pearse A. Keane, Samantha Cruz Rivera, Sebastian J. Vollmer and Xiaoxuan Liu); 
and the SPIRIT-AI and CONSORT-AI Consensus Group, which was responsible  
for reaching consensus on the content and wording of the items within the checklists 
(Aaron Y. Lee, Adrian Jonas, Andre Esteva, Andrew L. Beam, An-Wen Chan, Maria 
Beatrice Panico, Cecilia S. Lee, Charlotte Haug, Christopher J. Kelly, Christopher Yau, 
Cynthia Mulrow, Cyrus Espinoza, David Moher, Dina Paltoo, Elaine Manna, Gary Price, 
Gary S Collins, Hugh Harvey, James Matcham, Joao Monteiro, John Fletcher, M. Khair 
ElZarrad, Lavinia Ferrante Di Ruffano, Luke Oakden-Rayner, Melanie J. Calvert,  
Melissa McCradden, Pearse A. Keane, Richard Savage, Robert Golub, Rupa Sarkar and 
Samuel Rowley).
Competing interests
M.J.C. has received personal fees from Astellas, Takeda, Merck, Daiichi Sankyo, Glaukos, 
GlaxoSmithKline and the Patient-Centered Outcomes Research Institute (PCORI) 
outside the submitted work. P.A.K. is a consultant for DeepMind Technologies, Roche, 
Novartis and Apellis, and has received speaker fees or travel support from Bayer, 
Allergan, Topcon and Heidelberg Engineering. C.J.K. is an employee of Google and 
owns Alphabet stock. A.E. is an employee of Salesforce CRM. R.S. is an employee of 
Pinpoint Science. J. Matcham was an employee of AstraZeneca at the time of this study. 
J. Monteiro is Chief Editor of the journal Nature Medicine; he has recused himself from 
any aspect of decision-making on this manuscript and played no part in the assignment 
of this manuscript to in-house editors or peer reviewers, and was also separated and 
blinded from the editorial process from submission inception to decision.
Additional information
Supplementary information is available for this paper at https://doi.org/10.1038/
s41591-020-1037-7.
Correspondence and requests for materials should be addressed to A.K.D.
Peer review information Javier Carmona was the primary editor on this article, and 
managed its editorial process and peer review in collaboration with the rest of the 
editorial team.
Reprints and permissions information is available at www.nature.com/reprints.
Open Access This article is licensed under a Creative Commons 
Attribution 4.0 International License, which permits use, sharing, adap-
tation, distribution and reproduction in any medium or format, as long 
as you give appropriate credit to the original author(s) and the source, provide a link to 
the Creative Commons license, and indicate if changes were made. The images or other 
third party material in this article are included in the article’s Creative Commons license, 
unless indicated otherwise in a credit line to the material. If material is not included in 
the article’s Creative Commons license and your intended use is not permitted by statu-
tory regulation or exceeds the permitted use, you will need to obtain permission directly 
from the copyright holder. To view a copy of this license, visit http://creativecommons.
org/licenses/by/4.0/.
© The Author(s) 2020
Nature Medicine | VOL 26 | September 2020 | 1351–1363 | www.nature.com/naturemedicine
1362

## Page 13 (Section: Acknowledgements)

Consensus Statement
NATuRe MeDICIne
Regulatory Agency, London, UK. 27New England Journal of Medicine, Waltham, MA, USA. 28Google Health, London, UK. 29Annals of Internal Medicine, 
Philadelphia, PA, USA. 30Patient Partner, Birmingham, UK. 31British Medical Journal, London, UK. 32National Institutes of Health, Bethesda, MD, USA. 
33Patient Partner, London, UK. 34Patient Partner, Centre for Patient Reported Outcome Research, Institute of Applied Health Research, University of 
Birmingham, Birmingham, UK. 35Centre for Statistics in Medicine, University of Oxford, Oxford, UK. 36Hardian Health, London, UK. 37AstraZeneca, 
Cambridge, UK. 38Nature Research, New York, NY, USA. 39Food and Drug Administration, Silver Spring, MD, USA. 40Australian Institute for Machine 
Learning, North Terrace, Adelaide, Australia. 41The Hospital for Sick Children, Toronto, Canada. 42PinPoint Data Science, Leeds, UK. 43Journal of the 
American Medical Association, Chicago, IL, USA. 44The Lancet Group, London, UK. 45Medical Research Council, London, UK. 
Nature Medicine | VOL 26 | September 2020 | 1351–1363 | www.nature.com/naturemedicine
1363


---

# Industry-scale application and evaluation of deep learning for drug target prediction

- **Authors:** Noé Sturm, Andreas Mayr, Thanh Le Van, Vladimir Chupakhin, Hugo Ceulemans, Joerg Wegner, Jose-Felipe Golib-Dzib, Nina Jeliazkova, Yves Vandriessche, Stanislav Böhm, Vojtech Cima, Jan Martinovic, Nigel Greene, Tom Vander Aa, Thomas J Ashby, Sepp Hochreiter, Ola Engkvist, Günter Klambauer, Hongming Chen
- **Issuer:** Journal of cheminformatics
- **Type:** Scientific article
- **Published:** 2020-04-19
- **Language:** en
- **DOI:** 10.1186/s13321-020-00428-5
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33430964/
- **Licence:** CC-BY

## Section: Abstract

AbstractArtificial intelligence (AI) is undergoing a revolution thanks to the breakthroughs of machine learning algorithms in computer vision, speech recognition, natural language processing and generative modelling. Recent works on publicly available pharmaceutical data showed that AI methods are highly promising for Drug Target prediction. However, the quality of public data might be different than that of industry data due to different labs reporting measurements, different measurement techniques, fewer samples and less diverse and specialized assays. As part of a European funded project (ExCAPE), that brought together expertise from pharmaceutical industry, machine learning, and high-performance computing, we investigated how well machine learning models obtained from public data can be transferred to internal pharmaceutical industry data. Our results show that machine learning models trained on public data can indeed maintain their predictive power to a large degree when applied to industry data. Moreover, we observed that deep learning derived machine learning models outperformed comparable models, which were trained by other machine learning algorithms, when applied to internal pharmaceutical company datasets. To our knowledge, this is the first large-scale study evaluating the potential of machine learning and especially deep learning directly at the level of industry-scale settings and moreover investigating the transferability of publicly learned target prediction models towards industrial bioactivity prediction pipelines.Keywords: QSAR, Deep learning, Machine learning, Structure-based virtual screening, Cheminformatics, Big data, ChEMBL, PubChem, Prospective evaluation, Retrospective evaluation

## Section: Introduction

Artificial intelligence (AI) is evolving fast through algorithmic advances in various application fields, including drug discovery [1–3]. Quantitative structure activity relationship (QSAR) studies constitute one of the key elements of early drug development. The aim is to quantify the biological activities of small molecules as a function of their molecular structures. To this end, typical drug development programs adopt a trial and error strategy in which vast numbers of molecules are tested to measure their biological activity in the presence of a target protein. Over the years, large quantities of QSAR data have been generated. The ChEMBL and PubChem databases [4, 5] are regarded as the major resources for publicly available small molecule bioactivity data, containing more than 15 and 239 million bioactivity data points, respectively. Despite the wealth of data, these databases remain difficult to use due to the heterogeneity of their data. It is important to mention that much of the existing QSAR data remains in-house in pharmaceutical companies.

There has been a long tradition in using such datasets to build predictive QSAR classification and regression models with the help of machine learning algorithms [6]. QSAR models typically either heavily rely on the molecular similarity principle assuming that molecules with similar structures have similar biological activities [7], or they are more feature-based, as e.g. the ChEMBL target prediction tool [8–10]. Based on this assumption, machine learning algorithms fit functions that are capable of mapping small molecule structures to their biological activities, which in turn allows to make predictions on new molecules and to prioritize them. In the most basic form, QSAR models are built on a per-project basis with the objective of predicting the activity of new molecules for one single target protein, thus can also be considered as target prediction methods. Therefore, the modelling task consists of compiling one dataset of molecules with activities on one protein and of utilizing one or several so-called single-task algorithms to build predictive models. Some of the most popular methods are random forest [11] (RF) and support vector machine [12] (SVM) models. A comprehensive overview and review of drug target prediction methods is given by Sydow et al. [13].

With the rise of AI in the era of cheap computation, many novel machine learning algorithms have been applied to various application domains such as online customer recommendation [14], speech recognition [15], computer vision [16–19], natural language processing [20] and generative modelling [21]. Drug target prediction also benefits from these newly developed deep learning techniques [22]. One attractive aspect of deep learning in drug discovery is its versatility. Deep learning algorithms offer the possibility of creating multitask models which particularly suit drug target prediction for a panel of target proteins [23–26]. This technique has been notably successful in two machine learning challenges. Dahl et al. (2014) [27] won the Merck Kaggle challenge by applying a multitask fully connected deep neural network and Mayr et al. [28] won the Tox21 challenge by using a similar approach. However, despite the recent successes of deep learning in competitions, and several studies claiming the superiority of multitask deep learning, there is still the question, how well deep learning models perform in industrial settings with much more data compared to competitions and different data distributions compared to publicly available databases and benchmark datasets. We considered this to be the main research question here and in order to gain insights, we first trained predictive machine learning models using diverse different algorithms on public data and then transferred these models to industrial data and analyzed the performances of these models there.

Typically, the dataset used to train a target prediction model represents its underlying chemical applicability domain. It is therefore highly desirable to use a large-scale public dataset for the study following the idea that “the more data the better”. Fortunately, a few large-scale datasets [29–32] have already been created and used to benchmark target prediction algorithms. Mayr et al. [29] created a large-scale benchmark dataset for drug discovery (the LSC dataset), which they provided to the community for model development and method comparisons. The LSC dataset is based on data from ChEMBL and considered each individual assay as a separate prediction task, which should allow a fair method comparison for predicting experimental measurements. Another larger dataset, that follows similar goals as the LSC dataset, is the ExCAPE-DB dataset [30], also created as part of the ExCAPE project. The data of ExCAPE-DB contains information extracted from both the ChEMBL and the PubChem database, whereas the LSC dataset is based purely on ChEMBL. Another main difference of ExCAPE-DB to the LSC dataset is that in ExCAPE-DB different assays were merged together if they were annotated to measure the effect on the same target. This merging of different assays to the same targets may lead to increased noise (see e.g. [33]), but it allows to directly transfer models learned on public data to company internal pharma data by means of a commonly shared target. For the LSC dataset on the other hand, transferring the model would require an accurate mapping from public to private assays, which would demand overwhelming manual inspection, if it would be possible at all. A further aspect of merging different assays, is, that more training data is available per target and that some measurement noise might be averaged out.

For this study, we decided to use ExCAPE-DB, as it is one of the largest open source benchmark target prediction datasets, and allows to evaluate target prediction models trained on public data on their ability to predict industrial QSAR and thus their potential usability in industrial drug discovery projects. To this end, we evaluate the classification performance of the learned models on two industry-size datasets stemming from two different pharmaceutical companies. To be able to draw comparisons of the obtained prediction performances between public and private databases, we also compute prediction performances on ExCAPE-DB itself.

Regarding the machine learning algorithms, we decided to compare deep learning with gradient boosting, which serves as a representative of ensemble learning based approaches such as RFs. We also compare to a Bayesian matrix factorization approach, that considers the problem of target prediction more from the point of view of a regression problem. We do not include a similarity-based approach such as SVMs or k-nearest-neighbors, since this would have resulted in a high additional computational effort due to the large numbers of compounds of many targets being in the range of tens and hundreds of thousands. It should be noted, that ensemble-based approaches as well as the matrix factorization approach are established machine learning methods in pharmaceutical industry [34, 35].

## Section: Methods

Compound distributions across the targets for the AstraZeneca and the Janssen dataset, respectively. In the lower panel, the y-axis shows the number of compounds for targets represented by the x-axis, where the targets are sorted according to the number of compounds. The horizontal dashed line represents the maximum number of compounds per target observed in the datasets. In the upper panel, a point represents the activity ratio of a target; targets are sorted the same way as in the lower panel. The curve in the upper panel is a smooth average

Contingency tables ExCAPE-ML vs. company datasets

Prospective and Retrospective Model Evaluation with three folds (A, B, C). White and colored circles in the Figure represent clusters of compounds, where the size of the circles indicates the cluster sizes (nr. of compounds in the clusters). Colors indicate folds, to which clusters are assigned to, where white circles indicate folds, which are not used for building or evaluating a particular model. In stage 1, the inner loop, one of the three folds serves as the training set, one serves as a test set and the third one is kept aside as a test set for Stage 2a, the outer loop. The respective inner folds used in Stage 1 are merged to training sets for Stage 2a, the retrospective model testing stage. All folds together are merged to the training set for obtaining full-scale models in Stage 2b, the prospective model testing stage. Stage 1 is used for hyperparameter selection of Stage 2a and hyperparameter selection of Stage 2b. For retrospective model testing (Stage 2a) the two respective performance values (Perf X.Y) are averaged in each outer loop iteration step and the hyperparameter setting with the best ROC-AUC value is used for training models in Stage 2a, which finally gives performance values (Perf X) for retrospective model testing. For prospective model testing (Stage 2b) all six performance values (Perf X.Y) of the inner loop are averaged for hyperparameter selection. A final trained model on all data is then evaluated on AstraZeneca and Janssen industrial datasets

## Section: Methods › Used public dataset: ExCAPE-ML

QSAR data from ExCAPE-DB was used to construct the ExCAPE machine learning dataset, which will be referred to as the ExCAPE-ML dataset. ExCAPE-DB is a collection of protein–ligand activity entries compiled from ChEMBL and PubChem containing around 70.8 million data points covering about one million compounds and 1667 targets. The collection includes entries from PubChem screens labeled as inactive. Data points from ChEMBL and PubChem were aggregated together with standardized compound structures, official target gene symbols and standardized, log-transformed activity values (pXC50 values). For classification tasks, we assigned the data points to two classes (i.e. inactive, active) according to their pXC50 values. A compound-target record was defined to be active if it fulfilled the criterion that pXC50 ≥ 6 (activity ≤ 1 µM). The dataset was trimmed down by only keeping targets with at least 300 QSAR data points, including at least 75 active compounds and 75 inactive compounds. This resulted in the ExCAPE-ML dataset, being composed of 955,386 compounds, covering 526 distinct target proteins for a total of 49,316,517 QSAR data points (about 90% sparse) with an overall active to inactive ratio close to 1:100.

Roughly, there are two blocks of targets in ExCAPE-ML: 338 targets are annotated with less than 10,000 compounds and 188 targets are annotated with more than 10,000 compounds out of which 155 targets are annotated with between 100,000 and 468,789 compounds (Additional file 1: Fig. S1). The ratio of active to inactive compounds is much higher for smaller targets (less than 100,000 compounds) than for larger targets. The high imbalance level in those large datasets very likely reflects the presence of high-throughput screening data deposited into PubChem, where hit rates are typically low, whereas the low imbalance level in smaller datasets presumably corresponds to data obtained from lead optimization projects in which the aim is often to optimize chemical series of active compounds and where many of the analogues would also be active. Overall, the full compound-target matrix, i.e. the matrix relating compounds and targets by their activities, is very sparse with about 90% of its elements missing.

The 526 target proteins are associated with diverse target families. We further characterized the targets of ExCAPE-ML using information from ChEMBL, EC numbers [36] and UniProt [37]. Details on the dataset composition are available in Additional file 1: Notes S1.

## Section: Methods › Used external industrial test sets

We built external test sets by querying AstraZeneca and Janssen in-house dose–response screening databases with the 526 targets of ExCAPE-ML. AstraZeneca and Janssen dose–response repositories were queried for assays associated to targets of ExCAPE-ML (official gene symbols) and to the species present in ExCAPE-DB (i.e. rat, mouse and human). Duplicated compound-target pairs were aggregated using median pXC50 activity. We retrieved 3 million AstraZeneca data points documenting 854,171 compounds and 20.6 million Janssen data points annotating 2,134,870 compounds. All compounds were standardized according to ExCAPE-DB’s standardization protocol. Compounds present in the ExCAPE-ML dataset were discarded from the AstraZeneca and Janssen datasets. This filtering step resulted in an AstraZeneca dataset of 808,699 molecules covering 352 targets out of the 526 targets of ExCAPE-ML. The same step resulted in a Janssen dataset of 1,794,089 compounds covering 465 targets with a total of 19 million data points. An overview about the compound distributions across the targets for the AstraZeneca dataset and the Janssen dataset is visualized by Fig. 1.

For the discarded compounds from the AstraZeneca and the Janssen datasets (that overlap with ExCAPE-ML) we computed a contingency table (see Table 1) between ExCAPE-ML and the respective company target-compound labels. The correlation between these labels is high, with a Matthew’s correlation coefficient of 0.74 and 0.91 for AstraZeneca and Janssen datasets, respectively. About 90% of the target-compound labels are identical underpinning the idea that models trained on public data can indeed be used to inform drug discovery efforts in companies.

Compound distributions across the targets for the AstraZeneca and the Janssen dataset, respectively. In the lower panel, the y-axis shows the number of compounds for targets represented by the x-axis, where the targets are sorted according to the number of compounds. The horizontal dashed line represents the maximum number of compounds per target observed in the datasets. In the upper panel, a point represents the activity ratio of a target; targets are sorted the same way as in the lower panel. The curve in the upper panel is a smooth average

Contingency tables ExCAPE-ML vs. company datasets

## Section: Methods › Descriptors

In this study, we used ECFP [38] descriptors (radius = 3, count values, unfolded) to represent compounds. In total, the molecular descriptor vectors contained 1,459,681 features to describe the complete ExCAPE-ML dataset. The descriptors were generated from isomeric SMILES by using AMBIT toolkit [39] which was developed based on the CDK toolkit [40].

## Section: Methods › Prospective and retrospective model evaluation

As mentioned above, the main goal of this study was to evaluate the predictive classification performance of machine learning models, which were learned on publicly available data, on industrial data. This is referred to as prospective [41] model evaluation. Additionally, we evaluated the classification performance of machine learning models also on public data itself, which we refer to as retrospective model evaluation.

In contrast to prospective model evaluation, retrospective model evaluation requires a cross validation procedure. Since we also needed to determine hyperparameters for the considered machine learning algorithms and we wanted to avoid a hyperparameter selection bias (consider that the best hyperparameter combination might be dataset dependent [42]), which would arise when test set data leak into the hyperparameter choice, an additional cross validation step for hyperparameter selection as explained in Mayr et al. [29] was needed. This led to a nested cross validation procedure for retrospective model evaluation.

The whole process of hyperparameter selection as well as training and testing of machine learning models for prospective and retrospective evaluation is summarized in Fig. 2: The first two stages (Stage 1, Stage 2a) are the inner and outer loop components of a three-fold nested cross validation loop and are used to perform a retrospective performance evaluation [29, 43]. The third stage (Stage 2b) is prospective model evaluation, which is done with respect to ground truth from the two industry datasets.

Prospective and Retrospective Model Evaluation with three folds (A, B, C). White and colored circles in the Figure represent clusters of compounds, where the size of the circles indicates the cluster sizes (nr. of compounds in the clusters). Colors indicate folds, to which clusters are assigned to, where white circles indicate folds, which are not used for building or evaluating a particular model. In stage 1, the inner loop, one of the three folds serves as the training set, one serves as a test set and the third one is kept aside as a test set for Stage 2a, the outer loop. The respective inner folds used in Stage 1 are merged to training sets for Stage 2a, the retrospective model testing stage. All folds together are merged to the training set for obtaining full-scale models in Stage 2b, the prospective model testing stage. Stage 1 is used for hyperparameter selection of Stage 2a and hyperparameter selection of Stage 2b. For retrospective model testing (Stage 2a) the two respective performance values (Perf X.Y) are averaged in each outer loop iteration step and the hyperparameter setting with the best ROC-AUC value is used for training models in Stage 2a, which finally gives performance values (Perf X) for retrospective model testing. For prospective model testing (Stage 2b) all six performance values (Perf X.Y) of the inner loop are averaged for hyperparameter selection. A final trained model on all data is then evaluated on AstraZeneca and Janssen industrial datasets

## Section: Methods › Evaluation of model performance

Our main prediction performance measure was the area under the receiver operating characteristic curve (ROC-AUC) metrics, which reflects the model’s ability to rank correctly active compounds higher than inactive compounds and which is an established performance measure for classification tasks. Additionally, we provide classification performance estimates by the Cohen-kappa score [44, 45] (Kappa) and the F1 score [46] (harmonic mean of precision and recall). Since we did not optimize thresholds for the respective models with respect to Kappa or F1, it is important to mention that our results should not be interpreted to provide a direct comparison of Kappa or F1 for the different methods. The results serve more as side-information to have a baseline for classification performance with respect to the native usage of the prediction methods.

## Section: Methods › Hyperparameter selection

Our selection criterion for preferring one hyperparameter setting over another was based on the ROC-AUC scores of the individual models trained with a certain hyperparameter.

In the inner loop of the previously mentioned three-fold nested cross validation procedure, we trained a model on one data fold and finally estimated its ROC-AUC value on a second fold while skipping the remaining third fold (see Fig. 2). This process yielded in two performance estimates per skipped fold, i.e. we obtained six performance estimates per hyperparameter (Perf X.Y in Fig. 2) in Stage 1. From there on, we followed two separate scenarios: retrospective evaluation (Stage 2a) and prospective evaluation (Stage 2b).

For retrospective evaluation, we averaged each pair of performance estimates per skipped fold, hence resulting in three estimates. These estimates were then used to select the hyperparameter settings employed in each of the three outer cross validation steps respectively (Stage 2a). For prospective evaluation, we used the average performance estimate obtained over all the six estimates to select the hyperparameter setting for training a final model to be applied on the industrial datasets (Stage 2b).

It is worthwhile to note that for gradient boosting, which works in a single task scenario, hyperparameter settings were selected for each target individually, whereas this was not the case in the multitask scenario, i.e. deep learning and matrix factorization, for simplicity. Therefore, for the multitask case, we computed averages over the targets for hyperparameter selection.

## Section: Methods › Definition of folds for retrospective model evaluation

In order to avoid overoptimistic performance estimation, i.e. avoid the compound series bias as described in Mayr et al. [29], ExCAPE-ML was split into three folds based on a chemical structure clustering [47] which should help assigning molecules from the same chemical series either to the training or to the test set, but not to both sets (Additional file 1: Notes S2).

## Section: Methods › Used machine learning method implementations and their hyperparameters

For deep learning, we considered (standard) feed-forward fully connected deep neural networks (DNNs). We did not take into account neural graph convolution-based or neural sequence-based deep learning approaches, since the necessary network architecture design (hyperparameter) searches may have become very costly from a computational point of view and the question which deep learning architectures work best was not the main focus of this study. The hyperparameter search for our considered DNNs included up to 4 layers and up to 4096 hidden units per layer. We also applied the hyperparameter search on the overall architecture (ReLU [48, 49] architecture, SELU/SNN [50] architecture). The whole list of searched hyperparameters is listed in Additional file 1: Table S1. The number of input features was reduced by an upstream feature selection process, such that only features that exceeded a minimum occurrence threshold (more than 0.25% none-sparse entries) across the compounds in the respective training sets were kept. This resulted in between about 2300 and 2600 features (dependent on the respective training set from which a model is obtained). We applied dropout for regularization at the hidden units and used a sigmoid output layer matching the number of targets to predict (526 output nodes). The objective for training the networks was the minimization of the summed cross-entropies across the different targets, where targets, for which no training data were available, have been excluded from the summation (for details see Additional file 1: Notes S3). The networks were trained by a stochastic gradient descent (SGD) optimizer. For measuring classification performance by Kappa and F1, we used a threshold of 0.5 on the sigmoid output layer.

For matrix factorization (MF) the algorithm Macau [51] was used. Macau was implemented by the SMURFF [52] software package. Hyperparameters were tuned via grid-search, by varying the values of the dimension of the latent space systematically, the precision of the observations, the precision of the compound features and the number of samples collected from Gibbs sampling (see Additional file 1: Table S1). In practice, the total number of Gibbs samples was always set to 2000 but we varied the number of burn-in iterations by steps of 100 between 200 and 1800, thus effectively resulting in 17 different number-of-sample values ranging from 200 to 1800. For classification predictions, the predicted continuous activity values were considered as active if the predicted activity value was higher than or equal to 6 and inactive if it was lower; the final activity prediction was calculated by averaging across per-sample predictions.

Gradient Boosting models were built using XGBoost [53] (XGB). Hyperparameter tuning was performed by hyperparameter grid search exploring the value list in Additional file 1: Table S1. For computing Kappa and F1, we used the classification thresholds provided by the used python package.

It should be mentioned, that for XGB the classifiers for compound activity were trained independently for each target, which is in contrast to the training of target classifiers obtained by DNNs and MF.

For XGB and MF, the number of input features was trimmed down to a fixed set of 29,413 features by removing any feature with low variance (threshold variance is 0.05, which was applied to non-zero entries only). This set of features was used for all experiments with XGB and MF. It should be noted, that the number of input features for DNNs was smaller (although being selected from the same original set of features as the selected 29,413 features) in order to allow training more DNNs in parallel for hyperparameter search on a GPU, which would otherwise not have been possible because of GPU memory restrictions.

## Section: Results and discussion

Retrospective evaluation performance

ROC-AUC, Kappa and F1-score performances of DNN, XGB and MF models on the ExCAPE-ML dataset. Violin plots illustrate the distribution of individual target performances, boxplots represent the interquartile range, with median value in transparent and average as the horizontal black segment

Prospective evaluation performance

ROC-AUC, Kappa and F1-score performances of DNN, XGB and MF models on AstraZeneca and Janssen datasets. Violin plots illustrate the distribution of individual target performances, boxplots represent the interquartile range, with median value in transparent and average as the horizontal black segment

Prospective Performance Comparison

Target family breakdown for ExCAPE-ML, AstraZeneca and Janssen predictions. The numbers on the horizontal axis represent the number of targets corresponding to the target family and dataset. The vertical axis represents the AUC value

Target Family Performance Comparison

## Section: Results and discussion › Retrospective validation performance

In the retrospective part of this study, we estimated the predictive classification performance of machine learning methods on ExCAPE-ML itself by cross validation. Table 2 shows mean cross validation model performance values (ROC-AUC, Kappa, F1) together with their standard deviations for test folds of the outer loop from the retrospective evaluation procedure over the individual targets. For the errors, thereby, first cross validation performances per target are computed, and then standard deviations over the individual targets. Additionally, Fig. 3 shows violin plots of the cross validation performances. Especially, ROC-AUC statistics suggests, that DNNs outperform XGB and MF with p-values of 8.01e-48 and 1.80e-71 for the alternative hypothesis that DNNs have a better mean ROC-AUC than XGB or MF, respectively (paired Wilcoxon test).

The retrospective analysis on ExCAPE-ML is in concordance with other comparative studies [29], which indicate that deep learning is a proficient method for drug target prediction

Furthermore, all three considered methods have been shown to work on to a certain extent on previously unseen compound series. This suggests the capability of the three methods to learn predictive models for the activities of compound series not present in the training set and in turn highlights that the knowledge learnt from ExCAPE-ML has the potential to be transferred to external datasets. In order to investigate this further, and to understand better how well models trained with ExCAPE-ML data can predict external data, we performed a prospective evaluation by applying ExCAPE-ML models, trained on all ExCAPE-ML data, to two external industrial datasets.

Retrospective evaluation performance

ROC-AUC, Kappa and F1-score performances of DNN, XGB and MF models on the ExCAPE-ML dataset. Violin plots illustrate the distribution of individual target performances, boxplots represent the interquartile range, with median value in transparent and average as the horizontal black segment

## Section: Results and discussion › Prospective validation performance

In the prospective part of this study, we assessed how well machine learning models trained on public data can be transferred to internal pharmaceutical industry data by applying them to two industrial, in-house datasets. The classification performance statistics (ROC-AUC, Kappa, F1) for prospective validation of our three prediction models on the AstraZeneca and Janssen datasets is given by Table 3 and further visualized by Fig. 4.

In general, ROC-AUC prediction performance on industrial datasets is moderate compared to the estimations made in the retrospective analysis (13 to 17% lower for the AstraZeneca dataset and 18 to 21% lower for the Janssen dataset). Nevertheless, despite predicting unseen molecules, the predictions for at least 25% of the targets reached a ROC-AUC ≥ 0.7 with all three methods simultaneously (99 out of 352 targets for the AstraZeneca dataset and 116 out of 465 targets for the Janssen dataset), hence demonstrating that the public models are still valuable for prospective predictions.

A Wilcoxon test could reject the hypothesis that the mean ROC-AUC of DNNs is below 0.6 with a p-value of 7.4e−31 for the AstraZeneca dataset and a p-value of 3.3e−17 for the Janssen dataset. For the other algorithms, we obtained also highly significant p-values, rejecting the hypothesis that prediction scores were random. Similarly, for targets in the AstraZeneca dataset and targets in the Janssen dataset, all methods exhibit Kappa scores, for which the null hypothesis, that Kappa is negative, could be rejected (e.g. for DNNs 7.2e−51 for the AstraZeneca dataset and 2.4e−51 for the Janssen dataset). This is especially notable, since the classification thresholds were not explicitly optimized for obtaining good Kappa scores.

A reason for the performance decrease compared to ExCAPE-ML could be that ExCAPE-ML has a different compound activity distribution than the AstraZeneca and Janssen datasets, which can be seen, when Fig. 1 is compared to Additional file 1: Fig. S1. On ExCAPE-ML there is a large number of targets that presumably arise from high-throughput screening and where the activity ratio is close to zero. This activity distribution property cannot be observed in the considered industrial datasets. Further, other, at least equally important, but harder quantifiable reasons for the performance decrease might be different assay technologies or a different chemical space of compounds, which is not reflected by the public dataset and which makes accurate predictions difficult.

If we compare the considered machine learning methods to each other, a consistent result to the retrospective performance analysis is that DNNs outperform XGB and MF. This is especially remarkable given the sizes of company-internal datasets and the differences in activity distributions. The respective p-values of Wilcoxon signed rank tests and sign tests are given by Table 4. It should be mentioned that the method comparison was not the main focus here and since the absolute performance differences were moderate, possibly further investigations will be needed, to better understand under which conditions a method excels another one.

We further investigated whether there would be a dependency of the prediction performance on the industrial datasets from the available training set size of the target in ExCAPE-ML. We found the Spearman correlation between training set sizes and the DNN ROC-AUC values over the targets to be 0.18 and 0.09 for the AstraZeneca and the Janssen dataset respectively. A correlation test showed significance at a threshold of 0.01. Additional file 1: Fig. S3 underpins the result, that there might be a slight correlation, however it isn’t large.

Overall, we can conclude (1) that for a big number of targets successful model transfer is observed with a certain performance decrease and (2) Deep Learning outperforms methods investigated in this classification study on industrial data in which aggregated ranking performance metrics across several diverse targets were used as the main criterion.

Prospective evaluation performance

ROC-AUC, Kappa and F1-score performances of DNN, XGB and MF models on AstraZeneca and Janssen datasets. Violin plots illustrate the distribution of individual target performances, boxplots represent the interquartile range, with median value in transparent and average as the horizontal black segment

Prospective Performance Comparison

## Section: Results and discussion › Prediction performances of different target families

In the final part of this study, we investigated performances obtained for various types of biological activities. In order to do so, we analyzed the distribution of ROC-AUC values across different protein target families (see Fig. 5). The first main column of Fig. 5 shows the prediction performances across target families for retrospective model evaluation. It can be observed, that machine learning algorithms seem to work well for predicting diverse types of biological activities. This is a similar observation to that found for assays in the study of Mayr et al. [29]. The second and third main columns of Fig. 5 show target family performances for the AstraZeneca and the Janssen datasets respectively. Although we observe that there is no perfect correlation between family performances found on ExCAPE-ML and the respective performances on the AstraZeneca and Janssen datasets, model transfer works similarly well across such diverse targets as membrane receptors, ion channels or enzymes catalyzing metabolic reactions.

Further, we investigated for each target, which of the three machine learning methods worked best and checked for each target family whether the winning probability of DNNs is less than a third or greater. The p-value results are given in Table 5 together with the numbers of targets won by DNNs and the overall numbers of targets for each target family. In general, we conclude, that for large enough target families, we can reject the null hypothesis that the winning probability of DNNs is only a third on the public dataset as well as on the two industrial datasets, indicating that Deep Learning is advantageous for most of the target families. Noticeable exceptions from this conclusion seem to be the Transferase family of the Janssen dataset, where MF wins 65 targets or the Oxidoreductase family of the AstraZeneca dataset, where XGB is the best method for 9 targets.

Target family breakdown for ExCAPE-ML, AstraZeneca and Janssen predictions. The numbers on the horizontal axis represent the number of targets corresponding to the target family and dataset. The vertical axis represents the AUC value

Target Family Performance Comparison

## Section: Conclusions

In this study, we utilized public bioactivity data to derive predictive machine learning models for classification, with the goal to transfer them to industrial data and evaluate their performances there. In a retrospective analysis we assessed the performance of our machine learning models on public data. We confirmed previous observations that multitask Deep Learning outperforms other state-of-the-art target prediction methods. In a prospective study, we directly transferred our learned models to industrial datasets and evaluated the predictive quality on those molecules. There our most important observation was, that particular models can still preserve good predictive quality with ROC-AUC performances, which were on average between about 0.65 and 0.70. Although the performance decreased, there are nevertheless a lot of useful models for specific targets with an AUC of at least 0.70 on both industrial datasets. Furthermore, successful model transfer works across different target families. We could finally observe that Deep Learning derived target prediction models are in this study superior to models derived by other machine learning algorithms also on industrial datasets.

We think the results of our study are interesting for both, drug discovery and machine learning. As mentioned, data distributions between public databases and industry databases might be different; it is therefore notable, that prediction performances transfer well to in-house data of companies. From a machine learning point of view, this study might serve as a proof-of-concept for successful model transfer.

## Section: Supplementary information

Additional file 1: Fig. S1. Compound distributions across the targets for the ExCAPE-ML dataset. Fig. S2. Targets per protein families. Notes S1. ExCAPE-ML Target Families. Notes S2. Clustering and Assignment of Clusters to Folds. Notes S3. Objective Function for Deep Learning. Table S1. Considered machine learning algorithm hyperparameters. Fig. S3. DNN ROC-AUC performances on industrial datasets vs. Training set size.

## Section: Supplementary information

Additional file 1: Fig. S1. Compound distributions across the targets for the ExCAPE-ML dataset. Fig. S2. Targets per protein families. Notes S1. ExCAPE-ML Target Families. Notes S2. Clustering and Assignment of Clusters to Folds. Notes S3. Objective Function for Deep Learning. Table S1. Considered machine learning algorithm hyperparameters. Fig. S3. DNN ROC-AUC performances on industrial datasets vs. Training set size.

## Section: Acknowledgements

Not applicable.

## Section: Authors’ contributions

ExCAPE-ML was generated by NS, VCh, JW, JFGD, NJ, and HCh. Dataset Extraction of the Janssen data was by TLV and VCh. Dataset Extraction of the AstraZeneca data was by NS, NG, and HCh. NS trained XGB, AM trained DNNs, TVA trained MF models on ExCAPE-ML and evaluated the performances there. NS and TLV applied all trained models to the Janssen and the AstraZeneca datasets, respectively. Several HPC runs were carried out by NJ, YV, SB, VCi, and TVA. VCh, HCe, JM, TJA, SH, OE, GK, and HCh supervised the project. NS, AM, GK, and HCh designed the concept of the manuscript and wrote major parts of it. All authors read and approved the final manuscript.

## Section: Funding

This research has mainly received funding from the ExCAPE project (https://www.excape-h2020.eu) within European Union’s Horizon 2020 framework under Grant Agreement no. 671555 and by the IT4Innovation infrastructure which is supported by the Large Infrastructures for Research, Experimental Development and Innovation project “IT4Innovation National Supercomputing Center—LM2015070”. Further, this research was supported by FFG grant 871302, LIT grant DeepToxGen and AI-SNN, FWF grant P 28660-N31. Several computations in this study were performed on the IT4I supercomputer center of Czech Republic with the platform Hyperloom [54].

## Section: Availability of data and materials

The ExCAPE-ML dataset, on which the retrospective analysis is applied and on which the models for the prospective analysis are learnt, is publicly available at https://zenodo.org/record/3559987 The industrial datasets from AstraZeneca and Janssen, cannot be provided to the public. Code, used for this study, is available at https://github.com/ExCAPE-Project.

## Section: Competing interests

The authors declare no competing interests.

## Section: Contributor Information

Noé Sturm, Email: noesturm@gmail.com.

Günter Klambauer, Email: klambauer@ml.jku.at.

Hongming Chen, Email: Hongming.Chen71@hotmail.com.

## Section: Supplementary information

Supplementary information accompanies this paper at 10.1186/s13321-020-00428-5.

## Section: Associated Data

Additional file 1: Fig. S1. Compound distributions across the targets for the ExCAPE-ML dataset. Fig. S2. Targets per protein families. Notes S1. ExCAPE-ML Target Families. Notes S2. Clustering and Assignment of Clusters to Folds. Notes S3. Objective Function for Deep Learning. Table S1. Considered machine learning algorithm hyperparameters. Fig. S3. DNN ROC-AUC performances on industrial datasets vs. Training set size.

## Section: Associated Data › Supplementary Materials

Additional file 1: Fig. S1. Compound distributions across the targets for the ExCAPE-ML dataset. Fig. S2. Targets per protein families. Notes S1. ExCAPE-ML Target Families. Notes S2. Clustering and Assignment of Clusters to Folds. Notes S3. Objective Function for Deep Learning. Table S1. Considered machine learning algorithm hyperparameters. Fig. S3. DNN ROC-AUC performances on industrial datasets vs. Training set size.

## Section: Associated Data › Data Availability Statement

The ExCAPE-ML dataset, on which the retrospective analysis is applied and on which the models for the prospective analysis are learnt, is publicly available at https://zenodo.org/record/3559987 The industrial datasets from AstraZeneca and Janssen, cannot be provided to the public. Code, used for this study, is available at https://github.com/ExCAPE-Project.


---

# Integrating Machine Learning-Based Virtual Screening With Multiple Protein Structures and Bio-Assay Evaluation for Discovery of Novel GSK3β Inhibitors

- **Authors:** Jingyu Zhu, Yuanqing Wu, Man Wang, Kan Li, Lei Xu, Yun Chen, Yanfei Cai, Jian Jin
- **Issuer:** Frontiers in pharmacology
- **Type:** Scientific article
- **Published:** 2020-09-11
- **Language:** en
- **DOI:** 10.3389/fphar.2020.566058
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33041806/
- **Licence:** CC-BY

## Section: Abstract

Glycogen synthase kinase-3β (GSK3β) is associated with various key biological processes, and it has been considered as a critical therapeutic target for the treatment of many diseases. However, it is a big challenge to develop ATP-competition GSK3β inhibitors because of the high sequence homology with other kinases. In this work, a novel parallel virtual screening strategy based on multiple GSK3β protein structures, integrating molecular docking, complex-based pharmacophore, and naive Bayesian classification, was developed to screen a large chemical database, the 50 compounds with top-scores then underwent a luminescent kinase assay, which led to the discovery of two GSK3β inhibitor hits. The high screening enrichment rate indicates the reliability and practicability of the integrated protocol. Finally, molecular docking and molecular dynamics simulation were employed to investigate the binding modes of the GSK3β inhibitors, and some “hot residues” critical to GSK3β affinity were highlighted. The present study may provide some valuable guidance for the development of novel GSK3β inhibitors.

## Section: Introduction

Glycogen synthase kinase-3 (GSK3) is an evolutionarily very conserved serine/threonine kinase that is ubiquitous in mammalian eukaryotic cells, and it presents a broad spectrum of cellular functions, like cell division, differentiation, transcription, apoptosis, and so on (Frame and Cohen, 2001; Hu et al., 2018). GSK3 contains two functionally distinct isoforms, α and β, and these two isoforms share a 98% sequence identity within the active domain (MacAulay and Woodgett, 2008). Among them, GSK3β has received more attention because of its central role in the regulation of many important metabolic and signaling proteins, structural proteins and transcription factors, that depicts GSK3β as a promising target for the treatment of cancer, neurodegenerative diseases, neuropsychiatric diseases, and other major diseases (Cohen and Frame, 2001; Osolodkin et al., 2013; O’Leary and Nolan, 2015; Maqbool and Hoda, 2017; Abdul et al., 2018). Therefore, a certain number of GSK3β inhibitors with different kinds have been discovered in last decades (Wagman et al., 2004; Maqbool and Hoda, 2017), and some have been pushed into the clinical trials (Wu et al., 2019). GSK3β inhibitors can be roughly classified into two categories: non-ATP competition and ATP competition inhibitors (Force and Woodgett, 2009; Swinney et al., 2016; Dey et al., 2017; Saura et al., 2017). These two types of inhibitors represent two different focuses on the development of GSK3β inhibitors: affinity and selectivity. non-ATP inhibitors binding to the ATP outside area usually contain higher selectivity but lower affinity to GSK3β, but ATP inhibitors acting to ATP pocket are just the opposite. Nowadays, a large number of ATP competition GSK3β inhibitors have been developed, but no selective GSK3β inhibitor has been FDA approved so far (Sahin et al., 2019). As mentioned above, GSK3β show a 98% sequence identity to GSK3α, besides, GSK3β share a highly conserved sequence in many other kinases, such as cyclin-dependent kinases (CDK) (Bax et al., 2001), that makes it challenging to develop selective GSK3β inhibitors. Therefore, the application of appropriate methods for developing high selective GSK3β inhibitors has become critical and urgent.

As is known to all, traditional lead kinase inhibitors discovery based on experimental systems is an expensive, inefficient and lengthy process because of its screening against a broad panel of diverse kinases. As a counterpart to experimental high-throughput screening, virtual screening (VS) is able to virtually screen large compound databases and has become a good choice for the discovery of novel inhibitors (Hou and Xu, 2004; Amaro and Li, 2010). VS based on molecular docking has received more and more attention (Tanrikulu et al., 2013). For conventional VS, only one protein structure is used in most docking programs, and the protein almost performs the “rigid” structure to maintain optimum efficiency of VS. Thus, integrated strategies for VS in a parallel manner may be the most appropriate to balance the efficiency and precision of VS, and some successful cases in the field of kinase inhibitor development have been reported (Bajorath, 2002; Holliday et al., 2011; Tian et al., 2014; Fan and Huang, 2017; Zhou et al., 2018). Among them, naive Bayesian analysis, a machine learning algorithm, has been widely applied to drug discovery processes such as high-throughput VS, ADMET (absorption, distribution, metabolism, excretion, and toxicity) properties evaluation, and SAR (structure-activity relationship) analysis (Liu, 2004; Chen et al., 2011; Ekins et al., 2019). Bayesian analysis is a well-known statistical algorithm and it could scale linearly with the number of samples comparing with traditional fitting methodologies, thus, Bayesian analysis could be fast and easily automated to process large amounts of data (Rogers et al., 2005; Tian et al., 2013a). Moreover, the Bayesian model focuses on the more important features of samples, and then assigns greater weight to the characteristics to distinguish the “good” samples from the large amounts of sample, that would significantly lead to a higher quality enrichment (Klon et al., 2004; Rogers et al., 2005). In this study, we present an efficient and reliable predictive strategy for parallel Bayesian machine learning-VS integrating molecular docking and complex-based pharmacophore based on multiple GSK3β proteins (the workflow is illustrated in Figure 1 ), 50 potential inhibitors of GSK3β were purchased and some compounds with potent GSK3β inhibitory activity were confirmed by a series of biochemical studies. Finally, the GSK3β binding mechanisms of these inhibitors were well analyzed through molecular docking and molecular dynamics simulation. It could provide some important guidance for the discovery of promising GSK3β inhibitors from a huge chemical database for the treatment of related diseases.

The workflow of this study.

## Section: Methods and Materials

Scoring power and screening power of the eight GSK3β protein structures.

(A–H) Eight GSK3β complexes have better ability to distinguish known inhibitors and non-inhibitors under SP or XP docking accuracy; (I) AUC value of Bayesian model constructed based on docking score or integrating docking scores and pharmacophore fit values.

The selectivity scores and AUC values of feature(S) and feature(D).

(A) Preliminary screening results of 50 compounds with enzyme experiments; (B) Cpd22 and Cpd49 concentration gradient results; (C, D) 2D structure diagram of Cpd22 and Cpd49.

The pScore and inDrug values from Badapple prediction.

2D presentations of the interactions between GSK3β and (A) Cpd22; (B) Cpd49; (C) LY2090314; (D) 2D presentations of the interactions between GSK3α and Cpd49 (H-bonds colored in magenta).

(A) the Cpd49-GSK3β residues interaction spectrum; (B) 2D presentations of the MD simulation interactions between GSK3β and Cpd49; (C) 3D presentations of the MD simulation interactions between GSK3β and Cpd49.

X-ray crystal structures of (A) GSK3β/AMP-PNP (PDB ID 1PYX); (B) GSK3β/AZD2858 (PDB ID 4ACD); (C) GSK3β/CHIR-99021 (PDB ID 5HLN); (D) GSK3β/Alsterpaullone (PDB ID 1Q3W).

## Section: Methods and Materials › Preparation of GSK3β Complexes and Validation Dataset

A total of 54 crystallographic structures of GSK3β complexes were retrieved from the RCSB Protein Data Bank (PDB) (Berman et al., 2000). Firstly, the residues within 10 Å of each apo-ligand were reserved and structurally aligned with STAMP algorithm in VMD ( Figure S1 ) (Humphrey et al., 1996; Tian et al., 2014). Secondly, the root-mean-square deviation (RMSD) values from the alignment were used to create a phylogenetic tree through the phylogenetic tree module of VMD ( Figure S2 ). And then, these complexes could be classified eight types according to the differences of the GSK3β structures. Finally, eight representative complexes with the highest resolution within each type were chosen, namely, 1Q3W (Bertrand et al., 2003), 1Q4L (Bertrand et al., 2003), 2OW3 (Zhang et al., 2007), 3L1S (Arnost et al., 2010), 4B7T (Tahtouh et al., 2012), 4J71, 4NM3 (Stamos et al., 2014) and 4PTG (Sivaprakasam et al., 2015) (highlighted in red in Figure S2 ).

In order to evaluate the “screening power” of these eight protein structures, a validation dataset was built, including the known GSK3β inhibitors and non-inhibitors. The non-duplicated GSK3β inhibitors with definite biological activity were obtained from the BindingDB database (Liu et al., 2007), and the non-inhibitors were randomly selected from the ChemDiv database through the Find Diverse Molecules module in Discovery Studio 3.5 (DS3.5), and the ratio of non-inhibitors versus inhibitors was set to 1:20. At last, 800 inhibitors and 16,000 non-inhibitors were chosen for further study.

## Section: Methods and Materials › Molecular Docking Procedure

The crystallographic structures of eight GSK3β complexes were employed as initial receptors for VS. Molecular docking simulations were carried on by the Glide module in Schrodinger (Friesner et al., 2006). First, each complex was prepared using the Protein Preparation Wizard in Schrodinger, to remove crystallographic water molecules, add hydrogen atoms, assign protonated states, assign partial charges. Afterward, each complex was minimized with the OPLS-2005 force field until the RMSD reached a maximum value of 0.3 Å. The compounds in the validation set were processed through the LigPrep protocol in Schrodinger with the default parameters set. Finally, a bounding box of size 10 × 10 × 10 Å was generated with the co-crystallized ligand as centroid using the Receptor Grid Generation module for each system.

Subsequently, the “scoring power” was evaluated to estimate the docking precision of these eight systems. The crystallized ligand was first extracted from each GSK3β complex, and then re-docked into the corresponding binding site, the RMSD between the docking pose and crystallographic conformation of the inhibitors was calculated. On the other hand, the “screening power” was also investigated. All molecules in the validation dataset were docked into the binding site of each protein with the Standard Precision (SP) or Extra Precision (XP) scoring modes. The student ’s t-test was used to measure the difference in the distribution of docking scores between active inhibitor and non-inhibitors.

## Section: Methods and Materials › Pharmacophore Procedure

The eight crystal GSK3β structures were also used as the initial receptors for complex-based pharmacophore models. First, the proteins were prepared through the prepare protein module in DS3.5 to add polar hydrogen, remove water molecules, repair the broken chain, and add the CHARMm field with the default parameters. Second, all molecules in the validation set were prepared through the prepare ligands module in DS3.5. Then, the Receptor-Ligand Pharmacophore Generation (RLPG) module was employed to generate the complex-based pharmacophore models for eight GSK3β complexes (Hou et al., 2012). A set of pharmacophoric features were identified from each system (Sutter et al., 2011), including hydrogen bond acceptor (HBA), hydrogen bond donor (HBD), hydrophobic (HYD), negative ionizable (NI), positive ionizable (PI), and ring aromatic (RA) features of ligands. And the parameters were kept as the default setting except for the minimum number of the pharmacophore features was set to 3.

The selectivity of the pharmacophore model is evaluated through genetic function approximation (GFA) scoring function (Rogers and Hopfinger, 1994; Meslamani et al., 2012). For each complex structure, the generated models are ranked according to their selectivity scores evaluated by the GFA model, and thus 10 top-ranked pharmacophore models would be produced, and feature(S) was defined as the pharmacophore features with the highest selectivity. Besides, in order to investigate the capability of each model to distinguish between inhibitors and non-inhibitors, a validation set containing 800 active GSK3β inhibitors and 16,000 non-inhibitors mentioned above was constructed. The pharmacophore features of the pharmacophore model with the best discrimination between inhibitors and non-inhibitors were set to feature(D), and the area under receiver operating characteristic (ROC) curve (AUC) was calculated to evaluate this discrimination capability. Moreover, the molecules in the validation set were all mapped onto the pharmacophore models to generate the fit values.

## Section: Methods and Materials › Naive Bayesian Classification

Consequently, naive Bayesian classification (NBC) based on multiple protein structures was employed to evaluate the screening accuracy. This machine learning approach has been proved to significantly increase the hit rate of virtual screening (Tian et al., 2013b; Li et al., 2014). First, the data matrix consists of above docking scores (from molecular docking) and fit values (from pharmacophore) were used as the independent variables (X); and 1/0 was used as the response variable (Y), in which 1 presents inhibitor and 0 means non-inhibitor. Then, NBC was developed using the Create Bayesian Model module in DS3.5 (Hou et al., 2012) to distinguish the inhibitors from non-inhibitors. The prediction precision of each classifier was evaluated by the AUC value for discriminating the GSK3β inhibitors from non-inhibitors. Finally, the best Bayesian classifier was utilized to re-score the compounds.

## Section: Methods and Materials › Integrated Virtual Screening

The docking-VS was performed to screen the ChemDiv database (approximately 2,000,000 compounds). First, each compound was docked into the binding pockets of eight GSK3β with corresponding scoring modes. Then, 10,000 compounds with the best docking scores were obtained and then mapped onto the pharmacophore models generated from the GSK3β complexes. Afterward, 2,000 compounds with the best fit values were chosen and then to re-screening with the best Bayesian classifier. Last, the 100 compounds with top-ranked by the Bayesian scores were assessed the drug-likeness by Filter by Lipinski and Veber Rules module in DS3.5. Finally, 50 compounds were purchased from ChemDiv for subsequent GSK3β inhibitory assay in vitro.

## Section: Methods and Materials › Kinase Assay

GSK3β kinase activity was measured by ADP-Glo Kinase Assay system from Promega (Product code V1991) (Auld et al., 2009; Zegzouti et al., 2009; Cho et al., 2011), which is a non-radioisotope, homogeneous, ADP quantitative kit based on a luminescent kinase assay. Compounds were initially tested in triplicate at 20 µM, and then, those molecules which contain an inhibitory activity greater than 50% were chosen to further test in a nine-point dose curve with 2-fold serial dilution starting from 40 µM (three times). The assay protocol was listed as below: GSK3β protein was firstly incubated with 1μg/ml of the peptide substrate, second, the test compounds were added into the solution for 60 min at 25°C with a GSK3β reaction buffer, which contained 40 mM Tris (pH = 7.5), 20 mM MgCl2, 0.1mg/ml BSA, 50 μM DTT, and 50 μM ATP. The assays were done in 384-well white plates with a total reaction volume of 5 μl per well. Then, the reactions were terminated through the introduction of 5 μl ADP-Glo reagent assay, and the assay plate was incubated for 40 min. Finally, 10 μl of kinase detection buffer was added to convert ADP to ATP and introduce luciferase and luciferin to detect ATP.

## Section: Methods and Materials › Promiscuity Assessment

The promiscuity of Cpd49 was evaluated by an online program, Badapple (http://pasilla.health.unm.edu/tomcat/badapple/badapple). the simplified molecular input line entry specification (SMILES) formats of Cpd49 was entered into the input box and the results would be generated automatically.

## Section: Methods and Materials › Molecular Docking and MD

The 3D structure of compound22 (Cpd22) and Cpd49 were sketched using maestro, LY2090314 was retrieved from the PubChem Compound database. All these inhibitors were prepared by the Ligprep module with the OPLS-2005 force field in Schrodinger. The crystal structure of GSK3β with the highest resolution, 1Q4L, and the crystal structure of GSK3α, 2DFM (Wang et al., 2019), were prepared as the initial receptors for the molecular docking through the Protein Preparation Wizard module. The grid file of the GSK3β protein was generated following the step in Chapter 2.2, and that of GSK3α was generated with the specified residues, Val101, Pro102, and Arg107 (hinge region), as centroids. Then Cpd22, Cpd49, and LY2090314 were respectively docked into the GSK3β protein, and Cpd49 was docked into the GSK3α protein using the Glide module (XP mode), and the best-docked structure of Cpd49 in the GSK3β-ligand system was chosen for the following MD simulation.

The Cpd49 with the best bioactivity was conducted to MD with Desmond package in Schrodinger (Chapon, 2014), and the docked GSK3β/Cpd49 complex was chosen as the initial system. All amino acid interactions in the protein were modeled with the OPLS-2005 force field. The simulation system was solvated in a 10 Å orthorhombic box with periodic boundary condition, and built with the 3-Point Transferable Inter-molecular Potential (TIP3P) water model. Afterward, the whole system was neutralized with salt concentrations of 0.15 M of Na+ ions. Before MD simulation, the system was minimized with OPLS-2005 force field. And then, the 200-ns MD was performed using the NPT ensemble under a target temperature of 310 K and a target pressure of 1 atm, the energy and atomic coordinate trajectory recording interval were set to 20 ps. Thereafter, the RMSD and protein-ligand contacts were all calculated with the Simulation Interaction Diagram protocol in Desmond package.

## Section: Methods and Materials › Results and Discussion

Scoring power and screening power of the eight GSK3β protein structures.

(A–H) Eight GSK3β complexes have better ability to distinguish known inhibitors and non-inhibitors under SP or XP docking accuracy; (I) AUC value of Bayesian model constructed based on docking score or integrating docking scores and pharmacophore fit values.

## Section: Methods and Materials › Results and Discussion › Validation of Docking-Based Virtual Screening

To investigate the prediction capability and reliability of molecular docking, the screening ability, including “scoring power” and “screening power”, was evaluated. Scoring power shows the reliability of the docking program, namely, whether it can predict the real binding conformation between inhibitors and proteins (Shen et al., 2020). Herein, the RMSD between docking pose and crystallographic structures was calculated to reveal this “power” and RMSD ≤ 2.0 Å was used as a criterion. Firstly, the original ligands of eight GSK3β complexes were extracted and then re-docked into the corresponding binding pocket of the protein. The RMSD values were calculated and the values were summarized in Table 1 . Generally, the docking program, whether SP mode or XP mode, basically reproduces the experimental conformation (all RMSD values ≤ 2.0 Å), indicating the eight chosen protein structures all satisfy the docking accuracy with Glide module.

Next, the screening power was estimated using the Student’s t-test (P-value), which was conducted to assess the different distributions between the inhibitors and non-inhibitors under SP or XP score modes (Shen et al., 2020). As shown in Table 1 and Figure 2 , the molecular docking can effectively distinguish the inhibitors form non-inhibitors, the P-values of eight complexes all far lower than 0.05, except the SP mode of 4B7T. However, discrimination for certain structures still exhibits significant different sampling powers ( Figure 2 ). For instance, the P-value of the SP mode for 2OW3 is 2.958 ×10−69, while that for 4B7T is only 0.172 ( Table 1 ). In general, the XP scoring mode exhibited more accurate determination than the SP scoring mode ( Figure 2 ). Therefore, it is necessary to choose an appropriate docking mode for a specific protein structure to ensure docking prediction accuracy. In summary, our molecular docking model based on the eight GSK3β structures with Glide could fulfill the requirement of satisfactory docking. Thus, the docking-based VS with the multiple structures would be a reliable tool for the development of potential GSK3β inhibitors.

Scoring power and screening power of the eight GSK3β protein structures.

(A–H) Eight GSK3β complexes have better ability to distinguish known inhibitors and non-inhibitors under SP or XP docking accuracy; (I) AUC value of Bayesian model constructed based on docking score or integrating docking scores and pharmacophore fit values.

## Section: Methods and Materials › Validation of Pharmacophore-Based Virtual Screening

Eight complexes of GSK3β were employed to generate the pharmacophore models, and the models were ranked through the selective scores detected by the GFA algorithm. The results were tabulated in Table 2 . The prediction capacity of each pharmacophore model to distinguish the inhibitors and non-inhibitors was evaluated with the AUC values, and it indicates that the models contain satisfactory prediction power when AUC > 0.7 (Tian et al., 2013b). According to Table 2 , feature(S) and feature(D) were analyzed and compared.

Generally speaking, a pharmacophore model with a higher selectivity score shows a stronger prediction power. But as shown in Table 2 , we found that most models with the high selectivity score contain a poor discrimination power, such as 4NM3 (AUC < 0.7). Some models, especially the feature(D) of 2OW3, with a low selective score, show a fair inhibitor selectivity on the contrary. It seems that the pharmacophore models using feature(D) are more suitable for our VS protocol. Therefore, to simultaneously avoid a high rate of false positives and find more active GSK3β inhibitors, 1Q4L and 2OW3 models with feature(D) were chosen to perform pharmacophore-based VS (AUC > 0.7, Table 2 ).

The selectivity scores and AUC values of feature(S) and feature(D).

## Section: Methods and Materials › Naive Bayesian Classifiers With Multiple GSK3β Structures

As described above, two protocols based on molecular docking and pharmacophore were respectively optimized for the following VS. In order to further improve the hit rate of screening, a parallel virtual screening based on multiple structures integrating molecular docking and pharmacophore was built and the prediction capabilities were evaluated by NBC model. The flow diagram of the model generation process is revealed in Figure 1 . The data matrix consists of all the docking scores and fit values of the compounds in the validation dataset for each complex. According to the above results, the docking mode with a higher P-value and/or pharmacophore model with a fair AUC value should be selected as the independent variables to build the NBC models (bolded in Tables 1 and 2 ). Firstly, the prediction power based on the chosen docking score was estimated and the AUC = 0.774 ( Figure 2I ), this value was slightly better than that of the above pharmacophore. But when the model combined the docking scores and fit values, the accuracy was significantly improved, the classifier achieved an AUC of 0.833, indicating that the VS integrating a machine learning based on multi-conformational GSK3β could effectively highlight the active GSK3β inhibitors.

## Section: Methods and Materials › GSK3β Inhibition Assay

To determine the GSK3β inhibitory activity of those hit molecules from VS, we performed GSK3β inhibition assays based on ADP-Glo method, in which LY2090314 (Atkinson et al., 2015; Gray et al., 2015; Kunnimalaiyaan et al., 2018) was used as the reference compound. The 50 compounds were tested at the initial concentration of 20 μM. The results of the GSK3β inhibitory activities of these hits are shown in Figure 3A . Among the tested compounds, Cpd22 showed effective inhibiting GSK3β activity 57.6% and Cpd49 inhibiting GSK3β activity 58.5% at the concentration of 20 μM, respectively. Afterward, the GSK3β inhibition potency (IC50) of Cpd22 and Cpd49 was identified, both compounds could potentially inhibit the activity of GSK3β, with IC50 of 15.49 μM and 9.34 μM, respectively ( Figure 3B ). The 2D structures of the two inhibitors are illustrated in Figures 3C, D , and both compounds present new scaffolds.

(A) Preliminary screening results of 50 compounds with enzyme experiments; (B) Cpd22 and Cpd49 concentration gradient results; (C, D) 2D structure diagram of Cpd22 and Cpd49.

## Section: Methods and Materials › PAINS Assessment for Cpd49

Cpd49 with the better bioactivity was then investigated whether it could be categorized as a PAINS compound. PAINS refer to a series of promiscuous compounds specifically binding to different macromolecular targets and leading to misleading false-positive results in experimental assays (Baell and Holloway, 2010). The assessment results from Badapple prediction were shown in Table 3 . The cyclopropane of Cpd49 exhibits a moderate pScore value with 185 and shows a “True” inDrug result. While the tetrahydroindazole group presents a low pScore value with a “False” result inDrug database. Besides, the scaffold3 generated no pScore and the inDrug result is “False”. These results indicate Cpd49 would be a GSK3β selective inhibitor.

The pScore and inDrug values from Badapple prediction.

## Section: Methods and Materials › Molecular Docking Analysis

To elucidate the binding mode of inhibition of GSK3β by Cpd22 and Cpd49, the two inhibitors were docked to the crystal structure 1Q4L. The docking scores were −9.032 kcal/mol for GSK3β/Cpd22, and −9.566 kcal/mol for GSK3β/Cpd49. The interactions between the inhibitors and GSK3β have respectively illustrated in Figure 4 . The docking results indicated that Cpd22 and Cpd49 interact with GSK3β in the same position, in which residues Ile62, Val70, Ala83, Val110, Asp133, Tyr134, Val135, Thr138, Arg141, Leu188, Cys199, and Asp200 constructed the binding pocket and interacted with the inhibitors. Meanwhile, hydrophobic interactions were formed with residues Ile62, Val70, Ala83, Val110, Tyr134, Val135, Leu188, and Cys199 (shown in black lines in Figures 4A, B ), which was consistent with the analytical results from our previous research. These residues are important to stabilize the binding affinity between the inhibitors and GSK3β (Zhu et al., 2019). In addition, there are several key hydrogen bonds (H-bond) were formed in both complexes. Figure 4A showed that Cpd22 formed four H-bonds with Ile62, Val135, and Arg141. For Cpd49, Val135 formed two H-bonds with the pyrazole and nitro group, and Asp133 also formed an H-bond. These H-bond interactions could maintain the specific binding interactions between the ligand and GSK3β (Zhao et al., 2017). Herein, LY2090314, as a positive control, was also docked into the GSK3β protein, and the result was illustrated in Figure 4C . Similar to Cpd49, LY2090314 formed the two H-bond interactions with Asp133 and Val135 of GSK3β ( Figure 4B ). Moreover, the carbonyl group of LY2090314 formed an H-bond with Arg141, similarly, the Arg141 of GSK3β also form H-bond with the carbonyl group of Cpd22 ( Figure 4A ). That may be the reason why LY2090314 contains more potent bioactivity than Cpd22 and Cpd49, because of the more H-bond interactions with GSK3β. Finally, Cpd49 was chosen to investigate the interaction with GSK3α, Figure 4D shows that the binding pose of Cpd49 in the binding site of GSK3α is almost same with that in GSK3β, it is not surprised because of the high sequence identity between GSK3α and β. Although Cpd49 formed three H-bonds with GSK3α, the docking score, -6.783 kcal/mol, was far lower than GSK3β, indicating that Cpd49 preferred to bind with GSK3β.

2D presentations of the interactions between GSK3β and (A) Cpd22; (B) Cpd49; (C) LY2090314; (D) 2D presentations of the interactions between GSK3α and Cpd49 (H-bonds colored in magenta).

## Section: Methods and Materials › Molecular Dynamic Simulations Analysis

To explore the dynamic binding process of the studied inhibitor, Cpd49 with the best bioactivity was submitted to 200-ns MD. Firstly, the backbone RMSD of the complex was calculated and the result illustrated in Figure S3 . The plot showed that the system reached equilibrium after 200 ns simulation. In order to understand the mechanism of ligand adaptation in binding space of GSK3β, the per-residue contributions in ligand binding were calculated and the key residues-inhibitor interactions were rendered in Figure 5A . As the appears at first glance, several residues formed the strong hydrophobic interactions with Cpd49, including Ile62, Ala83, Tyr134, and Leu188, these residues could form the strong non-polar interactions with GSK3β selective inhibitors, which make the dominating force for the high GSK3β affinity (Zhu et al., 2019), meanwhile, Asp133 and Val135 form strong H-bonds with Cpd49, these hydrogen bond interactions are significantly important for the specific GSK3β binding of the selective inhibitors ( Figure 5B ), which is consistent with the docking analysis discussed above. However, Val135 exhibits more favorable contributions to Cpd49 than Asp133. As shown in Figure 5C , the pyrazole group of Cpd49 was closer to Val135 and then formed two H-bonds with Val135. it can be perceived Val135 is a critical residue for selective binding to GSK3β. As shown in Figure 5C , Cpd49 was sandwiched between residues Ala83 and Leu188, and encompassed by residues Ala83 above and residues Leu188 below, that formed strong non-polar interactions which highly improved the binding affinity to GSK3β for Cpd49. Overall, the above results prove that Asp133, Val135, Ala83, and Leu188 may be the key residues for inhibitor binding.

Moreover, four X-ray crystallographic structures of GSK3β complexes, including AMP-PNP (PDB ID 1PYX) (Bertrand et al., 2003) and three inhibitors under clinical investigation (Xu et al., 2019), Alsterpaullone (PDB ID 1Q3W) (Bertrand et al., 2003), AZD2858 (PDB ID 4ACD) (Berg et al., 2012), and CHIR-99021 (PDB ID 5HLN) (Wagner et al., 2016), were chosen to compare to the binding configuration of Cpd49/GSK3β complex. The crystal structure of GSK3β/AMP-PNP was illustrated in Figure 6A . The adenine of AMP-PNP forms two H-bonds with Asp133 and Val135, respectively. Asp133 and Val135 are two key hinge residues, which plays a critical role in the GSK3β specific binding for a selective inhibitor (Pandey and DeGrado, 2016). As shown in Figure 5C , the tetrahydroindazole group of Cpd49 could mimic the adenine of ATP to form the key H-bonds with Asp133 and Val135. Similar H-bond interactions occur in AZD2858 and CHIR-99021 systems ( Figures 6B, C ). Besides, the oxygen atom of the ribose could hydrogen bond to Gln185, and the phosphate group of AMP-PNP could form the H-bonds with Lys85 and Lys183, respectively ( Figure 6A ) (Bertrand et al., 2003). The H-bond with Lys85 is also formed in AZD2858 system, which is caused by the internal hydrogen bond on the pyrazine ring ( Figure 6B ) (Berg et al., 2012), while these interactions all lose in Cpd49/GSK3β system, which may result in lower bioactivity of Cpd49. On the other hand, the hydrophobic interaction is important for the GSK3β affinity. In AMP-PNP system, these residues consist of Ile62, Val70, Ala83, Val110, Leu132, Tyr134, and Leu188 (Bertrand et al., 2003), and Cpd49 could form the similar non-polar interactions, especially with Ile62, Ala83, Tyr134, and Leu188 ( Figure 5A ). The binding mode of Alsterpaullone/GSK3β shows in Figure 6D . First, Alsterpaullone forms two H-bonds with Val135, but unlike Cpd49 system, Alsterpaullone forms a water bridge with Asp133, and the other two water bridges also form between Alsterpaullone and Thr138/Gln185 (Bertrand et al., 2003). Similar to AMP-PNP and AZD2858, Alsterpaullone also could form a strong H-bond with Lys85 ( Figure 6D ). Second, Alsterpaullone also forms strong van der Waals interactions with GSK3β, especially Ile62 and Val70, so is in the CHIR-99021 system ( Figure 6C ) (Wagner et al., 2016), while Cpd49 loses that interaction with Val70 ( Figure 5A ). Thus, all these extra interactions discussed above may lead to the higher GSK3β binding affinity for Alsterpaullone than Cpd49

(A) the Cpd49-GSK3β residues interaction spectrum; (B) 2D presentations of the MD simulation interactions between GSK3β and Cpd49; (C) 3D presentations of the MD simulation interactions between GSK3β and Cpd49.

X-ray crystal structures of (A) GSK3β/AMP-PNP (PDB ID 1PYX); (B) GSK3β/AZD2858 (PDB ID 4ACD); (C) GSK3β/CHIR-99021 (PDB ID 5HLN); (D) GSK3β/Alsterpaullone (PDB ID 1Q3W).

## Section: Conclusion

In the present study, a parallel VS strategy based on multiple GSK3β protein structures was developed to screen against a large chemical library, in which the NBC model combining molecular docking and pharmacophore show a reliable prediction capability. After a series of biochemical studies, two GSK3β inhibitor hits (Cpd22 and Cpd49) were identified from 50 virtual screened compounds, that highlights the high prediction accuracy and the robust reliability of the integrated machine learning-based VS. Besides, the binding modes between GSK3β and two inhibitors were identified by molecular docking, and some key residues critical to GSK3β selectivity were highlighted through MD simulation. We hope that this study would provide some guidance for the virtual screening or design of novel GSK3β inhibitors.

## Section: Data Availability Statement

The data that support the findings of this study are available from the corresponding author upon reasonable request.

## Section: Author Contributions

JZ and JJ developed the study concept and design. YW and KL performed the modeling studies and carried out the data analysis. MW performed the bio-assay evaluation. LX provided software. JZ, YW, and YaC drafted the manuscript. YuC and JJ approved the manuscript.

## Section: Funding

The study was supported by the National Natural Science Foundation of China (No. 21807049 and 81803430), the Fundamental Research Funds for the Central Universities (JUSRP51703A), the Postgraduate Research & Practice Innovation Program of Jiangsu Province (KYCX19_1888), and the Natural Science Foundation of Jiangsu Province (No. BE2019650).

## Section: Conflict of Interest

The authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.

The reviewer HS declared a past co-authorship with one of the authors, LX, to the handling editor.


---

# Intense bitterness of molecules: Machine learning for expediting drug discovery

- **Authors:** Eitan Margulis, Ayana Dagan-Wiener, Robert S Ives, Sara Jaffari, Karsten Siems, Masha Y Niv
- **Issuer:** Computational and structural biotechnology journal
- **Type:** Scientific article
- **Published:** 2020-12-25
- **Language:** en
- **DOI:** 10.1016/j.csbj.2020.12.030
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33510862/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Graphical abstractConceptualization of BitterIntense contribution to optimizing drug development. Red dashed arrow represents the classical drug development process in which the palatability of the drug is assessed in or after clinical trials, with the risk of developing intensely bitter drugs. The green arrow represents the drug development process with BitterIntense, enabling easy assessment of aversive taste in early stages.

## Section: Introduction

The use of sophisticated and highly automated processes in drug discovery has resulted in expedited pipelines and the approval of more than 4,000 medicines as of April 2020 [1]. Yet, a key aspect related to regimen compliance has not been properly addressed. The oral route remains the main way for drug administration [2], with aversive taste of drugs causing swallowing difficulties and compliance problems. This is especially relevant with pediatric medicine, for which encapsulation does not always provide a solution [3], [4], [5]. Even though some bitter-masking agents exist, they are often insufficient for masking or preventing a drug’s intensely bitter taste [4], [5], [6]. Indeed, more than 90% of pediatricians report that a drug’s aversive taste and low palatability are the biggest barriers to completing the medication regimen, leaving children with limited access to “child-friendly” drugs and exposing them to possible harm and insufficient treatment [4], [7]. Because of the potential risks caused by aversive taste of drugs, the Food and Drug Administration (FDA) has added taste events to their Adverse Event Reporting System [8] and expects that all medicines with the potential to be given to children should be assessed for palatability [9], [10]. The problem is also acute for the older population, and the European Medicines Agency (EMA) reflection paper on the development of medicines for geriatrics lists taste as a key consideration for medicine development [11]. Sour or metallic taste can also elicit aversion, but intense bitterness is particularly abundant among drugs, and many of them were shown to activate bitter taste receptors [12], [13]. The challenge imposed by aversive taste in drug development has led to the establishment of several assays for bitterness measurement, including the rat brief access taste aversion (BATA) [14], electronic tongues and human sensory panels [15].

The current pipeline for drug development process includes four main stages: drug design, preclinical phase (animal testing), clinical phases in human and the final review and approval by the medicines regulators including the FDA and the EMA [16], [17]. During the design and preclinical phases, the taste of the drug is usually disregarded. It is evaluated, if at all, only during the clinical phases when the drug is introduced to humans. As a result, in clinical trials with nauseous drugs (usually due to intense bitterness), reduced compliance to the treatment and increased dropout rates have been documented in several cases [18], [19]. In addition, knowledge of the aversive taste of drug candidates enables the selection of a similarly aversive placebo in order to avoid unblinding of the trials [20], [21]. Often, it is only once intense bitter taste is suspected to affect the clinical trial and cause compliance problems, that the palatability of the drug is tested, usually in human taste panels [15]. This may lead to reformulation of the drug and repeat the preclinical and clinical phases. Such detours may delay a potential medicine from getting to the patient for an additional 6 to 24 months, potentially using additional animals, and increasing financial costs. For a moderately successful medicine, this could be a reduction in income estimated at hundreds of millions of dollars.

Bitter taste can be elicited by structurally diverse compounds. Over 1000 bitter-tasting compounds are currently documented in BitterDB. Salts, peptides, fatty acids, polyphenols, alkaloids, terpenoids and compounds from additional chemical families contribute to the wide chemical space of bitter tastants [22], [23]. Bitter compounds vary also in their perceived intensity: quinine and amarogentin were reported as extremely bitter to humans, recognizable at micromolar concentrations. Other molecules, such as caffeine and naringin elicit slightly bitter taste and are typically recognizable at millimolar concentrations [23]. Notably, we showed that bitter compounds are not more toxic than non-bitter compounds [24], questioning the common paradigm that posited the evolutionary role of bitter taste as a marker for toxicity [25], [26].

Bitter compounds are recognized by G-protein coupled receptors subfamily of bitter taste receptors, called T2Rs [27], [28], that harbor 25 functional T2R subtypes in human [29]. While some receptors are broadly tuned with hundreds of diverse ligands, others are very selective with 0–3 known agonists [30], [31]. T2Rs are not only expressed in the oral cavity but also in many extraoral tissues, possessing different physiological roles besides chemosensation of bitter tastants [32], [33]. For example, activation of T2Rs expressed in human airway smooth muscle with inhaled bitter tastants was shown to mediate relaxation of the muscles and decreased airway obstruction in mouse models of asthma [34]. T2Rs expressed in thyrocytes were shown to regulate the production of thyroid hormones and influence the function of the thyroid gland [35]. Surprisingly, a human cohort suggested that polymorphism in T2R42 gene, an orphan bitter taste receptor, is associated with lower thyroid hormone levels [35]. The fact that T2Rs can be expressed in extraoral tissues and that orphan T2Rs can be associated with physiological phenomena may suggest the involvement of T2Rs in health and disease [32] as well as a potential off-target for drugs [36].

We have previously developed BitterPredict [37], which classifies molecules into bitter or non-bitter with over 80% accuracy. Several other machine learning predictors followed suit [38], [39]. In addition, structure-based methods were developed for identification of new agonists for specific bitter taste receptors [12], [40], [41]. Here we are interested specifically in finding intensely or extremely bitter molecules, since these are the ones that are likely to cause compliance problems. This will allow project teams to address very bitter compounds in the early stages of development and focus on bitterness masking for the flagged molecules or deprioritizing them for oral administration.

To establish a machine learning algorithm for intense bitterness, data had to be gathered: we curated data from BitterDB and from a public repository of natural compounds by AnalytiCon Discovery [42], and have measured bitterness intensity of several new compounds using the BATA assay. Next, we successfully trained a new machine learning classifier “BitterIntense” with the ability to assign compounds as “very bitter” (VB) or “not very bitter” (NVB) based on descriptors calculated from their chemical structure. BitterIntense was then used to assess prevalence of VB compounds in datasets of interest in order to elucidate additional attributes of VB compounds as in relation with possible toxic and therapeutic effects.

## Section: Materials and Methods

BATA assay. The rat brief access taste aversion (BATA) model has been demonstrated as a highly translatable tool for screening bitter compounds [14], [43]. Comparison of BATA and human gustatory trials at GlaxoSmithKline (GSK) suggest an average offset of 0.5 log concentration (3-Fold), with rats typically slightly more tolerant to bitter taste than humans [43]. We have chosen the 3 mM IC50 in rat model as a threshold for classifying compound as “very bitter” or “not very bitter”, and 0.1 mM human recognition threshold in human data. This accommodates both the difference between species, and difference between measures (IC50 is the concentration that inhibits 50% of consumption, while recognition threshold is the lowest concentration at which recognition occurs). Studies at GSK were performed using Davis Rig MS-160 lickometers (DiLog Instruments, Tallahassee, USA) and as described by Soto et al. [14] with the following exceptions: 12 male Sprague Dawley Crl:CD (SD) rats (number determined following power analysis of historic GSK data), 6 to 7 weeks of age on arrival, supplied by Charles River UK (Marston, UK) were used per study. Rats were housed in groups of either two or four, kept on a 12 h light: dark cycle, 19-21oC, 45–55% humidity. 5LF2 rodent diet (LabDiet, Missouri, USA) was fed ad libitum. Animal grade drinking water (AGW) was reverse osmosis filtered, UV treated and provided ad libitum between water restriction periods. All testing occurred during the light period. Rats were water restricted for 21 h prior to each test session to ensure sufficient thirst for the rats to attempt to lick all solutions presented. Each test session was limited to a maximum of 30 min, following which rats were returned to their home cages and given free access to AGW for a minimum of 2.5 h before commencement of the next water restriction period. Following completion of each study, rats were health assessed by a named veterinary surgeon and returned to non-naïve stock. A minimum one-week washout period was provided prior to use of rats on subsequent BATA studies.

All compounds presented during BATA studies were fully solubilised across a range of concentrations with 0.5 log dose separation to generate concentration response curves. Lick counts of zero and one were excluded from data sets due to being deemed an insufficient attempt to lick a solution and therefore not related to palatability. Lick responses were modelled using a three parameter logistic function with the minimum constrained to zero (R v.3.5.1, Foundation for Statistical Computing, Vienna, Austria). Lick response was expressed as a percentage of the median AGW response within each study, 95% confidence interval. The concentration of API that elicited lick rates equivalent to 50% of the median AGW was then calculated and deemed the IC50.

All animal work conforms to the UK Animals (Scientific Procedures) Act, European Directive 2010/63/EU and the GSK Policy on the Care, Welfare and Treatment of Animals. All protocols were approved as part of the GSK Scientific and Ethical Review Forum and carried out in accordance with the appropriate project licence issued by the UK Home Office.

For all studies performed at GSK, commercially available compounds were sourced from Sigma Aldrich (Gillingham, UK). GSK compounds were supplied by the internal dispensary.

BitterDB and Analyticon data. Data on bitterness intensity and chemical structures for the training and testing of the model were also obtained from BitterDB [23] and Analyticon’s repository on Kaggle website [42]. There are about 180 compounds with known sensory thresholds (out of 217 that have any kind of sensory data, provided in Supplementary Material). Compounds that were verbally described as intensely bitter, in most cases possessed bitter recognition thresholds below 0.1 mM and compounds that were described as slightly bitter, possessed thresholds with values higher than 0.1 mM. Based on this, all compounds with bitter recognition threshold below 0.1 mM, were classified as “very bitter”, and compounds with bitter recognition threshold above 0.1 mM were classified as “not very bitter”.

For compounds with unknown bitter recognition thresholds, we considered the taste descriptions. For example, we classified compounds as very bitter if they were described as “Intensely/extremely bitter”, “more bitter than quinine”, etc. On the other hand, compounds that were described as “slightly/weak bitter” were classified as not very bitter. The addition of the non-bitter subset had shown to be beneficial in preliminary testing of the classifier (not shown), increasing the ability to distinguish between very bitter compounds and not very bitter compounds.

Chemical families analysis. The chemical families of the compounds in the training set were extracted using ClassyFire webserver [44].

Datasets preparation. After obtaining the SMILES strings of the compounds, we uploaded the compounds to Maestro (Schrödinger Release 2017–2: MS Jaguar, Schrödinger, LLC, New York, NY, 2017). We generated 3D structures using ligprep and Epik (Schrödinger Release 2017–2: LigPrep, Epik, LLC, New York, NY, 2018) in pH 7.0 ± 0.5. All compounds were desalted when available, retaining the bigger ion and excluding the smaller counter ion. In general, if structures had additional molecules, these were removed. We retained the original chirality of compounds when specified, otherwise we generated additional stereoisomer per ligand. For each compound, the conformer with the lowest energy was extracted and used. When 2 stereoisomers where generated for one compound, we kept both structures. Compounds that could not be neutralized were excluded from the sets due to the limitations of calculating QikProp descriptors. All the datasets in this current study were prepared in the same protocol as mentioned above.

Descriptors calculation. Three sets of descriptors were calculated for the prepared 3D structures using Canvas (Schrödinger Release 2017–4: Canvas, Schrödinger, LLC, New York, NY, 2017): Physicochemical descriptors, Ligfilter descriptors (moieties, atoms and functional groups) and QikProp descriptors (ADME descriptors). For the QikProp descriptors, additional PM3 properties were calculated as well (Schrödinger Release 2017–4: QikProp, Schrödinger, LLC, New York, NY, 2017). Compounds that failed to calculate one of the descriptors were excluded from the analysis.

Dataset split for training, test and hold-out sets. All the collected compounds were divided randomly into training, test and hold-out set using functions from python’s Scikit-learn package. The training set consisted of 493 compounds: 169 very bitter compounds and 324 not very bitter compounds.

The test set consisted of 123 compounds: 43 very bitter compounds and 80 not very bitter compounds and was used for testing the performance of the model during the training. The hold-out set consisted of 105 compounds: 31 very bitter compounds and 74 not very bitter compounds. We have established this set for final evaluation of the model, as an external set of compounds that the model has never encountered before.

Distributions of selected descriptors (MW, AlogP, Ring count and QPlogHERG) in the training, test and hold-out sets are shown in Supplementary Fig. S3.

Model construction and fitting. The XGBoost model was constructed and fitted using Python 3.7.5, in Spyder 3.7 environment. Relevant packages: Scikit-learn (version 0.21.3), XGBoost (version 0.9), Numpy (version 1.17.4), pandas (version 0.25.3), matplotlib (version 3.1.1) and seaborn (version 0.9.0).

An early stopping approach was used in the training process, in which the performance of a model is monitored during the training process which is stopped once the performance ceased improving, see Figs. S1 and S2. The evaluation metrics for the early stopping were: logarithmic loss [45] and Binary classification error rate (defined as = #(wrong cases)/#(all cases)).

Feature selection. The most contributing features were selected according to their feature importance gain score, calculated using XGBoost library in python [46]. We constructed a loop that tested the changes in the accuracy of the model by setting different thresholds of the gain scores in order to select the best features. When setting the threshold on 0.004, we maintained 55 features (out of 235 original features) that had the most contribution to model, obtaining 83% accuracy.

Parameter tuning. The parameters of the XGBoost algorithm were tuned using sklearn’s GridSearchCV from sklearn.model selection module [47]. The number of cross validation folds was set to 10 and the scoring method was set for ‘f1 score’ in order to improve the precision and the recall. Parameter tuning was performed on the training set using the initial fitted model, suggesting that the optima parameters are: colsample_bytree = 0.6, gamma = 0.5, max_depth = 5. In brief, colsample_bytree is the fraction of features that will be randomly sampled to construct each decision tree, gamma represents the minimum loss reduction required to make a further partition on a leaf node of the decision tree and max depth represents the maximum depth of a tree. In addition, the parameter (scale_pos_weight) that helps with unbalanced data was tuned by the ratio between positive and negative observations in the training set to 1.9.

Evaluation of the performance of the model. After calculating the number of true positives (TP), true negatives (TN), false positives (FP) and false negatives (FN), we evaluated the model using four metrics:Accuracy=TP+TNTP+FP+TN+FNPrecision=TPTP+FPRecall/Sensitivity=TPTP+FNSpecificity=TNTN+FPF1score=2∗Precision∗RecallPrecision+Recall

Toxicity data. FocTox dataset consists of FAO/WHO food contaminants list and a list of extremely hazardous substances defined in section 302 of the U.S. Emergency Planning and Community Right-to-Know Act. CombiTox dataset is a combination of two datasets (The Toxin and Toxin‐Target Database version 2.0 (T3DB) and DSSTox—the Distributed Structure‐Searchable Toxicity Database). The datasets were taken from the paper of Nissim I. et al. [24].

Hepatotoxicity data. All hepatotoxicity descriptors were extracted from FDA’s DILIrank [48] dataset which is an updated version of the LTKB (Liver Toxicity Knowledge Base) Benchmark dataset [49]. DILIrank consists of 1,036 FDA-approved drugs with known hepatotoxicity descriptors and liver toxicity risk assessments. The compounds in the dataset were prepared as explained in “Datasets preparation” section.

External datasets. DrugBank (version 5.1.5) consist of experimental and approved drugs [1], and Natural products atlas (NPatlas, version 2019_08) [50] were downloaded from their official websites. Compounds were prepared according to the protocol of “Datasets preparation” section. COVID 19 drugs and their targets were retrieved from “IUPHAR/BPS Guide to Pharmacology” [51]. After excluding the antibodies and compounds without chemical structure we prepared the remaining 34 compounds according to the “Datasets preparation” section.

Data Analysis and visualization of the data. All the data in this current study was analyzed using Pandas library [52] and visualized with Matplotlib [53] library in Python.

## Section: Results

Establishment of positive and negative sets. 34 compounds were obtained from behavioral studies using the rat brief access taste aversion (BATA – see Materials and Methods). Additional compounds were pulled from the BitterDB [23], and the Analyticon repository of natural compounds on kaggle [42]. The compounds were classified into 2 classes: “Very bitter” (VB) and “Not very bitter” (NVB) using the following criteria: Compounds with sensory bitter recognition threshold below 0.1 mM; or molecules with taste description that states “extremely bitter” or “intensely bitter” etc., were included in the VB class (246 compounds). Compounds with bitter recognition threshold above 0.1 mM or molecules with taste description that includes “slightly bitter” or “weak bitter taste” etc., were included in the NVB class (323 compounds). The BATA test measures aversion, which is assumed to be driven mainly by bitterness. The IC50 achieved for each compound in the BATA test was used to classify compounds using the following criteria: molecules with IC50 below or equal to 3 mM were classified as VB. Molecules with IC50 above 3 mM were classified as NVB. In addition, 152 non-bitter compounds were added to the NVB class from the negative set used previously in BitterPredict [37] to enable correct prediction (namely, they should be classified as NVB) also for non-bitter compounds. For practical purposes pursued here, we group non-bitter and not very bitter into the same category. The non-bitter compounds that were included in the negative set were randomly selected and had MW greater than 250 g/mol to match the MW of very bitter compounds.

Chemical families analysis. Bitter compounds are structurally diverse and, and many chemical families can elicit bitter taste [22]. Drug-like molecules and phytonutrients, such as flavonoids, isoflavones, terpenes, and glucosinolates can elicit bitter taste with various intensities [54]. Here we analyze which chemical families are enriched with intensely bitter compounds. The chemical families for VB and NVB compounds in the training set are represented in Fig. 1. The VB class is enriched with triterpene saponins and triterpenes in general, while NVB class is broadly represented by different chemical families. The results suggest that triterpene saponines are the most abundant VB compounds in our training set. Interestingly, this family is also found among the top chemical families of NVB molecules, illustrating that taste intensity can not be simply deduced based on the chemical family of the compound.Fig. 1Representation of chemical families in the training set (A) – Top chemical families represented in the dataset of very bitter compounds. (B) - Top chemical families represented in the dataset of not very bitter compounds. The compound on the lower left side (Asperosaponin VI) is a representative of very bitter triterprene saponins, the compound on the lower right (Nitrosaccharin) is a representative of not very bitter benzothiazoles. Deriv. = derivatives.

Training the classifier. Physicochemical, Ligfilter and Qikprop descriptors were calculated for the compounds in the dataset (see Materials and Methods). 15% of the compounds (105 compounds) were chosen randomly and left out of the training set, as a hold-out test set for final evaluation of the model. The other 616 compounds were randomly divided into: 80% training set (493 compounds) and 20% internal test set (123 compounds). Extreme Gradient Boosting (XGBoost) algorithm was chosen for this classification task. XGBoost is a popular and powerful decision-tree-based ensemble method that uses optimized gradient boosting techniques and is known to perform well with small to medium size datasets [46].

Since the training set is rather small, we extracted the highest contributing features (see Materials and Methods) in order to avoid overfitting. 55 features were selected out of 235 for the model training. Further details are described in the Methods section.

BitterIntense Performance. Evaluation of the model’s performance (Table 1) was carried out on three sets: training set (with cross-validation, k-fold = 10), test set, and hold-out set. BitterIntense was able to achieve over 80% accuracy across the different datasets. The precision, which indicates the ratio between the true positives and all the positive assignments (true positives and false positives), was on average 80% on training set, 71% on the test set and 63% on the hold-out set. Recall, which indicates how well the model identified the true positives (ratio between true positives and the sum of true positives and false negatives) was on average 85% on the training set, 86 on the test set and 77% on the hold-out set. In addition, we calculated the F1-score which is another metric for the accuracy of the model by taking into account both the precision and the recall values (defined as the harmonic mean of precision and recall, see Methods section): for the training set F1-score was 82 ± 5%, for the test set 78% and for the hold-out set 70%. In general, we observed higher recall values than precision values, suggesting that our model has less false negatives than false positives. This result is in line with our goal to maximize identification of very bitter compounds.Table 1BitterIntense performance on the training, test and hold-out sets. Training set evaluation was done using k-fold cross validation with k = 10. The results in the training set column represent the mean metric with its standard deviation across 10 iteration of cross validation.Training setTest setHold-out set(493 compounds)(123 compounds)(105 compounds)Accuracy (%)87 ± 58380Precision (%)80 ± 87163Recall (%)85 ± 48677F1 score82 ± 57870Specificity (%)8181

Important features. The feature importance was measured in XGBoost by the “gain” method which is the average gain of splits which use the feature in the prediction process. Higher gain value implies greater importance of the feature. The top 15% of features are represented in Fig. 2 and suggest that molecule’s size and polarizability are the most influential factors for bitterness level. Fitting the model using the heavy atom count feature only, results in 70% accuracy on the training set, with recall and precision of 70% and 58% respectively. This result emphasizes the importance of molecular size and suggests correlation between the size of the molecule and the bitterness intensity.Fig. 2Top 15% important features in the model. The importance is calculated by the average gain of splits which use the feature in the prediction process in each tree in the XGBoost model. The heavy atom count, molar refractivity, number of likely metabolic reactions (metab), number of tertiary amines and amide groups, π (carbon and attached hydrogen) component of the solvent accessible surface area (PISA), hydrophobicity (AlogP), hydrophobic component of the solvent accessible surface area (FOSA) and Predicted IC50 value for blockage of hERG channels (QPlogHERG).

Relationship between bitterness intensity and toxicity. Though bitter taste is often regarded as a marker for toxicity that guards against consuming poisons [55], our previous analysis showed that bitter compounds are not necessarily toxic and vice versa [24]. We explored whether similar conclusions hold for VB compounds, by comparing toxicities of VB and NVB compounds. BitterIntense was applied to toxic compounds from FocTox and CombiTox datasets, collated in previous work [24]. The FocTox dataset consists of FAO/WHO food contaminants and extremely hazardous substances. Out of 289 compounds, only 25 were predicted to be very bitter (pVB, 8.6%). CombiTox, a manually curated dataset of toxic compounds [24], holds ~134,000 compounds, out of which 12% were pVB, suggesting that toxic substances are not necessarily very bitter and in fact, most of the toxicants are predicted to be NVB. Thus it appears that only ~10% of toxic compounds are intensely bitter.

We further checked the possible connection between the level of bitterness and liver toxicity (hepatotoxicity) and cardiac toxicity. Hepatotoxicity is the most common cause for the discontinuation of clinical trials on a drug, and the most common reason for an approved drug’s withdrawal from the marketplace [48], [56]. Drug-induced liver injury (DILI) has been listed as the leading cause of acute liver failure in the USA in 2002 [57], and DILI has become an important concern in the drug discovery process. A possible connection between the level of bitterness and hepatotoxicity could suggest that the level of bitterness is a potential marker for such toxicity. We predicted the level of bitterness of drugs with known hepatotoxicity descriptors, taken from DILIrank dataset [48].

Most of the drugs in the dataset (729 compounds) were predicted as NVB (pNVB), and only 258 were predicted as VB. The pVB drugs do not appear to be more hepatotoxic than the pNVB drugs: the most hepatotoxic class (class number 8, Fig. 3A) as well as the “Most DILI concern” category (Fig. 3B) are actually enriched with pNVB drugs.Fig. 3Bitterness levels of drugs and their hepatotoxicity descriptors. (A) Distribution of pVB (silver) and pNVB (black) drugs across severity classes of hepatotoxicity. (B) Distribution of pVB and pNVB drugs across DILI concern categories. The severity of hepatotoxicity increases from left to right in all figures.

Cardiac toxicity is a possible side effect of many anti-cancer drugs [58] and other drugs, causing heart problems as well as sudden cardiac death [59]. For this reason, the FDA has required almost all new drugs to be assessed for cardiac toxicity, which led to discontinuation of clinical trials and even withdrawal of drugs from the market [60]. One of the mechanisms of cardiotoxicity is blockage of voltage-gated potassium channels called the hERG channels [61]. QPlogHERG is a common descriptor for predicted IC50 value for blockage of hERG K + channels, which indicates cardiac toxicity [62], where values below −5 are of concern [63]. As QPlogHERG appeared in the top features list of our model (Fig. 2), we checked whether very bitter compounds tend to be more toxic for the heart. QPlogHERG values were already calculated for our training and test sets as part of the descriptors calculation process (see methods section), we have used these values to compare the QPlogHERG values of VB and NVB compounds. Our results (Fig. 4) suggest that VB compounds are more cardiotoxic than NVB compounds, where the median value for VB compounds is −5.2 (considered cardiotoxic) and the median for NVB compounds is −4.Fig. 4QPlogHERG values of VB (grey) and NVB (white) compounds. Statistical significant difference was observed using Mann-Whitney test, n = 721, P-value < 0.0001.

Very bitter drugs and their potential therapeutic effects. Since VB drugs are more likely to cause compliance problems, we applied BitterIntense on all compounds (approved and experimental drugs) from Drugbank (5.1.5)1 to evaluate the abundance of VB drugs (Fig. 5). Out of 10,170 compounds that were able to pass through our predictor, 23.6% were pVB. Specifically, 18% of experimental drugs and 26% of approved drugs are pVB. For comparison, in microbial natural products (NPatlas, version 2019_08, n = 24,805) [50], 47.7% were pVB. Thus only ¼ of drug candidates, but about half of the microbial natural products are likely to be VB.Fig. 5Prevalence of pVB compounds (silver) and pNVB compounds (white) across 3 datasets: NPatlas, DrugBank and COVID19 drugs. Statistical significant difference in the proportions of pVB compounds was observed using Two Proportion Z-Test.

Are there specific therapeutic indications or targets that are enriched with pVB drugs? We focused here on a highly relevant disease, the COVID19. The COVID19 pandemic is spreading throughout the world, with millions of confirmed cases and hundreds of thousands of deaths, according to reports by the World Health Organization that were published in June 2020 [64]. Some drugs have been suggested for treating COVID-19 patients, but no drug has yet been approved fully and officially by the FDA. Several drugs are currently under study and clinical trial, for example: Remdesivir, an adenosine analog that was previously tested as a potential drug for Ebola and as anti-viral drug [65], showed promising result in COVID19 patients and thus was granted an FDA Emergency Use Authorization on 1 May 2020 [66]. Interestingly, taste and smell loss [67], including impairment of the bitter taste, are reported by many COVID19 patients [68]. We applied BitterIntense to possible COVID19 drug candidates and compared it to the general abundance of pVB drugs in DrugBank. A list of ligands related to COVID19 in “Coronavirus Information – IUPHAR/BPS Guide to Pharmacology” [51] was retrieved. After excluding antibodies and compounds without chemical structure (Fig. 5), among 34 drug candidates, 41.2% were pVB. The proportion of pVB drugs among COVID19 potential drugs, is thus significantly higher than in DrugBank (23.6%)(P-value = 0.016), suggesting that VB drugs may be more abundant in the COVID19-related list than in general drugs. No evident difference was found between the main targets of pVB and NVB COVID19-related drug candidates.

Representation of chemical families in the training set (A) – Top chemical families represented in the dataset of very bitter compounds. (B) - Top chemical families represented in the dataset of not very bitter compounds. The compound on the lower left side (Asperosaponin VI) is a representative of very bitter triterprene saponins, the compound on the lower right (Nitrosaccharin) is a representative of not very bitter benzothiazoles. Deriv. = derivatives.

BitterIntense performance on the training, test and hold-out sets. Training set evaluation was done using k-fold cross validation with k = 10. The results in the training set column represent the mean metric with its standard deviation across 10 iteration of cross validation.

Top 15% important features in the model. The importance is calculated by the average gain of splits which use the feature in the prediction process in each tree in the XGBoost model. The heavy atom count, molar refractivity, number of likely metabolic reactions (metab), number of tertiary amines and amide groups, π (carbon and attached hydrogen) component of the solvent accessible surface area (PISA), hydrophobicity (AlogP), hydrophobic component of the solvent accessible surface area (FOSA) and Predicted IC50 value for blockage of hERG channels (QPlogHERG).

Bitterness levels of drugs and their hepatotoxicity descriptors. (A) Distribution of pVB (silver) and pNVB (black) drugs across severity classes of hepatotoxicity. (B) Distribution of pVB and pNVB drugs across DILI concern categories. The severity of hepatotoxicity increases from left to right in all figures.

QPlogHERG values of VB (grey) and NVB (white) compounds. Statistical significant difference was observed using Mann-Whitney test, n = 721, P-value < 0.0001.

Prevalence of pVB compounds (silver) and pNVB compounds (white) across 3 datasets: NPatlas, DrugBank and COVID19 drugs. Statistical significant difference in the proportions of pVB compounds was observed using Two Proportion Z-Test.

## Section: Discussion and conclusions

BitterIntense was developed to easily classify compounds as Very bitter (VB) or Not very bitter (NVB) and has achieved above 80% accuracy on test set. The model was trained with chemically diverse compounds. The most important features in the classification task of VB vs NVB compounds are the heavy atom count and the molar refractivity (a measure of polarizability). Training the model with the single feature of heavy atom count resulted in a model with 70% accuracy, with recall and precision of 70% and 58% respectively. This means that VB molecules are often larger than NVB molecules, but additional features greatly improve the predictions, reaching average accuracy of 87%, recall of 85% and precision of 80% on the training set. One possible explanation for the correlation between the size of the molecule and the bitterness intensity is that bigger molecules can interact with more residues in the binding site of the receptor, resulting in strong binding and slow dissociation. The correlation between size and long residence time of ligands in binding pockets of receptors, including GPCRs was shown [69], [70]. In addition, larger number of heavy atoms was shown to correlate with selectivity of bitter molecules towards T2Rs (namely, activating a small number of T2R subtypes) [30] emphasising the importance of this descriptor for bitterness perception.

In addition, BitterIntense was used for analysis of connection between toxicity and the level of bitterness of molecules. Our results suggest that compound that are considered acute toxic or hepatotoxic for human are not necessarily predicted to be very bitter. There are several possible explanations for this trend: some bitter compounds that activate T2Rs were also shown to interact with Cytochrome P450 enzymes (CYP) [71], promiscuous monooxygenases involved in metabolism of drugs and xenobiotics in the human body [72]. Perhaps VB and pVB drugs interact differently or even with stronger affinity with CYP enzymes, possibly explaining the differences in the hepatotoxic effect. This hypothesis could be tested in future work. Furthermore, activation of extraoral T2Rs might contribute to the decreased risk for hepatotoxic effect of the very bitter drugs. Activation of gut T2Rs was shown to lead to detoxification by upregulating the transcription of xenobiotic efflux pumps [73]. However, our results reveal that VB compounds have significantly lower QPlogHERG values than NVB compound, suggesting that VB compounds could be more cardiotoxic than NVB by blocking hERG channels, in line with previous work that found hERG channels among off-targets of bitter compounds [12]. Interestingly, T2Rs are also expressed in the heart, which raises the possibility that bitter compounds may both activate cardiac T2Rs [74] and block hERG channels [12]. In summary, our analysis shows that VB and pVB drugs tend to be less harmful as far as acute toxicity and hepatotoxicity, but have more potential to be cardiotoxic than NVB compounds. The possible underlying mechanisms require further study, while VB and pVB drug candidates should be kept in the drug discovery process with potential aversiveness (but not necessarily toxicity) flagging.

Our results suggest that (experimental and approved) drugs tend to be less enriched with pVB compounds as compared to random dataset of microbial natural products. Furthermore, drugs suggested for potential repurposing for COVID-19 targets, tend to include more pVB compared to general population of drugs, raising the question of potential beneficial effect of bitterness or involvement of bitter taste receptors in the disease, interesting also in view of taste loss being one of the symptoms of the disease [68]. However, as it appears that many COVID-19 patients temporarily lose taste sensitivity [68], the aversive taste of orally administered drugs may be actually less problematic for administration in this case. While the potential involvement or mediation of bitter taste receptors in COVID19 is unclear, the results further highlight the importance of flagging - but not excluding from the pipeline – of pVB drug candidates.

BitterIntense is a quick and easy method that enables flagging of intensely bitter compounds during early stages of drug development, and can thus potentially reduce financial costs, animal testing and the lead time to the patients. The ability to detect pVB drugs in early stages not only will accelerate the drug development process but will also promote the development of more palatable drugs suitable for children and geriatric patients. In addition, BitterIntense could also be of interest for biotech and foodtech companies that are working on bioactive molecules, artificial sweeteners or natural products of plants that are developed to be integrated in food products. Thus, our proposal is to integrate computational taste prediction along other computational tools within discovery and development of new bioactive compounds.

## Section: Declaration of Competing Interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.


---

# Investigating Core Signaling Pathways of Hepatitis B Virus Pathogenesis for Biomarkers Identification and Drug Discovery via Systems Biology and Deep Learning Method

- **Authors:** Shen Chang, Lily Hui-Ching Wang, Bor-Sen Chen
- **Issuer:** Biomedicines
- **Type:** Scientific article
- **Published:** 2020-08-31
- **Language:** en
- **DOI:** 10.3390/biomedicines8090320
- **Source:** https://pubmed.ncbi.nlm.nih.gov/32878239/
- **Licence:** CC-BY

## Page 1 (Section: Introduction )

biomedicines
Article
Investigating Core Signaling Pathways of Hepatitis B
Virus Pathogenesis for Biomarkers Identiﬁcation and
Drug Discovery via Systems Biology and Deep
Learning Method
Shen Chang 1, Lily Hui-Ching Wang 2
and Bor-Sen Chen 1,*
1
Laboratory of Automatic Control, Signal Processing and Systems Biology, Department of Electrical
Engineering, National Tsing Hua University, Hsinchu 30013, Taiwan; s107061595@m107.nthu.edu.tw
2
Institute of Molecular and Cellular Biology, National Tsing Hua University, Hsinchu 30013, Taiwan;
lilywang@life.nthu.edu.tw
*
Correspondence: bschen@ee.nthu.edu.tw
Received: 6 July 2020; Accepted: 21 August 2020; Published: 31 August 2020


Abstract: Hepatitis B Virus (HBV) infection is a major cause of morbidity and mortality worldwide.
However, poor understanding of its pathogenesis often gives rise to intractable immune escape and
prognosis recurrence. Thus, a valid systematic approach based on big data mining and genome-wide
RNA-seq data is imperative to further investigate the pathogenetic mechanism and identify biomarkers
for drug design. In this study, systems biology method was applied to trim false positives from
the host/pathogen genetic and epigenetic interaction network (HPI-GEN) under HBV infection
by two-side RNA-seq data. Then, via the principal network projection (PNP) approach and the
annotation of KEGG (Kyoto Encyclopedia of Genes and Genomes) pathways, signiﬁcant biomarkers
related to cellular dysfunctions were identiﬁed from the core cross-talk signaling pathways as drug
targets. Further, based on the pre-trained deep learning-based drug-target interaction (DTI) model
and the validated pharmacological properties from databases, i.e., drug regulation ability, toxicity,
and sensitivity, a combination of promising multi-target drugs was designed as a multiple-molecule
drug to create more possibility for the treatment of HBV infection. Therefore, with the proposed
systems medicine discovery and repositioning procedure, we not only shed light on the etiologic
mechanism during HBV infection but also eﬃciently provided a potential drug combination for
therapeutic treatment of Hepatitis B.
Keywords: hepatitis B virus infection; pathogenesis; host/pathogen interspecies genetic and epigenetic
network (HPI-GEN); systems medicine discovery; drug-target interaction (DTI) model; deep learning;
multiple-molecule drug
1. Introduction
Hepatitis B Virus (HBV) infection remains a prevalent health challenge worldwide, and is
greatly associated with substantial morbidity and mortality due to serious liver diseases, such as
hepatitis, ﬁbrosis, cirrhosis, and even hepatocellular carcinoma [1]. According to the latest report of
World Health Organization (WHO) [2], HBV aﬀected an estimated 257 million people and causing
600,000 deaths per year. While current therapies seek to control the progression of the disease,
life-long treatment and surveillance are still needed because resistance develops during treatment and
reactivation often occurs after medication discontinuation [3,4]. In recent years, dedication to new
drug design and immunotherapy development has been made by researchers to hopefully silence
HBV in infected hepatocytes [5,6]. However, the host/pathogen cross-talk mechanism contributing
Biomedicines 2020, 8, 320; doi:10.3390/biomedicines8090320
www.mdpi.com/journal/biomedicines

## Page 2 (Section: Introduction )

Biomedicines 2020, 8, 320
2 of 48
to the development and persistence of HBV infection requires further investigation, and its current
therapies are still inadequate. Thus, new treatment options are needed to achieve a better therapy for
HBV-infected patients.
Even so, de novo drug discovery is particularly an expensive, time-consuming, and high-risk
process, let alone exploring a drug to eradicate HBV from patients, which is generally believed
arduous [4,7,8]. Conventionally, the pipelines of drug development from laboratory to market take
nearly average 13 to 15 years and cost approximately two to three billion U.S. dollars, in which about
10% of all drugs that start from pre-clinical trials ever make it to actual human testing [9,10]. Fortunately,
as the advancement of biological science drives the progress of high-throughput functional genomics
and proteomics technology, novel experimental and bioinformatics methods have not only accelerated
the deciphering of protein interactions, but also given rise to the construction of networks for signaling
pathways and protein complex identiﬁcation in speciﬁc diseases [11]. Meanwhile, based on the
manifold data types from wet-lab experiments, several computational approaches have been suggested
to predict biological networks for expediting the modeling of functional pathways so as to exemplify the
molecular mechanisms of cellular processes. Researchers are thereby being empowered to profoundly
explore the complicated and mysterious mechanisms of biological systems for better investigating
the potential drug targets [12]. On the other hand, with the development of molecular biology, drug
repurposing, also known as drug repositioning, was proposed to reduce the time spent and the capital
expenditure. The process of drug repositioning is to ﬁnd new use outside the scope of the original
medical indication for existing drugs [13]. Its prospect for new clinical indications is promising, since
compared with other drug development strategies, a repositioned drug could be instantly put into
preclinical testing and clinical trials for its safety and reliability proven in humans.
Nonetheless, the commonly used correlation networks in bioinformatics applications are often
based on oversimpliﬁed algorithms.
As inherent diﬃculties appear in assessing the impact of
microRNA (miRNA), long non-coding RNA (lncRNA), epigenetic modiﬁcation, microenvironment
factors, etc., hardly can these networks mirror the complicated mechanisms of factual biological
systems. In addition, while wide doses of the repositioned drugs can be tested using in vitro and
in vivo experiments, it takes great time and eﬀort. Therefore, to discover potential drugs for the
treatment of HBV-infected patients, the development of a systematic procedure in computational
framework based on potent models and existing data is indispensable.
In this study, we employed the systems biology technique to identify the signiﬁcant biomarkers
from the host/pathogen interspecies genetic and epigenetic interaction network (HPI-GEN) through
two-side RNA-seq data during HBV infection. Subsequently, with the analysis of these biomarkers by
the proposed drug discovery and repositioning procedure, potential combinations of multi-targets
drugs were recommended to the clinical trials of Hepatitis B therapy. By and large, the process can be
subdivided into a few steps: (1) Construct candidate HPI-GEN composed of host/pathogen interspecies
protein-protein interaction network (HPI-PPIN) and host/pathogen interspecies gene regulation
network (HPI-GRN) by big data mining. (2) Prune the false positives in candidate HPI-GEN by system
identiﬁcation analysis with the assistance of two-side proﬁle RNA-seq data and Akaike Information
Criterion (AIC) to identify the real HPI-GEN between host and pathogen. (3) Extract the core HPI-GEN
from real HPI-GEN via principal network projection (PNP) approach. (4) Investigate the core signaling
pathways related to manifold cellular function (especially host inﬂammatory and immune response,
pathological anti-apoptosis, and cell survival) in the core HPI-GEN by the annotation of KEGG
(Kyoto Encyclopedia of Genes and Genomes) pathways to gain insights into the etiologic mechanism
of HBV infection. (5) Select the signiﬁcant biomarkers related to pathological cellular dysfunctions.
(6) Predict the candidate drugs from available drugs for the selected signiﬁcant biomarkers by the
pre-trained deep learning-based drug-target interaction (DTI) model. (7) Consider general criteria
for drug design speciﬁcations including regulation ability, toxicity, and sensitivity to further sift out
the promising drugs. (8) Combine these agreeable drugs as a potential multiple-molecule drug for
possible therapeutic treatment of Hepatitis B. It is worthwhile to note that instead of a single drug,

## Page 3 (Section: Materials and Methods )

Biomedicines 2020, 8, 320
3 of 48
a combination of promising drugs was proposed for the treatment to slow or even prevent inherent or
adaptive drug resistance through the simultaneous blockade of multiple targets or pathways [14].
Nowadays, researches have been dedicated to drug discovery and design, while few of them
propose an integral end-to-end systematic procedure from identifying signiﬁcant biomarkers based
on pathogenic mechanism to recommending promising drugs for one disease. Here, we dig into the
pathogenic characters of viral proteins played on the pathogenesis to select the potential drug targets
from two-side RNA-seq data and reinterpret the role of available drugs based on a pre-trained deep
learning-based DTI model through big drug-target interaction data, which gives an alternative way for
systems drug discovery and repositioning to overcome HBV infection.
2. Materials and Methods
2.1. The Construction of the HPI-GEN in HepaRG Cell Line during HBV Infection and the Application of Deep
Learning-Based DTI Model for New Drug Design: An Overview
To gain new insight into the molecular mechanism of HBV infection, candidate cross-talk HPI-GEN,
which consists of candidate intraspecies, candidate interspecies PPIN between host and pathogen,
and candidate HPI-GRN encompassing regulatory networks between host gene, pathogen gene,
host miRNA and host lncRNA, was constructed by big data mining and preprocessing of host/pathogen
gene/miRNA/lncRNA expression from online database.
Given that the information for interspecies PPIN construction is insuﬃcient, in addition to
interactions attained from bio-databases, data ampliﬁcation technique through nature-linguistic
programming (NLP) and web scrapping was introduced to expand the dataset. Then, for identifying
real HPI-GEN, a systematic identiﬁcation approach was exploited based on the genome-wide RNA-seq
data of HepaRG cells and Hepatitis B Virus under HBV infection. In addition, to deal with the highly
complicate real HPI-GEN, we employed PNP method to extract core network structure consisted of
the top 3000 nodes with highest energy. Such eﬀective approach beneﬁts us to investigate the core
signaling pathways for establishing the crucial molecular pathogenic mechanism to identify signiﬁcant
biomarkers that contribute to the progression of HBV infection. Finally, following the drug discovery
procedure, we built the deep learning-based DTI model to identify the potential multi-target drugs to
target their signiﬁcant biomarkers for therapeutic treatment of HBV infection.
2.2. Big Data Mining and Data Preprocessing of RNA-seq Data for Human and Pathogen
In this study, two-side sequencing-based dataset was obtained from the Gene Expression Omnibus
(GEO) at the National Center for Biotechnology Information (NCBI). We obtained the data recorded by
Mueller et al. [15], containing human and virus genomes with the time-course through GEO series
with accession number GSE101575 [15]. The raw data of the dataset, which contains 27,267 human
genes and 4 HBV genes, involves the gene expression proﬁles of human HepaRG cells from three
patients during HBV infection at 6, 9, 12, and 24 h post reactivation with drug (RG7834) treatment
and without. Only the data without medication administration was deployed to the ensuing system
identiﬁcation process.
To unravel the cellular mechanism during HBV infection, core signaling pathways identiﬁed
from HPI-GEN are requisite.
The candidate HPI-GEN, involving many experimental data and
computational predictions from numerous databases, consists of multiple networks. Among them,
the candidate human PPIs were obtained from the Biological General Repository for Interaction
Datasets database (BioGRID) [16], DIP [17], BIND [18], IntAct [19], and MINT [20]; the candidate
human miRNA and lncRNA regulations were individually obtained from Target Scan Human
database [21], and CircuitDB [22]; the candidate regulations between human transcription factors
and their targets were according to the Integrated Transcription Factor Platform database (ITFP) [23],
the Human Transcriptional Regulation Interactions database (HTRIdb) [24], and the Transcription
Factor database (TRANSFAC) [25]; the candidate host-pathogen interspecies PPIs were obtained from

## Page 4 (Section: Text Mining of Human and Pathogen Protein Interactions )

Biomedicines 2020, 8, 320
4 of 48
VirusMentha [26], IMEx [27], PSICQUIC [28], the PPIN constructed by Zhong et al. [29], and based on
the automatic pipeline method of NLP; the candidate host-pathogen interspecies regulations were
collected from VIRmiRNA [30], ViRBase [31], miRecords [32], starBase v2.0 [33], miRTarBase [34],
and based on the automatic pipeline method of NLP.
2.3. Text Mining of Human and Pathogen Protein Interactions
To reinforce the comprehension of the interaction relationships between host and pathogen,
BioBERT (Bidirectional Encoder Representations from Transformer for Biomedical Text Mining) [35,36],
an up-to-date BioNER (Biomedical Named Entity Recognition) approach is employed on the PubMed
database to analyze binary interactions between host and pathogen. BioNER is a computerized
procedure of identifying biomedical named entities such as genes, protein complexes, diseases,
and chemicals in texts referring to information retrieval and data extraction.
Amongst all the
BioNER application, BioBERT, which has achieved state-of-the-art performance in terms of precision,
is eﬃcaciously utilized in biomedical text mining applications to address data.
In brief, we scraped and collected 26,732 existing PubMed articles associated with Hepatitis B
Virus and Homo sapiens within 20 years and transformed it into XML format. Nonetheless, on account
of Pubmed’s property, the full texts from most articles in PMC aren’t publicly accessible so that looking
forward to automatically download integrated content is unrealistic. Consequently, we additionally
crawled 2831 articles from PLOS ONE to strengthen our network complexity. Then, BioBERT model
was exerted to discern known entities and identify the types of overlapping entities among each
sentence separated from the relevant content with periods in the corpus.
In order to facilitate analysis and reconﬁrmation, we also gathered the synonym names of both
host and pathogen proteins (compiled from BioThesaurus database [37]) to prevent omission of vital
interactions owing to protein names mismatch. Afterwards, in each sentence, we extracted all present
proteins and identiﬁed the correlations by determining the human proteins under the circumstance
that Hepatitis B Virus proteins had existed. To abate computational complexity, in conformity with the
subsequent system identiﬁcation processing requirement, the verb recognition and identiﬁcation were
left out of account and binary interactions were built. For instance, providing that “HBx” and “BCL2”
were simultaneously identiﬁed in the same sentence, we then set the corresponding value to 1 and so
forth, vice versa to 0.
Furthermore, to verify that authentic interaction relationships derived from the statistical analysis
of sentences, we scrutinized entire extracted entities and completed the construction of ultimate host
and pathogen interaction-relationships matrix.
2.4. Dynamic Models of Candidate HPI-GEN for Human Cells and HBV During the Infection
Candidate HPI-GEN, constructed via big data mining techniques, is the epitome of an intricate
network comprised of protein interactions and gene regulations between host and pathogen during
HBV infection. As inevitable false-positive information extraction might incur system distraction from
genuine consequence and discrepancy during the pathway analysis process, dynamic models were
built to carry out systematic identiﬁcation approach by two-side time-proﬁle HBV infection RNA-seq
data to prune false-positives in candidate HPI-GEN.
Protein abundances mirror a dynamic balance among a series of linked processes spanning the
transcription, processing, and degradation of mRNAs to the translation, modiﬁcation, and breakdown
of the proteins themselves necessary for cellular protein production and maintenance [38].
As a consequence, for the protein interactive model of PPI pre-network in candidate HPI-GEN,
the dynamic interaction model of the ith host protein can be described by the following equation:
pH
i (t + 1) = pH
i (t) +
NiP
n=1
aH
inpH
i (t)pH
n (t) +
ViP
v=1
bH
ivpH
i (t)pP
v(t)
+αH
i gH
i (t) −γH
i pH
i (t) + βH
i + vH
i (t), for i = 1, 2, . . . , I, αH
i ≥0 and −γH
i ≤0
(1)

## Page 5 (Section: Text Mining of Human and Pathogen Protein Interactions )

Biomedicines 2020, 8, 320
5 of 48
where pH
i (t), pH
n (t), gH
i (t) and pP
v(t) indicate the expression levels of the ith host protein, the nth host
protein, the ith host gene, and the vth pathogen protein at time t, respectively; aH
in and bH
iv denote the
interactive ability between the ith host protein and nth host protein and between the ith host protein
and vth pathogen protein, respectively; Ni and Vi signify the number of host proteins and pathogen
proteins interacting with the ith host protein; and I typiﬁes the total number of the human proteins
in candidate PPIN. αH
i , −γH
i and βH
i indicate the translation rate from the corresponding mRNA,
the degradation rate, and the basal expression level of the ith host protein, respectively; the basal level
denotes the interactions with unknown factors, such as acetylation, methylation, and ubiquitination;
and vH
i (t) represents the stochastic noise of the ith host protein at time t. Note that the intraspecies and
interspecies biological mechanism of human proteins in candidate PPIN are represented in Equation (1)
as the form of
NiP
n=1
aH
inpH
i (t)pH
n (t) and
ViP
v=1
bH
ivpH
i (t)pP
v(t), respectively.
Now that the interactions between the host and pathogen proteins are mutual and their biological
characteristics involved in PPIs are similar, the dynamic PPIN of the qth pathogen protein in candidate
HPI-GEN can be described by the analogous equation as follows:
pP
q (t + 1) = pP
q (t) +
Nq
P
n=1
aP
qnpP
q (t)pH
n (t) +
Vq
P
v=1
bP
qvpP
q (t)pP
v(t)
+αP
q gP
q (t) −γP
q pP
q (t) + βP
q + vP
q (t), for q = 1, 2, . . . , Q, αP
q ≥0 and −γP
q ≤0
(2)
where pP
q (t), pH
n (t), gP
q (t) and pP
v(t) indicate the expression levels of the qth pathogen protein, the nth
host protein, the qth pathogen gene, and the vth pathogen protein at time t, respectively; aP
qn and bP
qv
denote the interactive ability between the qth pathogen protein and nth host protein and between the qth
pathogen protein and vth pathogen protein, respectively; Nq and Vq signify the number of host proteins
and pathogen proteins interacting with the qth pathogen protein; and Q typiﬁes the total number
of the pathogen proteins in candidate PPIN. αP
q , −γP
q and βP
q indicate the translation rate from the
corresponding mRNA, the degradation rate, and the basal expression level of the qth pathogen protein,
respectively; the basal level βP
q denotes the interactions with unknown factors such as acetylation and
ubiquitination; and vP
q (t) represents the stochastic noise of the qth pathogen protein at time t. Similarly,
the intraspecies and interspecies biological mechanism of pathogen proteins in candidate PPIN are
represented in Equation (2) as the form of
Nq
P
n=1
aP
qnpP
q (t)pP
n(t) and
Vq
P
v=1
bP
qvpP
q (t)pH
v (t), respectively.
For the GRN of host genes in the candidate HPI-GEN, the dynamic regulatory model of the jth
host gene can be described as follows:
gH
j (t + 1) = gH
j (t) +
TjP
τ=1
cH
jτpH
τ (t) +
LjP
ℓ=1
dH
jℓlH
ℓ(t) −
Mj
P
µ=1
eH
jµgH
j (t)mH
µ (t)
−λH
j gH
j (t) + δH
j + ϖH
j (t), for j = 1, 2, . . . , J, −eH
jµ ≤0 and −λH
j ≤0
(3)
where gH
j (t), pH
τ (t), mH
µ (t) and lH
ℓ(t) indicate the expression levels of the jth host gene, the τth host TF,
the µth host microRNA, and the ℓth host lncRNA at time t, respectively; cH
jτ, −eH
jµ and dH
jℓrepresent the
regulation ability of the τth host TF, the µth host microRNA, and the ℓth host lncRNA on the jth host
gene, respectively; Tj, Mj and Lj denote the number of host TFs, host miRNAs, and host lncRNAs,
respectively, which regulate the expression level of the jth host gene; J indicates the total amount of
genes in GRN; −λH
j and δH
j indicate the degradation rate and the expression basal level of the jth host
gene, respectively; and ϖH
j (t) denotes the stochastic noise due to modeling residue at time t. The basal
level δH
j denotes the unknown regulations such as methylation. Note that since microRNAs silence
gene expression by binding to target mRNAs [39], repression ability −eH
jµ in candidate GRN model
should be constrained negative. Likewise, −λH
j degradation rate should be restricted non-positive
due to the depression regulation of mRNA. Furthermore, though supporting evidence comes from

## Page 6 (Section: Text Mining of Human and Pathogen Protein Interactions )

Biomedicines 2020, 8, 320
6 of 48
numerous research showing that HBV proteins play a vital role in the regulation of viral and host
gene expression, diﬀerent from other viruses such as HIV, whose viral protein directly binds to
nucleic acids [40], HBV proteins are thought to aﬀect host gene expression through transregulation,
e.g., transactivation and transrepression [41–44]. Thus, it seems tenable to exclude the regulations
between pathogen proteins and host gene in the Equation (3).
In the same way, for the GRN of pathogen genes in the candidate HPI-GEN, the dynamic regulatory
model of the uth pathogen gene can be described as follows:
gP
u(t + 1) = gP
u(t) +
TuP
τ=1
cP
uτpH
τ (t) +
LuP
ℓ=1
dP
uℓlH
ℓ(t) −
Mu
P
µ=1
eP
uµgP
u(t)mH
µ (t)
−λP
ugP
u(t) + δP
u + ϖP
u(t), for u = 1, 2, . . . , U, −eP
uµ ≤0 and −λP
u ≤0
(4)
where gP
u(t), pH
τ (t), mH
µ (t) and lH
ℓ(t) indicate the expression levels of the uth pathogen gene, the τth
host TF, the µth host microRNA, and the ℓth host lncRNA at time t, respectively; cP
uτ, −eP
uµ and dP
uℓ
represent the regulation ability of the τth host TF, the µth host microRNA, and the ℓth host lncRNA on
the uth pathogen, respectively; Tu, Mu and Lu denote the number of host TFs, host miRNAs, and host
lncRNAs, respectively, which regulate the expression level of the uth pathogen; U indicates the total
amount of pathogen genes in GRN; −λP
u and δP
u indicate the degradation rate and the expression
basal level of the uth pathogen, respectively; and ϖP
u(t) denotes the stochastic noise due to modeling
residue at time t. It is worth noting that there is a consensus on the opinion about the indispensability
of host protein synthesis machinery for pathogen protein production and gene transcription [45,46].
Walsh et al. [47] even suggested that viruses are fully reliant on the translation machinery of their
host cells to produce the polypeptides that are essential for viral replication. As a result, only gene
regulation conducted by host transcription factors pH
τ (t) instead of pathogen proteins pP(t) is included
in Equation (4).
Since the expression of the µth host miRNA mH
µ (t) and the ℓth host lH
ℓ(t) in Equation (3) at time
t might also be regulated by other regulators, the µth miRNA can be described by the following
stochastic dynamic regulatory equation:
mH
µ (t + 1) = mH
µ (t) +
Tµ
P
τ=1
f H
µτpH
τ (t) +
LµP
ℓ=1
hH
µℓlH
ℓ(t) −
Mµ
P
r=1
kH
µrmH
µ (t)mH
r (t)
−ϕH
µ mH
µ (t) + ηH
µ + εH
µ (t), for µ = 1, 2, . . . , M, −kH
µr ≤0 and −ϕH
µ ≤0
(5)
where mH
µ (t), pH
τ (t), mH
r (t) and lH
ℓ(t) indicate the expression levels of the µth host gene, the τth host
TF, the rth host miRNA and the ℓth host lncRNA at time t, respectively; f H
µτ, −kH
µr and hH
µℓrepresent the
regulation ability of the τth host TF, the rth host microRNA and the ℓth host lncRNA on the µth host
miRNA, respectively; Tµ, Mµ and Lµ denote the number of host TFs, host miRNAs and host lncRNAs,
respectively, which regulate the expression level of the µth host miRNA; M indicates the total number
of miRNAs in GRN; −ϕH
µ and ηH
µ indicate the degradation rate and the expression basal level of the µth
host miRNA, respectively; and εH
µ (t) denotes the stochastic noise due to modeling residue at time t.
Along the same line, the dynamic regulatory model of the host lncRNA in candidate GEIN can be
described by the following dynamic equation:
lH
ℓ(t + 1) = lH
ℓ(t) +
TℓP
τ=1
xH
ℓτpH
τ (t) +
Oℓ
P
ℓ=1
yH
ℓolH
o (t) −
Mℓ
P
r=1
zH
ℓµlH
ℓ(t)mH
µ (t)
−σH
ℓlH
ℓ(t) + φH
ℓ+ ψH
ℓ(t), for ℓ= 1, 2, . . . , L, −zH
ℓµ ≤0 and −σH
ℓ≤0
(6)
where lH
ℓ(t), pH
τ (t), mH
µ (t) and lH
o (t) indicate the expression levels of the ℓth host lncRNA, the τth host
TF, the µth host microRNA and the ℓth host lncRNA at time t, respectively; xH
ℓτ, −zH
ℓµ and yH
ℓo represent
the regulation ability of the τth host TF, the µth host microRNA and the oth host lncRNA on the ℓth host

## Page 7 (Section: Parameter Estimation of the Dynamic Models of Candidate HPI-GEN by System Identification Approach )

Biomedicines 2020, 8, 320
7 of 48
lncRNA, respectively; Tℓ, Mℓand Lℓdenote the number of host TFs, host miRNAs and host lncRNAs,
respectively, which regulate the expression level of the ℓth host lncRNA; L indicates the total number
of lncRNA in GRN; −σH
ℓand φH
ℓindicate the degradation rate and the expression basal level of the ℓth
host lncRNA, respectively; and ψH
ℓ(t) denotes the stochastic noise due to modeling residue at time t.
2.5. Parameter Estimation of the Dynamic Models of Candidate HPI-GEN by System Identiﬁcation Approach
In order to identify real HPI-GEN, the accurate model parameters training process by executing a
system identiﬁcation approach to the candidate HPI-GEN after the construction of dynamic model
Equations (1)–(6) is requisite. Consequently, the stochastic Equations (1) and (2), which depict the
relation of protein interactions of the ith host and qth pathogen protein, can be converted into the linear
regression forms as below, respectively:
The ith host protein:
pH
i (t + 1) = [pH
i pH
1 (t) · · · pH
i pH
Ni(t)pH
i pP
1(t) · · · pH
i pP
Vi(t)gH
i (t)pH
i (t)1]


aH
i1...
aH
iNi
bH
i1...
bH
iVi
αH
i
1 −γH
i
βH
i


+ vH
i (t)
≜φHP
i
(t)θHP
i
+ vH
i (t), for i = 1, 2, . . . , I
(7)
The qth host protein:
pP
q (t + 1) = [pP
q pH
1 (t) · · · pP
q pH
Nq(t)pP
q pP
1(t) · · · pP
q pP
Vq(t)gP
q (t)pP
q (t)1]


aP
q1
...
aP
qNq
bH
q1
...
bP
qVq
αP
q
1 −γP
q
βP
q


+ vP
q (t)
≜φPP
q (t)θPP
q
+ vP
q (t), for q = 1, 2, . . . , Q
(8)
where φHP
i
(t) and φPP
q (t) represent the regression vectors that can be obtained from the expression
data and θHP
i
and θPP
q
are the unknown parameter vectors to be estimated for the ith host protein,
qth pathogen protein in host PPIN, respectively.
Thence, the Equations (7) and (8) of the ith host and qth pathogen protein can further be augmented
for Yi and Yq time points as the following forms, respectively:
The ith host protein:


pH
i (t2)
pH
i (t3)
...
pH
i

tYi + 1



=


φHP
i
(t1)
φHP
i
(t2)
...
φHP
i

tYi



θHP
i
+


vH
i (t1)
vH
i (t2)
...
vH
i

tYi



, for i = 1, 2, . . . , I
(9)

## Page 8 (Section: Parameter Estimation of the Dynamic Models of Candidate HPI-GEN by System Identification Approach )

Biomedicines 2020, 8, 320
8 of 48
the Equation (9) can also be simply represented as
PH
i = ΦHP
i
θHP
i
+ ΩHP
i
, for i = 1, 2, . . . , I
(10)
The qth host protein:


pP
q (t2)
pP
q (t3)
...
pP
q

tYq + 1



=


φPP
q (t1)
φPP
q (t2)
...
φPP
q

tYq



θPP
q
+


vP
q (t1)
vP
q (t2)
...
vP
q

tYq



, for q = 1, 2, . . . , Q
(11)
the Equation (11) can also be simply represented as
PP
q = ΦPP
q θPP
q
+ ΩPP
q , for q = 1, 2, . . . , Q
(12)
After a succession of equation transformation procedure in advance, the parameters in vectors
θHP
i
and θPP
q
of Equations (10) and (12) can be estimated by individually employing the following
constrained least-squares estimation problems, θHP
i
parameters estimation:
ˆθHP
i
= min
θHP
i
∥ΦHP
i
θHP
i
−PH
i ∥
2
2, subject to AHP
i
ˆθHP
i
≤bHP
i
where AHP
i
=
"
0
· · ·
0
0
· · ·
0
−1
0
0
0
· · ·
0
0
· · ·
0
0
1
0
#
∈R2×(I+Q+3) and bHP
i
=
"
0
1
#
(13)
θPP
q
parameters estimation:
ˆθPP
q
= min
θPP
q
∥ΦPP
q θPP
q
−PP
q ∥
2
2, subject to APP
q
ˆθPP
q
≤bPP
q
where APP
q
=
"
0
· · ·
0
0
· · ·
0
−1
0
0
0
· · ·
0
0
· · ·
0
0
1
0
#
∈R2×(I+Q+3) and bPP
q
=
"
0
1
#
(14)
Subsequently, we can acquire the interaction parameters in PPIN Equations (1) and (2) individually
by resolving the least-squares problems in (13) and (14) with the help of the function lsqlin in MATLAB
optimization toolbox and simultaneously ensure the protein translation rate αH
i
and αP
q to be a
non-negative value and the protein degradation rate −γH
i and −γP
q to be a non-positive value; that is to
say αH
i , αP
q ≥0 and −γH
i , −γP
q ≤0.
In the same manner, the dynamic Equations (3)–(6) which depict the relationship of gene regulations
for the jth host gene, uth pathogen gene, µth host miRNA, and ℓth host lncRNA can be rewritten into
the linear regression forms below, respectively:

## Page 9 (Section: Parameter Estimation of the Dynamic Models of Candidate HPI-GEN by System Identification Approach )

Biomedicines 2020, 8, 320
9 of 48
The jth host gene:
gH
j (t + 1) = [pH
1 (t) · · · pH
Tj(t)gH
j (t)mH
1 (t) · · · gH
j (t)mH
Mj(t) lH
1 (t) · · · lH
Lj(t) gH
j (t) 1]


cH
j1
...
cH
jTj
−eH
j1
...
−eH
jMj
dH
j1
...
dH
jLj
1 −λH
j
δH
j


+ ϖH
j (t)
≜φHG
j
(t)θHG
j
+ ϖH
j (t), for j = 1, 2, . . . , J
(15)
The uth pathogen gene:
gP
u(t + 1) = [pH
1 (t) · · · pH
Tu(t)gP
u(t)mH
1 (t) · · · gP
u(t)mH
Mu(t) lH
1 (t) · · · lH
Lu(t) gP
u(t) 1]


cP
u1...
cP
uTu
−eP
u1
...
−eP
uMu
dP
u1...
dP
uLu
1 −λP
u
δP
u


+ ϖP
u(t)
≜φPG
u (t)θPG
u
+ ϖP
u(t), for u = 1, 2, . . . , U
(16)
The µth host miRNA:
mH
µ (t + 1) = [pH
1 (t) · · · pH
TµmH
µ (t)mH
1 (t) · · · mH
µ (t)mH
Rµ(t) lH
1 (t) · · · lH
Lµ(t) mH
µ (t) 1]


f H
µ1
...
f H
µTµ
−kH
µ1
...
−kH
µRµ
hH
µ1
...
hH
µLµ
1 −ϕH
µ
ηH
µ


+ εH
µ (t)
≜φHM
µ
(t)θHM
µ
+ εH
µ (t), for µ = 1, 2, . . . , M
(17)

## Page 10 (Section: Parameter Estimation of the Dynamic Models of Candidate HPI-GEN by System Identification Approach )

Biomedicines 2020, 8, 320
10 of 48
The ℓth host lncRNA:
lH
ℓ(t + 1) = [pH
1 (t) · · · pH
TℓlH
ℓ(t)mH
1 (t) · · · lH
ℓ(t)mH
Mℓ(t) lH
1 (t) · · · lH
Lℓ(t) lH
ℓ(t) 1]


xH
ℓ1...
xH
ℓTℓ
−zH
ℓ1
...
−zH
ℓMℓ
yH
ℓ1...
yH
ℓLℓ
1 −σH
ℓ
φH
ℓ


+ ψH
ℓ(t)
≜φHL
ℓ(t)θHL
ℓ
+ ψH
ℓ(t), for ℓ= 1, 2, . . . L
(18)
where φHG
j
(t), φPG
u (t), φHM
µ
(t) and φHL
ℓ(t) represent the regression vectors that can be obtained from
the expression data and θHG
j
, θPG
u , θHM
µ
and θHL
ℓ
are the unknown parameter vectors to be estimated for
the jth host gene, uth pathogen gene, µth host miRNA, and ℓth host lncRNA in host GRN, respectively.
Then, Equations (15)–(18) of the jth host gene, uth pathogen gene, µth host miRNA, and ℓth host
lncRNA can be further augmented for Yj, Yu, Yµ and Yℓtime points as the following forms, respectively:
The jth host gene:


gH
j (t2)
gH
j (t3)
...
gH
j (tYj + 1)


=


φHG
j
(t1)
φHG
j
(t2)
...
φHG
j
(tYj)


θHG
j
+


ϖH
j (t1)
ϖH
j (t2)
...
ϖH
j (tYj)


, for j = 1, 2, . . . , J
(19)
the Equation (19) can also be simply represented as:
GH
j = ΦHG
j
θHG
j
+ ΩHG
j
, for j = 1, 2, . . . , J
(20)
The uth pathogen gene:


gP
u(t2)
gP
u(t3)
...
gP
u(tYu + 1)


=


φPG
u (t1)
φPG
u (t2)
...
φPG
u (tYu)


θHG
u
+


ϖP
u(t1)
ϖP
u(t2)
...
ϖP
u(tYu)


, for u = 1, 2, . . . , U
(21)
the Equation (21) can also be simply represented as:
GP
u = ΦPG
u
θPG
u
+ ΩPG
u , for u = 1, 2, . . . , U
(22)
The µth host miRNA:


mH
µ (t2)
mH
µ (t3)
...
mH
µ (tYµ + 1)


=


φHM
µ
(t1)
φHM
µ
(t2)
...
φHM
µ
(tYµ)


θHM
µ
+


εH
j (t1)
εH
j (t2)
...
εH
j (tYµ)


, for µ = 1, 2, . . . , M
(23)

## Page 11 (Section: Parameter Estimation of the Dynamic Models of Candidate HPI-GEN by System Identification Approach )

Biomedicines 2020, 8, 320
11 of 48
the Equation (23) can also be simply represented as:
MH
µ = ΦHM
µ
θHM
µ
+ ΩHM
µ
, for µ = 1, 2, . . . , M
(24)
The ℓth host lncRNA:


lH
ℓ(t2)
lH
ℓ(t3)
...
lH
ℓ(tYℓ+ 1)


=


φHL
ℓ(t1)
φHL
ℓ(t2)
...
φHL
ℓ(tYℓ)


θHG
j
+


ψH
ℓ(t1)
ψH
ℓ(t2)
...
ψH
ℓ(tYℓ)


, for ℓ= 1, 2, . . . , L
(25)
the Equation (25) can also be simply represented as:
LH
ℓ= ΦHG
ℓ
θHG
ℓ
+ ΩHG
ℓ
, for ℓ= 1, 2, . . . , L
(26)
After a succession of equation transformation procedure in advance, the parameters in vectors
θHG
j
, θPG
u , θHM
µ
and θHL
ℓ
of Equations (20), (22), (24) and (26) can be estimated by individually
employing the following constrained least-square estimation problem,
ˆθHG
j
= min
θHG
j
1
2∥ΦHG
j
θHG
j
−GH
j ∥
2
2,
subject to AHG
j
ˆθHG
j
≤bHG
j
where bHG
j
=
"
0
1
#
and AHG
j
=


0
0
· · ·
0
1
0
· · ·
0
0
0
· · ·
0
0
0
0
0
· · ·
0
0
1
· · ·
0
0
0
· · ·
0
0
0
...
...
...
...
...
...
...
...
...
...
...
...
...
...
0
0
· · ·
0
0
0
· · ·
1
0
0
· · ·
0
0
0
0
0
· · ·
0
0
0
· · ·
0
0
0
· · ·
0
1
0


∈R(Mj+1)×(Tj+Mj+Lj+2)
(27)
ˆθPG
u
= min
θPG
u
1
2∥ΦPG
u θPG
u
−GP
u∥
2
2,
subject to APG
u
ˆθPG
u
≤bPG
u
where bPG
u
=
"
0
1
#
and APG
u
=


0
0
· · ·
0
1
0
· · ·
0
0
0
· · ·
0
0
0
0
0
· · ·
0
0
1
· · ·
0
0
0
· · ·
0
0
0
...
...
...
...
...
...
...
...
...
...
...
...
...
...
0
0
· · ·
0
0
0
· · ·
1
0
0
· · ·
0
0
0
0
0
· · ·
0
0
0
· · ·
0
0
0
· · ·
0
1
0


∈R(Mu+1)×(Tu+Mu+Lu+2)
(28)
ˆθHM
µ
= min
θHM
µ
1
2∥ΦHM
µ
θHM
µ
−MH
µ ∥
2
2,
subject to AHM
µ
ˆθHM
µ
≤bHM
µ
where bHM
µ
=
"
0
1
#
and AHM
µ
=


0
0
· · ·
0
1
0
· · ·
0
0
0
· · ·
0
0
0
0
0
· · ·
0
0
1
· · ·
0
0
0
· · ·
0
0
0
...
...
...
...
...
...
...
...
...
...
...
...
...
...
0
0
· · ·
0
0
0
· · ·
1
0
0
· · ·
0
0
0
0
0
· · ·
0
0
0
· · ·
0
0
0
· · ·
0
1
0


∈R(Mµ+1)×(Tµ+Mµ+Lµ+2)
(29)
ˆθHL
ℓ
= min
θHL
ℓ
1
2∥ΦHL
ℓθHL
ℓ
−LH
ℓ∥
2
2,
subject to AHL
ℓ
ˆθHL
ℓ
≤bHL
ℓ
wherebHL
ℓ
=
"
0
1
#
and AHL
ℓ
=


0
0
· · ·
0
1
0
· · ·
0
0
0
· · ·
0
0
0
0
0
· · ·
0
0
1
· · ·
0
0
0
· · ·
0
0
0
...
...
...
...
...
...
...
...
...
...
...
...
...
...
0
0
· · ·
0
0
0
· · ·
1
0
0
· · ·
0
0
0
0
0
· · ·
0
0
0
· · ·
0
0
0
· · ·
0
1
0


∈R(Mℓ+1)×(Tℓ+Mℓ+Lℓ+2)
(30)

## Page 12 (Section: Determination of Significant Interaction Pairs )

Biomedicines 2020, 8, 320
12 of 48
Through applying the function lsqlin in MATLAB optimization toolbox to solve the constrained
least-squares estimation problem in (27)–(30), we could obtain optimal regulatory parameters for GRN
Equations in (3)–(6) and concurrently guarantee that the miRNA repression ability −eH
jµ, −eP
uµ, −kH
µr and
−zH
ℓµ as well as the degradation rate −λH
j , −λP
u, −ϕH
µ and −σH
ℓvalues corresponding to the jth host gene,
the uth pathogen gene, the µth host miRNA, and the ℓth host lncRNA to be non-positive, respectively.
So far, the structure of dynamic regression model construction is complete, yet if we substitute the
expression data into the linear model right away, inﬁnite solutions problems will emerge due to the
lack of enough data points, in other words, information deﬁciency in comparison with parameters for
evaluation, that is, overﬁtting. Thus, the cubic spline for extra numbers of time-proﬁle data points
interpolation is applied to prevent this trouble (For more details, readers can refer to Appendix A).
Then, with the processed RNA-seq data, the accurate solutions of the constrained least-squares
estimation problems in (13)–(14) and (27)–(30) can be attained.
Moreover, since the measurement technology of genome-wide protein expression in HepaRG cells
and Hepatitis B Virus during infection hasn’t been realized yet, and supporting evidence comes from
research showing that the cellular concentrations of proteins correlate with the abundances of their
corresponding mRNAs, which implied that the variance in protein abundance can be explained by that
of mRNA [48–51] and a correlation coeﬃcient of 48% was also obtained between the mRNA and protein
abundances in human liver [49], i.e., the RNA-seq data of gene expressions can substitute protein
expressions and contribute to suﬃcient information for resolving above constrained least-squares
parameter estimation problems in (13) and (14) and (27)–(30). One could retain more information in
our previous research [52].
2.6. Determination of Signiﬁcant Interaction Pairs
On account of approaching the best combination to constitute the robust HPI-GEN in the parameter
identiﬁcation procedures, we exploited the cost function to obtain the optimal ﬁt for the host/pathogen
RNA-seq data, to be more precisely, estimation of the expected relative distance between the ﬁtted
model and the unrecognized authentic molecular pathogenic mechanism that actually generated the
observed data. On the whole, as the cost function of the parameter estimation for linear regression
model, mean squared error (MSE) is enough to calculate the residual variance. However, the cost from
the model complexity that might also inﬂuences the performance should be taken into consideration as
well. Akaike Information Criterion (AIC), taking the place of MSE, was thereby selected to assess the
residual variance and model complexity at once. As the expected residual variance declines with rising
parameter numbers for inadequate model complexities, there should be a minimum around the correct
parameter number after repeated coordination [52]. Meanwhile, owing to computational eﬃciency,
computing the AIC statistics for all possible combinations is impracticable. Stepwise methods are
developed to decreasing the complexity of exhaustive searching [52]. Finally, while reaching the
minimum of AIC value, we could acquire the real number of interactions or regulations for each protein
(gene) one by one in the candidate HPI-GEN. Those insigniﬁcant regulations or interactions out of the
real number determined by AIC should be pruned to obtain the real HPI-GEN.
For each model composing PPIN, the AIC values of the ith host and the qth pathogen protein can
be deﬁned individually as the following equations:
The ith host protein:
AICHP
i
(Ni, Vi)
= log

1
Yi

PH
i −ΦHP
i
ˆθHP
i
T
PH
i −ΦHP
i
ˆθHP
i

+ 2(Ni+Vi)
Yi
= log

(σHP
i
2 
+ 2(Ni+Vi)
Yi
(31)

## Page 13 (Section: Determination of Significant Interaction Pairs )

Biomedicines 2020, 8, 320
13 of 48
The qth pathogen protein:
AICPP
q

Nq, Vq

= log

1
Yq

PP
q −ΦPP
q
ˆθPP
q
T
PP
q −ΦPP
q
ˆθPP
q

+
2(Nq+Vq)
Yq
= log

(σPP
q
2 
+
2(Nq+Vq)
Yq
(32)
for i = 1, . . . , I and q = 1, . . . , Q, where AICHP
i
(Ni, Vi) with the model complexity Ni + Vi and
AICPP
q

Nq, Vq

with the model complexity Nq + Vq denote the ith host and the qth pathogen protein
in PPI model, respectively; (σHP
i
2 and (σPP
q
2 signify the covariance of estimated residual error
between PH
i and ΦHP
i
ˆθHP
i
and between PP
q and ΦPP
q
ˆθPP
q , respectively; and ˆθHP
i
and ˆθPP
q
represent the
estimated parameters acquired from the solutions of the parameter estimation problems in (13) and
(14), respectively. Suppose N∗
i , V∗
i and N∗
q, V∗
q could minimize AICHP
i
(Ni, Vi) and AICPP
q

Nq, Vq

in (31)
and (32), respectively. Then, N∗
i , V∗
i and N∗
q, V∗
q denote the real number of PPIs in the ith host protein
and the qth pathogen protein. The insigniﬁcant PPIs out of these numbers should be pruned as false
positives from candidate PPIs to obtain real PPIs in HPI-GEN.
For each model comprising GRN, the AIC values of the jth host gene, the uth pathogen gene,
the µth host miRNA, and the ℓth host lncRNA can be deﬁned individually as following equations:
The jth host gene:
AICHG
j

Tj + Mj + Lj

= log
 
1
Yj

GH
j −ΦHG
j
ˆθHG
j
T
GH
j −ΦHG
j
ˆθHG
j
!
+
2(Tj+Mj+Lj)
Yj
= log
"
(σHG
j
2 #
+
2(Tj+Mj+Lj)
Yj
(33)
The uth pathogen gene:
AICPG
u (Tu + Mu + Lu)
= log

1
Yu

GP
u −ΦPG
u
ˆθPG
u
T
GP
u −ΦPG
u
ˆθPG
u

+ 2(Tu+Mu+Lu)
Yu
= log

(σPG
u
2 
+ 2(Tu+Mu+Lu)
Yu
(34)
The µth host miRNA:
AICHM
µ

Tµ + Mµ + Lµ

= log

1
Yµ

MH
µ −ΦHM
µ
ˆθHM
µ
T
MH
µ −ΦHM
µ
ˆθHM
µ

+
2(Tµ+Mµ+Lµ)
Yµ
= log

(σHM
µ
2 
+
2(Tµ+Mµ+Lµ)
Yµ
(35)
The ℓth host lncRNA:
AICHL
ℓ(Tℓ+ Mℓ+ Lℓ)
= log

1
Yℓ

LH
ℓ−ΦHL
ℓ
ˆθHL
ℓ
T
LH
ℓ−ΦHL
ℓ
ˆθHL
ℓ

+ 2(Tℓ+Mℓ+Lℓ)
Yℓ
= log

(σHL
ℓ
2 
+ 2(Tℓ+Mℓ+Lℓ)
Yℓ
(36)
for
j
=
1, . . . , J,
q
=
1, . . . , Q,
µ
=
1, . . . , M,
and
ℓ
=
1, . . . , L
where
AICHG
j

Tj + Mj + Lj

,
AICPG
u (Tu + Mu + Lu),
AICHM
µ

Tµ + Mµ + Lµ

and
AICHL
ℓ(Tℓ+ Mℓ+ Lℓ)
with the model complexity Tj + Mj + Lj, Tu + Mu + Lu, Tµ + Mµ + Lµ and Tℓ+ Mℓ+ Lℓdenote the
AIC values of the jth host gene, the uth pathogen gene, the µth host miRNA, and the ℓth host lncRNA
in GRN model, respectively; (σHG
j
)2, (σPG
u )2, (σHM
µ
)2 and (σHL
ℓ
)2 signify the covariance of estimated
residual error between GH
j and ΦHG
j
ˆθHG
j
, GP
u and ΦPG
u
ˆθPG
u , MH
µ and ΦHM
µ
ˆθHM
µ
, and LH
ℓand ΦHL
ℓ
ˆθHL
ℓ,
respectively; and ˆθHG
j
, ˆθPG
u , ˆθHM
µ
and ˆθHL
ℓ
represent the estimated parameters acquired from the
solutions of the parameter estimation problems in (27)–(30), respectively. Similarly, the real numbers of
regulation by TF, miRNA, lncRNA are obtained by minimizing the corresponding AICs in (33)–(36).

## Page 14 (Section: Extracting Core Network Structure from the Real HPI-GEN by Using PNP Approach )

Biomedicines 2020, 8, 320
14 of 48
The insigniﬁcant regulations out of these real numbers should be pruned as false positives to obtain
the real regulations by TF, miRNA, lncRNA in HPI-GEN.
So far, through a sequence of systematic identiﬁcation processes, the construction for real
HPI-GENs is broadly accomplished by pruning those insigniﬁcant interactions and regulations out of
the corresponding AIC. Unfortunately, due to the excessively enormous network architecture, we could
hardly extract the core pathways to investigate the pathogenesis during HBV infection, let alone
screening of candidate proteins as new targets for drug development. We thereby extracted the core
network from the real HPI-GEN via applying the principal network projection (PNP) method.
2.7. Extracting Core Network Structure from the Real HPI-GEN by Using PNP Approach
Prior to core network extraction from the real HPI-GEN through applying PNP method, it is
essential to integrate the network estimated parameters from PPIN and GRN into a system matrix A
as follows,
A
=


AHP,HP
AHP,PP
0
0
APP,HP
APP,PP
0
0
AHG,HP
0
AHG,HM
AHG,HL
AHM,HP
0
AHM,HM
AHM,HL
AHL,HP
0
AHL,HM
AHL,HL
APG,HP
0
APG,HM
APG,HL


=


ˆaH
11
· · ·
ˆaH
1I
...
ˆaH
in
...
ˆaH
I1
· · ·
ˆaH
II
ˆbH
11
· · ·
ˆbH
1Q
...
ˆbH
iv
...
ˆbH
I1
· · ·
ˆbH
IQ
0
· · ·
0
...
0
...
0
· · ·
0
0
· · ·
0
...
0
...
0
· · ·
0
ˆaP
11
· · ·
ˆaP
1I
...
ˆaP
qn
...
ˆaP
Q1
· · ·
ˆaP
QI
ˆbP
11
· · ·
ˆbP
1Q
...
ˆbP
qv
...
ˆbP
Q1
· · ·
ˆbP
QQ
0
· · ·
0
...
0
...
0
· · ·
0
0
· · ·
0
...
0
...
0
· · ·
0
ˆcH
11
· · ·
ˆcH
1I
...
ˆcH
jτ
...
ˆcH
I1
· · ·
ˆcH
II
0
· · ·
0
...
0
...
0
· · ·
0
−ˆeH
11
· · ·
−ˆeH
1M
...
−ˆeH
jµ
...
−ˆeH
I1
· · ·
−ˆeH
IM
ˆdH
11
· · ·
ˆdH
1L
...
ˆdH
jℓ
...
ˆdH
I1
· · ·
ˆdH
IL
ˆf H
11
· · ·
ˆf H
1I
...
ˆf H
µτ
...
ˆf H
M1
· · ·
ˆf H
MI
0
· · ·
0
...
0
...
0
· · ·
0
−kH
11
· · ·
−kH
1M
...
−kH
µr
...
−kH
M1
· · ·
−kH
MM
ˆhH
11
· · ·
ˆhH
1L
...
ˆhH
µℓ
...
ˆhH
M1
· · ·
ˆhH
ML
ˆxH
11
· · ·
ˆxH
1I
...
ˆxH
ℓτ
...
ˆxH
L1
· · ·
ˆxH
LI
0
· · ·
0
...
0
...
0
· · ·
0
−ˆzH
11
· · ·
−ˆzH
1M
...
−ˆzH
ℓµ
...
−ˆzH
L1
· · ·
−ˆzH
LM
ˆyH
11
· · ·
ˆyH
1L
...
ˆyH
ℓo
...
ˆyH
L1
· · ·
ˆyH
LL
ˆcP
11
· · ·
ˆcP
1I
...
ˆcP
uτ
...
ˆcP
Q1
· · ·
ˆcP
QI
0
· · ·
0
...
0
...
0
· · ·
0
−ˆeP
11
· · ·
−ˆeP
1M
...
−ˆeP
uµ
...
−ˆeP
Q1
· · ·
−ˆeP
QM
ˆdP
11
· · ·
ˆdP
1L
...
ˆdP
uℓ
...
ˆdP
Q1
· · ·
ˆdP
QL


∈R(2I+2Q+L+M)×(I+Q+L+M)
where HP, PP, HG, HM, HL and PG denote the host protein, pathogen protein, host gene, host miRNA,
host lncRNA and pathogen gene, respectively; ˆaH
in, ˆbH
iv and ˆaP
qn, ˆbP
qv mentioned in (1) and (2) could
be acquired in ˆθHP
i
and ˆθPP
q
by resolving the parameter estimation problems in (13) and (14) and
pruning false positives by AIC method in (31) and (32), respectively;

ˆcH
jτ, −ˆeH
jµ, ˆdH
jℓ

,

ˆf H
µτ, −kH
µr, ˆhH
µℓ

,

ˆxH
ℓτ, −ˆzH
ℓµ, ˆyH
ℓo

, and
n
ˆcP
uτ, −ˆeP
uµ, ˆdP
uℓ
o
mentioned in (3)–(6) could be acquired in ˆθHG
j
, ˆθPG
u , ˆθHM
µ
and
ˆθHL
ℓ
by resolving the parameter estimation problems in (27)–(30) and pruning false positives by AIC
method in (33)–(36) respectively. Note that since the regulations from pathogen proteins weren’t taken
into consideration, the corresponding parameters in matrix A are padded with zeros.
Thereafter, we extract the core components of HPI-GEN by PNP approach, a principal network
analysis method for dimensionality reduction based on network structure projection technique, that is,

## Page 15 (Section: Extracting Core Network Structure from the Real HPI-GEN by Using PNP Approach )

Biomedicines 2020, 8, 320
15 of 48
projecting matrix A to its principal singular vectors space. Accordingly, the combined network matrix
A can be denoted by singular value decomposition form below,
A = USVT
(37)
where
U
∈
R(2I+2Q+L+M)×(I+Q+L+M),
V
∈
R(I+Q+L+M)×(I+Q+L+M), and S
=
diag

σ1, . . . , σs, . . . σI+Q+L+M

is a diagonal matrix of σ1, . . . , σs, . . . σI+Q+L+M which includes the I + Q
+ L + M singular values of the matrix A in descending order, i.e., σ1 ≥. . . ≥σs ≥. . . ≥σI+Q+L+M ≥0.
S =


σ1
0
· · ·
0
· · ·
0
0
σ2
· · ·
0
· · ·
0
...
...
...
...
...
...
0
0
· · ·
σs
· · ·
0
...
...
...
...
...
...
0
0
· · ·
0
· · ·
σI+Q+L+M
0
0
· · ·
0
· · ·
0
...
...
...
...
...
...
0
0
· · ·
0
· · ·
0


Also, we deﬁne the expression fraction Ew of the interaction ability of the proteins and the
transcriptional regulatory ability of the genes, lncRNAs, miRNAs as the normalization of singular
value form,
Ew =
σ2
w
I+Q+L+M
P
w=1
σ2w
(38)
According to the diminishing property of the singular values, under the basic premise of sustaining
system energy from the whole network structure, we pick out the minimum X such that ΣX
w=1Ew ≥0.85,
i.e., the vector space spanned by the orthonormal bases composed of the principal singular vectors
corresponding to the top X singular values contains 85% energy of HPI-GEN structure.
Afterwards, we deﬁne and apply the projection value of each node, including gene, miRNA,
lncRNA, and protein in the real HPI-GEN to the vector space spanned by the orthonormal basis
composed of the principal singular vectors corresponding to the top X singular values as below,
ProjR(Arow,i, VT∗) =
" XP
k=1
(Arow,ivk)2
#1/2
ProjC(Acol,j, U∗) =
" XP
k=1
(AT
col,juk)2
#1/2
(39)
where Arow,i denotes the ith row vector of A for i = 1, . . . , 2I + 2Q + L + M; Acol,j signiﬁes jth column
vector of A for j = 1, . . . , I + Q + L + M; VT∗; and U∗represent the vector spaces spanned by the
orthonormal basis {v1, v2, . . . , vk} and {u1, u2, . . . , uk} for k = 1, . . . , X, respectively; ProjR(Arow,i, VT∗)
and ProjC(Acol,j, U∗) indicate the projection value from Arow,i and Acol,j to VT∗and U∗vector
spaces, respectively.
While the projection value ProjR(Arow,i, VT∗) or ProjC(Acol,j, U∗) in (39) approaches zero, it intimates
that the corresponding node i or j isn’t the pivotal factor or independent to the core network extracted
via the PNP procedure. Conversely, the larger projection value it gets, the greater the node contributes
to the core network.
Eventually, we select the ﬁrst 3000 components on the top of the list with higher energy in (39) as
the core host-pathogen network from real HPI-GEN of HBV infection by ranking the projection value
of each node and subsequently uploading those nodes into DAVID to obtain the KEGG pathways as

## Page 16 (Section: Deep Learning-Based Drug-Target Interaction Prediction )

Biomedicines 2020, 8, 320
16 of 48
shown in Table 3. Taking KEGG pathways as reference, we systematically identify and investigate the
molecular pathogenic mechanism of HBV infection from the core HPI-GEN as shown in Figure 4 and
select the signiﬁcant biomarkers for the further novel drug discovery procedure.
2.8. Deep Learning-Based Drug-Target Interaction Prediction
2.8.1. Data Preparation
Following the identiﬁcation of promising pathogenic biomarkers, a potent drug-target interaction
(DTI) model to predict the interactions between the identiﬁed biomarkers and their corresponding
molecule drugs is crucial for discovering favorable molecular compounds for the therapeutic treatment.
Thus, we constructed a deep learning-based DTI model to collect viable interactions to identify available
drugs for the selected biomarkers. Meanwhile, since most patients in need of attention and treatment
are infected with chronic hepatitis, the highest priority was assigned to eﬃcacious drugs with lower
toxicity that would not cause irreparable harm to health.
First, we integrated databases from UniProt [53], DrugBank [54], ChEMBL [55], Pubchem [56],
and BindingDB [57] to assemble applicable drug-target interactions. As feature descriptors are simple
numerical vectors designed to delineate the complicated information of objects, they have been
widely utilized to describe the genomic sequences and chemical properties of molecules such as
the characteristics from 2D, 3D spectrum of structure, molecular weight, predictive values of LogP,
etc. of late [58,59]. In view of this property, we employed both the oﬀ-the-shelf build-in molecular
and protein descriptor functions of python package pyBioMed to transform the features from each
drug and its target among the previously collected drug-target interactions into descriptor under
python 2.7 environment, respectively. These features include molecular dockings such as amino acid
composition and dipeptide composition. For more details about the descriptor transformation, readers
could access the documents of pyBioMed. Thereafter, we united the descriptors of both drugs and
their relevant targets into a matrix as the training dataset to train the DTI model. The vector vdrug−target
corresponding to the descriptor of each drug-target pair is given below:
vdrug−target = [D, T] =
h
d1, d2, · · · , dI, t1, t2, · · · tJ
i
(40)
where vdrug−target denotes the vector of the descriptor for each the drug-target pair comprising two
parts. The former part D is the descriptor of the drug and di represents the ith drug feature; the latter
portion T is the descriptor of the target and tj indicates the jth target characteristic; I is the total number
of drug features; J is the total number of target features.
Before performing drug-target interaction prediction, to keep our DTI model from inferior
performance arising from between-class imbalance and distracting variation, some data preprocessing
procedures are requisite. The entire preprocessing procedure in our work encompasses down sampling,
data partitioning, feature scaling, and dimensionality reduction.
•
Down Sampling:
There are two categories of drug-target interaction in our samples: 16,000,000 samples for
the unknown interactions (negative instances) and 60,000 samples for the known interactions
(positive instances). Though deep learning methods scale well with the quantity of data and can often
leverage extremely large datasets for good performance, imbalanced class distribution often causes
the model to be overwhelmed by the large class and ignore the minority one. So as to mitigate the
eﬀect arising from class imbalance, we reduced the number of majority samples (negative instances) to
60,000 which will allow the model to learn from both classes equally.
•
Data Partitioning:
After the down sampling procedure, we partition the data (the reconstructed matrix of drug-target
pairs) into two sets, three-fourth for training and one-fourth for testing.

## Page 17 (Section: Parameters Tuning Process Based on Deep Learning Algorithm )

Biomedicines 2020, 8, 320
17 of 48
•
Feature Scaling:
Since the variables of the features in each drug-target pair are measured at diﬀerent scales, they
do not contribute equally to the model ﬁtting and might end up with creating a bias. To deal with this
potential problem, a feature-wise scaling is usually implemented prior to model ﬁtting. As powerful
techniques of feature scaling, Min-max scaling (normalization) and Standardization are both widely
used in data analysis. However, despite possessing the capability to shift and rescale the data into
a limited range of values, normalization is sensitive to the outliers [60]; in contrast, standardization
maintains useful information about outliers and makes the model less sensitive to them [61]. Thus,
we apply Standardization on each feature and the corresponding mathematical formulation is shown
as follows:
d∗
i = di−µi
σi , ∀i = 1, . . . , I
t∗
j =
tj−ωj
δj , ∀j = 1, . . . , J
(41)
where di and d∗
i represent the ith feature of the drug before and after Standardization, respectively;
µi and σi signify the mean and standard deviation of the ith drug feature; tj and t∗
j indicate the jth
feature of the target before and after Standardization, respectively; ωj and δj denote the mean and
standard deviation of the ith target feature; I is the total number of features in the drug while J is that
of the target.
•
Dimensionality Reduction:
Since the high-dimensional patterns in samples might augment the number of neurons in the
network and elevate the computational complexity for training, we adopted principal components
analysis (PCA) to distill 692 features from original 1014 features of the samples. One could retain as
much information of interested [62,63].
Note that it is illegal and useless to carry out data preprocessing to the testing set solely relying
on the characteristics in testing data in that we would never get any information from the features of
testing data until the training phase is over. Hence, aside from the aforementioned transformation
performed on the training data sets, we also provide the identical transformation on the testing data
during the process of feature scaling and dimensionality reduction. More exactly, we extracted the
mean and standard deviation variables of each feature in the training data set to standardize the
corresponding feature in the testing data. Likewise, the transformation matrix for executing PCA of the
features in training data was concurrently used to reduce the dimension of the features in testing data.
So far, the training data for tuning the network parameters of the deep learning-based DTI
model and the testing data for evaluating the model performance are ready. Nonetheless, if learned
merely on the features from the training set, the hyperparameters would always choose the maximum
possible model capacity, leading to overﬁtting [63]. As a result, we randomly split out one-tenth of the
training data to estimate the generalization error during training, allowing for the hyperparameters
to be updated in every epoch. In addition, Early Stopping method was also employed to specify an
arbitrarily large number of training epochs and stop training once improving the model’s ﬁt to the
training data comes at the expense of increased generalization error. Eventually, through setting the
optimizer as Adam [64] and learning rate = 0.001, we then trained our DTI model for 40 epochs with
100 samples in each mini-batch.
2.8.2. Parameters Tuning Process Based on Deep Learning Algorithm
In the network architecture, each layer can be simpliﬁed into a function below:
ˆhn = δ(wTxn + b)
(42)

## Page 18 (Section: Parameters Tuning Process Based on Deep Learning Algorithm )

Biomedicines 2020, 8, 320
18 of 48
where xn and ˆhn indicate the input and output vectors corresponding to the descriptor of the nth
drug-target pair, respectively; δ denotes the activation function (ReLU for each hidden layer and
Sigmoid for the output layer); and the vectors w and b are given as follows:
w =


w1
w2
...
we


, b =


b1
b2
...
be


(43)
where the weights parameters w1, w2, . . . we in w and bias parameters b1, b2, . . . be in b are free variables
that capture the model’s representation of the data in each layer and are learned from each sample.
To evaluate the model performance, the predicted output is compared with the true label to
compute a loss for the current set of model weights. Since drug-target interaction prediction issue is
a binary classiﬁcation problem, binary cross-entropy is chosen to calculate the loss of each iteration.
The summation of the loss L(y, ˆy) for totally N samples is given by the expression as below:
L(y, ˆy) = −1
N
N
X
n=1
(yn ∗log( ˆyn) + (1 −yn) ∗log(1 −ˆyn)) = 1
N
N
X
n=1
Cn(yn, ˆyn)
(44)
where Cn(yn, ˆyn) is loss of the nth sample calculated by binary cross-entropy, in which yn is the nth
actual label (1 or 0) and ˆyn is the nth predicted probability distribution.
During the learning process, the parameter set θ (46) in each layer should achieve the minimization
of the objective function (47) to obtain the optimal network parameters θ∗. Accordingly, backward
propagation learning algorithm (48) is designed to update the network parameters of both weights
(w1, w2, . . . , we) and bias (b1, b2, . . . , be).
θ =


w1
...
we
b1
...
be


(45)
θ∗= argmin
θ L(θ)
(46)
θi = θi−1 −η∇L(θi−1)
(47)
where i is the ith iteration of the learning process; η is the learning rate (set as 0.001); and ∇L(θi−1) is
the gradient of L(θi−1) given as follows:
∇L(θi−1) =


∂L(θi−1)
∂w1...
∂L(θi−1)
∂we
∂L(θi−1)
∂b1...
∂L(θi−1)
∂be


(48)
Consequently, by back-propagating a corrective error signal through the network, weighted
connections between neurons in the DTI model are iteratively adjusted and assessed on the basis of the
drug-target pairs in the training and the validation sets.

## Page 19 (Section: Measurement of Prediction Quality )

Biomedicines 2020, 8, 320
19 of 48
2.8.3. Measurement of Prediction Quality
Assessing a model is quite tricky. It isn’t reliable to evaluate model performance (training accuracy
of the ﬁnal epoch) merely based on one speciﬁc validation set, in that the accuracy obtained from
one validation set can be very diﬀerent to that from another. Thus, we took advantage of a general
technique named 10-fold cross validation to avoid the possible bias. That is, the original samples for
training is randomly partitioned into 10 equal size subsamples; one is retained as the validation data
for testing the model, and the remaining 9 subsamples are used as training data. Through repeatedly
training and validating the models 10 times with diﬀerent partitions, we then compute an average score
over the rounds to give an estimate of the model’s predictive performance. Afterwards, the model
parameters with diﬀerent validation errors were applied to the testing data for generating the ﬁnal test
accuracy and loss.
Aside from that, to compare the eﬀectiveness of our DTI model with that of other state-of-the-art
ML-based approaches, we adopted AUC-ROC curve [65] to tell how good a speciﬁc model can
distinguish two classes, that is, whether or not a drug interacts with a target. ROC represents the
relationship between beneﬁt (true positive rate) and cost (false positive rate), while AUC is a value in
the range of 0 to 1 that indicates the degree of separability between classes. The higher AUC we obtain,
the more accurate outcome we will get from the model. The formulas for AUC-ROC curve are shown
as below:
True Positive Rate = Recall/Sensitivity =
TP
TP + FN
(49)
Speciﬁcity =
TN
TN + FP
(50)
False Positive Rate = 1 −Speciﬁcity =
FP
TN + FP
(51)
where True Positive (TP) means that the actual value is positive and is judged correctly; False Positive
(FP) shows that the actual value is positive but is judged by mistake; True Negative (TN) indicates the
actual value is negative and is judged accurately; False Negative (FN) represents the actual value is
negative but is judged in error.
3. Results
3.1. Overview of Systems Medicine Discovery Procedure
Though a great advance has been made to design and evaluate medicine based on the application
of diversiﬁed drug repositioning approaches, it still takes a large amount of time and vigor if without
a potent avenue to select the promising biomarkers and drugs for the clinical trials. In this study,
we proposed a systematic biology method containing two sections including potential biomarkers
identiﬁcation and novel drugs discovery.
The overall ﬂowchart of the proposed systems biology procedure is shown in Figure 1. On one
hand, we applied a systematic identiﬁcation analysis procedure to the constructed candidate HPI-GEN,
considering both accuracy and model complexity with the help of the information from the two-side
real-time proﬁle RNA-seq. Note that the total nodes and edges respectively given in Tables 1 and 2
of the real HPI-GEN in Figure 2 abstracted from the candidate HPI-GEN has considerably shrunk
in comparison with that of the candidate HPI-GEN, which indicates that the false-positives were
eliminated during the identiﬁcation process. Supported with the PNP approach, we then identiﬁed
the core HPI-GEN in Figure 3 by selecting top-ranked 3000 nodes with signiﬁcant projection values
that could reﬂect 85% of the real HPI-GEN. The higher the projection value is, the stronger regulatory
capacity it possesses in the host/pathogen cross-talk mechanism during HBV infection. In the meantime,
given identiﬁed KEGG pathways derived through uploading nodes in core HPI-GEN into DAVID in
Table 3, we selected the core signaling pathways so as to explore the underlying etiologic mechanism

## Page 20 (Section: Measurement of Prediction Quality )

Biomedicines 2020, 8, 320
20 of 48
in HBV infection as shown in Figure 4, involving microenvironmental factors by surveying relevant
papers and research.
Table 1. The total number of nodes in candidate interspecies host/pathogen interspecies genetic
and epigenetic interaction network (HPI-GEN) and identiﬁed HPI-GEN during Hepatitis B Virus
(HBV) infection.
Node
Candidate HPI-GEN
Real HPI-GEN
LncRNA node
143
137
MiRNA node
922
922
TF node
2477
1325
Receptor node
2105
2105
Virus node
4
4
Protein node
13,465
12,258
Total node
19,116
16,751
Table 2. The total number of edges in candidate interspecies HPI-GEN and identiﬁed interspecies
HPI-GEN during HBV infection.
Edge
Candidate HPI-GEN
Real HPI-GEN
LncRNA-LncRNA
0
0
LncRNA-miRNA
0
0
LncRNA-TF
156
9
LncRNA-Receptor
2
0
LncRNA-Protein
90
8
LncRNA-Virus
8
1
MiRNA-LncRNA
510
303
MiRNA-MiRNA
96
86
MiRNA-TF
42,913
7909
MiRNA-Receptor
26,888
9694
MiRNA-Protein
146,144
65,561
MiRNA-Virus
39
15
TF-LncRNA
231
157
TF-MiRNA
1439
944
TF-TF
33,426
8061
TF-Receptor
14,948
6500
TF-Protein
76,441
39,574
TF-Virus
54
38
Receptor-LncRNA
26
15
Receptor-MiRNA
143
102
Receptor-TF
2364
644
Receptor-Receptor
1490
693
Receptor-Protein
7755
4560
Virus-LncRNA
5
3
Virus-MiRNA
109
80
Virus-TF
509
77
Virus-Receptor
164
72
Virus-Protein
682
276
PPIs
4,039,657
906,428
Total edge
4,396,289
1,051,810

## Page 21 (Section: Measurement of Prediction Quality )

Biomedicines 2020, 8, 320
21 of 48
 
Figure 1.
Flowchart of applying systems biology method to construct the candidate HPI-GEN,
real HPI-GEN, core HPI-GEN, and core signaling pathways during the infection of HBV to identify
the potential biomarker for later drug discovery repurposing. The grey blocks in the shape of a
cloud indicate the online databases for constructing candidate HPI-GEN and later drug repositioning;
the white diamond blocks are the corresponding data types of each database; the orange diamond blocks
signify candidate protein-protein interaction network (PPIN) and gene regelation network (GRN);
the blue blocks represent the input information including the raw RNA-seq data for system identiﬁcation
and the collected articles for BioBERT to augment the interspecies interactions and regulations in PPIN
and GRN, respectively; the red blocks denote the models comprising BioBERT and stochastic regression
models utilized in the systems biology approach; the white rectangle blocks indicate the systematic
methods applied to constructing the candidate HPI-GEN and extracting core HPI-GEN; the purple
blocks imply the drug discovery and repositioning procedure proposed afterwards; and the yellow
rounded rectangular blocks are the real HPI-GEN and core HPI-GEN during the infection of HBV.

## Page 22 (Section: Measurement of Prediction Quality )

Biomedicines 2020, 8, 320
22 of 48
Figure 2. Real HPI-GEN between host and pathogen under infection of HBV. The real HPI-GEN
describes the cross-talk interaction and regulation between host and pathogen after system identiﬁcation
analysis to prune false positives from candidate HPI-GEN. The purple lines denote PPIs; the green,
yellow, blue, and red lines indicate the regulations by Transcriptional factors (TFs), lncRNAs, miRNAs,
and Virus proteins respectively; and the total numbers of lncRNAs, miRNAs, proteins, receptors,
Virus proteins, and TFs in the network are 137, 922, 12,258, 2015, 4, 1325, respectively.
 
Figure 3. Core HPI-GEN under infection of HBV. The core HPI-GEN denotes the cross-talk interactions
between host and pathogen after performing PNP to extract the top 3000 nodes from the real HPI-GEN.
The purple lines denote PPIs; the green, yellow, blue, and red lines indicate the regulations by TFs,
lncRNAs, miRNAs, and Virus proteins, respectively; and the total numbers of lncRNAs, miRNAs,
proteins, receptors, Virus proteins, and TFs in the network are 6, 262, 2086, 332, 4, 312, respectively.

## Page 23 (Section: Measurement of Prediction Quality )

Biomedicines 2020, 8, 320
23 of 48
 
Figure 4. The core host/pathogen cross-talk signaling pathways during HBV infection. This is a network obtained from the core HPI-GEN by the annotation of
KEGG (Kyoto Encyclopedia of Genes and Genomes) pathways, which represents an intracellular pathogenic mechanism during the invasion of host hepatocyte by
HBV. The solid black lines indicate the regulation (with an arrowhead) and interaction between nodes. The solid lines in diﬀerent colors except black represent the
regulations of the corresponding cellular functions; among them, the lines with an arrowhead denote the activation of cellular functions while the lines with a circular
head indicate the inhibition of cellular functions. Furthermore, for the nodes of downstream target genes, the blocks with an upward pointing arrow signify a rising
expression; comparatively, the blocks with a downward pointing arrow signify a dropping expression under HBV infection.

## Page 24 (Section: Extracting Core Signaling Pathways from Identified HPI-GEN and Core HPI-GEN in HBV Infection )

Biomedicines 2020, 8, 320
24 of 48
On the other hand, after determining the biomarkers from signaling pathways of the core HPI-GEN
as shown in Table 4, we proposed a deep learning-based drug-target interaction (DTI) method to
predict the potential interactions (dockings) between the identiﬁed biomarkers and their corresponding
drugs for further candidate drugs discovery. The outcome of the DTI model is presented in a form of
probability. The higher probability analyzed by the DTI model, the connection between the selected
biomarker and the predicted drug is more likely to exist. However, given the enormous number of
candidate drugs, the general drug speciﬁcations such as regulation ability, toxicity, and sensitivity from
multiple databases were taken into consideration to reduce the search space and ensure the safety and
eﬃcacy in clinical trials. The pertinent ﬂow-process diagram of the systems molecular drug design
procedure is shown in Figure 5.
3.2. Extracting Core Signaling Pathways from Identiﬁed HPI-GEN and Core HPI-GEN in HBV Infection
For the purpose of analyzing the molecular mechanism under HBV infection, extracting core
signaling pathways from candidate HPI-GEN is critical. The process to construct candidate HPI-GEN
and identify real HPI-GEN as well as core HPI-GEN has been shown in the ﬂowchart of Figure 1.
Thereafter, we identiﬁed the real HPI-GEN via parameter identiﬁcation concerning the cost of
model complexity under the auspices of corresponding RNA-seq data to prune false positives from
candidate HPI-GEN (refer to Section 2.4–Section 2.6 for more details). The total numbers of the nodes
of proteins, Transcription factors (TFs), miRNAs, lncRNAs, and Virus proteins as well as the edges of
their interactions and regulations for the candidate HPI-GEN and identiﬁed real HPI-GEN are given
in Tables 1 and 2, respectively. In addition, through employing the network visualizing software
Cytoscape, the network of real HPI-GEN under HBV infection is shown in Figure 2.
Since the immense complexity of real HPI-GEN limits the possibility to eﬃciently investigate
the pathogenic mechanism under HBV infection, applying principal network projection (PNP) and
subsequently abstracting the top 3000 nodes with signiﬁcant projection values on the 85% pivotal
network structures to distill core HPI-GEN are essential. Meanwhile, the results of core HPI-GEN
under the infection of HBV is shown in Figure 3.
Moreover, we employed DAVID Bioinformatics Resources version 6.8 to analyze the enrichments
of relative pathways and speciﬁc cellular functions of core HPI-GEN as shown in Table 3.
Table 3. The pathway enrichment analysis of proteins by applying the DAVID in core HPI-GEN during
HBV infection.
Term
Numbers
p-Value
MicroRNAs in cancer
103
8.6 × 10−18
Pathways in cancer
108
8.7 × 10−10
FoxO signaling pathway
49
5.6 × 10−9
Viral carcinogenesis
63
6.3 × 10−8
Hepatitis B
47
7.3 × 10−7
Cell cycle
39
1.6 × 10−5
MAPK signaling pathway
64
6.2 × 10−5
TNF signaling pathway
33
1.3 × 10−4
Ras signaling pathway
55
6.2 × 10−4
PI3K-Akt signaling pathway
77
7.6 × 10−4
Through the multifaceted assessment of the core HPI-GEN based on existing studies and the
annotation of KEGG signaling pathways, we could attain the core signaling pathways associated
with microenvironmental factors including cytokines, chemokines, etc., for the pathogenesis of HBV
infection as represented in Figure 4. Then, on the basis of the investigating the consequence of the
systematic pathogenic molecular mechanism, we could identify the potential biomarkers holding great
promise for the development of therapeutic targets.

## Page 25 (Section: Analysis of Core Interspecies Cross-Talk Pathways to Investigate Host/Pathogen Offensive/Defensive Mechanism during HBV Infection )

Biomedicines 2020, 8, 320
25 of 48
3.3. Analysis of Core Interspecies Cross-Talk Pathways to Investigate Host/Pathogen Oﬀensive/Defensive
Mechanism during HBV Infection
Based on the core host/pathogen cross-talk signaling pathways in Figure 4, several identiﬁed
processes leading to dysfunction of antiviral machinery are investigated to aﬀord a stepwise
understanding of the host/pathogen oﬀensive and defensive mechanism under HBV infection.
3.3.1. Inception of HBV Infection
Hepatitis B Virus (HBV) has a 3.2-kb circular and partially double-stranded DNA genome that
contains four genes named S, C, P, and X genes coding for the envelope proteins, the core protein and a
related protein termed precore protein, the viral DNA polymerase, and the multifunctional regulatory
protein, respectively [66,67]. The journey of HBV virions starts from attaching to host hepatocytes
through heparan sulfate proteoglycans (SDC2 and HSPG2) and promptly transfers to sodium acid
cotransporter (SLC10A1), initiating the HBV life cycle. Once entering the cells, the viral nucleocapsid
containing the partially double-stranded DNA, known as the relaxed circular DNA (rcDNA), will be
released into the cytoplasm and transported into the nucleus. The plus strand of the rcDNA is then
repaired and completed to generate the covalently closed circular (cccDNA), which later forms the
HBV minichromosome and is transcribed into RNAs for viral replication [68].
3.3.2. Liver Microenvironment and Immune Pathogenesis under HBV Infection
Inﬂammatory and innate immune responses impact the pathogenesis of numerous diseases
and participate in the activation of common inﬂammatory mediators and regulatory pathways.
On top of the Toll pathways that could be directly stimulated by the viral particles, in response
to the foreign invasions, leukocytes, e.g., neutrophils and macrophages that phagocytose and kill
pathogens, might simultaneously coordinate additional host responses by synthesizing a wide range of
inﬂammatory mediators, such as TNF-α, IL-6, IFN-α, and IFN-γ [69]. These cytokines and chemokines
provoke the secretion of antiviral eﬀectors and a series of immunoregulatory mechanisms against
HBV infection. In general, cellular and molecular events and interactions would eﬀectively mitigate
impending injury or infection during inﬂammatory responses [70]. However, along with the frequent
recurrence of inﬂammation, once imbalances of the microenvironment occur, it might lead to abnormal
epigenetic variations and even immune dysregulation [71], which consequently incurs viral relapse.
3.3.3. Toll Pathway as the First Line of Defense against Infection
Toll-like receptors (TLRs) have long been recognized as the ﬁrst line of antiviral immunity in
that they initiate intracellular signaling pathways to induce antiviral mediators, such as interferons
(IFNs) and other cytokines [72]. Upon the recognition of foreign invaders (HBV-associated molecular
patterns), TLRs elicited phosphorylation of IKKβ (IKBKB) through several signaling transduction
proteins, including MyD88, IRAK1, TRAF6, TAB1, and TAK1. IκBα (NFKBIA) is a downstream protein
of IKKβ keeping NF-κB sequestered in an inactive state in cytoplasm [73]. When phosphorylated
by IKKβ, IκBα dissociated from NF-κB, resulting in the nuclear translocation of NF-κB and the
induction of its several targets, in which the Interleukin 6 (IL6), the interferon-alpha receptor 1 (IFNAR1),
the interferon-gamma receptor 2 (IFNGR2), and BCL3 were recognized as shown in Figure 4. Among them,
IL-6 is the pleiotropic cytokine encoded by IL6 gene that catalyzes immune reaction and inﬂammatory
responses [74,75]; IFNAR1 is the receptor that binds type I interferons and activates the JAK-STAT
signaling pathway, along with MAPK, PI3K, and Akt signaling pathways associated with multiple
cellular functions, such as inﬂammation and immune response regulation [76]; IFNGR2 is a receptor
that binds to interferon-γ (IFN-γ), which is the immune interferon produced predominantly by natural
killer (NK) and natural killer T (NKT) cells in response to viral infection [77]; and BCL3 is a protein that
inhibits DNA damage-induced apoptosis and acts as a transcriptional coregulator of NF-κB [78,79].

## Page 26 (Section: TNF–Stimulated Signaling Pathways )

Biomedicines 2020, 8, 320
26 of 48
In addition to stimulation of the downstream NF-κB pathway, the phosphorylated IKKβ also
activated the pathway of mammalian target of rapamycin (mTOR) by triggering the disruption of
TSC1/TSC2 complex. In general, TSC1 stabilizes TSC2 through direct binding, thereby preventing
TSC2 from ubiquitination and degradation. Once IKKβ phosphorylates TSC1 incurring collapse of its
connection with TSC2, it obliquely leads to the stabilization of RhebGTP, which mediates signaling
to mTOR [80,81]. As for the substrates of mTOR, among all the identiﬁed downstream proteins in
the core host/pathogen signaling pathways as shown in Figure 4, the translational repressor 4EBP1
(EIF4EBP1) stood out to be a pivotal constituent. It is well acknowledged that when the 4EBP1 protein
is hyperphosphorylated by mTOR kinase, it can’t bind and hijack the eIF4E factor, i.e., a general initiator
for translational regulation [82,83]. Concurrently, it is reported that the released eIF4E might form a
complex with the 5′ stem-loop structure of the HBV genome, thus ensuring viral replication [84].
3.3.4. TNF-α-Stimulated Signaling Pathways
TNF-α is a multifunctional cytokine that plays a principal role in cell proliferation, apoptosis,
inﬂammation, and immune response. From the core host/pathogen cross-talk signaling pathways in
Figure 4, as soon as TNF-α bound to TNF receptors (TNFRs), it contributed to the phosphorylation
of Akt via both TNFR2/TRAF2/PIK3CB and TNFR1/TRADD/TRAF2/PIK3CB signaling transductions.
Akt is an eﬀector of Class I PI3K triggering multiple downstream pathways and has been shown
to be a critical mediator of cell proliferation and survival in a variety of cell types [85]. In Figure 4,
a few pathways of Akt were incorporated into the core host/pathogen cross-talk network. First of all,
the activated Akt inhibited the induction of autophagy through transactivating mTOR, i.e., impeding
GTPase-activating protein complex TSC1-TSC2 as previously described. It is worth noting that TSC2
rather than TSC1 was directly phosphorylated by Akt, which destabilized TSC2 and disrupted its
aﬃnity with TSC1 [86]. Secondly, Akt also enhanced MDM2-mediated ubiquitination leading to
p53 (TP53) degradation [87] and catalyzed the nuclear localization and stabilization of BCL3 by
phosphorylation [79], where BCL3 is the aforementioned transcription coregulator having been proven
to interact with NF-κB so as to facilitate its transcriptional ability. Moreover, it even caused nuclear
exclusion and cellular dysfunctions of FoxO proteins through phosphorylation and repression [88].
Therefore, as the identiﬁed target genes of FoxO proteins in the core host/pathogen cross-talk pathways,
BNIP3, BMI1, SOD2, and cyclin-dependent kinase inhibitor 1 (CDKN1A) encoding p21, might probably
be down-regulated. Within, BNIP3 is a pro-apoptotic factor that induces cell death through interacting
with anti-apoptotic proteins [89]; BMI1 is a critical epigenetic repressor that functions through chromatin
remodeling and plays a central role in DNA damage repair [90,91]; and SOD2 is the antioxidant defense
enzyme that participates in apoptotic signaling and oxidative stress regulation [92]. However, it is
well documented that FoxO1/FoxO3 could rapidly relocalize into the nucleus in response to STAT3
activation by IL-6, and the accumulation of FoxO1/FoxO3 in nuclei coincided with elevated expression
of CDKN1A and other genes [93]. This phenomenon could interpret the high expression of the target
genes BNIP3, BMI1, SOD2, and CDKN1A, as well as the promotion of viral replication, since activator
FOXO1 has also been found to bind to HBV DNA and activate its transcription [94].
Aside from the activation of PI3K/Akt pathway, in response to cytokine signals, TRAF2 also
recruited TAK1/TAB3 complex and IKK complex, which is composed of IKKα, IKKβ, and IKKγ (IKBKG),
bringing about the autophosphorylation-dependent activation of TAK1 [95] and the activation of its
substrates, such as IKKβ and MKK7. MKK7 then upregulated the transcriptional activity of c-JUN and
ATF2 via activation of the JNK1. c-Jun is an AP-1 family transcription factor involved in the regulation
of cell death and survival [96] as well as inﬂammation and innate immune response [97]. In Figure 4,
the induction of c-Jun is discovered to be associated with the overexpression of the proinﬂammatory
cytokine receptor IL18R1 essential for IL18 mediated signal transduction [98], the ligand PD-L1 (CD274)
regulating the cellular immune responses to prevent inﬂammation [99], and the major cyclins CCND1
controlling the progression of a cell through the G1 phase by conjugating CDK4/6 enzymes required for
the synthesis of cell cycle [100]. Besides, c-Jun not only modulated the expression of BCL3 by serving

## Page 27 (Section: TAK-STAT Signaling Pathways )

Biomedicines 2020, 8, 320
27 of 48
as either the coactivator of NF-κB or the activator of BCL3 gene to reinforce cell survival [101,102],
but also induced miR-221 to interfere with the regulation ability of the histone deacetylase 6 (HDAC6),
which has been reported to both suppress NF-κB activation and control autophagosome maturation
essential for ubiquitin-selective quality-control autophagy [103]. Apart from that, c-Jun could even
impact the modulation of Fas expression, which sparked oﬀthe loss of Fas-ligand (FasL)-mediated
apoptosis by means of down-regulating the activity of p53.
3.3.5. TAK-STAT Signaling Pathways
The Janus kinase (JAK)-signal transducer and activator of transcription (STAT) signaling pathway
is a chain of interactions between proteins involved in various physiological processes, including
immune function, cell growth, and cell death [104]. The activation of STAT3 was mainly provoked by
JAK1 while JAK1 was brought in the proximity of receptors including the Glycoprotein 130 (IL6ST) and
the gamma interferon receptor 1 (IFNGR1), which receive the signal from IL-6 and IFN-γ, respectively.
However, the activation of STAT1 primarily stemmed from the phosphorylation of TYK2, a member
of JAK family that was previously described by other research groups [105], by the alpha interferon
receptor 1 (IFNAR1) residing in IFN-α stimulation. In spite of forming homodimers or heterodimers
and translocating to the nucleus where they regulated the transcription of target genes, STAT3 and
STAT1 played diﬀerent even in part opposite roles in the process of pathogen infection. STAT3
constitutive activity is essential for cell survival and the extent of inﬂammation. Among the identiﬁed
STAT3 targets in the host/pathogen cross-talk signaling pathway in Figure 4, an anti-inﬂammatory and
anti-apoptosis factor referred to as PD-L1 and the major cyclin CCND1 involved in proliferation and
cell cycle progression as mentioned previously were included. Additionally, STAT3 could also inhibit
apoptosis by suppressing Fas transcription and p53 expression.
In contrast, STAT1 promoted apoptosis by inducing the expression of CXCL10 and strengthened
the antiviral ability through modulating the expression of GBP1. Amongst these two downstream
targets, CXCL10 is a ligand for the receptor CXCR3 involved in chemotaxis, induction of apoptosis,
and regulation of cell growth associated with a variety of human diseases including Hepatitis C [106]
and Endotheliitis [107]. GBP1 is a binding protein which has been shown to provide broad host
protection against diﬀerent pathogen classes through expediting oxidative killing and delivering
antimicrobial peptides to autophagolysosomes [108]. Furthermore, STAT1 also negatively regulated
the cell cycle though inducing the expression of the CDK inhibitors CDKN1A, a target of transcription
factors FoxOs as stated previously.
Albeit STAT3 was directly activated by JAK1, it could also be indirectly triggered through the
cytoplasmic signaling cascade of SHC/ERK pathway composed of signaling proteins, i.e., SHC1,
GRB2, and SOS1, and the classical MAPK/ERK pathway comprised of signaling proteins, i.e., HRAS,
RAF1, MEK1, and ERK1.
Except inducing the activation of STAT3, MAPK/ERK pathway also
contributed to the MSK1-mediated phosphorylation of c-Jun and ATF2, the inhibition of FoxO3
nuclear translocation, and most importantly, the regulation of eIF4E activity having been elucidated
chieﬂy via phosphorylation on serine 209 of eIF4E by other research groups [83,109], which ultimately
proliferated viral replication. More exactly, this was carried out by mitogen-activated kinase2 (MNK2),
the downstream kinase of ERK1.
3.3.6. TNFs-Induced Apoptotic Pathways
As a component of the cell response to viral infection, apoptosis mediated by the sequential
activation of caspases is indispensable for aborting the production and release of progeny virus.
While diverse signaling pathways inducing apoptosis have been found, caspase-mediated proteolysis
of downstream substrates is still a critical element of the execution pathway common to all forms
of apoptosis [110]. And among all the avenues conducive to apoptosis progression, the pathways
contributing to the modulation of caspase-3 (CASP3), a frequently activated death protease that

## Page 28 (Section: Virus Proteins-Induced Pathogenic Mechanism )

Biomedicines 2020, 8, 320
28 of 48
catalyzes the speciﬁc cleavage of many integral cellular proteins, occupied a key position and a majority
of them began with the activation of FADD in Figure 4.
Induction of FADD, the upstream activating protein of caspase-10 (CASP10), was mediated by not
only the bifurcated TNFR1-TRADD signaling cascades but also the interaction with the FasL receptor
(FAS) and the TNF-related apoptosis-inducing ligand receptor (DR5). Upon stimulation, FADD in turn
recruited the initiator caspase caspase-10 to form the death-inducing signaling complex, which leads to
activation of a caspase cascade and eventual cell-death. Having been shown to activate the executioner
caspase-3 through direct processing, caspase-10 is described to be functional-independent to caspase-8
(CASP8) in initiating Fas- and tumor necrosis factor-related ligand-mediated apoptosis [111,112].
Based on the cleavage potential of caspase-3 associated with the dismantling of the cell and the
formation of apoptotic bodies, the identiﬁed critical targets including Beclin-1 (BECN1), DNA-PK
(PRKDC), and the DNA fragmentation factor subunit alpha (DFFA) were speciﬁcally cleaved by
caspase-3 with subsequent loss of its original capability. Among them, BECN1 is the component of the
phosphatidylinositol-3-kinase (PI3K) complex that induces the appearance of autophagosome [113];
PRKDC is the nuclear serine/threonine protein kinase that takes part in degraded DNA repair [114];
and DFFA is a subunit of DFF. Further, according to previous study, whilst DFFA is cleaved, the DNA
fragmentation factor subunit beta (DFFB) would dissociate from the cleaved fragments of DFFA and
trigger both DNA fragmentation and chromatin condensation during apoptosis [115].
Additionally, it is worthwhile to note that Akt, including AKT1 and AKT2, has been reported to interact
with X-linked inhibitor of apoptosis protein (XIAP) and protect it from ubiquitination and degradation [116].
Once phosphorylated by Akt, the XIAP would exploit its second baculovirus IAP repeat domain (BIR2)
to inhibit the apoptotic executioner caspase-3 [117]. We believe that this identified episode carries a
foreshadowing for the succeeding virus-induced malfunctions of programmed cell death.
3.3.7. Virus Proteins-Induced Pathogenic Mechanism
Proteins encoded by the viral genomes, especially HBx, a 154 amino acid gene product of the X gene,
have emerged as promiscuous transactivators activating the transcription of host genes by interacting
directly with nuclear transcription factors or by obliquely activating various signal transduction pathways
in the cytoplasm and have been proven to be potent epigenetic modifying factors in hepatocytes.
HBx regulated the expression of BCL3 to subvert apoptotic signaling pathways via both synergistically
cooperating with p300 (EP300) to enhance c-Jun transcriptional activity and activating NF-κB by either
directly interacting with NF-κB for augmenting its binding ability to its target DNA sequence or promoting
phosphorylation of IκB as shown in Figure 4. In addition, apoptosis inhibition could also be induced by
dysfunction of caspase-3 through enhancing the ability of Akt, an upstream kinase of caspase-3 as stated
earlier, by HBx. Once caspase-3 lost its function, in response to signal from damaged DNA, DNA-PKs,
the substrate of caspase-3, would act in concert with XRCC4 and a number of tightly coupled proteins
to repair DNA. Further, it was suggested that the intense activity or high expression of XRCC4 might be
beneficial to the promotion of HBV cccRNA formation and thereby facilitate the viral replication [118].
Since Hepatitis B Virus supremely requires components from the host cell to complete its replication cycles,
merely one developed avenue to hijack host signaling pathways can’t meet its demand. In addition to the
significant translation initiation factor eIF4E induced by HBx through Akt/mTOR pathway as just mentioned,
eIF4E was activated via the MAPK/ERK pathway as HBx could also trigger Ras and its downstream
signaling pathways. Hence, forming a node of convergence of the PI3K/Akt/mTOR and Ras/Raf/MAPK
signaling pathways, the regulation of eIF4E is clearly consequential for HBx to promote viral replication.
Additionally, overexpression of cyclin G1 (CCNG1) resulted from the loss of microRNA-122 (a liver-specific
miRNA) induced by HBx could also augment virus proliferation. It was reported that CCNG1 specifically
interacts with p53 and blocks its specific binding to HBV enhancer elements, which simultaneously abrogates
p53-mediated inhibition of HBV transcription and releases cell proliferation from G1/S arrest [119].
p53 acts as a sequence-speciﬁc DNA binding protein that activates the transcription of substantial
target genes associating with the regulation of cell cycle progression, apoptosis, DNA repair,

## Page 29 (Section: Drugs Discovery and Repositioning Based on Selected Biomarkers for HBV )

Biomedicines 2020, 8, 320
29 of 48
and senescence. In Figure 4, HBx interacted with p53 both directly and indirectly to inhibit its
DNA consensus sequence binding and transcriptional activity, which has been reported to eﬃciently
block p53-mediated cellular functions [120,121]. Apart from that, HBx also inhibited p53 by conjugating
c-Jun and STAT3 as well as keeping MDM2, the principal cellular antagonist of p53 acting to limit the
p53 growth-suppressive function [122], from ubiquitin-directed self-degradation.
Asforthetargetsofp53,apoptosis-associatedproteins, suchastheproapoptoticproteinBax, whichcould
permeabilize mitochondria and engage the apoptotic program giving rise to activation of caspase-3 [123,124],
the apoptosis antigen Fas triggering the Fas signaling pathway as mentioned earlier, and the DDIT4
negatively regulating cell growth, proliferation, and survival via inhibition of the activity of mTOR [125]
were identified in our core host/pathogen cross-talk signaling pathways in Figure 4. Further, having been
reported to participate in the generation of ROS and p53-dependent DNA damage [126], DDIT4 was
negative-regulated by the HBx-induced upregulation of microRNA-221 to promote aberrant proliferation.
Such significant inverse correlation between DDIT4 mRNA levels and miR-221 expression has been observed
in a mouse model of liver cancer as well [127]. Besides, the direct suppression of histone deacetylases 6
(HDAC6) by HBx-induced miR-221 would result in autophagosome maturation failure; nevertheless, HBx
yet also bound to Vps34 (PI3KC3) to enhance its activity, inducing the autophagic response crucial for the
formation of autophagosomes as well as the intensification of viral replication.
STAT1 and STAT3 are both critical elements in viral replication, despite acting as distinct roles from
each other. Functional characterization of miR-338-3p indicated that miR-338-3p inhibited cell proliferation
by inducing cell cycle arrest at the G1/S phase. The identified downregulation of miR-338-3p and tyrosine
phosphorylation of STAT3 triggered by HBx might cause CCND1 overexpression beneficial to virus cell
cycle progression [128]. In addition, forced low expression of miR-338 by HBx also directly led to the
increased level of autophagy. This process was mainly through the up-regulation of LC3 by the released
transcription factor ATF2, which has been identified as a direct target of miR-338 [129]. Furthermore, instead
of FoxO3, HBx appeared to assist FoxO1 in counteracting the reduction of its nuclear relocalization arising
from Akt phosphorylation by inducing STAT3 activation, which is conducive to the transcription of cccDNA
as previously described. In contrast, since interferons (IFNs) activated STATs via phosphorylation [130],
once recruited by HBx, histone acetyltransferase (HAT) CBP (CEBBP) might dynamically regulate STAT1
acetylation to counteract IFN-catalyzed STAT1 phosphorylation, nuclear translocation, DNA binding,
and target gene regulation. On the other hand, STAT1 nuclear translocation induced by IFN-α might also
be deprived by HBV polymerase [131]. Previous studies demonstrated that miR-122 regulates type I IFN
expression through both down-regulating SOCS1 and SOCS3 to enhance interferon-mediated suppression
of HBV [132,133]. Nonetheless, it appears that merely the regulation of SOCS1 by miR-122 was identified
in Figure 4. Finally, as a target gene of FoxOs and STAT1, CDKN1A overexpression was mediated by
HBx-induced upregulation of miR-29a. Serving as a direct upstream of HDAC4, miR-29a could thereby
alleviate the deacetylation of CDKN1A through HDAC4 inhibition.
3.4. Drugs Discovery and Repositioning Based on Selected Biomarkers for HBV
Through reviewing the cellular dysfunctions triggered by the core host/pathogen cross-talk
interspecies signaling pathways under HBV infection shown in Figure 4, we selected the signiﬁcant
biomarkers including AKT1, NFKBIA, EIF4EBP1, HDAC6, STAT1, STAT3, and TP53 as drug targets
shown in Table 4. However, there is still a long way to the clinical trials on account of the intrinsic
diﬃculties for drug design and development. To this end, we proposed a systematic drug discovery
and repositioning approach to uncover the multiple-molecule drug for therapeutic treatment based on
the deep learning and data mining technique as shown in Figure 5.
Table 4. The drug targets identiﬁed for HBV infection.
Disease
Drug Targets
HBV infection
AKT1, NFKBIA, EIF4EBP1, HDAC6, STAT1, STAT3, TP53

## Page 30 (Section: Drugs Discovery and Repositioning Based on Selected Biomarkers for HBV )

Biomedicines 2020, 8, 320
30 of 48
 
Figure 5. The ﬂowchart of the proposed systems drug discovery and repositioning procedure. According
to the potential biomarkers identiﬁed in Figure 4, we propose a systems drug discovery and repositioning
method for ﬁguring out promising multiple-molecule drug to alleviate HBV infection. First, we collected
data in respect to drug-target interaction from various online databases. Then, we turned each drug
and target into descriptors and assembled them into a matrix of drug-target pairs. To keep our
model from poor performance, data preprocessing prior to training is indispensable. Accordingly,
we adopted data preprocessing approaches including down sampling, data partitioning, feature scaling,
and dimensionality reduction (For more details, readers can refer to Section 2.8.1 in Materials and Methods)

## Page 31 (Section: Drugs Discovery and Repositioning Based on Selected Biomarkers for HBV )

Biomedicines 2020, 8, 320
31 of 48
based on the property of the data. After training the Deep learning-based drug-target interaction (DTI)
model shown in Figure 6 with the constructed training data, we evaluated the model performance
(as shown in Table 5 and Figure 7) and compared the model eﬃcacy of DTI with that of other traditional
machine learning (ML)-based methods (as shown in Figure 8). Since there is only a neuron in the
output layer which delivers the probability of whether the relation (docking) between a drug and a
target exists, the DTI model enabled us to stress the importance on speciﬁc interactions (with output
score approaching 1) and to identify candidate drugs. Next, concerning the availability of the predicted
drugs (candidate drugs) via general criteria for drug design speciﬁcations such as regulation ability,
toxicity, and sensitivity obtained from databases, we further ﬁltered promising drugs that modulate
multiple molecular targets and possess the eﬃcacy with lower dosages. After all, low-dose drugs
are more attainable and cause less harm to patients. In this regard, a set of multi-target drugs with
appropriate toxicity for clinical investigations were selected as a multiple-molecule drug to overcome
HBV infection.
Table 5. Model performance (10-fold cross validation).
Validation
Loss
Validation
Accuracy (%)
Testing
Loss
Testing
Accuracy (%)
1
0.254831
92.09
0.236721
92.28
2
0.237422
91.89
0.2264
92.04
3
0.228304
92.35
0.226482
92.49
4
0.227555
92.62
0.228102
92.6
5
0.223151
92.55
0.218528
92.74
6
0.223817
93.04
0.227157
92.77
7
0.239133
92.39
0.225822
92.58
8
0.235536
92.93
0.226848
92.8
9
0.22345
93.1
0.218475
93.11
10
0.235327
92.21
0.219082
92.64
Average
0.232853
92.517
0.225362
92.605
Standard deviation
0.00983
0.409527
0.005559
0.294099
 
Figure 6. Conﬁguration of the deep learning-based DTI model. v is the vector of each drug-target pair
for the input layer; I is the total number of drug features; and J is the total number of target features.

## Page 32 (Section: Drugs Discovery and Repositioning Based on Selected Biomarkers for HBV )

Biomedicines 2020, 8, 320
32 of 48
(a) 
(b) 
Figure 7. Training and Validation Learning curves (10-fold cross validation). “-x-” lines in diﬀerent
colors denote the training accuracy and loss, while “-o-” lines in diﬀerent colors represent the validation
accuracy and loss in (a,b), respectively. The bold lines in red and blue indicate the model’s average loss
and accuracy of training and validation in (a,b), respectively. Moreover, since stopping the training
of the neural network early before it has overﬁtted the training dataset can reduce overﬁtting and
improve the generalization of the DTI model, Early Stopping approach is additionally employed to
automatically stop the learning process at the epoch of 70.

## Page 33 (Section: Deep Learning-Based Drug-Target Interaction Prediction Model )

Biomedicines 2020, 8, 320
33 of 48
Figure 8. The Receiver Operating Characteristic (ROC) curve of models based on diﬀerent methods.
The accuracy of each method is calculated by the area under the corresponding ROC curve (AUC)
(Readers can refer to Section 2.8.3 for further illustration), where the DTI model could achieve an
accuracy of 0.99, which is higher than that of Random Forest (RF) (accuracy of 0.70), Nearest Neighbor
(accuracy of 0.67), and Support Vector Machine (SVM) (accuracy of 0.57).
3.4.1. Deep Learning-Based Drug-Target Interaction Prediction Model
To eﬀectively predict whether the identiﬁed targets interact with some existing drugs, we provide
a deep learning-based DTI model as shown in Figure 6. It is a fully-connected neural network
containing an input layer and ﬁve layers with weights; four hidden layers (512, 256, 128, and 64 neurons
in each layer) and an output layer (1 neuron). The intermediate hidden layers are applied with
rectiﬁed linear unit (ReLU) activation function that thresholds negative signals to 0 and passes through
positive signal. This type of activation function allows faster learning in comparison with alternatives,
e.g., sigmoid or tanh unit [134]. In contrast, the output of the last layer is fed to a sigmoid function
which produces a likelihood probability (0,1) score of the corresponding predicted docking where
a higher value symbolizes a more reliable drug-target interaction. In addition, to further reducing
overﬁtting, we incorporated a dropout layer [135] with a probability of 0.5 following the output of
each hidden layer.
For avoiding a poor performance due to assessing the model with a data set unfairly sampled (outliers
or other anomalies are presented in one set), we introduced 10-fold cross validation measure to
authenticate the learning eﬀectiveness as shown in Table 5 and the corresponding learning curves that
plot the learning performance of DTI model over experience and time are also presented in Figure 7.
Note that since the model has been diagnosed well-ﬁt and continuous training will likely lead to an

## Page 34 (Section: Systems Discovery and Design of the Multiple-Molecule Drug for HBV Infection )

Biomedicines 2020, 8, 320
34 of 48
overﬁt, it automatically stops learning at the epoch of 70. Subsequently, via calculating the loss and
accuracy of each DTI model yields on the test set, we received an average accuracy of 92.6 (%) with the
standard deviation of 0.294 (%).
Moreover, with the increasement of experimental data, numerous machine learning approaches such as
Random Forest (RF) [136], Support Vector Machine (SVM) [137], Nearest Neighbor [138], etc. have been
applied to predict drug-target interactions. Therefore, to evaluate the model performance, we contrast
our DTI model with a few of them, which are RF, Nearest Neighbor, and SVM. By adopting the
visualization tool, Receiver Operating characteristic (ROC), we can clearly ﬁnd that DTI outperforms
other traditional binary classiﬁers as presented in Figure 8.
3.4.2. Systems Discovery and Design of the Multiple-Molecule Drug for HBV Infection
On the basis of the pre-trained DTI model, we could evaluate the docking ability between the identiﬁed
biomarkers and the available drugs. The larger predicted result we obtain, the higher probability that
the speciﬁc drug-target pair will have interaction. Namely, the candidate drugs would be sifted out
owing to holding higher probability (with output score approaching 1) to interact with the identiﬁed
biomarkers. However, the exploration of promising drugs from a large quantity of the candidates
(predicted drugs) is still arduous. Accordingly, in order to narrow down the scope of the possible
options and improve the reliability of the ultimate selected drug combination, general criteria for drug
design speciﬁcations including regulation ability, toxicity, and sensitivity were applied to further ﬁlter
out unavailable or inappropriate medications.
Under the criteria of the pharmacological properties, the regulation ability value for each drug was
extracted from the LINCS L1000 level 5 dataset consisting of results from 978 genes of 75 cell lines
treated with 19,811 small molecular compounds. By referring to LINCS L1000, we can examine
whether a speciﬁc gene was up-regulated (positive values) or down-regulated (negative values) after
being treated with a small molecular compound. Screening through a positive-regulation of NFKBIA,
EIF4EBP1, HDAC6, STAT1, and TP53 and the negative-regulation of AKT1 and STAT3, the remaining
drugs with agreeable regulation ability for the treatment of HBV-infected patients are shown in Table 6.
Table 6. The candidate multi-target drugs for the identiﬁed biomarkers.
AKT1
Drug
Regulation ability (L1000)
Toxicity (LD50, mol/kg)
Sensitivity (EC50, nM)
ribavirin
−1.5283
1.9876
−1.18823
tacrolimus
−0.5897
2.7541
−1.50335
sorafenib
−0.3125
2.7885
−0.43586
tenofovir
−0.6152
2.955
−0.63588
meloxicam
−0.2726
3.4619
−0.68734
NFKBIA
Drug
Regulation ability (L1000)
Toxicity (LD50, mol/kg)
Sensitivity (EC50, nM)
chlortalidone
0.4056
1.8623
0.05198
busulfan
2.501
2.3207
−0.44631
rifaximin
0.681
2.6259
0.03563
sorafenib
3.5635
2.7885
−0.43586
meloxicam
3.2603
3.4619
−0.68734
EIF4EBP1
Drug
Regulation ability (L1000)
Toxicity (LD50, mol/kg)
Sensitivity (EC50, nM)
chlortalidone
0.4153
1.8623
0.05198
busulfan
0.7491
2.3207
−0.44631
rifaximin
1.7372
2.6259
0.03563
sorafenib
0.4733
2.7885
−0.43586
dactinomycin
0.2923
4.3767
0.00307

## Page 35 (Section: Systems Discovery and Design of the Multiple-Molecule Drug for HBV Infection )

Biomedicines 2020, 8, 320
35 of 48
Table 6. Cont.
HDAC6
Drug
Regulation ability (L1000)
Toxicity (LD50, mol/kg)
Sensitivity (EC50, nM)
argatroban
0.5717
1.5976
−0.01405
chlortalidone
0.6495
1.8623
0.05198
entecavir
0.5388
2.3879
0.03615
nutlin-3
0.1749
2.529
−0.6695
meloxicam
0.1047
3.4619
−0.68734
STAT1
Drug
Regulation ability (L1000)
Toxicity (LD50, mol/kg)
Sensitivity (EC50, nM)
chlortalidone
0.234
1.8623
0.05198
ribavirin
0.982
1.9876
−1.18823
zaﬁrlukast
0.2615
2.5723
−0.24097
sorafenib
0.5799
2.7885
−0.43586
hydroﬂumethiazide
1.5238
3.1299
0.3949
STAT3
Drug
Regulation ability (L1000)
Toxicity (LD50, mol/kg)
Sensitivity (EC50, nM)
argatroban
−1.2902
1.5976
−0.01405
ribavirin
−0.8934
1.9876
−1.18823
lamivudine
−0.3132
2.1348
−1.33248
zaﬁrlukast
−0.5053
2.5723
−0.24097
tenofovir
−1.5088
2.955
−0.63588
hydroﬂumethiazide
−0.7348
3.1299
0.3949
meloxicam
−1.6727
3.4619
−0.68734
TP53
Drug
Regulation ability (L1000)
Toxicity (LD50, mol/kg)
Sensitivity (EC50, nM)
acetylcysteine
1.0705
1.294
−1.2170
busulfan
2.2886
2.3207
−0.44631
nutlin-3
1.6295
2.529
−0.6695
sorafenib
0.5683
2.7885
−0.43586
calcitriol
0.4321
5.1352
0.28577
Subsequently, to further narrow down the possibilities for drug combinations, the drug toxicity
speciﬁcation (LD50) recorded in DrugBank as well as the drug sensitivity speciﬁcation (EC50) obtained
from the PRISM dataset, which is a dataset comprising sensitivity values of 4518 drugs tested across
578 human cell lines, were also adopted. Being the numeric index of lethality, median lethal dose
(LD50) plays a pivotal role in drug safety evaluation [139]. The drug with lower LD50 possesses higher
toxicity, and thus it is more detrimental. On the other hand, half maximal eﬀective concentration
(EC50) is used as a measurement of concentration, which is often adopted to evaluate the suitability
and the eﬃcacy of drugs, where lower EC50 indicates the stronger inducibility, i.e., higher sensitivity.
Based on these concepts, the drug combination comprising Sorafenib, Nutlin-3, and Tenofovir as
shown in Table 7 was then designed as the multiple-molecule drug to rejuvenate the dysfunctions in
the pathogenic mechanism under HBV infection with minor collateral tissue damage.

## Page 36 (Section: Discussion )

Biomedicines 2020, 8, 320
36 of 48
Table 7. Potential multiple-molecule drug and the corresponding target genes for HBV infection therapy.
Drugs
Targets
AKT1
NFKBIA
EIF4EBP1
HDAC6
STAT1
STAT3
TP53
Sorafenib
O
O
O
O
O
Nutlin-3
O
O
Tenofovir
O
O
Chemical structures of multi-target drugs
Sorafenib
Nutlin-3
Tenofovir
O indicates the docking between each multi-target drug composing the multiple-molecule drug and their
corresponding drug target.
Among them, Sorafenib is a multikinase inhibitor drug having been approved for several tumor
types, including Hepatocellular Carcinoma (HCC) [140]. Although prominent eﬀects of Sorafenib for
apoptosis induction were recognized, several limitations have been indicated by numerous medical
studies upon applying Sorafenib to various cancers as a single agent. Therefore, the use of Sorafenib in
combination with other targeted agents appears to be the main strategy for combatting drug resistance
and has been widely explored with promising results [141]. Falling under the category of small
molecule inhibitor, Nutlin-3 is conducive to the restoration of p53 pro-apoptotic ability, leading to the
activation of cell cycle arrest and apoptosis pathways [142]. Though it is a novel antitumor compound,
which hasn’t been clinically approved, the synergistic eﬀect of Nutlin-3 combined with other agents
contributes to diminishing of the dose required in monotherapy and decreasing the occurrence of
adverse drug events [143,144]. Being a potent nucleotide analogue reverse-transcriptase inhibitor,
Tenofovir is highly active against human immunodeﬁciency virus (HIV). In spite of its clinical use
associated with the risk of kidney injury [145], it has been shown highly eﬀective to patients who
have never undergone an antiretroviral therapy [146]. Owing to its low toxicity, triﬂe side eﬀects,
and subtle drug resistance compared to other antivirals, Tenofovir is thereby frequently used as a
member of combined drugs against HBV to ensure stronger antiviral activity and a more favorable
safety proﬁle [147,148]. It is worth noting that while therapy with Tenofovir is commonly used to
treat Hepatitis B, life-long therapy is needed, which often increases the risk of relapse. In this respect,
the combination of other viable drugs with Tenofovir may have a chance to improve the therapeutic
eﬀect and shorten the course of therapy.
Taken together, by administering the proposed multiple-molecule drug, an up-regulation of NFKBIA,
EIF4EBP1, HDAC6, STAT1, and TP53 accompanied by the down-regulation of AKT1 and STAT3 can
plausibly be attained, yielding encouraging results for the treatment of HBV-infected patients.
4. Discussion
Traditional drugs commonly used for treatment in patients aﬄicted with HBV are interferon and
nucleoside analogues. However, the low therapeutic response of patients to interferon and the inevitable
development of drug resistance to nucleoside analogues render the clinical treatment challenging [149].
In addition, serious toxic accumulation of the nucleoside analogues during long-term therapy for HBV
infection is nonnegligible as well. Therefore, great eﬀorts have been placed into seeking highly speciﬁc

## Page 37 (Section: Apoptosis in HBV Infection )

Biomedicines 2020, 8, 320
37 of 48
ligands aﬀecting single target to alleviate HBV replication and to treat HBV-related complications. Yet,
in view of the prohibitive development costs and timeline of a newly designed drug as well as the
frequent failure of monotherapy due to drug resistance, growing interest has centered on discovering
eﬀective combinations of drugs for HBV treatment.
In this study, we develop a medicine discovery and repositioning procedure in terms of system
identiﬁcation approaches via two-side RNA-seq data and deep learning-based framework considering
drug design speciﬁcations to ﬁnd a possible drug combination for the treatment of HBV infection.
Through investigation of core HPI-GEN annotated with KEGG pathways, the core signaling pathways
responsible for the abnormally regulated cellular functions were extracted and uniﬁed in Figure 4.
However, distinct cooperation between these pathways sparks diversiﬁed implication. Consequently,
further discussion of the integrated eﬀect is conducive to the selection of potential biomarkers in
relation to the remedy of HBV infection.
4.1. Apoptosis in HBV Infection
As a fundamental and highly regulated biological process, apoptosis is a form of programmed cell
death that participates in cell resistance to viral infection. Although mounting evidence shows that HBx
is uniquely endowed with the capability to regulate apoptosis, its dual role as an apoptotic mediator
raises the diﬃculty to elucidate the pathological mechanism [150].
Caspase-3 is the typical hallmark of apoptosis [110]. Numerous studies have shown that HBx abrogates
the activity of caspase-3 [151–153], resulting in resistance to assorted apoptotic stimuli. In Figure 4,
HBx-mediated inhibition activity of caspase-3 was chieﬂy through both activating XIAP, the inhibitor
of caspase-3, and directly or obliquely regulating transcription factors such as NF-κB and p53 to
aﬀect the expression of their downstream anti-apoptotic target, e.g., BCL3 and Bax. Further, even if
previous researches did not speciﬁcally indicate the paramount downstream anti-apoptotic genes of
NF-κB [154,155], BCL3, which hampers DNA damage-induced apoptosis and serves as a transcriptional
coregulator of NF-κB [78,79], counted for NF-κB -mediated anti-apoptosis a lot in the pathogenic
mechanism. Furthermore, inhibition of caspase-3 not only abrogated apoptotic killing triggered by the
pathways in response to TNF-α, FasL, and TRAIL stimulation, but also contributed to the activation
of autophagy, leading towards alleviated apoptosis coming from caspase-3 loss of its function to
cleave Beclin-1.
Asides from that, Fas, indispensable for the FasL-induced pathway that gives rise to the activation
of caspase-3, was downregulated during HBV infection. Negative-expression of Fas might impede
the sustainable anti-viral response of death ligand stimulus-speciﬁc apoptotic pathway. In contrast,
as a target gene relevant to execution and completion of apoptosis, the overexpressed CDKN1A
triggered by HBx-induced HDAC4 inhibition was concordant with the earlier research that HBx can
relieve a block on CDKN1A expression and prolong G1→S transition in human hepatoma cells [156,157].
Even though p21, the protein encoded by CDKN1A, is treated as a cyclin-dependent kinase inhibitor
capable of inhibiting all cyclin/CDK complexes, it often promotes the assembly of type-D cyclins with
CDK4 and CDK6 and arrests cell cycle progression in the G1 phase [156,158], which not only protects
cells against apoptosis but also enhances the chance of tumorigenesis.
4.2. Autophagy in HBV Infection
Autophagy is a catabolic mechanism known to engulf long-lived proteins and damaged organelles via
a lysosomal degradative pathway. Previous studies have suggested that HBV can hijack components in
the autophagic regulatory pathways to promote its survival through augmentation of autophagosomes
formation and inhibition of autolysosome maturation [159,160], which indicates the possibility of
targeting the autophagic pathway for the treatment of Hepatitis B.
HBx-catalyzed autophagic response, which is crucial for the formation of autophagosomes as well
as intensiﬁcation of viral replication, resided mainly in the increased activity of the Beclin-1/Vps34
complex accompanied by the unchanged mTOR activity and positive regulation of LC3 during HBV

## Page 38 (Section: Inflammation and Innate Immune Response in HBV Infection )

Biomedicines 2020, 8, 320
38 of 48
infection, which has also been reported in several research [159,160]. The phagophores undergo
nucleation and elongation with Beclin-1/Vps34 complex and LC3 lipidation to form double-membraned
autophagosomes [161], and the autophagic membranes generated during infection are used for
viral envelopment [162].
However, rather than Beclin-1, only PI3KC3 was activated by the
direct interconnection with HBx, which is in agreement with the study that the need for HBx to
also induce the expression of Beclin-1 is redundant [163].
Moreover, although emerging study
revealed that HBx eﬃciently impedes autophagic degradation by disturbing lysosomal acidiﬁcation
relevant to its degradative capacity without inﬂuencing on the fusion of autophagosomes and
lysosomes [160], HBx-induced reduction of HDAC6 regulation ability might lead to autophagosome
maturation failure [103]. Despite the necessity of further validation through biological experiments,
this discovery provides possible mechanistic insight into the overall observation of HBV infection.
Firstly, the intrinsic ability of HDAC6 to deacetylate NF-κB, having been detected to hamper the
invasion of cancer [164,165], was destructed by HBx through transrepression, which might gradually
create a potent microenvironment favorable to the malignant transformation of cells. Meanwhile,
the negative-regulation of HDAC6 in human HCCs and consequential loss of its tumor suppression
ability supported by previous research [166] apparently advocate the hypothesis.
4.3. Inﬂammation and Innate Immune Response in HBV Infection
Inﬂammation and innate immune response represent a highly coordinated process aimed at ﬁghting
infection or tissue injury. When cells are subject to foreign invasion, the inﬂammatory response can
ensure successful resolution of the condition and the restoration of tissue homeostasis. However,
inappropriately controlled natural defense mechanisms will eventually lead to the progression of
chronic diseases [167]. In general, innate immunity counts for a great deal in governing infection right
after contact with the pathogen to limit the spread of the virus [168]. However, the exploitation of
immune and inﬂammatory signaling pathways enables viruses to subvert antiviral immunity and
replicate in the hostile environment [169].
Of all the proteins involved in the activation and execution of inﬂammation response, NF-κB
stands out as being crucial for this process in diverse metazoan organisms. During HBV infection,
NF-κB-dependent transcription accelerated by HBx not only triggered the anti-apoptosis mechanism
in favor of viral persistence as mentioned earlier but also augmented the inﬂammatory response
leading to hepatitis and cell transformation in accordance with the indication of previous study [170].
Concurrently, emerging research has also uncovered that the dysregulated continual synthesis
of IL-6, an identiﬁed target of NF-κB, plays a pathological eﬀect on chronic inﬂammation and
autoimmunity [167], which obliquely emphasizes the magnitude of the correlation between abnormally
regulated NF-κB and excessive inﬂammation. Besides, regarding viral immunoregulation, even though
it is contradictory that HBx on one hand sensitized cells to inﬂammatory stimuli, but on the other
positive-regulated PD-L1 through transactivation of c-Jun and activation of STAT3, the ﬁndings are
consistent with the idea that production of PD-L1 transcripts pertained positively to the intensity of
liver inﬂammation to prohibit and thereby evade the host immune response [171,172].
Moreover, unlike other proteins in their family which typically share common characteristics and
functions, STAT1 and STAT3 poles apart and the mutual functional antagonism of them in T-cell-induced
inﬂammation has also been elucidated [173]. Despite both serving as the target of miR-122, SOCS1
was regulated by miR-122 and thus transactivated by HBx in the identiﬁed mechanism during HBV
infection, while SOCS3 did not. Therefore, we suggest that the abrogation of STATs activity by HBx
to attenuate the interferon-mediated suppression of infection depends on STAT1 instead of STAT3.
Meanwhile, blockades of IL-6- and IFNs-stimulated immune signaling pathways by viral proteins
were through STAT1 rather than STAT3, which also supports the idea from another perspective. In
addition, activation of STAT3 mediated by HBx also bolstered its unshakeable status on maintaining
viral persistence. Likewise, inactivation of STAT1 mediated by HBV proteins counteracted its eﬀects
on the provocation of the innate antiviral system. Such phenomena have also been revealed in the

## Page 39 (Section: Discovery of Potential Drug Combination )

Biomedicines 2020, 8, 320
39 of 48
evidence of numerous studies [174]. It is worth noting that the reported capacity of HBx to block STAT1
nuclear import by means of aﬀecting its methylation status was partially through the communication
with CBP in the identiﬁed host/pathogen cross-talk. In such a way, that STAT1 lost its ability to block
cell cycle progression and hinder hepatoma cell transformation in a course of prolonged inﬂammatory
injury. This led to continuous destruction and regeneration of hepatocytes, increasing the chances of
genetic alterations.
4.4. Discovery of Potential Drug Combination
Based on the signiﬁcant biomarkers including AKT1, NFKBIA, EIF4EBP1, HDAC6, STAT1, STAT3,
and TP53, the combination of agreeable multi-target drugs, i.e., Sorafenib, Nutlin-3, and Tenofovir,
was eventually recommended as a potential treatment for later clinical researches of the multi-drug
therapy treating HBV-infected patients. Meanwhile, to gain deeper insight into the discovery of
promising drugs, in silico proﬁling using deep learning-based DTI model was performed to predict
interactions (dockings) between available drugs and the identiﬁed biomarkers. Additionally, deciding
whether a drug is ready for clinical trials greatly pertains to preclinical studies that yield preliminary
eﬃcacy, toxicity, safety, etc., information. Therefore, to further narrow down the scope and improve the
reliability of the predicted drugs, the general pharmacological speciﬁcations for drug design including
regulation ability, toxicity, and sensitivity were additionally adopted to evaluate the eﬃcacy.
However, the entire process of moving a drug to clinical trials is actually a long way to go. Better
preclinical preparation and assessment can be beneﬁcial to the approval of a new medicine or drug
combination. Considering the common reasons for withdrawal of an approved drug, e.g., hepatotoxicity
and adverse events as well as the safety and tolerability assessment of a drug such as HLA
(human leukocyte antigen) test, is conducive to better ﬁnding an agreeable option for drug combination.
Repositioning drugs to treat with both common and rare disease is gradually becoming an attractive
proposition. Taking advantage of drug repositioning avenues provides a faster discovery and translation
of clinically relevant drug combinations. Furthermore, aided with the expediting development
of computational technology and low-cost sequencing approaches, mounting publicly accessible
data will certainly open up a broad spectrum of drug discovery and repositioning. Consequently,
by systematically integrating more extensive data and information for both drugs and targets, a more
appropriate drug combination out of the scope of original medical indication can be unveiled to bring
new hope to HBV therapeutics.
5. Conclusions
The advent of the genomic eras has presented researchers with a myriad of high throughput biological
data, which spark the interests in diverse biology applications. In this study, to investigate the
pathogenetic mechanism under HBV infection, we constructed candidate host/pathogen interspecies
genetic and epigenetic interaction network (HPI-GEN) by big data mining. Then, with the help of
the two-side RNA-seq data, system identiﬁcation strategies were applied to trim the false positives
from the candidate HPI-GEN to obtain the real HPI-GEN. Thereafter, based on the extraction of PNP
and the annotation of KEGG pathways, interspecies cross-talk signaling pathways are investigated
from the real HPI-GEN for pathogenic mechanism under HBV infection to identify signiﬁcant
biomarkers. Moreover, in order to discover promising drugs for the identiﬁed drug targets, we trained
a deep learning-based DTI model to predict possible drug-target interactions. Eventually, with the
consideration of general drug design speciﬁcations including regulation ability, toxicity, and sensitivity,
a combination of multi-target drugs as a potential multiple-molecule drug was selected to abate HBV
infection. It is worth pointing out that although only pathogenesis for HBV infection was investigated
in this work, our unique workﬂow can also be utilized on a wide variety of disease in view of systems
biology, holding utility to aid in diversiﬁed drug discovery and repurposing process. Meanwhile,
along with the development of NGS (Next-Generation Sequencing) technology, additionally integrating
analysis from available genomics data into our pipeline can reinforce better downstream analysis and

## Page 40 (Section:  )

Biomedicines 2020, 8, 320
40 of 48
perform more exact biological interpretation. As more extensive genomic and pharmacological data
being considered, the proposed pipeline could help reveal a more exhaustive host/pathogen oﬀensive
and defensive mechanism under HBV infection and facilitate the development of optimal therapy
ensuring greater therapeutic outcome.
Author Contributions: Conceptualization, S.C. and B.-S.C.; Methodology, S.C. and B.-S.C.; Software, S.C.
and B.-S.C.; Validation S.C. and B.-S.C.; Formal Analysis, S.C. and B.-S.C.; Investigation, S.C. and B.-S.C.;
Data Curation, S.C.; Writing-original Draft Preparation, S.C.; Writing-Review and Editing, S.C., L.H.-C.W.,
and B.-S.C.; Visualization, S.C.; Supervision, B.-S.C.; Funding Acquisition, B.-S.C. All authors have read and
agreed to the published version of the manuscript.
Funding:
This
research
was
funded
by
Ministry
of
Science
and
Technology
grant
number
MOST 107-2221-E-007-112-MY3.
Conﬂicts of Interest: The authors declare no conﬂict of interest.
Appendix A
In order to avoid overﬁtting in the parameter estimation process, the cubic spline interpolation
method was employed to interpolate 4 time points into 1440 points. Even if the cubic interpolation
couldn’t increase the information for the parameter estimation, it could indeed prevent the parameters
estimation in Equations (13) and (14) and (27)–(30) from overﬁtting during the identiﬁcation process.
References
1.
Chang, M.-H. Hepatitis B virus infection. Semin. Fetal Neonatal Med. 2007, 12, 160–167. [CrossRef] [PubMed]
2.
World Health Organization Global Hepatitis Report; World Health Organization: Geneva, Switzerland, 2017;
Available online: http://apps.who.int/iris/bitstream/handle/10665/255016/9789241565455-eng.pdf?sequence=1
(accessed on 18 March 2020).
3.
Hong, X.; Kim, E.S.; Guo, H. Epigenetic regulation of hepatitis B virus covalently closed circular DNA:
Implications for epigenetic therapy against chronic hepatitis B. Hepatology 2017, 66, 2066–2077. [CrossRef]
[PubMed]
4.
Fanning, G.C.; Zoulim, F.; Hou, J.; Bertoletti, A. Therapeutic strategies for hepatitis B virus infection: Towards
a cure. Nat. Rev. Drug Discov. 2019, 18, 827–844. [CrossRef]
5.
Gehring, A.J.; Protzer, U. Targeting innate and adaptive immune responses to cure chronic HBV Infection.
Gastroenterology 2019, 156, 325–337. [CrossRef]
6.
Pol, S.; Nalpas, B.; Driss, F.; Michel, M.-L.; Tiollais, P.; Denis, J.; Bréchot, C. Eﬃcacy and limitations of a
speciﬁc immunotherapy in chronic hepatitis B. J. Hepatol. 2001, 34, 917–921. [CrossRef]
7.
Shih, C.; Chou, S.-F.; Yang, C.-C.; Huang, J.-Y.; Choijilsuren, G.; Jhou, R.-S. Control and eradication strategies
of hepatitis B virus. Trends Microbiol. 2016, 24, 739–749. [CrossRef]
8.
Nassal, M. HBV cccDNA: Viral persistence reservoir and key obstacle for a cure of chronic hepatitis B. Gut
2015, 64, 1972. [CrossRef]
9.
Nosengo, N. Can you teach old drugs new tricks? Nature 2016, 534, 314–316. [CrossRef]
10.
Scannell, J.W.; Blanckley, A.; Boldon, H.; Warrington, B. Diagnosing the decline in pharmaceutical R&D
eﬃciency. Nat. Rev. Drug Discov. 2012, 11, 191–200.
11.
Rao, V.S.; Srinivas, K.; Sujini, G.N.; Kumar, G.N.S. Protein-protein interaction detection: Methods and
analysis. Int J. Proteom. 2014, 2014, 147648. [CrossRef] [PubMed]
12.
Droit, A.; Poirier, G.; Hunter, J. Experimental and bioinformatic approaches for interrogating protein-protein
interactions to determine protein function. J. Mol. Endocrinol. 2005, 34, 263–280. [CrossRef] [PubMed]
13.
Ashburn, T.T.; Thor, K.B. Drug repositioning: Identifying and developing new uses for existing drugs.
Nat. Rev. Drug Discov. 2004, 3, 673–683. [CrossRef]
14.
Antolin, A.A.; Workman, P.; Mestres, J.; Al-Lazikani, B. Polypharmacology in precision oncology: Current
applications and future prospects. Curr. Pharm. Des. 2016, 22, 6935–6945. [CrossRef] [PubMed]
15.
Mueller, H.; Wildum, S.; Luangsay, S.; Walther, J.; Lopez, A.; Tropberger, P.; Ottaviani, G.; Lu, W.; Parrott, N.;
Zhang, J.D.; et al. A novel orally available small molecule that inhibits hepatitis B virus expression. J. Hepatol.
2017, 68, 412–420. [CrossRef] [PubMed]

## Page 41 (Section:  )

Biomedicines 2020, 8, 320
41 of 48
16.
Stark, C.; Breitkreutz, B.-J.; Reguly, T.; Boucher, L.; Breitkreutz, A.; Tyers, M. BioGRID: A general repository
for interaction datasets. Nucleic Acids Res. 2006, 34, D535–D539. [CrossRef]
17.
Salwinski, L.; Miller, C.S.; Smith, A.J.; Pettit, F.K.; Bowie, J.U.; Eisenberg, D. The database of interacting
proteins: 2004 update. Nucleic Acids Res. 2004, 32, D449–D451. [CrossRef]
18.
Bader, G.D.; Betel, D.; Hogue, C.W.V. BIND: The biomolecular interaction network database. Nucleic Acids Res.
2003, 31, 248–250. [CrossRef]
19.
Orchard, S.; Ammari, M.; Aranda, B.; Breuza, L.; Briganti, L.; Broackes-Carter, F.; Campbell, N.H.; Chavali, G.;
Chen, C.; del-Toro, N.; et al. The MIntAct project–IntAct as a common curation platform for 11 molecular
interaction databases. Nucleic Acids Res. 2014, 42, D358–D363. [CrossRef]
20.
Licata, L.; Briganti, L.; Peluso, D.; Perfetto, L.; Iannuccelli, M.; Galeota, E.; Sacco, F.; Palma, A.; Nardozza, A.P.;
Santonico, E.; et al. MINT, the molecular interaction database: 2012 update. Nucleic Acids Res. 2012, 40,
D857–D861. [CrossRef]
21.
Min, H.; Yoon, S. Got target? Computational methods for microRNA target prediction and their extension.
Exp. Mol. Med. 2010, 42, 233–244. [CrossRef]
22.
Friard, O.;
Re, A.;
Taverna, D.;
De Bortoli, M.;
Corá, D. CircuitsDB: A database of mixed
microRNA/transcription factor feed-forward regulatory circuits in human and mouse. BMC Bioinform. 2010,
11, 435. [CrossRef] [PubMed]
23.
Zheng, G.; Tu, K.; Yang, Q.; Xiong, Y.; Wei, C.; Xie, L.; Zhu, Y.; Li, Y. ITFP: An integrated platform of
mammalian transcription factors. Bioinformatics 2008, 24, 2416–2417. [CrossRef] [PubMed]
24.
Bovolenta, L.A.; Acencio, M.L.; Lemke, N. HTRIdb: An open-access database for experimentally veriﬁed
human transcriptional regulation interactions. BMC Genom. 2012, 13, 405. [CrossRef] [PubMed]
25.
Wingender, E.; Chen, X.; Hehl, R.; Karas, H.; Liebich, I.; Matys, V.; Meinhardt, T.; Prüss, M.; Reuter, I.;
Schacherer, F. TRANSFAC: An integrated system for gene expression regulation. Nucleic Acids Res. 2000, 28,
316–319. [CrossRef]
26.
Calderone, A.; Licata, L.; Cesareni, G. VirusMentha: A new resource for virus-host protein interactions.
Nucleic Acids Res. 2014, 43, D588–D592. [CrossRef]
27.
Orchard, S.; Kerrien, S.; Abbani, S.; Aranda, B.; Bhate, J.; Bidwell, S.; Bridge, A.; Briganti, L.; Brinkman, F.S.L.;
Cesareni, G.; et al.
Protein interaction data curation: The International Molecular Exchange (IMEx)
consortium. Nat. Methods 2012, 9, 345–350. [CrossRef]
28.
del-Toro, N.; Dumousseau, M.; Orchard, S.; Jimenez, R.C.; Galeota, E.; Launay, G.; Goll, J.; Breuer, K.; Ono, K.;
Salwinski, L.; et al. A new reference implementation of the PSICQUIC web service. Nucleic Acids Res. 2013,
41, W601–W606. [CrossRef]
29.
Wu, Z.-J.; Zhu, Y.; Huang, D.-R.; Wang, Z.-Q. Constructing the HBV-human protein interaction network to
understand the relationship between HBV and hepatocellular carcinoma. J. Exp. Clin. Cancer Res. 2010, 29,
146. [CrossRef]
30.
Qureshi, A.; Thakur, N.; Monga, I.; Thakur, A.; Kumar, M. VIRmiRNA: A comprehensive resource for
experimentally validated viral miRNAs and their targets. Database 2014. [CrossRef]
31.
Li, C.-W.; Wang, W.-H.; Chen, B.-S. Investigating the speciﬁc core genetic-and-epigenetic networks of cellular
mechanisms involved in human aging in peripheral blood mononuclear cells. Oncotarget 2016, 7, 8556–8579.
[CrossRef]
32.
Xiao, F.; Zuo, Z.; Cai, G.; Kang, S.; Gao, X.; Li, T. miRecords: An integrated resource for microRNA–target
interactions. Nucleic Acids Res. 2008, 37, D105–D110. [CrossRef] [PubMed]
33.
Li, J.-H.; Liu, S.; Zhou, H.; Qu, L.-H.; Yang, J.-H. starBase v2.0: Decoding miRNA-ceRNA, miRNA-ncRNA
and protein–RNA interaction networks from large-scale CLIP-Seq data. Nucleic Acids Res. 2013, 42, D92–D97.
[CrossRef] [PubMed]
34.
Hsu, S.-D.; Lin, F.-M.; Wu, W.-Y.; Liang, C.; Huang, W.-C.; Chan, W.-L.; Tsai, W.-T.; Chen, G.-Z.; Lee, C.-J.;
Chiu, C.-M.; et al. miRTarBase: A database curates experimentally validated microRNA–target interactions.
Nucleic Acids Res. 2010, 39, D163–D169. [CrossRef] [PubMed]
35.
Kim, D.; Lee, J.; So, C.; Jeon, H.; Jeong, M.; Choi, Y.; Yoon, W.; Sung, M.; Kang, J. A neural named entity
recognition and multi-type normalization tool for biomedical text mining. IEEE Access 2019, 7, 1. [CrossRef]
36.
Lee, J.; Yoon, W.; Kim, S.; Kim, D.; Kim, S.; So, C.; Kang, J. BioBERT: A pre-trained biomedical language
representation model for biomedical text mining. Bioinformatics 2019, 1, 36. [CrossRef] [PubMed]

## Page 42 (Section:  )

Biomedicines 2020, 8, 320
42 of 48
37.
Liu, H.; Hu, Z.-Z.; Zhang, J.; Wu, C. BioThesaurus: A web-based thesaurus of protein and gene names.
Bioinformatics 2005, 22, 103–105. [CrossRef] [PubMed]
38.
Vogel, C.; Marcotte, E.M. Insights into the regulation of protein abundance from proteomic and transcriptomic
analyses. Nat. Rev. Genet. 2012, 13, 227–232. [CrossRef]
39.
Eulalio, A.; Huntzinger, E.; Izaurralde, E. Getting to the root of miRNA-Mediated gene silencing. Cell 2008,
132, 9–14. [CrossRef]
40.
Zhang, S.; Pointer, D.; Singer, G.; Feng, Y.; Park, K.; Zhao, L.J. Direct binding to nucleic acids by Vpr of
human immunodeﬁciency virus type 1. Gene 1998, 212, 157–166. [CrossRef]
41.
Williams, J.S.; Andrisani, O.M. The hepatitis B virus X protein targets the basic region-leucine zipper domain
of CREB. Proc. Natl. Acad. Sci. USA 1995, 92, 3819. [CrossRef]
42.
Cheong, J.H.; Yi, M.; Lin, Y.; Murakami, S. Human RPB5, a subunit shared by eukaryotic nuclear RNA
polymerases, binds human hepatitis B virus X protein and may play a role in X transactivation. EMBO J.
1995, 14, 143–150. [CrossRef] [PubMed]
43.
Maguire, H.F.; Hoeﬄer, J.P.; Siddiqui, A. HBV X protein alters the DNA binding speciﬁcity of CREB and
ATF-2 by protein-protein interactions. Science 1991, 252, 842. [CrossRef] [PubMed]
44.
Kuzhandaivelu, N.; Cong, Y.S.; Inouye, C.; Yang, W.M.; Seto, E. XAP2, a novel hepatitis B virus X-associated
protein that inhibits X transactivation. Nucleic Acids Res. 1996, 24, 4741–4750. [CrossRef] [PubMed]
45.
Ganem, D.; Prince, A.M. Hepatitis B virus infection–natural history and clinical consequences. N. Engl.
J. Med. 2004, 350, 1118–1129. [CrossRef]
46.
Mitra, B.; Thapa, R.J.; Guo, H.; Block, T.M. Host functions used by hepatitis B virus to complete its life cycle:
Implications for developing host-targeting agents to treat chronic hepatitis B. Antivir. Res. 2018, 158, 185–198.
[CrossRef]
47.
Walsh, D.; Mohr, I. Viral subversion of the host protein synthesis machinery. Nat. Rev. Microbiol. 2011, 9,
860–875. [CrossRef]
48.
Lu, P.; Vogel, C.; Wang, R.; Yao, X.; Marcotte, E.M. Absolute protein expression proﬁling estimates the relative
contributions of transcriptional and translational regulation. Nat. Biotechnol. 2007, 25, 117–124. [CrossRef]
49.
Anderson, L.; Seilhamer, J. A comparison of selected mRNA and protein abundances in human liver.
Electrophoresis 1997, 18, 533–537. [CrossRef]
50.
de Sousa Abreu, R.; Penalva, L.O.; Marcotte, E.M.; Vogel, C. Global signatures of protein and mRNA
expression levels. Mol. Biosyst. 2009, 5, 1512–1526. [CrossRef]
51.
Maier, T.; Güell, M.; Serrano, L. Correlation of mRNA and protein in complex biological samples. FEBS Lett.
2009, 583, 3966–3973. [CrossRef]
52.
Wang, Y.C.; Chen, B.S. Integrated cellular network of transcription regulations and protein-protein interactions.
BMC Syst. Biol. 2010, 4, 20. [CrossRef] [PubMed]
53.
The UniProt, C. UniProt: A worldwide hub of protein knowledge. Nucleic Acids Res. 2018, 47, D506–D515.
[CrossRef] [PubMed]
54.
Knox, C.; Law, V.; Jewison, T.; Liu, P.; Ly, S.; Frolkis, A.; Pon, A.; Banco, K.; Mak, C.; Neveu, V.; et al. DrugBank
3.0: A comprehensive resource for ’omics’ research on drugs. Nucleic Acids Res. 2011, 39, D1035–D1041.
[CrossRef] [PubMed]
55.
Gaulton, A.; Bellis, L.J.; Bento, A.P.; Chambers, J.; Davies, M.; Hersey, A.; Light, Y.; McGlinchey, S.;
Michalovich, D.; Al-Lazikani, B.; et al. ChEMBL: A large-scale bioactivity database for drug discovery.
Nucleic Acids Res. 2012, 40, D1100–D1107. [CrossRef] [PubMed]
56.
Kim, S.; Thiessen, P.A.; Bolton, E.E.; Chen, J.; Fu, G.; Gindulyte, A.; Han, L.; He, J.; He, S.; Shoemaker, B.A.;
et al. PubChem Substance and Compound databases. Nucleic Acids Res. 2016, 44, D1202–D1213. [CrossRef]
[PubMed]
57.
Liu, T.; Lin, Y.; Wen, X.; Jorissen, R.N.; Gilson, M.K. BindingDB: A web-accessible database of experimentally
determined protein–ligand binding aﬃnities. Nucleic Acids Res. 2006, 35, D198–D201. [CrossRef] [PubMed]
58.
Khan, S.A.; Virtanen, S.; Kallioniemi, O.P.; Wennerberg, K.; Poso, A.; Kaski, S. Identiﬁcation of
structural features in chemicals associated with cancer drug response: A systematic data-driven analysis.
Bioinform. Oxf. Engl. 2014, 30, i497–i504. [CrossRef]
59.
Nandy, A.; Harle, M.; Basak, S. Mathematical descriptors of DNA sequences: Development and applications.
Gen. Pap. Ark. 2006, 9, 211–238.

## Page 43 (Section:  )

Biomedicines 2020, 8, 320
43 of 48
60.
Gron, A. Hands-On Machine Learning with Scikit-Learn. and TensorFlow: Concepts, Tools, and Techniques to Build.
Intelligent Systems; O’Reilly Media, Inc.: Newton, MA, USA, 2017.
61.
Raschka, S. Python Machine Learning; Packt Publishing: Birmingham, UK, 2015.
62.
Abdi, H.; Williams, L.J. Principal component analysis. WIREs Comput. Stat. 2010, 2, 433–459. [CrossRef]
63.
Goodfellow, I.; Bengio, Y.; Courville, A. Deep Learning; The MIT Press: Cambridge, MA, USA, 2016.
64.
Kingma, D.; Ba, J. Adam: A Method for Stochastic Optimization. arXiv 2014, arXiv:1412.6980.
65.
Bradley, A.P. The use of the area under the ROC curve in the evaluation of machine learning algorithms.
Pattern Recognit. 1997, 30, 1145–1159. [CrossRef]
66.
Tiollais, P.; Pourcel, C.; Dejean, A. The hepatitis B virus. Nature 1985, 317, 489–495. [CrossRef] [PubMed]
67.
Ganem, D.; Varmus, H.E. THE molecular biology of the hepatitis B viruses. Annu. Rev. Biochem. 1987, 56,
651–693. [CrossRef] [PubMed]
68.
Tuttleman, J.S.; Pourcel, C.; Summers, J. Formation of the pool of covalently closed circular viral DNA in
hepadnavirus-infected cells. Cell 1986, 47, 451–460. [CrossRef]
69.
Zakaria, M.K.; Sankhyan, A.; Ali, A.; Fatima, K.; Azhar, E.; Qadri, I. HBV/HCV Infection and Inﬂammation.
J. Genet. Syndr. Gene Ther. 2014, 5, 241.
70.
Chen, L.; Deng, H.; Cui, H.; Fang, J.; Zuo, Z.; Deng, J.; Li, Y.; Wang, X.; Zhao, L. Inﬂammatory responses and
inﬂammation-associated diseases in organs. Oncotarget 2017, 9, 7204–7218. [CrossRef]
71.
Garcia-Gomez, A.; Rodríguez-Ubreva, J.; Ballestar, E. Epigenetic interplay between immune, stromal and
cancer cells in the tumor microenvironment. Clin. Immunol. 2018, 196, 64–71. [CrossRef]
72.
Ma, Z.; Cao, Q.; Xiong, Y.; Zhang, E.; Lu, M. Interaction between hepatitis B virus and toll-like receptors:
Current status and potential therapeutic use for chronic hepatitis B. Vaccines 2018, 6, 6. [CrossRef]
73.
Jacobs, M.D.; Harrison, S.C. Structure of an IκBα/NF-κB Complex. Cell 1998, 95, 749–758. [CrossRef]
74.
Tanaka, T.; Narazaki, M.; Kishimoto, T. IL-6 in inﬂammation, immunity, and disease. Cold Spring Harb.
Perspect. Biol. 2014, 6, a016295. [CrossRef]
75.
Lee, Y.; Park, U.S.; Choi, I.; Yoon, S.K.; Park, Y.M.; Lee, Y.I. Human interleukin 6 gene is activated by hepatitis
B virus-X protein in human hepatoma cells. Clin. Cancer Res. 1998, 4, 1711. [PubMed]
76.
Ivashkiv, L.B.; Donlin, L.T. Regulation of type I interferon responses. Nat. Rev. Immunol. 2014, 14, 36–49.
[CrossRef]
77.
Schoenborn, J.; Wilson, C. Regulation of Interferon-γ During Innate and Adaptive Immune Responses.
Adv. Immunol. 2007, 96, 41–101. [PubMed]
78.
Nolan, G.P.; Fujita, T.; Bhatia, K.; Huppi, C.; Liou, H.C.; Scott, M.L.; Baltimore, D. The bcl-3 proto-oncogene
encodes a nuclear I kappa B-like molecule that preferentially interacts with NF-kappa B p50 and p52 in a
phosphorylation-dependent manner. Mol. Cell. Biol. 1993, 13, 3557. [CrossRef] [PubMed]
79.
Kashatus, D.; Cogswell, P.; Baldwin, A.S. Expression of the Bcl-3 proto-oncogene suppresses p53 activation.
Genes Dev. 2006, 20, 225–235. [CrossRef] [PubMed]
80.
Dann, S.G.; Thomas, G. The amino acid sensitive TOR pathway from yeast to mammals. FEBS Lett. 2006,
580, 2821–2829. [CrossRef]
81.
Lee, D.-F.; Kuo, H.-P.; Chen, C.-T.; Hsu, J.-M.; Chou, C.-K.; Wei, Y.; Sun, H.-L.; Li, L.-Y.; Ping, B.; Huang, W.-C.;
et al. IKKβ suppression of TSC1 Links inﬂammation and tumor angiogenesis via the Mtor pathway. Cell
2007, 130, 440–455. [CrossRef]
82.
Richter, J.D.; Sonenberg, N. Regulation of cap-dependent translation by eIF4E inhibitory proteins. Nature
2005, 433, 477–480. [CrossRef]
83.
Mohr, I. Phosphorylation and dephosphorylation events that regulate viral mRNA translation. Virus Res.
2006, 119, 89–99. [CrossRef]
84.
Ryu, D.-K.; Ahn, B.-Y.; Ryu, W.-S. Proximity between the cap and 5′ ε stem–loop structure is critical for the
suppression of pgRNA translation by the hepatitis B viral polymerase. Virology 2010, 406, 56–64. [CrossRef]
85.
Sugatani, T.; Hruska, K.A. Akt1/Akt2 and mammalian target of rapamycin/Bim play critical roles in osteoclast
diﬀerentiation and survival, respectively, whereas Akt is dispensable for cell survival in isolated osteoclast
precursors. J. Biol. Chem. 2005, 280, 3583–3589. [CrossRef] [PubMed]
86.
Inoki, K.; Li, Y.; Zhu, T.; Wu, J.; Guan, K.-L. TSC2 is phosphorylated and inhibited by Akt and suppresses
mTOR signalling. Nat. Cell Biol. 2002, 4, 648–657. [CrossRef] [PubMed]

## Page 44 (Section:  )

Biomedicines 2020, 8, 320
44 of 48
87.
Ogawara, Y.; Kishishita, S.; Obata, T.; Isazawa, Y.; Suzuki, T.; Tanaka, K.; Masuyama, N.; Gotoh, Y. Akt
Enhances Mdm2-mediated Ubiquitination and Degradation of p53. J. Biol. Chem. 2002, 277, 21843–21850.
[CrossRef] [PubMed]
88.
Chiu, A.P.; Tschida, B.R.; Sham, T.-T.; Lo, L.H.; Moriarity, B.S.; Li, X.-X.; Lo, R.C.; Hinton, D.E.; Rowlands, D.K.;
Chan, C.-O.; et al. HBx-K130M/V131I promotes liver cancer in transgenic mice via AKT/FOXO1 signaling
pathway and arachidonic acid metabolism. Mol. Cancer Res. 2019, 17, 1582. [CrossRef]
89.
Burton, T.R.; Gibson, S.B. The role of Bcl-2 family member BNIP3 in cell death and disease: NIPping at the
heels of cell death. Cell Death Diﬀer. 2009, 16, 515–523. [CrossRef]
90.
Liu, J.; Cao, L.; Chen, J.; Song, S.; Lee, I.H.; Quijano, C.; Liu, H.; Keyvanfar, K.; Chen, H.; Cao, L.-Y.; et al.
Bmi1 regulates mitochondrial function and the DNA damage response pathway. Nature 2009, 459, 387–392.
[CrossRef]
91.
Alkema, M.; Wiegant, J.; Raap, A.K.; Bems, A.; van Lohuizen, M. Characterization and chromosomal
localization of the human proto-oncogene BMI-1. Hum. Mol. Genet. 1993, 2, 1597–1603. [CrossRef]
92.
Danial, N.N.; Korsmeyer, S.J. Cell Death: Critical Control Points. Cell 2004, 116, 205–219. [CrossRef]
93.
Oh, H.-M.; Yu, C.-R.; Dambuza, I.; Marrero, B.; Egwuagu, C.E. STAT3 protein interacts with Class O Forkhead
transcription factors in the cytoplasm and regulates nuclear/cytoplasmic localization of FoxO1 and FoxO3a
proteins in CD4(+) T cells. J. Biol. Chem. 2012, 287, 30436–30443. [CrossRef]
94.
Shlomai, A.; Shaul, Y. The metabolic activator FOXO1 binds hepatitis B virus DNA and activates its
transcription. Biochem. Biophys. Res. Commun. 2009, 381, 544–548. [CrossRef]
95.
Hirata, Y.; Takahashi, M.; Morishita, T.; Noguchi, T.; Matsuzawa, A. Post-Translational modiﬁcations of the
TAK1-TAB complex. Int J. Mol. Sci. 2017, 18, 205. [CrossRef] [PubMed]
96.
Shaulian, E.; Karin, M. AP-1 as a regulator of cell life and death. Nat. Cell Biol. 2002, 4, E131–E136. [CrossRef]
[PubMed]
97.
Schonthaler, H.B.; Guinea-Viniegra, J.; Wagner, E.F. Targeting inﬂammation by modulating the Jun/AP-1
pathway. Ann. Rheum. Dis. 2011, 70, i109. [CrossRef] [PubMed]
98.
Akira, S. The role of IL-18 in innate immunity. Curr. Opin. Immunol. 2000, 12, 59–63. [CrossRef]
99.
Qin, W.; Hu, L.; Zhang, X.; Jiang, S.; Li, J.; Zhang, Z.; Wang, X. The diverse function of PD-1/PD-L pathway
beyond cancer. Front. Immunol. 2019, 10, 2298. [CrossRef] [PubMed]
100. Motokura, T.; Bloom, T.; Kim, H.G.; Jüppner, H.; Ruderman, J.V.; Kronenberg, H.M.; Arnold, A. A novel
cyclin encoded by a bcl1-linked candidate oncogene. Nature 1991, 350, 512–515. [CrossRef] [PubMed]
101. Fujioka, S.; Niu, J.; Schmidt, C.; Sclabas, G.M.; Peng, B.; Uwagawa, T.; Li, Z.; Evans, D.B.; Abbruzzese, J.L.;
Chiao, P.J. NF-κB and AP-1 connection: Mechanism of NF-κB-Dependent regulation of AP-1 activity.
Mol. Cell. Biol. 2004, 24, 7806. [CrossRef] [PubMed]
102. Rebollo, A.; Dumoutier, L.; Renauld, J.C.; Zaballos, A.; Ayllón, V.; Martínez-A, C. Bcl-3 expression promotes
cell survival following interleukin-4 deprivation and is controlled by AP1 and AP1-like transcription factors.
Mol. Cell. Biol. 2000, 20, 3407–3416. [CrossRef]
103. Lee, J.-Y.; Koga, H.; Kawaguchi, Y.; Tang, W.; Wong, E.; Gao, Y.-S.; Pandey, U.B.; Kaushik, S.; Tresse, E.;
Lu, J.; et al. HDAC6 controls autophagosome maturation essential for ubiquitin-selective quality-control
autophagy. EMBO J. 2010, 29, 969–980. [CrossRef]
104. Aaronson, D.S.; Horvath, C.M. A road map for those who don’t know JAK-STAT. Science 2002, 296, 1653–1655.
[CrossRef]
105. Stark, G.R.; Kerr, I.M.; Williams, B.R.; Silverman, R.H.; Schreiber, R.D. How cells respond to interferons.
Annu. Rev. Biochem. 1998, 67, 227–264. [CrossRef] [PubMed]
106. Ferrari, S.M.; Fallahi, P.; Ruﬃlli, I.; Elia, G.; Ragusa, F.; Paparo, S.R.; Patrizio, A.; Mazzi, V.; Colaci, M.;
Giuggioli, D.; et al. Immunomodulation of CXCL10 Secretion by hepatitis C Virus: Could CXCL10 be a
prognostic marker of chronic hepatitis C? J. Immunol. Res. 2019, 2019, 5878960. [CrossRef] [PubMed]
107. Park, J.-W.; Li, Z.; Choi, J.-S.; Oh, H.-J.; Park, S.-H.; Yoon, K.-C. Expression of CXCL9, -10, and -11 in the
aqueous humor of patients with herpetic endotheliitis. Cornea 2012, 31, 1246–1250. [CrossRef] [PubMed]
108. Nordmann, A.; Wixler, L.; Boergeling, Y.; Wixler, V.; Ludwig, S. A new splice variant of the human
guanylate-binding protein 3 mediates anti-inﬂuenza activity through inhibition of viral transcription and
replication. FASEB J. 2011, 26, 1290–1300. [CrossRef]

## Page 45 (Section:  )

Biomedicines 2020, 8, 320
45 of 48
109. Ueda, T.; Watanabe-Fukunaga, R.; Fukuyama, H.; Nagata, S.; Fukunaga, R. Mnk2 and Mnk1 are essential
for constitutive and inducible phosphorylation of eukaryotic initiation factor 4E but not for cell growth or
development. Mol. Cell. Biol. 2004, 24, 6539–6549. [CrossRef]
110. Porter, A.G.; Jänicke, R.U. Emerging roles of caspase-3 in apoptosis. Cell Death Diﬀer. 1999, 6, 99–104.
[CrossRef]
111. Stennicke, H.; Jürgensmeier, J.; Shin, H.; Deveraux, Q.; Wolf, B.; Yang, X.; Zhou, Q.; Ellerby, H.; Ellerby, L.;
Bredesen, D.; et al. Pro-caspase-3 Is a Major Physiologic Target of Caspase8. J. Biol. Chem. 1998, 273,
27084–27090. [CrossRef]
112. Wang, J.; Chun, H.J.; Wong, W.; Spencer, D.M.; Lenardo, M.J. Caspase-10 is an initiator caspase in death
receptor signaling. Proc. Natl. Acad. Sci. USA 2001, 98, 13884. [CrossRef]
113. Dikic, I.; Elazar, Z. Mechanism and medical implications of mammalian autophagy. Nat. Rev. Mol. Cell Biol.
2018, 19, 349–364. [CrossRef]
114. Gottlieb, T.M.; Jackson, S.P. The DNA-dependent protein kinase: Requirement for DNA ends and association
with Ku antigen. Cell 1993, 72, 131–142. [CrossRef]
115. Liu, X.; Zou, H.; Slaughter, C.; Wang, X. DFF, a Heterodimeric Protein That Functions Downstream of
Caspase-3 to Trigger DNA Fragmentation during Apoptosis. Cell 1997, 89, 175–184. [CrossRef]
116. Dan, H.; Sun, M.; Kaneko, S.; Feldman, R.; Nicosia, S.; Wang, H.-G.; Tsang, B.; Cheng, J. Akt Phosphorylation
and Stabilization of X-linked Inhibitor of Apoptosis Protein (XIAP). J. Biol. Chem. 2004, 279, 5405–5412.
[CrossRef]
117. Scott, F.L.; Denault, J.-B.; Riedl, S.J.; Shin, H.; Renatus, M.; Salvesen, G.S. XIAP inhibits caspase-3 and -7 using
two binding sites: Evolutionarily conserved mechanism of IAPs. EMBO J. 2005, 24, 645–655. [CrossRef]
[PubMed]
118. Ahnesorg, P.; Smith, P.; Jackson, S.P. XLF Interacts with the XRCC4-DNA Ligase IV Complex to Promote
DNA Nonhomologous End-Joining. Cell 2006, 124, 301–313. [CrossRef] [PubMed]
119. Wang, S.; Qiu, L.; Yan, X.; Jin, W.; Wang, Y.; Chen, L.; Wu, E.; Ye, X.; Gao, G.F.; Wang, F.; et al. Loss of
microRNA 122 expression in patients with hepatitis B enhances hepatitis B virus replication through cyclin
G1-modulated P53 activity. Hepatology 2012, 55, 730–741. [CrossRef] [PubMed]
120. Wang, X.W.; Gibson, M.K.; Vermeulen, W.; Yeh, H.; Forrester, K.; Stürzbecher, H.W.; Hoeijmakers, J.H.;
Harris, C.C. Abrogation of p53-induced apoptosis by the hepatitis B virus X gene. Cancer Res. 1995, 55,
6012–6016.
121. Lee, S.G.; Rho, H.M. Transcriptional repression of the human p53 gene by hepatitis B viral X protein. Oncogene
2000, 19, 468–471. [CrossRef]
122. Moll, U.M.; Petrenko, O. The MDM2-p53 Interaction. Mol. Cancer Res. 2003, 1, 1001.
123. Cregan, S.P.; MacLaurin, J.G.; Craig, C.G.; Robertson, G.S.; Nicholson, D.W.; Park, D.S.; Slack, R.S.
Bax-Dependent Caspase-3 Activation Is a Key Determinant in p53-Induced Apoptosis in Neurons. J. Neurosci.
1999, 19, 7860. [CrossRef]
124. Chipuk, J.E.; Kuwana, T.; Bouchier-Hayes, L.; Droin, N.M.; Newmeyer, D.D.; Schuler, M.; Green, D.R. Direct
activation of bax by p53 mediates mitochondrial membrane permeabilization and apoptosis. Science 2004,
303, 1010. [CrossRef]
125. Sofer, A.; Lei, K.; Johannessen, C.M.; Ellisen, L.W. Regulation of mTOR and cell growth in response to energy
stress by REDD1. Mol. Cell. Biol. 2005, 25, 5834–5845. [CrossRef] [PubMed]
126. Ellisen, L.W.; Ramsayer, K.D.; Johannessen, C.M.; Yang, A.; Beppu, H.; Minda, K.; Oliner, J.D.; McKeon, F.;
Haber, D.A. REDD1, a developmentally regulated transcriptional target of p63 and p53, links p63 to regulation
of reactive oxygen species. Mol. Cell 2002, 10, 995–1005. [CrossRef]
127. Pineau, P.; Volinia, S.; McJunkin, K.; Marchio, A.; Battiston, C.; Terris, B.; Mazzaferro, V.; Lowe, S.W.;
Croce, C.M.; Dejean, A. miR-221 overexpression contributes to liver tumorigenesis. Proc. Natl. Acad. Sci. USA
2010, 107, 264–269. [CrossRef] [PubMed]
128. Fu, X.; Tan, D.; Hou, Z.; Hu, Z.; Liu, G. miR-338-3p is down-regulated by hepatitis B virus X and inhibits cell
proliferation by targeting the 3’-UTR region of CyclinD1. Int. J. Mol. Sci. 2012, 13, 8514–8539. [CrossRef]
[PubMed]
129. Lu, R.; Yang, Z.; Xu, G.; Yu, S. miR-338 modulates proliferation and autophagy by PI3K/AKT/mTOR signaling
pathway in cervical cancer. Biomed. Pharmacother. 2018, 105, 633–644. [CrossRef]

## Page 46 (Section:  )

Biomedicines 2020, 8, 320
46 of 48
130. Darnell, J.E.; Kerr, I.M.; Stark, G.R. Jak-STAT pathways and transcriptional activation in response to IFNs
and other extracellular signaling proteins. Science 1994, 264, 1415. [CrossRef]
131. Wu, M.; Xu, Y.; Lin, S.; Zhang, X.; Xiang, L.; Yuan, Z. Hepatitis B virus polymerase inhibits the
interferon-inducible MyD88 promoter by blocking nuclear translocation of Stat 1. J. Gen. Virol. 2008,
88, 3260–3269. [CrossRef]
132. Gao, D.; Zhai, A.; Qian, J.; Li, A.; Li, Y.; Song, W.; Zhao, H.; Yu, X.; Wu, J.; Zhang, Q.; et al. Down-regulation
of suppressor of cytokine signaling 3 by miR-122 enhances interferon-mediated suppression of hepatitis B
virus. Antivir. Res. 2015, 118, 20–28. [CrossRef]
133. Li, A.; Song, W.; Qian, J.; Li, Y.; He, J.; Zhang, Q.; Li, W.; Zhai, A.; Kao, W.; Hu, Y.; et al. MiR-122 modulates
type I interferon expression through blocking suppressor of cytokine signaling 1. Int. J. Biochem. Cell Biol.
2013, 45, 858–865. [CrossRef]
134. Xavier, G.; Antoine, B.; Yoshua, B. Deep sparse rectiﬁer neural networks. PMLR 2011, 15, 315–323.
135. Srivastava, N.; Hinton, G.; Krizhevsky, A.; Sutskever, I.; Salakhutdinov, R. Dropout: A simple way to prevent
neural networks from overﬁtting. J. Mach. Learn. Res. 2014, 15, 1929–1958.
136. Cao, D.S.; Zhang, L.X.; Tan, G.S.; Xiang, Z.; Zeng, W.B.; Xu, Q.S.; Chen, A.F. Computational prediction of
drug target interactions using chemical, biological, and network features. Mol. Inform. 2014, 33, 669–681.
[CrossRef] [PubMed]
137. Byvatov, E.; Fechner, U.; Sadowski, J.; Schneider, G. Comparison of support vector machine and artiﬁcial
neural network systems for drug/nondrug classiﬁcation. J. Chem. Inf. Comput. Sci. 2003, 43, 1882–1889.
[CrossRef] [PubMed]
138. Liu, Y.; Wu, M.; Miao, C.; Zhao, P.; Li, X.-L. Neighborhood regularized logistic matrix factorization for
drug-target interaction prediction. PLoS Comput. Biol. 2016, 12, e1004760. [CrossRef] [PubMed]
139. LeBeau, J.E. The role of the LD50 determination in drug safety evaluation. Regul. Toxicol. Pharmacol. 1983, 3,
71–74. [CrossRef]
140. Wilhelm, S.; Carter, C.; Lynch, M.; Lowinger, T.; Dumas, J.; Smith, R.A.; Schwartz, B.; Simantov, R.; Kelley, S.
Discovery and development of sorafenib: A multikinase inhibitor for treating cancer. Nat. Rev. Drug Discov.
2006, 5, 835–844. [CrossRef]
141. Ibrahim, N.; Yu, Y.; Walsh, W.R.; Yang, J.L. Molecular targeted therapies for cancer: Sorafenib mono-therapy
and its combination with other therapies (review). Oncol. Rep. 2012, 27, 1303–1311.
142. Miao, R.; Xu, X.; Wang, Z.; Liu, S.; Qu, K.; Chen, W.; Liu, C. Synergistic eﬀect of nutlin-3 combined with aspirin
in hepatocellular carcinoma HepG2 cells through activation of Bcl-2/Bax signaling pathway. Mol. Med. Rep.
2018, 17, 3735–3743. [CrossRef]
143. Tokalov, S.V.; Abolmaali, N.D. Protection of p53 wild type cells from taxol by nutlin-3 in the combined lung
cancer treatment. BMC Cancer 2010, 10, 57. [CrossRef]
144. Zheng, T.; Wang, J.; Song, X.; Meng, X.; Pan, S.; Jiang, H.; Liu, L. Nutlin-3 cooperates with doxorubicin to
induce apoptosis of human hepatocellular carcinoma cells through p53 or p73 signaling pathways. J. Cancer
Res. Clin. Oncol 2010, 136, 1597–1604. [CrossRef]
145. Fernandez-Fernandez, B.; Montoya-Ferrer, A.; Sanz, A.B.; Sanchez-Niño, M.D.; Izquierdo, M.C.; Poveda, J.;
Sainz-Prestel, V.; Ortiz-Martin, N.; Parra-Rodriguez, A.; Selgas, R.; et al. Tenofovir nephrotoxicity: 2011
update. AIDS Res. Treat. 2011, 2011, 354908. [CrossRef] [PubMed]
146. Martin, P.; Lau, D.T.; Nguyen, M.H.; Janssen, H.L.; Dieterich, D.T.; Peters, M.G.; Jacobson, I.M. A Treatment
algorithm for the management of chronic hepatitis b virus infection in the united states: 2015 update.
Clin. Gastroenterol. Hepatol. 2015, 13, 2071–2087. [CrossRef]
147. Lee, Y.B.; Lee, J.-H.; Lee, D.H.; Cho, H.; Ahn, H.; Choi, W.-M.; Cho, Y.Y.; Lee, M.; Yoo, J.-J.; Cho, Y.; et al.
Eﬃcacy of entecavir-tenofovir combination therapy for chronic hepatitis b patients with multidrug-resistant
strains. Antimicrob. Agents Chemother. 2014, 58, 6710. [CrossRef]
148. Marcellin, P.; Ahn, S.H.; Ma, X.; Caruntu, F.A.; Tak, W.Y.; Elkashab, M.; Chuang, W.-L.; Lim, S.-G.; Tabak, F.;
Mehta, R.; et al. Combination of tenofovir disoproxil fumarate and peginterferon α-2a increases loss of
hepatitis b surface antigen in patients with chronic hepatitis, B. Gastroenterology 2016, 150, 134–144. [CrossRef]
[PubMed]
149. Fung, J.; Lai, C.L.; Seto, W.K.; Yuen, M.F. Nucleoside/nucleotide analogues in the treatment of chronic
hepatitis B. J. Antimicrob. Chemother. 2011, 66, 2715–2725. [CrossRef] [PubMed]

## Page 47 (Section:  )

Biomedicines 2020, 8, 320
47 of 48
150. Kew, M.C. Hepatitis B virus x protein in the pathogenesis of hepatitis B virus-induced hepatocellular
carcinoma. J. Gastroenterol. Hepatol. 2011, 26, 144–152. [CrossRef]
151. Diao, J.; Khine, A.A.; Sarangi, F.; Hsu, E.; Iorio, C.; Tibbles, L.A.; Woodgett, J.R.; Penninger, J.; Richardson, C.D.
X protein of hepatitis B virus inhibits Fas-mediated apoptosis and is associated with up-regulation of the
SAPK/JNK pathway. J. Biol. Chem. 2001, 276, 8328–8340. [CrossRef]
152. Lee, Y.I.; Kang-Park, S.; Do, S.I.; Lee, Y.I. The hepatitis B virus-X protein activates a phosphatidylinositol
3-kinase-dependent survival signaling cascade. J. Biol. Chem. 2001, 276, 16969–16977. [CrossRef]
153. Gottlob, K.; Fulco, M.; Levrero, M.; Graessmann, A. The hepatitis B Virus HBx protein inhibits caspase 3
activity. J. Biol. Chem. 1999, 273, 33347–33353. [CrossRef]
154. Su, F.; Theodosis, C.N.; Schneider, R.J. Role of NF-κB and myc proteins in apoptosis induced by hepatitis B
virus HBx protein. J. Virol. 2001, 75, 215. [CrossRef]
155. Wang, T.; Wang, Y.; Wu, M.-C.; Guan, X.-Y.; Yin, Z.-F. Activating mechanism of transcriptor NF-kappaB
regulated by hepatitis B virus X protein in hepatocellular carcinoma. World J. Gastroenterol. 2004, 10, 356–360.
[CrossRef] [PubMed]
156. Park, U.S.; Park, S.K.; Lee, Y.I.; Park, J.G.; Lee, Y.I. Hepatitis B virus-X protein upregulates the expression
of p21waf1/cip1 and prolongs G1–>S transition via a p53-independent pathway in human hepatoma cells.
Oncogene 2000, 19, 3384–3394. [CrossRef]
157. Al-Anazi, M.R.; Nazir, N.; Colak, D.; Al-Ahdal, M.N.; Al-Qahtani, A.A. Deletion and functional analysis of
hepatitis B virus X protein: Evidence for an eﬀect on cell cycle regulators. Cell. Physiol. Biochem. 2018, 49,
1987–1998. [CrossRef] [PubMed]
158. Abbas, T.; Dutta, A. p21 in cancer: Intricate networks and multiple activities. Nat. Rev. Cancer 2009, 9,
400–414. [CrossRef]
159. Tang, H.; Da, L.; Mao, Y.; Li, Y.; Li, D.; Xu, Z.; Li, F.; Wang, Y.; Tiollais, P.; Li, T.; et al. Hepatitis B virus X
protein sensitizes cells to starvation-induced autophagy via up-regulation of beclin 1 expression. Hepatology
2009, 49, 60–71. [CrossRef] [PubMed]
160. Liu, B.; Fang, M.; Hu, Y.; Huang, B.; Li, N.; Chang, C.; Huang, R.; Xu, X.; Yang, Z.; Chen, Z.; et al. Hepatitis B
virus X protein inhibits autophagic degradation by impairing lysosomal maturation. Autophagy 2014, 10,
416–430. [CrossRef] [PubMed]
161. Rautou, P.-E.; Mansouri, A.; Lebrec, D.; Durand, F.; Valla, D.; Moreau, R. Autophagy in liver diseases.
J. Hepatol. 2010, 53, 1123–1134. [CrossRef]
162. Li, J.; Liu, Y.; Wang, Z.; Liu, K.; Wang, Y.; Liu, J.; Ding, H.; Yuan, Z. Subversion of cellular autophagy
machinery by hepatitis B virus for viral envelopment. J. Virol. 2011, 85, 6319. [CrossRef]
163. Sir, D.; Tian, Y.; Chen, W.-L.; Ann, D.K.; Yen, T.-S.B.; Ou, J.-H.J. The early autophagic pathway is activated by
hepatitis B virus and required for viral DNA replication. Proc. Natl. Acad Sci. USA 2010, 107, 4383. [CrossRef]
164. Yang, C.-J.; Liu, Y.-P.; Dai, H.-Y.; Shiue, Y.-L.; Tsai, C.-J.; Huang, M.-S.; Yeh, Y.-T. Nuclear HDAC6 inhibits
invasion by suppressing NF-κB/MMP2 and is inversely correlated with metastasis of non-small cell lung
cancer. Oncotarget 2015, 6, 30263–30276. [CrossRef]
165. Kim, M.; Lu, F.; Zhang, Y. Loss of HDAC-Mediated Repression and Gain of NF-κB Activation Underlie
Cytokine Induction in ARID1A- and PIK3CA-Mutation-Driven Ovarian Cancer. Cell Rep. 2016, 17, 275–288.
[CrossRef] [PubMed]
166. Jung, K.H.; Noh, J.H.; Kim, J.K.; Eun, J.W.; Bae, H.J.; Chang, Y.G.; Kim, M.G.; Park, W.S.; Lee, J.Y.; Lee, S.Y.; et al.
Histone deacetylase 6 functions as a tumor suppressor by activating c-Jun NH2-terminal kinase-mediated
beclin 1-dependent autophagic cell death in liver cancer. Hepatology 2012, 56, 644–657. [CrossRef] [PubMed]
167. Jones, S.A. Directing transition from innate to acquired immunity: Deﬁning a role for IL-6. J. Immunol. 2005,
175, 3463. [CrossRef] [PubMed]
168. Busca, A.; Kumar, A. Innate immune responses in hepatitis B virus (HBV) infection. Virol. J. 2014, 11, 22.
[CrossRef] [PubMed]
169. Ong, E.Z.; Chan, K.R.; Ooi, E.E. viral manipulation of host inhibitory receptor signaling for immune evasion.
PLoS Pathog. 2016, 12, e1005776. [CrossRef] [PubMed]
170. Luedde, T.; Schwabe, R.F. NF-κB in the liver–linking injury, ﬁbrosis and hepatocellular carcinoma. Nat. Rev.
Gastroenterol. Hepatol. 2011, 8, 108–118. [CrossRef] [PubMed]
171. Schönrich, G.; Raftery, M.J. The PD-1/PD-L1 axis and virus infections: A delicate balance. Front. Cell
Infect. Microbiol. 2019, 9, 207. [CrossRef]

## Page 48 (Section:  )

Biomedicines 2020, 8, 320
48 of 48
172. Germanidis, G.; Argentou, N.; Hytiroglou, P.; Vassiliadis, T.; Patsiaoura, K.; Germenis, A.; Speletas, M. Liver
FOXP3 and PD1/PDL1 expression is down-regulated in chronic HBV hepatitis on maintained remission
related to the degree of inﬂammation. Front. Immunol. 2013, 4, 207. [CrossRef]
173. Hong, F.; Jaruga, B.; Kim, W.H.; Radaeva, S.; El-Assal, O.N.; Tian, Z.; Nguyen, V.-A.; Gao, B. Opposing roles
of STAT1 and STAT3 in T cell–mediated hepatitis: Regulation by SOCS. J. Clin. Investig. 2002, 110, 1503–1513.
[CrossRef]
174. Dufour, J.-F.; Clavien, P.A. Signaling Pathways in Liver Diseases; Springer: New York, NY, USA, 2010; pp. 1–526.
© 2020 by the authors. Licensee MDPI, Basel, Switzerland. This article is an open access
article distributed under the terms and conditions of the Creative Commons Attribution
(CC BY) license (http://creativecommons.org/licenses/by/4.0/).


---

# Large-scale evaluation of cytochrome P450 2C9 mediated drug interaction potential with machine learning-based consensus modeling

- **Authors:** Anita Rácz, György M Keserű
- **Issuer:** Journal of computer-aided molecular design
- **Type:** Scientific article
- **Published:** 2020-03-27
- **Language:** en
- **DOI:** 10.1007/s10822-020-00308-y
- **Source:** https://pubmed.ncbi.nlm.nih.gov/32221780/
- **Licence:** CC-BY

## Section: Abstract

Cytochrome P450 (CYP) enzymes play an important role in the metabolism of xenobiotics. Since they are connected to drug interactions, screening for potential inhibitors is of utmost importance in drug discovery settings. Our study provides an extensive classification model for P450-drug interactions with one of the most prominent members, the 2C9 isoenzyme. Our model involved the largest set of 45,000 molecules ever used for developing prediction models. The models are based on three different types of descriptors, (a) typical one, two and three dimensional molecular descriptors, (b) chemical and pharmacophore fingerprints and (c) interaction fingerprints with docking scores. Two machine learning algorithms, the boosted tree and the multilayer feedforward of resilient backpropagation network were used and compared based on their performances. The models were validated both internally and using external validation sets. The results showed that the consensus voting technique with custom probability thresholds could provide promising results even in large-scale cases without any restrictions on the applicability domain. Our best model was capable to predict the 2C9 inhibitory activity with the area under the receiver operating characteristic curve (AUC) of 0.85 and 0.84 for the internal and the external test sets, respectively. The chemical space covered with the largest available dataset has reached its limit encompassing publicly available bioactivity data for the 2C9 isoenzyme.Electronic supplementary materialThe online version of this article (10.1007/s10822-020-00308-y) contains supplementary material, which is available to authorized users.

## Section: Introduction

The cytochrome P450 (CYP) enzyme family plays an important role in the biotransformation of xenobiotics. CYPs are involved in the bulk of phase I metabolism processes. Moreover, CYPs are responsible for most of the drug–drug interactions, which can affect the efficacy and safety of drugs. Many drugs have been withdrawn from the market due to the inhibition of these enzymes [1, 2]. Until now, 57 CYP genes are identified in humans, in which the CYP1, 2, and 3 families have the biggest contribution in the metabolism of the foreign substances [3]. More than 95% of FDA-approved drugs are metabolized by six isoforms of these subfamilies [4, 5]. The CYP 2C subfamily is one of the most important CYP families, consisting of two main isoforms, 2C9 and 2C19. Specifically, 2C9 is connected to the hepatic clearance of 12–16% of the clinically relevant drugs [6]. Anti-inflammatory agents, such as diclofenac, ibuprofen and anticoagulant molecules such as progesterone are amongst the substrates of CYP 2C9 isoenzyme [7]. CYP 2C9 is preliminarily expressed in the liver and the small mucosa, and the amount of CYP 2C9 is 15–20% compared to the total amount of the expressed CYP enzymes [8].

In the past 20 years the number of in silico models for different metabolic endpoints on CYP enzymes have increased and made the drug discovery processes faster and more efficient. Out of these, quantitative structure activity relationship (QSAR) models represent the correlation of biological activity on the specific CYP isoenzyme of the molecules with different molecular representations (descriptors) [7]. In the case of the CYP 2C9 isoform, the range of the models starts with a CoMFA model and a relatively small dataset containing 26 molecules in total by Jones and coworkers from 1996 [9]. In the past decade the number and size of available datasets increased rapidly. However, the number of compounds involved in model development has stopped around 15,000. Usually, the time consuming 3D models (CoMFA, CoMSIA) operated with a much lower number of compounds [10]. In contrast, prediction models based on bigger databases have mostly integrated machine learning (deep learning) algorithms and their combinations. The calculated models for CYP 2C9 are connected either to (a) usually smaller in-house datasets/literature data [11, 12] or (b) freely available large databases (such as PubChem) [13]. Machine learning algorithms have highly increased the performance of predictive models compared to earlier studies and parallel with the covered chemical space, their applicability domain could be widely extended. The trends in the modeling phase are the use of support vector machines (SVM) [14, 15], the Naïve Bayes algorithm [16], neural networks [17] or tree-based algorithms such as a simple correlation and regression tree (CART) or a more complex random forest (RF) or boosted tree (BT) [18]. Moreover, combined models are also represented in the literature, where either the applied datasets [13] or the algorithms [17] are combined. A great selection of the previous models (not just for the 2C9 isoform) can be found in the recent review by Kato [4].

In our study, we have taken a next step to overcome the limitations of the covered chemical space and built a large-scale model with over 45,000 individual molecules, which combines all the available Pubchem databases for the 2C9 isoform. Moreover, we purposefully did not apply any applicability domain concept in the modeling phase (to avoid any limitation regarding the modelled chemical space), and combined several models into a consensus optimum based on different molecular descriptor sets and fingerprint types. Our primary aim was not just to build the largest available model for CYP 2C9, but also to showcase the advantages of probability threshold optimization and consensus modeling. Based on the results obtained we suggest that consensus voting technique with custom probability thresholds provides a robust and predictive model for discriminating compounds with high 2C9 related drug interaction potential.

## Section: Materials and methods › Data handling

The study is based on the publicly accessible CYP 2C9 bioactivity databases available in PubChem (NCBI), with the following AID numbers: 777, 1851 and 883 [19–21]. These datasets include the class memberships of the molecules as active/inactive depending on the ability of test compounds to inhibit the 2C9 conversion of the substrate luciferin-H to luciferin.

Data handling was started with the elimination of those molecules, which had no SMILES code, or their class memberships were inconclusive (indicated in the database). Moreover, duplicates (either with different or identical class memberships) were also excluded from the dataset. The dominant protonation state at a pH of 7.4 was assigned to each compound with ChemAxon Calculator (cxcalc) [22] and Scrödinger (LigPrep) [23]. Scrödinger (LigPrep) was used to generate the 3D structures of the molecules in the exact protonation states.

The largest dataset, AID 777 was used for model training and internal validation. Thus, the model was optimized for this dataset. The numbers of active and inactive molecules were balanced in the dataset; in this way the two-class classification model could be more robust and less biased [24]. All active molecules were included. Having a balanced dataset, the same number of inactives were selected by the Diversity Picker node (RDKit extension) in KNIME based on the MaxMin algorithm [25]. Finally, still more than 35,000 different molecules with appropriate 3D structures were included in model building.

## Section: Materials and methods › Molecular descriptors sets

Different descriptor sets were calculated for the datasets including (a) classical 1, 2 and 3D molecular descriptors and extended connectivity fingerprints (ECFP) with the use of DRAGON 7.0 [26], (b) interaction fingerprints and docking scores by Schrödinger software (Glide) [27, 28] and (c) pharmacophore fingerprints with ChemAxon’s fingerprint generator.

Classical molecular descriptors were filtered based on the inter-correlations with the use of 0.997 as the correlation limit [29], constant descriptors were also omitted. In total, 3740 standard molecular descriptors were included for modeling. The definition of the used molecular descriptors can be found in details in reference [30]. In case of the ECFP fingerprint, standard parameters were used in DRAGON 7.0, with a maximum radius of 4 and a fingerprint length of 1024 [31]. The PDB structure 5K7K [32] was prepared using the Protein Preparation Wizard of Schrödinger [33] briefly bond orders and hydrogens were assigned, missing loops and sidechains were modeled, protonation states at a pH of 7.4 were generated, H-bond geometries were optimized and a restrained minimization of the structures was carried out. Ligand docking was carried out with Glide SP (standard precision) for the whole dataset into the selected CYP 2C9 enzyme structure from PDB (Protein Data Bank) database (ID: 5K7K [32]), containing a potent inhibitor (with an IC50 value of 36 nM). One binding pose was kept for each molecule. The 3D structures of the ligands for the docking were prepared with Schrödinger (LigPrep) as mentioned above. The predicted binding poses were used for the calculation of interaction fingerprints Schrödinger Maestro [34]. Non-interacting residues and non-occurring interactions were filtered out from the interaction fingerprint vectors, which finally contained 176 bit positions [35]. Pharmacophore fingerprints were generated with the fingerprint generator module of ChemAxon.

The descriptors were grouped together in three datasets, containing: (a) the interaction fingerprint variables, together with the docking score (177 variables), (b) the classical molecular descriptors calculated with DRAGON 7.0 (3740 variables) and (c) the ECFP fingerprints together with the pharmacophore fingerprints (1234 variables).

## Section: Materials and methods › Machine learning algorithms and evaluation tools

We have selected two well-known and frequently used machine learning algorithms, the tree-based gradient boosted tree (BT) [36], and the neural network-based multi-layer feed-forward of resilient backpropagation network (RPropMLP) [37] for modeling. Both algorithms are included in the KNIME analytics platform [38].

The resilient backpropagation is an improved backpropagation algorithm, which is an essential part of multi-layered feed-forward networks. Backpropagation learning means a repetitive application of the chain rule in order to calculate the influence of each weight in the network, taking into account an arbitrary error function [37]. RPropMLP algorithm implements a local adaptation of the weight updates, in agreement to the behavior of the error function. As in all standard neural network models, the number of hidden layers and the number of hidden neurons per layer can be (and are worth to be) optimized. These two parameters were optimized for every training model in a loop cycle in KNIME to find their best combination. RPropMLP is in the following text to MLP for simplicity.

Gradient boosted tree (GBT) is a well-known and useful technique amongst the tree-based algorithms. The basic idea of GBT is the ensemble of decision trees, which are created for the prediction of the target vector. The main difference of the algorithm compared to the previous versions is that the weak learners (decision trees) are identified by gradients in the loss function instead of using high weights (as it is happening for example in the standard adaptive boosting algorithm). Gradient boosted tree was optimized with the tree depth (limitation of the tree levels) for the training model in a loop cycle with KNIME (parameter optimization loop with brute force) in the same way as for MLP. The best value of tree depth was determined for each case.

## Section: Results and discussion

First, the chemical space covered by the three applied datasets was visualized and compared. The evaluation was based on standard molecular descriptors (constitutional descriptors and molecular properties blocks in Dragon), and only unique molecules were included in each dataset. Principal component analysis was carried out and the first two principal component scores (PC) were plotted on a scatterplot (Fig. 1). Moreover the covered chemical space was also visualized in a scatterplot of logP against molecular weight values. The additional evaluation of drug-like properties can be seen in Supplementary material Figure S1. We can conclude that the chemical space coverage of AID 777 is much greater than the other two sets, thus AID 1851 and AID 883 were merged and applied together as an external test set. It can also be seen that the other two datasets occupy a subspace inside the AID 777, thus validating their use as the external set. In Fig. 1b it is shown that the AID777 dataset covers the largest area in the MW-logP space with much better sampling than that provided by AID1851 and AID883 sets.Fig. 1a Principal component analysis of the three PubChem datasets (grey: AID 777, red: AID 1851, green: AID 883). The first two principal component scores are plotted against each other. b Comparison of the three datasets based on the log P and molecular weight values of the molecules. The coloring is the same as in the previous case

Molecular descriptor variables were standardized for both of the algorithms. Five-fold stratified cross-validation (class ratios remains the same in each iteration), and internal validation with a 70% train–30% test ratio were used on the primary dataset (AID777). External validation was carried out with the merged set consisting of AID1851 and AID883. (The same data curation steps were applied to the external set, as outlined earlier.)

The primary predicted class memberships were based on the individual class probabilities, with a threshold of 0.5. However, the optimum value of this threshold should be determined for each case. Models can perform much better if the best possible threshold is used, which can be actually higher or lower than 0.5. Thus, the probability threshold was determined based on the calculated receiver operating curves (ROC), defining the optimum value as the threshold value corresponding to point on the ROC curve with the minimum Euclidean distance (d) to the upper left corner of the plot (corresponding to perfect classification), see Fig. 2. Hence, the original class memberships were recalculated with the determined new thresholds for each dataset.Fig. 2An example of the ROC curves with the threshold optimum determination (blue circle: point with the optimal probability value; d: distance between the optimal point and perfect classification)

After the calculation of the primary classification models, consensus modeling (consensus 1) was carried out based on the probability values for the active class, provided by each of the primary models. Minimum, maximum and average values were calculated for each molecule, and finally, ROC curves were plotted based on these new probability values.

Another version of consensus modeling was also applied (consensus 2), where the molecules with inconclusive class memberships in the different models were excluded from the consensus model, keeping only those molecules where the predicted class memberships were the same for each primary model (after the threshold optimization). Minimum, maximum and average probability values for the active class were calculated for each molecule and ROC curves were plotted in the same way as for consensus 1 models.

The complete workflow of the modeling is included in Fig. 3.Fig. 3The complete modeling workflow. The explanation of the abbreviations can be found in the beginning of the manuscript

After data handling, 35,733 molecules were included in the models, with a ratio of actives to inactives of 46/54. The small difference from the 50–50 ratio was caused by the exclusion of those molecules, which failed during ligand docking. Thus, modeling was performed on each of the three different descriptor sets, with the training set containing 25,013 molecules, and the internal test set containing 10,720 molecules.

Class memberships were recalculated based on the determination of probability thresholds with the ROC curves of the original models. As a global performance metric, area under the ROC curve (AUC) was calculated for each model with the scikit-learn Python package [39].

The consensus models from the three primary datasets were generated with the calculation of the minimum, maximum and average values of the active probability values for each molecule. The performances of the primary models for the three descriptor sets and the calculated consensus 1 and consensus 2 models can be found in Table 1.Table 1AUC values of the prepared primary and consensus models for training, CV, internal and external validationMethodValidationPrimary modelsConsensus 1Consensus 2IFP + DSECFP + PFP1D, 2D, 3D MDMinAveMaxMinAveMaxMLPTraining0.690.890.820.860.880.870.890.910.90CV0.650.750.760.750.780.760.810.830.81Test0.660.760.760.760.770.760.810.820.81External0.650.740.740.750.760.740.790.810.80GBTTraining0.730.840.870.830.850.840.880.890.88CV0.690.790.800.780.790.780.820.840.83Test0.690.790.800.770.790.780.820.830.82External0.670.750.760.750.760.730.800.810.80Abbreviations can be found in the beginning of the text. The best models (based on the AUC of the validation sets) are marked with bold

In the comparison of the primary models, the ECFP + PFP and 1, 2, 3D molecular descriptors clearly outperformed the IFP + DS (docking score) versions. The average of the probability values was the best consensus option, not just for the consensus 1 models, but for the consensus 2 models as well. Gradient boosted tree performed slightly better for the primary models, in the consensus modeling part, the performances were very similar for the two algorithms. The validation part was successful; models performed excellently even for the external sets (with a relatively minor performance drop compared to training). The amount of molecules for each validation part, and the ratio of actives and excluded molecules for consensus 2 can be seen in Table 2. The number of molecules was the same as for the primary models, in the case of the consensus 1 models.Table 2The number of molecules in each validation part, and the number of active molecules in consensus 2 modelsSamplesValidationConsensus 1Consensus 2Active molecules in consensus 2 (%)Ratio of excluded molecules (consensus 2)MLPTraining25,01315,56752.50.41CV25,01314,69648.40.41Test10,720660849.60.38External9983591921.00.41GBTTraining25,01317,34851.80.31CV25,01316,58748.10.34Test10,720726048.90.32External9983601322.10.40The ratio of excluded molecules is assigned to consensus 2 models

In the final model building step, the consensus models of all the six primary models were calculated based on the active probability values and the assigned class memberships. Minimum, maximum and average of the probability values were compared in the consensus 1 and 2 models. The consensus 2 model with the use of average probability values gave the best AUC value for each validation set (Table 3). The AUC value of the consensus 2 model was 0.84 even for the external validation set based on the average probability values. Moreover the AUC values of the training and the validation sets were not far from each other.Table 3The AUC values of the prepared consensus models based on the six primary models for training, CV, internal and external validationValidationConsensus 1 (MLP + GBT)Consensus 2 (MLP + GBT)MinAveMaxMinAveMaxTraining0.870.880.870.910.930.91CV0.760.790.760.840.860.84Test0.770.790.760.830.850.83External0.750.770.740.830.840.82Abbreviations can be found in the beginning of the text. The AUC values of the best model are marked with bold numbers

For the consensus 1 model, the number of molecules was the same as for the primary models. The total number of different molecules in consensus 2 model (MLP + GBT) is more than 23,000 (Table 4).Table 4The amount of molecules and the ratio of actives in consensus 2 model together with the ratio of excluded molecules compared to the primary modelsSamplesValidationConsensus 1 (MLP + GBT)Consensus 2 (MLP + GBT)Active molecules in consensus 2 (%) (MLP + GBT)Ratio of excluded molecules (consensus 2 for MLP + GBT)MLPTraining25,01314,10552.20.44CV25,01312,52649.30.50Test10,720573850.70.46External9983480223.00.52

The AUC values of the best three models were compared to that of the previous literature models. Comparison was done with five other studies, where the authors used the AUC values as the performance parameter of their model (Fig. 4). The numbers of used molecules – thus the covered chemical space—was clearly larger than the previous studies in each case, and the AUC values were in the same scale. AUC values are indicated on the diagram for internal and external test sets (previous studies typically applied only one of these).Fig. 4The number of used molecules in the previous studies compared to the top three models in our study. Sun et al. [15], Rostkowski et al. [40], Li et al. [41], Cheng et al. [17], and Wu et al. [18] can be found in the reference list. Model 1: consensus 2 model based on the MLP + GBT algorithms; model 2: consensus 2 model based on the GBT algorithm and model 3: consensus 1 model based on the GBT algorithm. Our selected models can be found in Table 1 and 3 marked with bold

The AUC, Matthews Correlation Coefficient (MCC), sensitivity (Sn) and Specificity (Sp) values of the top three models are compared with the above mentioned previous studies Tables 5, 6 and 7 (where available).Table 5The AUC values of the best three models compared to the previous literature modelsAUC valuesReferencesInternal test setExternal test setSun et al.0.85–[15]Rostkowski et al.0.90–[40]Li et al.–0.77[41]Cheng et al.–0.86[17]Wu et al.–0.81[18]Model 10.850.84–Model 20.830.81–Model 30.790.76–Table 6Comparison of the Matthews Correlation Coefficients of the top three models and the previous studiesMCC valuesReferenceCross-validationExternal test setWu et al–0.35[18]Cheng et al0.49–[17]Li et al–0.32[41]Model 10.610.48–Model 20.530.42–Model 30.440.31–Model 1: consensus 2 model based on the MLP + GBT algorithms; model 2: consensus 2 model based on the GBT algorithm and model 3: consensus 1 model based on the GBT algorithmTable 7Comparison of the sensitivities (Sn) and specificities (Sp) of the top three models and the previous studiesCross-validationExternal test setReferencesSnSpSnSpWu––0.290.97[18]Cheng et al0.630.85––[17]Li et al––0.320.77[41]Model 10.820.790.820.76–Model 20.780.750.790.70–Model 30.730.710.670.71–Model 1: consensus 2 model based on the MLP + GBT algorithms; model 2: consensus 2 model based on the GBT algorithm and model 3: consensus 1 model based on the GBT algorithm

While the AUC values are comparable with the previous studies, the MCC values, sensitivities and specificities are slightly or remarkably better. In particular, our models show a greatly improved performance in terms of the balance of sensitivity and specificity.

a Principal component analysis of the three PubChem datasets (grey: AID 777, red: AID 1851, green: AID 883). The first two principal component scores are plotted against each other. b Comparison of the three datasets based on the log P and molecular weight values of the molecules. The coloring is the same as in the previous case

An example of the ROC curves with the threshold optimum determination (blue circle: point with the optimal probability value; d: distance between the optimal point and perfect classification)

The complete modeling workflow. The explanation of the abbreviations can be found in the beginning of the manuscript

AUC values of the prepared primary and consensus models for training, CV, internal and external validation

The number of molecules in each validation part, and the number of active molecules in consensus 2 models

The AUC values of the prepared consensus models based on the six primary models for training, CV, internal and external validation

The amount of molecules and the ratio of actives in consensus 2 model together with the ratio of excluded molecules compared to the primary models

The number of used molecules in the previous studies compared to the top three models in our study. Sun et al. [15], Rostkowski et al. [40], Li et al. [41], Cheng et al. [17], and Wu et al. [18] can be found in the reference list. Model 1: consensus 2 model based on the MLP + GBT algorithms; model 2: consensus 2 model based on the GBT algorithm and model 3: consensus 1 model based on the GBT algorithm. Our selected models can be found in Table 1 and 3 marked with bold

The AUC values of the best three models compared to the previous literature models

Comparison of the Matthews Correlation Coefficients of the top three models and the previous studies

Comparison of the sensitivities (Sn) and specificities (Sp) of the top three models and the previous studies

## Section: Conclusion

Our study provides a large-scale classification model of CYP 2C9 mediated drug interaction potential based on more than 46,000 experimentally tested compounds. The applied algorithms, RPropMLP and GBT were good candidates providing appropriate models for large databases. The use of interaction fingerprints and docking scores gave slightly worse results than the other two primary datasets (typical 1–3D descriptors, molecular and pharmacophore fingerprints), but together, the AUC values of the consensus models have increased. The applied probability threshold determination based on the ROC curves has greatly improved the accuracy of our models in each case. From the consensus modeling point of view, the voting-based consensus 2 models were better than the consensus 1 models, but both gave good results. The AUC values were 0.84 and 0.85 for the external and internal test sets in the case of our best model (consensus 2 with MLP + GBT algorithms). Considering the unprecedented number of diverse molecules used for modeling (and the classification performance being comparable to earlier studies employing much smaller datasets), the resulting classification models are suitable for use in drug discovery workflows.

## Section: Electronic supplementary material

Supplementary file1 (DOCX 801 kb)

## Section: Electronic supplementary material

Below is the link to the electronic supplementary material.Supplementary file1 (DOCX 801 kb)

Supplementary file1 (DOCX 801 kb)


---

# Machine learning-driven protein engineering: a case study in computational drug discovery

- **Authors:** Harry F Rickerby, Katya Putintseva, Christopher Cozens
- **Issuer:** Engineering biology
- **Type:** Scientific article
- **Published:** 2020-03-16
- **Language:** en
- **DOI:** 10.1049/enb.2019.0019
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36970228/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractResearch and development in drug discovery will need to find significant efficiency gains if the industry is to continue generating novel drugs. There is great expectation for machine learning (ML) to provide this boost in R&D productivity, but to harness the full potential of ML, the generation of new, high‐quality datasets will be necessary. Here, the authors present a platform that combines high‐throughput display and selection data generation with ML. More specifically, deep learning is used to inform the directed evolution of novel biotherapeutics using DNA library synthesis, ultra‐high throughput selections, and next generation sequencing. By combining the learnings of multiple in silico models, their platform enables multi‐parameter optimisation across multiple important protein characteristics. They also present a model for benchmarking these ML‐driven drug discovery platforms according to the accuracy of their underlying in silico models, in conjunction with the throughput of their empirical experimentation.Inspec keywords: proteins, biology computing, learning (artificial intelligence), drugs, molecular biophysics, optimisation, DNAOther keywords: machine learning‐driven protein engineering, computational drug discovery, significant efficiency gains, drugs, great expectation, high‐quality datasets, high‐throughput display, selection data generation, deep learning, directed evolution, DNA library synthesis, ultra‐high throughput selections, generation sequencing, learnings, silico models, multiple important protein characteristics, ML‐driven drug discovery

## Section: Introduction

Our current model for drug discovery is inefficient. Despite our understanding of disease constantly improving, our efficiency in generating new therapies has continuously fallen over the past 60 years. Adjusting for inflation, in the 1960s, it cost the global pharmaceutical industry an average of $100 million to take a drug from discovery to the market, today it costs over $2.5 billion [1, 2]. There is disagreement over the root cause of this decline, but broadly it is driven by a high failure rate, with only around 1‐in‐10 drugs that enter clinical trials reaching the market [3, 4].

The integration of machine learning (ML) into the drug discovery process provides an opportunity to reverse this trend. ML is ideally suited to accelerating drug discovery since it is able to accurately capture and model the complexity of biological systems [5]. Capturing this complexity could help unravel the mechanisms that drive the success and failure of different drug candidates, thereby helping us design drugs with better chances of being successful.

To do this, most ML algorithms, particularly deep learning, require large volumes of high‐quality data. To provide them this training data, many researchers and companies have focused on the use of publicly available data, hoping to avoid expensive experimental data generation [6]. Unfortunately, public datasets were not produced with ML in mind. The data often contains significant experimental biases. Without the requisite controls for these biases, models will fail to pick up on the underlying parameter, and will instead simply be a model of the experiment. In addition, these experiments are frequently not performed in rigorously controlled conditions, without sufficient replicates to prevent algorithms from overfitting to biological noise.

The application of ML in drug discovery is more likely to be successful if backed by an underlying experimental workflow that provides high‐quality training data. To provide an example of such an ML‐driven drug discovery engine, here we summarise LabGenius’ approach to protein engineering in biotherapeutics.

## Section: Application of ML to protein engineering

Any new biological therapeutic needs to satisfy a range of biochemical and biophysical requirements in order to qualify as a potential drug candidate. These characteristics are derived from a protein's underlying amino acid sequence. The ability to computationally predict protein fitness from its underlying sequence would be a powerful tool, drastically simplifying and rationalising the design of novel biotherapeutics. Unfortunately, this goal has not yet been achieved because the relationship between sequence and fitness is complex and difficult to model [7].

The traditional approach to engineering novel biological therapeutics uses iterative rounds of directed evolution, taking small steps through sequence space towards variants with higher fitness. These variants are selected from large libraries based on their performance along one particular axis — typically their ability to bind to a target [8, 9, 10]. The resulting pool of variants is then expressed individually and tested according to other important parameters: potency, solubility, expressibility, the propensity to aggregate, stability, immunogenicity, and so on [11]. With luck, a few variants will emerge from the funnel that satisfies all of these criteria. However, because none of these other parameters are factored into the design of the original library, finding these high performing variants fundamentally comes down to chance. Even if a functional molecule is identified, it is incredibly unlikely to be the optimal solution.

Often molecules that actually fail some of these tests are pushed through to animal testing and clinical trials anyway in the hope that these red flags will not prove to be ‘show‐stopping’ issues. In reality, these flags are strongly correlated with an antibody's chances of success during clinical trials [12]. An optimal approach may be to co‐optimise for as many of these parameters as possible at the start of a programme. This would increase the flux of high‐performing molecules through in vitro characterisation, delivering only molecules with excellent biochemical and biophysical properties to animal studies and clinical trials.

To achieve this, accurate computational models are necessary to predict a protein's performance for multiple biochemical and biophysical properties. To build these models using deep learning, large volumes of high‐quality empirical data linking sequence to fitness are required. Finally, a protein library synthesis method is necessary to faithfully reproduce the predictions recommended by the sequence‐fitness models.

Based on these requirements, we present our approach to ML‐driven protein engineering.

## Section: LabGenius’ ML‐driven protein engineering platform › Library construction

Conventional antibody engineering relies on antibody libraries derived from animal immune repertoires, followed by optimisation via random mutagenesis [9]. To efficiently explore sequence space, and to enable ML informed library design, it is necessary to be able to precisely control which amino acids are mutated and what they are mutated to. To facilitate this, we construct diverse combinatorial synthetic DNA libraries of between 106 and 1013 variants (depending on the specifics of the library design). This allows us to enrich for functional proteins prior to the application of any selective pressure.

## Section: LabGenius’ ML‐driven protein engineering platform › Selection

Next, this library is exposed to various selective pressures during a phage display and selection step. This allows us to bin variants into a range of high‐performing and low‐performing pools. Once selected, these pools are sequenced with next generation sequencing, providing large volumes of DNA sequences linked to their fitness for the screened parameter.

Selections performed as part of a platform such as this one are different from traditional selection campaigns. In classic phage display, selection conditions are performed with the express goal of finding the best binders to a given target. This means performing multiple rounds of biopanning and iteratively increasing the stringency of selection to enrich for the tightest binders [8]. Our goal is to map the fitness landscape to enable multi‐parameter optimisation. As such, selection stringency must be carefully optimised — too high, and there will be insufficient data to build a map of the sequence‐fitness landscape, too low and the signal will not be evident through the noise.

## Section: LabGenius’ ML‐driven protein engineering platform › Data analysis and ML

The data generated in selections are then used to train ML models, allowing us to build fitness landscape maps based on the library of sequences that we have selected. These maps are iteratively improved and refined as more experimental data is accumulated. This approach allows extrapolation to greater numbers of variants and therefore an exploration of an even greater proportion of possible sequence space. It also enables quicker and cheaper identification of high‐fitness variants and novel proteins that were not present in the starting library.

It is important to note that these models are in fact models of the screening method, not a direct model of the underlying parameter of interest. As a result, it is critical that the screen maps as closely as possible to the underlying parameter. A good example of this issue is in phage display: in producing a phage library, Escherichia coli is used as a chassis for phage particle expression. Each variant in the library will be expressed at differing rates, based on the bacteria's ability to do so. This means that before selection, the phage library will be biased towards variants that have been expressed to a higher titre. Training a model on the results of this selection without controlling for this bias will result in the conflation of two properties — expressibility and binding. To truly understand sequence‐fitness landscapes for certain properties then, it is necessary to design assays carefully, factoring in any way in which signal from the screen could be masking the signal from the property of interest.

## Section: LabGenius’ ML‐driven protein engineering platform › Data analysis and ML › Modelling sequence‐fitness landscapes

ML is a particularly powerful technique in modelling sequence‐fitness landscapes since it is able to capture interactions between amino acid or nucleotide positions, also known as epistasis. If each position in a sequence had a linear input into the underlying fitness function, the fitness landscape would be smooth and easily predictable. However, protein fitness landscapes are inherently hazardous, and functional proteins are often only a single mutation away from either getting trapped at local maxima or falling into death valleys [13]. The ruggedness of the fitness landscape can, therefore, be characterised by the complexity of the underlying epistatic interactions.

Putinseva et al. demonstrate that feed forward neural networks are an excellent tool for inferring genotype‐to‐phenotype relationships [14]. If the sequences are represented in a binary matrix, where each row corresponds to a sequence and each column corresponds to a mutation, then using feed forward neural networks allows co‐optimisation of the impact of each of these mutations, together with the non‐linear function that maps genotype to phenotype. Increasing the complexity of the neural network architecture improved the accuracy of the model. This illustrates that ML is capable of capturing the multidimensional epistatic interactions that govern the shape of the fitness landscape and predicting them with high accuracy.

## Section: LabGenius’ ML‐driven protein engineering platform › Data analysis and ML › Multi‐objective optimisation

For each parameter that we test, a new sequence‐fitness landscape is constructed in silico. This allows us to find shared fitness peaks across all of the empirically tested parameters. Using this information, we can construct new DNA libraries to interrogate these high‐performing regions of sequence space.

For example, in engineering protease stable binding molecules we would build in silico genotype–phenotype models of protease stability and target binding based on selection data. Next, we would rationalise the search for high performers across these parameters through Pareto‐front optimisation.

## Section: Benchmarking ML‐driven biologics discovery platforms

Drug discovery platforms are evaluated based mostly on the success of the molecules that they output. However, this approach to valuing a discovery platform misses the compounding value of ML‐driven discovery platforms. As more data is produced, and as the underlying models become more accurate, these platforms should provide increasing numbers of high‐quality assets.

As such, it is important to establish benchmarks that allow us to directly measure the performance of these platforms as opposed to their clinical outputs. Here, we present our own internal benchmarking system, comprising two measurable parameters.

Example of how ML‐driven drug discovery platform benchmarks could be visualised. For each in vitro characterisation assay, the platform is rated according to the effective throughput of the library construction and screen. It is also rated according to the accuracy of the underlying in silico sequence‐fitness model. These two metrics together provide an insight into the ability of a platform to identify novel, high‐performing variants

Example of how the generalisability of an ML‐driven drug discovery platform could be benchmarked and visualised. Here, the accuracy of the model is assessed using different test datasets, where these test datasets are of varying sequence identity from the dataset that the model was trained on

## Section: Benchmarking ML‐driven biologics discovery platforms › Sequence‐fitness model accuracy

A useful benchmark for sequence‐fitness models is accuracy. Model accuracy quantifies the difference between a model's predictions of fitness and experimentally measured fitness. With an accurate model, less empirical exploration of sequence space is required to find high‐performing variants. To quantify this, the model is asked to classify a number of experimentally characterised DNA sequences that it has not seen before. Its accuracy is defined as the proportion of these sequences that the model calls correctly.

## Section: Benchmarking ML‐driven biologics discovery platforms › Effective platform throughput

Since there is a significant amount of noise in biological systems, we can assume that the model's accuracy will be significantly below 100%. As such, we will continue to rely on empirical experimentation to explore the solution space, validate the model's predictions and identify the strongest candidates. Given that the model is identifying potential high‐performing areas of sequence space, it is important that we are able to precisely specify which mutations are tested at each round of empirical screening, as opposed to randomly sampling the space. To capture this, as well as total throughput, we define ‘effective platform throughput’ as the number of planned sequence variants that the platform can produce and screen per unit time (assuming that any screen returns at least one ‘hit’).

Each function that the platform optimises for would be benchmarked according to these two factors (see Fig. 1). For example, when searching for binding molecules to a new target, an in silico model is unlikely to be accurate. However, since we can select for new binders at extremely high throughput, the platform is likely to be able to generate novel binding molecules. For a parameter such as immunogenicity, a reliable high‐throughput screen does not currently exist. This means that a more accurate model is required to produce high‐fitness variants.

This framework not only allows comparisons between different ML‐driven drug discovery platforms but also enables data‐driven decision‐making within an organisation. Where platform throughput and model accuracy are low, it will be difficult to find high performers. In this case, investment in these weaker areas of a platform would be necessary.

Another important aspect of such ML‐driven drug discovery platforms is their ‘generalisability’. For example, to what extent could a model trained on immunogenicity data from immunoglobulin G be extended to predict the immunogenicity of single‐chain fragment variables or immunoglobulinE? More generalisability allows a platform to address a wider array of protein categories, thus providing greater value. While not included as a core aspect of our benchmarking system, generalisability should also be considered when evaluating these systems. One way to do this is to track the model's accuracy when it is asked to predict the fitness of a number of test datasets, each of which having varying degrees of sequence similarity to the training set (see Fig. 2). For example, this would allow us to assess the platform when test data is only 50% similar to the data it was trained with, and compare this to its accuracy when test data is 80% similar to its training data.

Example of how ML‐driven drug discovery platform benchmarks could be visualised. For each in vitro characterisation assay, the platform is rated according to the effective throughput of the library construction and screen. It is also rated according to the accuracy of the underlying in silico sequence‐fitness model. These two metrics together provide an insight into the ability of a platform to identify novel, high‐performing variants

Example of how the generalisability of an ML‐driven drug discovery platform could be benchmarked and visualised. Here, the accuracy of the model is assessed using different test datasets, where these test datasets are of varying sequence identity from the dataset that the model was trained on

## Section: Conclusions

There is great promise in the application of ML and computation in drug discovery. However, to extract the most value from these technologies, we suggest that drug discovery platforms should be built from the ground up with ML in mind. We have presented LabGenius’ approach to building such a platform, focusing on protein engineering for biotherapeutic drug discovery. This platform enables multi‐parameter optimisation across multiple biochemical and biophysical characteristics from the very beginning of a drug discovery campaign. This has the potential to accelerate the discovery of high‐performing leads, reduce the failure rate, and increase the efficiency of the discovery process by enabling projects to be cancelled earlier. We have also presented a framework for objectively evaluating ML‐driven drug discovery platforms that captures their compounding value.


---

# Machine Learning in Drug Discovery and Development Part 1: A Primer

- **Authors:** Alan Talevi, Juan Francisco Morales, Gregory Hather, Jagdeep T Podichetty, Sarah Kim, Peter C Bloomingdale, Samuel Kim, Jackson Burton, Joshua D Brown, Almut G Winterstein, Stephan Schmidt, Jensen Kael White, Daniela J Conrado
- **Issuer:** CPT: pharmacometrics & systems pharmacology
- **Type:** Scientific article
- **Published:** 2020-03-11
- **Language:** en
- **DOI:** 10.1002/psp4.12491
- **Source:** https://pubmed.ncbi.nlm.nih.gov/31905263/
- **Licence:** CC-BY-NC

## Section: Abstract

Artificial intelligence, in particular machine learning (ML), has emerged as a key promising pillar to overcome the high failure rate in drug development. Here, we present a primer on the ML algorithms most commonly used in drug discovery and development. We also list possible data sources, describe good practices for ML model development and validation, and share a reproducible example. A companion article will summarize applications of ML in drug discovery, drug development, and postapproval phase.

## Section: Text

Application of artificial intelligence (AI; Box 1) in drug discovery and development has emerged as a key promising pillar. Its importance has been consolidated by the need of new strategies to overcome the high failure rate in drug development of ~ 90%.1, 2 As such, pharmaceutical companies are beginning to explore how various AI frameworks can supplement or be integrated into the current drug discovery and development processes.1

Machine learning (ML), a branch of AI (Figure 1), is “based on the idea that systems can learn from data, identify patterns and make decisions with minimal human intervention.”13 AI frameworks may contain several different ML methods applied together. For example, an AI framework in drug discovery may optimize drug candidates through a combination of ML models that predict favorable physicochemical characteristics (e.g., solubility and permeability), pharmacokinetics (PK), safety, and possibly efficacy.14, 15, 16, 17, 18, 19, 20, 21 An AI framework in drug development may use ML methods to prescreen covariates in PK‐pharmacodynamic data, identifying patient subpopulations, predicting clinical outcomes, informing clinical trial design, and investigating novel therapeutic purpose for existing drugs (i.e., drug repositioning or drug repurposing).22, 23, 24, 25 However, ML methods have been utilized more often in drug discovery than in development.

ML can support a range of different drug discovery and development applications. To be a fit‐for‐purpose approach, the application of ML should be guided by answers to the following three questions: (i) What is the drug discovery and/or development need? (ii) What ML methods are most appropriate to address this need? and (iii) What data can be used to support these ML methods? Data quality is as critical as data quantity in that data should be unbiased and diverse to support robust models. In addition, researchers should prepare to validate and interpret the models and results.

This work consists of two parts. The first part is a tutorial on the most commonly used ML algorithms along with possible data sources, good practices for ML model development and validation, and a reproducible example. The second part, published in a companion article, is an overview of applications of ML in drug discovery, drug development, and the postapproval phase.

## Section: Data sources for building ML models

The amount of data being generated today is staggering. An estimated 2.5 quintillion bytes are created every single day.26 However, it is not the quantity of data but it is the opportunity to generate knowledge that matters most. Some common examples of large data sets include chemical structure data, gene expression and genetic data, high throughput in vitro data, clinical trial data, and electronic medical records. Data may be freely available public data, commercially available data, internal companies’ data, or data shared among participating institutions.27 The reader can refer to Conrado et al.28 for examples of individual data‐sharing initiatives.

“Big data” and advances in technologies for data science have paved the way for the applications of ML in drug discovery and development. Recent advances in ML technology, in turn, allow us to make use of large data sets on a scale that was previously unrealizable. A rapidly emerging field is the use of wearable technology and sensors, which provide a wealth of real‐time data that can be leveraged to assess patient health and detect trends for potential health risks.29 For example, wearable sensors that can be adhered directly to patients’ body surfaces can provide detailed movement data.30 Alternatively, small, wearable devices, such as sensors embedded into a ring or wristband, enable pulse wave, arterial blood flow, physical activity, and sleep pattern data to be monitored continuously.31, 32 Technological advances in computer‐aided diagnosis and detection systems created the fields of radiomics and radiogenomics.33, 34 These advances enable researchers to convert medical images into quantitative data7, 23, 24 that can be used to develop ML models to generate hypotheses and inferences as well as support decision making beyond visual interpretation.35 Postmarket surveillance data such as adverse drug reaction (ADR) reports from the U.S. Food and Drug Administration (FDA) Adverse Event Reporting System36 are also vital sources in that they can inform drug discovery and development by back translating to the molecular mechanisms and targets of the adverse events.37 The Adverse Event Reporting System contains rich sources of ADR information submitted voluntarily by drug manufacturers, healthcare professionals, and consumers in the United States. More than 9 million ADR reports were submitted from 1969 to the present, and the number of reports increases every year.

Data can be either structured or unstructured.28 Structured data could occur through a user‐friendly online data repository including a description of the data, tools for data querying, a data dictionary, summary tables, and some means of support.28 Examples of structured data are the Alzheimer's Disease Neuroimaging Initiative (ADNI), the Parkinson's Progression Markers Initiative (PPMI), and the Coalition Against Major Diseases (CAMD) consortium database.28 Unstructured data as the name suggests are everything else. Unfortunately, most data are unstructured and require substantial amounts of time and effort to curate. Within drug development, efforts have been underway through the Clinical Data Interchange Standards Consortium (CDISC) to standardize clinical research data.38 The Coalition for Accelerating Standards and Therapies (CFAST; https://c-path.org/programs/cfast) was initiated in 2012 as a partnership between CDISC and the Critical Path Institute (C‐Path) to accelerate clinical research by creating and maintaining therapeutic area data standards. Integrated and standardized data sets can catalyze biomedical discoveries and drug development28 as well as help the regulatory agencies to review new drug applications more efficiently. These standardized structured data sets are ideal for use as “training data sets” (refer to the ML Algorithms section) in ML. Together, data standardization and ML modeling could revolutionize drug discovery and development in these and other disease areas.

## Section: ML algorithms

ML algorithms may involve fitting data to statistical models or the algorithms may be more heuristic in nature. Unlike traditional model fitting, the goal of an ML algorithm is usually to make accurate predictions about outcomes for new data when the covariates are provided. The parameters returned by the model are generally of secondary interest, and statistical hypothesis testing is not usually performed.

## Section: ML algorithms › Supervised ML

A supervised ML algorithm requires an input data set, which can be split into a “training” data set and a “test” or “validation” data set. The process of fitting (or “calibrating”) the model to the training data set is called “model training.” The “trained” ML model can then be validated—having its predictive performance assessed—using the test or validation data set. The “validated” ML model can then be applied to new data sets (i.e., not used for model development) to make predictions or decisions based on the new data set covariates.

With supervised ML, the training data set contains both covariates and outcomes. Such a data set is called “labeled”39, 40 because it includes the outcomes. The outcome may be continuous or categorical. After a supervised ML model is trained, it can be used to predict outcomes for new data set based on its covariates. Several widely used algorithms in supervised ML are described in the next sections.

## Section: ML algorithms › Supervised ML › Linear and logistic regression

Multiple linear regression is a widely used algorithm in supervised ML when a continuous outcome varies linearly with the independent variables or covariates. An outcome or dependent variable can be represented as follows:Y=β0+β1x1+…+βnxn

where Y is the outcome prediction, β1-n are the coefficients and x1-n are the covariates. Ordinary least squares, which is based on the principle of maximum likelihood, is the simplest and most common way of estimating the coefficients. This model is not designed to handle strong collinearities between covariates. Severe multicollinearity greatly reduces the precision of the estimated coefficients. In such cases, principal component analysis may be used to reduce the number of features to a smaller set of unrelated components.

Logistic regression is a widely used supervised ML method for modeling binary outcomes, such as yes/no, success/failure, and survived/died. The logistic regression model estimates the probability that the outcome belongs to a particular binary category. The probability curve is sigmoid or S‐shaped and constrained between 0 and 1.PY=1=11+e-β0+β1x1+…+βnxn.

## Section: ML algorithms › Supervised ML › Ridge regression, least absolute shrinkage and selection operator (LASSO), and elastic net

Some data sets, such as genetic data sets, have large numbers of features (covariates) relative to the number of observations, but most features are expected to have minimal association with the outcome. Including all of the features in a linear or logistic regression model would add noise to the model and potentially result in a nonidentifiable model when the number of features is greater than the number of observations. Instead of reducing the number of features for multiple linear regression, we can fit a model starting with all predictors using a technique that constrains the coefficient estimates, or equivalently, that shrinks the coefficient estimates toward zero. The two best‐known techniques for shrinking the regression coefficients toward zero are ridge regression and LASSO.41 Multiple linear regression is the underlying model used for these techniques. However, the fitting procedure is not based on maximum likelihood. Instead, these techniques work by applying a “penalty” to the fitting procedure that depends on the magnitude of the coefficients. All coefficients are usually penalized equally. Therefore, before applying ridge regression or other shrinkage methods, the analyst will typically rescale the covariates to prevent covariates with numerically wider ranges from being excessively penalized.

Ridge regression shrinks the regression coefficients by imposing a penalty on their size. Instead of minimizing only the residual sum of squares, as ordinary least squares does, ridge regression minimizes:Y-βX2+γβ2.

Here, the first term is simply the residual sum of squares. In the second term, γ is a weight factor, and β2 is the sum of the squared coefficients. Thus, when γ=0 the ordinary least squares coefficients are returned, and when γ=∞, the coefficients will approach zero. However, a disadvantage is that it includes all predictors in the final model. As with the ridge regression, the LASSO shrinks the coefficient estimates toward zero:Y-βX2+λβ1.

Here, in the second term, λ is a weight factor, and β1 is the sum of the absolute values of the coefficients. This penalty has the effect of forcing some of the coefficient estimates to be exactly equal to zero. LASSO performs variable selection, yielding models that involve only a subset of the variables. As a result, models generated from the LASSO are generally much easier to interpret than those generated from the ridge regression. For a data set with N observations, LASSO will select at most N features.42 LASSO can also be adapted to fit logistic regression models.

Elastic net is another shrinkage‐based method that linearly combines the penalties from ridge and LASSO to minimize:Y-βX2+γβ2+λβ1.

Compared with LASSO, the elastic net can yield a model including more features than number of observations, but with possibly far fewer than would be selected via the ridge penalty alone. In addition, the elastic net exhibits a grouping effect, where highly correlated features will have similar estimated coefficients.

## Section: ML algorithms › Supervised ML › Decision trees and random forest

Decision trees41, 43, 44, 45 are a commonly used group of nonlinear ML methods. Each model is a set of rules organized in the form of a tree. Starting at the base or “root node,” the algorithm selects a “branch” based on the decision rule at the root node. The decision rule is generally based on a single covariate and a specified threshold (e.g., if the third covariate is greater than five, take the left branch). The algorithm then reaches the next node and follows the next decision rule. Eventually, the algorithm reaches a “leaf node,” which represents a specific output decision, returned as a result. Decision trees can be used for building both classification models for making qualitative predictions and regression models for making quantitative predictions. One reason for the popularity of single decision trees is their ease of interpretation and representation. However, they are outperformed by more advanced ML algorithms, such as random forest or gradient boosting modeling.

Random forest41, 46 is a method that creates a large collection of decision trees, where each decision tree makes a prediction or “vote” for a certain outcome. For each tree, typically one third of the training data set is randomly selected and set aside, and the remaining two thirds of the training data set is used for model development. When these decision trees are being built, each time a split in a tree is considered, a random sample of predictors is chosen as split candidates from the full set of predictors. A single predictor and a corresponding decision rule threshold are identified that maximize the accuracy of the decision tree. When all of the trees are completed, the model is ready to make predictions about new data. The prediction is defined by majority voting from this collection of decision trees. To evaluate the accuracy of the model, the trained forest can be used to predict the remaining one‐third of the observations and calculate the out‐of‐bag (OOB) error.

Random forest is a type of ensemble modeling because it involves combining multiple ML models to improve the overall performance of the model. Ensemble models generally combine the results by voting or taking the mode, mean, or weighted mean of the results from different models. More advanced techniques include bagging and boosting. Bagging involves creating random subsamples, or bootstrapping, of training data with replacement and building a model for each subset. For boosting, see the Gradient Boosting section.

## Section: ML algorithms › Supervised ML › Gradient boosting

Gradient boosting41, 47 differs from bagging methods in that the trees are trained and combined sequentially. This algorithm generates models by computing a sequence of trees in which each successive tree is built from the prediction residuals of the preceding tree. A simple partitioning of the data is determined at each step in the boosting tree algorithm, and the deviations of the observed values from the respective residuals for each partition are computed. Given the preceding sequence of trees, the next tree will then be fitted to the residuals to find another partition that will further reduce the error in the model.

## Section: ML algorithms › Supervised ML › Neural networks (NNs)

NNs48 are composed of units called artificial neurons. Each connection between neurons can transmit a signal to another neuron. All neurons have multiple inputs and one output. The receiving neuron can process the signals and then signal downstream neurons connected to it. Each input is associated with a weight that varies as learning proceeds, which can increase or decrease the strength of the signal that is sent downstream. A general formula for the output Y of a neuron is:Y=f∑iWiXi.

where f is a specified function, X i is the i th input, and W i is the weight associated with the i th input. Neurons are typically organized in the following three types of layers: (i) the input layer (i.e., the bottom layer), where the predictors are entered; (ii) the hidden (middle) layers; and (iii) the output layer (i.e., the top layer), where the predictions are generated.

Deep NN (DNN), also known as deep learning, refers to a model with more than one hidden (middle) layer. Recent advances of DNN‐based algorithms have been implemented in various fields from automatic speech recognition49 to medical image recognition.50 DNNs can be further categorized based on model architectures; convolution NN, recurrent NN, and long short‐term memory‐based recurrent NN.

## Section: ML algorithms › Supervised ML › Genetic algorithm

The genetic algorithm is inspired by the process of natural selection and belongs to the larger class of evolutionary algorithms. The genetic algorithm works as following:22 First, the solution space is defined and corresponds to a set of models to test.The search for the best model is initialized by randomly creating an initial population, defined as a set of individuals with a genome (model structures). These model structures can then be fitted to the data, and the best model is identified based on a goodness‐of‐fit statistic criterion (e.g., Akaike information criterion).Then, the next generation can be created by first selecting sets of “parents.” Parents are selected randomly, with replacement and probability of selection proportional to fitness.Next, the genomes of the parents are lined up and “crossover” occurs, i.e., some user‐defined fraction of the parent sets (e.g., 60%), at a single, random location in the genome. For instance, if the genome contains four genes (model characteristics: one compartment PK model + first‐order absorption + presence of lag time + proportional residual error), then a 50% split would generate the left part with “one compartment PK model + first‐order absorption” and the right part with “presence of lag time + proportional residual error.” Then, the left part of the first parent is combined with the right part of the second parent and vice versa.Subsequently, a mutation is randomly applied based on a prespecified small proportion. For instance, the “presence of lag time” feature is reversed to “absence of lag time.”This process is repeated until no further improvement is seen (i.e., a model with an improved goodness‐of‐fit criterion is no longer obtained).

A reproducible example can be found in Bies et al.,22 where a genetic algorithm–based, hybrid ML approach to model selection has been developed and applied.

## Section: ML algorithms › Unsupervised ML

Unsupervised ML deals with unlabeled data51 defined as data that include the covariates, but not the outcomes. This technique is used to identify patterns and associations between data points. Dimensionality reduction methods may be applied as a first step in the analysis.52 Principal component analysis is among the most widely used dimensionality reduction techniques. In addition, the data may also be normalized to facilitate comparison between data points. Several widely used algorithms in unsupervised ML are described in the next sections.

## Section: ML algorithms › Unsupervised ML › K‐means

K‐means groups data points with similar properties or features into a fixed number of clusters (K). K‐means is commonly applied to gene expression or clinical lab data to identify similar groups of samples or subjects. The algorithm can be initialized by randomly selecting K “centroids” from the data set. A centroid is a data point (imaginary or real) at the center of a cluster, i.e., the mean value of the points assigned to the cluster. Hence, “means” in the “K‐means” expression corresponds to the centroid.53 Each data point is assigned to the nearest cluster. Each centroid is then updated (i.e., iteration) so that the total within‐cluster variation is minimized. There are several K‐means algorithms, and the standard algorithm defines the total within‐cluster variation as the sum of squared Euclidean distances between points and the corresponding centroid.54 Most often, a local optimum is achieved; hence, it is suggested to run the algorithm multiple times with randomized starting centroids for better outcome. Systematically, the steps are the following:54 Define K, the number of clusters to be created.Select randomly K centroids from the data set (i.e., the initial cluster centers).Assign each data point to the nearest centroid based on the Euclidean distance between the point and the centroid.Recompute the centroid for each of the K clusters by calculating the new mean value of all the data points in the cluster.Iteratively minimize the sum of squared Euclidean distances. Repeat Step 3 and Step 4 until the centroids do not change.

To select the number of clusters, the total within‐cluster distance to the centroid may be compared for increasing K values. The point where the average within‐cluster distance to the centroid levels off may be chosen as the value of K.

K‐means is relatively fast, robust, and easy to interpret. It is also relatively efficient when the data set are well separated from each other. However, some drawbacks of K‐means include (i) a priori selection of K, (ii) distinguish data that are close or overlapping, (iii) obtain different results produced by non‐linear transformation, and (iv) inability to handle categorical data.

## Section: ML algorithms › Unsupervised ML › Hierarchical

This algorithm creates a set of nested clusters structured as a hierarchical tree. Unlike K‐means, hierarchical clustering starts with considering each observation as an individual cluster. Then iterations are performed to merge similar clusters until all the clusters are merged. A dendrogram (i.e., a tree diagram that shows the taxonomic relationship between covariates) is obtained to show the hierarchical relationship between the clusters. This technique is also known as agglomerative hierarchical clustering. Another less commonly used hierarchical technique is called divisive hierarchical clustering, where all the observations are grouped into one cluster and then successively split into multiple clusters.

Hierarchical clustering offers several advantages including easy implementation and the lack of a need to specify the number of clusters. However, limitations include sensitivity to outliers and greater computation resource requirements.

## Section: ML algorithms › Active learning

Active learning is a ML method where the algorithm can interactively request labeled data to train themselves. Active learning can be used when a full labeled data set has not yet been collected and cost constraints prevent full labeling. For example, if one wishes to predict affinity to a protein based on selected chemical features, it may be too expensive to run experiments with a full compound library. An active learning algorithm would design a series of experiments to learn the relationship between the chemical features and affinity. Each experiment would be designed based on the previous data obtained. The algorithm would select the most informative compounds for future experiments. Although there are many different approaches to active learning, these methods often use a supervised ML algorithm to process the data that have already been collected.55 To select new data for labeling, an active learning algorithm may identify unlabeled samples that have the greatest prediction uncertainty. These samples will be more informative compared with samples with high prediction certainty, thus allowing greater improvement in prediction accuracy.

## Section: Good practices for ML model development and validation › Data curation and preparation

Every ML experiment begins with data curation on the data required to build a model (i.e., training data); indeed, a common saying is that a model will be only as good as the data from which it is derived.56, 57 Modelers typically rely on data generated (and, more recently, even compiled) by other scientists. Therefore, data quality is often highly dependent on the data providers. Although often an overlooked aspect, data curation and preparation are cornerstone to develop reliable models. Common issues related to data curation and preparation are described in the next sections. Good practices for the curation of chemical data sets in drug discovery are presented in Box 2.

## Section: Good practices for ML model development and validation › Data curation and preparation › Outliers

Data entry or experimental errors can introduce observations that appear to be inconsistent with the rest of the data. Data curation includes identifying and potentially removing or correcting outliers.64 The modeler could also perform a sensitivity analysis by rerunning the model without the outliers and comparing the model results.

Because many data sets for ML are large, manually identifying and handling outliers may not be possible. However, one may be able to summarize the covariate ranges and visually inspect the distributions to identify outliers or ranges where outliers fall. Heuristic or statistical/mathematical methods to detect and handle data outliers can be performed in a semiautomated manner.65, 66

## Section: Good practices for ML model development and validation › Data curation and preparation › Missing data

Another challenge with data preparation is handling missing data. Missing data are not unusual, often the result of missed data collection or entry and issues with data processing. Although some ML algorithms, such as random forest, can handle missing data, most algorithms do not perform well with missing data.

There are several strategies to handle missing data. The first step should be to find the number of the missing values and visualize their distribution. Packages in R and Python such as VIM67 and missingno68 can aid in this process. As a rule of thumb, and depending on the importance of the variable, one could consider removing variables with 70% or more missing data, as often they do not provide information toward predictability. For the remaining covariates, the simplest strategy is to remove data points for which any covariate is missing. Another simple alternative is to replace missing values with the median value for continuous variables or with the mode for categorical variables. For time‐dependent variables, similar statistical measures could be considered across time points. Although these strategies allow ML models to be fit by various algorithms, they may also introduce bias.

More sophisticated approaches to handle missing data for time‐dependent variables include model‐based imputation (e.g., regression model of height and weight in children). Another model‐based imputation is the K‐nearest neighbor. The assumption with K‐nearest neighbor is that a missing point value can be approximated by the values of the nonmissing points that are closest to it based on other variables.

For established pharmacometric analyses, several effective strategies to handle missing data have been described in the literature.69 Handling missing data is usually quite challenging, and strategies to address it need to be executed in the context of the problem at hand. Often, a combination of different methods might be required to effectively manage missing data.

## Section: Good practices for ML model development and validation › Overfitting

Overfitting is gaining explanatory power of the training data by sacrificing generalizability (i.e., predictive ability for relevant data sets not used in the model building). As in any learning task, memorizing peculiarities of the training data (i.e., fitting noise) is discouraged because the goal of learning is to envision a general principle that can be later applied to other scenarios or cases. According to the principle of parsimony, one should use the simplest model or method that delivers the pursued performance level (e.g., avoid using NN or random forest if a single linear model provides an adequate solution). This also means to avoid including more parameters and/or covariates than required.70 Models that explain too well the training data usually experience a sharp drop in performance when making predictions for new data.

Overfitting may be addressed in a retrospective manner (i.e., after model development) using adequate model validation procedures (refer to the Model Validation section) or in a prospective manner (i.e., before model development). The distinction between retrospective and prospective approaches to avoid overfitting is philosophically similar to the distinction between quality control and quality assurance. In the context of computer‐aided drug discovery and development of ML models, both prospective and retrospective approaches are utilized.

Prospective avoidance of overfitting usually involves a rule of thumb regarding the ratio of training observations to covariates included in the model. A minimum ratio of 5:1 is often recommended for multivariate regression approaches,60, 71 but a more conservative ratio of 10:1 is safer.

An approach called regularization can help avoid overfitting when using complex, flexible ML approximations.72 Regularization techniques are neither prospective nor retrospective, but somewhat in the middle, as they are applied “on the fly” while training the model. For example, dropout is a regularization technique used in the context of DNN; it consists of removing or ignoring randomly selected neurons during training, resulting in a network that is capable of better generalization.73 Moreover, for complex ML approaches that require tuning hyperparameters (e.g., learning rate and number of hidden units in a neural network), the models are usually interrogated by a third data set (besides traditional training and holdout sets), which is called a “test data set.” Test data sets can be used for regularization by early stopping, i.e., stopping further training when the error on the validation data set increases, as this is a warning of overfitting.74

Overfitting can depend on the number of tested covariates in the model.75 If covariates are added in an univariate or stepwise manner, then one must consider the inflation of the false positive rate or Type I error as a result of multiple comparison, i.e., the larger the number of covariate models tested, the greater the probability of finding significant covariates by chance. For instance, if one statistical test is performed at the 0.05 α level and the null hypothesis is true, there is a 5% chance of incorrectly rejecting the null hypothesis (i.e., false positive or Type I error); however, if 10 independent statistical tests are performed and the null hypotheses are true, the family‐wise error rate is 40%. If these “false positive” covariates are then included in model, this will contribute to overfitting. We have observed that the use of small random subsets of descriptors (a “random subspace” approximation) is a useful strategy to mitigate the chance of spurious correlations.76 Ensemble learning, which is the combination of individuals models into a meta‐model (e.g., random forest), can also improve model robustness.

## Section: Good practices for ML model development and validation › Model validation

Model validation is performed to assess the model’s predictive performance when it is used to make predictions for relevant data that were not used for model building. A validated model is expected to make sufficiently accurate predictions for the intended use (i.e., to have sufficient predictive performance). Model validation includes a series of techniques for quantitative assessment of the model stability and predictive power;77, 78 it serves to detect the occurrence of overfitting and chance correlations (when no cause–effect relationship is encoded in the correlation). Validation techniques can be roughly classified into internal and external validation approaches.

## Section: Good practices for ML model development and validation › Model validation › External validation

External validation is the most stringent type of model validation.77, 79 Here, the validation data set should be completely independent from the training data set—e.g., a different study altogether. For instance, a model was developed using a sample of subjects with disease X (training data set), and the intended use for the model is to make predictions of any sample of subjects with disease X outside of the training data set. A successful external validation may rely on the following assumptions: (i) the training data set is representative of the general population with disease X, and (ii) the validation data set is a sample of the population with disease X, consequently, a sample of the training data set.

The validation data set must not be used at any stage of the model development or selection. If this condition is not met, then an additional external validation data set would be required as a more definitive proof of the model predictive ability.57 For instance, if multiple models are built and the best models are selected based on the predictive performance for the validation data set, then this is not an external validation. Something similar occurs when a model ensemble is built using a selective ensemble procedure based on the performance on a holdout set; in this case, a third validation sample should be included as solid proof of the ensemble predictive power.

## Section: Good practices for ML model development and validation › Model validation › Internal validation

Cross‐validation is one of the most frequently used internal validation procedures. It can be used when an external validation data set is not available or is prohibitively expensive to obtain. However, it is important to understand that internal validation methods can be considered overoptimistic in the sense that a successful internal validation does not guarantee transportability.

The simplest type of cross‐validation is the holdout method.80 The analysis data set is split into two subsets called the training subset and the holdout subset. The model is developed using the training subset only and used to make predictions for the holdout subset. Then, at the minimum, a measure of the residuals (e.g., difference between the observed and model predicted values) could be used to evaluate the model performance. However, evaluation results can have a high variability, depending on which data points end up in the training vs. the test subset.80 Ensuring that the data set is split randomly and relevant variables are balanced among the subsets can help mitigate this issue.

K‐fold cross‐validation is an improvement of the holdout method.80 The training data set is randomly divided into K equal or nearly equal subsets (also called “folds”) and then K‐1 parts of it are systematically used for model development and the remaining fraction is reserved for model evaluation. The process is repeated until each part has been once removed from the training data set. Averaging the predictive performance on the folds allows computing a confidence interval for the parameter estimates, for instance. Although the training data set should be randomly divided into K parts, one may want to ensure that relevant variables are balanced among the K parts. The advantage of this method is that the variability in evaluation results as a result of the splits of the data set is attenuated, with the reduction magnitude being directly proportion to the size of K.80 Leave‐one‐out cross‐validation is a K‐fold cross‐validation with K equal to N, where N is the number of independent experimental units (i.e., subjects within a study). Although K‐fold cross‐validation methods are more computationally intensive, they can be automated using packages such as caret (refer to the Resources section). Cross‐validation has also been implemented in Perl‐speaks NONMEM as part of the stepwise covariate modeling procedure.81

## Section: Good practices for ML model development and validation › Data leakage

Data leakage is a common and critical mistake when developing ML models. Definitions for data leakage include the following: (i) it is “when information from outside the training data set is used to create the model”82 or (ii) “when the data you are using to train a ML algorithm happen to have the information you are trying to predict.”83 Data leakage may reduce the generalization of the model (overfitting), overestimate model performance, and/or completely invalidate the model. A common example of data leakage is leaking data from the test or validation data set into the training set:82, 83, 84 Perform data preparation (e.g., variables normalization) or featuring engineer in the whole data set before splitting into training and validation data setsIn time‐series data: Sample time points instead of experimental units (e.g., subjects) when setting aside the validation data setInclude time‐varying predictors that are correlated with time and have a similar distribution between the training and validation data sets

Other examples are:82, 83, 84 Leaking the correct prediction into the test data (e.g., use the response itself as a predictor)Leaking of information from the future into the pastReversing randomization or anonymization of data that were intentionally includedInclude information from data that is outside of the application scope for the model

Recommendations to avoid data leakage include:82, 83, 84 Remove incremental identification fields from the data setWhen possible, remove predictors that are correlated with time from time‐series data setsConduct data preparation and feature engineering separately for the training and validation data sets. In the case of cross‐validation, this should be done within the cross‐validation foldsIn time‐series data, perform nested cross‐validation to evaluate performance: select a particular time value (t) and, for instance, establish that all data points lower than (or equal to) t will be part of the training set, and all data points greater than (or equal to) t will be part of the validation data setUse an unseen validation data set as a final check

## Section: A reproducible example › ML model to guide drug repurposing: Searching for novel inhibitors of putrescine uptake in Trypanosoma cruzi (T. cruzi)

This example is an adaptation of the work of Alberca et al. 76 to obtain a ML model for the subsequent search for drugs against T. cruzi, i.e., putrescine uptake inhibitors. T. cruzi is a parasite that is transmitted to animals and people by insect vectors and causes Chagas disease, a neglected tropical infectious disease endemic to Latin America.85 Putrescine is a low‐molecular‐weight polyamine with crucial importance for the parasite survival.76 Different from humans, T. cruzi cannot synthesize putrescine and must uptake it from the human host via a high‐affinity putrescine transporter; this makes putrescine uptake an attractive target for drugs against T. cruzi.76

Alberca et al.76 developed a linear regression model using small random subsets of descriptors (a random subspace approximation) followed by an ensemble‐learning procedure to combine the results (Supplementary Material S1 ).76 Although we follow the data set preprocessing (i.e., creation of the training and validation data sets) of Alberca et al., a random forest model and a LASSO model are developed for demonstration (Supplementary Material S2 ).

For model development and validation, a data set composed of 256 polyamine analogs (previously assayed against T. cruzi) was compiled from literature.76 The 256 compounds were labeled as “active” or “inactive” according to their half‐maximal effective concentrations against T. cruzi. The active group were compounds with half‐maximal effective concentrations of less than 20 µM (n = 116), and the remaining compounds were considered inactive (n = 140).

For reproducibility, Supplementary Material S3 carries the data set with the 256 compounds (polyamines_dataset.csv). The first column of the data set contains a code for each compound, with the compounds labeled as “AXXX” belonging to the active class, and the compounds labeled as “IXXX” belonging to the inactive class. The second column is a binary dependent variable (named “ActivityClass”) that takes values of 0 for the inactive compounds and values of 1 for the active compounds. Other data set columns are the 3,668 molecular descriptors that were computed with Dragon 6.0 (commercial software, Milano Chemometrics & QSAR Research Group, Syracuse, Italy); these descriptors can be used to evaluate molecular structure‐activity relationships as well as high‐throughput screening of molecule databases.86 Common examples of molecular descriptors are molecular weight and number of atoms.

The procedure for the analysis is the following: A series of packages required for data analysis purposes are installedWorking directory is setData set with the 256 compounds is readA random and balanced training data set with 87 active and 87 inactive compounds is obtained. The data set consisting of 256 polyamine analogs was divided into two groups using a representative sampling procedure: (i) training data set, which was used to develop or “train” the models, and (ii) test data set, which was used to internally validate the models. Of the compounds, 75% (n = 87) in the active group were kept for the training data set; an equal number of compounds (n = 87) were taken from the inactive group (62.1% of the inactive group). To obtain a balanced training data set, we have undersampled the inactive group. A balanced training data set prevents model bias toward predicting a specific category (i.e., active vs. inactive). In the original article, Alberca et al.76 sampled the 87 compounds from the active and inactive groups through a two‐step clustering approach (hierarchical clustering followed by K‐means) to ensure representativity. For simplicity, we have omitted this sampling approach in this example.

# Obtain a random and balanced training data set with 87 active # and 87 inactive compounds set.seed(123) random_sample <- strata(data = data set, stratanames = "ActivityClass", size = c(87, 87), method = "srswor" ) training_set <- data set[random_sample$ID_unit, ]

Columns (i.e., variables) with missing values or scarcely informative descriptors (constant or almost constant values) are then removed to yield the final training data set with 1,608 predictors:

# Columns containing non‐available descriptor values for at # least one compound are removed (i.e., keep only descriptor # with information available for all compounds) training_set <‐ training_set[ , apply(training_set, 2, function(x) !any(is.na(x)))] # Columns displaying no variance (sd = 0) or almost no variance # are indexed. Applied to numeric columns only. index_low_variance <‐ nearZeroVar(x = training_set) # Remove the previously indexed columns training_set <‐ training_set[ , ‐index_low_variance]

The remaining 29 active and 53 inactive compounds were assigned to the validation data set. For simplicity, a holdout cross‐validation (internal validation) is being used.

# Create the validation set testing_set <‐ data set[‐random_sample$ID_unit, ] testing_set <‐ subset(testing_set, select = names(training_set))

Then we develop a random forest model using default parameters. Among the “randomForest” arguments are “mtry” and “ntree”: (i) mtry is the number of variables tried at each split. The default values are different for classification (sqrt(p) where p is number of predictors) and regression (p/3). (ii) ntree is the number of trees to grow with a default of 500. Note that this should be set to a reasonable large number to ensure that every input row gets predicted at least a few times.

# Develop a random forest model using default parameters set.seed(123) rf_model <‐ randomForest(ActivityClass ~ ., data = training_set, importance = TRUE) rf_model # Call: # randomForest(formula = ActivityClass ~ ., data = training_set, importance = TRUE) # Type of random forest: classification # Number of trees: 500 # No. of variables tried at each split: 40 # # OOB estimate of error rate: 23.56% # Confusion matrix: # 0 1 class.error # 0 72 15 0.1724138 # 1 26 61 0.2988506 # Predicting on validation set and check classification accuracy pred_testing_rf <‐ predict(rf_model, testing_set, type = "class") mean(pred_testing_rf == testing_set$ActivityClass) # 0.804878 table(pred_testing_rf, testing_set$ActivityClass) # pred_testing_rf 0 1 # 0 43 6 # 1 10 23

In the previous model, a few metrics can be looked at to evaluate this forest classification model, such as OOB estimate of error rate (23.6%) for the training data set and the classification accuracy (80.5%) and confusion matrix for the validation data set—(i) OOB error rate: for each tree, one third of the training data set is randomly selected and set aside (do not confuse it with the validation or holdout data set), hence the trained forest model makes predictions on the remaining one third of the observations and calculate the OOB error; (ii) classification accuracy is the proportion in which the model predicted the correct classification of the validation data set (i.e., the number of correct predictions divided by the total number of predictions); and (iii) the outputted confusion matrix can be interpreted as following:

True classification 0 1 Predicted classification 0 True negative (TN)False negative (FN) 1 False positive (FP)True positive (TP)

where 0 and 1 correspond to the inactive and active classifications, respectively. From this, the positive predictive value (PPV) and the negative predictive value (NPV) can be derived:PPV=TPTP+FP=2323+6=0.793or79.3%. NPV=TNTN+FN=4343+10=0.811or81.1%.

Hence, PPV is the proportion of positive predictions that are true positives, and NPV is the proportion of negative predictions that are true negatives.

As we mentioned previously, random forest is a type of ensemble modeling in that it combines multiple ML models to improve the overall performance of the model. This along with the fact that the random forest model is interrogated "on the fly" by a test data set (one third of the training data set) make for a powerful ML algorithm. In this example, however, interpreting an ensemble of 500 trees with more than a thousand predictors is rather cumbersome, and the modeler may want to investigate the performance of a simpler model.

Therefore, we also developed a logistic regression model:

# 10‐fold cross‐validation set.seed(123) fitControl <‐ trainControl( method = "cv", number = 10) # Logistic regression model training logistic_model <‐train(ActivityClass ~ ., data = training_set, method = "glm", family = "binomial", maxit = 100, trControl = fitControl) ## Predicting on training set and checking classification accuracy pred_training_logistic <‐ predict(logistic_model, training_set) mean(pred_training_logistic == training_set$ActivityClass) # 1 table(pred_training_logistic, training_set$ActivityClass) # pred_training_logistic 0 1 # 0 87 0 # 1 0 87 ## Predicting on testing set and checking classification accuracy pred_testing_logistic <‐ predict(logistic_model, testing_set) mean(pred_testing_logistic == testing_set$ActivityClass) # 0.5609756 table(pred_testing_logistic, testing_set$ActivityClass) # pred_testing_logistic 0 1 # 0 31 14 # 1 22 15

As we expected, the accuracy of the logistic model in predicting the training data set (100%) is higher than that of the random forest model. However, it performs poorly in predicting the validation data set (i.e., close to a random classification). This is an example of overfitting, as logistic regression cannot handle a large number of covariates.

We then perform a multiple linear regression model with the LASSO algorithm, a relative simple model that can work with many covariates by performing variable selection:

# Format x and y variables as required (x as a matrix, y as a list of # values) x <‐ as.matrix(training_set[ , ‐1]) # Removes ActivityClass y <‐ as.double(as.matrix(training_set[ , 1])) # Only ActivityClass x_test <‐ as.matrix(testing_set[ , ‐1]) # Removes ActivityClass y_test <‐ as.double(as.matrix(testing_set[ , 1])) # Only ActivityClass # Use default parameters # alpha=1 is the lasso penalty, and alpha=0 the ridge penalty. # Logistic regression (family=’binomial’), as we have a # binary response. Here, we already perform 10‐fold cross # validation to choose the best λ. set.seed(123) cv_lasso <‐ cv.glmnet(x, y, family = 'binomial', alpha = 1, type.measure = 'class') # lengthy output suppressed # best lambda cv_lasso$lambda.min # 0.02904885 # extract only non‐zero coefficients extract.coef(cv_lasso) # or equivalent coef(cv_lasso, s = "lambda.min")[which(coef(cv_lasso, s = "lambda.min") != 0)] # results 44 non‐zero coefficients # Predicting on validation set and check classification accuracy pred_testing_lasso <‐ predict(cv_lasso, newx = x_test, type = "class", s = "lambda.min") mean(pred_testing_lasso == y_test) # 0.7682927 table(pred_testing_lasso, y_test) # y_test # pred_testing_lasso 0 1 # 0 44 10 # 1 9 19

LASSO selected 40 predictors for the final model. For the validation data set, the classification accuracy, PPV, and NPV are 76.8%, 65.5% and 83.0%, respectively. Although the classification accuracy and NPV are comparable with those of the random forest model, the PPV is lower (65.5% vs. 79.3%). Whether the percent reduction in PPV with LASSO justifies the choice of the random forest model though will depend of the context in which the model will be applied. Herein, the fit‐for‐purpose context goes beyond knowing that the model will be applied to screen for potential drug candidates to treat against T. cruzi. For instance, let us assume that an “active” classification from the model will be the gold standard on deciding whether to translate the compound to a clinical trial in the disease population. In this case, having a model with a higher PPV is probably warranted. On the other hand, if the model will be used to generate a short list of compounds (i.e., getting rid of probable inactive compounds) to be tested in a series of more definitive in vitro tests, then the LASSO would be expected to perform similarly to the random forest model (NPV of 83% and 81% for LASSO and random forest, respectively). In summary, there is no absolute best ML algorithm.

## Section: Resources

The popularity and widespread adoption of ML across industry has helped create versatile tools and resources for researchers to build a variety of ML models. For the benefit of our readers, we have compiled a list of open source tools and learning resources related to ML (Table 1). Although the list is not exhaustive, it contains a useful collection of tools based on our experience with building ML models.

Open source tools and learning resources on ML

## Section: Additional considerations

Models used by ML algorithms may be much more complex than traditional statistical models, thus limiting interpretability. In some cases, the model could be interpreted based on the relative importance of the covariates. This could be determined, for example, by refitting the model without a given covariate and computing the reduction in model accuracy. Another way of interpreting the effect of a covariate is to plot the predicted outcome vs. the covariate, setting the other covariates equal to their medians within the data set.

In pharmacometric analysis, models are often used to simulate new data. However, many ML models do not describe the variability in the outcome as a model parameter, thus making the simulation process more difficult. If new simulated outcome data are required, and the covariates are provided, one approach is to start with the model predictions and add random noise with a variance determined by the model accuracy for the test or validation data set. However, this approach may not work when there are repeated measurements within subjects because model accuracy alone does not distinguish between intersubject and intrasubject variability.

This first part of our work presented a tutorial on ML concepts and technical aspects. With such knowledge, the reader will be able to follow the second part of our work, which is an overview on applications of ML in drug discovery, drug development, and the postapproval phase.

## Section: Funding

No funding was received for this work.

## Section: Conflict of Interest

The authors declared no competing interests for this work.

## Section: Supporting information

Supplementary Material S1.

Supplementary Material S2.

Supplementary Material S3.

Click here for additional data file.


---

# Machine Learning Methods in Drug Discovery

- **Authors:** Lauv Patel, Tripti Shukla, Xiuzhen Huang, David W Ussery, Shanzhi Wang
- **Issuer:** Molecules (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2020-11-12
- **Language:** en
- **DOI:** 10.3390/molecules25225277
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33198233/
- **Licence:** CC-BY

## Section: Abstract

The advancements of information technology and related processing techniques have created a fertile base for progress in many scientific fields and industries. In the fields of drug discovery and development, machine learning techniques have been used for the development of novel drug candidates. The methods for designing drug targets and novel drug discovery now routinely combine machine learning and deep learning algorithms to enhance the efficiency, efficacy, and quality of developed outputs. The generation and incorporation of big data, through technologies such as high-throughput screening and high through-put computational analysis of databases used for both lead and target discovery, has increased the reliability of the machine learning and deep learning incorporated techniques. The use of these virtual screening and encompassing online information has also been highlighted in developing lead synthesis pathways. In this review, machine learning and deep learning algorithms utilized in drug discovery and associated techniques will be discussed. The applications that produce promising results and methods will be reviewed.

## Section: 1. Introduction

Advancements in computational science have accelerated drug discovery and development. Artificial intelligence (AI) is widely used in both industry and academia. Machine learning (ML), an essential component in AI, has been integrated into many fields, such as data generation and analytics. The basis of algorithm-based techniques, such as ML, requires a heavy mathematical and computational theory. ML models have been used in many promising technologies, such as deep learning (DL) assisted self-driving cars, advanced speech recognition, and support vector machine-based smarter search engines [1,2,3,4]. The advent of these computer-assisted computational techniques, first explored in the 1950s, has already been used in drug discovery, bioinformatics, cheminformatics, etc.

Drug discovery has been based on a traditional approach that focuses on holistic treatment. In the last century, the world’s medical communities started to use an allopathic approach to treatment and recovery. This change led to the success of fighting diseases, but high drug costs ensued, becoming a healthcare burden. While quite diverse and specific to candidates, the cost of drug discovery and development has consistently and dramatically increased [5]. As illustrated in Figure 1, the generalized components of early drug discovery include target identification and characterization, lead discovery, and lead optimization. Many computer-based approaches have been used for the discovery and optimization of lead compounds, including molecular docking [6,7], pharmacophore modeling [8], decision forests [9], and comparative molecular field analysis [10]. ML and DL have become attractive approaches to drug discovery. The applications of ML and DL algorithms in drug discovery are not limited to a specific step, but for the whole process. In this article, we review the ML and DL algorithms that have been widely used in drug discovery.

## Section: 2. ML Algorithms Used in Drug Discovery

ML algorithms have significantly advanced drug discovery. Pharmaceutical companies have greatly benefited from the utilization of various ML algorithms in drug discovery. ML algorithms have been used to develop various models for predicting chemical, biological, and physical characteristics of compounds in drug discovery [11,12,13,14,15,16,17,18,19]. ML algorithms can be incorporated in all steps of the process of drug discovery. For example, ML algorithms have been used to find a new use of drugs, predict drug-protein interactions, discover drug efficacy, ensure safety biomarkers, and optimize the bioactivity of molecules [20,21,22,23,24]. ML algorithms that have been widely used in drug discovery, which include: Random Forest (RF), Naive Bayesian (NB), and support vector machine (SVM) as well as other methods [25,26,27].

ML algorithms and techniques are not a monolithic, homogeneous subset of AI. There are two main types of ML algorithms: Supervised and unsupervised learning. Supervised learning learns from training samples with known labels to determine labels of new samples. Unsupervised learning recognizes patterns in a set of samples, usually without labels for the samples. The data are usually transformed into a lower dimension to recognize patterns in high-dimensional data using unsupervised learning algorithms prior to recognizing patterns. Dimension reduction is useful, not only, because unsupervised learning is more efficient in a low dimension space but also because the recognized pattern can be more easily interpreted. Supervised and unsupervised learning can be combined as semi-supervised and reinforcement learning, where both functions can be utilized for various data sets [28]. Expansive volumes of data are critical for the development, evolution, and viability of successful ML algorithms in every step of the drug discovery process. The reliance on big high-quality data and known, well-defined training sets are even more essential in precision medicine and therapies within drug discovery. Precision medicine requires a comprehensive characterization of all related pan-omic data: Genomic, transcriptomic, proteomic, etc., to assist in developing genuinely effective personalized medicines. The widespread use of high-throughput screening and sequencing, online multi-omic databases, and ML algorithms, in the past two decades, have created a flourishing environment for many aspects of data generation, collection, and maintenance required for drug development. The advancements of data analytics have successfully attempted to describe and interpret the generated data. This endeavor, supported with ML techniques and integrated databases through multiple software/web-tools (Table 1, Table 2 and Table 3), is now regularly used for all steps in drug discovery. The ability of new data analytics to synergize with classical approaches and prior hypotheses to produce novel hypotheses and models has proven itself to be useful in applications of repositioning, target discovery, small molecule discovery, synthesis, etc. [29,30,31]. The information generated within the medical and multi-omic fields is multidimensional. The data is often noisy and heterogeneous in character and source. Using ML methods, like generalized linear models through NB, the issues of analysis and interpretation of multidimensional data may be unburdened. Other ML techniques and models commonly used in these areas of analysis include regression, clustering, regularization, neural networks (NNs), decision trees, dimensionality reduction, ensemble methods, rule-based methods, and instance-based methods [31,32].

## Section: 3. Random Forest (RF)

RF is a widely used algorithm explicitly designed for large datasets with multiple features, as it simplifies by removing outliers, as well as classify and designate datasets based on relative features classified for the particular algorithm. It is commonly trained for large inputs and variables and accessibility based on data collection from multiple databases. It is beneficial in different aspects, such as attributing missing data, working with outliers, and estimating characteristics for classification [25]. The underlying mathematical process of RF consists of several uncorrelated decision trees as an ensemble; each tree is responsible for determining one prediction. The one that constitutes the most votes is considered the best fit (Figure 2a) [36]. Although false positives may happen in any statistical analysis, RF, along with SVM and NB, has been suggested to make the least amount of errors compared to other algorithms. With multiple decision trees, individual errors are minimized due to their assemblies of several predictions rather than solely focusing on one prediction.

In drug discovery, RFs are mainly used either for feature selections, classifiers, or regression. Cano et al. utilized RF methods to improve affinity prediction between ligand and the protein by virtual screening through selecting molecular descriptors, based on a training data set for enzymes, such as ligands of kinases and nuclear hormone receptors. Some of the essential factors accompanying RF in drug discovery are: It expedites the training process, uses fewer parameters, imputes missing data, and incorporates nonparametric data [37]. Rahman et al. utilized multivariate RF by including information relating to genomic sequencing, which helped sustain error and achieve drug responses based on genomic characterizations. Multivariate RFs specialize in limiting error by calculating several error estimates techniques within the system. The computational framework inputs the data that incorporates genetic and epigenetic characterization combinations, allowing the framework to predict the mean and confidence interval of the drug responses. An important quality essential for analyzing any drug to be processed in clinical trials [38]. Rahman et al. endeavored to combine the modeling framework with functional RF for improving the prediction based on the response profile. They tried to combat the difficulties observed in individuals related to finding appropriate compounds depending on individual tumors. RF was incorporated for the generation of the regression tree node and leaf nodes. It acquired the data points of dose-responses. The leaf nodes in the algorithms are responsible for making predictions about the dose-response profile, simultaneously storing the functional data. The model recorded data is comprised of the genome sequences and their characteristics [39]. RF algorithms have also been implemented as a method of classification and regression in a quantitative structure-activity relationship (QSAR) modeling used in lead discovery processes [40,41].

## Section: 4. Naive Bayesian (NB)

NB algorithms are a subset of supervised learning methods that have become an essential tool used in predictive modeling classification. Standard NB algorithms work to classify features of datasets, and depending on the input characteristics, factor correlation, and dimensionality of the data, it can be one of the most efficient techniques for the task [42,43,44]. The effectiveness of NB alongside decision tree algorithms for the use of text mining has not been determined. These techniques enhance the accuracy of retrieved data sets, which generally originate in large, muddled sources [45,46]. Classification of biomedical data is crucial in the drug discovery process, especially in the target discovery subset. NB algorithms have shown great promise as classification tools for biomedical data, often filled with non-related information and data, known as noise [47]. NB techniques could also serve important roles in predicting ligand-target interactions, which could be a massive step forward in lead discovery [48]. Recently, researchers have been able to incorporate NB techniques into diverse applications within the drug discovery process. In a study, Pang et al. used NB models and additional techniques as classifiers for active and inactive compounds, with possible activity as antagonists for estrogen receptors in breast cancer [49]. The researchers utilized the ability of NB algorithms to process vast quantities of information while having a unique tolerance to random noise. The technique, in combination with other tools such as extended-connectivity fingerprint-6, was able to collect excellent outputs. In a recent study, Wei et al. utilized a combinational technique of NB and support vector machine algorithms to predict possible compounds that could be active against targets of human immunodeficiency virus type-1 and the hepatitis C virus generated from multiple QSAR models [50]. Their model utilized NB as a classifier technique paired alongside two different descriptor systems, one also being extended-connectivity fingerprint-6. The utilization of NB, combined with other systems and techniques, has shown to be useful in incorporating drug discovery processes.

## Section: 5. Support Vector Machine (SVM)

SVMs are supervised machine learning algorithms used in drug discovery to separate classes of compounds based on the feature selector by deriving a hyperplane. It utilizes the similarities between classes to formulate infinite numbers of the hyperplane. For linear data, it trains by separating classes consisting of compounds based on selected features and projects them into chemical feature space. An optimal hyperplane attained by maximizing margin between classes in N-dimensional space (N is the number of features); it is denoted by a hyperplane, which is used to classify data points by setting decision boundaries [51]. SVM is crucial to drug discovery because of its capability of distinguishing between active and inactive compounds, ranking compounds from each database (shown in Figure 2b), or training regression model. Regression models are vital in determining the relationship between the drug and ligand, as it employs a query for datasets to predict [52,53,54,55]. When several active compounds are screened against a single protein of interest, SVM can be attributed in various scenarios. SVM classification has a subset binary class prediction that could differentiate between active from inactive molecules.

For drug discovery, it could rank compounds from different databases based on the probability of being active for any computational screening. SVM can be extrapolated in different ways to attain results, with a main focus to distinguish between active and inactive compounds. The process could be manipulated by training the algorithm using various descriptors for feature selectors such as 2D fingerprints, and target protein. A class label is formulated, negative or positive, depending on the direction where the compound is placed from the hyperplane, thereby ranking compounds from the most selective to least selective [55,56]. However, for non-linear data, kernel functions are utilized to optimize the results. Kernel functions plot the data in a higher-dimensional space, where the separation between classes is feasible.

For drug-target interaction, it is specifically designed for integrating ligands and proteins of interest information as an essential component for SVM modeling [51]. Wang et al. investigated drug-target interactions and integrated information obtained from published research of various source to enhance the prediction. They used kernel function to incorporate information on drug pharmacological and therapeutic effects, drug chemical structures, and protein genomic information to characterize the drug-target interactions. Generally, results from the different sources were all promising, and kernel function for the prediction of pharmacological and therapeutic effects displayed the most potential [57]. SVM are also frequently used in predicting drugs that could have multiple bioactivities. For example, Kawaii et al. used SVM classifiers to construct a query where drugs were set against hundreds of targets to establish different biological pathways targeting their bioactivities [58]. In another study, a similar process was used to determine the bioactivities for antihypertensive drugs. The information about the drug activity was obtained from the Market Driven Demand Response database, and a multi-label SVM was employed to produce the query that shows the bioanalysis of drugs [59,60]. Drugs were discovered to be dual inhibitors against both angiotensin-converting enzyme I and neutral endopeptidases.

## Section: 6. Limitations

ML algorithms have been an essential component of drug discovery. These methods increase efficiency and explore thousands of combinations that would have been impossible without this technology. As stated earlier, algorithms are trained with inputted data, but there are a few constraints with this technique. Although ML has been around for quite some time now, the biological pathways/targets being discovered are still novel. Information for the particular protein of interest might be limited, resulting in not much-extrapolated data. Free Energy Perturbation method is a platform where biological information regarding the protein is generated based on computational screening [61]. Data gathered from this method is utilized for training algorithms; however, not all the information is collected from a wet lab, rather computer-generated prediction is utilized. The accuracy of the training data might be lower than anticipated. Even though algorithms discussed in this review have a higher threshold for minimizing errors, there are still some categorical errors from training sets [61].

A more concise way to understand this is by the statistical angle. With algorithms prediction, there is always a concern with overfitting or underfitting. Overfitting is when the model consists of lower quality information/technique but generates higher quality performance. It occurs when the model picks up unusual features during the training, resulting in a negative impact on the model [17]. In contrast, underfitting models fail to recognize the data sets’ underlying trend and generalize the new data inputted [62]. Both underfitting and overfitting result in inaccurate results. There are several ways to tackle overfitting and underfitting, such as increasing the sample size and cross-validation. Cross validation is an often-used technique used to estimate the accuracy of the ML algorithms’ models, by using independent data sets to infer the models.

Another concern raised by chem-informaticians is ample chemical space constructed through algorithms [52,63]. The chemical area is a relative set of descriptors, consisting of thousands of compounds within a frame with boundaries generated by ML algorithms [64,65]. The challenge with chemical space is the clustering of compounds with high density, which often leads to avoidance of compounds with some essential properties and compounds. Studies regarding these issues are discussed later, models to augment chemical space coverage to highlight the molecules with properties different from others [19,66].

## Section: 7. Deep Learning (DL) Methods

DL algorithms are considered one of the cutting-edge areas of development and study in almost all scientific and technological fields. The renaissance of artificial NNs into workable algorithms from their former theorized and predicted applications, first developed in the 1950s, is an essential pillar of DL and the continued success brought by AI-based integration of standard techniques. DL algorithms give computational models the ability to learn a representation of multidimensional data through abstraction [67]. DL has allowed for resolving many challenges faced by standard ML algorithms, including image recognition and speech recognition. In the drug discovery process, DL techniques have become exemplar methods of drug activity prediction, target discovery, and lead molecule discovery [68,69,70]. The basis of DL is often implicated in NN systems, where they are used to create systems that have the capability to complete complex data recognition, interpretation, and generation. The main subsets of artificial NNs used in current drug discovery are deep neural networks (DNNs), recurrent neural networks (RNNs), and convolutional neural networks (CNNs).

The utilization of specific NNs from the variations that exist in the subset is dependent on multiple factors. DNNs, a specific type of feed forward neural networks, function with singular path data flow from the input layer through the hidden layer(s) reaching an output layer (Figure 3a). The outputs generated are typically identified using trained supervised learning algorithms. DL algorithms function through neural networks which can incorporate other ML techniques for training. Through supervised and reinforcement learning guided methods, a DNN can be trained to complete complex tasks. A generative DNN can create novel chemical compounds from existing libraries and training sets (Figure 3a); while, a predictive DNN can predict the chemical attributes of the novel compounds [71,72]. QSAR models are currently being used to find the correlation between these compounds’ chemical structure and activity. QSAR analysis is one of the most advanced forms of DL-based AI in current drug discovery and development. It has allowed researchers to take 2D chemical structures and determine physicochemical descriptors related to the molecule’s activity. 3D-QSAR has allowed further inquiry of geometric structure impacting ligand-target interactions [33,73,74]. QSAR has been actively used in the pharmaceutical industry to predict on/off-target activities of developed lead compounds on specific targets. These algorithmic approaches to discovery and development are not, by all means, full proof or thoroughly capable.

There are always some error sources and imprecision over the multiplicity of studies conducted using these AI algorithms. It has been found that NNs face a few deficiencies in comparison to other ML algorithms in their applications of QSAR studies. The first being the presence of excess descriptors that cause redundancy in NN and eventual clogging of outputs. This redundancy can significantly drop the efficiency of the NN, while also creating non-ideal outputs. Unknown descriptors also pose an issue because they may also affect the output generated. These issues have been alleviated using more specific feature selection algorithms to get a smaller number of higher quality descriptors; however, it will continue to be a problem faced by NN-based QSAR. The second issue with these NN-based assays is implementing ideal network parameters without overfitting [74]. Remedies to this issue have been proposed and implemented, but it persists to be a recurring issue without the necessary adjustments [75].

Once the initial work of target discovery is complete and better understanding is developed for target-molecule interaction, chemical synthesis and characterization become a priority in the pipeline. An important note in this process is using descriptive simplified molecular-input line-entry system (SMILES) nomenclature in much of the algorithms regarding de novo drug design and discovery. RNNs, which are a type of NN that utilize a system of self-learning through generational processing of the inputs and developing hidden layers. The subset RNN-type long short-term memory have become a reliable, standardized method for generating novel chemical structures. RNNs are unique in their ability to use neurons connected in the same hidden layer to form a functioning cycle of processing inputs and outputs compared to DNNs and feedforward neural networks (Figure 3b), which have no connections within the same layer and only push outputs. These generative RNNs have shown promising results in the generation of sensible, structurally correct, and feasible, novel SMILE structures that were not included in the original SMILE training sets [76,77,78,79]. A recent study by Segler et al. used generative RNN models to develop possible molecular structures that could have activity against Staphylococcus aureus (S. aureus) and Plasmodium falciparum (P. falciparum). Their models were given small sets of molecular structures that had known activity against these target organisms; from these inputs, the model generated 14% of the 6051 potential molecule candidates for S. aureus that has been developed by medicinal chemists. The model also generated 28% of the existing compounds developed for P. falciparum [80]. Traditionally, the generation and implementation of chemical synthesis routes have been the sole responsibility of chemists. However, this role is evolving to include more and more computational based synthesis, also known as computer-aided synthesis planning (CASP), with the emergence of AI [81,82,83]. The Monte Carlo tree search (MCTS) based through NN techniques have been used in current studies to generate CASP workflows. The MCTS technique is ideal for this purpose because of the simulation’s ability to perform random continuous step searches without branching until optimal conditions and solutions are met [82,83]. In a groundbreaking study conducted by Segler and Waller [84], an MCTS method using three NNs alongside 12.4 million transformation rules, retrieved through AI-based data mining, from all the available chemical synthesis literature at the time to generate a sensible workflow for CASP. The first NN, an expansion node, retrospectively searches for new transformations to create the molecule; it also predicts the feasibility of applying the transformation from the 12.4 million transformation rules. This allows the expansion node to select the best, as in most feasible and high yielding, transformations from the literature. The second NN, a rollout node, filters the inputs to include only the most frequently reported transformation rules to enable the best possibilities of successful transformations. The update node then incorporates the new pathway into the search tree. This algorithm was able to solve 80% of retrosynthesis problems in just 5 s, and >90% of problems in 60 s [82,83,84]. Various studies have been conducted to optimize AI-based chemical synthesis and reaction routes [85,86,87]. Through the further implementation of AI-based chemical synthesis and characterization, it will be possible to move drug discovery further from the bench to in silico and increase the time and cost-efficiency of discovery and development.

CNNs are a subset of DNNs that take inputs, assign weights to specific parts of the input, then build the ability to differentiate the data. While traditional DNNs are limited in their ability to function correctly on higher-dimensional datasets, CNNs serve as a gleaming solution to tackling this issue with their ability to preserve input dimensionality. The training required for a CNN model is significantly less than DNNs, and RNNs would need to function with reasonable accuracy and efficacy. These advantages have allowed it to become a prominent learning algorithm for image recognition, surpassing other standard ML algorithms. In the process of drug discovery, CNNs have become efficient tools used in target discovery, lead discovery and characterization, in silico target-lead interaction screening, and protein-ligand scoring [68,88,89,90]. Combinations of these DL techniques, such as CNNs, have also been very successful in identifying gene mutations and disease targets [91,92]. The incorporation of CNNs into drug development is not merely limited to target discovery; it has also been widely used in later-stage development. One such use of CNNs in this manner to assist in the generation of motility models of cancer cells responding to treatment [93]. In a recent study, Feng, Zhang, and Shi demonstrated the use of deep learning based drug-drug interaction (DDI) predictors [94], with the aim to address a wet lab issue during the drug discovery, which is often costly and time consuming. The researchers developed a new method utilizing graph convolutional networks and DNN models. In their design, the graph convolutional network served as a structure feature extractor from drugs found in DDI, learning low-dimensional representations (vectors) of the features from the DDI networks. The information is then taken to the DDN model which served as the actual predictor; the ability of the model to take the feature vectors and link them with corresponding feature vectors of possible drug combinations allowed it to produce the interaction prediction. Encouragingly, the predictions using their method outclassed popularly used state-of-the-art-methods [94].

## Section: 8. Examples of Drug Discovery (Paper Summaries and Relevance to Topic)

ML is already being used to develop novel molecules that could be used as future antibiotic candidates. In a recent, groundbreaking study conducted by Stokes et al., the researchers demonstrated the utility and capability of ML techniques in the drug discovery process [95]. They specifically capitalized on the use of DNNs to create novel molecules with broad-spectrum antibacterial activity. These discovered candidates were also identified to be structurally distinct from any known antibiotics. The researchers utilized a training set of 2335 molecules for a DNN model to predict the growth inhibition of Escherichia coli, followed by the running of the model on greater than 107 million molecules from several chemical libraries. This gave the researchers the ability to identify potential lead compound candidates that may have similar bioactivity. Through scoring generated by the model, the researchers were able to identify a list of sensible candidates that meet a predetermined score threshold and various other eliminative criteria. The researchers’ efforts proved fruitful, and they were able to identify a c-Jun N-terminal kinase inhibitor, halicin, that is distinct from known antibiotics. This antibacterial candidate was also discovered to be a potent growth inhibitor of Escherichia coli, and had shown efficacy against Clostridioides difficile and Acinetobacter baumannii infections in murine models [95]. In a study conducted by Fields et al., ML algorithms, including NNs-based techniques and SVM models, were used to discover novel antimicrobial peptides, also known as bacteriocins, from bacteria could ultimately be used as compelling antibiotic candidates [96]. Discoveries such as that of the bacteriocins are the outcomes of the machine-learning algorithm’s ability to build and function as complex processing systems. In the study, a positive and negative training set of 346 bacteriocins was used to train the algorithm. These input bacteriocins were represented as complicated vector sums. The machine-learning algorithm then took the inputs and generated new vector structure outputs that preserved the original inputs’ key features. These outputs were translated into 676 bacteriocins that were not identical to the input bacteriocins. From the output bacteriocins, 28,895 peptides were generated using a sliding window algorithm; these peptides spanned 20-mers and were placed through biophysical parameters. Fields et al. then selected 16 of the highest affinity peptides from the biophysical filtration for in vitro testing. Their finding indicated that the peptides had significant antimicrobial activity against Escherichia coli and Pseudomonas aeruginosa [96].

The utility of ML-based mining has proved to be extremely advantageous with the advent of high throughput data generation and collection. These algorithms have been extensively used alongside the vast data generated utilizing high-throughput sequencing to enhance the target discovery process [15,97]. The innovation of algorithm-assisted data collection and manipulation has already been implemented in emerging research; recently, it has been used to find novel molecular therapeutic targets for aggressive melanoma. Researchers were able to use unsupervised learning techniques through GeneCluster to identify groups of cell lines, one was a primary melanoma group, and the other was an aggressive melanoma group. Through further analysis using supervised learning techniques, the researchers were able to identify invasion-specific genes related to aggressive melanoma [98]. One of the many challenges with cancer treatments is detecting response profiles designed primarily for individual patients. Sakellaropoulos et al. built a network-based framework. They trained a database containing 1001 cancer cell lines, from the Genomics of Drug Sensitivity in Cancer, using DNN to predict drug responses based on gene expressions. The results were evaluated in several clinical cohorts. DNNs are observed to outperform several others in silico screening due to their capability to embrace biological interactions and create models that can capture the biological complexities and accurately predict clinical response with the help of cancer cell baselines. Their model incorporated RF and elastic net (Enet) algorithms to evaluate the DNN model’s results. This framework was only tested on five patients; thus, not much coverage was obtained through this model; therefore, they expanded their study to a more massive sample size. They utilized response data for two drugs: Cisplatin and paclitaxel, and analyzed it with gene expression profiles and patients’ responses to those two drugs gathered from different clinical trials. The study was done on a small scale, implementing DL network training sets and ML algorithms, with a limited amount of knowledge. It is believed that ML could essentially be a powerful tool to assist within the medicinal field, as more data and information are retrieved on patient response profiles [99].

The diseases discussed have been around for a long time, but the emergent need for a treatment for Coronavirus disease 2019 (COVID-19) has stirred up the research world. The pandemic outbreak has caused detrimental effects around the world, but the COVID-19 virus (SARS-CoV-2) is a novel strain of the same species of virus causing the 2003 Severe acute respiratory syndrome (SARS-CoV-1); thus, several studies are incorporating earlier information into supervised ML to quickly find a remedy for this virus [100]. Researchers worldwide are exhausting all available resources, and ML has helped narrow down the drug candidates and minimize clinical trial failure. Kowalewski and Ray developed ML models to help identify effective drugs against 65 human proteins (target) studied to interact with SARS-CoV-2 proteins. As the virus is known to target the respiratory tract, including nasal epithelial cells and upper airway and lungs, they deduce it from inhaling therapeutics to directly target the damaged cells. They assembled 14 million chemicals from ZINC databases and utilized ML models to predict vapor pressure and mammalian toxicity to rank the chemicals and find drugs that share the same chemical space. Their main goal was to establish a short term and long-term pipeline for future purposes. They utilized SVM and RF to create models that could predict drugs and their efficacy. Although most of the researchers focus on a single protein responsible for replication and host entry, it might only allow short term repair. In the long term, Kowalewski and Ray proposed to look into multiple drugs that could potentially target various proteins with diverse biological pathways [101].

## Section: 9. Conclusions

ML-based techniques seek to revitalize the development of drugs. These methods are based on separate applications in target discovery, lead compound discovery, synthesis, protein-ligand interactions, etc. ML applications are paving the way for algorithm-enhanced data query, analysis, and generation. One such example is ML incorporated into target discovery, based heavily on the refinement and search of existing omics and medical data. Through AI integration using ML techniques, viable targets can be found using data clustering, regression, and classification from vast omics databases and sources. Lead compound discovery, e.g., using QSAR, is currently frequently used to develop sensible molecular candidates based on training inputs. Lead compound synthesis has also been expedited with NN-based retrosynthesis algorithms alongside best-chance trees with the input of vast amounts of accumulated data and rules to develop algorithms that can generate synthesis pathways with greater than 90% accuracy in 60 s. Applications of ML in the processes of drug development have been used for some time now. These applications have proven to be steps above previous methods; the development of ML and DL techniques are not all brand new. They have been carefully crafted and developed through decades of research. This curation of function and utility to ML algorithms and techniques has allowed for the continued success and development in drug discovery. Owing to more precise algorithms, more powerful supercomputers, and substantial private and public investment into the field, these applications are becoming more intelligent, cost-effective, and time-efficient while boosting efficacy.


---

# Precompetitive Consensus Building to Facilitate the Use of Digital Health Technologies to Support Parkinson Disease Drug Development through Regulatory Science

- **Authors:** Diane Stephenson, Robert Alexander, Varun Aggarwal, Reham Badawy, Lisa Bain, Roopal Bhatnagar, Bastiaan R Bloem, Babak Boroojerdi, Jackson Burton, Jesse M Cedarbaum, Josh Cosman, David T Dexter, Marissa Dockendorf, E Ray Dorsey, Ariel V Dowling, Luc J W Evers, Katherine Fisher, Mark Frasier, Luis Garcia-Gancedo, Jennifer C Goldsack, Derek Hill, Janice Hitchcock, Michele T Hu, Michael P Lawton, Susan J Lee, Michael Lindemann, Ken Marek, Nitin Mehrotra, Marjan J Meinders, Michael Minchik, Lauren Oliva, Klaus Romero, George Roussos, Robert Rubens, Sakshi Sadar, Joseph Scheeren, Eiichi Sengoku, Tanya Simuni, Glenn Stebbins, Kirsten I Taylor, Beatrice Yang, Neta Zach
- **Issuer:** Digital biomarkers
- **Type:** Scientific article
- **Published:** 2020-11-26
- **Language:** en
- **DOI:** 10.1159/000512500
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33442579/
- **Licence:** CC-BY-NC

## Section: Abstract

Innovative tools are urgently needed to accelerate the evaluation and subsequent approval of novel treatments that may slow, halt, or reverse the relentless progression of Parkinson disease (PD). Therapies that intervene early in the disease continuum are a priority for the many candidates in the drug development pipeline. There is a paucity of sensitive and objective, yet clinically interpretable, measures that can capture meaningful aspects of the disease. This poses a major challenge for the development of new therapies and is compounded by the considerable heterogeneity in clinical manifestations across patients and the fluctuating nature of many signs and symptoms of PD. Digital health technologies (DHT), such as smartphone applications, wearable sensors, and digital diaries, have the potential to address many of these gaps by enabling the objective, remote, and frequent measurement of PD signs and symptoms in natural living environments. The current climate of the COVID-19 pandemic creates a heightened sense of urgency for effective implementation of such strategies. In order for these technologies to be adopted in drug development studies, a regulatory-aligned consensus on best practices in implementing appropriate technologies, including the collection, processing, and interpretation of digital sensor data, is required. A growing number of collaborative initiatives are being launched to identify effective ways to advance the use of DHT in PD clinical trials. The Critical Path for Parkinson's Consortium of the Critical Path Institute is highlighted as a case example where stakeholders collectively engaged regulatory agencies on the effective use of DHT in PD clinical trials. Global regulatory agencies, including the US Food and Drug Administration and the European Medicines Agency, are encouraging the efficiencies of data-driven engagements through multistakeholder consortia. To this end, we review how the advancement of DHT can be most effectively achieved by aligning knowledge, expertise, and data sharing in ways that maximize efficiencies.


---

# Reporting guidelines for clinical trial reports for interventions involving artificial intelligence: the CONSORT-AI extension

- **Authors:** Xiaoxuan Liu, Samantha Cruz Rivera, David Moher, Melanie J Calvert, Alastair K Denniston, SPIRIT-AI and CONSORT-AI Working Group
- **Issuer:** Nature medicine
- **Type:** Scientific article
- **Published:** 2020-09-09
- **Language:** en
- **DOI:** 10.1038/s41591-020-1034-x
- **Source:** https://pubmed.ncbi.nlm.nih.gov/32908283/
- **Licence:** CC-BY

## Section: Abstract

The CONSORT 2010 statement provides minimum guidelines for reporting randomized trials. Its widespread use has been instrumental in ensuring transparency in the evaluation of new interventions. More recently, there has been a growing recognition that interventions involving artificial intelligence (AI) need to undergo rigorous, prospective evaluation to demonstrate impact on health outcomes. The CONSORT-AI (Consolidated Standards of Reporting Trials–Artificial Intelligence) extension is a new reporting guideline for clinical trials evaluating interventions with an AI component. It was developed in parallel with its companion statement for clinical trial protocols: SPIRIT-AI (Standard Protocol Items: Recommendations for Interventional Trials–Artificial Intelligence). Both guidelines were developed through a staged consensus process involving literature review and expert consultation to generate 29 candidate items, which were assessed by an international multi-stakeholder group in a two-stage Delphi survey (103 stakeholders), agreed upon in a two-day consensus meeting (31 stakeholders) and refined through a checklist pilot (34 participants). The CONSORT-AI extension includes 14 new items that were considered sufficiently important for AI interventions that they should be routinely reported in addition to the core CONSORT 2010 items. CONSORT-AI recommends that investigators provide clear descriptions of the AI intervention, including instructions and skills required for use, the setting in which the AI intervention is integrated, the handling of inputs and outputs of the AI intervention, the human–AI interaction and provision of an analysis of error cases. CONSORT-AI will help promote transparency and completeness in reporting clinical trials for AI interventions. It will assist editors and peer reviewers, as well as the general readership, to understand, interpret and critically appraise the quality of clinical trial design and risk of bias in the reported outcomes.

## Section: Main

Randomized controlled trials (RCTs) are considered the gold-standard experimental design for providing evidence of the safety and efficacy of an intervention1,2. Trial results, if adequately reported, have the potential to inform regulatory decisions, clinical guidelines and health policy. It is therefore crucial that RCTs are reported with transparency and completeness so that readers can critically appraise the trial methods and findings and assess the presence of bias in the results3–5.

The CONSORT statement provides evidence-based recommendations to improve the completeness of the reporting of RCTs. The statement was first introduced in 1996 and has since been widely endorsed by medical journals internationally5. Over the past two decades, it has undergone two updates and has demonstrated a substantial positive impact on the quality of RCT reports6,7. The most recent CONSORT 2010 statement provides a 25-item checklist of the minimum reporting content applicable to all RCTs, but it recognizes that certain interventions may require extension or elaboration of these items. Several such extensions exist8–13.

AI is an area of enormous interest with strong drivers to accelerate new interventions through to publication, implementation and market14. While AI systems have been researched for some time, recent advances in deep learning and neural networks have gained considerable interest for their potential in health applications. Examples of such applications are wide ranging and include AI systems for screening and triage15,16, diagnosis17–20,prognostication21,22, decision support23 and treatment recommendation24. However, in the most recent cases, published evidence has consisted of in silico, early-phase validation. It has been recognized that most recent AI studies are inadequately reported and existing reporting guidelines do not fully cover potential sources of bias specific to AI systems25. The welcome emergence of RCTs seeking to evaluate newer interventions based on, or including, an AI component (called ‘AI interventions’ here)23,26–31 has similarly been met with concerns about the design and reporting25,32–34. This has highlighted the need to provide reporting guidance that is ‘fit for purpose’ in this domain.

CONSORT-AI (as part of the SPIRIT-AI and CONSORT-AI initiative) is an international initiative supported by CONSORT and the EQUATOR (Enhancing the Quality and Transparency of Health Research) Network to evaluate the existing CONSORT 2010 statement and to extend or elaborate this guidance where necessary, to support the reporting of clinical trials for AI interventions35,36. It is complementary to the SPIRIT-AI statement, which aims to promote high-quality protocol reporting for AI trials. This Consensus Statement describes the methods used to identify and evaluate candidate items and gain consensus. In addition, it also provides the CONSORT-AI checklist, which includes the new extension items and their accompanying explanations.

## Section: Methods

The SPIRIT-AI and CONSORT-AI extensions were simultaneously developed for clinical trial protocols and trial reports. An announcement for the SPIRIT-AI and CONSORT-AI initiative was published in October 2019 (ref. 35), and the two guidelines were registered as reporting guidelines under development on the EQUATOR library of reporting guidelines in May 2019. Both guidelines were developed in accordance with the EQUATOR Network’s methodological framework37. The SPIRIT-AI and CONSORT-AI Steering Group, consisting of 15 international experts, was formed to oversee the conduct and methodology of the study. Definitions of key terms are provided in the glossary (Box 1).

## Section: Ethical approval

This study was approved by the ethical review committee at the University of Birmingham, UK (ERN_19-1100). Participant information was provided to Delphi participants electronically before survey completion and before the consensus meeting. Delphi participants provided electronic informed consent, and written consent was obtained from consensus meeting participants.

## Section: Literature review and candidate item generation

An initial list of candidate items for the SPIRIT-AI and CONSORT-AI checklists was generated through review of the published literature and consultation with the Steering Group and known international experts. A search was performed on 13 May 2019 using the terms ‘artificial intelligence’, ‘machine learning’ and ‘deep learning’ to identify existing clinical trials for AI interventions listed within the US National Library of Medicine’s clinical trial registry (ClinicalTrials.gov). There were 316 registered trials, of which 62 were completed and 7 had published results30,38–43. Two studies were reported with reference to the CONSORT statement30,42, and one study provided an unpublished trial protocol42. The Operations Team (X.L., S.C.R., M.J.C. and A.K.D.) identified AI-specific considerations from these studies and reframed them as candidate reporting items. The candidate items were also informed by findings from a previous systematic review that evaluated the diagnostic accuracy of deep-learning systems for medical imaging25. After consultation with the Steering Group and additional international experts (n = 19), 29 candidate items were generated, 26 of which were relevant for both SPIRIT-AI and CONSORT-AI and 3 of which were relevant only for CONSORT-AI. The Operations Team mapped these items to the corresponding SPIRIT and CONSORT items, revising the wording and providing explanatory text as required to contextualize the items. These items were included in subsequent Delphi surveys.

## Section: Delphi consensus process

In September 2019, 169 key international experts were invited to participate in the online Delphi survey to vote upon the candidate items and suggest additional items. Experts were identified and contacted via the Steering Group and were allowed one round of ‘snowball’ recruitment in which contacted experts could suggest additional experts. In addition, individuals who made contact following publication of the announcement were included35. The Steering Group agreed that individuals with expertise in clinical trials and AI and machine learning (ML), as well as key users of the technology, should be well represented in the consultation. Stakeholders included healthcare professionals, methodologists, statisticians, computer scientists, industry representatives, journal editors, policy makers, health ‘informaticists’, experts in law and ethics, regulators, patients and funders. Participant characteristics are described in Supplementary Table 1. Two online Delphi surveys were conducted. DelphiManager software (version 4.0), developed and maintained by the COMET (Core Outcome Measures in Effectiveness Trials) initiative, was used to undertake the e-Delphi survey. Participants were given written information about the study and were asked to provide their level of expertise within the fields of (i) AI/ML, and (ii) clinical trials. Each item was presented for consideration (26 for SPIRIT-AI and 29 for CONSORT-AI). Participants were asked to vote on each item using a 9-point scale, as follows: 1–3, not important; 4–6, important but not critical; and 7–9, important and critical. Respondents provided separate ratings for SPIRIT-AI and CONSORT-AI. There was an option to opt out of voting for each item, and each item included space for free text comments. At the end of the Delphi survey, participants had the opportunity to suggest new items. 103 responses were received for the first Delphi round, and 91 responses (88% of participants from round one) were received for the second round. The results of the Delphi survey informed the subsequent international consensus meeting. 12 new items were proposed by the Delphi study participants and were added for discussion at the consensus meeting. Data collected during the Delphi survey were anonymized, and item-level results were presented at the consensus meeting for discussion and voting.

The two-day consensus meeting took place in January 2020 and was hosted by the University of Birmingham, UK, to seek consensus on the content of SPIRIT-AI and CONSORT-AI. 31 international stakeholders from among the Delphi survey participants were invited to discuss the items and vote on their inclusion. Participants were selected to achieve adequate representation from all the stakeholder groups. 41 items were discussed in turn, comprising the 29 items generated in the initial literature review and item-generation phase (26 items relevant to both SPIRIT-AI and CONSORT-AI; 3 items relevant only to CONSORT-AI) and the 12 new items proposed by participants during the Delphi surveys. Each item was presented to the consensus group, alongside its score from the Delphi exercise (median and interquartile ranges) and any comments made by Delphi participants related to that item. Consensus-meeting participants were invited to comment on the importance of each item and whether the item should be included in the AI extension. In addition, participants were invited to comment on the wording of the explanatory text accompanying each item and the position of each item relative to the SPIRIT 2013 and CONSORT 2010 checklists. After open discussion of each item and the option to adjust wording, an electronic vote took place, with the option to include or exclude the item. An 80% threshold for inclusion was pre-specified and deemed reasonable by the Steering Group to demonstrate majority consensus. Each stakeholder voted anonymously using Turning Point voting pads (Turning Technologies, version 8.7.2.14).

## Section: Checklist pilot

Following the consensus meeting, attendees were given the opportunity to make final comments on the wording and agree that the updated SPIRIT-AI and CONSORT-AI items reflected discussions from the meeting. The Operations Team assigned each item as an extension or elaboration item on the basis of a decision tree and produced a penultimate draft of the SPIRIT-AI and CONSORT-AI checklists (Supplementary Fig. 1). A pilot of the penultimate checklists was conducted with 34 participants to ensure clarity of wording. Experts participating in the pilot included the following: (a) Delphi participants who did not attend the consensus meeting, and (b) external experts who had not taken part in the development process but who had reached out to the Steering Group after the Delphi study commenced. Final changes were made on wording only to improve clarity for readers, by the Operations Team (Supplementary Fig. 2).

## Section: Recommendations

CONSORT-AI checklist

## Section: Recommendations › CONSORT-AI checklist items and explanation

The CONSORT-AI extension recommends that 14 new checklists items be added to the existing CONSORT 2010 statement (11 extensions and 3 elaborations). These items were considered sufficiently important for clinical-trial reports for AI interventions that they should be routinely reported in addition to the core CONSORT 2010 checklist items. Table 1 lists the CONSORT-AI items.Table 1CONSORT-AI checklistSectionCONSORT 2010 itemaCONSORT-AI itemAddressed on page numberbTitle and abstractTitle and Abstract1aIdentification as a randomized trial in the titleCONSORT-AI 1a,b Elaboration(i) Indicate that the intervention involves artificial intelligence/machine learning in the title and/or abstract and specify the type of model.1bStructured summary of trial design, methods, results, and conclusions (for specific guidance see CONSORT for abstracts)(ii) State the intended use of the AI intervention within the trial in the title and/or abstract.IntroductionBackground and objectives2aScientific background and explanation of rationaleCONSORT-AI 2a (i) ExtensionExplain the intended use of the AI intervention in the context of the clinical pathway, including its purpose and its intended users (for example, healthcare professionals, patients, public).2bSpecific objectives or hypothesesMethodsTrial design3aDescription of trial design (such as parallel, factorial) including allocation ratio3bImportant changes to methods after trial commencement (such as eligibility criteria), with reasonsParticipants4aEligibility criteria for participantsCONSORT-AI 4a (i) ElaborationState the inclusion and exclusion criteria at the level of participants.CONSORT-AI 4a (ii) ExtensionState the inclusion and exclusion criteria at the level of the input data.4bSettings and locations where the data were collectedCONSORT-AI 4b ExtensionDescribe how the AI intervention was integrated into the trial setting, including any onsite or offsite requirements.Interventions5The interventions for each group with sufficient details to allow replication, including how and when they were actually administeredCONSORT-AI 5 (i) ExtensionState which version of the AI algorithm was used.CONSORT-AI 5 (ii) ExtensionDescribe how the input data were acquired and selected for the AI intervention.CONSORT-AI 5 (iii) ExtensionDescribe how poor quality or unavailable input data were assessed and handled.CONSORT-AI 5 (iv) ExtensionSpecify whether there was human–AI interaction in the handling of the input data, and what level of expertise was required of users.CONSORT-AI 5 (v) ExtensionSpecify the output of the AI interventionCONSORT-AI 5 (vi) ExtensionExplain how the AI intervention’s outputs contributed to decision-making or other elements of clinical practice.Outcomes6aCompletely defined pre-specified primary and secondary outcome measures, including how and when they were assessed6bAny changes to trial outcomes after the trial commenced, with reasonsSample size7aHow sample size was determined7bWhen applicable, explanation of any interim analyses and stopping guidelinesRandomizationSequence generation8aMethod used to generate the random allocation sequence8bType of randomization; details of any restriction (such as blocking and block size)Allocation concealment mechanism9Mechanism used to implement the random allocation sequence (such as sequentially numbered containers), describing any steps taken to conceal the sequence until interventions were assignedImplementation10Who generated the random allocation sequence, who enrolled participants, and who assigned participants to interventionsBlinding11aIf done, who was blinded after assignment to interventions (for example, participants, care providers, those assessing outcomes) and how11bIf relevant, description of the similarity of interventionsStatistical methods12aStatistical methods used to compare groups for primary and secondary outcomes12bMethods for additional analyses, such as subgroup analyses and adjusted analysesResultsParticipant flow (a diagram is strongly recommended)13aFor each group, the numbers of participants who were randomly assigned, received intended treatment, and were analyzed for the primary outcome13bFor each group, losses and exclusions after randomization, together with reasonsRecruitment14aDates defining the periods of recruitment and follow-up14bWhy the trial ended or was stoppedBaseline data15A table showing baseline demographic and clinical characteristics for each groupNumbers analyzed16For each group, number of participants (denominator) included in each analysis and whether the analysis was by original assigned groupsOutcomes and estimation17aFor each primary and secondary outcome, results for each group, and the estimated effect size and its precision (such as 95% confidence interval)17bFor binary outcomes, presentation of both absolute and relative effect sizes is recommendedAncillary analyses18Results of any other analyses performed, including subgroup analyses and adjusted analyses, distinguishing pre-specified from exploratoryHarms19All important harms or unintended effects in each group (for specific guidance see CONSORT for harms)CONSORT-AI 19 ExtensionDescribe results of any analysis of performance errors and how errors were identified, where applicable. If no such analysis was planned or done, justify why not.DiscussionLimitations20Trial limitations, addressing sources of potential bias, imprecision, and, if relevant, multiplicity of analysesGeneralizability21Generalizability (external validity, applicability) of the trial findingsInterpretation22Interpretation consistent with results, balancing benefits and harms, and considering other relevant evidenceOther InformationRegistration23Registration number and name of trial registryProtocol24Where the full trial protocol can be accessed, if availableFunding25Sources of funding and other support (such as supply of drugs), role of fundersCONSORT-AI 25 ExtensionState whether and how the AI intervention and/or its code can be accessed, including any restrictions to access or re-use.aWe strongly recommend reading this statement in conjunction with the CONSORT 2010 Explanation and Elaboration for important clarifications on all the items. bIndicates page numbers to be completed by authors during protocol development.

The 14 items below passed the threshold of 80% for inclusion at the consensus meeting. CONSORT-AI 2a, CONSORT-AI 5 (ii) and CONSORT-AI 19 each resulted from the merging of two items after discussion with the consensus group. CONSORT-AI 4a (i) and (ii) was split into two items for clarity and was voted upon separately. CONSORT-AI 5(iii) did not fulfill the criteria for inclusion on the basis of its initial wording (77% vote to include); however, after extensive discussion and rewording, the consensus group unanimously supported a re-vote, at which point it passed the inclusion threshold (97% to include). The Delphi and voting results for each included and excluded item are described in Supplementary Table 2.

CONSORT-AI checklist

## Section: Title and abstract › CONSORT-AI 1a,b (i) Elaboration: Indicate that the intervention involves artificial intelligence/machine learning in the title and/or abstract and specify the type of model › Explanation

Indicating in the title and/or abstract of the trial report that the intervention involves a form of AI is encouraged, as it immediately identifies the intervention as an AI/ML intervention and also serves to facilitate indexing and searching of the trial report. The title should be understandable by a wide audience; therefore, a broader umbrella term such as ‘artificial intelligence’ or ‘machine learning’ is encouraged. More-precise terms should be used in the abstract, rather than the title, unless they are broadly recognized as being a form of AI/ML. Specific terminology relating to the model type and architecture should be detailed in the abstract.

## Section: Title and abstract › CONSORT-AI 1a,b (ii) Elaboration: State the intended use of the AI intervention within the trial in the title and/or abstract › Explanation

Describe the intended use of the AI intervention in the trial report title and/or abstract. This should describe the purpose of the AI intervention and the disease context26,44. Some AI interventions may have multiple intended uses, or the intended use may evolve over time. Therefore, documenting this allows readers to understand the intended use of the algorithm at the time of the trial.

## Section: Introduction › CONSORT-AI 2a (i) Extension: Explain the intended use for the AI intervention in the context of the clinical pathway, including its purpose and its intended users (for example, healthcare professionals, patients, public) › Explanation

In order to clarify how the AI intervention is intended to fit into a clinical pathway, a detailed description of its role should be included in the background of the trial report. AI interventions may be designed to interact with different users, including healthcare professionals, patients and the public, and their roles can be wide-ranging (for example, the same AI intervention could theoretically be replacing, augmenting or adjudicating components of clinical decision-making). Clarifying the intended use of the AI intervention and its intended user helps readers understand the purpose for which the AI intervention was evaluated in the trial.

## Section: Methods

CONSORT-AI 4a (i): State the inclusion and exclusion criteria at the level of participants. CONSORT-AI 4a (ii): State the inclusion and exclusion criteria at the level of the input data. CONSORT 13b (core CONSORT item): For each group, losses and exclusions after randomization, together with reasons.

## Section: Methods › CONSORT-AI 4a (i) Elaboration: State the inclusion and exclusion criteria at the level of participants

CONSORT-AI 4a (i): State the inclusion and exclusion criteria at the level of participants. CONSORT-AI 4a (ii): State the inclusion and exclusion criteria at the level of the input data. CONSORT 13b (core CONSORT item): For each group, losses and exclusions after randomization, together with reasons.

## Section: Methods › CONSORT-AI 4a (i) Elaboration: State the inclusion and exclusion criteria at the level of participants › Explanation

The inclusion and exclusion criteria should be defined at the participant level as per usual practice in non-AI interventional trial reports (Fig. 1). This is distinct from the inclusion and exclusion criteria made at the input-data level, which is addressed in item 4a (ii).Fig. 1CONSORT 2010 flow diagram — adapted for AI clinical trials.CONSORT-AI 4a (i): State the inclusion and exclusion criteria at the level of participants. CONSORT-AI 4a (ii): State the inclusion and exclusion criteria at the level of the input data. CONSORT 13b (core CONSORT item): For each group, losses and exclusions after randomization, together with reasons.

CONSORT-AI 4a (i): State the inclusion and exclusion criteria at the level of participants. CONSORT-AI 4a (ii): State the inclusion and exclusion criteria at the level of the input data. CONSORT 13b (core CONSORT item): For each group, losses and exclusions after randomization, together with reasons.

## Section: Methods › CONSORT-AI 4a (ii) Extension: State the inclusion and exclusion criteria at the level of the input data › Explanation

‘Input data’ refers to the data required by the AI intervention to serve its purpose (for example, for a breast-cancer diagnostic system, the input data could be the unprocessed or vendor-specific post-processing mammography scan upon which a diagnosis is being made; for an early-warning system, the input data could be physiological measurements or laboratory results from the electronic health record). The trial report should pre-specify if there were minimum requirements for the input data (such as image resolution, quality metrics or data format) that determined pre-randomization eligibility. It should specify when, how and by whom this was assessed. For example, if a participant met the eligibility criteria for lying flat for a CT scan as per item 4a (i), but the scan quality was compromised (for any given reason) to such a level that it was deemed unfit for use by the AI system, this should be reported as an exclusion criterion at the input-data level. Note that where input data are acquired after randomization, any exclusion is considered to be from the analysis, not from enrollment (CONSORT item 13b and Fig. 1).

## Section: Methods › CONSORT-AI 4b Extension: Describe how the AI intervention was integrated into the trial setting, including any onsite or offsite requirements › Explanation

There are limitations to the generalizability of AI algorithms, one of which is when they are used outside of their development environment45,46. AI systems are dependent on their operational environment, and the report should provide details of the hardware and software requirements to allow technical integration of the AI intervention at each study site. For example, it should be stated if the AI intervention required vendor-specific devices, if there was specialized computing hardware at each site, or if the site had to support cloud integration, particularly if this was vendor specific. If any changes to the algorithm were required at each study site as part of the implementation procedure (such as fine-tuning the algorithm on local data), then this process should also be clearly described.

## Section: Methods › CONSORT-AI 5 (i) Extension: State which version of the AI algorithm was used › Explanation

Similar to other forms of software as a medical device, AI systems are likely to undergo multiple iterations and updates during their lifespan. It is therefore important to specify which version of the AI system was used in the clinical trial, whether this is the same as the version evaluated in previous studies that have been used to justify the study rationale, and whether the version changed during the conduct of the trial. If applicable, the report should describe what has changed between the relevant versions and the rationales for the changes. Where available, the report should include a regulatory marking reference, such as an unique device identifier, that requires a new identifier for updated versions of the device47.

## Section: Methods › CONSORT-AI 5 (ii) Extension: Describe how the input data were acquired and selected for the AI intervention › Explanation

The measured performance of any AI system may be critically dependent on the nature and quality of the input data48. A description of the input-data handling, including acquisition, selection and pre-processing before analysis by the AI system, should be provided. Completeness and transparency of this description is integral to the replicability of the intervention beyond the clinical trial in real-world settings. It also helps readers identify whether input-data-handling procedures were standardized across trial sites.

## Section: Methods › CONSORT-AI 5 (iii) Extension: Describe how poor-quality or unavailable input data were assessed and handled › Explanation

As with CONSORT-AI 4a (ii), ‘input data’ refers to the data required by the AI intervention to serve its purpose. As discussed in item 4a (ii), the performance of AI systems may be compromised as a result of poor quality or missing input data49 (for example, excessive movement artifact on an electrocardiogram). The trial report should report the amount of missing data, as well as how this was identified and handled. The report should also specify if there was a minimum standard required for the input data and, where this standard was not achieved, how this was handled (including the impact on, or any changes to, the participant care pathway).

Poor quality or unavailable data can also affect non-AI interventions. For example, sub-optimal quality of a scan could affect a radiologist’s ability to interpret it and make a diagnosis. It is therefore important that this information is reported equally in the control intervention, where relevant. If this minimum quality standard was different from the inclusion criteria for input data used to assess eligibility pre-randomization, this should be stated.

## Section: Methods › CONSORT-AI 5 (iv) Extension: Specify whether there was human–AI interaction in the handling of the input data, and what level of expertise was required of users › Explanation

A description of the human–AI interface and the requirements for successful interaction when input data are handled should be provided — for example, clinician-led selection of regions of interest from a histology slide that is then interpreted by an AI diagnostic system50, or an endoscopist’s selection of a colonoscopy video clips as input data for an algorithm designed to detect polyps28. A description of any user training provided and instructions for how users should handle the input data provides transparency and replicability of trial procedures. Poor clarity on the human–AI interface may lead to lack of a standard approach and may carry ethical implications, particularly in the event of harm51,52. For example, it may become unclear whether an error case occurred due to human deviation from the instructed procedure, or if it was an error made by the AI system.

## Section: Methods › CONSORT-AI 5 (v) Extension: Specify the output of the AI intervention › Explanation

The output of the AI intervention should be clearly specified in the trial report. For example, an AI system may output a diagnostic classification or probability, a recommended action, an alarm alerting to an event, an instigated action in a closed-loop system (such as titration of drug infusions) or another output. The nature of the AI intervention’s output has direct implications on its usability and how it may lead to downstream actions and outcomes.

## Section: Methods › CONSORT-AI 5 (vi) Extension: Explain how the AI intervention’s outputs contributed to decision-making or other elements of clinical practice › Explanation

Since health outcomes may also critically depend on how humans interact with the AI intervention, the report should explain how the outputs of the AI system were used to contribute to decision-making or other elements of clinical practice. This should include adequate description of downstream interventions that can affect outcomes. As with CONSORT-AI 5 (iv), any effects of human–AI interaction on the outputs should be described in detail, including the level of expertise required to understand the outputs and any training and/or instructions provided for this purpose. For example, a skin cancer detection system that produced a percentage likelihood as its output should be accompanied by an explanation of how this output was interpreted and acted upon by the user, specifying both the intended pathways (for example, skin lesion excision if the diagnosis is positive) and the thresholds for entry to these pathways (for example, skin lesion excision if the diagnosis is positive and the probability is >80%). The information produced by comparator interventions should be similarly described, alongside an explanation of how such information was used to arrive at clinical decisions on patient management, where relevant. Any discrepancy in how decision-making occurred versus how it was intended to occur (that is, as specified in the trial protocol) should be reported.

## Section: Results › CONSORT-AI 19 Extension: Describe results of any analysis of performance errors and how errors were identified, where applicable. If no such analysis was planned or done, explain why not › Explanation

Reporting performance errors and failure case analysis is especially important for AI interventions. AI systems can make errors that may be hard to foresee but that, if allowed to be deployed at scale, could have catastrophic consequences53. Therefore, reporting cases of error and defining risk-mitigation strategies are important for informing when, and for which populations, the intervention can be safely implemented. The results of any performance-error analysis should be reported and the implications of the results should be discussed.

## Section: Other information › CONSORT-AI 25 Extension: State whether and how the AI intervention and/or its code can be accessed, including any restrictions to access or re-use › Explanation

The trial report should make it clear whether and how the AI intervention and/or its code can be accessed or re-used. This should include details about the license and any restrictions to access.

## Section: Discussion

CONSORT-AI is a new reporting-guideline extension developed through international multi-stakeholder consensus. It aims to promote transparent reporting of AI intervention trials and is intended to facilitate critical appraisal and evidence synthesis. The extension items added in CONSORT-AI address a number of issues specific to the implementation and evaluation of AI interventions, which should be considered alongside the core CONSORT 2010 checklist and other CONSORT extensions54. It is important to note that these are minimum requirements and there may be value in including additional items not included in the checklists in the report or in supplementary materials (Supplementary Table 2).

In both CONSORT-AI and its companion project SPIRIT-AI, a major emphasis was the addition of several new items related to the intervention itself and its application in the clinical context. Items 5 (i)–5 (vi) were added to address AI-specific considerations in descriptions of the intervention. Specific recommendations were made pertinent to AI systems related to algorithm version, input and output data, integration into trial settings, expertise of the users and protocol for acting upon the AI system’s recommendations. It was agreed that these details are critical for independent evaluation or replication of the trial. Journal editors reported that despite the importance of these items, they are currently often missing from trial reports at the time of submission for publication, which provides further weight for their inclusion as specifically listed extension items.

A recurrent focus of the Delphi comments and consensus group discussion was the safety of AI systems. This was in recognition that AI systems, unlike other health interventions, can unpredictably yield errors that are not easily detectable or explainable by human judgement. For example, changes to medical imaging that are invisible, or appear random, to the human eye may change the likelihood of the diagnostic output entirely55,56. The concern is that given the theoretical ease with which AI systems could be deployed at scale, any unintended harmful consequences could be catastrophic. CONSORT-AI item 19, which requires specification of any plans to analyze performance errors, was added to emphasize the importance of anticipating systematic errors made by the algorithm and their consequences. Beyond this, investigators should also be encouraged to explore differences in performance and error rates across population subgroups. It has been shown that AI systems may be systematically biased toward different outputs, which may lead to different or even unfair treatment, on the basis of extant features53,57–59.

The topic of ‘continuously evolving’ AI systems (also known as ‘continuously adapting’ or ‘continuously learning’ AI systems) was discussed at length during the consensus meeting, but it was agreed that this be excluded from CONSORT-AI. These are AI systems with the ability to continuously train on new data, which may cause changes in performance over time. The group noted that, while of interest, this field is relatively early in its development without tangible examples in healthcare applications, and that it would not be appropriate for it to be included in CONSORT-AI at this stage60. This topic will be monitored and will be revisited in future iterations of CONSORT-AI. It is worth noting that incremental software changes, whether continuous or iterative, intentional or unintentional, could have serious consequences on safety performance after deployment. It is therefore of vital importance that such changes be documented and identified by software version and that a robust post-deployment surveillance plan is in place.

This study is set in the current context of AI in health; therefore, several limitations should be noted. First, there are relatively few published interventional trials in the field of AI for healthcare; therefore, the discussions and decisions made during this study were not always supported by existing examples of completed trials. This arises from our stated aim of addressing the issues of poor reporting in this field as early as possible, recognizing the strong drivers in the field and the specific challenges of study design and reporting for AI. As the science and study of AI evolves, we welcome collaboration with investigators to co-evolve these reporting standards to ensure their continued relevance. Second, the literature search of AI RCTs used terminology such as ‘artificial intelligence’, ‘machine learning’ and ‘deep learning’, but not terms such as ‘clinical decision support systems’ or ‘expert systems’, which were more commonly used in the 1990s for technologies underpinned by AI systems and share risks similar to those of recent examples61. It is likely that such systems, if published today, would be indexed under ‘artificial intelligence’ or ‘machine learning’; however, clinical decision support systems were not actively discussed during this consensus process. Third, the initial candidate items list was generated by a relatively small group of experts consisting of SteeringGroup members and additional international experts; however, additional items from the wider Delphi group were taken forward for consideration by the consensus group, and no new items were suggested during the consensus meeting or post-meeting evaluation.

As with the CONSORT statement, the CONSORT-AI extension is intended as a minimum reporting guidance, and there are additional AI-specific considerations for trial reports that may warrant consideration (Supplementary Table 2). This extension is aimed particularly at investigators and readers reporting or appraising clinical trials; however, it may also serve as useful guidance for developers of AI interventions in earlier validation stages of an AI system. Investigators seeking to report studies developing and validating the diagnostic and predictive properties of AI models should refer to TRIPOD-ML (Transparent Reporting of a Multivariable Prediction Model for Individual Prognosis or Diagnosis–Machine Learning) and STARD-AI (Standards for Reporting Diagnostic Accuracy Studies–Artificial Intelligence), both of which are currently under development32,62. Other potentially relevant guidelines, which are agnostic to study design, are registered with the EQUATOR Network63. The CONSORT-AI extension is expected to encourage careful early planning of AI interventions for clinical trials and this, in conjunction with SPIRIT-AI, should help to improve the quality of trials for AI interventions. The development of the CONSORT-AI guidance does not include additional items within the discussion section of trial reports. The guidance provided by CONSORT 2010 on trial limitations, generalizability and interpretation were deemed to be translatable to trials for AI interventions.

There is also recognition that AI is a rapidly evolving field, and there will be the need to update CONSORT-AI as the technology, and newer applications for it, develop. Currently, most applications of AI involve disease detection, diagnosis and triage, and this is likely to have influenced the nature and prioritization of items within CONSORT-AI. As wider applications that utilize ‘AI as therapy’ emerge, it will be important to continue to evaluate CONSORT-AI in the light of such studies. Additionally, advances in computational techniques and the ability to integrate them into clinical workflows will bring new opportunities for innovation that benefits patients. However, they may be accompanied by new challenges around study design and reporting. In order to ensure transparency, minimize potential biases and promote the trustworthiness of the results and the extent to which they may be generalizable, the SPIRIT-AI and CONSORT-AI Steering Group will continue to monitor the need for updates.

## Section: Supplementary information

Supplementary Figures 1–2, Supplementary Tables 1–2, Supplementary Note.

## Section: Supplementary information

Supplementary Figures 1–2, Supplementary Tables 1–2, Supplementary Note.


---

# Review of Drugs Approved via the 505(b)(2) Pathway: Uncovering Drug Development Trends and Regulatory Requirements

- **Authors:** Ingrid Freije, Stéphane Lamouche, Mario Tanguay
- **Issuer:** Therapeutic innovation & regulatory science
- **Type:** Scientific article
- **Published:** 2020-01-06
- **Language:** en
- **DOI:** 10.1007/s43441-019-00036-y
- **Source:** https://pubmed.ncbi.nlm.nih.gov/32008242/
- **Licence:** CC-BY-NC

## Section: Abstract

A 505(b)(2) application is a type of US new drug application (NDA) that contains full reports of investigations of safety and effectiveness, but where at least some of the information required for approval comes from studies not conducted by or for the applicant and for which the applicant has not obtained a right of reference. Most 505(b)(2) applications consist of changes to a previously approved drug product (ie, a new dosage form, new routes of administration, etc). Sponsors often face challenges determining the studies to be conducted to support approval via 505(b)(2) pathway. This 5-year (2012-2016) retrospective analysis reviewed approved 505(b)(2) NDAs available on the FDA website, to determine the nature of studies (preclinical, clinical pharmacology, and efficacy/safety) conducted for various types of submissions and to better understand the trends in terms of regulatory requirements. The database consisted of 226 NDAs. One hundred twelve of those 226 had complete FDA review information, with the following FDA submission classes being more prevalent: type 3, new dosage form; type 4, new combination; and type 5, new formulation or new manufacturer. Therefore, only these 112 NDAs were further examined as they could show trends in terms of the studies conducted for various types of applications. Based on the investigation of NDA review documents, coupled with guidance documents, decision trees for studies to be conducted have been developed, which may serve as a guide of recommendations for a successful 505(b)(2) development program and NDA submission.


---

# Similarity-Based Methods and Machine Learning Approaches for Target Prediction in Early Drug Discovery: Performance and Scope

- **Authors:** Neann Mathai, Johannes Kirchmair
- **Issuer:** International journal of molecular sciences
- **Type:** Scientific article
- **Published:** 2020-05-19
- **Language:** en
- **DOI:** 10.3390/ijms21103585
- **Source:** https://pubmed.ncbi.nlm.nih.gov/32438666/
- **Licence:** CC-BY

## Section: Abstract

AbstractComputational methods for predicting the macromolecular targets of drugs and drug-like compounds have evolved as a key technology in drug discovery. However, the established validation protocols leave several key questions regarding the performance and scope of methods unaddressed. For example, prediction success rates are commonly reported as averages over all compounds of a test set and do not consider the structural relationship between the individual test compounds and the training instances. In order to obtain a better understanding of the value of ligand-based methods for target prediction, we benchmarked a similarity-based method and a random forest based machine learning approach (both employing 2D molecular fingerprints) under three testing scenarios: a standard testing scenario with external data, a standard time-split scenario, and a scenario that is designed to most closely resemble real-world conditions. In addition, we deconvoluted the results based on the distances of the individual test molecules from the training data. We found that, surprisingly, the similarity-based approach generally outperformed the machine learning approach in all testing scenarios, even in cases where queries were structurally clearly distinct from the instances in the training (or reference) data, and despite a much higher coverage of the known target space.Keywords: target prediction, molecular similarity, machine learning, random forest, molecular fingerprints, drug discovery

## Section: 1. Introduction

Computational methods for predicting the macromolecular targets of small molecules have become increasingly relevant and popular in recent years due to (i) the shift from the “one-drug-one-target” paradigm to “polypharmacology” [1,2,3,4,5], (ii) the increasing availability of chemical and biological data [6,7,8] and (iii) advances in algorithms and hardware technology. Depending on the types of utilized data, in silico methods for target prediction may be categorized as ligand-based, structure-based, or hybrid methods [9,10,11,12]. Ligand-based methods range from straightforward similarity-based approaches [13,14,15,16,17,18,19,20,21] and linear regressions [22] to more complex machine learning (ML) models such as random forests [23,24,25], support vector machines [25,26,27], self-organizing maps [28], neural and deep neural networks [25,29,30,31,32,33,34], and network-based models [35,36,37,38]. They typically use large amounts of chemical information and measured bioactivity data [12] and, as a result, have a larger coverage of the target space when compared to structure-based methods, which rely on 3D structures of macromolecules. The third type of methods, hybrid approaches such as proteochemometrics and network-based approaches, utilize chemical, biological and structural information for target prediction.

Despite the abundance of in silico methods and models for target prediction that have been published in recent years, our understanding of their value and scope under (close to) real-world conditions remains limited [39]. In an ideal scenario, the performance of a model would be determined by large-scale prospective validation. However, the efforts and costs involved in running experiments on scales that can yield statistically meaningful conclusions are in general prohibitive. In consequence, to the best of our knowledge, the Similarity Ensemble Approach (SEA) method remains the only target prediction model that has undergone systematic experimental validation [40,41,42].

Most studies of new target prediction models are limited to retrospective validation [39]. Clearly, recent years have seen substantial progress in the implementation of more robust validation techniques of this kind, but one important aspect missed by most investigations is the relationship between the accuracy and reliability of predictions as a function of the distance between the compound of interest (query molecule) and the training data. In other words, reported validation studies often give a good idea of how well a model performs on the “average compound” originating from a defined dataset, but not so much about how trustworthy a prediction is for a particular compound of interest, which may or may not be structurally closely related to any of the instances in the training data. A further relevant point that is often not given the necessary consideration is target space coverage. Models trained and applied to targets for which a rich body of data is available will likely produce better performance statistics than models aiming to cover a wide target space. From the perspective of the end user, the most important question will be which method produces the most reliable predictions while covering the largest possible target space, and this question has been generally left unanswered.

This work aims to establish the value of two of the most common types of ligand-based methods for target prediction under conditions that closely resemble real-life applications: a straightforward similarity-based approach and a random forest-based ML approach, both employing Morgan2 fingerprints as representations of molecular structures. In particular, we investigate how the structural relationship between a query molecule and the molecules used for model training impact the reliability of predictions, and to what extent the individual approaches are able to cover the known target space.

## Section: 2. Results and Discussion

Creation of the knowledge base/training sets (brown) and test sets (blue) from version 24 (ChEMBL24) and version 25 (ChEMBL25) of the ChEMBL database. Measured bioactivities are counted as individual records (unique compound-protein pairs), compounds are counted as unique canonical SMILES of the preprocessed and standardized structures, and targets are counted as unique ChEMBL target IDs. The number of compounds reported in box d does not include the presumed inactive compounds used to create the individual training sets for the generation of the ML models.

General workflow for the development and validation of the similarity-based method and the machine learning approach for target prediction.

Distributions of the median maxTC values (quantifying the median molecular similarity of each query molecule and its nearest ligand of each of the query molecule’s annotated targets) for the queries from the ChEMBL24 database (blue) and ChEMBL25 database (grey). The results of the similarity-approach are marked without a pattern; the results for the ML approach are shown with a pattern. The bars represent the number of queries within a median maxTC bin. The distributions show that the ChEMBL24 test set is more similar to the data of the knowledge base than the ChEMBL25 test set (which is expected as the knowledge base is a subset of the ChEBML24 database). The lines report the cumulative percentage of queries with median maxTCs greater than or equal to the values covered by a bin. For the sake of clarity, the lines are only shown for the similarity-based approach as they are almost identical with the lines for the ML approach.

Query molecule (sunitinib) with examples of high, low, and medium similarity compounds from the ligand sets of its targets.

Success rates (A–C) and recovery rates (D–F) of the similarity-based approach under (A,D) the standard testing scenario with external data, (B,E) the standard time-split testing scenario, and (C,F) the close-to-real-world testing scenario. As expected, the performance under all testing scenarios drops as the queries become increasingly dissimilar to the data underlying the models. The data for these graphs are also provided in tabular format in the Supporting Information (Table S1–S4).

Success rates (A–C) and recovery rates (D–F) of the ML approach (solid lines and bars) and the similarity-based approach (dashed lines and bars; reduced target scope, identical with that of the ML approach) under the (A,D) standard testing scenario with external data, (B,E) the standard time-split testing scenario, and (C,F) the close-to-real-world testing scenario. In general, the similarity-based approach shows a tendency to outperform the ML approach. As expected, the performance under all testing scenarios drops as queries become more dissimilar from the training set/knowledge base. The data for these graphs are also provided in tabular format in the Supporting Information (Table S5–S12).

Overall success and recovery rates of the ML approach when using individual target models with a different minimum number of active compounds.

## Section: 2. Results and Discussion › 2.1. Similarity-Based Method and Machine Learning Approach for Target Prediction

Bioactivity data for model building and validation was extracted from the ChEMBL database [43] version 24. These data were curated and processed (see Methods section for details), resulting in a “processed dataset” consisting of 1,015,188 compound-protein pairs (546,981 unique compounds and 4676 unique targets; Figure 1a). Compound-protein pairs with an activity value less than or equal to 10,000 nM were marked as “active” (732,570 bioactivities) while those with activities greater than or equal to 20,000 nM were marked as “inactive” (282,618 bioactivities). Prior to any model development, the compounds in the processed dataset (Figure 1a) were randomly assigned to a “global knowledge base” (Figure 1b) or a “global test set” (Figure 1e) at a ratio of 90:10.

The similarity-based approach uses the maximum pairwise similarities (Tanimoto coefficients (TC) derived from Morgan2 fingerprints; maxTCs) between a query molecule and the sets of ligands representing the 4239 individual proteins in the knowledge base (Figure 1c) to produce a rank-ordered list of potential targets (Figure 2). In cases where multiple proteins have the same maxTCs, the next highest TCs are considered until all proteins are ranked.

The ML approach decomposes the multi-label problem (i.e., a single query molecule may interact with many proteins) into a series of binary classification problems (i.e., a query molecule does or does not interact with a particular protein). This technique, known as binary relevance, is an intuitive and popular transformation [44] in target prediction [24,25,45]. Here, a query molecule is tested on all the target models individually and the models’ prediction probability of the active class (p-values) are then used to rank the potential targets for the query molecule (Figure 2). More specifically, random forest models were generated for each of the 1798 targets represented by a minimum of 25 ligands in the global knowledge base (Figure 1d). The individual models were trained on all active and all inactive compounds recorded for a target in the global knowledge base. Following a widely-applied approach in target prediction for expanding chemical space coverage [9,18,33,45,46], all training sets for ML for which the number of confirmed inactive compounds did not exceed the number of confirmed active compounds by a factor of 10 (this was the case for 1793 out of the 1798 targets) were supplemented with presumed inactive compounds (i.e., randomly chosen compounds from the global knowledge base which do not have any annotation for the particular target) to give a balance of 10:1. The hyperparameters of the individual random forest classifiers were optimized during a grid search within a cross-validation framework (see Method section for details).

Creation of the knowledge base/training sets (brown) and test sets (blue) from version 24 (ChEMBL24) and version 25 (ChEMBL25) of the ChEMBL database. Measured bioactivities are counted as individual records (unique compound-protein pairs), compounds are counted as unique canonical SMILES of the preprocessed and standardized structures, and targets are counted as unique ChEMBL target IDs. The number of compounds reported in box d does not include the presumed inactive compounds used to create the individual training sets for the generation of the ML models.

General workflow for the development and validation of the similarity-based method and the machine learning approach for target prediction.

## Section: 2. Results and Discussion › 2.2. Evaluation of the Scope and Performance of the Similarity-Based Method and Machine Learning Approach for Target Prediction

The scope and limitations of the individual approaches are evaluated under the following validation settings:

Based on our experience in working with TCs derived from Morgan2 (and some related) fingerprints, we distinguish the following classes of queries:

For the sake of clarity, the discussion of the methods’ performance focuses on these three categories (Figure 4 shows examples of different TCs of a query molecule and knowledge base ligands). A more fine-graded view is provided by the graphs and supplementary tables, which use a bin width for the TC of 0.2 for the disaggregation of the results. The trends observed at both levels of granularity are consistent.

Distributions of the median maxTC values (quantifying the median molecular similarity of each query molecule and its nearest ligand of each of the query molecule’s annotated targets) for the queries from the ChEMBL24 database (blue) and ChEMBL25 database (grey). The results of the similarity-approach are marked without a pattern; the results for the ML approach are shown with a pattern. The bars represent the number of queries within a median maxTC bin. The distributions show that the ChEMBL24 test set is more similar to the data of the knowledge base than the ChEMBL25 test set (which is expected as the knowledge base is a subset of the ChEBML24 database). The lines report the cumulative percentage of queries with median maxTCs greater than or equal to the values covered by a bin. For the sake of clarity, the lines are only shown for the similarity-based approach as they are almost identical with the lines for the ML approach.

Query molecule (sunitinib) with examples of high, low, and medium similarity compounds from the ligand sets of its targets.

Success rates (A–C) and recovery rates (D–F) of the similarity-based approach under (A,D) the standard testing scenario with external data, (B,E) the standard time-split testing scenario, and (C,F) the close-to-real-world testing scenario. As expected, the performance under all testing scenarios drops as the queries become increasingly dissimilar to the data underlying the models. The data for these graphs are also provided in tabular format in the Supporting Information (Table S1–S4).

Success rates (A–C) and recovery rates (D–F) of the ML approach (solid lines and bars) and the similarity-based approach (dashed lines and bars; reduced target scope, identical with that of the ML approach) under the (A,D) standard testing scenario with external data, (B,E) the standard time-split testing scenario, and (C,F) the close-to-real-world testing scenario. In general, the similarity-based approach shows a tendency to outperform the ML approach. As expected, the performance under all testing scenarios drops as queries become more dissimilar from the training set/knowledge base. The data for these graphs are also provided in tabular format in the Supporting Information (Table S5–S12).

Overall success and recovery rates of the ML approach when using individual target models with a different minimum number of active compounds.

## Section: 2. Results and Discussion › 2.2. Evaluation of the Scope and Performance of the Similarity-Based Method and Machine Learning Approach for Target Prediction › 2.2.1. Evaluation of the Scope and Performance of the Similarity-Based Method

Success rates (A–C) and recovery rates (D–F) of the similarity-based approach under (A,D) the standard testing scenario with external data, (B,E) the standard time-split testing scenario, and (C,F) the close-to-real-world testing scenario. As expected, the performance under all testing scenarios drops as the queries become increasingly dissimilar to the data underlying the models. The data for these graphs are also provided in tabular format in the Supporting Information (Table S1–S4).

## Section: 2. Results and Discussion › 2.2. Evaluation of the Scope and Performance of the Similarity-Based Method and Machine Learning Approach for Target Prediction › 2.2.1. Evaluation of the Scope and Performance of the Similarity-Based Method

Overall, the similarity-based approach achieved high success rates, ranking at least one known target among the top-3, top-5, and top-15 positions in 86%, 88%, and 93% of all cases (Figure 5A). The success rates were found to be strongly linked with the distance between the query molecule and the nearest ligand (for that target) in the knowledge base. For 95% of all high similarity queries (as defined in the introductory section of the Results and Discussion section), the protein ranked at the top position was a known target. For medium similarity queries, however, the success rates were only 55%, 63%, and 82% when considering the top-3, top-5, and top-15 ranks, respectively. For low similarity queries, the success rates dropped to 10% (top-3), 12% (top-5), and 18% (top-15), respectively.

The similarity-based approach obtained good overall recovery rates (Figure 5D), with a strong correlation of performance and the distance between the query molecule and the compounds in the knowledge base observed here as well. The recovery rate is defined as the percentage of known bioactivities ranked among the top-k positions of the list of predicted targets. For high similarity queries, 92%, 97%, and 100% of the known targets were ranked among the top-3, top-5, and top-15 positions, respectively. In contrast, for medium similarity queries, the recovery rates were only 35%, 45%, and 70% when considering the top-3, top-5, and top-15 ranks, respectively. For low similarity queries, these success rates dropped to 1% (top-3), 1% (top-5), and 3% (top-15).

Success rates (A–C) and recovery rates (D–F) of the similarity-based approach under (A,D) the standard testing scenario with external data, (B,E) the standard time-split testing scenario, and (C,F) the close-to-real-world testing scenario. As expected, the performance under all testing scenarios drops as the queries become increasingly dissimilar to the data underlying the models. The data for these graphs are also provided in tabular format in the Supporting Information (Table S1–S4).

## Section: 2. Results and Discussion › 2.2. Evaluation of the Scope and Performance of the Similarity-Based Method and Machine Learning Approach for Target Prediction › 2.2.1. Evaluation of the Scope and Performance of the Similarity-Based Method

As expected, the success and recovery rates obtained for the similarity-based approach on the set of compounds newly introduced with version 25 of the ChEMBL database (“ChEMBL 25 test set”) were generally lower than for the ChEMBL24 test set (Figure 5B). The overall success rates among the top-3, top-5, and top-15 positions were 58%, 61%, and 69% (vs. 86%, 88%, and 93% obtained for the ChEMBL24 test set, see above). However, the success rates for queries represented by structurally related ligands in the knowledge base were comparable with those obtained for the ChEMBL24 test data: for high similarity queries, a known target was ranked at the top position in 93% of all cases (vs. 95% obtained for the ChEMBL24 test set). This is contrasted by the performance on medium similarity queries which had success rates of 70%, 76%, and 88% for the ChEMBL25 test set when considering the top-3, top-5, and top-15 ranks (vs. 55%, 63%, and 82% obtained for the ChEMBL24 test set). The success rates of the low similarity queries form the ChEMBL 25 test set dropped to 5%, 7%, and 13% for the top-3, top-5, and top-15 ranks (compared to 10%, 12%, and 18% for the ChEMBL 24 test set).

In accordance with the trends observed for the success rates, the recovery rates were also lower for queries from the new data in the ChEMBL25 database. Only 47%, 53%, and 63% of the known interactions were recovered among the top-3, top-5, and top-15 targets, as opposed to a recovery rate of 72%, 79%, and 87% obtained on the ChEMBL24 test set. Again, interactions with queries, which are more structurally related to the knowledge base, had higher recovery rates than those that were more distant (Figure 5E).

## Section: 2. Results and Discussion › 2.2. Evaluation of the Scope and Performance of the Similarity-Based Method and Machine Learning Approach for Target Prediction › 2.2.1. Evaluation of the Scope and Performance of the Similarity-Based Method

In the close-to-real-world testing scenario, an additional 1296 interactions (of 838 query molecules) not represented by the knowledge base were considered in the performance assessment. The 1296 interactions correspond to 4% of all interactions newly introduced with version 25 of the ChEMBL database. In consequence, the overall success rates for the top-3, top-5, and top-15 predictions decreased to 55%, 59%, and 66%, which represents a drop by 2 to 3 percentage points compared to the standard time-split scenario (Figure 5C). Likewise, the recovery rates for the top-3, top-5, and top-15 predictions dropped to 45%, 51%, and 61%, which is a decrease by 2 to 3 percentage points compared to the standard time-split scenario (Figure 5F).

## Section: 2. Results and Discussion › 2.2. Evaluation of the Scope and Performance of the Similarity-Based Method and Machine Learning Approach for Target Prediction › 2.2.1. Evaluation of the Scope and Performance of the Similarity-Based Method

The similarity-based approach has the widest scope of the approaches as any target with at least one known annotated ligand is represented in the knowledge base. The similarity-based approach covers a total of 4239 targets.

## Section: 2. Results and Discussion › 2.2. Evaluation of the Scope and Performance of the Similarity-Based Method and Machine Learning Approach for Target Prediction › 2.2.2. Evaluation of the Scope and Performance of the Machine-Learning Approach

In the following subsections, the performance of the ML is discussed and directly compared to the performance of the similarity-based approach. For the sake of direct comparability, in the following discussion all statements on the performance of the similarity-based approach refer to its application to the reduced target space of the ML approach (1798 proteins) rather than the full target space covered by the similarity-based approach (4239 proteins). Note that, importantly, the target ranking performance of the similarity-based approach on the full target scope is almost identical to that on the reduced target scope, meaning that there is no noticeable drop in performance in the top-k success and recovery rates of the similarity-based approach (using identical absolute values for k) when applied to a target space of 4239 proteins instead of 1798, which is remarkable.

Success rates (A–C) and recovery rates (D–F) of the ML approach (solid lines and bars) and the similarity-based approach (dashed lines and bars; reduced target scope, identical with that of the ML approach) under the (A,D) standard testing scenario with external data, (B,E) the standard time-split testing scenario, and (C,F) the close-to-real-world testing scenario. In general, the similarity-based approach shows a tendency to outperform the ML approach. As expected, the performance under all testing scenarios drops as queries become more dissimilar from the training set/knowledge base. The data for these graphs are also provided in tabular format in the Supporting Information (Table S5–S12).

Overall success and recovery rates of the ML approach when using individual target models with a different minimum number of active compounds.

## Section: 2. Results and Discussion › 2.2. Evaluation of the Scope and Performance of the Similarity-Based Method and Machine Learning Approach for Target Prediction › 2.2.2. Evaluation of the Scope and Performance of the Machine-Learning Approach

The ML approach achieved overall success rates of 82%, 86%, and 91% for the top-3, top-5, and top-15 positions, respectively (Figure 6A—solid lines), which is 1 to 3 percentage points lower than the success rates obtained by the similarity-based approach. The success rates were found to be strongly linked with the distance between the query molecule and the ligands in the knowledge base. For 90% of all high similarity queries, the known target was assigned the top rank (as compared to 95% for the similarity-based approach). For the median similarity queries, the success rates were only 49%, 57%, and 75% when considering the top-3, top-5, and top-15 ranks, respectively (which is 6 to 7 percentage points lower than the success rates of similarity-based approach). The success rates of the low similarity queries decreased to 10% (top-3), 15% (top-5), and 28% (top-15). Whereas the top-3 success rate was identical with that of the similarity-based approach, the top-5 and top-15 rates of the ML approach were 3 and 10 percentage points higher, respectively. This suggests that the ML approach may be able to predict the targets of low similarity queries better.

The recovery rates for the ML approach for high similarity queries were 88%, 94%, and 98% for the top-3, top-5, and top-15 positions, respectively (2 to 4 percentage points lower than the recovery rates of the similarity approach) (Figure 6D). For medium similarity queries, the recovery rates were only 30%, 39%, and 60% when considering the top-3, top-5, and top-15 ranks, respectively (5, 6 and 11 percentage points lower than the recovery rates of the similarity-based approach). The recovery rates for low similarity queries dropped to 3% (top-3), 5% (top-5), and 12% (top-15), which is still 2, 3, and 9 percentage points better than the values for the similarity-based approach.

Success rates (A–C) and recovery rates (D–F) of the ML approach (solid lines and bars) and the similarity-based approach (dashed lines and bars; reduced target scope, identical with that of the ML approach) under the (A,D) standard testing scenario with external data, (B,E) the standard time-split testing scenario, and (C,F) the close-to-real-world testing scenario. In general, the similarity-based approach shows a tendency to outperform the ML approach. As expected, the performance under all testing scenarios drops as queries become more dissimilar from the training set/knowledge base. The data for these graphs are also provided in tabular format in the Supporting Information (Table S5–S12).

## Section: 2. Results and Discussion › 2.2. Evaluation of the Scope and Performance of the Similarity-Based Method and Machine Learning Approach for Target Prediction › 2.2.2. Evaluation of the Scope and Performance of the Machine-Learning Approach

In line with the results obtained for the similarity-based approach, the success and recovery rates obtained for the standard time-split scenario were lower than for the standard testing scenario (Figure 6B). The overall top-3, top-5, and top-15 success rates were 53%, 57%, and 65%, respectively (vs. 82%, 86%, and 91% obtained for the ChEMBL24 test set; see above), which corresponds to 4, 3, and 1 percentage points below the time-split success rates of the similarity-based approach. For high similarity queries, a known target was ranked at the top position in 86% of all cases (which is 7 percentage points lower than the results obtained with the similarity-based approach). For medium similarity queries, the success rates were 59%, 65%, and 76% when considering the top-3, top-5, and top-15 ranks, respectively (vs. 49%, 57%, and 75% obtained for the ChEMBL24 test set). This corresponds to a drop by 11 to 13 percentage points over the similarity-based approach. For low similarity queries, the success rates were 4%, 7%, and 13% (nearly identical to the similarity-based approach in that scenario).

The recovery rates were also lower for queries from the new data in the ChEMBL25 database. Only 44%, 50%, and 60% of all the known interactions were covered among the top-3, top-5, and top-15 predictions (Figure 6E), respectively (vs. 69%, 75%, and 84% for the ChEMBL24 test set). The trends observed for the recovery rates under the standard time-split scenario for the similarity and ML approach were the same as the success rates described above.

## Section: 2. Results and Discussion › 2.2. Evaluation of the Scope and Performance of the Similarity-Based Method and Machine Learning Approach for Target Prediction › 2.2.2. Evaluation of the Scope and Performance of the Machine-Learning Approach

In the close-to-real-world testing scenario, an additional 3381 interactions (11% of the new interactions with version 25 of the ChEMBL database), which were not represented in the knowledge base, (from 1778 query molecules) were considered in the performance assessment. The overall success rates under this scenario were 49%, 52%, and 59% for the top-3, top-5, and top-15 predictions, respectively (Figure 6C). This represents a drop by 4 to 6 percentage points compared to the standard time-split scenario. The overall recovery rates for the top-3, top-5, and top-15 predictions dropped by 4 to 6 percentage points to 40%, 45%, and 54%, respectively (Figure 6F). In comparison to the similarity-based approach, the overall success rates under the close-to-real-world scenario were 6 percentage points lower for the top-3, top-5, and top-15 while the recovery rates were 5 percentage points lower.

## Section: 2. Results and Discussion › 2.2. Evaluation of the Scope and Performance of the Similarity-Based Method and Machine Learning Approach for Target Prediction › 2.2.2. Evaluation of the Scope and Performance of the Machine-Learning Approach

The 90:10 split of the processed ChEMBL24 data and the requirement for a minimum of 25 ligands per target for model building resulted in a reduced scope of the ML approach over the similarity-based approach. While the similarity-based approach covers a total of 4239 targets, the ML approach covers only 1798 targets (42% of the similarity-based approach’s target scope). As such, the ML approach did not cover 379 of the known targets of ChEMBL 24 queries, which resulted in the inability of the method to predict 2099 known interactions of 792 queries.

The accuracy of the ML approach can be marginally increased by using larger training sets (Table 1), at the cost of target coverage. Models based on training sets consisting of a minimum of 50, 75 or 100 ligands (and ten times as many confirmed and/or presumed inactive compounds selected as described in the Methods section) would further reduce the number of proteins to 1296, 1066 and 899, respectively. The improvements in ranking performance are explained primarily by the reduction of the number of proteins represented by the approach, making ranking an easier task.

Overall success and recovery rates of the ML approach when using individual target models with a different minimum number of active compounds.

## Section: 3. Methods

Hyperparameters explored in the grid search of each target classification model.

## Section: 3. Methods › 3.1. Data Preparation

Following a protocol closely related to that of Bosc et al. [24], the selection criteria listed below (italics indicate a ChEMBL data field and quotations indicate the value) were applied for the extraction of data from ChEMBL 24 [43]:

This extraction procedure resulted in a dataset containing 1,482,972 bioactivity records (i.e., compound-protein pairs). Of these records, 2206 had standard_units of “μg mL−1” as opposed to “nM” and therefore the standard_value for these records were converted to nM using the topological information from canonical_smiles and the Descriptors.ExactMolWt function of RDKit (RDKit: Open-source cheminformatics; version 2019.03.2.0; http://www.rdkit.org). The molecules were then passed through the salt and element filter described in ref. [47], and the SMILES of the remaining compounds were converted with RDKit to non-isomeric SMILES. Duplicate compound-protein pairs, resulting from multiple bioactivity values recorded in the original data or from the removal of compound stereochemistry, were consolidated by calculating the median activity value as the representative activity value for the 1,179,102 unique bioactivity records. Compound-protein pairs with activity values less than or equal to 10,000 nM were labeled “active” (732,570 bioactivities) while those with activities greater than or equal to 20,000 nM were marked as “inactive” (282,618 bioactivities). Compound-protein pairs with activity values between 10,000 nM and 20,000 nM (163,914 bioactivities) were not considered for model building or validation and were discarded. The resulting dataset (“processed dataset”) consists of 1,015,188 compound-protein pairs, comprising 546,981 unique compounds and 4676 unique targets (Figure 1a) from which the knowledge base for the similarity-based approach (Figure 1c), the training sets for the ML approach (Figure 1b), and the testing sets (Figure 1e–g) were derived. Additionally, data from the next version of the ChEMBL database (version 25) was processed as described above and new bioactivity records were used for further test sets (Figure 1h–j)

## Section: 3. Methods › 3.2. Development of Target Prediction Models

Hyperparameters explored in the grid search of each target classification model.

## Section: 3. Methods › 3.2. Development of Target Prediction Models › 3.2.1. Similarity-Based Approach

The pairwise similarity of each compound of the test set (query molecule) and all compounds of the knowledge base for similarity-based target prediction was quantified based on TCs derived from Morgan fingerprints with a radius of 2 and a length of 2048 bits. Morgan2 fingerprints were selected because they are closely related to the extended connectivity fingerprints [48] with a diameter of 4 bonds (ECFP4), which have been widely applied in target prediction [16,17,25,49] and virtual screening [50] and have shown to perform favorably. For example, in tests of the target prediction methods Polypharmacology Browser (PPB2) [49] and MolTarPred [16,17], the ECFP4 fingerprints obtained the best performance among a collection of different molecular fingerprints.

The proteins were assigned ranks from 1 to 4239 (the total number of proteins represented by the knowledge base) according to the maximum pairwise TC of the query molecule and any of the ligands of that protein (maxTC). In cases where multiple proteins had the same maxTC, the ranking was refined based on the distance of the query molecule to the next nearest neighbor until non-ambiguous ranks could be assigned to all proteins.

## Section: 3. Methods › 3.2. Development of Target Prediction Models › 3.2.2. Machine Learning Approach for Target Prediction

Random forest binary classification models were built with scikit-learn (Scikit-learn: Machine Learning in Python; version 0.20.1; https://scikit-learn.org) [51] for all of the 1798 targets represented in the ML knowledge base by at least 25 ligands. The training set for each model is composed of the bioactivity records from the knowledge base and supplemented with presumed inactive compounds (selected randomly following the procedure described in the section “Generation of training and test sets” of Methods) to obtain a ratio of 1:10 compounds. The number of estimators (n estimators) and maximum depth of the estimators (max depth) of these models were optimized individually for each model during a grid search within a 10-fold cross-validation framework (Table 2). The best combination of parameters for each model (see the supplementary information), as measured by the average MCC score across the 10 folds, was then used to retrain the final model for each target using the complete training sets.

For a given query molecule, the proteins were then ranked by prediction probability of the active class (p-value). Proteins assigned identical p-values were ranked according to the iterative process described for the similarity-based approach.

Hyperparameters explored in the grid search of each target classification model.

## Section: 4. Conclusions

This work aimed to determine the scope and limitations of two of the most commonly applied ligand-based methods for target prediction: a similarity-based approach, and a random forest-based machine learning approach, both employing Morgan2 fingerprints as molecular representations. By analyzing the performance of the approaches under three different scenarios and deconvoluting the results based on the distance of the test compounds (queries) from the training data (or knowledge base molecules), we obtained a robust and differentiated picture of the performance and reach of the approaches.

We have found that, in general, the similarity-based approach performed better than the ML approach, despite the similarity-based approach covering almost 2.5 times more proteins than the ML approach (4239 vs. 1798 proteins). Under the standard testing scenario with external data, the percentage of queries for which their target was recovered among the top-5 out of 1798 positions was 88% for the similarity-based approach and 85% for the ML approach (identical target space applied for the testing of both approaches). Under the time-split testing scenario, a drop in performance compared to the previous testing scenario was observed. Within a year’s time (i.e., the difference between ChEMBL24 and ChEMBL25), the top-5 success rate performance of all the approaches dropped by an average of 25% for the new chemical and target spaces explored during that year. This reduction in performance is expected, given the evolution of the chemical and target spaces over time, and is consistent with the drop performance observed for compounds with a comparable degree of (dis-) similarity with the training data in the standard testing scenario with external data. The results indicate that the single time-split scenario, which represents a snapshot of the evolution of research in small-molecule drug discovery, may not be essential for obtaining an understanding of the robustness of a method, provided that model performance is evaluated taking into account training-to-test set distances. The third scenario, which is closest to the real-life application of the method, looks into how the method would perform, taking into account that some of the targets of new molecules may not be covered by the model. Here, minor drops in model performance were observed.

It was surprising to find that overall the similarity-based approach outperformed the ML approach, particularly for the low-similarity queries, where it was hoped that the ML models would have generalized and been able to make more reliable predictions. It is probable that the ML approach may perhaps be improved with more and diverse data and achieve better generalization with more specific training protocols for individual targets.

## Section: Acknowledgments

The calculations described in this work were performed on resources provided by UNINETT Sigma2 - the National Infrastructure for High Performance Computing and Data Storage in Norway.

## Section: Supplementary Materials

The following are available online at https://www.mdpi.com/1422-0067/21/10/3585/s1, Table S1. Success rates under the standard testing scenario with external data by the similarity approach, Table S2. Recovery rates under the standard testing scenario with external data by the similarity approach, Table S3. Success rates under the time-split and close-to-real-world testing scenarios by the similarity approach, Table S4. Recovery rates under the time-split and close-to-real-world testing scenarios with by the similarity approach, Table S5. Success rates under the standard testing scenario with external data by the similarity approach with a reduced target scope, Table S6. Recovery rates under the standard testing scenario with external data by the similarity approach with a reduced target scope, Table S7. Success rates under the time-split and close-to-real-world testing scenarios by the similarity approach with a reduced target scope, Table S8. Recovery rates under the time-split and close-to-real-world testing scenarios with by the similarity approach with a reduced target scope, Table S9. Success rates under the standard testing scenario with external data by the ML approach, Table S10. Recovery rates under the standard testing scenario with external data by the ML approach, Table S11. Success rates under the time-split and close-to-real-world testing scenarios by the ML approach, Table S12. Recovery rates under the time-split and close-to-real-world testing scenarios with by the ML approach.

Click here for additional data file.

## Section: Author Contributions

Conceptualization, N.M. and J.K.; methodology, N.M. and J.K.; software, N.M.; validation, N.M.; formal analysis, N.M. and J.K.; investigation, N.M. and J.K.; resources, J.K.; data curation, N.M.; writing—original draft preparation, N.M. and J.K.; visualization, N.M. and J.K.; supervision, J.K.; project administration, J.K.; funding acquisition, J.K. All authors have read and agreed to the published version of the manuscript.

## Section: Funding

This research was funded by the Trond Mohn Foundation (BFS2017TMT01).

## Section: Conflicts of Interest

The authors declare no conflicts of interest.

## Section: Associated Data

Click here for additional data file.

## Section: Associated Data › Supplementary Materials

Click here for additional data file.


---

# Systems Approach to Pathogenic Mechanism of Type 2 Diabetes and Drug Discovery Design Based on Deep Learning and Drug Design Specifications

- **Authors:** Shen Chang, Jian-You Chen, Yung-Jen Chuang, Bor-Sen Chen
- **Issuer:** International journal of molecular sciences
- **Type:** Scientific article
- **Published:** 2020-12-26
- **Language:** en
- **DOI:** 10.3390/ijms22010166
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33375269/
- **Licence:** CC-BY

## Page 1 (Section: Introduction )

International Journal of 
Molecular Sciences
Article
Systems Approach to Pathogenic Mechanism of Type 2
Diabetes and Drug Discovery Design Based on Deep Learning
and Drug Design Speciﬁcations
Shen Chang 1, Jian-You Chen 1, Yung-Jen Chuang 2
and Bor-Sen Chen 1,*


Citation: Chang, S.; Chen, J.-Y.;
Chuang, Y.-J.; Chen, B.-S. Systems
Approach to Pathogenic Mechanism
of Type 2 Diabetes and Drug
Discovery Design Based on Deep
Learning and Drug Design
Speciﬁcations. Int. J. Mol. Sci. 2021,
22, 166. https://doi.org/10.3390/
ijms22010166
Received: 7 October 2020
Accepted: 21 December 2020
Published: 26 December 2020
Publisher’s Note: MDPI stays neu-
tral with regard to jurisdictional clai-
ms in published maps and institutio-
nal afﬁliations.
Copyright: © 2020 by the authors. Li-
censee MDPI, Basel,
Switzerland.
This article is an open access article
distributed under the terms and con-
ditions of the Creative Commons At-
tribution (CC BY) license (https://
creativecommons.org/licenses/by/
4.0/).
1
Laboratory of Automatic Control, Signal Processing and Systems Biology,
Department of Electrical Engineering, National Tsing Hua University, Hsinchu 30013, Taiwan;
s107061595@m107.nthu.edu.tw (S.C.); s107061588@m107.nthu.edu.tw (J.-Y.C.)
2
Institute of Bioinformatics and Structural Biology, National Tsing Hua University, Hsinchu 30013, Taiwan;
yjchuang@life.nthu.edu.tw
*
Correspondence: bschen@ee.nthu.edu.tw
Abstract: In this study, we proposed a systems biology approach to investigate the pathogenic mech-
anism for identifying signiﬁcant biomarkers as drug targets and a systematic drug discovery strategy
to design a potential multiple-molecule targeting drug for type 2 diabetes (T2D) treatment. We ﬁrst
integrated databases to construct the genome-wide genetic and epigenetic networks (GWGENs),
which consist of protein–protein interaction networks (PPINs) and gene regulatory networks (GRNs)
for T2D and non-T2D (health), respectively. Second, the relevant “real GWGENs” are identiﬁed by
system identiﬁcation and system order detection methods performed on the T2D and non-T2D RNA-
seq data. To simplify network analysis, principal network projection (PNP) was thereby exploited
to extract core GWGENs from real GWGENs. Then, with the help of KEGG pathway annotation,
core signaling pathways were constructed to identify signiﬁcant biomarkers. Furthermore, in order to
discover potential drugs for the selected pathogenic biomarkers (i.e., drug targets) from the core sig-
naling pathways, not only did we train a deep neural network (DNN)-based drug–target interaction
(DTI) model to predict candidate drug’s binding with the identiﬁed biomarkers but also considered a
set of design speciﬁcations, including drug regulation ability, toxicity, sensitivity, and side effects to
sieve out promising drugs suitable for T2D.
Keywords: type 2 diabetes (T2D); pathogenic mechanism; deep neural network (DNN)-based DTI
model; pathogenic biomarkers; drug design speciﬁcation; multiple-molecule targeting drug
1. Introduction
In recent years, chronic diseases are major causes of morbidity and mortality world-
wide. As patients’ long-term conditions could deteriorate gradually with age, chronic dis-
eases require continuous monitoring and treatment to maintain quality of life. Diabetes is
one of the prominent chronic diseases caused by either dysfunctional insulin production or
failed deployment of insulin. Among them, type 2 diabetes (T2D) accounts for 90% to 95%
cases in all diabetes and is estimated to impact about 435 million patients around the world
by 2030 [1]. While T2D is considered to be most common in adults, the diagnosis of pedi-
atric T2D increases steadily [2]. Common symptoms for T2D include frequent urination,
thirst, constant hunger, etc. Most importantly, as a risk factor for heart, blood vessels, eyes,
kidneys, and nervous system diseases, T2D might inevitably increase the risk of death and
the medical burden on society.
T2D has been typically seen as insulin-independent, which implies an ineffective
utilization of insulin due to insulin resistance [3]. However, it has been shown that the
pancreatic β-cell destruction due to inﬂammation and immune response might also give
rise to T2D aggravation [4,5]. Nowadays, albeit much effort has been dedicated to elucidate
Int. J. Mol. Sci. 2021, 22, 166. https://doi.org/10.3390/ijms22010166
https://www.mdpi.com/journal/ijms

## Page 2 (Section: Introduction )

Int. J. Mol. Sci. 2021, 22, 166
2 of 33
the T2D pathogenic mechanism, few studies discussed how pancreatic destruction occurs in
T2D, let alone its correlation with inﬂammatory response on β-cells. In fact, the systematic
pathogenic mechanism of T2D still remains unclear. Therefore, we proposed a systems
biology approach to investigate key pathogenic factors in view of genetic and epigenetic
networks through system identiﬁcation and system order detection methods by genome-
wide RNA-seq data of T2D.
In the past decade, many methodologies have been proposed to identify the com-
plex relations between the gene–gene, gene–protein, and protein–protein interactions.
Although traditional biological experiments have been used to identify the protein–protein
interaction network in the late 1990s [6], some drawbacks were also incurred. First, it is
expensive and time-consuming to execute a large number of experiments for developing
new therapies. Second, the biological experiments have practical limitations on taking the
whole genome into consideration [7]. As a result, some potential pathways for diseases
may not be well detected and studied. For instance, while the genome-wide association
studies (GWAS) have investigated the single nucleotide polymorphisms (SNPs) of the
human genome and found many disease-related variations, such ﬁndings alone can not
explain the complex pathogenesis [8,9]. To overcome these challenges, we employed a
systems biology approach to macroscopically analyze the systematic relationship among
the proteins, genes, and microenvironment in the T2D pathogenic mechanism.
The systems biology method has been widely used to investigate the pathogene-
sis of disease such as cancer [10] and the progression of virus infection [11]. Likewise,
in the proposed issues of T2D management, the systems biology method was deployed to
trim off false positives from the candidate genome-wide genetic and epigenetic networks
(GWGENs) as well as identify the disease-based GWGENs. Then, with the help of the
principal network projection (PNP) approach, the core GWGENs were sifted out and fur-
ther projected to KEGG pathways for subsequent analysis. Right after, by comparing the
discrepancy between the non-T2D and T2D core signaling pathways, the pathogenic mech-
anism can be revealed. According to the analyzed pathogenic mechanism in core signaling
pathways, the fat accumulation-dependent signaling pathways and the high glucose-
induced signaling pathways lead pancreatic β-cells to excessive burden, bringing about
cell inﬂammation and apoptosis during the development of T2D. Such phenomenon re-
duces the production of insulin secretion and disrupts the balance between glucose and
insulin, giving rise to T2D. Hence, we proposed IKK, STAT3, PPARƔ,, ETS1, and FAS as the
signiﬁcant pathogenic biomarkers contributing to the fat accumulation-dependent as well
as the inﬂammatory-dependent cell apoptosis for systematic drug discovery design.
The process of drug development is an arduous task because of the high cost and time-
consuming trials. It is estimated that it takes about 12–15 years and more than one billion US
dollars before marketing a new drug [12]. Pharmaceutical companies need to spend a large
amount of time and effort on executing experiments to understand the properties and the
interactions of the drug to its targets. In addition, numerous animal and clinical trials ought
to be carried out so as to ensure its safety and effectiveness [13]. These complicated proce-
dures vastly increase the risk of failure in drug development, and most of them originate
from the poor clinical outcomes [14]. On this ground, we developed systematic strategies
based on drug–target interaction prediction and drug design speciﬁcations, which include
drug regulation ability, toxicity, sensitivity, and side effect, to confront the problems from
the perspective of system engineering. As the result, we chose and combined Sulforaphane
and Biotin as the multiple-molecule targeting drug, which may potentially regulate IKK,
STAT3, PPARƔ,, ETS1, and FAS for T2D management. Taken together, we expect that the
systematic drug discovery and design procedures presented in this study can provide an
efﬁcient way to ﬁnd the multiple-molecule targeting drug candidates for T2D treatment
before clinical trials.

## Page 3 (Section: Results )

Int. J. Mol. Sci. 2021, 22, 166
3 of 33
2. Results
2.1. Overview of Systems Biology Method and Systematic Drug Discovery Design in T2D
In this work, we proposed a combination of systems biology method and systematic
drug discovery design (as shown in Figure 1) to gain deeper insight into the T2D patho-
genesis and to identify potential drugs for T2D treatment based on the selected signiﬁcant
biomarkers (drug targets). By and large, the process can be subdivided into a few steps:
(1) candidate GWGENs construction from big data mining; (2) the system identiﬁcation
method by RNA-seq data and system order detection method to construct real GWGENs
shown in Figure A1 by pruning the false positives from candidate GWGEN; (3) the principal
network projection method (PNP) for extracting core GWGENs shown in Figure A2 from
the real GWGENs to simplify the network analysis; (4) the pathogenic mechanism of T2D
and the signiﬁcant biomarkers investigating by comparing the core signaling pathways
between non-T2D and T2D in Figure 2; (5) a pretrained drug–target interaction (DTI) model
to predict candidate drugs for the targets (biomarkers); (6) drug design speciﬁcations to
further sieve out promising drugs for the proposed drug combination (multiple-molecule
targeting drug).
Figure 1. Flowchart of systems biology method and the outline of systematic drug discovery design. The candidate
genome-wide genetic and epigenetic networks (GWGEN) consist of gene regulation network (GRN) and protein–protein
interaction network (PPIN), where candidate GRN was constructed through integrating gene regulation databases and
candidate PPIN was constructed via protein–protein interaction databases. The candidate GWGENs were identiﬁed to
obtain real GWGENs by RNA-seq data from GSE81608 through system identiﬁcation and system order detection. Then,
core GWGENs were extracted from real GWGENs by the principal network projection (PNP) method. Potential drugs were
discovered according to the signiﬁcant biomarkers determined by investigating the T2D pathogenesis constructed through
comparing core signaling pathways of non-type 2 diabetes (T2D) and T2D.

## Page 4 (Section: Results )

Int. J. Mol. Sci. 2021, 22, 166
4 of 33
 
Figure 2. The T2D pathogenic mechanism investigation by comparing the T2D and non-T2D core signaling pathways.
The genes and proteins in the core signaling pathways were chosen from the T2D and non-T2D core GWGENs. The gene
regulations and protein interactions were constructed based on the edges in core GWGENs. The blocks of light orange,
light blue, and light green background color separately indicate the T2D differential signaling pathways, the common
signaling pathways of both T2D and non-T2D, and the non-T2D differential signaling pathways, respectively. The cellular
functions caused by target genes are clustered with solid lines in different colors and referred to Uniprot. The bold
arrowhead marks in black denote the relatively low and high expression in pathogenic signaling pathways in contrast to
non-T2D.2.2. The Pathogenic Microenvironment in T2D.
Note that, to reinforce the reliability of constructed T2D pathogenic mechanism,
the collected RNA-seq data on the pancreatic β-cell was selected with age greater than or
equal to 50 years due to high incidence, and they were classiﬁed into non-T2D and T2D,
as shown in Table 1.
Table 1. Samples of RNA-seq data on pancreatic β-cells from GSE81608 were selected according to
age greater than or equal to 50 years and classiﬁed into non-T2D and T2D.
RNA-seq Data
Non-T2D
T2D
Age ≥50
86
123
Based on the information from the accessible bioinformatics databases, the candidate
GWGENs were constructed and identiﬁed by system identiﬁcation and the system order
detection method to prune off the trivial interactions and regulations. Although the
extracted GWGENs (real GWGENs plotted by Cytoscape software in Figure A1) in a
smaller scale could be apparently observed as shown in Table A1, the network complexity
it owns still blocked the further analysis. To deal with this problem, the PNP method was
applied to distill the real GWGENs into the core GWGENs, which effectively reduced the
network size and simpliﬁed the subsequent pathogenic markers and pathway analysis of
T2D. Notably, among the core GWGENs as shown in Figure A2, the top 3000 major nodes
from 85% of the real GWGENs after projection were included.

## Page 5 (Section: Results )

Int. J. Mol. Sci. 2021, 22, 166
5 of 33
Thereafter, the core GWGENs for T2D and non-T2D were projected to KEGG pathways
by DAVID software to derive the core signaling pathways in Tables 2 and 3, respectively.
According to the enrichment analysis of core T2D signaling pathways shown in Table 2,
there are 22 genes related to insulin resistance and 11 genes related to type II diabetes melli-
tus. In addition, 14 genes are associated with lipid metabolism. Such ﬁndings indicate that
pathogenic factors of diabetes are related to not only high glucose but also fat accumulation.
As a result, with the help of KEGG pathway annotation, core signaling pathways for T2D
and non-T2D were constructed and individually illustrated in Figures A3 and A4.
Table 2. KEGG pathway enrichment analysis of core T2D signaling pathways using DAVID tool.
KEGG Pathway Enrichment Analysis of T2D Core Signaling Pathways
Pathway
Gene Number
p-Value
mTOR signaling pathway
15
3.1 × 10−3
Insulin resistance
22
5.8 × 10−3
Regulation of lipolysis in adipocytes
14
6.2 × 10−3
PI3K–Akt signaling pathway
50
3.1 × 10−2
Type II diabetes mellitus
11
3.2 × 10−2
Table 3. KEGG pathway enrichment analysis of core non-T2D signaling pathways using DAVID tool.
KEGG Pathway Enrichment Analysis of non-T2D Core Signaling Pathways
Pathway
Gene Number
p-Value
Jak–STAT signaling pathway
25
3.1 × 10−2
Cell cycle
22
3.3 × 10−2
mTOR signaling pathway
12
5.4 × 10−2
p53 signaling pathway
13
6.6 × 10−2
AMPK signaling pathway
20
8.9 × 10−2
According to the T2D pathogenic signaling pathways (Figure 2), the lipid and glu-
cose metabolism pathways are found to play crucial roles in impairing the pancreatic
functions, leading to the occurrence of T2D. Lipid accumulation in the pancreas owing to
long-term excessive caloric intakes inevitably causes the burden on the pancreas β-cell,
which thereby impacts the insulin production. In our body, lipids are degraded into either
the triglycerides or the free fatty acids (FFAs). Some of them might also transform into
low-density lipoproteins (LDLs). It is known that LDLs and FFAs can act to interfere
with insulin biosynthesis, insulin secretion, and cell proliferation [15]. On the other hand,
serving as a peptide hormone to consolidate the concentration of glucose level in blood
and to stimulate the decomposition of fat, glucagon (GCG) would be suppressed to a lower
concentration due to the high glucose intake. Therefore, the ability of lipid decomposi-
tion is declined. In addition, higher glucose is often accompanied by the enrichment of
glucagon-like peptide-1 (GLP1) and insulin-like growth factor 1 (IGF1). Although the
provoked downstream pathways may expand the cell mass and enhance the capacity of
insulin secretion to balance the blood sugar level, extreme glucose intake often disturbs
homeostasis. As a result, the pancreatic β-cells cannot withstand the impact of high glucose
and lipids, and they eventually cause dysfunction.
Furthermore, the effect of immune and inﬂammatory responses should not be ne-
glected. When the pancreatic β-cells suffer damage from endoplasmic reticulum stress
(ER stress), the immune response would be activated along with the secretion of cytokine
factors, such as IL6 and FAS or chemokine CXCL10.

## Page 6 (Section: Pancreatic -Cell Proliferation and Apoptosis in the T2D Inflammatory Microenvironment )

Int. J. Mol. Sci. 2021, 22, 166
6 of 33
2.2. Pancreatic β-Cell Proliferation and Apoptosis in the T2D Inﬂammatory Microenvironment
We conducted a literature survey to outline the biological functions implied in Figure 2.
Under high glucose conditions, GLP1 and IGF1 ligands were induced to a higher level
than normal. Catalyzed by GLP1, GLP1R delivered the transduction signal via PIK3R1,
RAS, RAF1, and MEK1 to activate the MAPK pathway. The activated MAPK due to the
overexpression of GLP1 obliquely elevated the level of transcription factor (TF) ETS1,
which subsequently upregulated the target gene FOXO1 but downregulated TF FOXA2.
Emerging studies revealed that the upregulation of FOXO1 contributes to the apoptosis of
the pancreatic β-cell, concurrently alleviating cell proliferation [16]. In addition, serving as
an important TF in pathogenic pathways, FOXO1 could suppress TF GSK3B to elevate
PDX1 expression, where GSK3B is a negative regulator, and its downregulation maintains
PDX1 protein stability to delay its phosphorylated degradation [17]. As a critical regulator
in pancreatic β-cell development, PDX1 is responsible for cell proliferation and insulin
secretion [18]. However, it has been reported that a decreased FOXA2 could reduce its
binding to the PDX1 promoter [19], holding an antagonism. If without sufﬁcient PDX1,
pancreatic β-cells cannot repair the damage from cell apoptosis and peroxide [20]. It has
been validated that the AKT1 activates the downstream protein MTOR through TSC2 and
RHEB and simultaneously upregulates TF FOXO1, which is phosphorylated by kinase
PHKB [21,22]. In T2D, MTOR phosphorylated S6KB1, and it is well documented that this
upregulation expands the cell size and number of pancreas for producing more insulin
and maintaining the pancreatic function to decompose the glucose [23]. Among signaling
transductions associated with pancreatic β-cell survival, upon receiving the signal from
ligand low-density lipoprotein (LDL), receptor LDLR stimulated MIR24 to restrain the
transcription of target gene IRE1. Notably, the inhibition of IRE1 protects the pancreatic
β-cell from ER stress-induced apoptosis while accelerating the impairment of insulin
secretion [24].
Furthermore, the inﬂuence of AKT1-dependent immune response, FFA-induced,
and MAPK-relevant pathways occupied a key position on cell survival. In the AKT1 path-
way, PDK1 suppressed TF IKK phosphorylation degradation through SGK1. SGK1 plays
a role in anti-inﬂammation, since it impedes the apoptotic promoter NF-κB from translo-
cation to mitigate its ability for inﬂammatory cytokines transcription [25]. In contrast,
the MTOR pathway and CXCL10-mediated MYD88 signaling both enhanced the nuclear
translocation of NF-κB through IKK. It can initiate immune response, contributing to the
cell inﬂammation and apoptosis [26,27]. NF-κB is a double-edge sword in immune modu-
lation. In general, NF-κB-dependent transcription not only accelerates the anti-apoptosis
mechanism in favor of cell survival but also augments the inﬂammatory response, lead-
ing to cell death. Nevertheless, in T2D, the absence of anti-apoptosis pathways pertaining
to NF-κB was found.
On top of that, FFA mediated the reduction of AKT1 phosphorylation by JUNB and
XBP1, hence weakening the transcriptional ability of AKT1.
Concerning cell death, the members of the CASP family count for a great deal in
inducing apoptosis when stimulated by exogenous and endogenous environmental factors.
The IGF1 signal indirectly induced the NEDD8 activation and further upregulated the
inﬂammatory mediator CASP1, resulting in an aggravated inﬂammation response [28].
Another CASP member, CASP8, could be triggered by the FASL-stimulated apoptotic
pathway as well, causing the inception of cell inﬂammatory response and apoptosis. On the
other hand, as a typical hallmark of apoptosis in the CASP family, CASP3 could be indirectly
activated by IL6. Although IL6 might upregulate AKT1 activity to raise the cell proliferation
through JAK2-induced demethylation, IL6 inhibited the key controller of anti-apoptosis
BCL2 through STAT3 downregulation. It is worth noting that from the non-T2D signaling
pathway, IL6 was characterized as an anti-inﬂammatory cytokine and indirectly interacted
with ISL1 and SETD7 to activate PDX1, intensifying cell proliferation. Moreover, the FFA-
dependent ER stress could also interrupt the STAT3-dependent signaling, which causes
the blockade of cellular defensive machinery from BCL2. The inhibited BCL2 activated

## Page 7 (Section: Abnormality in Insulin Synthesis and Insulin Secretion )

Int. J. Mol. Sci. 2021, 22, 166
7 of 33
the caspase cleavage TF SP1 and obliquely its target gene CASP3, resulting in apoptosis,
which has been suggested through opening the channel on mitochondria membrane to
secret CYCS [29].
2.3. Abnormality in Insulin Synthesis and Insulin Secretion
Insulin synthesis and secretion are signiﬁcant and indispensable modulation functions
in the pancreas. Without sufﬁcient insulin, the pancreas is not able to effectively decom-
pose glucose to generate enough energy for cell tissues. In T2D, there exist confrontations
between the glucose-induced promotion of insulin and the apoptosis-triggered reduction
of insulin secretion. From the pathogenic signaling pathways shown in Figure 2, the high
expression of phosphorylated PDK1 interacted with TF SGK1 to prompt the upregulation
of PLD1, which has previously been described to facilitate insulin secretion [30]. Likewise,
the increment of insulin production could also be triggered by GCG-stimulated TF MAFA
activation pathway through signaling cascades GPR52, ABCB1, CAMP, PKA, and CREB1.
This ﬁnding is in line with the observation of a study that GCG level rises in response to
lipid metabolism when lipids accumulate in the pancreas [31]. Furthermore, the upreg-
ulated SGK1 inhibited NEDD4 to accelerate the GLUT1 deubiquitylation, promoting the
insulin secretion. On the other hand, as the ubiquitin ligase, COP1, its inhibition induced
by the GLP1-stimulated MAPK pathway could attenuate the degradation of negative
modulator ETV1 and impel its target gene EXOC6 to overexpress, therefore weakening the
ensuing insulin secretion stimulation.
Meanwhile, in contrast to the upregulation of GLUT1, the target gene GLUT2 was
repressed by PPARγ through both the signaling cascades: one via FFA-dependent FFAR1
and FABP5 signal transduction; the other via the decrement of TF PGC1α transcriptional
ability through GLP1-catalyzed deacetylated enzyme SIRT upregulation. Consequently,
the loss of GLUT2 gave rise to a drop on insulin secretion. Furthermore, miRNAs also play a
key role in the pancreas to regulate insulin synthesis and secretion. An abnormal expression
of miRNAs often arouses repercussion. Despite holding the potency to prevent pancreatic
β-cells from apoptosis through IRE1 inhibition [24], MIR24 was inevitably induced by
LDL to dampen insulin synthesis through triggering MAFA downregulation. Aside from
that, acting as a downstream of MAPK signaling cascades, when activated, MIR29B2 kept
its target MCT1 (SLC16A1, a plasma membrane monocarboxylate transporter to manage
the exocrine function of insulin) from expression, thereby resulting in the interruption of
insulin secretion [32].
2.4. Potential Multiple-Molecule Targeting Drug for T2D Utilizing Systematic Drug
Discovery Approach
According to the investigation of the pathogenic mechanism, the primary progression
of T2D stemmed from excessive inﬂammation and cell apoptosis owing to fat accumulation
in the pancreas. Moreover, an over intake of glucose pressures the pancreas to overwork,
therefore leading to dysfunction. In line with this notion, signiﬁcant biomarkers related
to fat accumulation, cell inﬂammation, and apoptosis were selected. Then, we used these
biomarkers to search for favorable compounds that can serve as potential therapy of T2D.
Consequently, we took IKK, STAT3, FAS, ETS1, and PPARγ as biomarkers and sought
to reverse their expression levels. Amongst them, IKK, STAT3, and FAS are pertinent to
pancreas inﬂammation and death; ETS1 is responsible for pancreas proliferation; PPARγ
can regulate the glucose ﬂux into the pancreas through the channel protein GLUT2 and
therefore stimulate insulin secretion.
After deﬁning these potential biomarkers as drug targets, we select candidate drugs by
drug repositioning, with consideration of their chemical properties. On one hand, a deep
neural network (DNN)-based DTI model was pretrained to predict drug–target binding
likely to exist; on the other, drug design speciﬁcations, i.e., regulation ability, toxicity,
sensitivity, and side effect were further exploited to sieve out potential drugs for designing
a multiple-molecule targeting drug for T2D treatment before clinical trials. The ﬂowchart
of systematic drug discovery and design procedure is described in Figure 3.

## Page 8 (Section: Abnormality in Insulin Synthesis and Insulin Secretion )

Int. J. Mol. Sci. 2021, 22, 166
8 of 33
 
Figure 3. The ﬂowchart of systematic drug discovery and design procedure. The drug–target binding datasets were
obtained from BindingDB, which integrated substantial information of drugs and targets from several databases. Then,
the drug and target features were sequentially preprocessed through descriptor transformation, standardization, and PCA
dimension reduction. Afterwards, the processed data were split into training and testing data for deep neural network
(DNN)-based drug–target interaction (DTI) model training and performance evaluation, respectively. During the training
process, the model parameters were updated through the error between the true binding label and predicted binding label
of each drug–target pair. The well-trained DNN-based DTI model was used to predict the binding probability between
drugs and the identiﬁed biomarkers to sift out candidate drugs. Finally, with the consideration of drug design speciﬁcations
including regulation ability, toxicity, sensitivity, and side effect, potential drugs were selected and integrated for novel
medication therapy curing T2D.
From our DNN-based DTI model (Figure 4), we set four hidden layers, and each of
them is connected with a ReLU activation function layer behind. The ReLU activation
function could avoid vanishing gradient problems and converge much faster than the other
activation functions adopted to deal with classiﬁcation issues [33]. Meanwhile, to hinder the

## Page 9 (Section: Abnormality in Insulin Synthesis and Insulin Secretion )

Int. J. Mol. Sci. 2021, 22, 166
9 of 33
model from overﬁtting during the training process, the dropout layer is incorporated after
each hidden layer. The dimension of the input layer is 618, corresponding to the features
size of the drug–target pair, and 512, 256, 128, and 64 neurons are embedded respectively
in the four hidden layers. Prior to the output layer, a sigmoid activation function is applied
to limit the value within the range between 0 and 1 (probability). Note that a sigmoid
function is commonly used in binary classiﬁcation problems. The outcome of DTI indicates
the likelihood of a binding, where a higher value corresponds to a more reliable interaction
(binding) between the drug and target. The loss and accuracy during the training process
are recorded in Figures 5 and 6, respectively. The well-trained DTI model was supervised
through applying the 10-fold cross-validation to evaluate the model performance, as shown
in Table 4. Eventually, we received an average accuracy of 94.89 (%) with the standard
deviation of 0.156 (%), and the model with best testing performance was picked as our
DTI model.
 
Figure 4. The schematic diagram of the DNN-based DTI model.
Figure 5. Training and validation loss of DNN-based DTI model (10-fold cross-validation).

## Page 10 (Section: Abnormality in Insulin Synthesis and Insulin Secretion )

Int. J. Mol. Sci. 2021, 22, 166
10 of 33
Figure 6. Training and validation accuracy of DNN-based DTI model (10-fold cross validation).
Table 4. 10-fold cross-validation measure for the DNN-based DTI model.
Model Performance (10-Fold Cross-Validation)
Validation Loss
Validation
Accuracy (%)
Testing Loss
Testing
Accuracy (%)
1
0.148
95.23
0.159
94.87
2
0.151
94.93
0.150
95.05
3
0.159
94.58
0.155
94.69
4
0.155
94.73
0.161
94.68
5
0.154
94.75
0.156
94.91
6
0.147
94.91
0.155
94.95
7
0.164
94.74
0.157
94.96
8
0.162
94.56
0.158
94.82
9
0.151
95.18
0.155
95.06
10
0.142
95.2
0.153
94.94
Average
0.153
94.88
0.156
94.89
Standard
deviation
0.007
0.252
0.003
0.131
The far-left column recorded the numbers of 10-fold cross-validation models. The block with values
in bold denotes the model with best testing accuracy in contrast to the other models and is chosen as
the well-trained DTI model for drug–target binding prediction.
Furthermore, we also compared the DNN-based DTI model with other DTI models
based on machine learning classiﬁcation approaches, such as random forest, K-nearest
neighbor (KNN), and Support Vector Machine (SVM) by the receiver operating charac-
teristic (ROC) curve measure. The visualization of ROC curve comparison is denoted in
Figure 7. From the ﬁgure, the performance of our proposed DTI model is apparently better
than the others, which indicates that the deep learning algorithm greatly adapts to the
calculation of the overwhelming and complicated drug–target interaction data in contrast
to other traditional machine learning methods.

## Page 11 (Section: Abnormality in Insulin Synthesis and Insulin Secretion )

Int. J. Mol. Sci. 2021, 22, 166
11 of 33
Figure 7. The receiver operating characteristic (ROC) curves and AUC (area under the curve) scores for DTI model based
on DNN, random forest, K-nearest neighbor (KNN) and Support Vector Machine (SVM). The dotted line on the diagonal
indicates the virtual model without predicted value due to random prediction and is the boundary for judging whether the
model performs well. On the upper left of the dotted line, the model is better than the randomly predicted model; contrarily,
on the right lower of the dotted line, the model is worse than the randomly predicted model. The “area” in the parenthesis
of each label denotes the AUC score.
Through the prediction of the pretrained DNN-based DTI model, candidate drugs
were sieved out owing to possessing high probability to bind (dock) to the selected biomark-
ers. However, the balance between the drug potency and adverse effect should also be
concerned, since potent drugs are usually accompanied with a high risk of damage. Accord-
ingly, with the consideration of the drug design speciﬁcations such as regulation capacity,
toxicity, sensitivity, and side effect, we could further assure the stability and safety of drugs
in clinical trials. For the purpose of measuring the regulation capacity of candidate drugs,
the available data with well-documented regulation ability information was downloaded
from L1000 level 5 dataset, which contains 978 genes treated with 19,811 small molecular
compounds in 78 different cell lines [34]. By referring to LINCS L1000, we can examine
whether a speciﬁc gene was upregulated (positive values) or downregulated (negative
values) after being treated with an existing compound. On the other hand, the drug with
lower toxicity often possesses a smaller side effect with reference to the median lethal dose
(LD50) value in DrugBank. Being the numeric index of lethality, LD50 plays a pivotal
role in drug safety evaluation. Further, administering a drug with higher drug sensitivity
(a lower value of half maximal effective concentration (EC50)) could also cut down the
dosage of the drug and further mitigate the ensuing side effect [35]. Within, the drug
sensitivity data were collected from the PRISM dataset, which includes 4518 drugs being
experimented across 578 human cell lines based on the EC50. EC50 is used to measure
the potency of a drug, where a drug with smaller EC50 implies that it could exert the
maximum effect with a lower dose [36]. On top of that, we deﬁned the side effect of each
drug as its additional binding to other targets rather than the desired biomarkers. The fewer
unwanted targets the drug binds, the smaller it affects other pathways. The side effects

## Page 12 (Section: Abnormality in Insulin Synthesis and Insulin Secretion )

Int. J. Mol. Sci. 2021, 22, 166
12 of 33
for the candidate drugs are denoted in Table 5, and further information of the proposed
candidate drugs for the identiﬁed biomarkers were presented in Table 6. Leveraging these
pharmacological properties from databases, appropriate drugs were plausibly selected
from Tables 5 and 6 to meet the drug design speciﬁcations. Ultimately, we suggested a
combination of Sulforaphane and Biotin as our potential multiple-molecule targeting drug
for T2D.
Table 5. The side effect for candidate drugs on core signaling pathways.
Candidate Drugs
Binding Biomarkers
Binding Numbers Except
Desired Target Biomarkers
in Core Signaling Pathways
Anisomycin
IKK, STAT3, PPARγ, ETS1, FAS
37
* Sulforaphane
IKK, STAT3, PPARγ, ETS1, FAS
23
Memantine
IKK, STAT3
11
Trimetozine
IKK, STAT3, PPARγ
14
* Biotin
IKK, STAT3, PPARγ, ETS1
19
Gabexate
IKK, STAT3, PPARγ, ETS1
31
Famotidine
IKK, STAT3, PPARγ, ETS1
25
Cilostazol
IKK, STAT3, PPARγ, ETS1
26
Acetylcysteine
IKK, STAT3, PPARγ, ETS1, FAS
41
The side effect of a drug is deﬁned as the number of targets except the desired biomarkers. The
candidate drugs with ‘*’ are selected as our potential drugs for T2D.
Table 6. The candidate drugs for T2D and their corresponding information.
Candidate
Drugs
Regulation Ability to Speciﬁc Biomarkers
Toxicity
(LD50, moL/kg)
Sensitivity
(EC50)
IKK
STAT3
PPARγ
ETS1
FAS
Anisomycin
0.822
0.809
3.622
5.507
−0.184
3.535
−1.099
*
Sulforaphane
−0.029
0.079
0.075
0.089
−0.059
3.110
−0.008
Memantine
−0.997
0.707
2.346
−0.383
Trimetozine
−0.724
0.650
0.489
2.148
−0.851
* Biotin
−1.214
1.075
0.969
−0.986
2.058
−0.249
Gabexate
−1.324
−0.942
1.237
−2.151
1.999
−0.229
Famotidine
−0.693
0.356
−1.004
−0.119
1.952
−0.548
Cilostazol
−0.570
−1.622
0.387
−1.222
1.889
−0.141
Acetylcysteine
−0.788
0.645
−0.620
1.923
−1.000
1.294
−0.554
Some of the candidate drugs are denoted and ranked based on their toxicity. The regulation ability block without values represented that no
binding between the drug and target existed. The blocks with values in bold indicate unwanted regulations. The positive value of regulation
ability signiﬁes the positive regulation, whereas the negative value denotes the downregulation. For each drug, the larger LD50 value it possesses,
the lower toxicity it has; the smaller LD50 value it owns, the higher efﬁcacy (sensitivity) it holds. The candidate drugs with ‘*’ are selected as the
potential drugs.
Sulforaphane is a natural edible substance isothiocyanate produced by the enzymatic
action of the myrosinase on glucopharanin, which is a 4-methylsulﬁnylbutyl glucosino-
late contained in cruciferous vegetables of the genus Brassica such as broccoli, brussel
sprouts, and cabbage. Several experiments have validated that Sulforaphane mitigates
oxidative stress and protects cells from damage by invaded tumors and diseases [37].
Biotin, also called vitamin H, is a water-soluble B vitamin and involves a wide range of
metabolic processes in body. It plays an important role in not only the protein synthesis

## Page 13 (Section: Discussion )

Int. J. Mol. Sci. 2021, 22, 166
13 of 33
but also the fat and carbohydrate metabolism. A previous experiment in rats documented
that the insulin secretion dysfunction is related to the loss of biotin [38]. The chemical
structures of the T2D multiple-molecule targeting drug and the corresponding drug design
speciﬁcations with respect to suitable regulation ability, low toxicity, high sensitivity and
low side effect are given in Table 7.
Table 7. The drug design speciﬁcations of a potential multiple-molecule targeting drug for T2D.
Drug Names
Regulation Ability to Speciﬁc Biomarkers
Toxicity
(LD50, moL/kg)
Sensitivity
(EC50)
IKK
STAT3
PPARγ
ETS1
FAS
Sulforaphane
√
√
√
√
3.110
−0.008
Biotin
√
√
√
√
2.058
−0.249
Sulforaphane
Biotin
Binding numbers except their desired target biomarkers in core signaling pathways (side effect)
23
19
Chemical structures of multiple molecular drugs
 
‘√’ denotes the drug could bind to the biomarkers with a desired regulation capacity. Among the chemical structures of the multiple
molecular drugs, “R(CH2)nH” indicates the alkyl group; “RNCS” means the isothiocyanate group; “RSOR′” represents the sulﬁnyl group;
“R′R”NH” is the secondary amine; “RCOR′” means the carbonyl group; ‘RSR′’ is the sulﬁde group; and the “RCOOH” is the carboxyl
group.
 represents a solid wedge where the bond is pointing out toward the viewer and
indicates a hashed wedge where the bond is
receding away from the viewer.
According to Tables 5–7, the combination therapy of Sulforaphane and Biotin has the
potential to restore the abnormal regulation in T2D. The reversing of STAT3 may reduce the
cell apoptosis caused by the endogenous damage substances, and the lower expression of
FAS can decrease the cell apoptosis by the interference of an exogenous microenvironment.
In addition, the reduction of IKK expression can suppress some phosphorylated degrada-
tions, hence mitigating the formation of inﬂammatory environments and the subsequent
activation of cell apoptosis. Furthermore, the downregulation of ETS1 by the proposed
multiple-molecule targeting drug can facilitate FOXA2 to form the connection with FOXO1,
therefore enhancing the cell proliferation. The recovery expression of PPARγ can achieve
the equilibrium between glucose intake and insulin secretion. Taken together, by admin-
istering the proposed multiple-molecule targeting drug, an upregulation of STAT3 and
PPARγ accompanied by the downregulation of IKK, ETS1, and FAS can validly be attained,
yielding encouraging results for the treatment of T2D patients.
3. Discussion
3.1. The Association between Macrophage Polarization and Inﬂammatory Response in T2D
When it comes to the T2D pathogenic mechanism, the pancreatic β-cell could not
withstand the decomposition of excessive glucose in the body from long-term high glucose
intakes, leading to pancreatic β-cell exhaustion and insulin resistance. Although the accu-
mulation of glucose in the body is a crucial factor for T2D development, it is worth noting
that the inﬂammatory-dependent apoptosis stemming from the fat accumulation in the

## Page 14 (Section: The Modulation of Ion Channels Involved in Insulin Resistance and Glucose Homeostasis )

Int. J. Mol. Sci. 2021, 22, 166
14 of 33
pancreatic β-cell is also a pivotal issue. In T2D speciﬁc signaling pathways, FFA produced
by the hydrolysis of oils and fats not only disrupted the glucose homeostasis but also
increased the ER stress to indirectly trigger the follow-up inﬂammatory response, i.e., IKK-
induced NF-κB pathway and apoptotic pathways related to the CASP family. Additionally,
to form the inﬂammatory microenvironment, the immune response is initiated to activate
the releasing of pro-inﬂammatory cytokines such as IL-1β and IL-6 when damage and
infection occur.
Among all types of immune cells, macrophages exert a signiﬁcant effect on pancreatic
β-cells in T2D. Macrophages are mononuclear phagocytic cells and widely distributed
in human organs. They play an indispensable role in physiological homeostasis, im-
mune surveillance, and cell regeneration. There are mainly two types, M1- and M2-type
macrophage, existing in the pancreas. M1-type macrophages are referred to as “pro-
inﬂammatory macrophages” that can activate inﬂammatory response and recruit T-cells
and natural killer cells to eliminate the harmful substance [39]. However, excessive in-
ﬂammation stimulated by cytokine and chemokine often inevitably causes great harm to
health. Conversely, M2-type macrophages named “anti-inﬂammatory macrophages” can
primarily mediate the side effect arising from the inﬂammatory and immune response [40].
Under a high glucose and fat environment, glucotoxicity and lipotoxicity in response to the
damage infringe the stability of pancreatic β-cell, so that the accumulation of intracellular
stress including the oxidative and ER stress intensiﬁes [41]. Moreover, the intracellular
stress can modulate the polarization of macrophage from M2-type to M1-type, causing
the imbalance in the ratio of M1-type/M2-type macrophages. Consequently, the num-
ber of M1-type macrophages residing in the pancreatic β-cell outweighs that of M2-type
macrophages to induce pancreatic β-cell toward inﬂammatory-dependent apoptosis and
pancreatic function impairment, which further strengthens the investigation of pancreatic
β-cell destruction by apoptosis and inﬂammation in the T2D pathogenic mechanism.
3.2. The Modulation of Ion Channels Involved in Insulin Resistance and Glucose Homeostasis
Nutrients and chemical substances are essential to sustain cell stability and survival.
The ways for substances intakes from the extracellular space into cells consist of the
diffusion across the plasma membrane and the transmission on it via channel proteins.
As modulators of ion channels residing on the plasma membrane, the GLUT family, i.e.,
GLUT1 and GLUT2, stood out as crucial factors to maintain the equilibrium between the
glucose uptake and insulin secretion in the T2D pathogenic mechanism. As the result
of high glucose intakes, GLUT1 and GLUT2 increase the ratio of ATP/ADP, leading to
inducing the electrical and transductive signal to inactivate the KATP+ ion channel protein,
a modulator of K+ ﬂux in cells [42]. Then, the inactivated KATP+ channel further activates
the opening of the Ca2+ ion channel, elevating the concentration of Ca2+ to promote insulin
secretion [43]. However, in the aforementioned pathogenic signaling pathways of T2D,
FFA-dependent pathway inhibited GLUT2 to reduce the sensitivity of insulin secretion via
pancreatic β-cell in response to glucose accumulation. This phenomenon has also been
reported in diseases related to glycogen metabolism and metabolic disorders [44]. It is
also commonly found in T2D and should be taken into consideration when performing its
medical treatment.
3.3. Potential Multiple-Molecule Targeting Drug for to the Identiﬁed Biomarkers of T2D
In recent years, pharmacology companies have devoted to the discovery and design of
drugs for T2D treatment, e.g., Metformin, Sulfonylureas, Meglitinides, Thiazolidinediones,
DPP-4 inhibitors, GLP-1 receptor agonists, etc. Metformin is the ﬁrst-line medication for the
treatment of T2D, working for lowering the production of glucose in liver and improving
insulin sensitivity. In spite of holding promising efﬁcacy, it can give rise to acute pancreatitis
if overdosed [45,46]. Adjuvant medication therapy with either Sulfonylureas such as
Glucotrol or Meglitinides such as Repaglinide can effectively stimulate pancreas β-cells to
secrete more insulin in the short term; however, Sulfonylureas can cause the progressive

## Page 15 (Section: Materials and Methods )

Int. J. Mol. Sci. 2021, 22, 166
15 of 33
dysfunction of pancreas β-cells in a long-term treatment. Furthermore, they also aggravate
the risk of gaining weight and lowering blood glucose levels [47,48]. Thiazolidinediones
is an analogue of Metformin, rendering tissues more sensitive to the insulin. However,
it may as well result in overweight and even severe side effects, i.e., heart failure and
anemia. DPP-4 inhibitors that prevent DPP-4 from degrading GLP-1, e.g., Sitagliptin,
and GLP-1 receptor agonists that affect GLP-1 to last longer, e.g., Liraglutide, are of
particular interest for their glucose-lowering effects, which are useful to the treatment of
T2D [49]. Although they are at very low risk of hypoglycemia and are also known to help
with weight loss, these medications might lead to gastrointestinal disorders, e.g., nausea,
diarrhea, or constipation, and overdosage often increases the probability of pancreatitis
occurrence [50,51]. SGLT2 inhibitors are one of the newer medications used to lower blood
sugar in patients with T2D. Unlike most anti-diabetic drugs that work by either increasing
insulin in the body or increasing the insulin sensitivity of cells, SGLT2 inhibitors, e.g.,
Dapagliﬂozin, Canagliﬂozin, Empagliﬂozin, etc., cause kidneys to excrete glucose into
urine to reduce the blood sugar level [52]. However, excess sugar in urine creates a cozy
environment for bacteria and fungi to thrive in the urinary tract or genital area, giving rise
to urinary tract infection (about 50% greater in patients with diabetes) [53]. In addition,
some patients may experience increased frequency of urination, which leads to lower blood
pressure due to the loss of ﬂuids; others may notice a slight increase in their cholesterol
values [54]. Therefore, discovering effective treatments and promising medications for T2D
is still needed.
The proposed drug combination of Sulforaphane and Biotin not only is natural and
readily available from daily life but also holds a chance to keep the body from inﬂammatory-
dependent apoptosis and fat accumulation. Although further evaluation in clinical trials is
still needed and the potential side effects after consuming should be monitored, the new-
found medication indeed brings hope to improve T2D management.
4. Materials and Methods
4.1. Overview the Procedure of Systems Biology and Systematic Drug Discovery and Design for
Type 2 Diabetes (T2D) and Non-T2D
To investigate and gain much more understanding of the T2D pathogenesis, we ap-
plied a systems biology approach [55] to build core signaling pathways and explored
discrepancies between non-T2D and T2D from the perspective of molecular genetics and
epigenetics. Furthermore, a systematic drug discovery procedure was proposed to dis-
cover and design a promising drug combination for treating T2D. Notably, drug design
speciﬁcations were further utilized for screening potential drugs from predicted candidate
drugs. The procedure of a systems biology approach and the outline of systematic drug
discovery and design method is shown in Figure 1 and subdivided into a few steps:
4.1.1. The Construction of Candidate GWGENs
The candidate protein–protein interaction network (PPIN) and candidate gene regula-
tory network (GRN) were constructed and integrated into GWGEN for non-T2D and T2D
respectively by mining the protein–protein interaction and gene regulation databases.
4.1.2. The Identiﬁcation of Real GWGENs
The system identiﬁcation and system order detection method Akaike information cri-
terion (AIC) are used to remove the false positive protein interactions and gene regulations
in candidate GWGENs to obtain the real GWGENs via the RNA-seq data downloaded
from NCBI GSE81608.
4.1.3. Extracting Core GWGENs by Principal Network Projection (PNP) Method
The core GWGENs were obtained through extracting 85% of the principal network
components consisting of the top 3000 proteins, genes, miRNAs, and lncRNAs by the PNP
method from the viewpoint of network signiﬁcance.

## Page 16 (Section: The Explorations of Core Signaling Pathways )

Int. J. Mol. Sci. 2021, 22, 166
16 of 33
4.1.4. The Explorations of Core Signaling Pathways
According to the nodes and edges in core GWGENs and the KEGG pathways annota-
tions, the core signaling pathways were established for T2D and non-T2D. Subsequently,
we investigated the genetic and epigenetic pathogenic mechanism by comparing their core
signaling pathways.
4.1.5. Potential Multiple-Molecule Targeting Drug Discovery
The deep neural network (DNN) was trained for the drug–target interaction model
(DTI) via the drug–target interaction database. With the help of the DTI model, drugs hav-
ing the possible interactions with biomarkers were predicted to be the candidate drugs.
Then, the potential multiple-molecule targeting drug was selected for T2D treatment before
clinical trials from the candidate drugs according to the drug design speciﬁcations of drug
regulation ability, toxicity, sensitivity, and side effect.
4.2. Data Mining, Preprocessing and Candidate GWGENs Construction
In our research, the dataset with accession number GSE81608 was downloaded from
the gene expression omnibus (GEO) of the National Center for Biotechnology Information
(NCBI), and its relevant experimental platform was GPL16791. The dataset contained
mRNA expression levels of genes, proteins, miRNAs, TFs, receptors, and lncRNAs in
pancreatic α-cell, β-cell, δ-cell, and PP-cell. The samples of the dataset were assorted
into two categories, i.e., T2D and non-T2D. In this study, to identify the T2D pathogenic
mechanism on the pancreatic β-cell, the samples of the subtype β-cell were speciﬁcally
extracted from the original experimental data. Furthermore, according to the WHO report,
the age distribution of incidence in diabetes is at the range of approximately 50 years old
and older. Therefore, 86 and 123 samples were chosen respectively for T2D and non-T2D
with age equal to or greater than to 50 years old. Then, we constructed the candidate PPIN
based on the Database of Interacting Proteins (DIP) [56], IntAct [57], the Biological General
Repository for Interaction Datasets database (BioGRID) [58], the Biomolecular Interaction
Network Database (BIND) [59], and the Molecular INTeraction Database (MINT) [60].
In addition, the candidate GRN was built based on the Integrated Transcription Factor
Platform database (ITFP) [61], the Human Transcriptional Regulation Interactions database
(HTRI) [62], and the TRANScription FACtor database (TRANSFAC) [63]. MiRNAs and
lncRNAs regulations in GRN were referenced to the TargetScanHuman database [64],
CircuitsDB [65], and StarBase2.0 [66].
4.3. Constructing the Systematic Model for the Candidate GWGEN of T2D and Non-T2D
For the purpose of imitating the human cellular system, we built the stochastic inter-
active and regulatory models to describe the candidate GWGEN. The candidate GWGEN
was composed of PPIN containing the protein–protein interactions and GRN containing
the regulations of genes, miRNAs, and lncRNAs. Next, we described the interactions
of proteins and regulations of genes, lncRNAs, and miRNAs using the protein–protein
interactive model (PPIM), gene regulatory model (GRM), lncRNA regulatory model (LRM),
and miRNA regulatory model (MRM) in detail.
First, the q-th protein in PPIM can be described as the following equations:
pq[n] =
Gq
∑
r = 1
r̸ = q
κqrpq[n]pr[n] + λq,PPIM + µq,PPIM[n], for q = 1, . . . , Q, n = 1, . . . , N (1)
where pq[n] indicates the expression level of the q-th protein in the n-th sample and
pr[n] indicates the expression level of the r-th protein in the n-th sample; κqr denotes the
interaction ability between the q-th protein and the r-th protein; Gq represents the total
number of proteins that interact with the q-th protein; Q denotes the total number of

## Page 17 (Section: The Explorations of Core Signaling Pathways )

Int. J. Mol. Sci. 2021, 22, 166
17 of 33
proteins in candidate PPIM; N means the total number of samples in our data; λq,PPIM
shows the basal level in the model of the q-th protein due to unknown protein interactions
of histone modiﬁcations such as phosphorylation and acetylation; and µq,PPIM[n] expresses
the data noise of the q-th protein.
Second, the transcriptional regulation of the x-th gene in GRM is given as below:
gx[n] =
Ux
∑
u = 1
u̸ = x
αxutu[n] +
Vx
∑
v=1
βxvlv[n] −
Wx
∑
w=1
γxwmw[n]gx[n] + λx,GRM + µx,GRM[n]
, for x = 1, . . . , X, n = 1, . . . , N
(2)
where gx[n] denotes the expression level of the x-th gene in the n-th sample; tu[n], lv[n],
and mw[n] individually indicate the expression level of the u-th TF, the v-th lncRNA and
the w-th miRNA of the n-th sample; Ux, Vx, and Wx separately mean the total binding
number of TFs, lncRNAs and miRNAs; αxu shows the transcriptional regulatory ability
from the u-th TF to the x-th gene; βxv represents the transcriptional regulatory ability from
the v-th lncRNA to the x-th gene; γxw≥0 expresses the post-transcriptional regulatory
ability of the w-th miRNA on the x-th gene; X denotes the total number of gene in GRNs; N
indicates the total number of data samples; λx,GRM means the basal level of the x-th gene
because of the unknown gene regulations such as methylation; and µx,GRM[n] is the data
noise.
Third, TFs, lncRNAs, and miRNAs also have a potential impact on the i-th lncRNA
and we can depict this behavior by the LRM in candidate GWGENs. The equation is
obtained as follows:
li[n] =
Ui
∑
u=1
σiutu[n] +
Vi
∑
v = 1
v̸ = i
ςivlv[n] −
Wi
∑
w=1
τiwmw[n]li[n] + λi,LRM + µi,LRM[n]
, for i = 1, . . . , I, n = 1, . . . , N
(3)
where li[n] indicates the expression level of the i-th lncRNA; tu[n], lv[n], and mw[n] repre-
sent the expression level of the u-th TF, the v-th lncRNA, and the w-th miRNA of the n-th
sample, respectively; Ui, Vi, and Wi individually show the total binding number of TFs,
lncRNAs and miRNAs. σiu expresses the transcriptional regulatory ability from the u-th TF
to the i-th lncRNA; ςiv means the transcriptional regulatory ability from the v-th lncRNA
to the i-th lncRNA; τiw ≥0 denotes the post-transcriptional regulatory ability from the
w-th miRNA to the i-th lncRNA; I is the total number of lncRNAs and N indicates the total
number of samples; λi,LRM denotes the basal level of the i-th lncRNA; µi,LRM[n] expresses
the data noise.
Fourth, the expression of the j-th miRNA is also affected by the TFs, lncRNAs, and
miRNAs. Furthermore, we can illustrate MRM in candidate GWGENs through the follow-
ing equation:
mj[n] =
Uj
∑
u=1
ωjutu[n] +
Vj
∑
v = 1
v̸ = j
ξjvlv[n] −
Wj
∑
w=1
ψjwmw[n]mj[n] + λj,MRM + µj,MRM[n]
, for j = 1, . . . , J, n = 1, . . . , N
(4)
where mj[n] means the expression level of j-th miRNA; tu[n], lv[n], and mw[n] separately
represent the expression level of the u-th TF, the v-th lncRNA and the w-th miRNA,
respectively; Uj, Vj, and Wj show the binding total number of TFs, lncRNAs and miRNAs;
ωju denotes the transcriptional regulatory ability from the u-th TF to the j-th miRNA;
ξjv expresses the transcriptional regulatory ability from the v-th lncRNA to the j-th miRNA;
ψjw indicates the post-transcriptional regulatory ability from the w-th miRNA to the j-th

## Page 18 (Section: The System Identification and System Order Detection Methods for Real GWGENs Identification )

Int. J. Mol. Sci. 2021, 22, 166
18 of 33
miRNA; J is the total number of miRNAs and N indicates the total number of samples;
λj.MRM is the basal level of the j-th miRNA; µj,MRM[n] denotes the data noise.
4.4. The System Identiﬁcation and System Order Detection Methods for Real GWGENs
Identiﬁcation
According to the above stochastic models, PPIM in (1) composed the candidate PPIN;
GRM in (2), LRM in (3), and MRM in (4) constituted the candidate GRN. We made use of
the system identiﬁcation and system order detection methods to obtain the real GWGENs
of T2D and non-T2D by the corresponding RNA-seq data, respectively. In order to identify
the parameters of these stochastic models, Equations (1)–(4) could separately be rewritten
as the following linear regression forms.
pq[n] =
h
pq[n]p1[n]
pq[n]p2[n]
· · ·
pq[n]pGq[n]
1
i
×


κq1
κq2
...
κqGq
λq,PPIM


+ µq,PPIM[n]
(5)
gx[n] =

t1[n]
· · ·
tUx
l1[n]
· · ·
lVx
m1[n]gx[n]
· · ·
mWx[n]gx[n]
1
 ×


αx1
...
αxUx
β1
...
βxVx
−γ1
...
−γxWx
λx,GRM


+ µx,GRM[n]
(6)
li[n] =

t1[n]
· · ·
tUi
l1[n]
· · ·
lVi
m1[n]li[n]
· · ·
mWi[n]li[n]
1
 ×


αi1
...
αiUi
β1
...
βiVi
−γ1
...
−γiWi
λi,LRM


+ µi,LRM[n]
(7)
mj[n] =
h
t1[n]
· · ·
tUj
l1[n]
· · ·
lVj
m1[n]mj[n]
· · ·
mWj[n]mj[n]
1
i
×


αj1
...
αjUj
β1
...
βjVj
−γ1
...
−γjWj
λj,MRM


+ µj,MRM[n]
(8)

## Page 19 (Section: The System Identification and System Order Detection Methods for Real GWGENs Identification )

Int. J. Mol. Sci. 2021, 22, 166
19 of 33
for q = 1, . . . , Q, x = 1, . . . , X, i = 1, . . . , I, j = 1, . . . , J, n = 1, . . . , N, where (5), (6),
(7), and (8) are separately regression forms for PPIM, GRM, LRM, and MRM. Q, X, I, and J
are respectively the total number of proteins, genes, lncRNAs and miRNAs in the candidate
GWGWN, and N is the total number of samples.
The linear regression forms in (5), (6), (7), and (8) could be simpliﬁed as the follow-
ing formulas:
pq[n] = φq,PPIM[n] · θq,PPIM + εq,PPIM, for q = 1, . . . , Q
(9)
gx[n] = φx,GRM[n] · θx,GRM + εx,GRM, for x = 1, . . . , X
(10)
li[n] = φi,LRM[n] · θi,LRM + εi,LRM, for i = 1, . . . , I
(11)
mj[n] = φj,MRM[n] · θj,MRM + εj,MRM, for j = 1, . . . , J
(12)
where the Φq,PPIM[n], Φx,GRM[n], Φi,LRM[n], and Φj,MRM[n] individually denote the regres-
sion vectors of proteins, gene, lncRNAs, and miRNAs in the n-th sample; θq,PPIM means the
parameter vector of the protein-protein interaction abilities and protein basal levels; θx,GRM,
θi,LRM, and θj,MRM are the parameter vector of the transcriptional regulatory abilities and
basal levels of the genes, lncRNAs, and miRNAs, respectively; εq,PPIM, εx,GRM, εi,LRM, and
εj,MRM are individually the data noise for PPIM, GRM, LRM and MRM.
For N samples, the above regression equations are given as below:


pq[1]
pq[2]
...
pq[N]

=


φq,PPIM[1]
φq,PPIM[2]
...
φq,PPIM[N]

· θq,PPIM +


εq,PPIM[1]
εq,PPIM[2]
...
εq,PPIM[N]

, for q = 1, . . . , Q
(13)


gx[1]
gx[2]
...
gx[N]

=


φx,GRM[1]
φx,GRM[2]
...
φx,GRM[N]

· θx,GRM +


εx,GRM[1]
εx,GRM[2]
...
εx,GRM[N]

, for x = 1, . . . , X
(14)


li[1]
li[2]
...
li[N]

=


φi,LRM[1]
φi,LRM[2]
...
φi,LRM[N]

· θi,LRM +


εi,LRM[1]
εi,LRM[2]
...
εi,LRM[N]

, for i = 1, . . . , I
(15)


mj[1]
mj[2]
...
mj[N]

=


φj,MRM[1]
φj,MRM[2]
...
φj,MRM[N]

· θj,MRM +


εj,MRM[1]
εj,MRM[2]
...
εj,MRM[N]

, for j = 1, . . . , J
(16)
The above equations could be individually represented as the follows:
Pq = Φq,PPIM · Θq,PPIM + Eq,PPIM, for q = 1, . . . , Q
(17)
Gx = Φx,GRM · Θx,GRM + Ex,GRM, for x = 1, . . . , X
(18)
Li = Φi,LRM · Θi,LRM + Ei,LRM, for i = 1, . . . , I
(19)
Mj = Φj,MRM · Θj,MRM + Ej,MRM, for j = 1, . . . , J
(20)
where Φq,PPIM, Φx,GRM, Φi,LRM, and Φj,MRM are separately the regression matrix of pro-
teins, genes, lncRNAs and miRNAs of N samples. Θq,PPIM, Θx,GRM, Θi,LRM, and Θj,MRM
are the corresponding interactive and regulatory parameter vectors. Eq,PPIM, Ex,GRM,
Ei,LRM, and Ej,MRM are the corresponding data noise vectors.

## Page 20 (Section: The System Identification and System Order Detection Methods for Real GWGENs Identification )

Int. J. Mol. Sci. 2021, 22, 166
20 of 33
What is worth noticing is that the maximum degree of the parameter estimation of
proteins in PPIs and genes in GRNs must be less than the samples; otherwise, it would
cause the overﬁtting problem during the process of system identiﬁcation.
Firstly, for the purpose of identifying the real GWGENs, we adopted the least square
method to estimate the parameter vectors θq,PPIM, θq,GRM, θq,LRM, and θq,MRM with nega-
tive regulation constraint on miRNA as follows:
ˆΘq,PPIM = argmin
Θq,PPIM
1
2∥Φq,PPIM · Θq,PPIM −Pq∥2
2
(21)
,
2
,
,
,
2
,
1
ˆ
argmin 2
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
subject to 
0
0
1
0
0
0
0
0
0
0
0
0
0
1
0
0
x GRM
i
i
i
x GRM
x GRM
x GRM
x
i GRM
U
V
W
G
Θ
Θ
=
Φ
⋅Θ
−










Θ
≤




























































 
(22)
,
2
,
,
,
2
,
1
ˆ
argmin 2
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
subject to 
0
0
1
0
0
0
0
0
0
0
0
0
0
1
0
0
i LRM
i
i
i
i LRM
i LRM
i LRM
i
i LRM
U
V
W
L
Θ
Θ
=
Φ
⋅Θ
−










Θ
≤




























































(23)
,
2
,
,
,
2
,
1
ˆ
argmin 2
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
subject to 
0
0
1
0
0
0
0
0
0
0
0
0
0
1
0
0
j MRM
j
j
j
j MRM
j MRM
j MRM
j
j MRM
U
V
W
M
Θ
Θ
=
Φ
⋅Θ
−










Θ
≤




























































 
(24)
Based on the above constrained optimization problems in Equations (21)–(24), we
sought out the optimal solution of the interactive ability parameters among proteins
ˆΘq,PPIM, the regulatory parameters of genes ˆΘx,GRM, lncRNAs ˆΘi,LRM and miRNAs
ˆΘj,MRM via the RNA-seq data of non-T2D and T2D, respectively. The above optimization
problems for parameter estimation could be solved by the MATLAB optimization toolbox.
Carefully, the negative inequality constraints in Equations (21)–(24) mean that the regu-
latory parameters of miRNAs should be less than or equal to zero to ensure the negative
regulation of miRNAs on genes, lncRNAs and miRNAs.
After the parameter estimation of candidate GWGENs of non-T2D and T2D by the
corresponding RNA-seq data, we used the system order detection method, AIC, to detect
the system order (the number of interactions of each protein or the number of regulations
of each gene, lncRNA and miRNA). The detailed equations of AIC for each protein, gene,
lncRNA and miRNA are shown below.
AIC(Qq) = log(Ωq,PPIM)+ 2(Gq+1)
N
, for Ωq,PPIM = (Pq−Φq,PPIM· ˆΘq,PPIM)T(Pq−Φq,PPIM· ˆΘq,PPIM)
N
(25)

## Page 21 (Section: The Principal Network Projection (PNP) Method for the Core GWGENs Extraction from Real GWGENs )

Int. J. Mol. Sci. 2021, 22, 166
21 of 33
where Ωq,PPIM means the estimated residual error of the q-th protein for the least square
parameter estimation ˆΘq,PPIM in (21) and Qq denotes the number of protein interactions
with the q-th protein.
AIC(Ux, Vx, Wx) = log(Ωx,GRM)+ 2(Ox,GRM+1)
N
, for Ωx,GRM = (Gx−Φx,GRM· ˆΘx,GRM)T(Gx−Φx,GRM· ˆΘx,GRM)
N
, Ox,GRM = Ux + Vx + Wx
(26)
where Ωx,GRM denotes the estimated residual error of the x-th gene in (22) and Ox,GRM
means the number of regulations of the genes, lncRNAs and miRNAs on the x-th gene;
ˆΘx,GRM is the estimated parameters in (22).
AIC(Ui, Vi, Wi) = log(Ωi,LRM)+ 2(Oi,LRM+1)
N
, for Ωi,LRM = (Li−Φi,LRM· ˆΘi,LRM)T(Li−Φi,LRM· ˆΘi,LRM)
N
, Oi,LRM = Ui + Vi + Wi
(27)
where Ωi,LRM shows the estimated residual error of the i-th lncRNA in (23) and Oi,LRM
indicates the number of regulations of the genes, lncRNAs and miRNAs on the i-th lncRNA;
ˆΘi,LRM expresses the estimated parameters in (23).
AIC(Uj, Vj, Wj) = log(Ωj,MRM)+
2(Oj,MRM+1)
N
, for Ωj,MRM =
(Mj−Φj,MRM· ˆΘj,MRM)T(Mj−Φj,MRM· ˆΘj,MRM)
N
, Oj,MRM = Uj + Vj + Wj
(28)
where Ωj.MRM expresses the estimated residual error of the j-th miRNA in (24) and Oj.MRM
represents the number of parameters regulations of the genes, lncRNAs and miRNAs on
the j-th miRNA; ˆΘj,MRM is the estimated parameter in (24).
According to the order detection of AIC in system identiﬁcation [67], the real order of a
system (i.e., the number of interactions of the q-th protein in (1) or the number of regulations
on the x-th in (2)) is to minimize the AIC. Therefore, the true number of interactions or
regulations for each protein, gene, lnRNA and miRNA in candidate GWGENs can be
obtained by solving the following AIC minimization problems.
Q∗
q = argmin
Qq
AIC(Gq), for q = 1, . . . , Q
(29)
U∗
x, V∗
x , W∗
x = argmin
Ux,Vx,Wx
AIC(Ux, Vx, Wx), for x = 1, . . . , X
(30)
U∗
i , V∗
i , W∗
i = argmin
Ui,Vi,Wi
AIC(Ui, Vi, Wi), for i = 1, . . . , I
(31)
U∗
j , V∗
j , W∗
j = argmin
Uj,Vj,Wj
AIC(Uj, Vj, Wj), for j = 1, . . . , J
(32)
where Q∗
q denoted the true number of protein interactions for the q-th protein; U∗
x, V∗
x , W∗
x
individually indicate the true number of regulations of genes, lncRNAs and miRNAs on
the x-th gene; U∗
i , V∗
i , W∗
i denote the true number of regulations of genes, lncRNAs and
miRNAs on the i-th lncRNA, respectively; U∗
j , V∗
j , W∗
j are separately the true number of
regulations of genes, lncRNAs and miRNAs on the j-th miRNA. Therefore, the protein–
protein interactions and gene, miRNA, and lncRNA regulations out of true order by AIC
minimization problems in (29)–(32) are considered as false positives in candidate GWGEN
of non-T2D and T2D and should be removed one by one to obtain the real GWGEN.
4.5. The Principal Network Projection (PNP) Method for the Core GWGENs Extraction from
Real GWGENs
The real GWGENs of non-T2D and T2D were compared to investigate the genetic and
epigenetic pathogenic molecular mechanism. However, it was still harder to analyze the
two larger scale and complicated real GEGENs so that we applied the principal network

## Page 22 (Section: The Principal Network Projection (PNP) Method for the Core GWGENs Extraction from Real GWGENs )

Int. J. Mol. Sci. 2021, 22, 166
22 of 33
projection (PNP) method on the basis of the singular value decomposition (SVD) to extract
the core GWGENs from the real GWGENs. Before studying the core network extraction in
depth, we will start by introducing the real GWGEN network matrix H. Network matrix H
consists of interactions among proteins and regulations of the TF-gene, TF-lncRNA, TF-
miRNA, lncRNA-gene, lncRNA-lncRNA, lncRNA-miRNA, miRNA-gene, miRNA-lncRNA,
and miRNA-miRNA in the real GWGEN as the follows:
H =


hprotein⇔protein
0
0
hTF⇒gene
hln cRNA⇒gene
hmiRNA⇒gene
hTF⇒ln cRNA
hln cRNA⇒ln cRNA
hmiRNA⇒ln cRNA
hTF⇒miRNA
hln cRNA⇒miRNA
hmiRNA⇒miRNA


(33)
where hprotein⇔protein denotes the sub-matrix of PPI of which the bidirectional arrow at
the subscript of the parameter means that the protein interaction is bidirectional; hTF⇒gene,
hTF⇒ln cRNA, hTF⇒miRNA, hln cRNA⇒gene, hln cRNA⇒ln cRNA, hln cRNA⇒miRNA, hmiRNA⇒gene,
hmiRNA⇒ln cRNA and hmiRNA⇒miRNA denote the transcriptional regulatory sub-networks of
TFs on genes, lncRNAs, and miRNAs; lncRNAs on genes, lncRNAs, and miRNAs; and
miRNAs on genes, lncRNAs, and miRNAs, respectively. The detail components of network
matrix H of real GWGENs are given below:
H =


11
12
1
1
21
22
2
2
1
2
1
1
1
11
12
1
1
11
12
1
1
ˆ
ˆ
ˆ
ˆ
0
0
0
0
0
0
0
0
ˆ
ˆ
ˆ
ˆ
0
0
0
0
0
0
0
0
ˆ
ˆ
ˆ
ˆ
0
0
0
0
0
0
0
0
ˆ
ˆ
ˆ
ˆ
0
0
0
0
0
0
0
0
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
q
q
q
q
x
x
r
Q
r
Q
q
q
qr
qQ
Q
Q
Q
QQ
u
U
v
V
κ
κ
κ
κ
κ
κ
κ
κ
κ
κ
κ
κ
κ
κ
κ
κ
α
α
α
α
β
β
β
β
































































11
12
1
1
21
22
2
2
21
22
2
2
21
22
2
2
1
2
1
2
1
2
1
2
1
2
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
x
x
x
x
x
x
x
x
w
W
u
U
v
V
w
W
x
x
xu
xU
x
x
xv
xV
x
x
xw
xW
X
X
Xu
XU
X
X
X
γ
γ
γ
γ
α
α
α
α
β
β
β
β
ω
ω
γ
γ
α
α
α
α
β
β
β
β
γ
γ
γ
γ
α
α
α
α
β
β
β





















































1
2
11
12
1
1
11
12
1
1
11
12
1
1
21
22
2
2
21
22
2
2
21
22
2
2
1
2
1
2
1
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
x
x
i
i
i
i
i
i
i
i
v
XV
X
X
Xw
XW
u
U
v
V
w
W
u
U
v
V
w
W
i
i
iu
iU
i
i
iv
iV
i
β
γ
γ
γ
γ
σ
σ
σ
σ
ς
ς
ς
ς
τ
τ
τ
τ
σ
σ
σ
σ
ς
ς
ς
ς
τ
τ
τ
τ
σ
σ
σ
σ
ς
ς
ς
ς
τ





































2
1
2
1
2
1
2
11
12
1
1
11
12
1
1
11
12
1
1
21
22
2
2
21
22
2
2
21
22
2
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
i
i
i
i
j
j
j
j
j
i
iw
iW
I
I
Iu
IU
I
I
Iv
IV
I
I
Iw
IW
u
U
v
U
w
W
u
U
v
U
w
τ
τ
τ
σ
σ
σ
σ
ς
ς
ς
ς
τ
τ
τ
τ
ω
ω
ω
ω
ξ
ξ
ξ
ξ
ψ
ψ
ψ
ψ
ω
ω
ω
ω
ξ
ξ
ξ
ξ
ψ
ψ
ψ






































2
1
2
1
2
1
2
1
2
1
2
1
2
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
ˆ
j
j
j
j
j
j
j
W
j
j
ju
jU
j
j
jv
jU
j
j
jw
jW
J
J
Ju
JU
J
J
Jv
JU
J
J
Jw
JW
ψ
ω
ω
ω
ω
ξ
ξ
ξ
ξ
ψ
ψ
ψ
ψ
ω
ω
ω
ω
ξ
ξ
ξ
ξ
ψ
ψ
ψ
ψ






















































∈R(Q∗+X∗+I∗+J∗)×(U∗+V∗+W∗)
(34)
where ˆκqr is the interaction ability of between the q-th protein and the r-th protein;
ˆαxu, ˆβxv, and ˆγxw are individually the regulation abilities of the u-th TF on the x-th gene,
the v-th lncRNA on the x-th gene, and the w-th miRNA on the x-th gene; ˆσiu, ˆςiv, and ˆτiw
represent the regulation abilities of the u-th TF on the i-th lncRNA, the v-th lncRNA on
the i-th lncRNA, and the w-th miRNA on the i-th lncRNA, respectively; ˆωju, ˆξjv, and ˆψjw
separately show the regulation abilities of the u-th TF on the j-th miRNA, the v-th lncRNA
on the j-th miRNA, and the w-th miRNA on the w-th miRNA. In addition, some zeros are

## Page 23 (Section: The Principal Network Projection (PNP) Method for the Core GWGENs Extraction from Real GWGENs )

Int. J. Mol. Sci. 2021, 22, 166
23 of 33
omitted in the matrix, which means that there is neither interaction nor regulation between
the source and target.
Thereafter, the core GWGENs were obtained by applying PNP on the network matrix
H with an energy threshold of 85%. First, the network matrix H is decomposed by singular
value decomposition (SVD) as follows [68]:
H = SVDT
(35)
where S ∈R(Q∗+X∗+I∗+J∗)×(Q∗+X∗+I∗+J∗) and DT ∈R(U∗+V∗+W∗)×(U∗+V∗+W∗) are the uni-
tary singular matrices; V = diag(v1, · · · , vii, · · · vU∗+V∗+W∗) ∈R(Q∗+X∗+I∗+J∗)×(U∗+V∗+W∗)
denotes the diagonal matrix of which the components at the diagonal are the singular
values of H and are arranged in descending order, i.e., v1 ≥v2 ≥· · · ≥vi ≥· · · ≥
vU∗+V∗+W∗≥0.
V =


v1
0
· · ·
0
· · ·
0
0
v2
· · ·
0
· · ·
0
...
...
...
...
...
...
0
0
· · ·
vi
· · ·
0
...
...
...
...
...
...
0
0
· · ·
0
· · ·
vU∗+V∗+W∗
0
0
· · ·
0
· · ·
0
...
...
...
...
...
...
0
0
· · ·
0
· · ·
0


(36)
In addition, we deﬁned the normalization of singular values in (36) as below.
Ei =
v2
i
U∗+V∗+W∗
∑
i=1
v2
i
and
U∗+V∗+W∗
∑
i=1
Ei = 1
(37)
I
∑
i=1
Ei ≥0.85
(38)
From the above formula, the top I signiﬁcant singular vector structures were selected
to represent the system with energy equal to or more than 85%. Then we respectively
projected each node of the real GWGEN (i.e., each row of network matrix H) to the top I
singular vectors as follows.
Z(a, b) = ha,: · dT
b,:, for a = 1, . . . , Q∗+ X∗+ I∗+ J∗, b = 1, . . . , I
(39)
where Z(a, b) denotes the projection value of the a-th node on the b-th signiﬁcant singular
vector; ha,: means the a-th row vector of network matrix H, and dT
:,b denotes the the b-th
column of DT. Next, we deﬁne the 2-norm projection value to each node such as protein,
gene, lnRNA and miRNA in real GWGEN from the top I signiﬁcant singular vectors as
below.
S(a) =
v
u
u
t
I
∑
i=1
Z2(a, b), for a = 1, . . . , Q∗+ X∗+ I∗+ J∗
(40)
According to the equation in (40), the top 3000 pivotal proteins, genes, miRNAs,
and lncRNAs with higher projection value were selected to construct the core GWGENs
for T2D and non-T2D, respectively. Afterwards, the core GWGENs were uploaded to
the DAVID website for KEGG pathway enrichment analysis, and the construction of
core signaling pathways for non-T2D and T2D were accomplished with the help of the
annotation of KEGG pathways. The enrichment analysis was used to validate that our
results were associated with T2D. Eventually, the potential biomarkers were chosen through

## Page 24 (Section: Systematic Drug Discovery Based on Drug Design Specifications for T2D )

Int. J. Mol. Sci. 2021, 22, 166
24 of 33
investigating the T2D pathogenesis by comparing the non-T2D and T2D core signaling
pathways.
4.6. Systematic Drug Discovery Based on Drug Design Speciﬁcations for T2D
Based on drug design speciﬁcations, we aimed to discover a potential multiple-
molecule targeting drug for the identiﬁed biomarkers. We proposed a DTI model based on
a deep neural network to predict the drug–target interaction between the available drugs
and targets (biomarkers). Since it is not enough to consider the drug–target interaction
alone for drug design, some speciﬁcations, i.e., regulation ability, toxicity, sensitivity and
side effect are necessary to sieve the candidate drugs predicted by the DTI model. Then,
with these considerations, we suggested an appropriate multiple-molecule targeting drug
for T2D treatment before clinical trials.
First, based on the ﬂowchart of the systematic drug discovery method in Figure 3, we
accessed an integrated collection of protein–ligand afﬁnity data through BindingDB’s uni-
ﬁed interface [69], which harvests the selected data and information from multiple existing
databases, i.e., PubChem, ChEMBL, UniProt, DrugBank, etc. (for more details, readers can
refer to Appendix B). Recently, the feature-based method, for instance, molecular descriptor,
is broadly used to describe the structural and chemical properties of molecules such as
characteristics from the 2D and 3D spectrum of structure, molecular weight, hydrophilic,
hydrophobicity, etc. It was validated that the chemical properties of the drug and genomic
sequence of the target could be described with the molecular descriptor for the purpose of
convenient analysis in drug design, since the molecular descriptor can transform compli-
cated chemical properties into a simple numerical feature vector [70,71]. On this ground,
we utilized the functions from python package pyBioMed to transform both the drug and
target into a descriptor as their features individually under the python2.7 environment.
The considered drug features of a molecule included constitutional descriptors, connec-
tivity indices, E-state indices, charge descriptors, molecular properties and kappa shape
indices. For the target features, the structural and physicochemical features of proteins and
peptides from amino acid sequence such as amino acid composition, dipeptide composition
. . . , etc. are calculated (for more detailed information about the descriptor transformation,
readers could access the documents of pyBioMed [72]). Then, the descriptor of the drug
and target were combined into a feature vector vdrug-target corresponding to the drug–target
pair as below [73]:
vdrug−target = [D, T] = [d1, d2, · · · , dM, t1, t2, · · · tN]
(41)
Among vdrug−target, 363 features for a drug and 996 features for a target were collected,
where the former features in vdrug-target are for the drug and the latter are for the target. d1
represents the ﬁrst drug feature; t1 indicates the ﬁrst target feature; M is the total number of
drug features; and N denotes the total number of target features. Before training the DNN-
based DTI model, we encountered a problem that features are not in the same standing.
Since the variables of the features are measured at different scales, they do not contribute
equally to the model ﬁtting and might end up creating a bias, i.e., the feature with a larger
value would dominate the result. To deal with this potential problem, a feature-wise scaling
is usually implemented prior to model ﬁtting. As powerful techniques of feature scaling,
Min-max Normalization and Standardization methods are commonly used for bringing
every feature in the same footing without any upfront importance. Although Min-max
Normalization can also normalize the data into the same scale, it is much more sensitive
to outliers compared to Standardization. Therefore, Standardization was performed on
the features before applying principal component analysis (PCA) to improve the model
performance, and the corresponding mathematical formulation is shown as follows:
d∗
i = di −µi
σi
, ∀i = 1, . . . , M
(42)

## Page 25 (Section: Systematic Drug Discovery Based on Drug Design Specifications for T2D )

Int. J. Mol. Sci. 2021, 22, 166
25 of 33
t∗
j = tj −µj
σj
, ∀j = 1, . . . , N
(43)
where di is the i-th drug feature and the d∗
i is the i-th drug feature after Standardization;
µi and σi individually represent the mean and standard deviation of the i-th drug feature;
tj indicates the j-th feature of the target and t∗
j denotes the j-th feature of the target after
Standardization; µj and σj separately signify the mean and standard deviation of the j-th
target feature; M denotes the total number of drug features; and N is the total number of
target features.
h = σ(wx + b)
(44)
where x and h denote input and output, respectively; w is the weighting matrix and b is
the bias vector; σ(·) indicates the activation function with Rectiﬁed Linear Unit (ReLU) in
the hidden layer and Sigmoid in the output layer. Since the binary classiﬁcation issue is
concerned, the binary-cross entropy is chosen as the cost function to calculate the model
loss:
Cn(w, b) = −[ ˆpn log pn + (1 −ˆpn)log(1 −pn)]
(45)
L(w, b) = 1
N
N
∑
n=1
Cn(w, b)
(46)
where pn means the truth label of positive interaction; ˆpn indicates the predictive probability
of positive interaction, 1 −pn shows the truth label of negative interaction, and 1 −ˆpn
represents the predicted probability of negative interaction. L( ˆpn, pn) denotes the average
of total loss C( ˆpn, pn). According to the cost function, the backward propagation algorithm
is applied to update the model parameter set θ containing the weighting matrix and bias
vector through calculating the gradient of cost function in (46) to get the result in (50) and
eventually derive the optimal solution θ∗in (48) as follows.
θ =
 w
b

(47)
θ∗= argmin
θ
L(θ)
(48)
θl = θl−1 −η∇L(θl−1)
(49)
where l is the l-th epoch of learning procedure; η is the learning rate; and ∇L(θl−1) is the
gradient of L(θl−1) as below:
∇L(θl−1) =
"
∂L(θl−1)
∂w
∂L(θl−1)
∂b
#
(50)
Based on the backward propagation method, the DNN-based DTI model could adjust
the parameters to ﬁt the drug–target interaction data at each iteration well. In addition,
the hyperparameters were tuned to not only lower the training time but also achieve
the best model performance. We used Adam [74] as an optimizer with a default setting
and set the learning rate as 0.0001 to make the model parameter θ converge faster and
precisely. We set 100 for epochs and 100 for batch size. For the data, we split one-fourth
of the data as testing data and three-fourths of it as training data. Moreover, we further
divided the training data into ten equal folds to perform ten-fold cross-validation, in which
nine-tenths of them were used for model training and one-tenth was used for validation.
Such application is exploited to supervise whether the model was better than that of the
former epoch and to guarantee the model stability. Furthermore, to avoid overﬁtting,
not only did we embed the dropout layer (dropout rate = 0.4) behind each hidden layer but
also applied the early stopping strategy to monitor whether the test accuracy decreased
with the continuous improvement of training accuracy or not. After accomplishing model
training as shown in Figure 4, we adopted the AUC (area under the curve) score and ROC

## Page 26 (Section: Conclusions )

Int. J. Mol. Sci. 2021, 22, 166
26 of 33
(receiver operating characteristics) curve [75] in Figure 7 as the performance measurement.
It is one of the most useful evaluation metrics to visualize the model performance when it
comes to the binary classiﬁcation problems. The higher AUC score is that in which the area
under the line is larger; the better accuracy is for the DNN-based DTI model predicting the
true positive and true negative drug–target interaction. The formulas for the AUC score
and ROC curve are shown below.
TPR(True Positive Rate) =
TP
TP + FN
(51)
speciﬁcity =
TN
TN + FP
(52)
FPR(False Positive Rate) = 1 −speciﬁcity =
FP
TN + FP
(53)
where TP (True Positive) means that the real value is true and is judged correctly; TN (True
Negative) shows that the real value is true and is judged by mistake; FP (False Positive)
indicates the real value is false and is judged accurately; FN (False Negative) represents
that the real value is false and is judged in error.
It is worth noting that the majority of previous network approaches use machine
learning (ML)-based methods to perform predictions over the drug–target interaction
space [76–78]. However, such techniques have major limitations. Traditional ML is a time-
consuming process and requires lots of expertise to design and run the algorithms. Without
a good understanding of the domain knowledge and feature engineering, a traditional
machine algorithm can hardly work well.
As a kind of ML-based model with multiple hidden layers and a more complicated
parameter training procedure, the deep learning method attracts lots of attention for its
relatively better performance and ability to learn representations of data with multiple
levels of abstraction [79]. When there is a lack of domain understanding for feature in-
trospection, deep learning techniques outshine others as we do not have to worry much
about feature engineering. Additionally, the comparison of deep-learning methods with
other acceptable ML algorithms in the task of new DTIs identiﬁcation has previously been
performed as well, where framework based on deep learning could indeed achieve rela-
tively high prediction performance [80]. As a result, for each algorithm compared in our
work, only default parameters without ﬁne-tuning were set to learn features from the data.
However, a disadvantage should be solved that there are no experimental validated nonin-
teracting drug–target pairs so that it is difﬁcult to select negative samples, which would
largely inﬂuence the predictive accuracy of the method [81]. Hence, apart from extracting
a great number of samples from the presently largest database, BingdingDB, we further
followed the criteria in Appendix B to abstract negative examples from existing drug–target
interactions, which enabled us to evaluate and manipulate the data more realistically to
achieve better performance.
5. Conclusions
In this study, on the basis of our proposed combination of systems biology and
systematic drug discovery design, we not only investigated the complicated pathogenic
molecular mechanism of T2D from genetic and epigenetic perspectives but also discovered
a potential drug combination for the clinical treatment of T2D based on four drug design
speciﬁcations. At ﬁrst, we constructed the stochastic biological networks by systematic
identiﬁcation and system order detection methods by exploring big data. After that,
we extracted the core signaling pathways by the PNP method and the annotation of KEGG
pathways to select the signiﬁcant biomarkers from the pathogenesis of T2D. For the purpose
of discovering candidate drugs interacting with these biomarkers, we trained a DNN-based
DTI model to predict the possible drug–target interactions. Moreover, we considered the
drug regulation ability, toxicity, sensitivity and side effects as the drug design speciﬁcations
to better sieve appropriate potential drugs. As a result, a set of combinational multiple

## Page 27 (Section:  )

Int. J. Mol. Sci. 2021, 22, 166
27 of 33
molecular drugs is proposed as a multiple-molecule targeting drug for T2D treatment.
Since the beginning of this century, the advent of the genomic era has presented researchers
with a myriad of high throughput genome-wide biological data, which can assist in the
interpretation of the indecipherable genetic and epigenetic regulations and the optimization
of drug efﬁcacy. Considering the combination of multiple types of genomics data could
beneﬁt us to gain deeper insight into the pathogenic mechanism of diseases. It is expected
that our systems biology and systematic drug discovery design might provide a new
orientation for T2D therapeutics.
Author Contributions: Conceptualization, S.C., J.-Y.C. and B.-S.C.; Data curation, S.C. and J.-Y.C.;
Formal analysis, S.C., J.-Y.C. and B.-S.C.; Funding acquisition, B.-S.C.; Investigation, S.C., J.-Y.C.
and B.-S.C.; Methodology, S.C., J.-Y.C. and B.-S.C.; Project administration, B.-S.C.; Resources, B.-
S.C.; Software, S.C., J.-Y.C. and B.-S.C.; Supervision, B.-S.C.; Validation, S.C., J.-Y.C. and B.-S.C.;
Visualization, S.C. and J.-Y.C.; Writing—original draft, S.C. and J.-Y.C.; Writing—review and editing,
S.C., J.-Y.C., B.-S.C. and Y.-J.C. All authors have read and agreed to the published version of the
manuscript.
Funding: This research was funded by Ministry of Science and Technology grant number MOST
107-2221-E-007-112-MY3.
Conﬂicts of Interest: The authors declare no conﬂict of interest.
Abbreviations
T2D
Type 2 Diabetes
GRN
Gene Regulatory Network
PPIN
Protein-Protein Interaction Network
GWGEN
Genome Wide Genetic and Epigenetic Network
PNP
Principal Network Projection
DTI
Drug–Target Interaction
Appendix A
Table A1. The statistics of the nodes and edges in candidate GWGEN, non-T2D GWGEN, and T2D
GWGEN after identiﬁcation.
Candidate GWGEN
Non-T2D GWGEN
T2D GWGEN
LncRNA-TF
158
1
4
LncRNA-Receptor
2
2
0
LncRNA-Protein
142
8
3
LncRNAs
384
121
125
MiRNA-TF
17,052
1
3
MiRNA-Receptor
13,438
3
2
MiRNA-Protein
75,629
8
16
MiRNAs
417
22
29
TF-LncRNA
417
133
162
TF-MiRNA
723
25
31
TF-TF
33,897
2249
1984
TF-Receptor
16,241
1059
1084
TF-Protein
84,634
8336
8887

## Page 28 (Section:  )

Int. J. Mol. Sci. 2021, 22, 166
28 of 33
Table A1. Cont.
TFs
4351
1086
1057
Receptor-LncRNA
101
29
35
Receptor-MiRNA
78
2
1
Receptor-TF
2520
356
327
Receptor-Receptor
1757
231
183
Receptor-Protein
9111
1991
1737
Receptors
2768
2093
2033
Proteins
19,041
18,101
17,924
PPIs
6,244,695
826,916
814,993
Total nodes
26,961
21,423
21,168
Total edges
6,500,938
841,350
829,452
The content in the table shows the number of nodes or edges. The rows of the table contain different
types of node and edge, e.g., LncRNA-TF indicates that lncRNA regulates the transcriptional factor
(TF), and LncRNAs means the nodes of LncRNA. Also, we count and record the number of proteins
and protein–protein interactions (PPIs).
Figure A1. (A) The real GWGEN network of non-T2D; (B) The real GWGEN network of T2D. The real GWGENs were
constructed by pruning the false positives from candidate GWGENs though system identiﬁcation and systems order
detection methods. The numbers in the ﬁgure signify the node numbers of proteins, TFs, Receptors, LncRNAs, and MiRNAs.
The orange lines indicate the protein–protein interactions and the blue lines denote the gene regulations.

## Page 29 (Section:  )

Int. J. Mol. Sci. 2021, 22, 166
29 of 33
Figure A2. (A) The core GWGEN network of non-T2D; (B) The core GWGEN network of T2D. The core GWGENs were
extracted by PNP method the real GWGEN to simplify the pathogenic analysis of T2D. The numbers in the ﬁgure signify
the node numbers of proteins, TFs, Receptors, LncRNAs and MiRNAs. The orange lines indicate the protein–protein
interactions and the blue lines denote the gene regulations.
 
Figure A3. The core signaling pathways of non-T2D based on our result for investigating the non-T2D genetic and epigenetic
molecular mechanism. The genes and proteins in the core signaling pathways were chosen from the non-T2D core GWGENs.
The gene regulations and protein interactions were constructed on the basis of the edges in non-T2D core GWGENs. The
cellular functions caused by target genes are clustered with solid lines in different colors.

## Page 30 (Section:  )

Int. J. Mol. Sci. 2021, 22, 166
30 of 33
 
Figure A4. The core signaling pathways of T2D based on our result for investigating the T2D genetic and epigenetic
molecular mechanism. The gene regulations and protein interactions were constructed on the basis of the edges in T2D
core GWGENs. The cellular functions caused by target genes are clustered with solid lines in different colors. The cellular
functions caused by target genes are clustered with solid lines in different colors. The bold arrowhead marks in black denote
the relatively low and high expression in T2D pathogenic signaling pathways in contrast to non-T2D.
Appendix B
BindingDB is a well accessible database of measured binding afﬁnities, focusing chieﬂy
on the interactions among small molecules and proteins. It provided about one million
binding data for thousands of small molecules and proteins. By the following ﬁve criteria,
we collected a binary classiﬁcation dataset with 33,777 samples for positive examples and
27,493 for negative instances.
1.
The chemical identiﬁer (PubChem CID) is recorded, and the small molecule has
chemical structure expressed by SMILES (Although both SMILES and InChI are
recorded in BindingDB dataset, SMILES is easier to read and more supported by
software).
2.
The protein identiﬁer (Uniprot ID) is recorded, and the protein is represented by the
sequence in Fasta format.
3.
The half maximal inhibitory concentration (IC50) value, a primary measure of binding
effectiveness, is recorded
4.
The chemical molecule weight is less than 1000 Da due to our focus on small molecule
drugs.
5.
According to the activity threshold discussed by Wang et al. [82], it is recorded as
positive if the IC50 is less than 100 nm and negative if IC50 is greater than 10,000 nm.
Since most drug–target interaction databases do not provide real negative examples,
it is a common solution to randomly sample a small number of unknown interactions as
negative examples. However, unknown interactions do not mean negation, i.e., without
interactions. There might just be no experimental evidence or record at present. There-
fore, we followed the above procedure to evaluate and classify BindingDB samples more
practically.

## Page 31 (Section:  )

Int. J. Mol. Sci. 2021, 22, 166
31 of 33
References
1.
Chen, L.; Magliano, D.J.; Zimmet, P.Z. The worldwide epidemiology of type 2 diabetes mellitus–present and future perspectives.
Nat. Rev. Endocrinol. 2011, 8, 228–236. [CrossRef]
2.
Pulgaron, E.R.; Delamater, A.M. Obesity and type 2 diabetes in children: Epidemiology and treatment. Curr. Diab. Rep. 2014,
14, 508. [CrossRef] [PubMed]
3.
Khawandanah, J. Double or hybrid diabetes: A systematic review on disease prevalence, characteristics and risk factors. Nutr.
Diabetes 2019, 9, 33. [CrossRef] [PubMed]
4.
Zhou, T.; Hu, Z.; Yang, S.; Sun, L.; Yu, Z.; Wang, G. Role of Adaptive and Innate Immunity in Type 2 Diabetes Mellitus. J. Diabetes
Res. 2018, 2018, 7457269. [CrossRef] [PubMed]
5.
Xia, C.; Rao, X.; Zhong, J. Role of T Lymphocytes in Type 2 Diabetes and Diabetes-Associated Inﬂammation. J. Diabetes Res. 2017,
2017, 6494795. [CrossRef] [PubMed]
6.
Fields, S.; Sternglanz, R. The two-hybrid system: An assay for protein-protein interactions. Trends Genet. 1994, 10, 286–292. [CrossRef]
7.
Rao, V.S.; Srinivas, K.; Sujini, G.N.; Kumar, G.N.S. Protein-protein interaction detection: Methods and analysis. Int. J. Proteom.
2014, 2014, 147648. [CrossRef] [PubMed]
8.
Yi, N. Statistical analysis of genetic interactions. Genet. Res. 2010, 92, 443–459. [CrossRef]
9.
Spencer, C.C.A.; Su, Z.; Donnelly, P.; Marchini, J. Designing Genome-Wide Association Studies: Sample Size, Power, Imputation,
and the Choice of Genotyping Chip. PLoS Genet. 2009, 5, e1000477. [CrossRef]
10.
Yeh, S.-J.; Chang, C.-A.; Li, C.-W.; Wang, L.H.-C.; Chen, B.-S. Comparing progression molecular mechanisms between lung
adenocarcinoma and lung squamous cell carcinoma based on genetic and epigenetic networks: Big data mining and genome-wide
systems identiﬁcation. Oncotarget 2019, 10, 3760–3806. [CrossRef]
11.
Li, C.-W.; Jheng, B.-R.; Chen, B.-S. Investigating genetic-and-epigenetic networks, and the cellular mechanisms occurring in
Epstein–Barr virus-infected human B lymphocytes via big data mining and genome-wide two-sided NGS data identiﬁcation.
PLoS ONE 2018, 13, e0202537. [CrossRef] [PubMed]
12.
Hughes, J.P.; Rees, S.; Kalindjian, S.B.; Philpott, K.L. Principles of early drug discovery. Br. J. Pharmacol. 2011, 162, 1239–1249.
[CrossRef] [PubMed]
13.
Akhondzadeh, S. The Importance of Clinical Trials in Drug Development. Avicenna J. Med. Biotechnol. 2016, 8, 151. [PubMed]
14.
Weaver, M.F.; Hopper, J.A.; Gunderson, E.W. Designer drugs 2015: Assessment and management. Addict. Sci. Clin. Pract. 2015,
10, 8. [CrossRef]
15.
Boden, G. Free Fatty Acids, Insulin Resistance, and Type 2 Diabetes Mellitus. Proc. Assoc. Am. Physicians 1999, 111, 241–248. [CrossRef]
16.
Kitamura, T.; Ido Kitamura, Y. Role of FoxO Proteins in Pancreatic beta Cells. Endocr. J. 2007, 54, 507–515. [CrossRef]
17.
Liu, Z.; Tanabe, K.; Bernal-Mizrachi, E.; Permutt, M.A. Mice with beta cell overexpression of glycogen synthase kinase-3β have
reduced beta cell mass and proliferation. Diabetologia 2008, 51, 623–631. [CrossRef]
18.
Li, Y.; Cao, X.; Li, L.-X.; Brubaker, P.L.; Edlund, H.; Drucker, D.J. β-Cell Pdx1 Expression Is Essential for the Glucoregulatory,
Proliferative, and Cytoprotective Actions of Glucagon-Like Peptide-1. Diabetes 2005, 54, 482. [CrossRef]
19.
Chen, F.; Sha, M.; Wang, Y.; Wu, T.; Shan, W.; Liu, J.; Zhou, W.; Zhu, Y.; Sun, Y.; Shi, Y.; et al. Transcription factor Ets-1 links
glucotoxicity to pancreatic beta cell dysfunction through inhibiting PDX-1 expression in rodent models. Diabetologia 2016, 59,
316–324. [CrossRef]
20.
Humphrey, R.K.; Yu, S.M.; Flores, L.E.; Jhala, U.S. Glucose regulates steady-state levels of PDX1 via the reciprocal actions of GSK3
and AKT kinases. J. Biol. Chem. 2010, 285, 3406–3416. [CrossRef]
21.
Bernal-Mizrachi, E.; Wen, W.; Stahlhut, S.; Welling, C.M.; Permutt, M.A. Islet beta cell expression of constitutively active
Akt1/PKB alpha induces striking hypertrophy, hyperplasia, and hyperinsulinemia. J. Clin. Investig. 2001, 108, 1631–1638.
[CrossRef] [PubMed]
22.
Mao, Z.; Zhang, W. Role of mTOR in Glucose and Lipid Metabolism. Int. J. Mol. Sci. 2018, 19, 2043. [CrossRef] [PubMed]
23.
Blandino-Rosano, M.; Chen, A.Y.; Scheys, J.O.; Alejandro, E.U.; Gould, A.P.; Taranukha, T.; Elghazi, L.; Cras-Méneur, C.; Bernal-Mizrachi,
E. mTORC1 signaling and regulation of pancreatic β-cell mass. Cell Cycle 2012, 11, 1892–1902. [CrossRef] [PubMed]
24.
Zhu, Y.; Sun, Y.; Zhou, Y.; Zhang, Y.; Zhang, T.; Li, Y.; You, W.; Chang, X.; Yuan, L.; Han, X. MicroRNA-24 promotes pancreatic beta cells
toward dedifferentiation to avoid endoplasmic reticulum stress-induced apoptosis. J. Mol. Cell Biol. 2019, 11, 747–760. [CrossRef]
25.
Zhou, H.; Gao, S.; Duan, X.; Liang, S.; Scott, D.A.; Lamont, R.J.; Wang, H. Inhibition of serum- and glucocorticoid-inducible kinase
1 enhances TLR-mediated inﬂammation and promotes endotoxin-driven organ failure. FASEB J. 2015, 29, 3737–3749. [CrossRef]
26.
Aleksic, T.; Baumann, B.; Wagner, M.; Adler, G.; Wirth, T.; Weber, C.K. Cellular immune reaction in the pancreas is induced by
constitutively active IkappaB kinase-2. Gut 2007, 56, 227–236. [CrossRef]
27.
Liu, T.; Zhang, L.; Joo, D.; Sun, S.-C. NF-κB signaling in inﬂammation. Signal Transduct. Target. Ther. 2017, 2, 17023. [CrossRef]
28.
Segovia, J.A.; Tsai, S.Y.; Chang, T.H.; Shil, N.K.; Weintraub, S.T.; Short, J.D.; Bose, S. Nedd8 regulates inﬂammasome-dependent
caspase-1 activation. Mol. Cell Biol. 2015, 35, 582–597. [CrossRef]
29.
Gurzov, E.N.; Eizirik, D.L. Bcl-2 proteins in diabetes: Mitochondrial pathways of beta-cell death and dysfunction. Trends Cell Biol.
2011, 21, 424–431. [CrossRef]
30.
Ma, W.-n.; Park, S.-Y.; Han, J.-S. Role of phospholipase D1 in glucose-induced insulin secretion in pancreatic Beta cells. Exp. Mol.
Med. 2010, 42, 456–464. [CrossRef]

## Page 32 (Section:  )

Int. J. Mol. Sci. 2021, 22, 166
32 of 33
31.
Habegger, K.M.; Heppner, K.M.; Geary, N.; Bartness, T.J.; DiMarchi, R.; Tschöp, M.H. The metabolic actions of glucagon revisited.
Nat. Rev. Endocrinol. 2010, 6, 689–697. [CrossRef] [PubMed]
32.
Pullen, T.J.; da Silva Xavier, G.; Kelsey, G.; Rutter, G.A. miR-29a and miR-29b contribute to pancreatic beta-cell-speciﬁc silencing
of monocarboxylate transporter 1 (Mct1). Mol. Cell. Biol. 2011, 31, 3182–3194. [CrossRef] [PubMed]
33.
Nwankpa, C.; Ijomah, W.; Gachagan, A.; Marshall, S. Activation Functions: Comparison of trends in Practice and Research for
Deep Learning. arXiv 2018, arXiv:1811.03378.
34.
Subramanian, A.; Narayan, R.; Corsello, S.M.; Peck, D.D.; Natoli, T.E.; Lu, X.; Gould, J.; Davis, J.F.; Tubelli, A.A.; Asiedu, J.K.; et al. A Next
Generation Connectivity Map: L1000 Platform and the First 1,000,000 Profiles. Cell 2017, 171, 1437–1452.e1417. [CrossRef] [PubMed]
35.
Cheng, F.; Li, W.; Liu, G.; Tang, Y. In silico ADMET prediction: Recent advances, current challenges and future trends. Curr. Top
Med. Chem. 2013, 13, 1273–1289. [CrossRef] [PubMed]
36.
Corsello, S.M.; Nagari, R.T.; Spangler, R.D.; Rossen, J.; Kocak, M.; Bryan, J.G.; Humeidi, R.; Peck, D.; Wu, X.; Tang, A.A.; et al.
Non-oncology drugs are a source of previously unappreciated anti-cancer activity. bioRxiv 2019, 730119. [CrossRef]
37.
Guerrero-Beltrán, E.; Calderón, M.; Pedraza-Chaverri, J.; Chirino, Y. Protective effect of sulforaphane against oxidative stress:
Recent advances. Exp. Toxicol. Pathol. 2010, 64, 503–508. [CrossRef]
38.
Romero-Navarro, G.; Cabrera-Valladares, G.; German, M.S.; Matschinsky, F.M.; Velazquez, A.; Wang, J.; Fernandez-Mejia, C.
Biotin regulation of pancreatic glucokinase and insulin in primary cultured rat islets and in biotin-deﬁcient rats. Endocrinology
1999, 140, 4595–4600. [CrossRef]
39.
He, W.; Yuan, T.; Maedler, K. Macrophage-associated pro-inﬂammatory state in human islets from obese individuals. Nutr.
Diabetes 2019, 9, 36. [CrossRef]
40.
Kraakman, M.J.; Murphy, A.J.; Jandeleit-Dahm, K.; Kammoun, H.L. Macrophage polarization in obesity and type 2 diabetes:
Weighing down our understanding of macrophage function? Front. Immunol. 2014, 5, 470. [CrossRef]
41.
Eguchi, K.; Manabe, I. Macrophages and islet inﬂammation in type 2 diabetes. Diabetes Obes. Metab. 2013, 15 (Suppl. 3), 152–158.
[CrossRef] [PubMed]
42.
Demirbilek, H.; Galcheva, S.; Vuralli, D.; Al-Khawaga, S.; Hussain, K. Ion Transporters, Channelopathies, and Glucose Disorders.
Int. J. Mol. Sci. 2019, 20, 2590. [CrossRef] [PubMed]
43.
Jacobson, D.A.; Shyng, S.L. Ion Channels of the Islets in Type 2 Diabetes. J. Mol. Biol. 2020, 432, 1326–1346. [CrossRef]
44.
Kanungo, S.; Wells, K.; Tribett, T.; El-Gharbawy, A. Glycogen metabolism and glycogen storage disorders. Ann. Transl. Med. 2018,
6, 474. [CrossRef] [PubMed]
45.
Alsubaie, S.; Almalki, M.H. Metformin induced acute pancreatitis. Dermato Endocrinol. 2013, 5, 317–318. [CrossRef] [PubMed]
46.
Fimognari, F.L.; Corsonello, A.; Pastorell, R.; Antonelli-Incalzi, R. Metformin-Induced Pancreatitis: A possible adverse drug effect
during acute renal failure. Diabetes Care 2006, 29, 1183. [CrossRef] [PubMed]
47.
Sola, D.; Rossi, L.; Schianca, G.P.C.; Mafﬁoli, P.; Bigliocca, M.; Mella, R.; Corlianò, F.; Fra, G.P.; Bartoli, E.; Derosa, G. Sulfonylureas
and their use in clinical practice. Arch. Med. Sci. 2015, 11, 840–848. [CrossRef]
48.
Apovian, C.M.; Okemah, J.; O’Neil, P.M. Body Weight Considerations in the Management of Type 2 Diabetes. Adv. Ther. 2019, 36,
44–58. [CrossRef]
49.
Hinnen, D. Glucagon-Like Peptide 1 Receptor Agonists for Type 2 Diabetes. Diabetes Spectr. 2017, 30, 202–210. [CrossRef]
50.
Storgaard, H.; Cold, F.; Gluud, L.L.; Vilsbøll, T.; Knop, F.K. Glucagon-like peptide-1 receptor agonists and risk of acute pancreatitis
in patients with type 2 diabetes. Diabetes Obes. Metab. 2017, 19, 906–908. [CrossRef]
51.
Yang, T.-L.; Shen, M.-C.; Yu, M.-L.; Huang, Y.-B.; Chen, C.-Y. Acute pancreatitis in patients with type 2 diabetes mellitus treated
with dipeptidyl peptidase-4 inhibitors. J. Food Drug Anal. 2016, 24, 450–454. [CrossRef] [PubMed]
52.
Shubrook, J.H.; Bokaie, B.B.; Adkins, S.E. Empagliﬂozin in the treatment of type 2 diabetes: Evidence to date. Drug Des Devel Ther
2015, 9, 5793–5803. [CrossRef] [PubMed]
53.
Fournier Gangrene Associated With Sodium–Glucose Cotransporter-2 Inhibitors. Ann. Intern. Med. 2019, 170, 764–769. [CrossRef] [PubMed]
54.
Rosenstock, J.; Ferrannini, E. Euglycemic Diabetic Ketoacidosis: A Predictable, Detectable, and Preventable Safety Concern With
SGLT2 Inhibitors. Diabetes Care 2015, 38, 1638–1642. [CrossRef]
55.
Wang, Y.-C.; Chen, B.-S. Integrated cellular network of transcription regulations and protein-protein interactions. BMC Syst. Biol.
2010, 4, 20. [CrossRef]
56.
Xenarios, I.; Rice, D.W.; Salwinski, L.; Baron, M.K.; Marcotte, E.M.; Eisenberg, D. DIP: The database of interacting proteins. Nucleic
Acids Res. 2000, 28, 289–291. [CrossRef]
57.
Hermjakob, H.; Montecchi-Palazzi, L.; Lewington, C.; Mudali, S.; Kerrien, S.; Orchard, S.; Vingron, M.; Roechert, B.; Roepstorff, P.;
Valencia, A.; et al. IntAct: An open source molecular interaction database. Nucleic Acids Res. 2004, 32, D452–D455. [CrossRef]
58.
Stark, C.; Breitkreutz, B.J.; Reguly, T.; Boucher, L.; Breitkreutz, A.; Tyers, M. BioGRID: A general repository for interaction datasets.
Nucleic Acids Res. 2006, 34, D535–D539. [CrossRef]
59.
Bader, G.D.; Betel, D.; Hogue, C.W. BIND: The Biomolecular Interaction Network Database. Nucleic acids Res. 2003, 31, 248–250. [CrossRef]
60.
Licata, L.; Briganti, L.; Peluso, D.; Perfetto, L.; Iannuccelli, M.; Galeota, E.; Sacco, F.; Palma, A.; Nardozza, A.P.; Santonico, E.; et al.
MINT, the molecular interaction database: 2012 update. Nucleic Acids Res. 2011, 40, D857–D861. [CrossRef]
61.
Zheng, G.; Tu, K.; Yang, Q.; Xiong, Y.; Wei, C.; Xie, L.; Zhu, Y.; Li, Y. ITFP: An integrated platform of mammalian transcription
factors. Bioinformatics 2008, 24, 2416–2417. [CrossRef] [PubMed]

## Page 33 (Section:  )

Int. J. Mol. Sci. 2021, 22, 166
33 of 33
62.
Bovolenta, L.A.; Acencio, M.L.; Lemke, N. HTRIdb: An open-access database for experimentally veriﬁed human transcriptional
regulation interactions. BMC Genom. 2012, 13, 405. [CrossRef] [PubMed]
63.
Wingender, E.; Chen, X.; Hehl, R.; Karas, H.; Liebich, I.; Matys, V.; Meinhardt, T.; Prüss, M.; Reuter, I.; Schacherer, F. TRANSFAC:
An integrated system for gene expression regulation. Nucleic Acids Res. 2000, 28, 316–319. [CrossRef] [PubMed]
64.
Min, H.; Yoon, S. Got target?: Computational methods for microRNA target prediction and their extension. Exp. Mol. Med. 2010,
42, 233–244. [CrossRef]
65.
Friard, O.; Re, A.; Taverna, D.; De Bortoli, M.; Corá, D. CircuitsDB: A database of mixed microRNA/transcription factor
feed-forward regulatory circuits in human and mouse. BMC Bioinform. 2010, 11, 435. [CrossRef]
66.
Li, J.-H.; Liu, S.; Zhou, H.; Qu, L.-H.; Yang, J.-H. starBase v2.0: Decoding miRNA-ceRNA, miRNA-ncRNA and protein-RNA
interaction networks from large-scale CLIP-Seq data. Nucleic Acids Res. 2014, 42, D92–D97. [CrossRef]
67.
Chen, B.S.; Wu, C.C. Systems Biology: An Integrated Platform for Bioinformatics, Systems Synthetic Biology and Systems Metabolic
Engineering; Nova Science Publishers: Hauppauge, NY, USA, 2014.
68.
Shlens, J. A Tutorial on Principal Component Analysis. arXiv 2005, arXiv:1404.1100.
69.
Gilson, M.K.; Liu, T.; Baitaluk, M.; Nicola, G.; Hwang, L.; Chong, J. BindingDB in 2015: A public database for medicinal chemistry,
computational chemistry and systems pharmacology. Nucleic Acids Res. 2016, 44, D1045–D1053. [CrossRef]
70.
Nandy, A.; Harle, M.; Basak, S.C. Mathematical descriptors of DNA sequences: Development and applications. Arkivoc 2006,
9, 211–238. [CrossRef]
71.
Khan, S.A.; Virtanen, S.; Kallioniemi, O.P.; Wennerberg, K.; Poso, A.; Kaski, S. Identiﬁcation of structural features in chemicals
associated with cancer drug response: A systematic data-driven analysis. Bioinformatics 2014, 30, i497–i504. [CrossRef]
72.
Dong, J.; Yao, Z.-J.; Zhang, L.; Luo, F.; Lin, Q.; Lu, A.-P.; Chen, A.F.; Cao, D.-S. PyBioMed: A python library for various molecular
representations of chemicals, proteins and DNAs and their interactions. J. Cheminformatics 2018, 10, 16. [CrossRef] [PubMed]
73.
Ezzat, A.; Wu, M.; Li, X.-L.; Kwoh, C.-K. Drug-target interaction prediction via class imbalance-aware ensemble learning. BMC
Bioinform. 2016, 17, 509. [CrossRef]
74.
Kingma, D.P.; Ba, J. Adam: A Method for Stochastic Optimization. arXiv 2014, arXiv:1412.6980.
75.
Bradley, A.P. The use of the area under the ROC curve in the evaluation of machine learning algorithms. Pattern Recognit. 1997,
30, 1145–1159. [CrossRef]
76.
Liu, Y.; Wu, M.; Miao, C.; Zhao, P.; Li, X.-L. Neighborhood Regularized Logistic Matrix Factorization for Drug-Target Interaction
Prediction. PLoS Comput. Biol. 2016, 12, e1004760. [CrossRef] [PubMed]
77.
Byvatov, E.; Fechner, U.; Sadowski, J.; Schneider, G. Comparison of Support Vector Machine and Artiﬁcial Neural Network
Systems for Drug/Nondrug Classiﬁcation. J. Chem. Inf. Comput. Sci. 2003, 43, 1882–1889. [CrossRef]
78.
Cao, D.S.; Zhang, L.X.; Tan, G.S.; Xiang, Z.; Zeng, W.B.; Xu, Q.S.; Chen, A.F. Computational Prediction of Drug Target Interactions
Using Chemical, Biological, and Network Features. Mol. Inform. 2014, 33, 669–681. [CrossRef]
79.
LeCun, Y.; Bengio, Y.; Hinton, G. Deep learning. Nature 2015, 521, 436–444. [CrossRef]
80.
Wen, M.; Zhang, Z.; Niu, S.; Sha, H.; Yang, R.; Yun, Y.; Lu, H. Deep-Learning-Based Drug–Target Interaction Prediction. J. Proteome
Res. 2017, 16, 1401–1409. [CrossRef]
81.
Chen, X.; Yan, C.C.; Zhang, X.; Zhang, X.; Dai, F.; Yin, J.; Zhang, Y. Drug–target interaction prediction: Databases, web servers
and computational models. Brief. Bioinform. 2016, 17, 696–712. [CrossRef]
82.
Wang, Z.; Liang, L.; Yin, Z.; Lin, J. Improving chemical similarity ensemble approach in target prediction. J. Cheminformatics 2016,
8, 20. [CrossRef] [PubMed]


---

# The emerging roles of artificial intelligence in cancer drug development and precision therapy

- **Authors:** Guosheng Liang, Wenguo Fan, Hui Luo, Xiao Zhu
- **Issuer:** Biomedicine & pharmacotherapy = Biomedecine & pharmacotherapie
- **Type:** Scientific article
- **Published:** 2020-05-20
- **Language:** en
- **DOI:** 10.1016/j.biopha.2020.110255
- **Source:** https://pubmed.ncbi.nlm.nih.gov/32446113/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Artificial intelligence (AI) has strong logical reasoning ability and independent learning ability, which can simulate the thinking process of the human brain. AI technologies such as machine learning can profoundly optimize the existing mode of anticancer drug research. But at present AI also has its relative limitation. In this paper, the development of artificial intelligence technology such as deep learning and machine learning in anticancer drug research is reviewed. At the same time, we look forward to the future of AI.
