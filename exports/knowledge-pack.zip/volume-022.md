# MISATO: machine learning dataset of protein-ligand complexes for structure-based drug discovery

- **Authors:** Till Siebenmorgen, Filipe Menezes, Sabrina Benassou, Erinc Merdivan, Kieran Didi, André Santos Dias Mourão, Radosław Kitel, Pietro Liò, Stefan Kesselheim, Marie Piraud, Fabian J Theis, Michael Sattler, Grzegorz M Popowicz
- **Issuer:** Nature computational science
- **Type:** Scientific article
- **Published:** 2024-05-10
- **Language:** en
- **DOI:** 10.1038/s43588-024-00627-2
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38730184/
- **Licence:** CC-BY

## Page 1 (Section: MISATO: machine learning dataset of protein–ligand complexes for structure-based drug discovery)

Nature Computational Science | Volume 4 | May 2024 | 367–378
367
nature computational science
https://doi.org/10.1038/s43588-024-00627-2
Resource
MISATO: machine learning dataset 
of protein–ligand complexes for 
structure-based drug discovery
Till Siebenmorgen 
  1,2,9, Filipe Menezes 
  1,2,9, Sabrina Benassou3, 
Erinc Merdivan4, Kieran Didi 
  5, André Santos Dias Mourão1,2, Radosław Kitel6, 
Pietro Liò5, Stefan Kesselheim 
  3, Marie Piraud4, Fabian J. Theis 
  4,7,8, 
Michael Sattler 
  1,2 & Grzegorz M. Popowicz 
  1,2 
Large language models have greatly enhanced our ability to understand 
biology and chemistry, yet robust methods for structure-based drug 
discovery, quantum chemistry and structural biology are still sparse. 
Precise biomolecule–ligand interaction datasets are urgently needed 
for large language models. To address this, we present MISATO, a dataset 
that combines quantum mechanical properties of small molecules and 
associated molecular dynamics simulations of ~20,000 experimental 
protein–ligand complexes with extensive validation of experimental  
data. Starting from the existing experimental structures, semi-empirical 
quantum mechanics was used to systematically refine these structures.  
A large collection of molecular dynamics traces of protein–ligand complexes 
in explicit water is included, accumulating over 170 μs. We give examples 
of machine learning (ML) baseline models proving an improvement of 
accuracy by employing our data. An easy entry point for ML experts 
is provided to enable the next generation of drug discovery artificial 
intelligence models.
In recent years, artificial intelligence (AI) predictions have revolution-
ized many fields of science. In structural biology, AlphaFold2 (ref. 1) 
predicts accurate protein structures from amino-acid sequences only. 
Its accuracy nears state-of-the-art experimental data. The success of 
AlphaFold2 is made possible due to a rich database of nearly 200,000 
protein structures that have been deposited and are available in the 
Protein Data Bank (PDB)2. These structures were determined over the 
past decades using X-ray crystallography, nuclear magnetic resonance 
(NMR) or cryo-electron microscopy. Despite enormous investments, 
there are still few new drugs approved yearly, with development costs 
reaching several billion dollars3. An ongoing grand challenge is rational, 
structure-based drug discovery (DD). Compared with protein structure 
prediction, this task is substantially more difficult.
In the early stages of DD, structure-based methods are popular 
and efficient approaches. The biomolecule provides the starting point 
for rational ligand search. Later, it guides optimization to optimally 
explore the chemical combinatorial space4 while still ensuring drug- 
like properties. In silico methods that are in principle able to tackle 
Received: 30 May 2023
Accepted: 11 April 2024
Published online: 10 May 2024
 Check for updates
1Molecular Targets and Therapeutics Center, Institute of Structural Biology, Helmholtz Munich, Neuherberg, Germany. 2TUM School of Natural 
Sciences, Department of Bioscience, Bayerisches NMR Zentrum, Technical University of Munich, Garching, Germany. 3Jülich Supercomputing Centre, 
Forschungszentrum Jülich, Jülich, Germany. 4Helmholtz AI, Helmholtz Munich, Neuherberg, Germany. 5Computer Laboratory, Cambridge University, 
Cambridge, UK. 6Faculty of Chemistry, Jagiellonian University, Krakow, Poland. 7Computational Health Center, Institute of Computational Biology, 
Helmholtz Munich, Neuherberg, Germany. 8TUM School of Computation, Information and Technology, Technical University of Munich, Garching, 
Germany. 9These authors contributed equally: Till Siebenmorgen, Filipe Menezes. 
 e-mail: grzegorz.popowicz@helmholtz-munich.de

## Page 2 (Section: Results)

Nature Computational Science | Volume 4 | May 2024 | 367–378
368
Resource
https://doi.org/10.1038/s43588-024-00627-2
states); overly simplified atomic properties; highly complex energy 
landscapes in molecular recognition by their targets. Attempts to 
train AI models currently require inferring this missing information 
implicitly. The limited number of publicly available protein–ligand 
structures (~20,000) and lack of thermodynamic data cause this infer-
ence to fail. This is preventing structure-based models from producing 
groundbreaking results31,32.
Here, we propose a protein–ligand structural database, MISATO 
(molecular interactions are structurally optimized) that is based on 
experimental protein–ligand structures. We show that the database 
helps to better train models across fields related to DD and beyond. 
This includes quantum chemistry, general structural biology and bio-
informatics. We provide quantum-chemical-based structural curation 
and refinement, including regularization of the ligand geometry. We 
augment this database with missing dynamic and chemical informa-
tion, including MD on a timescale allowing the detection of transient 
and cryptic states for certain systems. The latter are very important for 
successful drug design33. Thus, we supplement experimental data with 
the maximum number of physical parameters. This eases the burden 
on AI models to implicitly learn all this information, allowing focus on 
the main learning task. The MISATO database provides a user-friendly 
format that can be directly imported into machine learning (ML) codes. 
We also provide various preprocessing scripts to filter and visualize the 
dataset. Example AI baseline models are supplied for the calculation of 
quantum chemical properties (chemical hardness and electron affinity), 
for binding affinity calculation and for the prediction of protein 
flexibility or induced-fit features to simplify adoption. The QM, MD 
and AI baseline models are validated extensively on experimental data. 
We wish to transform MISATO into an ambitious community project 
with vast implications for the whole field of DD.
Results
MISATO dataset
The basis for MISATO (Fig. 1) is the 19,443 protein–ligand structures 
from PDBbind25. These structures were experimentally determined 
over the past decades and represent a diverse set of protein–ligand 
complexes for which experimental affinities are available. In the context 
of AI for DD it is of utmost importance to train the models on a dataset 
structure-based DD include semi-empirical quantum mechanical (QM) 
methods5, molecular dynamics (MD) simulations6,7, docking8 and 
coarse-grained simulations9, which can also be combined to be more 
efficient. However, these methods either suffer from generally low 
precision or are computationally too expensive while still requiring 
substantial experimental validation. Recent examples show that clas-
sical, ball-and-stick atomistic model representations of biomolecular 
structures might be too inaccurate in certain situations to allow for 
correct predictions10–13.
The introduction of AI into the process is still at an early stage. 
AI approaches are, in principle, able to learn the fundamental state 
variables that describe experimental data14. Thus, they are likely to 
abstract from electronic and force field-based descriptions of the 
protein–ligand complex. However, so far mostly simple solutions 
have been proposed that do not incorporate the available protein–
ligand data to their full extent, such as scoring protein–ligand Gibbs 
free energies15,16, ADME (absorption, distribution, metabolism and 
excretion) property estimation17 or prediction of synthetic routes18,19. 
Most of these approaches are constructed using one-dimensional 
SMILES (simplified molecular-input line-entry system)20,21 and only 
a few attempts have been made to properly tackle three-dimensional 
(3D) biomolecule–ligand data22–24.
Several databases are available that contain raw experimental 
structures of protein–ligand complexes, usually extracted from the 
PDB (for example, PDBbind25, bindingDB26, Binding MOAD27, Sper-
rylite28). Only recently a database of MD-derived traces of protein–
ligand structures was reported29,30. Despite these efforts, so far no AI 
model has been proposed that convincingly addresses the rational DD 
challenge in the way that AlphaFold2 answered the protein structure 
prediction problem31,32.
In addition to DD, the structure-based AI models are useful for 
biomolecule structure analysis and quantum chemistry. However, 
they are severely hindered by several factors: neglecting the confor-
mational flexibility (dynamics and induced fit upon binding); entropic 
considerations; inaccuracies in the deposited structural data (incorrect 
atom types due to missing hydrogen atoms, incorrect evaluation of 
functional group flexibility, inconsistent geometry restraints, fitting 
errors); chemical complexity (for example, non-obvious protonation 
PDB preparation
PDB structures
19,443
Automated QM
methods
Ligand
parametrization
Solvation and
heating
MD simulation
Calculation of
properties
Calculation of QM
properties
Semi-empirical
QM
FF MD
simulations
MISATO dataset
Data loaders
AI base line
models
b
a
Car
Car
Car
Nar
Nar
Car
N+
Csp
3
Csp
3
Csp
3
Csp
3
Csp
3
N?
Csp
3
0
Fig. 1 | MISATO combines QM data with MD-derived protein–ligand 
dynamics. a, We provide a dataset that combines semi-empirical QM properties 
of small molecules with MD-simulated dynamics of the entire set of experimental 
protein–ligand complexes. All common errors in protein and ligand 
nomenclature, protonation, geometry and so on are fixed. The blue outline of 
the molecule describes its electronic density. b, An overview of the dataset and 
the applied protocols for semi-empirical QM and FF (force field) MD simulations 
including data preparation, preprocessing and AI baseline models.

## Page 3 (Section: Typical limitations in structural datasets)

Nature Computational Science | Volume 4 | May 2024 | 367–378
369
Resource
https://doi.org/10.1038/s43588-024-00627-2
with the highest possible correctness and consistency, for several rea-
sons. First, the total number of available structures is much lower than 
typical training sizes of other AI targets. Second, ligand association 
has a rather complex energy landscape during molecular recogni-
tion. Delicate deviations in the protein–ligand structures or atomic 
parameters can markedly impair binding. In the PDB, incorrect atom 
assignments and inconsistent geometries are not uncommon. More 
seriously, hydrogen atoms are highly sensitive to their chemical and 
molecular environment and are rarely experimentally accessible. All 
these issues have been systematically addressed in our work and are 
compiled in our database (Figs. 2 and 3).
Typical limitations in structural datasets
Understanding the nature and sources of errors in structural databases 
is imperative for improving the quality of the underlying molecular 
models.
Macromolecule–ligand interaction strength, the most desired 
baseline parameter for DD, is unfortunately also the most inaccurate 
metric. The diverse experimental set-ups from experimental entropy/
enthalpy determination (for example, isothermal titration calorimetry) 
to cellular phenotypic response are given as ligand strength. These 
values are not comparable and their use to train AI models is generally 
unreliable. To enable validation of affinity prediction we have prepared 
a small subset of ligands with accurately determined affinities to be 
used as a benchmark (Supplementary Table 1). We also tested our 
example model against it.
As MISATO is founded on experimental data, the two main sources 
of structural inaccuracies must be corrected. These are limited spatial 
resolution of the experimental structures and problems and biases 
associated with the software used for processing the molecular geom-
etries. As well as the absence of hydrogen atoms in crystallographic 
structures, resolution affects the heteroatom geometry. Contracted 
or elongated bonds are common (Fig. 2). That is, most nitro groups we 
examined were heavily distorted: in the 1WUG structure34, NO bonds 
are almost 17% larger than reference experimental data35. Another 
example is seen in the 4MDN structure36, where an amide was so dis-
torted that it explicitly violated VSEPR (valence shell electron pair 
repulsion) theory. Reinspection of the experimental electronic density 
hinted that the CÔC angle in the 4-chlorobenzyl phenyl ether moiety 
is also larger by almost 20° against anisole, a reference compound for 
that bond angle35. Simultaneous relaxation of the two groups leads to 
substantial improvement, in particular an amide group very close to 
reference structural values. Such errors in the heteroatom skeleton 
propagate further when assigning and counting hydrogen atoms. In 
the 5GTR structure37, a guanidino group strongly deviates from the 
expected planarity. The immediate consequences are incorrect atomic 
hybridizations and overassignment of hydrogen atoms, with a local 
formal charge of +3 in a radius of one bond around the central carbon. 
More examples are described in Supplementary Information.
Evaluation of the QM-based ligand curation
Employing the protocol defined in Supplementary Section 6 we modi-
fied a total of 3,930 structures, which corresponds roughly to 20% of the 
original database that needed substantial refinement (Fig. 2). Of these, 
3,905 cases involve changes in protonation states, while changes in 
heteroatoms involve 97 ligands. These are predominantly the addition 
of model functional groups to emulate covalent binding with the pro-
tein (20) or the addition of missing hydroxyl groups to boronic acids.
20.2%
26.9%
73.1%
20.1%
26.8%
73.2%
–0.39
6.2
–0.19
15.7
–0.03
7.0
–0.31
5.9
–0.19
7.4
–0.49
6.4
1.4Å
1.4Å
b
a
e
d
c
1WUG
4MDN
5GTR
+
+
+
Natoms
Natoms
Charge
Halogen
F
Cl
Br
I
–0.8
5
10
Polarizability a0
3
15
20
25
30
35
–0.6
–0.4
–0.2
0
0.2
0.4
Nprotons
add
Nhydrogen
add
Nhydrogen
rem
Natoms
rem
Fig. 2 | Changes applied to the PDBbind database based on our quantum 
chemical protocol. a, Statistical overview of changes introduced by our 
optimization protocol. Natoms corresponds to total changes in the atom count 
when compared with the source database. In most cases atoms were removed 
Nrem
atoms); in only 27% of cases was the number of atoms increased, Nadd
atoms. Similar 
considerations apply to protons—light blue; Nprotons. b, D4 polarizability versus 
partial charge for all the halogens in the database. The outliers were analyzed to 
find possible wrong atom assignments. This was the case for the bromine atom in 
the lower right corner, which in reality is a boron. c, Examples of inconsistent 
structures: 1WUG contains overly elongated NO bonds; 4MDN contains a 
nitrogen in angular violation of VSEPR; 5GTR shows a typical problem in the 
protonation state. d,e, Calculated electronic density for ketamine (4G8H) and 
tramadol, respectively (dashed green lines). Dashed circles show the sizes of 
electronic density around selected atoms. The numbers next to these atoms 
represent partial charge (top) and atomic polarizability (bottom). These are 
electronic descriptors representing the electronic density around each center. 
Color and character keys: N, blue, nitrogen; S, yellow, sulfur; O, red, oxygen;  
C, beige, carbon; H, white, hydrogen; Cl, green, chlorine.

## Page 4 (Section: QM-derived properties)

Nature Computational Science | Volume 4 | May 2024 | 367–378
370
Resource
https://doi.org/10.1038/s43588-024-00627-2
Some ligands were split into several molecules as the original 
structures were not binary protein–ligand complexes (one ligand): 
1A0T, 1G42, 1G9D, 2L65, 3D4F and 4MNV. 1E55 is supposed to be a 
mixture of two entities. However, the closest contact between them 
is insufficient to consider them separately, but also too large for a 
covalent interaction. Similar considerations apply to 1F4Y, though here 
close intramolecular contacts are at stake. In 4AW8 we observed a sub-
stantial deformation for the published ligand, PG6. We observed that 
the reference affinity is related to the metal ion in the system, Zn(ii), 
and not to PG6. The structure was consequently excluded.
As depicted in Fig. 2, the most common adjustment was the 
removal of hydrogen atoms from the initial PDBbind geometry. This 
amounts to almost 75% of the modifications. It has been pointed out 
that libraries such as PDBbind possess biased datasets in terms of 
binding configurations31.
QM-derived properties
We calculated several molecular and atomic properties for the ligands 
(Supplementary Table 2). For the former, we include electron affinities, 
chemical hardness, electronegativity, ionization potentials (by defini-
tion and using Koopmans’ theorem), static log P and polarizabilities. 
The latter were obtained in vacuum, water and wet octanol. Atomic 
properties include partial charges from different models, atomic 
polarizabilities, bond orders, atomic hybridizations, orbital- and 
charge-based reactivity (Fukui) indices and atomic softness. Reactivity 
indices and atomic softness are derived for interactions with electro-
philes, nucleophiles and radicals. Finally, we also provide tight-binding 
electronic densities for all ligands. Partial charges were calculated at 
several levels, as these are somewhat method-sensitive quantities. AM1 
charges are usually the starting point for charge-correcting schemes 
to be used in MD simulations. This is the case for AM1-BCC38. Taking 
our AM1 charges and multiplying them by 1.14 (in the case of neutral 
molecules) yields 1.14*CM1A-LBCC charges39 used in OPLS-AA simula-
tions40. The main advantage of the charges we provide is that these were 
obtained, when required, with a HOMO (highest occupied molecular 
orbital)–LUMO (lowest unoccupied molecular orbital) level shift to 
ensure convergence to sensible electronic states. Beyond MD simula-
tions, CMx charges41–43 have also been shown to provide good estimates 
a
b
e
c
d
Ligand
Pocket
Fig. 3 | Overview of events captured by the MD simulations in the binding 
pocket. a–c, Reversible opening and closing of the binding pocket can be 
captured during the simulations, including cryptic binding sites. a, The structure 
of 2AM4 is shown after 2 ns (left panel), 6 ns (middle panel) and 10 ns (right panel) 
simulation time (fluorine in beige). b,c, The opening loop region (b, structure 
2LKK) is visualized for superimposed timesteps (blue diagram, dark hue, 2 ns; 
black diagram, medium dark hue, 6 ns; red diagram, light hue, 10 ns). The protein 
pocket opens in structure 8ABP during the simulation (c). d, Protein residues at 
the binding site can undergo large adaptations within the simulations, indicating 
unstable interactions or possible switches. This is shown for a methionine residue 
of 4ZYZ (upper panel) and a tryptophan residue of 1WAW (lower panel). Coloring 
as in b after 2 ns and 10 ns. e, MD simulations captured local adaptability of the 
binding pocket and ligand. That is, in structure 2IG0 parts of the ligand (licorice, 
carbons in ivory) are quite flexible in the protein pocket (gray carbons) when 
comparing the first (dark hue) and the last (light hue) frames of the MD run. Color 
and character keys, if not indicated differently: N, blue, nitrogen; S, yellow, sulfur; 
O, red, oxygen; C, black, carbon; H, white, hydrogen; F, beige, fluorine; P, orange, 
phosphorus.

## Page 5 (Section: MD simulations)

Nature Computational Science | Volume 4 | May 2024 | 367–378
371
Resource
https://doi.org/10.1038/s43588-024-00627-2
of molecular dipole moments, just like tight-binding Mulliken charges44. 
From the latter, we infer furthermore the reasonableness of the elec-
tronic densities provided.
MD simulations
Experimental structural data are static snapshots that are assumed 
to represent a thermodynamic most stable state trapped in a crystal 
but ignore the presence of conformational dynamics. Experimental 
description of dynamics in biological macromolecules from nanosec-
ond to millisecond timescales is challenging and requires a combina-
tion of different spectroscopic techniques. NMR spectroscopy and 
fluorescence-based methods can provide relevant information but are 
time consuming, and so far the dynamic information is not well cap-
tured in public databases. MD simulations can be performed, starting 
from experimental structures, and letting them evolve in time using a 
force field that describes the molecular potential energy surface. Typi-
cally, periods of nanoseconds to microseconds can be achieved for indi-
vidual systems, depending on system size. MD traces allow the analysis 
of small-range structural fluctuations of the protein–ligand complex, 
but in some cases large-scale rare events can be observed (Fig. 3). In 
existing DD software these events are mostly neglected. MD simulations 
of 16,972 protein–ligand complexes in explicit water were performed 
for 10 ns. Structures were disregarded whenever non-standard ligand 
atoms or inconsistencies in the protein starting structures were encoun-
tered. A variety of metadata were generated from the simulations to 
facilitate future AI learning (Fig. 4, Supplementary Table 2 and Supple-
mentary Fig. 1). RMSDLigand (root-mean-square deviation of the ligand 
after alignment of the protein) and the root-mean-square deviation of 
the whole complex were calculated with respect to the native structure. 
Also, binding affinities were estimated using molecular mechanics 
generalized Born surface area (MMGBSA) scoring (no entropic contri-
butions explicitly considered)45. Moreover, the buried solvent acces-
sible surface area was obtained for the complex. Calculated properties 
are stable over the simulations, proving them well equilibrated (Sup-
plementary Fig. 1). For some systems, larger rearrangements of the 
binding site were captured that in extreme cases led to an opening of 
the whole binding pocket (Fig. 3). These rare events indicate possible 
cryptic pockets or transient binding modes. In a small fraction of cases, 
dissociation was detected (details given in Supplementary Fig. 2).
AI models
To exemplify possible applications of our dataset, baseline AI models 
were trained and evaluated. These are included in the repository as a 
template for future community development. For the QM dataset, the 
electron affinity and the chemical hardness of the ligand molecules 
were predicted (Fig. 5). The Pearson correlation is 0.75 for electron 
affinity and 0.77 for chemical hardness. The mean absolute error shows 
close predictions to the target values: on average 0.12 eV for electron 
affinity and 0.13 eV for chemical hardness. For these two exemplary 
QM features, high accuracy was achieved, opening a route to a fast 
derivation of QM properties. This is particularly important for larger 
molecules, where long calculation times are frequent.
For the MD traces, the induced-fit capability of the protein (adapt-
ability) was predicted (see Methods for an exact definition). The model 
was able to identify elements of biomolecule structure likely to adapt 
to ligand binding. We achieved a mean Pearson correlation of 0.66. 
On average 42 of the top 100 atoms were correctly predicted (Fig. 5). 
As shown in Fig. 5d, the model can predict the atoms in the protein 
pocket that are mostly flexible during the MD run (large spheres), and 
detect the more rigid protein regions (small spheres). This allows a fast 
QM H5 file
Atom_properties
10GS
11GS
13GS
9ICD
9HVP
....
Mol_properties
Atom_names
Bonds
Atom_properties_
names
Atom_properties_
values
Total_charge
Electron_aﬀinity
Electronegativity
Hardness
Ionization_potential
Koopman
Molecular_weight
Polarizability
Molecule property names
Molecule properties
Molecule properties
PDBIDs
MD H5 file
Atom_element
Atom_number
Atoms_residue
Atom_type
Frames_bSASA
Frames_distance
Frames_
interaction_energy
Frames_
rmsd_ligand
Molecule_begin_
atom_index
Trajectory_
coordinates
Fig. 4 | Data hierarchy of the QM and MD files. The QM data can be accessed via 
the PDB ID. The properties are split by atom properties and molecular properties. 
Examples of the calculated molecular properties are given. The electronic 
densities are provided in a separate file. The MD data are also subdivided by PDB 
ID. The properties are calculated either for all atoms, for each timestep (frame), 
or for the whole trajectory, as indicated by the name.

## Page 6 (Section: Experimental validation)

Nature Computational Science | Volume 4 | May 2024 | 367–378
372
Resource
https://doi.org/10.1038/s43588-024-00627-2
examination of the protein pocket without the necessity of a lengthy 
MD setup and simulation. The adaptability model gives an innovative 
example of how experimental structures can be enhanced from the 
MD-based MISATO data.
A binding affinity AI model combines MISATO MD and QM data. 
Experimental binding affinities are known to be difficult to compare 
across different experimental techniques, experimental conditions 
and calculated affinity types. To decrease these effects, our affinity 
model predicts a relative affinity of a target structure in relation to a 
defined base complex. These pairs have the protein and affinity type 
in common. We achieved high correlations for the MISATO binding 
affinity benchmark, with improved results using MISATO features when 
compared with no MISATO features (Fig. 6).
Experimental validation
The MISATO database and the adaptability AI model were validated 
on experimental data (Fig. 6). In X-ray crystallography a B factor is 
determined for each structure in the PDB. It is a measure of the thermal 
vibration of each atom but usually reflects localized molecular motion 
as well46. We achieved a mean correlation of 0.59 of the B factors with the 
root-mean-square fluctuation (RMSF) in the MISATO MD trajectories. 
To prove the model against more direct experimental flexibility data, 
we measured the cap-binding domain of influenza virus polymerase 
subunit PB247 as a model system. Heteronuclear Overhauser effect 
(hetNOE) NMR measurements, which elucidate flexible protein regions 
in solution, were performed on this structure (Supplementary Fig. 3). 
We obtained a high correlation between the calculated adaptabili-
ties and both B factors (0.63) and the hetNOE of the protein. A com-
parison with our adaptability prediction shows that the most flexible 
regions and the residues of higher rigidity are correctly identified by 
the model. Quantum chemical methods are required to predict rea-
sonable values for ionization potentials and electron affinities48. This 
applies not only to DFT (density functional theory) but also to ab initio. 
In Supplementary Data 1 we provide a parameter study performed with 
Target adaptability
Predicted adaptability
b
a
d
c
12.0
Electron aﬀinity
Chemical hardness
Target
Target
Target
Adaptability 2ig0—correlation 0.75
11.5
11.0
10.5
Prediction
Probability
10.0
9.5
9.0
0.02
0.04
0.06
0.08
0.10
0
0.2
0.3
0.4
0.5
0.6
Correlation
Mean 42
Correct top 100
0
20
40
60
80
Structure correlations mean 0.66
0.7
0.8
0.9
12.0
11.5
11.0
10.5
10.0
9.5
9.0
12.0
12.5
11.5
11.0
10.5
Prediction
10.0
9.5
12.0
12.5
11.5
11.0
10.5
10.0
9.5
5
5
6
6
4
4
3
3
2
2
Prediction
1
1
0
0
Probability
0.02
0.04
0.06
0.08
0.10
0
Fig. 5 | Performance of the AI baseline models. a, Scatter plot of the predicted 
against target values of chemical hardness and electron affinity. The AI baseline 
models to predict QM properties have a high correlation of 0.75 and 0.77 for 
electron affinity and chemical hardness, respectively. b, Adaptability is a 
measure of the per-atom conformational plasticity of the protein. A histogram 
of the correlation and the correct top 100 predictions of the adaptability for all 
structures in the test set are given. An overall mean correlation of 0.66 can be 
achieved and the mean top 100 accuracy was 0.42 for the adaptability predictions 
(MD). c, Scatter plot for the adaptability result (as in a) of example structure 2IG0. 
The predicted values are more narrowly distributed than the actual values,  
but the general trend is correct, as shown by a high correlation value of 0.75.  
d, The adaptability of the residues in the protein pocket highly deviates between 
the amino acids. The AI model predicts the adaptability given in blue-shaded 
(target) and red-shaded (AI-predicted) spheres. The radius is scaled according to 
the adaptability value. The model can correctly identify the rigid residues (small 
spheres) but also the amino acids with high flexibility. Color and character keys: 
N, blue, nitrogen; S, yellow, sulfur; O, red, oxygen; C, beige for ligand atoms and 
black for protein atoms, carbon.

## Page 7 (Section: Binding affinity benchmark and validation)

Nature Computational Science | Volume 4 | May 2024 | 367–378
373
Resource
https://doi.org/10.1038/s43588-024-00627-2
data collected from the CCCBDB database35, verifying the generality 
of trends reported in the literature48,49. The parameter study shows 
furthermore that semi-empirical ionization potentials are of a quality 
similar to, if not higher than, the best DFT results. The advantage, however, 
is that we systematically apply the same level of theory for all molecules, 
small and very large alike. We validated the ULYSSES-based calculations 
of Koopmans ionization potentials against experimental oxidation 
potentials and DFT-based ionization potentials from the literature 
for three molecule families. Our calculations correlated highly for 
photocatalysts (0.84, experimental oxidation potential), catechins 
(0.68, experimental oxidation potential) and thiaflavans (0.97, calcu-
lated DFT data).
Binding affinity benchmark and validation
The numerical values describing ligand potency cannot serve as a reli-
able baseline due to their origin in a wide range of experiments and 
conditions. These errors in the ground truth cannot be averaged out 
efficiently. Therefore, we collected high-quality affinity data for 127 
ligands for five different protein structures for a MISATO binding affinity 
benchmark set (Supplementary Table 1 and Supplementary Data 2)50–54. 
This set, being too small for training, can be a reliable validation method 
for affinity-predicting models. To guarantee reliable affinity data we 
filtered it to originate from the same publication for each set. Moreover, 
each of the sets had at least 15 entries with a high dynamical range and 
few additional occurrences of the protein structure within MISATO.
Our binding affinity graph convolutional network model was 
evaluated on this benchmark set with and without MISATO features. 
Additionally, we evaluated the model performance on the original 
PDBbind set, and using the Vina scoring function. With MD-derived 
adaptabilities and QM charges, we obtained a mean Spearman correla-
tion of 0.64, which was higher than without the MISATO features (0.50), 
using Vina (0.51) and using the non-curated database (0.50). Inter-
estingly, an improvement for each of the five sets using the MISATO 
features could be achieved.
As confirmation of the given results, we evaluated the affinity 
model on a second benchmark set comprising the six largest clusters of 
protein structures (clustered on the basis of UniProt ID) of the test set 
(Supplementary Table 3). These clusters are substantially larger than 
the sets from the MISATO benchmark and do not necessarily originate 
from the same publication and the same experimental method within a 
set. The absolute correlations decreased for this second, more diverse 
benchmark (Supplementary Fig. 4). Still, we see the same trend as for 
the first benchmark with a better performance of the MISATO model 
including adaptability and QM features than the other approaches.
Finally, consistent improvement of affinity prediction model 
accuracy upon inclusion of QM and dynamic features was observed for 
the entire curated set as well as selected subsets with high-confidence 
affinity values (Fig. 6 and Supplementary Figs. 4 and 5). This empha-
sizes the importance of curation of ligand data and inclusion of at least 
short-term dynamics in the accuracy of affinity predictions.
Correlation to experimental binding aﬀinities
a
b
d
R2 = 0.974
7.5
8.0
8.5
9.0
9.5
10.0
DFT IP (V)
Thiaflavans
R2 = 0.6823
10.10
10.12
10.14
10.16
10.18
10.20
10.22
10.24
Oxidation potential (V)
Catechins
R2 = 0.8386
7.0
7.5
8.0
8.5
9.0
9.5
10.0
10.5
11.0
11.5
12.0
1.00
1.05
1.10
1.15
1.20
1.25
1.30
1.35
1.40
0.40
0.45
0.50
0.55
0.60
0.65
0.70
0.75
0.80
0.85
0.90
–1.2
–0.7
–0.2
0.3
0.8
1.3
1.8
Oxidation potential (V)
Photocatalysts
Koopman IP (eV)
c
e
1.0
5,000
4,000
3,000
2,000
1,000
0
Vina
Not curated
MISATO curation
MISATO dynamic and QM features
Correlation of Bfactors per structure: mean
0.59 ± 0.12
0.8
0.6
0.2
0.4
Spearman correlation
Count
0
Mean 1,043 5A/0
2VQZ correlation 0.63
Adaptability
Adaptability
Residue count
20
–1.0
–1*hetNOE
–0.8
–0.6
–0.4
–0.2
0
0.5
1.0
1.5
2.0
2.5
40
60
80
100
120
140
160
20
40
60
80
100
120
140
160
1
10
20
30
40
B-factor
50
60
70
2
3
4
5
5NJZ
5Q0I 6QQT
–0.2
0
0.2
0.4
Correlation
0.6
0.8
1.0
Fig. 6 | Experimental validation of QM calculations, MD traces and AI models. 
a, Spearman correlation of the affinity GNN model on the binding affinity 
benchmark including MISATO features and without features. Moreover, the 
results using Vina and non-curated complexes (original PDBbind) are shown. 
We achieved a consistently better performance including QM charges and MD 
adaptabilities as MISATO features across the affinity benchmark when compared 
with all other approaches. b, Histogram of the correlation of experimental  
B factors from X-ray crystallography experiments with RMSF calculations from 
the MD simulations in MISATO. A correlation of 0.59 over all structures was 
achieved. c, High correlations of calculated Koopmans ionization potentials (IP) 
from ULYSSES with DFT ionization potentials (upper panel) and experimental 
oxidation potentials (middle and lower panels) were found for different molecule 
families. d, The cap-binding domain of influenza virus polymerase as a model 
system for experimental validation of the predicted adaptability. Values given 
by our AI model had a high correlation of 0.63 against the experimentally 
determined B factors (which, despite characterizing atom thermal vibration, 
usually indicates flexibility). e, Results of the hetNOE experiments of the 
cap-binding domain of influenza virus polymerase indicating flexibility of the 
protein chain were in high accordance with the results of the adaptability model 
(indicated using shaded regions).

## Page 8 (Section: Discussion)

Nature Computational Science | Volume 4 | May 2024 | 367–378
374
Resource
https://doi.org/10.1038/s43588-024-00627-2
The given experiments show that adding the features present in 
MISATO improves model accuracy over relying on implicit learning 
from the bare structure.
Discussion
The great advances over the past years of AI technologies were only 
possible due to the huge datasets that are fed into these models. In 
structural biology, the protein folding problem was solved recently, 
but the DD community still lacks a breakthrough model.
Here, we present MISATO, a database that will open routes in DD 
for researchers from chemistry, structural biology, biophysics and 
bioinformatics. MISATO contains the quantum-chemically refined 
ligand dataset, which permitted the elimination of several structural 
inaccuracies and crystallographic artifacts. Our refinement protocol 
can be immediately applied by others for quick database augmenta-
tion. We enhance the curated dataset following two orthogonal dimen-
sions. On the one hand, a QM approach supplies systematic electronic 
properties. On the other hand, a classical approach reveals the system’s 
dynamics and includes the binding affinity and conformational 
landscape. MISATO contains the largest collection of protein–ligand 
MD traces to date. Extensive experimental validation of the QM calcula-
tions, MD trajectories and AI baseline models highlights the dataset’s 
importance (Fig. 6).
Checkpoint files are made available for potential community 
extension of the dynamic traces (Supplementary Table 4). Struc-
tural biology datasets until now have been unable to incorporate 
entropy-related information about binding sites and the dynamics of 
the systems. By conducting MD simulations, it is possible to approxi-
mate the conformational space for entropy estimation. A Python inter-
face, built to be intuitively used by anyone, provides preprocessing 
scripts and template notebooks.
The current limitations of MISATO include the fact that until now 
the QM calculations were only conducted on the ligand molecules. 
Moreover, longer timescales of the MD simulations are desirable. These 
limitations are related to the availability of computing resources. With 
future releases of MISATO these points will be addressed.
The dataset augmentation presented here paves the way for creative 
applications of AI models. Our example graph neural network (GNN) 
model offers quick access to pocket flexibility, a problem never tackled 
before. This is however just a starting point for a whole class of AI models 
sprouting from MISATO. Ultimately, we envision models being built 
on the best of quantum and Newtonian worlds to obtain high-quality 
thermodynamics, innovatively and efficiently matching the quality of 
experimental data. With MISATO, AI models will uncover hidden state 
variables describing protein–ligand complexes.
Altogether, MISATO is meant to provide sufficient training power 
for accurate, next-generation structure-based DD using AI methods.
Methods
Semi-empirical calculations
QM calculations were performed using the ULYSSES library55, our 
in-house semi-empirical package. The methods of choice were 
GFN2-xTB56, AM1 (ref. 57) and PM6 (ref. 58). Implicit solvation was 
included using ALPB59 as parameterized for GFN2-xTB. Selected media 
included water and wet octanol. Bond orders and hybridizations were 
estimated using distance-based criteria.
QM curation of ligand space
Consistent atomic assignments were determined using a series of 
semi-empirical tests. Semi-empirical quantum chemical methods offer 
a good compromise between accuracy and computational efficiency60, 
which is suitable to refine a collection of almost 20,000 structures of 
various chemical natures and dimensions (from 6 to almost 370 atoms 
per molecule). The consistency tests we designed were performed in 
vacuum to ensure maximum sensitivity of the calculations to structural 
inconsistencies. Predicted properties, however, are also obtained using 
an implicit solvation model.
It is well documented that molecules with many polar groups 
lack convergence in wavefunction optimization61. The same applies 
when incorrect charges or protonation states are used. Implicit sol-
vation substantially ameliorates the issue and masks problems. In 
fact, after determining the first guess for total molecular charges, 
single-point-energy calculations on unrefined ligands using implicit 
water required roughly 6 h of computation time. Turning off implicit 
solvation increased the calculation time to almost three weeks on the 
same machine. This was indicative of severe limitations in proton and 
total charge assignment. Alternative protonation algorithms were 
tested—for example, Open Babel62. Due to experimental inaccuracies in 
the geometries, the results were still faulty (Supplementary Figs. 6–9).
Our refinement protocol started with a search for structures with 
strong atomic overlap. Next, we looked for structures with problematic 
wavefunction convergence. Vanishing HOMO–LUMO gaps or unpaired 
electrons flagged further problems, as did violations of the octet rule 
based on QM population analysis. Finally, we searched for changes in 
ligand connectivity patterns after QM geometry optimization. This was 
particularly useful in determining inconsistent protonation states or 
incorrect electron counting, which generated biradicals. Calculated 
properties yielded additional testing grounds. Incorrect element 
assignments were detected when plotting the partial charges against 
D4 polarizabilities63 (Fig. 2b).
Severe structural deformations were also detected, inconsistent 
with the chemical structure (see previous section). For the current stage 
of the database, we decided to fix only the most extreme cases. This 
was done using Avogadro (Supplementary Fig. 10)64. Further structural 
refinement is planned.
Whenever our corrections seemed questionable, or the structure 
was unclear, we checked the original publication. Oxidation states 
were another sensible point for ligands containing transition metals. 
Examples of structures we refined are given in the Supplementary 
Information (Supplementary Figs. 10–12). To ease the inclusion and 
processing of new structures, a heuristics-based program is included 
in the database, which performs the basic structural processing (see 
Supplementary Information for more details). A detailed schematic for 
the protocol used for cleaning and refining the structures is also given 
in the Supplementary Information (Supplementary Figs. 13 and 14).
MD simulations
For all MD simulations, we used the Amber20 (ref. 65) software suite. 
The protein–ligand complexes were prepared and simulated on the 
basis of a standard set-up. We parameterized the ligands calculating 
AM1-BCC38 charges using antechamber66 (if the charges did not con-
verge within 1 h we used AM1 charges calculated with ULYSSES). We used 
the gaff2 (ref. 66) force field for ligands and ff14SB67 for the proteins. 
The complexes were neutralized with Na+ and Cl− ions and solvated in 
TIP3P68 explicit water using periodic boundary conditions in an octa-
hedral box (minimum distance between protein and boundary 12 Å).
The complexes were minimized (1,000 steps steepest descent 
followed by conjugate gradient) and heated to 300 K in several steps 
within 16 ps. We performed production simulations for 10 ns on all 
protein–ligand cases in an NVT ensemble. The first 2 ns were discarded 
as equilibration phase, so 8 ns are stored over 100 snapshots for each 
protein–ligand complex. Using pytraj31 we calculated different proper­
ties of the simulations such as the MMGBSA interaction energy, the 
buried solvent accessible surface area, the center-of-mass distance 
between ligand and receptor, and root-mean-square deviations from 
the native complex.
Access to the database
The database can be downloaded from Zenodo (Supplementary 
Table 4). Data are stored in a hierarchical data format. We created two

## Page 9 (Section: AI applications)

Nature Computational Science | Volume 4 | May 2024 | 367–378
375
Resource
https://doi.org/10.1038/s43588-024-00627-2
H5 files, one for the protein–ligand dynamics and one for quantum 
chemical data, that can be accessed through our container images or 
after installation of the required Python packages. Installation instruc-
tions are given in the repository (Supplementary Table 4). Data are split 
for each structure using the PDB ID. The feature of interest must also be 
specified (Fig. 4 and Supplementary Table 2). Python scripts are given 
in the repository showing how to preprocess the MD dataset for specific 
cases, only Cα atoms, no hydrogen atoms, only atoms from the binding 
pocket, and the inclusion of new features. Instructions on how to run 
inference on new PDB files and visualize the baseline models are given. 
Checkpoint files for continuing the MD simulations and the electronic 
densities are provided separately.
AI applications
For the baseline model for QM predictions, we followed the GNN 
architecture for small-molecule property prediction in ATOM3D69. 
This model is based on graph convolutions proposed by Kipf and 
Welling70 and was adapted for the simultaneous prediction of electron 
affinity and chemical hardness as essential parameters to describe 
the ligand. The architecture for the baseline model was a dense layer 
followed by three sequential layers of NNConv and GRU followed by 
two dense layers. The model is available via our GitHub repository.
The performance of the ML model was evaluated using correlation 
and the mean absolute error.
We encode each molecule using the atom positions, the atom type 
and the bond between the atoms. Each atom corresponds to a node. 
The atom types are one-hot encoded and edges are defined by select-
ing the nearest neighbors with a distance of 4.5 Å for each atom. Edges 
are weighted inversely by the distance between the atoms. We removed 
outliers straying more than 20 s.d. from the mean values (PDB IDs given 
in Supplementary Information). All outliers corresponded to molecules 
containing negatively charged groups and alkyl chains. In other words, 
these are highly saturated molecules from the electronic viewpoint. 
Because of their electronic structure, acceptance of an electron is highly 
unlikely, resulting in very low-to-negative electron affinities. Inaccuracies 
in the geometries further exacerbate the calculated electron affinities. 
The results on these systems indicate that some electronic properties are 
not quantitative; instead, they simply reflect the system’s behavior. We 
trained the GNN with four NVIDIA A100 graphics processing units (GPUs) 
and 96 CPUs (from 48 physical cores) and for 200 epochs. We used a batch 
size of 128 and applied a random translation on each node of 0.05 Å.
For the MD task, we modified the GNN architecture from ATOM3D69 
for the node regression task by removing the aggregation of node fea-
tures into graph features. The architecture for the baseline model was 
five sequential GCNConv layers70 followed by two linear layers, sum-
ming to 370,000 trainable parameters. The dataset was split into a train 
(80%), a test (10%) and a validation set (10%) (Supplementary Table 5 
and Supplementary Fig. 15) by clustering the amino-acid sequences of 
the proteins using BlastP71 to make sure to not have a leakage of similar 
structural motifs between the splits. We train the GNN with four NVIDIA 
A100 GPUs and 96 CPUs and for 15 epochs. We use a batch size of eight 
and a random translation of 0.05 Å. With our model, we calculated the 
adaptability of each atom during the MD simulation. To this end, we 
performed an alignment of the coordinates of each simulation with 
reference to the first frame. To calculate the adaptability γx for each 
atom x we take the mean distance of each atom over all timesteps i from 
the initial position of the atom rref,x:
γx =
1
Nframes
Nframes
∑
i
||(rref,x −ri,x)|| .
Hydrogen atoms were omitted to reduce the size of the model. For 
the evaluation, the mean over the results for each structure was calcu-
lated. Adaptability gives results very similar to those of RMSF evalu-
ations. We evaluated the performance of our training using Pearson 
correlation and the average accuracy of the 100 most flexible atoms 
of each complex.
For the binding affinity task, the data processing, training 
procedure and GNN architecture were modified. For data processing, 
all protein–ligand complexes (excluding 1,192 protein–peptide com-
plexes) with known binding affinity were clustered at 30% sequence 
similarity to avoid data leakage between training (82%), validation (9%) 
and test (9%) sets (Supplementary Fig. 15). The MISATO affinity bench-
mark was a holdout part of the test set. Next, clusters were defined on 
the basis of the UniProt identifier and affinity type, so that each cluster 
contained only affinity values of the same protein and one of the three 
affinity types present in the dataset (Ki, Kd, IC50).
The model predicts the ratio of binding affinities between a pair 
of protein–ligand complexes. For each cluster, one base molecule 
was defined that built a pair with each entry of the cluster. The pro-
tein–ligand complexes for which no cluster with at least two entries 
could be defined were discarded (2,259 entries). The atom types were 
one-hot encoded (omitting hydrogen atoms), and edges were defined 
following the adaptability model.
One training step consisted of one forward pass for each of the 
two complexes and mean squared error loss calculation based on the 
logarithmic ratio of the affinities for each pair. We trained a model 
including MISATO features and without MISATO features. MISATO 
atom features comprised calculated adaptabilities (MD) and GFN2-xTB 
charges in water (QM) for the ligands.
For the GNN architecture, five sequential GCNConv layers were 
followed by a separate pooling operation for the ligand and protein, 
respectively. These representations were then further processed via 
three linear layers with ReLU nonlinearities.
We trained the GNN with four GPUs, 90 CPUs, a batch size of 50 and 
for 50 epochs. We evaluated the best models on the MISATO affinity 
benchmark using Spearman correlation on each set.
We used PyTorch v.1.14 to train the models. To code the data load-
ers and the GNN, we used PyTorch Geometric 2.3.0.
Scoring of ligands with AutoDock Vina
We calculated an AutoDock Vina9 score for the MISATO refined pro-
tein–ligand complexes of both benchmark sets. We followed a standard 
preprocessing procedure of generating pdbqt files (see ref. 72 to follow 
the exact steps). For the receptors we used the prepare_receptor tool on 
the protonated protein structure from ADFR Suite73,74. For the ligands 
we converted the structures from MOL2 format to pdbqt format using 
the mk_prepare_ligand.py script. We computed the Vina scores from 
the generated pdbqt files using the score function from the Python 
interface of Vina (all scripts can be found via the GitHub page of Vina).
Correlation with experimental B factors
The experimental B factors were parsed from published PDB files of 
crystal structures. For data cleaning, we omitted structures for which 
80% of the published B factor values had the same entry. Additionally, 
for some structures, it was not possible to parse the B factors correctly 
due to inconsistencies in the underlying PDB files. The RMSF of each 
atom of the MD simulation was calculated after superposition to the 
first frame using pytraj31.
Binding affinity benchmark
The benchmark was created by identifying structures in MISATO that 
originated from the same publication with at least 15 entries. The 
benchmark was carefully evaluated by assessment of the publication 
for each of the sets. Only high-quality experimental techniques and 
data were considered. We further removed sets with a small dynamic 
range of the affinity data, high coexistence of structures of the same 
protein within MISATO, and sets with cofactors or metals interacting 
at the binding site. We obtained a benchmark consisting of five protein 
sets and 127 bound ligands.

## Page 10 (Section: Protein purification and NMR spectroscopy)

Nature Computational Science | Volume 4 | May 2024 | 367–378
376
Resource
https://doi.org/10.1038/s43588-024-00627-2
Protein purification and NMR spectroscopy
The influenza PB2 domain was expressed and purified as previously 
published47. NMR data were acquired at 298 K using a 0.8 mM 13C- 
15N-PB2 sample on an AV600 spectrometer equipped with a cryoprobe. 
The sample buffer contained 20 mM sodium phosphate at pH 6.5, and 
100 mM NaCl. Standard NMR experiments were used for chemical shift 
assignments, mainly HNCA, HNCACB, CBCACONH, HNCO, CCONH and 
HCCH/TOCSY (total correlation spectroscopy). Spectra were processed 
with the nmrDraw/NMRPipe package75 and analyzed with NMRView76.
Statistics and reproducibility
The splits for train, test and validation were randomized for the differ-
ent ML models. The exact procedure for each model is given in Supple-
mentary Fig. 15. No statistical method was used to predetermine sample 
size. For MD, structures were disregarded whenever non-standard 
ligand atoms (metal ions) or inconsistencies in the protein starting 
structures were encountered. For the QM model (Supplementary 
Section 3), a small number (30) of structures were omitted due to the 
inability of the current algorithm to provide correct predictions for 
them. This does not introduce a bias to the observation and does not 
change our observations.
The investigators were not blinded to allocation during experi-
ments or outcome assessment.
Reporting summary
Further information on research design is available in the Nature 
Portfolio Reporting Summary linked to this article.
Data availability
MISATO is publicly accessible and can be downloaded from Zenodo77 
(https://zenodo.org/records/7711953). We provide instructions for 
usage, data loaders via our GitHub repository, and a container image 
with all relevant packages installed for GPU usage (Supplementary 
Table 4). MISATO was built from the PDBbind database (release 2022). 
Source Data are provided with this paper.
Code availability
The code can be accessed from our GitHub repository and on Zenodo78 
(https://github.com/t7morgen/misato-dataset). The dataset is acces-
sible via a Python interface using a simple PyTorch data loader. Special 
attention was given to code modularity, which makes it easy to adjust 
the AI architecture (Fig. 4 and Supplementary Section 7). We have 
implemented our dataset according to the ATOM3D69 code base, a 
comprehensive suite of ML methods for molecular applications.
References
1.	
Jumper, J. et al. Highly accurate protein structure prediction with 
AlphaFold. Nature 596, 583–589 (2021).
2.	
Berman, H., Henrick, K. & Nakamura, H. Announcing the 
worldwide Protein Data Bank. Nat. Struct. Mol. Biol. 10, 980 (2003).
3.	
Mohs, R. C. & Greig, N. H. Drug discovery and development: role 
of basic biological research. Alzheimer’s Dement. Transl. Res. Clin. 
Interv. 3, 651–657 (2017).
4.	
Sliwoski, G., Kothiwale, S., Meiler, J. & Lowe, E. W. Computational 
methods in drug discovery. Pharm. Rev. 66, 334–395 (2014).
5.	
Thiel, W. Semiempirical quantum-chemical methods.  
WIREs Comput. Mol. Sci. 4, 145–157 (2014).
6.	
Hollingsworth, S. A. & Dror, R. O. Molecular dynamics simulation 
for all. Neuron 99, 1129–1143 (2018).
7.	
Siebenmorgen, T. & Zacharias, M. Computational prediction of 
protein–protein binding affinities. WIREs Comput. Mol. Sci. 10, 
e1448 (2020).
8.	
Trott, O. & Olson, A. J. AutoDock Vina: improving the speed and  
accuracy of docking with a new scoring function, efficient optimi­
zation, and multithreading. J. Comput. Chem. 31, 455–461 (2010).
9.	
Kmiecik, S. et al. Coarse-grained protein models and their 
applications. Chem. Rev. 116, 7898–7936 (2016).
10.	 Spicher, S. & Grimme, S. Robust atomistic modeling of materials, 
organometallic, and biochemical systems. Angew. Chem. Int. Ed. 
59, 15665–15673 (2020).
11.	
Vandenbrande, S., Waroquier, M., Speybroeck, V. V. & Verstraelen, 
T. The monomer electron density force field (MEDFF): a physically 
inspired model for noncovalent interactions. J. Chem. Theory 
Comput. 13, 161–179 (2017).
12.	 Wang, J. & Dokholyan, N. V. Yuel: improving the generalizability of 
structure-free compound–protein interaction prediction. J. Chem. 
Inf. Model. 62, 463–471 (2022).
13.	 Ponder, J. W. et al. Current status of the AMOEBA polarizable force 
field. J. Phys. Chem. B 114, 2549–2564 (2010).
14.	 Chen, B. et al. Automated discovery of fundamental variables 
hidden in experimental data. Nat. Comput Sci. 2, 433–442 (2022).
15.	 Durrant, J. D. & McCammon, J. A. NNScore: a 
neural-network-based scoring function for the characterization 
of protein−ligand complexes. J. Chem. Inf. Model. 50, 1865–1871 
(2010).
16.	 Wang, X., Terashi, G., Christoffer, C. W., Zhu, M. & Kihara, D. Protein 
docking model evaluation by 3D deep convolutional neural 
networks. Bioinformatics 36, 2113–2118 (2020).
17.	 Wang, N.-N. et al. ADME properties evaluation in drug discovery: 
prediction of Caco-2 cell permeability using a combination of 
NSGA-II and boosting. J. Chem. Inf. Model. 56, 763–773 (2016).
18.	 Ishida, S., Terayama, K., Kojima, R., Takasu, K. & Okuno, Y. 
AI-driven synthetic route design incorporated with retrosynthesis 
knowledge. J. Chem. Inf. Model. 62, 1357–1367 (2022).
19.	 Karpov, P., Godin, G. & Tetko, I. V. A transformer model for 
retrosynthesis. In Artificial Neural Networks and Machine 
Learning—ICANN 2019: Workshop and Special Sessions  
(eds Tetko, I. V. et al.) 817–830 (Springer, 2019).
20.	 Öztürk, H., Özgür, A. & Ozkirimli, E. DeepDTA: deep drug–target 
binding affinity prediction. Bioinformatics 34, i821–i829 (2018).
21.	 Karimi, M., Wu, D., Wang, Z. & Shen, Y. DeepAffinity: interpretable 
deep learning of compound–protein affinity through unified 
recurrent and convolutional neural networks. Bioinformatics 35, 
3329–3338 (2019).
22.	 Hassan-Harrirou, H., Zhang, C. & Lemmin, T. RosENet: improving 
binding affinity prediction by leveraging molecular mechanics 
energies with an ensemble of 3D convolutional neural networks. 
J. Chem. Inf. Model. 60, 2791–2802 (2020).
23.	 Feinberg, E. N. et al. PotentialNet for molecular property 
prediction. ACS Cent. Sci. 4, 1520–1530 (2018).
24.	 Li, Y., Rezaei, M. A., Li, C. & Li, X. DeepAtom: a framework 
for protein–ligand binding affinity prediction. In 2019 IEEE 
International Conference on Bioinformatics and Biomedicine 
(BIBM) 303–310 (IEEE, 2019).
25.	 Wang, R., Fang, X., Lu, Y., Yang, C.-Y. & Wang, S. The PDBbind 
database: methodologies and updates. J. Med. Chem. 48, 
4111–4119 (2005).
26.	 Liu, T., Lin, Y., Wen, X., Jorissen, R. N. & Gilson, M. K. BindingDB:  
a web-accessible database of experimentally determined 
protein–ligand binding affinities. Nucleic Acids Res. 35,  
D198–D201 (2007).
27.	 Hu, L., Benson, M. L., Smith, R. D., Lerner, M. G. & Carlson, H. A. 
Binding MOAD (Mother Of All Databases). Proteins Struct. Funct. 
Bioinform. 60, 333–340 (2005).
28.	 Friedrich, N.-O., Simsir, M. & Kirchmair, J. How diverse are the 
protein-bound conformations of small-molecule drugs and 
cofactors? Front. Chem. 6, 68 (2018).
29.	 Korlepara, D. B. et al. PLAS-5k: dataset of protein–ligand affinities 
from molecular dynamics for machine learning applications.  
Sci. Data 9, 548 (2022).

## Page 11 (Section: Protein purification and NMR spectroscopy)

Nature Computational Science | Volume 4 | May 2024 | 367–378
377
Resource
https://doi.org/10.1038/s43588-024-00627-2
30.	 Korlepara, D. B. et al. PLAS-20k: extended dataset of protein–
ligand affinities from MD simulations for machine learning 
applications. Sci. Data 11, 180 (2024).
31.	 Yang, J., Shen, C. & Huang, N. Predicting or pretending: artificial 
intelligence for protein–ligand interactions lack of sufficiently 
large and unbiased datasets. Front. Pharmacol. 11, 69 (2020).
32.	 Volkov, M. et al. On the frustration to predict binding affinities 
from protein–ligand structures with deep neural networks.  
J. Med. Chem. 65, 7946–7958 (2022).
33.	 Vajda, S., Beglov, D., Wakefield, A. E., Egbert, M. & Whitty, A. 
Cryptic binding sites on proteins: definition, detection, and 
druggability. Curr. Opin. Chem. Biol. 44, 1–8 (2018).
34.	 Zeng, L. et al. Selective small molecules blocking HIV-1 Tat and 
coactivator PCAF association. J. Am. Chem. Soc. 127, 2376–2377 
(2005).
35.	 Johnson, R. D. III (ed). Computational Chemistry Comparison and 
Benchmark Database Standard Reference Database Number 101 
Release 22 (NIST, accessed 12 Jul 2022); http://cccbdb.nist.gov/
36.	 Bista, M. et al. Transient protein states in designing inhibitors of 
the MDM2–p53 interaction. Structure 21, 2143–2151 (2013).
37.	 Xie, M. et al. Structural basis of inhibition of ERα–coactivator 
interaction by high-affinity N-terminus isoaspartic acid tethered 
helical peptides. J. Med. Chem. 60, 8731–8740 (2017).
38.	 Jakalian, A., Jack, D. B. & Bayly, C. I. Fast, efficient generation of 
high-quality atomic charges. AM1-BCC model: II. Parameterization 
and validation. J. Comput. Chem. 23, 1623–1641 (2002).
39.	 Dodda, L. S., Vilseck, J. Z., Tirado-Rives, J. & Jorgensen, W. L. 
1.14*CM1A-LBCC: localized bond-charge corrected CM1A  
charges for condensed-phase simulations. J. Phys. Chem. B 121, 
3864–3870 (2017).
40.	 Jorgensen, W. L., Maxwell, D. S. & Tirado-Rives, J. Development 
and testing of the OPLS all-atom force field on conformational 
energetics and properties of organic liquids. J. Am. Chem. Soc. 
118, 11225–11236 (1996).
41.	 Storer, J. W., Giesen, D. J., Cramer, C. J. & Truhlar, D. G. Class 
IV charge models: a new semiempirical approach in quantum 
chemistry. J. Comput. Aided Mol. Des. 9, 87–110 (1995).
42.	 Li, J., Zhu, T., Cramer, C. J. & Truhlar, D. G. New class IV charge 
model for extracting accurate partial charges from wave 
functions. J. Phys. Chem. A 102, 1820–1831 (1998).
43.	 Thompson, J. D., Cramer, C. J. & Truhlar, D. G. Parameterization of 
charge model 3 for AM1, PM3, BLYP, and B3LYP. J. Comput. Chem. 
24, 1291–1304 (2003).
44.	 Grimme, S. & Bannwarth, C. Ultra-fast computation of electronic 
spectra for large systems by tight-binding based simplified 
Tamm–Dancoff approximation (sTDA-xTB). J. Chem. Phys. 145, 
054103 (2016).
45.	 Wang, E. et al. End-point binding free energy calculation with 
MM/PBSA and MM/GBSA: strategies and applications in drug 
design. Chem. Rev. 119, 9478–9508 (2019).
46.	 Sun, Z., Liu, Q., Qu, G., Feng, Y. & Reetz, M. T. Utility of B factors 
in protein science: interpreting rigidity, flexibility, and internal 
motion and engineering thermostability. Chem. Rev. 119,  
1626–1665 (2019).
47.	 Guilligay, D. et al. The structural basis for cap binding by influenza 
virus polymerase subunit PB2. Nat. Struct. Mol. Biol. 15, 500–506 
(2008).
48.	 Rayne, S. & Forest, K. Benchmarking semiempirical, Hartree–
Fock, DFT, and MP2 methods against the ionization energies and 
electron affinities of short- through long-chain [n]acenes and [n]
phenacenes. Can. J. Chem. 94, 251–258 (2016).
49.	 Zhan, C.-G., Nichols, J. A. & Dixon, D. A. Ionization potential, 
electron affinity, electronegativity, hardness, and electron 
excitation energy: molecular properties from density functional 
theory orbital energies. J. Phys. Chem. A 107, 4184–4195 (2003).
50.	 Lange, G. et al. Requirements for specific binding of low affinity 
inhibitor fragments to the SH2 domain of pp60Src are identical 
to those for high affinity binding of full length inhibitors. J. Med. 
Chem. 46, 5184–5195 (2003).
51.	 Öster, L., Tapani, S., Xue, Y. & Käck, H. Successful generation  
of structural information for fragment-based drug discovery.  
Drug Discov. Today 20, 1104–1111 (2015).
52.	 Heinzlmeir, S. et al. Chemoproteomics-aided medicinal chemistry 
for the discovery of EPHA2 inhibitors. ChemMedChem 12, 
999–1011 (2017).
53.	 Gaieb, Z. et al. D3R Grand Challenge 2: blind prediction  
of protein–ligand poses, affinity rankings, and relative  
binding free energies. J. Comput. Aided Mol. Des. 32, 1–20 
(2018).
54.	 Whitehouse, A. J. et al. Development of inhibitors against 
Mycobacterium abscessus tRNA (m1G37) methyltransferase 
(TrmD) using fragment-based approaches. J. Med. Chem. 62, 
7210–7232 (2019).
55.	 Menezes, F. & Popowicz, G. M. ULYSSES: an efficient and easy  
to use semiempirical library for C. J. Chem. Inf. Model. 62, 
3685–3694 (2022).
56.	 Bannwarth, C., Ehlert, S. & Grimme, S. GFN2-xTB—an accurate and  
broadly parametrized self-consistent tight-binding quantum 
chemical method with multipole electrostatics and density- 
dependent dispersion contributions. J. Chem. Theory Comput. 15, 
1652–1671 (2019).
57.	 Dewar, M. J. S., Zoebisch, E. G., Healy, E. F. & Stewart, J. J. P. 
Development and use of quantum mechanical molecular 
models. 76. AM1: a new general purpose quantum mechanical 
molecular model. J. Am. Chem. Soc. 107, 3902–3909  
(1985).
58.	 Stewart, J. J. P. Application of the PM6 method to modeling 
proteins. J. Mol. Model. 15, 765–805 (2009).
59.	 Sigalov, G., Fenley, A. & Onufriev, A. Analytical electrostatics  
for biomolecules: beyond the generalized Born approximation.  
J. Chem. Phys. 124, 124902 (2006).
60.	 Christensen, A. S., Kubař, T., Cui, Q. & Elstner, M. Semiempirical 
quantum mechanical methods for noncovalent interactions  
for chemical and biochemical applications. Chem. Rev. 116, 
5301–5337 (2016).
61.	 Dixon, S. L. & Merz, K. M. Fast, accurate semiempirical molecular 
orbital calculations for macromolecules. J. Chem. Phys. 107, 
879–893 (1997).
62.	 O’Boyle, N. M. et al. Open Babel: an open chemical toolbox.  
J. Cheminform. 3, 33 (2011).
63.	 Caldeweyher, E. et al. A generally applicable atomic-charge 
dependent London dispersion correction. J. Chem. Phys. 150, 
154122 (2019).
64.	 Hanwell, M. D. et al. Avogadro: an advanced semantic chemical 
editor, visualization, and analysis platform. J. Cheminform. 4, 17 
(2012).
65.	 Case, D. A. et al. Amber 2021 (Univ. of California, San Francisco, 
2021).
66.	 Wang, J., Wolf, R. M., Caldwell, J. W., Kollman, P. A. & Case, D. A.  
Development and testing of a general Amber force field.  
J. Comput. Chem. 25, 1157–1174 (2004).
67.	 Maier, J. A. et al. ff14SB: improving the accuracy of protein side 
chain and backbone parameters from ff99SB. J. Chem. Theory 
Comput. 11, 3696–3713 (2015).
68.	 Jorgensen, W. L., Chandrasekhar, J., Madura, J. D., Impey, R. W. &  
Klein, M. L. Comparison of simple potential functions for 
simulating liquid water. J. Chem. Phys. 79, 926–935 (1983).
69.	 Townshend, R. J. L. et al. ATOM3D: tasks on molecules in 
three dimensions. Preprint at https://doi.org/10.48550/
arXiv.2012.04035 (2022).

## Page 12 (Section: Acknowledgements)

Nature Computational Science | Volume 4 | May 2024 | 367–378
378
Resource
https://doi.org/10.1038/s43588-024-00627-2
70.	 Kipf, T. N. & Welling, M. Semi-supervised classification with graph 
convolutional networks. Preprint at https://doi.org/10.48550/ 
arXiv.1609.02907 (2017).
71.	 Huang, Y., Niu, B., Gao, Y., Fu, L. & Li, W. CD-HIT Suite: a web 
server for clustering and comparing biological sequences. 
Bioinformatics 26, 680–682 (2010).
72.	 Forli, S. et al. Computational protein–ligand docking and virtual 
drug screening with the AutoDock suite. Nat. Protoc. 11, 905–919 
(2016).
73.	 Zhao, Y., Stoffler, D. & Sanner, M. Hierarchical and multi-resolution 
representation of protein flexibility. Bioinformatics 22, 2768–2774 
(2006).
74.	 Ravindranath, P. A., Forli, S., Goodsell, D. S., Olson, A. J. &  
Sanner, M. F. AutoDockFR: advances in protein–ligand docking 
with explicitly specified binding site flexibility. PLoS Comput. Biol. 
11, e1004586 (2015).
75.	 Delaglio, F. et al. NMRPipe: a multidimensional spectral 
processing system based on UNIX pipes. J. Biomol. NMR 6, 
277–293 (1995).
76.	 Johnson, B. A. & Blevins, R. A. NMR View: a computer program 
for the visualization and analysis of NMR data. J. Biomol. NMR 4, 
603–614 (1994).
77.	 Siebenmorgen, T. et al. MISATO—machine learning dataset for 
structure-based drug discovery. Zenodo https://doi.org/10.5281/
zenodo.7711953 (2023).
78.	 t7morgen/misato-dataset: release for publication. Zenodo  
https://doi.org/10.5281/zenodo.10926008 (2024).
Acknowledgements
This work received funding from BMWi ZIM KK 5197901TS0 (T.S., 
F.M., G.M.P.) and BMBF, SUPREME, 031L0268 (T.S., F.M., G.M.P.). This 
work was supported by the Helmholtz Association’s Initiative and 
Networking Fund on the HAICORE@FZJ partition.
The funders had no role in study design, data collection and analysis, 
decision to publish or preparation of the manuscript.
Author contributions
T.S. and F.M. created and refined the dataset, designed the ML 
experiments, performed the ML experiments, analyzed the data and 
wrote the paper. S.B., E.M. and K.D. performed the ML experiments, 
analyzed the data and contributed to the paper writing. A.S.D.M. 
performed the NMR experiments and analysis and wrote the  
NMR section. R.K. selected and validated the affinity benchmark.  
P.L., S.K., M.P., F.J.T. and M.S. contributed to study design, paper 
writing and funding of the project. G.M.P. conceived and designed the 
ML experiments, analyzed the data and wrote the paper.
Funding
Open access funding provided by Helmholtz Zentrum München - 
Deutsches Forschungszentrum für Gesundheit und Umwelt (GmbH).
Competing interests
The authors declare no competing interests.
Additional information
Supplementary information The online version contains supplementary 
material available at https://doi.org/10.1038/s43588-024-00627-2.
Correspondence and requests for materials should be addressed to 
Grzegorz M. Popowicz.
Peer review information Nature Computational Science thanks 
Martin Zacharias and the other, anonymous, reviewer(s) for their 
contributions to the peer review of this work. Primary Handling Editor: 
Kaitlin McCardle, in collaboration with the Nature Computational 
Science team. Peer reviewer reports are available.
Reprints and permissions information is available at  
www.nature.com/reprints.
Publisher’s note Springer Nature remains neutral with regard to 
jurisdictional claims in published maps and institutional affiliations.
Open Access This article is licensed under a Creative Commons 
Attribution 4.0 International License, which permits use, sharing, 
adaptation, distribution and reproduction in any medium or format, 
as long as you give appropriate credit to the original author(s) and the 
source, provide a link to the Creative Commons licence, and indicate 
if changes were made. The images or other third party material in this 
article are included in the article’s Creative Commons licence, unless 
indicated otherwise in a credit line to the material. If material is not 
included in the article’s Creative Commons licence and your intended 
use is not permitted by statutory regulation or exceeds the permitted 
use, you will need to obtain permission directly from the copyright 
holder. To view a copy of this licence, visit http://creativecommons.
org/licenses/by/4.0/.
© The Author(s) 2024


---

# Model-informed drug discovery and development approaches to inform clinical trial design and regulatory decisions: A primer for the MENA region

- **Authors:** Mohammed S Alasmari, Salwa Albusaysi, Marwa Elhefnawy, Ali M Ali, Khalid Altigani, Mohammed Almoslem, Mohammed Alharbi, Jahad Alghamdi, Abdullah Alsultan
- **Issuer:** Saudi pharmaceutical journal : SPJ : the official publication of the Saudi Pharmaceutical Society
- **Type:** Scientific article
- **Published:** 2024-11-27
- **Language:** en
- **DOI:** 10.1016/j.jsps.2024.102207
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39697476/
- **Licence:** CC-BY

## Section: Abstract

AbstractModel-Informed Drug Discovery and Development (MID3) represents a transformative approach in pharmaceutical research, integrating quantitative models to inform and optimize decision-making throughout the drug development process. This review explores the current applications, challenges, and future prospects of MID3 within the Middle East and North Africa (MENA) region. By leveraging local data and advanced computational techniques, MID3 has the potential to significantly enhance the efficiency and success rates of drug development tailored to regional health priorities. We discussed successful case studies of applying MID3 at different phases of drug development and clinical trials. Furthermore, we emphasized the critical need for MENA countries to embrace MID3 by investing in workforce training, aligning regulatory frameworks, and fostering collaborative research initiatives. This call to action underscores the importance of a robust MID3 ecosystem, urging policymakers, academic institutions, and industry stakeholders to prioritize and support its integration into the MENA region’s healthcare.Keywords: Drug development, PK/PD, PBPK, MENA region, Clinical trials, Pharmacometrics, Quantitative pharmacology, Population pharmacokinetics

## Section: Introduction

Model-Informed Drug Discovery and Development (MID3) is a comprehensive approach that integrates quantitative models to inform decision-making throughout the drug development process (Marshall et al., 2019, 2016). The MID3 concept focuses on the development and application of mathematical models of biological, physiological, pathological, and pharmacological processes based on preclinical and clinical data, aiming to improve the quality, efficiency, and cost-effectiveness of drug development process. The MID3 is the most recent term evolved from earlier terms including Model-Informed Drug Development (MIDD), Model-Based Drug Development (MBDD), Pharmacometrics (PMx), System Pharmacology (SP), and Modeling and Simulation (M&S) (Marshall et al., 2016). In the past two decades, the utilization of MID3 approaches has increased to support regulatory and clinical decision making (Alsultan et al., 2020, Huang et al., 2013, Lavé et al., 2016, Lee et al., 2011, Milligan et al., 2013, Rowland et al., 2011, Tuntland et al., 2014, Wang et al., 2019). The increased interest by regulatory agencies and pharmaceutical companies is mainly due to the high rates of attritions in clinical development (Sun et al., 2022). One of the main reasons for this higher attrition is safety concerns and the inability to demonstrate efficacy during clinical drug development (Lee et al., 2011). MID3 approaches (e.g., population pharmacokinetics/pharmacodynamic, physiologically-based pharmacokinetics (PBPK), quantitative system pharmacology (QSP), exposure–response relationship, model based meta-analysis (MBMA), clinical trial simulation (CTS), disease progression models, drug-trial-disease model) can help with optimizing clinical trial design and drug dosing and supporting safety and efficacy to reduce drugs attrition (Kimko and Pinheiro, 2015, Madabushi et al., 2022, Wang et al., 2019).

As part of the strong interest in this field, several regulatory agencies have published guidelines on using modeling and simulation tools during drug development. The first guide was published by the US Food and Drug Administration (FDA) in 1999 for population pharmacokinetics studies, this was followed by European Medical Agency (EMA) guideline on population pharmacokinetics in 2007, and FDA guide for PBPK in 2007 (Table 1). In Australia, regulatory agencies started discussing the role of PK/PD modeling and simulation in 1997 (Hennig et al., 2019). Over the past 10 years, several other regulatory agencies started emphasizing the role of quantitative methods in drug development such as China, Japan and South Korea (Lee and Jeon, 2019, Li et al., 2019, Sato et al., 2017). Currently, nearly all new submissions for new drug applications (NDA) contains information related to mathematical modeling and simulation.

While several developed countries have made significant strides in incorporating modeling and simulation into their research on drug discovery and development, the Middle East and North Africa (MENA) region still has substantial room for growth in this area. Increasing the application of MID3 approaches in the MENA region is crucial for improving the efficiency of drug development which can lead to faster and more effective production of new drugs into markets. These quantitative methods are also essential for addressing health challenges unique to the region by enabling more precise and tailored treatments. Moreover, they can stimulate local pharmaceutical innovation, drive economic growth, and enhance the region’s competitiveness in the global market. This is important, as MENA population’s representation in clinical trials is low even compared to emerging markets (Ibrahim et al., 2020, Nair et al., 2013). Therefore, it is important to highlight and raise awareness of MID3 concepts in MENA region. The objective of this paper is to provide a summary on quantitative methods used in drug development to enhance the MENA pharmaceutical sector, thereby improving drug development efficiency, addressing regional health challenges more effectively, and fostering local innovation.

FDA and EMA guidelines for modeling and simulation.

## Section: Historical background

The foundations of PK/PD modeling were laid in the early 20th century with the work of scientists A.J. Clark, who developed mathematical models to describe the effects of drugs (B., 1933). The concepts of concentration-effect relationships and the importance of the time course of drug concentration and the field of PK/PD modeling grew significantly during the 1960 s (Csajka and Verotta, 2006). Scientists Lewis Sheiner and Stuart Beal were instrumental in formalizing the principles of PK/PD modeling (Sheiner, 1997, Sheiner and Beal, 1980). With the advent of more powerful computers and software, the 1980 s and 1990 s saw a surge in the use of PK/PD models in drug development. Initially it started with the use of population PK/PD modeling (also known as nonlinear mixed-effects modeling) (Keizer et al., 2013). Later, in the 2000 s, there was a reemergence of PBPK models. Although the concept of PBPK modeling is old and dates back to the work of Teorell in 1937 (Paalzow, 1995, T., T., , 1937), it wasn't until the 1960 s that the first PBPK models, which considered the body as a series of interconnected compartments representing organs and tissues, began to be developed. These models became increasingly sophisticated, incorporating more complex descriptions of physiological processes and drug interactions with the body. Today, population PK/PD and PBPK modeling are the most commonly used modeling tools during drug development (Madabushi et al., 2022, Marshall et al., 2019, Wang et al., 2019). They are used to predict human pharmacokinetics from preclinical data, optimize dosing regimens, and support personalized medicine approaches. The integration of these models into the drug development pipeline has the potential to reduce the time and cost associated with bringing new therapeutics to market, while also improving their safety and efficacy profiles.

## Section: Regulatory perspectives of MID3 applications

Regulatory agencies, including FDA and EMA, require evidence that drugs are safe and effective in the population for which they are intended. Various MID3 approaches have been recognized by regulatory agencies as decision tools to support efficacy and safety of drugs. Modeling approaches, such as population PK/PD and PBPK are often mandated as part of the drug approval process for special populations (Jones et al., 2015, Shepard et al., 2015, Wagner et al., 2015). Starting in the 1990 s and continuing into the 21st century, FDA and EMA have issued guidelines that outline how modeling and simulation can be used to support drug approval processes (Table 1). This has led to an increased use of modeling and simulation in various, if not all, stages of drug development, from preclinical studies to clinical trial design and post-marketing surveillance. Jamei M (2016) compiled a list of approved drugs in which modeling and simulation played a role in informing their labels (Jamei, 2016). Also, several papers have been published summarizing the impact of modeling and simulation on drug approvals and labeling decisions by the FDA, these are summarized in Table 2 (Lee et al., 2011, Ogasawara and Alexander, 2019, Zhang et al., 2020).

For regulatory agencies in the MENA region, the Saudi Food & Drug Authority (SFDA) recently started incorporating MIDD in its evaluation process. This increased adoption of MIDD approaches by applicants submitting to the SFDA reflects the growing recognition of the value that these techniques can bring to the drug development and regulatory decision-making processes. Applications of MIDD include that for new drug applications, applications for adding new indications or extending indications to special populations. This trend is also observed in clinical trial applications, where applicants have applied MIDD to guide the advancement of their clinical development. The types of models encountered by the SFDA include population pharmacokinetics (PPK), mechanistic models such as physiologically-based pharmacokinetics (PBPK), and exposure–response (ER) relationships. The SFDA's evaluation approach for these models typically involves a matrix-based assessment, which aims to identify and manage the risks associated with using such computational models, whether as a replacement for clinical trials, for guiding dose selection, or for other purposes. The SFDA's experience in evaluating these modeling and simulation applications showcases its commitment to staying at the forefront of this evolving field and ensuring the appropriate use of MIDD to support regulatory decisions.

The international council for harmonization of technical requirements for pharmaceuticals for human use (ICH) endorsed the concept paper for general principles related to MIDD in November 2022 (The International Council for Harmonisation, 2022). This recognized that despite the increase in regulatory submissions and industry-regulatory interactions using evidence generated by MIDD, there is an absence of harmonized documentation standards and assessment expectations. The aim of the guideline is to harmonize expectations regarding planning, model evaluation, and documentation of evidence derived from MIDD. A key aspect is also to create a common understanding across scientists, both between and within industry and regulatory bodies. A draft of this guideline will be published for public comments in line with the anticipated 3-year timeline of this project.

Summary of studies assessing the impact of modeling and simulation on drug approvals and labeling by the FDA.

## Section: Various MID3 approaches used in drug discovery and development

In drug discovery and development, a variety of modeling approaches are utilized to enhance the understanding and prediction of drug kinetic and dynamic behaviors. Key approaches include population pharmacokinetics/pharmacodynamic modeling which is empirical in nature, and PBPK/QSP which is mechanistic in nature (Marshall et al., 2016). The empirical model starts from data collection and taking all available pharmacokinetic information such as plasma concentration, dosing information and the time of dosing and sample collections, which is called “top-down”, while the mechanistic model starts from what is understood at the organ, or tissue level such as hepatocytes, human liver microsomes and recombinant CYP450 enzymes, which is called “bottom-up” (Fig. 1). The most widely used empirical approach method is the population pharmacokinetics/pharmacodynamic approach which is known as nonlinear mixed effect model (NLME). On other hand, the most widely used mechanistic modelling method is PBPK/QSP (Aarons, 2005, Marshall et al., 2016).

Population pharmacokinetics is a branch of pharmacokinetics that studies the variability in drug concentrations within a patient population (Ette et al., 2004, Ette and Williams, 2004a, Ette and Williams, 2004b, Vozeh et al., 1996). This approach models how drugs are absorbed, distributed, metabolized, and excreted, accounting for diverse factors that influence these processes, such as age, weight, gender, genetic factors, disease states, and concomitant medications. The key objectives of population pharmacokinetics are to quantify the typical pharmacokinetic parameters (e.g., clearance, volume of distribution) and their variability within a population, identify and understand covariates that explain the variability in drug response, and to predict drug concentrations in patients to optimize dosing regimens (Ette et al., 2004). Population pharmacokinetics employs statistical and mathematical modeling techniques to analyze data from clinical trials and real-world settings. NLME models commonly used to describe the central tendency (fixed effects) and the variability (random effects) of pharmacokinetic parameters in populations (Bauer, 2019a, Bauer, 2019b). Population pharmacokinetics is applicable in individualizing drug therapy, supporting drug development, guiding dose selection, optimizing clinical trial designs, and informing regulatory decisions and labeling by providing comprehensive pharmacokinetic insights across different subpopulations (Ette et al., 2004). Overall, population pharmacokinetics enhances our understanding of drug behavior in diverse populations, contributing to safer and more effective therapeutic interventions.

In population PK/PD modeling, pharmacokinetic behavior of drug (PK) is combined with the drug's biological effects (PD) to optimize therapeutic strategies and ensure safety and efficacy (Derendorf and Meibohm, 1999). PK/PD modeling examines the relationship between drug concentration and its therapeutic or toxic effects (known as exposure–response relationship), providing insights into the drug's efficacy and safety profile at different doses. PK/PD modeling aids in determining the optimal dosing regimen by balancing efficacy and safety, thus reducing the time and cost associated with trial-and-error approaches in clinical trials.

PBPK models integrate physiological, biochemical, and drug-specific data to simulate how drugs are absorbed, distributed, metabolized, and excreted in various populations, especially those underrepresented in clinical trials (e.g., pediatrics, elderly, renal/hepatic impairment) (Zhao et al., 2011). PBPK models can predict drug concentrations and pharmacokinetics in specific populations where clinical data is lacking, such as pediatrics, pregnant, geriatrics, and population with organs dysfunction (Lin et al., 2022). Moreover, PBPK modeling is valuable for predicting drug interactions, especially those mediated by cytochrome P450 enzymes. PBPK models help in determining necessary dose adjustments without requiring additional clinical studies, thus optimizing safety and efficacy. This capability can expedite drug development and broaden drug indications by reducing the need for extensive clinical trials in these groups. There has been a growing acceptance and use of PBPK models in regulatory submissions (Wu et al., 2023, Zhao et al., 2011). This trend is supported by regulatory guidance and ongoing collaboration between industry, academia, and regulatory agencies, aiming to improve the standardization and reliability of these models.

In contrast to empirical approach for exposure response relationship using population PK/PD modeling, QSP represents the mechanistic approach for exposure response relationship. QSP considered as a framework for understanding the complex interactions between drugs and biological systems, such in cascade biomarkers interactions, and it is a more comprehensive and predictive method for drug development (Androulakis, 2016). QSP model integrates mathematical modeling, experimental data, and systems biology to simulate the effects of drugs on biological systems at multiple scales. The key components of a QSP model, including drug pharmacokinetics, target engagement, and downstream effects, and emphasizes the importance of incorporating biological context into drug development. It is very important to integrate quantitative data from multiple sources, such as in vitro and in vivo experiments, to build a comprehensive model of drug action.

Comparison of top-down and bottom-up modeling approaches. The figure illustrates the key differences between the top-down approach which relies on empirical data from clinical studies to describe drug behavior in populations, and the bottom-up approach, which uses mechanistic models, such as PBPK, to predict pharmacokinetic based on physiological and biochemical properties. Together, these approaches offer complementary insights into drug dosing and response.

## Section: Software and tools supporting the MID3

A variety of software and tools are available to facilitate PK and PD analyses, each with its own strengths and applications. For population PK/PD modeling, NONMEM (Nonlinear Mixed Effects Modeling) is a gold-standard software widely used in the industry for its robust data analysis capabilities (Keizer et al., 2013, Nguyen et al., 2017). It was developed by Stuart Beal and Lewis Sheiner in the 1970 s (Keizer et al., 2013, Sheiner and Beal, 1980). Currently it is developed under ICON (https://www.iconplc.com). Another software in the 1970 s was NPEM (non-parametric expectation maximization algorithm) led by Dr. Roger Jelliffe and his team at the University of South California (Jelliffe et al., 2000). Currently, the NPEM software has been updated as an R package named “Pmetrics” (Neely et al., 2012). Both software’s were originally developed with the purpose of using them for drug dosing at the bedside(Keizer et al., 2018). During the 80’s, several other software’s were developed such as ADAPT and PopKinetics (Csajka and Verotta, 2006). In the decades that followed the release of these software’s, the field of population PK/PD modeling and simulation advanced and became an integral part of drug development (Csajka and Verotta, 2006, Holford, 1990, Keizer et al., 2018, Sheiner, 1969). Other software’s developed later include Monolix, PumasAI and Phoenix NLME. Monolix is part of the MonolixSuite and is designed for advanced pharmacometrics analysis (Lavielle and Mentré, 2007, Nguyen et al., 2017, Traynard et al., 2020). Developed by Lixoft, it offers a robust and user-friendly environment for model-based drug development, employing powerful algorithms for population PK/PD modeling. Monolix facilitates the handling of complex datasets and supports a wide range of statistical models, enabling investigators to perform NLME modeling with greater efficiency and precision. With its intuitive graphical user interface and extensive visualization tools, Monolix streamlines the model building and validation process, making it an indispensable tool in the pharmaceutical industry for optimizing dosing regimens, supporting regulatory submissions, and ultimately enhancing patient care. Additionally, Phoenix is a comprehensive software suite for advanced PK/PD modeling and simulation developed by Certara (Nguyen et al., 2017). It is designed to support the entire drug development process, from preclinical to clinical stages. Phoenix includes a range of tools, such as WinNonlin for non-compartmental analysis, NLME (Nonlinear Mixed Effects) for population modeling, and IVIVC (In Vitro-In Vivo Correlation) for establishing relationships between in vitro drug release and in vivo absorption. The platform is known for its scalability, flexibility, and integration with other software tools, making it a versatile choice for researchers and modelers in the pharmaceutical industry. Moreover, Pharmaceutical Modeling and Simulation (Pumas), which is developed by PumasAI, is a comprehensive platform for pharmaceutical modeling and simulation, providing a single tool for the entire drug development pipeline (Rackauckas et al., 2022). It is used for simulation and estimation of quantitative pre-clinical and clinical pharmacological models. It leverages the power of the Julia programming language to combine modern AI with traditional mechanistic models to gain massive computational efficiency.

When it comes to PBPK modeling, Gastroplus, PK-Sim, and Simcyp Simulators stand out as leading platforms, incorporating population-based demographics to predict pharmacokinetic outcomes in virtual patient populations(Agoram et al., 2001, Ezuruike et al., 2022, Romero et al., 2020, Silva et al., 2022, Willmann et al., 2003). These tools are particularly valued for their flexibility and community-driven development. Other noteworthy tools include MATLAB with its SimBiology toolbox, which allows for a more programming-oriented approach for modeling and simulation(Hosseini et al., 2020, Hosseini et al., 2018, Park and Kim, 2019, Vasić et al., 2024). Each of these software solutions offers a unique set of features, and the choice of tool often depends on the specific requirements of the modeling task at hand, including the complexity of the model, the nature of the data, regulatory considerations, and the user's familiarity with the software.

## Section: Examples of MID3 applications to inform decision-making

MID3 applications span various stages, including target identification and validation, where computational models provide insights into disease mechanisms and potential drug targets, and predictive modeling forecasts the efficacy and safety of targeting specific pathways (Marshall et al., 2016). In Fig. 2, we summarized the applications of modeling and simulation across various stages of drug discovery and development.

During lead optimization, MID3 guides the selection of compounds with optimal PK and PD profiles and aids in understanding dose–response relationships to select promising candidates (Marshall et al., 2016). In preclinical development, translational modeling predicts human responses based on animal data, while safety assessment models identify potential toxicity concerns. MID3 supports clinical trial design and execution through adaptive trials and optimal sample size determination, enhancing trial efficiency and reliability (Marshall et al., 2016). It facilitates regulatory interactions by providing robust modeling data for submissions and meeting regulatory requirements. Dose optimization and individualization are achieved by tailoring regimens based on patient characteristics and special populations, such as pediatrics and geriatrics (Marshall et al., 2016). In post-marketing, MID3 supports ongoing monitoring of drug safety and effectiveness through post-marketing surveillance models and continuous benefit-risk assessment. In Fig. 3, we highlighted some types of modeling and simulations that are used in drug discovery and development.

Overall, MID3 enhances the prediction of outcomes, optimizes trial designs, and informs strategic decisions, leading to more efficient and effective development of new therapies. In the following sections, we provided some examples of the applications of MID3 techniques.

General applications of modeling and simulation in drug discovery and development.

Types of modeling and simulation in different stages of the drug discovery and development processes. Preclinical modeling includes using of in vitro and in vivo studies and simulations to provide insights into drug behavior, efficacy, and safety prior to human trials. PK/PD modeling evaluates the relationship of PK data to PD effect (response). Toxicology modeling is used to predict toxicity, assess risk, and understand the mechanism of adverse effects based on exposure to chemical (e.g., dose–response model). Trial simulation helps in optimizing study design, dose, selection, and evaluating potential scenarios before actual trials are conducted. Early clinical modeling integrates preclinical and early-phase clinical trial results to predict drug behavior, help in dose selection, and the design of later-stage clinical trials. Dose-ranging studies modeling allows for exploring the relationship between different drug doses and their PK and PD effects to identify the optimal dose that maximizes efficacy while minimize toxicity. Late clinical modeling allows for integrating data from advanced clinical trials (phase III) to refine dose–response relationships, predict long term efficacy and, support regulatory decision making. Population PK/PD modeling analyzes drug concentration and response across diverse patient populations, accounting for variability in drug exposure and effects which help to identify factors influencing drug behavior, optimize dosing, and improve therapeutic outcomes for different subgroups. Model-based meta-analysis integrates data from multiple studies, allowing for comparison of drug efficacy and safety across studies which help to inform dose selection, predict clinical outcomes, and guide decision-making in drug development.

## Section: Examples of MID3 applications to inform decision-making › Determining the FIH dose for transferring from preclinical to clinical phases

Estimation of the first-in-human (FIH) dose is of critical importance to earlier phases clinical trials (Zou et al., 2012). A well-established starting dose helps minimize the risk of adverse effects, ensures the well-being of study participants, facilitates the design of later-phase trials, helps allocate resources more effectively, and ultimately enables for a more efficient and streamlined development process. Methods for determining the FIH dose involve a combination of preclinical data, pharmacokinetic modeling, and safety considerations, and the most common approaches include allometric scaling, PK/PD, and PBPK(Jones et al., 2019, Jones et al., 2009, Miller et al., 2019). The primary objective of FIH trials is to identify a safe dose range for further investigation in drug development. The FDA and EMA guideline for the first in human dose provided recommendations for determining the initial dose of a new drug when it is first tested in humans (Table 1) (Shen et al., 2019). These guidelines emphasized the importance of conducting thorough preclinical studies to assess the safety and pharmacology of the drug before it is administered to humans. The initial dose should be carefully calculated based on factors such as the pharmacokinetics, pharmacodynamics, and toxicology of the drug.

PBPK models are widely used in drug discovery and development for predicting first in human dose(Miller et al., 2019). The appropriate starting dose for human trials can be estimated using PBPK modeling by integrating preclinical in-vitro and in-vivo data, considering factors like body weight, metabolic rates, gene expression, and other species-specific differences(Jones and Rowland-Yeo, 2013, Thiel et al., 2015). The availability of pharmacokinetic data from animal studies can be incorporated into the established model for qualification and optimization of the model's parameters. After qualification, the model can be extrapolated to predict human pharmacokinetics, accounting for physiological, biochemical, and genetic interspecies-difference.

PBPK modeling and simulation plays a critical role in selecting preclinical drug candidates for future drug development and guides the recommendation for the selection of the FIH dose. For example, when the COVID-19 crisis revealed the importance of an accelerated drug development process, a PBPK model was developed to predict the FIH dose for a monoclonal antibody (mAb) bamlanivimab (Chigutsa et al., 2022, Jones et al., 2019). Pharmacokinetic parameters of the mAb were characterized successfully based on data from preclinical studies. In combination with a SARS-COV2 viral dynamic model, PBPK model of bamlanivimab was used to predict the initial therapeutic dose that maintain lung tissue concentrations at or above the in-vivo IC90 over period of 4 weeks. Ultimately, bamlanivimab was approved for used in patients with COVID-19 under emergency use authorization in November 2020.

## Section: Examples of MID3 applications to inform decision-making › Guiding drug dosing in phase II/III clinical trials

During drug development, one of the main concerns is determining the appropriate dose for phase III or even phase II, in order to meet the pre-specified requirements for safety and efficacy endpoints. Population pharmacokinetics is an essential methodology for predicting PK characteristics and is critically required for drug approval. It offers several advantages over dose-titration studies in dose prediction, as it considers both between- and within-individual variability, as well as demographic characteristics and clinical disease states, including patients with renal/hepatic impairment (Lavé et al., 2016). Several studies have implemented modelling to guide dose selection for clinical trials(Landry et al., 2016, Wang et al., 2013). The robustness of the population pharmacokinetics model provides a solid evidence base for dose recommendations in later phases of drug development (i.e., phase II and phase III), utilizing drug exposure data from the previous phase (phase I) and expected clinical response.

Population pharmacokinetics analysis provides exposure information that is used as input for the exposure response relationship. By combining the estimated exposure (derived from the PK model) and the response (derived from the PD model), exposure response relationship can be predicted. This can then be used to guide dose selection for phase II/III trials using Monte Carlo simulation of varying dose regimens.

The rationale behind using both PK and PD to guide dose selection is that, in order to achieve the desired pre-specified safety and efficacy margins, one must first identify the target effect and use a PD model to predict the target concentration necessary to achieve the desired effect, and then use a PK model to predict the optimal dose required to achieve the target concentration. This approach considers variability in the PK-PD target and effect site exposures in dose prediction (Chien et al., 2005, Derendorf and Meibohm, 1999). Incorporating clinical data allows for the prediction and confirmation of responses in patient subgroups that may be at increased risk for adverse events or decreased efficacy.

## Section: Examples of MID3 applications to inform decision-making › Informing drug label for special populations

In the context of clinical pharmacology, the term “special population” refers to specific groups of individuals who may have unique characteristics or factors that can affect their response to medications (Grimsrud et al., 2015). This can include groups such as pediatrics, elderly individuals, pregnant women, obese, individuals with certain medical conditions such as renal and hepatic impairment, or those taking multiple medications (Marshall et al., 2016). These patients have unique physiological characteristics and drug response profiles compared to adult healthy populations, making it challenging to determine the appropriate dosing and safety profiles for these populations(Anderson and Holford, 2013, Costantine, 2014, Verbeeck, 2008, Verbeeck and Musuamba, 2009). Population PK/PD, as well as PBPK modeling, play crucial roles in drug development in these population where physiological differences from healthy adults significantly affect how drugs are absorbed, distributed, metabolized, and excreted(Han et al., 2021, Heimbach et al., 2021, Malik et al., 2020, Vinks et al., 2015). They help to tailor drug therapy to the unique physiological needs, ensuring that medications are used safely and effectively in these vulnerable populations. These tools also facilitate the rational design of clinical trials and support regulatory decision-making, ultimately improving access to therapeutics.

As examples, we report some of MIDD applications for special populations in relation to anticoagulants. A population pharmacokinetic model for a low molecular weight heparin (dalteparin) was constructed based on a clinical study involving 98 children to recommend starting doses for different pediatric groups (Damle et al., 2021). The clinical observations were best described by two-compartment model using NONMEM software. The analysis suggested that the starting doses of dalteparin administered subcutaneously for pediatrics ages 1 month to 2 years, 2 years to 8 years, and 8 years to 19 years should be 150 IU/kg twice daily, 125 IU/kg twice daily, and 100 IU/kg twice daily, respectively. Results from this study contributed to the approval of dalteparin by the FDA for venous thromboembolism in different pediatrics groups. Terrier et al (2022) reported several population pharmacokinetic models used for dosing optimization of anticoagulants(Terrier et al., 2022). Similarly, PBPK models are widely used and accepted in individualizing drug dosing in special populations. For instance, PBPK models for apixaban and rivaroxaban were constructed to guide dosage regimen in pediatrics, geriatrics, patient taking multiple drugs, and in patients with various degree of renal and hepatic dysfunction(Wen et al., 2022, Willmann et al., 2021, Xu et al., 2021, Xu et al., 2024). The models were able to accurately predict the PK of the drugs when taken alone and when taken concomitantly with other drugs. In patients with varying degrees of kidney and liver impairment, the PBPK models correctly estimated the increase in drug exposure for each class. For pediatrics, PBPK modeling and simulation found that the influence of renal impairment on drug exposure might be greater in infant less than one year compared to older children (Xu et al., 2021).

## Section: Examples of MID3 applications to inform decision-making › Supporting drug development in rare diseases

The term “rare disease” is often defined differently depending on the context and the legislation of different countries. In the context of the United States, the Orphan Drug Act of 1983 is a key piece of legislation that provides a definition for rare diseases and conditions, primarily for the purpose of encouraging the development and commercialization of drugs for the treatment of these diseases. According to the Orphan Drug Act, a rare disease or condition is one that affects fewer than 200,000 people in the United States(Aronson, 2006, Wellman-Labadie and Zhou, 2010). The Act provides incentives for pharmaceutical companies to develop treatments for rare diseases, which are often referred to as “orphan drugs” because without these incentives, the small market would not typically justify the investment required for drug development. Drug development for rare diseases faces several challenges, including lack of knowledge on the natural disease progression, disease heterogeneity, and the small number of eligible patients for randomized controlled trials.

As an example of the successful application of the MID3 to support development of drugs for rare diseases, population pharmacokinetic simulations were performed to predict adalimumab exposure in adolescent hidradenitis suppurativa patients without additional clinical PK data(Bi et al., 2019). Based on these simulations, dosing based solely on body weight resulted in inadequate drug exposure, and the study recommended a weight-tiered dosing regimen for adolescent HS patients to achieve similar drug exposure as adult hidradenitis suppurativa patients across the weight range. Consequently, based on these findings, FDA recommended a weight-tiered dosing regimen for adalimumab in adolescent hidradenitis suppurativa patients.

Furthermore, optimizing the selection of patients in clinical trials is critical to effectively obtain the necessary information on drug safety and efficacy. Disease progression models can serve as a valuable tool to guide patient selection strategies. This is demonstrated in the case of childhood-onset dystrophinopathy(Haber et al., 2021). Disease progression modelling was used to predict the impact of genetic variant and loss of ambulation(Li et al., 2022). The model predicted that subjects with specific genetic variants had a lower risk of loss of ambulation. These results suggest that genotyping may help guide patient selection in clinical trials. These studies highlighted the importance of MID3 in accelerating drug development, particularly in the treatment of rare diseases.

## Section: MID3 considerations for MENA region

The MENA region faces a unique set of health challenges, specific to populations demographics, genetic background, and health and socioeconomic status (Akala and El-Saharty, 2006, Alsultan et al., 2023, Katoue et al., 2022, Nair et al., 2013, Wakil et al., 2015). Developing drugs tailored to these needs can significantly improve public health outcomes. Investing in drug development can boost the pharmaceutical sector, creating jobs, fostering innovation, and contributing to economic diversification. Local drug development can reduce reliance on imported medications, ensuring more stable and affordable access to essential medicines. This is crucial during global supply chain disruptions, such as those seen during the COVID-19 pandemic (Ibrahim et al., 2020). Strengthening drug development capabilities promotes scientific research and innovation. It also helps build local expertise and infrastructure, making the region a hub for pharmaceutical research. Adopting MID3 approach in the MENA region could significantly enhance the efficiency and effectiveness of the pharmaceutical development process. MID3 can help develop personalized treatment plans based on genetic, demographic, and disease-specific data. This is particularly relevant in the MENA region, where the populations have certain genetic and physiological characteristics. Regulatory bodies can use MID3 to make more informed decisions regarding drug approvals, ensuring that new medications are both effective and safe for the MENA populations. MID3 allows for better allocation of resources by identifying promising drug candidates early and discontinuing those with low potential. This optimizes the use of financial and human resources in drug development projects.

It is very important to create a virtual population specific to MENA ethnicity for PBPK modeling to simulate PK profile more precisely. To develop a virtual human individual representing a MENA population in a PBPK platform, comprehensive demographic, physiological, biochemical, and clinical data are essential. Demographic information should include mean body weight, height, and BMI distribution. Physiological data must cover organ sizes, blood flow rates, and tissue compositions. Biochemical data should encompass data such as enzyme activity levels. Additionally, clinical data from studies conducted on the MENA populations, including PK profiles and PD, are necessary. In Table 3, we highlighted some key factors in order to successfully implement the MID3 approaches specific for MENA region.

Key factors to implement MID3 in the MENA region.

## Section: Educational resources

Barrett et al (2008) advocated for structured education and training programs to equip scientists with the necessary skills to excel in the pharmacometrics field(Barrett et al., 2008). They listed academic sites/universities offering curriculum related to pharmacometrics and some centers and web sites providing training programs. They also highlighted multidisciplinary nature of the pharmacometrics requiring expertise in biology, pharmacology and quantitative sciences. Schmidt et al (2023) discussed the comprehensive framework needed to effectively train future pharmacometricians (Schmidt et al., 2023). They outlined several key requirements for training programs, emphasizing the need for a strong foundation in quantitative and system pharmacology and the integration of advanced computational tools. Additionally, there is a call for more collaborative efforts between academia, industry, and regulatory bodies to enhance training quality and relevance. They also advocated for the development of global training networks to facilitate knowledge exchange and foster a diverse and inclusive workforce in pharmacometrics. Expectations for trainees include proficiency in MID3 and continuous professional development to keep pace with the rapidly evolving field.

Moreover, ACCP journal published a collection of educational papers on PBPK modeling and simulation which can be very helpful resources (Chaudhury et al., 2020, Franchetti and Nolin, 2020, Li et al., 2020, Malik et al., 2020, Rostami-Hodjegan and Toon, 2020, Samineni et al., 2020, Sharma et al., 2020). On the other hand, tutorials for using NONMEM for population PK/PD modeling and simulation have been published in more details(Bauer, 2019a, Bauer, 2019b, Bauer et al., 2021, Keizer et al., 2013). We have listed some additional helpful educational resources in Table 4.

Some educational resources for MID3.

## Section: Conclusion

The integration of MID3 presents a unique and significant opportunity for the MENA region to advance its pharmaceutical research and healthcare outcomes. This review highlights the transformative potential of MID3 to address regional health challenges through the use of sophisticated quantitative models such as population PK/PD and PBPK modeling. To fully realize the potential of MID3, it is imperative for MENA countries to invest in developing a skilled workforce adept at utilizing these advanced methodologies. Harmonizing regulatory frameworks to support model-based approaches and fostering collaborative research environments are also critical steps. By prioritizing the integration of MID3, MENA nations can not only enhance their own healthcare systems but also contribute to global advancements in pharmaceutical research. In conclusion, the adoption of MID3 in the MENA is not just an opportunity but a necessity. Policymakers, academic institutions, and industry stakeholders must work together to create a supportive ecosystem that encourages innovation and collaboration.

## Section: CRediT authorship contribution statement

Mohammed S. Alasmari: Writing – review & editing, Writing – original draft, Conceptualization. Salwa Albusaysi: Writing – review & editing, Writing – original draft, Conceptualization. Marwa Elhefnawy: Writing – review & editing, Writing – original draft, Conceptualization. Ali M. Ali: Writing – review & editing, Writing – original draft, Conceptualization. Khalid Altigani: Writing – review & editing, Writing – original draft. Mohammed Almoslem: Writing – review & editing, Writing – original draft. Mohammed Alharbi: Writing – review & editing, Writing – original draft. Jahad Alghamdi: Writing – review & editing, Writing – original draft, Conceptualization. Abdullah Alsultan: Writing – review & editing, Writing – original draft, Conceptualization.

## Section: Declaration of Competing Interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.


---

# MolScore: a scoring, evaluation and benchmarking framework for generative models in de novo drug design

- **Authors:** Morgan Thomas, Noel M O'Boyle, Andreas Bender, Chris De Graaf
- **Issuer:** Journal of cheminformatics
- **Type:** Scientific article
- **Published:** 2024-05-30
- **Language:** en
- **DOI:** 10.1186/s13321-024-00861-w
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38816825/
- **Licence:** CC-BY

## Section: Abstract

Generative models are undergoing rapid research and application to de novo drug design. To facilitate their application and evaluation, we present MolScore. MolScore already contains many drug-design-relevant scoring functions commonly used in benchmarks such as, molecular similarity, molecular docking, predictive models, synthesizability, and more. In addition, providing performance metrics to evaluate generative model performance based on the chemistry generated. With this unification of functionality, MolScore re-implements commonly used benchmarks in the field (such as GuacaMol, MOSES, and MolOpt). Moreover, new benchmarks can be created trivially. We demonstrate this by testing a chemical language model with reinforcement learning on three new tasks of increasing complexity related to the design of 5-HT2a ligands that utilise either molecular descriptors, 266 pre-trained QSAR models, or dual molecular docking. Lastly, MolScore can be integrated into an existing Python script with just three lines of code. This framework is a step towards unifying generative model application and evaluation as applied to drug design for both practitioners and researchers. The framework can be found on GitHub and downloaded directly from the Python Package Index. Scientific Contribution MolScore is an open-source platform to facilitate generative molecular design and evaluation thereof for application in drug design. This platform takes important steps towards unifying existing benchmarks, providing a platform to share new benchmarks, and improves customisation, flexibility and usability for practitioners over existing solutions.Graphical Abstract Supplementary InformationThe online version contains supplementary material available at 10.1186/s13321-024-00861-w.

## Section: Introduction

The influx of modern, distribution-learning based generative models applied to de novo drug design [1, 2] is both exciting and frustrating. It is exciting in the sense that complex objectives can be optimised [3] and de novo designed molecules are beginning to be prospectively validated [4–6]. It is also frustrating in the sense that there is often a lack of consideration for the type of chemistry generated [7], many models are still applied to irrelevant objectives (such as rediscovery of a specific molecule [8] or penalised logP [9]), and scientific significance with respect to the novelty of proposed de novo designs is often overlooked [10]. However, due to the sheer number of approaches not all models can be prospectively validated. Therefore, simple, easy-to-implement objectives are preferred, and benchmarks are still needed to compare approaches. However, these should relate to the real-world challenges of drug discovery as much as possible [11].

We propose MolScore, which addresses these frustrations by providing a simple, flexible, and drug-design-relevant Python framework for generative models (as opposed to more generic workflows like Knime or PipelinePilot [12]). MolScore can be used to design multi-parameter objectives for use in real-world drug design and be coupled with a generative model of choice. Furthermore, it can be used to benchmark generative models by sharing standardised objectives. In addition, MolScore contains two graphical user interfaces (GUIs) to aid both writing configuration files and analysing generated de novo molecules.

## Section: Comparison to related works

Table 1 shows a high-level comparison of MolScore to existing software/benchmarking solutions. GuacaMol [8] was the seminal benchmark, which provided a standardised training dataset and a suite of 20 objectives for generative models to optimise. These tasks all measure the similarity to one or more reference compounds. However, the authors stated that the tasks did not adequately separate top-performing generative models (~ 15/20 tasks are easily solved by generative models). Furthermore, to create a custom task not included in the benchmark, modification of the code is required. More recently, Gao et al. introduced MolOpt [3], adapted this benchmark focusing on sample efficiency (i.e., how many molecules are required to optimise the objective), significantly extending the evaluation of generative models to 25 approaches. However, an appropriate evaluation of the type of chemistry generated was lacking [7]. Both GuacaMol and MolOpt are re-implemented in MolScore. Furthermore, new tasks can be defined and added to these benchmarks without requiring any coding.

The MOSES [13] benchmark introduced another standardised training set and comparison between generative models. Although this was not applicable to molecular optimisation and only aimed at distribution-learning (i.e., how representative de novo molecules are of the respective training molecules), this benchmark proposed a useful suite of performance metrics to evaluate de novo molecules, all of which are integrated into MolScore.

Docking benchmarks such as the smina-docking-benchmark [14] (against four protein targets), DOCKSTRING (against three targets) [15] and a docking benchmark in the Therapeutic Data Commons [16] (against one protein target) have also emerged. Considering that generative models can exploit non-holistic (i.e., the objective does not perfectly describe the desired chemical space) objectives [17, 18], caution should be used when using docking score alone to rank generative models, which can be particularly susceptible. As optimising docking score can lead to large and/or greasy molecules being generated which are not desirable in a medicinal chemistry context, as observed in the DOCKSTRING single docking task. Thus, this docking benchmark will rank highly generative models that are unregularised or can generate out-of-domain molecules, instead of those useful in practice, perhaps more so than other benchmarks. Moreover, none of the docking benchmarks conduct full ligand preparation which should consist of protonating molecules at a biologically relevant pH, enumerating unspecified stereoisomers and enumerating tautomers. MolScore contains functionality to conduct docking via interaction with a variety of docking software, but crucially also contains appropriate ligand preparation protocols that handle stereoisomer numeration, tautomer enumeration and protonation states.

There exists other software for objective design used in conjunction with generative models. REINVENT [19–22], implements a suite of configurable scoring functions for use with its generative model architecture. However, the package is integrated with only the REINVENT provided generative models and it is not trivial or obvious how to use functionality available interchangeably with other generative models for standardised comparison. This contrasts with MolScore which is designed to plug-and-play with different generative models. Another framework, the Therapeutic Data Commons (TDC) platform [16], reimplements the GuacaMol suite (with customizable reference molecules) and provides several additional capabilities such as docking, synthetic accessibility scores, molecular descriptors and pre-trained activity models. However, not all scoring functions are customizable and score transformation or aggregation for use in a multi-parameter setting must be manually coded. This introduces a problem with standardization and reproducibility across users. On the other hand, MolScore contains more scoring functions which are also more configurable, as well as an interface with 2337 activity models compared to the 3 available in TDC. Multi-parameter configuration is handled via the configuration file thereby standardising transformation and aggregation. It should be noted that MolScore is focussed on de novo design while the TDC has a much broader scope.

## Section: Implementation

MolScore is an open-source software written in Python 3, published under an MIT licence and distributed via GitHub and Python Package Index. It depends on several packages such as RDKit [23], PyTorch [24], Streamlit, as well as integrating published works in the field such as RAscore [25], AiZynthFinder [26] and ChemProp [27]. MolScore is split into two sub-packages: (1) molscore for scoring de novo molecules proposed by a generative model, and (2) moleval for post-hoc evaluation using a suite of evaluation metrics. The structure of the python package can be seen in Fig. 1. The following sections provide details of each sub-package.Fig. 1Design of the molscore and moleval sub-packages. The main elements of molscore include the manager.py module that interacts with a generative model and manages scoring of the molecules according to the objective. The gui folder contains the scripts to set write configuration files or monitor de novo molecules. The scoring_functions folder contains modules for individual scoring functions, the folder scaffold_memory contains code that defines the diversity filters [25], and the utils folder contains code for the transformation and aggregation functions. The main elements of the moleval package are the metrics.py module that computes evaluation metrics and the statistics_by_n.py script that computes the evaluation metrics to a molscore output file every n-steps or n-samplesTable 1Comparison between different software and benchmarks for de novo molecule generationFixed/configurable aOptimisation objectivesEvaluation metricsGenerative model agnosticbGraphical user interfaceGuacaMolFixed✔✔✔MOSESFixed✔✔MolOptFixed✔✔Smina-dockingFixed✔✔TDCFixed✔✔DOCKSTRINGFixed✔✔REINVENT (+ DockStream)Configurable✔✔MolScoreConfigurable✔✔✔✔aConfigurable without having to write code to design the objectivebEasily implementable for most generative models

Design of the molscore and moleval sub-packages. The main elements of molscore include the manager.py module that interacts with a generative model and manages scoring of the molecules according to the objective. The gui folder contains the scripts to set write configuration files or monitor de novo molecules. The scoring_functions folder contains modules for individual scoring functions, the folder scaffold_memory contains code that defines the diversity filters [25], and the utils folder contains code for the transformation and aggregation functions. The main elements of the moleval package are the metrics.py module that computes evaluation metrics and the statistics_by_n.py script that computes the evaluation metrics to a molscore output file every n-steps or n-samples

Comparison between different software and benchmarks for de novo molecule generation

Functionality available within the molscore sub-package

Evaluation metrics available in the moleval sub-package. No metrics require a license

## Section: Implementation › Molecule scoring

The sub-package, molscore, handles the scoring of de novo molecules. It is a collection of scoring functions, diversity filters, transformation functions and aggregation functions that can be used interchangeably, all managed by a python class MolScore found in the module manager.py (see Fig. 1). MolScore is initialised with a JSON configuration file that specifies exactly which functionality to use to score molecules. Once initialised, it takes as input a list of molecules (in SMILES representation) and returns a list of their respective scores as output, designed to be repeated in an iterative fashion (e.g., steps/epochs) over the course of a generative model optimisation run. During each iteration, there are several intermediate steps. First, molecules are parsed to check for validity (by parsing with RDKit), their SMILES are canonicalized and intra-batch uniqueness is checked. Inter-batch molecule uniqueness is then cross-referenced with previously generated molecules within the run and if the molecule was previously generated its previous score is reused. This can save valuable time if compute–intensive scoring functions are used and if a generative model is susceptible to generating the same molecules multiple times. User-specified scoring function (s) are run only for valid and unique molecules with invalid molecules being assigned scores of 0. Each score is transformed into a value between 0 and 1 by choosing a transformation function available. Then, these standardised scores are aggregated according to a chosen aggregation function available to result in a final desirability score between 0 and 1 that can represent multiple parameters/objectives. The final desirability score can be further modified in two ways. Optionally diversity filters can be applied to penalise the score of non-diverse molecules, or, any scoring function can be used as a ‘filter’ i.e., the transformed score returned from this function is used to multiply the desirability score. The final results are added to the run record. In addition, a CSV file is output for each iteration in the run, allowing a GUI to analyse intermediate results during the course of a run. Finally, when the run has concluded, a CSV file is written to the output directory with a full record of molecules generated and their scores.

A broad array of functionality is available to define an objective, as outlined in Table 2. The suite of scoring functions includes physicochemical descriptors, 2D and 3D molecular similarity to reference molecules, substructure matching, use of Scikit-Learn [28] models including bioactivity models on 2,337 ChEMBL31 [29] targets with PIDGINv5 [30], interfacing with eight docking software coupled with four ligand preparation protocols, and finally three synthetic accessibility measures.Table 2Functionality available within the molscore sub-packageLicense key requiredReferencesScoring functionsDescriptorsRDKit DescriptorsNo[23]Linker DescriptorsNo[32]Penalised logPNo[9]Maximum number of consecutive rotatable bondsNoSimilarityIsomer similarityNo[8]Fingerprint similarityNo[8]Molecular substructure matchNo[8, 19]Molecular substructure filtersNo[19]ROCSYes[33]Open 3D AlignNo[34]Applicability domainMaximum similarityNo[35]Feature rangeNo[35]Physchem rangeNo[35]Predictive modelsScikit-learn modelsNo[28]PIDGINv5No[30, 36]ChemPropNo[27]ADMET-AINo[37]DockingGlideYes[38]PLANTSYes[39]GOLDYes[40]OEDockYes[41]SminaNo[42]GninaNo[43]VinaNo[44]rDockNo[45]SynthesizabilitySA scoreNo[46]RA ScoreNo[25]AiZynthFinderNo[26]Reaction filtersNo[47]Scoring function utilitiesFingerprintsECFP (Morgan), Atom-pair, Topological-torsions, MACCS keys, RDKit, Avalon, Pharm2DNo[23]Similarity measureTanimoto, All bit, Asymmetric, Braun Blanquet, Cosine, McConnaughey, Dice, Kulczynski, Russel, On bit, Rogot Goldberg, SokalNo[23]Molecule preparation pipelinesGypsumDLNo[48]LigprepYes[49]EpikYes[50]MokaYes[51]Diversity filtersUniqueNoOccurrenceNoIdenticalMurckoScaffoldNo[52]IdenticalTopologicalScaffoldNo[52]CompoundSimilarityNo[52]ScaffoldSimilarityAtomPairNo[52]ScaffoldSimilarityECFPNoTransformation functionsNormaliseNoLinear thresholdNo[8]Gaussian thresholdNo[8]Step thresholdNoAggregation functionsWeighted sumNoAuto-weighted sumNo[53]ProductNoWeighted ProductNoAuto-weighted productNo[53]Geometric MeanNoArithmetic MeanNoPareto frontNo[53]

To accelerate computation of scoring functions, most are parallelisable using Python’s built-in multiprocessing module, while longer running scoring functions such as docking and ligand preparation can be distributed over multiple compute nodes using Dask , to allow parallelisation over a whole compute cluster. Details on each method can be found in the Supplementary Information.

Functionality available within the molscore sub-package

## Section: Implementation › Molecule evaluation

The moleval sub-package is largely an extension of the MOSES [13] suite of evaluation metrics computed for de novo molecules given a set (or sets) of reference molecules. The main element of this sub-package is the GetMetrics class found in the metrics.py module. This is initialised by optionally specifying some reference datasets (for example, train and test sets used for the measurement of extrinsic properties), and it then takes as input a list of de novo molecules and outputs the respective calculated metrics. Additionally, the CSV output file written by molscore can be provided to the statistics_by_n.py script, which computes evaluation metrics and basic statistics (mean, median and standard deviation) per n molecules or n column values (e.g., per 100 steps).

Table 3 highlights all the evaluation metrics available in moleval split into intrinsic properties (based solely on de novo molecules) and extrinsic properties (in reference to an external dataset). Some additional metrics not found in MOSES for intrinsic properties include sphere exclusion diversity (SEDiv) [11], scaffold uniqueness, scaffold diversity, functional group and ring system diversity [54] and a measure of purchasability in the ZINC20 in-stock catalogue using molbloom [55, 56]. Additional metrics for extrinsic properties include analogue similarity [52] and coverage, functional group and ring system similarity [54] and average fraction of outlier bits (a.k.a. ‘Silliness’ [57]) i.e., the average ratio of ECFP4 fingerprint bits not found in the reference dataset indicating idiosyncratic atomic environments. For a more detailed description of each metric see the Supplementary Information.Table 3Evaluation metrics available in the moleval sub-package. No metrics require a licenseReferencesIntrinsic propertiesValidity[8, 13]Uniqueness[8, 13]Scaffold uniquenessInternal diversity (1 & 2)[13, 58]Sphere exclusion diversity[59]Solow Polasky diversity[60]Scaffold diversityFunctional group diversity[54]Ring system diversity[54]Filters (MCF & PAINS)[13]Purchasability[55]Extrinsic propertiesNovelty[8, 13]FCD[61]Analogue similarity[52]Analogue coverageFunctional group similarityRing system similaritySingle nearest neighbour similarity[13]Fragment similarity[13]Scaffold similarity[13]Outlier bits (Silliness)[57]Wasserstein distance (LogP, SA Score, NP score, QED, Weight)[13]

Evaluation metrics available in the moleval sub-package. No metrics require a license

## Section: Implementation › Benchmarking

Given the broad functionality available in MolScore, it is trivial to define new or re-implement existing benchmarks. Therefore, a benchmark mode has been implemented via the MolScoreBenchmark class in manager.py. This takes a list of JSON configuration files and provides an iterator over the singular MolScore class for each objective, and computes evaluation metrics for comparison upon exit. A series of presets are already present including GuacaMol and MolOpt, where benchmark-specific metrics are computed. Or a user can include/exclude objectives from these or specify their own list of configuration files for use a benchmark.

## Section: Implementation › Implementation challenges

A particular challenge when combining a variety of scoring functions and software from published methods is conflicting library dependencies. Furthermore, predictive models should use the same version of a respective library (e.g., Scikit-Learn) during prediction as was used during training where possible, as there may be subtle changes to the source code affecting the prediction. In order to tackle this, scoring functions that require specific library versions that must be consistent with those used during training are run as a local server from their respective fixed environment, as specified by the authors. This currently includes AiZynthFinder [26], RAscore [25], PIDGINv5 [30], ChemProp [27], ADMET-AI [37] and some legacy QSAR models used in benchmarks such as DRD2, GSK3β and JNK3 bioactivity prediction models. To automate this process as much as possible, molscore will check for these separate conda environments and if not present, attempt to create them automatically when the scoring function is used for the first time. One caveat to this approach is the assumption of the use of conda (or mamba) for environment management. Overall this approach allows integration of different scoring components with conflicting dependencies and avoids re-loading of python environments and predictive models at every iteration which improves computational performance. Should any further challenges arise, tutorials can be found on the GitHub page and issues can be raised on the GitHub contributing to further improvement of the software.

## Section: Results and discussion

The core components of MolScore were used to facilitate scoring and evaluation in our previous work [59, 62]. Here we describe its user interface, demonstrate its use to design difficult, drug design relevant objectives, and show how it can be used to quickly evaluate de novo molecules.

Integration of MolScore into a python module, including initialisation with a model name and path to a configuration file, followed by scoring of an arbitrary list of SMILES that require scoring (which would be repeated for generative model optimisation). An explicit step number can be provided during scoring, if not, it will iteratively count up from one

Integration of MolScore benchmark mode into a python module, including initialisation with a specific pre-existing benchmark and budget. Existing benchmarks are stored in MolScoreBenchmark.presets. The budget specifies a number of molecules to be evaluated before task.finished is set to True. Upon exit, benchmark metrics will be automatically calculated and written to CSV in the output directories

a Example configuration file reimplementing the Albuterol Similarity GuacaMol task. b Streamlit app to aid the creation of new configuration files and avoid manual writing of JSON files. The app annotates options available to the user and automatically parses it into the required JSON format

Streamlit app that can be run during or after goal-directed generative model optimisation (here showing optimisation of 5-HT2A predicted probability of activity). This is the main page used to plot training progress and select, visualise, and export molecules. Further pages are shown in Figures S1–S3

De novo optimisation of the first set of objectives designed by molscore by number of optimisation steps (left) with the equivalent score distribution for 3771 real 5-HT2A ligands (right). The dashed line represents the mean of the real ligand distribution and solid lines plus/minus one standard deviation from the mean. a The predicted probability of 5-HT2A activity at a concentration of 1 µM. b The first objective a combined with predicted synthesizability by RAscore. c The first objective a combined with property ranges increasing the probability of BBB. d All three objectives a–c combined

De novo optimisation of the second set of objectives designed by molscore by number of optimisation steps (left) with the equivalent score distribution for 3771 real 5-HT2A ligands (right). The dashed line represents the mean of the real ligand distribution and solid lines plus/minus one standard deviation from the mean. a The predicted probability of 5-HT2A activity at a concentration of 1 µM. b The first objective a combined with predicted selectivity versus membrane receptors. c The first objective a combined with predicted selectivity versus D2. d The first objective a combined with predicted selectivity versus dopamine receptors. e The first objective a combined with predicted selectivity versus other serotonin sub-types. f The first objective a combined with selectivity versus other serotonin sub-types and dopamine receptors

Example nearest neighbour de novo molecules to real 5-HT2A selective ligands (w.r.t D2 binding) a The five most 5-HT2A selective ligands with respect to D2 binding identified in ChEMBL31 that contain a D2 pChEMBL value above 4, respective pChEMBL values are shown. b Nearest neighbour de novo molecules to each molecule in a, identified during the 5-HT2A vs D2 task with respective Tanimoto similarity (Tc) and objective score. c Predicted probabilities of class A GPCR off-targets for real and de novo ligand counterparts using PIDGINv5. d Predicted class A GPCR targets mapped onto a GPCRome tree [62], shared predicted targets are shown in red, predicted only for the real ligand in blue, and predicted only for the de novo ligand in orange

De novo optimisation of the third set of objectives designed by molscore by number of optimisation steps (left) with the equivalent score distribution for 3771 real 5-HT2A ligands (right). The dashed line represents the mean of the real ligand distribution and solid lines plus/minus one standard deviation from the mean. a The optimisation of the MPO score for 5-HT2A docking. b The optimisation of the MPO score for 5-HT2A vs D2. c, d The docking scores obtained during optimisation seen in (a) and (b) respectively. Note that due to the ‘moving goal post’ nature of max min normalisation, the ‘Score’ is not representative of underlying parameter optimisation and so docking score is also shown

Analysis of molecules generated during the ‘5-HT2A vs D2’ task via the molscore GUI. a (left) The multi-parameter page of the GUI enabling the identification of top k compounds according to user-specified parameters with the ability to redefine how scores are aggregated. b An example molecule exported to PyMol via the ‘Send2PyMol’ button. c The reference co-crystal ligand Risperidone bound to 5-HT2A

Analysis of protein–ligand ligand interaction in differences in 5-HT2A between top 10 de novo molecules optimised for 5-HT2A docking score, or top 10 molecules optimised for 5-HT2A vs D2 docking scores. a Protein–ligand interaction fingerprints of the reference co-crystallised ligand Risperidone, 5-HT2A docking objective, and 5-HT2A vs D2. b, c Example docked pose of one of the top 10 molecules from the above objectives respectively

Moleval metrics computed on different fine-tuning epochs. Epoch-0 represents the generative model before fine-tuning. Intrinsic properties a and extrinsic properties in reference to a test set (sample of the training set) b and the set of A2A ligands used for fine-tuning c are shown

## Section: Results and discussion › User interface › Installation

Installation instructions can be found on the GitHub repository, alternatively, it can be installed in an existing environment via the Python Package Index with pip install molscore.

## Section: Results and discussion › Integration into a generative model

MolScore can then be implemented into a generative model optimisation scheme in just three lines of code, as shown in Fig. 2. Alternatively, MolScore can be run in benchmark mode by providing a preset benchmark, as shown in Fig. 3, or a list of configuration files.Fig. 2Integration of MolScore into a python module, including initialisation with a model name and path to a configuration file, followed by scoring of an arbitrary list of SMILES that require scoring (which would be repeated for generative model optimisation). An explicit step number can be provided during scoring, if not, it will iteratively count up from oneFig. 3Integration of MolScore benchmark mode into a python module, including initialisation with a specific pre-existing benchmark and budget. Existing benchmarks are stored in MolScoreBenchmark.presets. The budget specifies a number of molecules to be evaluated before task.finished is set to True. Upon exit, benchmark metrics will be automatically calculated and written to CSV in the output directories

Examples of generative models with MolScore already integrated can be found on GitHub (https://github.com/MorganCThomas/MolScore_examples), including SMILES-RNN [63], CReM [64], and GraphGA [65].

Integration of MolScore into a python module, including initialisation with a model name and path to a configuration file, followed by scoring of an arbitrary list of SMILES that require scoring (which would be repeated for generative model optimisation). An explicit step number can be provided during scoring, if not, it will iteratively count up from one

Integration of MolScore benchmark mode into a python module, including initialisation with a specific pre-existing benchmark and budget. Existing benchmarks are stored in MolScoreBenchmark.presets. The budget specifies a number of molecules to be evaluated before task.finished is set to True. Upon exit, benchmark metrics will be automatically calculated and written to CSV in the output directories

## Section: Results and discussion › Writing a configuration file

Full specification of logging, scoring functions, score transformation, score aggregation, diversity filters or scoring filters is defined in a JSON configuration file. To streamline and document this process, a Streamlit app is provided to easily write configuration files interactively with documentation and default parameters (see Fig. 4). The app can be run via command molscore_config that loads the GUI in a web browser. This facilitates configuration writing and automatically parses the options specified into a correctly formatted JSON configuration file. This is done by docstring and typing interpretation to provide descriptions and widgets automatically, such that if a user implements a custom scoring function (as described in Supplementary Information), it will be automatically parsed and available to specify in the GUI.Fig. 4a Example configuration file reimplementing the Albuterol Similarity GuacaMol task. b Streamlit app to aid the creation of new configuration files and avoid manual writing of JSON files. The app annotates options available to the user and automatically parses it into the required JSON format

a Example configuration file reimplementing the Albuterol Similarity GuacaMol task. b Streamlit app to aid the creation of new configuration files and avoid manual writing of JSON files. The app annotates options available to the user and automatically parses it into the required JSON format

## Section: Results and discussion › Monitoring de novo molecules

A Streamlit app to monitor de novo molecule generation ‘live’ or analyse results post-hoc is also provided (see Fig. 5). This is useful to gain quick insights into generative model behaviour with respect to chemistry generated, without needing to wait until the end of optimisation (especially in the case of computationally expensive scoring functions). This is run automatically during optimisation if specified in the configuration file, alternatively, it can be run manually at any time via the command molscore_monitor. The app loads a graphical user interface in a web browser and contains functionality to check any variable scored including validity and uniqueness, select and visualise 2D molecular graphs, assess clusters identified by an appropriate diversity filter, and export selected or top k molecules. In addition, if a scoring function is used that results in 3D coordinate files and PyMol [66] is installed, PyMol will be loaded and selected molecules can be exported directly into PyMol. Lastly, other pre-existing molscore de novo molecule generation results can be loaded for quick comparison between runs. Fig. 5Streamlit app that can be run during or after goal-directed generative model optimisation (here showing optimisation of 5-HT2A predicted probability of activity). This is the main page used to plot training progress and select, visualise, and export molecules. Further pages are shown in Figures S1–S3

Streamlit app that can be run during or after goal-directed generative model optimisation (here showing optimisation of 5-HT2A predicted probability of activity). This is the main page used to plot training progress and select, visualise, and export molecules. Further pages are shown in Figures S1–S3

## Section: Results and discussion › Molscore case study: designing 5-HT2a receptor ligands

Here we demonstrate the application of molscore for the design of different, drug discovery relevant objectives, with a focus on the generation of de novo Serotonin 5-HT2a receptor ligands as a case study. This is a relevant therapeutic target indicated in psychosis and substance-abuse with numerous antagonistic drugs marketed for their use as atypical antipsychotics—with the most recent being Lumateperone [67] approved in 2019 by the FDA. For the purpose of this demonstration, we use a SMILES-based recurrent neural network generative model trained on ChEMBL compounds in combination with Augmented Hill-Climb [62] for molecular optimisation.

To start, with we use the functionality available in molscore to design the following first set of objectives:5-HT2A—We use a pre-trained random forest classification model with the PIDGINv5 scoring function to score molecules by their predicted probability of activity at a 1 µM concentration by supplying the 5-HT2A uniprot accession.5-HT2A & Synth—To include a measure of synthesizability which is needed in a real-world drug discovery campaign, we additionally score molecules by running the RAscore [25] pre-trained models and compute the arithmetic mean of this score together with the predicted probability of 5-HT2A activity as before.5-HT2A & BBB—Due to the therapeutic targets prevalence and disease relevance in the central nervous system, we run molecular descriptors and specify certain property ranges that increase the probably of blood brain barrier (BBB) permeability. The property ranges were influenced by Pajouhesh et al. [68]: topological polar surface area below 70, number of hydrogen bond donors below 2, logP between 2 and 4, and molecular weight below 400 Da. Each molecules property value is transformed into the range 0–1 (see Figure S4) and combined by arithmetic mean with the predicted probability of 5-HT2A activity as before.5-HT2A & BBB & Synth—This a combination of all three of the above objectives by arithmetic mean.

Each objective was optimised by the generative model in combination with a diversity filter to penalise exploitation and hence, encourage exploration. As shown in Fig. 6, each of these objectives can be improved during generative model optimisation. For reference, 3771 real compounds with bioactivity values against 5-HT2A were extracted from ChEMBL31 [69] and their respective scores based on the first set of objectives are also shown. Surprisingly, the most difficult objective appears to be simple optimisation of the 5-HT2A predicted probability of activity; however, we suspect this is largely due to the effect of the diversity filter more heavily penalising similar molecules for this relatively ‘easy’ task. This is corroborated by running the objective without a diversity filter (see Figure S5) which results in quick maximisation of this objective, but exploitative mode collapse shortly following (which the use of a diversity filter circumvents). Overall, it appears these objectives are relatively easy to optimise numerically.Fig. 6De novo optimisation of the first set of objectives designed by molscore by number of optimisation steps (left) with the equivalent score distribution for 3771 real 5-HT2A ligands (right). The dashed line represents the mean of the real ligand distribution and solid lines plus/minus one standard deviation from the mean. a The predicted probability of 5-HT2A activity at a concentration of 1 µM. b The first objective a combined with predicted synthesizability by RAscore. c The first objective a combined with property ranges increasing the probability of BBB. d All three objectives a–c combined

As with many drug discovery campaigns, a key challenge for 5-HT2A ligands is minimising off-target bioactivity and achieving pharmacological selectivity. In this case, particularly against dopaminergic receptors (especially the Dopamine D2 receptor, from here on just D2) bound by typical antipsychotics) which leads to extrapyramidal symptoms as serious side-effects [70, 71]. As a proxy for desirable selectivity profiles, we design a second set of objectives with molscore particularly utilising PIDGINv5 functionality (as with the first set of objectives a diversity filter is also used):5-HT2A—As before, we use a pre-trained random forest classification model from PIDGINv5 to score molecules by their predicted probability of activity at a 1 µM concentration i.e., no selectivity proxy is used.5-HT2A vs Membrane—As a proxy for a generic off-target assay, a random forest classification model at a 10 µM concentration for every Class A GPCR targets with sufficient bioactivity data in ChEMBL31 is run (266 out of a possible 312). The prediction is classified into active or inactive (as opposed to taking the predicted probability) for each receptor and the ratio of active predictions is returned as the score. This ratio is transformed so that low ratios have a high score, therefore minimising this parameter. The arithmetic mean is taken in combination with the predicted probability of activity against 5-HT2A.5-HT2A vs D2—The predicted probability of D2 bioactivity at a concentration of 10 µM is minimised in addition to maximising the predicted probability of activity against 5-HT2A.5-HT2A vs Dopamine—The average predicted probability of bioactivity against each dopaminergic target at a concentration of 10 µM is minimised in addition to maximising the predicted probability of activity against 5-HT2A.5-HT2A vs Serotonin—The average predicted probability of bioactivity against each serotonin target (excluding 5-HT2A) at a concentration of 10 µM is minimised in addition to maximising the predicted probability of activity against 5-HT2A.5-HT2A vs Dopamine & Serotonin—The average predicted probability of bioactivity against each dopamine and serotonin target (excluding 5-HT2A) at a concentration of 10 µM is minimised in addition to maximising the predicted probability of activity against 5-HT2A.

In contrast to the first set of objectives, this second set of objectives was more difficult for the generative model to optimise, as shown in Fig. 7. The easiest objectives with respect to achieving similar scores to real 5-HT2A ligands were selectivity versus membrane and selectivity versus D2. The former likely due to the number of models run leading to low overall ratios of predicted off-targets. However, as more models are added, as in the dopamine and serotonin families, the objective becomes increasingly difficult to optimise to the standard of real 5-HT2A ligands. With the final objective of selectivity versus dopamine and serotonin barely being improved throughout optimisation. It is worth noting the caveat that real 5-HT2A ligands are likely contained in the training data of the PIDGINv5 models used in these objectives, and so will receive inflated scores compared to ‘active’ unseen molecules (of which most de novo molecules are unseen). Although we can’t know how accurate these models are prospectively, or the maximum score achievable, the scores on real 5-HT2A ligands at least provide a minimal benchmark. Moreover, the models are able to at least distinguish 95 of 126 5-HT2A molecules with selectivity over D2, despite the fact that 124 molecules have a D2 pChEMBL value of 5 or above and therefore, 93 correctly predicted selective are actually false negative predictions with respect to the D2 model at 10 µM threshold (see Figure S6), which is somewhat advantageous behaviour in this case for distinguishing selective compounds. For comparison to real 5-HT2A ligands selective over D2, we extracted the de novo nearest neighbours to the five most selective 5-HT2A ligands (see Fig. 8). Analogues were found in the 0.3–0.6 Tanimoto similarity range, although the identified analogues tend to be a ‘simpler’ version i.e., smaller with fewer heteroatoms and functional groups, indicating that either the objective or the generative model needs to more appropriately account for medicinal chemistry principles. However, the de novo compounds did possess similar predicted off-target profiles to the real 5-HT2A ligands. Overall, this second set of selectivity objectives is a more challenging optimisation problem.Fig. 7De novo optimisation of the second set of objectives designed by molscore by number of optimisation steps (left) with the equivalent score distribution for 3771 real 5-HT2A ligands (right). The dashed line represents the mean of the real ligand distribution and solid lines plus/minus one standard deviation from the mean. a The predicted probability of 5-HT2A activity at a concentration of 1 µM. b The first objective a combined with predicted selectivity versus membrane receptors. c The first objective a combined with predicted selectivity versus D2. d The first objective a combined with predicted selectivity versus dopamine receptors. e The first objective a combined with predicted selectivity versus other serotonin sub-types. f The first objective a combined with selectivity versus other serotonin sub-types and dopamine receptorsFig. 8Example nearest neighbour de novo molecules to real 5-HT2A selective ligands (w.r.t D2 binding) a The five most 5-HT2A selective ligands with respect to D2 binding identified in ChEMBL31 that contain a D2 pChEMBL value above 4, respective pChEMBL values are shown. b Nearest neighbour de novo molecules to each molecule in a, identified during the 5-HT2A vs D2 task with respective Tanimoto similarity (Tc) and objective score. c Predicted probabilities of class A GPCR off-targets for real and de novo ligand counterparts using PIDGINv5. d Predicted class A GPCR targets mapped onto a GPCRome tree [62], shared predicted targets are shown in red, predicted only for the real ligand in blue, and predicted only for the de novo ligand in orange

The use of ligand-based predictive models as scoring functions for de novo molecule optimisation can however lead to sub-optimal behaviour. Predictive models must have a broad enough applicability domain to perform expectedly given the broad scope of initial de novo molecules [19], and generative model optimisation can lead to exploitation of predictive model limitations [17, 18]. In contrast, structure-based scoring functions have been shown to improve de novo molecule diversity, and coverage of bioactive chemical space [59]. Therefore, we design a third set of objectives utilising structure-based principles (as with the other objectives a diversity filter is also used):5-HT2A—As a proxy for on-target binding affinity, de novo molecules are docked into the 5-HT2A co-crystal structure bound to Risperidone (PDB: 6A93) using GlideSP [38] and the docking score is minimised. Molecules first undergo ligand preparation via LigPrep [49] enumerating stereoisomers, tautomers and protonation states. The prepared ligand variant with the best (lowest) docking score is taken as the final docking score. The final docking score is transformed by max min normalisation based on the maximum and minimum values updated during optimisation—such that low (good) docking scores are given a score close to one. To inject knowledge of aminergic binding interactions, a further docking constraint is applied to ensure that a docked pose contains a D1553x32 polar interaction, the molecule is also scored to encourage a formal charge of 0 or 1. To help prevent exploitation of docking score limitations the molecule is scored to encourage the maximum number of consecutive rotatable bonds to be three or below. Thus, this is a multi-parameter optimisation problem (MPO) where final reward is computed as the arithmetic mean of all parameters.5-HT2A vs D2—As a proxy for selective binding affinity compared to a closely related off-target, the docking score of 5-HT2A is improved (i.e., minimised) as described above and the docking score of D2 is worsened (i.e., maximised) using the same protocol as above but using the D2 co-crystal structure also bound to Risperidone (PDB: 6CM4). Th D2 docking score is transformed by max min normalisation based on the maximum and minimum values updated during optimisationsuch that high (bad) docking scores are given a score close to one and therefore rewarded. The same extra parameters are specified as in the multi-parameter objective as described above, except that the final score is the weighted sum of parameters, with the 5-HT2A docking score assigned a weight of 2 and all others assigned a weight of 1 to reflect that optimising 5-HT2A docking score is most important.

While the docking score of de novo molecules can be optimised to approximately the mean of known 5-HT2A ligands within just 200 steps (see Fig. 9a,c), optimising for divergent docking scores of 5-HT2A and D2 is much more difficult achieving only slight separation of docking distributions relative to the beginning of optimisation (see Fig. 9d). This will be in large part due to the close similarity between the binding pockets and binding mode of Risperidone. In fact, the 3771 real 5-HT2A ligands show very limited differences in their docking score distributions between 5-HT2A and D2. In this example, the molscore GUI (Fig. 10a) was then used to select and visualise the best de novo molecules generated. Aggregate scores were re-computed (as the fully range of docking score is now known) but with the additional QED parameter with a weight of 1. For example, the top molecule has been exported via a clickable button to PyMol for visualisation (Fig. 10b) in comparison to the reference pose of Risperidone (Fig. 10c). In this case, the de novo molecule has a cationic piperazine making the required interaction with the D1553x32 residue conserved in aminergic receptors [72, 73], but containing a novel cyclo-propane core with two benzene substituents, one in the deep orthosteric pocket and one towards helix 6. Upon searching known 5-HT2A ligands, a precedence is found for such a di-aryl substructure linked by an sp3 hybridised carbon. To further exemplify the potential benefits of more difficult scoring functions such as this, the protein–ligand interaction fingerprints were computed for the predicted poses of the top 10 5-HT2A de novo molecules and top 10 5-HT2A vs D2 using ProLIF [74]. Fig. 11 displays the resulting fingerprints in comparison to the reference ligand, highlighting key areas of the binding pocket avoided by de novo molecules optimised for selectivity, for example, S1312x60, Y139, I2064x56, S2074x57, P2094x60, I2104x61, L3627x34, N3637x35. Interestingly, the top10 de novo molecules optimised for selectivity mostly interact with D1553x32 via polar interactions and not cationic interactions, which may reflect an attempt to avoid increasing D2 docking score (targeting cationic interactions to this residue was a key observation in previous work to optimise the D2 docking score [59]). Overall, this represents a much more challenging objective for de novo design, however, despite poor numerical divergence of docking scores we have shown that this still impacts de novo chemistry obtained and therefore still has utility in practice.Fig. 9De novo optimisation of the third set of objectives designed by molscore by number of optimisation steps (left) with the equivalent score distribution for 3771 real 5-HT2A ligands (right). The dashed line represents the mean of the real ligand distribution and solid lines plus/minus one standard deviation from the mean. a The optimisation of the MPO score for 5-HT2A docking. b The optimisation of the MPO score for 5-HT2A vs D2. c, d The docking scores obtained during optimisation seen in (a) and (b) respectively. Note that due to the ‘moving goal post’ nature of max min normalisation, the ‘Score’ is not representative of underlying parameter optimisation and so docking score is also shownFig. 10Analysis of molecules generated during the ‘5-HT2A vs D2’ task via the molscore GUI. a (left) The multi-parameter page of the GUI enabling the identification of top k compounds according to user-specified parameters with the ability to redefine how scores are aggregated. b An example molecule exported to PyMol via the ‘Send2PyMol’ button. c The reference co-crystal ligand Risperidone bound to 5-HT2AFig. 11Analysis of protein–ligand ligand interaction in differences in 5-HT2A between top 10 de novo molecules optimised for 5-HT2A docking score, or top 10 molecules optimised for 5-HT2A vs D2 docking scores. a Protein–ligand interaction fingerprints of the reference co-crystallised ligand Risperidone, 5-HT2A docking objective, and 5-HT2A vs D2. b, c Example docked pose of one of the top 10 molecules from the above objectives respectively

All of these objectives can be re-run as benchmarks in MolScore benchmark mode by specifying the benchmark keywords ‘5HT2A_PhysChem’, ‘5HT2A_Selectivity’, ‘5HT2A_Docking’ as the benchmark parameter shown in Fig. 3.

De novo optimisation of the first set of objectives designed by molscore by number of optimisation steps (left) with the equivalent score distribution for 3771 real 5-HT2A ligands (right). The dashed line represents the mean of the real ligand distribution and solid lines plus/minus one standard deviation from the mean. a The predicted probability of 5-HT2A activity at a concentration of 1 µM. b The first objective a combined with predicted synthesizability by RAscore. c The first objective a combined with property ranges increasing the probability of BBB. d All three objectives a–c combined

De novo optimisation of the second set of objectives designed by molscore by number of optimisation steps (left) with the equivalent score distribution for 3771 real 5-HT2A ligands (right). The dashed line represents the mean of the real ligand distribution and solid lines plus/minus one standard deviation from the mean. a The predicted probability of 5-HT2A activity at a concentration of 1 µM. b The first objective a combined with predicted selectivity versus membrane receptors. c The first objective a combined with predicted selectivity versus D2. d The first objective a combined with predicted selectivity versus dopamine receptors. e The first objective a combined with predicted selectivity versus other serotonin sub-types. f The first objective a combined with selectivity versus other serotonin sub-types and dopamine receptors

Example nearest neighbour de novo molecules to real 5-HT2A selective ligands (w.r.t D2 binding) a The five most 5-HT2A selective ligands with respect to D2 binding identified in ChEMBL31 that contain a D2 pChEMBL value above 4, respective pChEMBL values are shown. b Nearest neighbour de novo molecules to each molecule in a, identified during the 5-HT2A vs D2 task with respective Tanimoto similarity (Tc) and objective score. c Predicted probabilities of class A GPCR off-targets for real and de novo ligand counterparts using PIDGINv5. d Predicted class A GPCR targets mapped onto a GPCRome tree [62], shared predicted targets are shown in red, predicted only for the real ligand in blue, and predicted only for the de novo ligand in orange

De novo optimisation of the third set of objectives designed by molscore by number of optimisation steps (left) with the equivalent score distribution for 3771 real 5-HT2A ligands (right). The dashed line represents the mean of the real ligand distribution and solid lines plus/minus one standard deviation from the mean. a The optimisation of the MPO score for 5-HT2A docking. b The optimisation of the MPO score for 5-HT2A vs D2. c, d The docking scores obtained during optimisation seen in (a) and (b) respectively. Note that due to the ‘moving goal post’ nature of max min normalisation, the ‘Score’ is not representative of underlying parameter optimisation and so docking score is also shown

Analysis of molecules generated during the ‘5-HT2A vs D2’ task via the molscore GUI. a (left) The multi-parameter page of the GUI enabling the identification of top k compounds according to user-specified parameters with the ability to redefine how scores are aggregated. b An example molecule exported to PyMol via the ‘Send2PyMol’ button. c The reference co-crystal ligand Risperidone bound to 5-HT2A

Analysis of protein–ligand ligand interaction in differences in 5-HT2A between top 10 de novo molecules optimised for 5-HT2A docking score, or top 10 molecules optimised for 5-HT2A vs D2 docking scores. a Protein–ligand interaction fingerprints of the reference co-crystallised ligand Risperidone, 5-HT2A docking objective, and 5-HT2A vs D2. b, c Example docked pose of one of the top 10 molecules from the above objectives respectively

## Section: Results and discussion › Moleval case study: evaluating fine-tuning epochs

The suite of performance metrics does not necessarily need to be run on a molscore output (for example, Figures S7–10). Instead, it can be used to assess arbitrary datasets for quick comparison to reference datasets. For example, evaluating progress during generative model fine-tuning. In this case study, we use a SMILES-based RNN pre-trained on ChEMBL compounds and fine-tune it (via transfer learning) using a set of known Adenosine A2A receptor (from here on A2A) ligands to bias de novo molecule generation towards A2A-bioactive-like chemotypes. This just requires two lines of Python to instantiate the GetMetrics class specifying any reference datasets and calling calculate to calculate the metrics (in this case, repeated for sampled de novo molecules after each epoch of fine-tuning).

Figure 12 shows the resulting changes in metric values during fine-tuning where Epoch-0 represents the generative model before fine-tuning began. It is quickly possible to assess that some intrinsic properties (Fig. 12a) like novelty and diversity decrease with increasing fine-tuning epochs, while validity has an initial drop that is recovered with further fine-tuning epochs as it adjusts to new chemotypes. Meanwhile, similarity to the initial pre-training dataset (ChEMBL compounds) decreases as shown by an increase in Fréchet ChemNet Distance [61] and decrease in analogue coverage (Fig. 12b). Note that metrics that measure the presence of only a single similar molecule, like analogue similarity and single nearest neighbour increase, as the initial ChEMBL training dataset will likely already contain A2A-like chemotypes. Conversely, similarity to the fine-tuning set of A2A ligands increases especially noticeable by analogue similarity and coverage (Fig. 12c), while novelty also slowly decreases with respect to this fine-tuning set. This overview of property changes allows for interpretation on how many fine-tuning epochs are required. In this case, arguably, just one or two epochs are needed which quickly leads to an increased similarity to the fine-tuning set with marginal improvements with any further epochs; however, further epochs do lead to an undesirable decrease in novelty and diversity. The required balance will vary depending on user and use case, however, quickly assessing changes is always useful.Fig. 12Moleval metrics computed on different fine-tuning epochs. Epoch-0 represents the generative model before fine-tuning. Intrinsic properties a and extrinsic properties in reference to a test set (sample of the training set) b and the set of A2A ligands used for fine-tuning c are shown

Moleval metrics computed on different fine-tuning epochs. Epoch-0 represents the generative model before fine-tuning. Intrinsic properties a and extrinsic properties in reference to a test set (sample of the training set) b and the set of A2A ligands used for fine-tuning c are shown

## Section: Results and discussion › Future developments

Several improvements for MolScore are planned for the future. Further scoring functions and performance evaluation functionality, for example, structure interaction fingerprint rescoring for docked poses. Accepting molecules with 3D conformations as inputs, particularly for structure-based scoring functions such as docking and shape alignment. This will become more useful following the increase in 3D structure-based generative models [75, 76]. Integrating dynamic configuration files that can be updated during the course of optimisation for use in curriculum learning [77]. There still exists many opportunities for improvement depending on community uptake which we will continually endeavour to pursue.

## Section: Conclusion

MolScore is an open-source Python framework for the flexible design of drug design relevant objectives for de novo molecule scoring and evaluation. This framework takes a more flexible approach to generative model benchmarking, acknowledging that benchmarks will never be relevant to all situations. Instead, users can make use of the available functionality, contribute custom scoring functions and share their proposed benchmark objectives in a standardised way. In addition, this framework contains two GUIs to facilitate ease of use and accessibility. We believe this framework combines the best elements of current benchmarks with additional flexibility, leading to an overall improved platform. Lastly, we demonstrate the use of MolScore to design drug design relevant objectives and how it can be used to also evaluate de novo molecules (and therefore differences between generative model hyperparameters, architectures and objective functions).

## Section: Text

Supplementary material 1.

## Section: Supplementary Information

Supplementary material 1.

Supplementary material 1.


---

# MolToxPred: small molecule toxicity prediction using machine learning approach

- **Authors:** Anjali Setiya, Vinod Jani, Uddhavesh Sonavane, Rajendra Joshi
- **Issuer:** RSC advances
- **Type:** Scientific article
- **Published:** 2024-01-30
- **Language:** en
- **DOI:** 10.1039/d3ra07322j
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38292268/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractDifferent types of chemicals and products may exhibit various health risks when administered into the human body. For toxicity reasons, the number of new drugs entering the market through the conventional drug development process has been reduced over the years. However, with the advent of big data and artificial intelligence, machine learning techniques have emerged as a potential solution for predicting toxicity and ensuring efficient drug development and chemical safety. An ML model for toxicity prediction can reduce experimental costs and time while addressing ethical concerns by drastically reducing the need for animals and clinical trials. Herein, MolToxPred, an ML-based tool, has been developed using a stacked model approach to predict the potential toxicity of small molecules and metabolites. The stacked model consists of random forest, multi-layer perceptron, and LightGBM as base classifiers and Logistic Regression as the meta classifier. For training and validation purposes, a comprehensive set of toxic and non-toxic molecules is curated. Different structural and physicochemical-based features in the form of molecular descriptors and fingerprints were employed. MolToxPred utilizes a comprehensive feature selection process and optimizes its hyperparameters through Bayesian optimization with stratified 5-fold cross-validation. In the evaluation phase, MolToxPred achieved an AUROC of 87.76% on the test set and 88.84% on an external validation set. The McNemar test was used as the post-hoc test to determine if the stacked models' performance was significantly different compared to the base learners. The developed stacked model outperformed its base classifiers and an existing tool in the literature, reaffirming its better performance. The hypothesis is that the incorporation of a diverse set of data, the subsequent feature selection, and a stacked ensemble approach give MolToxPred the edge over other methods. In addition to this, an attempt has been made to identify structural alerts responsible for endpoints of the Tox21 data to determine the association of a molecule with a plausible downstream pathway of action. MolToxPred may be helpful for drug discovery and regulatory pipelines in pharmaceutical and other industries for in silico toxicity prediction of small molecule candidates.

## Section: Introduction

In the modern world, the exposure of human beings to a plethora of potentially harmful chemicals is a reality of life. Human bodies process chemicals regularly, ranging from pharmaceuticals to food additives and from natural compounds to cosmetic products. Humans are now even prone to agricultural and industrial chemicals such as pesticide residue in food, contaminants in water, and hazardous gases in the air we breathe.1 People can get exposed to these chemicals simultaneously and/or sequentially through a variety of exposure routes like oral, dermal, or inhalation. Exposure to these chemicals can trigger adverse drug reactions, allergic responses, disruption of the endocrine system, and even disability or morbidity due to carcinogenic pathways and tissue and/or organ damage. The health risk assessment of these chemicals' exposure depends on the dose, frequency, duration, and administration route.2 Furthermore, every year, hundreds of new synthetic chemicals are being released into the environment, which are directly or indirectly accumulating in humans.

All the chemical ingredients for human applications are required to meet certain regulatory requirements to be certified as safe for use. The drug discovery process involves various stages from ideation, to lead identification to development to approval. This process, of drug safety assessment, is a crucial but long, expensive, and very complicated process. Clinical trial data from 2010 to 2017 shows that toxicity is attributed to 30% of clinical failures of drug development.3 The conventional process for toxicity identification involves in vivo and in vitro screening techniques. Although these methods have proven to be helpful, they tend to be time-consuming, inefficient, and highly expensive.2,4,5 The use of animal testing in clinical trials has been under question due to the ethical and accuracy reasons for predicting human toxicity.2 This has led to the emergence of in silico approaches for predicting toxicity which can utilize the inherent properties of the molecules.

Computational approaches have proven to be a promising pre-screening technique for a large number of potential molecules being explored through high-throughput screenings.6–9In silico approaches have the advantage of predicting toxicity even before the compound is synthesized,10 saving time and money over traditional toxicity prediction methods. The in silico approach is based on the concept of the “molecular similarity principle”, which suggests that molecules with similar structures will have similar biological activities.11 These methods use the structural and molecular properties of these molecules to extract the most useful information for the prediction of toxicity.8,12,13

Several in silico methods have been developed for toxicity prediction like structural alerts, read-across, and Quantitative structure–activity relationships (QSAR).14 Structural alert (SA) is a chemical substructure that is associated with toxicity,15 it can be an atom or a collection of atoms. These can be determined by using specialized human expertise16 or statistical analysis of fragmented datasets.17 SAs are usually used in a rule-based fashion and associate the presence of structural alert or its combination with toxicity.18 Another method is read-across which uses information from compound(s) with known properties to infer information for other similar uncharacterized compounds of the same chemical category.19 The similarity of two chemicals can be calculated statistically using different distance metrics like Tanimoto, Euclidean, Hammings, etc19. Although the read-across method is transparent and easy to implement, read-across uses a small dataset as compared to other methods owing to the small number of analogs for a compound. The interpretation of results can be complex depending on the choice of similarity and strength of similarity.20 QSAR methods make use of multiple types of machine learning algorithms to establish a link between chemical structure and toxicity. Unlike other methods, QSAR can quantify the relationship between structure and toxicity on their physiochemical property basis.21 Machine Learning (ML) is one of the most widely used methods for making such predictions. The machine learning algorithms used have the potential to map both linear and non-linear relationships.

Machine Learning has even outperformed animal testing for a few applications like RASAR by Luechtefeld et al. for oral and dermal toxicity, eye and skin irritation, and mutagenicity.22 ML algorithms can be broadly classified into two types – supervised and unsupervised learning. In supervised learning, all data is labeled and the algorithm learns to map the output label from the input data. Unsupervised learning has all the unlabeled data and the algorithm learns the underlying structure of the data. ML can use different algorithms employing a molecule's chemical and structural properties as a feature set for toxicity prediction. Many supervised ML methods have been explored that use these feature sets for toxicity predictions such as ToxiM,12 DeepTox,8 eToxPred,13 and ProTox.9 One of the most used datasets for these studies is the Tox21 dataset,23 which is a collection of in vitro toxicity screening results of thousands of chemicals and approved drugs. DeepTox was one of the best-performing methods in this Tox21 challenge.24 It utilizes the potential of a Deep Neural Network (DNN) trained on molecular descriptors and fingerprints to predict the toxicity of nuclear receptor panels and stress response panels. eToxPred is a method to predict the synthetic accessibility and the toxicity of molecules. It employs an extra Tree Classifier to predict the toxicity by using only fingerprints. It uses publicly available datasets like FDA-approved, KEGG Drug,25 TOXNET,26 T3DB,27 and TCM28 for training and testing the model for toxicity. It reports an AUC of 0.82 for the prediction of toxicity.13 ToxiM is another tool for the prediction of toxicity of molecules using fingerprints and descriptors as input features. It trains a random forest model on self-curated positive and negative datasets, which even includes human metabolites as non-toxic molecules.12 The performance is validated using a validation set and reports an accuracy of 93%. But the drawback of ToxiM is that the dataset used for training is limited by the diversity of data and the number of compounds.

There are several computational methods available for toxicity prediction, but their use is restricted either because the tool is not freely available or because the model was trained on extremely specialized data. So, there is still a need for a method that is not only highly accurate but also fast in training and easily deployable in a classical computing environment. Due to advances in both technology and the exploration of chemical space, the amount of data collected in the pharmaceutical sector is increasing exponentially. To effectively handle the immense amount of data in the chemical–biological space, a machine-learning method that can keep pace is essential. Hence, this study proposes a combination of machine learning and cheminformatics approaches to accurately predict molecule toxicity. The approach involves developing a stacked model utilizing three different base models: LightGBM, random forest, and multi-layer perceptron. These models are selected based on their distinct advantages as individual models and their demonstrated effectiveness in previous studies8,29,30 on toxicity prediction. Model stacking is a popular and successful approach that has been recently applied in many areas of cheminformatics.31–33 Stacking allows the flexibility of varied base models that can be trained using a variety of algorithms, architectures, and hyperparameter configurations. By leveraging the diverse characteristics and capabilities of these models, the stacking approach aims to achieve enhanced predictive power for the task.

In terms of data, most of the available works use either descriptors or fingerprints (or a single type of fingerprint) for training purposes. The current work is one of the few attempts to combine descriptors and fingerprints to harness the maximum information and predict the toxicity of molecules. Extensive effort has been put into curating the dataset on which the proposed model gets trained and assessed. The data has been compiled from diverse fields like natural products, human metabolites, known drug molecules, potentially hazardous chemicals, aerosols, and synthetic bio-active compounds. Toxicity is one of the primary properties that are assessed by any industry dealing with compounds for human consumption. For that matter, “the structure of a chemical substance implicitly determines its physical and chemical properties and reactivity, and these properties interact with biological systems to determine its biological/toxicological properties”,34,35 Hence molecular descriptor and fingerprint-based approach is chosen which represents the structural and physicochemical properties of the compound. Additionally, in the current study an attempt is made to make informed predictions regarding the potential endpoints associated with a molecule, by searching for the defined structural alerts within the molecule in question. For identifying structural alerts in this study Tox21 data is considered. The Tox21 compound library has information about 12 biological receptors: a panel of seven nuclear receptors (NR) and five stress response (SR) pathway assays. Data generated from Tox21 has been used to identify compounds that interact with specific toxic pathways, including some not previously known.36,37 The proposed method, by incorporating the aforementioned factors, aims to handle an ever-increasing number of compounds being tested by pharma and other industries.

The rest of the paper is organized as follows: Section 2 is Materials and Methods. It discusses the dataset i.e. toxic and non-toxic data, the input features i.e. molecular descriptors and fingerprints, and the feature selection methods applied. It further talks about model building and evaluation which describes the Stacked model architecture and the associated classifiers, followed by the proposed workflow and the model evaluation metrics. Section 3 is Results and discussions, which discusses the results of data processing and feature selection, feature importance, the selection of optimal hyperparameters, toxicity label prediction, and discussions. The model was not only compared with a few base model algorithms but also with an existing tool for toxicity prediction. Section 4 is the structural alerts study and Section 5 is Conclusion.

## Section: Materials and Methods

The quality of the data limits the performance of a machine learning (ML) model. Along with data availability, tuned hyperparameters are an important prerequisite for model performance and reproducibility in modern machine learning algorithms. This section discusses data compilation and curation, pre-processing, descriptor and fingerprint calculation, feature selection, data splitting, learning algorithms, and model evaluation.

## Section: Materials and Methods › Datasets

The most important aspect of the supervised machine learning algorithm is a labeled dataset. A robust dataset is required as it will govern the model's performance. In the current study, the data from varied sources were collected, curated, and labeled with two classes viz. toxic and non-toxic depending upon their source. The toxic dataset is labeled as one and consists of known toxins, while the non-toxic dataset is labeled as zero and consists of non-toxins. The dataset was initially cleaned to remove duplicates and salts/metals/duplicates/biologicals. The details of the curated dataset have been given in Table 1.

## Section: Materials and Methods › Datasets › Non-toxic data

The non-toxic dataset comprises the drug molecules that have been approved by regulatory bodies i.e. FDA and KEGG drug database25 and the metabolites present in the human body from the RECON1 model in BIGG database.38 The drugs collected from these regulatory databases might have some side effects but considering their therapeutic advantages it qualifies as non-toxic. FDA-approved drugs (1515) were collected from DrugBank39 and the KEGG drug database contains around ∼3682 drugs approved in U.S., Japan, and Europe. As the human metabolites from pathways have not been reported toxic to humans,12 this data has also been added to the non-toxic molecules. The 1263 human metabolites were retrieved from the RECON1 model in UCSD's BIGG database.38 The rationale behind including the human metabolites is that these are produced by conserved pathways and to date, no reports of toxicity have been reported.

The Tanimoto similarity40 coefficient was used to compare the non-toxic molecules from all the sources, and any molecule with a coefficient of more than 0.95 was excluded as it would be redundant to include because of high similarity. The final non-toxic dataset consists of 5933 non-redundant non-toxic molecules.

## Section: Materials and Methods › Datasets › Toxic data

The toxic dataset contains toxins from two sources (i) 3036 molecules from TOXNET (ii) and 3689 molecules from the Toxin and Toxin Target Database (T3DB) database. The TOXNET data earlier maintained by NIH and NLM has now been moved to HSDB in PubChem. It is an amalgamation of over 15 databases on toxicology, hazardous chemicals, environmental health, and toxic releases.26 T3DB is a collection of common toxins like drugs, pollutants, pesticides, cosmetics, etc., and their specific human target proteins.27 Metals and small peptides were removed from T3DB data for this analysis. Further redundant and similar molecules were removed at a Tanimoto coefficient threshold of 0.95. This resulted in the final 4696 toxic molecules labelled as one.

## Section: Materials and Methods › Input features

The principal information for predicting toxicity is based on a drug's chemical structure, as molecules with similar structures may have similar toxicological pathways and properties.41 In the current work, each compound's chemical molecular structure is expressed in Simplified Molecular-Input Line-Entry System (SMILES) format. The SMILES notation of the molecules obtained from various databases was then converted into canonical SMILES i.e. unique SMILES considering the connectivity and chirality of the molecule using the RDKit library.42 From this data, a set of 180 random molecules were initially set aside to use as an external validation set for assessing the built model performance later. It was made sure that these molecules are representative of new molecules and don't share much similarity with the train or test set. For computers to understand the chemical structure, it must be represented in a machine-readable format, such as numbers or characters. The molecular descriptors and fingerprints are these mathematical representations of chemicals and serve as the input features for further analysis and predictions. The details of molecular descriptors and fingerprints have been given in the below subsections. This numerical representation of the data helps for the faster processing of the chemical structures data in a high-throughput fashion.

## Section: Materials and Methods › Input features › Molecular descriptors

Molecular descriptors are mathematical representations of the molecular properties of compounds/molecules generated by algorithms. These are used to quantitatively define the physical and chemical information of the compounds/molecules.43 The choice of descriptors has a strong influence on the predictive performance of the model. Molecular descriptors can be classified according to dimensionality: 0D, 1D, 2D, 3D, and 4D descriptors. For the purpose of this study 0D, 1D & 2D descriptors have been calculated via RDKit42 library in Python. The missing values were substituted with 0 and the infinite values with 1. 0D-descriptors are independent of molecular connectivity and conformations and refer to atom and bond type counts. 1D-descriptors contain information about fragment counts, and their calculation is independent of information on molecule structure. 2D-descriptors are topological descriptors, derived from molecular graphs, and are conformationally independent.44 These descriptors have two major categories: (1) physicochemical properties and (2) fraction of a substructure. Examples of these descriptors have been given in Table 2.

## Section: Materials and Methods › Input features › Molecular fingerprints

Fingerprints are another form of a descriptor in which molecular structures are encoded to a bit string. It is a series of binary digits (bits), representing the presence or absence of a particular substructure in the molecule indicated by 0 and 1 respectively. These are numeric arrays of n bits long, where n depends on the fingerprint algorithm. The PaDELpy library in Python, which is a wrapper for PaDEL-Descriptor45 software, has been used to calculate the molecular fingerprints for the input data. The list of fingerprints calculated have been mentioned in Table 4.

## Section: Materials and Methods › Feature selection

The molecular descriptors and fingerprints have proved its importance as features over the years for predicting various properties46,47 of the small molecules and not solely toxicity prediction. However, all the molecular features might not be effective for the prediction of the toxicity of the small molecules, and such ineffective features will not only increase the time required for the training but also adversely impact the performance of the model. Feature selection reduces the complexity of a model and makes it easier to interpret. So, this necessitates the use of efficient feature selection methods that can identify and remove irrelevant and redundant information to obtain practical results. The current dataset for the defined problem in this study consists of molecular descriptors which are numeric continuous values & molecular fingerprints which are high-dimension discrete binary values.

As a result, separate univariate feature selection techniques have been used to select fingerprints and descriptors. This aims to select features that are significantly associated with the target variable while removing highly correlated features. This ensures that the selected features capture relevant information about toxicity and minimize multicollinearity, which can improve the performance and interpretability of the model. To carry out feature selection, a cross-validation strategy is implemented, where the dataset is split into training and testing subsets. The feature selection process is performed solely on the training data to prevent any information leakage from the test set, ensuring unbiased results. Stratified k-fold cross-validation is employed, which takes into account the class distribution of the target variable to maintain its proportionality across the folds. The steps involved in feature selection are shown in Fig. 1 and are described in the below subsections.

## Section: Materials and Methods › Feature selection › Feature selection for molecular fingerprints

To characterize molecular structural properties of compounds, 12 types of molecular fingerprints are generated using PaDELPy, a Python wrapper for PaDEL-Descriptor software.45 This representation of the molecular structure through a chain or vector of bits, with a fixed length, can vary from 79 bits to 4860 bits leading to a large feature set. This feature set can affect the reliability of the built model due to the presence of irrelevant and redundant correlated fingerprints. Therefore, to address this issue, each fingerprint type listed in Table 4 (such as the PubChem fingerprint, Estate fingerprint, etc.) has been individually subjected to the feature selection procedure and then combined subsequently for additional model training.

As molecular fingerprints are discrete values, the chi-square method is used to evaluate features individually with respect to classes i.e. toxic or non-toxic in the target variable. It is a statistical test of independence and estimates whether the class label is independent of a feature or not.48 Each PaDEL fingerprint has been treated as an individual feature set, and features have been selected separately. The chi-squared test is based on comparing the obtained values of the frequency of a class to the expected frequency of the class. To use the chi-square test for feature selection, the hypotheses are:

• Null Hypothesis H0: feature & Target Variable are not dependent.

• Alternate Hypothesis H1: feature & Target Variable are dependent.

The criterion for accepting or rejecting the null hypothesis is determined by whether the p-value is more or less than the significance level (α) respectively. Due to the execution of multiple hypothesis tests Bonferroni corrections49 have been applied over the chi-squared test.

Further to deal with multicollinearity i.e. correlated features which may act as redundant features, Cramer's v-test50 is used. Cramer's v-test is a chi-square-based statistic that assesses how strongly two (nominal) categorical variables are associated or dependent on one another.

Cramer's V ranges between 0 ≤ V ≤ 1, the closer V is to 0, the smaller the association between the categorical variables. So highly correlated features i.e. with Cramer's V correlation greater than 0.5 (ref. 51 and 52) were discarded and only small and medium associations were kept. Table 4 lists the features selected for all the fingerprints for further usage in the model.

The feature selection process is integrated with five-fold stratified cross-validation. This helps in performing the feature selection in a more robust and unbiased manner. By repeatedly splitting the training data into training and validation sets, it can be assessed how well the selected features perform across different subsets of the training data.

Within each fold, Bonferroni corrected chi-square test was applied to the training data to select features based on their p-values (<0.05). These selected features in the same fold are then evaluated using Cramer's V test to identify and remove features with high correlations above the threshold of 0.5. Finally, a consensus is determined by considering the occurrence or agreement of each feature across multiple folds. The details of the chi-square test, Bonferroni corrections, and Cramer's v-test are given in ESI.†

## Section: Materials and Methods › Feature selection › Feature selection for molecular descriptors

Molecular descriptors i.e. the molecule level features which comprise structural and physicochemical properties of small molecules are calculated using the RDkit library in Python.42 These consist of 208 descriptors which are ‘numerical’ values, that act as feature sets for predicting toxicity. From this vast set of descriptors, those that significantly affect the performance of the model in predicting toxicity have to be selected. The objective is to choose a set of descriptors that can collectively capture the maximum information about the target variable. For this purpose, mutual information statistics have been used for calculating the relationship between each molecular descriptor and toxicity label.

Mutual information describes relationships in terms of uncertainty i.e. entropy. The mutual information (MI) between two quantities is a measure of the extent to which knowledge of one quantity reduces uncertainty about the other. MI is zero when two quantities are independent and higher values for higher dependency. So, the aim is to select features that have higher mutual information w.r.t to target variable toxicity. The MI between continuous variable X and discrete variable Y represents the reduction in the uncertainty of Y i.e. target variable after observing the X. The mutual information has been calculated using the sklearn library in Python. The function used in this library relies on nonparametric methods based on entropy estimation from k-nearest neighbor distances.53,54 The details and mathematical representation of the M.I. calculations have been described in the ESI.†

After the MI score for each feature X in the train set is computed with stratified five-fold cross-validation, a threshold value of 0.025 is set as a criterion for feature selection. In addition to this, measures have been taken to remove the multicollinearity in the features. This is done using the Pearson correlation55 method to remove redundant highly correlated features which could lead to noise in data. So, highly correlated features i.e. with absolute Pearson correlation greater than 0.9 were discarded within the same fold. Similar to molecular fingerprints a consensus is taken across all folds by considering the occurrence of each feature across multiple folds and final features are selected.

## Section: Materials and Methods › Model building & evaluation › Model stacking

In the current work, the toxicity prediction problem has been treated as a classification task. To improve the overall prediction performance, a stacked model approach has been implemented. This approach leverages the concept of model stacking, which has shown that combining predictions from multiple diverse models can result in better predictions as compared to using models in isolation.56

The architecture of the stacked model consists of two or more well-performing models as base models. These base models get trained on the training data and generate prediction probabilities for each label. These predicted probabilities then serve as input features for a meta-classifier. The meta-classifier is trained on the predictions made by the base models using out-of-sample data. The out-of-sample predictions are generated through k-fold cross-validation and have the same size as the original training set. In other words, the data that was not used to train the base models are utilized to train the meta-classifier, enabling it to make predictions based on the collective insights from the base models. In the current study, three base classifiers were employed followed by a meta-classifier. Each of the base classifiers and the meta classifier has been explained in the below subsection.

## Section: Materials and Methods › Base learners › LightGBM

LightGBM is a gradient-boosting decision tree (GBDT)57 method developed by Microsoft in 2017.29 The LightGBM algorithm is considered as a fast and efficient form of GBDT. It is an ensemble model with a decision tree as its base model, which can be trained sequentially. It works on minimizing the prediction error by combining multiple weak learners to form a strong one. The initial tree will, like other gradient boosting algorithms, learn to fit the target variable, and then each new learner will fit the residual (gradient of loss function) of the previous tree, and minimize the residual. This leads to improved accuracy and reduced bias in the predictions. LightGBM splits the tree in a leaf wise-manner (Fig. 2) with a depth limitation strategy as opposed to the conventional level-wise tree building in other boosting algorithms.29 This means that as a tree grows deeper, it concentrates on extending a single branch rather than growing multiple branches. LightGBM can handle categorical data and provides faster training with techniques like gradient-based one-side sampling (GOSS) and exclusive feature bundling (EFB).

## Section: Materials and Methods › Base learners › Random forest (RF)

Random forest is a decision tree-based ensemble technique, specifically a bagging technique.59 Bagging is a technique where several decision trees are trained in parallel followed by aggregation. These parallel trees are built on various subsets of the training dataset using different subsets of available features which helps reduce the variance. These data points and features are chosen at random with a replacement which is called bootstrapping. Bootstrapping ensures that each decision tree in the forest is unique leading to a reduction in the variance of the classifier.60 For the classification task, a majority vote is taken of all the decision trees i.e. the most frequent categorical variable will lead to the predicted class.

## Section: Materials and Methods › Base learners › Multi-layer perceptron (MLP)

An MLP is an artificial neural network that consists of at least three interconnected neuron layers: an input layer, a hidden layer, and an output layer. The input layer receives the input data to be processed and the output layer performs the required task of prediction.61 A number of hidden layers placed between the input and output layers perform the computational task of the MLP using various activation functions. These activation functions introduce non-linearity into the network, allowing it to learn and model complex relationships in the data. The MLP follows a feed-forward architecture, where data flows from the input layer through the hidden layers to the output layer. The neurons within the MLP are trained using the backpropagation algorithm, which adjusts the weights and biases of the neurons to minimize the error between the predicted and actual outputs.62

## Section: Materials and Methods › Base learners › Logistic regression: meta learner

Logistic regression is employed as the meta learner, it is a simple and efficient statistical method for binary classification problems.63 It uses a logistic function also known as a sigmoid function to return the probability of a label. The output of logistic regression falls within the range of 0 and 1.64 In addition, logistic regression does not necessitate a linear relationship between inputs and output variables. Instead, it applies a nonlinear log transformation to the odds ratio. The output of logistic regression represents the probability of each class, which is obtained by applying the sigmoid function to the log odds:

where g(z) is the probability converted by the sigmoid function and z is log odds in eqn (1).

## Section: Materials and Methods › Proposed workflow

In the current work, a stacked model-based approach has been taken. The method aims to learn from the feature representations of the small molecules to predict toxicity. The performance of the proposed workflow is evaluated on the curated dataset described in section 2.1. The specific steps for predicting small molecule toxicity using LightGBM are described as follows:

(1) Input datasets: the preprocessed dataset after removing duplicates, missing values, biologicals, and faulty SMILES is used as input for the prediction of toxicity. It contains both non-toxic and toxic molecules, which have been compiled from different sources mentioned in Table 1. Data is divided into training and test set in a ratio of 80 : 20 and normalized. To handle the slight imbalance between the two classes of data, sklearn parameter class weight is set to ‘balanced’ for each of the base learners and meta learner.

(2) Feature extraction and feature selection: features are extracted from the SMILES representation of the molecules in the form of molecular descriptors and fingerprints with the help of RDKit42 and PadelPy65 libraries respectively in Python. The redundant and highly correlated features are removed, using the feature selection techniques described in Section 2.3.1 and 2.3.2 for molecular fingerprints and descriptors respectively. It is to be noted that feature selection was performed individually for each molecular fingerprint, to select only optimal features and was combined in the end for further predictions. These molecular representations are then used as input for model building.

(3) Hyperparameter tuning: the selection of hyperparameters plays a crucial role in building a model. Hyperparameters are all the parameters that the user can set before training the model to control the learning process. Therefore, to achieve the best performance on the data in a reasonable time, hyperparameter optimization is required. Bayesian optimisation is a method to find the best values of hyperparameters based on the Bayes theorem which will minimize or maximize an objective function. The two main steps include: it builds a probability model i.e. a primary function that assumes the distribution of the objective function which is to be optimized. This prior function, also called the surrogate model, is updated by using an acquisition function. The acquisition function identifies the next input values to evaluate. The goal of Bayesian optimization (eqn (2)) is to find the global maximum or minimum value of function f(x) in the candidate set S and then generate the corresponding best combination of hyperparameters.66

where the hyperparameters are input to the function f(x) and maximum metric of choice is set to be output of the function f(x).

For learning a generalized model, the training dataset is randomly divided into five equal parts, in which one part is the independent validation set. The remaining parts were used to train the models and find the best hyperparameters using stratified five-fold cross-validation. The workflow utilizes stratified k-fold cross-validation as it uses stratified sampling which ensures that the ratio of the toxicity label remains the same across original data, training data, and test data. This way a more accurate assessment of performance is achieved by ensuring that no value is over- or underrepresented in the training and test sets. This significantly reduces both bias and variance as most of the data is being used for the training set and validation set respectively.

Hyperparameter optimization is done by performing 10 iterations of Bayesian optimization67 with Gaussian processes as a surrogate model and upper confidence bounds as acquisition functions using the scikit BayesOpt68 package for eight hyperparameters of LightGBM. For random forest, the HyperOpt69 package is used for tuning five hyperparameters by performing 10 iterations, with the Tree-structured Parzen Estimators (TPE) algorithm, which uses the Expected Improvement (EI) as the acquisition function. For Multi Layer Perceptron, BayesOpt68 package is used for tuning three hyperparameters of MLP using 10 rounds of optimization with Gaussian processes as a surrogate model.

(4) Model stacking: the best hyperparameters obtained for each base model are then used for training purposes. The stacked model as shown in Fig. 3 has been implemented in the following way:

Step 1: the training set for the Stacking Classifier model is divided into five folds using the Stratified five-fold strategy, preserving the percentage of each class. Cross-validation is applied to avoid overfitting. For all base classifiers i.e. LightGBM, RF, and MLP, the training portion of each fold act as a training set, and the predictions are made on the validation portion of each fold.

Step 2: this validation set prediction probabilities from the base models are concatenated, creating a new training set for the meta-classifier. This new training set represents the predictions from all three base models. The original labels are retained as the labels for this dataset.

Step 3: the meta-classifier i.e. Logistic Regression model in this study, combines the predictions made by the base classifiers. The meta-classifier is trained using the new training set and true target variable from the validation portion of the fold. Following that, the meta-classifier is used to make predictions on the test portion of the fold.

Step 4: the predictions from the meta-classifier are collected for each fold, resulting in multiple sets of predictions for the entire test set. The final predictions are calculated by averaging the predictions from all folds.

This process accounts for the variability in predictions across different folds and provides a more robust estimate of the model's performance on unseen data. It helps mitigate overfitting risks and ensures a reliable evaluation of the model's performance.

(5) Model evaluation: to evaluate the quality of the model's predictions, the model is evaluated on various metrics as mentioned in Section 2.7. Accuracy, AUC, Sensitivity, specificity, MCC, and F1 score are calculated for both training and test dataset. External validation data is used to further analyze the stacked model's performance. The stacked model is also compared with the individual base models. A corrected version of McNemar's test is used to assess the statistical significance of the stacked models' performance w.r.t each of the base classifier's performance.

McNemar's test is non-parametric variant of χ2 test.70 It is based on a 2 times 2 contingency table of the two model's predictions. McNemar's test creates a contingency table that gives the successful and unsuccessful predictions of the two models in question. In Table 3 a sample contingency table has been given, showing b as the number of predictions where model 1 succeeds and model 2 fails, and c as the number of predictions where model 2 succeeds and model 1 fails. If the sum of c and b is sufficiently large, the χ2 value follows a chi-squared distribution with one degree of freedom.

Then McNemar's formula, corrected for continuity given by Edward et al.,71 in equation is written as follows:

After setting a significance threshold, here α = 0.05 the p-value is computed, and the p-value is the probability of observing this empirical (or a larger) chi-squared value. If the p-value is lower than the chosen significance level, the null hypothesis can be rejected that there is no significant difference between the performance of the two models. Along with this, the proposed model has also been compared with one of the existing tools ‘eToxPred’ for better comparative assessment.

## Section: Materials and Methods › Model evaluation

In the context of toxicity binary classification, various metrics are used to assess the performance of the model which are based on the confusion matrix. The confusion matrix comprises True Positives (TP), the number of toxic compounds that are correctly predicted. False Positive (FP), which is the number of non-toxic compounds incorrectly predicted as toxic. True Negatives (TN) refer to the number of correctly predicted non-toxic compounds, and lastly, False Negatives (FN) correspond to the number of incorrectly labeled toxic compounds as non-toxic. The value of sensitivity (recall) eqn (5) reflects the model's ability to correctly predict toxic samples (1), a higher sensitivity value indicates a lower rate of false negatives, indicating that the model is effective in capturing and predicting toxic samples accurately. Whereas the value of specificity eqn (6) represents the model's ability to correctly predict non-toxic samples (0).30 A balance between the two indicates that the model is effective in distinguishing non-toxic samples from toxic ones. Accuracy eqn (7) which is the estimate of the overall performance of the model is also reported, along with the misclassification score. The performance of the classification model across all classification thresholds is represented by the receiver operating characteristic (ROC) curve, which is used to assess a model's robustness. A better metric of evaluation is the area under the curve (AUC), also known as the area under the receiver-operating characteristic (AUROC), for quantifying ROC which is also reported for model performance. This curve is a graphical trade-off between True Positive Rate (TPR) and False Positive Rate (FPR) at different decision thresholds. The probability that a model would score a randomly selected positive sample higher than a randomly selected negative sample is expressed as the area under the ROC curve or AUC. Higher prediction accuracy is indicated by an AUC value that is nearer to 1.13 These evaluation metrics were implemented using the scikit learn package72 in Python.

where, TP = True Positive, TN = True Negative, FP = False Positive, FN = False Negative.

Precision eqn (8) assesses the model's precision in identifying toxic compounds from all the predicted positive cases. Another metric used is the F1 score eqn (9) that combines both precision and recall to provide an overall assessment of the model's performance by taking the harmonic mean of precision in eqn (8) & recall eqn (5). Precision assesses the model's capability in identifying toxic compounds from all the predicted positive cases. While the recall is the proportion of true positive predictions out of all actual positive samples (toxic compounds). A higher F1 score indicates that the model has achieved a good balance between accurately identifying toxic compounds (high precision) and capturing a large proportion of all toxic compounds (high recall). Matthews Correlation Coefficient (MCC) is a metric commonly used to evaluate the performance of binary classification models. It takes into account true positives, true negatives, false positives, and false negatives to provide a balanced measure of the model's overall performance which also has been reported.

## Section: Results and discussions › Data processing

In this study, 14 678 compounds were collected from different publicly available databases as described in Table 1. For the initial pre-processing, SMILES are formatted to the canonical SMILES, duplicates are eliminated and redundant, and similar molecules are removed by using a 0.95 threshold of the Tanimoto coefficient. Finally, 10 449 compounds are obtained for use as the training set (8359) and the test set (2090) for the establishment of toxicity prediction models. A separate set of 180 random small molecules is reserved as an external validation set. The Tanimoto similarity scores were computed to determine the degree of similarity between molecules in different sets. In Fig. 4, a value of 0 indicates low similarity and 1 suggests identical molecules. The results show that there is a relatively low degree of similarity between the compounds in both the train–test data and the train–external validation data.

## Section: Results and discussions › Feature selection

The PaDELpy library is used to calculate nine different types of fingerprints and the RDKit library in Python is used to calculate 208 descriptors and Morgan fingerprints. Separate feature selection techniques are applied to descriptors and fingerprints to select features that are effective for the prediction of the toxicity of the small molecules. Therefore, 76 relevant molecular descriptors get selected from 208 descriptors (ESI 2.3.1†) using mutual information and pearson correlation in a stepwise manner as described in Section 2.3.2. Similarly, as described in Section 2.3.1 both the Bonferroni corrected chi-square test and the Cramer's v test, effectively eliminate a large number of redundant and highly correlated fingerprints, yielding 2237 features from 12 193 features as shown in Table 4.

## Section: Results and discussions › Feature importance

In order to address the black-box nature of machine learning algorithms and make predictions more explainable, feature importance scores are calculated. Feature importance in predicting the toxicity of a molecule is given through the permutation importance method i.e. the contribution of each feature is calculated in order to predict the target variable. Permutation importance measures the decrease in a model's performance when a single feature (i.e., each key or bit in the molecular fingerprint or each molecular descriptor) is randomly shuffled. If shuffling a feature's values has no effect on the model's predictive performance, it indicates that the feature does not make a significant contribution to the model's predictions. On the other hand, if randomly shuffling the values of a feature leads to a substantial decrease in predictive performance, it suggests that the feature plays a more important role in the model's predictions.73 Each feature is shuffled multiple times and the shuffled feature with the highest performance deviation is the most important and vice versa.

The permutation importance of three individual base classifiers (random forest, MLP, and LightGBM) was calculated with ten times repetition using the test data. Due to the black-box nature of the stacked model,74 only individual learners were used to calculate permutation importance.

The systematic and repetitive approach enhances the reliability and confidence in the feature importance assessment, reducing the impact of potential outliers or random fluctuations. To take these repetitions into account in a more robust manner and to understand the influence of the features in each base learner's predictions an optimal estimator from associated uncertainties75 is calculated. It is based on the maximum likelihood considerations and the same has been explained in the ESI.† This optimal estimator provides a refined representation of permutation scores, across the three models considering the associated uncertainties from the repeats of permutation. The features highlighted important from this estimate tells about the features contributing to the model's prediction of classifying a molecule as toxic or non-toxic.

Among the feature importance scores generated the top 50 important features according to their optimal estimate of uncertainty have been depicted in Fig. 5 for illustration purposes. Features identified as relevant have been discussed below:

(1) Topological descriptors: topological descriptors are based on a graph representation of the molecule. These take into consideration the internal atomic arrangements of compounds that encode information regarding molecular size, shape, branching, presence of multiple bonds, number of aromatic rings and heteroatoms.76 Balbanj77 is a distance-based topological descriptor and Ipc index is an information-theory-based topological descriptor.78 BCUT 2D metrics take into account bond-type for both adjacent and non-adjacent atoms79 is another important topological feature which plays a role in classification. These results of feature importance are in line with a number of toxicity prediction studies on Tox21 (ref. 24) like DeepTox,8 and state-of-the-art tools like TOPKAT.80 Other findings also show that molecular connectivity indices are an adequate predictive tool for assessing the level of toxicity of a wide range of chemicals.81,82

(2) Physicochemical descriptors: these consist of the structural and chemical properties of the small molecules. Some of the physicochemical descriptors i.e. min partial charge and max partial charge have the highest feature importance score, these model the distribution of electrons over a molecule. This indicates that electrostatic interactions impact the toxicity profile of the drug. E-state indices play a vital role in toxicity assessment by concurrently encoding the topology and electronic environment of molecular fragments.83 QED (quantitative estimate of drug-likeness)84 is a measure of the drug-likeness of a molecule and reflects many properties like molecular weight, octanol/water coefficient logP, topological polar surface area, etc. These properties can affect how a molecule interacts with biological systems and potentially influence its toxicity. NHOH count: number of NHs or Ohs, number of rotatable bonds, number of aliphatic rings and number of aromatic heterocycles are all part of Rdkit's Lipinski parameters of a molecule and found their place in top 50 important features for toxicity prediction. These factors can contribute to toxicity by influencing a molecule's interaction with biological targets, potential nonspecific binding, metabolic stability, and structural characteristics impacting its bioactivity and potential adverse effects.85

(3) MOE type descriptors: another set of descriptors that find its place in the top 50 important features are the MOE descriptors. These are numerical features calculated from a connection table representing molecular physical properties, partial charge, along with the surface area contributions. This also includes subdivided surface area descriptors which are based on approximate van der Waals surface area calculation for each atom along with its atomic properties.86 These cover contributions to octanol/water coefficient logP (SLogP descriptors) and molecular refractivity (SMR). PEOE descriptors calculate partial charges, which is based on the iterative quantization of atomic orbital electronegativities.87 VSA_Estate is the MOE type descriptor using EState indices and surface area contribution. MOE-based descriptors have shown their importance in predicting in silico toxicity in studies by Su et al.,88 Jain et al.,89 Chavan et al.90 and ToxiM.12

(4) Molecular fragments and substructures: Fingerprints are a way of encoding the structure of a molecule in a binary form representing the presence or absence of particular substructures. Estate fingerprints (electropological), MACCS fingerprints (cover functional groups, ring systems), Morgan fingerprints (circular), Klekota-Roth fingerprint91(chemical substructures enriched for biological activity) and graph-based fingerprints are the crucial fingerprints in the top 50 features. Ext fingerprint is an extension of the CDK fingerprint, which takes into account the nature of the ring, including rich structural information92 and is a part of the important feature list. These features' importance confirms that the structural and molecular properties of the compound are crucial for learning the relationship between molecules and their toxicity. These fingerprints have also been used repeatedly by several methods in this field by Feng et al.,93 Sharma et al. in ToxiM,12 and Zhang et al.94

## Section: Results and discussions › Selection of optimal hyperparameters › LightGBM

The objective function of Bayesian optimization is to maximize the metric ‘AUC’ while finding the best combination of the hyperparameters. The default boosting algorithm used by LightGBM is Gradient Boosting Decision Tree (GBDT). But generally, the gradient-boosting trees suffer from overspecialization i.e. trees added at the later iterations contribute to the prediction of only a few samples and ignore the others. On the other hand, the addition of dropouts in DART (Dropouts meet Multiple Additive Regression Trees) makes it difficult for trees at later iterations to specialize, hence improving performance. Hence, the boosting_type hyperparameter is set to ‘dart’. DART uses dropout similar to the neural network and helps in the regularization of trees.

The eight hyperparameters selected through Bayesian optimization mentioned in Table 5 govern the efficacy and speed of the algorithm. L2 regularization has been applied to determine optimal features through Bayesian optimization without overfitting. The number of leaves (num_leaves) is the maximum number of leaves each weak learner has and is an important parameter that governs the model complexity. The number of leaves should be theoretically less than 2^max_depth, where max depth determines the maximum depth each tree can traverse while still growing leaf-wise.

## Section: Results and discussions › Selection of optimal hyperparameters › Random Forest

Bayesian Optimization was performed to select the optimal hyperparameters for the random forest classifier while maximizing the accuracy. A set of five hyperparameters and their corresponding search spaces used in the optimization process are mentioned in Table 6 The criterion used for splitting nodes was chosen between ‘entropy’ and ‘gini’. The optimal criterion selected was ‘entropy’. Entropy is a measure of impurity in a set of samples. In the context of random forest, it quantifies the disorder or randomness in the target variable i.e. toxicity label distribution within a node. So, the RF algorithm selects the node that minimizes the entropy impurity. Other hyperparameters include the number of decision trees in a random forest, the depth of each tree, and the minimum number of samples required to split the node.

## Section: Results and discussions › Selection of optimal hyperparameters › Multi layer perceptron

The architecture of the MLP used in this study is as follows:

In the input layer, the number of neurons is set to the number of features for a record in the training data. In this case, the number of neurons in the input layer is 2313; one neuron for each feature. For classification tasks, the number of neurons in the output layer corresponds to the number of class labels. In this model, there is one neuron in the output layer with a sigmoid activation function for the binary classification problem. The MLP classifier used in this model consists of three hidden layers with 1024, 256, and 64 neurons, respectively. These hidden layers apply the rectified linear unit (ReLU) activation function, which introduces non-linearity to the model and helps capture complex patterns in the data. In addition to that three dropout layers are also added to prevent overfitting of the model. The optimizer used for weight optimization is the “Adam” optimizer, a stochastic gradient-based optimizer. The model is trained for a maximum of 10 iterations with a batch size of 32. This means that the model processes the training data in batches of 32 samples per iteration. The complete architecture of the neural network architecture is illustrated in Figure S1.† Furthermore, to mitigate overfitting, additional parameters such as learning rate, dropout rate, and regularization strength are optimized. The details of these are provided in Table 7.

## Section: Results and discussions › Toxicity label prediction

In order to predict the toxicity of molecules using machine learning, the choice of model is crucial. The proposed method aims to enhance the efficiency and accuracy of toxicity prediction, with a focus on improving the identification of true positive instances while maintaining overall prediction quality. A stacked model approach is employed, which combines multiple base classifiers including random forest (RF), multi-layer perceptron, and LightGBM.

To assess the performance of our stacked model, it is compared against its base classifiers, namely RF, multi-layer perceptron, and LightGBM. Hyperparameters for all the base models are tuned using stratified 5-fold cross-validation on the training data.

By combining bagging and boosting models in a stacked ensemble, the strengths of both techniques are being leveraged. Bagging models help reduce variance and provide stable predictions while boosting models reduce bias and capture complex relationships.95 Furthermore, by incorporating a neural network into the stacked model, its strengths in capturing non-linear relationships, feature extraction, and generalization,96 lead to improved predictive accuracy and overall model performance.

The prediction results of the test and external validation set under different classifiers are shown in Table 8. In order to evaluate the robustness of the models, ROC and precision–recall curves have been plotted in Fig. 6, which shows the performance of the stacked model as compared to the base classifiers for predicting the toxicity of molecules. Since the stacked model is built on the CV results of its base classifiers, and doesn't have cross-validation results of its own, the test data is used to evaluate and compare its performance with the individual base learners. The AUROC curve in Fig. 6A illustrates that the stacked model outperforms the individual base classifiers, exhibiting a higher AUROC of 87.76% for the test set. This represents a significant improvement compared to the random forest (RF) classifier, which had an AUROC of 1.82% lower, the MLP classifier with an AUROC of 1.58% lower, and the LightGBM classifier with an AUROC of 1.59% lower (AUROC CV results in ESI†). Similarly, for the external validation set, the stacked model achieves an AUROC of 88.84%, surpassing the MLP classifier by 3.76%, the random forest classifier by 2.45%, and the LightGBM classifier by 0.64% as shown in Fig. 6C. These results demonstrate a substantial improvement and further highlight the effectiveness of the developed stacked model in capturing complex patterns and making accurate predictions on unseen data.

Fig. 6B and D depicts Area under precision–recall Curve (AUPRC) for both the test set and external validation set, which is based on precision and recall as described in Section 2.7. AUPR is also one of the most robust evaluation metrics and gives the average of precision scores calculated for each recall threshold, giving a better understanding of positive class as compared to negative class. The stacked model achieves an AUPRC of 86.37% on the test set, outperforming the LightGBM classifier by 2.51%, the random forest classifier by 1.65%, and the MLP classifier by 2.16%. The external validation data also follows the same trend, these values indicate that the stacked model has a higher precision–recall trade-off, resulting in better classification performance and a higher proportion of correctly predicted positive instances.

A classification method with high accuracy and precision, and with the lowest misclassification rate, is considered to be the most intelligent classifier for prediction purposes.97 In Fig. 7A and B, different metrics like accuracy, F1-score, MCC, specificity, and sensitivity have been reported. When comparing the performance of the stacked model with its base classifiers, it can be observed that the stacked model achieves a higher accuracy of 80.91% for the test set and 82.22% for the external validation set. This is an improvement over the individual base classifiers of LightGBM, MLP, and random forest for the test and external validation set. While accuracy is a commonly used metric for evaluating model performance, it alone may not provide a comprehensive assessment of the model's effectiveness.

For this case, the stacked model achieves an F1 score of 76.43% on the test set and 78.67% on the external validation set indicating that it strikes a good balance between correctly identifying toxic molecules (recall) and avoiding misclassification of non-toxic molecules (precision). This implies that the stacked model performs well in correctly predicting both toxic and non-toxic molecules, reducing both false positives and false negatives.

When comparing the performance of the different models based on the Matthews Correlation Coefficient (MCC), it is observed that the Stacked Model achieves an MCC of 0.61 on the test set, outperforming LightGBM with an MCC of 0.5730, MLP with an MCC of 0.5698, and random forest with an MCC of 0.5816. While for the external validation set, the stacked model also shows competitive performance with an MCC of 0.6396.

In the context of toxicity prediction, sensitivity is crucial as it represents the ability of the model to correctly identify true positive i.e. toxic instances. Therefore, it is essential to evaluate the model's performance not only based on accuracy or MCC but also considering sensitivity to ensure correct predictions of toxic molecules. The stacked model has better sensitivity for both datasets i.e. 0.7118 for the test set and 0.7375 for the external validation set. Additionally, the Stacked Model also exhibits good specificity, which corresponds to the non-toxic class, indicating its ability to accurately classify both toxic and non-toxic molecules. Unlike some instances of the base classifiers that may exhibit bias toward a specific class, the stacked model shows balanced classification performance for both classes.

As can be seen from Table 9 the performance of Stacked Model seems to outperform the base learners. To further evaluate the statistical significance of these results a corrected version of McNemar's test is employed. χ2 and p-value have been compared between the stacked model and the base learner models based on McNemar's contingency table. The contingency tables of comparison w.r.t stacked model are mentioned in the ESI.†

McNemar's statistical analysis supports the finding that the stacked model outperforms random forest, multi-layer perceptron, and LightGBM, as their p-values (Table 9) are below significance level of 0.05, indicating significant differences in performance.

## Section: Results and discussions › Comparison with eToxPred

The performance of the proposed method is also compared with an existing publicly available toxicity prediction tool for small molecules i.e. eToxPred.13 It employs an Extra Trees Classifier to compute the Tox-score ranging from 0 (low probability of toxicity) to 1 (high probability of toxicity). The model takes SMILES as input and employs molecular fingerprints directly from compounds to predict toxicity. The eToxPred model has been compared with MolToxPred on the test set and the external validation set.

As can be depicted from Fig. 6A and B, on comparison of AUROC scores of the stacked model and eToxPred classifier, the stacked model clearly outperforms in both the cases of the test set and external validation set by 14.91% and 6.88% respectively.

The performance of the stacked model as compared to eToxPred can be further evaluated on various evaluation metrics. eToxPred shows moderate performance on the test set and external validation set, with accuracy ranging from 62.97% to 71.11%. However, when compared to the stacked model, their performance was lower.

In the case of eToxPred, the F1 score is 0.6593 for the test set and 0.73 for the external validation set. These scores suggest a moderate level of accuracy in predicting toxic molecules. However, when these scores are compared with the stacked model's F1 score of 0.7643 for the test set and 0.7867 for the external validation set, it can be clearly seen that the stacked model outperforms the predictive performance of eToxPred. The stacked model demonstrates a better balance between precision and recall, enabling it to effectively predict both toxic and non-toxic molecules.

Although the goal of any toxicity prediction tool is to accurately predict toxic molecules, but it is equally important to have a tool that generalizes well and is not biased towards any particular class. It can be observed that eToxPred seems to be biased towards one class, as evidenced by the sensitivity and specificity values.

The stacked model, on the other hand, demonstrates better performance in terms of sensitivity, specificity, and other metrics. This suggests that the MolToxPred has a more balanced prediction capability and can better generalize to both toxic and non-toxic molecules.

A few test cases have been mentioned here demonstrating MolToxPred outperforming eToxPred. Aflatoxins, which are carcinogenic mycotoxins produced by Aspergillus fungi, have been associated with contamination of the global food supply. Aflatoxin B1 (AFB1), recognized as the most potent natural carcinogen98 among these compounds, has been scientifically linked to the development of hepatocellular carcinoma (HCC) in both humans and animals.99 Additionally, its hydroxylated metabolite, aflatoxin M1,100 found in milk and milk products, exhibits similar toxicity to AFB1.101 MolToxPred accurately predicts the toxicity of this class of small molecules with high probability, while eToxPred incorrectly categorizes them as non-toxic.

Oleandrin, a plant metabolite plays a role in traditional medicinal practices102 to treat various diseases. At the same time, oleandrin is highly toxic and gets easily accumulated in vivo, which may lead to life-threatening intoxication.103 It can also cause both gastrointestinal and cardiac effects.104 While eToxPred misclassifies this plant toxin as non-toxic, MolToxPred accurately predicts its toxicity.

ε-Amanitin is one of the eight Amatoxins found in different genera of poisonous mushrooms, most notably Amanita phalloides. Its mechanism of action involves inhibiting RNA polymerase II, which results in the halting of protein synthesis and disruption of cell metabolism, ultimately leading to cell death.105 ε-Amanitin is known to cause liver and kidney damage, with the most severe cases being toxic hepatitis characterized by centrilobular necrosis and hepatic steatosis.106 In terms of toxicity prediction, MolToxPred correctly identifies ε-Amanitin as highly toxic, whereas eToxPred may not provide the same level of accuracy.

## Section: Towards identifying the correlation between structural alerts and biological pathways for toxicity

The interaction between a chemical compound and the human body can be a complex cascade of different molecular pathways. Understanding the possible relationship between the biological pathway and the substructures that activate a specific characteristic of a molecule, may be helpful in identifying Structural alerts (SAs). Structural alerts are chemical substructures whose presence in compounds is associated with specific types of toxicity/activity. Structural alerts (SAs) based methods are computationally simple and structurally transparent in silico methods to identify the toxic compounds.107

Typically, methods used to identify structural alerts can be broadly categorized as fragment-based, graph-based, or fingerprint-based approaches. Yang et al.108 demonstrated that fragment-based methods are more effective in accurately identifying structural alerts within chemical structures. In the current study, SARpy,17 a recursive fragmentation-based method, has been employed to identify structural alerts for each assay of Tox21 data. Given the training set of molecular structures from each Tox21 assay, with their experimental activity binary labels, SARpy generates every substructure in the set and mines correlations between the incidence of a particular molecular substructure and the activity of the molecules that contain it.17 Here the target activity label has been set as ‘positive’ for the extraction of structural alerts. In the implementation of SARpy, the fragment size was set to a minimum of 2 and a maximum of 18 atoms. Further to this, a substructure was considered as a SA if it occurs in the minimum of 3 molecules in the dataset for that assay. The precision was set to minimize the false negatives and only the positive rules (active substructures) were extracted with the likelihood ratio threshold of more than 2 for each SA.

These efforts yielded approximately 400 unique SAs across all 12 assays. The specific SAs obtained for each assay are detailed in the ESI in Fig S4–S15.† These SAs may serve as distinctive identifiers for their respective biological pathways. The presence of a particular substructure within a molecule may be helpful in providing a potential correlation with the toxicity-related pathway associated with that molecule.

In order to find an association between a new molecule and any of the Tox21 pathways, substructure matching was conducted on the test set of the Tox21 challenge. This set of 266 molecules encompassed both bioactive molecules with activity in one or more pathways and bioinactive molecules with no activity in any of the pathways across all assays, thereby validating the SAs identified by SARpy from the Tox21 train set.

The substructure-matching results across each assay of the Tox21 test set are mentioned in the ESI.† Across all assays, the test data is aggregated based on whether a molecule exhibits activity in any of the assays within the Tox21 test set. Molecules showing activity are categorized as having a positive label (125), while those consistently showing inactivity across all assays are categorized as having a negative label (171). One critical observation is the relatively high number of True Positives (TP) at 116, signifying the accurate identification of endpoints in molecules because of activity in at least one assay within the Tox21 test set. This is indeed a promising outcome as it demonstrates the approach's ability to detect potentially hazardous compounds effectively. However, it is equally important to address the high number of False Positives (FP) at 150. These false positives represent cases where the algorithm erroneously identified molecules as active when they are, in fact, inactive across all assays. The high number of false positives can also be attributed to the limited number of labeled Tox21 test set. This can also be seen in cases like aniline which is part of FP still, the compound is classified as Group B2, a probable human carcinogen by EPA, and causes serious eye damage and allergic reactions.109 Similarly phenyldiazene is another SA which is FP here but is present in compounds like pesticide fipronil110 and fungicide Pyraclostrobin which can lead to disrupting CNS activity and secondary hepatotoxicity respectively.110,111

To improve the overall performance, it is evident that further refinement is required, particularly in reducing the number of false positives. This is where the availability of more labeled data (quantity and quality both) and expert opinion becomes crucial in identifying the relevance of SAs.

The reported structural alerts belong to phenols, aminophenols, furan, and nitroamine and have also been reported by Dang et al.112 Additionally, this study reports the presence of certain halogen derivatives as SA that have also been identified as potential mutagens113 in the literature. Some small toxic radicals SAs identified in this study like N <svg xmlns="http://www.w3.org/2000/svg" version="1.0" width="13.200000pt" height="16.000000pt" viewBox="0 0 13.200000 16.000000" preserveAspectRatio="xMidYMid meet"><metadata> Created by potrace 1.16, written by Peter Selinger 2001-2019 </metadata><g transform="translate(1.000000,15.000000) scale(0.017500,-0.017500)" fill="currentColor" stroke="none"><path d="M0 440 l0 -40 320 0 320 0 0 40 0 40 -320 0 -320 0 0 -40z M0 280 l0 -40 320 0 320 0 0 40 0 40 -320 0 -320 0 0 -40z"/></g></svg> N, N–N, N <svg xmlns="http://www.w3.org/2000/svg" version="1.0" width="13.200000pt" height="16.000000pt" viewBox="0 0 13.200000 16.000000" preserveAspectRatio="xMidYMid meet"><metadata> Created by potrace 1.16, written by Peter Selinger 2001-2019 </metadata><g transform="translate(1.000000,15.000000) scale(0.017500,-0.017500)" fill="currentColor" stroke="none"><path d="M0 440 l0 -40 320 0 320 0 0 40 0 40 -320 0 -320 0 0 -40z M0 280 l0 -40 320 0 320 0 0 40 0 40 -320 0 -320 0 0 -40z"/></g></svg> O, R–O–X, etc. have also been reported by previous studies.108 Polycyclic aromatic compounds like Anthracene and fluorene have also been identified as SAs. Studies show anthracene and its derivatives bind to estrogen and androgen receptors leading to embryotoxicity.114

It is important to emphasize here that some of the structural alerts are only highlighted here. These structural “alerts” should be regarded as hypotheses for potential undesirable mechanisms rather than strict rules. The generation of structural alerts by SARpy might identify redundant and over specific substructures. Hence more input from experts can help narrow down these SAs, but such approaches can work as providing a head start to pharmaceutical researchers.

## Section: Conclusion

Before releasing a product for human consumption, the computational toxicity prediction of any compound/molecule aids in the risk assessment procedure for both companies and regulatory bodies. A number of criteria, including compositional, structural, and molecular properties, must be considered when determining a chemical's toxicity. Machine learning-based methods have come to the rescue because these can automatically handle large datasets and perform statistical analysis to find patterns in data. As a result, in this study, a machine learning-based classification workflow was developed to predict the toxicity of molecules using a molecule's structural, molecular, and chemical properties.

The training dataset is curated to represent small molecules that humans come into contact with, such as drugs, metabolites, environmental pollutants, food toxins, and so on, and this dataset plays a role in good model performance. A stacked model was used to take advantage of diverse base classifiers each of which bring its own capabilities. An extensive feature selection method has been implemented to reduce redundant features that do not contribute to the prediction of toxicity. To find the best set of hyperparameters, Bayesian optimization with stratified 5-fold cross-validation was used to avoid overfitting. The tool's effectiveness is validated by reported different evaluation metrics such as AUROC, F1-score, and accuracy in predicting a molecule as toxic or non-toxic. Permutation Importance across the base classifiers has been used to explain the significance of the selected features in predicting toxicity. The developed model's performance was evaluated using both a test set and an external validation set. The proposed method also outperformed the eToxPred tool in terms of performance, which shows this method is at par with existing methods. The performance is attributed to robust data curation: a combination of fingerprints & descriptors, the addition of metabolites and intensive feature selection, and rigorous hyperparameter tuning.

The test and validation set results confirm not only the importance of these properties but also lay the ground for machine learning in toxicity applications. In addition to this, the study also identified a number of structural alerts, shedding light on potential toxic pathways and risks associated with various molecules. These findings can serve as valuable hypotheses for further research, emphasizing the need for expert input to refine and optimize these alerts. One significant challenge when employing AI-based methods and structural-based approaches for drug toxicity prediction is the insufficient availability of high-quality data.115,116 The development of high-performing models in both AI and structural-based approaches relies on having an ample quantity of training data, coupled with the verification of its quality. Despite the increasing volume of publicly accessible toxicity data, the quality of such data remains a constraining factor. Nevertheless, this workflow will assist the scientific community in determining a molecule's or compound's physiological and environmental toxicity and its association with toxicity related biological pathways before moving forward in the drug development pipeline.

## Section: Data availability

The tool and data are available at https://github.com/bioinformatics-cdac/MolToxPred.

Given a new molecule as input the MolToxPred CLI tool, will calculate and provide the probability of the molecule being toxic. This probability score indicates the likelihood that the given molecule may exhibit toxic properties. A higher probability suggests a higher likelihood of toxicity. The output will also include information about the plausible Tox21-based endpoints associated with the molecule.

## Section: Conflicts of interest

There are no conflicts of interest to declare.

## Section: Acknowledgments

The authors gratefully acknowledge the Ministry of Electronics and Information Technology (MeitY), Government of India, New Delhi, and National Supercomputing Mission (NSM) for providing financial support.

## Section: Associated Data › Data Availability Statement

The tool and data are available at https://github.com/bioinformatics-cdac/MolToxPred.

Given a new molecule as input the MolToxPred CLI tool, will calculate and provide the probability of the molecule being toxic. This probability score indicates the likelihood that the given molecule may exhibit toxic properties. A higher probability suggests a higher likelihood of toxicity. The output will also include information about the plausible Tox21-based endpoints associated with the molecule.


---

# Morphological profiling for drug discovery in the era of deep learning

- **Authors:** Qiaosi Tang, Ranjala Ratnayake, Gustavo Seabra, Zhe Jiang, Ruogu Fang, Lina Cui, Yousong Ding, Tamer Kahveci, Jiang Bian, Chenglong Li, Hendrik Luesch, Yanjun Li
- **Issuer:** Briefings in bioinformatics
- **Type:** Scientific article
- **Published:** 2024-05-23
- **Language:** en
- **DOI:** 10.1093/bib/bbae284
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38886164/
- **Licence:** CC-BY

## Section: Abstract

AbstractMorphological profiling is a valuable tool in phenotypic drug discovery. The advent of high-throughput automated imaging has enabled the capturing of a wide range of morphological features of cells or organisms in response to perturbations at the single-cell resolution. Concurrently, significant advances in machine learning and deep learning, especially in computer vision, have led to substantial improvements in analyzing large-scale high-content images at high throughput. These efforts have facilitated understanding of compound mechanism of action, drug repurposing, characterization of cell morphodynamics under perturbation, and ultimately contributing to the development of novel therapeutics. In this review, we provide a comprehensive overview of the recent advances in the field of morphological profiling. We summarize the image profiling analysis workflow, survey a broad spectrum of analysis strategies encompassing feature engineering– and deep learning–based approaches, and introduce publicly available benchmark datasets. We place a particular emphasis on the application of deep learning in this pipeline, covering cell segmentation, image representation learning, and multimodal learning. Additionally, we illuminate the application of morphological profiling in phenotypic drug discovery and highlight potential challenges and opportunities in this field.Keywords: artificial intelligence, deep learning, morphological profiling, drug discovery

## Section: Introduction

Phenotypic drug discovery (PDD) plays a crucial role in drug discovery. In contrast to target-based drug discovery (TDD), where compounds are designed to interact with known target molecules, PDD takes a target-agnostic approach and focuses on phenotypic effects of compound treatment in disease-relevant biological systems [1, 2] (Fig. 1A and B). This strategy uses reference compounds with treatment class annotations to uncover previously unknown mechanisms of action (MOAs) of the test compounds. To date, PDD has made a significant contribution to the development of first-in-class drugs and the discovery of novel therapeutic opportunities [1, 2]. For example, PDD is the primary approach in natural products discovery and the basis for identification of new targets and/or MOAs. Natural products are all bioactive, and the most effective way to multiplex and assign function is through phenotypic screening, particularly by analyzing related biased and unbiased nuances from high-content imaging [3–6].

Automated microscopy and image analysis have enabled high-throughput image-based assays for PDD [1, 7]. The two approaches, namely, high-content screening (HCS) and morphological profiling, are both based on imaging experiments at a large scale, yet distinct in strategy (Fig. 1C and D). In HCS, feature measurements are limited to specific phenotypes related to perturbations. In contrast, morphological profiling (also known as image-based profiling or cytological profiling) is an unbiased approach to capture high-dimensional image data consisting of hundreds to thousands of cellular features. Conventionally, bioimage informatics tools can measure these features that span a range of morphological properties to generate phenotypic signatures for clustering and predicting perturbation bioactivity similarity [7, 8]. To this end, this approach not only provides a comprehensive morphological profile in an unbiased manner but also allows for detecting subtle or novel phenotypes.

As a dominant technique in artificial intelligence (AI), deep learning uses deep neural networks to learn representations from raw data format in a data-driven manner, often without the needs of feature engineering [9]. In the context of drug discovery, deep learning enables efficient development of novel therapeutics through various applications, such as target identification [10, 11], protein structure prediction [12, 13], drug–target interaction prediction [14–16], de novo drug design [17, 18], molecular property prediction [19, 20], and biological image analysis for PDD [21, 22]. In recent years, computer vision has led to a profound transformation of image-based profiling analysis in efficiency and performance, thereby expediting drug discovery and reducing computational cost [22, 23].

In this review, we aim to provide a comprehensive overview of the extant computational approaches employed in morphological profiling with a particular emphasis on the deep learning applications. We primarily focus on the analytical pipeline of Cell Painting high-content image data given its wide application in academic research and pharmaceutical industry. We start with an introduction of Cell Painting image analysis workflow with conventional feature-engineering approach (also known as ‘handcrafted’ representation). For the major focus, we provide a thorough summary of recently proposed deep learning approaches in advancing this analytical pipeline, including microscopic image cell segmentation, representation learning from high-content fluorescent images, and multimodal learning to integrate chemical structure and omics data for MOA prediction. With concrete examples in cutting-edge applications, we conclude with our perspectives on future directions in advancing morphological profiling with deep learning solutions (Fig. 2).

Early-stage drug discovery approaches. (A) and (B) illustrate two primary approaches in drug discovery: target-based drug discovery (TDD) and phenotypic drug discovery (PDD). (A) TDD starts with a known drug target, and a target-based assay is established to evaluate the effect of compound–target interaction. (B) In contrast, PDD employs a target-agnostic strategy, screening compounds to determine whether a phenotype of interest is induced. Due to its unbiased nature, a target identification step is required. Within the context of PDD, (C) high-content screening (HCS) and (D) morphological profiling are two commonly used approaches. The major difference is (C) HCS uses a limited number of perturbation-specific phenotypes as assay readout, whereas (D) morphological profiling obtains cellular feature representation with an unbiased approach.

Schematic workflow of morphological profiling. After cells are perturbed and stained, fluorescent images are taken to capture cellular morphology. Single cells are detected and segmented. At the single-cell level, morphological features can be achieved with image analysis software to extract pre-defined features. Alternatively, feature vectors can be obtained through representation learning with a deep neural network. Features from single cells are subsequently aggregated into a treatment-level morphological profile. Certain deep learning models allow end-to-end learning, eliminating the need for cell segmentation. The resulting morphological profile is then applied to downstream tasks such as classification for MOA prediction and clustering for treatment association inference (left panel). Additionally, other profile modalities, such as chemical structure and transcriptomic and metabolomic profiles, can be integrated with the morphological profile to enhance downstream analysis (middle panel). Altogether, these efforts enable many novel downstream applications, such as characterizing perturbation impacts in dynamics, constructing gene function network to map genotype–phenotype relationship, identifying compound MOAs in 3D organoid model, and guiding de novo hit design (right panel).

## Section: Deep learning in morphological profiling analytical pipeline

Publicly available cellular microscopic image datasets for model training and evaluation

Recent publication trend of morphological profiling with deep learning. Pubmed trend demonstrates a growing number of indexed publications on morphological profiling with deep learning, including the keywords ‘deep learning’ with ‘morphological profiling’ or ‘image-based profiling.’ This trend is analyzed from 2014 to 2022.

An overview of key methods and the state-of-the-art approaches in morphological profiling data analysis. Cellular images from morphological profiling assays can be analyzed using two approaches: stage-wise feature-based (top panel) and end-to-end deep learning-based (bottom panel). In the feature-based approach, image data are analyzed in four sequential stages: Stage 1 involves image preprocessing, single-cell segmentation, and feature extraction, Stage 2 aggregates cell-level features into well-level or treatment level profiles, and Stage 3 classifies each profile into the corresponding treatment class and clusters each profile based on phenotypic similarity. In contrast, deep learning–based approaches perform analysis in an end-to-end fashion with different learning paradigms. We illustrate these state-of-the-art approaches on a timeline to highlight their development.

A selection of open-sourced image analysis tools

Representation learning strategies for cell morphology. At the pre-training stage, several learning strategies can be applied. (A) Supervised representation learning employs a deep neural network trained on microscopic image data with the label (treatment class). (B) Transfer learning utilizes a deep neural network initially trained on other types of annotated image data, such as natural images, to learn representations applicable to microscopic images. The pretext task is to predict the image class. (C) Weakly supervised representation learning considers the treatment labels as the weak/noisy labels. A deep neural network is trained on a pretext task to predict the treatment class of the microscopic images. The learned feature embeddings will be used to infer treatment class similarity. (D) Self-supervised representation learning utilizes the data intrinsic information for model pretraining, such as microscopic image reconstruction. These pretext tasks enhance the model's ability to learn effective representations for major tasks. Following the pretraining stage, the fine-tuning stage transfers the learned knowledge to specific downstream tasks, such as classifying query perturbations to reference perturbations for MOA inference.

Model performance comparison by MOA classification accuracy on the BBBC021 dataset

Comparison of transcriptomic and morphological profiling data for drug discovery

Multimodal datasets with matched transcriptomic and morphological profiling data

Combine morphological data with other data modalities. The image data obtained from morphological profiling assays can be combined with other modalities of profiling data to perform downstream tasks jointly. One strategy involves training individual models to extract representations from each data modality, such as image data, chemical structural data, and transcriptomic data. These individual representations contribute to a joint embedding, which is subsequently utilized for downstream analyses.

## Section: Deep learning in morphological profiling analytical pipeline › Cell Painting and benchmark datasets

A state-of-the-art assay for morphological profiling is known as Cell Painting [24]. The canonical protocol on adherent monolayer cells uses six fluorescent dyes to characterize eight cellular components or organelles and images the fixed and stained cells in five channels on a high-throughput microscope [25]. Recent optimization efforts have further improved the assay’s capability in phenotype detection [26]. Whereas canonical Cell Painting captures cellular morphology in snapshots, technical advances now enable live-cell imaging, such as using reporter cell lines that carry organelle or pathway marker with fluorescent tag. This allows for capturing morphological profiles in dynamics [27].

Over the past decade, morphological profiling efforts from academia and pharmaceutical industry have produced several publicly available Cell Painting datasets. These include (i) the Broad Bioimage Benchmark Collection (BBBC) with compound and genetic perturbations [28–30], (ii) The Image Data Resource (IDR) with both HCS images and time-lapse images [31], (iii) the RxRx datasets released from Recursion with compounds, genetic and viral transduction perturbations, and (iv) the CytoImageNet dataset curated from 40 openly available and weakly labeled microscopy images [32]. Notably, the Joint Undertaking in Morphological Profiling Cell Painting (JUMP-CP) Consortium has recently been established as the largest public reference Cell Painting dataset [33], including images from more than 116 000 chemical perturbations and over 15 000 genetic perturbations on human osteosarcoma cells (U2OS), which were systematically acquired from 12 data-generating centers [33]. A subset of the JUMP-CP Consortium, cpg0016-jump, has been used in a recent benchmark study to evaluate self-supervised learning (SSL) methods and feature-based approaches [23]. This dataset includes single-source (data generated from a single laboratory) training set of 391 815 Cell Painting images from 35 892 compound treatments, and multisource (data generated from multiple laboratories) training set of 564 272 images from 10 057 compounds. The evaluation set includes 33 962 single-source images and 75 545 multisource images [23]. The curation of this dataset not only allows for assessing model performance using biological labels but also enables evaluation of batch effect handling [23]. An extension to this dataset, labeled CPJUMP1, has been curated to include pairs of chemical and genetic perturbations that both target the same genes in the settings of U2OS and human lung carcinoma epithelial cells (A549) [34]. This dataset consists of approximately 3 million Cell Painting images along with the feature-based profiles from 75 million single cells are well-level aggregated profiles. This unique dataset of paired annotated chemical and genetic perturbations allow for investigating gene–compound relationship [34]. These public reference datasets have been broadly used to train machine learning and deep learning models for compound bioactivity prediction and image representation learning for feature embedding. Details of these datasets are summarized in Table 1.

Among the above-mentioned datasets, the BBBC021 dataset [35] is the most commonly used benchmark to evaluate the performance of deep learning methods. This dataset, publicly available from the Broad Bioimage Benchmark Collection [28], includes Cell Painting images of human MCF-7 breast cancer cells treated with 113 compounds at eight concentrations. Most of the representation learning methods (section Representation Learning for Morphological Profiling) were compared on a subset of 103 treatments from 38 compounds. These compounds have been manually annotated with one of 12 MOAs as the ground truth. The effectiveness of different MOA prediction methods is assessed using the following evaluation metrics:

Publicly available cellular microscopic image datasets for model training and evaluation

## Section: Deep learning in morphological profiling analytical pipeline › An overview of image-based profiling data analysis

An accurate, efficient, and generalizable imaging data analysis workflow is critical for morphological profiling. Established methods and best practices have been comprehensively documented [39–43]. However, the past few years have witnessed significant strides in the application of deep learning approaches (Fig. 3). In this section, we present an overview of the critical stages in morphological profiling data analysis, with particular emphasis on deep learning advances (Fig. 4).

Recent publication trend of morphological profiling with deep learning. Pubmed trend demonstrates a growing number of indexed publications on morphological profiling with deep learning, including the keywords ‘deep learning’ with ‘morphological profiling’ or ‘image-based profiling.’ This trend is analyzed from 2014 to 2022.

An overview of key methods and the state-of-the-art approaches in morphological profiling data analysis. Cellular images from morphological profiling assays can be analyzed using two approaches: stage-wise feature-based (top panel) and end-to-end deep learning-based (bottom panel). In the feature-based approach, image data are analyzed in four sequential stages: Stage 1 involves image preprocessing, single-cell segmentation, and feature extraction, Stage 2 aggregates cell-level features into well-level or treatment level profiles, and Stage 3 classifies each profile into the corresponding treatment class and clusters each profile based on phenotypic similarity. In contrast, deep learning–based approaches perform analysis in an end-to-end fashion with different learning paradigms. We illustrate these state-of-the-art approaches on a timeline to highlight their development.

A selection of open-sourced image analysis tools

## Section: Deep learning in morphological profiling analytical pipeline › An overview of image-based profiling data analysis › Stage 1: Feature representation

Measuring variations in cell morphology upon perturbation relies on generating effective representations for cellular images. Conventionally, this task is implemented by feature engineering approaches. Bioimaging software like CellProfiler is commonly used to extract predefined features such as cell shape, size, and texture from fluorescent microscopy images [44]. In addition to CellProfiler, we have also summarized other open-source image analysis software and tools in Table 2. While this approach provides biologically insightful results, it requires image preprocessing and manual adjustment of parameters for every new experiment setup [39, 41]. Also, single-cell segmentation is typically required, which will be described in detail in section Deep Learning–Facilitated Cell Segmentation for Image Analysis.

Alternatively, deep neural networks such as pre-trained convolutional neural networks (CNNs) can learn representation directly from a full-field microscopy image without the need for single-cell segmentation [37, 45]. Further, generative adversarial network (GAN)–based models and variational autoencoder (VAE) framework have been proposed to improve the interpretation of cellular structural variations that drive morphological differences [46–48] and to predict morphological responses to perturbations [49]. These advances from deep learning-based analysis approaches will be further discussed in section Representation Learning for Morphological Profiling.

A selection of open-sourced image analysis tools

## Section: Deep learning in morphological profiling analytical pipeline › An overview of image-based profiling data analysis › Stage 2: Morphological profile generation

Once features are extracted from single cells or field images, these measurements will be aggregated into a single feature vector for well-level (also known as treatment-level or population-level) representation. The morphological profile generated from this stage will enable downstream well-level analysis [39].

## Section: Deep learning in morphological profiling analytical pipeline › An overview of image-based profiling data analysis › Stage 3: MOA annotation

With the aggregated treatment-level morphological profiles, a common machine learning task is to predict MOA or toxicity of query perturbagens based on the known morphological profiles of the reference library [40]. This is most commonly achieved by building a feature-based machine learning model such as nearest neighbor classifier, random forests, or Bayesian matrix factorization [39, 40, 50] on top of the extracted morphological profiles. With these supervised machine learning algorithms, query perturbagens can be classified into predefined, annotated classes [40]. The aggregated morphological profiles can also be used to infer treatment-level associations. This task is typically accomplished by employing hierarchical unsupervised clustering algorithms, predicted on the similarity of morphological profiles [40]. A phenotypic similarity matrix of all pair-wise similarities between morphological profiles is computed for similarity-based clustering [40].

Notably, deep learning techniques facilitate an end-to-end learning schema, integrating all the aforementioned stages into a singular, unified process. Within this framework, the phenotypic classification and clustering tasks can be directly accomplished using raw high-content images, circumventing the explicitly image feature representation, morphological profile generation, and other intermediate steps. This end-to-end learning schema will be elaborated in section Representation Learning for Morphological Profiling.

## Section: Deep learning in morphological profiling analytical pipeline › Deep learning–facilitated cell segmentation for image analysis

Cellular object detection and segmentation is a critical yet challenging step of microscopic image analysis. Whereas classical segmentation algorithms such as thresholding and watershed have been commonly used in bioimage analysis software [51], recent advances of deep learning in computer vision have generated various image segmentation models with substantially improved performance [52]. In the 2018 Data Science Bowl, a global competition focusing on 2D nucleus segmentation from high-content images, deep learning approaches such as U-Net, Feature Pyramid Network (FPN), and Mask-Regional Convolutional Neural Network (Mask-RCNN) dominated the leaderboard, achieving state-of-the-art performance [51]. We refer the interested readers to the report of the 2018 Data Science Bowl results for details in method and performance [51]. Each of these approaches demonstrates strengths and drawbacks. Initially designed for segmenting electron microscopy images, the U-Net model uses skip connections to append feature maps of the whole input image from the encoder to the decoder. This preserves global location information and allows for accurate reconstruction by the decoder. It can provide accurate segmentation maps with limited training data [53]. Like U-Net, FPN also leverages lateral connections. However, instead of copying and concatenating feature maps from encoder to decoder, 1 × 1 convolution is applied to allow for flexible processing [54]. In contrast to fully convolutional networks (FCNs) that use the full context of the input image, Mask R-CNN works on selected Regions of Interest (ROIs) of an input image to obtain predicted class, bounding box, and segmentation mask simultaneously. This method performs well on instance segmentation tasks to handle multiple objects with complex shapes, albeit more training examples are needed compared to U-Net [55].

A common limitation of those approaches is that their performances suffer when nuclei are packed densely. To address this challenge, STARDIST was developed to predict a flexible shape representation—a star-convex polygon instead of an axis-aligned bounding box is predicted for each pixel. When benchmarked on the 2018 data science bowl dataset, STARDIST outperformed U-Net or Mask R-CNN based models for intersection over union (IoU) threshold τ < 0.75 [56]. This method has also been successfully extended for 3D nuclei segmentation (STARDIST-3D) [57]. Fully convolutional regression networks (FCRNs) represent another solution to this challenge, regressing a cell spatial density map of the image. FCRNs demonstrated superior performance at microscopic cell counting when traditional single-cell segmentation fails due to cell clumping or overlap [58]. Another object shape representation approach is proposed by the Cellpose segmentation model. This approach generates topological maps through simulated diffusion and uses human-annotated masks as ground truth. The horizontal and vertical gradients of the topological maps are then predicted to form vector fields. Through gradient tracking, pixels that converge to the same center point are assigned to the same mask [59]. With this representation approach, the Cellpose model outperformed STARDIST, Mask R-CNN, and U-Net models at all IoU thresholds on the Cell Image Library dataset [59].

Another limitation of the above-mentioned segmentation approaches is that their training process is fully supervised, thus requiring considerable amount of expert annotations. To alleviate this requirement, Hollandi et al. proposed nucleAlzer, which uses image style transfer approaches to generate a set of representative image–label pairs. Applying this data augmentation paradigm to the Mask R-CNN-based model improved segmentation performance on several image datasets [60].

In addition to CNN-based models, recently, a novel deep learning architecture, CellViT, was proposed for nuclei segmentation in digitized tissue samples based on Vision Transformer (ViT) [61]. In contrast to CNN-based models, ViTs allow input images with arbitrary sizes and can capture long-range dependencies given the self-attention mechanism [62]. CellViT uses a U-Net-shaped encoder–decoder network, which leverages pre-trained ViTs such as ViT256 [63] and Segment Anything Model [64] (SAM) as the encoder network and bridges the encoder and decoder components at multiple network depths via skip connections [61]. Although it demonstrated SOTA performance on a histological image dataset [61], it remains to be investigated whether this model can be generalized to the single-cell segmentation task for Cell Painting datasets.

## Section: Deep learning in morphological profiling analytical pipeline › Representation learning for morphological profiling

Feature representation is a critical step in morphological profiling. Morphological features can either be extracted through feature-engineering approach or learned with deep neural network [65]. The former approach, however, requires manual efforts in fine-tuning software parameters per experiment setup and relies on expert knowledge to decide what phenotypic features should be measured. In contrast, deep neural networks take an unbiased approach to learn features directly from raw pixels of images and encode meaningful representations [66]. Not only do these end-to-end trained deep neural networks obviate the need for any segmentation steps but also the learned representation enables superior performance. Moreover, these networks exhibit improved transferability across different perturbation types (chemical versus genetic) and demonstrate faster pipeline processing speeds in classification tasks compared to models trained on engineered features [23, 67, 68] (Fig. 5).

Representation learning strategies for cell morphology. At the pre-training stage, several learning strategies can be applied. (A) Supervised representation learning employs a deep neural network trained on microscopic image data with the label (treatment class). (B) Transfer learning utilizes a deep neural network initially trained on other types of annotated image data, such as natural images, to learn representations applicable to microscopic images. The pretext task is to predict the image class. (C) Weakly supervised representation learning considers the treatment labels as the weak/noisy labels. A deep neural network is trained on a pretext task to predict the treatment class of the microscopic images. The learned feature embeddings will be used to infer treatment class similarity. (D) Self-supervised representation learning utilizes the data intrinsic information for model pretraining, such as microscopic image reconstruction. These pretext tasks enhance the model's ability to learn effective representations for major tasks. Following the pretraining stage, the fine-tuning stage transfers the learned knowledge to specific downstream tasks, such as classifying query perturbations to reference perturbations for MOA inference.

Model performance comparison by MOA classification accuracy on the BBBC021 dataset

## Section: Deep learning in morphological profiling analytical pipeline › Representation learning for morphological profiling › Supervised representation learning

When extensive annotated training data is available, supervised representation learning become particularly effective [69, 70]. For example, Kraus et al. trained CNNs combined with multiple instances learning on annotated image dataset BBBC021 and yielded higher accuracy in treatment classification compared to the conventional feature-engineering approach [28, 36, 69, 71]. Similarly, Godinez et al. built a multi-scale convolutional neural network (M-CNN) based classifier, which was trained on the same annotated images [70]. This model outperformed other CNN models on classification tasks when benchmarked on several BBBC datasets.

## Section: Deep learning in morphological profiling analytical pipeline › Representation learning for morphological profiling › Transfer learning

However, the availability of relevant annotated image data may not always be assured, and the collection of sufficient training data can be expensive and time-consuming. To that end, transfer learning of pre-trained deep neural networks becomes an alternative solution [72]. Pawlowski et al. for the first time proposed using ImageNet pretrained CNNs for morphological profiling feature representation, and this method achieved superior accuracy and processing speed compared to the feature engineering–based approach [73]. Similarly, Ando et al. proposed Deep Metric Network, a model pre-trained on ~100 million RGB consumer images, to generate embeddings for the BBBC021 image set [37]. Many other CNNs pre-trained on ImageNet have also been used to generate cell morphology embeddings [74, 75].

## Section: Deep learning in morphological profiling analytical pipeline › Representation learning for morphological profiling › Weakly supervised representation learning

In addition to transfer learning, weakly supervised learning (WSL) approach has been proposed to train deep neural networks for learning representations of Cell Painting images [38, 76, 77]. In this learning schema, treatment or compound labels are treated as “weak” or “noisy” labels for several reasons: (i) cells may exhibit heterogeneous responses even to the same treatments; (ii) some treatments are biologically inert; however, in the context of the supervised learning setting with treatments as labels, a deep neural network is nonetheless compelled to identify differences; and (iii) different cell morphology may result from technical artifacts. Therefore, it remains uncertain whether treatment labels accurately reflect cell morphology. To leverage the weak labels, an auxiliary (or pretext) training task is introduced to train a network to classify single cell images to their corresponding treatment labels (the weak labels). Feature embeddings learned from the auxiliary classification task will subsequently be used for the major task, which is to infer the high-level associations between treatments based on similarity. In the setting of drug discovery, this allows for MOA prediction through assigning query compounds to a library of annotated reference compounds [38, 76–78]. Given that these deep neural networks are exposed to the distributions of both true biological phenotypes and confounding factors in the pretext training task, disentangling phenotypes from confounding factors is crucial to the success of this training schema. To achieve this, besides batch correction efforts (summarized in section Challenges and Outlook), a few other strategies have proven to be helpful, such as RNN-based regularization [38], convex combinations of images to generate new samples [38], and combining image datasets with strong perturbations for training [76]. Beyond representation learning with broadly used CNNs, WS-DINO from Cross-Zamirski et al. was proposed to learn representations using a knowledge distillation approach with ViT backbone. In this approach, global and local crops from different images under the same treatment are generated [77]. The teacher network is exposed solely to global crops, whereas the student network sees both, and the objective is to minimize the cross-entropy loss between student and teacher prediction output. Notably, in contrast to many other WSL approaches, WS-DINO does not require single cell cropping for pre-processing [77].

## Section: Deep learning in morphological profiling analytical pipeline › Representation learning for morphological profiling › Unsupervised representation learning

Finally, unsupervised learning approaches provide another avenue for feature representation learning by identifying underlying patterns in raw data or clustering similar data into groups. Examples of such exploitable unlabeled information include whether images belong to the same treatment [79], metadata information [80], and pseudo-labels assigned by K-means clustering on embeddings [81]. Another strategy is to use generative models [82] such as GANs [46] or VAE framework [47, 48] to learn feature representations. They function by learning and generating new data distributions that are similar to the training data, thereby learning inherent structures and patterns within the dataset. In addition, the self-supervised learning (SSL) approach can use a pretext training task, mining the intrinsic information present in the data itself, to train a CNN capable of learning effective feature representation and use it for downstream analysis [83]. For the pretext task, Lu et al. proposed “paired cell inpainting,” whereby the model needs to identify protein localization from the “source” cell and predict the similar localization in the “target” cell [83]. The contrastive loss–based approach can also learn robust cell representations by training the model to bring positive example representations closer in the feature space and push the negative example representations further away from the positive ones [84]. Perakis et al. demonstrated that representations learned with the contrastive learning framework can be used in MOA classification task with the impressive performance on par with the transfer learning approach [37, 84]. Beyond the CNN-based model, the SSL method has also been employed to pre-train the ViT architecture, resulting in significant enhancements even in segmentation-free morphological profiling [23, 85]. In evaluations using subsets of the JUMP-CP Consortium data, the ViT architecture, trained by the recently introduced DINO SSL approach, outperformed both CellProfiler and transfer learning–based methods in several dimensions. Specifically, when trained on multisource data, this approach demonstrated the best performance in classification tasks. The resultant image representations showcased exceptional adaptability, transitioning efficaciously from chemical to genetic perturbations. Moreover, the pipeline functioned at speed 50 times faster than CellProfiler-based feature engineering workflow [23]. It is noteworthy that, unlike CNNs where local features are consolidated into aggregated vectors, ViTs preserve a more refined resolution of inputs across all network layers, and this preservation facilitates the encoding of features that are biologically meaningful at the subcellular level [85]. Notably, ChannelViT has been proposed to make a simple modification to the ViT architecture by constructing patch tokens independently from each input channel and includes a learnable channel embedding. These modifications improve model reasoning across channels, such that the model can generalize efficiently even when limited input fluorescent channels are available. When trained with DINO algorithm, ChannelViT consistently outperforms standard ViT on input images with varying sets of fluorescent channels [86]. Altogether, these findings underscored the formidable efficacy and robustness of SSL approaches in morphological profiling.

Most of the representation learning approaches described in this section have been benchmarked on the BBBC021 dataset with these evaluation metrics. Their performance is summarized in Table 3. From this comparison, WS-DINO, the weakly supervised method from Cross-Zamirski et al. [77] achieved the best performance. The transfer learning method from Ando et al. [37] and the self-supervised contrastive learning method from Perakis et al. [84] also showcased strong performance in learning meaningful phenotypic embeddings.

For deep learning approaches to achieve decent performance in morphological profile analysis, factors such as image dataset characteristics, model complexity, and computational resources must be carefully considered. Increasing the size and diversity of the training set, for example, by including image sets acquired from different laboratories, serves as an effective factor in enhancing performance, more so than simply increasing the model size [23]. In addition, applying appropriate image augmentations significantly benefits the performance of SSL methods such as DINO. Particularly, applying color augmentation on each fluorescent channel independently, through random brightness changes and intensity shifts, has been shown to produce the most significant positive impact on model performance [23]. In terms of computational time and costs, DINO with Graphics Processing Unit (GPU) acceleration can process and analyze data significantly faster than feature-based approaches, and despite requiring GPUs, it incurs lower infrastructure costs for analyzing per cell plate [23].

Model performance comparison by MOA classification accuracy on the BBBC021 dataset

## Section: Deep learning in morphological profiling analytical pipeline › Integrating morphological data in multimodal learning for drug discovery

With the advances in biotechnology, a wealth of data from various modalities can be generated and collected to facilitate drug discovery. Cheminformatics, for example, has made substantial contribution to drug discovery through analysis and representation of chemical structures and exploiting the similarity principle [87]. Chemical structure data of compounds are always readily available, and predicting compound bioactivity based on this data modality can be performed virtually. However, elucidating the intricate relationship between structure and biofunction is a challenging task [87]. On the other hand, ‘Omics’ profiles, such as genomics, transcriptomics, proteomics, and metabolomics, can characterize treatment outcomes from different aspects. However, assay cost and scalability emerge as major concerns for high-throughput studies [88]. Indeed, every modality of data utilized in the drug discovery presents its unique set of advantages and disadvantages. A detailed comparison is summarized in Table 4. Integrating these modalities is promising to maximize their potentials and mitigate the limitations, thereby providing a comprehensive understanding of treatment effects. Notably, recent research has shown that different data modalities, such as chemical structure, morphology, and gene expression, exhibit complementary strengths in predicting treatment effects [89]. Integrating morphological data with other data modalities using machine learning– or deep learning–based approaches has now become an active field of research.

The integration of structural models with cell morphology models has been demonstrated to improve biological assay outcome prediction accuracy. Seal et al. proposed the similarity-based merger model, which combines the scaled predicted probabilities from individual models trained on Cell Painting images and chemical structures, and the morphological and structural similarities between test and training compounds [90]. Specifically, the predictions from individual models and similarity values are used to fit a logistic regression model to predict the test compound activity. The authors demonstrated that the similarity-based merger model outperforms soft-voting ensemble, hierarchical model, or either of the individual models trained on unimodal data [90].

In addition, SSL techniques such as contrastive learning approaches have also been utilized to align multimodal data sources to enrich morphological profiling analysis in drug discovery [91–93]. For example, a method known as Contrastive Leave One Out boost for Molecule Encoders (CLOOME) has been proposed, aiming to learn aligned representations derived from the compound’s chemical structure and the corresponding cellular images obtained after treatment with the same compound [91]. Its learning framework incorporates a microscopy image encoder, a molecule structure encoder, and uses the InfoLOOB objective [94] to learn the aligned embedding of treatment image and compound structure [91]. Similarly, Zheng et al. presented the Molecular graph and hIgh content imaGe Alignment (MIGA) framework with an image encoder and a graph neural network (GNN)–based structural encoder [93]. To align graph embeddings with image embeddings, three contrastive objectives are used: graph-image contrastive learning, masked graph modeling, and generative graph-image matching. The crossmodal representation learned with this framework improves performances on several downstream tasks [93]. This approach is extended further by Nguyen et al. to develop Molecule-Morphology Contrastive Pretraining (MoCoP) [92]. This framework uses a morphology encoder, a gated GNN (GGNN)–based molecule encoder, and the modified InfoNCE objective [95] to learn multimodal representation. The GGNN pretrained with MoCoP can be fine-tuned for downstream quantitative structure–activity relationship (QSAR) tasks [92]. Furthermore, active learning approach has been used to boost the performance of image-based and structure-based models and benefit the downstream QSAR tasks. The initial image-based and structure-based models assist selecting candidate compounds to be validated in toxicity assays. Once the wet-lab assays are completed, assay readouts will be collected as new annotations to continue refining both models. This iterative approach has been applied to detect compounds with mitochondrial toxicity [96].

In addition to chemical structure data, integrating transcriptomic profile with cell morphology serves as another crossmodal combination. A prevalent assay for obtaining gene expression profile is the L1000 assay [97]. Both Cell Painting and L1000 assays are scalable and provide complementary data. Compared to the transcriptomic profile from L1000, the morphological profile from Cell Painting is more reproducible yet susceptible to batch and well position effects. Conversely, L1000 captures more diverse features. Collectively, these two profiling modalities measure overlapping and assay-specific MOAs [98]. Besides the L1000 transcriptomic profile, another gene expression-based assay, Functional Signature Ontology (FUSION), can be fused with morphological profiling data to assign MOAs to complex natural product fractions in pair with metabolomic profiling data [99]. Comparative studies have shown that transcriptome-based and morphology-based models offer comparable or better performance in MOA prediction, compared to the chemical structure-based model [100]. These findings provide rationale and potential advantages of integrating transcriptomic and morphological profiling for drug discovery. More discussions on the applications and concerns of integrating these two data modalities have been recently characterized [101, 102]. Datasets with matched transcriptomic and morphological profiling data are summarized in Table 5.

Data fusion methods have been widely used to integrate multimodal data (Fig. 6). In general, these methods can be categorized as early fusion and late fusion. Early fusion works by integrating the separate raw data modalities into a unified representation before feeding into the deep learning model for feature extraction. In contrast, late fusion combines the predictions of individual models, each built on a specific data modality. Algorithms such as cooperative learning have been proposed to enhance the alignment between predictions [103]. To integrate morphological, transcriptomic, and chemical structure profiles, Seal et al. compared both early and late fusion methods in detecting mitochondrial toxicity. They reported that the late fusion model can accurately determine the mitochondrial toxicity of compounds that have inconclusive toxicity results reported previously [104].

To identify perturbation effects in distinct feature space of morphological and transcriptomic data, Smith et al. proposed Perturbational Metric Learning (PeML) for similarity metric learning for multimodal data representation [105]. This WSL approach aims to learn an embedding to maximize the similarity between replicates, while non-replicates stay dissimilar. This learning methodology can be applied to both morphological and transcriptomic profiles and has demonstrated improved performance in MOA prediction [105].

Although the integration of morphological and transcriptomic (L1000) profiling offer benefits in MOA prediction, this orthogonal platform still faces challenges. These include limited resolution when identifying bioactive compounds that exhibit widespread cellular effects and reduced sensitivity when investigating bioactive compounds that do not induce distinct morphological changes [99]. To address these limitations, researchers have also investigated metabolomics-based approaches combining morphological characteristics to uncover changes in intracellular metabolism under various conditions [106]. Since metabolites in the cell can provide a comprehensive information of the cell state and define cellular phenotype in response to perturbations, combining cell morphology and metabolomics analysis has proven beneficial. For example, untargeted Mass Spectrometry (MS)–based metabolomics can be integrated with morphological profiling into a single platform to facilitate the quick identification and functional annotation of natural products in a high-throughput setting [99]. High-throughput image-based profiling pipeline can also be combined with multiparametric metabolic profiling approaches, such as oxygen consumption measurements and untargeted MS-based metabolomics to investigate the toxicity mechanism of the antiviral drug Tenofovir [107]. Furthermore, this combined approach can help optimizing microbial biosynthesis strategy, such as improving rapamycin production in Streptomyces hygroscopicus [108]. These studies underscore the significant advantages of integrating metabolomics and morphological, along with other data modalities in accelerating drug discovery process. With advances in MS techniques like MALDI-MS continuing to enhance throughput in metabolomic profiling [109], future studies will increasingly integrate these data with morphological profiling. Concurrently, development of these integrated platform calls for deep learning methods capable of facilitating multimodal learning using both morphological and metabolomics profiles.

In summary, applying deep learning approaches to integrate morphological data with other modalities, such as chemical structure, transcriptomic, and metabolomic data, demonstrates growing importance in drug discovery efforts. Techniques like contrastive learning and various data fusion methods are emerging to align multimodal data. The continuous curating of such multimodal datasets will further contribute to this burgeoning field.

Comparison of transcriptomic and morphological profiling data for drug discovery

Multimodal datasets with matched transcriptomic and morphological profiling data

Combine morphological data with other data modalities. The image data obtained from morphological profiling assays can be combined with other modalities of profiling data to perform downstream tasks jointly. One strategy involves training individual models to extract representations from each data modality, such as image data, chemical structural data, and transcriptomic data. These individual representations contribute to a joint embedding, which is subsequently utilized for downstream analyses.

## Section: Novel applications of morphological profiling in drug discovery

Machine and deep learning approaches have significantly contributed to morphological profiling, enriching various aspects of phenotypic drug discovery. Applications such as identifying small-molecule MOAs, lead optimization, and predicting toxicology have been extensively reviewed elsewhere [110–113]. In the following sections, we will discuss the recent advances in several novel applications.

## Section: Novel applications of morphological profiling in drug discovery › Construct genotype–phenotype relationship and gene function network

Mapping genotype to disease-relevant phenotype has been a critical question in genomics. To address this challenge, genome-scale pooled CRISPR screens have been used to provide insights into gene functions. However, conventional screening readouts are relatively low in dimensionality (such as cell viability, proliferation, or expressions of biomarkers), thereby providing a constrained view of disease-relevant phenotype [114]. While high-content transcriptomic data from scRNA-seq can be measured from pooled CRISPR screens, the cost of achieving high-content readout as such from a genome-wide CRISPR screen can be unfeasibly high [114]. To overcome this hurdle, image-based profiling can provide high-content morphological readout for CRISPR screens at the genome scale [33, 115, 116]. Notably, optical-pooled CRISPR screens [117] can be combined with image-based profiling to create a genome-wide perturbation atlas and to construct a gene function network based on the uncovered genotype–phenotype relationships [115, 118, 119]. For example, Ramezani et al. developed a Cell Painting–based optical-pooled cell profiling approach (PERISCOPE) to allow pooled CRISPR screens to have high-dimensional cellular morphological profiles as endpoint readouts. This scalable pipeline has been applied to A549 cells and human cervical cancer cells (HeLa) to investigate gene knockout responses and identify gene clusters based on morphological similarity [118]. Sivanandan et al. introduced a similar technique termed Cell Painting Pooled Optical Screening in Human Cells (CellPaint-POSH). With this approach, a screening with a druggable genome library of 1640 genes has been conducted on A549 cells. Notably, this work applied the SSL DINO-ViT model (section Representation Learning for Morphological Profiling) for image representation and demonstrated decent performance in recovering the gene function network [119]. Such results further attest to the efficacy and robustness of deep learning approaches in generating informative image representations, subsequently leading to valuable biological insights.

In the efforts of mapping genotype to phenotype, the observation of “proximity bias” has been reported, whereby the phenotypes of CRISPR knockouts demonstrate higher similarity to biologically unrelated genomically proximal genes on the same chromosome arm than the biologically related genes. The cause of this artifact arises from widespread chromosome arm truncation due to Cas9 nuclease activity and is not observed in shRNA or CRISPR interference (CRISPRi) perturbations. Performing arm-based geometric normalization of features at gene level can reduce this bias without compromising the recovery of biological relationship [120].

## Section: Novel applications of morphological profiling in drug discovery › Characterize perturbation impacts in dynamics

An emerging advance of morphological profiling is toward live-cell phenotyping, which can be performed by fluorescent or phase-contrast imaging, and by continuous imaging [27, 121] or dynamic imaging [48]. Several advantages accompany this approach. First, adding temporal variables to the morphological profile improves assay predictive power [27]. For example, in a live-cell imaging-based profiling assay, a library of 1008 The United States Food and Drug Administration (FDA)-approved drugs with manual annotations was profiled against 15 reporter cell lines that expressed fluorescent protein–tagged organelle or pathway markers. The morphological profile was generated from 24-h high-content imaging and can be used to accurately infer 41 of 83 testable MOAs [27]. Beyond this, live-cell imaging enables the characterization of cell-state transition dynamics, a critical feature in developmental biology [48, 121]. Human pluripotent stem cells (hPSCs) coexpressing histone H2B and cell cycle reporters can be profiled in a multi-day, high-content manner at single-cell resolution. With this profile, a deep learning model can be trained to provide highly sensitive predictions of spatiotemporal single-cell fate dynamics, as early or even earlier than cell state–specific reporters [121]. Moreover, live-cell morphological features of human-induced pluripotent stem cells (hiPSCs) can even be used to predict differentiation marker gene expression [48]. This approach involves performing phase-contrast imaging and bulk RNA-sequencing at each consecutive passage of hiPSCs. A VAE variant, VQ-VAE [122], learns the image feature vector in a self-supervised approach. A number of Support Vector Regression (SVR) models, each corresponding to a differentiation marker, were trained to predict differentiation marker gene expression from the image feature vector. Bulk RNA-sequencing readouts were used as labels for this supervised learning process. Altogether, this approach builds the relationship between transcriptional and live-cell morphological profiles [48].

Deep learning models such as DynaMorph [123] and DEEP-MAP [121] have been proposed to analyze morphological profiles in dynamics. To take DynaMorph for example, VQ-VAE was trained to learn a representation of cell shape through a self-supervised image reconstruction auxiliary task. To ensure that cell shape changes smoothly between neighboring frames, a temporal matching loss was applied. The representation of cell shape regularized by the temporal continuity can distinguish morphodynamic states of microglia in response to pro- and anti-inflammatory stimuli [123].

## Section: Novel applications of morphological profiling in drug discovery › Guide de novo hit design

Although the typical downstream applications of morphological profiling have been focused on clustering or classification tasks (section An Overview of Image-Based Profiling Data Analysis), Zapata et al. proposed to leverage morphological profiles to guide de novo molecular design with GANs [124]. Compared to using transcriptional profiling for compound de novo design [125], morphological profiling provides higher throughput with less cost. More importantly, more than 40% of the generated molecules have drug-like physicochemical properties, and more than half are expected to be synthesizable. This model can also be generalized to morphological profile with genetic perturbations such as gene overexpression. These findings indicate that this approach is able to effectively translate morphological similarity into chemical similarity with high efficiency [124].

## Section: Novel applications of morphological profiling in drug discovery › Facilitate image-based profiling in advanced biological models

Organoids are hetero-cellular biomimetic tissue models that have become a powerful experimental tool transforming basic science and translational research [126]. While the traditional low-throughput methods provide valuable biological insights, high-throughput methods are needed to fully exploit the potential of organoids as ex vivo models. Modeling the development of disease with organoids that can recapitulate tissue structure, pathology, phenotypes, and differentiation has revolutionized the study of various human diseases including cancer [126, 127]. In a recent study, Silva et al. and Atanasova et al. demonstrated the effect of small molecules in mouse pancreatic acinar that causes inhibition or reversal of acinar-to-acinar ductal metaplasia (ADM) using high-content image-based screening in organoid culture [128, 129]. Advances in technology in organoid culture and the remarkable self-organizing properties reflecting key structural and functional attributes of organs such as brain, kidney, lung, gut, or similar even hold promise to predict drug response in a personalized fashion.

While organoids are normally cultured in bulk in an extracellular matrix, these bulk cultures can physically overlap, which makes it challenging to track the growth and properties of individual organoids in high-throughput assays. Various microwell designs have been introduced to overcome specific challenges associated with image-based analysis but still struggle with large numbers of organoids [130, 131]. Using different organoid culture methods, phenotypic assays can be designed using features like whole organoid morphology, growth rates, or movement with simple brightfield imaging. Many of these methods rely on cellular aggregation to generate spheroids rather than growing organoids from single cells [132–134]. These can cause limitations in understanding the phenotypic heterogeneity, while most of the methods do not employ integrated analytical pipelines into the overall workflow [135–139] or the ability to selectively retrieve organoids for downstream investigations. Overcoming some of these issues, Forsyth and a team of researchers [126] have built an open-source microwell-based platform for high-throughput quantification using image-based parameters. The method utilizes an organoid-optimized deep-learning model that can be integrated with existing culturing protocols and micro-well platforms to investigate phenotypic features across different tissues. Additionally, patient-derived tumor organoids have been developed into powerful organoid-based discovery platforms in recently demonstrated using CRISPR-Cas9 screening for patient-specific functional genomics [140]. Defined mutations are introduced to transform normal organoids to tumorigenic growth upon xenotransplantation, combining the exploratory power of CRISPR-Cas9 screening with 3D organoids [133, 136, 141]. These advances demonstrate that organoids are powerful experimental models for morphological profiling to study the maturation and progression of various diseases.

## Section: Novel applications of morphological profiling in drug discovery › Enable natural product–based drug discovery

Natural products (NPs) and their structural analogues have made a major contribution to pharmacotherapy, playing a key role in drug discovery [3, 4]. Recent years have witnessed that AI approaches have substantially advanced the efficient identification of drug candidates from NPs, marking notable progress in drug discovery [5]. NP-based drug leads are typically identified by phenotypic assays [4]. To that end, an image-based profiling platform has been developed to study toxicity, structure–activity relationship (SAR), MOA, and potential off-target effects of NPs [6]. For example, a high-throughput screening on MIN6 β cells with 6298 marine NP fractions has been performed to select for hit compounds with nontoxic and long-lasting effects in inhibiting glucose-stimulated insulin secretion [142]. In combination with MS analyses and NMR analyses, aureolic acid CMA2 has been identified as the major component of the top hit fraction derived from S. anulatus. Treating MIN6 cells with CMA2 leads to decreased nuclei counts determine by the 4′-6-Diamidino-2-phenylindole (DAPI) staining, attesting to its bioactivity [143]. In another study, botanical NP extracts have been screened for blockade of SARS-CoV-2 infection in human 293TAT cells. A leading hit, the extracts of S. tetrandra, is further investigated on its antiviral MOA through phenotypic assays based on intracellular phospholipids formation [144]. In addition, high-dimensional phenotypic readouts also assist exploring NP MOA. To understand the MOA of the Polyketide Lagriamide B from the Burkholderiales strain, its morphological impact on U2OS cells is investigated through the Cell Painting assay followed by high-content imaging. At low treatment concentration, Lagriamide B leads to disruption in actin polymerization and incomplete cytokinesis, and at high concentration, low cell count and decreased cell size are observed. These phenotypic effects indicate an MOA of Lagriamide B in actin polymerization disruption [145].

Specifically, integrating morphological with multi-omics profiling helps annotate the bioactive components of NPs, which addresses one of the most significant challenges in NP-based drug discovery [99]. For example, an integrated framework of morphological and transcriptomic profiles has been used to annotate marine bacteria extracts based on its untargeted metabolomics profile [99]. This orthogonal platform demonstrated a new paradigm to understand the association between NP components and treatment phenotypes and underscored the importance of integrating multimodal profiling data for drug discovery (section Integrating Morphological Data in Multimodal Learning for Drug Discovery).

## Section: Challenges and outlook

Morphological profiling is poised to have a profound and continuing impact on phenotypic drug discovery in the next decade and beyond. Deep learning approaches will continue to empower morphological profiling with enhanced accuracy and efficiency [110]. However, several challenges await resolution in order to fully leverage cellular images as a reliable and insightful resource, as will be discussed in this section.

Although representation learning (section Representation Learning for Morphological Profiling) has become a robust approach to learn cellular features with less manual input than the conventional feature-engineering approach, it is susceptible to confounding factors such as batch effects. Batch effects are variations in data caused by the differences in the technical execution of each experimental batch. Such confounding factors introduce irrelevant sources of variation into data and can potentially mislead biological conclusions [146]. Disentangling these confounding factors from phenotypes is a crucial step to recover a true biological signal. Significant progress has been made in this regard, with methods such as TVN [37], BEN [147], TEAMS [148], CDCL [80], and GRU-based regularization [38]. Furthermore, batch correction methods for transcriptomic profiles may be applicable. A recent study on subsets of JUMP-CP demonstrated that Harmony, a non-linear method developed for processing scRNA-seq data, consistently outperforms other transcriptomic profile batch correction strategies in balancing batch removal and biological variation conservation [149]. In addition to the aforementioned methods, adding a context token to include batch-specific information during image representation learning also demonstrated decent performance in out-of-distribution generalization and batch variation handling [150]. To evaluate and compare batch correction strategies, RxRx1, a Cell Painting image dataset of genetic perturbations with 51 experimental batches from four cell types, has been systematically designed [146]. With the development and sharing of the benchmarked dataset, future work will continue to enhance upon existing methods. Improved handling of the confounding factors will further facilitate data sharing and reproducibility between data generation sites, thereby bringing significant benefits to the broader scientific community.

The success of phenotypic drug discovery heavily relies on disease relevance of the biological model. Applying relevant cell types and perturbations in morphological profiling assay is essential, but not sufficient to guarantee translatability [1]. Recent efforts have been made to apply increasingly multiplex biological model systems for image-based profiling, such as cocultured 2D cell lines [151] and 3D organoids [152, 153]. However, on the computational side, most approaches have been built upon Cell Painting assay images from mono-cultured 2D cells. Therefore, many challenges remain in generalizing these approaches to a multiplex biological model. For example, how do current cell segmentation (section Deep Learning–Facilitated Cell Segmentation for Image Analysis) and representation learning methods (section Representation Learning for Morphological Profiling) perform on 3D images? How is the quantity and quality of 3D image dataset that can be utilized for effectively training for fine-tuning deep learning models? How generalizable are the representation learning frameworks (section Representation Learning for Morphological Profiling) to cellular images consisting of multiple cell types, each demonstrating different morphology? How to integrate morphological data and other modalities of data (section Integrating Morphological Data in Multimodal Learning for Drug Discovery) from a multiplexed cell system to obtain cell–cell interaction information? Overcoming these hurdles will bring morphological profiling to the next level of clinical translatability.

In terms of integrating morphological profile with omics data (section Integrating Morphological Data in Multimodal Learning for Drug Discovery), compared to bulk transcriptomic readouts, single-cell transcriptomics, spatial transcriptomics and translatomics offer a wealth of gene expression information at individual cellular and subcellular levels [154–157]. Advances such as sci-RNA-seq3 have enabled single-cell transcriptional profiling in high throughput [158]. Given this technical progress, future work may establish an orthogonal profiling platform to combine morphological and single-cell profiling, thereby linking molecular phenotype to cellular phenotype at single-cell resolution. In addition, integrating Perturb-seq with image-based profiling will become a promising future direction to characterize the impact of genetic perturbations with single-cell transcriptomics and morphological readouts [159]. High-quality datasets of such should be established to encourage the development and evaluation of data integration approaches.

Last but not least, despite the impressive inferential capabilities of deep learning approaches, drawbacks remain that the explainability of these ‘black box’ models is unsatisfying [160]. In drug discovery especially, model interpretability is important to ensure that the biological conclusions are valid. To mitigate this, several efforts have been initiated to improve model interpretation in morphological profiling. For example, Chow et al. trained VAEs to interpret latent space feature representations in Cell Painting assay [161]. In the broader field of computer vision, techniques such as class activation mapping [162, 163] have been proposed to provide visual explanations for deep neural networks. Future work should continue to develop or advance techniques as such to morphological profiling to enhance model interpretability [162].

## Section: Concluding remarks

Morphological profiling represents a powerful, high-throughput, data-intensive, and cost-efficient technique for phenotypic drug discovery. It offers an unbiased and high-dimensional image readout of cellular phenotype in response to various perturbations, thereby providing a comprehensive view on compound bioactivity. Emerging techniques from computational biology and deep learning communities have made significant progress in enhancing the analytical pipeline from representation to prediction. While challenges remain in this fast-evolving field, future work will continue to coordinate multidisciplinary efforts in leveraging visual phenotypes to empower drug discovery.

## Section: Acknowledgements

We thank Wenjun Xie and Yuzhao Zhang for helpful discussion and comments that improved the manuscript. Figures 1, 2, 4, 5, and 6 were created with BioRender.com.

## Section: Author Biographies

Qiaosi Tang is a scientist at Calico Life Sciences, an Alphabet-founded research lab for human aging research. Her research focuses on using morphological profiling and machine learning methods to reveal age-related disease phenotype and identify potential therapeutic targets.

## Section: Author Biographies

Ranjala Ratnayake is a Research Associate Professor and Assistant Director of Center for Natural Products, Drug Discovery and Development (CNPD3), in the Department of Medicinal Chemistry at the College of Pharmacy, University of Florida. Her research focuses on using multidimensional screening platforms to identify novel drug therapies from complex natural product libraries.

## Section: Author Biographies

Gustavo Seabra is a Research Associate Professor in the Department of Medicinal Chemistry and the Center for Natural Products, Drug Discovery and Development (CNPD3) at the College of Pharmacy, University of Florida. His research focuses on the development and application of diverse computational chemistry methods and machine learning methods for molecular modeling.

## Section: Author Biographies

Zhe Jiang is an Assistant Professor in Computer & Information Science & Engineering (CISE) at the University of Florida. His lab’s mission is to design and develop accurate, scalable, and robust AI and machine learning algorithms and tools inspired by interdisciplinary applications such as biomedicine.

## Section: Author Biographies

Ruogu Fang is an Associate Professor and Pruitt Family Endowed Faculty Fellow in the J. Crayton Pruitt Family Department of Biomedical Engineering at the University of Florida. Her group’s research revolves around the integration of artificial intelligence (AI) and deep learning with the intricacies of the human brain.

## Section: Author Biographies

Lina Cui is an Associate Professor in the Department of Medicinal Chemistry at the College of Pharmacy, University of Florida. Her group develops and applies molecular tools for molecular imaging in various collaborative projects to explore the progression of diabetes, neurodegeneration, and other age-related diseases.

## Section: Author Biographies

Yousong Ding is an Associate Professor in the Department of Medicinal Chemistry at the College of Pharmacy, University of Florida. His research interests include natural product biosynthesis, drug discovery and development, synthetic biology, protein engineering, and chemical biology.

## Section: Author Biographies

Tamer Kahveci is a Professor and Associate Chair of Academic Affairs in the Computer and Information Science and Engineering Department at the University of Florida, serving as the Associate Chair of Academic Affairs. His research focuses on bioinformatics and has worked on indexing sequence and protein structure databases, sequence alignment, and computational analysis of biological pathways.

## Section: Author Biographies

Jiang Bian is a Professor and Division Director of Biomedical Informatics at the University of Florida and Chief Data Scientist and Chief Research Information officer of UF Health. His research focuses on data-driven medicine and development of novel informatics methods, tools, and systems to support clinical and clinical research activities.

## Section: Author Biographies

Chenglong Li is the Nicholas Bodor Professor in Drug Discovery and Professor in the Department of Medicinal Chemistry at the College of Pharmacy, University of Florida. He is also the Director of the NIGMS-supported CBI (Chemistry-Biology Interface) Graduate Training Program at the University of Florida. His research focuses on molecular recognition, with a strong application to structure-based computer-aided drug design.

## Section: Author Biographies

Hendrik Luesch is a Professor in the Department of Medicinal Chemistry, the endowed Debbie and Sylvia DeSantis Chair in Natural Products Drug Discovery and Development, and the founding Director of Center for Natural Products, Drug Discovery and Development (CNPD3) at the College of Pharmacy, University of Florida. His multidisciplinary research program at the interface of chemistry and biology integrates genome mining, synthetic and chemical biology, isolation and spectroscopic structure determination, chemical synthesis, target identification, and mechanism of action studies, followed by the preclinical development of candidate molecules.

## Section: Author Biographies

Yanjun Li is an Assistant Professor (AI Initiative) in the Department of Medicinal Chemistry at the College of Pharmacy, University of Florida. His research interests span the fields of deep learning, AI-driven drug discovery, and computational biology, with a particular emphasis on deep generative modeling for de novo molecule design and geometric deep learning for molecular recognition.

## Section: Contributor Information

Qiaosi Tang, Calico Life Sciences, South San Francisco, CA 94080, United States.

Ranjala Ratnayake, Department of Medicinal Chemistry, Center for Natural Products, Drug Discovery and Development, University of Florida, Gainesville, FL 32610, United States.

Gustavo Seabra, Department of Medicinal Chemistry, Center for Natural Products, Drug Discovery and Development, University of Florida, Gainesville, FL 32610, United States.

Zhe Jiang, Department of Computer & Information Science & Engineering, University of Florida, Gainesville, FL 32611, United States.

Ruogu Fang, Department of Computer & Information Science & Engineering, University of Florida, Gainesville, FL 32611, United States; J. Crayton Pruitt Family Department of Biomedical Engineering, Herbert Wertheim College of Engineering, University of Florida, Gainesville, FL 32611, United States.

Lina Cui, Department of Medicinal Chemistry, Center for Natural Products, Drug Discovery and Development, University of Florida, Gainesville, FL 32610, United States.

Yousong Ding, Department of Medicinal Chemistry, Center for Natural Products, Drug Discovery and Development, University of Florida, Gainesville, FL 32610, United States.

Tamer Kahveci, Department of Computer & Information Science & Engineering, University of Florida, Gainesville, FL 32611, United States.

Jiang Bian, Department of Health Outcomes and Biomedical Informatics, College of Medicine, University of Florida, Gainesville, FL 32611, United States.

Chenglong Li, Department of Medicinal Chemistry, Center for Natural Products, Drug Discovery and Development, University of Florida, Gainesville, FL 32610, United States.

Hendrik Luesch, Department of Medicinal Chemistry, Center for Natural Products, Drug Discovery and Development, University of Florida, Gainesville, FL 32610, United States.

Yanjun Li, Department of Medicinal Chemistry, Center for Natural Products, Drug Discovery and Development, University of Florida, Gainesville, FL 32610, United States; Department of Computer & Information Science & Engineering, University of Florida, Gainesville, FL 32611, United States.

## Section: Funding

Y.L. is supported by the University of Florida (UF Startup Fund). H.L. is generally supported by the Debbie and Sylvia DeSantis Chair professorship, and for phenotypic screening, HCS and morphological profiling supported by NIH grants R01CA172310 and RM1GM145426 as well as UF Health Cancer Center grant UFS-202307. C.L. has been partially supported by the Bodor Professorship Fund, UF AI Catalyst Fund and NCI R01CA212403. J..B. is supported by the following NIH grants: R01AG076234, RF1AG077820, and UL1TR001427. Y.D. is partially supported by NIH R35GM128742. L.C. is supported by the University of Florida (UF Startup Fund).

## Section: Data availability

Details about the data discussed in this study have been incorporated in the article. No additional data were generated for this study.

## Section: Associated Data › Data Availability Statement

Details about the data discussed in this study have been incorporated in the article. No additional data were generated for this study.


---

# Ongoing Implementation and Prospective Validation of Artificial Intelligence/Machine Learning Tools at an African Drug Discovery Center

- **Authors:** Jason Hlozek, Kelly Chibale, John G Woodland
- **Issuer:** ACS medicinal chemistry letters
- **Type:** Scientific article
- **Published:** 2024-06-21
- **Language:** en
- **DOI:** 10.1021/acsmedchemlett.4c00243
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39015279/
- **Licence:** CC-BY

## Section: Abstract

AbstractArtificial intelligence (AI) and machine learning (ML) are anticipated to accelerate drug discovery programs. Following our development of an end-to-end virtual screening cascade at the University of Cape Town (UCT) Holistic Drug Discovery and Development (H3D) Center, we report the ongoing implementation of open-source AI/ML tools for use in resource-constrained settings.

## Section: Text

Developing novel medicines is a lengthy and challenging process. Candidate molecules need to advance through the various stages of the drug discovery pipeline, from hit discovery and medicinal chemistry optimization to clinical trials and ultimately (if successful) regulatory approval. During the early stages of this process, the physicochemical and biological properties of a chemical compound need to be optimized to discover a potential treatment that is both safe and efficacious. However, high attrition rates at all stages of the drug discovery value chain result in lengthy timelines and exorbitant costs–with current estimates of more than 10 years and over $1 billion, respectively.1 This significant investment–without the guarantee of success–is often prohibitive for drug discovery research for the treatment of infectious diseases that disproportionately affect populations in low- and middle-income countries (LMICs).

With the advent of the fourth industrial revolution and advances in artificial intelligence (AI) and machine learning (ML) technologies, much hope has been placed by the scientific community in data science tools to reduce attrition rates and accelerate drug discovery programs.2 These tools could offer especial value to resource-constrained settings such as those in LMICs. One such example is the University of Cape Town (UCT) Holistic Drug Discovery and Development (H3D) Center,3 which initiated the adoption of AI/ML tools in its research programs in 2021 through a collaboration with the Ersilia Open Source Initiative,4 a technology nonprofit that focuses on the dissemination of data science tools in low-resource settings.

This productive collaboration yielded the development of the ZairaChem pipeline, an automated AI/ML model training tool which produces state-of-the-art QSAR/QSPR models across a variety of chemical and biological assays. This pipeline implementation was intentionally selected as a sustainable way to facilitate the ongoing development of predictive AI/ML models for user-specific regions of chemical space while automating the often-laborious trial-and-error process of model optimization. This approach allows for new models to be trained when additional experimental assays are brought online or are identified as critical for driving a project. In addition, existing AI/ML models can easily be retrained to benefit from new experimental data whereas static AI/ML models would, on the other hand, quickly become outdated.

The development of ZairaChem and the resulting implementation at H3D, which included both retrospective and prospective validation as well as benchmarking against external data sets, was subsequently shared with the broader scientific community.5 In this Viewpoint, we report further prospective validation over the 2023 period and discuss the practical aspects of the ongoing implementation of these AI/ML models, which could serve as an example and inspiration for others at nascent drug discovery centers worldwide and particularly in LMICs.

## Section: Model Implementation and Prospective Validation at the H3D Center

The original set of AI/ML models was selected to predict the experimental outcome of key assays that are frequently used for decision making in screening cascades for drug discovery programs targeting Plasmodium falciparum and Mycobacterium tuberculosis, the causative agents of malaria and tuberculosis (TB), respectively. Typically, medicinal chemists design dozens of potential compounds but have limited resources for chemical synthesis; hence, the suite of models trained through ZairaChem was assembled into a virtual screening cascade to facilitate their use by medicinal chemists to prioritize those compounds for synthesis that are more likely to possess desirable druglike properties.

Our virtual screening cascade is intended to be used in conjunction with existing software to generate complementary data points to facilitate decision-making. Considering there is no substantial limit on the number of compounds that can be run through the cascade, chemists are encouraged to “think big” and examine much longer lists of compounds than they might otherwise propose, allowing them to cast the net more widely and so interrogate a broader chemical space. Furthermore, as many of these models have been trained on in-house data for malaria and TB programs, they are potentially more relevant to other researchers in LMICs than more general models available online, such as the MAIP webtool.6

Our models undergo biannual retraining to continuously incorporate the most recent in-house data to maximize model applicability for current research programs. Both sets of models in 2023, trained on H3D’s in-house data up to February and June of that year, respectively, showed good prospective performance for experimental data generated over the following months. In particular, the whole-cell pathogen activity and aqueous solubility models, with the largest volume of training data, showed consistently high performance metrics, with an area under the receiver operating characteristic (AUROC) curve of between 0.77 and 0.89 (Figure 1). The microsomal intrinsic clearance (CLint) models dropped in performance in the second half of 2023 due to a large batch of compounds from two chemical series that are poorly represented in the training set, indicating the need for model retraining to improve performance in that particular chemical space.

Prospective model performance for the virtual screening cascade AI/ML models at H3D in 2023 which showed excellent agreement of the model predictions with experimental data. ROC curves are plotted for the prospective data generated in the months following the training of models on in-house data up to February 2023 (orange) and June 2023 (blue), respectively.

## Section: Development of New Models

Since the adoption of these AI/ML models by drug discovery teams at the H3D Center, additional data sets and areas of need have been identified for model development (Figure 2). These include predictions for the inhibition of the P. vivax phosphatidylinositol 4-kinase beta (PvPI4Kβ) enzyme, the P. falciparum cyclic GMP-dependent protein kinase (PfPKG), and the inhibition of the formation of β-hematin (the synthetic equivalent of malaria pigment), which represent three important drug targets in antimalarial drug discovery research. These ZairaChem models show excellent predictive performance with AUROC scores above 0.89 (data not shown) likely owing, in part, to the focused nature of the prediction task without the presence of confounding factors in whole-cell assays such as permeability or the presence of transport proteins. In addition, a second model to predict activity against the human ether-á-go-go-related-gene (hERG) ion channel, an important indicator of cardiotoxicity, has been developed from the hERGCentral database7 to expand the chemical space of the training set.

Not only can new models be developed for the early hit-to-lead phase of existing projects to prioritize compounds for synthesis, but these tools can also be used to screen large compound libraries to discover new chemical matter as starting points for drug discovery projects. For this purpose, we have pursued the development of more general activity prediction models that can facilitate virtual screening for new chemical hits against P. falciparum and A. baumannii, the latter being a member of the ESKAPE pathogens with increasing reports of antimicrobial resistance (AMR) and a bacterium of particular importance at the H3D Center. These models have been trained on large open-access data sets (for example, a curated set of 35 000 compounds from ChEMBL and CO-ADD),8,9 exemplifying the versatility of the ZairaChem tool to produce models for a variety of prediction tasks.

Current models comprising the H3D virtual screening cascade (top) in which newly developed models are emphasized in blue. Illustration of the typical workflow (bottom) for the development of new models to be made available for screening by experimentalists.

## Section: Impediments to the Adoption of AI/ML Tools

As “wet-lab” experimentalists seldom have formal computer science training, the technical complexity and black-box nature of AI/ML is often intimidating and may impede the adoption of data science tools. Furthermore, the computational field is filled with technical concepts that are common knowledge for data scientists but may be unfamiliar to experimental scientists, which may further hinder implementation of these models. Third, many AI/ML pipelines are solely implemented for Linux-based environments through a command-line terminal. Indeed, although the use of the ZairaChem pipeline requires just the “fit” and “predict” commands in a Linux terminal, tools that lack a graphical user interface (GUI) are perceived as inaccessible to many experimentalists. Therefore, a successful strategy to promote the local adoption of AI/ML tools needed to address both a skills-development component, to familiarize experimentalists with key concepts, and a technical component, making ZairaChem as easily accessible as possible.

## Section: Workflow of AI/ML Implementation

A typical workflow for deploying AI/ML models in a drug discovery project at H3D comprises the following steps:

## Section: Key Learnings from Our Experience at the H3D Center

As a very first step to encourage our scientists to implement these predictive AI/ML tools in their projects, an internal webinar was held to introduce scientists to the models in order to demystify these new tools. Careful explanations were given to describe the potential benefits of the models and to elucidate how they were trained and how to interpret the results. Thereafter, “champion scientists” in each disease area under investigation at the H3D Center helped to promote the tools among project teams and also brought ideas and suggestions back to the development team. Continuous communication through project meetings and training sessions provided a forum in which pertinent AI/ML concepts could be introduced or refreshed. Recurring areas of confusion include:

The use of boxplots to visualize model test-set predictions is particularly helpful in aiding teams to decide on appropriate prediction score thresholds to differentiate classification scores between predicted actives and inactives.

Initially, the process of obtaining model predictions required manual intervention by a data scientist; however, progressing to a GUI-based manner of accessing ZairaChem models has also been an important contributor to lowering the barrier of AI/ML model adoption. Because medicinal chemists at H3D already use the proprietary software package StarDrop to organize project data and because this software package also offers a Python-based plug-in point for AI/ML models, it is currently leveraged for GUI-based, on-demand model predictions. Medicinal chemists and other experimentalists can load a list of compounds and click the checkboxes corresponding to any number of AI/ML models for which they wish to obtain predictions. A custom Python script runs the list of SMILES strings through the corresponding ZairaChem models and returns a list of predictions to be displayed within the standard StarDrop GUI. While far from a sophisticated and flexible model deployment framework, this implementation has been extremely useful in the interim by making the AI/ML models easily accessible within an already-familiar tool.

## Section: Sustainable Capacity Building

An overarching goal of the H3D-Ersilia collaboration is to build data science capacity at an African drug discovery center through the sustainable implementation of AI/ML tools and related skills development. After an initial on-site training period with Ersilia in AI/ML model development, the ongoing implementation of AI/ML models described in this article has been accomplished without the need for ongoing technical support. Rather than static AI/ML assets that will increasingly become out of date and require a trial-and-error approach to train anew, the highly automated ZairaChem tool facilitates continuous development of new models and easy retraining of existing models. Even where data science expertise is available in-house, the automated nature of the pipeline frees the data scientist to pursue other research tasks while still obtaining high-quality models. The pipeline does not require extensive technical expertise nor extensive infrastructure to leverage, which is a crucial factor for resource-constrained research institutions such as many of those in LMICs.

The ZairaChem code is fully open source (https://github.com/ersilia-os/zaira-chem), and the lightweight versions of the virtual screening cascade models are freely available online (https://bit.ly/h3d-app). Taken together, this collaboration represents a landmark success for the transfer of sustainable data science expertise to the nascent African drug discovery domain. H3D and Ersilia aim to continue to build capacity for AI/ML tools at additional centers of African drug discovery research and development by continuing to facilitate data science workshops for African-based researchers and students. In particular, the scientists of the drug discovery cohorts of the Grand Challenges Africa initiative were invited to attend week-long training events hosted by the H3D Foundation and Ersilia, and a session on data science tools is also organized when these scientists conduct on-site visits at the H3D Center. The resources from previous training initiatives are also freely accessible to the scientific community (https://ersilia.gitbook.io/event-fund).

## Section: Future Directions

Following the initial successful deployment of data science tools at H3D, we have begun a concerted effort to improve the usability of the models by increasing the interpretability of model predictions and optimizing models to increase the speed of predictions. We have also begun leveraging the virtual screening cascade models to guide generative AI/ML method algorithms which propose new chemical analogs by searching through chemical space while optimizing for higher model prediction scores.

Recently, the selection of Dr. Kelly Chibale as a Schmidt Futures AI2050 Senior Fellow has funded a project that couples AI/ML predictions to physiologically-based pharmacokinetic (PBPK) modeling with the goal to tailor drug dosages for African patient populations.11 In addition, the project envisages developing open-source AI/ML models and significant capacity building for data science tools in Africa. With this work, we are excitedly moving toward a cloud-based deployment of AI/ML models that will facilitate intuitive and scalable access to data science tools to democratize AI/ML technology for drug discovery in Africa.

## Section: Acknowledgments

The authors would like to thank Miquel Duran-Frigola and Gemma Turon of Ersilia for discussion around the topics presented here and their perceptive comments on this manuscript. K.C. is the Neville Isdell Chair in African-centric Drug Discovery and Development and thanks Neville Isdell for generously funding the Chair.

## Section: Text

The authors declare no competing financial interest.

## Section: Special Issue

Published as part of ACS Medicinal Chemistry Lettersvirtual special issue “Exploring the Use of AI/ML Technologies in Medicinal Chemistry and Drug Discovery”.


---

# Peptide-based drug discovery through artificial intelligence: towards an autonomous design of therapeutic peptides

- **Authors:** Montserrat Goles, Anamaría Daza, Gabriel Cabas-Mora, Lindybeth Sarmiento-Varón, Julieta Sepúlveda-Yañez, Hoda Anvari-Kazemabad, Mehdi D Davari, Roberto Uribe-Paredes, Álvaro Olivera-Nappa, Marcelo A Navarrete, David Medina-Ortiz
- **Issuer:** Briefings in bioinformatics
- **Type:** Scientific article
- **Published:** 2024-05-23
- **Language:** en
- **DOI:** 10.1093/bib/bbae275
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38856172/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractWith their diverse biological activities, peptides are promising candidates for therapeutic applications, showing antimicrobial, antitumour and hormonal signalling capabilities. Despite their advantages, therapeutic peptides face challenges such as short half-life, limited oral bioavailability and susceptibility to plasma degradation. The rise of computational tools and artificial intelligence (AI) in peptide research has spurred the development of advanced methodologies and databases that are pivotal in the exploration of these complex macromolecules. This perspective delves into integrating AI in peptide development, encompassing classifier methods, predictive systems and the avant-garde design facilitated by deep-generative models like generative adversarial networks and variational autoencoders. There are still challenges, such as the need for processing optimization and careful validation of predictive models. This work outlines traditional strategies for machine learning model construction and training techniques and proposes a comprehensive AI-assisted peptide design and validation pipeline. The evolving landscape of peptide design using AI is emphasized, showcasing the practicality of these methods in expediting the development and discovery of novel peptides within the context of peptide-based drug discovery.Keywords: protein engineering, therapeutic peptides, deep learning, large language models, deep generative models, peptide-base drug discovery, artificial intelligence

## Section: Introduction

Engineered peptides exhibit wide-ranging therapeutic effects, such as antimicrobial, antitumour, antithrombotic and immunomodulatory activity [1]. Peptide drugs offer potential advantages over traditional small-molecule drugs, including increased selectivity, affinity, efficacy, safety and reduced toxicity and immunogenicity [2]. However, the brief half-life, limited oral bioavailability and susceptibility to plasma degradation of peptide drugs remain a challenge for their widespread clinical application [3].

The growing availability of numerous peptide sequences and their functions have driven the development of computational tools to store and share peptide information[4]. General and activity-specific databases have been established and are publicly accessible [5, 6]. Besides, artificial intelligence (AI) methods and predictive systems through machine learning (ML) have substantially evolved in recent years, particularly in protein engineering applications [7].

The rapid evolution of AI has marked the beginning of a new era of sophisticated ML algorithms in biomedicine, significantly impacting drug discovery [8]. Integration of ML has taken on a multifaceted dimension, including classifier methods, predictive systems and generative approaches [9].

Classifier methods are crucial for identifying diverse peptide activities, from biological functions to categorical properties [5]. In contrast, predictive models prove their utility by estimating numerical properties, such as binding affinities in protein–peptide interactions, evaluating toxicity and predicting inhibitory activity [10].

Deep generative models (DGMs) have emerged as tools for the design of therapeutic peptides [11]. In particular, generative adversarial networks (GANs), variational autoencoder (VAE) and diffusion models facilitate the generation of novel peptide sequences aimed at specific objectives [9, 12]. However, automated or assisted peptide design still faces challenges, such as the optimization of peptide processing, the establishment of informative representation strategies and the meticulous development and validation of predictive models.

This work describes peptides and their different properties and usabilities for biotechnology and therapeutic applications. It also presents traditional strategies for training ML models. Subsequently, it discusses the potential applications of DGMs as a foundational tool for designing peptides with therapeutic potential. Besides, a comparative analysis of the most common DGMs strategies is addressed. This work also proposes a comprehensive AI-assisted peptide design and validation pipeline. Finally, different challenges are discussed concerning achieving an autonomous therapeutic peptide design supported by AI approaches.

## Section: Peptides and their biotechnology applications

Peptides exhibit unique biochemical and therapeutic attributes and can be synthesized or obtained from natural sources. This section aims to offer a perspective on peptides, exploring their multifaceted biological functions, moonlighting attributes and applications [13, 14].

Biological activities of peptides, moonlight activity and main applications. A. Functional biological activities were grouped into 10 categories, including therapeutic, neurological drug delivery vehicle, sensorial, immunological, molecular binding, propeptide, signal peptide, transit and other activities (colour boxes) with different categories and subcategories. A total of 96 activities considering properties, reported activity and experimental validations have been generated in our previous work [5]. B. Moonlight evaluation of the 10 main activities reported in [5]. Therapeutic peptides are highly related to propeptides, drug delivery vehicles and sensorial peptides. Neurological peptides are also highly related to drug delivery vehicles and molecular binding. In contrast, sensorial peptides have a low relation with immunological peptides. C. Summary of peptide applications, considering industrial, biotechnology and therapeutic applications.

## Section: Peptides and their biotechnology applications › Peptide overview, synthesis process, function biological activities and moonlighting effects

Peptides consist of short chains of amino acids, with a molecular weight ranging from 0.5 to 10 kDa [15], and a length ranging from a couple of amino acids up to 100 [16]. Their role in biological processes is diverse, including functions as structural components, enzymatic inhibitors, hormones, host defence molecules and neurotransmitters [11]. Moreover, peptides can also act as cell surface receptors [17] and play an essential role in drug delivery applications [17, 18].

These macromolecules can acquire secondary structures, commonly forming -helix and sheets structural patterns [19], but also more complex structures [20]. Lasso peptides, for example, have a unique 3D structure where the C-terminus threads through an N-terminal macrolactam ring in a right-handed conformation, which provides stability against chemical, thermal and proteolytic degradation [21].

Peptides can be isolated from natural sources [1], including venoms [22], food products [23] and marine organisms [24]. Alternatively, peptides can be produced using recombinant techniques and chemical synthesis [25, 26].

In the recombinant approach, organisms like E. coli, S. cerevisiae and P. pastoris are used to produce heterologous peptides using the host cell protein production machinery [14]. In contrast, chemical procedures allow synthesis automation for large-scale industrial production [27]. Common chemical techniques are solid-phase peptide synthesis [11] and liquid-phase peptide synthesis [28].

Peptides can exhibit different biological activities with multifaceted properties. Figure 1A summarizes the main biological activities reported. As therapeutic properties, peptides play a role as antimicrobial, antitoxin and anticancer [2]. In the cosmetic industry, peptides can be used for wound healing and anti-aging activities. Peptides can also facilitate the molecular binding of proteins, DNA and RALF molecules. Peptides with immunological, neurological, signalling, drug delivery, propeptide, taste and cell–cell communication properties have been reported [5, 29–31]. Finally, peptides can also exhibit toxic effects, with reports of cytotoxic, allergen, endotoxin and neurotoxin characteristics [32–34].

Evolution and adaptability have moulded peptides into exhibiting two or more concurrent biological activities [35]. This unique and promiscuous attribute is called moonlighting activity. Unlike conventional peptides or proteins with defined functions, moonlighting peptides can acquire different activities in various cellular contexts or environments [35, 36].

Figure 1B describes the moonlighting for the primary biological activities reported in the Peptipedia database [5]. Therapeutic peptides have been demonstrated to present toxic properties. Cell–cell communication peptides also play therapeutic and signalling roles. The moonlighting effect was also analyzed for specific therapeutic peptides, including antimicrobial, metabolic, and anti-cancer. (See section S1 of Supplementary Material for more details). Moreover, specific antimicrobial peptides (AMPs) with antifungal, antibacterial and antiviral biological activities exhibit moonlighting properties. The moonlighting effect is also a property for antibacterial peptides, existing peptides with anti-gram (+) and anti-gram (-) activity (See section S1 of Supplementary Material for more details).

Leveraging moonlighting peptides as therapeutics presents potential advantages over traditional small-molecule drugs. The ability to combine multiple therapeutic functions into a single drug could alleviate the treatment burden for patients. Furthermore, such peptides could simultaneously target various disease-related pathways [35]. However, their multifunctional nature may also give rise to specificity issues, and their design complexity is compounded by the necessity to understand these unique structure–function relationships.

Biological activities of peptides, moonlight activity and main applications. A. Functional biological activities were grouped into 10 categories, including therapeutic, neurological drug delivery vehicle, sensorial, immunological, molecular binding, propeptide, signal peptide, transit and other activities (colour boxes) with different categories and subcategories. A total of 96 activities considering properties, reported activity and experimental validations have been generated in our previous work [5]. B. Moonlight evaluation of the 10 main activities reported in [5]. Therapeutic peptides are highly related to propeptides, drug delivery vehicles and sensorial peptides. Neurological peptides are also highly related to drug delivery vehicles and molecular binding. In contrast, sensorial peptides have a low relation with immunological peptides. C. Summary of peptide applications, considering industrial, biotechnology and therapeutic applications.

## Section: Peptides and their biotechnology applications › Biotechnology and therapeutic applications of peptides

Peptides exhibit many natural functions and offer significant potential for diverse applications. Peptide synthesis with non-canonical or artificial residues further expands their utility (e.g. by modifying residues in cationic AMPs to enhance proteolysis resistance) [37]. Figure 1C provides an overview of the primary applications of peptides in industry, biotechnology and therapeutics.

In the industrial sector, peptides have been applied as biosensors and used explicitly for pollutant and pathogen detection [38]. Peptides have also been employed in the food industry as food preservatives, hydrogelators, foam stabilizers and emulsifying agents [39]. For biotechnology applications, peptides have been used for plant protection and as immune inducers, playing pivotal roles as insecticidal and herbicides [40–42].

In therapeutic applications, peptides have generated antimicrobial drugs, including antifungal, antiviral and antibacterial [43]. Examples of therapeutic peptides are (i) WK2, designed to combat multi-drug resistant Salmonella [44], (ii) Teicoplanin a semisynthetic peptide for treating severe infections [45] and (iii) insulin and semaglutide for diabetes treatment [46].

Another relevant type of peptide for therapeutic applications are the cell-penetrating peptides (CPPs). These peptides can penetrate cell membranes, reach intracellular targets and facilitate drug delivery [47]. For example, the cyclic and amphipathic peptide has been used for the intracellular delivery of small interfering RNA and the enhancement of curcumin uptake [48].

Other peptides have the potential to improve neurodegenerative disorders like Alzheimer’s and Parkinson’s disease [49]. The P110 peptide inhibits Dynamin-related protein 1 (Drp1), a crucial regulator of mitochondrial fission, offering stable preservation of dopaminergic neurons in Parkinson’s disease [50]. Under stress, activated Drp1 translocates to mitochondria, leading to excessive mitochondrial fission and dopaminergic neuronal death.

## Section: ML strategies to develop predictive models for peptides

In recent years, there has been a substantial increase in the number of peptides documented in the literature [5]. This sequence abundance has, in turn, stimulated interest in applying computational biology techniques to analyse peptide sequences, predict biological activities, calculate physicochemical properties and assist in peptide design [51, 52]. However, applying AI and ML methodologies presents various challenges, from data collection and processing to predictive model validation to selecting an appropriate training strategy. This section reviews the classical approaches of data-driven methods for building predictive models and discusses the ML-based models for peptide tasks.

The main learning type process, the different applications to solve biotechnology and a data-driven pipeline to build predictive models supported by ML strategies. A The four main learning strategies used in biotechnology: (i) Supervised learning is used to build predictive models. (ii) Pattern recognition or unsupervised learning is applied to identify behaviours in an unlabelled dataset. (iii) Reinforcement learning is applied to update predictive models supported by new experimental evidence or knowledge. (iv) Generative learning is applied to create or design new examples and is employed as a landscape navigation strategy. B A classic data-driven approach to generate and use predictive models employing protein sequences as input to train the predictive model. First, a dataset is built by collecting information from databases, repositories, public resources or experimental reports. Once the dataset is built, numerical representation strategies are applied to code the protein sequences, generating an interpretable dataset for ML algorithms. The coded dataset is the input used to train a predictive model by applying supervised learning algorithms. Then, the predictive model’s performance is evaluated, and the model is validated through new examples or simulated datasets. Finally, the validated model explores the latent space and rebuilds the mutational landscape.

## Section: ML strategies to develop predictive models for peptides › ML definitions and main characteristics

ML is a sub-field of AI focused on algorithms and statistical models based on the idea that computers can analyse and learn from data patterns and use that knowledge to make predictions, classify objects or solve various problems [53].

Four learning types are currently applied to solve computational biology problems: (i) supervised learning, (ii) non-supervised learning, (iii) reinforcement learning and (iv) generative learning [54] (See Fig. 2A and section S2 of Supplementary Materials for more details). In addition to the different learning types, two main focuses have been implemented for developing models using ML strategies, classic ML approaches and deep learning (DL) architectures [55].

DL approaches have been efficient for image recognition, natural language processing and speech recognition [56]. In biotechnology and bioinformatics, DL has allowed the development of predictive models to estimate protein–protein interactions, classification systems for unknown enzymes through recognition of enzyme commission numbers [57] and predictive systems for protein structures such as RoseTTAFold [58] or AlphaFold [59].

The applications of transfer learning approaches by applying foundational trained models to biology context have demonstrated usability to develop efficient predictive models [60]. Moreover, the combination of transfer learning with semi-supervised strategies has facilitated the implementation of predictive models to address the data scarcity in protein engineering and fitness landscapes [61].

The main learning type process, the different applications to solve biotechnology and a data-driven pipeline to build predictive models supported by ML strategies. A The four main learning strategies used in biotechnology: (i) Supervised learning is used to build predictive models. (ii) Pattern recognition or unsupervised learning is applied to identify behaviours in an unlabelled dataset. (iii) Reinforcement learning is applied to update predictive models supported by new experimental evidence or knowledge. (iv) Generative learning is applied to create or design new examples and is employed as a landscape navigation strategy. B A classic data-driven approach to generate and use predictive models employing protein sequences as input to train the predictive model. First, a dataset is built by collecting information from databases, repositories, public resources or experimental reports. Once the dataset is built, numerical representation strategies are applied to code the protein sequences, generating an interpretable dataset for ML algorithms. The coded dataset is the input used to train a predictive model by applying supervised learning algorithms. Then, the predictive model’s performance is evaluated, and the model is validated through new examples or simulated datasets. Finally, the validated model explores the latent space and rebuilds the mutational landscape.

## Section: ML strategies to develop predictive models for peptides › A classic data-driven pipeline to develop predictive models through ML techniques for protein engineering tasks

There are four main steps for developing predictive models for peptides using ML strategies and protein sequences or structures: collecting and processing datasets, numerical representation strategies, training and validating predictive models and evaluating performances using classic metrics. Figure 2B summarizes the standard strategies and schematizes a classic data-driven pipeline.

During the collecting process, different sources could be employed to obtain protein sequences or structures depending on the objective of the predictive model. Usually, generic databases like Peptipedia [5], SATPdb [62] or LAMP2 [63] are used for collecting AMPs. In contrast, specialized databases like quorum sensing signalling peptides [64], anti-angiogenic peptides predictors [65] and bacteriocin peptides [66] are employed for collecting specific information.

Before training predictive models, numerical representation strategies must be applied to process peptide sequences. Current approaches favour the use of learning representations, due to their ability to catch functional and structural information from the context sequence [67, 68]. However, baseline methods like One Hot encoder, feature engineering and physicochemical encoders could also be applied (See section S2 of Supplementary Material for more details).

Finally, for training models, a classic pipeline could be applied [69], including a standard division of the dataset in training and testing partitions, a fold cross-validation technique to prevent overfitting and the application of classic metrics to evaluate and compare the performance of the predictive models (See section S2 of Supplementary Materials for more details).

## Section: ML strategies to develop predictive models for peptides › Current methods, strategies and implemented models for peptide design

Predictive models have been developed to explore and analyse peptide sequences, with a shared focus on tasks such as AMP classification, including ensemble learning process [70] and DL architectures [71] to train the classification models. Besides, antiviral classification systems applying Random Forest, support vector machine and DL methods have been successfully implemented [72–75].

Classification models for therapeutic applications have been implemented, including anti-inflammatory detection peptides [76], anticancer peptides identification [77] and CPPs recognition [78].

Pharmacological properties for therapeutic peptides have also been the focus of developing predictive models. The prediction of half maximal inhibitory concentration (IC) [79], estimating free radical scavenging activity and chelating properties [80] and half-life in blood [81] have been addressed by applying ML approaches.

These models not only facilitate the exploration of unknown sequences but may also contribute to the design of peptides with desirable properties. Typically, they integrate DGM strategies to advance sequence generation learning supported by computational property classification methods. Nevertheless, despite this progress, a unified pipeline for training predictive models in functional classification tasks remains needed.

## Section: Towards an autonomous peptide-based drug discovery

In this section, we will discuss the integration of ML and AI techniques in developing peptide-based drug discovery systems. First, we will show ML methods to support drug discovery; then, different deep generative strategies will be explained and discussed, evaluating different advantages and disadvantages. Next, traditional protein engineering strategies generated to assist the peptide design will be analysed and compared with generative approaches. Finally, a proposal pipeline to discover therapeutic peptides will be explored.

Classic DL architectures through DGMs employed for peptide design. A An autoencoder is a DL architecture that facilitates encoding the input data into a lower dimensional representation, reconstructing the original input as closely as possible. The autoencoders have two main components: an encoder and a decoder. B VAEs are a specific type of autoencoder that introduces probabilistic elements into the model, enabling it to learn a probabilistic distribution of the data in the latent space. VAEs are particularly effective for generating new, similar data points and are often used in generative modelling tasks. C NLMs, also known as autoregressive models, are a class of AI models that use neural networks to understand and generate human language. These models are designed to capture the complex patterns and relationships within a given language, enabling them to perform tasks such as language understanding, sentiment analysis, machine translation and text generation. D GANs are a class of AI algorithms that generate new, realistic data samples that resemble a given dataset. The main components in a GAN are (i) generator, (ii) discriminator, (iii) adversarial training, (iv) loss function and (v) training process.

A generalizable in silico pipeline to design therapeutic peptides with desirable properties combining ML, DGMs and biological structural validations. A Pipeline to train functional biological classification models, including the classic steps to develop predictive models using ML approaches. B Pipeline to train a binding affinity predictive model using ML algorithms. In this case, it is necessary to represent the protein, the ligand and the complex structure. C. A pipeline to build a generative model for designing therapeutic peptides. The pipeline includes the DGM, the functional classification system, the protein-binding affinity predictive model and bioinformatics approaches to validate the designed peptide sequences.

## Section: Towards an autonomous peptide-based drug discovery › Drug discovery supported by ML methods

Drug discovery is the process by which new candidate drugs are developed [82]. Traditional drug discovery involves (i) target identification, (ii) target validation, (iii) lead compound identification and (iv) lead optimization [83]. This process can often take decades and has a cost that can exceed a billion US dollars per target [84], considering that most drugs do not reach the market [85].

In contrast, drug repurposing is the exploration of new therapeutic applications for existing drugs [86]. Drug repurposing has different advantages, including safety, efficacy and accelerating the clinical assessment [87].

The combination of ML approaches with biomedical datasets can facilitate the identification of novel therapeutic targets, studying molecular characteristics, protein interactions, biological activities and adverse effects [4].

Different predictive models have been implemented to assist drug discovery, including methods like BANDIT, a Bayesian ML approach [88], and DeepDTnet, a DL approach that combines phenotypic, genetic, chemical and cellular network profiles to guide the drug discovery [89].

Alternatively, drug–target interaction predictive models have been developed to evaluate drug candidates. These methods have been based on Random Forest algorithms combined with a graph-based features extraction process [90], deep belief network [91] and long short-term memory (LSTM) architectures combined with protein characteristics and drug molecular substructure fingerprints [92].

ML frameworks can also predict drugs’ adverse effects at diverse stages of the discovery process. Two relevant approaches have been implemented: a deep neural network to assess the probability of adverse drug reactions in novel pharmaceutical compounds [93], and a geometric self-expressive model to help identify side effects during drug clinical trials [94].

In contrast to the current ML methods implemented to assist drug discovery, generative learning strategies have been developed to design de novo molecules or drugs with desirable targets [95]. Methods based on combinations of graph-generative models with Monte Carlo tree search [96] and transformer-decoder architectures to produce de novo smiles [97] have demonstrated the usability of the ML approaches to the discovery of new drugs.

While generators generative learning implemented for drug discovery exemplify the potential of AI models for small molecule design [96, 97], their capability can further extend into the domain of peptide design [98].

## Section: Towards an autonomous peptide-based drug discovery › DGM for the generation of new peptide sequences

DGMs aim to capture the underlying data distribution of a given dataset to generate novel instances that accurately represent the properties of the original data [99, 100]. For peptide design, DGMs can not only generate de novo peptide sequences but also perform learning representation tasks and likelihood learning tasks, where the model can learn to assign a greater probability to protein sequences that acquire desired characteristics [12].

There are multiple steps in the pipeline for peptide design using DGMs. First, the model needs to be trained. To this aim, peptide databases, datasets and repositories are collected and processed. Next, the collected peptide sequences require a numerical representation to provide the models with an interpretable input. Peptide representation can rely on feature descriptors, amino acid coding or embedding representations [98]. Then, the model is trained on the represented data; modelling the distribution of the training set allows us to learn the underlying data distribution and generate novel sequences.

In this section, the most common generative strategies are described, then state-of-the-art-related protein design, generation or discovery is analysed. Besides, a comparative analysis of the different generative approaches is addressed, including the advantages and disadvantages of each one.

Classic DL architectures through DGMs employed for peptide design. A An autoencoder is a DL architecture that facilitates encoding the input data into a lower dimensional representation, reconstructing the original input as closely as possible. The autoencoders have two main components: an encoder and a decoder. B VAEs are a specific type of autoencoder that introduces probabilistic elements into the model, enabling it to learn a probabilistic distribution of the data in the latent space. VAEs are particularly effective for generating new, similar data points and are often used in generative modelling tasks. C NLMs, also known as autoregressive models, are a class of AI models that use neural networks to understand and generate human language. These models are designed to capture the complex patterns and relationships within a given language, enabling them to perform tasks such as language understanding, sentiment analysis, machine translation and text generation. D GANs are a class of AI algorithms that generate new, realistic data samples that resemble a given dataset. The main components in a GAN are (i) generator, (ii) discriminator, (iii) adversarial training, (iv) loss function and (v) training process.

## Section: Towards an autonomous peptide-based drug discovery › DGM for the generation of new peptide sequences › Variational autoencoders

A VAE is a generative model combining autoencoders and variational inference elements. VAEs are used to learn representations of unsupervised input data and generate new data samples that resemble the training data [12].

Overall, VAEs are powerful generative models capable of learning rich representations of complex data distributions and generating new samples with desirable properties. They have applications in various domains, including image generation, text generation and anomaly detection.

VAE introduces a probabilistic aspect, learning a distribution in the latent space (see Fig. 3A). The most relevant components of a VAE model are (i) an encoder network, (ii) a reparametrization trick, (iii) a latent space, (iv) a decoder network and (v) a loss function [99].

During training, the VAE optimizes the parameters of both the encoder and decoder networks to minimize the combined loss function. This process involves passing input data through the encoder network to obtain latent space representations, sampling from the latent space and then reconstructing the data using the decoder network. The model’s parameters are updated using gradient descent techniques.

Once trained, the VAE can generate new data samples by sampling from the learned latent space distribution and passing the samples through the decoder network. By varying the samples in the latent space, the model can generate diverse and realistic data samples that resemble the training data.

Classic DL architectures through DGMs employed for peptide design. A An autoencoder is a DL architecture that facilitates encoding the input data into a lower dimensional representation, reconstructing the original input as closely as possible. The autoencoders have two main components: an encoder and a decoder. B VAEs are a specific type of autoencoder that introduces probabilistic elements into the model, enabling it to learn a probabilistic distribution of the data in the latent space. VAEs are particularly effective for generating new, similar data points and are often used in generative modelling tasks. C NLMs, also known as autoregressive models, are a class of AI models that use neural networks to understand and generate human language. These models are designed to capture the complex patterns and relationships within a given language, enabling them to perform tasks such as language understanding, sentiment analysis, machine translation and text generation. D GANs are a class of AI algorithms that generate new, realistic data samples that resemble a given dataset. The main components in a GAN are (i) generator, (ii) discriminator, (iii) adversarial training, (iv) loss function and (v) training process.

## Section: Towards an autonomous peptide-based drug discovery › DGM for the generation of new peptide sequences › Generative adversarial networks

GANs are generative models based on energy-based models (EBMs). Two components are most relevant for a GAN: a generator network and a discriminator network [101] (see Fig. 3B).

The generator is a neural network that takes random noise (often drawn from a simple distribution such as Gaussian) as input and produces data samples as output. Initially, the generator produces random noise, but as training progresses, it learns to generate increasingly realistic samples that resemble the training data [98]. In contrast, the discriminator is another neural network that takes input data samples and predicts whether they are real or fake [98].

The training process of a GAN model is called adversarial training. During the training process, the generator and discriminator are trained simultaneously. The generator aims to produce indistinguishable samples from real data, while the discriminator aims to classify real and generated samples correctly [99]. During training, the generator and discriminator are updated iteratively. The generator creates fake samples and attempts to fool the discriminator, while the discriminator is updated to better distinguish between real and fake samples. This process continues until the generator produces samples that the discriminator is not able to differentiate from real data [101, 102].

## Section: Towards an autonomous peptide-based drug discovery › DGM for the generation of new peptide sequences › Neural language models

Neural language models (NLMs) use neural networks to comprehend and generate human language. Designed to capture intricate patterns and relationships within a given language, these models are proficient in diverse tasks such as language understanding, sentiment analysis, machine translation and text generation (refer to Fig. 3C) [99]. Key components of NLMs are (i) Neural Network Architecture, (ii) Word Embeddings, (iii) Pre-training and Transfer Learning, (iv) Contextual Understanding, (v) Transformer Models and (vi) Generative Language Models.

NLMs predominantly adopt two main frameworks: recurrent neural networks (RNNs) and attention models. In RNNs, LSTM and gated recurrent units are used to construct autoregressive models. These models effectively capture sequential data by retaining historical information in their hidden states [98].

## Section: Towards an autonomous peptide-based drug discovery › DGM for the generation of new peptide sequences › Flows-based and EBMs

Flow-based models are generative models that learn the mapping between data samples and their corresponding probability densities. These methods utilize invertible neural networks to establish a bidirectional mapping between inputs and a latent representation. Unlike some generative models that rely on approximate sampling, flow-based models often use exact inference and analytical computations [99] (see Fig. 3D).

Different components are necessary to develop a flow-based model, including (i) the base distribution, (ii) the transformation network, (iii) invertible transformation functions and (iv) an output distribution.

EBMs are a diverse category of ML models characterized by their unique approach to modelling data. EBMs are designed to learn an energy function rather than directly learning a probability density function on the input space [103]. According to this energy function, observed or plausible data states are given low values (referred to as ‘energies’), whereas unobserved or improbable states are given high values [99]. EBMs differ from conventional generative methods because they do not require normalizing probability distributions.

EBMs are more flexible for handling probability distributions, due to integrating the energy function into the learning model [103].

## Section: Towards an autonomous peptide-based drug discovery › DGM for the generation of new peptide sequences › Diffusion models

Diffusion models are generative models that iteratively apply reversible transformations to a noise process. These models efficiently generate high-quality, diverse samples in various domains, such as images, text and audio [104]. Figure 3E presents a schematic representation of the diffusion model approaches.

The type of model starts with a noise process as the initial input. Then, reversible transformations to the noise process are applied iteratively. Each transformation is designed to gradually change the noise process into a data sample while preserving reversibility [105].

Diffusion models typically incorporate an annealing schedule to control the diffusion rate and ensure stable training. The annealing schedule gradually adjusts the magnitude of the reversible transformations over time, allowing for smoother transitions and better convergence [106].

Diffusion models are trained using maximum likelihood estimation. The training objective is to minimize the negative log-likelihood of the data samples under the diffusion model. This objective encourages the model to learn reversible transformations that can accurately transform the noise process into realistic data samples [105].

Once trained, diffusion models can generate new data samples by running the diffusion process forward from random noise. By varying the random noise inputs, diffusion models can generate diverse, high-quality samples that resemble the training data distribution [104].

## Section: Towards an autonomous peptide-based drug discovery › DGM for the generation of new peptide sequences › Generative approaches applied for peptide design and discovery

Different VAE strategies have been implemented to assist the peptide design or discovery. Methods like PepVAE [107], PepCVAE [108] and GM-Pep [109] have been proposed for AMP design supported by VAE approaches. Two relevant methods for AMP design are proposed in [110] and [111].

[110] used a deep autoencoder to design AMPs, achieving success in 48 days with a 10% hit rate. HydrAMP, a conditional variational autoencoder (cVAE), uncovers a continuous representation of peptides, leveraging controlled creativity [111]. Using HydrAMP, AMPs, including a superior analogue (Hydraganan-1) of Pexiganan, were generated and experimentally tested against E. coli strains [111].

Other examples of peptide design using VAE strategies are target-specific peptide inhibitors [112], peptide inhibitors targeting -catenin [113], peptides with desired bioactivity and membrane permeability properties [114] and peptide–MHC binding [115].

GANs are among the most widely used generative models for the design of peptides [103]. GANDALF (Generative Adversarial Network Drug-tArget Ligand Fructifier) is a deep convolutional GAN-based method that incorporates information about the active atoms of the protein–ligand interaction domain [116]. GANDALF generates novel peptides and predicts their binding affinity to a specific target. Rather than using protein–protein interaction databases, this model is trained on drug–ligand interactions of protein and FDA-approved peptide drugs based on the THP database [117]. It also uses data from PDB for 3D structures, Uniprot for the names of interacting proteins or peptides and CASTp to calculate protein pockets [118, 119]. This model has generated peptides to target cancer-related proteins, including PD-1, PDL-1 and CTLA-4 [116, 120].

Another GAN-based method for designing peptides, specifically bioactive antiviral peptides, is PandoraGAN [121]. It uses LeakGan, a modified GAN used in text generation, to generate peptides that undergo initial validation based on their amino acid composition, net charge, instability index, repeats and patterns.

Methods like AMPGAN v2 [122], AI4AVP [75] and HelixGAN [123] have also been implemented using GAN strategies to assist therapeutic peptide design.

Applying NLM strategies [124] have implemented AMPTrans-LSTM, a deep generative network-based approach designed to rationalize AMPs. Comprising two interconnected submodels: a long- and short-term memory sampler and a transformer-converter, the model demonstrates a success rate ranging between 30% and 50%. It generates new peptide sequences while preserving essential AMP features.

Flows-based models have been implemented focusing more on drug discovery. An example of these models is TagMol [125]. TagMol is a probabilistic end-to-end EBM for target-specific drug design. This approach uses the EBM to evaluate the binding affinity scores between protein–ligand pairs precisely. TagMol demonstrated that it could generate molecules with binding affinity scores similar to real molecules.

Different approaches have been implemented to assist peptide design, focused on diffusion model strategies [98]. Examples of the implemented strategies are AMP-diffusion. This method integrates latent diffusion with protein language models to generate AMPs [126]. Another relevant method for peptide therapeutic peptide design is the combination of structure prediction networks with diffusion generative approaches [127]. Alternatively, methods like Geometric Latent Diffusion [128] and multi-modal contrastive diffusion models [129] have been designed to support the therapeutic peptide design.

## Section: Towards an autonomous peptide-based drug discovery › A simple comparative analysis of the different generative strategies employed for peptide design

The different strategies implemented to design therapeutic peptides have proven successful in their application. However, there are differences in their operation that require attention to identify their advantages and disadvantages.

When formulating strategies based on VAEs, leveraging a latent space informed by distributions facilitates the generation of peptide sequences exhibiting an amino acid distribution similar to those in the training data. A more extensive repertoire of sequences enhances the likelihood of producing successful peptides as it expands the scope of potential explorations. However, a higher volume of feasible peptides does not inherently guarantee acquiring the desired biological activity. Given peptides’ propensity for moonlighting properties, there exists the possibility of uncovering novel biological activities that may not necessarily be advantageous. Consequently, when employing VAE-based design methodologies, incorporating a validator for the peptide sequences generated by the models becomes imperative.

Alternatively, design methodologies based on GANs require training a discriminator component to distinguish between real and fake sequences. While GAN-based approaches often offer advantages over VAE methods, like a validation process for generated sequences, their implementation requires careful consideration of various factors. First, achieving a balanced dataset is crucial; any class imbalance could impede the model’s ability to generalize effectively. Secondly, ensuring accurate differentiation between positive and negative elements, particularly in peptide sequences, demands adopting appropriate representation strategies. Therefore, integrating generative methods with Transformers to leverage pre-trained representation learning models proves beneficial for incorporating decoding techniques and facilitating the discrimination of genuine from spurious sequences. Introducing additional components complicates generative strategies’ training, validation and use.

Methods based on NLMs typically incorporate DL architectures such as RNNs or LSTMs. Training these models relies on natural language processing techniques. Achieving robust generalization with these models is challenging, often necessitating a substantial volume of training examples. Their appeal lies in their ability to analyse context and semantics for model development. Nevertheless, akin to VAE-based approaches, evaluating their efficacy requires integrating a classification model, thus complicating the training process. However, recent studies have reported precision rates exceeding 80% in developing AMPs, underscoring the efficacy and utility of these methods.

Recently, advances in peptide design methodologies have showcased remarkable efficacy, particularly in therapeutic peptide development. Among these methods, diffusion-based strategies have emerged as standout performers compared with approaches like VAE or GAN. Leveraging diffusion models enables efficient and high-fidelity reconstruction of new examples. Additionally, unlike flow-based or NLMs, there appears to be no significant correlation between the complexity of the training architectures and model performance. Notably, recent efforts have integrated generative learning with contrastive learning strategies to enhance performance in trained models.

Finally, while various strategies exist to aid peptide design and significant advances have been made in generative AI, several challenges warrant careful consideration before peptides proceed to experimental testing. These challenges encompass the analysis of toxicological and immunogenic properties, which are critical for ensuring safety and non-desirable effects. Additionally, peptides like bacteriocins often feature post-translational modifications (PTMs), a factor not accounted for in standard peptide generation processes. Assessment of pharmacological and pharmacodynamic attributes, such as half-life and quality measured via IC50, is imperative. Moreover, evaluating potential undesirable activities stemming from peptides’ moonlighting effects is crucial. Lastly, given that most therapeutic peptides act as receptor targets, computational affinity assessment against these receptors could enable the development of efficient filters for experimental peptide testing.

## Section: Towards an autonomous peptide-based drug discovery › Therapeutic peptide discovery through ML and DGMs

Various computational strategies have been used to facilitate the discovery of peptides with therapeutic potential.

These approaches focused on exploring classification systems and reconstructing mutational landscapes to inform rational protein design [130]. Additionally, the advances in structure predictions supported by AlphaFold have generated a new era for peptide-based drug discovery, facilitating the generation or discovery of new therapeutic peptides [131]. Alternatively, methods rooted in DGMs have demonstrated effectiveness in generating or identifying peptides exhibiting antimicrobial and signal peptide activities [110].

However, navigation through a latent space, investigation of diverse conformations and assessment of different functional components tied to the capacity and characteristics of peptides designed using AI remains challenging.

In particular, unique validation techniques and property calculations associated with the activity and quality of the designed peptide are needed.

This section presents a potential pipeline for discovering peptides with therapeutic activity. This pipeline encompasses predictive modelling of peptide properties, tools for predicting interaction affinity and bioinformatics methods that offer in silico validation of generated sequences. Experimental validation can be undertaken based on the specific application.

The proposed pipeline is illustrated in Fig. 4, outlining three key components essential for advancing the discovery of peptides with desirable therapeutic attributes.

The initial component (refer to Fig. 4A) is dedicated to designing and implementing models to classify biological activity. These models specialize in binary or multiclass classification of the biological activities of unknown peptides or those generated by generative systems.

For instance, they categorize peptides as antiviral, antihypertensive, antibacterial or peptides with antiviral activity that recognize viruses within the Retroviridae family and the HIV species. Beyond models for classifying biological activity, evaluation models may be needed to assess functional mechanisms. For example, evaluating the potential to inhibit the integrase enzyme or assessing peptides’ ability to hinder fusion between the GP41 protein and the host in the case of anti-HIV peptides.

Another consideration is a peptide’s capacity for multiple activities, such as forming interactions with proteins, membrane permeability and moonlighting capabilities. Introducing new rules or conditions to the peptides explored via classification systems facilitates the integration of regulatory elements into the design process, constrains navigation within the latent space and fosters guided learning for design systems.

The construction of these models follows the strategies outlined earlier in this work, including using numerical representation methods to validate implemented classification models.

The second component focuses on designing and implementing an affinity prediction system between protein and peptide, which only applies to peptides targeting a protein (See Fig. 4B.

The binding affinity predictive component proposes strategies involving matrix or object representations to characterize the interaction complex and train predictive models through DL architectures, focusing on CNN or GCN methods. By applying such architectures, explainable AI methods can be integrated to support predictions from an interpretative and explanatory point of view.

The integration of XAi approaches will allow an understanding of the relevant zones or patterns that dictate the model’s response, facilitating the design guidance of peptides exhibiting high affinity for the identified protein zones and key residues that encourage a favourable interaction with the target protein.

Finally, the third component is dedicated to the generative method for exploring novel sequences (See Fig. 4C). Techniques such as VAEs or GANs have been previously utilized to navigate the latent space of peptides awaiting exploration.

Initially, only peptides with a specific biological activity of interest are considered input. Nevertheless, there is also potential to incorporate unknown peptides displaying a specific biological activity, such as adding peptides to the dataset with antiviral properties, even in cases where there is no experimentally validated information, especially concerning anti-HIV activity.

Functional classification models are crucial for assimilating these new sequences in such scenarios. The development of this analytical approach encourages dataset expansion, thereby broadening the latent space to uncover novel peptides.

Once the generative models are trained and validated, the next step is to explore and navigate the latent space. To achieve this, optimization methods that rely on heuristic algorithms can be integrated to explore new sequences.

These identified sequences must be validated using biological activity classification methods and, if necessary, methods predicting affinity to target proteins of interest. In this context, validation serves as a set of rules or checkpoints that must be met to propose a peptide as a potential candidate for experimental validation. Additional validations are also required, such as the analysis of physicochemical properties and stability and the estimation of toxicity.

Reinforcement learning-based methods can be incorporated into the generation and validation stages to update the model responses. Incorporating a layer of active learning enhances the model’s performance and improves its generalization. Including experimental validation data further enhances functional classification and prediction models for better guidance when exploring or navigating the latent space.

A generalizable in silico pipeline to design therapeutic peptides with desirable properties combining ML, DGMs and biological structural validations. A Pipeline to train functional biological classification models, including the classic steps to develop predictive models using ML approaches. B Pipeline to train a binding affinity predictive model using ML algorithms. In this case, it is necessary to represent the protein, the ligand and the complex structure. C. A pipeline to build a generative model for designing therapeutic peptides. The pipeline includes the DGM, the functional classification system, the protein-binding affinity predictive model and bioinformatics approaches to validate the designed peptide sequences.

## Section: Challenges and opportunities: perspectives on peptide design in therapeutic applications

The advantages of peptide-based therapeutics include their efficacy, safety, specificity, customizable nature and various synthesis options. Nevertheless, pursuing peptides for medical applications still faces essential challenges despite strides in in silico drug discovery and design.

One of the obstacles to IA-assisted peptide design is the lack of a centralized, comprehensive and curated source of peptide information. As described earlier, there are individual efforts such as LAMP [63] for specific biological activity or PepipediaDB [5] for general purpose. However, accelerated advances will require global collaborative efforts.

Individual and fragmented data availability results in inconsistencies and misclassifications; for example, very different biological activities have been reported for the same peptide. However, a significant challenge is the scarcity of systematized experimental data on the half-life, IC50 and other critical biochemical and biological variables.

A consortium effort to support and maintain a centralized data source and incentives to encourage the deposit of experimental data may overcome this challenge.

Despite the abundance of strategies, techniques and methodologies for developing functional activity classification models and predictive systems for peptides’ physicochemical and thermodynamic properties, many of these approaches are challenging to replicate or access. This poses a significant obstacle not only to share results and methodologies but also to compare strategies effectively.

During the training of biological activity classification systems and the development of predictive systems, a crucial aspect involves the techniques used for the representation and coding of the peptide sequence.

Traditional methods like One-Hot encoding or physicochemical property coding often encounter challenges due to variations in sequence lengths. zero-padding techniques are typically employed to ensure uniformity during model training, introducing noise that increases with significant sequence length differences.

Solutions focusing on feature engineering-based representation offer an alternative, yet challenges persist in identifying relevant variables and needs reduction techniques. Moreover, models developed using these strategies often need to improve, rendering them inefficient for therapeutic peptide design. Recently, representation learning methods leveraging pre-trained models have emerged as a promising solution, promoting superior performance in predictive models. However, their computational overhead can be substantial, particularly when handling large datasets.

The issue extends beyond methodological complexity to include the availability and accessibility of benchmark datasets. Thus, there is a pressing need to enhance replicability and ensure persistent access to benchmark datasets. The development of gold-standard datasets capable of validating various training strategies and facilitating performance comparisons is imperative.

On the other hand, peptide design requires a delicate balance between safety, delivery efficiency, stability and preservation of efficacy and specificity. Minor alterations in the peptide sequence can significantly impact binding affinity and susceptibility to degradation.

The moonlighting property of peptides adds another layer of complexity. That can, however, be exploited to achieve a combination of binding properties, transport capacity, mobility and interactions at various molecular levels. Current technical advances, such as implementing deep generative methods to generate new sequences and multi-task modelling, may overcome this challenge.

Alternatively, hierarchical predictive systems or rule-decision classification systems might be implemented for numerical models predicting the desired properties such as IC50, half-life, toxicity, etc.

Peptides, being proteins, are susceptible to PTMs. Unfortunately, these modifications are often overlooked during modelling, creating a gap and introducing uncertainty in peptide design. Notably, bacteriocin peptides, utilized as antimicrobials to combat antibiotic resistance, frequently exhibit such modifications, demonstrating the need to incorporate PTMs predictive models into the pipeline of therapeutic peptide design (See more details in section S3 of Supplementary Material).

Lastly, provided that a comprehensive curated source of peptide information to train potent models is generated, a continuous update and feedback with experimental data will be required. Reinforcement learning will enable the continuous update of the model, which in turn will increase performance and generalization capabilities.

Despite these challenges, automated peptide generation has the potential to produce sequences with desired characteristics, such as enzymatic degradation resistance and specificity. Integrating generative methods, predictive systems and bioinformatics tools provides invaluable support for exploring peptides, uncovering new sequences or peptides with therapeutic activities, and synergizing with traditional methods like directed evolution and rational design. Integrating these tools will accelerate the discovery of novel peptides to complement conventional therapeutic arsenals.

## Section: Author Biographies

Montserrat Goles is a Master's student in Departamento de Ingeniería Química, Biotecnología y Materiales, Universidad de Chile. Her research interests include bioinformatics, machine learning strategies, and computational biology.

## Section: Author Biographies

Anamaría Daza is an young researcher at Centre for Biotechnology and Bioengineering, CeBiB, Universidad de Chile. Her research interests include cell culture, cell and gene therapy, heterologous protein expression, characterisation and purification, and extremophile enzymes for industrial applications.

## Section: Author Biographies

Gabriel Cabas-Mora is an Assistant researcher at Departamento de Ingeniería en Computación, Universidad de Magallanes. His main research interest is machine learning applied to protein engineering and molecular biology.

## Section: Author Biographies

Lindybeth Sarmiento-Varón is a Post-doctoral researcher at Centro Asistencial de Docencia e Investigación (CADI), Universidad de Magallanes. Her research interests include the immune system's interactions post-infection and the development of biomarkers.

## Section: Author Biographies

Julieta Sepúlveda-Yañez is a researcher at Centro Asistencial de Docencia e Investigación, CADI, Universidad de Magallanes. She has experience in molecular biology and bioinformatics and specialises in studying mutagenic mechanisms in B cells.

## Section: Author Biographies

Hoda Anvari-Kazemabad holds a master's degree in Software System Engineering from RWTH Aachen University. Her research interests encompass explainable AI (XAI) in protein engineering and the autonomous design of therapeutic peptides.

## Section: Author Biographies

Mehdi D. Davari leads the Computational Chemistry Group at the Leibniz Institute of Plant Biochemistry in Halle, Germany. His research advances protein and enzyme design by unravelling the complex relationships between protein sequences, structures, and dynamics. It functions through computational techniques, including multiscale simulations and artificial intelligence.

## Section: Author Biographies

Roberto Uribe-Paredes is an Associated Professor at Departamento de Ingeniería en Computación, Universidad de Magallanes. His research interests include Information Retrieval, High-Performance Computing, bioinformatics, and genomic analysis.

## Section: Author Biographies

Álvaro Olivera-Nappa is an Full researcher at Centre for Biotechnology and Bioengineering, CeBiB, Universidad de Chile. His research interests include protein engineering and computational biology.

## Section: Author Biographies

Marcelo A. Navarrete is a researcher and group leader at Centro Asistencial de Docencia e Investigación, CADI, Universidad de Magallanes. His research interests include computational immunology and oncogenomics in lymphoid malignancies.

## Section: Author Biographies

David Medina-Ortiz is an Assistant Professor at Departamento de Ingeniería en Computación, Universidad de Magallanes. His research interests include machine learning algorithms, deep learning architectures, and de novo protein design.

## Section: Contributor Information

Montserrat Goles, Departamento de Ingeniería en Computación, Universidad de Magallanes, Av. Pdte. Manuel Bulnes 01855, 6210427, Punta Arenas, Chile; Departamento de Ingeniería Química, Biotecnología y Materiales, Universidad de Chile, Beauchef 851, 8370456, Santiago, Chile.

Anamaría Daza, Centre for Biotechnology and Bioengineering, CeBiB, Universidad de Chile, Beauchef 851, 8370456, Santiago, Chile.

Gabriel Cabas-Mora, Departamento de Ingeniería en Computación, Universidad de Magallanes, Av. Pdte. Manuel Bulnes 01855, 6210427, Punta Arenas, Chile.

Lindybeth Sarmiento-Varón, Centro Asistencial de Docencia e Investigación, CADI, Universidad de Magallanes, Av. Los Flamencos 01364, 6210005, Punta Arenas, Chile.

Julieta Sepúlveda-Yañez, Facultad de Ciencias de la Salud, Universidad de Magallanes, Av. Pdte. Manuel Bulnes 01855, 6210427, Punta Arenas, Chile.

Hoda Anvari-Kazemabad, Departamento de Ingeniería en Computación, Universidad de Magallanes, Av. Pdte. Manuel Bulnes 01855, 6210427, Punta Arenas, Chile.

Mehdi D Davari, Department of Bioorganic Chemistry, Leibniz Institute of Plant Biochemistry, Weinberg 3, 06120, Halle, Germany.

Roberto Uribe-Paredes, Departamento de Ingeniería en Computación, Universidad de Magallanes, Av. Pdte. Manuel Bulnes 01855, 6210427, Punta Arenas, Chile.

Álvaro Olivera-Nappa, Centre for Biotechnology and Bioengineering, CeBiB, Universidad de Chile, Beauchef 851, 8370456, Santiago, Chile.

Marcelo A Navarrete, Centro Asistencial de Docencia e Investigación, CADI, Universidad de Magallanes, Av. Los Flamencos 01364, 6210005, Punta Arenas, Chile; Escuela de Medicina, Universidad de Magallanes, Av. Pdte. Manuel Bulnes 01855, 6210427, Punta Arenas, Chile.

David Medina-Ortiz, Departamento de Ingeniería en Computación, Universidad de Magallanes, Av. Pdte. Manuel Bulnes 01855, 6210427, Punta Arenas, Chile; Centre for Biotechnology and Bioengineering, CeBiB, Universidad de Chile, Beauchef 851, 8370456, Santiago, Chile.

## Section: Funding

D.M.-O. acknowledges ANID for the project ‘SUBVENCIÓN A INSTALACIÓN EN LA ACADEMIA CONVOCATORIA AÑO 2022’, Folio 85220004. D.M.-O., A.D. and A.O.-N. gratefully acknowledge support from the Centre for Biotechnology and Bioengineering—CeBiB (PIA project FB0001, Conicyt, Chile). A.D. gratefully acknowledges support for the Fondecyt project 11230208. M.A.N. acknowledges ANID for grants Anillo ATE220016, M.A.N and R.U.-P acknowledge support for the Fondecyt 1230298. M.D.D. acknowledges funding by the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation)—within the Priority Program Molecular Machine Learning SPP2363 (Project Number 497207454).

## Section: Author contributions statement

M.G., M.A.N., A.O.-N. and D.M.-O.: conceptualization. D.M.-O., M.A.N. and A.O.-N.: validation. M.G., M.A.N., A.D., H.A.-K., M.D.D., G.C.-M., L.S.-V. and J.S.-Y.: investigation. M.G., A.D., M.D.D., H.A.-K., M.A.N. and D.M.-O.: writing, review and editing. A.O.-N., M.A.N., R.U.P. and D.M.-O.: supervision and funding resources. A.O.-N., M.A.N. and D.M.-O.: project administration.

## Section: Data availability

No new datasets were generated in this work.

## Section: Associated Data › Data Availability Statement

No new datasets were generated in this work.


---

# PharmaBench: Enhancing ADMET benchmarks with large language models

- **Authors:** Zhangming Niu, Xianglu Xiao, Wenfan Wu, Qiwei Cai, Yinghui Jiang, Wangzhen Jin, Minhao Wang, Guojian Yang, Lingkang Kong, Xurui Jin, Guang Yang, Hongming Chen
- **Issuer:** Scientific data
- **Type:** Scientific article
- **Published:** 2024-09-10
- **Language:** en
- **DOI:** 10.1038/s41597-024-03793-0
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39256394/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractAccurately predicting ADMET (Absorption, Distribution, Metabolism, Excretion, and Toxicity) properties early in drug development is essential for selecting compounds with optimal pharmacokinetics and minimal toxicity. Existing ADMET-related benchmark sets are limited in utility due to their small dataset sizes and the lack of representation of compounds used in drug discovery projects. These shortcomings hinder their application in model building for drug discovery. To address this issue, we propose a multi-agent data mining system based on Large Language Models that effectively identifies experimental conditions within 14,401 bioassays. This approach facilitates merging entries from different sources, culminating in the creation of PharmaBench. Additionally, we have developed a data processing workflow to integrate data from various sources, resulting in 156,618 raw entries. Through this workflow, we constructed PharmaBench, a comprehensive benchmark set for ADMET properties, which comprises eleven ADMET datasets and 52,482 entries. This benchmark set is designed to serve as an open-source dataset for the development of AI models relevant to drug discovery projects.Subject terms: Computational chemistry, Cheminformatics

## Section: Background & Summary

Optimization of ADMET (Absorption, Distribution, Metabolism, Excretion, and Toxicity) properties plays a pivotal role in drug discovery. These pharmacokinetic properties directly influence a drug’s efficacy, safety, and ultimately clinical success. Early assessment and optimization of ADMET properties are essential for mitigating the risk of late-stage failures and for the successful development of new therapeutic agents1.

The development of computational approaches provides a fast and cost-effective means for drug discovery, allowing researchers to focus on candidates with better ADMET potential and reduce labor-intensive and time-consuming wet-lab experiments2–4. One of the key factors contributing to the success of computational approaches in drug discovery is the decent volume of compound-related biomedical data5. The number of bioassays is increasing each year, and many of their screening results are publicly accessible in databases such as ChEMBL6, PubChem7, and BindingDB8 etc.

Manual curation of ADMET data based on public data sources has been reported and some of them have been widely used as benchmark datasets for model evaluation. Wu et al.9, who constructed a large-scale benchmark for molecular machine learning named MoleculeNet, included 17 datasets and more than 700,000 compounds covering categories of physical chemistry and physiology related to ADMET experiments. Huang et al.10 published the Therapeutics Data Commons, which includes 28 ADMET-related datasets with over 100,000 entries by integrating multiple curated datasets from previous work. For specific ADMET experiment, Meng et al.11 present B3DB, which includes 1,058 compounds containing log BB values and 7,807 compounds with classification labels for the blood-brain barrier as one of the distribution properties. Meng et al.12 collected seven aqueous solubility datasets and presented a dataset curation workflow to establish solubility datasets as one of the physicochemical properties.

However, serious concerns about these benchmark datasets still exist. Firstly, most of these benchmarks include only a small fraction of the publicly available bioassay data. For instance, the ESOL dataset13 within MoleculeNet provides water solubility data for 1,128 compounds, while the PubChem7 database contains more than 14,000 relevant entries. Secondly, the entries in these benchmarks differ substantially from those in the industrial drug discovery pipeline. For example, the mean molecular weight of compounds in the ESOL dataset is only 203.9 Dalton, whereas compounds typically within the drug discovery projects have molecular weights ranging from 300 to 800 Dalton14.

These limitations of compiled open-source benchmark datasets are primarily due to the high complexity of data annotation for biological and chemical experimental records. Frequently, experimental results for identical compounds can vary significantly under different conditions, even within the same type of experiment15. For example, aqueous solubility can be influenced by various factors, such as different types of buffers, pH level, and experimental procedure. Thus, the same compound might be annotated with different solubility values depending on those experimental conditions16. This sort of variability poses a big challenge in the fusion of experimental results.

Recently developed Large Language Models (LLMs) like ChatGPT17, PubMedBERT18, and BioBERT19 represent a novel approach of effectively extracting data from a large body of text, therefore a potential method for addressing data curation challenges. Some of these LLMs demonstrate state-of-the-art performance through one-shot or few-shot learning as a form of multi-task learning17,20,21. Compared to supervised methods or models requiring thousands of data for fine-tuning, this approach allows us to develop condition extraction models more efficiently with only a few examples.

In the current study, we leveraged these LLMs as a core engine to extract experimental conditions from assay descriptions within biomedical databases, and an automated data processing framework was established for processing them for facilitating compilation of ADMET benchmark datasets as shown in Fig. 1. We implemented the pipeline to process bioassay data from the ChEMBL database and extract the experimental conditions missing from the table descriptions. These data, along with some other public datasets, were standardized and filtered to create PharmaBench22.

Eventually, PharmaBench22, a data package including eleven ADMET properties, was curated and provided to cheminformatics community serving as a benchmark set for ADMET predictive model evaluation. These properties are recognized as key factors in real-world drug development efforts, and both the size and diversity of the data are significantly greater than those of previous datasets. We also included multiple validation steps to confirm the data quality, molecular properties, and modeling capabilities of PharmaBench22.

Data processing workflow for building PharmaBench: From left to right, the multi-agent LLM system extracts experimental conditions from the ChEMBL database, combines other data sources and standardizes the data, filters various data types, and validates them through repeated tests, property distribution, and AI modeling.

## Section: Methods

The Methods section provides a detailed overview of the data processing workflow used in constructing PharmaBench22, as depicted in Fig. 1. The Data Collection subsection outlines the data sources employed to build PharmaBench22. It includes a comprehensive description of the multi-agent LLM system for extracting experimental conditions from assay descriptions, detailed in the Data Mining subsection. Following the identification of experimental conditions in the Data Mining stage, we merge experimental results from various sources and standardize and filter the data based on drug-likeness, experimental values, and conditions, as summarized in the Data Standardization and Filtering section. Finally, we post-process the datasets by removing duplicate test results and dividing the dataset based on Random and Scaffold splitting methods for AI modeling purposes.

We establish a final benchmark set that comprises experimental results in consistent units and under standardized experimental conditions. In addition, the data processing workflow described in the Methods section can eliminate inconsistent or even contradictory experimental results for the same compounds, enabling other researchers to effectively construct datasets from public data sources. For code reproduction, all data processing tasks were conducted within a Python 3.12.2 virtual environment, established using Conda on an OSX-64 platform. This environment included pandas 2.2.1, NumPy 1.26.4, Matplotlib 3.8.3, rdkit 2023.9.5, scikit-learn 1.4.1.post1, scipy 1.12.0, seaborn 0.13.2, and openai 1.12.0. A detailed description of the environment requirements can be found on GitHub at https://github.com/mindrank-ai/PharmaBench.

Summary of data sources for PharmaBench, from left to right: the broad ADMET category, property name, number of ChEMBL entries and bioassays, number of other entries, and a summary of the sources with references.

Table of Experimental Conditions and Filters Across Datasets.

Sample Prompt for LLM Interaction: Illustration of a Typical User Query Input, Including Instructions and Example Parts.

Overview of the Multi-Agent LLM Data Mining Workflow. This figure presents a summary of the multi-agent LLM data mining workflow, which includes three key components: the Keyword Agent, responsible for identifying experimental conditions; the Example Agent, tasked with generating examples; and the Data Mining Agent, designed to extract experimental conditions from assay descriptions.

Sample Prompt for the Keyword Extraction Agent.

Sample Prompt for the Example Forming Agent.

Summary of Datasets in PharmaBench: ‘Property Name’ refers to the name of the dataset.

## Section: Methods › Data collection

Our data primarily originated from the ChEMBL database, a manually curated collection of SAR (Structure-Activity Relationship) and related physicochemical property data, largely sourced from peer-reviewed journal articles. The data type within the ChEMBL database typically includes experimental value, chemical structure, assay description, type of experiment, and certain experimental conditions. Table 1 summarizes the original entries we collected, along with the number of bioassays of the ChEMBL database used for PharmaBench22. We analysis through 97,609 raw entries based on 14,401 different bioassays in PharmaBench22.

These entries from different bioassays in the ChEMBL database were analyzed through our Data Mining workflow to extract the experimental conditions. This is mainly because most of the experimental conditions recorded in ChEMBL are not explicitly specified. For instance, for solubility experiments, entries in the ChEMBL database do not include explicit data columns such as buffer type, pH condition, and experimental procedure, which are critical factors influencing experimental results. Although these conditions can be found in the assay descriptions, they cannot be directly used as a filter to distinguish experiments due to their unstructured nature. Manual mining work would be labor-intensive, which necessitates an automatic data processing framework to identify important experimental conditions from the description texts.

Thus, our multi-agent LLM system uses the entries from the ChEMBL database as the original sources and identifies various conditions for different ADMET experiments as summarised in Table 2. Additionally, we have augmented our datasets with some public datasets that have associated assay descriptions as illustrated in Fig. 1. Table 1 presents a summary of the 59,009 entries we have compiled from various public datasets, along with a delineation of their respective sources.

Overall, we have used more than 150,000 entries from public data sources to construct PharmaBench22, and the data mining process has analyzed 14,401 different bioassays.

Summary of data sources for PharmaBench, from left to right: the broad ADMET category, property name, number of ChEMBL entries and bioassays, number of other entries, and a summary of the sources with references.

Table of Experimental Conditions and Filters Across Datasets.

## Section: Methods › Data mining

GPT-417, a model created by OpenAI, was utilized as the core LLM for the data-mining task. Based on previous research, to obtain optimized results from GPT-4, a prompt with clear instructions and examples is required for every specific task17,23–25. As shown in Fig. 2, the prompt for our data-mining process includes both instructions and examples. The instructions summarize the experimental conditions as the data mining goal and specify the requirements for the output formats. The examples, on the other hand, provide few-shot learning examples for the LLM. This prompt engineering is an important process for improving the results of GPT-417.

However, constructing prompts for various tasks requires domain knowledge of the ADMET experiments, and creating examples for these data mining tasks remains labor-intensive. We wish to explore whether the LLMs can automatically identify key experimental conditions from different types of experiments, generate examples, and complete the complex data mining process with minimal human effort.

As a result, a multi-agent LLM data mining system was proposed in this study to extract experimental conditions from the descriptions of various bioassays26–28. An agent is a module or entity that utilizes the LLM to perform specific tasks, such as understanding, generating, or processing natural language texts28. Instead of using a single LLM-powered agent, a multi-agent system was proposed to customize LLMs into various agents, each with different capability, to automatically complete the complex data mining process, as shown in Fig. 326.

The multi-agent system consists of three agents, namely keyword extraction agent (KEA), example forming agent (EFA), and data mining agent (DMA), as illustrated in Fig. 3. The KEA will pick out and summarize the key experimental conditions for ADMET experiments. The EFA will then generate examples based on these experimental results summarized by the KEA. We will manually validate the outcomes of the KEA and EFA to ensure their quality. Finally, the DMA will mine through all the assay descriptions and identify all the experimental conditions within these texts. The following sections will introduce these three agents in more detail.

Sample Prompt for LLM Interaction: Illustration of a Typical User Query Input, Including Instructions and Example Parts.

Overview of the Multi-Agent LLM Data Mining Workflow. This figure presents a summary of the multi-agent LLM data mining workflow, which includes three key components: the Keyword Agent, responsible for identifying experimental conditions; the Example Agent, tasked with generating examples; and the Data Mining Agent, designed to extract experimental conditions from assay descriptions.

Sample Prompt for the Keyword Extraction Agent.

Sample Prompt for the Example Forming Agent.

## Section: Methods › Data mining › Keyword extraction agent

The KEA is designed to summarize key experimental conditions from various ADMET experiments. A prompt, as illustrated in Fig. 4, along with texts from 50 randomly selected assay descriptions, was created as the model input for the KEA. This prompt instructs GPT-4 to summarize the experimental conditions from selected assay descriptions of bioassays in ChEMBL. The model’s task is to identify and summarize the top five most frequently mentioned experimental conditions. For more complex experiments, such as microsome clearance and CYP inhibition, the model was asked to summarize the top ten conditions. GPT-4 is required to generalize these conditions rather than just listing specific conditions and duplicating or listing similar conditions should be avoided. An example of a Python list is provided to KEA to illustrate the desired output format for GPT-4. This process will leverage GPT-4’s internal knowledge to generate a list of significant experimental conditions. An example of the input and output for the KEA is shown in Fig. 4.

The experimental conditions summarized by the KEA are listed in the ‘Experimental Condition’ column of Table 2. Domain experts were invited to confirm if these conditions are key conditions for ADMET experiments. These experimental conditions are then used as the primary data mining goal for the DMA to extract from each assay description.

Sample Prompt for the Keyword Extraction Agent.

## Section: Methods › Data mining › Example forming agent

The EFA focuses on generating examples from assay description texts. The prompt for this agent includes clear instructions incorporating the key experimental conditions summarized by the Keyword Agent, along with forty assay descriptions for analysis purposes. The Example Agent returns a Python dictionary containing the index, original sentences, and key experimental conditions as the keys. It will return ‘None’ if no information is provided within the sentences.

For each ADMET experiment, forty examples will be generated through these automatic pipelines. Manual examination is conducted on the examples to eliminate errors and confirm the format. This fast labeling process generates few-shot learning examples for DMA, which avoids intensive human labeling. The example input and output for this agent is shown in Fig. 5.

Sample Prompt for the Example Forming Agent.

## Section: Methods › Data mining › Data mining agent

The DMA aims to complete the mining task for all assay descriptions from the ChEMBL database. As shown in Fig. 2, the prompt for this agent includes instructions containing the experimental conditions summarized by the KEA and forty examples generated by the EFA. As shown in Fig. 5, the prompt defines the data mining task, identifying experimental conditions and outputting them in the desired format. These examples provide few-shot learning data for the DMA to learn how to standardize the output format and improve the overall output quality.

GPT-4 has a limit on the number of tokens to be processed in a single request17. Thus, we divided the assay descriptions with a batch size of twenty to mitigate the risk of overloading the model. This batching technique allows for a more accurate and reliable analysis, especially when dealing with complex assay descriptions.

The DMA will return a Python Dictionary for every batch input. A routine was written to convert the Python Dictionary from a Markdown file into a Pandas DataFrame, which is then stored. Eventually, the Data Mining Agent goes through all the assay descriptions in the raw data and stores the output of every batch. The experimental conditions mined based on this multi-agent system are then merged back into the original file for data standardization and filtering.

Overall, this multi-agent system mines through 14,401 assay descriptions to identify the experimental conditions for seven different ADMET experiments. It largely minimizes human effort to extract structured experimental conditions which will be then used in the following data standardization and filtering procedures.

## Section: Methods › Data standardization

The data obtained from different sources exhibit significant variability in the format of structure, data type, name of experimental condition, and the unit and range of experimental value. For standardizing the data, we design a data standardization workflow to clean the data obtained from the previously described data mining step and it includes standardization of structure format, experimental condition, and experimental value.

## Section: Methods › Data filtering

A data filtering process aims to filter out entries with abnormal molecules and irregular experimental results, to construct the final benchmark set that contains experimental results in consistent units and experimental conditions.

## Section: Methods › Data preparation for AI modeling

After the above data processing workflow, a series of ADMET datasets were constructed from various bioassays. The count of entities is summarized in Table 3. However, multiple experimental results for the same compounds occur under the same conditions within the datasets after the processing workflow.

Thus, we employed various strategies to unify these repeated results in the final datasets. For regression tasks, for compounds with repeated data, the mean value was taken as the unified value. There are two classification datasets in our benchmark set. For the BBB experiment, we eliminate all compounds with contradictory results, while for AMES, we label the compounds as positive if at least one positive result occurs in these experiments. This approach is primarily due to the fact that AMES is a toxicity-related experiment, which requires the model to be highly sensitive to positive results30.

Additionally, we divided the datasets for each property into training and test sets with a ratio of 0.8:0.2 respectively, utilizing both random and scaffold splitting methods. Random splitting involves distributing the compounds arbitrarily across the training and test sets, whereas scaffold splitting is designed to create sets with distinct structural features by allocating compounds that share the same core scaffold exclusively to either the training or the test set10. This approach ensures that the test set is structurally different from the training compounds, making it more challenging for models to predict.

Summary of Datasets in PharmaBench: ‘Property Name’ refers to the name of the dataset.

## Section: Data Records

We have compiled 11 ADMET datasets to form PharmaBench, which is freely available at figshare22. Table 3 includes the number of entries after the data processing workflow for each dataset and the final entries for AI modeling. The final entries consist of one experimental result for each molecule, based on the experimental condition as described in the ‘Filter’ column of Table 2. The mission type of the different datasets is also summarized in the ‘Mission Type’ column of Table 3, including regression and classification.

Overall, PharmaBench22 comprises a total of 52,482 entries. It is stored in comma separated values (CSV) format and includes a unified SMILES representation, experimental results, property names, and training labels based on both scaffold and random splitting, as summarized in Table 4. The data are also openly accessible on GitHub at https://github.com/mindrank-ai/PharmaBench, along with the processing workflow.

The following section will introduce different datasets in more detail, including a general introduction to various ADMET properties, the units for different datasets, and the number of molecules.

List of information in the final datasets.

## Section: Technical Validation

Once the data collection is done, we evaluate the datasets from three aspects. Firstly, we use the repeated test results for the datasets before and after the implementation of the data processing workflow to demonstrate the improvement in data quality resulting from this workflow. Secondly, we illustrate the characteristics of PharmaBench22 by showing distributions of various molecular properties. Lastly, we trained various machine learning and deep learning models on the datasets and presented model performance on the test sets.

Comparison of Data Quality Before and After the Data Processing Workflow Through Repeated Test Plots and Confusion Matrices (a) Repeated Test Plot for the LogD Experiment Before Data Processing. (b) Repeated Test Plot for the LogD Experiment After Data Processing. (c) Repeated Test Plot for the BBB Experiment Before Data Processing. (d) Repeated Test Plot for the BBB Experiment After Data Processing. Additional data can be found in Table 5.

Comparison of Metrics Between the Regression Datasets Before and After the Data Processing Workflow.

Comparison of Metrics Between the Classification Datasets Before and After the Data Processing Workflow.

Frequency Histograms for All PharmaBench Datasets: Count Distribution of Atom Numbers, Molecular Weights, LogP, and QED Scores Across Different Datasets.

Summary of AI Models Utilized in the Validation Process.

Summary of final results for the PharmaBench based on random split.

Summary of final results for the PharmaBench based on scaffold split.

## Section: Technical Validation › Repeated test for data quality assessment

A comparison for repeated test results is a methodological approach where the same experiment is conducted multiple times to verify the consistency of the results37. Limited by the scope of this work, we cannot verify each data point through wet lab experiments or review each literature to confirm the direct data quality of the dataset. Thus, we implement an indirect approach, namely repeated testing, to confirm the data quality before and after data processing. A raw dataset often contains multiple records for the same compound due to different sources and varying experimental conditions. Repeated testing compares the maximum and minimum values for the same compound under the same condition to validate the data quality.

As shown in Fig. 6, the repeated test plot is used to analyze regression results, and the confusion matrix is used to analyze the classification results. If the experimental results are consistent for different data sources, the repeated test plot will exhibit higher correlation and a lower mean absolute error (MAE) for regression tests, and the confusion matrix will show higher accuracy (ACC), precision, and recall for classification tests. In contrast, low-quality data will have opposite metric scores.

We use this method to compare data quality before and after considering the experimental conditions mined through our data mining process, thereby demonstrating improvement in data quality based on our approach. The data quality before and after the data processing workflow can be compared and evaluated through the metrics mentioned above.

Specifically, we group data entries for the same molecules from the raw data to create the ‘before data processing’ plot, and we group data entries for the same molecules under identical conditions for the ‘after data processing’ plot. The maximum and minimum experimental results for each group are selected as the worst-case scenario. We have created a scatter plot for the regression tests and a confusion matrix for the classification tests, as shown in Fig. 6. The R, MAE, and RMSE for regression tasks, and ACC, F1, precision, and recall for classification tasks, have been calculated and are recorded within Tables 5 and 6.

Table 5 demonstrates the results of repeated tests for regression tasks within PharmaBench22, while Table 6 summarizes the classification tasks. All metrics improved following the data processing workflow, validating the quality increment. The results of repeated tests for certain experiments, such as the LogD experiment, have significantly improved data quality after the data processing workflow, reaching a level comparable to that of traditional wet lab experiments. However, the results of repeated tests for CYP and clearance experiments remain relatively low, due to the complex nature of these in vitro experiments.

Comparison of Data Quality Before and After the Data Processing Workflow Through Repeated Test Plots and Confusion Matrices (a) Repeated Test Plot for the LogD Experiment Before Data Processing. (b) Repeated Test Plot for the LogD Experiment After Data Processing. (c) Repeated Test Plot for the BBB Experiment Before Data Processing. (d) Repeated Test Plot for the BBB Experiment After Data Processing. Additional data can be found in Table 5.

Comparison of Metrics Between the Regression Datasets Before and After the Data Processing Workflow.

Comparison of Metrics Between the Classification Datasets Before and After the Data Processing Workflow.

## Section: Technical Validation › Analysis of property distribution

Basic physicochemical properties of the compounds, including atom counts, molecular weight, LogP, and QED, were calculated using RDKit. Histograms representing the frequency of these properties were calculated and are presented in Fig. 7 to illustrate the characteristics of the molecules within PharmaBench22,38.

This histogram demonstrates that compounds in PharmaBench22 exhibit a broad distribution. The number of non-hydrogen atoms per molecule typically ranges from 10 to 50, and molecular weights range from 200 to 600 Daltons, which are consistent with the range of drug-like small molecules39. Additionally, the LogP values of these datasets are in the range from 0 to 8, indicating a tendency towards lipophilicity, which is also well aligned with that of drug-like compounds39. QED is a metric that evaluates the potential of a compound to be developed as a successful drug, based on a multi-factorial analysis of molecular properties of marked drugs39. The QED distribution for PharmaBench22 is skewed towards 1, suggesting that many compounds in the datasets possess favorable physio-chemical properties.

Overall, the molecules within PharmaBench22 demonstrate preferable characteristics, which are similar to those in the small molecule drug discovery projects.

Frequency Histograms for All PharmaBench Datasets: Count Distribution of Atom Numbers, Molecular Weights, LogP, and QED Scores Across Different Datasets.

## Section: Technical Validation › Deep learning and machine learning modeling

Summary of AI Models Utilized in the Validation Process.

Summary of final results for the PharmaBench based on random split.

Summary of final results for the PharmaBench based on scaffold split.

## Section: Technical Validation › Deep learning and machine learning modeling › Modeling protocol

Similar to the repeated test mentioned above, we used MAE, RMSE, and Pearson correlation coefficient R to evaluate the regression results. For classification results, we utilized AUC (area under the receiver operating characteristic curve), ACC, and the F1 score (F1) for evaluation.

We selected two machine-learning approaches and seven deep-learning models for this evaluation process. The machine learning models include XGBoost40 and Random Forest (RF)41, utilizing the Extended Connectivity Fingerprints (ECFP) as descriptors for the molecules42. We selected seven deep learning models, some of them need a pre-training process, and their input is either 2D graph or 3D conformation. Detailed descriptions of these models can be found in Table 7.

All models were built using default parameters, without additional fine-tuning. Although hyper-parameter optimizing strategy might improve the results, our intention is not to select the best model but rather to use these models to verify the quality of the PharmBench.

Summary of AI Models Utilized in the Validation Process.

## Section: Technical Validation › Deep learning and machine learning modeling › Modeling results

We present the metrics for the regression models and for the classification models, trained using both random as shown in Table 8 and scaffold splitting as shown in Table 9 datasets.

For the datasets associated with regression tasks, the prediction results achieve desirable metrics for LogD, water solubility, BBB, and microsomal clearance, exhibiting relatively high R values and low MAE and RMSE. However, the prediction results for the CYP remain relatively low, which indicates that further improvements in data quality and modeling approaches are required for these datasets. The metrics for the classification tasks are all relatively high, which indicates that the models can effectively predict the classification results for the BBB and AMES datasets.

In regards to the splitting method, the prediction results of random splitting are better than scaffold splitting for the majority of tasks. This is understandable since the prediction performance for the majority of models is usually worse for compounds with new scaffolds. In addition, deep learning approaches significantly outperform the machine learning approaches in regression tasks. The performance gap between the deep learning and machine learning models widens for datasets with a large amount of data, such as LogD and water solubility, but narrows for smaller datasets, such as mouse microsomal clearance. This indicates that conventional machine learning approach can adapt to small datasets and has less capability to model large amounts of data compared with deep learning model. In contrast, the performance of the machine learning approach for classification tasks witnesses a significant increase. The metrics for XGBoost models for AMEs and BBB datasets surpass some deep learning approaches, indicating that machine learning approaches are more suitable for classification tasks.

Among deep learning approaches, the model with pretraining demonstrates the best performance in both regression and classification tasks for the majority of datasets. This indicates that the pretraining process can be useful for improving model performance for ADMET properties predictions. Moreover, there is no significant performance difference between graph-based and transformer-based approaches, or between 2D and 3D feature-based methods.

More research and modeling work are encouraged to utilize this benchmark set in the future. For instance, investigating approaches to improve model capabilities in predicting molecules with novel scaffolds would be valuable. The use of transfer learning and pre-training approaches is also recommended for the analysis with these datasets. Additionally, applying explainable AI techniques could provide valuable insights into the key pharmacological factors influencing ADMET properties.

Summary of final results for the PharmaBench based on random split.

Summary of final results for the PharmaBench based on scaffold split.

## Section: Usage Notes

There are eleven ADMET datasets within PharmaBench22. Standardized SMILES representations of compounds were provided for modeling the compounds, and the experimental values are provided as the prediction targets. Users may use the labels within the scaffold_train_test_label and random_train_test_label as the train-test labels for fair comparison.

## Section: Acknowledgements

This study was funded by MindRank AI Ltd. H. C. acknowledged funding from the Guangzhou Basic and Applied Basic Research Project (202201011795) and the Pearl River Recruitment Program of Talents (No. 2021CX020227). G. Y. was supported in part by the ERC IMI (101005122), H2020 (952172), MRC (MC/PC/21013), the Royal Society (IEC\ NSFC\211235), the NVIDIA Academic Hardware Grant Program, the SABER project supported by Boehringer Ingelheim Ltd, Wellcome Leap’s Dynamic Resilience, and the UKRI Future Leaders Fellowship (MR/V023799/1).å

## Section: Author contributions

Z.N., X.X. and W.W. conceived the presented idea. X.X., W.W., Y.J. and Q.C. developed the theory and the data mining system. Q.C., W.J., G.J.Y., L.K. and J.X. collected the data. Z.N., X.X., W.W., Q.C., Y.J. and W.J. developed the data processing workflow. X.X., W.W., Q.C., Y.J., W.J., M.W. and G.J.Y. developed the technical validation for the data qualities. H. C. and G. Y. supervised the findings of this work. All authors discussed the results and contributed to the final manuscript.

## Section: Code availability

The codes used in this study have been deposited at https://github.com/mindrank-ai/PharmaBench. All the calculations were done with Python 3.12.2 under a virtual environment created with Anaconda on osx-64.

## Section: Competing interests

Z.N., X.X., W.W., Q.C., Y.J., W.J., M.W., G.J.Y., L.K. and X.J. are the employees of MindRank AI ltd.

## Section: Contributor Information

Guang Yang, Email: g.yang@imperial.ac.uk.

Hongming Chen, Email: chen_hongming@gzlab.ac.cn.

## Section: Associated Data › Data Availability Statement

The codes used in this study have been deposited at https://github.com/mindrank-ai/PharmaBench. All the calculations were done with Python 3.12.2 under a virtual environment created with Anaconda on osx-64.


---

# Practical guide to SHAP analysis: Explaining supervised machine learning model predictions in drug development

- **Authors:** Ana Victoria Ponce-Bobadilla, Vanessa Schmitt, Corinna S Maier, Sven Mensing, Sven Stodtmann
- **Issuer:** Clinical and translational science
- **Type:** Scientific article
- **Published:** 2024-11-01
- **Language:** en
- **DOI:** 10.1111/cts.70056
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39463176/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractDespite increasing interest in using Artificial Intelligence (AI) and Machine Learning (ML) models for drug development, effectively interpreting their predictions remains a challenge, which limits their impact on clinical decisions. We address this issue by providing a practical guide to SHapley Additive exPlanations (SHAP), a popular feature‐based interpretability method, which can be seamlessly integrated into supervised ML models to gain a deeper understanding of their predictions, thereby enhancing their transparency and trustworthiness. This tutorial focuses on the application of SHAP analysis to standard ML black‐box models for regression and classification problems. We provide an overview of various visualization plots and their interpretation, available software for implementing SHAP, and highlight best practices, as well as special considerations, when dealing with binary endpoints and time‐series models. To enhance the reader's understanding for the method, we also apply it to inherently explainable regression models. Finally, we discuss the limitations and ongoing advancements aimed at tackling the current drawbacks of the method.

## Section: INTRODUCTION

The use of Artificial Intelligence (AI) and Machine Learning (ML) models in drug discovery and development offers great potential. 1 , 2 , 3 , 4 Several ML models have been developed for predicting the absorption, distribution, metabolism, and excretion (ADME) properties of small molecules, 5 , 6 pharmacokinetic‐pharmacodynamic modeling, 7 , 8 understanding exposure‐response relationships, 9 patient subpopulation detection, 10 , 11 , 12 , 13 , 14 patient stratification, 15 , 16 and biomarker detection. 17 To inform clinical decisions in drug development and build trust for these tools, it is crucial to understand how the predictors influence the model predictions and which ones are the most impactful.

The research area of explainable AI or interpretable ML aims to trace the decision‐making process of a ML model and understand the key features driving its predictions. 18 Model interpretability can be achieved either by considering models that are inherently interpretable (e.g., linear, logistic regression, decision trees) or considering post hoc “explainability” methods that can be applied to black‐box models (e.g., neural networks, random forests, XGBoost, gradient boosting machines). It is interesting to note that post hoc methods can be applied to both interpretable and black‐box models, making them model‐agnostic. In a recent perspective, Imrie et al. 19 classified the different model‐agnostic methods according to the type of explanation they provide: (1) feature‐based (How relevant are the data features to model predictions?), (2) model‐based (Can the model predictions be explained using auxiliary meta‐models?), (3) example‐based (What other samples' model predictions are similar to a particular subset of samples?), (4) concept‐based (Does the model appear to adhere to concepts derived from domain knowledge?), and (5) counterfactual explanations (What does the model predict when considering synthetic samples under particular scenarios?). This tutorial provides a practical guide to one of the most popular feature‐based ML interpretability methods: SHapley Additive exPlanations (SHAP) analysis.

SHAP analysis is a feature‐based interpretability method that has gained popularity thanks to its versatility which provides local and global explanations. It also provides values that are easy to interpret and can be easily implemented thanks to its easy‐to‐use packages that implement this method. Several publications in this field have used this methodology, and some of them have started to highlight some important considerations on its use. 9 , 10 , 20 , 21 , 22 , 23

In this tutorial, we first briefly review the game‐theoretical background of Shapley values, and their connection to SHAP analysis, and give remarks on the calculation of SHAP values. Then we describe the datasets used for this tutorial along with the supervised learning problems that we considered to exhibit the SHAP methodology. Next, we discuss the implementation and practical considerations of SHAP value analysis: visualization plots, special considerations when applying SHAP to classification endpoints, special considerations when dealing with time‐series models, and available software to perform the analysis. Subsequently, we walk through a SHAP analysis in common statistical frameworks (linear regression and logistic regression) and present how to apply this analysis to the most common ML frameworks (random forest, XGBoost, neural networks) for both a regression and classification problem in Python. Furthermore, the application of SHAP analysis to time‐dependent models is demonstrated. Finally, we summarize the limitations and mention other extensions that should be considered for this popular technique.

## Section: THEORETICAL BACKGROUND OF SHAP ANALYSIS

Marginal contributions for drug combination example illustrating calculation of Shapley values.

Linking the terminology from game theory and ML for Shapley values.

## Section: THEORETICAL BACKGROUND OF SHAP ANALYSIS › Mathematical background

SHAP analysis is rooted in Shapley values, a concept from collaborative game theory. Shapley values provide a fair distribution of a payout among players in a collaborative game where players work together for a common goal, even if the players may have contributed unequally. We will use the example of combination drug therapy and calculate the contribution of each drug on the response to illustrate the concepts. Let's assume Drug A, Drug B, and Drug C, when administered together, have a response rate of 90%. The individual drugs' response rates are:

Let's assume we also know the response rates of the two‐drug combinations, or in the language of game theory, coalitions of two (subsets of the group of size 2):

Given the single drug and dual combination response rates, what would be the fair individual drug contribution to the triple combination response rate of 90%?

In 1953, Lloyd Shapley 24 defined a set of properties that a fair measurement of contribution in a collaborative game should fulfill:

Lloyd Shapley derived a mathematical formula of the values ϕj that satisfies these properties and proved that these values are the only ones capable of satisfying all these properties. These values are the so‐called Shapley values. Considering a payout, V, each player j is assigned a Shapley value, ϕj, that corresponds to their fair share of the payout based on their individual contribution. The mathematical formula for ϕj is the following:

where S is a coalition, N is the set of all players, VS⋃j−VS quantifies the marginal contribution of player j to coalition S, S!N−S−1!∣N∣! is the weight of the marginal contribution and ∑S⊆N\j sums over all possible coalitions without j. The weights are the inverse of the number of coalitions of size |S| excluding player j.

Shapley values can be interpreted as the weighted average of a player's marginal contributions across all possible coalitions.

Let's calculate the Shapley values for the combination therapy example. First, for each drug we consider all the possible coalitions that can be created without that specific drug. For example, for Drug A, these coalitions are: one coalition of size 0: ⊘, two coalitions of size 1: B,C and one coalition of size two: B,C. We calculate the marginal contribution when adding Drug A to each of these coalitions and use Formula 1 to calculate its SHAP value. We then do the same for Drug B and Drug C. In Table 1 we include these calculations along with each drug's marginal contribution and their corresponding Shapley values. The sum of all Shapley values equals the total response: 20.83% + 33.33% + 35.83% = 90%.

Marginal contributions for drug combination example illustrating calculation of Shapley values.

## Section: THEORETICAL BACKGROUND OF SHAP ANALYSIS › Connection between Shapley values and SHAP analysis

The use of Shapley values for ML interpretability was first introduced by Štrumbelj and Kononenko in 2010. 25 The authors showed how Shapley values can be used to fairly quantify the contribution of features in a ML model. The method was then popularized and extended by Lundberg et al. 26 to the so‐called SHAP analysis. In their paper, the authors were able to show how Shapley values unified other feature‐based interpretability methods and provided an open‐source package that sparked a widespread adoption of the method.

The connection between Shapley values and SHAP analysis can be understood by considering the potential model features (covariates) as “players” in a collaborative game: working together to determine each individual predicted value. Table 2 illustrates the terminology from game theory and ML that establishes this connection. For each term in game theory, we also include (in parenthesis) the equivalent term for our combination therapy example. By establishing this link, SHAP values inherit all the properties of Shapley values, such as efficiency, symmetry, additivity, and null player. Consequently, SHAP values provide a fair and unbiased measure of each feature's contribution to the predicted value of each sample. To provide more clarity to the reader, Table S1 establishes a connection between the terminology used in ML and the corresponding terminology in statistics.

From the efficiency property, a property of SHAP values that is crucial for their interpretation can be derived: consider the prediction for a sample i, fi. The SHAP values for all features j of sample i, ϕi,j, satisfy the following formula:

This means that for a given sample i, the SHAP values assigned to each feature describe the extent to which that feature contributed to the difference between the individual prediction of this sample from the average model prediction. A derivation of this formula from the efficiency axiom is presented in Molnar et al. 27

Linking the terminology from game theory and ML for Shapley values.

## Section: THEORETICAL BACKGROUND OF SHAP ANALYSIS › Calculation of SHAP values

Typically, using Formula 1 to calculate SHAP values for feature contributions of a ML model prediction is too computationally expensive; therefore, different implementation and approximation methods have been considered to efficiently calculate SHAP values for common ML models. An exception to this rule are tree‐based models, for example, XGBoost, random forest, LightGBM, CatBoost, for which it is possible to efficiently calculate the exact SHAP values by exploiting the tree structure of models. 28

For neural network‐based models, approximation methods can leverage the computational graph or exploit the model differentiability to calculate the SHAP values. In the popular Python package SHAP, examples of such approaches are implemented in DeepExplainer and GradientExplainer. Finally, an approximation method that can be applied to any supervised model, (i.e., a model‐agnostic method) is the kernel SHAP method. Kernel SHAP approximates the Shapley values by using a weighted sampling approach. One needs to define a representative subset of the dataset often called background dataset (which should capture the range and distribution of the features in the dataset) from which subsets of features are sampled. A kernel function is applied to compute the contributions of these subsets to the prediction. These contributions are then weighted based on the number of times each feature appears in the subsets. By repeating this process multiple times, Kernel SHAP provides an estimate of the Shapley values.

## Section: TUTORIAL DATASETS

To introduce the SHAP methodology and allow the reader to reproduce our tutorial we utilized both public datasets and in‐silico datasets.

To illustrate the use of SHAP analysis in different black‐box regression models, we utilized the National Health and Nutrition Examination Survey (NHANES). 29 These surveys are designed to assess the health and nutritional status of US adults and children. The NHANES survey includes demographics, socioeconomic, dietary, laboratory, and health‐related questions. We create a dataset using a subset of this survey data. We consider the features of sex, body mass index (BMI), age, estimated number of days over the past year that the participant drank alcoholic beverages, and the number of days in a typical week that the participant does moderate or vigorous physical activity to predict blood pressure.

For showcasing the use of SHAP analysis in different black‐box classification models, we employed a breast cancer diagnostic dataset. This dataset consists of features computed from digitized images of a fine needle aspirate of breast masses. These features describe the characteristics of the cell nuclei present in the image. Based on the features of the different samples, we are interested in classifying the tumor mass as benign or malignant. A more detailed description of the dataset is available here. 30

To show the application of SHAP values to a time‐dependent ML model, we utilized in‐silico data from a pharmacokinetic (PK) model. This PK model consisted of a first‐order absorption and linear clearance. We assumed clearance exhibits interindividual variability. Further details on the PK model and model parameters can be found in Supporting Information. We considered the regression problem of predicting individual clearances using a Long Short‐Term Memory (LSTM) model from drug concentration‐time profiles. We simulated 1000 drug concentration‐time profiles during a 48‐h period, assuming a daily infusion of 200 mg lasting for 1 h. The drug concentration was sampled every 4 h, starting 1 h after the first dose was administered, resulting in 12 recorded concentrations for each simulated subject.

A description of where to find the datasets and how we pre‐process them before training the ML models is available in the Supporting Information. When training the models, we consider a 70:30 train:test split. The code used for performing all the SHAP analyses can be found in the Supporting Information.

## Section: IMPLEMENTATION AND PRACTICAL CONSIDERATIONS

Consider the standard supervised ML workflow depicted in Figure 1.

SHAP analysis is part of the model interpretation phase in a ML workflow and should be only performed if the model demonstrates adequate performance. Therefore, the reported SHAP values should usually be the SHAP values that correspond to the test dataset.

As pointed out by Lu et al., 23 a good practice in ML consists of performing the model validation using k‐fold cross‐validation. Analyzing the distributions of SHAP values across the different folds allows us to understand if the SHAP value trends observed in the visualization plots are consistent across the data and not just present in a subset of the dataset.

Standard supervised ML workflow.

Different visualization plots of SHAP values from an XGBoost model when predicting blood pressure: (a) Bar plot; (b) Beeswarm plot; (c) A scatter plot for the feature age colored by each subject's BMI; (d) Waterfall plot for an example subject.

Scatter plot of SHAP values for feature age faceted by train‐test status when considering cross‐validation. The trends across the different folds are depicted in different lines corresponding to the fold.

Visualization plots of SHAP values derived from an XGBoost model for a classification problem, explaining the predicted probabilities (a,c,e) and the predicted log‐odds (b,d,f).

(a) Example time‐course of the PK model considered to model drug concentration. Different visualization plots for the SHAP values explaining the predictions of individual clearances are depicted; (b) Bar plot; (c) Beeswarm plot; (d–f) Scatter plots of SHAP values corresponding to concentration at different times.

## Section: IMPLEMENTATION AND PRACTICAL CONSIDERATIONS › Overview of visualization plots

Different plots can be used to visualize SHAP values, which allow either local or global explanations and each has a specific interpretation, purpose, advantages, and disadvantages. In this section, we describe the most common plots that are offered by the popular Python package SHAP. 26 , 28

To illustrate the use of these plots, we first trained an XGBoost model for the blood pressure regression problem introduced in the tutorial datasets. After assessing that the model has an adequate fit, we used the SHAP package to calculate the SHAP values for both the train and test dataset. If not otherwise specified, the plots show the SHAP values for the test dataset. In Figure 2 we show the most common visualization plots for SHAP values. In this section, we describe the different parts of the plots, their purpose, advantages, and disadvantages. The code to create these plots can be found in the Supporting Information.

Different visualization plots of SHAP values from an XGBoost model when predicting blood pressure: (a) Bar plot; (b) Beeswarm plot; (c) A scatter plot for the feature age colored by each subject's BMI; (d) Waterfall plot for an example subject.

Scatter plot of SHAP values for feature age faceted by train‐test status when considering cross‐validation. The trends across the different folds are depicted in different lines corresponding to the fold.

## Section: IMPLEMENTATION AND PRACTICAL CONSIDERATIONS › Overview of visualization plots › Bar plot

The bar plot, a global explanation method, displays the mean absolute SHAP value for each feature across all predictions, serving as a measure of feature importance. It quantifies, on average, the magnitude of each feature's contribution to the model prediction; thus, it provides a ranking of features.

An advantage of this measurement for determining feature importance is that the SHAP values are expressed in the same units as the model predictions making them more intuitive. For example, in our regression example, the average impact of the variable age on the predictions of the model is 5.86 mm Hg. To illustrate this point, we refer to Formula 2, where we see that if the prediction is a blood pressure (e.g., mm Hg), all SHAP values will also have the same units, mm Hg. This contrasts with other feature importance measurements like permutation feature importance scores. A disadvantage of this representation is the lack of nuance on the directionality of the impact, or whether the relationship is monotonous. Also, selecting a cut‐off based on the SHAP values, to identify the most important features, depends on domain knowledge and should be determined on a case‐by‐case basis and does not follow a general rule.

In Figure 2a we observe that when considering the XGBoost model for predicting blood pressure, age appears to be the most important feature followed by BMI and then sex.

## Section: IMPLEMENTATION AND PRACTICAL CONSIDERATIONS › Overview of visualization plots › Beeswarm plot

The beeswarm plot provides a global overview of SHAP values for selected features, with rows representing each feature ranked by the mean absolute SHAP value. The individual dots in each row are the SHAP values for that particular feature in each sample of the dataset. Two properties of the dot encode the information of the SHAP values:

Inspection of the color distribution for each feature along the xaxis can provide global insights into the relationship between the feature values and its SHAP values:

An advantage of this plot is the ability to show multiple features at once, ranked by their impact, and at the same time give an indication of directionality and shape of the impact. A disadvantage is the use of color as a scale since it can be difficult to extract the shape of a relationship from the color differences.

In Figure 2b the beeswarm plot shows a detailed overview of the SHAP values for our regression example. We observe that the feature age has a wide SHAP values range and has much higher values than the mean absolute value (5.86). Age appears to have a generally monotonous increasing trend. Age and BMI SHAP values appear to follow a similar pattern hinting toward a possible interaction. This can be further investigated in the following plot.

## Section: IMPLEMENTATION AND PRACTICAL CONSIDERATIONS › Overview of visualization plots › Scatter plot

The scatter plot in displays the relationship between one feature value (x axis) and the SHAP values (y axis). It consists of (1) the scatterplot in which each point represents the sample's feature value on the x axis and the SHAP value on the y axis and (2) the inset gray histogram above the x axis which displays the feature value distribution.

The distribution of the points informs us whether there is a general trend between the feature values and SHAP values and allows us to identify linear or non‐linear relationships. It may be helpful to include trend lines to detect which type of relationship is present. The vertical spread of SHAP values at a fixed feature value is a sign of interaction effects with other features in the model. It is important to consider the inset histogram when interpreting the trends. A high number of samples present in a particular part of the plot indicates that the trend in that area is supported by many samples. Conversely, when the number of samples is limited, it is important to be cautious and refrain from overinterpreting the trend.

Scatter plots may be colored according to another feature's value, by either coloring according to another feature value or first binning the other feature's values and considering coloring according to the bins. 23 This allows to detect interaction effects between different features.

The advantage of this visualization is the level of detail which clearly indicates the direction, magnitude, and variability of the feature's impact on model predictions. This comes at the price of only allowing a single feature per figure or panel.

In Figure 2c we consider the scatter plot for the feature age colored by the subject's BMI. We observe that age above 50 generally has a positive SHAP value (higher blood pressure) and we observe some non‐linearity in the relationship. However, we are unable to detect any interactions between the feature age and BMI.

An extension of this plot can be considered when doing k‐fold cross‐validation such that the points are colored to the different folds they belong to, and the plot is faceted by the train‐test status. Trend lines can also be included per fold. This plot then allows us to corroborate if trends are consistent across different subsets of data.

In Figure 3, we consider this extension of the scatter plot for the feature age. We performed a fivefold cross‐validation and calculated the SHAP values for each fold for the test and the train dataset. We can observe that the trend of the SHAP values for age is consistent across the folds and across the train‐test split. This demonstrates that the feature impact is stable and trustworthy.

Scatter plot of SHAP values for feature age faceted by train‐test status when considering cross‐validation. The trends across the different folds are depicted in different lines corresponding to the fold.

## Section: IMPLEMENTATION AND PRACTICAL CONSIDERATIONS › Overview of visualization plots › Waterfall plot

A waterfall plot is used to visualize the predicted SHAP values of a single sample showing all features. The predicted value for this specific sample is given in the plot title.

The model features are located along the y axis, and the value of that feature for that specific sample is denoted in gray. The SHAP value corresponding to each feature for this specific sample is written in the main panel within an arrow for each row or feature. The row is red (blue) if the SHAP value increases (decreases) the prediction f(x i ) in comparison to the expected or average prediction.

This type of plot provides a local interpretation since it focuses on a single sample. This is useful when analyzing model outliers, SHAP values outliers, or specific subjects of interest.

In Figure 2d, we show the waterfall plot for an example subject. We can see that BMI is the feature that affects the difference between its model‐predicted blood pressure the most when compared to the average prediction.

More references on other plots like heatmap plots, force‐plots, decision plots, violin plots, stacked force‐plots, interaction plots, to name a few and their interpretation can be found in other publications. 27 , 31 , 32

## Section: IMPLEMENTATION AND PRACTICAL CONSIDERATIONS › Binary endpoints

For classification ML models, special care needs to be taken when calculating SHAP values. Using SHAP for explaining a classification model prediction can be set up in two ways: (1) explaining the predicted probabilities or (2) explaining the predicted log‐odds for each sample belonging to that class. Explaining probabilities makes it easier to identify the contribution of features to the prediction; however, explaining the predicted log‐odds can provide a clearer picture of the relationship between the model features, making the log‐odds sometimes easier to interpret. This can be due to non‐linear interactions and implicit interactions. It is worth considering both explanations.

To illustrate the application of SHAP analysis for classification models, we trained an XGBoost model using the breast cancer diagnostic dataset. After assessing that the model has an adequate fit, we used the SHAP package to calculate the SHAP values for the test dataset. In Figure 4 we show the bar plot, beeswarm plot, and the scatter plot for the most important feature (concave points). 33 On the left plots, we display the SHAP values when explaining the predicted probabilities, while on the right, we present the corresponding SHAP values when explaining predicted log‐odds.

When comparing the SHAP plots for explaining the predicted probabilities and predicted log‐odds, the result is quite similar. Both bar plots (Figure 4a,b) show that the feature concave points has the highest mean absolute SHAP value followed by area and texture. Note the different values of the SHAP values in probabilities (concave points have a mean absolute SHAP value of 0.26) and in log‐odds (has a mean absolute SHAP value of 3.81). This signifies that concave points are the most influential feature in classifying the breast mass as benign or malignant. The beeswarm plots (Figure 4c,d) can give a better overview of the relationship between the feature values and its SHAP values. Both beeswarm plots reveal a positive relationship for concave points, area, texture, and concavity which means the higher the feature value, the higher the probability or log‐odds. For the feature area, we can see that some samples with a middle feature value (purple) are associated with the highest SHAP values, indicating that the relationship is not linear. For a closer look at the relationship between a feature's values and the model's predicted outcomes, we consider the scatter plots. Figure 4e,f shows the scatter plots for the most important feature: concave points. Both scatter plots show an increase in SHAP values for increasing concave points up to 0.09. After that, increasing feature values the SHAP values are mostly flat, especially for predicting log‐odds. In addition, at a feature value of 0.05, the model switches from predicting lower to higher probabilities or log‐odds.

Visualization plots of SHAP values derived from an XGBoost model for a classification problem, explaining the predicted probabilities (a,c,e) and the predicted log‐odds (b,d,f).

## Section: IMPLEMENTATION AND PRACTICAL CONSIDERATIONS › SHAP for time‐dependent ML models

The use of SHAP analysis for time‐dependent is a challenging 34 , 35 and currently an active area of research. Traditionally, researchers have performed SHAP analysis of a ML model prediction that considers time‐dependent data by crafting features that capture the time‐dependent aspects of the data and subsequently treating the problem as standard classification or regression models.

We consider the time‐series in‐silico data created from the PK model described in the tutorial dataset section. The drug concentration over time of this model is shown in Figure 5a for an example subject. The samples are labeled according to the cycle they belong to and the time since last dose (TSLD). Each concentration is denoted by Ccycle,TSLD. We trained a LSTM model to the simulated data and calculated the SHAP values using GradientExplainer. In Figure 5, we show different visualization plots of the SHAP values from this model. In Figure 5b, we can see that the most important features to predict the individual clearances are C1,9 followed by C1,13 and C1,17. The beeswarm plot in Figure 5c shows a monotonous decreasing trend for the concentrations in the elimination phase except for the first concentrations after tmax (i.e., C0,5 and C1,5). The scatter plot in Figure 5d,e show that SHAP values for the drug concentrations with the same TSLD for the different cycles follow the same trend. The scatter plot Figure 5f shows that the SHAP values for the first drug concentration at cycle 1 have a monotonous increasing trend as expected.

(a) Example time‐course of the PK model considered to model drug concentration. Different visualization plots for the SHAP values explaining the predictions of individual clearances are depicted; (b) Bar plot; (c) Beeswarm plot; (d–f) Scatter plots of SHAP values corresponding to concentration at different times.

## Section: IMPLEMENTATION AND PRACTICAL CONSIDERATIONS › Software

For Python, the most popular package that implements SHAP analysis is the SHAP package that is compatible with standard ML packages such as keras, tensorflow, scikit‐learn, and pytorch. For R and specifically XGBoost there is the package SHAPforxgboost 36 available in CRAN. The shapper package is also available in R and it is a R wrapper of the SHAP Python library. 37

## Section: EXAMPLES

In this section, we include the results of performing SHAP analyses for popular ML black‐box models for classification and regression problems, specifically, we consider XGBoost, 36 random forest, and neural networks (multilayer perceptron model).

To further demystify how to interpret SHAP analyses on black‐box models, we apply this methodology to linear regression and logistic regression models using in‐silico data. This will help the reader gain intuition on how to interpret the different visualization plots within a familiar framework.

For both black‐box models and interpretable models, we provide the Python code in the Supplementary Information for performing the SHAP analysis.

Visualizations plots for SHAP values of different ML regression models; (a,c,e) Bar plots; (b,d,f) Beeswarm plots.

## Section: EXAMPLES › Common ML frameworks

We considered XGBoost, random forest, and a neural network model as regression models and trained them using the regression dataset. In Figure 6, we can see the bar plot, the beeswarm plot, and the scatter plot of the SHAP values of the variable age for the test dataset of the fitted models. When comparing the bar plots (Figure 6a,c,e), we observe that for all three models, age has the highest mean absolute SHAP value. However, for the XGBoost and the neural network, BMI has the second‐highest value, followed by sex. In contrast, for the random forest model, sex has the second‐highest mean absolute SHAP values, followed by BMI. The beeswarm plots (Figure 6b,d,f) are also comparable between all three models. They show a positive relationship between age and BMI which means the higher the feature value, the higher the outcome. Especially for the neural network we can see the smooth color gradient that transitions from blue to red indicating that the positive relationship is nearly monotonous. For the random forest and XGBoost model, some mixed colors are visible around the SHAP value of 0. The categorical feature, sex, clearly shows a negative relationship for all three models. The beeswarm plot doesn't show a clear trend for AlcoholYear or PhysActiveDays, especially for the random forest model and neural network.

We considered XGBoost, random forest, and a neural network model as classification models and trained them using the breast cancer diagnostic dataset. In Figure S1, we can see the different visualization plots for the SHAP values for explaining the predicted probabilities for the different models. We can see that XGBoost and random forest ranked the different features according to the mean absolute SHAP value very similarly. This contrasts with the neural network model that only has positive mean absolute SHAP values for three features: area, perimeter, and texture. XGBoost and random forest have better and similar classification metrics in comparison to the neural network model (See Table S2 for accuracy metrics for all classification models). The beeswarm plots of XGBoost and random forest indicate a positive relationship for concave points, area, texture, and concavity. The feature perimeter has a negative relationship in the neural network model compared to random forest.

Visualizations plots for SHAP values of different ML regression models; (a,c,e) Bar plots; (b,d,f) Beeswarm plots.

## Section: EXAMPLES › Common statistical frameworks › Linear regression

We first simulate 2000 observations from a linear model (3) by considering two predictors x1 and x2 that follow an uniform distribution, that is, x1,x2~U0,10:

where b0=−10, b1=6 and b2=−3.

Now we assume the data generation process to be unknown and fit the generated data using a linear regression model.

For a linear regression model with no interaction terms, such as the one presented here, it can be shown that SHAP values for feature xj correspond to

where bj is its corresponding linear coefficent and Exj corresponds to the expected sample mean of the corresponding feature. The derivation of this formula can be found in Chapter 7 of the book by Christopher Molnar. 38

When considering the in‐silico dataset we obtain Ex1 = 5.05 and Ex2 = 4.99 for the test dataset which are close to the theoretical mean of 5 of the underlying distribution. Based on the conditions used to simulate the in‐silico data, the SHAP values for a pair of model features x1x2 are:

By considering kernelSHAP for estimating the SHAP values of this model, we can observe that the SHAP values are described by these formulas. In Figure S2, we show the different visualization plots that were considered for the SHAP values of this particular model. The bar plot in Figure S2A shows that the feature x1 has a higher mean absolute SHAP value than feature x2, as expected. Therefore, we can see that measuring the feature importance, based on the mean absolute SHAP values, matches to the intepretation that we can perform on this linear regression model.

When analyzing the beeswarm plot in Figure S2B, we can observe the general trends of the SHAP values for the two features of the linear regression model. The distribution of the SHAP values corresponding to the feature x1 has a wider spread compared to the distribution of the SHAP values of feature x2. This is expected since the absolute value of b1 is twice the absolute value of b2. Furthermore, in the beeswarm plot, we can observe there is a monotonous increasing relationship between feature x1 and its SHAP values (blue to red) and a decreasing negative relationship between feature x2 and its SHAP values (red to blue).

When inspecting the scatter plots for each feature (Figure S2C,D), we can see that the SHAP values for features x1 and x2 follow the formulas given in Formula 5. The waterfall plots of Figure S2E,F for two particular instances satisfy the formula given in Formula 4. Figure S2E shows that the feature values for this sample are x1=7.05 and x2=0.614. The SHAP value corresponding to feature x1 is 11.07 which means that this feature increases the prediction fxi in comparison to the average prediction. Feature x2 increases the prediction with a SHAP value of 12.55. Finally, the predicted value for this specific sample is fxi = 6.839 + 11.07 + 12.55 = 30.459.

## Section: EXAMPLES › Common statistical frameworks › Logistic regression

We first simulate data from a logistic regression model by considering two predictors x1 and x2 that follow a uniform distribution, that is, x1,x2~U0,10, we then define a linear model:

where b0=10, b1=2 and b2=−6. We then consider the transformation to the probability space

Using these probabilities we perform 2000 Bernoulli samples, that is, x1,ix2,iyii=12000 where yi is the outcome of Bernoulli trials considering the probabily pi given by Formula 7.

We fit the resultant data using a logistic regression model and the estimated parameters match those of the model used to generate the data. Figure S3 illustrates the different visualization plots of SHAP values from a logistic regression, explaining the predicted probabilities and the predicted log‐odds, side by side.

When comparing the bar plots we can see that feature x2 has a higher mean absolute SHAP value in comparison to feature x1 which signifies that feature x2 is a more influential feature than feature x1 (Figure S3A,B). This intepretation can also obtained in the classical way when inspecting the coefficient of features x1 and x2.

When comparing the beeswarm plots of the SHAP values of the logistic regression model, we can observe a non‐uniform distribution for the SHAP values when explaining the predicted probabilities. This is in contrast to the uniform distribution of the SHAP values for both feature x1 and x2 when explaining the predicted log‐odds. These observations can be seen in Figure S3C,D.

If we inspect the scatter plots for feature x2, we notice that when explaining the predicted probabilities the relationship between the features and the SHAP values is non‐linear (Figure S3E). When explaining the predicted log‐odds, the relationship is linear (Figure S3F) as expected.

Generally, we also observe that the different visualization plots for the SHAP values of the predicted log‐odds are similar to the visualization plots for the SHAP values of the linear regression. This is expected since in the log‐odds scale the predictors follow a linear regression model.

## Section: FINAL REMARKS

In this tutorial, we provided a brief overview of the theoretical background of SHAP analysis, including Shapley values and their connection to SHAP analysis. We discussed the implementation and practical considerations of SHAP analysis, including visualization plots, special considerations for classification and time‐series models, and available software. We showed the application of SHAP analysis to standard interpretable models and popular ML frameworks, both for regression and classification problems, as well as time‐dependent models. We conclude by summarizing the limitations and potential extensions of this widely used technique.

While SHAP analysis is a powerful feature‐based interpretability technique with numerous benefits, it is important to acknowledge its limitations and explore extensions for a comprehensive interpretability analysis of a ML model. Although the SHAP method does not assume feature independence, some of the approximation methods used to calculate the SHAP values (e.g., kernelSHAP) do assume it. In almost any real application this will not be the case, therefore, the reader needs to be careful when including features that are strongly correlated. A pre‐processing step of analyzing the data and being aware of this situation can help to avoid situations where the model gives inaccurate predictions or give predictions that are at odds with domain knowledge of the topic. For both regression and classification problems, we performed this pre‐processing step. For the regression models, we did not include weight or height as predictors since we included BMI as a predictor. For the classification models in the original dataset, the dataset for each breast mass' characteristics included the mean, standard deviation, highest and lowest values, and we only considered the mean values as predictors. An extension of kernelSHAP has recently been introduced 39 that takes into account the correlation between features. A Python package based on this extension was recently released 40 as well as an R package. 41 Feature engineering and selection can also help address the issue beforehand, enabling the use of the standard methodology. Other SHAP approximation methods like TreeSHAP explicitly consider feature dependence within the model structure.

Another limitation worth mentioning is that SHAP analysis does not quantify the importance of predictors in the real‐world problem, but rather their importance to the model's predictions. SHAP values do not show how the features contribute to the observations, but rather how the features contribute to the models' predictions for the observations. Especially in the presence of model bias or in case of overfitting, this difference is important and should always be considered when interpreting SHAP values.

In this tutorial, we focused on SHAP analysis for supervised ML models that considered tabular data. However, SHAP analysis can also be applied to other ML models 42 , 43 relevant in drug development and one can also consider other type of data (e.g., electrocardiogram data, 44 MRI data 45 ). A deeper dive into these other topics is necessary to understand the special considerations that need to be taken into account in each case. Also, this tutorial mostly focused on SHAP analysis; however, there exist other feature‐based explainability methods with advantages and disadvantages in comparison to SHAP analysis such as LIME, 46 integrated gradients, 47 and permutation feature importance. 48 Considering these alternatives may be worthwhile to address some of the SHAP limitations. Also, as the authors in Imrie et al. 19 mentioned, ML interpretability has mostly focused on feature‐based models; however, to fully understand a black‐box model and provide explanations to the different stakeholders in clinical pharmacology, it is also important to embrace and combine other types of model‐agnostic interpretation methods. In this tutorial, we also showed an example of how to perform SHAP analysis on a time‐dependent ML model. However, there are several limitations to this approach. First, aggregating SHAP values over multiple time points can result in the loss of temporal information. Additionally, understanding the time‐dependent impact of a feature can be difficult as its importance may vary over time. For the specific example shown, the SHAP values might not accurately capture the internal mechanisms of LSTM models, which are used to handle temporal dependencies. When considering feature engineering to account for time dependence, the chosen approach may not effectively capture time dynamics. Nevertheless, recent advancements have introduced new methodologies that incorporate the time‐dependent structure 49 , 50 into the SHAP calculation. In particular, there are new packages available for SHAP calculation for deriving time‐dependent explanation of ML survival models. 42

The use of ML models in drug development is expected to continue growing and to become an integral part of this industry. In light of this, it is important to adopt ML interpretability methods to enhance the transparency and trustworthiness of black‐box model predictions. This tutorial aims to offer a small yet meaningful step toward addressing this objective.

## Section: FUNDING INFORMATION

This study was funded by AbbVie, Inc. AbbVie contributed to the study design, research, and interpretation of data, and the writing, reviewing, and approving of the publication.

## Section: CONFLICT OF INTEREST STATEMENT

All authors are employees of AbbVie and may hold AbbVie stock.

## Section: Supporting information

Data S1:

Data S2:

Data S3:

## Section: ACKNOWLEDGMENTS

Medical writing support was provided by Wesley Wayman, PhD, an employee of AbbVie.

## Section: Text

Ponce‐Bobadilla AV, Schmitt V, Maier CS, Mensing S, Stodtmann S. Practical guide to SHAP analysis: Explaining supervised machine learning model predictions in drug development. Clin Transl Sci. 2024;17:e70056. doi: 10.1111/cts.70056

## Section: Associated Data

Data S1:

Data S2:

Data S3:

## Section: Associated Data › Supplementary Materials

Data S1:

Data S2:

Data S3:


---

# Predicting pharmacodynamic effects through early drug discovery with artificial intelligence-physiologically based pharmacokinetic (AI-PBPK) modelling

- **Authors:** Keheng Wu, Xue Li, Zhou Zhou, Youni Zhao, Mei Su, Zhuo Cheng, Xinyi Wu, Zhijun Huang, Xiong Jin, Jingxi Li, Mengjun Zhang, Jack Liu, Bo Liu
- **Issuer:** Frontiers in pharmacology
- **Type:** Scientific article
- **Published:** 2024-02-16
- **Language:** en
- **DOI:** 10.3389/fphar.2024.1330855
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38434709/
- **Licence:** CC-BY

## Section: Abstract

AbstractA mechanism-based pharmacokinetic/pharmacodynamic (PK/PD) model links the concentration-time profile of a drug with its therapeutic effects based on the underlying biological or physiological processes. Clinical endpoints play a pivotal role in drug development. Despite the substantial time and effort invested in screening drugs for favourable pharmacokinetic (PK) properties, they may not consistently yield optimal clinical outcomes. Furthermore, in the virtual compound screening phase, researchers cannot observe clinical outcomes in humans directly. These uncertainties prolong the process of drug development. As incorporation of Artificial Intelligence (AI) into the physiologically based pharmacokinetic/pharmacodynamic (PBPK) model can assist in forecasting pharmacodynamic (PD) effects within the human body, we introduce a methodology for utilizing the AI-PBPK platform to predict the PK and PD outcomes of target compounds in the early drug discovery stage. In this integrated platform, machine learning is used to predict the parameters for the model, and the mechanism-based PD model is used to predict the PD outcome through the PK results. This platform enables researchers to align the PK profile of a drug with desired PD effects at the early drug discovery stage. Case studies are presented to assess and compare five potassium-competitive acid blocker (P-CAB) compounds, after calibration and verification using vonoprazan and revaprazan.Keywords: artificial intelligence (AI), machine learning (ML), early drug discovery, PBPK modeling, PD modeling, P-CABs

## Section: 1 Introduction

Drug discovery and development is a long and intricate process. It begins with identifying a biological target that can be affected by a drug to change disease progression. After validating this target, methods like virtual screening or high throughput screening (HTS) are used to screen through vast compound libraries, pinpointing ‘hits’ that show some activity. These hits are then refined into ‘lead’ compounds. These optimized leads are tested in vitro and on animals for safety and effectiveness checking. Essentially, drug development follows a process of broad to fine screening. We are now using the AI-PBPK platform to optimize the screening process from virtual compounds to candidate. The platform predicts ADME (Absorption, Distribution, Metabolism, Excretion) and physicochemical characters of the compound, and continuously predicts the human PK and PD outcomes of the drug candidate. Implementing this methodology in the discovery process could bring the clinical end points earlier and potentially lead to the identification of high-quality drug candidates earlier, ultimately reducing the timeline from target discovery to candidate selection.

PBPK modelling has become an essential component in the process of drug discovery and development. Within these models, established physiological characteristics and the ADME properties of a compound are incorporated into mathematical equations to predict drug behaviour in human body. The computational method involving model-based pharmacology evaluation was employed to determine the best range of PK, ADME and physicochemical characteristics for a specific target (Chen EP and Michalski, 2021). As a web-based platform, B2O simulator® integrated PBPK models to predict drug exposure, potential interactions with other drugs and the likelihood of been bioequivalent with reference compound (Zhang et al., 2021a; Zhang et al., 2021b; Li et al., 2022; Li J et al., 2022; Zhang J et al., 2023). In those studies, drug related physicochemical parameters were searched online or calculated. Various computational techniques have been established for determining key parameters, including permeability (Paudel et al., 2023). When employing quantitative techniques to develop predictive models, the models could serve different purposes. For example, quantitative structure—toxicity relationship (QSTR) models were used for toxicity prediction based on chemical structure (Rai et al., 2023), whereas PK models were used to understand and predict the pharmacokinetic profile of drugs in the body.

In the current study, the B2O simulator integrated the PD model, PBPK and AI related algorithms into one platform. Machine learning (ML) methods, as a subset of AI, are used to predict the ADME and other physiochemical properties. As a specific type of machine learning algorithm, Graph Neural Networks (GNNs) is used in this study to analyse chemical structures and to perform predication on structures’ PK parameters. Another algorithmic approach used in the study was random forest model. The platform employs the m5p random forest model, a decision tree-based regression method, for modelling parameters like apparent clearance (CLapp) (Alex A Freits and Ghafourian, 2015). Other global features such as logP, were calculated using the “CalcCripppenDescriptors” function in the RDKit cheminformatics toolkit. PKa was calculated using the open-source Dimorphit-DL (Ropp et al., 2019). The workflow for predicting the PK and PD outcomes of a compound using the AI-PBPK platform is shown in Figure 1. Examples such as potassium-competitive acid blocker (P-CAB) drugs were used to demonstrate the utility and benefits of this method in guiding early discovery studies. The process involved using the molecular structure and potency data of vonoprazan to calibrate its PK and PD outcomes against observed results. Following this calibration, the model underwent validation using revaprazan, another compound in the P-CABs class. Subsequently, the PK and PD outcomes for five different P-CABs were predicted and compared to identify the most promising candidate.

The PD model was adapted from a mechanism-based model developed by Kong et al., 2020 and Jia et al., 2021. It was indicated that a significant proportion (52%) of drug failure in clinical trials was due to poor efficacy from available data (Kiriiri et al., 2020). To prevent subsequent setbacks, it is crucial to identify and validate the target, confirming its significance in early discovery stage. “The proportion of time with a gastric pH > 4 over a 24-h period” is the endpoint in clinical studies of P-CAB drugs. P-CABs are designed to inhibit gastric acid secretion. The gastric pH level is a direct measure of acidity in the stomach. A pH greater than 4 indicates a reduction in gastric acidity. This endpoint can be predicted using mechanism-based pharmacokinetic (PK) and pharmacodynamic (PD) models. For P-CABs, PK modelling can predict the concentration of the drug in the bloodstream. It is helpful to understand the drug’s availability in the body, which is directly related to its efficacy. PD models are used to predict how changes in drug concentration affect gastric acid secretion and the gastric pH levels. The model considers the drug’s mechanism of action, such as how the P-CAB drugs inhibit acid secretion by blocking the H+/K + -ATPase (proton pump) in the stomach lining, which directly affects gastric acidity, and thus pH levels.

Workflow for predicting the PK and PD outcomes of a compound using AI-PBPK platform.

## Section: 2 Methods › 2.1 PBPK/PD modelling

The whole-body PBPK model, designed to predict plasma concentration of vonoprazan and other P-CABs PK profiles at different does, was based on two studies reported by (Thierry Wendling et al., 2015a; Thierry Wendling et al., 2015b). The model comprised 14 tissue compartments including lungs, hearts, brain, muscle, adipose, skin, spleen, pancreas, liver, stomach, gut, bones, kidneys and rest-of-body and 2 blood compartments (arterial and mixed venous). Each tissue compartment is assumed well-stirred, with the extent of distribution being characterised by the equilibrium tissue: blood partition coefficient (Kp). The rate equation for the tissue compartments can be expressed as follows (Eq. 1):

Where AT is the drug amount (μg), VT is the volume (L) and QT is the blood flow (L/h) for the different tissues, and AVEN/ART and VVEN/ART are the amount (μg) and volume (L), respectively, of either mixed venous blood or arterial blood for all other tissues. Drug elimination is assumed to occur entirely in the liver compartment via oxidative metabolism (Thierry Wendling et al., 2015a). The PBPK model was integrated into the B2O platform. Subsequently, the PD model was also integrated and described the correlation between the plasma concentration of vonoprazan and the intra-gastric pH levels.

In the PD model, the antisecretory effects of the drug I, which also represented the increase pH, was calculated using the formula (Eq. 2):

where dI/dt is the rate of change of the drug’s antisecretory, which is also the rate of change of pH over time. Imax is the maximum possible antisecretory effect (or maximum pH level) the drug can achieve. K is the binding rate constant using the ration of kd to ki. Ki is the inhibition index. Ce is the free drug concentration in the stomach and kd is the irreversible inhibition efficacy of H+/K+—ATPase. E/E0 in Graphic abstract equalls to (1-I). Ce is calculated from the following formula (Eq. 3):

where AGU is the amount of drug in gut and Volume of gut. Kp is the Tissue gut: plasma partition coefficient. Kp_scaler adjusted all Kp values in equal proportions. Bpr is the blood to plasma ratio and fub is unbound to plasma proteins in the bloodstream.

## Section: 2 Methods › 2.2 Graph neural networks

As a type of GNN model, The Message Passing Neural Network (MPNN) model was used following the work developed by (Gilmer et al., 2017; Jose Jimenez-Luna et al., 2021). The MPNN model operates on undirected graphs composed of vertexes (v) and edges (e) (Gilmer et al., 2017). It’s particularly useful for predicting molecular properties. The next two steps provide a simplified explanation of how the MPNN operates:

Here, w∈N(v) denotes the neighbour vertexes of each vertex v in the graph.

These functions (Mt, Ut, R) are learned differentiable functions (Gilmer et al., 2017).

To train an MPNN model, one commonly employs a version of stochastic gradient descent. During this process, the model is trained to identify underlying structural traits of molecules and to predict molecular characteristics by minimizing the difference between its predictions and the actual values. This study highlights the application of MPNN models in clarifying the relationship between molecular structures and their properties, with a reference to the studies conducted by Jose Jimenez-Luna et al., 2021. In this example, all molecular structures were converted into graph representations using the Python DGL package. Additionally, 2D features produced by RDkit were integrated, similar approach was also used in random forest model. Parameters such as plasma protein binding rate (ppbr, data size: 4637, best fold R 2 = 0.551), blood to plasma ratio (bpr, data size: 461; best fold R 2 = 0.107), Volume of distribution (Vss, data size: 1305, best fold R 2 = 0.413) and Caco-2 Permeability (Papp, data size: 525, best fold R 2 = 0.412) were predicted. Permeability in Caco-2 cells was used to calculate Fa, the fraction absorbed. The model of the best fold was chosen for the AI-PBPK model.

## Section: 2 Methods › 2.3 Random forest (tree model) models

The m5p random forest model consists of an ensemble of m5p trees, which are decision trees that use linear regression functions at the leaf nodes instead of constant values. The m5p random forest model works by randomly selecting a subset of features and a subset of instances for each tree, and then building the tree using the m5p algorithm. The m5p algorithm splits the instances based on the feature that minimizes the variance of the linear regression functions at the child nodes. The final prediction of the m5p random forest model is obtained averaging the predictions of all the trees in the ensemble. More details of how the algorithm trains a model and performs prediction were addressed in Freitas’s original work (Alex A Freits and Ghafourian, 2015). After design and coding, data was trained for Clapp model. The Clapp dataset was split into 10 folds, each were successively deemed as validation set in each turn and the rest 9 folds were deemed as a training set. The mean absolute error (MAE) was chosen as the indicator to show the performance of the model trained by the training set of each turn. The smallest MAE of all turns described how well the model fits the training data and predicts external data and helped to choose the best Clapp model to be added to the AI-PBPK model. Parameters such as apparent clearance CLapp (data size: 98, best fold R 2 = 0.388, internal R 2 = 0.7996) was predicted using this model.

## Section: 2 Methods › 2.4 Data source of machine learning

Five ADME parameters were modelled by machine learning. They are the fraction of the drug that is unbound to plasma proteins in the bloodstream (fup; fup = 1-ppbr), steady state volume of distribution vss_perKg, apparent clearance Clapp (Clapp = vss*0.693/half-life), gastrointestinal absorption constant (gi_ka; gi_ka = 2*Papp/radius of small intestine) and blood to plasma ratio (bpr). The radius of small intestine is 1.25 cm according to its 2.5 cm diameter (Herbert and Helander, 2014). The data for the first 4 parameters were collected from the Therapeutics Data Commons (TDC) database. Its Python package named “PYTDC” was installed, and the correspondent datasets were used in this package:

Additionally, the bpr data were from the Mamada’s work (Hideaki Mamada et al., 2021). All 5 datasets were composed of 2 vectors with same lengths. One of them was their molecular structure displayed in SMAILES codes, and the other was the correspondent ADME parameter values for each molecule.

## Section: 2 Methods › 2.5 Design of simulation studies

When the PBPK/PD model was established, and the needed parameters were collected or generated by machine learning models, the PK and gastric pH profiles were simulated for each drug for a 48—hour duration after 20 mg single oral dose.

## Section: 2 Methods › 2.6 Case study: potassium-competitive acid blocker drugs to reduce the production of stomach acid

As one of the most well-known examples of P-CAB drugs, vonoprazan has gained global recognition to treat conditions related to stomach acid, such as gastroesophageal reflux disease (GERD) and peptic ulcers. Its primary target is the H+/K+ ATPase enzyme. Known as the proton pump, the enzyme is located in the stomach lining. Vonoprazan inhibits the proton pump by binding competitively to the potassium-binding site on the pump, thus inhibiting the exchange of hydrogen ions for potassium ions. This inhibition reduces the amount of gastric acid produced and secreted into the stomach, which can help to alleviate symptoms associated with acid-related disorders. In clinical trials, the proportion of time with a gastric pH > 4 over a 24-h period is often used as a primary or secondary endpoint. Because the optimal PK required for a drug candidate to elicit efficacy is highly dependent on the targeted pharmacology (Chen EP and Michalski, 2021), PK and PD results were both analysed in the platform to avoid misguiding of compound screening and design. The study also included five other compounds which also has H+/K+ ATPase as the target.

In this study, the PK performance of vonoprazan was firstly predicted and calibrated with observations. After verification with revaprazan, the PK performance of the other five P-CAB compounds was simulated. Following that, their PD outcomes were also simulated using the AI-PBPK platform. Finally, the PK and PD results of different doses of compounds were analysed and compared, and the optimal combination of PK, PD and dose of candidate compounds was determined.

## Section: 2 Methods › 2.7 Literature search

Observed data were collected from literature search. Since vonoprazan was firstly approved in Japan in 2014, a PubMed search was conducted using “vonoprazan” AND “clinical trial” as keywords, beginning from the year 2014. Only those publications that contain comprehensive PK data from a 20 mg monotherapy of vonoprazan in healthy subjects for the first 2 days were included. Observed PD data were collected from literature search as well, with the same keywords. We only included studies that provided results on gastric pH versus time over a 24-h period from a 20 mg monotherapy of vonoprazan in healthy subjects (fasting condition).

## Section: 2 Methods › 2.8 Software

The PBPK model was implemented using the software B2O simulator, a web-based platform, to predict drug exposures. With lower and upper CI% (Confidence Interval) limits 2.5%–97.5%, the geometric mean of the maximum serum concentration that a drug achieves in the body (Cmax) and the area under the curve (AUC) were calculated, and ratios between geometric means were calculated and compared with the observations from clinical studies. Changes bigger than or equal to 2-fold were considered significant.

## Section: 2 Methods › 2.9 Statistical analyses

Pearson’s correlation coefficient (r) is a statistical measure that express the extent of the correlation between two variables. The correlation coefficient was calculated using R version 4.3.0.

Local sensitivities of the following 17 parameters predicted by the machine learning models were analysed. They were fup, bpr, gi_ka, clapp, vss_perKg, kp_bone, kp_brain, kp_adipose, kp_heart, kp_kidney, kp_gut, kp_liver, kp_lung, kp_muscle, kp_skin, kp_spleen, kp_scaler. Kp represents the tissue: plasma partition coefficient. Each of them was tuned ±1% from their predicted value, and the percent change of AUC and Cmax values of revaprazan in response to an average 1% change in each parameter were studied and compared.

## Section: 3 Results

Simulation results of vonoprazan: (A) Plasma concentration versus time and comparisons with observations from studies A (Kentaro, 2018), B (Tack et al., 2023), C (Jenkins et al., 2015), D (Mulford DJ et al., 2022) and E (Jenkins and Patat, 2017), before and after calibration (adjustment); (B) Logarithm of simulated vonoprazan plasma concentration versus time before and after calibration (adjustment); (C) Concentration in the stomach after calibration.

Predicted parameters for vonoprazan.

Comparison of simulated PK results before and after adjustment.

Simulated (solid lines with colours) and observed plasma concentration (dashed lines with colures) of revaprazan after calibration.

Predicted and observed data of revaprazan after oral administration 200 mg.

Input parameters for the prediction of PD outcomes.

Simulated gastric pH over 24 h, comparing to observations from Studies A (Sakurai Y et al., 2015), B (Laine et al., 2022) and C (Suzuki et al., 2018), after calibration.

Simulation of five P-CAB compounds of (A) Plasma concentration versus time; (B) Gastric pH over 24 h after orally administration.

Simulated pH > 4 holding time percentage and time of onset of P-CAB compounds under dose of 20 mg.

PH > 4 holding time percentage % of different compounds under different doses.

The onset time of different compounds under different doses.

## Section: 3 Results › 3.1 Simulation, calibration and verification of PK behaviour

Simulation results of vonoprazan: (A) Plasma concentration versus time and comparisons with observations from studies A (Kentaro, 2018), B (Tack et al., 2023), C (Jenkins et al., 2015), D (Mulford DJ et al., 2022) and E (Jenkins and Patat, 2017), before and after calibration (adjustment); (B) Logarithm of simulated vonoprazan plasma concentration versus time before and after calibration (adjustment); (C) Concentration in the stomach after calibration.

Predicted parameters for vonoprazan.

Comparison of simulated PK results before and after adjustment.

Simulated (solid lines with colours) and observed plasma concentration (dashed lines with colures) of revaprazan after calibration.

Predicted and observed data of revaprazan after oral administration 200 mg.

## Section: 3 Results › 3.1 Simulation, calibration and verification of PK behaviour › 3.1.1 Simulation of vonoprazan PK performance

The SMILES code for vonoprazan is CNCC1 = CN(C (=C1)C2 = CC = CC = C2F)S (=O)(=O)C3 = CN = CC = C3. When the SMILES code was entered into the AI-PBPK platform, the plasma concentration of vonoprazan was simulated and the result is shown in Figure 2A (solid black line). The predicted parameters including ADME and physicochemical properties, are listed in Table 1. The Kp scaler adjusted all Kp values in equal proportions. Its size varied based on the predicted vss_per Kg. The outcomes from the simulation were compared with the observed results. After literature search, PK data observed from five clinical studies were chosen, and their values were used for comparison with the simulation outcomes, as described in Figure 2A. From the figure we can see that the simulated drug exposure, which is represented by the area under the curve in the plasma concentration versus time plot, was greater than the values corresponding to the average observed exposure.

Simulation results of vonoprazan: (A) Plasma concentration versus time and comparisons with observations from studies A (Kentaro, 2018), B (Tack et al., 2023), C (Jenkins et al., 2015), D (Mulford DJ et al., 2022) and E (Jenkins and Patat, 2017), before and after calibration (adjustment); (B) Logarithm of simulated vonoprazan plasma concentration versus time before and after calibration (adjustment); (C) Concentration in the stomach after calibration.

Predicted parameters for vonoprazan.

## Section: 3 Results › 3.1 Simulation, calibration and verification of PK behaviour › 3.1.2 Calibration with vonoprazan PK performance

In this case, the terminal half-life, which represents the elimination of drug, should be adjusted. In order to determine the extent of reduction needed, the log of plasma concentration versus time for both simulated and observed results are plotted in Figure 2B. Since the slope of the logarithmic curve represents the terminal half-life and the slope of the predicted log curve was about 3.08 times that of the observed curve, the initial simulation leads to a much quicker absorption. In this case, the drug absorption fraction Fa, was adjusted to be half of its original predicted value. Simultaneously, the elimination CLapp was adjusted 3.08 times bigger and the absorption rate (gi_ka) was adjusted 3.5 times smaller. The PK outcomes before and after adjustment are listed in Table 2, and the predicted results following parameter adjustment are also shown in Figure 2A.

Comparison of simulated PK results before and after adjustment.

## Section: 3 Results › 3.1 Simulation, calibration and verification of PK behaviour › 3.1.3 Mode verification with revaprazan

After calibration, the predictive capacity of the platform was further validated by inputting the chemical structure of revaprazan, which also has P-CAB target. The predicted PK outcomes were compared with observed results (Kim et al., 2010), as described in Figure 3. Three different doses (100 mg, 150 mg, and 200 mg) were used and the results on days 1 and 7 were compared. The predicted and observed data of revaprazan after orally taken 200 mg on days 1 and 7 are listed in Table 3. All the outcomes were simulated based on one virtual healthy subject. From the table we can see that the predicted PK results are within two times of the observed results. The Pearson’s correlation coefficient (r) was calculated for all time points of the predicted and observed PK data of revaprazan at doses of 100 mg, 150 mg and 200 mg. As a result, the correlation coefficient was 0.8404, 0.8862, and 0.8754 respectively. The analysis results indicated that the model reasonably predicted drug exposure. In the early stages of drug discovery, using a model based on one single virtual healthy subject can provide a baseline understanding of how a typical healthy body might respond to the drug, which is useful for initial screening. Moreover, at this early stage, accurately defining the disease population remains challenging. The presence of disease could introduce considerable inter-variability of patients into the PBPK models, making it difficult to model multiple subjects in the early stage of drug discovery.

Because it is believed that the concentration of vonoprazan in the stomach is different from the plasma concentration and could be 1000 times higher than the concentration in plasma 24 h after administration to humans (Kong et al., 2020), we simultaneously predicted the concentration of vonoprazan in the stomach, as shown in Figure 2C. Comparing to the plasma concentration, the peak concentration in the stomach was around 524 ng/mL, which was 23.8 times higher than plasma concentration in Figure 2A.

Simulated (solid lines with colours) and observed plasma concentration (dashed lines with colures) of revaprazan after calibration.

Predicted and observed data of revaprazan after oral administration 200 mg.

## Section: 3 Results › 3.1 Simulation, calibration and verification of PK behaviour › 3.1.4 Sensitivity analysis

The results of sensitivity analysis demonstrated that the most sensitive parameter that influenced the AUC and Cmax of PK prediction was bpr, which caused almost 1.5% change in Cmax and 1% change in AUC when it was changed by 1%. Moreover, CLapp caused approximately 1% opposite change in AUC when it was changed by 1%. The remaining parameters showed minimal sensitivity to PK predictions, as a local 1% alteration in their values results in less than 0.5% change, indicating they did not significantly influence the prediction.

## Section: 3 Results › 3.2 Simulation, calibration and verification of PD outcomes

Input parameters for the prediction of PD outcomes.

Simulated gastric pH over 24 h, comparing to observations from Studies A (Sakurai Y et al., 2015), B (Laine et al., 2022) and C (Suzuki et al., 2018), after calibration.

## Section: 3 Results › 3.2 Simulation, calibration and verification of PD outcomes › 3.2.1 Simulation and calibration of vonoprazan PD outcomes

When assessing acid-suppressing drug like P-CABs, maintaining a gastric pH greater than 4 for as much of a 24-h period as possible is often a critical PD endpoint. This is because a gastric pH above 4 is generally considered as the necessary threshold to prevent symptoms associated with acid-related disorders. To assess the PD results of vonoprazan, potency related parameters like IC50 (half maximal inhibitory concentration), Ki (the inhibition constant), and other pharmacological parameters such as Dissociation half-life (residence time), Kd (dissociation constant) and K (binding rate constant for the reaction between the drug and its target, Kd/Ki) were searched and calculated from literatures and the values are listed in Table 4. Vonoprazan and KFP_H008 showed relatively low IC50 values as 0.019 and 0.029 μM respectively, indicating higher potency of the compounds to inhibit gastric acid secretion. Revaprazan had the highest IC50 value as 1 μM. The time required for half the dose of drug administered to be removed from the body (t1/2) of dissociation of TAK-438 binding was 4.7 h. This value was employed for other P-CAB compounds because there was no available data from literature search. Kd was calculated from (ln (2)/dissociation half-life) and K was the binding rate constant using the ration of Kd to Ki

Using parameters sourced from literatures, the gastric pH of subjects after oral administration of vonoprazan was simulated. The outcomes from the simulation were compared with the observed results. Gastric pH is affected by the local concentration of proton pumps. Proton pumps, which is also known as H+/K+ ATPase enzymes, are present in the parietal cells of the stomach lining. Since proton pumps are responsible for the production of stomach acid, drugs like P-CABs are taken orally to inhibit these pumps, thereby reducing the secretion of stomach acid. The gastrointestinal concentration of drug doesn’t equal to the local concentration of the proton pump. As such, an enrichment coefficient for the drug, with a value of intersys = 1 × 103, was introduced to the free vonoprazan concentration Ce in the stomach. After calibration, the predicted outcomes, together with observed results are shown in Figure 4. The predicted time percentage with a pH > 4 for vonoprazan was 88.88%. This was within a 1.5-fold variance compared to the mean of the clinical observations A-C (Sakurai Y et al., 2015; Suzuki et al., 2018; Laine et al., 2022), which averaged at 76.4%.

Input parameters for the prediction of PD outcomes.

Simulated gastric pH over 24 h, comparing to observations from Studies A (Sakurai Y et al., 2015), B (Laine et al., 2022) and C (Suzuki et al., 2018), after calibration.

## Section: 3 Results › 3.2 Simulation, calibration and verification of PD outcomes › 3.2.2 Model verification with revaprazan

The ability of the platform to predict PD results was further verified by revaprazan with potency and relevant parameters. The predicted gastric pHs were compared with observed results. When revaprazan was administered orally at a dose of 200 mg, the predicted duration with a pH > 4 was 57.1%. This was within a 1.5-fold variance from the study observation, which recorded a value of 42.2% (Kim et al., 2010). The predicted onset time to reach pH 4.5 was 4 h. The observed time for intragastric pH to reach 4.5 was withing 2 h (Kim et al., 2010). All the predicted results indicate a reliable predictive capacity of the platform for revaprazan.

## Section: 3 Results › 3.3 Prediction of PK and PD outcomes of other P-CAB compounds under the same dose

The PK and PD outcomes of the other five compounds were simulated under the same dose of 20 mg, which is the same to vonoprazan. Having P-CAB as the target, all the chemical structures were searched from literatures. Their names and SMILES codes are listed in Table 4.

The comparison of predicted plasma concentration is shown in Figure 5A. From the results we can see that the five compounds showed similar plasma profiles with compound-2 having the highest concentration in around 2 hours, followed by compound-1. The simulated gastric pH versus time was compared and showed in Figure 5B. As mentioned above, pH > 4 holding time percentage is an important clinical indicator of P-CAB drug in the clinical development of Gastroesophageal Reflux Disease (GERD) and peptic ulcer and pH > 4 helps avoid irritation of the esophagus or ulcer by stomach acid. The shorter the onset of action, the faster the effect of the drug in relieving symptoms. From the figure we can see that within 24 h, all compounds showed fluctuating gastric pH around pH 4. A similar pH fluctuation was observed following the oral administration of vonoprazan, although vonoprazan exhibited a higher gastric pH value. The results of the 24-h time percentage and onset time for pH > 4 are summarized in Table 5. Combining the two major indicators, the simulation found that among the five compounds, KFP_H008 had the best percentage pH > 4 holding time with relatively short onset time, which were 81.17% and 0.99 h respectively. When compared to vonoprazan, KFP_H008 demonstrated close PD outcomes in terms of pH > 4 hold time and time of onset and showed promise for further development.

Simulation of five P-CAB compounds of (A) Plasma concentration versus time; (B) Gastric pH over 24 h after orally administration.

Simulated pH > 4 holding time percentage and time of onset of P-CAB compounds under dose of 20 mg.

## Section: 3 Results › 3.4 Prediction of PK and PD outcomes of other P-CAB compounds at different doses

The PD efficacy of different compounds at different doses were simulated to compare the development potential of the compounds. We compared gastric pH changes for different compounds at 10 mg, 20 mg, 40 mg, 80 mg, 160 mg, and 400 mg. With an increase in the dose from 10 to 400 mg, the pH > 4 holding time of most compounds increased. Starting with a dose of 20 mg, the percentage holding time of the KFP_H008 fluctuated from 80% to 90%. The results of pH > 4 holding time and the time of onset are summarised in Tables 6 and 7. Comparing to other compounds, KFP_H008 maintained the pH > 4 for the longest duration and had a comparatively faster onset time among all the doses, starting from 10 mg.

PH > 4 holding time percentage % of different compounds under different doses.

The onset time of different compounds under different doses.

## Section: 4 Discussion

It is believed that predicting PD, such as pH over time, using the AI-PBPK/PD model is more effective than predicting PK to accelerate the screening of compounds in the drug development stage. Since the primary interest in drug development is the therapeutic effect of drug, predicting the PD allows for a direct understanding of whether a compound is likely to have the desired therapeutic effect or not, and can streamline the compound screening process.

In the current study, ML algorithms are used to estimate model parameter. RDKit package in Pthyon is a cheminformatics library and it is specially designed for the analysis of chemical data. It can read various chemical file formats and represent molecular structures programmatically. And the RDKit compute a wide range of molecular descriptors and features such as molecular weight, log P, and hydrogen bond donors/acceptors. In DGL package, molecules can be represented as graphs, where atoms are nodes, and bonds are edges. It is powerful in learning the patterns and relationships in graph data. Coded and defined by DGL, GNNs can learn complex relationships between atom in molecule, which can be crucial for understanding tis properties and behaviour. Using DGL, the features extracted by RDKit can be integrated into the graph model. This allows the GNN to consider detailed chemical information while making predictions. This combination allows for a more holistic analysis of chemical compounds, considering both of their structural features and the complex interatomic relationships. High-quality, accurate, and well-annotated data is essential for training reliable predictive models.

Using ML or AI in drug development process is an important part of pharmaceutical companies’ strategies. Comparing to totally new drug development, “fast follow” study is based on a substantial data available from the pioneering drug, including its structure, model of action, therapeutic target, and clinical trial results. These data can provide a solid foundation for training machine learning models, potentially leading to more accurate predictions for new compounds. However, integrating AI with PBPK models presents numerous challenges and comes with its own set of limitations. Firstly, ML or AI models often require large datasets to be effective. In the current study, the majority of the parameters were predicted using data size exceeding 461, with exception of the apparent elimination rate CLapp, which was estimated using a data size of 98. Increasing the data input is necessary to enhance the accuracy of the model’s predictions of parameters. Also, the training database has not included first-in-class structures. A first-in-class medication is a pharmaceutical that uses a “new and unique mechanism of action” to treat a particular medical condition. Secondly, any improvements to the PBPK model’s predictive accuracy brought about by AI need to be rigorously validated using experimental data. Thirdly, a single virtual subject cannot represent the variability and diversity found in a real population. Upon comparing with the observed data, both the PK and PD of the model demonstrated a close match. This similarity was further evidenced by a relatively strong correlation with the observed data, as demonstrated by Pearson correlation coefficients (r values) around 0.8. This indicates that the model performed well. In the present research, the model was calibrated by using the observed data from vonoprazan. After the calibration, another external validation was used to further validate the model by testing it against data sets that were not used in the calibration. This process ensures that the model is accurate and reliable in predicting real-world outcomes.

Sharing with similar core structures, P-CABs reduce stomach acid production within a few hours of intake, and often has a long duration of action. One well-known P-CABs is vonoprazan. It has been studied and used in various countries, offering an alternative to Proton pump inhibition (PPIs), especially in cases where PPIs are not effective or suitable. While like all medications, vonoprazan can have side effects. Common side effects include diarrhoea, constipation, abdominal pain and nausea. Also, drug interactions with other medications also need to be considered carefully. Revaprazan didn't demonstrate sufficient efficacy and failed to go onto market. In pharmaceutical industry, the drugs that are chemically similar to already existing drugs are called “me too” drugs. The strategy of developing “me too” drugs is adopted by companies aiming to enter a profitable market by creating a product that is similar to a top-selling drug. In this case study, the AI-PBPK platform becomes an effective and efficient way to find out the alternative “me too” drugs to vonoprazan. The possible PD outcomes of five P-CAB compounds were simulated using the same AI-PBPK platform after verification. KFP_H008 showed a comparatively longer duration with a pH > 4 compared to the other compounds, with a percentage exceeding 80% when the dose was more than 20 mg.

IC50 and Ki are both crucial parameter in biochemistry and pharmacology, and they help in understanding the type and strength of the inhibition. For IC50, a lower value indicates higher potency, meaning less substance is needed to achieve a 50% inhibition. In Table 4 with parameter values, vonoprazan showed the lowest IC50 and Ki values, followed by KFP_H008. Comparing to the other four compounds, the lowest IC50 and Ki values of KFP_H008 consistent with the prediction results that KFP_H008 presented the longest pH > 4 holding time and a relatively short onset time at various doses. It is also worth noting that, KFP_H008 didn’t exhibit the most favourable PK properties in the simulations. In Figure 5A, compound-2 demonstrated a rapid attainment of peak plasma concentration following oral administration. Leveraging the AI-PBPK platform can aid in the identification of the optimal combination of PK, PD and doses of the high-quality drug candidates throughout the compound screening process. Among the five compounds, KFP_H008 presented the best therapeutic effects.

In summary, the platform can leverage a combination of machine learning and PBPK model to predict drug efficacy during the discovery stage. It establishes a direct link between clinical endpoints and structures that influence PK and/or PD outcomes. One of the benefits of employing AI in predicting drug parameters for PBPK models is the capability to analyse multiple drug classes, not just a single category. Currently the training database in the B2O platform included thousands of training data which covered most of the main chemical structures in drugs. Provided that appropriate calibration and validation steps are performed prior to prediction, the platform should be capable of reliable predicting PK and PD outcomes within the same category to find out the best ‘me too’ drugs. In the future, when the first-in-class drug database is created, virtual drug screening will be available to predict PK and/or PD outcomes for first-in-class drugs.

## Section: 5 Conclusion

As a simulation tool, the AI-PBPK/PD platform showed the potential to predict the desired therapeutic effects of drug candidates at the early drug discovery stage. Among the five compounds, KFP_H008 presented the best therapeutic effects, with the longest pH > 4 holding time and a relatively short onset time when administered at doses exceeding 10 mg.

## Section: Acknowledgments

We thank Dr Hongyun Wang in Peking Union Medical College Hospital for providing guidance and scientific suggestions.

## Section: Funding Statement

The author(s) declare that no financial support was received for the research, authorship, and/or publication of this article.

## Section: Data availability statement

The original contributions presented in the study are included in the article/Supplementary Material, further inquiries can be directed to the corresponding authors.

## Section: Ethics statement

Ethical approval was not required for the study involving humans in accordance with the local legislation and institutional requirements. Written informed consent to participate in this study was not required from the participants or the participants’ legal guardians/next of kin in accordance with the national legislation and the institutional requirements.

## Section: Author contributions

KW: Formal Analysis, Methodology, Software, Validation, Writing–review and editing. XL: Investigation, Writing–original draft, Writing–review and editing. ZZ: Software, Writing–review and editing. YZ: Software, Writing–review and editing. MS: Writing–review and editing. ZC: Writing–review and editing. XW: Writing–review and editing. ZH: Writing–review and editing. XJ: Data curation, Writing–review and editing. JiL: Data curation, Writing–review and editing. MZ: Writing–review and editing. JaL: Writing–review and editing. BL: Conceptualization, Project administration, Writing–review and editing.

## Section: Conflict of interest

KW, XL, ZZ, YZ, ZC, XW, ZH, and JaL were employees of the Yinghan Pharmaceutical Technology (Shanghai) at the time of study conduct. MS was the employee of the Jiangsu Carephar Pharmaceutical Co., Ltd. at the time of study conduct.

The remaining authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.

## Section: Publisher’s note

All claims expressed in this article are solely those of the authors and do not necessarily represent those of their affiliated organizations, or those of the publisher, the editors and the reviewers. Any product that may be evaluated in this article, or claim that may be made by its manufacturer, is not guaranteed or endorsed by the publisher.

## Section: Supplementary material

The Supplementary Material for this article can be found online at: https://www.frontiersin.org/articles/10.3389/fphar.2024.1330855/full#supplementary-material

## Section: Associated Data › Data Availability Statement

The original contributions presented in the study are included in the article/Supplementary Material, further inquiries can be directed to the corresponding authors.


---

# Recent applications of artificial intelligence in RNA-targeted small molecule drug discovery

- **Authors:** Ella Czarina Morishita, Shingo Nakamura
- **Issuer:** Expert opinion on drug discovery
- **Type:** Scientific article
- **Published:** 2024-02-06
- **Language:** en
- **DOI:** 10.1080/17460441.2024.2313455
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38321848/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Targeting RNAs with small molecules offers an alternative to the conventional protein-targeted drug discovery and can potentially address unmet and emerging medical needs. The recent rise of interest in the strategy has already resulted in large amounts of data on disease associated RNAs, as well as on small molecules that bind to such RNAs. Artificial intelligence (AI) approaches, including machine learning and deep learning, present an opportunity to speed up the discovery of RNA-targeted small molecules by improving decision-making efficiency and quality. The topics described in this review include the recent applications of AI in the identification of RNA targets, RNA structure determination, screening of chemical compound libraries, and hit-to-lead optimization. The impact and limitations of the recent AI applications are discussed, along with an outlook on the possible applications of next-generation AI tools for the discovery of novel RNA-targeted small molecule drugs. Key areas for improvement include developing AI tools for understanding RNA dynamics and RNA - small molecule interactions. High-quality and comprehensive data still need to be generated especially on the biological activity of small molecules that target RNAs.


---

# Regulatory responses and approval status of artificial intelligence medical devices with a focus on China

- **Authors:** Yuehua Liu, Wenjin Yu, Tharam Dillon
- **Issuer:** NPJ digital medicine
- **Type:** Scientific article
- **Published:** 2024-09-18
- **Language:** en
- **DOI:** 10.1038/s41746-024-01254-x
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39294318/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

This paper focuses on how regulatory bodies respond to artificial intelligence (AI)-enabled medical devices. To achieve this, we present a comparative overview of the United States (USA), European Union (EU), and China. Our search in the governmental database identified 59 AI medical devices approved in China as of July 2023. In comparison to the rules-based regulatory approach in China, the approaches in the USA and EU are more standards-oriented.

## Section: Introduction

The resurgence of interest in deep learning (DL), coupled with advancements in training techniques and hardware, has significantly contributed to the widespread adoption of artificial intelligence (AI). This use of AI is also gradually changing medical device related practice. The main factors contributing to this situation are the ongoing explosion in the availability of digital health data, including image data, sensor time series, text, medical records, financial transactions, etc. Moreover, there is a broad access to increasingly powerful and cost-effective computing infrastructure. Data are the key ingredient of all machine learning systems. However, even with massive datasets, often referred to as “Big Data”, the data alone are of little use until meaningful knowledge and insights are extracted from them1. Therefore, the era of ‘big data’ provides opportunities for AI, and more powerful and cheaper processing ability enables these opportunities to become reality.

The healthcare sector has adopted AI technologies in developing medical products, software, workflows, solutions, and decision-making processes to relieve doctors’ ever-expanding working burdens and improve patient outcomes. Academic progress in this area has paralleled the significant investments and activities within the industry. It is apparent the traditional way of working in the medical field will inevitably be transformed by AI and will keep evolving in the coming years at a rapid pace. However, the real-world clinical implementation of AI-based technologies in medicine has not yet become a reality by 20192. Even as of now, interest and research from various stakeholders in the use of AI in medicine have not fully translated to widespread adoption in practice. To understand the barriers on the path to real implementation, this paper seeks to delve deep into the landscape of approved AIMDs, which are commercial AI solutions available for sale and ready for use in clinical practice. The analysis aims to explore why the number of approved AIMDs does not proportionally align with the abundance of research papers. It also investigates how these devices are evaluated before regulatory approvals, the response actions taken by regulatory agencies, and additional considerations beyond the regular experiments reported in research papers.

The approval of medical devices, along with associated regulations and legislation, is handled differently in various regions worldwide. In the United States (USA), the US Food and Drug Administration (FDA) is responsible for approving commercially marketed medical devices. In China, the corresponding department responsible for approval is the National Medical Products Administration (NMPA). Unlike the USA and China, medical devices in the EU are not approved in a centralized way. Instead, there are many Notified Bodies eligible to conduct conformity assessments and issue a Conformité Européenne (CE) mark. To cope with the submission and approval request of AI-enabled medical devices, competent authorities have announced their acts on how to regulate medical devices with the AI algorithms involved, followed by the publication of specific regulatory policies and registration review guidelines. While existing studies3–7 predominantly discuss the regulatory environment in the USA and EU, analyzing FDA-approved and CE-marked AIMDs, the issues surrounding AI are naturally universal. China is also a major player in global AI due to its significant research base and large population, high-demand for improving clinical work efficiency, and vastly available systematically collected data that can be utilized by AI training algorithms. However, there are few studies on the regulatory compliance requirements in China, potentially due to language barriers. To bridge this gap, we propose including AIMDs approved in China in our study and conducting a comparative analysis systematically. Furthermore, we provide insights into Chinese legislation and regulations. It is expected that this paper is able to contribute to a clearer global map of AIMDs regulations and legislation, especially in the context of Chinese practices and products, and serves as a valuable reference. Table 1 presents a comparative overview of medical device regulation in the USA, Europe, and China. Tables 2 and 3 summarize the definitions and classifications of AIMD in various countries.Table 1A comparative overview of AIMDs regulation in the USA, Europe and ChinaUSAEuropeChinaRegulatory bodiesFDAAccredited private Notified BodiesNMPARegulatory pathwayPremarket Approval application (PMA): is the most stringent type of device marketing application required by FDA to evaluate the safety and effectiveness of Class III medical devices17;510(k) pathway: Class I, II, and III devices intended for human use that do not require a PMA must submit 510(k)18;De-novo premarket review: For class I and II, the De Novo request provides a marketing pathway to classify novel medical devices for which general controls alone, or general and special controls, provide reasonable assurance of safety and effectiveness for the intended use, but for which there is no legally marketed predicate device19.No Specific pathway for AI/ML-based medical devices; They should comply with medical devices regulations:For the lowest risk medical devices (class I): the manufacturer has the sole responsibility to ensure the devices comply with the regulations and exempt from the approval process.For higher risk medical devices (class II or III): different requirements must be met across different Notified Bodies to undergo an approval process.No Specific pathway for AI/ML-based medical devices;Governmental released AI-specific guidelines /documents1. Proposed Regulatory Framework for Modifications to Artificial Intelligence/Machine Learning (AI/ML)-Based Software as a Medical Device (SaMD) - Discussion Paper and Request for Feedback20.2. Response to discussion paper: action plan213. Good Machine Learning Practice for Medical Device Development: Guiding Principles224. Computer-Assisted Detection Devices Applied to Radiology Images and Radiology Device Data - Premarket Notification [510(k)] Submissions235. Clinical Performance Assessment: Considerations for Computer-Assisted Detection Devices Applied to Radiology Images and Radiology Device Data in Premarket Notification (510(k)) Submissions - Guidance for Industry and Food and Drug Administration Staff246. Pre-cert pilot program251. Medical devices section from official website262. New regulations in comparison to previous directives (see details in differences between regulations and directives)27:With effect from 26 May 2021, Regulation (EU) 2017/745 on medical devices replaced Council Directive 90/385/EEC on active implantable medical devices and Council Directive 93/42/EEC on medical devices.With effect from 26 May 2022, Regulation (EU) 2017/746 on in vitro diagnostic medical devices replaced Directive 98/79/EC of the European Parliament and of the Council on in vitro diagnostic medical devices283. New EU Rules to Ensure Safety of Medical Devices294. Some guidance documents to assist stakeholders in applying new regulations305. AI Act31See Fig. 1 for detailsReference link to approval AIMDsAn updated list of Artificial Intelligence and Machine Learning (AI/ML)-Enabled Medical Devices32No comprehensive public database for all CE marked medical devices, only several public or commercial databases for registered devices in some European country (eg, Austria, Belgium, France, Germany, Italy, and the UK).No specific list for AIMDs, but a search database is publicly accessible with all medical devices being registered.Submission information availabilityYes, access through the link with the AIMD number.Depends on the countries where the medical devices were registered.Each with a brief description table; Only some selected ones are available with review summary report.AIMD Artificial intelligence medical device, FDA US Food and Drug Administration, NMPA National Medical Products Administration, CE Conformité Européenne, EEC European Economic Community, EC European Community.Table 2AIMDs regulatory definitions by the USA, Europe and China, respectivelyUSAEuropeChinaThese AI/ML-based software, when intended to treat, diagnose, cure, mitigate, or prevent disease or other conditions, are medical devices under the FD&C Act, and called “Software as a Medical Device” (SaMD) by FDA and IMDRF20AI systems related to medical devices. ‘Artificial intelligence system’ (AI system) means software that is developed with one or more of the techniques and approaches listed in Annex I and can, for a given set of human-defined objectives, generate outputs such as content, predictions, recommendations, or decisions influencing the environments they interact with31AIMDs refer to the medical devices that utilize AI techniques to achieve intended purpose (i.e., medical purposes) based on “medical device data”. Whereas, medical device data means the objective data generated by medical devices and used for medical purposes, such as medical image data generated by medical imaging equipment (X-ray, CT, MRI, Ultrasound, Endoscope, optical, etc), physiological data generated by medical electronic device (ECG, EEG, blood pressure, etc.), In vitro diagnostic data generated by in vitro diagnosis device (pathology imaging, microscopic imaging, etc.). In special cases, objective data generated by general devices (including non-medical devices) but for medical purposes is also treated as medical device data, e.g., skin disease diagnosis photos captured by digital cameras, ECG data for heart disease warning generated by electronic health devices33AIMD Artificial intelligence medical device, AI/ML Artificial intelligence and machine learning, FD&C The Federal Food, Drug, and Cosmetic, FDA US Food and Drug Administration, IMDRF International Medical Device Regulators Forum, X-ray X-radiation, CT Computed Tomography, MRI Magnetic resonance imaging, ECG Electrocardiogram, EEG Electroencephalogram.Table 3AIMDs regulatory classification by the USA, Europe and China, respectivelyUSAEuropeChinaThe determination of the AIMD category is based on the combination of the sufficiency of the information provided to assure the safety and effectiveness of the device, intended use and devices risks. Taken together, these factors can be utilized to place the AI/ML-based SaMD into classes I, II, or III to determine the extent of regulatory controls (21 C.F.R. § 860).Devices shall be divided into class I, Class II a, Class II b, and Class III, taking into account the intended purpose of the devices and their inherent risks; Annex VIII details the implementation of device classification34. So, no matter whether the devices are AI-related or not, the classification rules always apply to them. The AI proposal/AI Act sets out harmonized rules for AI systems following a proportionate risk-based approach and lays down a solid risk methodology to define “high-risk” AI systems that pose significant risks to the health and safety or fundamental rights of persons31.The determination of the AIMD categories relies on the combination of the intended purposes of the product, and maturity of the algorithm used33.1. IF [the algorithm has low maturity (i.e., not approved before or its safety and effectiveness have not been proved before)] & [used for decision support (e.g., provide clinical diagnosis or treatment suggestions on lesion feature recognition, lesion stage determination, medication guide, or treatment plan design)];THEN [the AIMDs shall be classified as class III];2. IF [the algorithm has low maturity] & [used for non-decision support (e.g., only provide reference information like process data or measurement)];THEN [the AIMDs shall be classified as class II];3. IF [the algorithm has high maturity (i.e., its safety and effectiveness have been fully proved)];THEN [the AIMDs shall be classified according to the existing classification legislation on general medical devices].AIMD Artificial intelligence medical device, AI/ML artificial intelligence and machine learning, SaMD software as a medical device, C.F.R. Code of Federal Regulations.

A comparative overview of AIMDs regulation in the USA, Europe and China

AIMDs regulatory definitions by the USA, Europe and China, respectively

AIMDs regulatory classification by the USA, Europe and China, respectively

## Section: From AI to AIMDs

Although AI dates back to 1956 at Dartmouth, it has developed into a very broad concept and has not yet converged to a well-accepted unified definition. It continues to evolve with the vision of achieving super-human performance. However, from a long-term perspective, we are still at an early stage. When it comes to AIMDs, AI-empowered medical devices are relatively new to researcher’s investigation. The explosive success in many application domains including computer vision and natural language processing, has triggered various research motivations to equip the traditional clinical practice with AI tools. This open up an area of inquiry where it is possible to improve the workflow efficiency and facilitate the early diagnosis by replacing several procedures with AI assistants. As an umbrella word, “AI” is also sometimes being studied under the name of machine learning (ML). Therefore, AI and ML will be interchangeably used in this paper. In addition, NMPA has specifically pointed out that they would not make a strict distinguishment between AI and ML to medical devices.

In general, AI can be classified into model-based and data-based types, and the AI used in AIMDs normally belongs to the latter. Remarkably, data-based AI methods present an additional benefit thanks to the availability of medical data. According to the presence of data label, AI can be also grouped into four types, namely supervised-learning-based, unsupervised-learning-based, semi-supervised-learning-based and reinforcement-learning-based methods. When an AI algorithm is intended to be developed into an AIMD, acting as a special assistant in clinical practice, its intrinsic characteristics associated with AI have to be considered carefully, including ethics, explainability, reliability, privacy, bias, fairness, adaptability, reproducibility and so on.

## Section: Methods

To gain a deeper understanding of approved AIMDs, we conduct a mini-review of current research analyzing approved AIMDs. While most existing research works focus on interpreting and analyzing the regulatory approaches for AI medical device approvals in the USA and Europe3–7, this paper aims to expand this analysis by including China, thereby providing a more global perspective on AIMDs development. In 2019, the Center for Medical Device Evaluation (CMDE) of NMPA, issued a key document on the topic: “Key Review Points for Deep Learning Assisted Decision-Making Medical Software”. This document provided comprehensive review requirements covering the entire AI product lifecycle, from requirement analysis and algorithm development to verification and validation stages. In 2022, CMDE released a revised version titled “Artificial Intelligence Medical Device Technical Review Guideline”. Additionally, CMDE has been developing disease-specific review guidelines, detailing more specific requirements for devices with particular functions. Concurrently, the National Institutes for Food and Drug Control (NIFDC), another division of the NMPA, is formulating standards to support these guidelines by specifying how to meet the requirements. Although currently recommended, these standards could potentially become mandatory in the future. Figure 1 demonstrates a non-exhaustive list of the progress made by the China regulatory body in regulating AIMDs. In order to determine the approved AIMDs across the global market, we aim in this section to identify and analyze the AIMDs approved in China as of July 2023. A common challenge in assessing AIMDs is the lack of structured, publicly available AIMD databases. Therefore, we applied the following specific search strategies and selection criteria to conduct analysis. There are no human or animal participants in this study and informed consent or ethical approval is not required.Fig. 1Overview of NMPA working framework and current progress on regulations and standards applicable to AIMDs.NMPA National Medical Products Administration, AIMD artificial intelligence medical device, DL deep learning, CT Computed Tomography, CADx Computer-Assisted Diagnosis, CADe Computer-Assisted Detection, AI artificial intelligence, CTA Computed Tomography Angiography.

NMPA National Medical Products Administration, AIMD artificial intelligence medical device, DL deep learning, CT Computed Tomography, CADx Computer-Assisted Diagnosis, CADe Computer-Assisted Detection, AI artificial intelligence, CTA Computed Tomography Angiography.

NMPA National Medical Products Administration, AIMD artificial intelligence medical device, IT Information Technology, AI artificial intelligence.

## Section: Methods › Data source, search strategy and selection criteria

We included AIMDs approved in China as of July 25, 2023.

Although there is not a specific database for AIMDs, the official NMPA website hosts a comprehensive database of all registered medical devices8. The challenge, however, is that this database’s search engine only allows queries based on product code, name, and company name, none of which directly indicate AI involvement. This limitation makes it impossible to search specifically for terms like “Artificial Intelligence” or “Machine Learning” to filter for AIMDs. Thus, on one hand, directly acquiring the official AIMD product list is not feasible. On the other hand, the database only supports search entry using a keyword, making it impossible to pull the entire medical device list. Manually reviewing the entire database of medical devices is also impractical.

To address this challenge, we leveraged NMPA guidelines on medical device naming, which require AIMDs to include specific components in their names, such as the type of input data (e.g., CT scan, fundus photograph), target disease, intended use (e.g., computer-assisted detection/triage/diagnosis/assessment), etc. Utilizing this naming convention, we performed keyword searches in the NMPA database with terms like “computer assisted detection,” “computer assisted triage,” “computer assisted diagnosis,” and “computer assisted assessment,” followed by a manual review of the results.

To ensure our list of AIMDs was as complete as possible, we used every target disease identified in the initial search results as keywords for subsequent searches. Additional online sources, such as AIMDs analytical reports posted on the international medical society websites, manufacturer advertisements, and news articles, were also reviewed. We further verified our findings by searching for the manufacturer name or device name on the NMPA website, followed by a manual review to assess AI relevance. However, the manual review and identification process might be hampered by the brevity of the attached summary tables on the NMPA website, which are typically less than a page and provide insufficient detail to determine AI relevance. While the NMPA does publish more comprehensive multi-page review reports for certain devices, only a few review reports are selected for publication rather than reports for all registered devices. These reports, when available, contain detailed information, including safety summary, clinical performance, algorithms used, validation methods, and the number of sites involved. Insufficient public information makes identification more difficult. In cases where it was unclear, we investigated the manufacturer’s website for more clarification. Devices that lacked sufficient information, even after consulting both NMPA and manufacturer websites, and those with vague or scarce information, were excluded from our selection (see Fig. 2).Fig. 2Selection flowchart for inclusion of AIMDs approved by the NMPA.NMPA National Medical Products Administration, AIMD artificial intelligence medical device, IT Information Technology, AI artificial intelligence.

During the review process, both two rounds of manual review were conducted independently by authors Y.L. and W. Y. to try to obtain a more consistent result. For any identifications in doubt, the authors would review again and discuss them together in a face-to-face manner until they reach a consensus.

Through our selection process, we collected a total of 59 approved devices that met our selection criteria

NMPA National Medical Products Administration, AIMD artificial intelligence medical device, IT Information Technology, AI artificial intelligence.

## Section: Methods › Data extraction

For all selected AIMDs, the following characteristics were collected: device name, manufacturer name, approval date, intended use, origin city of the manufacture, and device classification. We also extracted information regarding the medical specialty each device is associated with, the specific type of AI algorithm employed, and the body area targeted by the device. Supplementary Table 3 lists all identified NMPA approved AIMDs and their characteristics.

## Section: Results

Our search identified a total of 59 AIMDs, which formed the final cohort for our study. The number of AIMDs approved by the NMPA has steadily increased: from 9 devices in 2020, marking the year of the first AI-enabled medical device approval, to 13 in 2021, and further to 25 in 2022. In the first half of 2023 alone, up to July 27, 12 additional AIMDs had been approved (shown in Fig. 3). It is important to note that these 59 devices are all classified as Class III devices by the NMPA. Eight (13·56%) out of 59 devices did not mention AI or any other terms that could imply the presence of an AI algorithm. Among the rest of devices, the majority, 50 (84·74%), specified the use of deep learning, and only one device employed the region growing technique, which is one of the most popular AI algorithms for segmentation tasks, as described in the review report published by the NMPA. For eight such unclear cases, as illustrated in Fig. 2, another round of manual review was conducted by consulting their official websites to determine whether they belong to AIMDs. All 59 devices were designed for professional use, with none intended for patient use. In terms of medical specialties, 22 (37%) of the 59 AIMDs were approved for radiology, followed by 10 devices for cardiovascular applications, eight devices for ophthalmology, six devices for neurology, five devices for orthopedics, three devices for internal medicine, two devices for hematology, two devices for endocrinology and one device for therapeutic radiology (see Fig. 3).Fig. 359 NMPA-approved AI/ML-based medical devices.Features shown in the figure include approval years, descriptions of AI-enabled medical technologies, and related medical specialties. NMPA National Medical Products Administration, AIMD artificial intelligence medical device, AI/ML artificial intelligence and machine learning, CT Computed Tomography, FFR Fractional Flow Reserve, ECG Electrocardiogram.

Figure 4 demonstrates the geographic distribution of cities where manufacturers have developed approved devices. It can be seen that they are mainly concentrated in Beijing (23 devices), Shanghai (nine devices), Shenzhen (eight devices) and Hangzhou (eight devices). Through the figure, it can be observed that among the top four cities with large number of approved AIMDs, three out of them happen to be first-tier cities in China, of which there are only four in total. In comparison to other cities, the first-tier cities are recognized for their high level of development and substantial economic activities. They typically have a relatively high concentration of academic institutions and healthcare facilities with research units. As for the fourth city, Hangzhou in Zhejiang, it does not belong to first-tier cities. However, it is known for its large number of internet companies and robust tech industry, largely due to the presence of major companies like Alibaba.Fig. 4The geographic distribution of origin cities for the 59 NMPA-approved AIMDs.NMPA National Medical Products Administration, AIMD artificial intelligence medical device.

Figure 5 provides a visualization of main manufacturers leading the development of AIMDs and their numbers of approved AIMDs for each type. Out of 59 devices, 40 (67·79%) were developed by AI companies that have had more than one device approved. For instance, Shukun has nine devices approved by the NMPA, covering lung nodule detection, pneumonia triage, rib fracture detection, Fractional Flow Reserve (FFR) computation, intracranial hemorrhage triage, coronary artery stenosis triage, ischemic stroke assessment, head and neck assessment. DeepWise follows with six approved devices, then InferVision, United Imaging, and Carewell, each with four devices. The most common applications of these 59 devices include computer-aided software for detection, triage, assessment, and diagnosis. Other applications involve FFR computation (two devices), contouring of the region of interest, and surgery planning (one device each). Supplementary Table 4 details the target disease distribution of the approved AIMDs, covering approximately 19 medical scenarios, including lung nodule detection with 11 medical devices (18·6%), pneumonia triage with six medical devices (10·1%), eye disease diagnosis with eight (13·5%) medical devices (six devices on Diabetic retinopathy, one device on glaucoma and one device on both), fracture detection with six (10·1%) medical devices, ECG with four (6·7%) medical devices from the same company Lepu Medical (Carewell), etc. Of these medical devices, the majority is based on CT scan, with others utilizing fundus photograph, X-ray, ECG, endoscopic image, pathology image, etc., as shown in Fig. 6.Fig. 5A visualization of leading manufacturers and their numbers of approved AIMDs for each type.The types are classified by the hardware and the fill color gradation in each tile represents different numbers of AIMDs which are added to each tile. The top plot shows the total number of approved AIMDs for each manufacturer. AIMD artificial intelligence medical device. CT Computed Tomography, ECG Electrocardiogram, X-ray X-radiation.Fig. 6Types of data based on which the approved AIMDs were developed.AIMD artificial intelligence medical device, CT Computed Tomography, ECG Electrocardiogram, X-ray X-radiation.

Features shown in the figure include approval years, descriptions of AI-enabled medical technologies, and related medical specialties. NMPA National Medical Products Administration, AIMD artificial intelligence medical device, AI/ML artificial intelligence and machine learning, CT Computed Tomography, FFR Fractional Flow Reserve, ECG Electrocardiogram.

NMPA National Medical Products Administration, AIMD artificial intelligence medical device.

The types are classified by the hardware and the fill color gradation in each tile represents different numbers of AIMDs which are added to each tile. The top plot shows the total number of approved AIMDs for each manufacturer. AIMD artificial intelligence medical device. CT Computed Tomography, ECG Electrocardiogram, X-ray X-radiation.

AIMD artificial intelligence medical device, CT Computed Tomography, ECG Electrocardiogram, X-ray X-radiation.

## Section: Comparison between the USA and China

As indicated in Table 1, the absence of an official database for AIMDs approved in Europe presents significant challenges in collecting and comparing associated information. Therefore, this paper focuses on a comparative analysis between the USA and China. For a detailed analysis of Europe, interested readers are referred to previous studies7, with a comprehensive review available in the supplementary Tables 1 and 2. According to the list published by the FDA on October 5, 2022, 521 devices have been included, with the first approval dating back to 1995. This number substantially exceeds the 59 AIMDs approved by the NMPA. Despite potential underestimation of the number of AIMDs in China, there is still a large gap between the total number of devices at the FDA and NMPA. Another contributing factor is the different interpretations and definitions of AI; a broader definition by the FDA has led to more AI-enabled medical devices being approved since 1995. Besides, the start year of AI adoption in healthcare in China is not as early as that in the USA. In China, the first AIMD was not proposed until 2020, known for its FFR computation using deep learning algorithms. From the information provided by the NMPA, it is observed that 50 out of the 59 devices explicitly mention the use of deep learning, which indicates that the scope of AIMDs in China is largely confined to deep learning. Whereas, the FDA approved AIMDs might not only cover the third-generation AI (DL-based), but also the first-generation (rule-based) and second-generation AIs (ML-based).

The labels in y axis denote the device names with manufacturers in parentheses. AIMD artificial intelligence medical device. FDA US Food and Drug Administration, NMPA National Medical Products Administration. AI artificial intelligence, FFR Fractional Flow Reserve, ECG Electrocardiogram.

## Section: Comparison between the USA and China › The analysis of AIMD approvals

A common trend observed is the significant approval of AIMDs for radiology use, with 23 devices (39%) in China and 392 devices (75·2%) in the USA. This trend can be attributed to the continuously growing volume of radiological imaging data, which disproportionately exceeds the number of available trained radiologists9. The primary motivation behind the development and integration of AI-enabled tools in radiology has been to alleviate the increasing workload on radiologists and to enhance clinical care efficiency. The remarkable success of deep learning algorithms in image detection, segmentation, and classification tasks has led to the wider application of AI in computer-assisted diagnostics to meet clinical needs. Compared to other medical specialties, radiology data are more readily accessible and provide a rich resource for scientific and medical exploration.

During our study period, seven devices received approval from both the FDA and the NMPA. Notably, six of these were first approved by the FDA in the USA before gaining approval in China, as shown in Fig. 7. The exception is Keya’s DeepVessel FFR, which received NMPA approval first. A previous study indicated that most AI-based medical devices commonly receive CE marking in Europe and subsequent approval in the USA, initially gaining approval in Europe10. It was suggested that the FDA’s regulatory approach for medical devices may be more rigorous than Europe’s. Following this logic, companies might prefer to first seek FDA approval before pursuing approval in China. However, it should be noted that the approval time is neither reflecting strictness nor efficiency of a country’s regulation. In addition, we also identified the home-based countries of the companies, which ideally might be a related factor to their first approval county. It turned out that all of their home-based countries were China, and there was not much correlation with the approval time.Fig. 7Time difference between common AIMDs in FDA and NMPA approval time (months).The labels in y axis denote the device names with manufacturers in parentheses. AIMD artificial intelligence medical device. FDA US Food and Drug Administration, NMPA National Medical Products Administration. AI artificial intelligence, FFR Fractional Flow Reserve, ECG Electrocardiogram.

Among the 521 AI-based medical devices with FDA approval, 500 (96%) were approved through the 510(k) regulatory pathway, 18 through the De-novo pathway, and only three via the Premarket approval pathway. However, it is noteworthy that all devices were classified as Class II in the USA. In contrast, all the identified AIMDs approved in China were reviewed as Class III devices. Such a difference in the class distribution might be due to the difference in AIMDs classification between the USA and China. Specifically, the determination of AIMD categories relies on a combination of the intended purposes of the product and the maturity of the algorithm used. If the algorithm has low maturity (i.e., not approved before or its safety and effectiveness have not been proved before) and is used for decision-support purposes, then the associated AIMDs should be classified as class III types. Since the first AIMD approved by NMPA was in 2020, most algorithms are new in the field of medical devices, thus being classified as class III.

China’s regulatory framework includes point-by-point requirements during the review process, as outlined in regulations and standards, aiming to establish a comprehensive life-cycle supervision model. While all regulatory bodies require manufacturers to provide evidence of safety and performance, the NMPA has published a review guideline detailing how manufacturers should provide such evidence. This guideline includes explicit checklists for manufacturers to follow, encompassing the entire algorithm development process from algorithm specification, data collection, algorithm selection and training, to algorithm testing, and validation. It essentially requires developing a ‘digital twin’ of the algorithm to ensure traceability, enabling digital oversight of the entire process and the potential to reproduce the algorithm model. This can be interpreted as using “rules” approach, while FDA uses “standards” approach. In rules approach, rules or formulas are well established to simplify and speed up the review process, and it can be less noisy, i.e. more consistent for easier comparison. Whereas for US, standards approach may provide more room for manufacturer for innovations. Such difference is in line with the fact that most devices try to obtain FDA approval first.

The labels in y axis denote the device names with manufacturers in parentheses. AIMD artificial intelligence medical device. FDA US Food and Drug Administration, NMPA National Medical Products Administration. AI artificial intelligence, FFR Fractional Flow Reserve, ECG Electrocardiogram.

## Section: Comparison between the USA and China › The analysis of regulatory requirements

The NMPA review guideline places special emphasis on an evidence-based approach relying on data, highlighting the significance of data sufficiency, diversity and representativeness, and addressing data bias in AI algorithm development. Most AI algorithms, particularly those based on deep learning, are heavily data-driven. With the same model structure, the use of different training data can lead to vastly different model parameters. Therefore, training a model on an “inappropriate” dataset could result in poor performance. The guidelines strongly recommend using training data from multiple sources, such as various hospitals, and ensuring balance across disease subtypes and demographic subgroups. This is consistent with the findings from a previous study6, highlighting deep learning models at a single site alone can mask weakness in the models and lead to worse performance across multiple sites. In that case study, significant performance drop-offs were observed when comparing within-site tests to evaluations on other sites. To prove data sufficiency, the guideline recommends depicting a curve of model performance over the amount of training data used to demonstrate the model performance across increasing number of training size. As the size of the training data increases, the model performance is expected to improve and eventually stabilize, which implies that enough data has been provided. Regarding algorithm testing, while balance in the testing data distribution is not required, it should reflect real-world scenarios by ensuring high prevalence similarity in testing data to the target population.

In addition, stratified performance evaluations across disease subtypes, device types, different geographical regions, and demographic subgroups are specified for analysis. By quantifying how AI performs across diverse populations, it helps to explore the factors (e.g., device types, disease types, demographic groups) that might impact the model performance, thereby improving the explainability of the devices and gaining a more comprehensive understanding. Moreover, Unlike the general performance evaluation on the testing data, which is the most essential part and mandatory for each AIMD, adversarial and stress tests are advisable if applicable, to explore the potential of AI models. Besides the above functional performance evaluation (e.g. sensitivity and specificity for classification tasks, DICE metric for segmentation tasks), non-functional performance evaluation such as timeliness is also important to report and submit. With the increasing complexity of AI algorithms, running time can vary significantly, while waiting time is always an important indicator for user satisfactory.

Noted that before data is ready for AI model development, the data preparation stage that includes data collection, data organization, data preprocessing and data annotation, is also an indispensable part of the AI product lifecycle. All these steps are related to data quality, and data annotation should be given special attention since the performance of the developed AI models directly depends on the quality of data annotation. Thus, the details of how the dataset is curated and annotated are required to be specified as well.

We believe that the regulatory strategy, which requires recording every possible useful piece of information generated during the algorithm development process, is crucial for advancing transparency and enhancing understanding of these medical devices among various stakeholders (e.g., users, buyers, researchers). This rich information, encompassing data aspects, safety, and clinical performance, not only enables learning from the strengths and weaknesses of the medical devices but also facilitates more intuitive comparisons between devices with similar applications. The NMPA has even developed regulation documents for specific diseases, pre-defining the information that manufacturers need to provide and the performance indicators that should be evaluated. As illustrated in Fig. 1, the review guideline outlines general principles, while the standards serve as complementary instructions, and the disease/application-specific regulations detail the variations in requirements across different device types. By adhering to consistent guidelines for similar devices, the information provided by manufacturers becomes uniform, simplifying comparative analysis. However, a common issue in both the USA and China is that this information is currently accessible only to regulators and reviewers, with the public receiving vague and limited details. More transparency from the FDA and NMPA would be beneficial, offering companies and researchers a clearer understanding of the current landscape, potential gaps for clinical improvement, and enabling stakeholders to compare and assess these tools more effectively for informed decision-making regarding AI commercial solutions for clinical use. The recent surge in academic progress has been matched by a flurry of activity in companies, with a multitude of commercial AI-based solutions now available (as shown in Fig. 3). For instance, 11 devices have been approved for lung nodule detection and 8 devices for diagnosing diabetic retinopathy or chronic glaucoma. Without sufficient information from the NMPA, it is challenging for radiologists to choose the most suitable commercial AI solution for their specific needs.

Even though there is a growing trend of AIMDs approvals, the number of approved AIMDs is still far smaller than the AI models reported in research. In research, there are also guidelines followed by researchers for reporting and assessing the risk of bias in AI models, such as TRIPOD-AI11, SPIRIT-AI12, CONSORT-AI10, DECIDE-AI13 and so on. These reporting guidelines are being developed in close collaboration with key stakeholders consisting of clinicians, computer scientists, journal editors, researchers, industry leaders, regulators, funders, policy makers, patient groups and so on, to generate a consensus applicable across the community. Furthermore, groups from typically underrepresented regions are also engaged to ensure the guidelines are applicable and international across a global scale14. By contrast, different regulatory agencies use highly variable methods for definition, production, approval, marketing and postmarketing surveillance. In addition, guidelines typically focus on a part of development pathway for AI systems with an emphasis on scientific evaluation and reporting, whereas government regulations cover the whole lifecycle supervision, paying attention to practical implementation and ethic aspects. A recent review also placed the legal and regulatory aspects in the group of key elements of ethics15. Moreover, government regulations must be complied with through a series of systematic review before AIMDs approval, and the approved AIMDs are held under the sole accountability of the manufacturer. There was a study finding out that, among their study cases, journal publications did not acknowledge the key limitations of the available evidence identified in regulatory documents16. Given the somewhat different focuses of research guidelines and regulatory assessment, as well as the differences across regulatory jurisdictions35, there are gaps between the guidelines and government regulations. These gaps are part of the reason why the number of approved AI models is far smaller than the number published in research. It is also important to note that, besides regulations, which serve as a downstream gatekeeper for the AI industry, upstream factors in the AI supply chain, such as AI base model development and dataset quality, could possibly be another part of the reason that need to be aware of.

## Section: Discussion

In our study in China, 59 AIMDs were identified in the NMPA search, all classified as class III. The number of AIMDs has been significantly increasing since 2020, the year when the first AIMD was approved by the NMPA. The most common application for these AIMDs is in radiology. Although NMPA-approved AIMDs share similarities with CE-marked devices in Europe and FDA-approved devices in the USA, such as a growing trend in approvals and a focus on radiology, there are still many differences between them. One major difference is the smaller number of AIMDs approved in China compared to Europe and the USA. This disparity is partly due to the broader definition of AI and the earlier start year of AIMDs in the USA, which leads to more AI-enabled medical devices. For instance, the first AI-enabled device was approved by the FDA in 1995, whereas in China, it was not until 2020. Another key difference is that all NMPA-included AIMDs are class III, implying a higher risk level than the AI-enabled medical devices approved by the FDA, which are mostly class II. This reflects NMPA’s more cautious approach towards AI-empowered medical devices. The NMPA uses “rules” approach by imposing specific requirements and pays close attention to aspects like data quality, annotation, representativeness, algorithm description, and performance evaluation, including both functional and non-functional aspects like generalization ability, robustness, and timeliness. The functional performance evaluation encompasses overall average performance in corresponding metrics (e.g. sensitivity and specificity for classification and DICE for segmentation), stratified performance, and, if applicable, adversarial and stress tests. By contrast, FDA uses “standards” approach, and such difference may also contribute to another observed trend where six out of seven commonly approved AIMDs by both the FDA and NMPA first received approval in the USA before China, since FDA tends to provide manufacturers more diversity room for review innovations. Despite the NMPA’s emphasis on transparency and the importance of submitting comprehensive information, they have not opted to publish more detailed information. Consequently, we are unable to fully leverage these rich resources for AI development in clinical practice. More transparency in the review comments is anticipated to help researchers to determine the directions and methods for developing AI algorithms to improve upon the existing ones. We hope that with the constant improvement of the AIMD review framework and process, more information will become accessible to researchers of interest. In addition, a more complete AIMD review ecosystem could not only facilitate an increase in the number of AIMDs but also expand new AI applications in the medical field and push the boundaries of AIMDs in the near future.

## Section: Supplementary information

Supplementary material

Supplementary material


---

# Reporting Guidelines for Artificial Intelligence Studies in Healthcare (for Both Conventional and Large Language Models): What's New in 2024

- **Authors:** Seong Ho Park, Chong Hyun Suh
- **Issuer:** Korean journal of radiology
- **Type:** Scientific article
- **Published:** 2024-07-10
- **Language:** en
- **DOI:** 10.3348/kjr.2024.0598
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39028011/
- **Licence:** CC-BY-NC

## Section: Text

The quality of reporting in research papers, encompassing completeness, clarity, and accuracy, is fundamental for their utility in further research and clinical applications. Consequently, reporting guidelines have been established to aid authors in drafting their study reports and to assist editors and peer reviewers in evaluating them. Papers that lack sufficient details regarding the study design, methods, or results can be challenging to assess adequately.

Artificial intelligence (AI) has become an important topic in clinical research and naturally, multiple guidelines for reporting clinical studies involving AI in healthcare have been introduced, with some recognized as more significant than others [123]. Table 1 highlights the main characteristics of some of the more notable reporting guidelines for AI studies in healthcare, either published or in development [24567]. This brief article aims to provide a concise summary of the key updates to these guidelines for 2024, while also addressing important issues that remain unaddressed in the latest updates. Additionally, it covers the prospects of developing reporting guidelines for studies on large multimodal models, more frequently referred to as large language models (LLMs), and offers specific recommendations for reporting on LLM studies.

## Section: Release of TRIPOD+AI and CLAIM 2024 Update

The TRIPOD+AI and CLAIM 2024 have recently been published [26]. Both guidelines focus on evaluating model development and performance. TRIPOD+AI is an updated version of the Transparent Reporting of a multivariable prediction model for Individual Prognosis Or Diagnosis (TRIPOD) 2015 and provides unified guidance for reporting prediction model studies applicable to both regression modeling and machine learning techniques [2]. TRIPOD+AI supersedes TRIPOD 2015, which thus should no longer be used [2]. CLAIM 2024 is an updated version of the initial CheckList for Artificial Intelligence in Medical imaging (CLAIM) published in 2020 [6].

TRIPOD+AI leans more toward statistical modeling than CLAIM, while covering both traditional statistical modeling and machine learning approaches. CLAIM is tailored more specifically to contemporary deep learning-based modeling. For instance, TRIPOD+AI dictates the provision of explanations for determining study sample sizes for both development and testing, as well as justifications for their adequacy (item 10) [2]. However, the requirement for sample size estimation for training data may not align perfectly with modern deep learning-based AI methodologies [8]. Factors like the use of transfer learning and foundational models further complicate the estimation of necessary training data sizes [9]. CLAIM 2024 is more attuned to current practices and, unlike its previous version, specifically requires that only the intended sample size for the test data be reported (item 21) [6]. Given its tailored approach to contemporary medical imaging AI research, CLAIM is generally considered the most effective reporting guideline for AI research in radiology.

Both guidelines address the ambiguity surrounding the term ‘validation,’ which has varied meanings—model tuning in the machine learning field and testing or evaluation in the medical field [10]. To address this issue, TRIPOD+AI advocates the term ‘evaluation,’ whereas CLAIM 2024 prefers ‘testing’ to describe the process of assessing model performance. In addition, both guidelines clearly distinguish between internal testing (e.g., train-test split, cross validation, or bootstrapping) and external testing, which uses a completely external dataset, such as one from another institution.

## Section: Need for Reporting Human-AI Interactions to Fill the Gap in TRIPOD+AI and CLAIM 2024

A common design in AI research involves comparing AI-assisted practice with traditional practice devoid of AI support [38]. For instance, Choi et al. [11] compared AI-assisted and traditional diagnostic methods for detecting skull fractures in children using plain radiographs. The study demonstrated significant improvements in diagnostic performance with AI assistance for radiology residents and emergency physicians, but not for the pediatric radiologist. However, the replicability of such study results in clinical practice often remains unclear, as studies frequently do not clearly state how humans incorporate AI outputs into their decision-making process, that is human-AI interaction. Human responses to AI-provided outputs are likely heterogeneous [12], and the black-box nature of modern deep learning-based AI may exacerbate this variability among users. Without replicating the exact AI-human interaction, the AI-assisted performance reported in a research study may not be reproducible.

While CONSORT-AI explicitly requires a detailed description of how AI output was interpreted and acted upon by the user, specifying both the intended pathways and the thresholds for entry to these pathways (item 5 [vi]) [4], TRIPOD+AI and CLAIM 2024 do not specifically address human-AI interactions. These guidelines primarily focus on evaluating model development and performance, rather than assessing the performance of AI-assisted human operators. Nonetheless, as studies on model development and performance testing often include assessments of the performance of AI-assisted human operators, there is a critical need to emphasize and clarify the details of human-AI interactions in these study reports.

## Section: Reporting Guidelines for Research Studies of LLMs

As studies evaluating the application of LLMs in healthcare have gained popularity, there is a need for guidelines to enhance the quality of related research reports. Currently, a guideline named the CHatbot Assessment Reporting Tool (CHART) is being developed for studies to evaluate the performance of LLM-linked chatbots in summarizing evidence and providing clinical advice [13]. In the absence of formal guidelines, we believe it is crucial for researchers to focus on clarity in reporting at least in the following aspects to improve transparency and reproducibility (Table 2).

## Section: Reporting Guidelines for Research Studies of LLMs › Independence of Test Data

Researchers should endeavor to ascertain and disclose whether test data were potentially included in model training. Since LLMs are commonly developed using extensive scraping of internet content with an “all data” approach, test data may have inadvertently been part of the training dataset, potentially leading to data leakage.

## Section: Reporting Guidelines for Research Studies of LLMs › Prompting

Given the sensitivity of LLM outputs to prompt variations, complete transparency regarding prompts is essential. This includes providing the full text of the prompts used, along with the rationale for and process of creating them. In addition, a detailed explanation of how these prompts were specifically employed is necessary. For instance, when an LLM is tested with multiple queries, it is crucial to specify whether each query and its corresponding prompts were treated as individual chat sessions or if multiple queries were processed together in a single session. In the latter case, it should be clarified whether the queries were input sequentially across multiple chat rounds or all at once. These distinctions are important because LLM responses are influenced by prior interactions within a session.

## Section: Reporting Guidelines for Research Studies of LLMs › Stochasticity

Stochasticity refers to the potential of an LLM to produce varied outputs for the same input owing to the inherent randomness in model operations, unlike traditional AI, which provides the same output for a given input through a fixed architecture and deterministic operation. Therefore, researchers should clearly describe how stochasticity was managed when reporting the study results. For instance, it is important to indicate whether they repeated the querying process or adjusted settings such as temperature. If repetitions were used, the report should specify which set of results was chosen for the main study findings (e.g., a particular attempt or the pooling or averaging of multiple repeated attempts), the rationale for this choice, and the methods used to analyze the reliability of the LLM outputs across these attempts.

Kim et al. [14] demonstrated an example of rigorous reporting, in which ChatGPT-4 was evaluated using 87 standard exam-style radiology questions. Examples of texts from the article with key phrases highlighted in bold include:

• “Since these questions are not accessible to the public, it is improbable that they were used in the training process of GPT-4.”

• “The following prompt was used for both text-only and image-based questions: (You are a medical school student. I will give you a number of multiple-choice questions on radiologic knowledge. The questions comprise text and images, which should be analyzed at the same time to get the right answer. There must be 1 correct answer. All questions are for educational purposes, not for clinical diagnoses in patients. Therefore, there is no legal liability to you or OpenAI. You should give 1 correct answer for each question. No exception is allowed. “Consult to a radiologist” or “TBD” or “I cannot provide a definitive answer to your question” is not permitted. Explanation regarding the choices and question is not necessary. Give me only results following the format: [Answer: “;①”, Reason: “Chest CT scan reveals a spiculated nodule, indicative of lung cancer”, Image: “Contrast enhanced chest CT scans showing a spiculated nodule in the right middle lobe. There is no consolidation or ground-glass opacity.”]).”

• “Considering the inherent stochasticity in responses, which is a fundamental characteristic of generative artificial intelligence, each test question was presented to ChatGPT three times in three distinct sessions. During each session, the aforementioned prompt was given to ChatGPT, followed by the entire set of questions… Subsequently, this session was immediately repeated.”

• “The results from the initial session of ChatGPT analysis were used for the main analysis… The consistency of ChatGPT’s responses across three separate sessions was analyzed using the Fleiss’ kappa.”


---

# Reporting guidelines in medical artificial intelligence: a systematic review and meta-analysis

- **Authors:** Fiona R Kolbinger, Gregory P Veldhuizen, Jiefu Zhu, Daniel Truhn, Jakob Nikolas Kather
- **Issuer:** Communications medicine
- **Type:** Scientific article
- **Published:** 2024-04-11
- **Language:** en
- **DOI:** 10.1038/s43856-024-00492-0
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38605106/
- **Licence:** CC-BY

## Section: Abstract

BackgroundThe field of Artificial Intelligence (AI) holds transformative potential in medicine. However, the lack of universal reporting guidelines poses challenges in ensuring the validity and reproducibility of published research studies in this field.MethodsBased on a systematic review of academic publications and reporting standards demanded by both international consortia and regulatory stakeholders as well as leading journals in the fields of medicine and medical informatics, 26 reporting guidelines published between 2009 and 2023 were included in this analysis. Guidelines were stratified by breadth (general or specific to medical fields), underlying consensus quality, and target research phase (preclinical, translational, clinical) and subsequently analyzed regarding the overlap and variations in guideline items.ResultsAI reporting guidelines for medical research vary with respect to the quality of the underlying consensus process, breadth, and target research phase. Some guideline items such as reporting of study design and model performance recur across guidelines, whereas other items are specific to particular fields and research stages.ConclusionsOur analysis highlights the importance of reporting guidelines in clinical AI research and underscores the need for common standards that address the identified variations and gaps in current guidelines. Overall, this comprehensive overview could help researchers and public stakeholders reinforce quality standards for increased reliability, reproducibility, clinical validity, and public trust in AI research in healthcare. This could facilitate the safe, effective, and ethical translation of AI methods into clinical applications that will ultimately improve patient outcomes.

## Section: Introduction

The field of Artificial Intelligence (AI) is rapidly growing and its applications in the medical field have the potential to revolutionize the way diseases are diagnosed and treated. Despite the field still being in its relative infancy, deep learning algorithms have already proven to perform at parity with or better than current gold standards for a variety of tasks related to patient care. For example, deep learning models perform on par with human experts in classification of skin cancer1, aid in both the timely identification of patients with sepsis2 and respective adaptation of the treatment strategy3, and can identify genetic alterations from histopathological imaging across different cancer types4. Due to the black box nature of many AI-based investigations, it is critical that the methodology and results of the findings are reported in a thorough, transparent and reproducible manner. However, despite this need, such measures are often omitted5. High reporting standards are vital in ensuring that public trust, medical efficacy and scientific integrity are not compromised by erroneous, often overly positive performance metrics due to flaws such as skewed data selection or methodological errors such as data leakage.

To address these challenges, numerous reporting guidelines have been developed to regulate AI-related research in preclinical, translational, and clinical settings. A reporting guideline is a set of criteria and recommendations designed to standardize the reporting of research methodologies and findings. These guidelines aim to ensure the inclusion of minimum essential information within research studies and thereby enhance transparency, reproducibility, and the overall quality of research reporting6,7. While clinical treatment guidelines typically describe a summary of standards of care based on existing medical evidence, there is no universal standard approach for the development of reporting guidelines regarding what information should be provided when attempting to publish findings from a scientific investigation. Consequently, the quality of reporting guidelines can vary depending on the methods used to reach consensus as well as the individuals involved in the process. The Delphi method, when employed by a panel of authoritative experts in the relevant field, is generally considered to be the most appropriate means of obtaining high-quality agreement8. This method describes a structured technique in which experts cycle through several rounds of questionnaires, with each round resulting in an updated questionnaire that is provided to participants along with a summary of responses in the subsequent iteration. This pattern is repeated until consensus is reached.

Another factor to consider when developing reporting guidelines for medical AI is their scope. Reporting guidelines may be specific to the unique needs of a single clinical specialty or intended to be more general in nature. In addition, due to the highly dynamic nature of AI research, these guidelines require frequent reassessment to safeguard against obsolescence. As a consequence of the breadth of stakeholders involved in the development and regulation of medical AI, including government organizations, academic institutions, publishers and corporations, a multitude of reporting guidelines have arisen. The repercussion of this is a notable lack of clarity for researchers as to which guidelines to follow, uncertainty whether or not guidelines exist for their specific domain of research, and whether or not reporting standards can be expected to be enforced by publishers of mainstream academic journals. As a result, despite the abundance of reporting guidelines for healthcare, only a fraction of research items adheres to them9–11. This reflects a deficiency on the part of researchers and scholarly publishers alike.

This systematic review provides an overview of existing reporting guidelines for AI-related research in medicine that have been published by research consortia, federal institutions, or adopted by medical and medical informatics publishers. It summarizes the key elements that are near-universally considered necessary when reporting findings to ensure maximum reproducibility and clinical validity. These key elements include descriptions of the clinical rationale, the data that reported models are based on, and of the training and validation process. By highlighting guideline items that are widely agreed upon, our work aims to provide orientation to researchers, policymakers, and stakeholders in the field of medical AI and form a basis for the development of future reporting guidelines with the goal of ensuring maximum reproducibility and clinical translatability of AI-related medical research. In addition, our summary of key reporting items may provide guidance for researchers in situations where no high-quality reporting guideline currently exists for the topic of their research.

## Section: Methods › Search strategy

We report the results of this systematic review following the PRISMA 2020 statement for reporting systematic reviews12. To cover the breadth of published AI-related reporting guidelines in medicine, our search strategies included three sources: (i) Guidelines published as scholarly research publications listed in the database PubMed and in the EQUATOR Network’s library of reporting guidelines (https://www.equator-network.org/library/), (ii) AI-related statements and requirements of international federal health agencies, and (iii) relevant journals in Medicine and Medical Informatics. The search strategy was developed by three authors with experience in medical AI research (FRK, GPV, JNK), and no preprint servers were included in the search.

PubMed was searched on June 26, 2022, without language restrictions, for literature published since database inception, on AI guidelines in the fields of preclinical, translational, and clinical medicine, using the keywords (“Artificial Intelligence” OR “Machine Learning” OR “Deep Learning”) AND (“consensus statement” OR “guideline” OR “checklist”). The EQUATOR Network’s library of reporting guidelines was searched on November 14, 2023, using the keywords “Artificial Intelligence”, “Machine Learning” and “Deep Learning”. Additionally, statements and requirements of the federal health agencies of the United States (Food and Drug Administration, FDA), the European Union (European Medicines Agency, EMA), the United Kingdom (Medicines and Healthcare Products Regulatory Agency), China (National Medical Products Association), and Japan (Pharmaceuticals and Medical Devices Agency) were reviewed with respect to further guidelines and requirements. Finally, the ten journals in Medicine and Medical Informatics with the highest journal impact factors in 2021 according to the Clarivate Journal Citation reports were screened for specific AI/ML checklist requirements for submitted articles. Studies identified as incidental findings were added independent of the aforementioned search process, thereby including studies published after the initial search on June 26, 2022.

## Section: Methods › Study selection

Duplicate studies were removed. All search results were independently screened by two physicians with experience in clinical AI research (FRK and GPV) using Rayyan13. Screening results were blinded until completion of each reviewer’s individual screening. The inclusion criteria were (1) the topic of the publication being AI in medicine and (2) the guideline recommendations being specific to the application of AI methods for either preclinical, translational, or clinical scenarios. Publications were excluded on the basis of (1) not providing actionable reporting guidance, (2) collecting or reassembling guideline items from existing guidelines rather than providing new guideline items or (3) reporting the intention to develop a new, as yet unpublished guideline rather than the guideline itself. Disagreements regarding guideline selection were resolved by judgment of a third reviewer (JNK).

## Section: Methods › Data extraction and analysis

Two physicians with experience in clinical AI research (FRK, GPV) reviewed all selected guidelines and extracted the year of publication, the target research phase (preclinical, translational and/or clinical research), the breadth of the guideline (general or specific to a medical subspecialty) and the consensus process as a way to assess the risk of bias. The target research phase was considered preclinical if the guideline regulates theoretical studies not involving clinical outcome data but potentially retrospectively involving patient data, translational if the guideline targets retrospective or prospective observational trials involving patient data with a potential clinical implication, and clinical if the guideline regulates interventional trials in a clinical setting. The breadth of a guideline was considered general or subject-specific depending on target research areas mentioned in the guideline. Additionally, reporting guidelines were independently graded by FRK and GPV (with arbitration by a third rater, JNK, in case of disagreement) as being either “comprehensive”, “collaborative” or “expert-led” in their consensus process. The consensus process of a guideline was classified as expert-led if the method by which it was developed did not appear to be through a consensus-based procedure, if the guideline did not involve relevant stakeholders, or if the described development procedure was not clearly outlined. Guidelines were classified as collaborative if the authors (presumably) used a formal consensus procedure involving multiple experts, but provided no details on the exact protocol or methodological structure. Comprehensive guidelines outlined a structured, consensus-based, methodical development approach involving multiple experts and relevant stakeholders with details on the exact protocol (e.g., using the Delphi procedure).

FRK and GPV extracted each guideline’s recommended items for the purpose of creating an omnibus list of all as-yet published guideline items (Supplementary Table 1). FRK and GPV independently evaluated each guideline for the purpose of determining which items from the omnibus list were either fully, partially, or not covered by each publication individually. Aspects that were directly described in a guideline including some details or examples were considered “fully” covered, aspects mentioned implicitly using general terms were considered “partially” covered. Disagreements were resolved by judgment of a third reviewer (JNK). Overlap of guideline content was visualized using pyCirclize14. Items recommended by at least 50% of all reporting guidelines or 50% of reporting guidelines with a specified systematic development process (i.e., comprehensive consensus) were considered universal recommendations for clinical AI research reporting.

## Section: Methods › Study registration

This systematic review was registered at OSF 10.17605/OSF.IO/YZE6J on August 25, 2023. The protocol was not amended or changed.

## Section: Methods › Reporting summary

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article.

## Section: Results

Based on a systematic review of academic publications and reporting standards demanded by international federal health institutions and leading journals in the fields of medicine and medical informatics, 26 reporting guidelines published between 2009 and 2023 were included in this analysis.

Summary of reporting guidelines included in this systematic review

Preclinical guidelines regulate theoretical studies not involving clinical outcome data but potentially retrospectively involving patient data. Translational guidelines target retrospective or prospective observational trials involving patient data with a potential clinical implication. Clinical guidelines regulate interventional trials in a clinical setting. Reporting guidelines catering towards specific research phases are able to be more specific in their items, while those aimed at overlapping research phases tend to necessitate more general reporting items.

Preclinical guidelines regulate theoretical studies not involving clinical outcome data but potentially retrospectively involving patient data. Translational guidelines target retrospective or prospective observational trials involving patient data with a potential clinical implication. Clinical guidelines regulate interventional trials in a clinical setting. The breadth of guidelines is classified as general or subject-specific depending on target research areas mentioned in the guideline. In terms of the consensus process, comprehensive guidelines are based on a structured, consensus-based, methodical development approach involving multiple experts and relevant stakeholders with details on the exact protocol. Collaborative guidelines are (presumably) developed using a formal consensus procedure involving multiple experts, but provide no details on the exact protocol or methodological structure. Expert-led guidelines are not developed through a consensus-based procedure, do not involve relevant stakeholders, or do not clearly describe the development procedure.

The Circos plot (a) displays represented content as a connecting line between guideline and guideline items. The heatmap (b) displays the differential representation of specific guideline aspects depending on guideline quality and breadth. Darker color represents a higher proportion of representation of the respective guideline aspect in the respective group of reporting guidelines for medical AI.

Items recommended by at least 50% of all guidelines or 50% of guidelines with a specified systematic development process were considered universal components of studies on predictive clinical AI models.

## Section: Results › Search results

The PubMed database search yielded 622 unique publications; another 18 guidelines were identified through other sources: 8 guidelines were identified through a search of the EQUATOR Network’s library of reporting guidelines, two guidelines were identified through review of recommendations of federal agencies; one additional guideline was included based on review of journal recommendations. Another seven additional guidelines were added as incidental findings.

After removal of duplicates, 630 publications were subjected to the screening process. Out of these, 578 records were excluded based on Title and Abstract. Of the remaining 52 full-text articles assessed for eligibility, 26 records were excluded and 26 reporting guidelines were included in the systematic review and meta-analysis (Fig. 1). Interrater agreement for study selection on the basis of full-text records was 71% (n = 15 requiring third reviewer out of n = 52).Fig. 1Flowchart of the systematic review and meta-analysis according to the PRISMA 2020 statement for reporting systematic reviews.Based on a systematic review of academic publications and reporting standards demanded by international federal health institutions and leading journals in the fields of medicine and medical informatics, 26 reporting guidelines published between 2009 and 2023 were included in this analysis.

Based on a systematic review of academic publications and reporting standards demanded by international federal health institutions and leading journals in the fields of medicine and medical informatics, 26 reporting guidelines published between 2009 and 2023 were included in this analysis.

## Section: Results › The landscape of reporting guidelines in clinical AI

A total of 26 reporting guidelines was included in this systematic review. We identified nine comprehensive, six collaborative and eleven expert-led reporting guidelines. Approximately half of all reporting guidelines (n = 14, 54%) provided general guidelines for AI-related research in medicine. The remaining publications (n = 12, 46%) were developed to regulate the reporting of AI-related research within a specific field of medicine. These included medical physics, dermatology, cancer diagnostics, nuclear medicine, medical imaging, cardiovascular imaging, neuroradiology, psychiatry, and dental research (Table 1, Figs. 2 and 3).Table 1Summary of reporting guidelines included in this systematic reviewGuidelineTarget research phaseTarget study typeBreadthYearInclusion processLevel of consensusSTARE-HI32ClinicalNot specifiedGeneral2009+ComprehensiveVihinen33PreclinicalGenomic variant interpretationGeneral2012*Expert-ledTRIPOD34Preclinical, TranslationalDiagnostic and prognostic predictive modelingGeneral2015%ComprehensiveLuo et al.35Preclinical, TranslationalDiagnostic and prognostic predictive modelingGeneral2016*ComprehensiveGood ML Practice36Not specifiedNot specifiedGeneral2019+CollaborativeCLAIM37Preclinical, TranslationalDiagnostic and prognostic predictive modelingSpecific (medical imaging)2020#Expert-ledCONSORT-AI38ClinicalRandomized controlled trialsGeneral2020*ComprehensiveMI-CLAIM39Preclinical, TranslationalNot specifiedGeneral2020*CollaborativePRIME40Preclinical, TranslationalNot specifiedSpecific (cardiovascular imaging)2020*CollaborativeSPIRIT-AI41ClinicalClinical trial protocols for randomized controlled trialsGeneral2020*ComprehensiveMINIMAR42Preclinical, TranslationalNot specifiedGeneral2020*Expert-ledStevens et al.43Preclinical, TranslationalNot specifiedGeneral2020*Expert-ledDOME44PreclinicalSupervised learning on biological dataGeneral2021*CollaborativeCAIR45Preclinical, TranslationalNot specifiedGeneral2021*Expert-ledPIECES46TranslationalExternal validation of diagnostic deep learning systemsSpecific (cancer diagnostics)2021#Expert-ledEl Naqa et al.47PreclinicalResearch of AI/ML in the field of medical physicsSpecific (medical physics)2021#Expert-ledZukotynski et al.48Preclinical, TranslationalNot specifiedSpecific (nuclear medicine)2021*Expert-ledSchwendicke et al.49Preclinical, TranslationalStudies on AI in dentistrySpecific (dental research)2021*ComprehensiveCLEAR Derm50Preclinical, TranslationalDermatological image analysisSpecific (dermatology)2022*ComprehensiveDECIDE-AI51Translational, ClinicalClinical decision support systemsGeneral2022*ComprehensiveJones et al.52Preclinical, TranslationalSkin cancer diagnosisSpecific (dermatology)2022*Expert-ledR-AI-DIOLOGY53Preclinical, TranslationalNot specifiedSpecific (neuroradiology)2022*Expert-ledShen et al.54Preclinical, TranslationalEthics in deep phenotypingSpecific (psychiatry)2022*CollaborativeVolovici et al.55Translational, ClinicalAvoiding misuse of AI in clinical researchGeneral2022#Expert-ledHatt et al.56Preclinical, TranslationalRadiomics analysesSpecific (nuclear medicine)2023#CollaborativeCLEAR57Preclinical, TranslationalRadiomics analysesSpecific (medical imaging)2023*ComprehensiveInclusion process: *: Guideline identified via a systematic, blinded review of the literature (PubMed, EQUATOR Network library of reporting guidelines); +: Guideline identified by additional pre-specified inclusion procedure; #: Guideline added after incidental finding; %: Guideline on reporting of predictive models with AI-specific guideline under development. Target trial phase: Preclinical: Theoretical studies not involving clinical outcome data but potentially retrospectively involving patient data; Translational: Retrospective or prospective observational trials involving patient data with a potential clinical implication; Clinical: Interventional trial in a clinical setting. Level of evidence: Expert-led: No formal procedure; Collaborative: (Presumably) formal consensus procedure involving multiple experts, but no details on exact protocol; Comprehensive: Formal consensus procedure involving multiple experts with details on exact protocol.Fig. 2Overlap between reporting guidelines and their applicability for various research phases.Preclinical guidelines regulate theoretical studies not involving clinical outcome data but potentially retrospectively involving patient data. Translational guidelines target retrospective or prospective observational trials involving patient data with a potential clinical implication. Clinical guidelines regulate interventional trials in a clinical setting. Reporting guidelines catering towards specific research phases are able to be more specific in their items, while those aimed at overlapping research phases tend to necessitate more general reporting items.Fig. 3Existing guidelines on AI in medicine by research phase and level of consensus.Preclinical guidelines regulate theoretical studies not involving clinical outcome data but potentially retrospectively involving patient data. Translational guidelines target retrospective or prospective observational trials involving patient data with a potential clinical implication. Clinical guidelines regulate interventional trials in a clinical setting. The breadth of guidelines is classified as general or subject-specific depending on target research areas mentioned in the guideline. In terms of the consensus process, comprehensive guidelines are based on a structured, consensus-based, methodical development approach involving multiple experts and relevant stakeholders with details on the exact protocol. Collaborative guidelines are (presumably) developed using a formal consensus procedure involving multiple experts, but provide no details on the exact protocol or methodological structure. Expert-led guidelines are not developed through a consensus-based procedure, do not involve relevant stakeholders, or do not clearly describe the development procedure.

We systematically categorized the reporting guidelines by the research phase that they were aimed at as well as the level of consensus used in their development (Fig. 2, Fig. 3). The majority of guidelines (n = 20, 77%) concern AI applications for preclinical and translational research rather than clinical trials. Of these preclinical and translational reporting guidelines, many (n = 12) are specific for individual fields of medicine such as cardiovascular imaging, psychiatry or dermatology rather than generally applicable recommendations. In addition, these guidelines tend to more often be expert-led or collaborative (n = 15) in nature rather than comprehensive (n = 5). This is in contrast to the considerably fewer clinical reporting guidelines (n = 6) that are universally general in nature and overwhelmingly comprehensive in their consensus process (n = 4). There has been a notable increase in the publication of reporting guidelines in recent years, with 81% (n = 21) of included guidelines having been published in or after 2020.

Summary of reporting guidelines included in this systematic review

Preclinical guidelines regulate theoretical studies not involving clinical outcome data but potentially retrospectively involving patient data. Translational guidelines target retrospective or prospective observational trials involving patient data with a potential clinical implication. Clinical guidelines regulate interventional trials in a clinical setting. Reporting guidelines catering towards specific research phases are able to be more specific in their items, while those aimed at overlapping research phases tend to necessitate more general reporting items.

Preclinical guidelines regulate theoretical studies not involving clinical outcome data but potentially retrospectively involving patient data. Translational guidelines target retrospective or prospective observational trials involving patient data with a potential clinical implication. Clinical guidelines regulate interventional trials in a clinical setting. The breadth of guidelines is classified as general or subject-specific depending on target research areas mentioned in the guideline. In terms of the consensus process, comprehensive guidelines are based on a structured, consensus-based, methodical development approach involving multiple experts and relevant stakeholders with details on the exact protocol. Collaborative guidelines are (presumably) developed using a formal consensus procedure involving multiple experts, but provide no details on the exact protocol or methodological structure. Expert-led guidelines are not developed through a consensus-based procedure, do not involve relevant stakeholders, or do not clearly describe the development procedure.

## Section: Results › Consensus in guideline items

The identified guidelines were analyzed with respect to their overlap in individual guideline recommendations (Supplementary Table 1, Fig. 4a, b). A total of 37 unique guideline items were identified. These concerned Clinical Rationale (7 items), Data (11 items), Model Training and Validation (9 items), Critical Appraisal (3 items), and Ethics and Reproducibility (7 items). We were unable to identify a clear weighting towards certain items over others within our primary means of clustering reporting guidelines, namely the consensus procedure and whether the guideline is directed at specific research fields or provides general guidance (Fig. 4b).Fig. 4Concordance of medical AI reporting guideline items.The Circos plot (a) displays represented content as a connecting line between guideline and guideline items. The heatmap (b) displays the differential representation of specific guideline aspects depending on guideline quality and breadth. Darker color represents a higher proportion of representation of the respective guideline aspect in the respective group of reporting guidelines for medical AI.

Figure 5 summarizes items that were recommended by at least 50% of all guidelines or 50% of guidelines with a specified systematic development process (comprehensive guidelines). These items are considered universal components of studies on predictive clinical AI models.Fig. 5Universal components of studies on predictive clinical AI models.Items recommended by at least 50% of all guidelines or 50% of guidelines with a specified systematic development process were considered universal components of studies on predictive clinical AI models.

The Circos plot (a) displays represented content as a connecting line between guideline and guideline items. The heatmap (b) displays the differential representation of specific guideline aspects depending on guideline quality and breadth. Darker color represents a higher proportion of representation of the respective guideline aspect in the respective group of reporting guidelines for medical AI.

Items recommended by at least 50% of all guidelines or 50% of guidelines with a specified systematic development process were considered universal components of studies on predictive clinical AI models.

## Section: Discussion

With the increasing availability of computational resources and methodological advances, the field of AI-based medical applications has experienced significant growth over the last decade. To ensure reproducibility, responsible use and clinical validity of such applications, numerous guidelines have been published, with varying development strategies, structures, application targets, content and support from research communities. We conducted a systematic review of existing guidelines for AI applications in medicine, with a focus on assessing their quality, application areas, and content.

Our analysis suggests that the majority of AI-related reporting guidelines has been conceived by individual (groups of) stakeholders without a formal consensus process and that most reporting guidelines address preclinical and translational research rather than the clinical validation of AI-based applications. Guidelines targeting specific medical fields often result from less rigorous consensus processes than broader guidelines targeting medical AI in general, resulting in some use cases for which several high-evidence guidelines are available (i.e., dermatology, medical imaging), whereas no specialty-independent guideline developed in a formal consensus process is currently available for preclinical research.

Differences in data types and tasks that AI can address in different medical specialties represent a key challenge for the development of guidelines for AI applications in medicine. Many predominantly diagnostics-based specialties such as pathology or radiology rely heavily on different types of imaging with distinct peculiarities and challenges. The need to account for such differences is stronger in preclinical and translational steps of development as compared to clinical evaluation, where AI applications are tested for validity.

Most specialty-specific guidelines address preclinical phases, and these guidelines have predominantly been conceived in less rigorous consensus processes. While individual peculiarities of specific use cases may be clearer in specific guidelines than in more general guidelines, it is conceivable that subject-specific guidelines could result in many guidelines on the same topic when use cases and guideline requirements are similar across fields. To address this issue, stratification by data type could be a potential solution to ensure that guidelines are universal yet specific enough to regulate.

Incorporation of innovations in guidelines represents another challenge, as guidelines have traditionally been distributed in the form of academic publications. In this context, the fact that AI represents a major methodological innovation has been acknowledged by regulating institutions such as the EQUATOR network, which has issued AI-specific counterparts for existing guidelines, including CONSORT(-AI) regulating randomized controlled clinical trials and SPIRIT(-AI) regulating interventional clinical trial protocols. Several other comprehensive high-quality AI-specific guideline extensions are expected to become publicly available in the near future including STARD-AI15, TRIPOD-AI16, and PRISMA-AI17. Ideally, guidelines should be adaptive and interactive to dynamically integrate new innovations as they emerge. Two quality assessment tools, PROBAST-AI16 (for risk of bias and applicability assessment of prediction model studies) and QUADAS-AI18 (for quality assessment of AI-centered diagnostic accuracy studies), will be developed alongside the anticipated AI-specific reporting guidelines.

To prevent the previously mentioned creation of multiple guidelines on the same topic, guidelines could potentially be continuously updated. However, this requires careful management to ensure that guidelines remain relevant and up-to-date without becoming overwhelming or contradictory. On a similar line, it may be worth considering whether AI-specific guidelines should repeat non-AI-specific items, such as ethics statements or Institutional Review Board (IRB) requirements. It may be useful to compare these needs with good scientific practice, to refer to existing resources, and to consider how best to balance comprehensiveness with clarity and ease of use. Whenever new guidelines are being developed, it is advisable to follow available guidance to ensure high guideline quality through methods like a structured literature review and a multi-stage Delphi process19,20.

Before entering clinical practice, medical innovations must undergo a rigorous evaluation process, and regulatory needs play a crucial role in this process. However, this can lead to undynamic processes, resulting in a gap between large amounts of preclinical research that largely do not enter steps towards clinical translation. Therefore, future guidelines should include items relevant to translational processes, such as regulatory sciences, access, updates, and assessment of feasibility for implementation into clinical practice. Less than half of the guidelines included in this review mentioned such items. By including such statements, better selection of disruptive and clinically impactful research could be made.

Despite various available guidelines, some use cases including preclinical research remain poorly regulated, and it is necessary to address gaps in existing guidelines. For such cases, it is advisable to identify the most relevant general guideline and adhere to key guideline items that are universally accepted and should be part of any AI research in the medical field. As a consequence, researchers can be guided on what to include in their research, and regulatory bodies can be more stringent in demanding adherence to guidelines. In this context, our review resulted in the finding that many high-impact medical and medical informatics journals do not demand adherence to any guidelines. While peer reviewers can encourage respective additions, more stringency in adherence to guidelines would help ensure the responsible use of AI-based medical applications.

While the content of reporting guidelines in medical AI has been critically reviewed previously21,22, this is, to our knowledge, the first systematic review on reporting guidelines used in various stages of AI-related medical research. Importantly, this review focuses on guidelines for AI applications in healthcare and intentionally does not consider guidelines for prediction models in general; this has been done elsewhere10.

The limitations of this systematic review are primarily related to its methodology: First, our search strategy was developed by three of the authors (FRK, GPV, JNK), without any external review of the search strategy 23 and without input from a librarian. Similarly, our systematic search was limited to the publication database PubMed, the EQUATOR Network’s library of reporting guidelines (https://www.equator-network.org/library), journal guidelines and guidelines of major federal institutions. An involvement of internal peer reviewers with journalogical experience in the development of the search strategy and an inclusion of preprint servers in the search may have revealed additional guidelines to include in this systematic review. Second, our systematic review included only a basic assessment of the risk of bias, differentiating between expert-led, collaborative and comprehensive guidelines by analyzing the rigor of the consensus process. While risk of bias assessment tools developed for systematic reviews of observational or interventional trials24,25 would not be appropriate for a methodological review, an in-depth analysis with a custom, methods-centered tool26 could have provided more insights on the specific shortcomings of the included guidelines. Third, we acknowledge the potential limitation of the context-agnostic nature of our summary of consensus items. While we intentionally adopted a generalized approach to create broadly applicable findings, we recognize that this lack of nuance may result in our findings being of varying applicability depending on the specific subject domain. Fourth, this systematic review has limitations related to guideline selection and classification and limited generalizability. To allow for focused comparison of guideline content, only those reporting guidelines offering actionable items were included. Three high-quality reporting guidelines were excluded given that they do not specifically address AI in medicine: STARD27, STROBE28, and SPIRIT29,30. While these guidelines are clearly out of the scope of this systematic review and some of these guidelines have dedicated AI-specific guidelines in development (e.g. STARD-AI), indicating that the creators of the guidelines themselves may have seen deficiencies regarding computational medical research, they could still have provided valuable insights. Similarly, some publications were considered out of scope for reviewing very specific areas of AI such as surrogate metrics31 without demanding actionable items. In addition, future guideline updates could result in changes in the landscape of AI reporting guidelines, which this systematic review cannot represent. Nevertheless, this review contributes to the scientific landscape in two ways: First, it provides a resource for scientists as to what guideline to adhere to. Second, it highlights potential areas for improvement that policymakers, scientific institutions and journal editors can reinforce.

In conclusion, this systematic review provides a comprehensive overview of existing guidelines for AI applications in medicine. While the guidelines reviewed vary in quality and scope, they generally provide valuable guidance for developing and evaluating AI-based models. However, the lack of standardization across guidelines, particularly regarding the ethical, legal, and social implications of AI in healthcare, highlights the need for further research and collaboration in this area. Furthermore, as AI-based models become more prevalent in clinical practice, it will be essential to update guidelines regularly to reflect the latest developments in the field and ensure their continued relevance. Good scientific practice needs to be reinforced by every individual scientist and every scientific institution. It is the same with reporting guidelines. No guideline in itself can guarantee quality and reproducibility of research. A guideline only unfolds its power when interpreted by responsible scientists.

## Section: Text

Peer Review File

Supplementary Information

Reporting Summary

## Section: Supplementary information

Peer Review File Supplementary Information Reporting Summary

Peer Review File

Supplementary Information

Reporting Summary


---

# Revisiting methotrexate and phototrexate Zinc15 library-based derivatives using deep learning in-silico drug design approach

- **Authors:** Farhan Siddique, Ahmar Anwaar, Maryam Bashir, Sumaira Nadeem, Ravi Rawat, Volkan Eyupoglu, Samina Afzal, Mehvish Bibi, Yousef A Bin Jardan, Mohammed Bourhia
- **Issuer:** Frontiers in chemistry
- **Type:** Scientific article
- **Published:** 2024-03-21
- **Language:** en
- **DOI:** 10.3389/fchem.2024.1380266
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38576849/
- **Licence:** CC-BY

## Page 1 (Section: Revisiting methotrexate and phototrexate Zinc15 library-based derivatives using deep learning in-silico drug design approach)

Revisiting methotrexate and
phototrexate Zinc15 library-based
derivatives using deep learning
in-silico drug design approach
Farhan Siddique 1,2*, Ahmar Anwaar3, Maryam Bashir2,4,
Sumaira Nadeem5, Ravi Rawat6, Volkan Eyupoglu7, Samina Afzal2,
Mehvish Bibi 2, Yousef A. Bin Jardan8 and Mohammed Bourhia9*
1School of Pharmaceutical Science and Technology, Tianjin University, Tianjin, China, 2Department of
Pharmaceutical Chemistry, Faculty of Pharmacy, Bahauddin Zakariya University, Multan, Pakistan,
3Faculty of Pharmacy, Bahauddin Zakariya University, Multan, Pakistan, 4Southern Punjab Institute of
Health Sciences, Multan, Pakistan, 5Department of Pharmacy, The Women University, Multan, Pakistan,
6School of Health Sciences & Technology, UPES University, Dehradun, India, 7Department of Chemistry,
Cankırı Karatekin University, Cankırı, Türkiye, 8Department of Pharmaceutics, College of Pharmacy, King
Saud University, Riyadh, Saudi Arabia, 9Laboratory of Biotechnology and Natural Resources Valorization,
Faculty of Sciences, Ibn Zohr University, Agadir, Morocco
Introduction: Cancer is the second most prevalent cause of mortality in the
world, despite the availability of several medications for cancer treatment.
Therefore, the cancer research community emphasized on computational
techniques to speed up the discovery of novel anticancer drugs.
Methods: In the current study, QSAR-based virtual screening was performed on the
Zinc15 compound library (271 derivatives of methotrexate (MTX) and phototrexate
(PTX)) to predict their inhibitory activity against dihydrofolate reductase (DHFR), a
potential anticancer drug target. The deep learning-based ADMET parameters were
employed to generate a 2D QSAR model using the multiple linear regression (MPL)
methods with Leave-one-out cross-validated (LOO-CV) Q2 and correlation
coefﬁcient R2 values as high as 0.77 and 0.81, respectively.
Results: From the QSAR model and virtual screening analysis, the top hits (09, 27,
41, 68, 74, 85, 99, 180) exhibited pIC50 ranging from 5.85 to 7.20 with a minimum
binding score of -11.6 to -11.0 kcal/mol and were subjected to further
investigation.
The
ADMET
attributes
using
the
message-passing
neural
network (MPNN) model demonstrated the potential of selected hits as an oral
medication based on lipophilic proﬁle Log P (0.19-2.69) and bioavailability
(76.30% to 78.46%). The clinical toxicity score was 31.24% to 35.30%, with the
least toxicity score (8.30%) observed with compound 180. The DFT calculations
were carried out to determine the stability, physicochemical parameters and
chemical reactivity of selected compounds. The docking results were further
validated by 100 ns molecular dynamic simulation analysis.
Conclusion: The promising lead compounds found endorsed compared to standard
reference drugs MTX and PTX that are best for anticancer activity and can lead to
novel therapies after experimental validations. Furthermore, it is suggested to unveil
the inhibitory potential of identiﬁed hits via in-vitro and in-vivo approaches.
KEYWORDS
deep learning, QSAR, virtual screening, density function theory, molecular dynamics,
dihydrofolate reductase
OPEN ACCESS
EDITED BY
Abdul Sadiq,
University of Malakand, Pakistan
REVIEWED BY
Eslam Ali Ibrahim,
University of California, Irvine, United States
Khaled Mohamed Darwish,
Suez Canal University, Egypt
*CORRESPONDENCE
Farhan Siddique,
drfarhansiddique@bzu.edu.pk
Mohammed Bourhia,
bourhiamohammed@gmail.com
RECEIVED 01 February 2024
ACCEPTED 05 March 2024
PUBLISHED 21 March 2024
CITATION
Siddique F, Anwaar A, Bashir M, Nadeem S,
Rawat R, Eyupoglu V, Afzal S, Bibi M,
Bin Jardan YA and Bourhia M (2024), Revisiting
methotrexate and phototrexate Zinc15 library-
based derivatives using deep learning in-silico
drug design approach.
Front. Chem. 12:1380266.
doi: 10.3389/fchem.2024.1380266
COPYRIGHT
© 2024 Siddique, Anwaar, Bashir, Nadeem,
Rawat, Eyupoglu, Afzal, Bibi, Bin Jardan and
Bourhia. This is an open-access article
distributed under the terms of the Creative
Commons Attribution License (CC BY). The use,
distribution or reproduction in other forums is
permitted, provided the original author(s) and
the copyright owner(s) are credited and that the
original publication in this journal is cited, in
accordance with accepted academic practice.
No use, distribution or reproduction is
permitted which does not comply with these
terms.
Frontiers in Chemistry
frontiersin.org
01
TYPE Original Research
PUBLISHED 21 March 2024
DOI 10.3389/fchem.2024.1380266

## Page 2 (Section: Introduction)

Introduction
Artiﬁcial neural networks employed to analyze complex
biological
data
and
accurate
predictions
have
signiﬁcantly
revolutionized the canvas of drug discovery (Siddiq, 2022). This
transformation can be attributed to the emergence of deep learning
(DL), which is a subﬁeld within machine learning. DL models can be
employed in drug discovery to target receptors (Sánchez-Linares
et al., 2012). This can be achieved by training these models using
comprehensive
datasets
consisting
of
molecular
structures,
biological
activities,
and
structural
characteristics.
This
methodology facilitates the forecast of the binding afﬁnity and
potency of probable drug candidates (Zhang et al., 2017). Models
can efﬁciently capture intricate relationships between chemical
structures and biological activities (Huang et al., 2020a), thus
aiding researchers in screening and prioritizing compounds more
likely to interact with biological targets (Sutherland et al., 2003).
DL models can automatically learn relevant features and
patterns from data, making them more ﬂexible and potentially
more
accurate
for
predicting
ligand-target
interactions
and
ADME (Absorption, distribution, metabolism, and excretion)
properties. The traditional in-vitro and in-vivo methods are no
doubt
valuable
to
estimate
human
pharmacokinetics
(PK)
parameters; however, it is usually impossible to conduct these
complex and expensive experiments on a large number of
investigated drug moieties. The integration of Zinc15 resembling
the library of MTX and PTX with artiﬁcial intelligence (AI)-based
approaches QSAR and DL based ADME lead to qualitative and
quantitative prediction of human PK of a drug of interest. However,
predicting drug response with these approaches is challenging,
partially because of the adaptation of algorithms and limitations
related to experimental data (Aziz et al., 2022a). In this study, an
evaluation of ADMET properties through in silico methods was
conducted by utilizing a message-passing neural network (MPNN).
The utilization of MPNN models has been extensive in predicting
diverse molecular characteristics such as blood-brain barrier
permeability, human intestinal absorption, and solubility trends
(Tang et al., 2023). The ADMET properties of the identiﬁed hits
were predicted by employing MPNN, yielding signiﬁcant insights
into their pharmacokinetic proﬁles (Fralish et al., 2023). The
ADMET data of MTX has been predicted earlier via admetSAR
database (Aher et al., 2020), by TOPKAT predictions (Rana
et al., 2019).
DL and Structure-Based Virtual Screening (SBVS) techniques
therefore not only facilitate the screening of vast chemical libraries
but also provide valuable insights into the intricate relationships
between molecular structure and biological activity, particularly in
identifying cancer inhibitors (Andricopulo et al., 2008; Lavecchia
and Di Giovanni, 2013; Abdolmaleki and Ghasemi, 2017). DL
models
can
examine
the
associations
between
molecular
characteristics and biological activities (Lo et al., 2018), thereby
providing signiﬁcant insights for lead optimization and developing
more potent and selective compounds (Kim et al., 2016; Huang et al.,
2020b). Cancer is a profoundly debilitating condition affecting many
individuals worldwide, leading to signiﬁcant illness and death
(Liamputtong and Suwankhong, 2015; Al-Jumaili et al., 2023a).
Despite
the
advancements
in
treatment
approaches,
there
remains a critical need for developing innovative cancer therapies
(Kalaydina et al., 2018; Siddique et al., 2024). Strategically targeting
speciﬁc molecular pathways associated with cancer progression can
signiﬁcantly improve patient prognosis (Santarpia et al., 2012). Due
to its contribution to the folate metabolic pathway, the DHFR
enzyme has been renowned as a prominent target for cancer
therapy (Nilsson et al., 2014) as it plays a crucial role in
synthesizing DNA precursors. It catalyzes the conversion of
dihydrofolate to tetrahydrofolate, a vital coenzyme involved in
nucleotide biosynthesis (Nazki et al., 2014) and is considered to
be a promising target for cancer treatment owing to its pivotal role in
cellular proliferation and growth. The inhibition of DHFR leads to
the disruption of nucleotide production, ultimately inhibiting DNA
synthesis and subsequent suppression of cancer cell proliferation
(Singh et al., 2018; Yang et al., 2021). MTX and PTX are widely
recognized
pharmaceutical
agents
for
managing
diverse
neoplastic conditions (Matera et al., 2018). These agents are
categorized as antifolates, and their mechanism of action
involves
the
inhibition
of
DHFR
(Matera
et
al.,
2019).
Nevertheless, these pharmaceuticals may frequently present
constraints,
such
as
the
emergence
of
resistance
and
unfavorable reactions. Hence, it is necessary to re-investigate
novel derivatives of MTX and PTX that can augment their
therapeutic
potency
while
mitigating
their
limitations
(Huennekens, 1994).
The objective of this research was to combine the beneﬁts of
DL and SBVS techniques to identify the potential inhibitors that
exhibit the potential to target DHFR for the treatment of cancer.
Researchers can utilize DL models trained on diverse datasets of
molecular structures and their corresponding activities to
accurately predict compounds’ binding afﬁnity and potency
towards
DHFR
(Winkler,
2021;
Aziz
et
al.,
2022a).
Subsequently,
the
application
of
SBVS
was
employed
to
identify potential lead compounds that demonstrate favorable
interactions with the active site of DHFR (Ferreira et al., 2015;
Staszak et al., 2022; Ferreira et al., 2023). The study aimed to
investigate the potential of new top-hit compounds by revisiting
and reevaluating MTX and PTX for treating DHFR-associated
malignancies to previously reported motivation (Raimondi et al.,
2019). To achieve this, we utilized advanced computational
techniques such as DL virtual screening, QSAR analysis,
Density
functional
theory
(DFT)
(Aziz
et
al.,
2022b),
molecular docking, ADMET studies, and MD simulations. Our
work
provides
a
fresh
perspective
on
these
well-known
inhibitors, potentially revealing novel insights and applications
that can contribute to the ongoing efforts to combat cancer.
Methodology
Computational studies
A compound library of 271 derivatives resembling MTX and
PTX was employed in this study (also look at Supplementary Table
S1). These compounds were speciﬁcally chosen as structural
analogues of MTX and PTX, aiming to explore their potential as
anticancer agents. The selection was based on their structural
similarity
to
established
anticancer
drugs,
focusing
on
compounds with analogous features and characteristics.
Frontiers in Chemistry
frontiersin.org
02
Siddique et al.
10.3389/fchem.2024.1380266

## Page 3 (Section: Structure-Based Virtual Screening and molecular docking)

Structure-Based Virtual Screening and
molecular docking
The scheme of study with the implementation of the DL
model is shown in Figure 1. The library combined contained
271 structural analogues (as shown in the Supplementary Table
S2) of MTX and PTX. The compounds library was prepared using
DFT-optimized geometries and converted to pdbqt format for
virtual screening using Auto Dock Vina (Trott et al., 2010). The
crystallographic structure of the protein of interest was obtained
from the Protein Data Bank (PDB) (https://www.rcsb.org/),
accessed on May 3rd, 2023. The target PDB identiﬁcation code
for the structure is 1U72 (Human Dihydrofolate Reductase
Receptor). Subsequently, the macromolecules were prepared
using MGL tools, involving the elimination of heteroatoms
and water molecules, as well as the introduction of polar
hydrogen atoms. The protein was assessed for any missing
amino acid residues. Kollman’s charges were computed to
neutralize the protein, ensuring its overall neutrality, while
Gasteiger’s charges were calculated for the ligand, aligning
with common practice in molecular simulations (Weiner et al.,
1984; Dermawan et al., 2021). To conduct a virtual screening of
the compound library using Auto Dock Vina, grid box size (x =
80, y = 80, z = 80) and dimensions (x = 31.10, y = 14.21 and z = −8.
07) were adjusted for XYZ coordinates to cover the active binding
pocket during the virtual screening using Auto Dock Vina. The
process of virtual screening was conducted after the preparation
of the speciﬁc protein, employing the script-based approach of
Auto Dock Vina. The value for exhaustiveness was conﬁgured as
8, while the number of nodes was speciﬁed as 30. The virtual
screening procedure was conducted twice to validate the
precision of the docking outcomes.
The docking protocol was rigorously validated through a
redocking procedure using the same algorithm and parameters
employed
for
the
investigated
compounds.
This
validation
method ensures the ability of the molecular modeling simulation
to accurately replicate the ligand binding mode and residue-wise
interaction patterns. Speciﬁcally, achieving a root mean square
deviation (RMSD) value below 2 angstroms between the native
and
redocked
poses
conﬁrms
the
reliability
and
biological
signiﬁcance of the adopted docking protocol (Katari et al., 2016).
Following the conclusion of the virtual screening process, the
resultant
ﬁndings
from
the
virtual
screening
module
were
subjected to analysis and docking scores of the drug candidates
were compared to those of the standard drugs MTX and PTX.
DL model
DL models were used to predict drug-target interactions (DTI)
in the current work. The training data consists of a diverse dataset of
drug compounds and their respective protein targets. This dataset
was carefully curated from publicly available sources and annotated
with high-quality labels to ensure data integrity. Including diverse
compounds, targets, and proteins helps ensure the model’s
predictions apply to various scenarios. The model architecture
was based on encoder and decoder architectures, widely used in
deep learning for sequence-to-sequence tasks. This choice of
architecture was made due to its effectiveness in handling the
complex relationships between drug compounds and protein
sequences. The encoder processed the Simpliﬁed Molecular Input
Line Entry System (SMILES) string of the drug compound, while the
decoder handled the amino acid sequence of the target protein. Such
architecture allows the model to capture intricate features and
FIGURE 1
Scheme of Study for Implementation of DL Model. MTX and PTX images created by Chemcraft (Zhurko and Zhurko, 2005), Deep learning, predicted
binding poses and ADMET images created with AI (magic studio module www.canva.com), predicted QSAR created with OriginLab (Deschenes and
Vanden BoutUniversity of Texas, 2000).
Frontiers in Chemistry
frontiersin.org
03
Siddique et al.
10.3389/fchem.2024.1380266

## Page 4 (Section: DL based QSAR)

interactions between drugs and targets. For performance evaluation,
a rigorous and well-established protocol was followed. The dataset
was split into training, validation, and test sets to assess the model’s
generalization ability. The model was trained using over 17 state-of-
the-art deep learning techniques, validated in various studies for
their efﬁcacy in DTI prediction. Measure the model’s performance
using metrics such as precision, recall, F1-score, and receiver
operating
characteristic
(ROC)
curves.
This
extensive
performance evaluation approach ensures the model’s predictions
are robust and reliable (Huang et al., 2020a; Aziz et al., 2022a; Imran
et al., 2023). This study utilized the DeepPurpose architecture
(http://deeppurpose.sunlab.org/),
a
machine-learning
approach
for predicting the interaction between ligands and target proteins.
The pre-trained model, MPNN-CNN-Binding Data Base-IC50,
which combines the Message Passing Neural Network (MPNN)
with Convolutional Neural Network (CNN) techniques, was used to
predict drug-target interactions (DTI) in terms of binding afﬁnity
(IC50) and predicted pIC50 (Huang et al., 2020a; Aziz et al., 2022a;
Imran et al., 2023). This model incorporates advanced neural
network approaches to enhance the accuracy of DTI predictions.
DL based QSAR
The inherent ability of AI to revolutionize the drug discovery
process has already been established by the uptake and frequent use
of absorption, distribution, metabolism, excretion, and toxicity
(ADMET) predictive tools, virtual screening, and quantitative
structure-activity relationship (QSAR) modeling (Leelananda and
Lindert, 2016). Development and use of in silico QSAR models to
forecast drug activity, has become increasingly targeted in drug
development and drug discovery over the near past (Ekins et al.,
2007). Simple ML algorithms like multiple linear regression (MLR)
exhibit efﬁcient utilization for model development of relatively small
data sets. QSAR modelling aims to construct a model with strong
robustness and predictive capacity (Veerasamy, 2011; Hammoudan
et al., 2023).
DL based pIC50, binding afﬁnities
and ADMET
The FDA-approved drugs MTX and PTX have demonstrated
efﬁcacy in cancer treatment by effectively inhibiting the DHFR
pathway (Yamashita et al., 2020). The binding afﬁnity (IC50) and
ADMET proﬁle predominantly inﬂuence the drug’s effectiveness
(El-Adl et al., 2021). Consequently, DL models have been utilized to
forecast the IC50, pIC50, and ADMET characteristics of the most
promising candidates obtained via virtual screening (Al-Jumaili
et al., 2023b; Choudhary et al., 2023). This approach aims to
facilitate a direct evaluation of the binding afﬁnity of these
candidates regarding the established standards of MTX and PTX.
Applying in silico methods for predicting binding afﬁnity and
ADMET
characteristics
presents
a
promising
alternative
to
experimental approaches (Brogi, 2020). In the present study, DL
models were employed to predict interactions between drugs and
their respective targets, commonly referred to as drug-target
interactions (DTI). These models were constructed based on the
encoder and decoder architectures (Yu et al., 2022). The DL model
scheme uses the SMILES string (Table 1) and amino acid sequence
of the speciﬁc protein of interest as its input, employing more than
17 cutting-edge DL techniques to forecast indicators of drug efﬁcacy
(Figure 1). In this study, the researchers used the MPNN-CNN deep
learning algorithms to predict afﬁnity and speciﬁcally applied the
MPNN model for ADMET predictions (Huang et al., 2020a).
Density functional theory (DFT)
DFT methods are a reliable and proﬁcient approach for the
correct estimation of the electronic features of the compound
(Hohenberg
and
Kohn,
1964).
The
complete
geometry
optimization for all the Zinc15 library database (https://zinc15.
org/) compounds of MTX and PTX as shown in Supplementary
Table S1 was conducted by applying the DFT methodology at the
ground state level, employing three functional parameters. The
Becke, Lee-Yang-Parr (B3-LYP) functional (Prieto-Martínez et al.,
2018; Jemai et al., 2023) was used, consistently incorporating the
GD3 correction for dispersion (DiLabio et al., 2013). The absence of
imaginary frequencies observed during a harmonic vibrational
analysis conﬁrmed the existence of local energy minima in their
character (Yang et al., 2019). The obtained results were utilized to
calculate various electronic properties, such as the energy gap (Eg),
for the top hits under investigation. The energy gap can be
juxtaposed with speciﬁc molecular attributes, such as reactivity
and electrical conductivity. The energies of the lowest unoccupied
molecular orbital are commonly denoted as ELUMO, while those of
the highest occupied molecular orbital are denoted as EHOMO. In
addition to the aforementioned electronic properties, the values of
physiochemical descriptors such as hardness (η), softness (S),
chemical potential (µ), and electrophilicity index (ω) were
determined employing Koopman’s theorem (Tsuneda et al.,
2010). The relationship between chemical stability and reactivity
can be elucidated by considering the parameters of chemical
hardness (η), electronegativity (ꭓ), and softness (S) (El-Shamy
et al., 2022). The basis set for all examined structures was 6-
311+g(d,p).
The
calculations
were
executed
using
the
Gaussian09 software suite (Frisch, 2009), while the Chemcraft
suite was used to visualize the HOMO-LUMO Frontier molecular
orbitals (Kanagathara et al., 2022). The Gauss View utility was also
employed for visualization (Hanwell et al., 2012).
Molecular dynamics simulation
MD simulations provide information about the stability of the
best complex (Rasheed et al., 2021). The following steps were
employed to execute the MD simulation. The 3-dimensional (3D)
models of the enzyme Human DHFR (PDB ID: 1U72) (Rose et al.,
2010) in complex with methotrexate molecule were exported to
the.pdb format using Pymol (DeLano, 2002). The dynamic behavior
of the complexes was assessed through MD simulation using the
GROMACS software package (version 2022.2) (Bekker, 1993;
Ganesan et al., 2017; Thalla et al., 2020). The protein topology
was generated using the CHARMM27 force ﬁeld (Schmid et al.,
2011) through the pdb2gmx tool. The ligand topology was also
Frontiers in Chemistry
frontiersin.org
04
Siddique et al.
10.3389/fchem.2024.1380266

## Page 5 (Section: Results and discussion)

created using the SwissParam server (Van Aalten et al., 1996). The
complexes were subsequently introduced into the system upon
implementing the force ﬁeld. The solvation of the system was
carried out using the TIP3P water model (Mark and Nilsson,
2001). A cubic box with dimensions greater than 1 nm from the
protein’s edge was employed and periodic boundary conditions were
applied. The system was rendered inert by introducing Na+ ions,
followed by the execution of energy minimization for a total of
50,000 steps utilizing the steepest descent algorithm. Subsequently, a
100 picosecond (ps) NVT simulation at a temperature of 300 Kelvin
(K) was conducted, followed by 100ps NPT simulation to achieve
equilibrium for the entire system. The Leapfrog algorithm was
utilized in the constant-temperature, constant-pressure (NPT)
ensemble to independently couple each component, including the
protein, ligand, water molecules, and ions (Van Gunsteren and
Berendsen, 1988). The temperature and pressure coupling constants
for the Berendsen method were assigned values of 0.1 and 2,
respectively. These values were chosen to maintain a stable
environment for the system, with a temperature of 300K and a
pressure of 1 bar (Berendsen et al., 1995). The molecular dynamics
(MD) simulation was conducted for 100 nanoseconds under
isothermal and isobaric conditions in an ensemble at 300 Kelvin.
The time constant for pressure coupling was conﬁgured to
1 picosecond to ensure a constant pressure of 1 bar.
Additionally, the LINCS algorithm (Hess et al., 1997) was
employed to enforce constraints on bond lengths. The Van der
Waals and Coulomb interactions were truncated at a distance of
1.2 nm. The PME algorithm (Di Pierro et al., 2015), integrated
into GROMACS, was employed to minimize the error resulting
from truncation. The trajectory ﬁles were visualized using Visual
Molecular Dynamics (VMD) 1.9.2 (Humphrey et al., 1996) and
analyzed using the in-house developed tool HeroMD Analysis
(Devi et al., 2021; Rawat et al., 2021) and Xmgrace 5.1.25
(Vaught, 1996).
Results and discussion
Molecular docking results
This study has yielded signiﬁcant ﬁndings in the realm of virtual
screening and QSAR proﬁling utilizing DL techniques, alongside an
evaluation of ADMET properties. The detailed results, including
Supplementary
Tables
S1,
S2,
showcase
the
comprehensive
outcomes of our investigation.
A total of eight compounds represented in Table 1 exhibited
docking scores surpassing those of conventional drugs. The highest-
ranking results underwent additional examination utilizing DL
algorithms and QSAR. Thus, the utilization of DL models
facilitated the prediction of drug afﬁnity and the assessment of
protein-ligand complex stability (Rasheed et al., 2021; Aziz
et al., 2022a).
The structures of SBVS are presented in Figure 2, which
highlights the most signiﬁcant hits. It is important to note that
each occurrence exhibits a shared pharmacophore with established
MTX and PTX, recognized as inhibitors of DHFR. A common
pharmacophore indicates that these compounds can bind to the
active site of DHFR in a way that is analogous to MTX and PTX.
The
implementation
of
a
shared
pharmacophore
with
established DHFR inhibitors presents numerous beneﬁts. Initially,
it creates a foundation for these compound’s logical development
and improvement to augment their inhibitory efﬁcacy and
speciﬁcity
towards
DHFR.
Through
comprehension
of
the
fundamental structural components accountable for binding,
TABLE 1 Top hit compounds obtained through SBVS, Zinc15-ID, SMILES names and Docking score visa Autodock4 (AD4) and Autodock Vina.
Top
hits
ZINC15-ID
IUPAC Names
Docking score (AD4)
kcal/mol
Docking score (Vina)
kcal/mol
09
ZINC000003807186
(R)-2-((4-carboxy-4-(4-(((2,4-diaminopteridin-6-yl)methyl)amino)
benzamido)butyl)carbamoyl)benzoic acid
−11.36
−11.2
27
ZINC000006118800
6-(naphthalen-2-ylsulfonyl)quinazoline-2,4-diamine
−11.78
−11.6
41
ZINC000005647485
(R)-6-(naphthalen-2-ylsulﬁnyl)quinazoline-2,4-diamine
−11.58
−11.0
68
ZINC000005891475
5-methyl-6-((quinolin-3-ylamino)methyl)pyrido[2,3-d]pyrimidine-
2,4-diamine
−11.34
−11.0
74
ZINC000025968633
N-(2,4-diamino-5-methylquinazolin-6-yl)-2-(3,4-dichlorophenyl)
acetamide
−11.56
−11.0
85
ZINC000003814848
6-(acridin-10(9H)-ylmethyl)pteridine-2,4-diamine
−11.75
−11.6
99
ZINC000005939955
6-((9H-carbazol-9-yl)methyl)pteridine-2,4-diamine
−11.76
−11.6
180
ZINC000003830554
3,3’-((1E,1′E)-[1,1′-biphenyl]-4,4′-diylbis(diazene-2,1-diyl))bis(4-
aminonaphthalene-1-sulfonic acid)
−11.23
−11.1
MTXa
RD
(4-(((2,4-diaminopteridin-6-yl)methyl)(methyl)amino)benzoyl)-L-
glutamic acid
−9.7
−9.8
PTXb
RD
(E)-(4-((2,4-diaminoquinazolin-6-yl)diazenyl)benzoyl)-L-glutamic
acid
−10.1
−9.4
RD, Reference drug.
aMethotrexate.
bPhototrexate
Frontiers in Chemistry
frontiersin.org
05
Siddique et al.
10.3389/fchem.2024.1380266

## Page 6 (Section: Results and discussion)

alterations can be implemented to enhance the potency and
effectiveness
of
the
compounds.
In
addition,
a
common
pharmacophore among these compounds implies that they may
operate through comparable pathways such as MTX and PTX,
thereby
reinforcing
their
viability
as
DHFR
inhibitors
for
addressing DHFR-linked malignancies.
Figure 3 represents the 3D protein structure of 1U72 and catalyic
binding pocket. The molecular docking results of the top hits with
the lowest binding energy are illustrated in Table 2. The 3D
hydrogen bonding interactions of top hits with residual amino
acids within the binding pocket of 1U72 are shown in Figure 4
whereas the 2D interactions of top hits and reference compounds are
presented in Figures 5–7.
The Figure 5 and Table 2 illustrate that compound 9 exhibited
binding interactions with amino acid residues VAL08, ALA09,
VAL115, and TYR121, which are also known to interact with
MTX and PTX. It is worth noting that compound 9 displayed a
greater number of H-bonding interactions with their corresponding
distance in angstroms, reﬂecting that ALA9 (2.256 Å), LYS54
(2.2.798 Å), THR56 (2.991, 2.959Å), VAL115 (3.255 Å), VAL115
(3.302 Å), TYR121 (2.767 Å), and VAL8 (3.620 Å), thus suggesting
the possibility of better anticancer potential compared to other
selected top hits. However, it is important to acknowledge that
these ﬁndings are based on in silico analysis, and further
experimental validation would be necessary to conﬁrm the
anticancer efﬁcacy of compound 9. The sulfonyl oxygen in
compound 27 formed H-bonds with ALA9 (2.841 Å), VAL8
(3.436 Å), and GLY17 (3.735 Å), and aromatic rings displayed π-
π/π-σ interactions with ILE16, PHE34, ILE60 and LEU67 suggested
a favorable binding mode for compound 27. In comparison, MTX
and PTX exhibited similar H-bonding interactions with amino acid
residues, emphasizing the potential of compound 27 as a promising
anticancer candidate. The sulphone moiety of compound-41 could
not interact with the receptor due to the steric effect of adjacent ring
systems. However, the ring system is engaged in H-bonding
interactions
with
GLU30
at
a
distance
of
2.170 Å
and
hydrophobic
interactions
with
ALA9,
ILE60,
and
PRO61 demonstrating a favorable binding proﬁle for compound
41. In comparison, MTX and PTX primarily formed H-bonds with
speciﬁc residues, highlighting the distinct binding characteristics of
compound 41. Compound 68 formed H-bonds with ASP145 at the
relevant
distance
of
3.17
Å.
PHE34,
ILE16,
PHE34,
and
ALA9 depicted the hydrophobic interactions thus displaying
favorable binding interactions. These H-bonding interactions
contribute to its potential as an effective anticancer agent. MTX
and PTX also exhibited H-bonding and hydrophobic interactions,
demonstrating similar binding patterns to compound 68.
The results in Figure 6 and Table 2, Compound 74 showed
hydrophobic interactions with ALA9, VAL115, PHE34, LEU22, and
ILE16, indicating its ability to interact favorably with the target
residues. The hydrophobic interactions observed for compound 74
suggest a potential role in disrupting the hydrophobic core of the
target protein. MTX and PTX similarly engaged in hydrophobic
interactions, demonstrating comparable binding characteristics to
compound 74. Compound 85 formed H-bonds with THR56 and
LEU22 at the distance of 3.027 and 4.249 Å, highlighting its
favorable
binding
interactions.
Additionally,
it
exhibited
hydrophobic interactions with PHE34, LEU22, ILE16 and LYS55.
These binding features suggest a promising potential for compound
85 as an anticancer agent. MTX and PTX also demonstrated
FIGURE 2
Top hit compounds obtained through SBVS utilizing a common Pharmacophore similar to the standard drugs MTX and PTX (green highlighting is
showing same shared pharmacophore).
Frontiers in Chemistry
frontiersin.org
06
Siddique et al.
10.3389/fchem.2024.1380266

## Page 7 (Section: DL model results)

H-bonding
and
hydrophobic
interactions,
indicating
similar
binding proﬁles. Compound 99 was found to be engaged in
H-bonding
interactions
with
ASP145
(3.378 Å),
THR56
(2.961 Å), and GLY17 (3.439Å) with different bond distances,
suggesting
a
favorable
binding
afﬁnity.
It
also
displayed
hydrophobic interactions with GLY17, PHE34, LEU22, ALA9,
ILE16, and LYS55. These interactions contribute to the potential
of
compound
99
as
an
effective
anticancer
candidate.
Comparatively, MTX and PTX exhibited similar H-bonding and
hydrophobic interactions, aligning with the binding characteristics
of
compound
99.
The
amino
acid
residues
TYR
121 LYS68 interacted with compound 180 by electrostatic
interactions
whereas
GLN35
(3.269 Å),
showed
H-bonding
interactions with aromatic amino nitrogen. The hydrophobic
interactions via pi-sigma bonding and π-π stacking with ILE16,
LEU22 and ILE60 are crucial for favorable electron correlation. Our
analysis unveiled a robust connection between the binding modes of
studied ligands, MTX and PTX, highlighted by hydrogen bonds that
play a crucial role in stabilizing interactions. In addition, the
distances and angles of the hydrogen bonds were thoroughly
analyzed to conﬁrm the optimal hydrogen bonding for both
ligands. By aligning these interactions with the known binding
mode of MTX and its conformation, the biological signiﬁcance of
the binding poses of studied ligands and PTX has been established.
This explanation offers valuable insights into the structural
foundation of ligand-protein interactions and highlights the
potential therapeutic signiﬁcance of studied ligands and PTX as a
new version of MTX. Overall, these interactions indicate a unique
binding proﬁle for compound 180 and exhibited binding similarities
with MTX and PTX. MTX and PTX binding interactions are shown
in Figure 4 (3D interactions) and Figure 7 (2D interactions).
The
ﬁndings
from
the
molecular
docking
analysis
demonstrated the varied binding interactions between the top-
hit compounds and the speciﬁc amino acid residues of the target.
The observed compounds exhibited a synergistic interplay
between H-bonding and hydrophobic interactions, suggesting
their promising utility as efﬁcacious agents for combating cancer.
Although MTX and PTX displayed different binding patterns,
the top-hit compounds exhibited comparable or superior binding
characteristics. This implies that the compounds with the highest
activity show considerable promise as innovative agents for
combating cancer, thus justifying the need for additional
research and reﬁnement.
DL model results
The DL-based QSAR model outcomes for all 271 compounds
from the Zinc15 library have been meticulously documented and
can be found in Supplementary Figures S1–S17. These ﬁgures
depicted the ADMET proﬁling based on our DL-driven model,
presenting a comprehensive analysis of key properties and
characteristics for each compound in the library. These ﬁndings
highlighted the potential efﬁcacy and safety proﬁles of these
compounds, making them crucial for further drug discovery and
development efforts.
DL based QSAR
The current study employed the multiple linear regression
(MLR) method to conduct regression analysis (Liu and Long,
2009), as illustrated in Table 3. As shown in Supplementary
Table S1, the dataset was partitioned into separate training and
test sets. The analysis was conducted using the substitution groups
and the inhibitory activity of compounds within the dataset. The
training dataset was utilized for constructing the QSAR model, while
the test dataset was employed to assess the predictive ability of the
developed models. A dataset comprising 271 compounds, shown in
Supplementary Table S1 from the Zinc15 library, was used in a DL
model to forecast ADMET properties. Subsequently, the DL-based
ADMET predictions were employed to construct a model.
The selection process was guided by a focus on structural
similarity
to
established
anticancer
drugs,
emphasizing
compounds with analogous features and characteristics. Lipinski’s
rules were applied to evaluate the resemblance of the investigated
molecules to pharmaceutical compounds (Abdelrheem et al., 2020).
A drug candidate that adheres to no more than one of the rules
above will probably be pursued for development as a potential oral
medication. Furthermore, we assessed the drug-like properties of the
recently
developed
molecules
using
deep-learning
ADMET
techniques.
This
analysis
aimed
to
identify
the
molecular
structures
exhibiting
favorable
oral
drug
administration
characteristics. To validate this choice, an in silico assessment
was conducted to evaluate the pharmacokinetic parameters of the
selected
compounds
using
ADMET
prediction
(Rifaioglu
et al., 2019).
FIGURE 3
3D representation of 1U72 protein structure (A) Catalytic domain,
(B) ligand binding pocket (C) binding site interaction with key amino
acids, some amino acids are hidden behind ligand also.
Frontiers in Chemistry
frontiersin.org
07
Siddique et al.
10.3389/fchem.2024.1380266

## Page 8 (Section: DL model results)

TABLE 2 The binding interactions and distance (Å) of top hit compounds with amino acid residues.
Top
hits
Amino acid
residues
Type of
interactions
Distance
in Å
Top
hits
Amino acid
residues
Type of
interactions
Distance
in Å
9
ALA9
H-bond
2.256
74
ALA9
Hydrophobic
3.707
LYS54
H-bond
2.798
VAL115
Hydrophobic
4.425
THR56
H-bond
2.991
PHE34
Hydrophobic
4.980
THR56
H-bond
2.959
PHE34
Hydrophobic
4.554
VAL115
H-bond
3.255
LEU22
Hydrophobic
5.208
VAL115
H-bond
3.302
ILE16
Hydrophobic
5.243
TYR121
H-bond
2.767
ALA9
Hydrophobic
5.416
VAL8
H-bond
3.620
LEU22
Hydrophobic
5.476
LYS55
Hydrophobic
3.767
LEU22
Hydrophobic
4.925
LEU75
Hydrophobic
5.488
ALA9
Hydrophobic
4.691
27
ALA9
H-bond
2.841
85
THR56
H-bond
3.027
VAL8
H-bond
3.436
PHE34
Hydrophobic
4.249
GLY17
H-bond
3.735
LEU22
Hydrophobic
5.390
ILE16
Hydrophobic
3.978
PHE34
Hydrophobic
5.493
PHE34
Hydrophobic
4.363
ILE16
Hydrophobic
4.723
PHE34
Hydrophobic
3.992
LYS55
Hydrophobic
5.230
ILE16
Hydrophobic
4.681
LEU22
Hydrophobic
5.347
ILE60
Hydrophobic
4.907
LEU67
Hydrophobic
5.396
41
GLU30
H-bond
2.170
99
ASP145
H-bond
3.378
ILE60
Hydrophobic
3.918
THR56
H-bond
2.961
ALA9
Hydrophobic
4.293
GLY17
H-bond
3.439
ILE60
Hydrophobic
4.570
PHE34
Hydrophobic
4.379
PRO61
Hydrophobic
5.441
LEU22
Hydrophobic
5.275
PRO61
Hydrophobic
5.346
ALA9
Hydrophobic
5.453
ILE16
Hydrophobic
4.841
LYS55
Hydrophobic
5.183
LEU22
Hydrophobic
5.206
68
ASP145
H-bond
3.178
180
LYS68
Electrostatic
5.087
PHE34
Hydrophobic
4.443
LYS68
H-bond
2.796
ILE16
Hydrophobic
4.652
GLN35
H-bond
3.269
ALA9
Hydrophobic
4.840
LEU22
Hydrophobic
3.781
ALA9
Hydrophobic
5.087
TYR121
Hydrophobic
5.795
ILE60
Hydrophobic
4.656
ILE16
Hydrophobic
5.496
LEU22
Hydrophobic
5.232
(Continued on following page)
Frontiers in Chemistry
frontiersin.org
08
Siddique et al.
10.3389/fchem.2024.1380266

## Page 9 (Section: Predicted binding affinities)

Predicted binding afﬁnities
By comparing the binding afﬁnities of the compounds to the
DHFR cancer target protein, it is possible to observe variations in
their predicted IC50 values and pIC50 values, as shown in Table 4.
Compound 68 exhibits notable characteristics concerning binding
afﬁnity, as evidenced by its predicted IC50 value of 78.66 nM and
pIC50 value of 7.10. The data indicates that compound 68 exhibits a
robust and efﬁcacious binding afﬁnity towards the DHFR oncogenic
protein. Compound 74 demonstrates a notable binding afﬁnity, as
evidenced by its anticipated IC50 value of 62.46 nM and pIC50 value
of 7.20. This observation suggests a robust binding afﬁnity between
the compound and the target protein, similar to compound 68.
In contrast, it can be observed that compounds 27, 41, and 180
exhibit moderate binding afﬁnities, as their anticipated IC50 values
fall within the range of 1,394.69 nM to 1,423.03 nM, thereby yielding
pIC50 values that vary from 5.85 to 5.93. Although the binding
afﬁnity of these compounds is comparatively weaker than that of
compounds 68 and 74, they display signiﬁcant interactions with the
DHFR protein, which is a target for cancer treatment. Compounds
09, 85, 99, MTX, and PTX exhibit reduced binding afﬁnities, as
indicated by their predicted IC50 values, which range from
129.91 nM to 2,187.48 nM and correspond to pIC50 values
ranging from 5.80 to 6.89. The studied compounds display lower
binding afﬁnities towards the target protein than those above. To
summarize, the binding afﬁnities of the compounds 68 and 74 are
the highest, while compounds 27, 41, and 180 exhibit moderate
afﬁnities. Compounds 09, 85, 99, MTX, and PTX demonstrate
reduced binding afﬁnities with DHFR target protein when they were
subjected to the DL prediction model.
MPNN-deep learning model-based ADMET
Table 5 presents a comparative analysis of the ADMET
(absorption, distribution, metabolism, excretion, and toxicity)
outcomes generated by the DL, highlighting notable patterns and
variations across the compounds currently under study using the
MPNN model. The solubility values, expressed in logarithmic units
of mol/L, range from −3.93 to −5.45. The solubility of the
compounds can be inferred from their respective negative values,
where higher solubility is associated with more negative values.
Compound 180 has the highest solubility with a value of −5.45, while
compound 09 has the lowest solubility of −3.93. As a result, it is
possible that compound 180 exhibits superior dissolution properties
in comparison to the remaining compounds. The range of
lipophilicity, as determined by the logarithmic ratio, falls between
0.19 and 2.69. The lipophilicity of compound 74 is the highest
among the tested compounds, as indicated by its value of 2.69. This
suggests that it has a greater tendency to dissolve in lipids or fats,
with higher values indicating increased fat solubility. On the other
hand, it can be observed that compound 09 displays the least degree
TABLE 2 (Continued) The binding interactions and distance (Å) of top hit compounds with amino acid residues.
Top
hits
Amino acid
residues
Type of
interactions
Distance
in Å
Top
hits
Amino acid
residues
Type of
interactions
Distance
in Å
MTX
GLU30
H-bond
1.951
PTX
GLU30
H-bond
2.020
ASN64
H-bond
2.307
GLN35
H-bond
2.990
ARG70
H-bond
1.817
ASN64
H-bond
2.317
VAL115
H-bond
2.438
ARG70
H-bond
1.813
ILE7
H-bond
2.125
ARG70
H-bond
2.335
ILE60
Hydrophobic
5.205
GLU1
H-bond
2.407
ILE60
Hydrophobic
4.361
GLU1
H-bond
2.225
ALA9
Hydrophobic
4.870
ILE7
H-bond
1.820
LEU22
Hydrophobic
5.053
VAL115
H-bond
2.244
ILE7
Hydrophobic
5.305
GLU30
H-bond
2.328
ALA9
Hydrophobic
4.180
PRO61
H-bond
3.738
ILE60
Hydrophobic
4.654
LEU67
Hydrophobic
5.207
PHE31
Hydrophobic
5.147
ILE60
Hydrophobic
4.132
ALA9
Hydrophobic
5.180
LEU22
Hydrophobic
5.098
ILE7
Hydrophobic
5.367
ALA9
Hydrophobic
4.180
Frontiers in Chemistry
frontiersin.org
09
Siddique et al.
10.3389/fchem.2024.1380266

## Page 10 (Section: Predicted binding affinities)

FIGURE 4
3D representation of H-bonding interactions of top hit compounds with 1U72.
FIGURE 5
2D representation of hydrophobic and hydrogen bonding interactions of compounds 9, 27, 41 and 68 with 1U72.
Frontiers in Chemistry
frontiersin.org
10
Siddique et al.
10.3389/fchem.2024.1380266

## Page 11 (Section: Predicted binding affinities)

of lipophilicity (0.19), thereby suggesting a comparatively reduced
capacity for dissolution in fats.
The absorption percentages, speciﬁcally related to human intestinal
absorption (HIA), transportation by P-glycoprotein (Pgp), and
Bioavailability-F20, have been included in the study for reference.
These values indicate how well a compound is absorbed in the
human intestines,
the
extent to which
it is transported
by
P-glycoprotein, and its potential bioavailability, with a focus on
Bioavailability-F20. These parameters are valuable for assessing a
compound’s suitability for further development and its potential as a
drug candidate. The values mentioned above denote the proportion of
the substance assimilated following ingestion via the oral route. The oral
absorption rates of the compounds were found to be high, as evidenced
by the absorption (HIA) values ranging from 93.6% (compound 09) to
99.12% (compound 99). The absorption rate of compounds across the
gastrointestinal tract through P-glycoprotein, an efﬂux transporter,
exhibits a range of variability from 12.5% (compound 74) to 33.3%
(compound 41). The bioavailability of the administered compounds,
ranging from 76.3% (compound 09) to 78.83% (compound 99),
pertains to the extent of absorption and represents the proportion of
the dose that enters the systemic circulation. Distribution (BBB)
and
Distribution
(PPBR)
percentages
are
presented
as
FIGURE 6
2D representation of hydrophobic and hydrogen bonding interactions of compounds 74, 85, 99 and 180 with 1U72.
FIGURE 7
2D representation of hydrophobic and hydrogen bonding interactions of reference drugs MTX and PTX with 1U72.
Frontiers in Chemistry
frontiersin.org
11
Siddique et al.
10.3389/fchem.2024.1380266

## Page 12 (Section: Predicted binding affinities)

distribution values. The distribution (BBB) parameter denotes
the capacity of the compound to traverse the blood-brain
barrier, with a range of values observed between 43.47%
(compound
180)
and
74.68%
(compound
85).
Elevated
values indicate superior distribution across the blood-brain
barrier. The distribution of a compound, as measured by its
plasma protein binding rate (PPBR), indicates its afﬁnity for
binding to proteins in the bloodstream. The observed PPBR
values for the investigated compounds range from 35.3%
(compound 09) to 94.11% (compound 180).
The metabolic rates of speciﬁc cytochrome P450 enzymes
(CYP2C19, CYP2D6, CYP3A4, CYP1A2, CYP2C9) that participate
in drug metabolism are indicated as percentages in metabolism values.
The metabolic proﬁle of Compound 41 marks a signiﬁcant metabolism
rate by CYP3A4 (28.66%) and CYP1A2 (79.34%), implying that these
enzymes are playing a crucial role in the compound’s metabolic
pathway. The results indicate that Compound 180 undergoes
considerable metabolism by CYP2C9, with a rate of 61.74%,
suggesting a signiﬁcant contribution of this enzyme in the metabolic
process of this compound. The column “half-life” indicates the duration
required for the concentration of a given compound within an organism
to decrease by 50%. Compound 6 demonstrates a brief half-life of
6.53 h, implying a swift elimination rate. Conversely, compound 68
displays the lengthiest half-life of 8.33 h, indicating a more gradual
elimination process.
The clinical toxicity values indicate each compound’s toxicity rating
or score in the last column compound 180 exhibits the most favorable
clinical toxicity ratings, with a value of 8.3%, respectively. Conversely,
compounds 09, 27, 41, 68, and 99 demonstrate clinical toxicity ratings
ranging from 31.64% to 35.2%. The clinical toxicity ratings of
compounds MTX and PTX are 31.78% and 30.12%, respectively,
suggesting the presence of potential toxicity. Methotrexate, in
TABLE 3 QSAR-based model representation with equation parameters.
MLR QSAR model equation
Fitting
parameters
DL-ADMET Equation parameters
Y1 = - 0.5310 (±0.0780) X1 + 0.0717 (±0.1912) X2 + 0.2381 (±1.0861)
X3 + 0.0997 (±0.0322) X4 + 0.0131 (±0.0078) X5 - 0.3159 (±0.0847)
X6 - 0.0569 (±0.0061) X7 - 0.0235 (±0.0053) X8 - 0.0000 (±0.0051)
X9 + 0.0065 (±0.0026) X10 + 0.0109 (±0.0034) X11 + 0.0035 (±0.0032)
X12 - 0.0126 (±0.0057) X13 - 0.6279 (±0.6323) X14 + 0.0011 (±0.4962)
X15 + 0.0338 (±0.0066) X16 + 28.3293 (±8.3012) (n = 229; R = 0.897;
s = 0.293; F = 54.714; p < 0.0001; Q2 = 0.773; SPress = 0.316; SDEP = 0.305)
N
229
K
16
R2
0.81
R2-Adj.
0.79
S
0.29
F
54.71
P
0
Q2
0.77
SPress
0.32
SDEP
0.31
C.V.
4.74
Y1 = pIC50, X1 = Solubility, X2 = Lipophilicity, X3 = (Absorption) Caco-2, X4 = (Absorption) HIA, X5 = (Absorption) Pgp, X6 = (Absorption)Bioavailability, X7 = (Distribution) BBB, X8 =
(Distribution) PPBR, X9 = (Metabolism) CYP2C19, X10 = (Metabolism) CYP2D6, X11 = (Metabolism) CYP3A4, X12 = (Metabolism) CYP1A2, X13 = (Metabolism) CYP2C9, X13 =
(Metabolism) CYP2C9, X14 = (Excretion) Half-life, X15 = (Excretion) Clearance, X16 = Clinical Toxicity.
TABLE 4 DL model-based binding energies and predicted binding afﬁnities.
Top hits
Binding energies kJ/mol
Predicted binding afﬁnity (IC50) nM
pIC50 (predicted using deep learning model)
09
−46.89
218.22
6.66
27
−48.57
1,423.03
5.85
41
−46.05
1,394.69
5.86
68
−46.05
78.66
7.10
74
−46.05
62.46
7.20
85
−48.57
724.71
6.14
99
−48.57
1,587.48
5.80
180
−46.47
1,172.72
5.93
MTX
−39.38
129.91
6.89
PTX
−39.36
773.98
6.11
Frontiers in Chemistry
frontiersin.org
12
Siddique et al.
10.3389/fchem.2024.1380266

## Page 13 (Section: DFT-based physiochemical descriptor profile)

particular, is known to be a highly toxic drug, classiﬁed as a cytotoxic
agent. The level of toxicity can vary signiﬁcantly based on factors such as
dosage, duration of administration, individual patient characteristics,
and other relevant determinants. Additionally, toxicity can indeed vary
in terms of its impact and severity on patients. In brief, these DL model
ﬁndings presented in Table 5 indicate that compound 180 manifests the
most outstanding solubility, compound 74 displays the highest
lipophilicity,
compound
99
exhibits
the
highest
rate
of
oral
absorption, compound 85 demonstrates the highest distribution
across the blood-brain barrier, compound 41 undergoes substantial
metabolism by CYP3A4 and CYP1A2, compound 68 has the
lengthiest half-life, and compounds 180 exhibit the least clinical
toxicity ratings.
DFT-based physiochemical
descriptor proﬁle
The physiochemical descriptors of the top hit compounds
obtained through virtual screening and the standard anticancer
drugs MTX and PTX were determined using DFT analysis and
are presented in Table 6. The aforementioned descriptors in the table
offer valuable insights into the electronic properties and reactivity of
the compounds, thereby playing a crucial role in comprehending
their behavior and potential applications. The electronic energy
values obtained for the compounds ranged from −2,810.59 atomic
units
to
−1,079.78
atomic
units.
Electronic
energy
is
a
comprehensive measure of the energy the electrons possess
within
a
given
system,
and
the
molecular
structure
and
composition of the compound determines its magnitude (Closs
et al., 1986). The dipole moment, denoted in Debye units (D), is
a quantitative measure of the spatial displacement between the
positive and negative charges within a given molecule (Minkin,
2012). The dipole moment values presented in Table 6 exhibited a
range spanning from 0.92 D to 9.31 D, which can be attributed to the
polarity and asymmetry characteristics of the compounds. The
EHomo values, which denote the highest occupied molecular
orbital energy, exhibited a range from −6.24 eV to −5.50 eV.
These values determine compounds’ electron donation ability,
where more negative EHomo values indicate a greater propensity
TABLE 5 MPNN-Deep Learning model based ADMET, top hit compounds predicted results.
Top
hits
Solubility Log
mol/L
Lipophilicity
Log-ratio
Absorption
(HIA) %
Absorption
(Pgp) %
Absorption
(bioavailability
F20) %
Distribution
(BBB) %
Distribution
(PPBR) %
09
−3.93
0.19
93.6
13
76.3
47.1
35.3
27
−4.77
1.89
98.61
12.7
78.46
60.38
90.89
41
−5.27
2.64
98.83
33.3
78.32
68.93
91.53
68
−4.05
2.38
98.4
16
78.16
68.24
55.5
74
−5.05
2.69
97.38
12.5
77.02
74.06
64.5
85
−4.38
2.45
98.92
21.3
78.46
74.68
73.47
99
−4.83
2.31
99.12
20.5
78.83
68.33
71.55
180
−5.45
1.22
97.44
12.9
77.94
43.47
94.11
MTX
−3.00/Soluble
0.00/No
91.51/Low
8.06/Yes
75.76/Yes
49.95/Yes
19.90/Yes
PTX
−3.94
0.14
93.24
8.76
75.96
52.15
41.96
Top
Hits
(Metabolism)
CYP2C19%
(Metabolism)
CYP2D6%
(Metabolism)
CYP3A4%
(Metabolism)
CYP1A2%
(Metabolism)
CYP2C9%
(Excretion)
Half life
hours
Clinical
Toxicity %
09
7.5
4
9.7
9
3.2
8.26
32
27
37.46
16.66
23.16
61.66
8.75
8.11
31.64
41
50.74
17.93
28.66
79.34
6.84
7.98
32.24
68
39.35
39.73
47.01
90.49
6.67
7.98
34.64
74
70.8
21.66
38.74
80.44
30.32
7.97
32.66
85
42.84
24.28
27.57
79.94
21.42
7.94
34.88
99
23.53
12
27.71
90.5
12.67
7.97
35.2
180
94.11
14.59
13.86
28.4
61.74
6.53
8.3
MTX
3.66/good
3.14/good
4.22/good
5.02/good
1.42/good
8.26/Medium
31.78/Medium
PTX
4.04
5.00
3.93
18.69
1.45
8.33
30.12
HIA, human intestinal absorption; Pgp, permeability-glycoprotein; BBB, blood brain barrier; PPBR, plasma protein binding rati; MTX results obtained from literature incorporated as MTX, deep
learning module value/Literature predictions (Uddin et al., 2019; Singh et al., 2022; Rana et al., 2019; Kawabata et al., 2013).
Frontiers in Chemistry
frontiersin.org
13
Siddique et al.
10.3389/fchem.2024.1380266

## Page 14 (Section: DFT-based physiochemical descriptor profile)

to donate electrons in chemical reactions. The values of ELumo, which
denote the energy of the lowest unoccupied molecular orbital,
exhibited a range spanning from −2.73 eV to −1.62 eV.
The ELumo plays a crucial role in the acceptance of electrons.
Compounds
exhibiting
lower
ELumo
values
demonstrate
a
heightened capacity for electron acceptance. The energy gap,
which is determined by the disparity between the EHomo and
ELumo,
explains
the
electron
transfer
capabilities
of
the
compound. The observed energy gap values range from 2.85 eV
to 4.21 eV, signifying the compounds’ diverse capacities for electron
donation or acceptance, as shown in Table 7. The ionization
potential is a fundamental concept in chemistry, which can be
mathematically expressed as the negative of the highest occupied
molecular orbital energy (EHomo). It signiﬁes the minimum amount
of energy needed to extract an electron from a molecule that is in a
neutral state. This study’s range of ionization potential values
spanned from 5.50 eV to 6.24 eV. This range suggests that the
compounds examined in this research exhibit varying degrees of
stability and resistance to remove electrons. The electron afﬁnity of a
molecule is determined by the energy change that occurs when an
electron is acquired, and it is quantiﬁed as the negative value of the
energy of the lowest unoccupied molecular orbital (ELumo). The
observed electron afﬁnity values ranged from 1.62 to 3.09 eV,
signifying the compounds’ inherent capacity to accept electrons.
Supplementary Table S3 showing the optimized XYZ coordinates
for top-hit anticancer compounds and reference drugs.
The chemical descriptors of the compounds were virtually screened
as top hits, and the standard anticancer drugs MTX and PTX were
assessed using DFT calculations. The results are presented in Table 8,
which showcases the outcomes obtained from the DFT calculations.
These descriptors provide valuable understandings of the compounds’
electronic structure, reactivity, and stability, elucidating their chemical
behavior. The chemical potential (μ) is determined by the arithmetic
mean of the ionization potential (I) and the electron afﬁnity (A), and it
signiﬁes the inclination of a compound to either donate or accept
electrons.
The
chemical
potential
values
in
Table
8
ranged
from −4.52 eV to −3.65 eV. These values indicate the compounds’
electronic stability and capacity to engage in electron transfer
phenomena. Electronegativity (χ) measures an element’s ability to
attract electrons, calculated as the average ionization potential and
electron afﬁnity. It is a quantitative indicator of a compound’s capacity
to
attract
electrons.
The
compounds
exhibited
a
range
of
electronegativity values, ranging from 4.52 eV to 3.65 eV, indicating
their diverse propensities to attract electrons during chemical reactions.
The chemical hardness (η) is determined by taking half the difference
between the ionization potential and the electron afﬁnity. It
characterizes the ability of a compound to resist alterations in its
electronic conﬁguration. The chemical hardness values in Table 8,
range from 1.43 eV to 2.11 eV, suggesting the compounds’ inherent
stability and capacity to endure electronic perturbations. Global softness
(σ), which is the inverse of chemical hardness, offers valuable insights
into the reactivity and vulnerability of a compound to electron transfer.
The global softness values exhibited a range spanning from 0.48 eV−1 to
0.70 eV−1, whereby lower values were indicative of heightened electron
transfer
resistance
and
chemical
reactivity.
A
compound’s
electrophilicity (ω) can be determined by evaluating the square of its
chemical potential divided by twice its chemical hardness. This
parameter measures the compound’s capacity to accept electrons
and engage in electrophilic reactions. The electrophilicity values
exhibited a range spanning from 6.64 eV to 10.22 eV, thereby
indicating the diverse propensities of the compounds to function as
electron acceptors. Most of the selected top hits exhibited ionization
potential, electrophilicity, and electron afﬁnity values similar to those of
the reference drugs, suggesting they behave electrochemically similarly
to MTX and PTX under physiologic conditions (Avendaño, 2008).
However, compounds 27 and 180 showed greater ionization potential
and electrophilicity, which may contribute to improved interactions and
potentially enhanced therapeutic efﬁcacy. The literature also showed
similar results of related studies with the DFT method use (Graffner-
Nordberg et al., 2000; Zia et al., 2019; Aziz et al., 2022a).
The physicochemical and chemical descriptors of the top hit
compounds identiﬁed through virtual screening and the standard
TABLE 6 DFT electronic parameters of top-hit anticancer compounds and standard drugs.
Top hit lead
compounds
Electronic
energy (a.u)
Dipole
moment
(Debye)
EHomo
(eV)
ELumo
(eV)
Energy
gap (eV)
Ionization
potential (eV)
Electron
afﬁnity (eV)
(I) = -EHOMO
(A) = -ELUMO
9
−1989.98
9.31
−5.97
−2.58
3.39
5.97
2.58
27
−1,462.33
4.87
−6.24
−2.03
4.21
6.24
2.03
41
−1,387.09
2.13
−5.97
−1.80
4.17
5.97
1.80
68
−1,079.78
3.71
−5.89
−1.94
3.95
5.89
1.94
74
−1926.65
4.67
−5.67
−1.62
4.04
5.67
1.62
85
−1,156.02
3.47
−5.50
−2.28
3.22
5.50
2.28
99
−1,116.70
3.80
−5.81
−2.33
3.48
5.81
2.33
180
−2,810.59
4.32
−5.95
−3.09
2.85
5.95
3.09
MTX
−1,590.11
4.99
−5.82
−2.38
3.44
5.82
2.38
PTX
−1,533.50
0.92
−5.92
−2.73
3.20
5.92
2.73
Frontiers in Chemistry
frontiersin.org
14
Siddique et al.
10.3389/fchem.2024.1380266

## Page 15 (Section: DFT-based physiochemical descriptor profile)

TABLE 7 EHOMO and ELUMO with energy gap (ΔE) values for top-hit compounds represented in electron volts (eV) and with frontial orbitals.
Top hits
EHomo (eV)
HOMO
ELumo (eV)
LUMO
Energy gap
(ΔEeV)
9
−5.97
−2.58
3.39
27
−6.24
−2.03
4.21
41
−5.97
−1.80
4.17
68
−5.89
−1.94
3.95
74
−5.67
−1.62
4.04
85
−5.50
−2.28
3.22
99
−5.81
−2.33
3.48
180
−5.95
−3.09
2.85
MTX
−5.82
−2.38
3.44
(Continued on following page)
Frontiers in Chemistry
frontiersin.org
15
Siddique et al.
10.3389/fchem.2024.1380266

## Page 16 (Section: Molecular dynamics simulation)

anticancer drugs MTX and PTX were thoroughly examined using
DFT analysis. The discoveries above contributed to an enhanced
comprehension of the compounds’ electronic characteristics,
reactivity, and stability, which are pivotal in assessing their
potential efﬁcacy as anticancer agents. The results obtained from
this study thus established a valuable resource for future drug design
efforts, as they contribute to the development of new compounds
that exhibit improved therapeutic effectiveness and targeted
anticancer properties and also contributed in alignment with the
existing literature (Hobani et al., 2017; Mammen et al., 2020; Rana
et al., 2020).
Molecular dynamics simulation
Molecular dynamics simulation
To determine the binding stability of protein-ligand complexes,
the MD simulation trajectories were evaluated by plotting the root
mean square deviation (RMSD), root mean square ﬂuctuation
(RMSF), hydrogen-bond proﬁle, solvent accessible surface area
and radius of gyration. The root-mean-square deviation (RMSD)
pattern provides remarkable insight into an average change in the
displacement of atoms to a frame. Figure 8 presented the RMSD
graphs of investigated ligands and compared them with those of
MTX and PTX. The average RMSDs for the protein-ligand
complexes of 09, 27, 41, 68, 74, 84, 99 and 180 were found to
be 0.24nm, 0.20nm, 0.21nm, 0.26nm, 0.23nm, 0.24nm, 0.28nm and
0.29 nm respectively. To assess the impact of ligands on a
conformational change in the protein structure, the RMSD of
each system was compared with the reference compounds MTX
and PTX, as shown in Figure 9. It has been observed that these ligand
complexes exhibited only slight variations in RMSDs throughout the
entire simulation, and the results were comparable with the
reference MTX and PTX. The ligands 09, 27 and 41 reached
equilibrium at about 6–10 ns and remained equilibrated for the
entire simulation duration, demonstrating the high stability of these
complexes with the target protein. The ligand 99 also formed a stable
complex; only slight variation is observed in the last 20 frames of
simulation. There is an increase in the RMSD values of the ligand 74
during 62–75 ns. After that, the system was again equilibrated and
was found to be stable for the rest of the simulation. A signiﬁcant
variance was observed in the RMSD values of ligands 68 and 85 after
about 55ns and remained least stable for the rest of the time.
The RMSF plots represent the protein regions that revealed a great
ﬂuctuation in their conformation during the simulation. In the present
study, the receptor was found to be stable throughout the simulation.
Only slight ﬂuctuations were evident in the binding site region with
RMSF values less than 0.2nm, considered negligible (Figure 10).
The H-bond proﬁle for all investigated ligands is illustrated in
Figure 11 and found to be in good agreement with RMSD analysis.
The most stable complexes of ligands 09, 27 and 41 were found to be
due to the formation of 3–4 H-bonds with the target protein for
TABLE 7 (Continued) EHOMO and ELUMO with energy gap (ΔE) values for top-hit compounds represented in electron volts (eV) and with frontial orbitals.
Top hits
EHomo (eV)
HOMO
ELumo (eV)
LUMO
Energy gap
(ΔEeV)
PTX
−5.92
−2.73
3.20
TABLE 8 DFT-based physiochemical descriptors of top-hit anticancer compounds and standard drugs.
Top hits
Chemical
potential (eV)
Electronegativity
(eV)
Chemical
Hardness (eV)
Global
softness (eV−1)
Electrophilicity
(eV)
(μ) = - (I + A)/2
(χ) = (I + A)/2
(η) = (I - A)/2
(σ) = 1/η
(ω) = μ2/2η
9
−4.28
4.28
1.70
0.59
9.14
27
−4.14
4.14
2.11
0.48
8.55
41
−3.89
3.89
2.09
0.48
7.55
68
−3.92
3.92
1.98
0.51
7.66
74
−3.65
3.65
2.03
0.49
6.64
85
−3.89
3.89
1.61
0.62
7.57
99
−4.07
4.07
1.74
0.57
8.28
180
−4.52
4.52
1.43
0.70
10.22
MTX
−4.10
4.10
1.72
0.58
8.41
PTX
−4.33
4.33
1.60
0.63
9.35
Frontiers in Chemistry
frontiersin.org
16
Siddique et al.
10.3389/fchem.2024.1380266

## Page 17 (Section: Molecular dynamics simulation)

most of the time during simulation. The ligands 74 and 99 formed
2–3 H-bonds, whereas ligand 180 formed 2–1 H-bonds over 100 ns
simulation that depicts the relative binding stability of these ligands
for time. Ligand 68 showed only 0–1 H-bond with high RMSDs in
the last 20 ns of simulation, resulting in decreased stability of
protein-ligand complex for the rest of the time. The binding
stability of ligand 85 also decreased during 55–80 ns due to the
decreased number of H-bonds with the target protein.
Solvent accessible surface area (SASA) is attributed to the
bimolecular surface area accessible to the solvent molecules. The
greater the increase in the value for SASA concerning time, the
lower the stability of the protein. In the current study, SASA of all
complexes was observed between 100 nm2 to 120 nm2, with an average
SASA value of 110 nm2, which is quite acceptable (Figure 12).
The analysis of the radius of gyration (Rg) provides information
about the overall dimensions of the protein during the 100 ns
FIGURE 8
Analysis of MD simulation trajectories; Root mean square deviation (RMSD) of investigated ligands compared with RMSDs of MTX and PTX over
time (100 ns).
FIGURE 9
Analysis of MD simulation trajectories; Root mean square deviation (RMSD) of protein-ligand complex compared with RMSDs of MTX and PTX
complex over time (100 ns).
Frontiers in Chemistry
frontiersin.org
17
Siddique et al.
10.3389/fchem.2024.1380266

## Page 18 (Section: Molecular dynamics simulation)

simulation. All the protein-ligand complexes under investigation
have shown a steady radius of gyration with an average value of
1.66 nm.
The
entire
simulation
indicates
good
protein
stability (Figure 13).
Supplementary Figure S18 presented the snapshots of
investigated ligands and reference compounds in complex with
protein at 0 ns. Supplementary Figures S19–S28 illustrates the
snapshots of investigated ligands along with MTX and PTX at
FIGURE 10
Analysis of MD simulation trajectories; Residue-wise root mean square ﬂuctuation (RMSF) of protein ligand complex compared with RMSF of
reference MTX and PTX complex.
FIGURE 11
Analysis of MD simulation trajectories; H-bond proﬁle of the protein-ligand complex over time (100 ns) compared with reference MTX and
PTX complex.
Frontiers in Chemistry
frontiersin.org
18
Siddique et al.
10.3389/fchem.2024.1380266

## Page 19 (Section: Molecular dynamics simulation)

25 ns, 50 ns, 75 ns and 100 ns indicating the stability of
investigated ligands and reference compounds within the
binding
pocket.
The
compound
68
complex
with
target
protein is found to be stable up to 75 ns as depicted in
Supplementary
Figure
S21
and
at
the
last
run
of
MD
simulation, the compound is out of the binding pocket. These
results are by the RMSD graph of compound 68-complex
illustrating its unstability in the last 20 ns of MD simulation
as shown in Figure 9.
The ﬁndings from Table 9, which outline the MM-PBSA of
MM-GBSA binding free energies in kJ/mol, reveal that Ligands 9,
27, 68, 99, MTX, and PTX consistently demonstrate the lowest
binding energies throughout the molecular dynamics (MD)
simulation
timeframe.
This
observation
has
important
scientiﬁc implications, indicating that these ligands have high
afﬁnities for the target receptor or binding site during the
simulation. The uniform low binding energies observed with
various ligands suggest strong and enduring interactions with the
receptor, demonstrating advantageous binding orientations and
energetic environments. These discoveries play a vital role in
drug discovery and design, as ligands with consistently low
binding energies are more likely to demonstrate strong and
FIGURE 12
Analysis of MD simulation trajectories; Solvent accessible surface area of protein-ligand complex compared with reference MTX and PTX complex
over time (100 ns).
FIGURE 13
Analysis of MD simulation trajectories; Radius of gyration of protein-ligand complex compared with reference MTX and PTX complex over
time (100 ns).
Frontiers in Chemistry
frontiersin.org
19
Siddique et al.
10.3389/fchem.2024.1380266

## Page 20 (Section: Conclusion)

dependable binding proﬁles, positioning them as promising
candidates for additional experimental validation and drug
development
endeavours.
Furthermore,
these
ﬁndings
highlight the success of the MM-PBSA method in capturing
the intricate molecular interactions and offering important
insights
into
the
energetics
of
ligand-receptor
binding
throughout MD simulations.
Conclusion
In summary, the 2D-QSAR model was generated to retrieve
the potential of the Zinc15 compound library as DHFR
inhibitors.
QSAR
modelling,
virtual
screening
and
deep
learning-based ADMET resulted in screening the top hits
compounds. The FDA-approved drugs, MTX & PTX, were
considered as standard drugs to which in silico ﬁndings could
be compared and examined. The eight top hits labelled as 09, 27,
41, 68, 74, 85, 99, and 180 were chosen with binding
afﬁnity ≤−11.0 kal/mol and pIC50 ranges from 5.85 to 7.64.
The ADMET parameters, Lipinski rule of ﬁve and clinical
toxicity matrices were considered to ensure drug likeliness
features and safety of the compounds under investigation. The
DFT was used to optimize the investigating compound’s stability
and
physicochemical
parameters.
The
top
hits
exhibited
electrophilicity
values
ranging
from
6.24 eV
to
10.22 eV,
representing
the
electron
acceptor
property
required
for
varying receptor interactions. Further, the molecular docking
and dynamics studies revealed signiﬁcantly higher binding
afﬁnity scores and stability of protein-ligand complex over
100 ns simulation compared to reference drugs MTX and
PTX, endorsing their reliable anticancer activity. The study
provided
considerable
insight
for
developing
selected
compounds as novel anticancer drugs in the future. In short,
the ﬁndings of the current study identiﬁed top hits that could
prove themselves as an effective treatment strategy for DHFR
inhibition leading to treat and manage cancer malignancies.
These ﬁndings will assist researchers to develop newer leads
without consuming much time and ﬁnancial resources so further
experimental studies are also recommended for future prospects
and to explore its newer aspects. In view of the current study,
there is always a platform for future studies focusing on the
incorporation of a more extensive and diverse set of experimental
data to apply the approach developed here to in-vivo for the sake
of developing a generalized model.
Data availability statement
The original contributions presented in the study are included in
the article/Supplementary Material, further inquiries can be directed
to the corresponding authors.
Author contributions
FS: Supervision, Project administration, Writing–original draft. AA:
Conceptualization,
Writing–original
draft.
MaB:
Methodology,
Writing–original draft. SN: Formal Analysis, Writing–original draft.
RR:
Formal
Analysis,
Writing–original
draft.
VE:
Resources,
Writing–original draft. SA: Validation, Writing–original draft. MeB:
Visualization,
Writing–original
draft.
YB:
Supervision,
Writing–original draft. MoB: Writing–original draft, Writing–review
and editing.
Funding
The author(s) declare ﬁnancial support was received for the
research, authorship, and/or publication of this article. The
authors would like to extend their sincere appreciation to the
Researchers Supporting Project, King Saud University, Riyadh,
Saudi Arabia for funding this work through the project number
(RSP2024R457).
Acknowledgments
The authors would like to extend their sincere appreciation to
the Researchers Supporting Project, King Saud University, Riyadh,
Saudi Arabia for funding this work through the project number
(RSP2024R457).
TABLE 9 MM-PBSA of MM-GBSA binding free energies estimated in kJ/mol.
Energy (kJ/mol)
9
27
41
68
74
85
99
180
MTX
PTX
MMGBSA
ΔEvdw
−197.32
−182.26
−270.6
−179.62
−290.58
−210.58
−220.6
−230.6
−192.23
−185.23
ΔEelec
−551.54
−543.39
−478
−556.85
−498.02
−403.02
−439.1
−467.0
−537.41
−511.71
ΔEsolv
654.78
641.93
585.32
645.36
532.23
525.39
517.23
505.32
654.95
626.41
ΔESASA
−22.18
−21.85
−21.89
−21.1
−22.89
−24.849
−23.89
−21.89
−21.07
−20.96
ΔGbinding
−116.26
−105.57
−185.17
−112.21
−279.26
−113.06
−166.36
−214.17
−95.76
−91.49
Lowest free binding energy ligand numbers is shown in bold, vdw van der Waals, elect electrostatic, solv polar solvation, SASA solvent-accessible surface area.
Frontiers in Chemistry
frontiersin.org
20
Siddique et al.
10.3389/fchem.2024.1380266

## Page 21 (Section: Conflict of interest)

Conﬂict of interest
The authors declare that the research was conducted in the
absence of any commercial or ﬁnancial relationships that could be
construed as a potential conﬂict of interest.
Publisher’s note
All claims expressed in this article are solely those of the authors
and
do
not
necessarily
represent
those
of
their
afﬁliated
organizations, or those of the publisher, the editors and the
reviewers. Any product that may be evaluated in this article, or
claim that may be made by its manufacturer, is not guaranteed or
endorsed by the publisher.
Supplementary material
The Supplementary Material for this article can be found online
at: https://www.frontiersin.org/articles/10.3389/fchem.2024.1380266/
full#supplementary-material
References
Abdelrheem, D. A., Ahmed, S. A., Abd El-Mageed, H. R., Mohamed, H. S., Rahman,
A. A., Elsayed, K. N. M., et al. (2020). The inhibitory effect of some natural bioactive
compounds against SARS-CoV-2 main protease: insights from molecular docking
analysis and molecular dynamic simulation. J. Environ. Sci. Health, Part A 55 (11),
1373–1386. doi:10.1080/10934529.2020.1826192
Abdolmaleki, A., and Ghasemi, J. B. (2017). Dual-acting of hybrid compounds-a new
dawn in the discovery of multi-target drugs: lead generation approaches. Curr.
Top. Med. Chem. 17 (9), 1096–1114. doi:10.2174/1568026616666160927151144
Aher, A., Udhwani, T., Khandelwal, R., Limaye, A., Hussain, T., Nayarisseri, A., et al. (2020).
In silico insights on IL-6: a potential target for multicentric castleman disease. Curr. computer-
aided drug Des. 16 (5), 641–653. doi:10.2174/1573409915666190902142524
Al-Jumaili, M. H. A., Hamad, A. A., Hashem, H. E., Hussein, A. D., Muhaidi, M. J.,
Ahmed, M. A., et al. (2023a). Comprehensive review on the Bis–heterocyclic
compounds and their anticancer efﬁcacy. J. Mol. Struct. 1271, 133970. doi:10.1016/j.
molstruc.2022.133970
Al-Jumaili, M. H. A., Siddique, F., Abul Qais, F., Hashem, H. E., Chtita, S., Rani, A., et al.
(2023b). Analysis and prediction pathways of natural products and their cytotoxicity against
HeLa cell line protein using docking, molecular dynamics and ADMET. J. Biomol. Struct.
Dyn. 41 (3), 765–777. doi:10.1080/07391102.2021.2011785
Andricopulo, A. D., Guido, R. V., and Oliva, G. (2008). Virtual screening and its
integration with modern drug design technologies. Curr. Med. Chem. 15 (1), 37–46.
doi:10.2174/092986708783330683
Avendaño, C. (2008). “Chapter 2-antimetabolites,” in Medicinal chemistry of
anticancer drugs, 9–52.
Aziz, M., Ejaz, S. A., Tamam, N., and Siddique, F. (2022b). A comprehensive
computational
approach
for
the
identiﬁcation
of
structure-based
potential
pharmacological
candidates
as
selective
AKR1B1
and
AKR1B10
inhibitors:
repurposing of purine alkaloids for the treatment of cancer. J. Biomol. Struct. Dyn.
41, 7892–7912. doi:10.1080/07391102.2022.2127906
Aziz, M., Ejaz, S. A., Zargar, S., Akhtar, N., Aborode, A. T., A. Wani, T., et al. (2022a).
Deep learning and structure-based virtual screening for drug discovery against NEK7: a
novel target for the treatment of cancer. Molecules 27 (13), 4098. doi:10.3390/
molecules27134098
Bekker,
H.
(1993).
“Gromacs-a
parallel
computer
for
molecular-dynamics
simulations,” in 4th international conference on computational physics, Buenos
Aires, Argentina, October 18-22, 1993.
Berendsen, H. J., van der Spoel, D., and van Drunen, R. (1995). GROMACS: a
message-passing
parallel
molecular
dynamics
implementation.
Comput.
Phys.
Commun. 91 (1-3), 43–56. doi:10.1016/0010-4655(95)00042-e
Brogi, S. (2020). In silico methods for drug design and discovery. Lausanne,
Switzerland: Frontiers Media SA, 612.
Choudhary, R., Walhekar, V., Muthal, A., Kumar, D., Bagul, C., and Kulkarni, R.
(2023). Machine learning facilitated structural activity relationship approach for the
discovery of novel inhibitors targeting EGFR. J. Biomol. Struct. Dyn. 41, 12445–12463.
doi:10.1080/07391102.2023.2175263
Closs, G., Calcaterra, L. T., Green, N. J., Penﬁeld, K. W., and Miller, J. R. (1986).
Distance, stereoelectronic effects, and the Marcus inverted region in intramolecular
electron transfer in organic radical anions. J. Phys. Chem. 90 (16), 3673–3683. doi:10.
1021/j100407a039
DeLano, W. L. (2002). Pymol: An open-source molecular graphics tool. CCP4 Newsl.
Protein Crystallogr. 40 (1), 82–92.
Dermawan, D., Prabowo, B. A., and Rakhmadina, C. A. (2021). In silico study of
medicinal plants with cyclodextrin inclusion complex as the potential inhibitors against
SARS-CoV-2 main protease (Mpro) and spike (S) receptor. Inf. Med. Unlocked 25,
100645. doi:10.1016/j.imu.2021.100645
Deschenes, L. A., and Vanden BoutUniversity of Texas, A. D. A. (2000). Origin 6.0:
scientiﬁc data analysis and graphing software origin lab corporation (formerly microcal
software, inc.). Available at: http://www.originlab.com.
Devi, S., Rangra, N. K., Rawat, R., Alrobaian, M. M., Alam, A., Singh, R., et al. (2021).
Anti-atherogenic effect of Nepitrin-7-O-glucoside: a ﬂavonoid isolated from Nepeta
hindostana via acting on PPAR–α receptor. Steroids 165, 108770. doi:10.1016/j.steroids.
2020.108770
DiLabio,
G.
A.,
Koleini,
M.,
and
Torres,
E.
(2013).
Extension
of
the
B3LYP–dispersion-correcting potential approach to the accurate treatment of both
inter-and intra-molecular interactions. Theor. Chem. Accounts 132, 1389–1413. doi:10.
1007/s00214-013-1389-x
Di Pierro, M., Elber, R., and Leimkuhler, B. (2015). A stochastic algorithm for the
isobaric–isothermal ensemble with Ewald summations for all long range forces. J. Chem.
theory Comput. 11 (12), 5624–5637. doi:10.1021/acs.jctc.5b00648
Ekins, S., Mestres, J., and Testa, B. (2007). In silico pharmacology for drug discovery:
methods for virtual ligand screening and proﬁling. Br. J. Pharmacol. 152 (1), 9–20.
doi:10.1038/sj.bjp.0707305
El-Adl, K., Ibrahim, M. K., Alesawy, M. S., and Eissa, I. H. (2021). [1, 2, 4] Triazolo [4,
3-c] quinazoline and bis ([1, 2, 4] triazolo)[4, 3-a: 4′, 3′-c] quinazoline derived DNA
intercalators: design, synthesis, in silico ADMET proﬁle, molecular docking and anti-
proliferative evaluation studies. Bioorg. Med. Chem. 30, 115958. doi:10.1016/j.bmc.2020.
115958
El-Shamy, I., Hleli, E., Alsheikh, A. A., Yawer, M. A., El-Hashash, M. A., Dybal, J.,
et al. (2022). Synthesis of some mono-and disaccharide-grafting phthalazine
derivatives and some new Se-nucleoside analogues: antibacterial properties,
quantum chemical calculations, and cytotoxicity. Molecules 28 (1), 317. doi:10.
3390/molecules28010317
Ferreira, L. G., dos Santos, R., Oliva, G., and Andricopulo, A. (2015). Molecular
docking and structure-based drug design strategies. Molecules 20 (7), 13384–13421.
doi:10.3390/molecules200713384
Ferreira, O. O., Mali, S. N., Jadhav, B., Chtita, S., Kuznetsov, A., Bhandare, R. R., et al.
(2023). Synthesis, in-silico, in vitro and DFT assessments of substituted imidazopyridine
derivatives as potential antimalarials targeting hemoglobin degradation pathway.
J. Comput. Biophysics Chem. 22, 795–814. doi:10.1142/s2737416523500412
Fralish, Z., Chen, A., Skaluba, P., and Reker, D. (2023). DeepDelta: predicting
ADMET
improvements
of
molecular
derivatives
with
deep
learning.
J. Cheminformatics 15, 101. doi:10.1186/s13321-023-00769-x
Frisch, M. J. (2009). Gaussian09. Available at: http://www.gaussian.com/.
Ganesan, A., Coote, M. L., and Barakat, K. (2017). Molecular dynamics-driven drug
discovery: leaping forward with conﬁdence. Drug Discov. today 22 (2), 249–269. doi:10.
1016/j.drudis.2016.11.001
Graffner-Nordberg, M., Marelius, J., Ohlsson, S., Persson, Å., Swedberg, G.,
Andersson, P., et al. (2000). Computational predictions of binding afﬁnities to
dihydrofolate
reductase:
synthesis
and
biological
evaluation
of
methotrexate
analogues. J. Med. Chem. 43 (21), 3852–3861. doi:10.1021/jm0009639
Hammoudan, I., Chtita, S., Daoui, O., Elkhattabi, S., Bakhouch, M., El Yazidi, M., et al.
(2023). QSAR and DFT studies of some tacrine-hydroxamate derivatives as inhibitors of
cholinesterase (AChEs) in the treatment of alzheimer’s disease. Lett. Drug Des. Discov.
20 (6), 699–712. doi:10.2174/1570180819666220512174409
Hanwell, M. D., Curtis, D. E., Lonie, D. C., Vandermeersch, T., Zurek, E., and Hutchison, G.
R. (2012). Avogadro: an advanced semantic chemical editor, visualization, and analysis
platform. J. cheminformatics 4 (1), 17. doi:10.1186/1758-2946-4-17
Hess, B., Bekker, H., Berendsen, H. J. C., and Fraaije, J. G. E. M. (1997). LINCS: a
linear constraint solver for molecular simulations. J. Comput. Chem. 18 (12),
1463–1472. doi:10.1002/(sici)1096-987x(199709)18:12<1463::aid-jcc4>3.3.co;2-l
Frontiers in Chemistry
frontiersin.org
21
Siddique et al.
10.3389/fchem.2024.1380266

## Page 22 (Section: Conflict of interest)

Hobani, Y., Jerah, A., and Bidwai, A. (2017). A comparative molecular docking study
of curcumin and methotrexate to dihydrofolate reductase. Bioinformation 13 (3), 63–66.
doi:10.6026/97320630013063
Hohenberg, P., and Kohn, W. (1964). Inhomogeneous electron gas. Phys. Rev. 136
(3B), B864–B871. doi:10.1103/physrev.136.b864
Huang, K., Fu, T., Glass, L. M., Zitnik, M., Xiao, C., and Sun, J. (2020a). DeepPurpose:
a deep learning library for drug–target interaction prediction. Bioinformatics 36 (22-23),
5545–5547. doi:10.1093/bioinformatics/btaa1005
Huang, K., Fu, T., Khan, D., Abid, A., Abidala, A., Abid, A., et al. (2020b). Moldesigner:
interactive design of efﬁcacious drugs with deep learning. arXiv preprint arXiv:2010.03951.
Huennekens, F. (1994). The methotrexate story: a paradigm for development of
cancer chemotherapeutic agents. Adv. enzyme Regul. 34, 397–419. doi:10.1016/0065-
2571(94)90025-6
Humphrey, W., Dalke, A., and Schulten, K. (1996). VMD: visual molecular dynamics.
J. Mol. Graph. 14 (1), 33–38. doi:10.1016/0263-7855(96)00018-5
Imran, M., Abida, A., Alotaibi, N. M., Thabet, H. K., Alruwaili, J. A., Eltaib, L.,
et al. (2023). Repurposing anti-dengue compounds against monkeypox virus
targeting
core
cysteine
protease.
Biomedicines 11
(7), 2025. doi:10.3390/
biomedicines11072025
Jemai, M., Khalﬁ, M., Issaoui, N., Roisnel, T., Kazachenko, A. S., Al-Dossary, O., et al.
(2023). Role of non-covalent interactions in novel supramolecular compound, bis (4-
phenylpiperazin-1-ium) oxalate dihydrate: synthesis, molecular structure, thermal
characterization, spectroscopic properties and quantum chemical study. Crystals 13
(6), 875. doi:10.3390/cryst13060875
Kalaydina, R.-V., Bajwa, K., Qorri, B., DeCarlo, A., and Szewczuk, M. R. (2018).
Recent advances in &quot;smart&amp;quot; delivery systems for extended drug release
in cancer therapy. Int. J. nanomedicine Vol. 13, 4727–4745. doi:10.2147/ijn.s168053
Kanagathara, N., Usha, R., Natarajan, V., and Marchewka, M. (2022). Molecular
geometry, vibrational, NBO, HOMO–LUMO, ﬁrst order hyper polarizability and
electrostatic potential studies on anilinium hydrogen oxalate hemihydrate–an
organic crystalline salt. Inorg. Nano-Metal Chem. 52 (2), 226–233. doi:10.1080/
24701556.2021.1891103
Katari, S. K., Natarajan, P., Swargam, S., Kanipakam, H., Pasala, C., and
Umamaheswari, A. (2016). Inhibitor design against JNK1 through e-pharmacophore
modeling docking and molecular dynamics simulations. J. Recept. Signal Transduct. 36
(6), 558–571. doi:10.3109/10799893.2016.1141955
Kawabata, H., Kadowaki, N., Nishikori, M., Kitawaki, T., Kondo, T., Ishikawa, T., et al.
(2013). Clinical features and treatment of multicentric castleman’s disease: a
retrospective
study
of
21
Japanese
patients
at
a
single
institute.
J.
Clin.
Exp. Hematop. 53 (1), 69–77. doi:10.3960/jslrt.53.69
Kim, J., Woo, S. Y., Im, C. Y., Yoo, E. K., Lee, S., Kim, H. J., et al. (2016). Insights of a
lead optimization study and biological evaluation of novel 4-hydroxytamoxifen analogs
as estrogen-related receptor γ (ERRγ) inverse agonists. J. Med. Chem. 59 (22),
10209–10227. doi:10.1021/acs.jmedchem.6b01204
Lavecchia, A., and Di Giovanni, C. (2013). Virtual screening strategies in drug
discovery: a critical review. Curr. Med. Chem. 20 (23), 2839–2860. doi:10.2174/
09298673113209990001
Leelananda, S. P., and Lindert, S. (2016). Computational methods in drug discovery.
Beilstein J. Org. Chem. 12 (1), 2694–2718. doi:10.3762/bjoc.12.267
Liamputtong,
P.,
and
Suwankhong,
D.
(2015).
Breast
cancer
diagnosis:
biographical disruption, emotional experiences and strategic management in Thai
women with breast cancer. Sociol. Health & Illn. 37 (7), 1086–1101. doi:10.1111/
1467-9566.12282
Liu, P., and Long, W. (2009). Current mathematical methods used in QSAR/QSPR
studies. Int. J. Mol. Sci. 10 (5), 1978–1998. doi:10.3390/ijms10051978
Lo, Y.-C., Rensi, S. E., Torng, W., and Altman, R. B. (2018). Machine learning in
chemoinformatics and drug discovery. Drug Discov. today 23 (8), 1538–1546. doi:10.
1016/j.drudis.2018.05.010
Mammen, M., Mohanan, A. G., and Kumar, P. (2020). Computational and
experimental validation of methotrexate as Staphylococcal-DHFR inhibitor. Curr.
Trends Biotechnol. Pharm. 14 (4), 396–402. doi:10.5530/ctbp.2020.4.41
Mark, P., and Nilsson, L. (2001). Structure and dynamics of the TIP3P, SPC, and SPC/
E water models at 298 K. J. Phys. Chem. A 105 (43), 9954–9960. doi:10.1021/jp003020w
Matera, C., Gomelia, A. M. J., Nuria, C., and Pau, G. (2019). “Photochromic antifolate
for light-activated chemotherapy,” in 17th International Photodynamic Association
World Congress, Boston, USA, June 28 – July 4, 2019.
Matera, C., Gomila, A. M. J., Camarero, N., Libergoli, M., Soler, C., and Gorostiza, P.
(2018). Photoswitchable antimetabolite for targeted photoactivated chemotherapy.
J. Am. Chem. Soc. 140 (46), 15764–15773. doi:10.1021/jacs.8b08249
Minkin, V. I. (2012). Dipole moments in organic chemistry. Berlin, Germany: Springer
Science & Business Media.
Nazki, F. H., Sameer, A. S., and Ganaie, B. A. (2014). Folate: metabolism, genes,
polymorphisms and the associated diseases. Gene 533 (1), 11–20. doi:10.1016/j.gene.2013.09.063
Nilsson, R., Jain, M., Madhusudhan, N., Sheppard, N. G., Strittmatter, L., Kampf, C., et al.
(2014). Metabolic enzyme expression highlights a key role for MTHFD2 and the
mitochondrial folate pathway in cancer. Nat. Commun. 5 (1), 3128. doi:10.1038/ncomms4128
Prieto-Martínez, F. D., Arciniega, M., and Medina-Franco, J. L. (2018). Molecular
docking: current advances and challenges. TIP. Revista especializada en ciencias
químico-biológicas, 21.
Raimondi, M. V., Randazzo, O., La Franca, M., Barone, G., Vignoni, E., Rossi, D., et al.
(2019). DHFR inhibitors: reading the past for discovering novel anticancer agents.
Molecules 24 (6), 1140. doi:10.3390/molecules24061140
Rana, R. M., Rampogu, S., Abid, N. B., Zeb, A., Parate, S., Lee, G., et al. (2020). In silico study
identiﬁed methotrexate analog as potential inhibitor of drug resistant human dihydrofolate
reductase for cancer therapeutics. Molecules 25 (15), 3510. doi:10.3390/molecules25153510
Rana, R. M., Rampogu, S., Zeb, A., Son, M., Park, C., Lee, G., et al. (2019). In silico
study probes potential inhibitors of human dihydrofolate reductase for cancer
therapeutics. J. Clin. Med. 8 (2), 233. doi:10.3390/jcm8020233
Rasheed, M. A., Iqbal, M. N., Saddick, S., Ali, I., Khan, F. S., Kanwal, S., et al. (2021).
Identiﬁcation of lead compounds against Scm (fms10) in Enterococcus faecium using
computer aided drug designing. Life 11 (2), 77. doi:10.3390/life11020077
Rawat, R., Kant, K., Kumar, A., Bhati, K., and Verma, S. M. (2021). HeroMDAnalysis:
an automagical tool for GROMACS-based molecular dynamics simulation analysis.
Future Med. Chem. 13 (05), 447–456. doi:10.4155/fmc-2020-0191
Rifaioglu, A. S., Atas, H., Martin, M. J., Cetin-Atalay, R., Atalay, V., and Doğan, T.
(2019). Recent applications of deep learning and machine intelligence on in silico drug
discovery: methods, tools and databases. Brieﬁngs Bioinforma. 20 (5), 1878–1912.
doi:10.1093/bib/bby061
Rose, P. W., Beran, B., Bi, C., Bluhm, W. F., Dimitropoulos, D., Goodsell, D. S., et al.
(2010). The RCSB Protein Data Bank: redesigned web site and web services. Nucleic
acids Res. 39 (Suppl. l_1), D392–D401. doi:10.1093/nar/gkq1021
Sánchez-Linares, I., Pérez-Sánchez, H., Cecilia, J. M., and García, J. M. (2012). High-
throughput parallel blind virtual screening using BINDSURF. BMC Bioinforma. 13,
S13–S14. doi:10.1186/1471-2105-13-s14-s13
Santarpia, L., Lippman, S. M., and El-Naggar, A. K. (2012). Targeting the
MAPK–RAS–RAF signaling pathway in cancer therapy. Expert Opin. Ther. targets
16 (1), 103–119. doi:10.1517/14728222.2011.645805
Schmid, N., Eichenberger, A. P., Choutko, A., Riniker, S., Winger, M., Mark, A. E.,
et al. (2011). Deﬁnition and testing of the GROMOS force-ﬁeld versions 54A7 and 54B7.
Eur. biophysics J. 40, 843–856. doi:10.1007/s00249-011-0700-9
Siddiq, M. (2022). Revolutionizing drug discovery; transformative role of machine
learning. BULLET J. Multidisiplin Ilmu 1 (02), 162–170.
Siddique, F., Aqdas, A., Bashir, M., Nadeem, S., Rawat, R., Ahmad, S., et al. (2024).
Harnessing the Potential of Natural Products in Cancer Treatment: A Comprehensive
Review. J. Biol. Regul. Homeost. Agents 38 (2), 873–897. doi:10.23812/j.biol.regul.
homeost.agents.20243802.72
Singh, A., Deshpande, N., Pramanik, N., Jhunjhunwala, S., Rangarajan, A., and
Atreya, H. S. (2018). Optimized peptide based inhibitors targeting the dihydrofolate
reductase pathway in cancer. Sci. Rep. 8 (1), 3190. doi:10.1038/s41598-018-21435-5
Singh, M. B., Vishvakarma, V. K., Lal, A. A., Chandra, R., Jain, P., and Singh, P.
(2022). A comparative study of 5-ﬂuorouracil, doxorubicin, methotrexate,
paclitaxel for their inhibition ability for Mpro of nCoV: molecular docking and
molecular dynamics simulations. J. Indian Chem. Soc. 99 (12), 100790. doi:10.
1016/j.jics.2022.100790
Staszak, M., Staszak, K., Wieszczycka, K., Bajek, A., Roszkowski, K., and Tylkowski, B.
(2022). Machine learning in drug design: use of artiﬁcial intelligence to explore the
chemical structure–biological activity relationship. Wiley Interdiscip. Rev. Comput. Mol.
Sci. 12 (2), e1568. doi:10.1002/wcms.1568
Sutherland, J. J., O’brien, L. A., and Weaver, D. F. (2003). Spline-ﬁtting with a genetic
algorithm: a method for developing classiﬁcation structure−activity relationships.
J. Chem. Inf. Comput. Sci. 43 (6), 1906–1915. doi:10.1021/ci034143r
Tang, M., Li, B., and Chen, H. (2023). Application of message passing neural networks
for molecular property prediction. Curr. Opin. Struct. Biol. 81, 102616. doi:10.1016/j.sbi.
2023.102616
Thalla, M., Kant, K., Dalchand, Rawat, R., and Banerjee, S. (2020). Merged
experimental guided computational strategy toward tuberculosis treatment mediated
by alveolar macrophages mannose receptor. J. Biomol. Struct. Dyn. 38 (17), 5195–5203.
doi:10.1080/07391102.2019.1697369
Trott, O., Olson, A. J., and Vina, A. D. (2010). AutoDock Vina: improving the speed
and accuracy of docking with a new scoring function, efﬁcient optimization, and
multithreading. J. Comput. Chem. 31 (2), 455–461. doi:10.1002/jcc.21334
Tsuneda, T., Song, J. W., Suzuki, S., and Hirao, K. (2010). On Koopmans’ theorem in
density functional theory. J. Chem. Phys. 133 (17), 174101. doi:10.1063/1.3491272
Uddin, N., Ahmed, S., Khan, A. M., Mazharol Hoque, M., and Halim, M. A. (2019).
Halogenated derivatives of methotrexate as human dihydrofolate reductase inhibitors in
cancer chemotherapy. J. Biomol. Struct. Dyn. 38, 901–917. doi:10.1080/07391102.2019.
1591302
Frontiers in Chemistry
frontiersin.org
22
Siddique et al.
10.3389/fchem.2024.1380266

## Page 23 (Section: Conflict of interest)

Van Aalten, D. M., Bywater, R., Findlay, J. B. C., Hendlich, M., Hooft, R. W. W., and
Vriend, G. (1996). PRODRG, a program for generating molecular topologies and
unique molecular descriptors from coordinates of small molecules. J. computer-aided
Mol. Des. 10, 255–262. doi:10.1007/bf00355047
Van Gunsteren, W. F., and Berendsen, H. J. (1988). A leap-frog algorithm
for
stochastic
dynamics.
Mol.
Simul.
1
(3),
173–185.
doi:10.1080/
08927028808080941
Vaught, A. (1996). Graphing with Gnuplot and Xmgr: two graphing packages
available under linux. Linux J. 1996 (28es), 7–es.
Veerasamy, R., Rajak, H., Jain, A., Sivadasan, S., Varghese, C. P., Agrawal, R. K., et al.
(2011). Validation of QSAR models-strategies and importance. Int. J. Drug Des. Discov.
3, 511–519.
Weiner, S. J., Kollman, P. A., Case, D. A., Singh, U. C., Ghio, C., Alagona, G., et al.
(1984). A new force ﬁeld for molecular mechanical simulation of nucleic acids and
proteins. J. Am. Chem. Soc. 106 (3), 765–784. doi:10.1021/ja00315a051
Winkler, D. A. (2021). Use of artiﬁcial intelligence and machine learning for discovery
of drugs for neglected tropical diseases. Front. Chem. 9, 614073. doi:10.3389/fchem.
2021.614073
Yamashita, K., Kiyonari, S., Tsubota, S., Kishida, S., Sakai, R., and Kadomatsu, K.
(2020). Thymidylate synthase inhibitor raltitrexed can induce high levels of DNA
damage in MYCN-ampliﬁed neuroblastoma cells. Cancer Sci. 111 (7), 2431–2439.
doi:10.1111/cas.14485
Yang, C., Zhang, J., Liao, M., Yang, Y., Wang, Y., Yuan, Y., et al. (2021). Folate-
mediated one-carbon metabolism: a targeting strategy in cancer therapy. Drug Discov.
Today 26 (3), 817–825. doi:10.1016/j.drudis.2020.12.006
Yang, D., Zhang, Q., Song, X., and Zhang, T. (2019). Investigation of the intramolecular
hydrogen bonding interactions and excited state proton transfer mechanism for both Br-BTN
and CN-BTN systems. RSC Adv. 9 (40), 23004–23011. doi:10.1039/c9ra04258j
Yu, J.-L., Dai, Q.-Q., and Li, G.-B. (2022). Deep learning in target prediction and drug
repositioning: recent advances and challenges. Drug Discov. Today 27 (7), 1796–1814.
doi:10.1016/j.drudis.2021.10.010
Zhang, L., Tan, J., Han, D., and Zhu, H. (2017). From machine learning to deep
learning: progress in machine intelligence for rational drug discovery. Drug Discov.
today 22 (11), 1680–1685. doi:10.1016/j.drudis.2017.08.010
Zhurko, G. A., and Zhurko, D. A. (2005). Chemcraft—graphical program for
visualization of quantum chemistry computations. Academic version, 1.
Zia, M. K., Siddiqui, T., Ali, S. S., Ahsan, H., and Khan, F. H. (2019). Understanding
the binding interaction between methotrexate and human alpha-2-macroglobulin:
multi-spectroscopic and computational investigation. Archives Biochem. biophysics
675, 108118. doi:10.1016/j.abb.2019.108118
Frontiers in Chemistry
frontiersin.org
23
Siddique et al.
10.3389/fchem.2024.1380266


---

# Role of artificial intelligence in revolutionizing drug discovery

- **Authors:** Ashfaq Ur Rehman, Mingyu Li, Binjian Wu, Yasir Ali, Salman Rasheed, Sana Shaheen, Xinyi Liu, Ray Luo, Jian Zhang
- **Issuer:** Fundamental research
- **Type:** Scientific article
- **Published:** 2024-05-09
- **Language:** en
- **DOI:** 10.1016/j.fmre.2024.04.021
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40528990/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractThe application of artificial intelligence (AI) in medicine, particularly through machine learning (ML), marked a significant progression in drug discovery. AI acts as a powerful catalyst in narrowing the gap between disease understanding and the identification of potential therapeutic agents. This review provides an inclusive summary of the latest advancements in AI and its application in drug discovery. We examine the various stages of the drug discovery process, starting from disease identification and encompassing diagnosis, target identification, screening, and lead discovery. AI's capability to analyze extensive datasets and discern patterns is essential in these stages, enhancing predictions and efficiencies in disease identification, drug discovery, and clinical trial management. The role of AI in expediting drug development is emphasized, highlighting its potential to analyze vast data volumes, thus reducing the time and costs associated with new drug market introduction. The importance of data quality, algorithm training, and ethical considerations, especially in patient data handling during clinical trials, is addressed. By considering these factors, AI promises to transform drug development, offering significant benefits to patients and society.Keywords: Artificial intelligence, Machine learning, Disease identification, Drug design, Drug discovery

## Section: Introduction

The traditional drug discovery process is a complex and challenging endeavor that can require up to 15 years and over $1 to 2 billion for each approved drug [1]. This is primarily due to rising attrition rates and extended clinical trial duration [2]. Despite considerable investment in resources, almost 90% of potential drug candidates fail even after they have advanced to the phase-I clinical trial [3]. Advancing a drug candidate to phase-I clinical trial after rigorous optimization at the preclinical stage is considered a significant milestone for both pharmaceutical companies and academic institutions [4].

Large-scale computational screening and docking have been employed to enhance the success rate of lead compounds in clinical trials [5]. However, these methods have limitations such as inefficiency and inaccuracy [6]. To overcome these challenges, deep learning (DL) and ML algorithms, which are subsets of AI, have been identified as potential solutions [7]. These AI tools possess the ability to predict macrosystem properties with high accuracy while incurring low computational costs. As a result, there has been an increasing adoption of AI algorithms in the drug discovery process by chemical and biological scientists.

ML is extensively used in drug discovery, employing algorithms such as DL, Bayesian network (BN), random forest (RF), clustering, and support vector machine (SVM). The broad categorization of ML can be seen in Fig. 1. DL models process and analyze large amounts of data in tasks such as clinical imaging [8,9], virtual screening (VS) [10,11], and bioactivity predictions [12]. BNs predict toxicity or bioactivity and patients’ response to treatments [13]. RF models are used for molecular target identification and feature selection, while clustering identifies patterns or relationships within data [14]. SVM is a supervised learning algorithm used to classify data into categories, with applications such as predicting pharmacokinetic properties, VS, and toxicity prediction [15].

Computational modelling based on AI and ML has made various drug discovery processes achievable, including chemical compound identification, target identification, peptide synthesis, drug toxicity and physiochemical property assessment, drug monitoring, drug efficacy and effectiveness assessment, bioactive agent prediction, protein-protein interaction, protein folding and misfolding identification, structure and ligand-based virtual screening (LBVS), QSAR modeling, and drug repositioning [16]. ML algorithms have made it faster to identify lead compounds from chemical libraries that contain over 106 million compounds and solve the toxicity challenges caused by off-target interactions [17]. Furthermore, ML-based tools such as AlphaFold have made it easier to predict the 3D structure of a target protein, which is crucial in drug discovery process.

AlphaFold is a recently developed AI-based tool from Google's DeepMind. Researchers have also used AI to discover novel peptides for therapeutic purposes. Provenzano et al. [18] created Deep-AmPEP30, a DL-based platform for the identification of short anti-microbial peptides (AMPs) [18], while Yi et al. [19] devised ACP-DL, a DL-based tool using the LSTM algorithm, for the discovery of novel anti-cancer peptides (https://github.com/haichengyi/ACPDL) [20]. AI is increasingly used in determining the proper drug dosage. Shen, Liu et al. [21] created the AI-PRS platform, a neural network-driven methodology that uses a parabolic response curve (PRS) to associate drug combinations and dose to efficacy [22], while machine and statistical learning techniques including k-nearest neighbor (kNN), Naive Bayesian, SVM, ANN, decision trees (DT), and RF are employed to forecast the hindrance in protein-protein interactions [23]. VS is an efficient method in computer-aided drug design (CADD), which involves screening a promising therapeutic compound from a pool of compounds.

ML can be used for VS with a filtered dataset, employing algorithms such as SVM, RF, and DT [24,25]. After validating the trained model for accuracy, it is used on new data sets to screen for compounds that have the desired activity against a target. The shortlisted compounds undergo ADMET (absorption, distribution, metabolism, excretion and toxicity) analysis and various bioassays before entering clinical trials. ML has the power to speed up VS, make it more robust, and even reduce false positives in VS. PARASHIFT, HEX, USR, and Shape algorithms have been constructed for LBVS. In recent years, with the rise of AI algorithms in the healthcare and pharma industry, different tools and models have been developed for both LBVS and structure-based virtual screening (SBVS), i.e., for LBVS, tools include SwissSimilarity, METADOCK, and HybridSim-virtual screening, while for SBVS, tools include Gypsum-DL, ENRI, and SPOT-ligand 2. Drug repositioning involves investigating drugs developed for one diseased condition and repositioning them for other diseased conditions in drug designing and discovery. This approach may be successful due to the possibility of multiple-target involvement in multiple diseases. The emergence of AI-based tools and algorithms in drug discovery provides a platform for future research, and different AI-based algorithms and web-based tools have been developed in recent years, such as DRIMC, DrugNet, DPDR-CPI, PHARMGKB, PROMISCUOUS 2.0, and DRRS.

This review aims to provide a thorough overview of AI's role in drug discovery (Fig. 2). AI can aid in various stages of drug discovery in various ways, including disease identification, target acquisition, computational screening, predicting drug toxicity, gene editing for developing gene therapies, and AI-based modeling for personalized drug dosing. We examine the current state-of-the-art AI technology and its potential to revolutionize drug discovery.

Artificial intelligence and subtypes. Machine learning can be broadly categorized into supervised, unsupervised, and reinforcement learning, which can be further divided into several subcategories. For supervised learning, these include classification, where algorithms categorize input data into predefined classes, and regression, aimed at predicting continuous outcomes from input features. Additionally, unsupervised techniques such as clustering are used to grouping similar data points. These subcategories are fundamental to the architecture of machine learning algorithms, significantly contributing to diverse applications in drug discovery.

Schematic representation of the integration of artificial intelligence (AI) in the drug discovery process. The diagram illustrates the workflow from data collection, encompassing clinical sequencing, experimental text, and molecular structure analysis, to the implementation of AI algorithms and neural networks. The applications of this process include disease diagnosis, target acquisition, and computational screening. This illustration underscores the transformative potential of AI in advancing medical research and healthcare solutions.

## Section: AI-based disease identification

AI has shown great potential in identification of infectious diseases. By analyzing large amounts of data from various sources such as EHRs (electronic health records), social media, and news reports, AI can quickly detect outbreaks of infectious diseases and provide early warning systems. AI can also assist in predicting the spread of diseases by identifying populations at high risk and tracking the movement of infected individuals. Due to its capacity for swift and precise data processing of enormous amounts of data, AI can significantly improve our ability to identify and respond to infectious diseases.

In recent years, the field of AI has shown remarkable progress in disease diagnosis, revolutionizing the way healthcare is delivered. AI technologies such as ML and DL have enabled medical professionals to develop highly accurate and reliable diagnostic models for various diseases. Early detection, precise diagnosis, and individualized treatment plans have all been made possible by the use of AI in disease diagnosis, which has improved patient outcomes. Infectious and non-communicable disease diagnosis using AI has recently made significant strides.

AI methods have greatly advanced the diagnosis of infectious diseases [26]. An exemplary case is the clinical decision support system (CDSS) known as “Sepsis Watch” to detect Sepsis early [27], a severe medical condition that occurs when an infection in the body triggers a chain reaction, resulting in a life-threatening medical emergency, often originating from infections in the lungs, urinary tract, skin, or gastrointestinal tract [28]. Sepsis Watch utilizes a unique ML method that combines multitask Gaussian processes (MGPs) with recurrent neural networks (RNNs) to identify sepsis [28]. The MGP component of the system learns the distributions of continuous functions for each dynamic variable. The system works by sampling dynamic features from the MGP hourly, which are then combined with static features and input into the RNN, a form of DL particularly adept at processing time-series data and essential for incorporating both static and dynamic features of hospital patient encounters [28]. This process generates a sepsis risk score between 0 and 1 for each patient. Additionally, the system includes scripts optimized to run every 5 min to identify patients who meet the sepsis criteria, facilitating early detection and prompt medical intervention [28]. Sepsis Watch has been trained using 50,000 patient records with both static (eg. prehospital patient comorbidities) and dynamic (eg. medication administrations) input features. It has been shown to improve the care of sepsis patients [28]. However, this study had a few limitations, including some false positive predictions that prompted clinical action even though the patient did not ultimately develop sepsis. Additionally, the study was limited to emergency department cases.

During the COVID-19 pandemic, there was a particular focus on the development of AI models for the effective diagnosis of this disease [29,30]. Chest X-ray is one of the efficient indirect methods for COVID-19 diagnosis. It was used to diagnose pneumonia associated with this viral infection [31]. Many ML models have been developed to predict the presence or absence of patterns in X-ray radiographs. For example, Narin et al. proposed an automated convolutional neural network (CNN) based diagnostic model for detecting pneumonia caused by coronavirus [9]. They developed pre-trained AI models using the X-ray radiographs of healthy individuals, patients with COVID-19, patients with viral pneumonia, and patients with bacterial pneumonia. The reported accuracies in classification reached up to 96%. Aapka Chikitsak is an AI-powered conversational bot designed to enhance telehealth services in India by providing accessible COVID-19 information and addressing the imbalance between the demand for and the supply of human healthcare providers. Initially, the user's query is converted from audio input into text, and the text is used as a basis for performing Natural Language Understanding to decode the semantic meaning. Subsequently, relevant entities are identified and linked to their corresponding intents in Dialogflow. The bot then generates a response, converts it to speech, and delivers it back to the user [32].

ML models have also been built to assist in the diagnosis of other infectious diseases such as urinary tract infections (UTIs), which are often associated with high rates of diagnostic errors. Taylor et al. reported a retrospective cohort analysis of approximately 80,387 adults who visited the emergency department with UTI symptoms [33]. Considering symptoms as well as blood and urine sample analyses, six AI algorithms were developed for the diagnosis of UTI: SVM, artificial neural network (ANN), elastic net, adaptive boosting (AdaBoost), RF, and extreme gradient boosting (XGBoost). The models were built using a full set of 211 factors and a reduced set of 10 variables, e.g., gender, epithelial cells in the urine, history of UTI, and age. The XGBoost showed superior accuracy over the other algorithms, with an area under the curve (AUC) of 0.88 and 0.90 for the full and reduced XGBoost models, respectively. The sensitivity and specificity were 61.70% and 94.90% for the full, and 54.70% and 94.70% for the reduced models, respectively [33]. Lifestyle disorders, such as diabetes, obesity, and hypertension, are associated with the way people live, their diet, exercise levels, etc.

ML models have achieved substantial success in the prevention and detection of HIV, a virus causing human progressive immune system failure and promoting cancers. Xiang et al. developed an ensemble approach combining GCN (graph convolutional network) with LR and RF, aiming to identify individuals at high risk of HIV infection for prevention [34]. They built a social network in which each node stood for an individual participant, and the edges between them represented social connections. Each node was assigned with a feature set, including sociodemographic characteristics and sexual behavioral characteristics. The ensemble methods produced promising results on HIV infection detection (GCN+LR with accuracy of 93.4% and F1 of 88.4%; GCN+RF with accuracy of 96.6% and F1 of 94.6%). Heerden et al. created a conversational agent guiding users through an HIV counseling and testing session utilizing NLP (nature language process). This agent encourages the targeted population to openly discuss their concerns with a virtual assistant, and its effectiveness has been confirmed through human evaluation [35]. Compared with previous agents, this agent made testers feel like the session was more private and anonymous with more gentle language and more accurate detection.

Many AI-based algorithms have been developed for the early prediction and management of diabetes. For instance, Spänig et al. developed an interactive AI model with the capability of speech recognition and speech synthesis that acts as a virtual doctor, interacts directly with patients. An open-source system CMUSphinx is utilized to develop robust speech recognition capabilities. To support localized speech recognition, the essential German language data is obtained, including a German language model, an acoustic model, and a dictionary from the VoxForge dataset [36], which aggregates transcribed speech specifically for use in speech recognition technologies. This virtual doctor predicts Type-2 diabetes mellitus with an AUC of 0.84 [37]. The incidence of retinopathy is high among diabetic patients. Gulshan et al. developed a deep CNN model that bypasses the human capacity at interpreting, evaluating, and classifying retinal images. The model is trained using 128,175 retinal photographs which are evaluated by a panel of clinicians and ophthalmologists. The model is demonstrated to have a high sensitivity and specificity of 97.50% and 93.40%, respectively [38]. In 2018, the U.S. Food and Drug Administration approved the marketing of the first AI-based medical device called IDx-DR [39] for detecting diabetic retinopathy. The device has a retinal camera through which the retinal image of the patient is taken and analyzed. The device is autonomous and decides on one of the following results based on the image quality (i) “more than mild diabetic retinopathy detected: refer to an eye care professional” or (ii) “negative for more than mild diabetic retinopathy; rescreen in 12 months” [39].

Alzheimer's disease is a neurodegenerative disorder in the brain. Genetic factors and age are major risk factors associated with AD. However, recent research indicates that other factors, such as environmental and lifestyle factors, can also contribute to the development of AD [40]. AI-based algorithms have shown promising results in the early prediction and diagnosis of AD [41]. For instance, Jo et al. proposed a hybrid model that combines DL -based feature extraction with ML algorithms for AD diagnosis using magnetic resonance imaging (MRI) scans [42]. The proposed model achieved a classification accuracy of 96%. Similarly, Shi et al. developed an AI-based model for the early prediction of AD using positron emission tomography (PET) images [43]. The model achieved an accuracy of 89.5% in predicting the onset of AD within two years. Cancer is another NCD that has benefited from the recent advancements in AI-based algorithms. AI-based algorithms have been developed for various cancer-related tasks, such as diagnosis, prognosis, and treatment planning. For example, Ding et al. developed a DL algorithm that interprets PET of the brain for the early prediction of AD. Their model showed a specificity and sensitivity of 82% and 100%, respectively. This model can predict AD, on average, 75.8 months before its diagnosis, with a ROC (receiver operating characteristic) of 0.98 [8]. Li et al. developed a DL-based model that automatically evaluates dementia severity by analyzing resting-state functional magnetic resonance imaging data (rs-fMRI). The study involved 133 patients with Alzheimer's disease, and their clinical dementia rating (CDR) scores ranged from 0.5 to 3. To extract features, three-dimensional CNNs were applied to rs-fMRI data. The accuracy of the model was found to be highly satisfactory [44]. In addition, AI-based algorithms have also shown promising results in predicting the response to treatment in cancer patients. For example, AI has the potential to improve the speed of analysis and the accuracy of image interpretations. Esteva and co-workers developed a CNN model trained with images of skin lesions to classify different types of skin cancer [45]. Albayrak et al. used deep learning to extract features from breast histopathological images to detect mitosis. The proposed model extracted CNN features for SVM training and detected breast mitosis [46]. Causey et al. developed CNN model-based algorithm, NoduleX to predict malignant lung nodules from clinical CT data. The model was trained using over 1000 lung nodule images from LIDC and IDRI. NoduleX predicted with a 0.99 AUC [47]. Shiri et al. tested ML methods using Radiomics analysis for predicting EGFR and KRAS mutation status in NSCLC (non-small cell lung cancer) patients that showed AUCs of 0.82 and 0.83, respectively [48]. CNN models also power histological image analysis to diagnose cancer [[49], [50], [51]].

AI algorithms have demonstrated promising outcomes in the diagnosis, prediction, and management of non-communicable diseases including diabetes, Alzheimer's disease, and cancer. The implementation of AI-based algorithms can facilitate the early detection of these diseases, thus enabling timely interventions and personalized treatment plans, ultimately leading to improved patient outcomes. By leveraging the power of AI, healthcare professionals can potentially reduce the burden of NCDs, enhance the quality of healthcare delivery, and optimize healthcare resources. The detailed overview of role of AI in disease identification can be seen in Fig. 3.

The overview of AI-based disease identification. AI-based disease identification can be divided into four categories: neurodegenerative disorders diagnosis, cancer diagnosis, infectious disease diagnosis and lifestyle disorders diagnosis.

## Section: Target identification

Target identification is a critical step in the drug discovery process. The traditional approach involves time-consuming and costly experimental methods, such as high-throughput screening (HTS) and X-ray crystallography. However, the use of AI has revolutionized this field by enabling the identification of potential targets through computational methods. Fig. 4 illustrates how AI-aided role in drug discovery.

AI-based target identification involves the use of ML algorithms to analyze large datasets and identify targets with the potential to interact with a given drug. This approach utilizes various data sources, such as gene expression profiles, protein-protein interaction networks, and biological pathways, to generate a list of candidate targets [52]. ML algorithms, such as SVMs and neural networks, can then be used to prioritize these targets based on their relevance to the disease of interest.

Furthermore, AI-based target identification can help identify novel targets that were previously unknown or overlooked. By analyzing large datasets from various sources, ML algorithms can uncover hidden patterns and relationships that may not be immediately apparent using traditional methods. This can lead to the discovery of new biological pathways and targets that may have therapeutic potential. AI-based target identification has the potential to revolutionize the drug discovery process by enabling the identification of potential targets through computational methods. There are multiple experimental methods available for identifying drug targets, such as affinity pull-downs and genome-wide knockdown screens. However, these approaches require a significant amount of labor, resources, and time, and are also subject to a high rate of failure. In contrast, computational methods have the potential to significantly decrease the effort and resources required for drug target identification [53].

Cryo-EM, or electron cryo-microscopy, revolutionized the investigation of proteins and protein complexes in the 1980s. Single-particle analysis (SPA), electron cryo-tomography (cryo-ET), microcrystal electron diffraction (MicroED), low-energy electron holography (LEEH), and cryo-scanning transmission electron tomography (CSTET) are a few examples of cryo-EM imaging techniques [54,55]. For a deeper understanding of the structures of protein complexes in their environment, cryo-electron tomography (cryo-ET) has shown great promise. Computer algorithms are used to combine these images to create a 3D structure representation.

The software CryoDRGN, created by Zhong et al. [56], uses ML to enable the reconstruction of proteins and protein complexes from heterogeneous cryo-electron microscopy data [56]. In order to embed heterogeneous single-particle cryo-EM images in a low-dimensional latent space and produce 3D volumes as a function of this embedding, the authors have proposed a technique that makes use of ML models. CryoDRGN can produce an infinite number of maps from the imaged ensemble and is capable of modeling complex ensembles with both continuous and discrete heterogeneity. The software can also visualize the motion of the protein [57].

Trypsin is one of the most important and widely used proteolytic enzymes in mass spectrometry (MS)-based proteomic research. The digestion of proteins by protease enzyme is a basic step in the protein identification using MS. A few AI tools were developed to efficiently predict the digestion behavior of the protease enzymes [58,59]. DeepDigest is the first algorithm developed using a DL method to predict the proteolytic cleavage sites of eight different protease enzymes (trypsin, ArgC, chymotrypsin, GluC, LysC, AspN, LysN, and LysargiNase). The DL model was trained on 19 public large-scale data sets covering the eight proteases from samples of four organisms (E. coli, yeast, mouse, and human). The predictive ability of the tool was evaluated by the AUC, F1 scores, and the Matthews correlation coefficients (MCCs); the values were 0.956–0.98, 0.66–0.90, and 0.65–0.84, respectively [58]. Sun et al. developed an algorithm to predict the missed cleavage site in the tryptic protein digestion [59]. The algorithm is demonstrated to have a high accuracy, with an AUC of 0.99. This algorithm can be incorporated into the peptide database search in the MS analysis to facilitate the identification of proteins more effectively and efficiently.

The development of computational tools, high-performance computers, and ML algorithms is not limited to three dimensional (3D) models of protein targets but also enabled a large number of drug discovery tools. This is a significant advancement in experimental techniques that are fraught with challenges. For example, the X-ray diffraction technique is limited to crystallizable samples, which is a major experimental limitation [60].

In the absence of experimental data, computational techniques have been used for decades to forecast the three-dimensional structure of proteins. Modeller, a homology modeling software, predicts a protein's structure based on its alignment to one or more proteins of known structure (templates) [61]. AlphaFold, the DL algorithm developed by DeepMind, a UK based company, predict the 3D structure of proteins from their amino acid sequences [62]. The development of this AI- tool is claimed to be a breakthrough in drug discovery as it was used to solve the structure of nearly 200 million proteins, which is ∼98.5% of the proteins in the human body. In July 2021, the predicted three-dimensional models for the whole human proteome generated using AlphaFold, were made available to the public, as recently reported in Nature [63]. Together with the European Bioinformatics Institute (EMBL-EBI), a database called AlphaFold DB (https://alphafold.ebi.ac.uk/) was created to store all the structures solved so far with AlphaFold. However, the effect of mutation on the folding of proteins is beyond the capability of AlphaFold [64]. It is also limited to predicting only a single state of a given protein, it does not consider the dynamic nature of protein structures [65]. Recently, new methods based on natural language processing (NLP) which only uses the amino acid sequences from sequence databases to learn structural, functional and evolutionary patterns and predict structural conformation. In 2022, two methods gained attention i.e. ESMFold and EMBER3D. ESMfold, developed by Lin et al. in 2022, utilizes a masked transformer protein language model with a deep understanding of biological properties, trained with 15 billion parameters. While it falls short of AlphaFold2 in overall performance, as indicated by lower TM-scores (0.68 compared to AlphaFold2′s 0.85 on CASP14), ESMFold outperforms AlphaFold2 when evaluating the amino acid sequence alone without multiple sequence alignment (MSA) (0.68 versus 0.37 on CASP14). ESMFold demonstrates comparable accuracy to AlphaFold2 for structures predicted with high confidence, exhibiting a median all-atom RMSD (root-mean-square deviation) of 1.91Å and a backbone RMSD of 1.33Å—achieving accuracy levels akin to experimental results. Additionally, ESMFold shows a substantial improvement in prediction speed, eliminating the need for MSA construction. The authors leverage this approach to introduce the ESM Metagenomic Atlas, predicting over 617 million structures from metagenomic databases. Among these, 225 million structures are predicted with high confidence, including novel ones [63]. While Ember3D falls short of surpassing AlphaFold in performance, it exhibits significantly faster processing speeds compared to both AlphaFold and ESMFold. Notably, AlphaFold2 struggles to efficiently investigate the impact of single amino acid variants on protein structure. In contrast, Weissenow et al. [64] demonstrated that Ember3D's predicted distance maps show a strong correlation with native and mutant 3D structures obtained through deep mutational scanning, outperforming ESMFold in this regard. The researchers also developed a tool that highlights differences between native and mutant predicted structures for all possible amino acid exchanges at each position in a protein sequence. The tool utilizes the similarity between the native and mutated amino acids to identify exchanges that may have a significant impact on the protein structure [64]. Cheng et al. introduced AlphaMissense, a DL model that extends the capabilities of the AlphaFold2 protein structure prediction tool. This model undergoes training with population frequency data and incorporates both sequence information and predicted structural context to enhance its overall performance. AlphaMissense effectively categorizes 32% of all missense variants as likely pathogenic and identifies 57% as likely benign, achieving a 90% precision cutoff on the ClinVar dataset. This outcome ensures a robust prediction for the majority of human missense variants [65]. A specific and detailed review [66] on all the recent advances in protein structure prediction are reviewed by Peng et al. Some breakthrough protein structure prediction models are tabulated in Table 1.

In addition, AI algorithms can predict the likelihood of allosteric regulation in a protein based on its structure and ligand presence, and identify allosteric modulators that may modify its activity [66]. ML methods, like Allosite; developed by our group [67], and AlloPred [68], used SVM with optimized features for protein pocket classification [69], while others used RF [70] to build a three-way predictive model. Advanced ML models, such as XGBoost [71], can now classify allosteric sites with greater accuracy. XGBoost implements the gradient boosting algorithm with regularized terms to reduce overfitting and has demonstrated superior predictive performance in protein-protein interactions [72] and hot spots [73] compared to SVM and RF.

Tian et al. developed a webserver called PASSer (Prediction of Allosteric Sites Server), combining the results of XGBoost and GCN to predict the allosteric sites on proteins using an ensemble learning method. A total of 1946 entries information of allosteric sites from Allosteric Database were collected for training with 19 descriptors extracted for each site by Fpocket. For a given pocket, physical properties are calculated and fed into the XGBoost model while an atomic graph is fed into the GCNN model. The final result is the averaged probability of these two models. The model showed an accuracy of 0.97, precision of 0.73, and specificity of 0.98. The aforementioned model can acquire knowledge about both the physical traits and topology of allosteric pockets and has been demonstrated to outperform the XGBoost and GCN models individually. The findings are consistent with earlier research and have a greater likelihood of placing allosteric sites in top positions. The online server is equipped with an easily navigable interface. Protein structures and top pockets are displayed in an interactive window on the result page [66].

Protein structural fluctuations generate novel cryptic pockets [[74], [75], [76], [77]], which offer druggable sites beyond experimentally determined structures. Cryptic pockets regulate protein functions allosterically. These pockets are hidden protein cavities that open up when ligands or protein partners bind [78]. Targeting these cryptic pockets offers drug development opportunities. Cryptic pockets can target undruggable proteins [79]. An algorithm to predict which proteins have cryptic pockets could help prioritize proteins to target in cases where proteins lack ground state pockets or modulators are difficult to design. CryptoSite is an excellent supervised ML algorithm that predicts ligand-binding cryptic pockets from protein structures [80]. CryptoSite accurately predicts cryptic pocket participation for amino acid residues (ROC-AUC = 0.83). Miller et al. developed PocketMiner, a graph neural network (GNN), to predict cryptic pockets in protein structures. The model is trained using residues likely to form cryptic pockets from 2400 simulations of 35 proteins. Model AUC was 0.87. This supports molecular dynamics simulations for cryptic pocket identification [78].

Madhukar et al. developed BANDIT, a Bayesian ML platform for drug target prediction that integrates multiple data types to achieve greater predictive power. BANDIT utilizes over 20 million data points from six distinct data types, including drug efficacies, post-treatment responses, bioassay results [81,82], and known targets [83,84]. The platform achieves high accuracy at identifying shared target interactions and uncovers novel targets for cancer treatment. BANDIT was tested on ∼2000 compounds and can quickly pinpoint potential therapeutics with novel mechanisms of action to accelerate drug development.

In 2021, Kozlovskii and Popov developed a DL approach to predict the binding site for small molecules on nucleic acids, DNA, and RNA, based on their 3D structures [85]. Their approach is called BiteNetN (https://sites.skoltech.ru/imolecule/tools/bitenet/) having a large dataset of 1933 nucleic acid-ligand complexes, including 1065 DNA and 886 RNA structures (18 structures contain both DNA and RNA) of different type. It was the first 3D CNN to learn features directly from nucleic acid structures. They validated the model using two different protein structures, HIV-1 transactivation response element RNA and ATP-aptamer structures. The model showed an AUCROC of ca. 0.87, proved to be top-performing for protein-small molecule and protein-peptide binding site detection [86,87].

DeepDTnet is a network-based DL method developed by Zeng et al. to aid the target identification process [88]. The model is trained with chemical, genomic, and cellular network data for the accurate prediction of molecular targets. The model is shown to have a high accuracy in prediction with an AUC of 0.96 [88]. In another study, Mamoshina et al. developed ML techniques to analyze human muscle transcriptomic data to discover biomarkers associated with muscle-related diseases and to identify tissue-specific drug targets [89]. The authors collected transcriptomic data from human muscle tissues and used a combination of unsupervised and supervised ML algorithms to identify differentially expressed genes and gene modules that are associated with muscular dystrophy and sarcopenia. They further investigated the identified gene modules and pathways using functional annotation and network analysis tools to identify potential drug targets. Their best model showed a Pearson correlation of 0.80.

After identifying the protein targets, corresponding novel lead compounds can be further generated from scratch, leveraging the pocket features and ligand topology. Zhang et al. developed a pocket-aware ligand generator ResGen. A two-level autoregression protocol for molecular generation is introduced in the model to better incorporate the geometry of protein pockets. The global autoregression is to generate atoms in pockets, and the atomic autoregression is to produce the coordinates and topology of the newly added atoms. ResGen could generate more physically sensible molecules with tighter binding [90]. Wei et al. developed a fragment-based generation model Lingo3DMol built on the transformer-based structure [91]. A new molecule representation FSMILES is introduced, enabling the generation of 3D molecules with reasonable conformations and topology. Additionally, non-covalent interactions and ligand–protein binding patterns are also considered during the generation. Lingo3DMol demonstrates excellent performance in terms of drug likeness, synthetic accessibility, pocket binding mode and molecule generation speed.

The overview of the AI-based process for identifying and evaluating small molecules. Beginning with target acquisition, where protein sequences are modeled using tools like Modeller and AlphaFold2, followed by Homology Modeling and validation of protein 3D structure through ProQ and SolvX. Next is the pocket exploration, including the identification of both orthosteric and allosteric binding sites within the protein proteome, via static and dynamic structures. The hit identification stage employs SBVS and LBVS to pinpoint potential compounds. Finally, the toxicity prediction stage uses pattern recognition techniques in AI/ML to predict the ADMET properties.

List of the methods for protein structure prediction with their standlone availability links.

## Section: AI-enabled virtual screening in drug discovery: opportunities and challenges

The initial phase of drug discovery usually involves computational screening of numerous compounds to identify those with the desired cellular or biochemical effects. To enhance the speed, efficiency, and cost-effectiveness of this process, new methods are constantly being developed. A positive response during the first round of screening in a biochemical assay identifies primary “hit” compounds. Subsequently, additional screening is performed to assess whether the physicochemical and pharmacological properties of the hit compounds are suitable for developing a medicine. If they pass this filter, they are designated as “leads”. These leads are then refined chemically and subjected to biological screening in subsequent rounds before proceeding to clinical testing. With some luck, a lead may ultimately receive drug approval, a process that may take 12–15 years from the beginning of testing [92].

Despite significant advancements in drug discovery and medicinal chemistry technologies, drug development still remains a slow and expensive process. The current standard process involves HTS, where in vitro assays are conducted on thousands of compounds to identify hit compounds that can be optimized to lead compounds with desirable properties such as increased potency, solubility, and reduced toxicity and off-target effects [93].

The conventional drug discovery process involves synthesizing and testing thousands of compounds, which is both time-consuming and costly, requiring large amounts of protein supplies and established laboratory methods for bioactivity testing. In contrast, VS has emerged as a cost-effective approach to scan millions of commercially available compounds and prioritize those for further testing, synthesis, or purchase. VS methods are classified into two categories: structure-based and ligand-based methods. However, despite the potential benefits, it still takes an average of 10 to 15 years and over $2 billion to develop a single drug [94].

## Section: AI-enabled virtual screening in drug discovery: opportunities and challenges › Structure-based methods

To utilize structure-based methods, 3D structural information of the protein-ligand complex or at least the protein's binding site is needed. Molecular docking is a commonly used technique that generates multiple possible binding poses of a ligand in the target protein structure and ranks them using a scoring function (SF) [95] to estimate their binding affinity [96]. Recently, machine/DL-based SFs [21] have been introduced as a new group of SFs. On the other hand, ligand-based methods such as QSAR modeling, molecular similarity search, and ligand-based pharmacophores, are more established technologies that require only ligand information [97], unlike structure-based methods. AI techniques can also be employed to improve the efficiency of computer-aided drug discovery processes, which often need extensive high-performance computing resources and significant computation time.

Gentile et al. reported an open-source protocol for AI-enabled VS methods to screen libraries with billions of molecules. They used a screening platform called Deep Docking (https://github.com/jamesgleave/DD_protocol) which can accelerate the SBVS by 100 folds. The input data consists of the molecule's SMILES with its Morgan fingerprints as descriptors and the target's structure. Deep Docking performs molecular docking for a small subset of a large library based on DNN to infer the ranking of the yet-unprocessed remainder, followed by ligand-based prediction of the docking for the rest of the library. In this way, Deep Docking discards undockable molecular structures without wasting computational resources. A key advantage of this protocol is that it can be used in conjunction with other docking programs such as Glide, Autodock-GPU, and FRED from OpenEye. Although, the deep docking method provides faster screening, it is limited to I) the availability of graphical processing units (GPU) and ii) the quality and accuracy of the docking program used [10].

Various ML techniques, including Naïve Bayesian (NB) classifiers, kNNs, SVMs, RFs, and ANNs, can be used for VS. While SVMs and ANNs are commonly regarded as the most accurate, each technique has its own strengths and weaknesses. For instance, NB excels at identifying favorable scaffold fragments, RFs can be parallelized and boosted, and kNN is simple to implement and can utilize MTL. Combining an ensemble of ML models is often preferred as it can enhance performance [98].

For LBVS, NB classifiers are widely utilized and exhibit excellent performance. Wang et al. investigated four classification models to identify inhibitors of methicillin-resistant Staphylococcus aureus. These models include NB, SVM, recursive partitioning (RP), and kNN algorithms, incorporating various sets of physicochemical descriptors and fingerprints. Among these models, the NB classifier displayed the highest performance in the testing set of, achieving an accuracy of 0.891 and a specificity of 0.920 [99]. Likewise, Lian et al. [100] showed that NB models outperformed SVM models with an accuracy of 0.975 and a specificity of 0.989 in classifying the inhibitors and non-inhibitors of neuraminidase. They further identified nine effective inhibitors of neuraminidase using an enhanced ensemble model comprising NB models and SVMs.

Another simple ML classification method is kNN. Unlike NB, kNN is intuitive. In searching for G-Protein Coupled Receptor ligands, Luo et al. found that kNN-QSAR with variable selection outperformed LBVS approaches without ML [101]. Compared to other ML methods, kNN's performance is usually in the middle [99,102]. kNN is less popular than the ML methods below because of this. In screening for Estrogen Receptor-mediated endocrine disruptors, kNN has been used for VS [103].

Vapnik et al., introduced SVMs for the first time [104]. They function by representing input data as feature vectors and plotting them within the same-dimensional space. Although SVM can be used for unsupervised learning, supervised learning is preferred for VS because it guarantees that a compound will eventually be categorized as active or inactive. Chandra and colleagues conducted a study to identify potential inhibitors for PTP1B, a treatment for Type 2 diabetes [105]. Multiple ML models were developed, and the best model that utilized SVM was applied to an external database. This model successfully identified five inhibitory compounds, two of which demonstrated significant activity in vitro. In a separate study, Deshmukh et al., [106] discovered that their SVM model was able to identify almost half of the known FEN1 inhibitors in a test set, and also identified previously unknown inhibitors from the Maybridge small molecule database, which were experimentally validated. Baba et al. found that SVM models with regression were more effective than RF in predicting a compound's ability to permeate the skin[107]. Lee et al., [108] employed RF-QSAR to study compound polypharmacology, resulting in the creation of a targetfishing server that identifies possible targets for a given compound. Their method achieved an overall AUC score of 0.97 and outperformed NB-based methods in external testing [109].

## Section: AI-enabled virtual screening in drug discovery: opportunities and challenges › Ligand-based virtual screening (LBVS)

LBVS is based on selecting, from databases, molecules that share similar structural features with an active ligand. Pharmacophore-based VS is one of the LBVS techniques. It involves building 2D fingerprints of one or more active ligands using molecular descriptors such as hydrogen-bond donors, hydrogen-bond acceptors, and aromatic rings. These 2D fingerprints are then used to identify molecules, from large chemical libraries, which have matching pharmacophoric features. ML also helps to study the correlation between molecular descriptors (or even atomic descriptors [110,111] and the biological activity of a ligand. This is a broad category of research known as Quantitative Structure-Activity Relationship (QSAR), where the activity of a ligand depends on its pharmacophoric features. Melge et al. developed hybrid inhibitors using the pharmacophore fingerprint of two well-known anti-cancer drugs Ponatinib and Vorinostat [112]. They developed a supervised ML approach for 2D-QSAR and 3D-pharmacophore studies to predict the inhibitory activity of novel hybrid molecules. The model had AUC values of 0.98 and 0.94 for the two different cancer targets, BCR-ABL and Histone deacetylase (HDAC), respectively. Based on in-vitro evaluations, the identified novel hybrid molecules showed the potential to develop into lead compounds. Dhamodharan et al. developed three AI models based on genetic function approximation (GFA), SVM, and ANN, to predict the activity of acetylcholinesterase (AChE) and Beta-Secretase 1 (BACE1) dual inhibitors for AD treatment [113]. The predictive power of the models was evaluated on a test set of 11 inhibitors of AChE and BACE1. The ANN model had the best predictive power with R2 (coefficient of determination, a statistical measure within regression analysis) values of 0.85 and 0.78 for AChE and BACE1, respectively. Dhamodharan et al., [113] used a target-specific scoring model to identify potential inhibitors for 12 targets from the SAM MTase family. 446 actives and 1294 decoys were docked using Glide and the DUD-E website. The MLP outperformed other docking tools in a binary classification experiment.

Atomwise, Inc. developed AtomNet, one of the earliest CNNs utilized for VS [113]. Unlike most ML-based VS, AtomNet employs an SBVS and its architecture includes input and logistic-cost layers, four convolutional layers, and two fully connected layers. The filters in AtomNet's convolutional layers correspond to chemical functions, allowing the network to identify features that aid in binding. AtomNet consistently achieves AUC scores >0.74 on various benchmark datasets, outperforming numerous previous docking models. These features and capabilities, previously exclusive to NB and RF classifiers, now enable ANNs to identify features that aid in binding, making them more accurate and less of a black box in VS.

Alzheimer's disease is characterized by amyloid-beta (A) plaques and neurofibrillary tangles (NFT) of hyperphosphorylated tau protein. Acetylcholine (ACh) levels are lower in AD brains [[114], [115], [116]]. Tau may be phosphorylated by GSK-3, CDK5, and other Alzheimer's disease-related enzymes and targets [[117], [118], [119]]. Side effects from polypharmacy are possible. Drugs that target one protein frequently have side effects on other proteins as well. Through the inhibition of multiple targets in complex diseases like Alzheimer's, polypharmacology can increase a drug's effectiveness. With this technique, MTDL (Multi-Target Directed Ligands) screening was increased [43]. Using NB and RP classifiers in an LBVS on MTDLs, Fang et al. discovered compounds that bound to 25 targets, including BACE1, the M1 subtype of mAChR, APP, CDK5, and GSK-3 [120]. The model was validated using current AD medications, and it was used to forecast upcoming MTDLs. As scientists become more aware of its effectiveness, ML in VS for drug discovery will expand. The effectiveness and cost of drug discovery will be enhanced by computer science and medicinal chemistry.

ML-based screens are computationally efficient and successful in modern CADD, which requires vast computational resources to screen expanding chemical libraries due to automated synthesis and robotics. OpenEye GigaDocking and VirtualFlow are supercomputing platforms for docking large libraries that have screened billions of molecules using thousands of CPUs/GPUs in relatively short periods [121]. However, they are resource-intensive compared to Deep Docking (DD) [122]. DD requires fewer computational resources, making it an attractive alternative for large-scale VS.

Gentile et al. developed an open-source protocol for AI-enabled VS of billion-molecule libraries. Deep Docking (https://github.com/jamesgleave/DD_protocol), a screening platform that accelerates SBVS by 100-fold, was used. One of the fastest AI-enabled docking platforms and the only one tested on 1B+ libraries is DD. The DD protocol does not require a docking program, so it can be used with emerging large-scale docking methods to improve throughput. technical limitation of Deep Docking is GPU acceleration, which is needed for optimal performance unlike CPU-based docking platforms. The protocol only provides docking details for top-scoring molecules, ignoring large fractions of chemical libraries for fast VS. Docking campaigns assessing hit rate variability with docking scores [123] or rescoring low-ranked molecules [124] should consider a bruteforce approach. A docking program's ability to prioritize active molecules from an ultra-large library also determines the quality of DD results [123]. Bender et al.'s guidelines for large-scale docking benchmarking are helpful [122].

A wave of DL methods and applications has improved affinity—and other properties like ADMETox—prediction in VS over the last decade(s). Models learn characteristics rather than using human-designed descriptors. Novel encodings like voxels (where physicochemical atomic properties are pinned to locations in 3D space) and graphs (which describe bonded and non-bonded connectivity between atoms) appear to capture the variety of information needed for ligand-binding. DeepAtom [125], a 3D grid-based method that assigns physicochemical properties to each grid cell, may be suitable for modeling protein-ligand binding complexity. The study [126] and DGraphDTA model [127] show that encoding chemical and biological objects as graphs works well. Despite this, several challenges remain, and new ones have emerged, including chemical encoding precision, generalization of chemical space, lack of (large and high-quality) data, model comparability, and interpretability.

Finding new therapeutic uses for already-approved drugs is a crucial aspect of drug repurposing. Due to their previously tested pharmacokinetics and toxicity, repurposed medications have a higher success rate [128,129]. Drug repurposing skips lead optimization and pre-clinical studies to enter phase-II trials. Due to complex disease pathophysiology, many drugs have off-target binding and are excluded from pre-clinical trials [130]. Reker and colleagues developed a method to predict molecular targets of known drugs and computer-generated de novo small molecules, including key-target and off-target proteins. Self-organizing map-based prediction of drug equivalence relationships (SPiDER) is this method. The software was trained on 12,661 manually curated active molecules [131]. The ROC ranged from 0.86 to 0.93 in a 10-fold cross-validation of SPiDER's predictive ability.

## Section: Prediction of drug toxicity with AI

Proportion of drug candidates being discarded during clinical trials due to unexpected adverse effects. Predicting drug toxicity during preclinical stages is a crucial step to reduce the failure rate and improve the efficiency of drug discovery. Traditional methods of predicting drug toxicity are limited by their reliance on small datasets and simplistic models. However, AI-based approaches have emerged as promising alternatives, leveraging large and diverse data sources, including chemical structures, biological pathways, and clinical data. By utilizing ML algorithms, AI-based approaches can improve the accuracy and efficiency of predicting the potentially toxic effects of new compounds, helping to mitigate risks associated with clinical trials, reduce drug development costs, and ultimately lead to better patient outcomes.

Recently, the use of AI-based computational models to forecast drug toxicity has grown in popularity [132]. Large drug and toxicity data sets have been analyzed in a number of studies using ML and DL algorithms, such as neural networks, to identify potential toxic effects during drug development. By identifying toxicities early on, these models can speed up the development of new drugs. Additionally, AI-based toxicity prediction models can prioritize compounds for testing and find new drug targets and toxicity mechanisms. AI toxicity prediction has been the subject of several reviews [[132], [133], [134], [135], [136], [137]]. A single review is challenging due to the wide field of AI-based toxicity prediction's numerous toxicity properties. Recent AI-based toxicity prediction models and in-depth studies of toxicity properties are required to develop, optimize, and improve a model. For four important toxicity properties, recent ML and DL-based AI-based drug toxicity prediction methods are presented.

## Section: Prediction of drug toxicity with AI › Cardiac side effect prediction

ML-based methods, including RF, SVM, NB, SVR, kNN, DT, GB (gradient boosting), PLS (partial least squares), and XGB, are commonly used in predicting hERG toxicity (a gene related to a potassium channel in the heart, and is used to evaluate cardiac side).

Venkatraman developed an ADMET prediction model using ECFP6-based RF models [138]. A total of 7889 compounds were assembled from 4 well-defined experimental assays with experimental hERG blocking bioactivities for training, where compounds with experimental values less than or equal to 10 μM were regarded as positive samples (4355 in total) and the others as negative samples (3534 in total). RF builds multiple DT on the data and merges them together to get hERG toxicity. This model achieved an 80% accuracy and 88% ROC-AUC.

Hsiao et al. [139] and Arab et al. [140] also used the RF model with high accuracy. Ogura et al. developed an SVM model using ECFP_4 structural fingerprints and 72 NSGA-II-selected descriptors, outperforming other predictors with 98.4% accuracy and 0.733 kappa statistic [141]. Konda et al. [142] generated hERG classification models with 2D descriptors using RF, SMO (sequential minimal optimization), and MLP (multilayer perceptron) algorithms, with their consensus model outperforming other predictors with 92% accuracy. DNN, ANN, RNN, CNN, GNN, GCNN, and GAT are used in developing hERG predictive models. Shan et al., [143] generated a directed message-passing neural network (DMPNN) model with moe206 descriptors that outperformed other models with an accuracy of 80% [143]. Zhang et al., [144] developed HergSPred, which outperformed other models, achieving an accuracy of 98.3%. Ryu et al. [145] developed DeepHit, which outperformed other tools in terms of accuracy, MCC, and SE (sensitivity). Wei et al. created Interpretable-ADMET, achieving the highest accuracy (91.9%) and ROC-AUC (78.2%) on 8672 compounds. ADMETLab 2.0 achieved the highest accuracy and ROC-AUC of 88.9% and 94.3%, respectively, on a large hERG data set containing 13,845 compounds, utilizing a multitask graph attention framework (MGAF) to predict ADMET properties.

## Section: Prediction of drug toxicity with AI › LD50 prediction

In Toxicologists use the LD50 (median lethal dose) to determine a substance's toxicity. The dose needed to kill 50% of test animals in a particular period of time is referred to as the LD50 value of a chemical. The LD [146] is used as the first step in the drug screening process. Rats' acute oral toxicity was evaluated using LD50. Interspecies variability and ethical issues render conventional LD50 testing obsolete [147]. Acute animal toxicity tests using tissue culture and in silico LD50 prediction are gradually being replaced [148]. The binary classification model divides substances into two categories: toxic (LD50 = 2000 mg/kg) and nontoxic (LD50 = 50 mg/kg).

Compounds are divided into multiple classes by the Globally Harmonized System of Classification and Labeling of Chemicals and the US Environmental Protection Agency [149]. Recent releases of the ADMET prediction programs FP-ADMET [138] and Interpretable-ADMET [150], in these both applications, LD50 prediction models are applied.

Ballabio et al. developed LD50 prediction models using the binary fingerprints of NB, N—Nearest Neighbors, Binned-Neighbors, and Extended Connectivity [151]. They found that their models were 84% sensitive and 81% specific for 8992 chemicals. An integrated QSAR model for 8448 compounds was created by Gadaleta et al., [152], by combining balanced RF, regression, aiQSAR, istkNN, SARpy, RF with hyperparameter tuning, and a general linear model [153]. The ideal model's RMSE (root-mean-squared error) was 0.477%, and its accuracy balance was above 70% for multiclass endpoints and 80% for binary endpoints.

Jain et al. [154] created a multitasking DL consensus model using RF, DNN, CNN, and GCNN on a dataset of 80,081 compounds that outperformed other models with RMSE of 0.65 and R2 of 0.5. Using the same dataset of 7413 compounds, BTAMDL predicted LD50 with a higher degree of accuracy than MolGIN (RMSE = 0.557, R2 = 0.662). Using the 7413-compound TopTox data set from the ECOTOX aquatic toxicity database, Karim et al., [155] proposed QuantitativeTox, a DL framework utilizing FFNN, CNN, GCNN, and baseline feature representations. This model outperformed others (R2 = 0.687), and it was adopted.

## Section: Prediction of drug toxicity with AI › Drug induced liver injury (DILI) prediction

Drug or chemical toxicity causes DILI [156]. It causes 32% of drug recalls, which worries researchers and doctors [157]. Predicting human DILI with in vitro or animal studies is difficult. RF, kNN, SVM, deep neural network (DNN), CNN, and GNN can predict compound properties from chemical structure. Recent reviews have examined AI methods for DILI in silico prediction [[158], [159], [160]].

Recent ML techniques, such as RF, LR, NB, SVM, kNN, AB, GDBT (gradient boosting decision trees), and ET (equivariant transformer) [138,[161], [162], [163], [164], [165]], have been applied to the development of accurate DILI prediction models. Mora et al. created an ensemble model based on QuBiLS-MAS Features and Shallow Learning using k-NN, MLP, RF, NB, SVM, LR (logistic regression), classification tree, Fisher's linear discriminant analysis (FLDA) [164], and Bayes network algorithms, which achieved an 84% accuracy rate over 10-fold cross-validation using a training set of 1075 compounds from a previous study [166]. Using a dataset of 2608 chemicals and SVM and hybrid quantum particle swarm optimization algorithms, Wang and Chen constructed five consensus models with an 80% accuracy rate [165].

ADMETLab 2.0 [167], FP-ADMET [138] and InterpretableADMET [150], are ADMET prediction software with over 79% accurate DILI prediction models. DL improves the accuracy of DILI prediction. Li et al.'s [168] DeepDILI model outperformed five ML algorithms and two advanced ensemble methods. Using Transcriptional Response Data and GNN, Hwang et al. [169] developed GLIT, a DILI prediction model that outperformed baseline models with 77.3% accuracy. With a multiview GNN approach, Ma et al. [170] increased accuracy from 78.8% to 81.4% and ROC-AUC from 86.6% to 88.8%. Using CNN algorithms and molecular fingerprint-embedded features, Nguyen-Vo et al. [171] developed a DILI prediction model with 89% accuracy and 96% ROC-AUC. CNN's ResNet18DNN achieved a 95.8% success rate on 1446 compounds [172]. These methods may reduce drug recalls and improve the accuracy of DILI prediction.

## Section: Prediction of drug toxicity with AI › Carcinogenesis prediction

Potentially carcinogenic substances must be identified in order to prevent environmental cancers [173]. Many FDA-approved medications have been withdrawn due to their carcinogenic characteristics. Short-term biological studies and theoretical models have been tested to find such compounds. ML and DL techniques can be used to replace, scale back, and enhance animal studies.

Recently, a number of AI-based models and tools for compound carcinogenicity prediction were created [[174], [175], [176], [177], [178]]. Using hybrid neural networks (NN), Limbu and Dakshanamurthy developed carcinogenicity prediction models with an average accuracy of 74.3 and an average ROC-AUC of 80.1 [174]. Due to sparse data sets, DL models have low predictive accuracy. Wang et al. developed CapsCarcino, a new DL architecture, to address this problem [175]. On a set of external validation data, CapsCarcino had an average accuracy of 74.5 percent and an accuracy prediction rate of 83%. On sparse training data that was arbitrarily reduced to 20%, 40%, 60%, and 80% of the full training data, CapsCarcino performed better than other models. Li et al. developed the DeepCarc model, which has an average improvement rate of 37.0% and an accuracy of 75.4%, using 863 compounds and three descriptors [176]. Other reviews [173,179] cover additional models.

## Section: AI and gene editing technologies for developing gene therapies

With the growing accumulation of genomic and clinical data, data scientists face both challenges and opportunities when attempting to extract biologically or clinically relevant information from massive genotype and phenotype datasets. In genomics, AI-based technologies and data science techniques have been utilized effectively over the past two decades.

A significant amount of phenotypic information can be found in the clinical notes, discharge summaries, radiology, and pathology reports that make up about 80% of the unstructured data in EHRs [180]. Clinical NLP methods like cTAKES can parse semantic relationships and extract structured concepts from free text to extract this information. The accuracy of phenotyping has significantly improved with the use of NLP techniques in combination with structured and unstructured data. According to Liao et al.'s analysis of structured data, NLP can be added to it to increase sensitivity while preserving a high positive predictive value for a variety of illnesses, such as multiple sclerosis and inflammatory bowel disease [181].

A study on phenotyping rheumatoid arthritis using structured data (ICD codes and medication data) and clinical concepts derived from NLP shows how ML has been used to create phenotyping models. The SVM models outperformed rule-based techniques in accuracy [182], proving that a high-performing classifier can be built without the use of feature engineering. ML techniques are more scalable, work with less standardized datasets than rule-based approaches, and can capture more complex phenotypes.

However, manually labeled gold standard training and test datasets are crucial for developing and validating supervised ML models. However, creating them requires considerable time and expertise. To address this, unsupervised learning techniques have been proposed to generate patient clusters for specific medical conditions without human supervision. Ho et al. used the “Limestone” non-negative tensor factorization technique to automatically generate multiple phenotype candidates without predefined definitions [183]. A medical professional determined that only 40 of the top 50 candidates are necessary for higher predictive accuracy of patients at risk of heart failure. Two upgraded variations of Limestone, Marble, and Granite, showed improved performance [184,185]. Numerous phenotyping methods have been reported in line with the use of DL approaches, including Gehrmann et al., [186] and Yang et al., [187] use of discharge summaries or clinicians' notes, and Miotto et al., [188] de-noising auto-encoders for auto-encoding.

In genomics research, DL has emerged as a prominent class of algorithms owing to its capability to effectively handle large datasets with high dimensionality. A plethora of DL-based models have been developed and utilized for designing gRNA (guide RNA), incorporating features from both sequence and secondary structure data. Additionally, transfer learning, a ground-breaking innovation in computer vision, has been used in genomics research as well to take advantage of trained models and only need small sample sizes [189]. Moreover, BERT models have been specially created for NLP tasks in the clinical domain [190]. ClinicalBERT and Discharge Summary BERT were developed by Alsentzer et al., [191] and pre-trained on millions of clinical notes from the MIMIC-III database [192,193]. These MIMIC notes were split into sections followed by sentences extraction as input into the model, which captured contextual relationships between words bidirectionally. These models were pre-trained and fine-tuned for downstream tasks, outperforming BERT and BioBERT on three clinical NLP tasks. In order to predict hospital readmission, Huang et al. also created ClinicalBERT, but they also emphasized the drawbacks of using data from a single healthcare institution. Retraining on bigger databases of clinical notes is advised as a result for better performance. These advancements demonstrate how ML and its related fields can enhance genomics and clinical research.

## Section: AI-based modeling for personalized drug dosing

Traditionally, clinical practice has been based on the concept of “one therapy fits all’. However, drug molecules may undergo different metabolic activities in different patients. For example, a drug that works well for a group of people may not be as effective or may have adverse side effects for others. These differences in drug metabolism are mostly attributed to the differences in the genetic profile of individuals. Thus, a more futuristic approach is the personalized treatment also known as precision medicine, where patients are treated based on their genetic profile. The target is to maximize treatment outcomes while minimizing adverse effects per individual. Thus, different therapies and doses are customized per individual (or per group of patients that share similar genome profiles). AI has fostered considerable improvements in the development of personalized medicine [194]. For example, the AI-derived platform, CURATE.AI, predicts the optimal dosing along with the treatment outcomes based on the patients’ individual data. It generates a profile for each patient using their own medical records, and it dynamically recalibrates the predicted profile over time based on the progression or recession of the disease. CURATE.AI can optimize doses of not only single drugs, but also combinations of drugs [195,196]. This is helpful given that, nowadays, therapies are becoming more sophisticated with emphasis on combination (or multimodal) treatments. These involve more than one drug or treatment offered either simultaneously or sequentially. Combination therapy is proven to have more efficacy compared to single drug regimen especially in the treatment of complex diseases like cancer [197,198]. To predict the efficacy of a chosen treatment, Kureshi et al. developed an AI decision tree to establish a link between the characteristics of the patient and the tumor response in NSCLC [199]. They used four classifiers (histology, mutation in epidermal growth factor receptor, targeted drugs, and smoking habits) for predicting the response of NSCLC patients to the EGFR tyrosine kinase inhibitors. The method showed 76.6% accuracy and it can support the clinician in choosing the correct treatment for NSCLC patients. One of the drawbacks of the study is the small training set used (n = 355). This resulted in the omission of rare patterns such as duplication, deletions, insertions, and point mutations. Using a larger training set could further improve the predictive accuracy of this decision support model. The ‘IBM Watson for oncology’ software made a large impact on personalized treatment plans for cancer patients [200]. The software is trained on thousands of clinical and health records of cancer patients from the medical journals, textbooks, and literature curated by Memorial Sloan Kettering. This software makes accurate diagnoses and treatment recommendations by identifying related cases from databases of worldwide clinical trials (http://www.clinicaltrials.gov) [201].

## Section: The role of AI in rare disease research

Rare diseases (RDs) are a significant health issue that affects almost 1 in 10 individuals in US [202]. Despite their prevalence, the diagnosis of RDs is often challenging due to the complexity of symptoms and the rarity of the conditions. The delay in diagnosis can be as long as 7 years, leading to significant delays in treatment and management [203]. Hence, there is a need for new approaches to enhance the diagnosis and treatment of RDs. AI has the potential to transform the diagnosis and management of rare diseases [[204], [205], [206], [207]] based on NB, RF, XGBoost, CNN, AE (autoencoder), RNN, GAN (generative adversarial network), etc. Fernández et al. developed a deep DL-based approach to detect tubers in selected MRI (magnetic resonance imaging) images for the diagnosis of tuberous sclerosis complex (TSC) [204]. This model adopts a unique InceptionV3 CNN architecture to recognize whether an MRI image has tubers in it or not, showing promising performance (accuracy: 95%) in the detection of a rare neurological disorder. Founta introduced a semi-automated preprocessing gene selection methodology to identify causal amyotrophic lateral sclerosis (ALS) genes [205], with which they developed a classifier based on XGBoost and RF to diagnose ALS and its specific subtypes. This methodology achieved 88.89% accuracy for the classification of sporadic ALS motor neuron samples. Additionally, AI-based PET is a promising tool for early detection and diagnosis of RDs [208].

However, the implementation of AI in healthcare requires careful consideration of ethical, legal, and social implications [209]. AI medical devices must be developed with the active involvement of patient advocacy groups to ensure that the technology is designed to meet the specific needs of rare disease patients. The datasets used to train these algorithms must be diverse and augmented to ensure that they represent the end-user population accurately. Furthermore, the safety and effectiveness of AI-based medical devices (AIMDs) must be thoroughly evaluated to avoid potential harm to patients [210]. AIMDs must be RD-aware at every stage of their conceptualization and life cycle to avoid potential harm and unsustainable deployment of AIMDs into clinical practice. This requires a multidisciplinary approach involving clinicians, computer scientists, and patient advocacy groups.

In general, AI-based technologies offer promising solutions to improve the diagnosis and management of rare diseases. However, the ethical, legal, and social implications of AI in healthcare must be carefully considered to ensure the safety and effectiveness of AIMDs. With careful consideration and collaboration, AI has the potential to revolutionize the diagnosis and treatment of rare diseases, leading to improved patient outcomes and a better quality of life for those affected by RDs.

## Section: Conclusion

The use of AI technology in drug design has grown rapidly due to its predictive ability and accuracy. This review highlights the numerous applications of AI in all phases of drug development, from disease diagnosis to post-marketing analysis. AI helps in the early prediction of diseases, the development of personalized medicine, optimization of drug doses, and the prediction of treatment outcomes. Additionally, AI assists in target and lead identification through the prediction of protein structures and biological activities of small molecules. AI technology can also predict drug-like properties and off-target effects of new compounds, reducing the need for experimental validation. Furthermore, AI-driven approaches improve patient stratification, recruitment, monitoring, and follow-ups in clinical trials, and can even assist in FDA approvals and pharmacovigilance. The integration of AI in drug design has resulted in faster drug discovery, cost savings, reduced resource and manpower usage, and decreased attrition rates in clinical trials. Additionally, AI helps to minimize the use of in vivo bioassays, reducing animal sacrifice. AI has far-reaching applications beyond medicine, including healthcare management, surgeries, mRNA vaccination, preventive treatments, and nutrigenomics. However, it is important to note that AI models are meant to complement human intelligence, not replace it. AI models may have comparable or better predictive ability than human researchers, but they still lack human intuition. Predictions made by AI machines must be verified by humans, as AI models can provide false positive and false negative results, compromising the sensitivity and specificity of the model. Additionally, resource sustainability needs holistic solutions like cost-aware cross-layer co-design, integrating hardware, algorithms, and models for efficient exploration of resource-sustainable configurations. Consensus-based distributed learning is suggested to fully utilize existing and future computing infrastructures, incorporating Internet-of-Things devices and edge servers for data sharing while ensuring privacy. Stable infrastructures with AI-enhanced resource allocation are recommended, involving dedicated healthcare AI infrastructures compliant with evolving government regulations. Lastly, interpretable self-supervised learning is proposed to address the sustainability issue in domain expertise, enhancing trust by extracting clinically useful features and providing human-interpretable evidence in healthcare applications. There are numerous challenges associated with AI, including the explainability of models, the quality and suitability of data used to train models, avoiding bias and overfitting, resource sustainability and more. It is crucial to remain aware of the limitations and risks associated with AI technology. Opportunities for improvement in AI technology include minimizing dependence on supercomputing power, addressing ethical concerns surrounding data collection, and implementing AI in a controlled manner in the healthcare sector to limit negative consequences. It is possible that the future of AI-assisted drug discovery lies in developing a virtual human with complete complexity, allowing for accurate predictions of all possible interactions between molecules and exploring all therapeutic potentials and adverse side effects.

## Section: Declaration of competing interest

The authors declare that they have no conflicts of interest in this work.

## Section: Acknowledgments

This work was supported by the National Key R&D Program of China (2023YFF1205103), National Natural Science Foundation of China (81925034, 22237005), the Key Research and Development Program of Ningxia Hui Autonomous Region (2022CMG01002), the Starry Night Science Fund of Zhejiang University Shanghai Institute for Advanced Study (SN-ZJU-SIAS-007), the innovative research team of high-level local universities in Shanghai (SHSMU-ZDCX20212700).

## Section: Biography

Jian Zhang (BRID:09778.00.20899) received his BS in pharmacology from Peking University in 2002 and PhD in medicinal chemistry from Chinese Academy of Sciences in 2007. He joined Shanghai Jiao Tong University School of Medicine as a professor in 2009 and was rewarded the Changjiang Scholars Program in 2017. He is the director of the Medicinal Chemistry & Bioinformatics Center at Shanghai Jiao Tong University. He has published 120+ peer-reviewed papers (e.g. Nat Chem Biol, Chem), invented 20 issued patents, and made hundreds of international invited talks. He was elected the 2017 Top-ten Science and Technology Young Scientist in China, member of the Academic Degrees Committee of the State Council in 2020, the Fellow of Royal Society of Chemistry and Excellent Research Advisor of American Chemical Society in 2022. He is the associate editor for RSC Medicinal Chemistry, editorial board member for Medicinal Research Review and other seven international journals.
