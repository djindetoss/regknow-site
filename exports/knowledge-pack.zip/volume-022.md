# Integrating Traditional Machine Learning and Deep Learning for Precision Screening of Anticancer Peptides: A Novel Approach for Efficient Drug Discovery

- **Authors:** Meiqi Xu, Jiefu Pang, Yangyang Ye, Ziyi Zhang
- **Issuer:** ACS omega
- **Type:** Scientific article
- **Published:** 2024-04-01
- **Language:** en
- **DOI:** 10.1021/acsomega.4c01374
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38617603/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractThe rapid and effective identification of anticancer peptides (ACPs) by computer technology provides a new perspective for cancer treatment. In the identification process of ACPs, accurate sequence encoding and effective classification models are crucial for predicting their biological activity. Traditional machine learning methods have been widely applied in sequence analysis, but deep learning provides a new approach to capture sequence complexity. In this study, a two-stage ACPs classification model was innovatively proposed. Three novel coding strategies were explored; two mainstream Natural Language Processing (NLP) models and 11 machine learning models were fused to identify ACPs, which significantly improved the prediction accuracy of ACPs. We analyzed the correlation between peptide chain amino acids and evaluated the relevant performance of the model by the ROC curve and t-SNE dimensionality reduction technique. The results indicated that the deep learning and machine learning fusion models of M3E-base and KNeighborsDist models, especially when considering the semantic information on amino acid sequences, achieved the highest average accuracy (AvgAcc) of 0.939, with an AUC value as high as 0.97. Then, in vitro cell experiments were used to verify that the two ACPs predicted by the model had antitumor efficacy. This study provides a convenient and effective method for screening ACPs. With further optimization and testing, these strategies have the potential to play an important role in drug discovery and design.

## Section: Introduction

Cancer is a significant global public health issue, with a rapid increase in cancer incidence and mortality rates worldwide.1,2 It is estimated that by 2025, the annual number of new cancer cases globally will exceed 20 million.3 Common cancer treatment modalities include surgery, chemotherapy, and radiotherapy.4 Among these, chemotherapy is one of the primary approaches to cancer treatment. However, the major challenge faced by traditional chemotherapy is the lack of specificity of chemotherapeutic drugs, making it difficult to target tumor sites for localized treatment. This leads to collateral damage to healthy tissues and a range of complications, often necessitating discontinuation of treatment. Therefore, there is a pressing need for breakthroughs in cancer drug therapy.

Anticancer peptides (ACPs) represent a class of peptides with anticancer activity and are found in various organisms, including mammals, plants, birds, amphibians, fish, insects, and microorganisms.5 Compared to traditional chemotherapy drugs, proteins, monoclonal antibodies and other agents, ACPs possess several distinctive characteristics, such as high specificity, ease of synthesis and modification, strong tumor penetration capabilities and diverse administration methods.6 As an emerging anticancer therapy, ACPs have received widespread attention in recent years. In terms of clinical applications, although ACPs are still in the early stages of development, a small number of peptide drugs have successfully entered clinical trials, demonstrating their potential in treating specific cancers. With the in-depth research on ACPs and the advancement of related technologies, we have reason to believe that ACPs will play an increasingly important role in future cancer treatment and bring new hope to cancer patients.

Ideally, anticancer peptides can selectively target cancer cells without harming normal tissue cells, inducing cancer cell death by altering cell membrane permeability, or interacting with intrinsic targets within cancer cells. The mechanisms of action of ACPs from different sources and their modified peptides have become a recent focus of research in anticancer drug development.7−9 Some ACP-based drugs have already entered clinical trials or been approved for use.10 Therefore, the rapid identification of potential ACPs holds significant importance for the development of cancer treatments. However, traditional methods of identifying ACPs through wet laboratory experiments are relatively costly and time-consuming. Computational techniques in the field of bioinformatics provide a solution to the rapid and accurate identification of ACPs. Among various computational methods, machine learning has emerged as a promising approach to efficiently identifying ACPs.

Traditional machine learning methods for ACP identification involve manually designing features for classifying protein sequences, followed by the use of classification models such as Support Vector Machines (SVM), Random Forest (RF), K-Nearest Neighbors (KNN), Extra Trees and Gradient Boosting Trees.11−14 However, relying solely on handcrafted features may not fully capture the complexity and diversity of data features.15,16 Deep learning methods, known for their ability to efficiently handle unstructured data, have increasingly been applied in ACP identification.17 Yi et al. introduced a deep learning Long Short-Term Memory (LSTM) neural network model, ACP-DL, which automatically learned how to identify anticancer peptides and nonanticancer peptides by integrating binary profile features and a simplified amino acid alphabet sparse matrix.18 However, this method still fundamentally used handcrafted features as inputs, limiting the neural network’s ability to acquire raw information. Yang et al. proposed the CACPP model, which employed a convolutional neural network (CNN) to extract high-potential features from peptide sequences and a contrastive learning module to learn more distinguishable feature representations in a deep learning framework.19 However, due to the restricted receptive field of the CNN network, it was challenging to capture the interactions between amino acids that are distant from each other in long peptide chains. Sun et al. proposed an ACP-BC model, which uses a bidirectional long short-term memory network (BiLSTM) to extract features from the original sequence and obtains deep abstract features through a bidirectional encoder representation converter (BERT), achieving an accuracy of 87%.20 However, handcrafted features also limited the neural network’s ability to acquire raw information, and using chemical formulas as inputs for the BERT network made it prone to truncation when peptide chains were too long. Currently, it appears that neural networks commonly used in computer vision, such as CNNs, and sequence-based neural networks, such as LSTMs, are more prevalent in ACP identification models. However, we believe that models related to Natural Language Processing (NLP) are more suitable for ACP screening.

In this study, we employed four different feature representation and encoding methods, and trained and compared various deep learning and machine learning models to screen peptide sequences with anticancer potential. First, we performed bigram processing on amino acid sequences to generate overlapping matrices and conducted relevant statistical analysis and t-SNE dimensionality reduction visualization. This aided in exploring the co-occurrence relationships and correlations between amino acids, providing support for the design and prediction of peptide sequences with anticancer potential. In the feature engineering phase, we utilized three encoding methods: (1) encoding considering only the amino acid letter information, (2) encoding considering both amino acid letter information and amino acid position information, and (3) encoding the amino acid sequence as if it were a sentence. In the third encoding method, we used two different NLP sequence representations, with or without splitting amino acids, and performed transfer training using two NLP models, BERT and M3E. We employed a greedy soup strategy to enhance network generalization and trained various machine learning models on top of deep learning. The results for each method included peptide sequence classification as well as performance evaluation using tools such as ROC curves and t-SNE dimensionality reduction plots. We identified the model combination of the m3e-base and KNeighborsDist with the highest average accuracy (ValACC and TestACC) of 93.85%. Using this model, we screened peptide sequences effectively validated by both the original NLP model and the comprehensive model, followed by synthesis and in vitro antitumor efficacy validation. The results indicated that the peptides validated by the model demonstrated significant anticancer cell cytotoxicity. Overall, our innovative approach combining NLP language models and machine learning models for ACP screening achieved high accuracy and ease of implementation compared with traditional screening methods. Through in vitro experiments, we confirmed that the peptides selected by our model possess effective anticancer activity, which could aid researchers in discovering more potential ACPs and promoting the development of ACP-based drugs. The workflow of this study was illustrated in Figure 1.

Workflow of this study.

## Section: Materials and Methods › Data Collection

The data for this study were collected from various publicly available anticancer peptide databases, including APD3 (https://aps.unmc.edu/database/anti), BioPepDB (http://bis.zju.edu.cn/biopepdbr/index.php?p=search&field=category&query=anticancer), DPL (http://www.peptide-ligand.cn/search/?csrfmiddlewaretoken=PSqYxvTcUbmCHIAOCjLDJa0tzZky9MoQ6YR9NrAVsHHqeUB6uBkdMNyrmIJ1o2Zf&q0=&q1=&q2=&q4=Anticancer+&q3=&q5=&submit=Search), PlantPepDB (http://14.139.61.8/PlantPepDB/pages/browse_result.php), and FeptideDB (http://www4g.biotec.or.th/FeptideDB/peptide_search.php). These diverse databases provided comprehensive data support by offering a wide range of anticancer peptide sequence information. To ensure data integrity, duplicate peptides within individual databases and between databases were removed, and the anticancer activity of each peptide was rigorously validated. The integrated database consists of 859 anticancer peptides. Additionally, to balance the data set, an equal number of random peptides were generated using a randomization process to serve as control samples for training and testing.

## Section: Materials and Methods › Data Preprocessing

Data preprocessing played a critical role in this study to ensure the quality and suitability of the amino acid sequence data. Strategies employed included identifying inconsistent or unexpected format data within sequences and correcting or removing them to ensure data set consistency and reliability. Furthermore, techniques such as imputation, deletion, or interpolation were applied to address missing values or blank data, ensuring data completeness and usability. In addition, noise data were also processed during data cleaning using filtering or other denoising methods to reduce random interference in the data, ensuring the stability and reliability of subsequent analyses.

After data cleaning, the Bigram method for processing amino acid sequences was a key step in this study.21 By applying Bigram processing to amino acid sequences, we generated an overlapping matrix. This matrix recorded the pairwise occurrences of amino acids in the sequences and, through statistical analysis methods, explored co-occurrence relationships and correlations between amino acids. Through the analysis of these relationships, we identified potential patterns and feature sequences with anticancer potential.

## Section: Materials and Methods › Peptide Sequence Feature Extraction and Representation

In this study, the feature extraction methods covered three novel encoding methods aiming to better capture the features of amino acid sequences. First, the first method considered only the encoding of the amino acid letters themselves, mapping different amino acids to specific symbols or numbers. Second, the second method comprehensively considered the letter and position information on amino acids for a more comprehensive representation of amino acid sequence features. Lastly, the third method viewed amino acid sequences as natural language texts, employing two different NLP sequence representation methods: one split the amino acid sequence into individual amino acids as words and the other treated the entire amino acid sequence as a sentence. Both methods used models from NLP (e.g., BERT and M3E) to represent amino acid sequences in vectorized form, facilitating understanding and processing by deep learning models.

## Section: Materials and Methods › Screening Model Construction › Construction of Screening Models Based on Machine Learning

In this study, for screening anticancer peptides, the research team chose a variety of machine learning algorithms for comparative analysis. These algorithms included LightGBMLarge, LightGBMXT, XGBoost, LightGBM, CatBoost, KNeighborsDist, KNeighborsUnif, RandomForestEntr, RandomForestGini, ExtraTreesEntr and ExtraTreesGini.

For model training and optimization, exhaustive parameter adjustments and optimizations were conducted for the machine learning models. For gradient boosting tree models such as LightGBM, XGBoost, and CatBoost, key parameters such as learning rate, tree depth, and number of leaf nodes were adjusted to improve model generalization and predictive performance. In KNN models, parameters such as the number of neighbors and distance measurement methods were adjusted. For ensemble learning methods such as Random Forests and Extra Trees, parameters such as the number of trees and maximum number of features were optimized to achieve the best model effect. During the training process, methods such as grid search were used to further enhance model stability and performance.

## Section: Materials and Methods › Screening Model Construction › Construction of Screening Models Based on Deep Learning

Specifically, two main deep learning models, BERT (Bidirectional Encoder Representations from Transformers) and M3E (Multiscale 3D Epitope Prediction), were chosen and explored in this study. BERT, a milestone in the NLP field with a Transformer structure, excels in capturing sequence features and context. M3E, a multitask model, has been enhanced for text classification tasks, allowing it to process multiscale features between sequences, which is advantageous for protein function prediction.

Moreover, in addition to the deep learning models, machine learning models were also incorporated to enhance the model performance. Specifically, comparative experiments were conducted in the BERT and M3E models, including using only NLP models and combining them with various machine learning models. These machine learning models include the ones listed above, such as LightGBMLarge, XGBoost, KNeighbors, etc., used to further enhance predictive performance on top of deep learning models.

During the model training and optimization process, this study conducted exhaustive tuning for different deep learning models and strategies. For BERT and M3E models, key hyperparameters such as learning rate, number of layers, and number of hidden units were adjusted, and techniques like pretraining and fine-tuning were used to improve model performance. In the model combination stage, parameters of different machine learning models were adjusted, and optimization methods such as grid search were used. Throughout the training process, appropriate loss functions and evaluation metrics were used to obtain more robust models with stronger generalization capabilities.

## Section: Materials and Methods › Experimental Design

In the experimental design of this study, a strict validation and test data set division approach was adopted (60% of the data for training, 20% for validation and tuning model parameters, and the final 20% for the ultimate model testing and evaluation). For the optimization of model parameters, methods like grid search were used to determine the best combination of hyperparameters, thereby enhancing the model’s generalizability. Regarding computational equipment and configuration, the experiment utilized high-performance computing servers equipped with high-memory GPUs (NVIDIA GeForce RTX 2070 graphics cards) to accelerate the model training and optimization process. The experimental environment was based on the Python programming language, employing relevant deep learning frameworks (such as PyTorch) and machine learning libraries (such as Scikit-learn), ensuring stability and efficiency of the experimental platform.

## Section: Materials and Methods › Model Evaluation

In the model evaluation process of this study, the performance metrics used covered multiple aspects, including Accuracy, Recall, Precision, F1 Score, and Area Under the Curve (AUC). These metrics were capable of comprehensively assessing the model’s performance in various aspects.

Accuracy intuitively reflects the overall predictive accuracy of the model, that is, the proportion of correctly predicted samples, and is a key indicator of the model’s basic performance. Recall measures the proportion of anticancer peptides identified by the model out of the total actual anticancer peptides, focusing on the model’s coverage capability. Precision assesses the proportion of samples correctly identified as anticancer peptides by the model out of the total samples predicted as anticancer peptides, reflecting the model’s accuracy. The F1 Score, which is the harmonic mean of precision and recall, provides an evaluation of comprehensive performance, particularly suitable for imbalanced data sets. Lastly, the AUC value measures the model’s overall performance at different thresholds, serving as an important indicator of the model’s predictive capacity. Together, these evaluation metrics enable us to understand and assess the model’s performance from multiple dimensions comprehensively, ensuring the model’s effectiveness and reliability in practical applications.

## Section: Materials and Methods › In Vitro Antitumor Efficacy of Synthetic Peptides

The model with the best effect was selected to predict two peptides with a high antitumor efficacy for synthesis. The two peptide sequences were purchased from Jill Biochemical Co., Ltd. (Shanghai, China) and synthesized by the synthesis method of fluorenylmethyloxy carbonyl chloride protective amino acids. The purity of the synthetic peptide was detected by high-performance liquid chromatography (HPLC) to be more than 95%. The in vitro cytotoxicity of peptides was evaluated in 4T1 cells (mouse breast cancer cells) using the sulfonyl rhodamine B (SRB) assay (Sigma-Aldrich, St. Louis, MO, USA).22,23 4T1 cells (6 × 103 cells/well) were seeded in 96-well plates, incubated for 24 h, and then treated with peptides at 37 °C for 24 h. The cell viability was determined using SRB, which allowed quantification of the living cells by measuring absorbance at 540 nm with a 96-well plate reader (model 680; Bio-Rad Laboratories Inc., Hercules, CA, USA). The half-maximal inhibitory concentration (IC50) was calculated according to the dose–effect curves using GraphPad Prism 8 software.

## Section: Results

Overlapping matrix visualization.

Visual analysis of encoding based on amino acid letters only. (a) ROC curves and AUC values. ROC: receiver operating characteristic; AUC: area under the ROC curve. (b) T-SNE dimensionality reduction diagram.

Visual analysis of encoding considering both amino acid letter and position information. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

Visual analysis of deep learning models. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

Visual analysis of fusion models of deep learning and machine learning. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

ROC curves and AUC values of the highest AvgAcc models and comparisons with other ACP predictors.

## Section: Results › Distribution Statistics Display

The activity of ACPs is influenced by the composition of amino acids and their structure. Previous studies mostly considered the frequency of individual amino acids in ACPs.24 However, we believed that the co-occurrence relationships and correlations between amino acids are more meaningful in the search for and exploration of peptides with anticancer activity. Therefore, we processed the amino acid sequences through bigram processing, generated overlapping matrices, and conducted a statistical analysis of the results.

As shown in the context matrix plot (Figure 2), lysine (Lys, K), alanine (Ala, A), and leucine (Leu, L) had the highest frequency in ACPs. This may be attributed to the positively charged nature of these amino acids or their hydrophobic properties. When ACPs interact with cancer cell membranes, the positively charged hydrophilic regions effectively bind to the negatively charged surface of cancer cell membranes through electrostatic adsorption. Simultaneously, the hydrophobic regions bind to the membrane lipids. This laid the foundation for the selective action of ACPs on cancer cells, and the results were consistent with the findings reported in the literature.25 It was noteworthy that the top three amino acid pairs in terms of occurrence frequency are K-K, A-K, and K-L, with frequencies of 617, 485, and 457, respectively (Table 1). Identifying amino acid pairs with higher occurrence frequencies was more helpful in designing amino acid sequences with anticancer activity based on contextual relationships, which could not be achieved by only counting individual amino acids.

Overlapping matrix visualization.

## Section: Results › Machine Learning Model Performance Evaluation Results

Visual analysis of encoding based on amino acid letters only. (a) ROC curves and AUC values. ROC: receiver operating characteristic; AUC: area under the ROC curve. (b) T-SNE dimensionality reduction diagram.

Visual analysis of encoding considering both amino acid letter and position information. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

## Section: Results › Machine Learning Model Performance Evaluation Results › Results of Encoding Based on Amino Acid Letters Only

We first explored the impact of encoding based on amino acid letters on the performance of machine learning models. This encoding strategy maps different amino acids to a set of unique symbols or numbers, serving as the basis for training and predicting machine learning models. To comprehensively assess the effectiveness of this encoding method, we employed a series of advanced machine learning algorithms, including but not limited to LightGBMLarge, XGBoost, CatBoost, etc. Each algorithm was evaluated on multiple dimensions including precision (Pre), recall (Rec), F1 score, and accuracy (ACC). The specific results are shown in Table 2. In the comparative analysis, we observed that the XGBoost model achieved a high score of 0.873 in average ACC, and its precision, recall, and F1 scores were also impressive at 0.909, 0.851, and 0.879, respectively. Furthermore, by conducting ROC curve analysis for the top 6 models ranked by ACC (Figure 3a), both XGBoost and LightGBMLarge models demonstrated outstanding performance with AUC values reaching 0.93, highlighting their excellence in classification tasks.

We further performed visual analysis of features using the t-SNE dimensionality reduction technique. Despite the simplicity and intuitiveness of this encoding method, the results in Figure 3b revealed a challenge. There seemed to be a difficulty in distinguishing between ACPs and non-ACPs using features extracted by this encoding method. This might be attributed to the fact that this encoding strategy overlooks spatial positions and contextual information in amino acid sequences, which often play crucial roles in biological sequence analysis.

Visual analysis of encoding based on amino acid letters only. (a) ROC curves and AUC values. ROC: receiver operating characteristic; AUC: area under the ROC curve. (b) T-SNE dimensionality reduction diagram.

## Section: Results › Machine Learning Model Performance Evaluation Results › Results of Encoding Considering Both Amino Acid Letter and Position Information

Next, we delved into a more complex encoding strategy that not only included the letter information on amino acids but also integrated their positional information in the sequence to achieve a comprehensive representation of amino acid sequence features. By introducing positional information, we aimed to capture the spatial structural characteristics of amino acid sequences, thereby enhancing the model’s classification ability for ACPs and non-ACPs. As shown in Table 3, we evaluated various machine learning models, including but not limited to XGBoost, LightGBM, etc. The results indicated that when positional information is introduced, the top-performing models remained comparable to the first encoding method across all metrics. XGBoost and LightGBMLarge models continued to exhibit the best performance. Furthermore, we conducted a comparative analysis of model performance through ROC curves (Figure 4a), and the results corroborated the numerical indicators in the table, demonstrating that the overall performance of the models was maintained.

To further analyze the impact of encoding on classification performance, we applied the t-SNE technique for dimensionality reduction and visualized the model’s classification results (Figure 4b). Despite the introduction of positional information, there was an improvement in the separation of the models in distinguishing ACPs from non-ACPs. However, the results suggested that this improvement was not significant, and the models still faced challenges in clearly distinguishing between the two sequence classes. This might indicate that simply adding positional information had limitations in enhancing the model’s ability to recognize ACPs, or it might suggest the need for further optimization of feature expression and model structure to fully leverage positional information. In conclusion, while the second encoding method provided a more complex and comprehensive feature representation by considering both amino acid letters and positional information, its practical application did not significantly improve model performance.

Visual analysis of encoding considering both amino acid letter and position information. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

## Section: Results › Deep Learning Model Performance Evaluation Results

Visual analysis of deep learning models. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

Visual analysis of fusion models of deep learning and machine learning. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

ROC curves and AUC values of the highest AvgAcc models and comparisons with other ACP predictors.

## Section: Results › Deep Learning Model Performance Evaluation Results › Results without Adding Machine Learning Models

In an effort to improve the results of traditional machine learning models, we experimented with two NLP deep learning models—BERT and M3E. Simultaneously, we employed a third encoding method that treats amino acid sequences as natural language text and utilized two different NLP sequence representation approaches: one treating the entire amino acid sequence as a single sentence and the other splitting the amino acid sequence into individual amino acids as words. This was done to vectorize the amino acid sequences for understanding and processing by deep learning models. As shown in Table 4, in the first NLP sequence representation method (treating the entire amino acid sequence as a single sentence), the BERT model performed better with test set ACC, Pre, Rec, and F1 scores of 0.904, 0.961, 0.851, and 0.903, respectively. The average ACC for the test and validation sets was 0.904. In the second NLP sequence representation method (splitting the amino acid sequence into individual amino acids as words), the M3E model showed superior performance, surpassing the optimal results of the first representation method. The test set ACC, Pre, Rec, and F1 scores reached 0.919, 0.925, 0.920, and 0.923, respectively, with the average ACC for the test and validation sets reaching 0.915. The ROC curve demonstrated an AUC value of 0.96 for the first representation method and a remarkable AUC value of 0.98 for the second representation method (Figure 5a). The t-SNE dimensionality reduction plot also indicated that the second representation method combined with the M3E model had better discriminability for the ACPs (Figure 5b). This aligns with reality as splitting amino acids in the sequence into individual words with a natural order is more consistent with the natural distribution of amino acids in the sequence. Therefore, transforming amino acid sequences into vector representations with semantic information can better capture advanced features and relationships in the sequence, leading to a noticeable improvement in model accuracy.

Visual analysis of deep learning models. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

## Section: Results › Deep Learning Model Performance Evaluation Results › Results of Fusion Models of Machine Learning and Deep Learning

In this study, to enhance the accuracy of deep learning models, we not only independently utilized NLP deep learning models, but also attempted to combine them with traditional machine learning models using the Greedy Soup strategy to achieve a superior performance. Through this fusion approach, we could leverage the ability of deep learning models to extract complex features from amino acid sequences and enhance the final classification accuracy by using machine learning models. We selected the model with the highest ACC from numerous combinations for detailed evaluation, and the results were listed in Table 5. The findings indicated that the overall performance of the model improved after incorporation of machine learning models. In particular, the combination of the M3E-base and KNeighborsDist models exhibited the highest accuracy in all tests, reaching an impressive 93.9%.

On the other hand, we visually presented the experimental results of this fusion strategy. The ROC curve graph clearly illustrated the classification performance of the fusion model (Figure 6a). We observed that when not considering the semantic information on amino acids, the combination of M3E-base and KNeighborsDist achieved an AUC value of 0.95, demonstrating excellent classification capability. In the presence of semantic information, the combination of M3E-base and KNeighborsDist increased the AUC value to 0.97, while the combination of bert_base_uncased and LightGBMXT reached an AUC value of 0.98. This highlighted the significance of semantic information in enhancing model performance.

Furthermore, the t-SNE dimensionality reduction plot revealed the separation of the model in handling different categories of data (Figure 6b). Comparing the dimensionality reduction results of different model combinations, we found that considering spatial information significantly improved the model’s ability to differentiate between ACPs (label = 1) and non-ACPs (label = 0). In particular, the combination of bert_base_uncased and LightGBMXT exhibited a higher category separation in the dimensionality reduction plot, corroborating its high AUC value in the ROC curve graph.

These results not only confirmed the effectiveness of NLP deep learning models in handling amino acid sequences but also indicated that traditional machine learning models could effectively enhance the performance of deep learning models, especially when incorporating semantic information into the sequence. Through this hybrid model, we could more accurately identify and classify ACPs, thereby applying them more effectively in drug design and related fields of bioinformatics.

Visual analysis of fusion models of deep learning and machine learning. (a) ROC curves and AUC values. (b) T-SNE dimensionality reduction diagram.

## Section: Results › Deep Learning Model Performance Evaluation Results › Comprehensive Results and Performance Comparison

This study conducted a comprehensive comparison of the impact of different encoding methods and model combinations on the task of identifying ACPs. By contrasting various encoding strategies and deep learning (DL) models with or without the inclusion of machine learning (ML) models, our determined the optimal model configuration for achieving high-precision recognition of ACPs. In addition, we compared the performance of our models with several currently known excellent ACP predictors. In Table 6, we compared six different encoding and model combination strategies, recording their average accuracy (AvgAcc). XGBoost models based on integer encoding (intEncode) and integer encoding considering amino acid position information (intPositionEncode) both demonstrated an AvgAcc of 0.873, providing a stable baseline performance. However, when transitioning to NLP deep learning models, we noted that bert-base-uncased achieved an AvgAcc of 0.904 without semantic information and without combining ML models. Furthermore, the m3e-base model, when considering semantic information and not combining ML models, reached an AvgAcc of 0.922. When combining DL models with ML models, performance showed a significant improvement. In particular, when not considering semantic information, the combination of the m3e-base and KNeighborsDist increased AvgAcc to 0.915. In the presence of semantic information, the same combination achieved the highest AvgAcc value in this study, reaching 0.939.

The ROC curve graph in Figure 7 provided an intuitive way to compare performance. From the graph, we observed that the combination of m3e-base and KNeighborsDist, which incorporated semantic information, demonstrated the most outstanding classification ability among all of the models, with an AUC value of 0.97. This further emphasized the importance of semantic information in enhancing model accuracy and the potential of ML models to effectively boost the performance of DL models.

Then, we selected two currently known excellent ACP predictors, iACP-FSCM26 and ACPred-FL,27 tested them with our data set, and compared their ROC curves and AccAvg values with our models. The performance comparison results showed that our models were significantly higher than the iACP-FSCM and ACPred-FL models in terms of the AUC value and AccAvg value. It proved that our models were advanced compared to existing ACP predictors.

ROC curves and AUC values of the highest AvgAcc models and comparisons with other ACP predictors.

## Section: Results › Model Prediction and In Vitro Antitumor Efficacy of Peptides

We randomly selected 741 peptides as test peptides in the database and predicted them using the model m3e-base+KNeighborsDist with the highest comprehensive evaluation. Two peptides with potentially high anticancer activity were predicted, namely, KEWLE and KRLAFA. Mass spectrometry results showed that the two peptides were successfully synthesized, and HPLC results confirmed that the purity of both peptides was above 95% (Figures S1–S4). Mouse breast cancer cell 4T1 cells were selected to validate the in vitro antitumor efficacy of the two peptides. The experimental results are shown in Table 7, and the IC50 values of the two peptides were, respectively, 47.46 ± 12.14 and 39.99 ± 9.744 μM, and both had in vitro antitumor efficacy.

## Section: Discussion

This study aimed to construct a precise and automated model for the screening of ACPs using machine learning methods. Initially, three different feature representation and encoding methods were employed, with the third encoding method combining two different NLP sequence representations, utilizing NLP models such as BERT and M3E, and introducing a combination strategy of machine learning models. By integration of various machine learning and deep learning models, a model combination with higher accuracy was ultimately selected. In vitro anticancer efficacy validation was performed, demonstrating that the peptides validated by the model exhibited potent anticancer cell toxicity. Overall, this study innovatively incorporated NLP into the screening of anticancer peptides, achieving higher and more achievable accuracy compared to traditional methods and confirming the practical and effective anticancer activity of the selected peptides.

The machine learning methods employed in this study, such as LightGBM, XGBoost, etc., demonstrated good generalization performance in terms of model efficiency, especially when dealing with high-dimensional features and large-scale data, exhibiting high efficiency and prediction accuracy. These machine learning models effectively screened anticancer peptides through traditional feature engineering and model fusion strategies, confirming their reliability in peptide sequence analysis. In contrast, deep learning methods such as BERT, M3E, etc., showed advantages in capturing sequence features and contextual information. These models could better utilize the sequential information and global context in the sequences, enhancing the model’s predictive capabilities through learning advanced features. Particularly, the BERT model, as an advanced model in the natural language processing field, successfully applied the Transformer structure to learn representations of protein sequences, offering new possibilities for the screening of anticancer peptides. In summary, traditional machine learning models have advantages in efficiency, while deep learning models excel in learning and representing sequence features. Therefore, combining machine learning and deep learning methods may become a new trend in the future for screening anticancer peptides. It is worth noting that compared with the studies by Wei et al.27 and Charoenkwan et al.,26 this study focuses on predicting the activity of ACP using a combination of deep learning and efficient feature expression, achieving the highest prediction accuracy of 0.939. The above comparative studies construct effective sequence feature expressions and achieve prediction through traditional machine learning, and the prediction accuracy is slightly lower than that in this study.

It was noteworthy that this experiment demonstrated significant practical value in the screening of anticancer peptides. By application of a combination of machine learning and deep learning models, the efficiency of anticancer peptide screening was improved. Traditional methods of anticancer peptide screening typically required extensive experimentation and human resources. The model constructed in this study could rapidly and accurately predict peptide sequences with potential anticancer activity, significantly shortening the screening cycle. This precise screening method effectively reduced the cost of developing new anticancer drugs, accelerating the drug development process. This is also in line with the future development trend in this field using advanced computational methods to discover functional peptides to aid drug screening.28

From a longer-term perspective, ACPs have emerged as a promising alternative due to their specificity, lower toxicity, and ability to circumvent drug resistance mechanisms that often limit the effectiveness of traditional therapies. Traditional chemotherapy indiscriminately targets rapidly dividing cells, leading to significant side effects, whereas ACPs offer a more targeted approach, potentially leading to more effective and less harmful treatments. Moreover, advancements in peptide engineering and drug delivery systems have significantly enhanced the stability, bioavailability, and tumor-targeting capabilities of ACPs, making them a viable option in the arsenal against cancer. However, despite these advantages, the clinical application of ACPs still faces several challenges such as their rapid degradation in the bloodstream, potential immunogenicity, and the complexity of large-scale synthesis. These issues necessitate further research and innovation to overcome. Additionally, while ACPs show promise in preclinical studies, their efficacy and safety in human trials must be rigorously tested. The possibility of replacing traditional anticancer drugs with peptides depends not only on overcoming these technical hurdles but also on demonstrating superior clinical outcomes.

While this study has made significant progress in anticancer peptide screening, there are limitations that need to be considered. First, the quality and quantity of the data set have a crucial impact on the training and prediction of machine learning and deep learning models, and the data set used in this study may have limitations. The size and coverage of the data set may influence the generalization ability and predictive performance of the model. Therefore, a more extensive and representative data set could further enhance the robustness of the model. Second, the choice of feature representation and encoding methods has a significant impact on the performance of the model. Although the feature engineering methods used in this study are diverse, there may still be a potential optimization space. Further exploration of more effective feature representation and encoding methods may improve the model’s ability to abstractly represent peptide sequences, thereby enhancing predictive performance. Lastly, despite the in vitro experiments validating the anticancer activity of the peptides screened by the model, more experimental data and further clinical trials are needed to verify the feasibility and effectiveness of their clinical application. There is a certain difference between laboratory conditions and actual treatment environments, necessitating more clinical data to support the experimental results obtained in this study.

## Section: Conclusions

This study successfully integrated different encoding methods with multiple machine learning approaches to construct a precise screening model for anticancer peptides. Through rigorous model training and comparison, the study accurately screened peptide sequences with anticancer potential and confirmed the effectiveness of the model’s predictions in in vitro experiments. Particularly, the introduction of NLP language models into the screening of anticancer peptides in this study, compared with traditional methods, significantly improved both the accuracy and efficiency of screening. This opened up new possibilities and avenues for the discovery and research of anticancer drugs. However, despite the relatively outstanding results achieved in this study, there were still some suggestions for improvement to consider. In future research, we will continue to explore and incorporate the latest technologies and theoretical advancements to continuously enhance the performance and practicality of the model, promoting the development and application of anticancer drugs.

## Section: Acknowledgments

Authors gratefully acknowledge the financial support from the Zhejiang City University Research and Incubation Fund (J-202326).

## Section: Data Availability Statement

All code used in data analysis and preparation of the manuscript, alongside a description of necessary steps for reproducing results, can be found in a GitHub repository: https://github.com/Keda0411/acps.

## Section: Supporting Information Available

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acsomega.4c01374.

## Section: Author Contributions

M.X. conceived the basic idea and designed the framework. M.Q. and J.P. performed the experiments. M.X., J.P., and Z.Z. wrote the manuscript. Y.Y. revised the manuscript.

## Section: Text

The authors declare no competing financial interest.

## Section: Supplementary Material

ao4c01374_si_001.pdf

## Section: Associated Data

ao4c01374_si_001.pdf

## Section: Associated Data › Supplementary Materials

ao4c01374_si_001.pdf

## Section: Associated Data › Data Availability Statement

All code used in data analysis and preparation of the manuscript, alongside a description of necessary steps for reproducing results, can be found in a GitHub repository: https://github.com/Keda0411/acps.


---

# Interpretable machine learning in predicting drug-induced liver injury among tuberculosis patients: model development and validation study

- **Authors:** Yue Xiao, Yanfei Chen, Ruijian Huang, Feng Jiang, Jifang Zhou, Tianchi Yang
- **Issuer:** BMC medical research methodology
- **Type:** Scientific article
- **Published:** 2024-04-20
- **Language:** en
- **DOI:** 10.1186/s12874-024-02214-5
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38643122/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackgroundThe objective of this research was to create and validate an interpretable prediction model for drug-induced liver injury (DILI) during tuberculosis (TB) treatment.MethodsA dataset of TB patients from Ningbo City was used to develop models employing the eXtreme Gradient Boosting (XGBoost), random forest (RF), and the least absolute shrinkage and selection operator (LASSO) logistic algorithms. The model's performance was evaluated through various metrics, including the area under the receiver operating characteristic curve (AUROC) and the area under the precision recall curve (AUPR) alongside the decision curve. The Shapley Additive exPlanations (SHAP) method was used to interpret the variable contributions of the superior model.ResultsA total of 7,071 TB patients were identified from the regional healthcare dataset. The study cohort consisted of individuals with a median age of 47 years, 68.0% of whom were male, and 16.3% developed DILI. We utilized part of the high dimensional propensity score (HDPS) method to identify relevant variables and obtained a total of 424 variables. From these, 37 variables were selected for inclusion in a logistic model using LASSO. The dataset was then split into training and validation sets according to a 7:3 ratio. In the validation dataset, the XGBoost model displayed improved overall performance, with an AUROC of 0.89, an AUPR of 0.75, an F1 score of 0.57, and a Brier score of 0.07. Both SHAP analysis and XGBoost model highlighted the contribution of baseline liver-related ailments such as DILI, drug-induced hepatitis (DIH), and fatty liver disease (FLD). Age, alanine transaminase (ALT), and total bilirubin (Tbil) were also linked to DILI status.ConclusionXGBoost demonstrates improved predictive performance compared to RF and LASSO logistic in this study. Moreover, the introduction of the SHAP method enhances the clinical understanding and potential application of the model. For further research, external validation and more detailed feature integration are necessary.Supplementary InformationThe online version contains supplementary material available at 10.1186/s12874-024-02214-5.Keywords: Machine learning, Logistic regression, Tuberculosis, Drug-induced liver injury, Retrospective study

## Section: Background

Drug-induced liver injury (DILI) presents significant challenges in the context of tuberculosis (TB) treatment. Anti-TB drugs exhibit noteworthy involvement in the occurrence of DILI [1, 2], and the lack of certain early-detection biomarkers [3] further poses challenges to the timely diagnosis and management of DILI. This absence of early detection may result in treatment interruptions and failures amongst TB patients [4, 5], impeding global TB eradication efforts [6]. In China, the elevated incidence rates of DILI in comparison to western nations highlight the potential involvement of traditional Chinese medicines (TCM) and herbal medicines in the development of DILI [7]. This requires addressing various challenges and complexities associated with DILI assessment in a comprehensive and objective manner. Therefore, the primary objective of this study is to develop an optimal predictive model for assessing DILI status, with a specific focus on TB patients within the Chinese context.

The emergence of machine learning (ML) algorithms presents an exciting opportunity to enhance DILI prediction models [8]. Among these, eXtreme Gradient Boosting (XGBoost) [9] and random forest (RF) [10] stand out as two widely-used ensemble learning techniques, each distinguished by its algorithmic approach and features. Selecting the most suitable option between them hinges on the particular characteristics of the data and the prediction objective. Therefore, it is often advisable to conduct experiments with both models to compare their performance.

Nevertheless, one of the primary challenges in implementing ML algorithms in clinical settings is interpreting the outcomes of the models [11, 12]. The Shapley Additive exPlanations (SHAP) framework [13] provides insights into the influence of various features on model predictions and the effect of these features on the DILI status in individuals, thus bridging the interpretability gap.

This study focuses on the development and validation of a prediction model for DILI in the context of TB treatment by using advanced ML algorithms with SHAP interpretability. Through this endeavor, we aim to achieve a balance between accurate prediction and the interpretability of the model, which is crucial for its clinical application.

## Section: Methods

Study schema for subject selection. Abbreviations: EHR, Electronic healthcare record; CDC, Center for Disease Control and Prevention

## Section: Methods › Data source

The study participants comprised individuals diagnosed with TB at specified hospitals in Ningbo from 1st January 2015 to 2nd January 2020, initially referred by the Chinese Center for Disease Control and Prevention (CDC) [14]. Thereafter, they were connected to administrative records obtained from the electronic health records (EHR) system employed by the local government [15]. The merged dataset comprised demographic information, hospitalization records (both inpatient and outpatient), laboratory tests, and medication profiles.

## Section: Methods › Exclusion criteria

To ensure consistency in the identification of covariates, individuals with only one health care encounter during the study period were excluded. Furthermore, individuals without ethnicity information and those under 18 years old at diagnosis were not included in the study. The exclusion criteria also filtered out misdiagnosed cases of DILI and liver injuries attributed to known factors like alcohol-related liver disease, non-alcoholic fatty liver disease (NAFLD), and viral hepatitis unrelated to drug-induced causes. The detailed flowchart is presented in Fig. 1.

Study schema for subject selection. Abbreviations: EHR, Electronic healthcare record; CDC, Center for Disease Control and Prevention

## Section: Methods › Baseline laboratory result collection

For patients included in the study, we defined the baseline period for collecting laboratory test results as from January 1, 2015, to the day before the index diagnosis of pulmonary tuberculosis, as shown in Supplemental Fig. 1. Additionally, liver function test indicators such as alanine transaminase (ALT) or alkaline phosphatase (ALP) were simultaneously examined.

To address the issue of varied baseline definitions in laboratory testing, we utilized two main strategies. Firstly, we employed a binary variable approach to categorize laboratory testing indicators as abnormal or normal, by comparing their values with predefined normal ranges. Secondly, we utilized ratio-based representation to quantify indicator abnormalities, such as calculating ALT multiples relative to the upper limit of the normal (ULN) range.

## Section: Methods › Factor identification

In our research, we followed the initial steps outlined in the high dimensional propensity score (HDPS) methodology by Schneeweiss et al. [16]. First, we identified 24 common factors, such as age and gender, to integrate into our models. We then categorized our data into four dimensions: outpatient records, inpatient records, laboratory test records, and medication records. Following the approach of Chen et al. [17], we identified the top 500 most prevalent codes within each dimension. Next, we evaluated code recurrence, classifying codes into three binary variables based on their frequency of occurrence over a 12-month baseline period. This yielded a total of 4*500*3 binary factors. Using a multiplicative model considering binary factor and DILI status, we prioritized covariates and selected the top 400 for inclusion in our final model based on an arbitrary cutoff recommendation [18, 19]. Finally, considering the previously specified 24 variables, our model training ultimately involved incorporating a total of 424 factors.

## Section: Methods › DILI diagnostic process

The determination of DILI outcomes followed the revised criteria set forth by the Chinese Society of Hepatology (CSH) DILI consensus, as outlined in Supplemental Table 1 [20].

## Section: Methods › Extraction of features used in prediction model

The LASSO regression method, aimed at reducing the number of variables and preventing overfitting [21], was applied to extract significant features for constructing the logistic model. Additionally, both the XGBoost and RF algorithms come equipped with their own feature selection techniques tailored to enhance their respective models.

## Section: Methods › Statistical analysis

The study reported the features of both the non-DILI and DILI groups by mean and standard deviation (SD) or as numbers and percentages whenever necessary. Laboratory variables were represented in median and quartiles [22]. The Kruskal–Wallis rank sum test was used for continuous variables, while the chi-square test was used for categorical variables. These analyses were conducted using the statistical software packages SAS 9.4 and R 4.0.3. A statistically significant result was determined with a two-sided P-value below 0.05.

## Section: Methods › Data splitting

In order to create training and validation sets, a stratified random function in R randomly assigned records at a 7:3 ratio, following conventional practices.

## Section: Methods › Parameter optimization

To optimize the parameters of the XGBoost and RF models, a ten-fold cross-validation process combined with grid search [23] was employed. This approach entailed identifying the hyperparameter set that yielded the maximum receiver operating characteristic (ROC). A detailed breakdown of the grid search particulars and optimal results can be found in Supplemental Table 2.

## Section: Methods › Model evaluation and interpretation

To assess the model's capacity to differentiate between positive and negative cases, we computed both the area under the receiver operating characteristic curve (AUROC) and the area under the precision recall curve (AUPR) [24]. Calibration was examined through reliability diagrams and Brier scores. Furthermore, the model's clinical utility was evaluated using decision curve analysis. The SHAP technique was utilized to delve deeper into variable contributions. A comprehensive overview of the workflow can be found in Supplemental Fig. 2.

## Section: Results

Demographic and clinical characteristics of patients with and without DILI

Comparison of performance ability of the three models in the validation set

Comparison of the AUROC of the XGBoost, logistic and random forest in the validation set

Comparison of the AUPR of the XGBoost, logistic and random forest in the validation set

Comparison of the calibration curve of the XGBoost, logistic and random forest in the validation set

The decision curve of the XGBoost, logistic and random forest in the validation set

Top important features selected by XGBoost (> 0.01). Abbreviations: ODILIO, outpatient drug-induced liver injury, once occurring; ODIHO, outpatient drug induced hepatitis, once occurring; ODIHS, outpatient drug induced hepatitis, sporadically occurring; IDIHO, inpatient drug induced hepatitis, once occurring; ODILIS, outpatient drug induced liver injury, sporadically occurring; IDIHF, inpatient drug induced hepatitis, frequently occurring; IDILIO, inpatient drug induced liver injury, once occurring; ODILIF, outpatient drug induced liver injury, frequently occurring; TBIL, total bilirubin; ALP, alkaline phosphatase; IDILIS, inpatient drug induced liver injury, sporadically occurring; ALT, alanine aminotransferase; FLD, fatty liver disease

## Section: Results › Participant and factor identification

The preliminary linkage of data yielded 12,087 instances. Following the application of exclusion criteria, a total of 7,071 subjects were identified as suitable for inclusion in the study.

During a one-year baseline period, we identified the 500 most prevalent codes across each data dimension (outpatient, inpatient, medication, and laboratory test) using the International Classification of Diseases-Tenth Revision (ICD-10), Current Procedural Terminology (CPT), and generic drug names. These items were then categorized into three binary variables: "ever occurring", "sporadically occurring", and "frequently occurring", indicating their recurrence. This process resulted in a total of 6,000 variables, from which the top 400 binary empirical variables were chosen based on their highest risk ratios associated with DILI status. Additionally, the final model incorporated 24 predefined baseline variables, such as gender, age, education level, medication, and maximum ratio of ULN for ALT, ALP, and Tbil, etc. Out of an initial pool of 424 features, 37 were selected for logistic model development using LASSO. The factors included in the LASSO logistic model are detailed in Supplemental Table 3.

## Section: Results › Epidemiology of DILI

The incidence of DILI was observed to be 16.3% overall, with a slightly higher observed in female patients (17.3% vs. 15.8%, p = 0.134). Detailed demographics and clinical information are outlined in Table 1. Compared to non-DILI individuals, those with DILI demonstrated lower educational attainment and a higher incidence of abnormal baseline levels in ALT and ALP [ALT: 91 (7.9%) vs. 273 (4.6%), p < 0.001; ALP: 100 (8.7%) vs. 400 (6.8%), p = 0.023]. Individuals of middle age, females, and those with pre-existing chronic liver conditions were found to have a higher susceptibility to DILI. Significant associations with DILI were identified for certain drugs, including pyrazinamide (PZA), isoniazid (INH), traditional Chinese medicines (TCM), and hepatoprotective agents such as silymarin and glycyrrhetinic acid.

Demographic and clinical characteristics of patients with and without DILI

## Section: Results › Model development and validation

The XGBoost and RF models were constructed using optimal parameters obtained through the previously mentioned GridSearchCV method. The LASSO logistic model was constructed with the aforementioned variables. Internal validation was conducted by partitioning validation sets, resulting in a comparison of model performance among the three models showcased in Table 2. The XGBoost model exhibited slightly superior discriminatory ability when compared with the RF and LASSO logistic model, with AUROC values of 0.89 versus 0.88/0.85 and AUPR values of 0.75 versus 0.73/0.67, respectively, as shown in Figs. 2 and 3. The RF model demonstrated increased recall with a score of 0.78, while the XGBoost model achieved the highest F1-score of 0.57. Calibration was evaluated through ten predictive probability-based bins and verified by the reliability diagram presented in Fig. 4, supported by a Brier score of 0.08, indicating the impressive alignment in calibration between the XGBoost and LASSO logistic models. Extensive analysis of the decision curve revealed positive net benefits for all models. Notably, XGBoost models outperformed both the RF and LASSO logistic models within the threshold range of approximately 0.2 to 0.5, as demonstrated in Fig. 5.

Comparison of performance ability of the three models in the validation set

Comparison of the AUROC of the XGBoost, logistic and random forest in the validation set

Comparison of the AUPR of the XGBoost, logistic and random forest in the validation set

Comparison of the calibration curve of the XGBoost, logistic and random forest in the validation set

The decision curve of the XGBoost, logistic and random forest in the validation set

## Section: Results › Model interpretation

Revealing the factors that influenced the outperformed model's predictions, Fig. 6 laid out the most paramount features of XGBoost (with feature importance > 0.01). Of note, historical occurrences of DILI, DIH, and fatty liver disease (FLD) during the baseline phase were consistently highlighted. Moreover, the ULN for ALT, ALP and Tbil were also identified as critical factors. The SHAP values calculated for the XGBoost model, as shown in Supplemental Fig. 3, indicate that individuals who had chronic liver disease during baseline were more likely to be in DILI status. Interestingly, we found that those with a lower educational level were more susceptible to DILI status. To gain a deeper understanding of the underlying mechanism and the effects of features in the XGBoost model, we randomly selected two typical patients from the dataset. Furthermore, we created force plots to visualize their decision process, as illustrated in Supplemental Fig. 4 and Supplemental Fig. 5. The average SHAP value was 0.168, where yellow indicates a positive impact and purple represents a negative impact. In Supplemental Fig. 4, the identified patient with a SHAP value of 1.06, surpassing the average, is likely to develop DILI. The significant influencing factor is being diagnosed with DILI or DIH at least once during the baseline period. The same rationale applies to the identified patient as depicted in Supplemental Fig. 5. Additionally, Supplemental Fig. 6 presents a force plot that captures the aggregate effect in the validation set.

Top important features selected by XGBoost (> 0.01). Abbreviations: ODILIO, outpatient drug-induced liver injury, once occurring; ODIHO, outpatient drug induced hepatitis, once occurring; ODIHS, outpatient drug induced hepatitis, sporadically occurring; IDIHO, inpatient drug induced hepatitis, once occurring; ODILIS, outpatient drug induced liver injury, sporadically occurring; IDIHF, inpatient drug induced hepatitis, frequently occurring; IDILIO, inpatient drug induced liver injury, once occurring; ODILIF, outpatient drug induced liver injury, frequently occurring; TBIL, total bilirubin; ALP, alkaline phosphatase; IDILIS, inpatient drug induced liver injury, sporadically occurring; ALT, alanine aminotransferase; FLD, fatty liver disease

## Section: Discussion

To our knowledge, this study represents the initial attempt to evaluate the prediction for DILI in an Asian population, predominantly of Han ethnicity, with TB using regional electronic health records. We observed slightly enhanced discrimination abilities in ML models compared to the logistic model. While logistic regression offers better clinical generalizability, it struggles with overfitting and handling missing variables, resulting in overall weaker performance than anticipated. In contrast, both XGBoost and RF employ more advanced techniques. XGBoost utilizes gradient boosting, progressively building weak learners and effectively capturing non-linear relationships with built-in regularization. On the other hand, RF, a bagging ensemble method, constructs independent decision trees on random subsets of data, resulting in robust averaging but with less explicit regularization. XGBoost excels in capturing intricate non-linear patterns, making it suitable for tasks involving complex and dynamic interactions like predicting DILI during TB treatment. Its training efficiency is also evident when handling large datasets. RF, with its robust averaging, is well-suited for further application in diverse datasets but may encounter challenges in effectively capturing subtle non-linear patterns among multiple explanatory variables.

Several prior studies have identified risk factors associated with DILI during TB treatment, involving chronic liver disease, specific drug combinations, age, and various demographic characteristics [25–27]. Lammert et al. [28] suggested an increased risk of DILI in patients with chronic liver disease indicative of NAFLD. Chang et al. [29] indicated a significant rise in hepatotoxicity risk associated with adding PZA to INH and RIF. Hosford et al. [30] established a notable elevation in hepatotoxicity risk among individuals over 60 years of age through a systematic literature review. Abbara et al. [2] found low patient weight, HIV-1 co-infection, higher baseline ALP levels, and alcohol intake were risk factors. Thus, in our model, we predefined enzyme levels, utilization of anti-TB drugs such as PZA, INH, and RIF, hepatoprotective agents such as silymarin and glycyrrhetinic acid, alcohol intake, and demographic variables such as age, gender, education level, ethnicity, profession as predictors. In the ultimate XGBoost model, the contribution weights for chronic liver disease, ULN of ALT, ALP, Tbil, and age surpass 0.01, consistent with earlier research discoveries.

Currently, a range of predictive models for DILI primarily operates at the molecular level in preclinical settings [31], utilizing diverse artificial intelligence assisted algorithms [32]. Minerali et al. [33] employed the Bayesian ML method, resulting in an AUROC of 0.81, 74% sensitivity, 76% specificity, and 75% accuracy. Xu et al. [34] proposed a deep learning model, achieving 87% accuracy, 83% sensitivity, 93% specificity, and an AUROC of 0.96. Dominic et al.'s Bayesian prediction model [35] demonstrated balanced performance with 86% accuracy, 87% sensitivity, 85% specificity, 92% positive predictive value, and 78% negative predictive value. In the clinical stage, only Zhong et al. introduced a single tree XGBoost model with 90% precision, 74% recall, and 76% classification accuracy for DILI prediction, using a clinical sample of 743 TB cases [36]. In our study, we leveraged regional healthcare data and employed the XGBoost algorithm. The model exhibited 76% recall, 82% specificity, and 81% accuracy in predicting DILI status. Our approach was proven robust, as evidenced by a mean AUROC of 0.89 and AUPR of 0.75 upon tenfold cross validation. During the clinical treatment stage, our model exhibited high levels of accuracy and interpretability.

The choice of a cutoff in a DILI prediction model is crucial and depends on specific study goals and requirements. Various studies have investigated optimal cutoff values in DILI prediction models to enhance understanding and prediction accuracy. For instance, in a study focused on drug-induced liver tumors, the maximum Youden index was utilized to determine the ideal cutoff point [37]. Another study, aimed at predicting DILI and cardiotoxicity, determined 0.4 as the optimal cutoff value using chemical structure and in vitro assay data [38]. Similarly, a system named DILIps, designed to predict DILI in drug safety, utilized the ROC curve to select the best cutoff value [39]. Given the imbalanced dataset in our study, we found the precision recall curve method seemed to be more appropriate. Additionally, considering the severe consequences of DILI, prioritizing the detection of DILI suggests choosing a lower cutoff to maximize sensitivity. Thus, in our study, we opted for the maximum Youden index as the best cutoff.

However, the acceptability of ML in the medical community faces a significant hurdle regarding interpretability, particularly in settings where clinical decisions are paramount. Our research employed SHAP strategies to illuminate the complex mechanisms of the XGBoost model.

## Section: Strengths and limitations

The study utilized a large dataset of over 7,000 TB patients to develop a robust model and comprehensively included clinical, demographic, and biochemical variables to improve predictive accuracy. Furthermore, the model incorporates SHAP analysis to improve interpretability. However, as we embark on the integration of ML into clinical settings, a vital concern persists regarding the generalizability of models [40]. While our model demonstrates enhanced predictive accuracy, it's important to recognize the inherent limitations stemming from the lack of external validation. Patient characteristics [41] and drug interactions [42] may differ widely across populations. This underscores the importance of validating models on diverse patient cohorts and geographical regions. Moreover, the study's reliance on a data-driven approach and the inherent complexity of integrating ML models into clinical practice present additional limitations [43]. Additionally, the dependence on clinical diagnosis for DILI and the potential influence of unmeasured variables on model accuracy are acknowledged. While the study's findings offer valuable insights, careful consideration is warranted when interpreting them.

## Section: Conclusions

XGBoost shows improved predictive performance compared to RF and LASSO logistics in this study. Moreover, introducing the SHAP method enhances the clinical understanding and potential application of the model. For further research, external validation and more detailed feature integration are necessary.

## Section: Conclusions › Code availability statement

To enhance reproducibility and facilitate peer review, we uploaded the code used for model fitting. The source code associated with this research is available on the GitHub repository (https://github.com/cpu-pharmacoepi/TB-DILI). For inquiries or assistance related to the code, please contact 1,020,202,613@cpu.edu.cn.

## Section: Supplementary Information

Supplementary Material 1.

Supplementary Material 2.

## Section: Acknowledgements

The authors thank all staff of the tuberculosis control centers, designated hospitals, community health service centers, and township health centers in ten counties/districts from Ningbo for their hard work and help in collecting clinical data. We also thank our colleagues from Ningbo Health Information Center for providing clinically relevant data for this study.

## Section: Acknowledgements › Disclosure of AI tools

We hereby disclose that generative AI tools were not utilized in the preparation or analysis of data presented in this manuscript. All methodologies and analyses were conducted utilizing established statistical and machine learning techniques as outlined in the Method section.

## Section: Authors’ contributions

All authors were involved in the design of the study, FJ and RH cleaned data and constructed the cohort; YC was involved in conceptualizing the study; YX and JZ were responsible for the analysis of the data and interpretation of the results.; YX, JZ and TY contributed to the drafting of the manuscript. All authors read and approved the final manuscript.

## Section: Funding

This research was supported by Zhejiang Medical Research Project(2018KY733) and Natural Science Foundation of Ningbo (2019A610386, 2019A610385). The content is solely the responsibility of the authors and does not necessarily represent the official views of the funding agencies.

## Section: Availability of data and materials

The datasets used and analyzed during the current study are available from the corresponding author on reasonable request. Data cannot be shared publicly because of privacy and confidentially of the TB patients in Ningbo, Zhejiang, China.

## Section: Declarations › Ethics approval and consent to participate

All aspects of this study, including research methods were conducted in strict accordance with relevant guidelines and regulations. This study was conducted in compliance with the ethical principles outlined in the Declaration of Helsinki. All patient data in the database were de-identified, and this study was determined to be exempt by the Institutional Review Board of the Ningbo Municipal Center for Disease Control and Prevention. Written informed consent was waived for the present study. The institutional Review Board of the Ningbo Municipal Center for Disease Control and Prevention waived the need for informed consent.

## Section: Declarations › Consent for publication

Not applicable.

## Section: Declarations › Competing interests

The authors declare no competing interests.

## Section: Contributor Information

Jifang Zhou, Email: 1020202613@cpu.edu.cn.

Tianchi Yang, Email: cn-yangtc@outlook.com.

## Section: Associated Data

Supplementary Material 1.

Supplementary Material 2.

## Section: Associated Data › Supplementary Materials

Supplementary Material 1.

Supplementary Material 2.

## Section: Associated Data › Data Availability Statement

The datasets used and analyzed during the current study are available from the corresponding author on reasonable request. Data cannot be shared publicly because of privacy and confidentially of the TB patients in Ningbo, Zhejiang, China.


---

# Large language models facilitating modern molecular biology and novel drug development

- **Authors:** Xiao-Huan Liu, Zhen-Hua Lu, Tao Wang, Fei Liu
- **Issuer:** Frontiers in pharmacology
- **Type:** Scientific article
- **Published:** 2024-12-24
- **Language:** en
- **DOI:** 10.3389/fphar.2024.1458739
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39776586/
- **Licence:** CC-BY

## Section: Abstract

AbstractThe latest breakthroughs in information technology and biotechnology have catalyzed a revolutionary shift within the modern healthcare landscape, with notable impacts from artificial intelligence (AI) and deep learning (DL). Particularly noteworthy is the adept application of large language models (LLMs), which enable seamless and efficient communication between scientific researchers and AI systems. These models capitalize on neural network (NN) architectures that demonstrate proficiency in natural language processing, thereby enhancing interactions. This comprehensive review outlines the cutting-edge advancements in the application of LLMs within the pharmaceutical industry, particularly in drug development. It offers a detailed exploration of the core mechanisms that drive these models and zeroes in on the practical applications of several models that show great promise in this domain. Additionally, this review delves into the pivotal technical and ethical challenges that arise with the practical implementation of LLMs. There is an expectation that LLMs will assume a more pivotal role in the development of innovative drugs and will ultimately contribute to the accelerated development of revolutionary pharmaceuticals.Keywords: artificial intelligence, large language models, drug development, ChatGPT, protein structure prediction

## Section: 1 Introduction

During the past few decades, the field of drug discovery has undergone a transformative revolution, largely due to the rapid advancements in information technology and modern biotechnology, such as artificial intelligence (AI), machine learning (ML), structural revolution (crystallography), and synthetic biology (Sadybekov and Katritch, 2023; Murray et al., 2023; Cova et al., 2022; Roggia et al., 2024). A notable paradigm shift is evident in contemporary drug discovery, where emerging technologies have streamlined the drug development process, consequently reducing associated costs (Pandey et al., 2022). Among them, computational approaches guided by molecular modeling techniques with AI for “hit identification” and “lead optimization” have garnered significant interest from biotech firms and research institutions (Jayatunga et al., 2022; Chakraborty et al., 2023). “Hit identification” is the process of screening large compound libraries to discover molecules that exhibit initial biological activity against a specific target, serving as potential starting points for drug development. “Lead optimization” is the systematic process of refining and enhancing the potency, selectivity, and pharmacokinetic properties of a promising drug candidate to improve its therapeutic potential and reduce side effects. Nowadays, the strategic application of AI in drug discovery has significantly hastened the development timeline and diminished both the cost and duration of early-stage drug discovery phases (Chakraborty et al., 2023; Lamberti et al., 2019).

LLMs are cutting-edge AI systems crafted on the foundation of neural network architectures and refined through exposure to human language from a plethora of sources, including articles, books, and news reports. Consequently, LLMs are capable of capture the complicated associative relationships between words in a text-based training dataset, harnessing the capabilities of deep learning (Thirunavukarasu et al., 2023). These models have been effectively integrated into numerous fields, demonstrating a versatility that encompasses dialogue and beyond. In particular, the recent surge in advancements within LLMs have paved the way for their integration into healthcare and biotechnological pharmaceutics (Liu et al., 2023a). Boasting the capacity to execute a multitude of language-centric tasks, LLMs capitalize on neural networks and are trained on vast repositories of text generated by humans, thus transforming them into invaluable assets for information retrieval and the delivery of biomedical insights. Consequently, they can serve as valuable tools for retrieving information and providing biomedical solutions (Thirunavukarasu et al., 2023; Eggmann et al., 2023). Among the vanguard of AI-powered LLMs, ChatGPT stands as a notable example, which was instrumental in streamlining the drug discovery process (De Angelis et al., 2023). Typically, LLMs in drug development could be utilized for understanding disease mechanisms, designing and optimizing drug molecules, predicting efficacy and safety, integrating with AI tools, translating between molecules and indications, and exploring federated learning for enhanced data utilization and task generalization. Especially, LLMs can be integrated with other AI technologies like machine learning and computational biology tools to synergistically accelerate drug discovery. For example, machine learning algorithms can analyze vast databases to identify intricate patterns, leading to the discovery of novel therapeutic targets and prediction of potential drug candidates with better accuracy and speed. Quantitative structure-activity relationship (QSAR) modeling and molecular docking simulations are AI-driven predictive techniques that provide insights into predicting the biological activity of novel compounds with great accuracy.

There is a strong belief that the rapid evolution and widespread adoption of AI are defining trends of our time. In this review, the recent development of LLMs was highlighted, including their architectural frameworks and operational mechanisms. Furthermore, the manuscript has placed a special emphasis on the practical applications of Large Language Models (LLMs) in the biopharmaceutical sector. Several successful case studies were detailed to highlight the strengths and limitations of these models. Each case study includes an in-depth analysis and critical evaluation of the respective models. It is especially crucial to diligently evaluate and address the associated concerns, risks, and potential pitfalls (Borji, 2023). It is believed that the integration of LLMs in drug discovery would greatly facilitate the acceleration of the drug discovery pipeline.

## Section: 2 Designing an artificial intelligence-driven platform

Schematic representation of the ChatGPT-assisted drug addiction research process. (This process initiates with grasping the roles of AI in drug addiction research and generating drug-like molecules. It advances by refining the GNC model to produce leads targeting DAT, NET, and SERT receptors. Optimization is driven by the Langevin equation and an enhanced GNC model, prioritizing binding affinity predictions, which led to 15 potential drug leads pinpointed. ChatGPT supports this process by offering creative input, methodological insights, and coding aid, from debugging to interpretation).

Schematic of a GRU-enhanced autoencoder for drug design: from SMILES encoding to cocaine addiction treatment leads. (The molecular generation pipeline uses a GRU-based autoencoder to encode and decode SMILES strings, and the stochastic generator was used to create novel molecules. The process starts from input SMILES through latent space manipulation to generated SMILES. Subsequently ADMET screening and binding affinity prediction were achieved for the identification of potential cocaine addiction treatment leads).

The study flowchart to predict and explain drug-drug interactions with ChatGPT.

T Overview of the benchmark MultiMedQA, PaLM and Med-PaLM. (Various medical question-answering datasets are integrated into a multimodal framework, which would improve the performance of PaLM through prompting and instruction tuning for clinical applications).

The workflow of MolReGPT. (This figure illustrates a four-step process for generating molecular captions and text-based molecular designs. Initially, it retrieves examples from a database using molecular information. Subsequently, it curates prompts with system instructions for tasks like molecular captioning and generation. In the third phase, it uses a few examples to facilitate a language model learn and generate responses. Finally, it calibrates the generation to ensure the responses are accurate and in the correct format for tasks like Mol2Cap, where it describes molecules).

The workflow of Chemformer. (It shows a two-step process for training a molecular model. In Step 1, the model is pre-trained on 100 million molecules, where it learns to encode and decode molecular structures. In Step 2, the model is fine-tuned for specific tasks, such as predicting reactions, optimizing molecules, and estimating molecular properties. Each task uses an encoder to understand the molecule and a decoder to generate the result).

The architectural structure of MolGPT.

The architectural structure of MOLGEN. (In Step 1, the model learns molecular language syntax and meaning by encoding and decoding molecular structures. In Step 2, the model is fine-tuned with domain-agnostic molecular prefixes to improve the capability of understanding molecular structures. In this process, a self-feedback paradigm was included, where the model is capable of generating candidates, evaluating them based on properties, and learns from the feedback to enhance the performance for generating synthetic and natural product molecules).

The architectural structure of KV-PLM. (The workflow of KV-PLM starts with internal molecular structure serialization into SMILES format, then the Meta-knowledge mapping is utilized to correlates molecular features to human intelligence. External biomedical text would subsequently be fused with molecular data. The language model pre-training would empower the model with the ability to predict molecular properties. It enables knowledgeable machine reading across different molecular properties (e.g., molecular structure, chemical properties, natural language documentation, and structured biomedical knowledge), which would facilitate tasks like description generation, property prediction, and knowledge extraction).

The workflow of MolT5. (MolT5 is trained in two steps (Sadybekov and Katritch, 2023): in pre-training, it learns from public data such as the chemical formulas and reactions (Murray et al., 2023). In fine-tuning, it specializes in tasks like creating molecule descriptions and generating new molecules).

The pipeline of Text + Chem T5. (Text + Chem T5 is capable of dealing with both text and chemistry information, which has a text encoder and a chemistry encoder that work together to understand inputs from different domains. The model is capable of understanding a chemical structure and generate a description for it, or it could receive a description and generate the chemical structure in SMILES format).

A four-step process of Mol-Instructions for creating and refining molecular descriptions and data. [(Sadybekov and Katritch, 2023) human and AI work together to generate task descriptions about molecules (Murray et al., 2023); information about molecules is gathered from data sources and formatted for AI (Cova et al., 2022); biological data is turned into text using templates, such as description of the functions of a specific protein (Roggia et al., 2024); the quality of molecules and proteins is checked].

Outline of the ConPLex model architecture and training framework (In step (Sadybekov and Katritch, 2023), a pre-trained protein language model and a circular fingerprint method are used to analyze molecular structures. In step (Murray et al., 2023), embedding layers process the molecular data, creating a numerical representation. In step (Cova et al., 2022), the model undergoes a series of binary and contrastive epochs to update and refine the learning rate and margin for improved accuracy in predicting molecular interactions).

The model architecture of ComplexQA with the deep graph convolution network. (ComplexQA is capable of molecular analysis that processes various molecular features through Conv1D blocks and integrates edge information using Conv2D blocks. Then applies graph convolutional networks (GCNs) with multiple blocks was used for feature aggregation and normalization. Finally, it concludes with the generation of a residue interface score to assess molecular interactions).

The workflow of ProteinMPNN. (ProteinMPNN is consisted of a backbone encoder that processes protein backbone coordinates and edge information, and a sequence decoder capable of generating protein sequences. Nodes and edges are updated in the encoder, and through iterative decoding, it produces a protein sequence with a calculated probability).

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development

Armed with the capabilities of natural language processing (NLP) and machine learning technologies, chatbots have demonstrated significant potential and have made substantial contributions across several fields (Haque and Rubya, 2023; Xu et al., 2021; Suppadungsuk et al., 2023). In particular, the emergence of ChatGPT, with its harnessing of generative models, has heightened global awareness of the vast of generative AI (Sallam, 2023). As this technology continues to evolve, this section aims to offer a comprehensive of the recent advances in LLMs within the realm of biotechnological pharmaceutics.

Schematic representation of the ChatGPT-assisted drug addiction research process. (This process initiates with grasping the roles of AI in drug addiction research and generating drug-like molecules. It advances by refining the GNC model to produce leads targeting DAT, NET, and SERT receptors. Optimization is driven by the Langevin equation and an enhanced GNC model, prioritizing binding affinity predictions, which led to 15 potential drug leads pinpointed. ChatGPT supports this process by offering creative input, methodological insights, and coding aid, from debugging to interpretation).

Schematic of a GRU-enhanced autoencoder for drug design: from SMILES encoding to cocaine addiction treatment leads. (The molecular generation pipeline uses a GRU-based autoencoder to encode and decode SMILES strings, and the stochastic generator was used to create novel molecules. The process starts from input SMILES through latent space manipulation to generated SMILES. Subsequently ADMET screening and binding affinity prediction were achieved for the identification of potential cocaine addiction treatment leads).

The study flowchart to predict and explain drug-drug interactions with ChatGPT.

T Overview of the benchmark MultiMedQA, PaLM and Med-PaLM. (Various medical question-answering datasets are integrated into a multimodal framework, which would improve the performance of PaLM through prompting and instruction tuning for clinical applications).

The workflow of MolReGPT. (This figure illustrates a four-step process for generating molecular captions and text-based molecular designs. Initially, it retrieves examples from a database using molecular information. Subsequently, it curates prompts with system instructions for tasks like molecular captioning and generation. In the third phase, it uses a few examples to facilitate a language model learn and generate responses. Finally, it calibrates the generation to ensure the responses are accurate and in the correct format for tasks like Mol2Cap, where it describes molecules).

The workflow of Chemformer. (It shows a two-step process for training a molecular model. In Step 1, the model is pre-trained on 100 million molecules, where it learns to encode and decode molecular structures. In Step 2, the model is fine-tuned for specific tasks, such as predicting reactions, optimizing molecules, and estimating molecular properties. Each task uses an encoder to understand the molecule and a decoder to generate the result).

The architectural structure of MolGPT.

The architectural structure of MOLGEN. (In Step 1, the model learns molecular language syntax and meaning by encoding and decoding molecular structures. In Step 2, the model is fine-tuned with domain-agnostic molecular prefixes to improve the capability of understanding molecular structures. In this process, a self-feedback paradigm was included, where the model is capable of generating candidates, evaluating them based on properties, and learns from the feedback to enhance the performance for generating synthetic and natural product molecules).

The architectural structure of KV-PLM. (The workflow of KV-PLM starts with internal molecular structure serialization into SMILES format, then the Meta-knowledge mapping is utilized to correlates molecular features to human intelligence. External biomedical text would subsequently be fused with molecular data. The language model pre-training would empower the model with the ability to predict molecular properties. It enables knowledgeable machine reading across different molecular properties (e.g., molecular structure, chemical properties, natural language documentation, and structured biomedical knowledge), which would facilitate tasks like description generation, property prediction, and knowledge extraction).

The workflow of MolT5. (MolT5 is trained in two steps (Sadybekov and Katritch, 2023): in pre-training, it learns from public data such as the chemical formulas and reactions (Murray et al., 2023). In fine-tuning, it specializes in tasks like creating molecule descriptions and generating new molecules).

The pipeline of Text + Chem T5. (Text + Chem T5 is capable of dealing with both text and chemistry information, which has a text encoder and a chemistry encoder that work together to understand inputs from different domains. The model is capable of understanding a chemical structure and generate a description for it, or it could receive a description and generate the chemical structure in SMILES format).

A four-step process of Mol-Instructions for creating and refining molecular descriptions and data. [(Sadybekov and Katritch, 2023) human and AI work together to generate task descriptions about molecules (Murray et al., 2023); information about molecules is gathered from data sources and formatted for AI (Cova et al., 2022); biological data is turned into text using templates, such as description of the functions of a specific protein (Roggia et al., 2024); the quality of molecules and proteins is checked].

Outline of the ConPLex model architecture and training framework (In step (Sadybekov and Katritch, 2023), a pre-trained protein language model and a circular fingerprint method are used to analyze molecular structures. In step (Murray et al., 2023), embedding layers process the molecular data, creating a numerical representation. In step (Cova et al., 2022), the model undergoes a series of binary and contrastive epochs to update and refine the learning rate and margin for improved accuracy in predicting molecular interactions).

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.1 ChatGPT

The chat generative pretrained transformer (ChatGPT), developed by OpenAI, stands at the forefront of language model-based chatbots, renowned for its conversational interactivity (https://openai.com/blog/chatgpt). On 14 March 2023, an upgraded version, GPT-4, was launched, which boasts improved capabilities for addressing complex issues with heightened precision and rationality. Furthering its progression, on 6 November 2023, the state-of-the-art model, GPT-4 Turbo, was introduced. This iteration is marked by its superior performance, an updated knowledge cutoff date of April 2023, and the introduction of a 128k context window, equating to the processing capacity of approximately 300 pages of text within a single prompt. Utilizing a neural network to process natural language, it is adept at generating contextually relevant responses and delivering nuanced, sophisticated answers through advanced modeling techniques (Brown et al., 2020).

Generally, ChatGPT can be harnessed in the following capacities. Primarily, ChatGPT serves as an intuitive interface a that facilitates more straightforward interactions between users and various AI systems, offering an alternative to traditional knowledge graph navigation. Indeed, it has emerged as a leading example of sophisticated human–computer interaction (HCI). Secondly, ChatGPT can be specifically applied for drug discovery, functioning as an advanced search engine tailored to the nuances of biological science in different ways (Savage, 2023). For rational drug design, ChatGPT could be used to generate innovative chemical structures with a high potential for clinical success and predict the absorption, distribution, metabolism, excretion, and toxicity (ADMET) profiles of the identified compounds (Savage, 2023; Zhao and Wu, 2023). Within this domain, efficient screening can be performed with ultra-large virtual libraries (greatly expanded drug-like chemical spaces), which would significantly amplify the drug-like chemical spaces and enhancing the probability of hit identification and lead discovery. Thirdly, ChatGPT holds promise in the generation of new protein targets for drug development. When equipped with extensive unlabeled data (e.g., the nearly 250 million protein sequences contained in the UniProt database and 1.28 million protein sequences contained in the PDB database), ChatGPT can autonomously deduce the intricate relationships between molecular building blocks on its own. In this field, its functionality mirrors that of AlphaFold, which depends heavily on (new) big data analytics and artificial intelligence for its operations.

In a study by Wang et al. (2023a), ChatGPT was successfully applied for the discovery of an anti-cocaine-addiction drug, which functions as a virtual guide offering strategic and methodological insights, as well as generative models for optimal drug-like molecules with desired properties (Figure 1). With the aid of ChatGPT, a novel platform named the Stochastic Generative Network Complex (SGNC) was developed. With this project, ChatGPT primarily serves for idea generation, methodology clarification, and coding assistance (Figure 2). For idea generation, ChatGPT was augmented with three plugins (WebPilot, ScholarAI, and AskYourPDF), which improves its capacity to comprehend the research background of anti-cocaine-addiction drug development, providing up-to-date available sources and accessing insights from previous works. For methodology clarification, plugins (WebPilot, Link Reader and Wolfram) were used to significantly improve the mathematical and statistical capabilities of ChatGPT. In terms of coding assistance, WebPilot, ChatwithGit, and Prompt Perfect were leveraged to refine coding skills and craft perfect prompts.

ChatGPT has been instrumental in successful identification of 15 promising drug leads capable of targeting the dopamine transporter (DAT), norepinephrine transporter (NET), and serotonin transporter (SERT). It was clearly indicated that the “cognitive abilities” of ChatGPT have the potentials to significantly streamline the development of modern pharmaceuticals offering potential promising avenues for drug discovery. However, it was also noted that the application of ChatGPT for drug development still faces many challenges due to the inherent limitations of generative AI. For example, it is still susceptible to generate false narratives and spread misinformation. Consequently, it is recommended that the information generated by ChatGPT-4 undergo rigorous and consistent verification to ensure its accuracy and reliability.

Mondal et al. explored the proficiency of ChatGPT in predicting and elucidating common drug-drug interactions (DDIs) (Figure 3) (Juhi et al., 2023). Initially, a curated set of 40 pairs of previously listed DDIs were selected for analysis via ChatGPT through a two-tiered questioning approach. The outcomes showed that for the initial query, one response was incorrect, while of the correct responses, 19 were definitive and 20 remained ambiguous. For the second question, one answer was deemed incorrect, with 17 correct answers being definitive and 22 being inconclusive. These results suggest that ChatGPT serves as a moderately effective instrument for assessing DDIs; however, it occasionally falls short in offering comprehensive guidance, indicating the necessity for further refinements to enhance its accuracy and reliability.

Zhang et al. investigated the competencies of ChatGPT in the realms of question-answering, knowledge discovery, and knowledge reasoning within the biomedical field, specifically its ability to establish connections between pairs of proposed entities. The performance of ChatGPT was then compared with existing biomedical knowledge graphs (BKGs) (Hou et al., 2023). The findings indicated that ChatGPT-4.0 outperformed BKGs in terms of providing existing knowledge, although BKGs had a higher confidence level and demonstrated higher reliability in terms of information accuracy. Moreover, compared with BKGs, ChatGPT demonstrated a limited ability to perform novel discoveries based on the existing information and to provide reasoning for knowledge discovery. Therefore, the study proposed that strategies integrating LLMs (like ChatGPT) and BKGs could be promising to enhance task performance and mitigate potential risks.

Xu et al. delved into the prowess and promise of ChatGPT within the realm of biomedical information retrieval, with a particular focus on its ability to discern associations between drugs and diseases (Gao et al., 2023). Their findings showed that ChatGPT achieved an impressive accuracy range of 74.6%–83.5% in identifying drug-disease associations and an even more remarkable 96.2%–97.6% for true and false pairs under varying prompt designs. This revealed that ChatGPT could serve as a valuable “assistant” in unearthing knowledge related to biotechnological and pharmaceutical advancements, with a level of reliability that is quite satisfactory. Nevertheless, it was also emphasized that the insights gleaned from ChatGPT should undergo thorough verification before being integrated into clinical practice. In a separate study, ChatGPT was employed to meticulously annotate single-cell RNA sequencing data, successfully correlating rare cell types with their functions and uncovering several distinct differentiation pathways of cell subtypes that had previously eluded detection (Zehua and Du, 2023).

Blatz et al. demonstrated the transformative potential of ChatGPT and other LLMs in the field of dental medicine (Eggmann et al., 2023). It was concluded that LLMs (e.g., ChatGPT) could be instrumental in several areas (Sadybekov and Katritch, 2023): revolutionizing dental practice by streamlining administrative tasks (Murray et al., 2023); enhancing dental telemedicine through real-time language translation services, thereby making consultations more accessible and scalable, particularly in underserved regions (Cova et al., 2022); bolstering clinical decision support by swiftly summarizing voluminous medical records or aggregating evidence-based medical findings (Roggia et al., 2024); expediting administrative tasks such as routine correspondence and record-keeping (Pandey et al., 2022); enriching patient education with credible health advice and guidance (Jayatunga et al., 2022); advancing dental education through the creation and administration of multiple-choice exams, practical assessments, and supervised patient treatments; and (Chakraborty et al., 2023) refining scientific writing, making it more coherent for non-native English speakers. In addition, the study underscored the imperative to address several critical challenges effectively (Sadybekov and Katritch, 2023): ensuring robust cybersecurity measures to safeguard patient data and medical information against malware attacks (Murray et al., 2023); implementing stringent patient data privacy protections to maintain confidentiality and security; and (Cova et al., 2022) conducting thorough scientific evaluations and verifications of LLM-generated responses to maintain accuracy and reliability.

As highlighted in numerous studies, ChatGPT is poised to exert profound influences on various aspects of natural science and social science in the near future. On the one hand, it is imperative to recognize that at present, ChatGPT might not be a fully-fledged “sage” capable of providing responses replete with adequate reasoning and evidence-based justifications (Heck, 2023). Consequently, robust quality control protocols must be established to safeguard the accuracy, credibility, privacy, and cybersecurity of the swift and beneficial information dispensed by ChatGPT. On the other hand, there remains a critical need to improve the “intelligence” of ChatGPT, thereby transforming it into an indispensable asset for researchers.

Schematic representation of the ChatGPT-assisted drug addiction research process. (This process initiates with grasping the roles of AI in drug addiction research and generating drug-like molecules. It advances by refining the GNC model to produce leads targeting DAT, NET, and SERT receptors. Optimization is driven by the Langevin equation and an enhanced GNC model, prioritizing binding affinity predictions, which led to 15 potential drug leads pinpointed. ChatGPT supports this process by offering creative input, methodological insights, and coding aid, from debugging to interpretation).

Schematic of a GRU-enhanced autoencoder for drug design: from SMILES encoding to cocaine addiction treatment leads. (The molecular generation pipeline uses a GRU-based autoencoder to encode and decode SMILES strings, and the stochastic generator was used to create novel molecules. The process starts from input SMILES through latent space manipulation to generated SMILES. Subsequently ADMET screening and binding affinity prediction were achieved for the identification of potential cocaine addiction treatment leads).

The study flowchart to predict and explain drug-drug interactions with ChatGPT.

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.2 Google bard and microsoft bing

Bard AI, a cutting-edge large language model developed by Google, signifies a new frontier in the field of AI-powered chatbots (Pichai, 2023). Propelled by the Language Model for Dialogue Applications (LaMDA, a state-of-the-art transformer-based neural language model), Bard is honed on an expansive dataset, ensuring its proficiency in conversational AI. Sharing a repertoire of capabilities with ChatGPT, Google Bard has demonstrated its efficacy across a spectrum of scientific applications, marking it as a formidable contender in the landscape of advanced AI technologies.

Sulaiman et al. conducted a study to assess proficiency of Google Bard in critically evaluating DDI screening, and it was subsequently compared with the authorized Lexicomp® Online™ database (Sulaiman et al., 2023). The interrater reliability analysis revealed a minimal concordance between Lexicomp and Google Bard in assessing DDI risk, with a Cohen’s kappa (κ) value of 0.01; similarly, a slight agreement between was observed in their severity ratings (κ = 0.02). However, there was a lack of consensus regarding the reliability rate, reflected by a κ value of −0.02. In a parallel study, AI platforms (ChatGPT, Bard, and Bing) were applied for DDI the prediction, and the sensitivity, specificity, and accuracy of each model were subsequently evaluated (Al-Ashwal et al., 2023). Notably, Microsoft Bing emerged as the top performer in terms of specificity (0.769) and accuracy (0.788). Furthermore, ChatGPT-3.5 and ChatGPT-4 exhibited the greatest variability in the consistency of their accuracy, highlighting the nuances in their predictive capabilities.

Cheungpasitporn et al. conducted a comparative analysis of the performance of various AI models (ChatGPT 3.5, ChatGPT 4, Bard AI, and Bing Chat) in identifying potassium and phosphorus content in foods (Qarajeh et al., 2023). The study revealed that ChatGPT 4 outperformed others in determining potassium content, achieving an overall accuracy of 81%, with specific rates of 60% for low-potassium foods and an impressive 99% for high-potassium foods. Comparatively, ChatGPT 3.5, Bard AI and Bing Chat showed accuracies of 66%, 79% and 81% accuracy, respectively. In the realm of phosphorus content identification, Bard AI stood out with a perfect 100% accuracy rate; in contrast, ChatGPT 3.5, ChatGPT 4 and Bing Chat managed to correctly identify high-phosphorus foods only 85%, 77% and 89% of the time, respectively. These findings illustrate the promising potential of AI-powered models in supporting renal diet management, particularly as adjunct tools for enhancing nutritional education and counseling. Nonetheless, it is evident that further enhancements are essential to achieve the desired levels of precision and reliability.

Tham et al. evaluated the proficiency of ChatGPT-3.5, ChatGPT-4.0, and Google Bard in generating accurate responses to inquiries concerning myopia (Beutel et al., 2023). Frequently asked myopia care-related questions were categorized into six different domains and allocated to the AI models. The responses generated were subsequently reviewed independently by three expert ophthalmologists, who graded them as poor, borderline, or good. A consensus approach was then used to establish the final assessment of each reply. The results showed that ChatGPT-4.0 outperformed in terms of accuracy, with 80.6% of the responses deemed ‘good’, surpassing 54.8% for Google Bard (Google Bard: 4.35 and ChatGPT-4.0: 4.23). All the models showed high average comprehensiveness scores and significant self-correction capabilities (66.7% for ChatGPT-4.0% and 60% for Google Bard). This highlighted the potential of ChatGPT-4.0 and Google Bard to deliver essential answers to myopia-related queries, although it is clear that their accuracy requires further enhancement and rigorous evaluation.

In a recent investigation, the capacity of ChatGPT and Google Bard to generate professional-quality responses to inquiries regarding ocular symptoms were systematically examined (Pushpanathan et al., 2023). The answers procured were meticulously appraised and graded by ophthalmologists at the consultant level, based on criteria of accuracy, comprehensiveness, and self-awareness. ChatGPT-4.0 achieved an impressive ‘good’ rating of 89.2%, significantly outperforming Google Bard, which registered at 40.5%. Although all the models garnered high mean comprehensiveness scores, they were concurrently found to display inadequate self-awareness capabilities. Parallel results were also observed in the accuracy of ChatGPT and Google Bard when addressing clinical radiology challenges on the Japan Radiology Board Examination (JRBE) (Toyama et al., 2023).

Therefore, although ChatGPT-4.0 demonstrated a distinct advantage in providing logical answers to a broad spectrum of inquiries, rigorous validation remains essential to ensure reliability and accuracy. In the context of research writing and data collection, it is worth noting that while Bard represents a modest improvement over ChatGPT (ChatGPT3.5) in analyzing the diversity of manuscript bibliographies, it still falls short of reference identification capabilities, even with its integration with Google search (King, 2023).

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.3 Med-PaLM

Recently, Google and DeepMind introduced MultiMedQA, which is a comprehensive collection of seven medical question-answering datasets (Figure 4), including LiveQA, MedQA, MedMCQA, MedicationQA, PubMedQA, HealthSearchQA, and MMLU clinical topics (Singhal et al., 2023). Utilizing MultiMedQA as a foundation, both the pathway language model (PaLM) (Chowdhery et al., 2022) and its instruction-tuned derivative, Flan-PaLM, were subjected to rigorous examination (Chung et al., 2022). The results showed that Flan-PaLM excelled in achieving the highest historical accuracy on the aforementioned datasets. Notably, Flan-PaLM scored an impressive 67.6% accuracy on MedQA (US Medical Licensing Exam-style questions), surpassing the previous state of the art by over 17%. These results prompted the implementation of prompt tuning to further specialize Flan-PaLM for the medical domain, resulting in the Med-PaLM model. Med-PaLM was capable of providing more favorable answers to the medical queries than clinicians, although its overall performance was still somewhat inferior to that of medical professionals. This demonstrated the effectiveness of instruction prompt tuning in improving the performance of Med-PaLM.

However, the study also identified limitations and proposed future research direction. These include expanding MultiMedQA to better mirror real-world clinical workflows, developing key LLM capabilities for numerous clinically significant applications, refining human evaluation, and addressing issues of fairness, equity, and ethical considerations.

T Overview of the benchmark MultiMedQA, PaLM and Med-PaLM. (Various medical question-answering datasets are integrated into a multimodal framework, which would improve the performance of PaLM through prompting and instruction tuning for clinical applications).

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.4 DrugChat

In a cutting-edge study, a pharmaceutical domain-specific LLM prototype, DrugChat, was developed to utilize ChatGPT-like capabilities for the analysis of drug compounds and the provision of insights on drug–molecule graphs (Liang et al., 2023). Like ChatGPT, DrugChat engages in multi-turn, interactive dialogues to address inquiries about uploaded compound molecule graphs. It is composed of three core components: a graph neural network (GNN), a large language model (LLM), and an adaptor, all of which are trained in an end-to-end fashion.

The GNN is tasked with interpreting the input compound molecule graph and extracting a meaningful representation. The adaptor then converts this graph representation into a format that is compatible with LLM. The LLM processes the transformed compound representation alongside the questions posed about the compound, ultimately generating answers.

For the instruction tuning phase, datasets comprising 10,834 drug compounds and 143,517 question-answer pairs were curated to train DrugChat. In this process, a pretrained GNN and a pre-trained Vicuna-13b model were utilized, with the weight parameters for the GNN and LLMs being fixed. However, the weight parameters for the adapter were continuously refined. The results demonstrated the proficiency of DrugChat in responding to various questions about the input compounds, such as “What makes this compound unique?” and “What diseases might this compound be able to treat?”, even when evaluated on the drug compound graphs not present in the training data.

However, as highlighted, the most significant challenge for DrugChat could be the phenomenon of “artificial (molecular) hallucinations” stemming from the implanted LLMs. The generation of unreliable answers and descriptions could seriously impede its practical application in drug discovery, potentially leading to undesirable consequences.

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.5 MolReGPT

Recently, a groundbreaking LLM-based system known as MolReGPT has been developed, which showcases the ability to translating molecule captions into natural language (Li et al., 2023). This system employs a retrieval-based prompt paradigm through in-context learning for both molecule captioning and text-based molecule generation. This could potentially revolutionize molecule discovery with MolReGPT without the need for fine-tuning. MolReGPT is structured around four principal components (Figure 5), including molecule caption retrieval (identifying the n most analogous examples), prompt management (constructing the system prompt), in-context few-shot molecule learning (translating molecule caption), and generation calibration (assessing validity). For the task of molecule caption retrieval, MolReGPT leverages Morgan fingerprints for molecule captioning and BM25 for text-based molecule generation. Prompt management encompasses four key steps: role identification, task description, example generation, and instruction output.

The results indicated that MolReGPT surpasses the performance of the tested fine-tuned models (e.g., MolT5-base) without any additional fine-tuning, achieving Text2Mol scores of 0.560 for molecule captioning and 0.571 for molecule generation. In terms of molecule understanding and text-based molecule generation, MolReGPT is comparable to the fine-tuned model MolT5-large. These findings suggest that MolReGPT could provide an innovative and adaptable platform for harnessing the potential of LLMs to advance molecule discovery through in-context learning, which might greatly reduce the cost associated with domain transfer.

The workflow of MolReGPT. (This figure illustrates a four-step process for generating molecular captions and text-based molecular designs. Initially, it retrieves examples from a database using molecular information. Subsequently, it curates prompts with system instructions for tasks like molecular captioning and generation. In the third phase, it uses a few examples to facilitate a language model learn and generate responses. Finally, it calibrates the generation to ensure the responses are accurate and in the correct format for tasks like Mol2Cap, where it describes molecules).

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.6 Chemformer

To tackle the resource-intensive challenge and multitasking demands in cheminformatics, a transformer-based model named Chemformer has been introduced, leveraging SMILES notation (Irwin et al., 2022). Chemformer, which is based on the BART language model, is versatile and can be readily applied to diverse tasks, such as sequence-to-sequence (e.g., reaction prediction and molecular optimization) and discriminative cheminformatics (e.g., property prediction) tasks, with the encoder stack alone being sufficient for many of these applications.

The training of Chemformer primarily consists of two stages (Figure 6): self-supervised pretraining and downstream fine-tuning. In the pretraining phase, extensive unlabeled SMILES datasets are used for model training through three different self-supervised pretraining tasks (masking, augmentation and a combination of masking and augmentation). During the fine-tuning phase, the pretrained Chemformer is tailored to a specific downstream task and further refined. A multitask learning strategy is utilized in this process to optimize multiple tasks concurrently, such as multiproperty prediction and multigene activity prediction. In particular, Chemformer has achieved the highest accuracy available on benchmark datasets for direct synthesis and retrosynthesis prediction.

The outcomes for chemical reaction prediction, molecular optimization and property prediction demonstrate the adaptability of Chemformer to various downstream tasks. The convergence rate and performance of Chemformer on downstream tasks could be improved by self-supervised pretraining. When training time is limited, the synergy of transfer learning and the innovative augmentation strategy can produce state-of-the-art results across all the tested downstream Seq2seq tasks, including chemical reaction prediction and molecular optimization.

The workflow of Chemformer. (It shows a two-step process for training a molecular model. In Step 1, the model is pre-trained on 100 million molecules, where it learns to encode and decode molecular structures. In Step 2, the model is fine-tuned for specific tasks, such as predicting reactions, optimizing molecules, and estimating molecular properties. Each task uses an encoder to understand the molecule and a decoder to generate the result).

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.7 MolGPT

To develop a generative pretraining (GPT) model adept at generating chemical structures with tailored properties or synthesizing drug-like molecules, a transformer-decoder-based generative model named MolGPT has been proposed (Bagal et al., 2022). MolGPT is comprised of three principal components (Figure 7): the input encoder, transformer-decoder model, and output decoder. The input encoder translates target molecules represented in the Simplified Molecular Input Line Entry System (SMILES) notation into a string of characters. The transformer-decoder model is comprised of multiple transformer modules and a single decoder module. Each transformer module features a multi-head masked self-attention mechanism calculated by the “Scaled Dot Product Attention”, and a feed-forward network designed to capture contextual information of the input sequence. The decoder module employs both self-attention and an encoder-decoder attention mechanism to generate the subsequent SMILES token. The output decoder then translates the generated SMILES string into a molecular structure. In this process, the resultant molecules can be generated based on desired single or multiple properties, a specified scaffold, or a combination of both.

Benchmarking experiments for training and evaluation demonstrated that MolGPT boasts exceptionally high validity and uniqueness scores, along with commendable Frechet ChemNet Distance (FCD) and KL divergence scores for the MOSES and GuacaMol datasets. Moreover, in terms of validity and novelty, MolGPT outperformed all the other tested methods for the GuacaMol dataset. In addition, MolGPT was found to acquire higher-level chemical representations through molecular property control, enabling the generation of molecules with intriguing properties or specified scaffolds. Based on these results, MolGPT is poised to play a critical role in the realm of rational drug design.

In a recent advancement, a conditional generative pretrained transformer model, cMolGPT, was designed for the autoregressive generation of target-specific de novo molecules using natural language processing (NLP) techniques (Wang et al., 2023b). This model was initially pretrained on an extensive SMILES dataset, enabling it to learn the parametric probabilistic distribution of drug-like properties (e.g., LogP and molecular weight), across the SMILES vocabulary space in an unsupervised manner. The cMolGPT model incorporates a of key-value pairs within the transformer architecture, which is further enforced by target-specific embeddings to facilitate the conditional generation of multihead attention for drug-like compounds. The findings revealed that cMolGPT is adept at generating SMILES strings that represent both drug-like and active compounds. In addition, the generated compounds not only closely resemble the chemical space of actual target-specific molecules but also encompass a significant portion of novel compounds. To assess the performance in generating target-specific compounds, evaluations were conducted on three target-biased datasets: EGFR, HTR1A, and S1PR1. The compounds generated by cMolGPT were predicted to exhibit higher activity compared to those generated by the tested conditional RNN models. This suggests that cMolGPT is a promising tool in the field of drug discovery, capable of expanding the chemical space of potential therapeutic agents.

To encapsulate the findings, it is evident that a transformer-decoder-based generative model could achieve state-of-the-art performance in the rational design and discovery of desired chemical structures. Consequently, such a model is regarded as an invaluable asset in the realm of de novo drug design, showcasing its potential to revolutionize the way we approach the development of novel therapeutics.

The architectural structure of MolGPT.

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.8 MOLGEN

To synthesize molecules with specific desired attributes, MOLGEN, a sophisticated pretrained molecular language model, has been recently introduced (Fang et al., 2023b). This system encompasses two pivotal stages (Figure 8): (Sadybekov and Katritch, 2023) a two-stage domain-agnostic molecular pretraining and (Murray et al., 2023) a self-feedback mechanism designed to mitigate the occurrence of “molecular hallucinations”. During the initial phase, the system reconstructs over 100 million molecules using SELFIES, a highly robust molecular language. This approach is complemented by the introduction of the domain-agnostic molecular prefix, which improves the transferability of the knowledge across diverse domains. The subsequent stage introduces a self-feedback paradigm, which is instrumental in fine-tuning the model’s parameters in accordance with generative probabilities, thereby incrementally refining the optimization of the generated molecules. This mechanism is pivotal in enabling MOLGEN to produce molecules with desired properties while circumventing the pitfalls of “molecular hallucinations”.

The efficacy of MOLGEN was subjected to a rigorous evaluation through extensive testing on established benchmarks. The assessments focused on its ability to accurately capture molecular distributions, generate diverse and realistic molecules, pinpoint targeted molecules and refine molecules under constraints. Across the domains of natural products and synthetic molecules, MOLGEN has consistently its proficiency in generating molecules that align with desired chemical preferences (e.g., logP (octanol–water partition coefficient), QED (quantitative estimate of drug likeness). Moreover, it has demonstrated a notable potential for identifying essential molecular substructures and navigating the chemical space, highlighting its value in the realm of molecular design and drug discovery.

The architectural structure of MOLGEN. (In Step 1, the model learns molecular language syntax and meaning by encoding and decoding molecular structures. In Step 2, the model is fine-tuned with domain-agnostic molecular prefixes to improve the capability of understanding molecular structures. In this process, a self-feedback paradigm was included, where the model is capable of generating candidates, evaluating them based on properties, and learns from the feedback to enhance the performance for generating synthetic and natural product molecules).

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.9 KV-PLM

Recognizing the limitations of current machine reading models, which tend to handle various data types separately, a significant divide often emerges between the nuanced interpretation of molecular structures and the absorption of knowledge from biomedical literature. To address this, Recently, a groundbreaking machine reading system known as KV-PLM has been introduced. It is designed to seamlessly integrate molecular structure data with biomedical text within a single deep learning architecture (Figure 9) (Zeng et al., 2022). The KV-PLM leverages the pretrained language model BERT12 as its foundational component. It employs the simplified molecular-input line-entry system (SMILES) to encode molecular structures into a format compatible with the byte pair encoding (BPE) algorithm. This encoding process transforms SMILES strings into a series of substring patterns. These patterns are then integrated into a comprehensive biomedical data and subjected to pretraining under a unified language modeling framework. The culmination of this process is the acquisition of meta-knowledge through a self-supervised language model, which can be efficiently adapted through fine-tuning for specific application within the biomedical domain.

To evaluate the efficacy of KV-PLM, a range of mono-source biomedical tasks were conducted, encompassing both molecular structure-related and biomedical text-related tasks. The system’s performance was benchmarked on MoleculeNet for SMILES property classification across datasets such as BBBP, SIDER, TOX21, and HIV, as well as for chemical reaction classification was evaluated on USPTO 1k TPL dataset. Additionally, the system was evaluated on biomedical named entity recognition (NER) and the relation extraction (RE) task using BC5CDR and ChemProt. The results indicated that KV-PLM model not only outperformed other model in these tasks but also demonstrated an ability to engage in knowledgeable and versatile reading.

Moreover, the system’s proficiency in versatile reading tasks involving “cross-information retrieval”, “match judging”, and “human professional performance” was confirmed. KV-PLM excelled in these versatile tasks, notably in facilitating effective cross retrieval between substances and property descriptions. These capabilities highlight the immense potential of KV-PLM in the realms of novel drug discovery and molecular property prediction, offering researchers a tool to gain a holistic and in-depth comprehension of molecular entities.

The architectural structure of KV-PLM. (The workflow of KV-PLM starts with internal molecular structure serialization into SMILES format, then the Meta-knowledge mapping is utilized to correlates molecular features to human intelligence. External biomedical text would subsequently be fused with molecular data. The language model pre-training would empower the model with the ability to predict molecular properties. It enables knowledgeable machine reading across different molecular properties (e.g., molecular structure, chemical properties, natural language documentation, and structured biomedical knowledge), which would facilitate tasks like description generation, property prediction, and knowledge extraction).

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.10 MolT5

To facilitate efficient communication between molecules structures and natural language, and to address challenge of limited data, Molecular T5 (MolT5), a self-supervised learning framework, was developed (Edwards et al., 2022). This framework employs a transformer-based architecture (Figure 10), leveraging the T5 that has been pretrained text-to-text model, enabling the simultaneous processing of vast amounts of unlabeled natural language text and molecular string data for pre-training purposes. In pursuit of this objective, two new tasks were introduced and formalized: molecular language tasks, specifically molecule captioning, and text-guided de novo molecule generation. Although these molecule–language tasks share similarities with vision–language tasks, there present distinct challenges, particularly the increased complexity of molecular captioning due to the diverse range of possible languages used for captioning. The performance of MolT5 was rigorously assessed using a suite of evaluation metrics, including BLEU, ROUGE, and METEOR, as well as a newly developed cross-modal retrieval similarity metric, the Text2Mol metric. When evaluated against the ChEBI-20 dataset using both the Text2Mol metric and BLEU metric, MolT5 achieved superior scores and outperformed RNNs and transformers in the two newly defined tasks. Notably, the performance of MolT5 further improved as the language model size increased.

MolT5 pretrains models on single-modal data, effectively mitigating the issue of data scarcity within the chemical domain. Furthermore, a variety metrics were also adopted including a new cross-modal embedding-based metric, to evaluate the performance of molecule captioning and text-based molecule generation. Results show that MolT5-based models are capable of generating high-quality outputs, encompassing both molecules and captions, in numerous instances.

As previously mentioned, the effective deployment of MolT5 poised to bolster the application of molecular AI, empowering researchers to uncover potential drug candidates by engaging with AI through natural language interactions and acquiring target chemical structures with specific functional attributes rather than relying solely on their properties. However, it is imperative to pay close attention to the potential biases introduced by the training dataset, the SMILES strings utilized, and the authenticity of the compounds listed in ChEBI-20.

The workflow of MolT5. (MolT5 is trained in two steps (Sadybekov and Katritch, 2023): in pre-training, it learns from public data such as the chemical formulas and reactions (Murray et al., 2023). In fine-tuning, it specializes in tasks like creating molecule descriptions and generating new molecules).

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.11 Text + Chem T5

To bridge the gap between human‒machine interactions and establish a cohesive framework for natural language and chemical representations, the first multidomain, multitask language model, Multitask Text and Chemistry T5 (Text + Chem T5 (Figure 11), https://github.com/GT4SD/gt4sd-core), was developed (Christofidellis et al., 2023). This model excels in managing both chemical and natural languages in parallel, outperforming others in cross-domain tasks across a broad spectrum of NLP-based evaluation metrics. Moreover, it negates the need for costly mono-domain pretraining and task-specific models. The capabilities of Text + Chem T5 was rigorously assessed across a range of tasks, including the predictions of forward and reverse chemical reactions, the generation of text-conditional novel molecules, the captioning of molecules spanning various domains, and execution of paragraph-to-action tasks within the linguistic domain. The findings underscored the effectiveness of Text + Chem T5 as a versatile multidomain and multitask model, adept at generating precise and enlightening captions (with a BLEU-2 score of 0.625, a Rouge-1 score of 0.647 and a Rouge-2 score of 0.498) and adeptly translating between natural language and the SMILES representation of molecules in both text-to-chemistry and chemistry-to-text endeavors.

In particular, Text + Chem distinguishes itself by its capacity to navigate complex drug discovery workflows, such as a hypothetical molecular discovery process, with a unified model. In this study, Text + Chem T5 uniquely succeeded in generating the desired molecule for the “text-to-SMILES task”, provide a synthetic route identical to the target reaction for “retrosynthesis”, and conceptually succeed in identifying and proposing an extremely similar reaction in a chemistry laboratory for a “paragraphs to actions” task. This fascinating capability, previously uncharted, positions Text + Chem T5 as superior even to established models such as ChatGPT and Galactica 1.3B.

The paramount advantage of Text + Chem T5 lies in its multifaceted task management. As indicated in this manuscript, Text + Chem is poised for targeted application across a variety of fields, such as chemical reaction prediction and retrosynthesis, significantly and efficiently bolstering modern drug development discovery in the physical sciences. It streamlines these processes by circumventing the need for task-specific fine-tuning and enhancing human–model interactions.

The pipeline of Text + Chem T5. (Text + Chem T5 is capable of dealing with both text and chemistry information, which has a text encoder and a chemistry encoder that work together to understand inputs from different domains. The model is capable of understanding a chemical structure and generate a description for it, or it could receive a description and generate the chemical structure in SMILES format).

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.12 Mol-Instructions

Recently, a novel LLM named Mol-Instructions has been introduced, specifically crafted to address the complexities of biomacromolecules, particularly those relevant to structural biology (Fang et al., 2023a). This model encompasses a comprehensive instruction dataset that is segmented into three pivotal components (Figure 12). (Sadybekov and Katritch, 2023) Molecule-oriented instructions, which delve into the inherent properties and behaviors of small molecules essential for chemical reactions and molecular design (Murray et al., 2023); protein-oriented instructions, which are geared towards predicting the structures, functions, and activities of proteins for protein design; and (Cova et al., 2022) biomolecular text instructions, which engage in natural language processing (NLP) tasks that are integral to the fields of associated with bioinformatics and cheminformatics.

As shown in Figure 12, Mol-Instructions demonstrates great potential in biomolecular studies. In particular, Mol-Instructions could be applied in three major areas (Sadybekov and Katritch, 2023): assessment of cross-modal comprehension, which involves the integration of different types of data to enhance understanding of biomolecular systems (Murray et al., 2023). Exploration of deeper biomolecular design, enabling the development of more sophisticated and effective molecular structures (Cova et al., 2022). Tool learning to address complex biological challenges, leveraging advanced computational methods to address intricate biological questions. Mol-Instructions stands as a significant advancement in the integration of computational linguistics and molecular biology, offering a multifaceted approach to understanding and manipulating biomacromolecules.

A four-step process of Mol-Instructions for creating and refining molecular descriptions and data. [(Sadybekov and Katritch, 2023) human and AI work together to generate task descriptions about molecules (Murray et al., 2023); information about molecules is gathered from data sources and formatted for AI (Cova et al., 2022); biological data is turned into text using templates, such as description of the functions of a specific protein (Roggia et al., 2024); the quality of molecules and proteins is checked].

## Section: 2 Designing an artificial intelligence-driven platform › 2.1 Large language models (LLMs) for drug development › 2.1.13 ConPLex (https://ConPLex.csail.mit.edu)

Recently, a sophisticated deep learning model known as ConPLex has been successfully developed for the sequence-based prediction of drug-target interactions with remarkable accuracy, broad adaptivity, and specificity (Singh et al., 2023). ConPLex boasts a competitive edge due to the innovative integration of pretrained protein language models (“PLex”, for lexicographic pretraining) and protein-anchored contrastive coembedding (“Con”, for contrastive learning) (Figure 13). The “PLex” component is capable of alleviating challenges posed by limited DTI training data, while the “Con” aspect effectively maps target proteins and drugs into a unified latent space, ensuring distinct separation between true interacting partners. Consequently, ConPLex enables more accurate predictions of DTIs by leveraging the distance within the learned representations, even when dealing with massive compound libraries and the expansive human proteome.

The experimental results have demonstrated the model’s efficacy in successfully predicting the tested kinase-drug interactions, with 12 out of 19 pairs showing K D values less than 100 nM, including four with subnanomolar affinity and an efficient EPHB1 inhibitor (PD-166326, K D = 1.3 nM). Beyond its broad generalizability and high specificity, ConPLex enhances interpretability, rendering the drug-target embedding space and the functions of human cell-surface proteins more transparent. In addition to the in silico screening of small-molecular-weight compounds, ConPLex holds potential for screening other drugs types, such as antibodies, and for toxicity prediction.

Given these significant advantages, ConPLex is anticipated to revolutionize in silico drug screening at the genomic scale and to accelerate the development of innovative drugs in modern pharmaceutical research.

Outline of the ConPLex model architecture and training framework (In step (Sadybekov and Katritch, 2023), a pre-trained protein language model and a circular fingerprint method are used to analyze molecular structures. In step (Murray et al., 2023), embedding layers process the molecular data, creating a numerical representation. In step (Cova et al., 2022), the model undergoes a series of binary and contrastive epochs to update and refine the learning rate and margin for improved accuracy in predicting molecular interactions).

## Section: 2 Designing an artificial intelligence-driven platform › 2.2 Deep learning for macromolecular drugs (protein structure prediction)

Protein structures are traditionally elucidated through experimental techniques such as by X-ray crystallography, nuclear magnetic resonance (NMR) and electron cryomicroscopy (cryo-EM), which are known for their precision. However, these methods are complex, time-consuming, and costly, which limits their widespread application. In light of these constraints and the growing need for novel protein structures, there has been a surge in interest in innovative strategies, particularly bioinformatics approaches to obtain novel protein structures. Despite the promise of these methods, they still necessitate considerable experimental effort.

The model architecture of ComplexQA with the deep graph convolution network. (ComplexQA is capable of molecular analysis that processes various molecular features through Conv1D blocks and integrates edge information using Conv2D blocks. Then applies graph convolutional networks (GCNs) with multiple blocks was used for feature aggregation and normalization. Finally, it concludes with the generation of a residue interface score to assess molecular interactions).

The workflow of ProteinMPNN. (ProteinMPNN is consisted of a backbone encoder that processes protein backbone coordinates and edge information, and a sequence decoder capable of generating protein sequences. Nodes and edges are updated in the encoder, and through iterative decoding, it produces a protein sequence with a calculated probability).

## Section: 2 Designing an artificial intelligence-driven platform › 2.2 Deep learning for macromolecular drugs (protein structure prediction) › 2.2.1 AlphaFold

AlphaFold, developed by DeepMind, has revolutionized protein structure prediction with unprecedented accuracy and reliability, harnessing the power of neural networks and homology modeling for protein model construction (Pandey et al., 2022). To extend the capabilities to predict protein complexes accurately and efficiently, AlphaFold-Multimer was introduced, expanding the capabilities of Alphafold2 to handle multiple chains (Yin et al., 2022). The latest version, AlphaFold3, has been successfully applied in various fields, including modeling of conventional protein structures and structures with novel folds, structural construction of artificial constructs and prediction of protein‒protein interactions. In particular, models generated by AlphaFold typically achieve TM-scores greater above 0.9, suggesting that both the overall fold and the details of the constructed models are theoretically correct (Skolnick et al., 2021). To date, AlphaFold DB (AlphaFold DB, https://alphafold.ebi.ac.uk) has provided open access to more than 214 million protein structure predictions (Varadi et al., 2023).

The exceptional performance of AlphaFold is largely attributed to the novel neural network architectures and specialized training regimens that incorporate evolutionary, physical and geometric constraints inherent to protein structures (Jumper and Hassabis, 2022). Alongside the simultaneous generation of multiple sequence alignments (MSAs) and pairwise features, two key modules, Evoformer and the structure module, play critical roles in protein structure development (Skolnick et al., 2021). Evoformer, a building block of a novel neural network, approaches predict protein structures as a graph inference problem, with graph edge defined by the proximity of residues. It consists of two specialized transformers for distinct data types: the MSA transformer and the pair representation transformer. The structure module is tasked with local side chain packing rearrangements, prioritizing the orientations of the protein backbone and residues, and positioning the side chains of different residues.

In a study utilizing the program Accuracy of NMR Structures Using RCI and Rigidity (ANSURR), the accuracy of AlphaFold-generated structures was compared to NMR structures (Fowler and Williamson, 2022). The results revealed that the AlphaFold models generally surpass NMR ensembles in accuracy, although there are scenarios, particularly those involving dynamic structures, where NMR ensembles may be more precise. This suggests that AlphaFold might display relatively low confidence in predicting dynamic structures. Consequently, it has been proposed that AlphaFold could be instrumental in refining NMR structure. Furthermore, structures generated by AlphaFold and subsequently validated by ANSURR are likely to satisfy application requirements, potentially eliminating the need for additional refinement processes.

## Section: 2 Designing an artificial intelligence-driven platform › 2.2 Deep learning for macromolecular drugs (protein structure prediction) › 2.2.2 MULTICOM

To enhance the precision of AlphaFold-Multimer in predicting complex structure (Zhu et al., 2023), a sophisticated quaternary structure prediction system (MULTICOM) has been developed (Liu et al., 2023b). It is capable of optimizing the inputs transformed into AlphaFold-Multimer, evaluating and refining the resulting outputs. It employs a dual approach, utilizing traditional sequence alignment and Foldseek-based structure alignment to generate MSAs and to identify templates for individual monomers. These MSAs for monomers are subsequently merged to form MSAs for multimers. Moreover, the structural predictions generated can be appraised using a suite of complementary metrics, and the refinement of structural predictions can be achieved through a Foldseek-based structure alignment strategy.

The results showed that the average TM-score for the initial predictions from MULTICOM for CASP15 assembly targets was ∼0.76, making a 5.3% increase over the standard AlphaFold-Multimer. The average TM-score for the top 5 predictions by MULTICOM was ∼0.80, which represents an 8% increase compared with the standard AlphaFold-Multimer. In addition, the Foldseek structure alignment-based multimer structure generation (FSAMG) method outperformed several prevalent sequences alignment-based multimer structure generation methods, such as NBIS-AF2-multimer predictions.

## Section: 2 Designing an artificial intelligence-driven platform › 2.2 Deep learning for macromolecular drugs (protein structure prediction) › 2.2.3 ComplexQA

In a cutting-edge study, a novel model quality assessment method, ComplexQA, has been introduced. This method leverages a deep graph neural network-based algorithm designed to assess the local quality of interfacial residues within protein complexes (Figure 14) (Zhang et al., 2023). It does so by analyzing a combination of sequence data, 3D structural information, and chemical properties. The process begins by converting the protein complex structures into undirected graphs, followed by the derivation of feature representation for each graph node. All the features, including the hidden features, are concatenated and used for graph learning purposes. To represent the edges of the graph, residue–residue features are acquired, primarily through two newly designed matrices: the adjacent matrix and the edge distance matrix. By integrating these two representations, the edge embedding features are generated, which are then employed for the subsequent edge convolution operations within the graph convolutional network block. This block further consists of two subblocks: one for edge convolution and another for node convolution. Finally, the output is transformed into a 1D convolutional layer, which employs a linear activation function to produce the final results. This sophisticated approach by ComplexQA offers a comprehensive evaluation of protein complex structures, enhancing our ability to understand and predict their quality.

In comparative evaluations across diverse datasets, ComplexQA outperformed the other leading algorithms (DProQA, GNN-DOVE, TRScore, GOAP, and ZRANK2). It also displayed commendable performance on challenging targets that featured a sparse number of acceptable models. Furthermore, ComplexQA is capable of delivering a detailed assessment of each interface residue, offering a level of precision that is invaluable in the field of protein complex structure analysis.

The model architecture of ComplexQA with the deep graph convolution network. (ComplexQA is capable of molecular analysis that processes various molecular features through Conv1D blocks and integrates edge information using Conv2D blocks. Then applies graph convolutional networks (GCNs) with multiple blocks was used for feature aggregation and normalization. Finally, it concludes with the generation of a residue interface score to assess molecular interactions).

## Section: 2 Designing an artificial intelligence-driven platform › 2.2 Deep learning for macromolecular drugs (protein structure prediction) › 2.2.4 ProtGPT2

ProtGPT2 (https://huggingface.co/nferruz/ProtGPT2), a cutting-edge autoregressive transformer model grounded in language-based principles, has been engineered to de novo construct protein structures with high throughput efficiency (Ferruz et al., 2022). The transformer was trained on an expansive dataset of ∼50 million non-annotated sequences from the UniRef50 (UR50) database, encompassing the full spectrum of protein diversity, thereby enabling it to learn and “comprehend” the intricacies of protein language in an autoregressive manner. In addition to the standard performance metrics, a suite of extrinsic tests was meticulously designed to assess the quality of the protein sequences generated by ProtGPT2.

The findings were compelling that ProtGPT2 demonstrated an impressive ability to generate sequences that, while remotely related to natural counterparts, also bore resemblance to known structural spaces. The generated proteins mirrored the natural amino acid propensities observed in their naturally occurring counterparts, with a notable predilection for globular structures, accounting for roughly 80% of the generated proteins. Moreover, sequences generated by ProtGPT2 were found to be only distantly related to those found in nature. When these results were integrated with similarity network analyses, it became evident that ProtGPT2 possesses the unique capability to explore and sample previously uncharted territories within the vast protein space.

## Section: 2 Designing an artificial intelligence-driven platform › 2.2 Deep learning for macromolecular drugs (protein structure prediction) › 2.2.5 ProteinMPNN

Recently, a novel deep learning-based protein sequence design strategy, ProteinMPNN, has emerged, demonstrating significant advantages in both in silico and experimental tests (Dauparas et al., 2022). This innovative approach is founded on the structured transformer framework (Figure 15), incorporating a message-passing neural network (MPNN) architecture that encompasses 3 encoder layers, 3 decoder layers and 128 hidden layers. ProteinMPNN was designed to predict target protein sequences in an autoregressive manner from the N- to C-terminus using protein backbone features as input data. The sequence recovery rate of the baseline model was approximately 41.2%, which was notably increased to more than 50% following a series of improvements. These enhancements were primarily focused on the following aspects (Sadybekov and Katritch, 2023): incorporating additional distance metrics between virtual Cβs (Murray et al., 2023), introducing an edge update mechanism (Cova et al., 2022), employing random sampling for the decoding order within the decoder (Roggia et al., 2024), integrating coding information regarding the relative position and chain number, and (Pandey et al., 2022) the incorporation of Gaussian noise to enhance model robustness.

The results were impressive, with ProteinMPNN demonstrating the ability to design sequences for monomers and cyclic oligomers with remarkable stability and precision. Most of the proteins produced by the MPNN were soluble (96 design sequences, 73 soluble). The crystal structures and the electron cloud density of the core side chain were highly consistent with the intended design structures. Similar successes were achieved in the design of proteins with cyclic and internal repeat symmetries as well as those incorporating polyproline II helix motifs.

ProteinMPNN achieved a sequence recovery rate of 52.4%, marking a 19.5% increase compared to that of Rosetta for native protein backbones, and even surpassed AlphaFold in this specific task. The running time was remarkably swift, averaging approximately one second. In particular, ProteinMPNN also enabled the coupling of amino acid sequences at various positions across single or multiple chains, further expanding its versatility and applicability in protein sequence design.

The workflow of ProteinMPNN. (ProteinMPNN is consisted of a backbone encoder that processes protein backbone coordinates and edge information, and a sequence decoder capable of generating protein sequences. Nodes and edges are updated in the encoder, and through iterative decoding, it produces a protein sequence with a calculated probability).

## Section: 3 Concluding remarks

AI has become an indispensable tool for addressing a multitude of societal challenges. The future of AI in drug development is set to be a landscape of innovation and efficiency, and it has been seeing a significant shift towards data-driven approaches, personalized medicine and clinical trials revolution. Take the AI-driven drug discovery and personalized medicines for examples. AI is expected to dominate drug discovery by making more accurate predictions of drug-target interactions and enhancing our understanding of disease physiopathology. AI models will be trained on larger biomedical datasets, including genomics, proteomics, and metabolomics, to identify novel drug candidates and optimize drug design. AI will continue to drive the growth of personalized medicines by leveraging Big Data to tailor treatments to individual patients. The ability to analyze genetic, environmental, and lifestyle data will lead to the development of highly personalized treatment plans. AI has the potential to revolutionize clinical trials by improving patient recruitment, monitoring, and data analysis. Advanced algorithms will enable the identification of suitable candidates based on genetic and phenotypic profiles, ensuring that trials are conducted with the most appropriate cohort of participants. Particularly noteworthy is the proliferation of AI algorithm programs, including DeepMind AlphaFold, Atomwise, Recursion Pharmaceuticals, BenevolentAI, and Insilico Medicine. These examples showcase the diverse integration of AI across the drug development spectrum, from the early stages of drug discovery to manufacturing processes and post-market surveillance. The future looks promising, with AI set to play a central role in making drug development more efficient, targeted, and personalized.

Nevertheless, the proliferation of LLMs ha as also sparked significant apprehensions, such as the phenomenon of “artificial hallucinations” (Beutel et al., 2023; Ji et al., 2022). The dissemination of AI-generated misinformation, fiction, or unsubstantiated claims poses a risk of misguiding unsuspecting users. To optimize benefits and mitigate risks, several key challenges must be surmounted to harness the full potential of LLMs (Sadybekov and Katritch, 2023). Transparency concerns. This is paramount for academic discourse surrounding generative AI. It is recommended that the judicious use of AI in scientific research be underscored and clearly articulated, as this could significantly bolster credibility (Tang et al., 2024). Therefore, tools and techniques that enhance the explain ability and interpretability of AI models are crucial. Moreover, the transparency in data governance is essential, providing insight into the quality and suitability of data used for training and inference in algorithmic decision-making. This includes documenting the origin of data, collection methods, and any preprocessing steps, which is crucial for identifying and mitigating potential biases (Murray et al., 2023). Combating AI hallucinations. AI hallucinations can occur due to several factors, including overfitting, training data bias/inaccuracy, and high model complexity. The foundation of preventing AI hallucinations lies in using high-quality, diverse training data that represents real-life scenarios without biases and errors. Moreover, regular validation using test datasets and human-in-the-Loop verification should also be instituted to preempt the spread of misinformation and to counteract biased responses. Finally, risk-based review systems and retrieval-augmented generation (RAG) might also be helpful in prioritizing and verifying the review of AI outputs (Cova et al., 2022). Dataset limitations. Owing to the nature of AI, the quality and scope of available data are pivotal to the design and practical application of AI models. There is a pressing need to focus on the quantity and quality of data, with larger and more diverse datasets being crucial for enhancing model performance (Roggia et al., 2024). Building trust in models. Trust is established through a combination of technical reliability, transparency, and alignment with user expectations. The factors that foster trust in models predominantly center on selecting the appropriate neural network architecture and molecular representations, alongside the advancement of innovative architectures imbued with inductive bias. For instance, recurrent neural networks (RNNs) are well-suited for sequential data due to their ability to maintain a form of memory. However, the choice extends beyond RNNs to include other architectures like convolutional neural networks (CNNs), which are effective for image data, and graph neural networks (GNNs), which are particularly adept at handling graph-structured data like molecules. As for molecular representations, except for SMILES strings, graph representations could capture the molecular structure more directly, including both topological and geometrical information, which is essential for tasks like drug discovery and material science. Moreover, innovative architectures with inductive bias (e.g., the 3D-CNN architecture (Skalic et al., 2019)) should be further developed to better address the nuances of specialized tasks. For example, geodesic 3D convolutional neural networks (gCNNs) use geodesic convolutions that consider the intrinsic geometry of the data, which is particularly useful in medical applications where the curvature and shape of organs, bones, and tissues are critical. These architectures can lead to improved model accuracy and computational efficiency by focusing on the most important information in the data (Pandey et al., 2022). Data safety and privacy. The safeguarding of personal information in terms of security, privacy, and confidentiality is non-negotiable, especially in the context of research, standards development, and commercial applications (Jayatunga et al., 2022). Computational complexity (time complexity, space complexity and scalability). The challenges posed by the computational demands and intricacies of contemporary deep learning methods are expected to remain a significant factor in the near term. For example, to address the scalability challenge, many AI applications leverage distributed computing and parallel processing techniques. Reducing the computational complexity of deep learning models can be achieved through network compression and acceleration techniques. Moreover, quantum computing offers a potential solution to overcoming computational limitations in AI. Quantum algorithms for machine learning, such as Grover’s algorithm, can potentially reduce the complexity of certain tasks, making previously intractable problems solvable. Additionally, quantum neural networks leveraging qubits could operate with higher efficiency and improved processing speed.

With unwavering conviction, we are stand atop the pinnacle of research, an epoch where AI, and especially LLMs, are set to transcend mere advancement and emerge as vital pillars of contemporary pharmaceutical innovation. It is imperative to accentuate the sophisticated and proficient application of AI throughout the biotechnological pharmaceutical development continuum, demonstrating its unparalleled ability to catalyze scientific breakthroughs and augment the efficacy of drug discovery endeavors.

## Section: Funding Statement

The author(s) declare that financial support was received for the research, authorship, and/or publication of this article. The authors express their gratitude to the Traditional Chinese Medicine Science and Technology Project of Shandong Province (M-2023080), the Shandong Provincial University Youth Innovation Team, China (No. 2022KJ102), the National Natural Science Foundation of China (No. 32000194), and the Research Fund for Academician Lin He New Medicine (JYHL2021MS23).

## Section: Author contributions

X-hL: Data curation, Formal Analysis, Writing–original draft. Z-hL: Methodology, Resources, Software, Writing–original draft. TW: Funding acquisition, Project administration, Supervision, Validation, Writing–review and editing. FL: Funding acquisition, Project administration, Supervision, Writing–review and editing.

## Section: Conflict of interest

The authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.

## Section: Publisher’s note

All claims expressed in this article are solely those of the authors and do not necessarily represent those of their affiliated organizations, or those of the publisher, the editors and the reviewers. Any product that may be evaluated in this article, or claim that may be made by its manufacturer, is not guaranteed or endorsed by the publisher.


---

# Lost in the Middle: How Language Models Use Long Contexts

- **Authors:** Nelson F. Liu, Kevin Lin, John Hewitt, Ashwin Paranjape, Michele Bevilacqua, Fabio Petroni, Percy Liang
- **Issuer:** Transactions of the Association for Computational Linguistics
- **Type:** Scientific article
- **Published:** 2024-01-01
- **DOI:** 10.1162/tacl_a_00638
- **Source:** https://doi.org/10.1162/tacl_a_00638
- **Licence:** CC-BY

## Section: Abstract

Abstract While recent language models have the ability to take long contexts as input, relatively little is known about how well they use longer context. We analyze the performance of language models on two tasks that require identifying relevant information in their input contexts: multi-document question answering and key-value retrieval. We find that performance can degrade significantly when changing the position of relevant information, indicating that current language models do not robustly make use of information in long input contexts. In particular, we observe that performance is often highest when relevant information occurs at the beginning or end of the input context, and significantly degrades when models must access relevant information in the middle of long contexts, even for explicitly long-context models. Our analysis provides a better understanding of how language models use their input context and provides new evaluation protocols for future long-context language models.


---

# Machine Learning Assisted Hit Prioritization for High Throughput Screening in Drug Discovery

- **Authors:** Davide Boldini, Lukas Friedrich, Daniel Kuhn, Stephan A Sieber
- **Issuer:** ACS central science
- **Type:** Scientific article
- **Published:** 2024-03-15
- **Language:** en
- **DOI:** 10.1021/acscentsci.3c01517
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38680560/
- **Licence:** CC-BY

## Section: Abstract

AbstractEfficient prioritization of bioactive compounds from high throughput screening campaigns is a fundamental challenge for accelerating drug development efforts. In this study, we present the first data-driven approach to simultaneously detect assay interferents and prioritize true bioactive compounds. By analyzing the learning dynamics during training of a gradient boosting model on noisy high throughput screening data using a novel formulation of sample influence, we are able to distinguish between compounds exhibiting the desired biological response and those producing assay artifacts. Therefore, our method enables false positive and true positive detection without relying on prior screens or assay interference mechanisms, making it applicable to any high throughput screening campaign. We demonstrate that our approach consistently excludes assay interferents with different mechanisms and prioritizes biologically relevant compounds more efficiently than all tested baselines, including a retrospective case study simulating its use in a real drug discovery campaign. Finally, our tool is extremely computationally efficient, requiring less than 30 s per assay on low-resource hardware. As such, our findings show that our method is an ideal addition to existing false positive detection tools and can be used to guide further pharmacological optimization after high throughput screening campaigns.

## Section: Introduction

High throughput screening (HTS) has significantly accelerated drug discovery efforts by allowing researchers to test large chemical libraries for bioactivity in a time and cost efficient manner, thus providing a crucial starting point for synthesizing small molecules with suitable pharmacological properties.1−4

However, one fundamental issue with HTS is its tendency to provide false positive readouts, either because the experimental response for a given hit compound is not reproducible or because it is not correlated with the intended biological activity.5−9 The underlying causes for the false positive readout can be extremely heterogeneous, including colloidal aggregation,10 autofluorescence,11 interference with assay technology,5,8 chemical reactivity,12 metal impurities,13 and measurement uncertainty.14

For these reasons, choosing which active compounds to prioritize for further pharmacological development after an HTS campaign still relies on further experimental profiling,15−17 thus increasing the time and resources necessary to identify true hits and subsequently deliver a drug to the market.

This issue has garnered significant attention in the cheminformatics community, leading to the development of several in-silico tools for false positive detection in HTS data.6,7,18−22 These methods are generally based on expert rule based approaches, for example Pan-Assay Interferent (PAINS) substructure filters,5,8 or machine learning models trained on historical HTS data.7,18,19 However, there are two main limitations to the use of these tools. First, they generally make assumptions concerning the assay interference mechanism, limiting their applicability to a narrow selection of false positives.6,18 Furthermore, this aspect also limits their trustworthiness in identifying true positives since they can only prioritize compounds that are unlikely to be interferents according to that specific mechanism. For example, given an autofluorescence predictor for HTS interferent detection, even if it classifies a compound as nonfluorescent, that molecule might still be a false positive due to other phenomena, e.g., statistical fluctuations or colloidal aggregation. Second, these approaches depend on the chemical, biological, and technological space evaluated to generate them.5,7 As such, their performance might be unreliable when evaluating compounds outside of the applicability domain of the model or when applied to HTS campaigns targeting unseen protein families, relying on new assay technologies and so forth.7

To speed up HTS hit triaging, we propose herein minimal variance sampling analysis (MVS-A), the first machine learning approach to simultaneously identify false positive compounds and prioritize true biologically active molecules in HTS data. Our approach is inspired by recent findings in gradient-based data valuation,23−25 which showcase how tracing sample gradients during the training process can highlight mislabeled data in computer vision and natural language processing applications.23,26 To make gradient-based data valuation more applicable out-of-the-box and reduce computational complexity, MVS-A is based on a novel formulation of sample influence for gradient boosting, thus enabling processing of large HTS data sets (e.g., above 300.000 compounds) in mere seconds. Because of this, MVS-A operates in an orthogonal fashion to prior false positive detection tools for HTS data: instead of requiring a preexisting library of assay interferents, it only requires training on the HTS itself, avoiding out-of-domain (OOD) applicability issues altogether. Additionally, since it does not make any assumptions about the interference mechanism, it can be used to successfully prioritize true positives.

To evaluate our approach, we curated a selection of 17 publicly available HTS data sets and 3 industrial ones with different sizes, class imbalance, biological targets, assay technology, and false positive rates. Our results show that MVS-A can outperform a variety of rule-based and data-driven baselines both at true positive and false positive identification.

## Section: Results and Discussion

Illustration of our proposed approach. After an HTS campaign is carried out, the most active compounds in the primary screen are usually prioritized for further testing. However, this strategy often does not distinguish well between true positives (TP) and false positives (FP), leading to high false positive rates in the confirmatory screens. In our approach, we first fit a Gradient Boosting Machine classifier on the primary HTS screen data and compute MVS-A scores for each active compound. Problematic compounds according to the classifier will have high MVS-A scores and are likely false positives and vice versa for true hits. Selecting compounds according to their MVS-A score leads to reduced false positive rates in subsequent confirmatory screens and enables the identification of false positives in the primary HTS screen.

False positive detection performance across all data sets. Asterisks denote significance according to one-tailed Wilcoxon Signed Rank tests with Bonferroni correct (one asterisk corresponds to α = 0.05, two asterisks to α = 0.01). P-values are reported in Table S5. (a) Distribution of relative precision scores across all data sets. The dotted gray line denotes random performance. (b) Distribution of enrichment factor scores across all data sets. (c) Distribution of BEDROC scores across all data sets.

True positive detection performance across all data sets. Asterisks denote significance according to one-tailed Wilcoxon Signed Rank tests with Bonferroni correct (one asterisk corresponds to α = 0.05, two asterisks to α = 0.01). P-values are reported in Table S6. (a) Distribution of relative precision scores across all data sets. The dotted gray line denotes random performance. (b) Distribution of enrichment factor scores across all data sets. (c) Distribution of BEDROC scores across all data sets.

Structural diversity distribution analysis. White diamonds indicate the median of the distribution. (a) Distribution of the scaffold diversity scores across all data sets for false positive detection. (b) Distribution of the scaffold diversity scores across all data sets for true positive detection.

(a) Structures of the most relevant true positive compounds from the choline transporter inhibitor screening campaign. (b) Rank percentiles for the lead compounds according to MVS-A and the experimental readout from the primary HTS. (c) Compound ranking for the primary hits according to MVS-A. (d) Compound ranking according to the experimental readout for the primary hits.

## Section: Results and Discussion › Using MVS-A to Prioritize Hits from HTS Campaigns

In recent years, analyzing sample gradient dynamics during supervised neural network training has attracted significant interest for modeling noisy data sets.23−28 These methods enable quantification of the influence of each sample on the neural network weights once the model has been trained. When training on noisy data, such as HTS campaigns, it has been shown that sample influence correlates with the likelihood of being mislabeled, thus enabling the identification of both trustworthy and problematic samples. However, neural network based approaches are computationally expensive and sensitive to hyperparameters, especially for large, imbalanced molecular data sets such as HTS data,29,30 making their use for nonexperts particularly challenging.

To tackle these limitations, we have developed minimum variance sampling analysis (MVS-A) to estimate sample influence in gradient boosting machines (GBM). GBM is a machine learning algorithm that fits an ensemble of decision trees in a sequence, each compensating for the mistakes of the previous tree. The advantages of using GBM instead of neural networks for computing sample influence are faster computation of importance scores, robust out-of-the-box performance, and classification performance on imbalanced HTS data, thus providing a good inductive bias for detecting false positive compounds.31,32 In practice, the way MVS-A works is by quantifying how “unusual” a certain active compound is according to the GBM model when comparing it to the boundary it has learned to separate active and inactive molecules. If a compound is labeled as active in the training set, but the pattern learned by the GBM model contradicts that, it will have a high MVS-A score. Vice versa, if a bioactive molecule is easily identified as such by the classifier, it will have a low MVS-A score. These scores can be used accordingly to prioritize compounds for further testing, or a threshold can be set to label true positives and false positives depending on the hit validation budget. In this study, we consider for all data sets the bottom 10% of the hits as true positives and the top 10% as false positives, as done in another ranking evaluation study.33

As such, our proposed approach for ranking HTS hits goes as follows (Figure 1):

Thanks to its computational efficiency, this pipeline takes only a few seconds on low-end hardware, even for large HTS data sets. Crucially, our approach relies exclusively on the HTS data set of interest. As such, it does not rely on historical information on which compounds tend to be false positives for that assay technology (like, e.g., PAINS), nor on assumptions of which biophysical process is causing the interference (e.g., aggregation or autofluorescence predictors). This means that our method is inherently applicable to any assay technology and any region of the chemical space while being able to detect any type of interferent.

Finally, we provide a more in-depth discussion of the theory behind MVS-A in chapter 1 of the Supporting Information.

Illustration of our proposed approach. After an HTS campaign is carried out, the most active compounds in the primary screen are usually prioritized for further testing. However, this strategy often does not distinguish well between true positives (TP) and false positives (FP), leading to high false positive rates in the confirmatory screens. In our approach, we first fit a Gradient Boosting Machine classifier on the primary HTS screen data and compute MVS-A scores for each active compound. Problematic compounds according to the classifier will have high MVS-A scores and are likely false positives and vice versa for true hits. Selecting compounds according to their MVS-A score leads to reduced false positive rates in subsequent confirmatory screens and enables the identification of false positives in the primary HTS screen.

## Section: Results and Discussion › Constructing a Benchmark for HTS Hit Prioritization

To evaluate our proposed approach, we curated a selection of 17 data sets from publicly available HTS data,34,35 for a total of 471370 unique compounds measured against 10 different protein families, using a variety of readout measurements and activity thresholds (Table 1, Table S1, Table S2, Table S3, and Table S4). We focused on HTS data sets where more than 200 hits were investigated both in primary and confirmatory screens, excluding campaigns where the false positive rate was above 95% or below 5%. Where possible, we prioritized the selection of assays targeting different protein families and confirmatory screen protocols.

As a result of this selection process, the false positive rates in our benchmark range from 11% to 91%, and the screened libraries evaluate different regions of the chemical space (Figure S1), thus covering a broad spectrum of HTS campaigns.

Each data set is generated from a primary screen, relying on single-dose measurements, and a confirmatory screen, which either adds replicates or assesses the dose–response activity against the same biological target. To define which molecules are considered bioactive in a given primary or confirmatory screen, we employed the original activity thresholds defined by the authors of the screening campaign. This ensures that our analysis accurately reflects real drug discovery campaigns as close as possible, where bioactivity criteria vary on a case-by-case basis, depending on the biological target and the purpose of the drug.

We define a compound as false positive if it was reported to be active in the primary screen but was found to be inactive or inconclusive in the confirmatory screen. Depending on the protocol employed for the confirmatory screen, different false positive types can be identified. When adding replicates, only errors associated with readout fluctuations or systematic errors (e.g., dust in the well plate) can be identified, while dose–response measurements enable detection of autofluorescence, colloidal aggregation, assay technology interference, and so forth.

## Section: Results and Discussion › Defining a Protocol to Assess HTS Hit Prioritization Strategies

For a given HTS data set, we run the MVS-A pipeline exclusively on the primary screening data. Then, we measure how effective our approach is at separating true actives and false positives by comparing its compound ranking to the confirmatory screening data. To evaluate the sorting performance, we measure top-K Precision, Enrichment Factor, and Boltzmann-Enhanced Discrimination of Receiver Operating Characteristic (BEDROC).33 Since Precision is sensitive to the amount of noise in the data set, we scale it with respect to the false positive and true positive rate for each data set, making this metric more consistent across data sets. Therefore, a relative top-K precision score of 0.0 indicates that a given ranking is equal to random sorting, while values above 0.0 denote percent improvements over assay noise. We further discuss our metric selection in chapter 4 of the Supporting Information.

To contextualize the performance of MVS-A, we provide the following baselines:

Additionally, to compare our approach with publicly available HTS interference predictors, we add the following baselines for false positive identification:

## Section: Results and Discussion › MVS-A Achieves Best Performance in HTS False Positive Detection

In terms of false positive detection, MVS-A matches or outperforms, on average, all alternative methods across all metrics (Figure 2). The performance of our approach is mostly consistent across different metrics, meaning that MVS-A provides the best performance both when considering the top 10% predictions, as indicated by relative precision and enrichment factor, and when evaluating the entire ranking, as measured by BEDROC. Crucially, MVS-A outperforms all baselines across all metrics and data sets on 12 out of 17 data sets, while achieving second best performance on the remaining 5, making it an ideal option for out-of-the-box scenarios.

CatBoost object importance is the most competitive alternative; however, MVS-A still outperforms it on 16 out of 17 data sets across all metrics. Compared to this baseline, MVS-A provides an improvement of 29%, 6%, and 10% for relative precision, enrichment factor, and BEDROC respectively. Considering the differences in sample importance formulation between these methods, this result supports our method’s assumption that focusing on the splitting decisions provides a better inductive bias for discovering mislabeled data.

Both anomaly detection methods, namely, Isolation Forest and VAE, struggle on this benchmark. Specifically, MVS-A outperforms them across all metrics on 16/17 and 15/17 data sets, respectively. Concerning VAE, this is likely due to the fact that these algorithms require large data sets (e.g., 106 compounds) to be trained properly,44 while the number of hits per HTS is much lower. Regarding Isolation Forest, its performance is likely affected by the high dimensionality of the input molecular representations, rendering the use of random splits less effective.39 In contrast, data valuation approaches like MVS-A object importance select the subset of informative features by first fitting a supervised classifier to distinguish active and inactive compounds, thus mitigating the issue of high dimensionality.

In comparison to GSK and REOS structural filters, MVS-A outperforms them on 16/17 data sets across all metrics. However, these alerts do not only detect false positives, but also focus on chemical moieties associated with target promiscuity or other undesirable pharmacological properties.36,47,48 This mismatch then could explain the poor performance observed in identifying false positives in this benchmark.

Finally, Hit Dexter, SCAM Detective, and the autofluorescence predictor show subpar false positive detection performance when compared to MVS-A, with our approach outperforming them across all metrics on 16/17, 17/17, and 15/17 data sets, respectively. This is likely because these approaches, unlike MVS-A, focus on specific interference mechanisms, while our benchmark makes no assumptions about the false positive origin. Furthermore, the performance of these baselines is likely degraded by applicability domain issues, while MVS-A is tailored to each specific screening campaign.

False positive detection performance across all data sets. Asterisks denote significance according to one-tailed Wilcoxon Signed Rank tests with Bonferroni correct (one asterisk corresponds to α = 0.05, two asterisks to α = 0.01). P-values are reported in Table S5. (a) Distribution of relative precision scores across all data sets. The dotted gray line denotes random performance. (b) Distribution of enrichment factor scores across all data sets. (c) Distribution of BEDROC scores across all data sets.

## Section: Results and Discussion › MVS-A Provides the Most Efficient HTS True Hit Prioritization Strategy

In line with the false positive retrieval benchmark, MVS-A on average matches or outperforms all other approaches across all metrics in terms of true hit detection (Figure 3) Specifically, it achieves the best performance in 13 data sets out of 17 across all metrics, and it ranks second best in the remaining 4 data sets, further highlighting its potential as an optimal out-of-the-box solution.

On average, the most competitive baseline is again CatBoost object importance; however, MVS-A still outperforms it on 16/17 data sets. This further highlights that MVS-A is more effective at assessing sample influence than the previous state-of-the-art GBM algorithms since it detects high fidelity data more efficiently.

As for the false positive detection benchmark, anomaly detection methods provide subpar performance for true positive identification, with VAE showing slightly better performance than Isolation Forest. This is likely a consequence of the low data available for training the VAE and the high dimensionality of the input in the case of the Isolation Forest.

Finally, in comparison to the primary readout ranking, MVS-A outperforms it on 15 data sets, with average improvements of 50%, 13%, and 14% in terms of relative precision, enrichment factor, and BEDROC. This is especially impressive considering that ranking compounds according to their primary HTS readout is the industry standard for hit triaging in HTS campaigns. The relatively low performance of this method could be due to the fact that assay interferents can be outliers in terms of primary readout, for example, by exhibiting very strong autofluorescence, causing them to be at the top of the primary readout ranking. As such, this benchmark shows that our data-driven approach is more efficient at finding true actives than the currently used criteria for HTS hit triaging

True positive detection performance across all data sets. Asterisks denote significance according to one-tailed Wilcoxon Signed Rank tests with Bonferroni correct (one asterisk corresponds to α = 0.05, two asterisks to α = 0.01). P-values are reported in Table S6. (a) Distribution of relative precision scores across all data sets. The dotted gray line denotes random performance. (b) Distribution of enrichment factor scores across all data sets. (c) Distribution of BEDROC scores across all data sets.

## Section: Results and Discussion › MVS-A Identifies Structurally Diverse Interferents

While being able to correctly prioritize true positives and exclude false positives is a fundamental requirement for an HTS hit triaging strategy, retrieving a diverse set of compounds is also crucial. To assess this, we investigated the ability of our approach to identify heterogeneous true actives and assay interferents by measuring the fraction of unique Murcko scaffolds among the hits for both categories in each data set.

In terms of false positive variety, MVS-A selects the most diverse selection of interferents, peaking at around 95% scaffold diversity, closely followed by Hit Dexter and CatBoost object importance (Figure 4a). In general, data valuation algorithms such as MVS-A naturally tend to identify more varied interferents since they do not rely on the presence of specific molecular motifs in the false positives but rather highlight any active that deviates from the pattern they learned while training on the primary screening data. This more flexible definition of what constitutes a false positive then leads to the identification of more structurally different interferents, outperforming even anomaly detection algorithms. On the contrary, structural filters and assumption-based predictors are inherently biased toward specific chemical scaffolds, thus flagging more homogeneous compounds. One exception to this seems to be frequent hitters, which likely encompass several different interference mechanisms in their definition and, as such, have more diverse chemical structures.

This trend is inverted for true positive discovery, where both data valuation approaches tend to yield less diverse selections of true hits, centered around 60% scaffold diversity (Figure 4b). In this case, the true positives identified by MVS-A and CatBoost are the ones that fit well the learned class boundary between actives and inactives in the primary data. The boundary in this case tends to include only a limited region of the chemical space, leading to more structurally similar true actives. In contrast, primary readout ranking has no chemical bias in its selection criteria, thus retrieving the most diverse true positives. Finally, the scaffold diversity rate distribution across all data sets for the anomaly detection baselines is comparable with the one observed to randomly picking hits from each HTS (Table S4). This is because the true positives identified by these methods correspond to distribution inliers, thus approximating the distribution of chemical motifs present in the training data.

Structural diversity distribution analysis. White diamonds indicate the median of the distribution. (a) Distribution of the scaffold diversity scores across all data sets for false positive detection. (b) Distribution of the scaffold diversity scores across all data sets for true positive detection.

## Section: Results and Discussion › MVS-A Identifies False Positives Belonging to Different Interferent Classes

By design, MVS-A makes no assumption concerning the interference mechanism of the false positive compounds in the primary screen; therefore, it should cover all types of interferents. To test this assumption, we measure across all data sets the fraction of compounds predicted to be false positives by our method that were also identified by the other assumption-based predictors (Figure S2).

MVS-A shows the highest overlap across all data sets with the autofluorescence predictor, with a median of 66%. This however is likely due to the nonselectivity of the autofluorescence predictor, which tends to flag the majority of compounds as fluorescent across all data sets (Table S7). These overconfident predictions could be due to applicability domain issues given that the training set used for this model originated from assays related to toxicological screening. Compared to the remaining in-silico predictors, MVS-A shows a median overlap of 51% with the colloidal aggregators identified by SCAM Detective, 33% with the structural filters from GSK and REOS and 8% with the frequent hitters detected by Hit Dexter.

Taken together, these results confirm the hypothesis that MVS-A can identify different classes of false positives while showing complementary performance with tools covering also compound promiscuity, such as frequent hitter predictors and general nuisance compound structural alerts.

## Section: Results and Discussion › Case Study I: Choline Transporter Inhibitor Screen from Vanderbilt University

To assess how well MVS-A would perform in a real drug discovery campaign, we investigated whether the true actives identified by our method are biased toward chemical moieties that would make them unsuitable for further pharmacological optimization. To do so, we re-evaluated the data set with the codename “transporter” from the publicly available HTS assays evaluated in this work. This assay was conducted in order to identify novel inhibitors for the presynaptic choline transporter (CHT), a potential therapeutic target for Alzheimer’s disease and schizophrenia.49 We chose this data set from our collection as a case study because the hits from its primary HTS screen were extensively validated by additional counterscreens and confirmatory assays (PubChem AID 488997). The goal of these experimental validation efforts was to identify potent selective CHT inhibitors eliciting the desired phenotypic response from primary HTS hits.

After 11 rounds of screening, only six compounds that were present in the primary HTS made it to the end of the pipeline, one of which, CHT4, was a false negative (Figure 5a). Crucially, all five true positives were immediately flagged as more promising than most other hits from the HTS campaign by MVS-A (Figure 5b), ranking within the top 20 primary HTS according to our method. Notably, among these five compounds there was also ML352, the best inhibitor from the screening campaign, which also showed suitable ADME properties.49 In contrast, ranking by experimental readout from the primary screen is far less efficient, with ML352, CHT5, and CHT3 ranking between 150th and 500th, CHT1 around 750th, and CHT2 around 2300th (Figure 5b,d).

We then used MVS-A to rank primary inactive compounds in terms of false negative likelihood by sorting inactive compounds in terms of importance to the underlying GBM classifier according to our method. Crucially, our approach correctly identified CHT4 as the most likely false negative compound out of all primary inactives (Figure 5b). This finding is especially relevant, since mining dark chemical matter in HTS data is a promising but largely unexplored starting point for drug discovery,50 given the lack of in-silico approaches to determine which samples to reinvestigate.

To summarize, in this case study MVS-A was able to identify the 6 most biologically relevant compounds just by observing the primary HTS data, including a false negative, while prioritizing molecules according to their experimental readout in the primary screen was a less efficient selection strategy. Additionally, this finding shows that MVS-A is not biased toward undesirable chemical moieties in terms of further pharmacological development.

(a) Structures of the most relevant true positive compounds from the choline transporter inhibitor screening campaign. (b) Rank percentiles for the lead compounds according to MVS-A and the experimental readout from the primary HTS. (c) Compound ranking for the primary hits according to MVS-A. (d) Compound ranking according to the experimental readout for the primary hits.

## Section: Results and Discussion › Case Study II: Industrial HTS Campaigns from Merck KGaA

To further evaluate the applicability of MVS-A on real scenarios, we investigated three currently ongoing HTS campaigns from Merck KGaA, aimed at different biological targets (Table S8). Each of these data sets is larger than the largest publicly available data set we included in our study so far, thus providing a realistic benchmark for how our method would fare in industrial applications. Due to computational limitations, we could only test MVS-A, CatBoost and primary readout ranking on these data sets.

In terms of false positive detection, on average, MVS-A outperforms all baselines across all metrics (Table S9). Regarding true positive detection, on average, CatBoost and MVS-A achieve similar performance, while primary readout ranking outperforms all alternatives in terms of precision and BEDROC (Table S10). In general, primary readout ranking performs much better as a baseline in these data sets, likely due to less assay noise compared to publicly available data, making the initial HTS screen more predictive of a compound’s performance in further validation screens.

## Section: Results and Discussion › Limitations and Practical Guidelines for the Use of MVS-A

While MVS-A achieved excellent performance in terms of false positive and true positive detection, it still requires careful deployment for real use cases.

First, the performance of MVS-A can fluctuate from data set to data set, and it can be difficult to forecast how effective it will be for a given HTS data set. While we investigated the relationship between its performance and the HTS of interest, such as the protein target family, structural diversity of the data set (Figure S3), and the cross-validation performance of the GBM classifier (Figure S4), we could not detect meaningful correlation between these factors. As such, although MVS-A never performs worse than random picking in our benchmarks, the bias toward specific scaffolds in terms of true positive prioritization can be problematic if it is not associated with an improved true hit rate. This issue can be tackled, however, by hybrid hit selection strategies aimed at selecting diverse chemical scaffolds according to the MVS-A true hit likelihood.

Another factor that can influence the performance is the choice of molecular representation for the analysis. However, we observed only a 3% performance variation when using different molecular fingerprints and molecular descriptors (Figure S5), consistently with the results observed for molecular property prediction tasks.

In terms of computational cost, unlike other false positive predictors, MVS-A requires to be retrained for each new HTS data set. However, our testing shows that the algorithm is extremely efficient and lightweight, taking less than 5 s per data set on a server with an AMD Ryzen Threadripper 3970X 32-Core Processor and less than 30 s on a laptop with an AMD Ryzen 5 3600 6-Core Processor (Figure S6).

Finally, while MVS-A accurately distinguishes between interferents and true positives, it does not account for other relevant factors for hit prioritization such as promiscuity. As such, the ideal application of our approach is not as a stand-alone tool, but in conjunction with other in-silico tools, e.g., structural alerts or frequent hitter predictors, to get a global view of the pharmacological potential of each primary HTS hit. To highlight this, we revisited the top 20 ranked compounds from the CHT inhibitor screening campaign according to MVS-A, as discussed in Case Study I, focusing on the 15 compounds our approach incorrectly selected as the true hit. Six of those could be removed according to REOS and GSK filters, one according to Hit Dexter and one according to InterPred, while SCAM Detective flagged most compounds as potential colloidal aggregators (Table S10). As such, the synergistic combination of these approaches could have brought the true positive rate from 25% when using MVS-A on its own to 38%.

## Section: Conclusions

High throughput screening holds a key role in current drug discovery research, but its impact is limited by the presence of many false positive compounds, making further pharmacological development of bioactive compounds slower and more expensive. In this study, we introduced minimal variance sampling analysis, a novel approach inspired by data valuation methods to simultaneously prioritize true positive compounds and detect assay interferents in HTS data.

To test our proposed method, we have constructed a new benchmark consisting of 17 primary-confirmatory HTS data set pairs, encompassing a variety of biological targets, assay technologies, number of compounds, and false positive rates.

MVS-A consistently matches or outperforms the other baselines in terms of both false positive and true positive detection. Crucially, it provides average improvements up to 50%, 13%, and 14% in terms of relative precision, enrichment factor, and BEDROC against primary readout sorting, a popular heuristic used in the pharmaceutical industry for HTS hit prioritization. Concerning false positive discovery, our method can identify a wide range of structurally diverse interferents with low overlap with the predictions of prior in-silico tools focusing on compound promiscuity, making our method an excellent addition to HTS false positive detection pipelines.

Regarding hit prioritization, MVS-A was able to identify the most biologically relevant hits from a primary HTS campaign in a retrospective case study on publicly available data. Interestingly, one of the hits correctly detected by MVS-A was a false positive, highlighting the potential of our approach to detect promising compounds from dark chemical matter.

On the three data sets provided by Merck KGaA, MVS-A performs competitively in terms of false positive detection and false positive retrieval, indicating that our approach is also reliable in the chemical space typically explored in industrial screening campaigns.

Finally, our method is extremely computationally efficient, allowing processing of HTS data on a laptop in under 30 s with minimal RAM usage. In light of these results, we are confident MVS-A will help accelerate HTS hit triaging and will stimulate further research into data valuation approaches for handling large chemical data sets. We provide this tool as an open source package at https://github.com/dahvida/AIC_Finder.

## Section: Acknowledgments

The authors thank Merck KGaA Darmstadt for their generous support with the Merck Future Insight Prize 2020. This project was also cofunded by the European Union (ERC, breakingBAC, 101096911). D.B. thanks Maximilian Schuh and Joshua Hesse for their help revising the draft and creating the pictures.

## Section: Data Availability Statement

All PubChem assays investigated in this study can be accessed from PubChem according to their AID, as shown in Table 1. The Python environment, data sets, performance of each method across all metrics, data sets and replicates, and code required to reproduce the results are available at the following GitHub repository: https://github.com/dahvida/AIC_Finder.

## Section: Supporting Information Available

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acscentsci.3c01517.

## Section: Author Contributions

Conceptualization: D.B. Benchmarking: D.B. Software: D.B. Methodology: D.B. and L.F. Analysis of the results: all authors. Writing original draft: D.B. Writing review and editing: all authors. All authors have given approval to the final version of the manuscript.

## Section: Text

Views and opinions expressed are those of the author(s) only and do not necessarily reflect those of the European Union or the European Research Council. Neither the European Union nor the granting authority can be held responsible for them.

## Section: Text

The authors declare no competing financial interest.

## Section: Supplementary Material

oc3c01517_si_001.pdf

## Section: Associated Data

oc3c01517_si_001.pdf

## Section: Associated Data › Supplementary Materials

oc3c01517_si_001.pdf

## Section: Associated Data › Data Availability Statement

All PubChem assays investigated in this study can be accessed from PubChem according to their AID, as shown in Table 1. The Python environment, data sets, performance of each method across all metrics, data sets and replicates, and code required to reproduce the results are available at the following GitHub repository: https://github.com/dahvida/AIC_Finder.


---

# Machine learning-based identification and immune characterization of ferroptosis-related molecular clusters in osteoarthritis and validation

- **Authors:** Xiaocheng Guo, Xinyuan Feng, Yue Yang, Wenying An, Lunhao Bai
- **Issuer:** Aging
- **Type:** Scientific article
- **Published:** 2024-05-29
- **Language:** en
- **DOI:** 10.18632/aging.205875
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38814177/
- **Licence:** CC-BY

## Section: Abstract

Osteoarthritis (OA), a degenerative joint disease, involves synovial inflammation, subchondral bone erosion, and cartilage degeneration. Ferroptosis, a regulated non-apoptotic programmed cell death, is associated with various diseases. This study investigates ferroptosis-related molecular subtypes in OA to comprehend underlying mechanisms. The Gene Expression Omnibus datasets GSE206848, GSE55457, GSE55235, GSE77298 and GSE82107 were used utilized. Unsupervised clustering identified the ferroptosis-related gene (FRG) subtypes, and their immune characteristics were assessed. FRG signatures were derived using LASSO and SVM-RFE algorithms, forming models to evaluate OA's ferroptosis-related immune features. Three FRG clusters were found to be immunologically heterogeneous, with cluster 1 displaying robust immune response. Models identified nine key signature genes via algorithms, demonstrating strong diagnostic and prognostic performance. Finally, qRT-PCR and Western blot validated these genes, offering consistent results. In addition, some of these genes may have implications as new therapeutic targets and can be used to guide clinical applications.


---

# Machine learning driven bioequivalence risk assessment at an early stage of generic drug development

- **Authors:** Dejan Krajcar, Dejan Velušček, Iztok Grabnar
- **Issuer:** European journal of pharmaceutics and biopharmaceutics : official journal of Arbeitsgemeinschaft fur Pharmazeutische Verfahrenstechnik e.V
- **Type:** Scientific article
- **Published:** 2024-10-26
- **Language:** en
- **DOI:** 10.1016/j.ejpb.2024.114553
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39490606/
- **Licence:** CC-BY

## Section: Abstract

Bioequivalence risk assessment as an extension of quality risk management lacks examples of quantitative approaches to risk assessment at an early stage of generic drug development. The aim of our study was to develop a model-based approach for bioequivalence risk assessment that uses pharmacokinetic and physicochemical characteristics of drugs as predictors and would standardize the first step of risk assessment. The Sandoz in-house bioequivalence database of 128 bioequivalence studies with poorly soluble drugs (23.5% non-bioequivalent) was used to train and validate the model. Four different modeling approaches, random forest, XGBoost, logistic regression and naïve Bayes, were compared. Among the best performing machine learning models, random forest was selected and optimized for the number of features, resulting in an accuracy of 84% on the test data set. The most important features for prediction were those related to solubility (dose number, acid dissociation constant), absorption and elimination rate, effective permeability, variability of pharmacokinetic endpoints, and absolute bioavailability. All features had a conceivable influence on the model predictions. The model was used to develop a bioequivalence risk assessment approach to categorize drugs in early development into high, medium or low risk classes.


---

# Machine Learning Empowering Drug Discovery: Applications, Opportunities and Challenges

- **Authors:** Xin Qi, Yuanchun Zhao, Zhuang Qi, Siyu Hou, Jiajia Chen
- **Issuer:** Molecules (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2024-02-18
- **Language:** en
- **DOI:** 10.3390/molecules29040903
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38398653/
- **Licence:** CC-BY

## Page 1 (Section: Introduction )

Citation: Qi, X.; Zhao, Y.; Qi, Z.; Hou,
S.; Chen, J. Machine Learning
Empowering Drug Discovery:
Applications, Opportunities and
Challenges. Molecules 2024, 29, 903.
https://doi.org/10.3390/
molecules29040903
Academic Editor: Shijun Zhong
Received: 15 January 2024
Revised: 8 February 2024
Accepted: 14 February 2024
Published: 18 February 2024
Copyright:
© 2024 by the authors.
Licensee MDPI, Basel, Switzerland.
This article is an open access article
distributed
under
the
terms
and
conditions of the Creative Commons
Attribution (CC BY) license (https://
creativecommons.org/licenses/by/
4.0/).
molecules
Review
Machine Learning Empowering Drug Discovery: Applications,
Opportunities and Challenges
Xin Qi 1,*,†, Yuanchun Zhao 1,†, Zhuang Qi 2, Siyu Hou 1 and Jiajia Chen 1
1
School of Chemistry and Life Sciences, Suzhou University of Science and Technology, Suzhou 215011, China;
2111121006@post.usts.edu.cn (Y.Z.); 2211121003@post.usts.edu.cn (S.H.); njucjj@126.com (J.C.)
2
School of Software, Shandong University, Jinan 250101, China; z_qi@mail.sdu.edu.cn
*
Correspondence: qixin@usts.edu.cn; Tel.: +86-0512-68418434
†
These authors contributed equally to this work.
Abstract: Drug discovery plays a critical role in advancing human health by developing new medica-
tions and treatments to combat diseases. How to accelerate the pace and reduce the costs of new drug
discovery has long been a key concern for the pharmaceutical industry. Fortunately, by leveraging
advanced algorithms, computational power and biological big data, artiﬁcial intelligence (AI) tech-
nology, especially machine learning (ML), holds the promise of making the hunt for new drugs more
efﬁcient. Recently, the Transformer-based models that have achieved revolutionary breakthroughs in
natural language processing have sparked a new era of their applications in drug discovery. Herein,
we introduce the latest applications of ML in drug discovery, highlight the potential of advanced
Transformer-based ML models, and discuss the future prospects and challenges in the ﬁeld.
Keywords: machine learning; drug discovery; transformer; opportunity; challenge
1. Introduction
Drug research and development play a vital role in improving human health and
well-being. However, the discovery of a new drug is an extremely complex, expensive and
time-consuming process, typically costing approximately USD 2.6 billion [1] and taking
more than 10 years on average [2]. Despite the high investment levels, the approval success
rate of launching a small-molecule drug to market from phase I clinical trial is less than
10% [3], highlighting the considerable risk of failure. Therefore, how to reduce the costs
and accelerate the pace of new drug discovery has emerged as a key concern within the
pharmaceutical industry.
The increasing availability of large-scale biomedical data provides tremendous op-
portunities for computational drug discovery, but effectively mining, correlating, and
analyzing these huge amounts of data has become a critical challenge. Fortunately, with
the advent of efﬁcient mathematical tools and abundant computational resources, artiﬁcial
intelligence (AI) approaches have rapidly developed (Figure 1). As the representative AI
method, machine learning (ML), empowers machines to learn from existing data by using
statistical approaches and make predictions, which can be further classiﬁed into supervised,
unsupervised, and reinforcement learnings [4,5]. Deep learning (DL), a subset of ML,
focuses on using multi-layered artiﬁcial neural networks (ANNs) structures to simulate
the neural networks of the human brain for learning data representations, making it more
powerful and ﬂexible in handling complex and high-dimensional data [6,7]. With the
advantages of low cost and fast speed, the ML approaches are revolutionizing and strength-
ening multiple stages of drug discovery, such as target identiﬁcation, de novo drug design
and drug repurposing. For example, DL-based open-source tools, such as DeepDTAF [8]
and DeepAfﬁnity [9], have been applied to predict the binding afﬁnity of drug–target
interactions (DTIs), making the hunt for new pharmaceuticals more efﬁcient. Accordingly,
more and more pharmaceutical giants, such as Sanoﬁ(Paris, France), Merck (Darmstadt,
Molecules 2024, 29, 903. https://doi.org/10.3390/molecules29040903
https://www.mdpi.com/journal/molecules

## Page 2 (Section: Introduction )

Molecules 2024, 29, 903
2 of 20
Germany), Takeda (Takeda, Japan) and Genentech (South San Francisco, America), have
initiated cooperation with AI companies to develop new drugs.
Figure 1. Introduction diagram of artiﬁcial intelligence and its subﬁelds: machine learning and
deep learning.
Notably, the Transformer-based language models, such as the Generative Pre-training
Transformer (GPT), Bidirectional Encoder Representations from Transformers (BERT) and
the Text-to-Text Transfer Transformer (T5), have not only achieved revolutionary break-
throughs but have also brought about a paradigm shift in the area of natural language
processing (NLP) [10]. In particular, the outstanding learning ability, generalization ability
and transferability of Transformer-based language models have sparked a new era of their
applications in drug discovery and development, primarily owing to the inherent similari-
ties between drug-related biological sequences and natural languages. Their remarkable
advantages, including capturing long-range dependencies in sequences, processing input
sequences in parallel, employing an attention mechanism, and having extendibility to incor-
porate multimodal information, make them valuable tools for various aspects of the drug
discovery process [11]. For example, by employing Transformer-based language models,
Kalakoti et al. [12] have successfully developed a modular framework called TransDTI for
predicting novel DTIs from sequence data. Its performance proved to be superior to existing
methods. Therefore, the Transformer-based models have the potential to revolutionize the
identiﬁcation and development of new drugs.
Given the signiﬁcance of ML techniques in the pharmaceutical industry, we here focus
on introducing the recent advancements, opportunities and challenges of ML applications

## Page 3 (Section: Applications of ML in Drug Discovery )

Molecules 2024, 29, 903
3 of 20
in drug discovery. First, we provide an updated overview of the emerging applications of
ML in different stages of the drug discovery process, including drug design, drug screening,
drug repurposing and chemical synthesis. Next, we highlight the opportunities of the
advanced Transformer-based models in empowering drug discovery. Furthermore, we
discuss the challenges and future prospects of ML in the ﬁeld of drug discovery.
2. Applications of ML in Drug Discovery
The process of discovering effective new drugs is time-consuming and predominantly
the most challenging part of drug development. With the advantages in learning from data,
discerning patterns, and making intelligent decisions, ML-based approaches have emerged
as versatile tools that can be applied in multiple stages of drug discovery, including drug
design, drug screening, drug repurposing and chemical synthesis (Figure 2). Moreover, con-
siderable efforts are dedicated to developing models, tools, software and databases based
on the core architecture of ML algorithms, to counter the inefﬁciencies and uncertainties
inherent in traditional drug development methods (Table 1).
Figure 2. Machine learning can be applied in multiple stages of the drug discovery process, mainly
including drug design, drug screening, drug repurposing and chemical synthesis.

## Page 4 (Section: Applications of ML in Drug Discovery )

Molecules 2024, 29, 903
4 of 20
Table 1. ML-based software/model used for drug discovery.
Name
Algorithm
Speciﬁc Function
PMID
Prediction of the target protein structure
TrRosetta server
DNN
Predict 3D structures of proteins
[13]
AlphaFold
DNN
Predict 3D structures of proteins
[14]
ComplexQA
GNN
Predict protein complex structure
[15]
ProteinBERT
Transformer
Predict secondary structure
[16]
ESMfold
Transformer
Predict structure of proteins
[17]
Predicting protein–protein interactions
IntPred
RF
Predict PPI interface sites
[18]
eFindSite
SVM; NBC
Predict PPI interfaces
[19]
DELPHI
RNN; CNN
Predict PPI sites
[20]
PPISP-XGBoost
XGBoost
Predict PPI sites
[21]
HN-PPISP
CNN
Predict PPI sites
[22]
TAGPPI
GCN
Predict PPIs
[23]
Struct2Graph
GAT
Predict PPIs
[24]
DeepFE-PPI
DNN
Predict PPIs
[25]
SGPPI
GCN
Predict PPIs
[26]
DeepPPI
DNN
Predict PPIs
[27]
DL-PPI
GNN
Predict PPIs
[28]
DeepSG2PPI
CNN
Predict PPIs
[29]
MaTPIP
Transformer; CNN
Predict PPIs
[30]
ProtInteract
Autoencoder; CNN
Predict PPIs
[31]
Predicting drug–target interactions
DeepC-SeqSite
CNN
Predict DTI binding sites
[32]
DeepSurf
CNN; ResNet
Predict DTI binding sites
[33]
PrankWeb
RF
Predict DTI binding sites
[34]
PUResNet
ResNet
Predict DTI binding sites
[35]
AGAT-PPIS
GNN
Predict DTI binding sites
[36]
DeepDTA
CNN
Predict DTI binding afﬁnity
[37]
SimBoost
GBM
Predict DTI binding afﬁnity
[38]
DEELIG
CNN
Predict DTI binding afﬁnity
[39]
DeepDTAF
CNN
Predict DTI binding afﬁnity
[8]
GraphDelta
CNN
Predict DTI binding afﬁnity
[40]
PotentialNet
CNN
Predict DTI binding afﬁnity
[41]
DeepAfﬁnity
RNN, CNN
Predict DTI binding afﬁnity
[9]
TeM-DTBA
CNN
Predict DTI binding afﬁnity
[42]
Wang et al.’s method
RL
Predict DTI binding pose
[43]
Nguyen et al.’s method
RF; CNN
Predict DTI binding pose
[44]
AMMVF-DTI
GAT; NTN
Predict drug–target interactions
[45]
De novo drug design
ReLeaSE
RNN; RL
Conduct de novo drug design
[46]
ChemVAE
CNN; GRU
Conduct de novo drug design
[47]
MolRNN
RNN
Conduct multi-objective de novo drug design
[48]
PaccMann(RL)
VAE
Generate compounds with anti-cancer drug properties
[49]
druGAN
AAE
Conduct de novo drug design
[50]
SCScore
CNN
Evaluate the molecular accessibility
[51]
UnCorrupt SMILES
Transformer
Conduct de novo drug design
[52]
PETrans
Transfer learning
Conduct de novo drug design
[53]
FSM-DDTR
Transformer
Conduct de novo drug design
[54]
DNMG
GAN
Conduct de novo drug design
[55]
MedGAN
GAN
Design novel molecule
[56]
Prediction of the physicochemical properties
Panapitiya et al.’s method
GNN
Predict aqueous solubility
[57]
SolTranNet
Transformer
Predict aqueous solubility
[58]
Zang et al.’s method
SVM
Predict multiple physicochemical properties
[59]
Prediction of the ADME/T properties
ADMETboost
XGBoost
Predict ADME/T properties
[60]
vNN
k-NN
Predict ADME/T properties
[61]
Interpretable-ADMET
CNN; GAT
Predict ADME/T properties
[62]
XGraphBoost
GNN
Predict ADME/T properties
[63]
DeepTox
DNN
Predict toxicity of compounds
[64]
Li et al.’s method
DNN
Predict human Cytochrome P450 inhibition
[65]
LightBBB
LightGBM
Predict blood–brain barrier
[66]
Deep-B3
CNN
Predict blood–brain barrier
[67]
PredPS
GNN
Predict stability of compounds in human plasma
[68]
Khaouane et al.’s method
CNN
Predict plasma protein binding
[69]
Application of AI in drug repurposing
deepDTnet
Autoencoder
Predict new targets of known drugs
[70]
NeoDTI
GCN
Predict new targets of known drugs
[71]
DTINet
Network diffusion algorithm and the
dimensionality reduction
Predict new targets of known drugs
[72]
MBiRW
Birandom walk algorithm
Predict new indications of known drugs
[73]
GDRnet
GNN
Predict new indications of known drugs
[74]
deepDR
VAE
Predict new indications of known drugs
[75]
GIPAE
VAE
Predict new indications of known drugs
[76]
DrugRep-HeSiaGraph
Heterogeneous siamese neural
network
Predict new indications of known drugs
[77]
iEdgeDTA
GCNN
Predict DTI binding afﬁnity
[78]

## Page 5 (Section: Application of ML in Drug Design )

Molecules 2024, 29, 903
5 of 20
Table 1. Cont.
Name
Algorithm
Speciﬁc Function
PMID
Retrosynthesis prediction
Segler et al.’s method
MCTS, DNN
Predict retrosynthetic analysis
[79]
Liu et al.’s method
RNN
Predict retrosynthetic analysis
[80]
RAscore
RF
Predict retrosynthetic accessibility score
[81]
Reaction prediction
Wei et al.’s method
Neural network
Predict reaction classes
[82]
Coley et al.’s method
Neural network
Predict products of chemical reactions
[83]
Gao et al.’s method
Neural network
Predict optimal reaction conditions
[84]
Marcou et al.’s method
RF
Evaluate reaction feasibility
[85]
Note: DNN, deep neural network; RNN, recurrent neural network; RF, random forest; CNN, convolutional neural
network; XGBoost, eXtreme gradient boosting; GCN, graph convolutional network; GAT, graph attention network;
SVM, support vector machine; NBC, naïve Bayes classiﬁer; ResNet, residual network; GBM, gradient boosting
machines; RL, reinforcement learning; GRU, gated recurrent unit; VAE, variational autoencoder; AAE, adaptive
adversarial autoencoder; GNN, graph neural networks; k-NN, k-nearest neighbor; LightGBM, light gradient
boosting machine; MCTS, Monte Carlo tree search, NTN, neural tensor network; GAN, generative adversarial
network; GCNN, graph convolutional neural network.
2.1. Application of ML in Drug Design
2.1.1. Prediction of the Target Protein Structure
Since proteins play crucial roles in various biological processes, their dysfunctions can
lead to abnormal cell behavior and lead to the development of diseases [86]. For selective
targeting of diseases, small-molecule compounds are generally designed based on the three-
dimensional (3D) chemical environment surrounding the ligand-binding sites of the target
protein [87]. Hence, predicting the 3D structure of the target protein is of great signiﬁcance
for structure-based drug discovery. Homology modeling has traditionally been used for this
purpose, relying on known protein structures as templates [88]. Comparatively, ML-based
approaches have shown great promise in predicting the 3D structures of target proteins
with improved accuracy and efﬁciency. For example, AlphaFold is a state-of-the-art protein
structure prediction system developed by DeepMind, a leading AI company. Based on deep
neural network (DNN), it has achieved remarkable success in multiple protein structure
prediction competitions, demonstrating its ability to accurately predict the 3D structures
of proteins by analyzing the adjacent amino acid distances and peptide bond angles [14].
Importantly, AlphaFold has signiﬁcantly advanced the ﬁeld of protein structure prediction
and has the potential to revolutionize drug discovery [14]. Therefore, ML-based approaches
hold great potential to enhance our understanding of protein structures. It should be noted
that protein structures can undergo changes in different environments, and proteins may
form multiple coexisting structures under the same conditions [89]. This complexity adds
to the challenges of structure prediction.
2.1.2. Prediction of PPIs
In most cases, proteins rarely implement their functions alone, but rather cooperate with
other proteins to form intricate relationships known as the protein–protein interaction (PPI)
network [86]. PPIs possess indispensable functions in diverse biological processes. They
can contribute to altering protein specificity, regulating protein activity and generating novel
binding sites for effector molecules [90]. Hence, understanding and targeting PPIs offers
opportunities to design innovative drugs that can modulate complex biological processes.
Currently, ML-based methods for PPI prediction can be broadly grouped into structure-
based and sequence-based categories. Structure-based approaches mainly leverage the
knowledge of protein structure similarity to predict PPIs [91]. For example, IntPred, a
random forest ML tool, was developed to predict protein–protein interface sites based on
structural features. Compared with other methods, the IntPred predictor showed strong
performance in identifying interactions at both the surface-patch and residue levels on
independent test sets of both obligate and transient complexes (Matthews’ Correlation
Coefﬁcient (MCC) = 0.370, accuracy = 0.811, speciﬁcity = 0.916, sensitivity = 0.411) [18].
Struct2Graph, a graph attention network (GAT)-based classiﬁer, was proposed to identify
PPIs directly from the 3D structure of protein chains [24]. The accuracy of Struct2Graph

## Page 6 (Section: Prediction of DTIs )

Molecules 2024, 29, 903
6 of 20
on balanced sets with equal numbers of positive and negative pairs was 0.9989, and the
average accuracy of ﬁve-fold cross-validation on unbalanced sets with a ratio of positive
and negative pairs of 1:10 was 0.9942 [24]. Comparatively, sequence-based PPI prediction
approaches aim to identify physical interactions between two proteins by leveraging
information from their protein sequences [92]. DNNs provide a robust solution for this
purpose. They are composed of multiple layers of interconnected neurons, allowing them
to automatically extract complex patterns and features from data. For example, DeepPPI
applied DNNs to effectively learn protein representations from common protein descriptors,
thereby contributing to the prediction of PPIs. It can achieve excellent performance on the
S. cerevisiae dataset with an accuracy of 0.925, precision of 0.9438, recall of 0.9056, speciﬁcity
of 0.9449, MCC of 0.8508 and area under the curve (AUC) of 0.9743, respectively [27].
Extensive experiments showed that DeepPPI was able to learn the useful features of protein
pairs through a layer-wise abstraction, resulting in better predictive performance than
existing methods on core S. cerevisiae, H. pylori and H. sapien datasets [27]. In addition,
based on Uniprot database, Li et al. [20] developed a DELPHI, a new sequence-based deep
ensemble model for PPI-binding sites’ prediction. Therefore, ML-based approaches have
great potential in enhancing the identiﬁcation of PPI sites. Compared with sequence-based
approaches, structure-based ones are limited by the scarcity of available protein structures
and the low quality of familiar protein structures [90,93].
2.1.3. Prediction of DTIs
Most drugs exert therapeutic effects by speciﬁcally interacting with target molecules
within the body, such as enzymes, receptors and ion channels. Hence, the accurate predic-
tion of DTIs is a pivotal step in the drug design pipeline. As the traditional experimental
approaches are time-consuming and costly, ML-based methods have been increasingly
developed and applied by researchers to predict DTIs. These methods primarily focus
on three key aspects: predicting the binding sites of drugs on target molecules, estimat-
ing the binding afﬁnity between drugs and targets, and determining the binding pose or
conformation of the drug within the target molecule [94].
Firstly, binding sites, also referred to as binding pockets, are speciﬁc locations within
a protein where interactions occur between the protein and a ligand (such as a drug
molecule) [94]. By introducing a deep convolutional neural network (CNN), Cui et al. [32]
developed a sequence-based method, DeepC-SeqSite, for predicting protein–ligand binding
residues. Notably, this method exhibited superior performance compared with multiple
existing sequence-based and 3D-structure-based methods, including the leading ligand-
binding method COACH [32]. Similarly, Zhou et al. [36] proposed a binding site prediction
method called AGAT-PPIS based on augmented GAT. It demonstrated signiﬁcant im-
provements over the state-of-the-art method, achieving an accuracy increase of 8% on the
benchmark test set. Moreover, binding afﬁnity represents the strength of an interaction
between a drug and its target. Some tools based on ML and DL algorithms have been
applied to determine DTIs’ binding afﬁnity, such as DEELIG [39] and GraphDelta [40].
In addition, the active conformation of ligands plays a crucial role in facilitating the ef-
fective binding between proteins and drugs [94]. By combining random forest and CNN
strategies, Nguyen et al. [44] proposed a scoring function to select the most relevant poses
generated by docking software tools including GOLD, GLIDE and Autodock Vina, thereby
contributing to obtaining more accurate and effective ligand–target binding conﬁgurations.
Therefore, ML algorithms have been extensively employed to predict DTIs and hold the
potential to facilitate the design of new drugs.
2.1.4. De Novo Drug Design
De novo drug design refers to the process of creating new drug molecules from scratch
using computational methods, without relying on existing bioactive compounds or known
drug structures. It involves designing molecules that have speciﬁc properties and functions
to target a particular disease or condition [95,96]. Compounds developed with traditional

## Page 7 (Section: Application of ML in Drug Screening )

Molecules 2024, 29, 903
7 of 20
de novo drug design methods (e.g., the fragment-based approach) usually have poor drug
metabolism and pharmacokinetics properties and are hard to synthesize due to the com-
plexity and impracticality of compound structures [97,98]. Therefore, there is high demand
for new methods to explore chemical entities that meet the requirements of biological
activity, drug metabolism, pharmacokinetics and synthesis practicality.
Recently, ML-based approaches, especially auto-encoder variants (e.g., the variational
auto-encoder (VAE) and adversarial auto-encoder (AAE)) have gained attention in the ﬁeld
of de novo drug design. PaccMannRL is an example of these approaches that combines a
hybrid VAE with reinforcement learning for the de novo design of anti-cancer molecules
from transcriptomic data [49]. Similarly, another approach, known as druGAN, utilizes
a deep generative AAE model to generate novel molecules that possess speciﬁc anti-
cancer properties [50]. In addition, a Wasserstein GAN and GCN-based model, known as
MedGAN, has been successfully developed to generate novel quinoline-scaffold molecules
from complicated molecular graphs and evaluate drug-related properties [56]. It has been
demonstrated that the MedGAN was able to produce 25% effective molecules, 62% fully
connected, among which 92% are quinoline, 93% are novel, and 95% are unique [56]. To
address the difﬁculty in synthesizing generated molecules, Coley et al. [51] deﬁned a
synthetic complexity score, namely SCScore, that utilizes precedent reaction knowledge to
train a neural network model for evaluating the level of synthetic complexity. Therefore,
ML-empowering approaches play crucial roles in de novo drug design, revolutionizing the
process of discovering and developing new drugs.
2.2. Application of ML in Drug Screening
2.2.1. Prediction of the Physicochemical Properties
The physicochemical properties of drugs, mainly including solubility, ionization de-
gree, partition coefﬁcient, permeability coefﬁcient and stability, play a signiﬁcant role in
determining their behavior (e.g., bioavailability, absorption, transportation and perme-
ability) in biological systems as well as the environment, and in evaluating their potential
risks to human health [6,59]. Hence, these properties are assessed during drug screening
to select promising candidates for further development and optimization. At present,
multiple ML-based tools have been proposed to predict the physicochemical properties of
molecules. For example, Francoeur et al. [58] developed a molecule attention Transformer
called SolTranNet for predicting aqueous solubility from the SMILES representation of
drug molecules. It has been demonstrated to function as a classiﬁer for ﬁltering insoluble
compounds, achieving a sensitivity of 0.948 on Challenge to Predict Aqueous Solubility
(SC2) datasets, which is competitive with other methods [58]. Moreover, by using molecular
ﬁngerprints and four ML algorithms, Zang et al. [59] developed a quantitative structure–
property relationship workﬂow to predict six physicochemical properties of environmental
chemicals, such as water solubility, octanol–water partition coefﬁcient, melting point, boil-
ing point, bioconcentration factor, and vapor pressure [59]. Therefore, these ML-based
predictors are valuable tools in drug discovery, as they can help in screening potential drug
candidates based on their physicochemical properties.
2.2.2. Prediction of the ADME/T Properties
Once hit or lead compounds are identiﬁed during the drug discovery process, a series
of tests and evaluations are conducted to assess their absorption, distribution, metabolism,
and excretion and toxicity (ADME/T) properties [99]. These pharmacokinetic properties
are essential for understanding how the compounds will behave in the human body and
whether they have the potential to be safe and effective as drugs. Imbalanced ADME/T
properties frequently cause the failure of drug candidates in late stages of drug development
and may even lead to the withdrawal of approved drugs [100]. Hence, ADME/T properties
are often employed as molecular ﬁlters to screen large databases of compounds in the early
stage of drug discovery, thereby helping to increase efﬁciency and improve the success rate
of drug screening [93,100].

## Page 8 (Section: Application of ML in Drug Repurposing )

Molecules 2024, 29, 903
8 of 20
To detect the ADME/T properties of drugs, various evaluation criteria such as hepa-
totoxicity, passing through the blood–brain barrier (BBB), plasma protein binding (PPB)
and cytochrome P450 2D6 (CYP2D6) inhibition are commonly used [101,102]. Accordingly,
there has been growing interest in developing ML-based tools for the prediction of these
criteria. For example, Tian et al. [60] developed a web server called ADMETboost that
utilizes the powerful extreme gradient boosting (XGBoost) model to learn about molecule
features from multiple ﬁngerprints and descriptors, allowing for the accurate prediction
of ADME/T properties, such as Caco2, BBB, CYP2C9 inhibition, CL-Hepa and hERG. It
has been demonstrated that this model can achieve remarkable results in the Therapeutics
Data Commons ADMET benchmark, ranking ﬁrst in 18 out of 22 tasks and within the top
three in 21 tasks [60]. Similarly, by utilizing more than 13 000 compounds obtained from
the PubChem BioAssay Database, Li et al. [65] proposed a multitask autoencoder DNN
model to predict the inhibitors of ﬁve major cytochrome P450 (CYP450) isoforms (1A2, 2C9,
2C19, 2D6 and 3A4). Especially, the multi-task DNN model achieved average prediction
accuracies of 86.4% in 10-fold cross-validation and 88.7% on external test datasets, outper-
forming single-task models, earlier described classiﬁers and conventional ML methods [65].
Furthermore, the Tox21 Challenge is a collaborative effort aimed at developing predictive
models for toxicity assessment using high-throughput screening data. In this context, Mayr
et al. [64] developed a DL pipeline, DeepTox, for toxicity prediction. It outperformed
all other computational methods (e.g., naïve Bayes, random forest and support vector
machine) in 10 out of 15 cases in the Tox21 Challenge [64]. Therefore, ML algorithms have
made signiﬁcant progress in predicting the ADME/T properties of drugs, contributing to
guiding drug safety assessment and preclinical research.
2.3. Application of ML in Drug Repurposing
Drug repurposing, also known as drug repositioning, is a strategy to identify new
indications from approved or investigational (including failed in clinical trials) drugs that
have not been approved [103]. As this approach takes advantage of the extensive safety
testing conducted during clinical trials for other purposes, repurposing known drugs not
only speeds up the drug development process but also presents cost-saving advantages
compared to developing entirely new drugs from scratch [103]. Currently, researchers are
increasingly developing and applying ML-based methods to conduct drug repurposing,
which can be broadly divided into target-centered and disease-centered approaches [104].
In target-centered drug repurposing, network-based methods have been widely ap-
plied to search new targets for known drugs. For example, by employing autoencoder and
Positive-Unlabeled matrix completion algorithms, Zeng et al. [70] developed a calculation
method called deepDTnet to identify new targets for known drugs from a heterogeneous
drug–gene–disease network. Experiments have shown that the deepDTnet achieved a high
accuracy in predicting new targets of existing drugs (AUC = 0.963), which is superior to
traditional ML methods [70]. Similarly, by combining the network diffusion algorithm and
the dimensionality reduction approach, Luo et al. [72] developed DTINet, a novel network-
integration procedure for DTI prediction and drug repositioning. It can outperform other
existing methods, with AUC and area under precision-recall (AUPR) 5.7% and 5.9% higher
than the second best method, respectively, providing an effective tool in the ﬁeld of drug
discovery and target identiﬁcation [72].
In addition, disease-centered approaches are mainly aimed at identifying drug–disease
relationships and can be widely divided into similarity-based and network-based ones [104].
Similarity-based methods have achieved signiﬁcant progress by combining drug or disease
characteristics with the known drug–disease associations [104]. For example, based on the
assumption that similar drugs are commonly associated with similar diseases, Luo et al. [73]
proposed a novel computational approach called MBiRW, which combines similarity mea-
surements and a Bi-Random walk algorithm to recognize potential novel indications for
a speciﬁc drug. MBiRW can achieve a high accuracy in predicting drug–disease associa-
tions (AUC = 0.917), which is superior to other methods [73]. In addition, network-based

## Page 9 (Section: Application of ML in Chemical Synthesis )

Molecules 2024, 29, 903
9 of 20
methods integrate information from different biological networks to improve the predictive
accuracy of drug–disease relationships. For example, Doshi et al. [74] developed a graph
neural network model called GDRnet for drug repurposing, which can efﬁciently screen
existing drugs in the database and predict their unknown therapeutic effects by evaluating
the scores of drug–disease pairs. Therefore, ML technology holds signiﬁcant promise in the
ﬁeld of drug repurposing, providing strong support for accelerating drug discovery.
2.4. Application of ML in Chemical Synthesis
Organic synthesis is a key part of the small-molecule drug-discovery process [97].
New molecules are synthesized along the path of compound optimization to achieve
improved properties. To promote molecule synthesis, researchers have developed multiple
ML-based computational tools applicable to the retrosynthesis prediction and forward
reaction prediction.
2.4.1. Retrosynthesis Prediction
Retrosynthesis planning aims to identify efﬁcient synthetic routes for a desired molecule
by recursively converting it into easier precursors. Therefore, it can effectively solve the syn-
thesis of complex molecules to facilitate the development of organic synthesis science [105].
At present, a series of ML-based approaches have been used for retrosynthesis planning,
mainly including template-based and template-free approaches.
The template-based approach involves systematically comparing the target molecule
with a set of templates, each representing alternative substructure patterns that occur during
a chemical reaction [105]. The ﬁrst work involving DNNs for this issue was presented by
Segler et al. [79], published in Nature. They found that Monte Carlo tree search (MCTS)
combined with DNNs and symbolic rules can be utilized to perform chemical synthesis
effectively. The routes generated by the model were comparable to those reported in the
literature in a double-blind AB test, thereby conﬁrming the accuracy of the model [79].
However, it is worth noting that template-based approaches cannot be extended beyond
templates, limiting their predictive ability [106].
As for the template-free method, it aims to uncover hidden relationships within
the data concerning reaction mechanisms rather than relying on direct matching [105].
For example, by using neural sequence-to-sequence models, Liu et al. [80] proposed the
template-free method called seq2seq, to perform the retrosynthetic reaction-prediction
tasks. This model was based on an encoder–decoder framework consisting of two re-
current neural networks (RNNs) and was trained on a dataset of 50,000 experimental
reactions extracted from the United States’ patent literature, demonstrating comparable
performances to the rule-based expert system model [80]. Therefore, ML algorithms have
been extensively employed to conduct retrosynthetic analysis and hold the potential to
facilitate chemical synthesis.
2.4.2. Forward Reaction Prediction
Contrary to retrosynthesis analysis, forward reaction prediction aims to identify po-
tential molecules that can be synthesized from given reactants and reagents [105]. Given
the reactant molecules as input, the ML model analyzes their structural and chemical
properties to generate predictions about the resulting products and reaction conditions. For
example, Wei et al. [82] introduced a novel reaction ﬁngerprinting approach that utilizes
neural networks to predict reaction types. The prediction results of this method on 16 basic
reactions of alkyl halides and alkenes indicates that neural networks can contribute to iden-
tify key features from the structure of reactant molecules to classify new reaction types [82].
Similarly, Coley et al. [83] proposed a neural network model to predict the main products
of chemical reactions by training the data extracted from a collection of 150,000 compounds’
reaction templates in the US patent database. In addition, in practical chemical synthesis
reactions, reaction conditions (e.g., solvent and temperature) are critical to maximize the
yield of desired products. Based on this, Gao et al. [84] proposed a neural network model

## Page 10 (Section: Opportunities for Transformer-Based ML Models in Empowering Drug Discovery )

Molecules 2024, 29, 903
10 of 20
to predict the optimal reaction conditions for various types of reactions. This model was
trained using a vast dataset of nearly 10 million entries extracted from the Reaxys database
and can effectively predict the ideal catalyst, solvent, reagent, and temperature for a given
reaction, facilitating the optimization of reaction conditions [84]. Therefore, the utilization
of ML-based models can assist in predicting reaction types, accelerating the discovery of
new chemical molecules, and identifying optimal reaction conditions, thereby holding
great potential in improving the efﬁciency of chemical synthesis processes.
3. Opportunities for Transformer-Based ML Models in Empowering Drug Discovery
The Transformer model, ﬁrstly proposed in the paper ‘Attention is All You Need’ by
Vaswani et al., is a highly advanced DL architecture utilizing self-attention mechanisms.
As it allows for parallelization and captures long-range dependencies more efﬁciently than
traditional RNN models, the Transformer model has proven to be highly effective in a wide
range of tasks and has set new benchmarks in the corresponding ﬁelds [10,11]. Given the
advantages of the Transformer, it has emerged as a promising future direction of ML in the
ﬁeld of drug discovery (Figure 3).
Figure 3. Opportunities for Transformer-based models in empowering drug discovery.

## Page 11 (Section: Opportunity 1: Transformer Models Empowering PPIs Identification )

Molecules 2024, 29, 903
11 of 20
3.1. Opportunity 1: Transformer Models Empowering PPIs Identiﬁcation
Existing ML-based approaches mainly use CNNs to extract low-dimensional features
from protein sequences based on the amino acid composition, while disregarding the long-
range relationships within these sequences [107]. Fortunately, transformers can capture
the long-distance dependencies in the protein sequences, making them suitable to predict
whether and how given proteins interact with each other [108]. For example, by utilizing
the advantage of the Transformer model in evolutionary scale modeling-multiple sequence
alignment, Lin et al. [109] developed DeepHomo2.0, a DL-based model that predicts
PPIs of homodimeric complexes by combining Transformer features, monomer structure
information, and direct-coupling analysis. The results showed that DeepHomo2.0 can
achieve a high accuracy of over 70% and 60% in terms of experimental monomer structure
and predicted monomer structure for the top 10 contacts predicted on the Protein Data Bank
(PDB)test set, respectively, which is superior to the DCA-based, protein language model-
based and other ML-based methods [109]. Similarly, Kang et al. [110] proposed AFTGAN,
a neural network that combines Transformer and GAT frameworks for effective protein
information extraction and multi-type PPI prediction. Experimental comparisons validated
the superior performance of AFTGAN in accurately predicting the PPIs of unknown
proteins. Therefore, given the advantage of the Transformer in extracting protein sequences,
it has demonstrated remarkable potential in advancing the prediction of PPIs.
3.2. Opportunity 2: Transformer Models Empowering DTIs’ Identiﬁcation
Despite the remarkable performance improvement of DL models in DTI prediction,
the primary challenge lies in the limited representation of drugs in these methods, as they
only consider SMILES sequences, SMARTS strings or molecular graphs, failing to capture
comprehensive drug representations [107]. It is worth noting that Transformers can be
employed either independently or in combination with other AI algorithms to address
these problems. For example, DeepMGT-DTI, a DL model that incorporates a Transformer
network and multilayer graph information, can effectively capture the structural features of
drugs, leading to improved DTI prediction [111]. Experiments have demonstrated that the
DeepMGT-DTI can achieve an AUC of 90.24%, an AUPR of 77.11%, an F1 score of 79.31%
and an accuracy of 85.15% on the DrugBank dataset. These performance metrics surpassed
those previous target sequence structure models, such as Deep DTA and Transformer-
CPI [111]. Moreover, GSATDTA, a novel triple-channel model based on graph–sequence
attention and Transformer, has been developed to predict the drug-target binding afﬁnity
with outstanding performance [107]. Therefore, Transformer models have shown promising
results for DTIs’ prediction.
3.3. Opportunity 3: Transformer Models Empowering De Novo Drug Design
Most existing deep generative models either focus on virtual screening on the available
database of compounds by DTI binding-afﬁnity prediction, or unconditionally generate
molecules with speciﬁc physicochemical and pharmacological properties, which ignore the
function of protein targets during the generation process [112]. In contrast, Transformer
models have the capability to consider the protein target and achieve target-speciﬁc molec-
ular generation. For example, AlphaDrug, a method for protein target-speciﬁc de novo
drug design, has been recently proposed. It utilizes a modiﬁed Transformer to optimize
the learning of protein information and integrates an efﬁcient MCTS guided by the Trans-
former’s predictions as well as docking values [112]. Notably, in terms of average docking
score, uniqueness, the octanol–water partition coefﬁcient logP, the quantitative estimate
of drug-likeness (QED), synthetic accessibility (SA) and Natural products-likeness (NP-
likeness) criteria, AlphaDrug is superior to other methods (such as LiGANN, SBMolGen
and SBDD-3D) [112]. In addition, the GPT model is a powerful language generation model
that can be ﬁne-tuned for speciﬁc tasks after pre-training on large amounts of text data [113].
It has been successfully applied to accelerate molecular generation for speciﬁc targets in
the ﬁeld of drug discovery. For example, cMolGPT, a GPT-inspired model, is a useful tool

## Page 12 (Section: Opportunity 4: Transformer Models Empowering Molecular Property Prediction )

Molecules 2024, 29, 903
12 of 20
for target-speciﬁc de novo molecular generation. The chemical space of the compounds
generated by cMolGPT closely matches with that of real target-speciﬁc ones [114].
3.4. Opportunity 4: Transformer Models Empowering Molecular Property Prediction
Despite the widespread application of ML-based models, the shortage of labeled data
continues to be a significant challenge in efficient molecular property predictions [10,115]. To
address this, researchers are exploring the use of unlabeled data and leveraging transformer-
based self-supervised learning (e.g., BERT) to improve predictions on small-scale labeled
data [116]. Currently, several BERT-based pre-training methods for molecular property
prediction have been proposed [10,117]. For example, a novel pre-training method, known
as K-BERT, was developed to extract chemical information from SMILES similar to chemists
for molecular property prediction in drug discovery [118]. The K-BERT model exhibited
superior performance in 8 out of 15 tasks, thus reflecting the efficacy and benefits of the
proposed pre-training approach in drug discovery. Specifically, K-BERT had an average AUC
score of 0.806, outperforming other competing methods (e.g., XGBoost-MACCS, XGBoost-
ECFP4, HRGCN+ and Attentive FP) [118]. Moreover, Wang et al. [119] proposed a two-stage
(pre-training and fine-tuning) model called SMILES-BERT that could use both unlabeled
data and labeled data to improve molecular property prediction. Compared with a range of
state-of-the-art approaches (e.g., CircularFP, NeuralFP, Seq2seqFP, Seq3seqFP), it exhibited
superior performance on three different datasets (the LogP dataset, PM2 dataset and PCBA-
686978 dataset) with accuracies of 0.9154, 0.7589, and 0.8784, respectively [119]. Therefore,
these Transformer-based predictors are essential tools for molecular property prediction,
contributing to the efficient screening of potential drug candidates.
3.5. Opportunity 5: Transformer Models Empowering Chemical Synthesis
Previous sequence-based approaches commonly employed RNNs for both the encoder
and decoder, with a single-head attention layer connecting them. These models treated
reactants and reagents separately in the input by utilizing atom mapping, which limits
the interpretability of the model [120]. Fortunately, Transformer-powered models have
shown potential to accelerate chemical synthesis. One notable example is the effectiveness
of the multi-head attention Molecular Transformer model in predicting chemical reactions
and reaction conditions [120,121]. In addition, inspired by the success of the Molecular
Transformer for forward reaction prediction, Schwaller et al. [122] proposed an enhanced
Molecular Transformer architecture coupled with a hyper-graph exploration algorithm
for automated retrosynthetic pathway prediction. This approach surpasses previous ML-
based methods by not only predicting reactants but also identifying reagents for each
retrosynthetic step, thereby signiﬁcantly raising the complexity of the prediction task.
4. Challenges of ML-Based Models in Drug Discovery
Given the remarkable advantages in identifying and extracting features from high-
dimensional and complex big data, ML-based models have made signiﬁcant progress in
multiple stages of drug discovery [99]. However, there remain several challenges that have
yet to be effectively resolved (Figure 4).
First, the effectiveness of ML algorithms heavily relies on the quantity of training
data, and typically, a larger dataset tends to yield a more accurate model [96]. When the
amount of data is inadequate, it can signiﬁcantly impact the performance and reliability
of ML models, potentially resulting in the risk of overﬁtting [123]. Indeed, the limited
availability of data, especially labeled data, poses a signiﬁcant challenge to the progress
of ML-driven drug discovery. One potential approach to address this issue is employing
transfer learning algorithms, where knowledge acquired from one task can be effectively
applied to another task [124–126]. Additionally, in light of the challenges associated with
acquiring extensive labeled datasets in drug discovery, there is a growing trend for the
effectiveness of concentrating efforts on smaller, carefully curated datasets. This shift
highlights the signiﬁcance of extracting meaningful insights from limited yet relevant data,

## Page 13 (Section: Opportunity 4: Transformer Models Empowering Molecular Property Prediction )

Molecules 2024, 29, 903
13 of 20
thereby enhancing the precision and applicability of ML models in the complex landscape
of drug discovery.
Figure 4. Challenges of machine learning-based models in drug discovery.
Second, the quality of the data is also crucial in determining the prediction performance
of ML models. The experimental drug-related data collected in public databases frequently
originates from varying biological assays, conditions, or methods, leading to disparate
results when different measurement techniques are employed for a speciﬁc compound,
thereby hindering direct comparisons. Hence, the strategies for ﬁltering raw inputs with
noise, outliers, or irrelevant information and automating data entry may be helpful to
achieve reliable and accurate ML models for drug discovery. For example, during the
data processing phase, noise reduction and outlier detection algorithms, such as Z-scores,
box plots or iterative deletion, can be applied to identify and purge outliers from the data,
enhancing its quality for ML model prediction. In addition, researchers can use cross-
validation experiments to assess the generalization ability of the models, ensuring that they
perform well not only on speciﬁc datasets but also on new, unseen data.
Third, due to the abundance of ML model architectures and the constant emergence
of new ones, it becomes challenging to choose the most suitable models that meet speciﬁc
research task requirements in the ﬁeld of drug discovery [99]. Generally, the model selec-
tion involves evaluating various options and considering factors such as the complexity of
the problem, available data, and computational resources. Furthermore, once the model
architecture is selected, the next step is to ﬁne-tune its parameters to optimize the model’s
performance. Although hyperparameter optimization tools have been proposed to auto-
mate the process of tuning substantial parameters in ML models, the entire system process
is also relatively complicated, which may bring certain difﬁculties to the application of
researchers [99,127]. In addition, the setting of hyper-parameters usually requires human

## Page 14 (Section: Concluding Remarks )

Molecules 2024, 29, 903
14 of 20
intervention, which may lead to their incomplete or inaccurate selection. Accordingly,
cross-validation is commonly used in variable selection and model parameter tuning to
evaluate the performances of various ML methods [128]. Moreover, establishing clear
performance metrics at the outset, such as accuracy, precision, recall, F1 score, AUC and
AUPR can help in objectively evaluating the suitability of different models depending on
the nature of the problem.
Fourth, unlike traditional models where the reasoning and decision-making process
can be easily understood, ML models, particularly DL models, operate using complex
mathematical algorithms and layers of interconnected neurons, making it challenging to in-
terpret their inner workings. The lack of transparency and interpretability pose difﬁculties
for ML models in explaining the observed phenomena and understanding the underlying
biological mechanisms. Hence, the ML models are often referred to as “black boxes” [99].
For this issue, employing visualization tools such as Activation Maximization [129], Local
Interpretable Model-agnostic Explanations (LIME) [130] and SHapley Additive exPlana-
tions (SHAP) [131] can help in understanding the model’s decision-making process by
providing insights into which features are most inﬂuential. In the future, a continuous
requirement is to develop robust models with high interpretability.
Therefore, a tremendous amount of work has been done to incorporate ML tools to
expedite the drug discovery cycle, but further advancement and improvement of these
tools is needed before the full potential of ML in drug discovery can be realized.
5. Concluding Remarks
The research and development of new drugs can contribute to meet the human de-
mand for treating diseases and provide more effective, safer, and more convenient treatment
options. Compared with the traditional strategies of drug discovery, ML-based approaches
have the potential to reduce time and costs, improve safety, and bridge the gap between
drug discovery and drug effectiveness, making them increasingly favored by the pharma-
ceutical industry and academia. In particular, the introduction of chatGPT has sparked
researchers’ growing interest and exploration in leveraging the Transformer model’s NLP
capabilities, particularly its self-attention mechanisms, to accelerate multiple stages of the
drug discovery process, thereby opening up new opportunities for advancements.
However, the current challenges in ML-based models can result in generating false
positives or false negatives, potentially leading to incorrect predictions and resource waste.
Further in vitro and in vivo experiments as well as clinical trials are needed to fully demon-
strate the practicability of ML-based drug discovery and obtain more reliable and accurate
results. Therefore, future research should focus on improving data quality, enhancing the in-
terpretability of ML algorithms, and integrating them with human professional knowledge
to increase the efﬁcacy of drug discovery.
Author Contributions: X.Q. and Y.Z. designed the review; Y.Z. collected the related data; X.Q. and
Y.Z. drafted the manuscript; X.Q., Y.Z., S.H., Z.Q. and J.C. revised the manuscript. All authors have
read and agreed to the published version of the manuscript.
Funding: This work was supported by the National Natural Science Foundation of China (Grant No.
32270705) and the Postgraduate Research & Practice Innovation Program of Jiangsu Province (Grant
No. KYCX23_3344).
Institutional Review Board Statement: Not applicable.
Informed Consent Statement: Not applicable.
Data Availability Statement: Not applicable.
Conﬂicts of Interest: The authors declare no conﬂicts of interest.

## Page 15 (Section: References)

Molecules 2024, 29, 903
15 of 20
Abbreviations
AI, artiﬁcial intelligence; ML, machine learning; DL, deep learning; ANN, artiﬁcial neural network;
NLP, natural language processing; DTI, drug–target interaction; 3D, three-dimensional; DNN, deep
neural network; PPI, protein–protein interaction; GAT, graph attention network; CNN, convolutional
neural network; VAE, variational auto-encoder; AAE, adversarial auto-encoder; RNN, recurrent
neural network; RF, random forest; XGBoost, eXtreme gradient boosting; GCN, graph convolutional
network; SVM, support vector machine; NBC, naïve Bayes classiﬁer; NTN, neural tensor network;
GAN, generative adversarial network; GCNN, graph convolutional neural network; ResNet, residual
network; GBM, gradient boosting machines; RL, reinforcement learning; GRU, gated recurrent unit;
GNN, graph neural networks; k-NN, k-nearest neighbor; LightGBM, light gradient boosting machine;
MCTS, Monte Carlo tree search, NTN, neural tensor network; GAN, generative adversarial network;
GCNN, graph convolutional neural network; ADME/T, absorption, distribution, metabolism, and
excretion and toxicity; BBB, blood–brain barrier; PPB, plasma protein binding, CYP2D6, cytochrome
P450 2D6; XGBoost, extreme gradient boosting; CYP450, cytochrome P450;MCTS, Monte Carlo Tree
Search; GPT, Generative Pre-Training Transformer; BERT, bidirectional encoder representations from
transformers; SC2, Challenge to Predict Aqueous Solubility; MCC, Matthews’ Correlation Coefﬁcient;
AUC, area under the curve; AUPR, area under precision-recall; PDB, Protein Data Bank; QED,
quantitative estimate of drug-likeness; SA, synthetic accessibility;NP, natural products; LIME, Local
Interpretable Model-agnostic Explanations; SHAP, SHapley Additive exPlanations.
References
1.
DiMasi, J.A.; Grabowski, H.G.; Hansen, R.W. Innovation in the pharmaceutical industry: New estimates of R&D costs. J. Health
Econ. 2016, 47, 20–33. [CrossRef] [PubMed]
2.
Ashburn, T.T.; Thor, K.B. Drug repositioning: Identifying and developing new uses for existing drugs. Nat. Rev. Drug Discov.
2004, 3, 673–683. [CrossRef]
3.
Dowden, H.; Munro, J. Trends in clinical success rates and therapeutic focus. Nat. Rev. Drug Discov. 2019, 18, 495–496. [CrossRef]
[PubMed]
4.
Deng, J.; Yang, Z.; Ojima, I.; Samaras, D.; Wang, F. Artiﬁcial intelligence in drug discovery: Applications and techniques. Brief.
Bioinform 2022, 23, bbab430. [CrossRef] [PubMed]
5.
Mak, K.K.; Pichika, M.R. Artiﬁcial intelligence in drug development: Present status and future prospects. Drug Discov. Today 2019,
24, 773–780. [CrossRef]
6.
Paul, D.; Sanap, G.; Shenoy, S.; Kalyane, D.; Kalia, K.; Tekade, R.K. Artiﬁcial intelligence in drug discovery and development.
Drug Discov. Today 2021, 26, 80–93. [CrossRef]
7.
Chen, H.; Engkvist, O.; Wang, Y.; Olivecrona, M.; Blaschke, T. The rise of deep learning in drug discovery. Drug Discov. Today
2018, 23, 1241–1250. [CrossRef]
8.
Wang, K.; Zhou, R.; Li, Y.; Li, M. DeepDTAF: A deep learning method to predict protein-ligand binding afﬁnity. Brief. Bioinform.
2021, 22, bbab072. [CrossRef]
9.
Karimi, M.; Wu, D.; Wang, Z.; Shen, Y. DeepAfﬁnity: Interpretable deep learning of compound-protein afﬁnity through uniﬁed
recurrent and convolutional neural networks. Bioinformatics 2019, 35, 3329–3338. [CrossRef]
10.
Zhang, S.; Fan, R.; Liu, Y.; Chen, S.; Liu, Q.; Zeng, W. Applications of transformer-based language models in bioinformatics:
A survey. Bioinform. Adv. 2023, 3, vbad001. [CrossRef]
11.
Vaswani, A.; Shazeer, N.; Parmar, N.; Uszkoreit, J.; Jones, L.; Gomez, A.N.; Kaiser, Ł.; Polosukhin, I. Attention is all you need. Adv.
Neural Inf. Process. Syst. 2017, 30, 1–11.
12.
Kalakoti, Y.; Yadav, S.; Sundar, D. TransDTI: Transformer-Based Language Models for Estimating DTIs and Building a Drug
Recommendation Workﬂow. ACS Omega 2022, 7, 2706–2717. [CrossRef] [PubMed]
13.
Du, Z.; Su, H.; Wang, W.; Ye, L.; Wei, H.; Peng, Z.; Anishchenko, I.; Baker, D.; Yang, J. The trRosetta server for fast and accurate
protein structure prediction. Nat. Protoc. 2021, 16, 5634–5651. [CrossRef]
14.
Senior, A.W.; Evans, R.; Jumper, J.; Kirkpatrick, J.; Sifre, L.; Green, T.; Qin, C.; Žídek, A.; Nelson, A.W.R.; Bridgland, A.; et al.
Improved protein structure prediction using potentials from deep learning. Nature 2020, 577, 706–710. [CrossRef]
15.
Zhang, L.; Wang, S.; Hou, J.; Si, D.; Zhu, J.; Cao, R. ComplexQA: A deep graph learning approach for protein complex structure
assessment. Brief. Bioinform. 2023, 24, bbad287. [CrossRef] [PubMed]
16.
Brandes, N.; Ofer, D.; Peleg, Y.; Rappoport, N.; Linial, M. ProteinBERT: A universal deep-learning model of protein sequence and
function. Bioinformatics 2022, 38, 2102–2110. [CrossRef]
17.
Lin, Z.; Akin, H.; Rao, R.; Hie, B.; Zhu, Z.; Lu, W.; Smetanin, N.; Verkuil, R.; Kabeli, O.; Shmueli, Y.; et al. Evolutionary-scale
prediction of atomic-level protein structure with a language model. Science 2023, 379, 1123–1130. [CrossRef]

## Page 16 (Section: References)

Molecules 2024, 29, 903
16 of 20
18.
Northey, T.C.; Bareši´c, A.; Martin, A.C.R. IntPred: A structure-based predictor of protein-protein interaction sites. Bioinformatics
2018, 34, 223–229. [CrossRef]
19.
Maheshwari, S.; Brylinski, M. Template-based identiﬁcation of protein-protein interfaces using eFindSitePPI. Methods 2016, 93,
64–71. [CrossRef]
20.
Li, Y.; Golding, G.B.; Ilie, L. DELPHI: Accurate deep ensemble model for protein interaction sites prediction. Bioinformatics 2021,
37, 896–904. [CrossRef]
21.
Wang, X.; Zhang, Y.; Yu, B.; Salhi, A.; Chen, R.; Wang, L.; Liu, Z. Prediction of protein-protein interaction sites through eXtreme
gradient boosting with kernel principal component analysis. Comput. Biol. Med. 2021, 134, 104516. [CrossRef]
22.
Kang, Y.; Xu, Y.; Wang, X.; Pu, B.; Yang, X.; Rao, Y.; Chen, J. HN-PPISP: A hybrid network based on MLP-Mixer for protein-protein
interaction site prediction. Brief. Bioinform. 2023, 24, bbac480. [CrossRef]
23.
Song, B.; Luo, X.; Luo, X.; Liu, Y.; Niu, Z.; Zeng, X. Learning spatial structures of proteins improves protein-protein interaction
prediction. Brief. Bioinform. 2022, 23, bbab558. [CrossRef] [PubMed]
24.
Baranwal, M.; Magner, A.; Saldinger, J.; Turali-Emre, E.S.; Elvati, P.; Kozarekar, S.; VanEpps, J.S.; Kotov, N.A.; Violi, A.; Hero, A.O.
Struct2Graph: A graph attention network for structure based predictions of protein-protein interactions. BMC Bioinform. 2022, 23,
370. [CrossRef] [PubMed]
25.
Yao, Y.; Du, X.; Diao, Y.; Zhu, H. An integration of deep learning with feature embedding for protein-protein interaction prediction.
PeerJ 2019, 7, e7126. [CrossRef]
26.
Huang, Y.; Wuchty, S.; Zhou, Y.; Zhang, Z. SGPPI: Structure-aware prediction of protein-protein interactions in rigorous conditions
with graph convolutional network. Brief. Bioinform. 2023, 24, bbad020. [CrossRef]
27.
Du, X.; Sun, S.; Hu, C.; Yao, Y.; Yan, Y.; Zhang, Y. DeepPPI: Boosting Prediction of Protein-Protein Interactions with Deep Neural
Networks. J. Chem. Inf. Model. 2017, 57, 1499–1510. [CrossRef] [PubMed]
28.
Wu, J.; Liu, B.; Zhang, J.; Wang, Z.; Li, J. DL-PPI: A method on prediction of sequenced protein-protein interaction based on deep
learning. BMC Bioinform. 2023, 24, 473. [CrossRef]
29.
Zhang, F.; Zhang, Y.; Zhu, X.; Chen, X.; Lu, F.; Zhang, X. DeepSG2PPI: A Protein-Protein Interaction Prediction Method Based on
Deep Learning. IEEE/ACM Trans. Comput. Biol. Bioinform. 2023, 20, 2907–2919. [CrossRef] [PubMed]
30.
Ghosh, S.; Mitra, P. MaTPIP: A deep-learning architecture with eXplainable AI for sequence-driven, feature mixed protein-protein
interaction prediction. Comput. Methods Programs Biomed. 2024, 244, 107955. [CrossRef]
31.
Soleymani, F.; Paquet, E.; Viktor, H.L.; Michalowski, W.; Spinello, D. ProtInteract: A deep learning framework for predicting
protein-protein interactions. Comput. Struct. Biotechnol. J. 2023, 21, 1324–1348. [CrossRef]
32.
Cui, Y.; Dong, Q.; Hong, D.; Wang, X. Predicting protein-ligand binding residues with deep convolutional neural networks. BMC
Bioinform. 2019, 20, 93. [CrossRef]
33.
Mylonas, S.K.; Axenopoulos, A.; Daras, P. DeepSurf: A surface-based deep learning approach for the prediction of ligand binding
sites on proteins. Bioinformatics 2021, 37, 1681–1690. [CrossRef]
34.
Jendele, L.; Krivak, R.; Skoda, P.; Novotny, M.; Hoksza, D. PrankWeb: A web server for ligand binding site prediction and
visualization. Nucleic Acids Res. 2019, 47, W345–w349. [CrossRef]
35.
Kandel, J.; Tayara, H.; Chong, K.T. PUResNet: Prediction of protein-ligand binding sites using deep residual neural network.
J. Cheminform. 2021, 13, 65. [CrossRef] [PubMed]
36.
Zhou, Y.; Jiang, Y.; Yang, Y. AGAT-PPIS: A novel protein-protein interaction site predictor based on augmented graph attention
network with initial residual and identity mapping. Brief. Bioinform. 2023, 24, bbad122. [CrossRef] [PubMed]
37.
Öztürk, H.; Özgür, A.; Ozkirimli, E. DeepDTA: Deep drug-target binding afﬁnity prediction. Bioinformatics 2018, 34, i821–i829.
[CrossRef] [PubMed]
38.
He, T.; Heidemeyer, M.; Ban, F.; Cherkasov, A.; Ester, M. SimBoost: A read-across approach for predicting drug-target binding
afﬁnities using gradient boosting machines. J. Cheminform. 2017, 9, 24. [CrossRef]
39.
Ahmed, A.; Mam, B.; Sowdhamini, R. DEELIG: A Deep Learning Approach to Predict Protein-Ligand Binding Afﬁnity. Bioinform.
Biol. Insights 2021, 15, 11779322211030364. [CrossRef]
40.
Karlov, D.S.; Sosnin, S.; Fedorov, M.V.; Popov, P. graphDelta: MPNN Scoring Function for the Afﬁnity Prediction of Protein-Ligand
Complexes. ACS Omega 2020, 5, 5150–5159. [CrossRef]
41.
Feinberg, E.N.; Sur, D.; Wu, Z.; Husic, B.E.; Mai, H.; Li, Y.; Sun, S.; Yang, J.; Ramsundar, B.; Pande, V.S. PotentialNet for Molecular
Property Prediction. ACS Cent. Sci. 2018, 4, 1520–1530. [CrossRef]
42.
Liyaqat, T.; Ahmad, T.; Saxena, C. TeM-DTBA: Time-efﬁcient drug target binding afﬁnity prediction using multiple modalities
with Lasso feature selection. J. Comput. Aided Mol. Des. 2023, 37, 573–584. [CrossRef]
43.
Wang, C.; Chen, Y.; Zhang, Y.; Li, K.; Lin, M.; Pan, F.; Wu, W.; Zhang, J. A reinforcement learning approach for protein-ligand
binding pose prediction. BMC Bioinform. 2022, 23, 368. [CrossRef]
44.
Nguyen, D.D.; Cang, Z.; Wu, K.; Wang, M.; Cao, Y.; Wei, G.W. Mathematical deep learning for pose and binding afﬁnity prediction
and ranking in D3R Grand Challenges. J. Comput. Aided Mol. Des. 2019, 33, 71–82. [CrossRef]
45.
Wang, L.; Zhou, Y.; Chen, Q. AMMVF-DTI: A Novel Model Predicting Drug-Target Interactions Based on Attention Mechanism
and Multi-View Fusion. Int. J. Mol. Sci. 2023, 24, 14142. [CrossRef]

## Page 17 (Section: References)

Molecules 2024, 29, 903
17 of 20
46.
Popova, M.; Isayev, O.; Tropsha, A. Deep reinforcement learning for de novo drug design. Sci. Adv. 2018, 4, eaap7885. [CrossRef]
[PubMed]
47.
Gómez-Bombarelli, R.; Wei, J.N.; Duvenaud, D.; Hernández-Lobato, J.M.; Sánchez-Lengeling, B.; Sheberla, D.; Aguilera-
Iparraguirre, J.; Hirzel, T.D.; Adams, R.P.; Aspuru-Guzik, A. Automatic Chemical Design Using a Data-Driven Continuous
Representation of Molecules. ACS Cent. Sci. 2018, 4, 268–276. [CrossRef] [PubMed]
48.
Li, Y.; Zhang, L.; Liu, Z. Multi-objective de novo drug design with conditional graph generative model. J. Cheminform. 2018, 10, 33.
[CrossRef] [PubMed]
49.
Born, J.; Manica, M.; Oskooei, A.; Cadow, J.; Markert, G.; Rodríguez Martínez, M. PaccMann(RL): De novo generation of hit-like
anticancer molecules from transcriptomic data via reinforcement learning. iScience 2021, 24, 102269. [CrossRef]
50.
Kadurin, A.; Nikolenko, S.; Khrabrov, K.; Aliper, A.; Zhavoronkov, A. druGAN: An Advanced Generative Adversarial Autoen-
coder Model for de Novo Generation of New Molecules with Desired Molecular Properties in Silico. Mol. Pharm. 2017, 14,
3098–3104. [CrossRef]
51.
Coley, C.W.; Rogers, L.; Green, W.H.; Jensen, K.F. SCScore: Synthetic Complexity Learned from a Reaction Corpus. J. Chem. Inf.
Model. 2018, 58, 252–261. [CrossRef] [PubMed]
52.
Schoenmaker, L.; Béquignon, O.J.M.; Jespers, W.; van Westen, G.J.P. UnCorrupt SMILES: A novel approach to de novo design.
J. Cheminform. 2023, 15, 22. [CrossRef] [PubMed]
53.
Wang, X.; Gao, C.; Han, P.; Li, X.; Chen, W.; Rodríguez Patón, A.; Wang, S.; Zheng, P. PETrans: De Novo Drug Design with
Protein-Speciﬁc Encoding Based on Transfer Learning. Int. J. Mol. Sci. 2023, 24, 1146. [CrossRef] [PubMed]
54.
Monteiro, N.R.C.; Pereira, T.O.; Machado, A.C.D.; Oliveira, J.L.; Abbasi, M.; Arrais, J.P. FSM-DDTR: End-to-end feedback strategy
for multi-objective De Novo drug design using transformers. Comput. Biol. Med. 2023, 164, 107285. [CrossRef] [PubMed]
55.
Song, T.; Ren, Y.; Wang, S.; Han, P.; Wang, L.; Li, X.; Rodriguez-Patón, A. DNMG: Deep molecular generative model by fusion of
3D information for de novo drug design. Methods 2023, 211, 10–22. [CrossRef]
56.
Macedo, B.; Ribeiro Vaz, I.; Taveira Gomes, T. MedGAN: Optimized generative adversarial network with graph convolutional
networks for novel molecule design. Sci. Rep. 2024, 14, 1212. [CrossRef]
57.
Panapitiya, G.; Girard, M.; Hollas, A.; Sepulveda, J.; Murugesan, V.; Wang, W.; Saldanha, E. Evaluation of Deep Learning
Architectures for Aqueous Solubility Prediction. ACS Omega 2022, 7, 15695–15710. [CrossRef]
58.
Francoeur, P.G.; Koes, D.R. SolTranNet-A Machine Learning Tool for Fast Aqueous Solubility Prediction. J. Chem. Inf. Model. 2021,
61, 2530–2536. [CrossRef]
59.
Zang, Q.; Mansouri, K.; Williams, A.J.; Judson, R.S.; Allen, D.G.; Casey, W.M.; Kleinstreuer, N.C. In Silico Prediction of
Physicochemical Properties of Environmental Chemicals Using Molecular Fingerprints and Machine Learning. J. Chem. Inf. Model.
2017, 57, 36–49. [CrossRef]
60.
Tian, H.; Ketkar, R.; Tao, P. ADMETboost: A web server for accurate ADMET prediction. J. Mol. Model. 2022, 28, 408. [CrossRef]
61.
Schyman, P.; Liu, R.; Desai, V.; Wallqvist, A. vNN Web Server for ADMET Predictions. Front. Pharmacol. 2017, 8, 889. [CrossRef]
[PubMed]
62.
Wei, Y.; Li, S.; Li, Z.; Wan, Z.; Lin, J. Interpretable-ADMET: A web service for ADMET prediction and optimization based on deep
neural representation. Bioinformatics 2022, 38, 2863–2871. [CrossRef] [PubMed]
63.
Deng, D.; Chen, X.; Zhang, R.; Lei, Z.; Wang, X.; Zhou, F. XGraphBoost: Extracting Graph Neural Network-Based Features for a
Better Prediction of Molecular Properties. J. Chem. Inf. Model. 2021, 61, 2697–2705. [CrossRef] [PubMed]
64.
Mayr, A.; Klambauer, G.; Unterthiner, T.; Hochreiter, S. DeepTox: Toxicity prediction using deep learning. Front. Environ. Sci.
2016, 3, 80. [CrossRef]
65.
Li, X.; Xu, Y.; Lai, L.; Pei, J. Prediction of Human Cytochrome P450 Inhibition Using a Multitask Deep Autoencoder Neural
Network. Mol. Pharm. 2018, 15, 4336–4345. [CrossRef]
66.
Shaker, B.; Yu, M.S.; Song, J.S.; Ahn, S.; Ryu, J.Y.; Oh, K.S.; Na, D. LightBBB: Computational prediction model of blood-brain-barrier
penetration based on LightGBM. Bioinformatics 2021, 37, 1135–1139. [CrossRef]
67.
Tang, Q.; Nie, F.; Zhao, Q.; Chen, W. A merged molecular representation deep learning method for blood-brain barrier permeability
prediction. Brief. Bioinform. 2022, 23, bbac357. [CrossRef]
68.
Jang, W.D.; Jang, J.; Song, J.S.; Ahn, S.; Oh, K.S. PredPS: Attention-based graph neural network for predicting stability of
compounds in human plasma. Comput. Struct. Biotechnol. J. 2023, 21, 3532–3539. [CrossRef]
69.
Khaouane, A.; Khaouane, L.; Ferhat, S.; Hanini, S. Deep Learning for Drug Development: Using CNNs in MIA-QSAR to Predict
Plasma Protein Binding of Drugs. AAPS PharmSciTech 2023, 24, 232. [CrossRef] [PubMed]
70.
Zeng, X.; Zhu, S.; Lu, W.; Liu, Z.; Huang, J.; Zhou, Y.; Fang, J.; Huang, Y.; Guo, H.; Li, L.; et al. Target identiﬁcation among known
drugs by deep learning from heterogeneous networks. Chem. Sci. 2020, 11, 1775–1797. [CrossRef] [PubMed]
71.
Wan, F.; Hong, L.; Xiao, A.; Jiang, T.; Zeng, J. NeoDTI: Neural integration of neighbor information from a heterogeneous network
for discovering new drug-target interactions. Bioinformatics 2019, 35, 104–111. [CrossRef]
72.
Luo, Y.; Zhao, X.; Zhou, J.; Yang, J.; Zhang, Y.; Kuang, W.; Peng, J.; Chen, L.; Zeng, J. A network integration approach for
drug-target interaction prediction and computational drug repositioning from heterogeneous information. Nat. Commun. 2017, 8,
573. [CrossRef]

## Page 18 (Section: References)

Molecules 2024, 29, 903
18 of 20
73.
Luo, H.; Wang, J.; Li, M.; Luo, J.; Peng, X.; Wu, F.X.; Pan, Y. Drug repositioning based on comprehensive similarity measures and
Bi-Random walk algorithm. Bioinformatics 2016, 32, 2664–2671. [CrossRef]
74.
Doshi, S.; Chepuri, S.P. A computational approach to drug repurposing using graph neural networks. Comput. Biol. Med. 2022,
150, 105992. [CrossRef] [PubMed]
75.
Zeng, X.; Zhu, S.; Liu, X.; Zhou, Y.; Nussinov, R.; Cheng, F. deepDR: A network-based deep learning approach to in silico drug
repositioning. Bioinformatics 2019, 35, 5191–5198. [CrossRef]
76.
Jiang, H.J.; Huang, Y.A.; You, Z.H. Predicting Drug-Disease Associations via Using Gaussian Interaction Proﬁle and Kernel-Based
Autoencoder. BioMed Res. Int. 2019, 2019, 2426958. [CrossRef]
77.
Ghorbanali, Z.; Zare-Mirakabad, F.; Salehi, N.; Akbari, M.; Masoudi-Nejad, A. DrugRep-HeSiaGraph: When heterogenous
siamese neural network meets knowledge graphs for drug repurposing. BMC Bioinform. 2023, 24, 374. [CrossRef] [PubMed]
78.
Suviriyapaisal, N.; Wichadakul, D. iEdgeDTA: Integrated edge information and 1D graph convolutional neural networks for
binding afﬁnity prediction. RSC Adv. 2023, 13, 25218–25228. [CrossRef]
79.
Segler, M.H.S.; Preuss, M.; Waller, M.P. Planning chemical syntheses with deep neural networks and symbolic AI. Nature 2018,
555, 604–610. [CrossRef]
80.
Liu, B.; Ramsundar, B.; Kawthekar, P.; Shi, J.; Gomes, J.; Luu Nguyen, Q.; Ho, S.; Sloane, J.; Wender, P.; Pande, V. Retrosynthetic
Reaction Prediction Using Neural Sequence-to-Sequence Models. ACS Cent. Sci. 2017, 3, 1103–1113. [CrossRef]
81.
Thakkar, A.; Chadimová, V.; Bjerrum, E.J.; Engkvist, O.; Reymond, J.L. Retrosynthetic accessibility score (RAscore)—Rapid
machine learned synthesizability classiﬁcation from AI driven retrosynthetic planning. Chem. Sci. 2021, 12, 3339–3349. [CrossRef]
82.
Wei, J.N.; Duvenaud, D.; Aspuru-Guzik, A. Neural Networks for the Prediction of Organic Chemistry Reactions. ACS Cent. Sci.
2016, 2, 725–732. [CrossRef]
83.
Coley, C.W.; Barzilay, R.; Jaakkola, T.S.; Green, W.H.; Jensen, K.F. Prediction of Organic Reaction Outcomes Using Machine
Learning. ACS Cent. Sci. 2017, 3, 434–443. [CrossRef]
84.
Gao, H.; Struble, T.J.; Coley, C.W.; Wang, Y.; Green, W.H.; Jensen, K.F. Using Machine Learning To Predict Suitable Conditions for
Organic Reactions. ACS Cent. Sci. 2018, 4, 1465–1476. [CrossRef]
85.
Marcou, G.; Aires de Sousa, J.; Latino, D.A.; de Luca, A.; Horvath, D.; Rietsch, V.; Varnek, A. Expert system for predicting reaction
conditions: The Michael reaction case. J. Chem. Inf. Model. 2015, 55, 239–250. [CrossRef]
86.
You, Z.H.; Li, S.; Gao, X.; Luo, X.; Ji, Z. Large-scale protein-protein interactions detection by integrating big biosensing data with
computational model. BioMed Res. Int. 2014, 2014, 598129. [CrossRef]
87.
Chan, H.C.S.; Shan, H.; Dahoun, T.; Vogel, H.; Yuan, S. Advancing Drug Discovery via Artiﬁcial Intelligence. Trends Pharmacol.
Sci. 2019, 40, 592–604. [CrossRef]
88.
Muhammed, M.T.; Aki-Yalcin, E. Homology modeling in drug discovery: Overview, current applications, and future perspectives.
Chem. Biol. Drug Des. 2019, 93, 12–20. [CrossRef]
89.
Zhang, Y.; Skolnick, J. The protein structure prediction problem could be solved using the current PDB library. Proc. Natl. Acad.
Sci. USA 2005, 102, 1029–1034. [CrossRef]
90.
Tang, T.; Zhang, X.; Liu, Y.; Peng, H.; Zheng, B.; Yin, Y.; Zeng, X. Machine learning on protein-protein interaction prediction:
Models, challenges and trends. Brief. Bioinform. 2023, 24, bbad076. [CrossRef]
91.
Soleymani, F.; Paquet, E.; Viktor, H.; Michalowski, W.; Spinello, D. Protein-protein interaction prediction with deep learning:
A comprehensive review. Comput. Struct. Biotechnol. J. 2022, 20, 5316–5341. [CrossRef]
92.
Li, S.; Wu, S.; Wang, L.; Li, F.; Jiang, H.; Bai, F. Recent advances in predicting protein-protein interactions with the aid of artiﬁcial
intelligence algorithms. Curr. Opin. Struct. Biol. 2022, 73, 102344. [CrossRef]
93.
Tripathi, N.; Goshisht, M.K.; Sahu, S.K.; Arora, C. Applications of artiﬁcial intelligence to drug design and discovery in the big
data era: A comprehensive review. Mol. Divers. 2021, 25, 1643–1664. [CrossRef]
94.
Dhakal, A.; McKay, C.; Tanner, J.J.; Cheng, J. Artiﬁcial intelligence in the prediction of protein-ligand interactions: Recent advances
and future directions. Brief. Bioinform. 2022, 23, bbab476. [CrossRef]
95.
Nicolaou, C.A.; Kannas, C.; Loizidou, E. Multi-objective optimization methods in de novo drug design. Mini Rev. Med. Chem.
2012, 12, 979–987. [CrossRef]
96.
Zhong, F.; Xing, J.; Li, X.; Liu, X.; Fu, Z.; Xiong, Z.; Lu, D.; Wu, X.; Zhao, J.; Tan, X.; et al. Artiﬁcial intelligence in drug design. Sci.
China. Life Sci. 2018, 61, 1191–1204. [CrossRef]
97.
Hessler, G.; Baringhaus, K.H. Artiﬁcial Intelligence in Drug Design. Molecules 2018, 23, 2520. [CrossRef]
98.
Schneider, G.; Funatsu, K.; Okuno, Y.; Winkler, D. De novo Drug Design—Ye olde Scoring Problem Revisited. Mol. Inform. 2017,
36, 1681031. [CrossRef]
99.
Wang, L.; Ding, J.; Pan, L.; Cao, D.; Jiang, H.; Ding, X. Artiﬁcial intelligence facilitates drug design in the big data era. Chemom.
Intell. Lab. Syst. 2019, 194, 103850. [CrossRef]
100. Yang, X.; Wang, Y.; Byrne, R.; Schneider, G.; Yang, S. Concepts of Artiﬁcial Intelligence for Computer-Assisted Drug Discovery.
Chem. Rev. 2019, 119, 10520–10594. [CrossRef]
101. Yu, E.; Xu, Y.; Shi, Y.; Yu, Q.; Liu, J.; Xu, L. Discovery of novel natural compound inhibitors targeting estrogen receptor α by an
integrated virtual screening strategy. J. Mol. Model. 2019, 25, 278. [CrossRef]

## Page 19 (Section: References)

Molecules 2024, 29, 903
19 of 20
102. Zhong, W.; Zhao, L.; Yang, Z.; Yu-Chian Chen, C. Graph convolutional network approach to investigate potential selective Limk1
inhibitors. J. Mol. Graph. Model. 2021, 107, 107965. [CrossRef]
103. Zhou, Y.; Wang, F.; Tang, J.; Nussinov, R.; Cheng, F. Artiﬁcial intelligence in COVID-19 drug repurposing. Lancet Digit. Health
2020, 2, e667–e676. [CrossRef]
104. Pan, X.; Lin, X.; Cao, D.; Zeng, X.; Yu, P.S.; He, L.; Nussinov, R.; Cheng, F. Deep learning for drug repurposing: Methods, databases,
and applications. Wiley Interdiscip. Rev. Comput. Mol. Sci. 2022, 12, e1597. [CrossRef]
105. Dong, J.; Zhao, M.; Liu, Y.; Su, Y.; Zeng, X. Deep learning in retrosynthesis planning: Datasets, models and tools. Brief. Bioinform.
2022, 23, bbab391. [CrossRef] [PubMed]
106. Lee, A.A.; Yang, Q.; Sresht, V.; Bolgar, P.; Hou, X.; Klug-McLeod, J.L.; Butler, C.R. Molecular Transformer uniﬁes reaction
prediction and retrosynthesis across pharma chemical space. Chem. Commun. 2019, 55, 12152–12155. [CrossRef]
107. Yan, X.; Liu, Y. Graph-sequence attention and transformer for predicting drug-target afﬁnity. RSC Adv. 2022, 12, 29525–29534.
[CrossRef]
108. Lee, M. Recent Advances in Deep Learning for Protein-Protein Interaction Analysis: A Comprehensive Review. Molecules 2023,
28, 5169. [CrossRef]
109. Lin, P.; Yan, Y.; Huang, S.Y. DeepHomo2.0: Improved protein-protein contact prediction of homodimers by transformer-enhanced
deep learning. Brief. Bioinform. 2023, 24, bbac499. [CrossRef] [PubMed]
110. Kang, Y.; Elofsson, A.; Jiang, Y.; Huang, W.; Yu, M.; Li, Z. AFTGAN: Prediction of multi-type PPI based on attention free
transformer and graph attention network. Bioinformatics 2023, 39, btad052. [CrossRef]
111. Zhang, P.; Wei, Z.; Che, C.; Jin, B. DeepMGT-DTI: Transformer network incorporating multilayer graph information for Drug-
Target interaction prediction. Comput. Biol. Med. 2022, 142, 105214. [CrossRef]
112. Qian, H.; Lin, C.; Zhao, D.; Tu, S.; Xu, L. AlphaDrug: Protein target speciﬁc de novo molecular generation. PNAS Nexus 2022,
1, pgac227. [CrossRef]
113. Radford, A.; Narasimhan, K.; Salimans, T.; Sutskever, I. Improving Language Understanding by Generative Pre-Training. 2018.
Available online: https://www.mikecaptain.com/resources/pdf/GPT-1.pdf (accessed on 14 January 2024).
114. Wang, Y.; Zhao, H.; Sciabola, S.; Wang, W. cMolGPT: A Conditional Generative Pre-Trained Transformer for Target-Speciﬁc De
Novo Molecular Generation. Molecules 2023, 28, 4430. [CrossRef]
115. Chithrananda, S.; Grand, G.; Ramsundar, B. ChemBERTa: Large-scale self-supervised pretraining for molecular property
prediction. arXiv 2020, arXiv:2010.09885.
116. Devlin, J.; Chang, M.-W.; Lee, K.; Toutanova, K. Bert: Pre-training of deep bidirectional transformers for language understanding.
arXiv 2018, arXiv:1810.04805.
117. Liu, Z.; Roberts, R.A.; Lal-Nag, M.; Chen, X.; Huang, R.; Tong, W. AI-based language models powering drug discovery and
development. Drug Discov. Today 2021, 26, 2593–2607. [CrossRef] [PubMed]
118. Wu, Z.; Jiang, D.; Wang, J.; Zhang, X.; Du, H.; Pan, L.; Hsieh, C.Y.; Cao, D.; Hou, T. Knowledge-based BERT: A method to extract
molecular features like computational chemists. Brief. Bioinform. 2022, 23, bbac131. [CrossRef]
119. Wang, S.; Guo, Y.; Wang, Y.; Sun, H.; Huang, J. Smiles-bert: Large scale unsupervised pre-training for molecular property
prediction. In Proceedings of the 10th ACM International Conference on Bioinformatics, Computational Biology and Health
Informatics, Niagara Falls, NY, USA, 7–10 September 2019; pp. 429–436.
120. Schwaller, P.; Laino, T.; Gaudin, T.; Bolgar, P.; Hunter, C.A.; Bekas, C.; Lee, A.A. Molecular Transformer: A Model for Uncertainty-
Calibrated Chemical Reaction Prediction. ACS Cent. Sci. 2019, 5, 1572–1583. [CrossRef]
121. Andronov, M.; Voinarovska, V.; Andronova, N.; Wand, M.; Clevert, D.-A.; Schmidhuber, J. Reagent prediction with a molecular
transformer improves reaction data quality. Chem. Sci. 2023, 14, 3235–3246. [CrossRef]
122. Schwaller, P.; Petraglia, R.; Zullo, V.; Nair, V.H.; Haeuselmann, R.A.; Pisoni, R.; Bekas, C.; Iuliano, A.; Laino, T. Predicting
retrosynthetic pathways using transformer-based models and a hyper-graph exploration strategy. Chem. Sci. 2020, 11, 3316–3325.
[CrossRef]
123. Mamoshina, P.; Vieira, A.; Putin, E.; Zhavoronkov, A. Applications of Deep Learning in Biomedicine. Mol. Pharm. 2016, 13,
1445–1454. [CrossRef]
124. Lu, J.; Wang, C.; Zhang, Y. Predicting Molecular Energy Using Force-Field Optimized Geometries and Atomic Vector Representa-
tions Learned from an Improved Deep Tensor Neural Network. J. Chem. Theory Comput. 2019, 15, 4113–4121. [CrossRef]
125. Cai, C.; Wang, S.; Xu, Y.; Zhang, W.; Tang, K.; Ouyang, Q.; Lai, L.; Pei, J. Transfer Learning for Drug Discovery. J. Med. Chem. 2020,
63, 8683–8694. [CrossRef]
126. Altae-Tran, H.; Ramsundar, B.; Pappu, A.S.; Pande, V. Low Data Drug Discovery with One-Shot Learning. ACS Cent. Sci. 2017, 3,
283–293. [CrossRef]
127. Krizhevsky, A.; Sutskever, I.; Hinton, G.E. ImageNet classiﬁcation with deep convolutional neural networks. Commun. ACM 2017,
60, 84–90. [CrossRef]
128. Chang, M. AI for Drug Development and Well-Being.
2020.
Available online: http://ctrisoft.net/StatisticiansOrg/AI/
AIforWellbingebook5.5x8.5in.pdf (accessed on 14 January 2024).
129. Erhan, D.; Bengio, Y.; Courville, A.C.; Vincent, P. Visualizing Higher-Layer Features of a Deep Network; University of Montreal:
Montreal, QC, USA, 2009.

## Page 20 (Section: References)

Molecules 2024, 29, 903
20 of 20
130. Ribeiro, M.T.; Singh, S.; Guestrin, C. “Why Should I Trust You?”: Explaining the Predictions of Any Classiﬁer. In Proceedings of
the 22nd ACM SIGKDD International Conference on Knowledge Discovery and Data Mining, San Francisco, CA, USA, 13–17
August 2016; pp. 1135–1144.
131. Lundberg, S.M.; Lee, S.-I. A Uniﬁed Approach to Interpreting Model Predictions. In Proceedings of the Neural Information
Processing Systems, Long Beach, CA, USA, 4–9 December 2017.
Disclaimer/Publisher’s Note: The statements, opinions and data contained in all publications are solely those of the individual
author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to
people or property resulting from any ideas, methods, instructions or products referred to in the content.


---

# Machine-Learning-Guided Peptide Drug Discovery: Development of GLP-1 Receptor Agonists with Improved Drug Properties

- **Authors:** Jens Christian Nielsen, Claudia Hjo Rringgaard, Mads Mo Rup Nygaard, Anita Wester, Lisbeth Elster, Trine Porsgaard, Randi Bonke Mikkelsen, Silas Rasmussen, Andreas Nygaard Madsen, Morten Schlein, Niels Vrang, Kristoffer Rigbolt, Louise S Dalbo Ge
- **Issuer:** Journal of medicinal chemistry
- **Type:** Scientific article
- **Published:** 2024-07-08
- **Language:** en
- **DOI:** 10.1021/acs.jmedchem.4c00417
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38977267/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractPeptide-based drug discovery has surged with the development of peptide hormone-derived analogs for the treatment of diabetes and obesity. Machine learning (ML)-enabled quantitative structure–activity relationship (QSAR) approaches have shown great promise in small molecule drug discovery but have been less successful in peptide drug discovery due to limited data availability. We have developed a peptide drug discovery platform called streaMLine, enabling rigorous design, synthesis, screening, and ML-driven analysis of large peptide libraries. Using streaMLine, this study systematically explored secretin as a peptide backbone to generate potent, selective, and long-acting GLP-1R agonists with improved physicochemical properties. We synthesized and screened a total of 2688 peptides and applied ML-guided QSAR to identify multiple options for designing stable and potent GLP-1R agonists. One candidate, GUB021794, was profiled in vivo (S.C., 10 nmol/kg QD) and showed potent body weight loss in diet-induced obese mice and a half-life compatible with once-weekly dosing.

## Section: Introduction

Peptide-based therapeutics are gaining increasing attention in the pharmaceutical industry. Peptide hormones have both high receptor potency and selectivity, minimizing off-target effects and generally translating into an excellent drug safety and efficacy profile.1,2 These features make endogenous peptides a good starting point for the development of novel peptide therapeutics. However, native unmodified peptides are rarely used as drugs because of their inherent limitations due to their very short systemic half-life and unfavorable physicochemical properties which must be circumvented to develop peptide molecules suitable for therapeutic use.1,2

Early drug discovery phases aim to improve the properties of candidate molecules by modifying their chemical structure. Such improvements can be achieved by rational design using an iterative and often laborious approach, where small batches of compounds are screened in multiple rounds of optimization. In contrast, when larger data sets are available, it is useful to construct mathematical models that capture the quantitative structure–activity relationship (QSAR) to guide drug design. QSAR models have been widely used in the development of small molecule therapeutics e.g., to discover novel binders3 and elute chemical motifs necessary for binding.4 For peptide drug discovery, however, data are often sparse, and this has limited the use of machine learning (ML) for QSAR optimization. The amount and composition of data are crucial parameters for QSAR methods,5 which is why it is advantageous to generate data that are specifically designed for modeling purposes.

Glucagon-like peptide-1 (GLP-1) is an endogenous 30-amino acid peptide hormone produced by enteroendocrine L-cells and secreted into the hepatic portal in response to food intake. By activating GLP-1 receptors in the pancreas, native GLP-1 serves as an incretin hormone stimulating insulin release and inhibiting glucagon secretion.6 In addition, GLP-1 is an important appetite regulator by activating central GLP-1 receptors (GLP-1R).7 In line with this, long-acting GLP-1R agonists such as semaglutide have been shown to be important tools in the treatment of diabetes and obesity.8,9 However, GLP-1 is known to self-assemble into amyloid fibrils and the intrinsic physical instability of GLP-1 poses a significant challenge in synthesis and formulation.10,11

Recent drug development efforts have taken advantage of the varying degrees of sequence homology of GLP-1, glucagon, and glucose-dependent insulinotropic polypeptide (GIP) to engineer unimolecular dual or triple agonists targeting receptors of GLP-1, glucagon, and GIP. This approach has proven to be a successful concept for treatment intervention in diabetes and obesity.12−17

Alternatively, one could further envision to exploit sequence homology to obtain beneficial peptide properties not only in terms of receptor pharmacology, but also from a synthesis and/or formulation perspective.18

Secretin is a 27-amino acid peptide hormone that together with GLP-1 belongs to the glucagon superfamily of structurally related peptide hormones all targeting family B G-protein coupled receptors (GPCRs).19 This family of peptides is linear peptides comprising 25 or more residues allowing them to span two key receptor domains. The C-terminal region of the peptides binds to the extracellular domain of their respective receptor whereafter the N-terminal region interacts with the core domain of the receptor enabling receptor activation.20 The sequence identity of secretin and GLP-1 is shown in Table 1.

Contrary to other peptides of the glucagon family, such as GLP-1, secretin is not reported to aggregate.21 Thus, secretin could serve as the starting backbone with improved physicochemical properties compared to GLP-1.

The main physiological role of secretin is to regulate water homeostasis and bicarbonate secretion from the exocrine pancreas and inhibit gastric acid secretion by activating the secretin receptor (SCTR),19 i.e., endogenous activities we intended not to activate.

Hence, we aimed to leverage the more favorable physicochemical properties of secretin to develop a selective and physicochemical stable GLP-1R agonist based on the secretin backbone. With this aim, we exploited an innovative ML-based peptide drug discovery platform termed streaMLine and demonstrated how streaMLine effectively facilitates accelerated development of novel peptide-based therapeutics by rigorous design and ML-driven analysis of large peptide libraries.

## Section: Results

Overview of the data generation and data analysis workflow of the streaMLine platform. Initially a systematic library of peptides is designed, typically on the order of hundreds to thousands of peptides. The crude library of peptides are prepared using solid-phase-peptide synthesis (SPPS) and cleaved from the resin. Failed peptide samples are identified by high-resolution mass spectrometry and excluded from the analysis. A panel of high-throughput assays for determining receptor potency and physicochemical properties at different pH levels are measured. For each assay end point, a random forest model is trained and used for inferring key amino acids substitutions that determine peptide properties.

Schematic representation of the parallelized development process for generating a selective and stable GLP-1R agonist based on the secretin backbone. The two-step process for converting secretin into a preclinical drug candidate. First, a minimal GLP-1R agonist was developed by introducing only necessary GLP-1 residues to provide activation of GLP-1R. Second, a parallelized workflow was initiated where a deep mutational scan, a glutamate scan, and a lipidation scan provided a blueprint for generating various soluble, physically stable, and half-life extended GLP-1R agonist.

Overview of substitution-effects from a GLP-1 dial-in scan in the secretin backbone. (A) Effect of introducing GLP-1 residues into the secretin backbone. For each assay end point, a random forest model was trained on 768 peptides and used to compute SHAP values determining the level of contribution of each amino acid substitution. Delta mean SHAP values denote the contribution of substituting the secretin residue with the corresponding GLP-1 residue. (B) Detailed overview of SHAP values for selected positions, where substitutions were introduced to obtain analogs with dual GLP-1R and SCTR potency. Small points denote SHAP values per individual peptide and large points denote mean SHAP value.

Overview of substitution-effects from a deep mutational scan (DMS) in a secretin derived GLP-1R and SCTR dual agonist. (A) Effect of single mutations in all positions. For GLP-1R and SCTR potency, random forest models were trained on 1152 peptides encoded using z-scales.23 From the models, the effect of single mutations was computed to normalize for assay batch effects. (B) Detailed overview of selected positions highlighting the effect of individual substitutions.

Overview of substitution-effects from glutamate scan and half-life extender (HLE) scan in a secretin-derived GLP-1R and SCTR dual agonist. (A) Effect of introducing HLEs or glutamate. For each assay end point, a random forest model was trained on 576 peptides and used to compute SHAP values determining the level of contribution of each amino acid substitution. Delta mean SHAP values denote the contribution of substituting the backbone residue with either a glutamate or HLE. (B) Detailed overview of SHAP values for selected positions that tolerate HLE derivatization or glutamate substitution for improving half-life and solubility, respectively. Small points denote SHAP values per individual peptide and large points denote mean SHAP value.

Overview of substitution-effects from selected substitutions in secretin derived selective GLP-1R agonist. Effect of combining selected substitutions identified in the deep mutational scan, HLE scan, and glutamate scan. For each assay end point a random forest model was trained on 192 peptides and used to determine SHAP values determining the level of contribution of each amino acid substitution. Mean SHAP values denote the contribution of each substitution relative to the data set mean.

GUB021794 dose dependently reduces body weight and adipose tissue mass in DIO mice. DIO mice were treated subcutaneously once daily (QD) with vehicle, semaglutide (10 nmol/kg), and ascending doses of GUB021794 (3, 10, or 30 nmol/kg) for 28 days. (A) Body weight. (B) Body weight change (% of day 1) at the end of the study. (C) Daily food intake. (D) Cumulative food intake day 28. (E) Fat mass day 28. (F) Plasma exposure day 29, (samples taken 24 h after dosing). Values expressed as mean of n = 10 + SEM. Dunnett’s test one-factor linear model. *: P < 0.05, **: P < 0.01, ***: P < 0.001 compared to Vehicle.

## Section: Results › The streaMLine Platform

The streamline platform is a drug development tool where peptide libraries are designed, synthesized, and screened to provide large data sets suitable for machine learning (ML)-enabled quantitative structure–activity relationship (QSAR) approaches. An overview of the learning cycles in the streamline platform is illustrated in Figure 1.

In the streaMLine platform, peptides are synthesized using solid-phase peptide synthesis (SPPS) in a plate format. The crude peptide libraries are screened directly in functional potency assays and in preformulation assays for determination of, for example, fibrillation and solubility. Each peptide library is analyzed by using high-resolution mass spectrometry (HRMS) to determine purity. The average purity per library ranges between 30 and 50%, and peptide samples with less than 10% purity are excluded from further analysis.

The peptide libraries are designed in a highly systematic manner, where each substitution is observed multiple times in combination with other substitutions. Typically, peptide libraries consist of hundreds to thousands of peptides, which enables robust evaluation of each substitution in multiple chemical contexts, i.e., different backbones. The peptide sequences together with assay data are used as training data to construct random forest models22 describing the relationship between peptide sequence and assay end point. In the training data, the systematic peptide library is encoded using amino acid descriptors (z-scales23 or one-hot encoding), and potential laboratory batch effects are incorporated in the model to normalize, e.g., synthesis and assay plate differences. For each assay end point, a new model is trained and used for inferring the key amino acid substitutions affecting the end point. Model inference is done either by (1) correcting assay data for batch effects and amino acid similarity and thereby computing normalized assay measurements for individual peptides, (2) or by computing Shapley Additive explanation (SHAP) values.24 SHAP values are used to explain the effect of each amino acid substitution on the end point and can thus be used to infer the key drivers in the data set. After model inference, the most promising substitutions are assessed in a new peptide library design.

Data points obtained on crude peptides are challenging to interpret individually, but in the context of the systematically designed peptide libraries, the random forest model provides accurate guidance for identifying the effect of substitutions. The performances of all models generated in this study are given in Figure S1.

Overview of the data generation and data analysis workflow of the streaMLine platform. Initially a systematic library of peptides is designed, typically on the order of hundreds to thousands of peptides. The crude library of peptides are prepared using solid-phase-peptide synthesis (SPPS) and cleaved from the resin. Failed peptide samples are identified by high-resolution mass spectrometry and excluded from the analysis. A panel of high-throughput assays for determining receptor potency and physicochemical properties at different pH levels are measured. For each assay end point, a random forest model is trained and used for inferring key amino acids substitutions that determine peptide properties.

## Section: Results › Development of Dual GLP-1R-SCTR Agonists

We applied the streaMLine platform to generate selective GLP-1R agonists with suitable physicochemical parameters starting from the secretin backbone.

The native secretin peptide has no GLP-1R potency, hence to identify both desired substitutions a starting point with some GLP-1R potency was needed. We therefore aimed at generating first a dual GLP-1R-SCTR agonist that could be used as an intermediate for further optimization (Figure 2).

A peptide library was designed to evaluate the effect of introducing GLP-1 residues into the native secretin. Nonconserved residues (position 2–3, 9–10, 12–14, and 17–25), were changed into the corresponding GLP-1 residue, one at a time or in combinations (Table 1). The library (768 peptides) was screened by determining GLP-1R and SCTR potency (EC50), fibril formation (ThT assay), and solubility (turbidity), and random forest models were trained to determine the relationship between measured end points and the amino acid sequence of peptides. From these models, we computed SHAP values to determine the level of contribution of each substitution.22 Substitutions with positive SHAP values increase the end point, while substitutions with negative SHAP values decrease the end point.

Amino acid positions 2, 9, 18, and 22 had the highest positive SHAP values for GLP-1R EC50, thus being critical for improving GLP-1R potency. Conversely, positions 3, 9, 10, 14, and 19 exhibited the most negative SHAP values for SCTR EC50, hence being critical for abolishing SCTR potency or enhancing GLP-1R selectivity (Figure 3A).

In addition to potency determination, the propensity for fibril formation and a reduction in solubility was most pronounced when mutating amino acid positions 12, 14, 18, 19, 21, 23, and 25. The introduction of GLP-1 residues at these positions could thus negatively affect the physicochemical properties of a peptide (Figure 3B).

Based on these learnings, five substitutions were introduced in the secretin backbone to achieve an agonist with dual activity on GLP-1R and SCTR (Table 1). Mutations 9D, 18A, and 22F increased GLP-1R potency. Likewise, 2A was found to increase the GLP-1R potency. The substitution of alanine for 2-aminoisobutyric acid (Aib) is well-known to prevent DPP-4 proteolytic cleavage of the GLP-1 backbone without compromising GLP-1R potency9,25 hence 2Aib was introduced. The 3E mutation prevented the isomerization of the native aspartic acid residue in secretin without influencing receptor potency. Next, a comprehensive sequence exploration was performed on the dual GLP-1R-SCTR agonist, i.e., a deep mutational scan.

Schematic representation of the parallelized development process for generating a selective and stable GLP-1R agonist based on the secretin backbone. The two-step process for converting secretin into a preclinical drug candidate. First, a minimal GLP-1R agonist was developed by introducing only necessary GLP-1 residues to provide activation of GLP-1R. Second, a parallelized workflow was initiated where a deep mutational scan, a glutamate scan, and a lipidation scan provided a blueprint for generating various soluble, physically stable, and half-life extended GLP-1R agonist.

Overview of substitution-effects from a GLP-1 dial-in scan in the secretin backbone. (A) Effect of introducing GLP-1 residues into the secretin backbone. For each assay end point, a random forest model was trained on 768 peptides and used to compute SHAP values determining the level of contribution of each amino acid substitution. Delta mean SHAP values denote the contribution of substituting the secretin residue with the corresponding GLP-1 residue. (B) Detailed overview of SHAP values for selected positions, where substitutions were introduced to obtain analogs with dual GLP-1R and SCTR potency. Small points denote SHAP values per individual peptide and large points denote mean SHAP value.

## Section: Results › Development of Selective GLP-1R Agonists

A deep mutational scan (DMS) was designed such that all-natural amino acids (except cysteine and methionine) were introduced in all sequence positions, either as single mutations or as double mutations. The library consisted of 1152 peptides, which were screened for GLP-1R and SCTR potency. Based on these data, we trained random forest models on the relationship between all assay end points and the peptide amino acid sequence. The models were used to normalize for batch effects (synthesis and assay plate) and the resulting pEC50 values for each single mutant are shown in Figure 4.

The DMS identified several receptor-selectivity-promoting substitutions. For each position, substitution maps were obtained allowing us to navigate toward desired properties, including GLP-1R potency and/or improved receptor selectivity. Rather than identifying a single compound with desired properties through an iterative design process, the DMS generated a solution space of possible amino acid substitutions from which peptide candidates could be designed and synthesized. A selection of substitutions is described below.

We identified amino acid positions 9, 12, and 25 where substitutions could significantly improve GLP-1R selectivity by increasing GLP-1R potency and decreasing SCTR potency (Figures 4A, B and S2). At position 12, several substitutions improved GLP-1R selectivity. 12Y most effectively improved GLP-1R potency and reduced SCTR potency, whereas 12E only reduced SCTR potency. Aromatic residues 25H, 25F, 25Y, and 25W improved GLP-1R potency while also reducing SCTR potency, with 25H being the most effective. At position 9, only the native GLP-1 residue 9D improved potency and selectivity.

In addition, amino acid positions 10, 14, and 19 were identified to improve selectivity by decreasing SCTR potency with a neglectable effect on GLP-1R potency (Figures 4A, B and S2). 10I and 10V reduced SCTR potency without significantly compromising GLP-1R potency. A similar effect was seen by substituting position 14 to F, Y, or L.

Positions 16, 18, and 22 could be substituted to enhance GLP-1R selectivity. For position 16, all mutations, except P, increased GLP-1R potency (Figure S2). For positions 18 and 22, 18A, 18Aib, 18L, 18, 22F, 22W, and 22Y considerably improved GLP-1R potency while only marginally affecting SCTR potency.

Overview of substitution-effects from a deep mutational scan (DMS) in a secretin derived GLP-1R and SCTR dual agonist. (A) Effect of single mutations in all positions. For GLP-1R and SCTR potency, random forest models were trained on 1152 peptides encoded using z-scales.23 From the models, the effect of single mutations was computed to normalize for assay batch effects. (B) Detailed overview of selected positions highlighting the effect of individual substitutions.

## Section: Results › Improving Solubility and Conjugation of Fatty Acid

In parallel with DMS, we systematically investigated the effect and tolerability of glutamate substitution and derivatization with half-life extenders (HLEs) in our dual GLP-1R-SCTR agonist. Glutamate substitutions can be used to modulate the isoelectric point of a peptide, thereby improving solubility at the desired formulation pH.26 Fatty acid conjugation is a well-described technology broadly applied to extend the half-life of peptides from minutes to hours. Native secretin and GLP-1 have reported half-lives in the range of 2–4 min.27,28 Conjugation with fatty diacids facilitates strong binding to serum albumin, thus reducing renal clearance and enzymatic degradation.28,29

Fatty acid conjugation was investigated by attachment to the epsilon nitrogen of lysines via linker moieties. The combined fatty acid and linker is here referred to as the half-life extender (HLE). Six different HLEs were evaluated in each position representing different lengths of fatty diacids, octadecanedioic acid (C18DA) and eicosanedioic acid (C20DA), and varying combinations of linker moieties, L-γ-glutamyl (gGlu) and 3,8-dioxa-aminooctanoic acid (OEG).

A library of 576 peptides was designed where each HLE at each position was examined in backbones comprising 0, 1, or 2 glutamate mutations. All positions were screened, except a few positions in the pharmacophore essential for receptor activation. For the glutamate substitution screening, positions 1–5, 7, and 8 were excluded, with position 15 already being a glutamate. For the HLE screening, positions 1–5, 7–9, 18, and 22 were excluded. The library was screened for GLP-1R and SCTR potency and turbidity. For each end point, we computed SHAP values to determine the contribution of each mutation relative to the backbone residue (Figure 5).

Evaluating the effect of glutamate mutations on GLP-1R potency revealed several amino acid positions where glutamate was tolerated, i.e., positions 12, 16, 17, 19, 20, 21, 24, 25, and 27. Position 12, 16, and 24 were found to have a positive impact on GLP-1R potency compared to the backbone residue. Among these positions, we found the largest reduction in turbidity from introducing 16E and 24E, indicating improved solubility (Figure 5B).

For the HLEs, we found no major difference in potency across the different fatty acids and/or linker combinations and therefore analyzed the different HLEs as a single substitution. Evaluating the effect of attaching HLEs on the GLP-1R potency revealed several positions where HLEs were tolerated, i.e., positions 10, 12, 14, 16, 17, 20, 21, 24, 25, and 27. For positions 12, 14, and 16, the attachment of HLEs was found to have positive effects on GLP-1R potency compared to the backbone residue, with positions 12 and 14 also inducing GLP-1R selectivity. This selectivity effect of positions 12 and 14 was consistent with the observations from the DMS, where GLP-1R selectivity could also be improved by mutating these positions (Figure 4). Importantly, no effect on turbidity was observed when HLEs were conjugated to positions 12 (Figure 5A) and 14 (Figure 5A, B).

Overview of substitution-effects from glutamate scan and half-life extender (HLE) scan in a secretin-derived GLP-1R and SCTR dual agonist. (A) Effect of introducing HLEs or glutamate. For each assay end point, a random forest model was trained on 576 peptides and used to compute SHAP values determining the level of contribution of each amino acid substitution. Delta mean SHAP values denote the contribution of substituting the backbone residue with either a glutamate or HLE. (B) Detailed overview of SHAP values for selected positions that tolerate HLE derivatization or glutamate substitution for improving half-life and solubility, respectively. Small points denote SHAP values per individual peptide and large points denote mean SHAP value.

## Section: Results › Fine-Tuning Potency, Selectivity, and Physicochemical Properties

Previous sections described our parallel peptide development process. The conjugation of HLEs could dramatically alter the properties of a peptide.26 We therefore set out to investigate if an HLE was compatible with positions and substitutions found to be selectivity-inducing in the deep mutational scan. Furthermore, this library would enable us to rank the mutations relative to each other and according to desired end points to identify an optimal combination of substitutions providing a selective GLP-1R agonist with desired physicochemical properties. We designed a library of 192 compounds where selected substitutions were evaluated at positions 3, 10, 12, 18, 19, and 21 in the dual agonist backbone (Table 1) being lipidated at position 14 with the HLE: C18DA-gGlu-2xOEG. The selected substitutions all induce selectivity in differing degrees, while some also have different physicochemical properties, such as opposite charges, hydrophobicity, helix-inducing effect, etc. In addition to receptor potency, we also assessed the solubility and the propensity for forming amyloid fibrils using a Thioflavin T (ThT) assay. We trained random forest models for each end point and calculated SHAP values to determine the contribution of each mutation to the relevant end points in a lipidated backbone (Figure 6).

In terms of selectivity, we found that 10V and 12Y provided the greatest positive effect by increasing the GLP-1R potency and decreasing the SCTR potency. For 12Y this also led to increased turbidity, meaning that this mutation should be accompanied by mutations that improve solubility.

Interestingly, three mutations were identified to diminish the propensity for fibril formation, 18Aib, 19Aib, and 21E, where the two former did not affect potency on the two receptors. We further used SHAP values to determine the interaction effect of these mutations that prevent fibril formation and found that the reduction in fibril formation was not additive when combining 18Aib and 19Aib (Figure S3). Thus, only one of the mutations is necessary to provide a reduction in fibrillation propensity.

Overview of substitution-effects from selected substitutions in secretin derived selective GLP-1R agonist. Effect of combining selected substitutions identified in the deep mutational scan, HLE scan, and glutamate scan. For each assay end point a random forest model was trained on 192 peptides and used to determine SHAP values determining the level of contribution of each amino acid substitution. Mean SHAP values denote the contribution of each substitution relative to the data set mean.

## Section: Results › Design and Characterization of Final Candidate

Based on all of the substitution options identified, we designed GUB021794. The peptide sequence is shown in Table 1. We aimed for a peptide candidate with minimal (<10 fold) GLP-1R potency loss compared to native GLP-1 but with a 10,000-fold selectivity ratio (GLP-1R over SCTR). The peptide candidate should be soluble, chemically- and physically stable at neutral pH and have a pharmacokinetic profile compatible with once-weekly dosing in humans. The in vitro characterization and pharmacokinetic properties of GUB021794 are summarized in Table 2. GUB021794 is potent and selective with a GLP-1R potency of 0.018 nM and an hSCTR potency of 190 nM.

For GUB021794, we modified the dual-acting backbone at positions 10, 12, 14, 16, 18, 24, and 25. The pronounced GLP-1R potency and high selectivity were achieved by combining substitutions identified in the DMS to have a positive effect on those end points. From the DMS (Figure 4), we identified positions where substitutions could induce selectivity by decreasing SCTR potency, while also improving GLP-1R potency or not significantly impacting GLP-1R potency. For this design, we decided to pursue 12Y and 25H as both were found to improve GLP-1R potency while also decreasing SCTR potency. 10V was introduced to further decrease SCTR potency without significantly reducing GLP-1R potency. In the glutamate scan (Figure 5), we identified two positions where glutamate had a positive impact on GLP-1R potency while also decreasing the turbidity of the peptides. Hence, glutamates were introduced in positions 16 and 24 to achieve a solubility of at least 10 mg/mL. The HLE scan (Figure 5) identified two positions, 12 and 14, where the attachment of a HLE-induced selectivity without compromising solubility. For the design of GUB021794, the HLE was attached to position 14 to improve GLP-1R potency and selectivity, while maintaining high solubility. Finally, we identified two positions where Aib was found to decrease the propensity for forming amyloid fibrils (Figure 6). In GUB021794, 18Aib was introduced to preserve the nonfibrillating properties at neutral pH.

While improving solubility and potency, the substitution of positions 24 and 25 additionally removes a sequence motif, QG, prone to cause chemical instability due to the potential deamidation of glutamine positioned next to glycine. Additionally, the isomerization of aspartic acid was addressed by substituting aspartic acid in position 3 for glutamic acid and by introducing the sterically hindered valine in position 10 next to 9D. Therefore, we obtain a candidate with high chemical stability at neutral pH.

Based on the sequence homology of peptides in the glucagon superfamily of structurally related peptide hormones, GUB021794 was tested for cross-reactivity toward other receptors in the family. GUB021794 showed no activation of the GIPR, GLP-2R, or the GCGR when tested at concentrations up to 3000 nM (Table S2).

The albumin binding affinity of fatty diacids correlates with the length of the fatty diacids; C18- and C20 diacids have the highest affinity.29 A C20DA-gGlu-2xOEG has previously been described to provide a once-weekly dosing regimen in humans12 while 2Aib is known to protect against DPP-4 proteolytic cleavage.9,25 Thus, to achieve a long-acting drug candidate compatible with once-weekly dosing, we attached C20DA-gGlu-2xOEG to position 14, while 2Aib was introduced to prevent DPP-4 proteolytic cleavage.

GUB021794 demonstrated a prolonged pharmacokinetic half-life of 22 h after intravenous dosing in rats. Such a pharmacokinetic profile has previously been shown to translate to a once-weekly pharmacokinetic profile in humans.29,30

## Section: Results › Metabolic Effects of GUB021794 in DIO Mice

GUB021794 was characterized in a mouse model of diet-induced obesity (DIO). DIO mice were treated subcutaneously once daily with vehicle, semaglutide (10 nmol/kg), or GUB021794 (3, 10, or 30 nmol/kg) for 28 days. 28-day treatment with GUB021794 promoted a dose-dependent reduction in body weight, on par with an equimolar dose (10 nmol/kg) of semaglutide (Figure 7A, B). Food intake (Figure 7C) was dose-dependently reduced throughout the study with maximal effect on treatments days 2–3 (Figure 7D). The marked reduction in body weight and food intake was reflected by a substantial reduction in whole-body adipose tissue mass (Figure 7E). Plasma exposure in DIO mice (Figure 7F) was dose-dependent and supported the extended half-life of GUB021794.

Overall, the preclinical data demonstrate that GUB021794 is a potent long acting GLP-1R agonist promoting robust body weight loss in DIO mice comparable to clinically approved GLP-1R agonists, such as semaglutide.31,32

GUB021794 dose dependently reduces body weight and adipose tissue mass in DIO mice. DIO mice were treated subcutaneously once daily (QD) with vehicle, semaglutide (10 nmol/kg), and ascending doses of GUB021794 (3, 10, or 30 nmol/kg) for 28 days. (A) Body weight. (B) Body weight change (% of day 1) at the end of the study. (C) Daily food intake. (D) Cumulative food intake day 28. (E) Fat mass day 28. (F) Plasma exposure day 29, (samples taken 24 h after dosing). Values expressed as mean of n = 10 + SEM. Dunnett’s test one-factor linear model. *: P < 0.05, **: P < 0.01, ***: P < 0.001 compared to Vehicle.

## Section: Discussion

In this study, we demonstrated the capability of the streaMLine platform to accelerate the drug discovery process of peptide pharmaceuticals. We systematically explored secretin as a peptide backbone to generate potent, selective, and long-acting GLP-1R agonists without the intrinsic physical instability previously reported for GLP-1.10,11 A total of 2688 peptides were synthesized, screened, and analyzed using an ML-guided approach to map out a solution space for generating GLP-1R agonists derived from the secretin backbone. Based on this solution space, we designed and characterized a novel GLP-1R agonist, GUB021794, that showed potent body weight loss in DIO mice, a pharmacokinetic profile compatible with once-weekly dosing in humans, and beneficial physicochemical properties.

The key features employed in the streaMLine platform are (1) systematic peptide library design where each mutation is observed multiple times in multiple different backbones, (2) analysis of large libraries consisting of 100–1000 s of crude peptides, and (3) ML-guided peptide design. The screening of peptide crudes leads to faster data generation, as the laborious peptide purification following SPPS can be omitted. This leads to faster generation of lead molecules as well as potential identification of better compounds as a larger chemical space can be screened using the same amount of resources. Despite the contribution of synthesis byproducts in the individual assay measurements of the peptide crudes, we observe that these contributions have a negligible effect on the overall data interpretation when analyzed as part of a larger systematic peptide library design.

Following the crude screening campaign of this study, we subsequently purified and profiled GUB021794, and verified the conclusions obtained from the crude libraries. Aside from verifying the conclusions obtained during the crude screenings, GUB021794 also demonstrated that the thorough screening approach enabled the generation of a very potent therapeutic peptide. Despite being derived from the alternative starting point secretin, GUB021794 showed a weight-lowering effect in DIO mice on par with semaglutide, a clinically approved GLP-1 receptor agonists.31,32

In addition to verifying our screening approach by in-depth characterization of GUB021794, several of the key amino acid substitutions identified in this study have been reported previously. For example, the amino acid positions being important for GLP-1R potency (Figure 2A), agreed with previous studies reporting the high importance of phenylalanine in position 2233 and loss in GLP-1R potency when introducing 2S34 and 9E into a GLP-1 context.25 Furthermore, we found position 19 to be important for SCTR potency in agreement with previous SAR efforts on the secretin backbone.35 The physicochemical screening enabled the identification and validation of mutations associated with fibril formation of GLP-1R agonists. We identified three substitutions preventing fibril formation, 18Aib, 19Aib, and 21E which could be responsible for the formation of amyloid fibrils of GLP-1R agonists previously reported.10,11

Previous studies using QSAR for peptide optimization have been limited to case studies on peptide families with large data sets publicly available such as antimicrobial peptides (AMPs),36 Major histocompatibility complex (MHC)37 and antitumor activity of peptides.38 Other related studies have extracted information about QSAR from smaller publicly available data sets. Deng et al. collected a data set of 141 unique angiotensin-converting enzyme (ACE) inhibitory dipeptides, and fitted a regression model to IC50 values with model predictions being validated by synthesis and in vitro testing of five novel ACE inhibitory dipeptides.39 Although not evaluating the physicochemical properties of the developed peptides, the study by Deng et al. highlights the great potential of peptide QSAR, even based on a limited data set. Our study demonstrates the importance of co-optimizing potency and physicochemical properties to avoid developing potent but unstable peptides.

In addition, we have demonstrated how the platform allows multiparameter screening in a parallelized workflow, thus enabling timeline-efficient identification of learnings to obtain peptides with drug properties early in a project. This accelerated approach further enables fast evaluation of the in vitro/in vivo correlation. In case, the peptide design needs re-evaluation, and the already generated data sets provide alternative solutions to be evaluated without significant timeline delay.

While the aim of the present work was to dial out the secretin receptor potency and leverage the more favorable physicochemical properties of secretin, the streaMLine platform is highly applicable for the development of other peptide-based therapies such as polyagonists targeting multiple receptors, since it enables fine-tuning potency on multiple receptors and allows for exploration of a large chemical solution space. Another application of streaMLine could be the development and potency optimization of nonendogenous peptides identified de novo by display technologies including mRNA display,40 or in the development of peptides containing noncanonical amino acids.41 Recent advances in artificial intelligence (AI) with pretrained deep learning models such as AlphaFold42 and protein language models (PLMs)43 ,44 have enabled improved prediction of protein and peptide properties. For example, de novo design of protein binders has been drastically improved recently45 making peptide-based therapies approachable for previously undruggable targets. Applying QSAR methods as demonstrated in this study could aid in quickly advancing de novo peptide hits to the clinical stage.

## Section: Conclusions

In summary, we have developed an ML-based drug discovery platform to systematically identify design solutions for optimizing peptide-based drugs. As a validation, we exploited the secretin peptide backbone as a scaffold to determine a solution space for designing novel GLP-1R agonists with a selective receptor profile and improved physicochemical properties. This unprecedented QSAR approach enables accelerated development of peptide drug candidates on multiple parameters and demonstrates a novel approach that can be applied for future developments of peptide drug candidates.

## Section: Experimental Section › General Procedure for Peptide Library Synthesis

Peptide libraries were synthesized using standard Fmoc-based solid phase methods on a SyroII fully automated parallel peptide synthesizer (MultiSynTech GmbH, Germany) equipped with a heating block. Tentagel S RAM resin with a loading of 0.23–0.25 mmol/g (Rapp polymer GmbH, Germany) was used. Fmoc deprotection was performed in two stages by treating the resin with 40% piperidine/DMF (0.2 M HOBt (1-hydroxybenzotriazole)) for 3 min at 45 °C followed by 20% piperidine/DMF (0.1 M HOBt) for 7 min at 75 °C. Asp, Cys, and His residues were Fmoc-deprotected at room temperature; i.e. 40% piperidine/DMF (0.2 M HOBt) for 3 min followed by 20% piperidine/DMF (0.1 M HOBt) for 15 min. Coupling was performed using 0.5 M Fmoc-amino acid in 0.5 M oxyma in DMF (except His which was dissolved in NMP) added in 5-fold excess to the resin and activated by 5-fold DIC (N,N′-diisopropyl-carbodiimide). Coupling conditions were single or double couplings for 15 min at 75 °C, except for His and Cys residues, which were double coupled for 15 min at 50 °C. Also, amino acids coupled after Aib were double coupled. The resin was washed 5× with DMF after Fmoc deprotection and 3× after couplings.

For peptides lipidated at the lysine residue, Boc-protected amino acid was incorporated as the N-terminal residue, and the lipidation position was incorporated as lysine (Mtt). The Mtt group (4-methyl-trityl) was removed by treating the resin 3 times with 75% HFIP (1,1,1,3,3,3-hexafluoro-propan-2-ol), 5% TIPS in DCM (dichloromethane) for 10 min. The resin was washed with 10% DIPEA in DCM, followed by a 3× DMF wash. The linker residue(s) were coupled to the epsilon-amino group of the deprotected lysine using double- or triple-standard coupling conditions prior to coupling the mono-t-butyl-protected fatty diacid. The fatty acid was double coupled using 2 equiv building blocks.

For N-terminal lipidated peptides, linker residues and mono-t-butyl protected fatty diacid were coupled to the N-terminus using the conditions described above.

After synthesis, the resin was washed with DCM and dried, and the polypeptide was cleaved from the resin by a 45 min treatment with TFA (trifluoroacetic acid)/TES (triethylsilane)/DODT(2,2′-(ethylenedioxy)diethanethiol)/water (93/2.5/2.5/2.0) at 40 °C followed by precipitation and wash using cold diethyl ether.

## Section: Experimental Section › General Procedure for Peptide Library Synthesis › Crude Peptide Libraries

The peptides were characterized by HR-MS (Waters, Denmark) and quantified by LC-CAD (ThermoFisher Scientific, Denmark). Finally, the crude peptide libraries were lyophilized.

## Section: Experimental Section › General Procedure for Peptide Library Synthesis › Purified GUB021974

The crude peptide was dissolved in acetonitrile/water and purified by reverse phase HPLC using a Waters preparative HPLC with C18 column (Reprosil Gold 200 Å, 5 μm, 30 mm × 250 mm), preparative pumps (waters 2545), UV/vis detector (Waters 2489) and a Waters fraction collector III. The mobile phase was run with a gradient of buffer A (0.1% TFA in H2O) and buffer B (0.1% TFA in acetonitrile at a flow rate of 20 mL/min at room temperature). Relevant fractions were analyzed, pooled, and lyophilized. Finally, the peptide was freeze-dried using a Telstar benchtop freeze-drieder. Peptide purity and mass were determined by analytical RP-HPLC-MS on an ACQUITY UPLC Peptide CSH C18 column (Waters, ACQUITY UPLC Peptide CSH, C18, 130 Å, 1.7 μm, 2.1 mm × 100 mm) using a Waters Acquity HPLC System equipped with a 3100 Mass Detector. Analysis was performed by gradient elution with buffer A (0.3% TFA in H2O) and buffer B (0.3% TFA in acetonitrile) at a temperature of 40 °C (gradients used were 40–60%B over 14 min). GUB021794: purity = 95%; calc. mass: 3862.3871; m/z = 1288.2 (m + 3/3).

## Section: Experimental Section › In Vitro Functional Assay: General Procedure for the Determination of hGLP-1R Potency

A CHO-K1 cell line stably overexpressing the hGLP-1R was obtained from Euroscreen (FAST-0145L), expanded, aliquoted, and frozen. An aliquot was thawed and plated in DPBS with 0.05% casein and 0.5 mM IBMX (2000 cells/well) in a 384-well format. The cells were then immediately stimulated for 30 min at room temperature with graded doses of test compound using human GLP-1(7–36) (synthesized at Gubra) as a positive control. cAMP accumulation was measured using a Cisbio assay for Gs-coupled receptors (cat. no. 62AM4PEC), where the assay reagents were added as per the manufacturer’s instructions and time-resolved fluorescence energy transfer recorded after one hour on a CLARIOstar (BMG Labtech) plate reader.

## Section: Experimental Section › In Vitro Functional Assay: General Procedure for Determination of hSCTR Potency

Frozen division arrested CHO-K1 cells stably overexpressing the hSCTR was obtained from PerkinElmer (ES-712-AF). Alternatively, a CHO-K1 cell line stably overexpressing the hSCTR was obtained from Euroscreen (FAST-0161L), expanded, aliquoted, and frozen. An aliquot was thawed and plated in DPBS with 0.05% casein and 0.5 mM IBMX as 2000 cells/well in a 384-well format. The cells were then immediately stimulated for 30 min at room temperature with graded doses of test compound using human secretin (synthesized at Gubra) as a positive control. cAMP accumulation was measured using a Cisbio assay for Gs-coupled receptors (cat. no. 62AM4PEC), where the assay reagents were added as per the manufacturer’s instructions and time-resolved fluorescence energy transfer recorded after 1 h on a CLARIOstar (BMG Labtech) plate reader.

## Section: Experimental Section › Biophysics: General Procedure for Determination of Solubility and Fibril Formation

Peptides were dissolved in buffers (50 mM sodium phosphate at pH 7.0) to 267 μM and incubated for 1–2 h at room temperature. The samples were then divided into two replicates of 80 μL in a black 384-well plate (μ-clear, Greiner Bio-One) and mixed with Thioflavin T (ThT) to a final concentration of 4 μM. The plate was centrifuged for 2 min at 2000 rpm to remove air bubbles, sealed, and placed in a plate reader (CLARIOstar, BMG). First, the turbidity of the samples was measured as the absorbance at 600 nm as an indication of precipitated material. Second, the plate reader temperature was set to 40 °C and the fluorescence was measured every 10 min for 72 h by exciting the ThT at 450 nm and measuring the emission at 480 nm. Samples were stressed by shaking the plate at 700 rpm (linear) for five min before every measurement, and fibril formation was determined as the average emission for each sample.

## Section: Experimental Section › Data Modeling

A random forest model22 was constructed for each in vitro endpoint. Features consisted of the peptide sequences as well as the specific plate number for synthesis and assay, respectively. For the deep mutational scan, peptide sequences were encoded using z-scales,23 and for the remaining data sets, peptide sequences were one-hot encoded (binary classification of the presence or absence of each amino acid in each position). The models were implemented in the statistical programming language R using the randomForest package version 4.6.14, and SHAP values were computed based on the random forest models using the treeSHAP package version 0.1.1.

## Section: Experimental Section › Ethics

All animal experiments were approved by The Danish Animal Experiments Inspectorate (License No. 2017-15-0201-01378). Animal experiments were conducted in agreement with internal Gubra bioethical guidelines that are fully compliant with internationally accepted principles for the care and use of laboratory animals.

## Section: Experimental Section › Pharmacokinetics in Rats

Male Spraque Dawley rats were obtained from Janvier (Janvier Laboratories, France) at 6 weeks of age. The animals were single-housed on the day of arrival. After 1 week of acclimatization, the animals (n = 3) were codosed with two test peptides; one compound was dosed intravenously and the other was dosed subcutaneously. In a parallel group (n = 3), the same two test peptides were dosed with opposite routes of administration. This allowed for profiling both the intravenous and subcutaneous administration routes and obtaining key pharmacokinetics parameters. Following dose administration, blood samples (90 μL) were collected in K2EDTA tubes at time points: 0.17, 1, 3, 6, 24, 30, 48, 72, and 96 h post-dosing. Plasma was obtained by centrifugation of the blood samples (3000 × g, 10 min 4 °C), and the plasma samples were frozen at −70 °C until analysis.

Pharmacokinetics parameters were calculated by noncompartmental analysis (NCA) of the individual plasma concentration–time profile from the animals. NCA was performed in the R-package NonCompart, using the log-linear trapezoidal method for the estimation of AUC and AUMC. AUC0–∞ was extrapolated <20%.

## Section: Experimental Section › LC-MSMS Analysis

Plasma concentrations were measured by LC-MSMS using electrospray ionization and multiple reaction monitoring. Calibration standards and quality control (QC) samples were prepared in a species-match matrix. In brief, 15 μL calibration standards, QC, and study samples were extracted by protein precipitation using 60 μL of methanol followed by the addition of 45 μL of Milli-Q water. Samples were shaken (800 rpm) at room temperature for 5 min before centrifugation (2570 × g, 40 min, 4 °C), and the supernatant was transferred to a LoBind PCR plate. Samples were analyzed on a Thermo Triscend UHPLC system coupled to a Sciex API 6500+ mass spectrometer. Samples were subject to online SPE cleanup on an HLB column (1 × 50 mm, Waters) before being loaded onto an Aeris Peptide XB C18 column (3.6 μm, 100 Å, 2 × 50 mm, Phenomenex, Torrance, USA) analytical column. The mobile phases consisted of acetonitrile and Milli-Q H2O both containing 0.1% V/V formic acid.

## Section: Experimental Section › Pharmacodynamics: Effect on Weight-Loss

Male C57BL/6JRj mice were obtained from Janvier (Janvier Laboratories, France), and group-housed in a controlled environment (12/12 h light-dark cycle, lights off at 3 PM, 22 °C ± 2 °C, humidity 50% ± 10%). Each animal was identified by an implantable subcutaneous microchip (PetID Microchip, E-vet, Haderslev, Denmark). Mice arrived at 5 weeks of age and were offered tap water and regular chow (Altromin 1324, Brogaarden, Denmark) or diet-induced obesity (DIO) was induced by offering ad libitum access to a 60% high-fat diet (5.15 kcal/g; 60 kcal% fat, 20 kcal% carbohydrates, 20% kcal% protein; D12492, Ssnif, Soest, Germany) for 46 weeks before study start. The mice were kept on a diet throughout the study. Mice were randomized according to body weight in week −1. The mice were SC-dosed once daily with Vehicle (50 mM phosphate, 3.5% mannitol) Lean (n = 10), Vehicle DIO (n = 10), positive control semaglutide (Ozempic, Novo Nordisk A/S, Denmark) 10 nmol/kg (n = 10) or the GLP-1R agonists; GUB021794, at 3, 10, or 30 nmol/kg (n = 10 mice/group) for 28 days. Body weight and food intake were measured daily from days −3 to 28. Whole-body lean/fat tissue composition was analyzed by noninvasive EchoMRI scanning (EchoMRI-900, Houston, TX, USA) performed on study day 28. Terminal exposure was measured using LC-MSMS on samples obtained 24 h after the last dosing.

## Section: Acknowledgments

We thank Henrik Björk Hansen for his help in revising the manuscript.

## Section: Supporting Information Available

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acs.jmedchem.4c00417.

## Section: Author Contributions

J.C.N., N.V., K.R., and L.S.D. conceptualized the study. C.H., A.W., L.E., R.B.M., M.S., carried out the in vitro experiments. T.P., S.R., A.N.M. caried out the in vivo experiments. J.C.N., C.H., M.M.N., A.W. analyzed the data. J.C.N., C.H., and L.S.D. wrote the paper. All authors reviewed and approved the final paper. J.C.N. and C.H. contributed equally to this work.

## Section: Text

The authors declare the following competing financial interest(s): All authors are employed at Gubra.

## Section: Notes

† Joint first author.

## Section: Supplementary Material

jm4c00417_si_001.pdf

jm4c00417_si_002.csv

## Section: Associated Data

jm4c00417_si_001.pdf

jm4c00417_si_002.csv

## Section: Associated Data › Supplementary Materials

jm4c00417_si_001.pdf

jm4c00417_si_002.csv


---

# Machine Learning to Predict Drug-Induced Liver Injury and Its Validation on Failed Drug Candidates in Development

- **Authors:** Fahad Mostafa, Victoria Howle, Minjun Chen
- **Issuer:** Toxics
- **Type:** Scientific article
- **Published:** 2024-05-24
- **Language:** en
- **DOI:** 10.3390/toxics12060385
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38922065/
- **Licence:** CC-BY

## Section: Abstract

AbstractDrug-induced liver injury (DILI) poses a significant challenge for the pharmaceutical industry and regulatory bodies. Despite extensive toxicological research aimed at mitigating DILI risk, the effectiveness of these techniques in predicting DILI in humans remains limited. Consequently, researchers have explored novel approaches and procedures to enhance the accuracy of DILI risk prediction for drug candidates under development. In this study, we leveraged a large human dataset to develop machine learning models for assessing DILI risk. The performance of these prediction models was rigorously evaluated using a 10-fold cross-validation approach and an external test set. Notably, the random forest (RF) and multilayer perceptron (MLP) models emerged as the most effective in predicting DILI. During cross-validation, RF achieved an average prediction accuracy of 0.631, while MLP achieved the highest Matthews Correlation Coefficient (MCC) of 0.245. To validate the models externally, we applied them to a set of drug candidates that had failed in clinical development due to hepatotoxicity. Both RF and MLP accurately predicted the toxic drug candidates in this external validation. Our findings suggest that in silico machine learning approaches hold promise for identifying DILI liabilities associated with drug candidates during development.Keywords: machine learning, drug-induced live injury, liver toxicity, random forest, multilayer perceptron, failed drug candidates

## Section: 1. Introduction

Drug-induced liver injury (DILI) continues to be a significant challenge for the pharmaceutical industry and regulatory organizations [1]. DILI is a complex safety issue characterized by various underlying processes, varying degrees of severity, population-specific differences, and the inherent challenges in categorizing the risk connected to medications, especially those recently granted marketing approval [2,3,4]. To prevent drugs with DILI liability from entering the market, it is crucial to enhance the ability to predict the potential risk of DILI in humans before obtaining marketing approval [5]. This improvement would lead to safer pharmaceuticals and more cost-effective drug development. In addition, prompt discontinuation of the development of drug candidates with a high propensity to cause DILI can result in the timely use of resources [6].

In silico models have gained popularity among researchers due to their rapid development times, cost-effectiveness and no requirement of physical substances, although experimental approaches such as in vitro and in vivo assays are still integral in the assessment of DILI risk [5,7]. Typically, in silico DILI prediction models have been developed and validated using marketed drugs, neglecting testing on drug candidates in the developmental stages [8]. Recognizing the challenge of the “translational gap” between drug development and clinical research [9,10], it becomes imperative to evaluate the performance of these in silico models using drug candidates that have failed during the drug development process.

In this study, we employed a large DILI likelihood dataset [11] created by the experts from the NIH LiverTox consortium [12]. We conducted a comparative analysis of various machine learning and deep learning algorithms to develop Quantitative Structure–Activity Relationship (QSAR) models, utilizing in-house Mold2 chemical descriptors. The evaluation through 10-fold cross-validation was used to select the model with the highest performance in terms of accuracy (ACC) or Matthews Correlation Coefficient (MCC). Subsequently, these models underwent external validation using a set of drug candidates that failed in clinical development due to hepatotoxicity in humans.

## Section: 2. Materials and Methods

Feature selection for DILI prediction.

## Section: 2. Materials and Methods › 2.1. Data and Annotation for DILI Likelihood

Medications can be classified in terms of their likelihood to cause liver injury in humans. The NIH LiverTox consortium has created a five-point classification for measuring the possibility that a medicine caused DILI. This classification is mostly based on the published literature. A drug is categorized by likelihood score on DILI [11] as category A (well known for DILI), Category B (highly likely to cause DILI), Category C (probably linked to DILI), Category D (possible cases for DILI), Category E (no evidence for DILI), or Category E* (suspected but no convincing DILI cases).

In this study, the dataset is reclassified into drugs with the likelihood to cause DILI (DILI group) and without the likelihood to cause DILI (non-DILI group). The likelihood of YES to DILI is enumerated as 1 for categories A, B, and C, and NO to DILI as 0 with E and E*. The training set comprises 240 DILI-positive, which includes 61 drugs belonging to group A, 80 of group B, and 99 of group C, and 335 DILI-negative with 206 of group E and 129 of group E*. Notably, the DILI-positives contained 34 medications with Black Box Warnings or withdrawn from the market due to DILI concern. An independent dataset were used as the external validation, including 22 drug candidates that were terminated in development due to liver toxicity [13].

## Section: 2. Materials and Methods › 2.2. Molecular Descriptors

Here, we used Mold2 to calculate 777 1D, and 2D molecular descriptors to capture critical two-dimensional chemical structural information associated with drugs. Mold2 is a software package developed by the FDA NCTR for fast calculating a large and diverse set of molecular descriptors encoding two-dimensional chemical structure information [14]. Compared with those calculated from commercial software on published datasets Mold2 descriptors provides similar or better performance to represent sufficient structural information [14].

## Section: 2. Materials and Methods › 2.3. Model Development

In the binary classification of machine learning, the data are represented as a set of pairs (x,y), where x denotes the input features and y represents the binary target variable. Mathematically, the input features are typically denoted as a real-valued vector x∈ Rn, where n is the dimensionality of the feature space. The target variable y is a binary label, taking on one of two values: 0 or 1. The goal of binary classification is to learn mapping from input features to the binary labels, which is represented as a function f:Rn→{0,1}. This mapping is learned through a training process using a labeled dataset, and the objective is to find a decision boundary or a hypothesis h(x) that accurately predicts the binary label y based on the input features x in a way that minimizes a suitable loss or cost function. The framework of model development for DILI prediction includes the following:

Feature selection for DILI prediction.

## Section: 2. Materials and Methods › 2.3. Model Development › 2.3.1. Feature Selection from Chemical Descriptors

Feature selection helps identifying the features that have the most impact on the prediction. It combats computational complexity, overfitting, and improves model interpretability by selecting the most relevant characteristics. Choosing influential features helps a model generalize to new data, minimizes noise, and adds to more efficient model training (Figure 1).

To assess the importance of input features, we analyzed the coefficients (weights) associated with each feature in the logistic regression model [15]. The absolute values of these coefficients represent the feature’s importance. The larger the absolute coefficient, the more important the feature is in predicting the binary outcome.

The logistic regression model represents the relationship between the features and the binary outcome (0 or 1) using the logistic function (sigmoid function). The model is defined as follows:

The logistic regression model can then be defined as

To reduce overfitting, Lasso regularization is adopted during logistic regression, which encourages sparse coefficient values, making feature selection more explicit [16]. The logistic regression model with L1 regularization is represented as follows with the defined objective function:

Here, J(θ) is the logistic regression cost function with Lasso regularization, m is the number of training samples, n is the number of features, θ represents the model parameters (weights), x(i) is the feature vector of the i-th sample, and hθx(i) is the logistic function. The λ term controls the strength of Lasso regularization. The Lasso regularization term encourages some of the θ coefficients to become exactly zero, which effectively selects a subset of features. The features with non-zero coefficients in the trained model are considered important for the classification task.

Feature selection for DILI prediction.

## Section: 2. Materials and Methods › 2.3. Model Development › 2.3.2. Model Selection and Mathematical Analysis

Model selection is an important component of developing predictive models since algorithms have different capabilities for modeling. In our current DILI study, binary classification was considered.

If x is the input features of dimension n, then y is the binary class with class labels 0 and 1. If θ is the model parameters and Hθ is the predicted P(y=1∣x,θ), the SVM classifier’s prediction probability is:

Hθ(x) predicts the class label, θ is the weight of the parameters and b is the bias. The objective function to minimize is

In the case of the DT classifier [17], it recursively partitions the feature space into regions by selecting split based on Gini impurity or the entropy index. Random forest (RF) is an ensemble of DTs [18,19]. Each tree is trained on a bootstrap sample, and the final prediction is obtained by aggregating predictions of individual trees. A deep learning-based classifier, which is known as multilayer perceptron (MLP), is also used to train the model. The mathematical representation of a neural network is as follows:

where W(1) and W(2) are weight matrices, and b(1) and b(2) are the biases. The cross-entropy loss function is

The KNN classifier assigns a class label C to a new instance xnew based on the majority class among its k-nearest neighbors as follows:

where Cxnew is the predicted class label for the xnew,c iterates the overall possible class labels, and δyi,c is the Kronecker delta, which is 1 if yi=c and 0 otherwise. To find the KNN of xnew, the Euclidean distance metric is used as dxi,xnew= ∑j=1mxij−xnew,j2, where m is the number of features in the data. Stochastic Gradient Descent (SGD) and Adaptive Moment Estimation (ADAM) are two optimization methods that are often used in machine learning models to minimize loss functions. SGD iteratively updates model parameters in logistic regression by examining small portions of training data, improving convergence speed and scalability [20]. These techniques let SVM discover the best hyperplane by repeatedly modifying the separation margins [21]. ADAM aids training in MLP by fine-tuning the network’s weights and biases, allowing it to approximate complicated correlations between inputs and outputs [22].

## Section: 2. Materials and Methods › 2.3. Model Development › 2.3.3. Model Evaluations and Statistical Analysis

To determine performance measures, predictions from each of the 100 iterations of the 10-fold cross-validation were compared with their actual DILI risk classifications. Each 10-fold cross-validation for the 2-class DILI prediction models produced a 2-by-2 confusion matrix.

A panel of statistical matrices are used for investigating machine learning models [23], such as accuracy (ACC), precision, recall, F1 score (F1), and MCC. The predictions made by a classifier can be categorized as true positive (TP), true negative (TN), false positive (FP), and false negative (FN).

## Section: 2. Materials and Methods › 2.3. Model Development › 2.3.4. Applicability Domain Analysis

Determining the applicability domain [24,25] often involves using various statistical and cheminformatics techniques, such as clustering analysis, distance measures, or domain-specific rules. These methods help assess whether new data points or compounds fall within the established domain. Knowing the domain of application enables users to apply the model to data that are comparable to the training data, enhancing trust in their robustness and generalizability. Normally, a hypothesis is considered for finding optimal prediction space in the 2D visualization of the prediction data points.

Here, the RF classifier and the Mahalanobis distance are utilized to apply the applicability domain [26] for evaluating the eligibility of new data points for prediction. Given a training dataset consisting of input features denoted as Xtrain and corresponding class labels ytrain, and a trained classifier model RF, the Mahalanobis distance, DOxnew, is calculated for a new data point xnew using the mean and covariance matrix of Xtrain. A threshold value, T, determined by a chosen significance level α and degrees of freedom, is utilized. The RF classifier predicts the class label ypred for xnew. If DOxnew is less than T,xnew is within the applicability domain; otherwise, it’s outside. The Mahalanobis distance’s comparison with T dictates the data point’s classification.

## Section: 3. Results

Shapley values used to explain the prediction of a model by attributing the contribution of 10 most important features out of 168 top features to the prediction.

Performance matrices for different machine learning and deep learning models on DILI prediction (mean ± standardized deviation).

MCC scores from the permuted labels vs. the real labels by RF (upper) and MLP models (down). Both tests were statistically significant (p-value < 0.001).

An applicability domain defines the specific conditions under which a predictive model or algorithm is expected to perform well. The blue dots are the training data points and elliptic circle indicates domain threshold.

Model predictions for drug candidates terminated in drug development with hepatotoxicity findings.

## Section: 3. Results › 3.1. Assessments of Feature Selection

Feature selection is critical for machine learning to solve the issues associated with high-dimensional DILI datasets. Here, we used a regularized logistic regression method for identifying the most important features. The dataset was split into training and validation sets with an 80–20 ratio by using a simple random sampling technique. Then, we selected the top important features for classification based on their root mean squared error (RMSE) and λ using least absolute shrinkage and selection operator (lasso) and transformed the training and testing sets to include only the selected features. For doing this we selected a range of values for the regularization parameter λ using cross-validation. For each value of λ, we fit a lasso regression model on the training data. Then, we used a validation dataset to evaluate the performance of each lasso model. Once the optimal λ was determined, we fit the lasso regression model with this λ value on the entire dataset to obtain the final model. Using lasso with 10-fold CV, 168 top-ranked molecular descriptors were selected with the best λ = 0.01 and minimum RMSE of 0.466. The model employed feature selection using L1 regularization with logistic regression and calculated p-values for the selected features. After standardizing the features, it fit the lasso model to the training data, identifying the features with non-zero coefficients and the lowest p-values. From the 168 top-ranked descriptors obtained through the lasso variable selection strategy, we extracted the 10 most valuable features with the smallest p-values for DILI prediction. Subsequently, we assessed feature importance using SHAP (Figure 2) [27], and the detailed descriptions of these features can be found in Supplementary Table S1.

Shapley values used to explain the prediction of a model by attributing the contribution of 10 most important features out of 168 top features to the prediction.

## Section: 3. Results › 3.2. Model Development and Performance Assessments

Table 1 presents a comparison of several machine learning methods in terms of performance measures evaluated by 100 repeats of 10-fold cross-validation.

RF had the highest ACC of 0.631, followed by MLP (0.626) and SVM (0.617). RF also had the highest recall of 0.716, followed by KNN (0.664) and MLP (0.658). It achieved the highest F1 score value of 0.677, followed by MLP (0.660) and SVM (0.654). Meanwhile, RF had the lowest standard deviation in the recall and F1 score.

MLP had the highest MCC means (0.245), followed by RF and SVM (0.226 and 0.225, respectively). It also had the highest precision (0.673), followed by SVM (0.663) and NB (0.662). MLP recorded the second highest recall (0.658) and F1 score (0.660).

Considering the metrics, RF consistently performs well in terms of ACC, precision, recall, MCC, and F1 score. It has the highest or near-highest mean values in most metrics. MLP has the highest MCC and precision and performs well in terms of recall. In summary, RF and MLP seem to be the best models based on the metrics provided.

We conducted a permutation test for the selected QSAR models based on RF and MLP. By randomly shuffling the labels, we generated a permuted label distribution. The MCCs from our RF and MLP models (Figure 3) were significantly higher than those obtained from the models with permuted labels (p-value < 0.0001). This suggests that the predictions from our models are not due to chance.

We evaluated the RF model for the application domain. For threshold 0.6 (Figure 4), we observed the number of training data points inside the application domain to be 428 and the number of train data points outside the domain to be 32. Accordingly, the ACC within the domain is 0.64 and outside is 0.62.

Performance matrices for different machine learning and deep learning models on DILI prediction (mean ± standardized deviation).

MCC scores from the permuted labels vs. the real labels by RF (upper) and MLP models (down). Both tests were statistically significant (p-value < 0.001).

An applicability domain defines the specific conditions under which a predictive model or algorithm is expected to perform well. The blue dots are the training data points and elliptic circle indicates domain threshold.

## Section: 3. Results › 3.3. Model Validation by Drug Candidates That Failed in Development

We tested the models using a set of 22 drug candidates that failed in drug development due to hepatotoxicity [15]. Both RF and MLP classifiers successfully predicted whether medications would result in “No-DILI-Concern” or “Most-DILI-Concern” with a success rate of 19/22 (90.9%) (Table 2). As a comparison, the rule-of-two model correctly predicted 13/22 compounds (59%), of which 8 compounds (*) were determined as ambiguous with either a high daily dose of >100 mg/day or a high logP value of >3 alone. We also applied the ToxSTAR online tool [28] for evaluating these drug candidates, which resulted in the correct prediction of 18/22 compounds (82%) for cholestasis and 16/22 compounds (73%) for hepatitis.

Model predictions for drug candidates terminated in drug development with hepatotoxicity findings.

## Section: 4. Discussions

In this study, we endeavored to construct computer models for assessing DILI risk caused by medications, utilizing a substantial human dataset annotated by experts from LiverTox. To achieve this, an extensive exploration of various machine learning and deep learning techniques was undertaken to evaluate the efficacy of different modeling classifiers.

A 10-fold cross-validation procedure was employed to assess several selected machine learning algorithms, complemented by external testing. Our findings revealed that the RF and MLP models stood out as highly effective in predicting DILI. Specifically, RF outperformed other machine learning strategies, achieving an average prediction accuracy of 0.631 during cross-validation, while the MLP deep learning approach attained the best MCC of 0.245. The permutation tests revealed that the predictions from both models are better than by chance.

QSAR models for DILI have been extensively studied in the literature. It is crucial to recognize that different endpoints in DILI prediction models can yield varying predictions due to differences in underlying mechanisms, data availability, and model complexities. In this study, we utilized a large dataset of drugs with quality endpoints related to DILI likelihood, as curated by the NIH’s LiverTox [11]. To the best of our knowledge, no other QSAR DILI model has been specifically based on the same endpoint. Another widely used dataset for developing QSAR models is DILIrank [29]. As detailed in Supplementary Table S2, various algorithms were employed to build these models, and they demonstrated comparable performance to ours, achieving accuracies in the range of 60–70% [8,30,31,32,33,34].

The top selected features by our models include Geary topological structure autocorrelation length-1 weighted by atomic van der Waals volumes (D455), Moran topological structure autocorrelation length-2 weighted by atomic masses (D480), the number of group Al-C(=X)-Al (D742), structure lopping centric group index (D253), and mean molecular topological order-9 charge index (D529). Interestingly, our top two ranking features have also been reported to contribute to QSAR models for predicting the inhibition of Cytochrome P450 enzymes, specifically CYP3A4, CYP2D6 [35] and CYP2C8 [36]. Notably, the inhibition of CYP enzymes is known to be associated with an increased risk of DILI in humans [37].

The RF model exhibited competitive F1 and AUC scores, demonstrating its capacity to successfully discriminate between positive and negative occurrences in the prediction process, achieving a harmonious balance between precision and recall. Of significant note, both models demonstrated their accuracy when externally validated against a set of 22 failed drug candidates with hepatotoxicity, although false negative rates need further evaluation. This underscores their potential in identifying compounds with hepatotoxic liabilities, mitigating risks to patients, and enhancing drug development procedures.

Both MLP and RF have unique advantages when developing QSAR models. RF offers robustness through its ensemble of decision trees, feature importance analysis, and noise resilience. On the other hand, MLPs excel at automatically learning from complex features and identifying non-linear connections between molecular descriptors and DILI. Without the need for additional ensemble methodologies, MLPs and RF can independently achieve competitive performance in DILI prediction by leveraging their respective strengths in feature learning and ensemble learning. These methods help identify important structural traits associated with DILI, providing a deeper understanding of the connections between chemical properties and liver damage.

However, there are also drawbacks to applying machine learning methods. One challenge is the availability of labeled data—finding high-quality, readily available data for training can be difficult. The size, quality, and representativeness of training datasets often vary, affecting the broad applicability of models. Another issue is class imbalance in datasets used for DILI prediction. For instance, when the proportion of liver injury cases is much lower than non-liver injury cases, models may perform poorly on the minority class and favor the dominant class. Extracting relevant traits or biomarkers from complex biological data can also be challenging. While machine learning algorithms can handle high-dimensional data, their interpretability may be limited, making it hard to understand the biological processes underlying DILI prediction. Additionally, complex models like deep learning neural networks (such as MLP) are prone to overfitting, especially when trained on small or noisy datasets. Overfitting occurs when a model memorizes the training data rather than capturing underlying patterns, leading to poor generalization performance on unseen data.

Developing a robust in silico model to predict the DILI risk in humans remains an unmet challenge in drug development. The urgency for accurate DILI prediction in pharmaceutical research and patient safety underscores the need for improved risk management and drug development practices. Machine learning approaches offer a promising solution to address these complex healthcare concerns. This study paves the way for future research into the application of machine learning in DILI prediction and its broader implications for medication safety and healthcare.

## Section: Supplementary Materials

The following supporting information can be downloaded at: https://www.mdpi.com/article/10.3390/toxics12060385/s1, Table S1: Top 10 ranking features out of 168 lasso selected features with symbol and chemical definition; Table S2: The published QSAR models for predicting liver toxicity in humans using DILIrank dataset as the endpoint.

## Section: Author Contributions

Conceptualization, M.C.; methodology, F.M., V.H. and M.C.; validation, F.M. and M.C.; data curation, F.M. and M.C.; writing—original draft preparation, F.M.; writing—review and editing, V.H. and M.C.; visualization, F.M.; supervision, M.C.; project administration, M.C. All authors have read and agreed to the published version of the manuscript.

## Section: Institutional Review Board Statement

Not applicable.

## Section: Informed Consent Statement

Not applicable.

## Section: Data Availability Statement

The datasets used and/or analyzed during the current study are available from the corresponding author on reasonable request.

## Section: Conflicts of Interest

The authors declare no conflict of interest.

## Section: Funding Statement

This research received no external funding.

## Section: Associated Data › Data Availability Statement

The datasets used and/or analyzed during the current study are available from the corresponding author on reasonable request.


---

# Matching patients to clinical trials with large language models

- **Authors:** Qiao Jin, Zifeng Wang, Charalampos S. Floudas, Fangyuan Chen, Changlin Gong, Dara Mark Bracken-Clarke, Elisabetta Xue, Yifan Yang, Jimeng Sun, Zhiyong Lu
- **Issuer:** Nature Communications
- **Type:** Scientific article
- **Published:** 2024-11-18
- **DOI:** 10.1038/s41467-024-53081-z
- **Source:** https://doi.org/10.1038/s41467-024-53081-z
- **Licence:** CC-BY

## Section: Abstract

AbstractPatient recruitment is challenging for clinical trials. We introduce TrialGPT, an end-to-end framework for zero-shot patient-to-trial matching with large language models. TrialGPT comprises three modules: it first performs large-scale filtering to retrieve candidate trials (TrialGPT-Retrieval); then predicts criterion-level patient eligibility (TrialGPT-Matching); and finally generates trial-level scores (TrialGPT-Ranking). We evaluate TrialGPT on three cohorts of 183 synthetic patients with over 75,000 trial annotations. TrialGPT-Retrieval can recall over 90% of relevant trials using less than 6% of the initial collection. Manual evaluations on 1,015 patient-criterion pairs show that TrialGPT-Matching achieves an accuracy of 87.3% with faithful explanations, close to the expert performance. The TrialGPT-Ranking scores are highly correlated with human judgments and outperform the best-competing models by 43.8% in ranking and excluding trials. Furthermore, our user study reveals that TrialGPT can reduce the screening time by 42.6% in patient recruitment. Overall, these results have demonstrated promising opportunities for patient-to-trial matching with TriaGPT.

## Section: Introduction

Clinical trials examine the effectiveness of medical interventions and provide crucial evidence that can be used to guide clinical practice. They also offer an opportunity for participants to receive experimental treatments that could potentially improve their health outcomes. However, matching patients to suitable clinical trials can be a challenging process1–3. This process includes analyzing a patient’s medical history, understanding the eligibility criteria of each clinical trial, and ensuring a match that satisfies both patient needs and trial requirements. As such, manually matching patients and clinical trials is often labor-intensive, time-consuming, and prone to human errors.

Recently, artificial intelligence (AI) has shown promise in improving the efficiency and accuracy of patient-trial matching4,5. Based on the directionality, there are two types of patient-trial matching tasks. The “trial-to-patient” scheme matches one trial to a list of candidate patients6, which is a common need for clinical trial organizers and can be done by converting the trial criteria to structured query languages and searching the patient database6–8. On the other hand, the “patient-to-trial” scheme matches one patient to a list of candidate clinical trials9–13. In this study, we focus on the patient-centric “patient-to-trial” scheme because such a model can empower individual patients as well as referral offices to explore a large set of potentially eligible clinical trials. However, the heterogeneity and ambiguity inherent in patient records and clinical trial criteria induce significant challenges for AI algorithms. Prior efforts encoded patient records and trial criteria into dense embeddings using neural networks, aiming to represent them in the same embedding space that enables patient-trial matching through similarity search14–16. Nonetheless, training neural networks with the language understanding capability of criteria texts and patient records requires large datasets. This is often infeasible due to the lack of paired patient-criterion matching annotations. Moreover, the dense retrieval process is non-explainable, making it challenging to debug and often resulting in skepticism among medical experts when applied to new criteria and patient groups.

In this work, we aim to explore how recent large language models (LLMs) such as GPT-417 can aid the process of patient-to-trial matching in a data-efficient and transparent way. LLMs are transformer-based models18 that can understand a given context and generate human-like responses accordingly. They have shown state-of-the-art capabilities in both the general domain17,19 and biomedicine20, including question answering21–26 and clinical trial design27,28. Several pilot studies have also explored using LLMs to enhance the first-stage retrieval of clinical trials by information extraction29,30, perform data augmentation with synthetic data31–33, and structuralize clinical trial criteria34. In contrast, our study presents an end-to-end solution, i.e., trial retrieval, matching, and ranking, to streamline clinical trial patient recruitment with LLMs.

The proposed method, namely TrialGPT, consists of three key components: TrialGPT-Retrieval, TrialGPT-Matching, and TrialGPT-Ranking. Given a patient note, TrialGPT-Retrieval first locates hundreds of highly relevant candidate clinical trials from a large initial collection using keyword generation and hybrid-fusion retrieval. Based on the retrieved trials, TrialGPT-Matching predicts the criterion-level eligibility of each patient with three elements: natural language explanations showing the relevance of the patient to the criterion, locations of relevant sentences in the patient note that are relevant to the target criterion, and the eligibility classification indicating whether the patient meets this criterion. Finally, TrialGPT-Ranking aggregates the TrialGPT-Matching results at the trial level and uses such scores to get a ranked list of clinical trials based on the eligibility of a given patient.

Our evaluations are conducted with three publicly available cohorts of 183 synthetic patients with over 75,000 trial eligibility annotations. Experimental results show that TrialGPT-Retrieval can recall over 90% of relevant clinical trials using less than 6% of the candidate clinical trials. The model also generates better keywords for trial retrieval compared to those produced by four human clinicians. Three domain experts evaluate TrialGPT-Matching on 1,015 patient-criterion pairs, and the results show that TrialGPT-Matching can accurately explain patient-criterion relevance, locate relevant sentences, and predict criterion-level eligibility with an accuracy close to that of human experts. We then evaluate the trial-level scores by TrialGPT-Ranking and results show that they are highly correlated with expert eligibility annotations. Such scores can be used to match eligible trials with patients effectively and exclude ineligible trials, with a performance of 43.8% higher than the best baselines.

We also conducted a pilot user study that mimics the actual clinical trial matching task at the National Cancer Institute (NCI). In the evaluation, each patient-trial pair is evaluated by one medical expert with TrialGPT and another one without TrialGPT. We also ensure that each medical expert annotates half of the pairs with TrialGPT and half without to mitigate the skill differences between the annotators when computing the time reduction. The overall time saving for all patient-trial pairs is about 42.6%, which shows its great potential to enhance the efficiency of the clinical trial matching process.

## Section: Results

The overall architecture of TrialGPT. (a) TrialGPT-Retrieval can filter out most of the irrelevant trials from the initial collection and return a list of candidate clinical trials; (b) For a given patient, TrialGPT-Matching can explain the relevance, generate the evident sentence locations, and predict the eligibility classification for each criterion in a trial; (c) TrialGPT-Ranking can aggregate the criterion-level predictions by TrialGPT-Matching and use these scores to perform fine-grained ranking to get the final recommended trials.

We show the mean ± standard deviation for applicable variables. “None” denotes there is no such eligibility label in the corresponding cohort. SIGIR: the patient-trial matching cohort published at the Special Interest Group on Information Retrieval (SIGIR). TREC: the Text REtrieval Conference (TREC). CT: the clinical trials track at TREC.

First-stage retrieval results. (a) Overview of TrialGPT-Retrieval. LLMs first generate a list of keywords for a given patient note. These keywords are used to derive the keyword-level relevant clinical trials, which are then fused to generate a final ranking. (b) Recalls of relevant clinical trials at different depths for various query types and retrievers. The hybrid retriever combines the results of the BM25 (lexical matching) and the MedCPT (semantic matching) retrievers. Source data are provided as a Source Data file.

(a) The percentage of correct, partially correct, and incorrect relevance explanations generated by TrialGPT-Matching; (b) Evaluation results of the relevant sentences located by TrialGPT-Matching based on 405 criterion-level annotations where at least one sentence is labeled as relevant in the ground-truth. 95% confidence intervals estimated by bootstrapping are shown as error bars; (c) The confusion matrices of the eligibility for inclusion criteria predicted by human experts and TrialGPT-Matching; (d) The confusion matrices of the eligibility for exclusion criteria predicted by human experts and TrialGPT-Matching. Not Incl.: Not included. Not Excl.: Not excluded. No Info.: Not enough information. Not Appl.: Not applicable. Source data are provided as a Source Data file.

(a) The percentage of inclusion criteria predicted as “included” by TrialGPT; (b) The percentage of inclusion criteria predicted as “not included”; (c) The percentage of inclusion criteria predicted as “no relevant information”; (d) The LLM-aggregated relevance score; (e) The percentage of exclusion criteria predicted as “excluded”; (f) The percentage of exclusion criteria predicted as “not excluded”; (g) The percentage of exclusion criteria predicted as “no relevant information”; (h) The LLM-aggregated eligibility score. “*” denotes p < 0.05, “**” denotes p < 0.01, “***” denotes p < 0.001, and “n.s.” denotes not significant (p > 0.05) by two-sided independent t-test. There are 60,240 unlabeled, 15,459 irrelevant, 6,981 excluded, 647 potential, and 8,173 eligible patient-trial pairs. Center line, median; box limits, upper and lower quartiles; whiskers, 1.5x interquartile range; points, outliers. Source data are provided as a Source Data file, including all the exact p values.

The Sign() function assigns suitable signs for the corresponding task, e.g., for “% Included”, it will be “+” for ranking and “-” for excluding clinical trials. Aggr.: aggregation. NDCG@10: normalized discounted cumulative gain at 10. P@10: precision at 10. AUROC: the area under the receiver operating characteristic curve.

Results of the patient-trial matching user study. (a) Experimental design and actual screening times of each patient-trial pair by two expert annotators; (b) Comparison of screening time aggregated by different clinical trials; (c) Comparison of screening time aggregated by different patient cases; (d) Comparison of screening time aggregated by short cases, long cases, annotators, and all pairs. Numbers in parentheses denote the sample sizes in the corresponding group of the comparison. Within the annotator (e.g., Annotator X or Y), significant tests are conducted by two-sided independent t-test. Other significant tests are two-sided paired t-tests. Trial A, B, C, D, E, and F denote NCT04432597, NCT05012098, NCT04287868, NCT04847466, NCT04719988, and NCT04894370, respectively. Source data are provided as a Source Data file.

## Section: Results › TrialGPT Architecture

The architecture of TrialGPT is shown in Figure 1. Overall, TrialGPT consists of three components: Retrieval (Figure 1a), Matching (Figure 1b), and Ranking (Figure 1c). TrialGPT-Retrieval is designed to filter out most of the irrelevant clinical trials in a large initial collection. Specifically, TrialGPT-Retrieval can generate a list of keywords based on the patient summary and feed them into a hybrid-fusion retriever to obtain a relatively small subset from a potentially large initial collection, while maintaining high recalls of relevant clinical trials. This retrieval step is designed to ensure the scalability of the TrialGPT in real-world applications where there are tens of thousands of clinical trials to consider, such as matching against as many as 23,000 active clinical trials being conducted in a single country (i.e., the United States).

For each candidate clinical trial returned by the TrialGPT-Retrieval, TrialGPT-Matching analyzes the eligibility of the given patient in a criterion-by-criterion style. For each criterion, TrialGPT-Matching generates three elements: (1) the explanation of the patient-criterion relevance; (2) the locations of relevant sentences in the patient notes to the criterion; (3) the eligibility classification for the patient-criterion pair.

Finally, TrialGPT-Ranking aggregates the criterion-level predictions by TrialGPT-Matching to derive trial-level scores that can be subsequently used to rank clinical trials by eligibility and exclude the ones that are explicitly ineligible.

The overall architecture of TrialGPT. (a) TrialGPT-Retrieval can filter out most of the irrelevant trials from the initial collection and return a list of candidate clinical trials; (b) For a given patient, TrialGPT-Matching can explain the relevance, generate the evident sentence locations, and predict the eligibility classification for each criterion in a trial; (c) TrialGPT-Ranking can aggregate the criterion-level predictions by TrialGPT-Matching and use these scores to perform fine-grained ranking to get the final recommended trials.

## Section: Results › Patient Cohorts

To evaluate TrialGPT, we use the patient summaries and clinical trials from three publicly available cohorts: a test collection for patient-trial matching published by Special Interest Group on Information Retrieval (SIGIR) in 201610, and the 2021 and 2022 Clinical Trials (CT) tracks9,13 of the Text REtrieval Conference (TREC). The SIGIR cohort has three different patient-trial eligibility labels: irrelevant (“would not refer this patient for this clinical trial”), potential (“would consider referring this patient to this clinical trial upon further investigation”), and eligible (“highly likely to refer this patient for this clinical trial”). The TREC cohorts also have three different patient-trial eligibility labels: irrelevant (“the patient is not relevant for the trial in any way”), excluded/ineligible (“the patient has the condition that the trial is targeting, but the exclusion criteria make the patient ineligible”), and eligible (“the patient is eligible to enroll in the trial”). We used the combination of the judged clinical trials for all patients in the individual cohort as the considered initial trials for TrialGPT-Retrieval for two reasons: (1) the largest realistic search space for clinical trials is about 23 thousand (the maximum number of active trials in a single country), which is similar to the number of judged trials in the TREC cohorts; (2) these cohorts used pooled judgment, which means that there might be eligible clinical trials outside of the labeled corpus but will be considered as irrelevant if retrieved. The baseline statistics of patient cohorts are shown in Table 1.

We show the mean ± standard deviation for applicable variables. “None” denotes there is no such eligibility label in the corresponding cohort. SIGIR: the patient-trial matching cohort published at the Special Interest Group on Information Retrieval (SIGIR). TREC: the Text REtrieval Conference (TREC). CT: the clinical trials track at TREC.

## Section: Results › TrialGPT-Retrieval can generate keywords for effective clinical trial filtering

As shown in Figure 2a, in the retrieval stage, large language models are prompted to generate a list of keywords for the initial screening of clinical trials at scale. For each keyword, we then get the list of relevant clinical trials using a hybrid retriever that matches both lexical and semantic information. The retrieval results are then combined into a ranked list with reciprocal rank fusion. We evaluated the retrieval performance of keywords generated by GPT-4 and GPT-3.5 using all three cohorts. As a comparison, we also tested when the raw patient notes were used to retrieve clinical trials. On the SIGIR cohort, we show the performance of clinician-generated keywords that are annotated in the original dataset.

The recalls of relevant clinical trials at different depths are shown in Figure 2b. In all three cohorts, keywords generated by GPT-4 and GPT-3.5 consistently achieved the highest performance, while directly using the raw patient notes achieved the lowest performance. This indicates that large language models can effectively generate keywords from patient notes for clinical trial retrieval. In terms of the retriever, the semantic MedCPT is much better than the lexical BM25 retriever, and the hybrid retriever achieves the best performance. In the SIGIR cohort, the performance of clinician-generated keywords is between the LLM-generated keywords and the raw notes. This shows that large language models can already generate better keywords than human clinicians for clinical trial retrieval. Overall, the average recall at the top 500 retrieved clinical trials is 50.0%, 83.4%, 86.2% for the raw note, TrialGPT-Retrieval with GPT-3.5, and TrialGPT-Retrieval with GPT-4, respectively. On average, to recall at least 90% of the relevant clinical trials, GPT-4-based TrialGPT-Retrieval only needs to select 5.5% of the initial document collection, and GPT-3.5-based TrialGPT-Retrieval needs 7.0%. As such, TrialGPT-Retrieval significantly improves the scalability by filtering out most of the irrelevant clinical trials and returning a short list of candidate clinical trials for further finer-grained analyses by TrialGPT-Matching and TrialGPT-Ranking.

First-stage retrieval results. (a) Overview of TrialGPT-Retrieval. LLMs first generate a list of keywords for a given patient note. These keywords are used to derive the keyword-level relevant clinical trials, which are then fused to generate a final ranking. (b) Recalls of relevant clinical trials at different depths for various query types and retrievers. The hybrid retriever combines the results of the BM25 (lexical matching) and the MedCPT (semantic matching) retrievers. Source data are provided as a Source Data file.

## Section: Results › TrialGPT-Matching achieves a high criterion-level prediction accuracy

As shown in Figure 1b, TrialGPT-Matching first generates the rationales and the relevant sentences for each criterion. Then, it predicts the criterion-level eligibility classification based on the rationales. TrialGPT assigns each inclusion criterion a label within {Included, Not included, Not enough information, Not applicable} and each exclusion criterion a label within {Excluded, Not excluded, Not enough information, Not applicable}. We sampled 105 patient-trial pairs from 53 patients in the SIGIR cohort, which contains 1,015 patient-criterion pairs. Three physicians were recruited and manually annotated these pairs regarding the criterion-level output elements by GPT-4: (1) the correctness of TrialGPT relevance explanation between the given patient and the criterion, (2) the relevant sentence locations in the patient note, and (3) the criterion-level prediction of the given patient’s eligibility. Consensus annotations derived from individual annotations and further discussions are used as the ground truth.

Evaluating relevance explanations: We show the percentage of “correct”, “partially correct” and “incorrect” TrialGPT explanations in Figure 3a. Overall, most explanations are “correct” (87.8%) by manual evaluations, while less than 10% of explanations are “partially correct” (9.66%), and only a small proportion are “incorrect” (2.56%). We also found that most of the incorrect explanations are for criteria labeled as “not included” and “not excluded”, which usually require implicit inference. TrialGPT exhibits much fewer mistakes when the criteria are explicitly “included” or “excluded”. These results suggest that TrialGPT can effectively explain how a patient is relevant to an eligibility criterion.

Evaluating relevant sentence locations: We compare the relevant sentences predicted by TrialGPT-Matching against the ground-truth expert annotations. As shown in Figure 3b, the TrialGPT-predicted sentence locations are 90.1% correct (precision) and cover 87.9% of the ground-truth relevant sentence IDs (recall), leading to an F1 score of 88.6%. The performance of TrialGPT is close to that of human experts, ranging from 86.9% to 91.5%. This shows that TrialGPT can faithfully locate relevant sentences in patient notes, providing strong explainability for human expert use and oversight.

Evaluating eligibility prediction: Finally, we evaluate the criterion-level eligibility labels predicted by TrialGPT and expert annotators against the ground-truth annotations. Figures 3c and 3d show the confusion matrices for these predictions. Overall, TrialGPT-Matching achieves a prediction accuracy of 0.873, close to the expert performance (0.887–0.900). For the inclusion criteria, TrialGPT reaches a prediction accuracy of 0.899 for all four labels, which is within the experts’ accuracy range from 0.876 to 0.916. For the exclusion criteria, while the accuracy is high for criteria labeled with “excluded” (1.00) and “not applicable” (0.98), TrialGPT tends to confuse among “not excluded”, “no relevant information”, and “not applicable”. TrialGPT achieves an accuracy of 0.859 on the exclusion criteria. These results suggest that TrialGPT can accurately predict patient eligibility at the criterion level, with a performance close to that of human experts.

We further inspected the 26 criterion-level predictions that are labeled as “Incorrect” by annotator consensus. Four types of errors have been identified: (E1) Incorrect reasoning, where TrialGPT predicts “not enough information” but the matching result can be implicitly inferred; (E2) Lack of medical knowledge, such as not recognizing that one medical term is synonymous with another or that one term is a subtype of another; (E3) Ambiguous label definitions, confusing “not enough information” with “not applicable” due to unclear or overlapping label definitions; (E4) Other unclassified errors. Supplementary Table 1 shows the proportion and example of each error type made by TrialGPT. Most (30.7%) of the errors are due to incorrect reasoning, followed by ambiguous or redundant definitions of the eligibility classes (26.9%). Lack of medical knowledge contributes to about 15.4% of the total errors. These results suggest that improving the medical capabilities of the backbone LLM is an important future direction.

(a) The percentage of correct, partially correct, and incorrect relevance explanations generated by TrialGPT-Matching; (b) Evaluation results of the relevant sentences located by TrialGPT-Matching based on 405 criterion-level annotations where at least one sentence is labeled as relevant in the ground-truth. 95% confidence intervals estimated by bootstrapping are shown as error bars; (c) The confusion matrices of the eligibility for inclusion criteria predicted by human experts and TrialGPT-Matching; (d) The confusion matrices of the eligibility for exclusion criteria predicted by human experts and TrialGPT-Matching. Not Incl.: Not included. Not Excl.: Not excluded. No Info.: Not enough information. Not Appl.: Not applicable. Source data are provided as a Source Data file.

## Section: Results › TrialGPT-Ranking scores correlate with trial-level eligibility

TrialGPT-Matching has achieved high prediction accuracy at the criterion level. However, since one clinical trial typically has many inclusion and exclusion criteria, trial-level scores should be computed to decide to which extent a given patient is eligible or ineligible. As such, the third component, TrialGPT-Ranking, aggregates the criterion-level predictions into trial-level scores, as shown in Figure 1c. In this section, we analyze the correlations between patient-trial eligibility and eight variants of trial-level scores, which are computed by two types of methods: linear aggregations and LLM aggregations. For each patient in the three cohorts, we consider the top 500 clinical trials returned by TrialGPT-Retrieval for the analysis. The results are presented as box plots in Figure 4.

Linear aggregations: Six scores are computed by counting the percentages of six different criterion-level eligibility predictions of TrialGPT (details in Methods). Their correlations with different types of trial-level eligibility labels are shown in Figure 4a-c for inclusion criteria and Figure 4e-g for exclusion criteria. Figure 4a shows the percentage of inclusion criteria predicted as “included” by TrialGPT. As expected, Figure 4a implies that the patients meet the highest percentages of inclusion criteria in eligible clinical trials and meet the lowest percentages of inclusion criteria in irrelevant clinical trials. The percentage of met inclusion criteria falls in between for relevant but ineligible trials. Figure 4b shows the percentage of inclusion criteria predicted as “not included”, which approximately follows the reverse trends of the met inclusion criteria (Figure 4a). Noticeably, no inclusion criterion is classified by TrialGPT-Matching as “not included” in most of the eligible patient-trial pairs, confirming the correctness of the model. Figure 4d shows the percentage of exclusion criteria predicted as “excluded”. Importantly, patients meet more exclusion criteria in ineligible clinical trials than in eligible clinical trials. Similar to Figure 4b, no exclusion criteria are labeled as met by TrialGPT-Matching in most eligible and potentially eligible patient-trial pairs. This is a characteristic feature of patient-trial pairs that are explicitly excluded and can be exploited in patient-trial matching.

LLM aggregations: We also use LLMs to further aggregate the criterion-level predictions of TrialGPT, resulting in the general relevance and the eligibility scores (details in Methods). The general relevance score (0~100) is shown in Figure 4d, where the irrelevant patient-trial pairs are much lower than the other labeled groups. Eligible and ineligible/potential patient-trial groups have certain overlaps, but the former is still significantly higher than the latter. The eligibility score (−100~100) is shown in Figure 4h, where negative scores denote ineligible, positive scores denote eligible, and a score of 0 denotes neutral. Overall, the trends of LLM-aggregated eligibility scores follow those of the LLM-aggregated relevance score. Noticeably, the eligible patient-trial pairs and the excluded (but relevant) patient-trial pairs have the least distributional overlap in TrialGPT-aggregated eligibility score, which indicates its superiority in distinguishing these two groups.

In summary, criterion-level TrialGPT-Matching predictions can be aggregated into trial-level scores by TrialGPT-Ranking that are highly correlated with patient-trial eligibility. The results of linear aggregations demonstrate that eligible patient-trial pairs have the highest proportions of met inclusion criteria and unmet exclusion criteria, while ineligible patient-trial pairs have the highest proportions of met exclusion criteria. In addition, the LLM aggregations are also significantly correlated with the manual eligibility labels. These results suggest that the aggregated scores of TrialGPT can be used to rank or exclude clinical trials for patient recruitment.

(a) The percentage of inclusion criteria predicted as “included” by TrialGPT; (b) The percentage of inclusion criteria predicted as “not included”; (c) The percentage of inclusion criteria predicted as “no relevant information”; (d) The LLM-aggregated relevance score; (e) The percentage of exclusion criteria predicted as “excluded”; (f) The percentage of exclusion criteria predicted as “not excluded”; (g) The percentage of exclusion criteria predicted as “no relevant information”; (h) The LLM-aggregated eligibility score. “*” denotes p < 0.05, “**” denotes p < 0.01, “***” denotes p < 0.001, and “n.s.” denotes not significant (p > 0.05) by two-sided independent t-test. There are 60,240 unlabeled, 15,459 irrelevant, 6,981 excluded, 647 potential, and 8,173 eligible patient-trial pairs. Center line, median; box limits, upper and lower quartiles; whiskers, 1.5x interquartile range; points, outliers. Source data are provided as a Source Data file, including all the exact p values.

## Section: Results › TrialGPT-Ranking can effectively rank and exclude candidate clinical trials

In this section, we evaluate TrialGPT by ranking candidate clinical trials and excluding ineligible clinical trials for given patients (component Figure 1c). Based on the correlation analysis, we design a suite of scoring methods to aggregate criterion-level predictions of TrialGPT to generate a trial-level score for ranking the candidate trials. Similarly, we consider the top 500 clinical trials returned by TrialGPT-Retrieval for each patient in the three cohorts Table 2 shows the Normalized Discounted Cumulative Gain at rank 10 (NDCG@10), Precision at rank 10 (P@10), and Area Under the Receiver Operating Characteristic curve (AUROC) of different methods in comparison to state-of-the-art models, which are described in Methods.

Ranking candidate clinical trials: As shown in Table 2, TrialGPT-Ranking outperforms all compared baselines, including dual-encoder, cross-encoder, and encoder-decoder models trained on different biomedical and clinical natural language inference (NLI)35 datasets. The best baseline for ranking clinical trials is the cross-encoder BioLinkBERT36 trained on MedNLI37, which achieves the NDCG@10 of 0.4797 and the P@10 of 0.4281. The most effective features of GPT-4-based TrialGPT for ranking are the LLM-aggregated eligibility scores. They achieve NDCG@10 of 0.7252 and P@10 of 0.6724, which are much higher than other aggregations. Combining both linear and LLM aggregations yields the highest NDCG@10 performance of 0.7275 and the P@10 of 0.6699 for GPT-4-based TrialGPT-Ranking. While GPT-3.5-based TrialGPT-Ranking also surpasses all baselines, the improvements are not as significant as GPT-4-based TrialGPT-Ranking. It should be noted that the results are not directly comparable to the results of TREC CT participating systems as we used the initial corpora of more realistic sizes and reported the average performance on three different cohorts.

Excluding ineligible clinical trials: Table 2 also shows the AUROC of excluding candidate trials, which is modeled as a binary classification task. Similarly, the best baseline for excluding clinical trials is the cross-encoder BioLinkBERT36 trained on MedNLI37, achieving the AUROC of 0.6176. This result only shows marginal improvement over the random score baseline, indicating that the task of excluding ineligible trials presents significant challenges. Unlike in the task of ranking clinical trials, the percentage of inclusion criteria predicted as “not included” and the percentage of exclusion criteria predicted as “excluded” also achieve comparable AUROC individually. Again, both GPT-3.5-based and GPT-4-based TrialGPT-Ranking outperforms all baselines, and the combination of the features achieves an AUROC of 0.6582 and 0.7979, respectively.

On average, the feature combination of GPT-4-based TrialGPT-Ranking achieved the performance of 0.7314, which is about 43.8% better than the best performing baseline score of 0.5085. These experimental results show that TrialGPT can effectively rank candidate clinical trials and exclude ineligible clinical trials, which could facilitate the trial-matching process.

The Sign() function assigns suitable signs for the corresponding task, e.g., for “% Included”, it will be “+” for ranking and “-” for excluding clinical trials. Aggr.: aggregation. NDCG@10: normalized discounted cumulative gain at 10. P@10: precision at 10. AUROC: the area under the receiver operating characteristic curve.

## Section: Results › TrialGPT can reduce the screening time for patient-trial matching

To evaluate whether TrialGPT can assist clinicians in performing the patient recruitment task, we set up a user evaluation that mimics patient-trial matching in real clinical settings. The evaluation result is shown in Figure 5a. Here, we consider six oncology clinical trials. Among these trials, four are conducted at the National Cancer Institute and have a physician coauthor (C.F.) as principal or associate investigator, and the other two are highly related. The physicians also created six semi-synthetic clinical vignettes (cases 1 to 6, available in the Supplementary Note) based on actual, anonymized patient referral requests. Cases 1–3 are short summaries of patients, while cases 4–6 are more extensive descriptions. For each patient-trial combination, the matching task is to quickly screen the eligibility criteria to either reject the patient or include the patient for further investigation. Two medical doctors (Annotators X and Y) performed the tasks, where half of the patient-trial pairs have TrialGPT predictions, and the other half do not have them. We also ensure that for each patient-trial pair, one annotator screened with TrialGPT, and another without. The accuracy of annotations with TrialGPT is higher than without (97.2% vs. 91.7%), although both are above 90% and their differences are not statistically significant. The comparison results for matching efficiency are shown in Figure 5b. There is no significant time difference between Annotator X and Annotator Y in screening with TrialGPT (32.7s v.s. 37.8s, p=0.73) or without TrialGPT (57.5s v.s. 65.4s, p=0.75) by two-sided independent t-test, which indicates that they have similar baseline screening capabilities. We observe a consistent trend of improved ffeiciency with TrialGPT: 35.9% to 51.9% less time is spent for different patients, and 32.4% to 60.2% less time is spent among different trials. In general, more time saving is observed for long cases (43.5%) than for short cases (41.0%). The overall time saving for all patient-trial pairs is about 42.6%, which can greatly improve the efficiency of a team evaluating patient referrals for clinical trials.

Results of the patient-trial matching user study. (a) Experimental design and actual screening times of each patient-trial pair by two expert annotators; (b) Comparison of screening time aggregated by different clinical trials; (c) Comparison of screening time aggregated by different patient cases; (d) Comparison of screening time aggregated by short cases, long cases, annotators, and all pairs. Numbers in parentheses denote the sample sizes in the corresponding group of the comparison. Within the annotator (e.g., Annotator X or Y), significant tests are conducted by two-sided independent t-test. Other significant tests are two-sided paired t-tests. Trial A, B, C, D, E, and F denote NCT04432597, NCT05012098, NCT04287868, NCT04847466, NCT04719988, and NCT04894370, respectively. Source data are provided as a Source Data file.

## Section: Discussion

We propose TrialGPT, a framework for end-to-end patient-trial matching with LLMs. The technical novelty of TrialGPT is to utilize LLMs for three vital sub-tasks: (1) First-stage retrieval: TrialGPT-Retrieval can filter out most of the irrelevant clinical trials from a large initial collection containing tens of thousands of clinical trials; (2) Criterion-level prediction: TrialGPT-Matching can match patient and clinical trials at criterion-level with explanations, where previous models suffer from the lack of annotated instances and cannot provide explanations; (3) Aggregation of criterion-level predictions: TrialGPT-Ranking further utilizes LLMs to aggregate the criterion-level predictions to generate trial-level scores, which outperforms other linearly aggregated scores at ranking and excluding candidate clinical trials. The language understanding capability of LLMs is exploited in all tasks, and the language generation capability of LLMs lays the foundation for the explainability of the overall workflow. Comparing to the structurization approach adopted by other studies7,34, TrialGPT utilizes LLMs to analyze the patient summary and the criteria in natural language, which does not require the criteria to follow any formats and is thus more flexible.

For evaluation, we use three publicly available patient-trial matching datasets, where the patients are represented by a paragraph of free-text clinical summary. However, clinical trial matching sometimes requires the recruiters to check the patients’ information more comprehensively, which involves longitudinal clinical notes, lab values, and even imaging data. This requires the model to (1) attend to much longer contexts, (2) process structured data, and (3) process multi-modal inputs. These aspects have not been evaluated by this study but are worth exploring in future work. Additionally, future evaluations should investigate how TrialGPT performs when integrating data from electronic health records (EHRs), which often include a combination of structured and unstructured data sources. The ability to seamlessly incorporate such diverse data types would significantly enhance the real-world applicability and increase the validation sample size of our framework. Further, the SIGIR and TREC datasets focus on the semantics of the clinical trial inclusion/exclusion criteria, excluding factors such as geolocation and trial recruitment status as these are addressable through traditional structured query approaches. As a result, any use of TrialGPT would similarly need to ensure the identified trials are appropriate for a patient along these lines as well.

Our work does not justify the position that clinical trial matching should be fully automatic and exclude human recruiters. Experts should always be in the loop of medical AI deployments, and the TrialGPT matching results are only used to assist them in improved efficiency. Evaluation in real-life clinical trial matching scenarios should also focus more on efficiency improvement for human recruiters, instead of solely reporting the prediction performance. In this sense, the explanation capability of TrialGPT, or more generally LLMs, is particularly helpful. This is exemplified by our pilot user study showing that TrialGPT can significantly reduce 42.6% of the screening time on average.

While our experiments have shown promising results in patient-to-trial matching with TrialGPT, this study has three main limitations. First, TrialGPT relies on OpenAI’s GPT series LLMs such as GPT-3.5 and GPT-4 as the backbone model. Although GPT-4 is currently the most capable LLM, it is closed-source and can only be accessed via commercial applications or API. Future studies should explore using and fine-tuning other open-source LLMs as alternatives. Second, while our study proposes a novel framework of patient-to-trial matching with LLMs, there are various other prompting strategies for each of the TrialGPT components that are worth exploring in future work. Third, our pilot user study is of limited scope in sample size. Nonetheless, it offers insights into the potential benefits of LLMs for assisting clinical trial matching and provides impetus to conduct larger-scale prospective evaluations regarding the impact of LLM-assisted clinical workflows in future studies.

In summary, we present TrialGPT, a novel architecture that uses large language models to perform patient-trial matching. Our evaluations show that TrialGPT can effectively recall relevant clinical trials in a large-scale collection and accurately predict criterion-level eligibility with faithful explanations. We also explore different pooling methods to aggregate the criterion-level predictions to trial-level scores that can be used to rank or exclude a list of candidate trials. The pilot user study has clearly demonstrated that TrialGPT significantly reduces the screening time needed for human experts. As such, we anticipate that large language models can be valuable in assisting the process of patient-trial matching.

## Section: Methods › Patient cohorts

We use three publicly available cohorts in this study: the SIGIR 2016 cohort, the TREC 2021 CT cohort, and the TREC 2022 CT cohort. All three cohort annotations only use the patient note and eligibility criteria without considering the geolocations and recruitment status of the clinical trials. Their baseline characteristics are shown in Table 1.

## Section: Methods › SIGIR 2016

The original cohort contains 60 patient case reports, but 1 report is removed since the report is about a group of patients (topic ID 201426, “A group of 14 humanitarian service workers…”). Additionally, another case (topic ID 201428) was removed since the there are no relevance judgements for the patient. The patient notes are derived from the Clinical Decision Support (CDS) tracks in TREC 201448 and 201549, which are “medical case narratives created by expert topic developers that will serve as idealized representations of actual medical records”48. They typically describe the patient’s medical history, current symptoms, tests, eventual diagnosis, and treatments. Given a patient note, four medical assessors annotate each candidate clinical trial with three possible labels: (a) “would not refer this patient for this clinical trial”; (b) “would consider referring this patient to this clinical trial upon further investigation”; and (c) “highly likely to refer this patient for this clinical trial”. We consider the label a to be “irrelevant”, the label b to be “potential”, and the label c to be “eligible”. The candidate clinical trials for annotation are derived from pooling various retrieval methods.

## Section: Methods › TREC 2021/2022 CT

The TREC 2021 and 2022 CT tracks contain 75 and 50 patients, respectively. These patient notes are synthetic patient case descriptions, “such as what may be included as part of an admission note”. For each patient, they annotate three eligibility labels for the candidate clinical trial: irrelevant (“the patient is not relevant for the trial in any way”), excluded/ineligible (“the patient has the condition that the trial is targeting, but the exclusion criteria make the patient ineligible”), and eligible (“the patient is eligible to enroll in the trial”). The candidate clinical trials are pooled from the submission systems of TREC participants.

## Section: Methods › TrialGPT

TrialGPT is an architecture for patient-trial matching with large language models. It is composed of three modules: (1) TrialGPT-Retrieval for filtering out most of the irrelevant clinical trials for a given patient; (2) TrialGPT-Matching for criterion-by-criterion analysis of a given patient-trial pair; and (3) TrialGPT-Ranking for fine-grained re-ranking of a list of candidate clinical trials. TrialGPT is LLM-agnostic, meaning it can be plugged into different backbone LLMs. In this study, we mainly use the GPT-4 (model version: 0613) and GPT-3.5 API (model version: 0613) through Microsoft Azure’s OpenAI services. We used the openai package (version 1.30.5) in Python to call the API. In the manuscript, the default backbone LLM of TrialGPT is GPT-4 unless otherwise specified. We set the inference temperature to 0 for deterministic outputs.

## Section: Methods › TrialGPT-Retrieval

Given a free-text patient summary, TrialGPT-Retrieval first generates a list of keywords using large language models. These keywords are intended to filter out most of the irrelevant clinical trials in the initial collection. The prompt for keyword generation is shown in Supplementary Table 2. Denote the list of keywords generated for the patient as [w1,w2,…,wK], where K is the number of generated keywords and is set up to 32 in the prompt. The LLMs are also instructed to rank the keywords by importance.

We first conduct hybrid retrieval for each keyword to find relevant clinical trials. Specifically, for keyword wi, we send it to both the traditional BM25 retriever50 for lexical retrieval and the dense MedCPT retriever51 for semantic retrieval. For each considered clinical trial tj, its rank in terms of relevance from BM25 and MedCPT retriever are denoted as Rank(BM25, wi,tj) and Rank(MedCPT, wi,tj), respectively. For example, Rank(BM25, wi,tj) = 1 means that clinical trial tj is the most relevant (ranking the first) for the keyword wi returned by the BM25 retriever. We use reciprocal rank fusion52 between the MedCPT and BM25 retrievers for the same keyword, and a decaying weight for combining the scores across different keywords. Finally, the TrialGPT-Retrieval score sj for a clinical trial tj for the given patient can be calculated as:

where the inner sum is the fusion of different keywords with the decaying factor of 1/i, the outer sum is the combination of two retrievers (Ret∈{BM25, MedCPT}), and C is the constant used in reciprocal rank fusion, which we set to 20.

The clinical trials are then ranked by the TrialGPT-Retrieval score and the highest ranked ones are considered as the candidate clinical trials.

## Section: Methods › TrialGPT-Matching

Here we denote a patient note as a list of P sentences [s1,s2,…,sP], a clinical trial as composed of the background information Β (containing the title, conditions, interventions, and the brief summary ), a list of M inclusion criteria [i1,i2,…,iM], and a list of N exclusion criteria [e1,e2,…,eN]. The objective of this module is to output a free-text relevance explanation R, a list of relevant sentence IDs S, and the eligibility prediction E for each criterion based on the input patient note. For an inclusion criterion,

while for an exclusion criterion,

We use different label sets for inclusion and exclusion criteria because the latter are often ambiguous. For example, exclusion criteria of “Pregnancy,” “The patient should not be pregnant,” and “Pregnant patients will be excluded” serve the same purpose. Traditional entailment labels might not be suitable to distinguish the semantic differences, while our eligibility-oriented label sets provide an end-to-end solution.

We make two LLM inference calls for each patient-trial pair: one for all inclusion criteria, and another one for all exclusion criteria. Overall, the prompt includes the task description, the clinical trial background information Β, and the inclusion ([i1,i2,…,iM]) and exclusion ([e1,e2,…,eN]) criteria. Motivated by chain-of-thought prompting53, we prompt the model to first generate the relevance explanation as grounding for future predictions of the relevant sentence IDs and the eligibility labels. In addition, we also prompt the model to generate criterion-level predictions in the JSON format, which can be easily parsed for aggregations. The TrialGPT prompts are shown in Supplementary Tables 3 and 4.

## Section: Methods › TrialGPT-Ranking

After getting the criterion-level predictions from TrialGPT-Matching, TrialGPT-Ranking then aggregates such scores to generate a trial-level score that can be used for practical applications such as ranking and excluding clinical trials. Specifically, we denote the eligibility predictions of TrialGPT for the inclusion criteria and exclusion criteria as [E(i1),E(i2),…,E(iM)] and [E(e1),E(e2),…,E(eN)], respectively. M is the number of inclusion criteria and N is the number of exclusion criteria in the trial.

Linear aggregation: six scores are simply derived based on the percentages of different eligibility predictions. While more sophisticated scoring methods can be used, we intentionally use these simple and linear aggregation strategies for better probing the capabilities of LLMs.

For a trial’s inclusion criteria:

For a trial’s exclusion criteria:

LLM aggregation: In addition, TrialGPT also uses LLMs to aggregate the criterion-level predictions by the prompt shown in Supplementary Table 5. The generated scores are directly used as aggregation scores. Specifically, we consider two main features: general relevance and eligibility: The general relevance (R) indicates how relevant a patient is to clinical trial, while the eligibility score (S) denotes how eligible the patient is to the clinical trial. We restrict that:

where 0 indicates that the patient is irrelevant to the clinical trial and 100 suggests that the patient is exactly relevant to the clinical trial. We further restrict that:

based on the assumptions that the absolute value of eligibility cannot be higher than relevance.

Feature combination: We further combine the linear and LLM aggregation features, generating the improved scores for ranking and excluding:

where I is an indicator function:

## Section: Methods › Criterion-level expert evaluation

Three annotators (F.C., C.G., and C.F.) are provided with 1,015 pairs of patient-criterion predictions by TrialGPT sampled from our patient cohorts. For each patient-criterion pair, the annotators first evaluate the correctness of TrialGPT explanation by “Correct”, “Partially Correct” or “Incorrect”. If at least two annotators provide the same label, it will be used as the consensus. If annotators choose three different scores for a patient-criterion pair, it will be labeled as “Partially Correct”. The annotators then annotate the relevant sentence locations for the criterion, and the consensus is the union of all annotator-provided sentences. Finally, the annotator provides the annotation of eligibility, with the same candidate label set as that of TrialGPT. Similarly, if at least two annotators assign the same eligibility label, it will be used as the consensus. If all three annotators assign different eligibility labels, a second round of discussion will be scheduled until there is a consensus label.

## Section: Methods › Compared methods

The core of TrialGPT lies in the prediction of patient-criterion eligibility. These predictions are then aggregated for the ranking and excluding tasks. As such, we compare TrialGPT to a variety of pre-trained language models that can predict patient-criterion eligibility. Since there are no existing patient-criterion eligibility annotations for training a supervised model, we consider transfer learning from the biomedical NLI datasets. Specifically, we use three categories of baselines: dual-encoder, cross-encoder, and encoder-decoder.

Dual-encoder models are also known as bi-encoder, where the patient note and the criterion are separately encoded by pre-trained transformers, and the eligibility is modeled as the similarity of the encoding vectors:

and:

where Enc denotes the pre-trained transformer encoder, and h is the dimension of the vector representations.

Cross-encoder models take both the patient note and the criterion as input, which enables cross-attention computations between the tokens in both texts. The eligibility prediction is modeled as a 3-way classification task based on the special [CLS] embedding of BERT54. We use label space mapping functions f that maps an NLI label to an eligibility label:

where

and

Then we compute the combination scores based on the criterion-level prediction, similar to the feature combination strategy used by TrialGPT:

Encoder-decoder models also take both the patient note and the criterion as input to the encoder, but instead of outputting a classification prediction, they generate the predicted NLI labels, e.g., “entailment”, “contradiction”, or “neutral”. These NLI labels are then mapped to eligibility labels that will be aggregated into the combination scores by the same methods described above for cross-encoder models.

## Section: Methods › Evaluation settings

Following the SIGIR and TREC evaluation guidelines, we define the relevance score ri of a clinical trial ci given a specific patient as:

We report the recall at different depths k for the first stage retrieval. Specifically, we denote the retrieved list of clinical trials as [c1,c2,…,ck], where k is the number of considered candidates. Their relevance scores are denoted as [r1,r2,…,rk]. Recall@k is a measurement of retrieval quality, which is computed by:

where R is the sum of all clinical trial relevance score in the considered collection.

We report NDCG@10 and P@10 for ranking candidate clinical trials, and AUROC for excluding ineligible clinical trials. Patient-trial pairs with unlabeled eligibility are not included for the computation of metrics.

For computing NDCG@10 and P@10, we denote the ranked list of clinical trials as [c1,c2,…,ck], where k is the number of considered candidates. Their relevance scores are denoted as [r1,r2,…,rk]. NDCG@k is a measurement ranking quality, which is computed by:

where

and

where [r′1,r′2,…,r′T] denotes the relevance of an ideal ranking.

P@10 is another metric for ranking quality, computed by:

where R denotes the set of relevance labels.

We draw the receiver operating characteristic (ROC) curve and compute the area under the ROC curve (AUROC) values using the sklearn package in Python.

## Section: Methods › Pilot user study

The pilot user study mimics a common task at the cancer center, where the trial organizer screens patient referral requests against the candidate clinical trials. The patient note varies from a short paragraph in the email to a long document sent via fax. We consider six clinical trials (NCT04432597, NCT05012098, NCT04287868, NCT04847466, NCT04719988, and NCT04894370) as the candidates, where the first four are managed by one physician coauthor (C.F.) and the other two are highly related. The physician also created six clinical vignettes (3 short and 3 long) based on real patient encounters, with the personally identifiable information modified. The task objective is to screen whether the patient is definitely ineligible (“No”) or potentially eligible and should be included for further investigation (“Maybe”). Two MD annotators (Q.J. and E.X.) recorded the time needed to make the decision after familiarizing themselves with the patient note. Each annotator screens half of the patient-trial pairs with TrialGPT and another half without. We also ensure that each patient-trial pair is screened by one annotator with TrialGPT and another without. The evaluation setting is visualized in Figure 5a.

## Section: Acknowledgments

This research was supported by the NIH Intramural Research Program, National Library of Medicine. We would like to thank the organizers of the SIGIR and TREC Clinical Trial tasks for making their datasets publicly available.

## Section: Data availability

The TREC Clinical Trial 2021 and 2022 cohorts can be downloaded from http://www.trec-cds.org/2021.html and http://www.trec-cds.org/2022.html, respectively. The SIGIR cohort is publicly available at https://data.csiro.au/collection/csiro:17152. The clinical vignettes for the user study are available in the Supplementary Materials. The criterion-level annotations generated in this study have been deposited in the Hugging Face database under accession code: https://huggingface.co/datasets/ncbi/TrialGPT-Criterion-Annotations. Preprocessed data files generated in this study have been deposited in the GitHub database under accession code: https://github.com/ncbi-nlp/TrialGPT55. Source data are provided with this paper.

## Section: Associated Data › Data Availability Statement

The TREC Clinical Trial 2021 and 2022 cohorts can be downloaded from http://www.trec-cds.org/2021.html and http://www.trec-cds.org/2022.html, respectively. The SIGIR cohort is publicly available at https://data.csiro.au/collection/csiro:17152. The clinical vignettes for the user study are available in the Supplementary Materials. The criterion-level annotations generated in this study have been deposited in the Hugging Face database under accession code: https://huggingface.co/datasets/ncbi/TrialGPT-Criterion-Annotations. Preprocessed data files generated in this study have been deposited in the GitHub database under accession code: https://github.com/ncbi-nlp/TrialGPT55. Source data are provided with this paper.


---

# Meta-research on reporting guidelines for artificial intelligence: are authors and reviewers encouraged enough in radiology, nuclear medicine, and medical imaging journals?

- **Authors:** Burak Koçak, Ali Keleş, Fadime Köse
- **Issuer:** Diagnostic and interventional radiology (Ankara, Turkey)
- **Type:** Scientific article
- **Published:** 2024-02-20
- **Language:** en
- **DOI:** 10.4274/dir.2024.232604
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38375627/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractPURPOSETo determine how radiology, nuclear medicine, and medical imaging journals encourage and mandate the use of reporting guidelines for artificial intelligence (AI) in their author and reviewer instructions.METHODSThe primary source of journal information and associated citation data used was the Journal Citation Reports (June 2023 release for 2022 citation data; Clarivate Analytics, UK). The first-and second-quartile journals indexed in the Science Citation Index Expanded and the Emerging Sources Citation Index were included. The author and reviewer instructions were evaluated by two independent readers, followed by an additional reader for consensus, with the assistance of automatic annotation. Encouragement and submission requirements were systematically analyzed. The reporting guidelines were grouped as AI-specific, related to modeling, and unrelated to modeling.RESULTSOut of 102 journals, 98 were included in this study, and all of them had author instructions. Only five journals (5%) encouraged the authors to follow AI-specific reporting guidelines. Among these, three required a filled-out checklist. Reviewer instructions were found in 16 journals (16%), among which one journal (6%) encouraged the reviewers to follow AI-specific reporting guidelines without submission requirements. The proportions of author and reviewer encouragement for AI-specific reporting guidelines were statistically significantly lower compared with those for other types of guidelines (P < 0.05 for all).CONCLUSIONThe findings indicate that AI-specific guidelines are not commonly encouraged and mandated (i.e., requiring a filled-out checklist) by these journals, compared with guidelines related to modeling and unrelated to modeling, leaving vast space for improvement. This meta-research study hopes to contribute to the awareness of the imaging community for AI reporting guidelines and ignite large-scale group efforts by all stakeholders, making AI research less wasteful.CLINICAL SIGNIFICANCEThis meta-research highlights the need for improved encouragement of AI-specific guidelines in radiology, nuclear medicine, and medical imaging journals. This can potentially foster greater awareness among the AI community and motivate various stakeholders to collaborate to promote more efficient and responsible AI research reporting practices.Keywords: Artificial intelligence, machine learning, guideline, checklist, reporting

## Section: Text

Poor or suboptimal reporting of medical research is regarded as a significant and widespread issue that contributes to the waste of scarce and valuable resources invested in research projects.1, 2, 3, 4, 5 For such studies, readers cannot assess the validity of the method relative to existing knowledge, and thus the reliability and reproducibility of the findings.6 This hinders the clinical translation of promising research findings7 and their comparability with other publications for evidence synthesis or meta-analysis.8 The adherence to consensus-based reporting standards (i.e., reporting guidelines) is one of the principal methods for reducing the risk of poor reporting. To promote this, vast projects, like Enhancing the QUAlity and Transparency Of health Research (EQUATOR) network, were started, and several reporting guidelines were developed and published in the literature.9, 10 Typically, these guidelines take the form of online or offline checklists, flowcharts, or explicit texts that instruct authors on how to report their research. Several studies researched the effectiveness of adhering to reporting guidelines in various study types. They found that adherence is associated with improved manuscript quality in peer review,11 favorable reviewer ratings and editorial decisions,12 higher citation counts and opportunity to be published in journals with a higher impact factor,13 and improved completeness and quality of the research.14, 15, 16, 17, 18, 19, 20, 21, 22

Similar to healthcare literature, medical artificial intelligence (AI) research faces poor or suboptimal reporting issues. With the massive growth of healthcare literature using AI, including medical imaging,23 the need for complete and structured reporting of prognostic and diagnostic studies that use machine learning algorithms or models has increased. An expanding body of research indicates that AI studies frequently fall short of expected reporting standards,24, 25 lacking sufficient details on modeling and its evaluation, and failing to adequately address potential sources of bias.26, 27, 28, 29, 30, 31, 32 Multiple specific guidelines relevant to AI studies have been developed to address these issues.25, 33, 34, 35, 36, 37, 38, 39, 40, 41 Examples of these guidelines include Checklist for AI in Medical Imaging (CLAIM),42, 43 Fairness, Universality, Traceability, Usability, Robustness, and Explainability-AI (FUTURE-AI),44 Minimum Information about Clinical AI Modelling (MI-CLAIM),45 CheckList for EvaluAtion of Radiomics research (CLEAR),46 and METhodological RadiomICs Score (METRICS).47 In addition, as a continuation of previous efforts, several guidelines are currently under development, such as Standards for the Reporting of Diagnostic Accuracy Studies-AI (STARD-AI) for AI-centered diagnostic test accuracy studies and Transparent Reporting of a Multivariable Prediction Model for Individual Prognosis or Diagnosis-AI (TRIPOD-AI) for those related to diagnostic models.48, 49 The most widely recognized AI guidelines and ones currently under development can be found in the following seminal papers.50, 51

The availability of reporting guidelines and checklists has not yet resolved the problem of inadequate reporting. While editorial guidance advocating for transparent reporting is widespread and well-intentioned, authors frequently overlook or fail to adhere to these guidelines.52, 53, 54, 55, 56, 57 In a very recent citation analysis of an AI checklist on medical imaging and a meta-research on radiomics, claims regarding the use of checklists and quality scoring tools for self-reporting (i.e., reporting with filling checklists by study authors) have been supported.26, 32 Journals can significantly impact the quality of reporting by encouraging or mandating responsible reporting practices, such as the use of reporting guidelines and checklists in their author and reviewer instructions.58, 59 However, research on the encouragement of AI reporting guidelines by journals specialized in radiology, nuclear medicine, and medical imaging is scarce.60 Investigating this issue could yield valuable insights to foster higher-quality research within these journals.

This meta-research study aims to determine how these journals encourage and mandate (i.e., requiring a filled-out checklist) the use of AI reporting guidelines in their author and reviewer instructions by comparing reporting guidelines that are specific to AI, related to modeling, and unrelated to modeling.

## Section: Methods

Figure 1 presents the key study steps of this meta-research.

Key study steps. WoS, Web of Science; RNMMI, Radiology, Nuclear Medicine, and Medical Imaging; SCIE, Science Citation Index Expanded; ESCI, Emerging Sources Citation Index; Q1, first quartile; Q2, second quartile; PDF, portable document format; AI, artificial intelligence.

## Section: Methods › Dataset

The primary source of journals and associated citation data used was the Journal Citation Reports (June 2023 release for 2022 citation data; Clarivate Analytics, UK). This report was based on data obtained from the Web of Science (WoS) (Clarivate Analytics, UK).

Journals indexed in the WoS category, radiology, nuclear medicine, and medical imaging, that met the following criteria were included in this study: inclusion in the Science Citation Index Expanded (SCIE) or Emerging Sources Citation Index (ESCI) and placement within the first quartile (Q1; top 25% of journals in the list) or second quartile (Q2; journals in the top 25%–50% group) based on the 2022 Journal Impact Factor. This analysis excluded journals that had a limited scope, specifically those that focused solely on review articles (i.e., not publishing original research articles), as these journals were not expected to publish articles using AI reporting guidelines.

Two readers, each in their third year of radiology residency and with prior experience conducting systematic reviews on reporting quality in AI or radiomics, accessed the author and reviewer instructions from the journals’ websites and saved them as PDF files. The task was distributed evenly among the readers, and they also reviewed each other’s resulting files. All author and reviewer instructions were accessed between September 4 and 7, 2023. In the case of multiple instructions, the most up-to-date version was selected.

To mitigate errors during the assessment of instructions, a custom Python script based on the PyMuPDF package was used to automatically annotate certain terms within the PDF documents. The terms covered AI, machine learning, reporting, guidelines, checklists, and their specific names or acronyms. The code and exact terms can be accessed at https://github.com/radiomic/PDFhighlighter.

## Section: Methods › Evaluation of author and reviewer instructions

The author and reviewer instructions that were automatically annotated by the script were evaluated by the same readers who downloaded the instructions. All evaluations underwent a meticulous review process overseen by an additional reader possessing 8 years of expertise as a radiology specialist, complemented by over 5 years of research experience in machine learning, radiomics, and systematic reviews. Final decisions were reached by consensus among all readers.

The collected data primarily fell into two categories: encouragement of authors or reviewers and the presence of submission requirements for filled-out checklists in case of encouragement. When evaluating the encouragement, to elicit a positive evaluation from readers, it was imperative to explicitly state the name of the reporting guideline or make a direct reference to it. In addition, encouragement was defined as any sort of mention of specific guidelines. For instance, if authors and reviewers are recommended for adherence, referral, or usage of the guidelines, even if not explicitly intended for integration into their workflow, it was considered encouragement. The inclusion of general references to the central source or hub of guidelines or checklists, such as the EQUATOR network website, was not regarded as a specific encouragement in this work. To fulfill the submission requirement (i.e., mandating), this study sought a clear indication that the filled-out checklist would be uploaded to the submission system as an integral part of both the manuscript and peer review processes. The submission systems were only investigated when the submission requirements were unclear in the instructions. Checklists without an associated publication in a journal (i.e., checklists as part of journal instructions without a digital object identifier) were not considered as a reporting guideline.

Three types of reporting guidelines were analyzed as follows: i) AI-specific reporting guidelines; ii) those related to modeling (e.g., diagnostic or prognostic modeling; may or may not be associated with AI or machine learning); and iii) those unrelated to modeling. AI-specific reporting guidelines and those related to modeling included those specified in two recent seminal articles.50, 51 For AI-specific guidelines (e.g., CLAIM, Consolidated Standards of Reporting Trials for AI (CONSORT-AI), Standard Protocol Items: Recommendations for Interventional Trials for AI (SPIRIT-AI), FUTURE-AI, MI-CLAIM), this study referred to the publication of Klontzas et al.50, which did not limit its scope to a specific data type. For guidelines related to modeling, including AI-specific ones (e.g. TRIPOD), this study referred to the paper of Klement and El Emam51, which primarily focused on structured data. Due to the potential omission of relevant reporting guidelines in these papers, this study refrained from confining its criteria to those listed in the aforementioned articles.

## Section: Methods › Statistical analysis

Statistical analysis was performed using Jamovi (version 2.2.5). The majority of the findings were presented through descriptive statistics, wherein percentages were rounded to the nearest whole number. The inter-reader agreement analysis of the first two readers was conducted using Cohen’s kappa or percentage agreement, as appropriate. The following grading system was used to interpret Cohen’s kappa: kappa ≤0.00, no; 0.00< kappa ≤0.20, slight; 0.20< kappa ≤0.40, fair; 0.40< kappa ≤0.60, moderate; 0.60< kappa ≤0.80, substantial; 0.80< kappa ≤1, almost perfect agreement. Comparison of the distribution of quantitative variables was conducted using either the Student’s t-test or the Mann–Whitney U test, depending on the statistical normality of the data. The chi-square test or Fisher’s exact test was employed to assess differences in the distribution of categorical variables across various citation variables between subjects. Furthermore, McNemar’s test was used for the same purpose within subjects, and the continuity correction was also applied. A P value of <0.05 was considered statistically gnificant.

## Section: Results

Encouragement of authors and reviewers for the reporting guidelines with and without submission requirements. AI, artificial intelligence. *Only the top five most frequently encouraged reporting guidelines were included.

## Section: Results › Baseline characteristics of journals

Out of 102 Q1 and Q2 radiology, nuclear medicine, and medical imaging journals indexed in SCIE and ESCI databases, 98 were included in this study. Four journals were excluded because they published only review articles. Of the journals included, 66 were from SCIE (Q1/Q2, 32/34), with a median 2022 impact factor of 3.9 (interquartile range: 2.4). The remaining 32 journals were from ESCI (Q1/Q2, 16/16), with a median 2022 impact factor of 2.25 (interquartile range: 1.9).

For all 98 journals, instructions specific to authors were found. However, specific instructions for reviewers or referees were found for 16 journals only (16%).

## Section: Results › Analysis of author instructions

Table 1 summarizes the encouragement of authors to use reporting guidelines that are specific to AI, related to modeling, and unrelated to modeling, as well as the requirement of submission for these reporting guidelines.

Considering all 98 journals, only five journals (5%) encouraged the authors to follow AI-specific reporting guidelines. Table 2 presents the AI-specific guidelines recommended in these journals: CLAIM (n = 3), Proposed Requirements for Cardiovascular Imaging-Related Machine Learning Evaluation (PRIME) (n = 1), and Checklist for AI in Medical Physics (CLAMP) (n = 1).42, 61, 62 Of these, three (60%) required a filled-out checklist along with the submission.

In total, 30 journals (31% of 98) endorsed at least one reporting guideline related to modeling, including both general modeling guidelines and AI-specific ones: TRIPOD (n = 26), along with the three aforementioned AI reporting guidelines, namely CLAIM, PRIME, and CLAMP.42, 61, 62, 63 One journal encouraged two modeling-related guidelines (TRIPOD and CLAIM). Of the 30 journals, only four (13%) required a filled-out checklist along with the submission. Furthermore, only one of the journals, Ultrasound in Obstetrics and Gynecology, encouraged TRIPOD and mandated a filled-out checklist.

A total of 75 journals (77% of 98) encouraged at least one guideline unrelated to modeling. The frequency of the most well-known guidelines in these categories is as follows: CONSORT (n = 61), Preferred Reporting Items for Systematic Reviews and Meta-Analyses (PRISMA) (n = 51), Animal Research: Reporting of In Vivo Experiments (ARRIVE) (n = 45), STARD (n = 44), and Strengthening the Reporting of Observational Studies in Epidemiology (STROBE) (n = 42).64, 65, 66, 67, 68 Of these journals, 36 (48%) required a filled-out checklist along with the submission.

The level of encouragement for authors, both with and without submission requirements, regarding the naming of reporting guidelines, is summarized in Figure 2, alongside a comparison with that of reviewers.

Statistically significant differences were observed in the proportions of author encouragement among pairwise comparisons of AI-specific reporting guidelines, those related to modeling, and those unrelated to modeling (P < 0.001 for all). Notably, the encouragement level for guidelines unrelated to modeling was consistently higher across all pairs.

There were no statistically significant differences in the distribution of author encouragement status concerning the journal index (i.e., SCIE vs. ESCI) and quartile (i.e., Q1 vs. Q2) (P > 0.05 for all).

Regarding the encouragement of reporting guidelines related to modeling in general, including AI-specific ones, as well as those unrelated to modeling, the inter-rater reliability analysis yielded almost perfect agreement, with Cohen’s kappa values ranging between 0.916 and 0.950.

Encouragement of authors and reviewers for the reporting guidelines with and without submission requirements. AI, artificial intelligence. *Only the top five most frequently encouraged reporting guidelines were included.

## Section: Results › Analysis of reviewer instructions

Table 1 summarizes the encouragement of reviewers to use reporting guidelines that are specific to AI, related to modeling, and unrelated to modeling, as well as the requirement of submission for these reporting guidelines.

Of the 16 journals that had instructions for reviewers, only one (6%), European Radiology, encouraged the reviewers to follow an AI-specific reporting guideline (CLAIM), which can also be regarded as a modeling-related guideline, without a filled-out checklist along with the submission of peer review.42 The primary purpose was, however, to check whether the authors provided the checklist.

Regarding the guidelines that are not related to modeling, six journals (38% of 16) encouraged the reviewers to follow at least one of those. The journals most frequently recommended CONSORT (n = 4) and PRISMA (n = 4) without a filled-out checklist along with the submission of peer review.67, 68

The summary of reviewer encouragement, both with and without submission requirements, regarding the naming of reporting guidelines, is depicted in Figure 2, alongside a comparison with that of the authors.

There was a statistically significant difference in the proportion of reviewer encouragement between AI-specific or modeling-related reporting guidelines and those unrelated to modeling (P < 0.025), with the latter being the higher.

There were no statistically significant differences in the distribution of reviewer encouragement status against the journal index (i.e., SCIE vs. ESCI) and quartile (i.e., Q1 vs. Q2) (P > 0.05 for all).

For reviewers, the encouragement of reporting guidelines related to modeling in general, including AI-specific ones, as well as those not related to modeling, resulted in high inter-rater reliability, with percentage agreement values ranging between 79% and 93%.

## Section: Discussion › Overview

This meta-research investigated how radiology, nuclear medicine, and medical imaging journals encourage and mandate (i.e., requiring a filled-out checklist) the use of AI reporting guidelines in their author and reviewer instructions. The results were presented by comparing reporting guidelines that are specific to AI, related to modeling, and unrelated to modeling. It was found that only a very small number of journals encouraged (5%, 5/98) and mandated (3%, 3/98) the use of AI reporting guidelines (i.e., CLAIM, PRIME, and CLAMP) for authors. In addition, only one journal (6% of 16 available reviewer instructions) encouraged the reviewers to follow AI reporting guidelines (i.e., CLAIM), without any requirement of submission. Encouragement and the mandated use of AI-specific guidelines and those related to modeling in the journals were generally lower compared with those unrelated to modeling.

## Section: Discussion › Previous related works

There is only one recent closely related study to this research in which the endorsement of AI reporting guidelines in radiology journals has been systematically analyzed.60 In their seminal study, Zhong et al.60 investigated the endorsement of 15 general reporting guidelines and 10 AI reporting guidelines. Of the 117 SCIE journals included, the authors found that CLAIM (1.7%, 2/117) was the only and the most implemented AI reporting guideline, while the other nine AI reporting guidelines were not mentioned. This study found that five (5%) out of the 98 journals encouraged AI-specific guidelines. The disparity in rates can be attributed to two methodological issues. First, the journals differed in their index sources. Second, our study encompassed half of the journals indexed in SCIE and ESCI (i.e., Q1–Q2). In contrast, Zhong et al.60 exclusively included all SCIE journals. Furthermore, the AI reporting guidelines considered for these works were different. This study referenced two prior works and imposed no additional restrictions on their use, provided that they were in the form of a publication (i.e., not a custom checklist that appears on the instructions of journals).50, 51 The authors of the prior investigation restricted their assessment to 10 AI reporting guidelines. Furthermore, both studies reached the same conclusion that the endorsement or encouragement to follow AI reporting guidelines in these journals was remarkably low. Their main findings were complementary and mutually reinforcing.

Given the scarcity of literature on the encouragement of AI reporting guidelines in radiology, nuclear medicine, and medical imaging journals, it would be beneficial to discuss studies that are not specifically pertinent to AI but are nevertheless extremely relevant to the encouragement of and mandating reporting guidelines. In a cross-sectional study, Malički et al.69 analyzed a representative sample of journal instructions for authors across multiple scientific fields, including health sciences. The instructions of 13% of journals suggested the use of reporting guidelines, while only 2% mandated its use. In addition, the authors discovered that journals in the health or life sciences, as well as those published by prominent publishers, were more likely to include reporting guidelines or standards in their author instructions. In a different study, Agha et al.70 investigated the impact of the mandatory implementation of reporting guidelines on the quality of reporting in a surgical journal. Compliance with STROBE, CONSORT, and PRISMA dramatically improved after the policy implementation. The authors observed that implementing a policy demanding the submission of a completed reporting checklist for observational research, randomized controlled trials, and systematic reviews can increase compliance. In addition, they recommended similar approaches for various journals and study types. In another seminal study, Hirst and Altman focused on the encouragement of reviewers to utilize reporting guidelines for 116 health research publications.59 They discovered that 41 (35%) of the journals offered reviewers with online instructions. In addition, they revealed that nearly half of the online instructions referred to these tools without providing clear instructions on how to use them.

## Section: Discussion › Potential reasons for low rates

Considering the relevant works above and the present study, it is evident that journals do not encourage and mandate AI reporting guidelines frequently. The potential causes can only be speculated because their analysis falls outside the scope of this study. The editorial team of the journals may wrongly presume that researchers are aware of these fundamental aspects of rigorous and transparent reporting and that authors are entirely responsible for implementing them, not the journals. The journals may also be hesitant to incorporate appropriate reporting practices through reporting guidelines, and they may be unwilling to address scientific misconduct and correct publication errors.71, 72, 73 The editors may also not want to unintentionally overburden the authors with too many instructions. Even if journals encourage good reporting practices, researchers may be resistant to fundamental change. Furthermore, despite the validity of these tools, journals may not agree on the importance of reporting guidelines and may be hesitant to recommend their usage in the absence of convincing proof of their effectiveness.

## Section: Discussion › What are the following steps?

In light of the outstanding and exponential growth of AI research on medical imaging over the past decade,23 it is necessary to promote the highest-quality research. It would be advantageous to conduct additional research to define the effectiveness of AI reporting guidelines. Such research will help persuade journals to encourage and mandate them. Hence, there is a need for further assessment of AI reporting guidelines to determine their optimal utilization. This assessment should consider whether they should be incorporated into the study design, applied during ongoing research, utilized solely for reporting purposes post-study completion, or implemented at the request of journals, among other potential considerations. Enhancing our understanding of the factors that influence the dissemination and implementation of these tools and strategies is crucial for improving their efficacy and promoting their broader adoption. Future research should investigate the obstacles journals might experience when adopting such policy changes in their journals, as well as how automated tools could minimize their workload while guaranteeing adherence to these reporting guidelines. Furthermore, radiology, nuclear medicine, and medical imaging journals may collaborate to improve reporting standards for research. These group initiatives should also be supported by scientific organizations, universities, institutions, societies, and funding agencies. This would make it more difficult for authors receiving negative reviews due to inadequate reporting to choose journals with more flexible reporting policies. This could enhance the overall reporting quality of the scientific literature. In certain areas of medical research, such as rehabilitation and disability, the journals established such collaborations.74 As of 2014, 28 prominent rehabilitation and disability journals have joined a group to require the adherence to reporting guidelines to increase the quality of research reporting, not just inside their journal but also within their field of medicine and research. They jointly published an editorial, announcing their agreement and urging authors to adhere to appropriate EQUATOR reporting guidelines when preparing articles for submission. They also requested reviewers to utilize reporting guidelines when evaluating submissions.74 A similar group effort is crucial to improve the overall reporting quality of AI research in radiology, nuclear medicine, and medical imaging journals.

## Section: Discussion › Limitations

This study has a few limitations. First, it assumed that instructions are the sole location where reporting guidelines that are encouraged or mandated can be found. However, some of the requirements editors put on authors and reviewers may not be necessarily outlined in the instructions. For instance, the submission systems of all the journals were not thoroughly analyzed to check whether they encouraged or requested the use of guidelines during the submission and/or review processes. It was presumed that this was not common practice. Nonetheless, their submission systems were only investigated when the submission requirements were not clear in the instructions. Second, only Q1 and Q2 SCIE and ESCI journals indexed in the WoS were included due to their well-known high standards for indexing. Therefore, it is unlikely to represent the editorial standards of all journals. To diversify the journal characteristics, Q1 and Q2 ESCI journals were included instead of Q3 and Q4 SCIE journals. However, achieving a perfect representation of journals in terms of diversity should not be a major concern in an exploratory study focusing on a new area of reporting guidelines. Third, while downloading the journal instructions, they were double-checked for accuracy. Due to the complex and multi-layered design of certain journal websites, some parts of the instructions may have been omitted. Additionally, this study aimed to evaluate the automatically annotated content of the instructions through independent readings by two readers, with consensus reached through consultation with a third reader. This study may have missed any reporting guidelines that were recommended or deemed necessary in the submission. However, the impact of missing instructions and their content analysis will likely be minor. Finally, the instructions were downloaded over a brief time frame (between September 4 and 7, 2023). If journals had improved their instructions after this period, these changes would not have been reflected in the results.

In conclusion, this meta-research study provides an overview of instructions for authors and peer reviewers across radiology, nuclear medicine, and medical imaging journals. It specifically examines the encouragement of AI-specific reporting guidelines and their submission requirements, comparing them with guidelines related to modeling and those unrelated to modeling. However, the findings indicate that these AI-specific guidelines are not commonly encouraged and mandated (i.e., requiring a filled-out checklist) by these journals, compared with other guidelines. To further encourage the use of these tools, all stakeholders, including developers, journal managers, editors, reviewers, authors, and funders, are required to collaborate. Given their position at the forefront of AI, if more of these journals enforce or encourage responsible reporting through guidelines, the value of articles and AI research may increase and become less wasteful.


---

# Mining for Potent Inhibitors through Artificial Intelligence and Physics: A Unified Methodology for Ligand Based and Structure Based Drug Design

- **Authors:** Jie Li, Oufan Zhang, Kunyang Sun, Yingze Wang, Xingyi Guan, Dorian Bagni, Mojtaba Haghighatlari, Fiona L Kearns, Conor Parks, Rommie E Amaro, Teresa Head-Gordon
- **Issuer:** Journal of chemical information and modeling
- **Type:** Scientific article
- **Published:** 2024-06-06
- **Language:** en
- **DOI:** 10.1021/acs.jcim.4c00634
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38843070/
- **Licence:** CC-BY

## Section: Abstract

AbstractDetermining the viability of a new drug molecule is a time- and resource-intensive task that makes computer-aided assessments a vital approach to rapid drug discovery. Here we develop a machine learning algorithm, iMiner, that generates novel inhibitor molecules for target proteins by combining deep reinforcement learning with real-time 3D molecular docking using AutoDock Vina, thereby simultaneously creating chemical novelty while constraining molecules for shape and molecular compatibility with target active sites. Moreover, through the use of various types of reward functions, we have introduced novelty in generative tasks for new molecules such as chemical similarity to a target ligand, molecules grown from known protein bound fragments, and creation of molecules that enforce interactions with target residues in the protein active site. The iMiner algorithm is embedded in a composite workflow that filters out Pan-assay interference compounds, Lipinski rule violations, uncommon structures in medicinal chemistry, and poor synthetic accessibility with options for cross-validation against other docking scoring functions and automation of a molecular dynamics simulation to measure pose stability. We also allow users to define a set of rules for the structures they would like to exclude during the training process and postfiltering steps. Because our approach relies only on the structure of the target protein, iMiner can be easily adapted for the future development of other inhibitors or small molecule therapeutics of any target protein.

## Section: Introduction

Discovery of new drugs that inhibit target proteins usually follows either a screening-based approach or a rational design approach.1,2 If no explicit information about either the structure of the protein target or a ligand that might bind to the protein is available, the screening of a large database might be the only realistic approach to identify a starting point for drug development. However, any additional information about the structure of either the protein or the ligand can narrow down the search space significantly and encourages rational ligand based or structure based drug design.2,3 The process of rational drug design requires either exquisite domain knowledge and devoted time by an experienced medicinal chemist or using an automated workflow that relies on virtual screening of protein–ligand databases combined with physics-based modeling, such as docking simulations, to identify candidate molecules that may potentially bind to the protein target of interest.4

In order to identify promising small molecule therapeutics, existing high-throughput virtual screening approaches often evaluate comprehensive drug databases such as ChEMBL,5 PubChem,6 and ZINC.7 Even with the recent advent of the Enamine REAL library of 6–11 billion molecules,8 it is still dwarfed by estimates for the total number of possible synthesizable small molecules that range from 1024–1060.9 Unfortunately, due to the size of such established or expanded databases, screening all compounds according to sufficiently sophisticated structure based methodologies, such as flexible ligand docking, can be intractable. Even with simpler methods such as pharmacophore modeling or rigid body docking, it can still be time-consuming to navigate through the chemically feasible space, with a tendency toward false-positives being ruled in while false-negatives, i.e., potential optimum lead molecules, can be ruled out.10,11

With the rise of modern machine learning, a more clever exploration of the chemical space for drug-like molecules becomes possible, thanks to the development of generative models that can generate molecules represented as either strings or graphs.12−22 More interestingly, the distribution can be skewed toward molecules with specific properties such as drug likeness using techniques such as variational autoencoders (VAEs),13,14 transfer learning,15 and reinforcement learning (RL).16−22 However, early deep learning methods rely on one-dimensional (1D) sequence or two-dimensional (2D) chemical representations of the drug and protein and do not take full advantage of three-dimensional (3D) structural information on the putative drug, thereby constraining the ability to generate drugs with shape and molecular compatibility with the target active site. When SMILES-based generative models were combined with additional information about protein structure, ligand structure, or protein–ligand interactions, the quality of generated molecules improved in terms of predicted binding affinity or binding mode similarity with a reference binder.23,24 Recent work has explored chemical space in the vicinity of some starting molecular scaffold, running docking simulations on these derived molecules,25 but the chemical space that can be explored by such a method is still rather limited. Generation of atomistic structures of new compounds conditioned on the 3D structure of a provided pocket or constrained on interaction fingerprints has also been proposed with sequential growth of atoms,26,27 hierarchical buildup of 3D coordinates28,29 or generating all-atom coordinates at once using diffusion models.30,31 However, these existing methods have either been tailored toward de novo generation or a local optimization but lack the flexibility to extend from de novo design to structure or ligand based rational design. These additional capabilities are essential for continuously improving the binding potency between ligands and proteins after a hit molecule is already identified.

In this work, we propose a novel composite workflow, dubbed “iMiner”, that mines chemical space for new tight binding inhibitors by combining deep RL with real-time flexible ligand docking against a protein binding site. We represent putative inhibitors as Self-Referencing Embedded Strings (SELFIES)32 that are generated from an Average Stochastic Gradient Descent Weigh-Dropped Long Short-Term Memory (AWD-LSTM)33 recurrent neural network (RNN), allowing wide coverage of chemical space. We illustrate the RL training procedure of iMiner that uses on-the-fly AutoDock Vina34 in a predefined binding pocket of the 3D structure of the protein to generate small molecule inhibitors, in which the AutoDock-Vina score is used to adjust the RNN so that the distribution of generated inhibitor molecules are shifted toward those that more strongly interact with the protein. The iMiner algorithm is further distinguished from other generative models with additional capabilities to drive not only de novo molecular design but also ligand based design (generating similar molecules to early optimized hits) and structure based design (growth from bound ligand fragments and/or enforcing ligand interaction with certain protein sites), a unique versatility within our reinforcement learning. Finally, iMiner also offers the option to provide a series of postfilters to down-select the generated molecules so that they obey Lipinski rules,35 increase the likelihood of synthetic accessibility (SA) and drug likeliness, avoid nonspecific binders (Pan-assay interference compounds or PAINS)36 or certain disfavored substructure elements, and find consensus molecules with alternative docking software and scoring functions.

To validate the effectiveness of the iMiner approach, we designed inhibitors for the popular SARS-COV-2 Main protease (Mpro) as an example (see Supporting Information). We chose this system because of the ready availability of experimental 3D structures37 and the fact that multiple effective ligands have already been proposed to inhibit Mpro,38 which provides ample information for different structure based and ligand based designing strategies.39 We illustrate the four features of the iMiner approach and evaluate our model’s capability to generate new inhibitors and perform structural modifications while keeping the pharmacophore intact, growing ligands from a fragment starting point, or retaining key interactions with a specified protein residue. Although illustrated on the SARS-COV-2 Mpro target, we would like to emphasize that the iMiner workflow can be readily adapted to generate small molecules for other protein targets, since it only requires a 3D structure of the target protein with a predefined binding site. Thus, we believe our ML algorithm will be of great interest to the drug design community to rapidly screen novel regions of chemical space in real-time for other antivirals or small molecule therapeutics in the future.

## Section: The iMiner Algorithm and Workflow

Figure 1 provides an illustration of the overall structure of the iMiner algorithm, which highlights the two major machine learning components, the generative and evaluative models, and their interplay for generating new inhibitor molecules. In addition, we embed the RL-physics model into a composite workflow for further analysis and down-selection, also displayed in Figure 1. Here we describe the iMiner algorithmic components and workflow in more detail.

Illustration of the overall structure of the iMiner algorithm and workflow. (a) The generative model uses SELFIES representations for molecules and a recurrent neural network to “mine” for new molecules that are presented to the evaluative model for 3D docking using AutoDock Vina. Vina scores and other loss/reward functions are used to drive gradient updates of the neural network. (b) The iMiner workflow provides automated postselection filters, consensus scoring, and MD simulations for overall ranking.

## Section: The iMiner Algorithm and Workflow › The Generative Module

Conceptually, generating molecules using a string representation is similar to the way text is generated in a natural language processing task. Our method starts with a specific [Break] token, and for each molecule, we utilized a RNN that takes in the last token in the string, together with the hidden state from the last step to predict a distribution of tokens following the current string. In this work a specific variant of the RNN, known as the AWD-LSTM, was used due to its exceptional performance in similar generative tasks (Figure 1a).33

## Section: The iMiner Algorithm and Workflow › The Generative Module › SELFIES Representation of Inhibitor Molecules

An arbitrary molecule can be represented as a topological graph using two main approaches: adjacency matrix methods and string based methods. The former uses an N by N matrix to encode a molecule, where N is the number of atoms in the molecule and the values of the matrix are typically bond orders between atoms. An adjacency matrix is not ideal for generative tasks because the size of the molecule that can be generated should not be fixed, and the learning of chemical knowledge by a ML model through adjacency matrix can be difficult. Instead, string based methods are more suited for molecular generation tasks, and SMILES strings have been the standard for molecular representation due to their conciseness and readability. However, SMILES strings have relatively complex syntax and require matching of open and closed brackets for branching, and ring modeling/modification is not trivial. Therefore, generating novel, chemically correct compounds through the use of SMILES strings can be challenging.

The SELFIES molecular representation32 is specifically designed to ensure that all generated strings correspond to valid molecules. By utilizing [Branch] and [Ring] tokens with predefined branch lengths and ring sizes, as well as generating symbols using derivation rules, the SELFIES representation guarantees that valence bond constraints are met and any combinations of tokens from its vocabulary correspond to a valid molecule. Therefore, we have used SELFIES in our generative model to encode molecules since it does not need to learn chemical syntax rules and can allocate more of its learning capacity toward generating valid molecules with properties of interest.

## Section: The iMiner Algorithm and Workflow › The Generative Module › Pretraining the Inhibitor Molecule Generation

The network was pretrained using supervised-learning (SL) of all molecules from the ChEMBL database to learn the conditional probability distributions of tokens that correspond to drug-like molecules. When our trained generative model is used for generating new molecules, a new token is sampled according to the predicted probabilities, and this new token is concatenated to the input string to sample the next token until the [Break] token is sampled, in which case a complete molecule has been generated.

We then validated our pretrained distributions using 13 drug-likeliness properties between our generated molecules and randomly sampled molecules from the ChEMBL database that we used for training. The molecular properties considered are well-recognized chemical features related to the drug-likeliness of a molecule which can be obtained through 2D topological connectivity of the molecule: fraction of sp3 hybridized carbons, number of heavy atoms, fraction of non-carbon atoms in all heavy atoms, number of hydrogen bond donors and acceptors, number of rotatable bonds, number of aliphatic and aromatic rings, molecular weight, approximate log partition coefficient between octanol and water (alogP),40 polarizable surface area (PSA), number of structural alerts,41 and size of the largest ring in the molecule. Despite the fact that during pretraining only token distributions were used as training targets, all distributions collected from our generated molecules closely follow the distributions from the ChEMBL database (Figure S1). This result suggests our pretrained model has learned key concepts of “drug-likeness” and provides a good starting point for the RL procedure.

## Section: The iMiner Algorithm and Workflow › The Evaluation Module

After our generative model was pretrained, we employed an RL workflow to bias the distribution of generated molecules toward specific properties of interest. RL training allows the model to interact with an environment by performing actions according to a policy model and uses the feedback from the environment to provide training signals to improve the model. In this work, the pretrained generative model is taken as the policy, and in each iteration, 2000 molecules were generated and sent to the evaluation module (Figure 1a).

## Section: The iMiner Algorithm and Workflow › The Evaluation Module › Physics-Based Docking

The central component of our evaluation model is docking with AutoDock Vina (Vina) in parallel with the RL. Within our evaluation model, the Vina score calculator takes a SMILES string representing the ligand and the 3D structure of the protein target, together with a predefined docking region, as input. AutoDock Vina then explores variations of the dihedral angle degrees of freedom and identifies the optimal conformation of the input inhibitor for placement in the designated protein binding site. Finally, AutoDock returns the Vina score as an approximation of the binding energy between the ligand and the protein. Multiple instances of the Vina score calculator tasks were established through GPU parallelization to allow high-throughput evaluation of the generated molecules.42 Vina scores were then cycled back to the generative model to improve molecule generation through proximal policy optimization (PPO),43 as will be discussed in next section. We emphasize that by using a physics-based docking model which utilizes the full 3D structure of our target protein and generated molecules as the critic, the training of the policy model is less likely to be contaminated due to exploiting failure modes of a neural-network based critic, an issue called wireheading.44 Instead, we benefit from a more reliable training signal and reduce the false positive and false negative rates of the generated molecules.

Vina scores alone are not sufficient to reliably train a molecule generator, as shown in the Supporting Information (Figure S2) because it will not always satisfy requirements for drug-likeness. To ensure that our generated molecules still bear drug-like properties, we incorporated an additional metric into the reward, SDL, which is a weighted average of the log likelihood for the 13 different drug-like properties used in pretraining assessment. Our custom drug-likeliness score is an extension of the widely used quantitative estimate of drug-likelihood (QED) value45 tailored to our deep learning generative model. Formally, the drug-likeliness score SDL is defined as

where propi(X) calculates the ith property of a molecule X and pi is defined by the probability distribution of property i by all molecules in the ChEMBL database. The parameter σi is defined as

where Si is the entropy of the distribution of property i,

such that a narrower distribution from the ChEMBL database contributes more to the drug likeliness score and defines the weights for each property as proportional to the inverse of the entropy. Introducing this additional reward ensures our model also accounts for similarity of generated molecules to the drug-likeliness present in the ChEMBL database and ensures that our generated molecules are more likely to be optimal leads for further drug design endeavors. Additionally, since the ChEMBL database also contains molecules with undesirable molecular scaffolds, we allow users to define specific undesirable chemical patterns using SMARTS strings46 and manually set the drug-likeliness score to 0 to discourage their appearances in future iterations. A set of suggested SMARTS patterns have been enabled by default, and further details are given in Supporting Information and Table S1.

## Section: The iMiner Algorithm and Workflow › The Evaluation Module › Reinforcement Learning with Different Reward Types

Our pretrained policy model defines a probability distribution for an arbitrary sequence of tokens from the SELFIES vocabulary, since the generation of the sequence is a Markovian decision process (MDP), and can be written as

where s0 corresponds to a starting state with [Break] as the only token in the string, st corresponds to an intermediate state with a finite length string of SELFIES tokens not ended with the [Break] token, and sT corresponds to the terminal state, with the last token being [Break] or the length of the string exceeding a predefined threshold. p(st|st–1) is the transition probability at time step t, which is the probability distribution of the next token from the generative RNN with the network parameters Θ. For each terminal state not exceeding the length limit, a corresponding molecule can be decoded, and the Vina score Svina and drug-likeliness score SDL, can be calculated and further optimized. The total reward for a terminal state with a decoded molecule X is then defined as

where i denotes the reward function types and λ parameters control the balance between the different scores. For the unconditional de novo generation case, where only the drug-likeliness score needs to be maximized and Vina score needs to be minimized, the reward becomes

Negative SDL is upward clipped to 0 and positive Svina is downward clipped to 0 to ensure the reward is non-negative. The expected reward under the MDP is then

To encourage the model to generate molecules based on a certain scaffold, we introduced a fragment similarity score, defined by the maximum Dice similarity of the Morgan fingerprints between fragments of the query molecule decomposed using BRICS47 and the target molecule or structural components, as well as a pharmacophore similarity score with the Pharm2D48 module in RDkit.49 In addition to molecular similarity, we also implemented a positional penalty of the docking score to impose a 3D structural similarity if needed. The algorithm identifies the most similar fragment component in a sampled molecule, calculates the shape alignment of the component to the target fragment, and clips the docking score to 0 if the alignment difference exceeds a given threshold.

A further augmented feature of iMiner is the generation of molecules that interact with specific protein residues in the pocket. We developed an interaction score as the weighted total of interactions of specific types between the predicted binding pose of a sampled molecule and the specific residues using Protein–Ligand Interaction Profiler (PLIP),50 where the weights are defined by users to prioritize certain interaction types and/or protein residues as desired. We also differentiated hydrogen bonding with angle <135° and the hydrogen-donor bond length >2.8 Å as weak interactions and down-scaled the corresponding interaction scores by 0.5 to encourage the generated molecules to form stronger bonds.

While we present results below using the different reward scores separately for clarity, all the above customized scores can be used jointly along with the drug-likeliness score and Vina score to meet different design criteria. Further details of the RL training procedure and hyperparameters λ are given in the Methods section and Supporting Information and Table S2.

## Section: The iMiner Algorithm and Workflow › The iMiner Workflow

The iMiner algorithm is embedded in a composite workflow that automates the postanalysis of generated molecules to help with overall ranking (Figure 1b) After completion of molecule generation and optimization, it is desirable to filter out PAINS molecules as well as molecules with Lipinski rule violations51 and to select for molecules with good synthetic accessibility (SA) scores according to the SwissADME software.52 We therefore developed and applied a set of filters requiring no PAINS, no Lipinski rule violations, and SA scores using the RDKit package,49 as well as a drug-likeliness score filter of >2.8 to exclude any structure that is not sufficiently drug-like. For the task to generate molecules with desired protein–ligand interactions, we applied an additional filter to extract molecules with confirmed interactions with the specified protein residue(s). While we use these specific values for the results described below, users have the option to change these values if desired.

Checking for consensus with alternate scoring functions is often considered good practice as any individual scoring function may have limited accuracy or be parametrized for different test cases.53 Thus, the workflow collects all molecules from RL training iterations with a user-defined Vina score cutoff and evaluates them with two alternative scoring functions. For cross-validation, we utilized a new AutoDock Vina score (newVina) and new InteractionGraphNet (newIGN)54 that were recently retrained using LP-PDBBind,55 a cleaned version of PDBBind data that implement control on the data similarity between the train, validation, and test data set. It was shown that the predicted binding affinities using retrained Vina and IGN scoring functions have much better accuracy and generalizability than those from the old versions, when evaluated using the cocrystal structures.55 The next step was to rescore the above resulting molecular poses with the newVina and newIGN scores and extract molecules that are in a certain consensus top range.

The final stage of the iMiner workflow is to run a molecular dynamics (MD) simulation for the protein–ligand complex. It has been widely recognized that molecular docking has some difficulties in terms of distinguishing nonbinders from binders as a consequence of lacking ensemble information and inability to capture induced-fit effects. Physics-based MD simulation has demonstrated its ability to improve the power of classical docking functions by effectively incorporating flexibility of both the receptor and the ligand while also including molecular aqueous solvent. Specifically, Guterres et al. have shown that 50 ns MD can serve as a postfilter for docking outcomes to distinguish decoys from binders if the ligand’s RMSD during the trajectory is larger than a threshold, which means that the binding is less stable.56 Therefore, we incorporate MD simulations into iMiner as a tool to validate the protein–ligand binding.

The automated MD procedure is described as follows: (1) the protein–ligand pose with the best Vina score is used as the initial structure and the simulation system is prepared by adding water solvent molecules and when required neutralizing counterions (Na+ or Cl–); (2) AMBER14SB/GAFF2/TIP3P are adopted to parametrize the protein, ligand, and water, respectively; (3) the system is first energy minimized followed by a 1 ns equilibration simulation in the NVT ensemble under 1 bar, 298.15 K, followed by a 1 ns simulation under the NPT ensemble; (4) a 50 ns production run is performed in the NPT ensemble and a total of 250 structures are collected for analysis in step 5; (5) for each structure the ligand’s RMSD is calculated with respect to the starting pose, and the probability of interactions between the ligand and protein are also analyzed with PLIP;50 (6) for a stable protein–ligand complex from step 5, if the user specifies, a longer production run in the NPT ensemble can be performed and the simulation time is also determined by the user. Herein, we use 1 μs for our SARS-CoV-2 main protease target in which the active site is not clearly defined solvent-exposed (not cryptic).57 For those targets that contain cryptic pockets or the structure is flexible, longer time may be needed.

## Section: Results

Kernel density estimate plots of Vina docking score and drug likeliness for de novo generated molecules before and after RL training. For this comparison, 1000 molecules were generated using the models before and after RL training to create the plot.

Drug-related property analysis between iMiner proposed molecules and experimentally confirmed binders. (a) Kernel density plots of the newVina and newIGN score distributions across two groups of molecules. (b) Distribution comparison of six different categories of bioactivity scores for the predicted target interaction.

iMiner generated structural analogs from a set of reference molecules. (a) The perampanel-derived38 reference molecules used to guide iMiner generation. (b) Surface rendering of the iMiner generated analogs in the Mpro canonical binding pocket. (c) 2D visualization of the iMiner-generated analogs with the shared motif highlighted in pink. Also see Table S5.

Structural based fragment growth using iMiner. (a) 2D and 3D visualization of the core fragment sitting in the pocket and interacting with His163 and Glu166. (b) Surface rendering of the filtered set of iMiner generated molecules overlaid in the Mpro canonical binding pocket denoted as P1, P1′, P2, and P3. The substructure fragments are shown in magenta. (c) Twelve representative filtered molecules with the fragment highlighted. Also see Table S6.

Molecules from iMiner interaction based design to target Mpro His163/Glu166. (a) Binding modes of the generated molecules show a rich polar interaction profile against specified residues. (b) Surface rendering of the generated molecules in the Mpro canonical binding pocket. (c) Twelve representative iMiner molecules with highlighted hydrogen bond donor/acceptor groups that form interaction with His163 (pink) and Glu166 (green). Also see Table S7.

Binding stability analysis between an iMiner-proposed molecule and a known ligand. (a) Representative 2D and 3D visualization of the crystal ligand of Mpro (PDB Code: 7L13) from Zhang et al.38 and iMiner_24_970 from the unconditional de novo design. (b) Residue-level protein–ligand interaction frequency comparison performed between both molecules.

## Section: Results › Unconditional De Novo Generation

We use SARS-CoV-2 Mpro as an example to demonstrate iMiner’s ability to generate a diverse set of potential small-molecule drug-like candidates without any information beyond the active site. To achieve this goal, two objectives are optimized during the RL training: (1) AutoDock Vina docking score to ensure the proposed molecules have good binding efficacy and (2) drug-likeliness to constrain our chemical search space only to molecules that are considered as drug-like.

When the training was completed, we looked at the shift in the distributions of the optimized objectives and the molecular properties of generated compounds. In Figure 2, we compare the distribution of Vina score and drug-likeliness score before and after RL training. The clear shift toward more negative Vina scores while maintaining a similar drug-likeliness distribution shows that iMiner can bias the generative model toward more potent and drug-like binders.

Furthermore, to inspect the changes in molecular properties before and after RL optimization, in Table 1, we evaluated the GuacaMol benchmarks,58 which probe 5 different aspects of the distribution of generated molecules with respect to the training data set. Model “validity” reports the proportion of syntactically correct molecules. Because we generated molecules via SELFIES representations, we achieved close to 100% validity for all generated molecules both in the pretrained step and after the RL optimization. Invalid molecules were either empty strings or molecules for which the SELFIES package failed to convert into a SMILES string and therefore were discarded before the next workflow steps. Model “uniqueness” reports how many generated molecules are duplicates versus those which are genuinely distinct. Our pretrained and RL models illustrate high uniqueness, indicating the model is able to generate a wide variety of nonredundant molecules. Model “novelty” is defined as the proportion of generated molecules that do not exist in the training data set. The high novelty of both our pretrained and RL model indicates that it is not memorizing molecules from the training data set but is indeed generating molecules that it has not seen before. By these 3 metrics, the pretrained and RL molecules satisfy the criteria of an unconditional de novo generation of unique molecules.

But the RL learning should also generate unique molecules that are specific to the 3D interaction space of the binding pocket. The Kullback–Leibler (KL) divergence measures differences in probability distributions of various physicochemical descriptors for the training set and the pretrained and RL model generated molecules. As defined by GuacaMol, a high KL divergence benchmark suggests that the generated molecules have similar physicochemical properties to those of the training data set. This is true for the pretrained models by design, but what is clear after the RL optimization is that the influence of the 3D shape requirements of the protein pocket and emphasis on drug-likeness results in significant deviation from the original training set. This is also reflected in the Frechet ChemNet Distance (FCD), which utilizes a hidden representation of molecules in a previously trained NN to predict biological activities and thus captures both chemical and biological similarities simultaneously for two sets of molecules.59 Molecules generated by our pretrained model have high FCD values, indicating that our molecules have similar biological activities as molecules from the ChEMBL training data set. However, the strong deviation after RL training shows that the generated molecules reside in a different chemical space. In Table S3, we show that the model after RL training can generate molecules that are more similar to those of known SARS-Cov-2 Mpro binders.

After the initial filtering with a top 10% Vina docking score cutoff, 12,600 molecules were selected for consensus rescoring and chemical property comparisons with other deep-learning-based methods were shown in Table S4. Then, 125 molecules were filtered from the consensus scoring for the final analysis to assess their distribution compared to a set of the known experimental binders borrowed from LP-PDBBind.55 Specifically, we looked at the newVina and newIGN score distributions as well as the bioactivity scores used in similar studies.60,61

In Figure 3a, the distribution of the surviving molecules falls in a similar and, in the case of newIGN, even better range compared to the known experimental binders, indicating that our stringent down-selection with consensus scoring could successfully lead us to molecules that have the potential to form strong interactions with our target protein. In Figure 3b, we examine the various bioactivity scores to show that our molecules are similar to the known binders from a pharmacological perspective. Bioactivity scores are a quantitative estimate of a compound’s interaction with different targets. A score of less than −0.5 usually means the compound is inactive; a score in the range of −0.5 to 0 corresponds to the compound being moderately active; and a score of larger than 0 indicates the compound is biologically active.60 Here, this similarity in the score distribution across all targets indicates that the proposed molecules and the experimental binders share close pharmacological properties. Specifically, 29 proposed molecules have a bioactivity score larger than 0 in the category of protease inhibitor, suggesting a high potential for proposed compounds to be effective.

Kernel density estimate plots of Vina docking score and drug likeliness for de novo generated molecules before and after RL training. For this comparison, 1000 molecules were generated using the models before and after RL training to create the plot.

Drug-related property analysis between iMiner proposed molecules and experimentally confirmed binders. (a) Kernel density plots of the newVina and newIGN score distributions across two groups of molecules. (b) Distribution comparison of six different categories of bioactivity scores for the predicted target interaction.

## Section: Results › Generation of Structural Analogs

Structural analogs are designed to have a similar structure to a reference molecule which is (often) a known binder but made to differ in certain functional groups to optimize the structure–activity relationship (SAR). Developing structural analogs is valuable in drug discovery because they can display a spectrum of biological activities distinct from the parent molecule, but it remains a combinatorial search challenge such that automated computational approaches can be of great value. We therefore have adapted iMiner’s reinforcement learning coupled with the docking algorithm to also include a structural similarity score to efficiently explore the variations in chemical space around a given target compound. We have considered two types of structural similarity: fingerprints that encode the topology of a molecule and pharmacophore models that capture the arrangement of chemical features important for biological activity. In this work, we exemplify this approach by generating analogs of the SARS-CoV-2 Mpro inhibitors reported by Zhang et al.38

Figure 4a displays the reference molecules which are comprised of a core cloverleaf motif around a central pyridinone ring, a pyridinyl group, and a meta-substituted phenyl ring directed toward His41, features considered to be well-optimized in ref (38). As seen in Figure 4b, the iMiner molecules generated to maintain similarity to the core motif have also varied the functional groups extending into the P3 region of the Mpro canonical binding pocket, as seen in Figure 4b. In addition, Table S5 shows that both newVina and newIGN scores of the docked poses of the generated molecules determined by Autodock Vina aggregate in the more negative energy (higher affinity) range compared to those of the reference perampanel derivatives since the iMiner model also optimizes binding affinities while exploring a local chemical space around the reference molecules.

iMiner generated structural analogs from a set of reference molecules. (a) The perampanel-derived38 reference molecules used to guide iMiner generation. (b) Surface rendering of the iMiner generated analogs in the Mpro canonical binding pocket. (c) 2D visualization of the iMiner-generated analogs with the shared motif highlighted in pink. Also see Table S5.

## Section: Results › Structure-Based Fragment Growth

Fragment-Based Drug Discovery (FBDD) has emerged as an attractive strategy in modern medicinal chemistry and drug development due to its advantages in lower experimental cost and diversity of paths to novel compounds.62 Fragments, for instance, from a screening campaign or as an interesting substructure of a validated binder, can serve as foundational building blocks which can be evolved and optimized into potent drug candidates. While fragments provide only starting points due to their modest affinity, deciding how to grow the molecule or even connect multiple fragments while enhancing activity can be an intricate and subtle task. While FBDD can be readily addressed by iMiner using structural similarity scores as demonstrated above, it is now more challenging because we are also enforcing the structural binding mode of the starting fragment. One intuitive approach would be to perform docking with constraints. However, few publicly available docking programs offer such a function without extensive reparametrization. Instead, iMiner employs a “top-down” approach that in addition to rewarding molecules with high similarity, also penalizes the docking scores of molecules whose binding poses do not match with the starting fragment, thereby reducing sampling of molecules with incorrect orientation or connectivity during the RL phase.

As an example, we use iMiner to propose molecules containing a pyridinone ring connected to a pyridinyl group that resides in the Mpro P1 pocket (Figure 5a), extracted from the molecules developed by Zhang et al. for Mpro, by performing RL training with a pose adjusted Vina score and fragment similarity score starting from a fine-tuned model (see Methods section). A set of 12 representative molecules in Figure 5b,c with the matching substructure aligned to the starting fragment were harvested from the validation and postfiltering process. As seen in the figure many of the proposed molecules extended from the fragment adopt a cloverleaf-like motif branching into the P1, P1′, and P2 subpockets as observed in Zhang et al. The preservation of hydrogen bonding interactions to His163 and Glu166 of these predicted poses, as adopted by the original fragment, was also preserved in the iMiner molecules. Together the results verify that the RL-physics model not only learned the chemical and structural information on the fragment but was able to grow a larger molecule that improves the pocket complementarity.

Structural based fragment growth using iMiner. (a) 2D and 3D visualization of the core fragment sitting in the pocket and interacting with His163 and Glu166. (b) Surface rendering of the filtered set of iMiner generated molecules overlaid in the Mpro canonical binding pocket denoted as P1, P1′, P2, and P3. The substructure fragments are shown in magenta. (c) Twelve representative filtered molecules with the fragment highlighted. Also see Table S6.

## Section: Results › Designing Molecules to Interact with Specific Protein Sites

An alternative scenario of significant interest involves designing molecules to engage with specific protein residues within the pocket. These residues may possess vital catalytic activities or exhibit low mutation rates; thus, the inhibitors designed specific to these residues are less likely to develop resistance to viral variants. We investigated the use of iMiner to generate molecules with hydrogen bonding interactions to His163 in the SARS-CoV-2 active site. His163 is a conserved residue in different SARS-CoV-2 strains and multiple inhibitors, such as the FDA-approved remdesivir63 and ensitrelvir,64 show consensus in forming a hydrogen bond with His163. Starting from the ChEMBL pretrained model and assuming no other knowledge about the structural and chemical features of a potential Mpro binder, we trained a model using an interaction score with respect to key residues such as His163 and Glu166, Vina docking score, and drug-likeliness score in the reward function.

In Figure 6, the overlay of postfiltered iMiner-generated molecules in their binding conformations determined through AutoDock Vina confirms their participation in hydrogen bonding interactions with His163 or Glu166 or both as expected. In Figure 6a, this set of 12 representative molecules has shown a diverse set of scaffolds while retaining the key interactions with the specified residues. Figure 6b further shows that the molecules could fill the P1, P2, P3, and P1′ subpockets, satisfying the pocket complementarity. In addition, several other key hydrogen bonding interactions with the backbone atoms of Cys145 and Ser144 were recovered from the docked poses of the proposed molecules, although these interactions were not explicitly enforced by the reward function.

Molecules from iMiner interaction based design to target Mpro His163/Glu166. (a) Binding modes of the generated molecules show a rich polar interaction profile against specified residues. (b) Surface rendering of the generated molecules in the Mpro canonical binding pocket. (c) Twelve representative iMiner molecules with highlighted hydrogen bond donor/acceptor groups that form interaction with His163 (pink) and Glu166 (green). Also see Table S7.

## Section: Results › Binding Stability Analysis

As the final step of the workflow following consensus scoring, we perform subsequent long MD simulations to measure the stability of the surviving molecules. The effectiveness of using MD to validate binding through experiment has also been demonstrated before.65 To illustrate this stability test, we analyzed the de novo generation design set, which consisted of 12 down-selected molecules from a more stringent newVina and newIGN rescoring threshold of the top 1.5% in each category. For each molecule, we start with 50 ns MD simulations, from which we found that 7 molecules had robust binding stability as defined by an average RMSD smaller than 4 Å and preserving more than 1 hydrogen bond between the ligand and protein residues. To validate the MD results for these 7 molecules more rigorously, the simulation was then prolonged to 1 μs based on previous studies of Mpro.57 In Figure 7, we show the best out of 3 de novo generated molecules that retained good binding within the active site. Further ligand trajectory-based analyses of other molecules proposed by all four protocols are shown in Figures S3 and S4. For comparison, we also performed 1 μs simulation for two known binders (PDB code: 7L11 and 7L13) reported by Zhang et al.38

As is evident in Figure 7 and Figures S3 and S4, the iMiner-generated molecules form very stable interactions such as hydrogen bonds, hydrophobic interactions, and pi-stacking, just as is the case for the known binders 7L11 and 7L13.38 In Figure 7 we find that both 7L13 and iMiner_24_970 form stable hydrogen bonds with Glu166, which is desirable as it is a low mutation site residue in Mpro such that these molecules may remain viable against future variants of SARS-Cov-2.66,67 The iMiner molecule also forms a long-lived pi–pi stacking interaction with His41, while the hydrogen bonding interaction with His41 is only weakly populated in 7L13. Similar conclusions are drawn when comparing the known binders against other iMiner proposed molecules. Thus, at the end of the iMiner workflow, the 3 generated molecules are certainly worth pursuing for synthesis and validation against biochemical and cellular assays.

Binding stability analysis between an iMiner-proposed molecule and a known ligand. (a) Representative 2D and 3D visualization of the crystal ligand of Mpro (PDB Code: 7L13) from Zhang et al.38 and iMiner_24_970 from the unconditional de novo design. (b) Residue-level protein–ligand interaction frequency comparison performed between both molecules.

## Section: Conclusions

In this work, we have shown that by combining real-time docking of 3D structures with state-of-the-art reinforcement learning algorithms, we can efficiently navigate through uncharted regions of chemical space while maintaining good metrics for synthetic feasibility and drug-likeness. The flexibility of the iMiner physics-ML model also allows for the creation of molecules that enforce interactions with target active site residues as well as growing molecules from fragments with options for satisfying chemical or structural restraints. As illustrated using the exemplar target, the Mpro catalytic site, the generated inhibitor molecules proposed by iMiner are optimized with respect to shape and intermolecular interactions to the target protein, but are also diverse enough when compared to other predicted Mpro inhibitor data sets, i.e., experimentally confirmed molecules extracted from LP-PDBBind,55 especially the trefoil inhibitors optimized by the Jorgensen group.38 Finally, every aspect of this work is generalizable to other protein targets and beyond the active site, for example, allosteric sites.

Overall, we believe the iMiner RL-physics algorithm and workflow tool will be of great benefit to the computational and medicinal chemistry fields at large and potentially aid traditional drug-design workflows as well. Although we have focused our current work on targeting Mpro of SARS-CoV-2, extension of this work to other protein targets relevant to other global diseases would be relatively trivial. For example, bacterial resistance to antibiotics is of preeminent concern in the medical community,68 and our iMiner workflow approach could be used to target novel bacterial biomolecules, such as bacterial ribosomes, or target resistance conferring bacterial proteins such as β-lactamase.68 Another direction pertains to molecules that are experimentally validated through a traditional HTVS approach as good binders, in which the iMiner algorithm could be utilized as an optimization or refinement step for elaborating on these existing leads or scaffolds. The potential of the method in this direction will be explored in future work.

## Section: Methods › Neural Network Architecture

The generative model employed in this study is an ASGD Weight-Dropped LSTM (AWD-LSTM),33 which is a specific variant of the Long Short-Term Memory (LSTM) recurrent neural network with shared DropConnect for weight regularization, and was trained through a non-monotonically triggered average stochastic gradient descent (NT-ASGD) algorithm.33,69 The basic LSTM cell contains two internal states, the hidden state ht and the cell state ct, and can be described through the following set of equations:

where [Wi, Wf, Wo, Wc, Ui, Uf, Uo, Uc] are the trainable parameters of the model, xt is the input to the cell at the current time step, c̃t contains the information to be added to the cell state, and it, ft, and ot represent the update gate, forget gate, and output gate, respectively, which are numbers between (0, 1) that control how much information should be updated, discarded, or retrieved from the cell state. σ denotes the sigmoid function, and ⊙ represents element-wise multiplication. The DropConnect mechanism70 was applied to the hidden-to-hidden weight matrices [Ui, Uf, Uo, Uc] by randomly zeroing out a small portion of the parameters in these weight matrices to prevent overfitting and ensured that the same positions in the hidden vectors were treated consistently throughout the forward and backward pass in regards to whether or not to be dropped.

The inputs into the RNN cells were tokens embedded as vectors of length 400, and 3 LSTM cells were stacked sequentially, that had 1152, 1152, and 400 units each. The hidden state from the last time step of the last RNN cell was then connected to a linear decoder with output size of 56 and softmax activation, representing the probabilities of the 56 possible tokens from the vocabulary. The dropout values used in the model were embedding dropout = 0.002, LSTM weight dropout = 0.02, RNN hidden state dropout = 0.015, and output dropout = 0.01. The neural network was implemented using pyTorch71 and the fastai package.72

## Section: Methods › Supervised Pretraining of the Network

The generative model was pretrained using molecules from ChEMBL24,5 and a total of 1,440,263 molecules were selected for training. All molecules were first converted to self-referencing embedded strings (SELFIES) using the selfies python package,32 and the tokens were extracted from the SELFIES with the fastai language model. We used categorical cross entropy loss:

where N represents the number of tokens in a molecule, p̂(ti|t1, t2, ..., ti–1) represents the actual probability of a specific token in the string at position i and with all previous defined tokens t1 through ti–1, and pΘ(ti|t1, t2, ..., ti–1) represents the probability predicted by the neural network with parameters Θ. The model was trained using Adam optimizer73 in batches of size 512, and we employed the “one cycle” learning rate policy74 with the maximum learning rate of 0.0005 to achieve superconvergence.75 During this pretraining stage we also used weight decay = 0.01 and the dropout multiplier of 0.2. The model was pretrained for 30 epochs.

For iMiner used to generate molecules similar to a scaffold or growing from a fragment, fine-tuning was conducted using molecules containing the target scaffold or fragment. These molecules can be curated from open source databases via a substructure search or from a set of molecules of any size defined by the users. While it is possible to directly perform RL training from the ChEMBL pretrained model with a fragment similarity reward term, the additional training ensures a consistent model performance in finding molecules with the desired substructures, as otherwise some specific fragments can be rare in the ChEMBL24 data set and the model cannot make sufficient sampling of the relevant structures in the initial few epochs of RL training. Details of the additional fine-tuning are provided in the Supporting Information.

## Section: Methods › Reinforcement Learning Procedure

Our RL training target goal is to maximize J(Θ) from formula 7 by taking steps along ∂ΘJ(Θ). The exact value for J(Θ) is intractable to evaluate but can be approximated through sampling the distribution of sT, which gives

and then

Directly taking gradients according to eq 17 corresponds to the REINFORCE algorithm.76 In this work, we further utilized the PPO algorithm,43 which estimated the gradients through a clipped reward and with an extra entropy bonus term:

where

with

denoting the ratio between the probability distribution in the current iteration and the probability distribution from the previous iteration (the iteration before last gradient update). A PPO algorithm reduces the variance in the gradient, stabilizes training runs, and encourages the model to explore a wider region of the chemical space through the introduction of an entropy bonus term.

After the pretraining finished, we copied the weights to a separate model with identical architecture and trained with reinforcement learning using PPO. Because AutoDock Vina can predict different scores and poses for the same molecules due to random initiation, docking-derived reward terms for the same molecules sampled multiple times in one batch were averaged before the target functions were calculated for training stability. In each iteration after the molecules were sampled, model weights were updated by taking gradient steps on the target function through formula 18 using an Adam optimizer. In each iteration, all collected data were used for training the model for a maximum of 10 epochs. The trainer would continue into next iteration and collect new molecules for training if the K-L divergence between the latest predicted probability and the old probability exceeded 0.03.

The model was trained with RL until the mean entropy of the predicted probability of the tokens from the RNN started to decrease drastically. The training details including batch size, learning rate, hyperparameters α and ϵ, and the ratio between the reward terms λ for the 4 tasks are reported in Table S2.

## Section: Acknowledgments

This work was supported by National Institute of Allergy and Infectious Disease grant U19-AI171954. This research used computational resources of the National Energy Research Scientific Computing, a DOE Office of Science User Facility supported by the Office of Science of the U.S. Department of Energy under Contract No. DE-AC02-05CH11231. The DALL-E 3 AI model was used to create illustrative artwork in Figure 1 (the lower left image demonstrating filtering of molecules).

## Section: Data Availability Statement

All the code for the iMiner reinforcement learning algorithm and workflow are provided in a private GitHub repository: https://github.com/THGLab/iMiner under reasonable requests.

## Section: Supporting Information Available

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acs.jcim.4c00634.

## Section: Author Contributions

∥ J.L., O.Z., and K.S. contributed equally. J.L., O.Z., and T.H-G. conceived the scientific direction, designed the experiments, analyzed results, and wrote the manuscript. F.L.K. prepared Mpro structures for docking in AutoDock Vina. C.P. wrote the code for pretraining the network. O.Z. wrote the code for the AutoDock Vina workflow. Y.W. wrote codes for molecular dynamics simulations and subsequent analysis. D.B., X.G., and K.S. contributed ideas and suggestions to the work. R.E.A. provided drug-design guidance. All authors discussed and performed final edits to the manuscript.

## Section: Text

The authors declare the following competing financial interest(s): C.P. has equity interest in Athae Bio.

## Section: Supplementary Material

ci4c00634_si_001.pdf

## Section: Associated Data

ci4c00634_si_001.pdf

## Section: Associated Data › Supplementary Materials

ci4c00634_si_001.pdf

## Section: Associated Data › Data Availability Statement

All the code for the iMiner reinforcement learning algorithm and workflow are provided in a private GitHub repository: https://github.com/THGLab/iMiner under reasonable requests.


---

# MISATO: machine learning dataset of protein-ligand complexes for structure-based drug discovery

- **Authors:** Till Siebenmorgen, Filipe Menezes, Sabrina Benassou, Erinc Merdivan, Kieran Didi, André Santos Dias Mourão, Radosław Kitel, Pietro Liò, Stefan Kesselheim, Marie Piraud, Fabian J Theis, Michael Sattler, Grzegorz M Popowicz
- **Issuer:** Nature computational science
- **Type:** Scientific article
- **Published:** 2024-05-10
- **Language:** en
- **DOI:** 10.1038/s43588-024-00627-2
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38730184/
- **Licence:** CC-BY

## Page 1 (Section: MISATO: machine learning dataset of protein–ligand complexes for structure-based drug discovery)

Nature Computational Science | Volume 4 | May 2024 | 367–378
367
nature computational science
https://doi.org/10.1038/s43588-024-00627-2
Resource
MISATO: machine learning dataset 
of protein–ligand complexes for 
structure-based drug discovery
Till Siebenmorgen 
  1,2,9, Filipe Menezes 
  1,2,9, Sabrina Benassou3, 
Erinc Merdivan4, Kieran Didi 
  5, André Santos Dias Mourão1,2, Radosław Kitel6, 
Pietro Liò5, Stefan Kesselheim 
  3, Marie Piraud4, Fabian J. Theis 
  4,7,8, 
Michael Sattler 
  1,2 & Grzegorz M. Popowicz 
  1,2 
Large language models have greatly enhanced our ability to understand 
biology and chemistry, yet robust methods for structure-based drug 
discovery, quantum chemistry and structural biology are still sparse. 
Precise biomolecule–ligand interaction datasets are urgently needed 
for large language models. To address this, we present MISATO, a dataset 
that combines quantum mechanical properties of small molecules and 
associated molecular dynamics simulations of ~20,000 experimental 
protein–ligand complexes with extensive validation of experimental  
data. Starting from the existing experimental structures, semi-empirical 
quantum mechanics was used to systematically refine these structures.  
A large collection of molecular dynamics traces of protein–ligand complexes 
in explicit water is included, accumulating over 170 μs. We give examples 
of machine learning (ML) baseline models proving an improvement of 
accuracy by employing our data. An easy entry point for ML experts 
is provided to enable the next generation of drug discovery artificial 
intelligence models.
In recent years, artificial intelligence (AI) predictions have revolution-
ized many fields of science. In structural biology, AlphaFold2 (ref. 1) 
predicts accurate protein structures from amino-acid sequences only. 
Its accuracy nears state-of-the-art experimental data. The success of 
AlphaFold2 is made possible due to a rich database of nearly 200,000 
protein structures that have been deposited and are available in the 
Protein Data Bank (PDB)2. These structures were determined over the 
past decades using X-ray crystallography, nuclear magnetic resonance 
(NMR) or cryo-electron microscopy. Despite enormous investments, 
there are still few new drugs approved yearly, with development costs 
reaching several billion dollars3. An ongoing grand challenge is rational, 
structure-based drug discovery (DD). Compared with protein structure 
prediction, this task is substantially more difficult.
In the early stages of DD, structure-based methods are popular 
and efficient approaches. The biomolecule provides the starting point 
for rational ligand search. Later, it guides optimization to optimally 
explore the chemical combinatorial space4 while still ensuring drug- 
like properties. In silico methods that are in principle able to tackle 
Received: 30 May 2023
Accepted: 11 April 2024
Published online: 10 May 2024
 Check for updates
1Molecular Targets and Therapeutics Center, Institute of Structural Biology, Helmholtz Munich, Neuherberg, Germany. 2TUM School of Natural 
Sciences, Department of Bioscience, Bayerisches NMR Zentrum, Technical University of Munich, Garching, Germany. 3Jülich Supercomputing Centre, 
Forschungszentrum Jülich, Jülich, Germany. 4Helmholtz AI, Helmholtz Munich, Neuherberg, Germany. 5Computer Laboratory, Cambridge University, 
Cambridge, UK. 6Faculty of Chemistry, Jagiellonian University, Krakow, Poland. 7Computational Health Center, Institute of Computational Biology, 
Helmholtz Munich, Neuherberg, Germany. 8TUM School of Computation, Information and Technology, Technical University of Munich, Garching, 
Germany. 9These authors contributed equally: Till Siebenmorgen, Filipe Menezes. 
 e-mail: grzegorz.popowicz@helmholtz-munich.de

## Page 2 (Section: Results)

Nature Computational Science | Volume 4 | May 2024 | 367–378
368
Resource
https://doi.org/10.1038/s43588-024-00627-2
states); overly simplified atomic properties; highly complex energy 
landscapes in molecular recognition by their targets. Attempts to 
train AI models currently require inferring this missing information 
implicitly. The limited number of publicly available protein–ligand 
structures (~20,000) and lack of thermodynamic data cause this infer-
ence to fail. This is preventing structure-based models from producing 
groundbreaking results31,32.
Here, we propose a protein–ligand structural database, MISATO 
(molecular interactions are structurally optimized) that is based on 
experimental protein–ligand structures. We show that the database 
helps to better train models across fields related to DD and beyond. 
This includes quantum chemistry, general structural biology and bio-
informatics. We provide quantum-chemical-based structural curation 
and refinement, including regularization of the ligand geometry. We 
augment this database with missing dynamic and chemical informa-
tion, including MD on a timescale allowing the detection of transient 
and cryptic states for certain systems. The latter are very important for 
successful drug design33. Thus, we supplement experimental data with 
the maximum number of physical parameters. This eases the burden 
on AI models to implicitly learn all this information, allowing focus on 
the main learning task. The MISATO database provides a user-friendly 
format that can be directly imported into machine learning (ML) codes. 
We also provide various preprocessing scripts to filter and visualize the 
dataset. Example AI baseline models are supplied for the calculation of 
quantum chemical properties (chemical hardness and electron affinity), 
for binding affinity calculation and for the prediction of protein 
flexibility or induced-fit features to simplify adoption. The QM, MD 
and AI baseline models are validated extensively on experimental data. 
We wish to transform MISATO into an ambitious community project 
with vast implications for the whole field of DD.
Results
MISATO dataset
The basis for MISATO (Fig. 1) is the 19,443 protein–ligand structures 
from PDBbind25. These structures were experimentally determined 
over the past decades and represent a diverse set of protein–ligand 
complexes for which experimental affinities are available. In the context 
of AI for DD it is of utmost importance to train the models on a dataset 
structure-based DD include semi-empirical quantum mechanical (QM) 
methods5, molecular dynamics (MD) simulations6,7, docking8 and 
coarse-grained simulations9, which can also be combined to be more 
efficient. However, these methods either suffer from generally low 
precision or are computationally too expensive while still requiring 
substantial experimental validation. Recent examples show that clas-
sical, ball-and-stick atomistic model representations of biomolecular 
structures might be too inaccurate in certain situations to allow for 
correct predictions10–13.
The introduction of AI into the process is still at an early stage. 
AI approaches are, in principle, able to learn the fundamental state 
variables that describe experimental data14. Thus, they are likely to 
abstract from electronic and force field-based descriptions of the 
protein–ligand complex. However, so far mostly simple solutions 
have been proposed that do not incorporate the available protein–
ligand data to their full extent, such as scoring protein–ligand Gibbs 
free energies15,16, ADME (absorption, distribution, metabolism and 
excretion) property estimation17 or prediction of synthetic routes18,19. 
Most of these approaches are constructed using one-dimensional 
SMILES (simplified molecular-input line-entry system)20,21 and only 
a few attempts have been made to properly tackle three-dimensional 
(3D) biomolecule–ligand data22–24.
Several databases are available that contain raw experimental 
structures of protein–ligand complexes, usually extracted from the 
PDB (for example, PDBbind25, bindingDB26, Binding MOAD27, Sper-
rylite28). Only recently a database of MD-derived traces of protein–
ligand structures was reported29,30. Despite these efforts, so far no AI 
model has been proposed that convincingly addresses the rational DD 
challenge in the way that AlphaFold2 answered the protein structure 
prediction problem31,32.
In addition to DD, the structure-based AI models are useful for 
biomolecule structure analysis and quantum chemistry. However, 
they are severely hindered by several factors: neglecting the confor-
mational flexibility (dynamics and induced fit upon binding); entropic 
considerations; inaccuracies in the deposited structural data (incorrect 
atom types due to missing hydrogen atoms, incorrect evaluation of 
functional group flexibility, inconsistent geometry restraints, fitting 
errors); chemical complexity (for example, non-obvious protonation 
PDB preparation
PDB structures
19,443
Automated QM
methods
Ligand
parametrization
Solvation and
heating
MD simulation
Calculation of
properties
Calculation of QM
properties
Semi-empirical
QM
FF MD
simulations
MISATO dataset
Data loaders
AI base line
models
b
a
Car
Car
Car
Nar
Nar
Car
N+
Csp
3
Csp
3
Csp
3
Csp
3
Csp
3
N?
Csp
3
0
Fig. 1 | MISATO combines QM data with MD-derived protein–ligand 
dynamics. a, We provide a dataset that combines semi-empirical QM properties 
of small molecules with MD-simulated dynamics of the entire set of experimental 
protein–ligand complexes. All common errors in protein and ligand 
nomenclature, protonation, geometry and so on are fixed. The blue outline of 
the molecule describes its electronic density. b, An overview of the dataset and 
the applied protocols for semi-empirical QM and FF (force field) MD simulations 
including data preparation, preprocessing and AI baseline models.

## Page 3 (Section: Typical limitations in structural datasets)

Nature Computational Science | Volume 4 | May 2024 | 367–378
369
Resource
https://doi.org/10.1038/s43588-024-00627-2
with the highest possible correctness and consistency, for several rea-
sons. First, the total number of available structures is much lower than 
typical training sizes of other AI targets. Second, ligand association 
has a rather complex energy landscape during molecular recogni-
tion. Delicate deviations in the protein–ligand structures or atomic 
parameters can markedly impair binding. In the PDB, incorrect atom 
assignments and inconsistent geometries are not uncommon. More 
seriously, hydrogen atoms are highly sensitive to their chemical and 
molecular environment and are rarely experimentally accessible. All 
these issues have been systematically addressed in our work and are 
compiled in our database (Figs. 2 and 3).
Typical limitations in structural datasets
Understanding the nature and sources of errors in structural databases 
is imperative for improving the quality of the underlying molecular 
models.
Macromolecule–ligand interaction strength, the most desired 
baseline parameter for DD, is unfortunately also the most inaccurate 
metric. The diverse experimental set-ups from experimental entropy/
enthalpy determination (for example, isothermal titration calorimetry) 
to cellular phenotypic response are given as ligand strength. These 
values are not comparable and their use to train AI models is generally 
unreliable. To enable validation of affinity prediction we have prepared 
a small subset of ligands with accurately determined affinities to be 
used as a benchmark (Supplementary Table 1). We also tested our 
example model against it.
As MISATO is founded on experimental data, the two main sources 
of structural inaccuracies must be corrected. These are limited spatial 
resolution of the experimental structures and problems and biases 
associated with the software used for processing the molecular geom-
etries. As well as the absence of hydrogen atoms in crystallographic 
structures, resolution affects the heteroatom geometry. Contracted 
or elongated bonds are common (Fig. 2). That is, most nitro groups we 
examined were heavily distorted: in the 1WUG structure34, NO bonds 
are almost 17% larger than reference experimental data35. Another 
example is seen in the 4MDN structure36, where an amide was so dis-
torted that it explicitly violated VSEPR (valence shell electron pair 
repulsion) theory. Reinspection of the experimental electronic density 
hinted that the CÔC angle in the 4-chlorobenzyl phenyl ether moiety 
is also larger by almost 20° against anisole, a reference compound for 
that bond angle35. Simultaneous relaxation of the two groups leads to 
substantial improvement, in particular an amide group very close to 
reference structural values. Such errors in the heteroatom skeleton 
propagate further when assigning and counting hydrogen atoms. In 
the 5GTR structure37, a guanidino group strongly deviates from the 
expected planarity. The immediate consequences are incorrect atomic 
hybridizations and overassignment of hydrogen atoms, with a local 
formal charge of +3 in a radius of one bond around the central carbon. 
More examples are described in Supplementary Information.
Evaluation of the QM-based ligand curation
Employing the protocol defined in Supplementary Section 6 we modi-
fied a total of 3,930 structures, which corresponds roughly to 20% of the 
original database that needed substantial refinement (Fig. 2). Of these, 
3,905 cases involve changes in protonation states, while changes in 
heteroatoms involve 97 ligands. These are predominantly the addition 
of model functional groups to emulate covalent binding with the pro-
tein (20) or the addition of missing hydroxyl groups to boronic acids.
20.2%
26.9%
73.1%
20.1%
26.8%
73.2%
–0.39
6.2
–0.19
15.7
–0.03
7.0
–0.31
5.9
–0.19
7.4
–0.49
6.4
1.4Å
1.4Å
b
a
e
d
c
1WUG
4MDN
5GTR
+
+
+
Natoms
Natoms
Charge
Halogen
F
Cl
Br
I
–0.8
5
10
Polarizability a0
3
15
20
25
30
35
–0.6
–0.4
–0.2
0
0.2
0.4
Nprotons
add
Nhydrogen
add
Nhydrogen
rem
Natoms
rem
Fig. 2 | Changes applied to the PDBbind database based on our quantum 
chemical protocol. a, Statistical overview of changes introduced by our 
optimization protocol. Natoms corresponds to total changes in the atom count 
when compared with the source database. In most cases atoms were removed 
Nrem
atoms); in only 27% of cases was the number of atoms increased, Nadd
atoms. Similar 
considerations apply to protons—light blue; Nprotons. b, D4 polarizability versus 
partial charge for all the halogens in the database. The outliers were analyzed to 
find possible wrong atom assignments. This was the case for the bromine atom in 
the lower right corner, which in reality is a boron. c, Examples of inconsistent 
structures: 1WUG contains overly elongated NO bonds; 4MDN contains a 
nitrogen in angular violation of VSEPR; 5GTR shows a typical problem in the 
protonation state. d,e, Calculated electronic density for ketamine (4G8H) and 
tramadol, respectively (dashed green lines). Dashed circles show the sizes of 
electronic density around selected atoms. The numbers next to these atoms 
represent partial charge (top) and atomic polarizability (bottom). These are 
electronic descriptors representing the electronic density around each center. 
Color and character keys: N, blue, nitrogen; S, yellow, sulfur; O, red, oxygen;  
C, beige, carbon; H, white, hydrogen; Cl, green, chlorine.

## Page 4 (Section: QM-derived properties)

Nature Computational Science | Volume 4 | May 2024 | 367–378
370
Resource
https://doi.org/10.1038/s43588-024-00627-2
Some ligands were split into several molecules as the original 
structures were not binary protein–ligand complexes (one ligand): 
1A0T, 1G42, 1G9D, 2L65, 3D4F and 4MNV. 1E55 is supposed to be a 
mixture of two entities. However, the closest contact between them 
is insufficient to consider them separately, but also too large for a 
covalent interaction. Similar considerations apply to 1F4Y, though here 
close intramolecular contacts are at stake. In 4AW8 we observed a sub-
stantial deformation for the published ligand, PG6. We observed that 
the reference affinity is related to the metal ion in the system, Zn(ii), 
and not to PG6. The structure was consequently excluded.
As depicted in Fig. 2, the most common adjustment was the 
removal of hydrogen atoms from the initial PDBbind geometry. This 
amounts to almost 75% of the modifications. It has been pointed out 
that libraries such as PDBbind possess biased datasets in terms of 
binding configurations31.
QM-derived properties
We calculated several molecular and atomic properties for the ligands 
(Supplementary Table 2). For the former, we include electron affinities, 
chemical hardness, electronegativity, ionization potentials (by defini-
tion and using Koopmans’ theorem), static log P and polarizabilities. 
The latter were obtained in vacuum, water and wet octanol. Atomic 
properties include partial charges from different models, atomic 
polarizabilities, bond orders, atomic hybridizations, orbital- and 
charge-based reactivity (Fukui) indices and atomic softness. Reactivity 
indices and atomic softness are derived for interactions with electro-
philes, nucleophiles and radicals. Finally, we also provide tight-binding 
electronic densities for all ligands. Partial charges were calculated at 
several levels, as these are somewhat method-sensitive quantities. AM1 
charges are usually the starting point for charge-correcting schemes 
to be used in MD simulations. This is the case for AM1-BCC38. Taking 
our AM1 charges and multiplying them by 1.14 (in the case of neutral 
molecules) yields 1.14*CM1A-LBCC charges39 used in OPLS-AA simula-
tions40. The main advantage of the charges we provide is that these were 
obtained, when required, with a HOMO (highest occupied molecular 
orbital)–LUMO (lowest unoccupied molecular orbital) level shift to 
ensure convergence to sensible electronic states. Beyond MD simula-
tions, CMx charges41–43 have also been shown to provide good estimates 
a
b
e
c
d
Ligand
Pocket
Fig. 3 | Overview of events captured by the MD simulations in the binding 
pocket. a–c, Reversible opening and closing of the binding pocket can be 
captured during the simulations, including cryptic binding sites. a, The structure 
of 2AM4 is shown after 2 ns (left panel), 6 ns (middle panel) and 10 ns (right panel) 
simulation time (fluorine in beige). b,c, The opening loop region (b, structure 
2LKK) is visualized for superimposed timesteps (blue diagram, dark hue, 2 ns; 
black diagram, medium dark hue, 6 ns; red diagram, light hue, 10 ns). The protein 
pocket opens in structure 8ABP during the simulation (c). d, Protein residues at 
the binding site can undergo large adaptations within the simulations, indicating 
unstable interactions or possible switches. This is shown for a methionine residue 
of 4ZYZ (upper panel) and a tryptophan residue of 1WAW (lower panel). Coloring 
as in b after 2 ns and 10 ns. e, MD simulations captured local adaptability of the 
binding pocket and ligand. That is, in structure 2IG0 parts of the ligand (licorice, 
carbons in ivory) are quite flexible in the protein pocket (gray carbons) when 
comparing the first (dark hue) and the last (light hue) frames of the MD run. Color 
and character keys, if not indicated differently: N, blue, nitrogen; S, yellow, sulfur; 
O, red, oxygen; C, black, carbon; H, white, hydrogen; F, beige, fluorine; P, orange, 
phosphorus.

## Page 5 (Section: MD simulations)

Nature Computational Science | Volume 4 | May 2024 | 367–378
371
Resource
https://doi.org/10.1038/s43588-024-00627-2
of molecular dipole moments, just like tight-binding Mulliken charges44. 
From the latter, we infer furthermore the reasonableness of the elec-
tronic densities provided.
MD simulations
Experimental structural data are static snapshots that are assumed 
to represent a thermodynamic most stable state trapped in a crystal 
but ignore the presence of conformational dynamics. Experimental 
description of dynamics in biological macromolecules from nanosec-
ond to millisecond timescales is challenging and requires a combina-
tion of different spectroscopic techniques. NMR spectroscopy and 
fluorescence-based methods can provide relevant information but are 
time consuming, and so far the dynamic information is not well cap-
tured in public databases. MD simulations can be performed, starting 
from experimental structures, and letting them evolve in time using a 
force field that describes the molecular potential energy surface. Typi-
cally, periods of nanoseconds to microseconds can be achieved for indi-
vidual systems, depending on system size. MD traces allow the analysis 
of small-range structural fluctuations of the protein–ligand complex, 
but in some cases large-scale rare events can be observed (Fig. 3). In 
existing DD software these events are mostly neglected. MD simulations 
of 16,972 protein–ligand complexes in explicit water were performed 
for 10 ns. Structures were disregarded whenever non-standard ligand 
atoms or inconsistencies in the protein starting structures were encoun-
tered. A variety of metadata were generated from the simulations to 
facilitate future AI learning (Fig. 4, Supplementary Table 2 and Supple-
mentary Fig. 1). RMSDLigand (root-mean-square deviation of the ligand 
after alignment of the protein) and the root-mean-square deviation of 
the whole complex were calculated with respect to the native structure. 
Also, binding affinities were estimated using molecular mechanics 
generalized Born surface area (MMGBSA) scoring (no entropic contri-
butions explicitly considered)45. Moreover, the buried solvent acces-
sible surface area was obtained for the complex. Calculated properties 
are stable over the simulations, proving them well equilibrated (Sup-
plementary Fig. 1). For some systems, larger rearrangements of the 
binding site were captured that in extreme cases led to an opening of 
the whole binding pocket (Fig. 3). These rare events indicate possible 
cryptic pockets or transient binding modes. In a small fraction of cases, 
dissociation was detected (details given in Supplementary Fig. 2).
AI models
To exemplify possible applications of our dataset, baseline AI models 
were trained and evaluated. These are included in the repository as a 
template for future community development. For the QM dataset, the 
electron affinity and the chemical hardness of the ligand molecules 
were predicted (Fig. 5). The Pearson correlation is 0.75 for electron 
affinity and 0.77 for chemical hardness. The mean absolute error shows 
close predictions to the target values: on average 0.12 eV for electron 
affinity and 0.13 eV for chemical hardness. For these two exemplary 
QM features, high accuracy was achieved, opening a route to a fast 
derivation of QM properties. This is particularly important for larger 
molecules, where long calculation times are frequent.
For the MD traces, the induced-fit capability of the protein (adapt-
ability) was predicted (see Methods for an exact definition). The model 
was able to identify elements of biomolecule structure likely to adapt 
to ligand binding. We achieved a mean Pearson correlation of 0.66. 
On average 42 of the top 100 atoms were correctly predicted (Fig. 5). 
As shown in Fig. 5d, the model can predict the atoms in the protein 
pocket that are mostly flexible during the MD run (large spheres), and 
detect the more rigid protein regions (small spheres). This allows a fast 
QM H5 file
Atom_properties
10GS
11GS
13GS
9ICD
9HVP
....
Mol_properties
Atom_names
Bonds
Atom_properties_
names
Atom_properties_
values
Total_charge
Electron_aﬀinity
Electronegativity
Hardness
Ionization_potential
Koopman
Molecular_weight
Polarizability
Molecule property names
Molecule properties
Molecule properties
PDBIDs
MD H5 file
Atom_element
Atom_number
Atoms_residue
Atom_type
Frames_bSASA
Frames_distance
Frames_
interaction_energy
Frames_
rmsd_ligand
Molecule_begin_
atom_index
Trajectory_
coordinates
Fig. 4 | Data hierarchy of the QM and MD files. The QM data can be accessed via 
the PDB ID. The properties are split by atom properties and molecular properties. 
Examples of the calculated molecular properties are given. The electronic 
densities are provided in a separate file. The MD data are also subdivided by PDB 
ID. The properties are calculated either for all atoms, for each timestep (frame), 
or for the whole trajectory, as indicated by the name.

## Page 6 (Section: Experimental validation)

Nature Computational Science | Volume 4 | May 2024 | 367–378
372
Resource
https://doi.org/10.1038/s43588-024-00627-2
examination of the protein pocket without the necessity of a lengthy 
MD setup and simulation. The adaptability model gives an innovative 
example of how experimental structures can be enhanced from the 
MD-based MISATO data.
A binding affinity AI model combines MISATO MD and QM data. 
Experimental binding affinities are known to be difficult to compare 
across different experimental techniques, experimental conditions 
and calculated affinity types. To decrease these effects, our affinity 
model predicts a relative affinity of a target structure in relation to a 
defined base complex. These pairs have the protein and affinity type 
in common. We achieved high correlations for the MISATO binding 
affinity benchmark, with improved results using MISATO features when 
compared with no MISATO features (Fig. 6).
Experimental validation
The MISATO database and the adaptability AI model were validated 
on experimental data (Fig. 6). In X-ray crystallography a B factor is 
determined for each structure in the PDB. It is a measure of the thermal 
vibration of each atom but usually reflects localized molecular motion 
as well46. We achieved a mean correlation of 0.59 of the B factors with the 
root-mean-square fluctuation (RMSF) in the MISATO MD trajectories. 
To prove the model against more direct experimental flexibility data, 
we measured the cap-binding domain of influenza virus polymerase 
subunit PB247 as a model system. Heteronuclear Overhauser effect 
(hetNOE) NMR measurements, which elucidate flexible protein regions 
in solution, were performed on this structure (Supplementary Fig. 3). 
We obtained a high correlation between the calculated adaptabili-
ties and both B factors (0.63) and the hetNOE of the protein. A com-
parison with our adaptability prediction shows that the most flexible 
regions and the residues of higher rigidity are correctly identified by 
the model. Quantum chemical methods are required to predict rea-
sonable values for ionization potentials and electron affinities48. This 
applies not only to DFT (density functional theory) but also to ab initio. 
In Supplementary Data 1 we provide a parameter study performed with 
Target adaptability
Predicted adaptability
b
a
d
c
12.0
Electron aﬀinity
Chemical hardness
Target
Target
Target
Adaptability 2ig0—correlation 0.75
11.5
11.0
10.5
Prediction
Probability
10.0
9.5
9.0
0.02
0.04
0.06
0.08
0.10
0
0.2
0.3
0.4
0.5
0.6
Correlation
Mean 42
Correct top 100
0
20
40
60
80
Structure correlations mean 0.66
0.7
0.8
0.9
12.0
11.5
11.0
10.5
10.0
9.5
9.0
12.0
12.5
11.5
11.0
10.5
Prediction
10.0
9.5
12.0
12.5
11.5
11.0
10.5
10.0
9.5
5
5
6
6
4
4
3
3
2
2
Prediction
1
1
0
0
Probability
0.02
0.04
0.06
0.08
0.10
0
Fig. 5 | Performance of the AI baseline models. a, Scatter plot of the predicted 
against target values of chemical hardness and electron affinity. The AI baseline 
models to predict QM properties have a high correlation of 0.75 and 0.77 for 
electron affinity and chemical hardness, respectively. b, Adaptability is a 
measure of the per-atom conformational plasticity of the protein. A histogram 
of the correlation and the correct top 100 predictions of the adaptability for all 
structures in the test set are given. An overall mean correlation of 0.66 can be 
achieved and the mean top 100 accuracy was 0.42 for the adaptability predictions 
(MD). c, Scatter plot for the adaptability result (as in a) of example structure 2IG0. 
The predicted values are more narrowly distributed than the actual values,  
but the general trend is correct, as shown by a high correlation value of 0.75.  
d, The adaptability of the residues in the protein pocket highly deviates between 
the amino acids. The AI model predicts the adaptability given in blue-shaded 
(target) and red-shaded (AI-predicted) spheres. The radius is scaled according to 
the adaptability value. The model can correctly identify the rigid residues (small 
spheres) but also the amino acids with high flexibility. Color and character keys: 
N, blue, nitrogen; S, yellow, sulfur; O, red, oxygen; C, beige for ligand atoms and 
black for protein atoms, carbon.

## Page 7 (Section: Binding affinity benchmark and validation)

Nature Computational Science | Volume 4 | May 2024 | 367–378
373
Resource
https://doi.org/10.1038/s43588-024-00627-2
data collected from the CCCBDB database35, verifying the generality 
of trends reported in the literature48,49. The parameter study shows 
furthermore that semi-empirical ionization potentials are of a quality 
similar to, if not higher than, the best DFT results. The advantage, however, 
is that we systematically apply the same level of theory for all molecules, 
small and very large alike. We validated the ULYSSES-based calculations 
of Koopmans ionization potentials against experimental oxidation 
potentials and DFT-based ionization potentials from the literature 
for three molecule families. Our calculations correlated highly for 
photocatalysts (0.84, experimental oxidation potential), catechins 
(0.68, experimental oxidation potential) and thiaflavans (0.97, calcu-
lated DFT data).
Binding affinity benchmark and validation
The numerical values describing ligand potency cannot serve as a reli-
able baseline due to their origin in a wide range of experiments and 
conditions. These errors in the ground truth cannot be averaged out 
efficiently. Therefore, we collected high-quality affinity data for 127 
ligands for five different protein structures for a MISATO binding affinity 
benchmark set (Supplementary Table 1 and Supplementary Data 2)50–54. 
This set, being too small for training, can be a reliable validation method 
for affinity-predicting models. To guarantee reliable affinity data we 
filtered it to originate from the same publication for each set. Moreover, 
each of the sets had at least 15 entries with a high dynamical range and 
few additional occurrences of the protein structure within MISATO.
Our binding affinity graph convolutional network model was 
evaluated on this benchmark set with and without MISATO features. 
Additionally, we evaluated the model performance on the original 
PDBbind set, and using the Vina scoring function. With MD-derived 
adaptabilities and QM charges, we obtained a mean Spearman correla-
tion of 0.64, which was higher than without the MISATO features (0.50), 
using Vina (0.51) and using the non-curated database (0.50). Inter-
estingly, an improvement for each of the five sets using the MISATO 
features could be achieved.
As confirmation of the given results, we evaluated the affinity 
model on a second benchmark set comprising the six largest clusters of 
protein structures (clustered on the basis of UniProt ID) of the test set 
(Supplementary Table 3). These clusters are substantially larger than 
the sets from the MISATO benchmark and do not necessarily originate 
from the same publication and the same experimental method within a 
set. The absolute correlations decreased for this second, more diverse 
benchmark (Supplementary Fig. 4). Still, we see the same trend as for 
the first benchmark with a better performance of the MISATO model 
including adaptability and QM features than the other approaches.
Finally, consistent improvement of affinity prediction model 
accuracy upon inclusion of QM and dynamic features was observed for 
the entire curated set as well as selected subsets with high-confidence 
affinity values (Fig. 6 and Supplementary Figs. 4 and 5). This empha-
sizes the importance of curation of ligand data and inclusion of at least 
short-term dynamics in the accuracy of affinity predictions.
Correlation to experimental binding aﬀinities
a
b
d
R2 = 0.974
7.5
8.0
8.5
9.0
9.5
10.0
DFT IP (V)
Thiaflavans
R2 = 0.6823
10.10
10.12
10.14
10.16
10.18
10.20
10.22
10.24
Oxidation potential (V)
Catechins
R2 = 0.8386
7.0
7.5
8.0
8.5
9.0
9.5
10.0
10.5
11.0
11.5
12.0
1.00
1.05
1.10
1.15
1.20
1.25
1.30
1.35
1.40
0.40
0.45
0.50
0.55
0.60
0.65
0.70
0.75
0.80
0.85
0.90
–1.2
–0.7
–0.2
0.3
0.8
1.3
1.8
Oxidation potential (V)
Photocatalysts
Koopman IP (eV)
c
e
1.0
5,000
4,000
3,000
2,000
1,000
0
Vina
Not curated
MISATO curation
MISATO dynamic and QM features
Correlation of Bfactors per structure: mean
0.59 ± 0.12
0.8
0.6
0.2
0.4
Spearman correlation
Count
0
Mean 1,043 5A/0
2VQZ correlation 0.63
Adaptability
Adaptability
Residue count
20
–1.0
–1*hetNOE
–0.8
–0.6
–0.4
–0.2
0
0.5
1.0
1.5
2.0
2.5
40
60
80
100
120
140
160
20
40
60
80
100
120
140
160
1
10
20
30
40
B-factor
50
60
70
2
3
4
5
5NJZ
5Q0I 6QQT
–0.2
0
0.2
0.4
Correlation
0.6
0.8
1.0
Fig. 6 | Experimental validation of QM calculations, MD traces and AI models. 
a, Spearman correlation of the affinity GNN model on the binding affinity 
benchmark including MISATO features and without features. Moreover, the 
results using Vina and non-curated complexes (original PDBbind) are shown. 
We achieved a consistently better performance including QM charges and MD 
adaptabilities as MISATO features across the affinity benchmark when compared 
with all other approaches. b, Histogram of the correlation of experimental  
B factors from X-ray crystallography experiments with RMSF calculations from 
the MD simulations in MISATO. A correlation of 0.59 over all structures was 
achieved. c, High correlations of calculated Koopmans ionization potentials (IP) 
from ULYSSES with DFT ionization potentials (upper panel) and experimental 
oxidation potentials (middle and lower panels) were found for different molecule 
families. d, The cap-binding domain of influenza virus polymerase as a model 
system for experimental validation of the predicted adaptability. Values given 
by our AI model had a high correlation of 0.63 against the experimentally 
determined B factors (which, despite characterizing atom thermal vibration, 
usually indicates flexibility). e, Results of the hetNOE experiments of the 
cap-binding domain of influenza virus polymerase indicating flexibility of the 
protein chain were in high accordance with the results of the adaptability model 
(indicated using shaded regions).

## Page 8 (Section: Discussion)

Nature Computational Science | Volume 4 | May 2024 | 367–378
374
Resource
https://doi.org/10.1038/s43588-024-00627-2
The given experiments show that adding the features present in 
MISATO improves model accuracy over relying on implicit learning 
from the bare structure.
Discussion
The great advances over the past years of AI technologies were only 
possible due to the huge datasets that are fed into these models. In 
structural biology, the protein folding problem was solved recently, 
but the DD community still lacks a breakthrough model.
Here, we present MISATO, a database that will open routes in DD 
for researchers from chemistry, structural biology, biophysics and 
bioinformatics. MISATO contains the quantum-chemically refined 
ligand dataset, which permitted the elimination of several structural 
inaccuracies and crystallographic artifacts. Our refinement protocol 
can be immediately applied by others for quick database augmenta-
tion. We enhance the curated dataset following two orthogonal dimen-
sions. On the one hand, a QM approach supplies systematic electronic 
properties. On the other hand, a classical approach reveals the system’s 
dynamics and includes the binding affinity and conformational 
landscape. MISATO contains the largest collection of protein–ligand 
MD traces to date. Extensive experimental validation of the QM calcula-
tions, MD trajectories and AI baseline models highlights the dataset’s 
importance (Fig. 6).
Checkpoint files are made available for potential community 
extension of the dynamic traces (Supplementary Table 4). Struc-
tural biology datasets until now have been unable to incorporate 
entropy-related information about binding sites and the dynamics of 
the systems. By conducting MD simulations, it is possible to approxi-
mate the conformational space for entropy estimation. A Python inter-
face, built to be intuitively used by anyone, provides preprocessing 
scripts and template notebooks.
The current limitations of MISATO include the fact that until now 
the QM calculations were only conducted on the ligand molecules. 
Moreover, longer timescales of the MD simulations are desirable. These 
limitations are related to the availability of computing resources. With 
future releases of MISATO these points will be addressed.
The dataset augmentation presented here paves the way for creative 
applications of AI models. Our example graph neural network (GNN) 
model offers quick access to pocket flexibility, a problem never tackled 
before. This is however just a starting point for a whole class of AI models 
sprouting from MISATO. Ultimately, we envision models being built 
on the best of quantum and Newtonian worlds to obtain high-quality 
thermodynamics, innovatively and efficiently matching the quality of 
experimental data. With MISATO, AI models will uncover hidden state 
variables describing protein–ligand complexes.
Altogether, MISATO is meant to provide sufficient training power 
for accurate, next-generation structure-based DD using AI methods.
Methods
Semi-empirical calculations
QM calculations were performed using the ULYSSES library55, our 
in-house semi-empirical package. The methods of choice were 
GFN2-xTB56, AM1 (ref. 57) and PM6 (ref. 58). Implicit solvation was 
included using ALPB59 as parameterized for GFN2-xTB. Selected media 
included water and wet octanol. Bond orders and hybridizations were 
estimated using distance-based criteria.
QM curation of ligand space
Consistent atomic assignments were determined using a series of 
semi-empirical tests. Semi-empirical quantum chemical methods offer 
a good compromise between accuracy and computational efficiency60, 
which is suitable to refine a collection of almost 20,000 structures of 
various chemical natures and dimensions (from 6 to almost 370 atoms 
per molecule). The consistency tests we designed were performed in 
vacuum to ensure maximum sensitivity of the calculations to structural 
inconsistencies. Predicted properties, however, are also obtained using 
an implicit solvation model.
It is well documented that molecules with many polar groups 
lack convergence in wavefunction optimization61. The same applies 
when incorrect charges or protonation states are used. Implicit sol-
vation substantially ameliorates the issue and masks problems. In 
fact, after determining the first guess for total molecular charges, 
single-point-energy calculations on unrefined ligands using implicit 
water required roughly 6 h of computation time. Turning off implicit 
solvation increased the calculation time to almost three weeks on the 
same machine. This was indicative of severe limitations in proton and 
total charge assignment. Alternative protonation algorithms were 
tested—for example, Open Babel62. Due to experimental inaccuracies in 
the geometries, the results were still faulty (Supplementary Figs. 6–9).
Our refinement protocol started with a search for structures with 
strong atomic overlap. Next, we looked for structures with problematic 
wavefunction convergence. Vanishing HOMO–LUMO gaps or unpaired 
electrons flagged further problems, as did violations of the octet rule 
based on QM population analysis. Finally, we searched for changes in 
ligand connectivity patterns after QM geometry optimization. This was 
particularly useful in determining inconsistent protonation states or 
incorrect electron counting, which generated biradicals. Calculated 
properties yielded additional testing grounds. Incorrect element 
assignments were detected when plotting the partial charges against 
D4 polarizabilities63 (Fig. 2b).
Severe structural deformations were also detected, inconsistent 
with the chemical structure (see previous section). For the current stage 
of the database, we decided to fix only the most extreme cases. This 
was done using Avogadro (Supplementary Fig. 10)64. Further structural 
refinement is planned.
Whenever our corrections seemed questionable, or the structure 
was unclear, we checked the original publication. Oxidation states 
were another sensible point for ligands containing transition metals. 
Examples of structures we refined are given in the Supplementary 
Information (Supplementary Figs. 10–12). To ease the inclusion and 
processing of new structures, a heuristics-based program is included 
in the database, which performs the basic structural processing (see 
Supplementary Information for more details). A detailed schematic for 
the protocol used for cleaning and refining the structures is also given 
in the Supplementary Information (Supplementary Figs. 13 and 14).
MD simulations
For all MD simulations, we used the Amber20 (ref. 65) software suite. 
The protein–ligand complexes were prepared and simulated on the 
basis of a standard set-up. We parameterized the ligands calculating 
AM1-BCC38 charges using antechamber66 (if the charges did not con-
verge within 1 h we used AM1 charges calculated with ULYSSES). We used 
the gaff2 (ref. 66) force field for ligands and ff14SB67 for the proteins. 
The complexes were neutralized with Na+ and Cl− ions and solvated in 
TIP3P68 explicit water using periodic boundary conditions in an octa-
hedral box (minimum distance between protein and boundary 12 Å).
The complexes were minimized (1,000 steps steepest descent 
followed by conjugate gradient) and heated to 300 K in several steps 
within 16 ps. We performed production simulations for 10 ns on all 
protein–ligand cases in an NVT ensemble. The first 2 ns were discarded 
as equilibration phase, so 8 ns are stored over 100 snapshots for each 
protein–ligand complex. Using pytraj31 we calculated different proper­
ties of the simulations such as the MMGBSA interaction energy, the 
buried solvent accessible surface area, the center-of-mass distance 
between ligand and receptor, and root-mean-square deviations from 
the native complex.
Access to the database
The database can be downloaded from Zenodo (Supplementary 
Table 4). Data are stored in a hierarchical data format. We created two

## Page 9 (Section: AI applications)

Nature Computational Science | Volume 4 | May 2024 | 367–378
375
Resource
https://doi.org/10.1038/s43588-024-00627-2
H5 files, one for the protein–ligand dynamics and one for quantum 
chemical data, that can be accessed through our container images or 
after installation of the required Python packages. Installation instruc-
tions are given in the repository (Supplementary Table 4). Data are split 
for each structure using the PDB ID. The feature of interest must also be 
specified (Fig. 4 and Supplementary Table 2). Python scripts are given 
in the repository showing how to preprocess the MD dataset for specific 
cases, only Cα atoms, no hydrogen atoms, only atoms from the binding 
pocket, and the inclusion of new features. Instructions on how to run 
inference on new PDB files and visualize the baseline models are given. 
Checkpoint files for continuing the MD simulations and the electronic 
densities are provided separately.
AI applications
For the baseline model for QM predictions, we followed the GNN 
architecture for small-molecule property prediction in ATOM3D69. 
This model is based on graph convolutions proposed by Kipf and 
Welling70 and was adapted for the simultaneous prediction of electron 
affinity and chemical hardness as essential parameters to describe 
the ligand. The architecture for the baseline model was a dense layer 
followed by three sequential layers of NNConv and GRU followed by 
two dense layers. The model is available via our GitHub repository.
The performance of the ML model was evaluated using correlation 
and the mean absolute error.
We encode each molecule using the atom positions, the atom type 
and the bond between the atoms. Each atom corresponds to a node. 
The atom types are one-hot encoded and edges are defined by select-
ing the nearest neighbors with a distance of 4.5 Å for each atom. Edges 
are weighted inversely by the distance between the atoms. We removed 
outliers straying more than 20 s.d. from the mean values (PDB IDs given 
in Supplementary Information). All outliers corresponded to molecules 
containing negatively charged groups and alkyl chains. In other words, 
these are highly saturated molecules from the electronic viewpoint. 
Because of their electronic structure, acceptance of an electron is highly 
unlikely, resulting in very low-to-negative electron affinities. Inaccuracies 
in the geometries further exacerbate the calculated electron affinities. 
The results on these systems indicate that some electronic properties are 
not quantitative; instead, they simply reflect the system’s behavior. We 
trained the GNN with four NVIDIA A100 graphics processing units (GPUs) 
and 96 CPUs (from 48 physical cores) and for 200 epochs. We used a batch 
size of 128 and applied a random translation on each node of 0.05 Å.
For the MD task, we modified the GNN architecture from ATOM3D69 
for the node regression task by removing the aggregation of node fea-
tures into graph features. The architecture for the baseline model was 
five sequential GCNConv layers70 followed by two linear layers, sum-
ming to 370,000 trainable parameters. The dataset was split into a train 
(80%), a test (10%) and a validation set (10%) (Supplementary Table 5 
and Supplementary Fig. 15) by clustering the amino-acid sequences of 
the proteins using BlastP71 to make sure to not have a leakage of similar 
structural motifs between the splits. We train the GNN with four NVIDIA 
A100 GPUs and 96 CPUs and for 15 epochs. We use a batch size of eight 
and a random translation of 0.05 Å. With our model, we calculated the 
adaptability of each atom during the MD simulation. To this end, we 
performed an alignment of the coordinates of each simulation with 
reference to the first frame. To calculate the adaptability γx for each 
atom x we take the mean distance of each atom over all timesteps i from 
the initial position of the atom rref,x:
γx =
1
Nframes
Nframes
∑
i
||(rref,x −ri,x)|| .
Hydrogen atoms were omitted to reduce the size of the model. For 
the evaluation, the mean over the results for each structure was calcu-
lated. Adaptability gives results very similar to those of RMSF evalu-
ations. We evaluated the performance of our training using Pearson 
correlation and the average accuracy of the 100 most flexible atoms 
of each complex.
For the binding affinity task, the data processing, training 
procedure and GNN architecture were modified. For data processing, 
all protein–ligand complexes (excluding 1,192 protein–peptide com-
plexes) with known binding affinity were clustered at 30% sequence 
similarity to avoid data leakage between training (82%), validation (9%) 
and test (9%) sets (Supplementary Fig. 15). The MISATO affinity bench-
mark was a holdout part of the test set. Next, clusters were defined on 
the basis of the UniProt identifier and affinity type, so that each cluster 
contained only affinity values of the same protein and one of the three 
affinity types present in the dataset (Ki, Kd, IC50).
The model predicts the ratio of binding affinities between a pair 
of protein–ligand complexes. For each cluster, one base molecule 
was defined that built a pair with each entry of the cluster. The pro-
tein–ligand complexes for which no cluster with at least two entries 
could be defined were discarded (2,259 entries). The atom types were 
one-hot encoded (omitting hydrogen atoms), and edges were defined 
following the adaptability model.
One training step consisted of one forward pass for each of the 
two complexes and mean squared error loss calculation based on the 
logarithmic ratio of the affinities for each pair. We trained a model 
including MISATO features and without MISATO features. MISATO 
atom features comprised calculated adaptabilities (MD) and GFN2-xTB 
charges in water (QM) for the ligands.
For the GNN architecture, five sequential GCNConv layers were 
followed by a separate pooling operation for the ligand and protein, 
respectively. These representations were then further processed via 
three linear layers with ReLU nonlinearities.
We trained the GNN with four GPUs, 90 CPUs, a batch size of 50 and 
for 50 epochs. We evaluated the best models on the MISATO affinity 
benchmark using Spearman correlation on each set.
We used PyTorch v.1.14 to train the models. To code the data load-
ers and the GNN, we used PyTorch Geometric 2.3.0.
Scoring of ligands with AutoDock Vina
We calculated an AutoDock Vina9 score for the MISATO refined pro-
tein–ligand complexes of both benchmark sets. We followed a standard 
preprocessing procedure of generating pdbqt files (see ref. 72 to follow 
the exact steps). For the receptors we used the prepare_receptor tool on 
the protonated protein structure from ADFR Suite73,74. For the ligands 
we converted the structures from MOL2 format to pdbqt format using 
the mk_prepare_ligand.py script. We computed the Vina scores from 
the generated pdbqt files using the score function from the Python 
interface of Vina (all scripts can be found via the GitHub page of Vina).
Correlation with experimental B factors
The experimental B factors were parsed from published PDB files of 
crystal structures. For data cleaning, we omitted structures for which 
80% of the published B factor values had the same entry. Additionally, 
for some structures, it was not possible to parse the B factors correctly 
due to inconsistencies in the underlying PDB files. The RMSF of each 
atom of the MD simulation was calculated after superposition to the 
first frame using pytraj31.
Binding affinity benchmark
The benchmark was created by identifying structures in MISATO that 
originated from the same publication with at least 15 entries. The 
benchmark was carefully evaluated by assessment of the publication 
for each of the sets. Only high-quality experimental techniques and 
data were considered. We further removed sets with a small dynamic 
range of the affinity data, high coexistence of structures of the same 
protein within MISATO, and sets with cofactors or metals interacting 
at the binding site. We obtained a benchmark consisting of five protein 
sets and 127 bound ligands.

## Page 10 (Section: Protein purification and NMR spectroscopy)

Nature Computational Science | Volume 4 | May 2024 | 367–378
376
Resource
https://doi.org/10.1038/s43588-024-00627-2
Protein purification and NMR spectroscopy
The influenza PB2 domain was expressed and purified as previously 
published47. NMR data were acquired at 298 K using a 0.8 mM 13C- 
15N-PB2 sample on an AV600 spectrometer equipped with a cryoprobe. 
The sample buffer contained 20 mM sodium phosphate at pH 6.5, and 
100 mM NaCl. Standard NMR experiments were used for chemical shift 
assignments, mainly HNCA, HNCACB, CBCACONH, HNCO, CCONH and 
HCCH/TOCSY (total correlation spectroscopy). Spectra were processed 
with the nmrDraw/NMRPipe package75 and analyzed with NMRView76.
Statistics and reproducibility
The splits for train, test and validation were randomized for the differ-
ent ML models. The exact procedure for each model is given in Supple-
mentary Fig. 15. No statistical method was used to predetermine sample 
size. For MD, structures were disregarded whenever non-standard 
ligand atoms (metal ions) or inconsistencies in the protein starting 
structures were encountered. For the QM model (Supplementary 
Section 3), a small number (30) of structures were omitted due to the 
inability of the current algorithm to provide correct predictions for 
them. This does not introduce a bias to the observation and does not 
change our observations.
The investigators were not blinded to allocation during experi-
ments or outcome assessment.
Reporting summary
Further information on research design is available in the Nature 
Portfolio Reporting Summary linked to this article.
Data availability
MISATO is publicly accessible and can be downloaded from Zenodo77 
(https://zenodo.org/records/7711953). We provide instructions for 
usage, data loaders via our GitHub repository, and a container image 
with all relevant packages installed for GPU usage (Supplementary 
Table 4). MISATO was built from the PDBbind database (release 2022). 
Source Data are provided with this paper.
Code availability
The code can be accessed from our GitHub repository and on Zenodo78 
(https://github.com/t7morgen/misato-dataset). The dataset is acces-
sible via a Python interface using a simple PyTorch data loader. Special 
attention was given to code modularity, which makes it easy to adjust 
the AI architecture (Fig. 4 and Supplementary Section 7). We have 
implemented our dataset according to the ATOM3D69 code base, a 
comprehensive suite of ML methods for molecular applications.
References
1.	
Jumper, J. et al. Highly accurate protein structure prediction with 
AlphaFold. Nature 596, 583–589 (2021).
2.	
Berman, H., Henrick, K. & Nakamura, H. Announcing the 
worldwide Protein Data Bank. Nat. Struct. Mol. Biol. 10, 980 (2003).
3.	
Mohs, R. C. & Greig, N. H. Drug discovery and development: role 
of basic biological research. Alzheimer’s Dement. Transl. Res. Clin. 
Interv. 3, 651–657 (2017).
4.	
Sliwoski, G., Kothiwale, S., Meiler, J. & Lowe, E. W. Computational 
methods in drug discovery. Pharm. Rev. 66, 334–395 (2014).
5.	
Thiel, W. Semiempirical quantum-chemical methods.  
WIREs Comput. Mol. Sci. 4, 145–157 (2014).
6.	
Hollingsworth, S. A. & Dror, R. O. Molecular dynamics simulation 
for all. Neuron 99, 1129–1143 (2018).
7.	
Siebenmorgen, T. & Zacharias, M. Computational prediction of 
protein–protein binding affinities. WIREs Comput. Mol. Sci. 10, 
e1448 (2020).
8.	
Trott, O. & Olson, A. J. AutoDock Vina: improving the speed and  
accuracy of docking with a new scoring function, efficient optimi­
zation, and multithreading. J. Comput. Chem. 31, 455–461 (2010).
9.	
Kmiecik, S. et al. Coarse-grained protein models and their 
applications. Chem. Rev. 116, 7898–7936 (2016).
10.	 Spicher, S. & Grimme, S. Robust atomistic modeling of materials, 
organometallic, and biochemical systems. Angew. Chem. Int. Ed. 
59, 15665–15673 (2020).
11.	
Vandenbrande, S., Waroquier, M., Speybroeck, V. V. & Verstraelen, 
T. The monomer electron density force field (MEDFF): a physically 
inspired model for noncovalent interactions. J. Chem. Theory 
Comput. 13, 161–179 (2017).
12.	 Wang, J. & Dokholyan, N. V. Yuel: improving the generalizability of 
structure-free compound–protein interaction prediction. J. Chem. 
Inf. Model. 62, 463–471 (2022).
13.	 Ponder, J. W. et al. Current status of the AMOEBA polarizable force 
field. J. Phys. Chem. B 114, 2549–2564 (2010).
14.	 Chen, B. et al. Automated discovery of fundamental variables 
hidden in experimental data. Nat. Comput Sci. 2, 433–442 (2022).
15.	 Durrant, J. D. & McCammon, J. A. NNScore: a 
neural-network-based scoring function for the characterization 
of protein−ligand complexes. J. Chem. Inf. Model. 50, 1865–1871 
(2010).
16.	 Wang, X., Terashi, G., Christoffer, C. W., Zhu, M. & Kihara, D. Protein 
docking model evaluation by 3D deep convolutional neural 
networks. Bioinformatics 36, 2113–2118 (2020).
17.	 Wang, N.-N. et al. ADME properties evaluation in drug discovery: 
prediction of Caco-2 cell permeability using a combination of 
NSGA-II and boosting. J. Chem. Inf. Model. 56, 763–773 (2016).
18.	 Ishida, S., Terayama, K., Kojima, R., Takasu, K. & Okuno, Y. 
AI-driven synthetic route design incorporated with retrosynthesis 
knowledge. J. Chem. Inf. Model. 62, 1357–1367 (2022).
19.	 Karpov, P., Godin, G. & Tetko, I. V. A transformer model for 
retrosynthesis. In Artificial Neural Networks and Machine 
Learning—ICANN 2019: Workshop and Special Sessions  
(eds Tetko, I. V. et al.) 817–830 (Springer, 2019).
20.	 Öztürk, H., Özgür, A. & Ozkirimli, E. DeepDTA: deep drug–target 
binding affinity prediction. Bioinformatics 34, i821–i829 (2018).
21.	 Karimi, M., Wu, D., Wang, Z. & Shen, Y. DeepAffinity: interpretable 
deep learning of compound–protein affinity through unified 
recurrent and convolutional neural networks. Bioinformatics 35, 
3329–3338 (2019).
22.	 Hassan-Harrirou, H., Zhang, C. & Lemmin, T. RosENet: improving 
binding affinity prediction by leveraging molecular mechanics 
energies with an ensemble of 3D convolutional neural networks. 
J. Chem. Inf. Model. 60, 2791–2802 (2020).
23.	 Feinberg, E. N. et al. PotentialNet for molecular property 
prediction. ACS Cent. Sci. 4, 1520–1530 (2018).
24.	 Li, Y., Rezaei, M. A., Li, C. & Li, X. DeepAtom: a framework 
for protein–ligand binding affinity prediction. In 2019 IEEE 
International Conference on Bioinformatics and Biomedicine 
(BIBM) 303–310 (IEEE, 2019).
25.	 Wang, R., Fang, X., Lu, Y., Yang, C.-Y. & Wang, S. The PDBbind 
database: methodologies and updates. J. Med. Chem. 48, 
4111–4119 (2005).
26.	 Liu, T., Lin, Y., Wen, X., Jorissen, R. N. & Gilson, M. K. BindingDB:  
a web-accessible database of experimentally determined 
protein–ligand binding affinities. Nucleic Acids Res. 35,  
D198–D201 (2007).
27.	 Hu, L., Benson, M. L., Smith, R. D., Lerner, M. G. & Carlson, H. A. 
Binding MOAD (Mother Of All Databases). Proteins Struct. Funct. 
Bioinform. 60, 333–340 (2005).
28.	 Friedrich, N.-O., Simsir, M. & Kirchmair, J. How diverse are the 
protein-bound conformations of small-molecule drugs and 
cofactors? Front. Chem. 6, 68 (2018).
29.	 Korlepara, D. B. et al. PLAS-5k: dataset of protein–ligand affinities 
from molecular dynamics for machine learning applications.  
Sci. Data 9, 548 (2022).

## Page 11 (Section: Protein purification and NMR spectroscopy)

Nature Computational Science | Volume 4 | May 2024 | 367–378
377
Resource
https://doi.org/10.1038/s43588-024-00627-2
30.	 Korlepara, D. B. et al. PLAS-20k: extended dataset of protein–
ligand affinities from MD simulations for machine learning 
applications. Sci. Data 11, 180 (2024).
31.	 Yang, J., Shen, C. & Huang, N. Predicting or pretending: artificial 
intelligence for protein–ligand interactions lack of sufficiently 
large and unbiased datasets. Front. Pharmacol. 11, 69 (2020).
32.	 Volkov, M. et al. On the frustration to predict binding affinities 
from protein–ligand structures with deep neural networks.  
J. Med. Chem. 65, 7946–7958 (2022).
33.	 Vajda, S., Beglov, D., Wakefield, A. E., Egbert, M. & Whitty, A. 
Cryptic binding sites on proteins: definition, detection, and 
druggability. Curr. Opin. Chem. Biol. 44, 1–8 (2018).
34.	 Zeng, L. et al. Selective small molecules blocking HIV-1 Tat and 
coactivator PCAF association. J. Am. Chem. Soc. 127, 2376–2377 
(2005).
35.	 Johnson, R. D. III (ed). Computational Chemistry Comparison and 
Benchmark Database Standard Reference Database Number 101 
Release 22 (NIST, accessed 12 Jul 2022); http://cccbdb.nist.gov/
36.	 Bista, M. et al. Transient protein states in designing inhibitors of 
the MDM2–p53 interaction. Structure 21, 2143–2151 (2013).
37.	 Xie, M. et al. Structural basis of inhibition of ERα–coactivator 
interaction by high-affinity N-terminus isoaspartic acid tethered 
helical peptides. J. Med. Chem. 60, 8731–8740 (2017).
38.	 Jakalian, A., Jack, D. B. & Bayly, C. I. Fast, efficient generation of 
high-quality atomic charges. AM1-BCC model: II. Parameterization 
and validation. J. Comput. Chem. 23, 1623–1641 (2002).
39.	 Dodda, L. S., Vilseck, J. Z., Tirado-Rives, J. & Jorgensen, W. L. 
1.14*CM1A-LBCC: localized bond-charge corrected CM1A  
charges for condensed-phase simulations. J. Phys. Chem. B 121, 
3864–3870 (2017).
40.	 Jorgensen, W. L., Maxwell, D. S. & Tirado-Rives, J. Development 
and testing of the OPLS all-atom force field on conformational 
energetics and properties of organic liquids. J. Am. Chem. Soc. 
118, 11225–11236 (1996).
41.	 Storer, J. W., Giesen, D. J., Cramer, C. J. & Truhlar, D. G. Class 
IV charge models: a new semiempirical approach in quantum 
chemistry. J. Comput. Aided Mol. Des. 9, 87–110 (1995).
42.	 Li, J., Zhu, T., Cramer, C. J. & Truhlar, D. G. New class IV charge 
model for extracting accurate partial charges from wave 
functions. J. Phys. Chem. A 102, 1820–1831 (1998).
43.	 Thompson, J. D., Cramer, C. J. & Truhlar, D. G. Parameterization of 
charge model 3 for AM1, PM3, BLYP, and B3LYP. J. Comput. Chem. 
24, 1291–1304 (2003).
44.	 Grimme, S. & Bannwarth, C. Ultra-fast computation of electronic 
spectra for large systems by tight-binding based simplified 
Tamm–Dancoff approximation (sTDA-xTB). J. Chem. Phys. 145, 
054103 (2016).
45.	 Wang, E. et al. End-point binding free energy calculation with 
MM/PBSA and MM/GBSA: strategies and applications in drug 
design. Chem. Rev. 119, 9478–9508 (2019).
46.	 Sun, Z., Liu, Q., Qu, G., Feng, Y. & Reetz, M. T. Utility of B factors 
in protein science: interpreting rigidity, flexibility, and internal 
motion and engineering thermostability. Chem. Rev. 119,  
1626–1665 (2019).
47.	 Guilligay, D. et al. The structural basis for cap binding by influenza 
virus polymerase subunit PB2. Nat. Struct. Mol. Biol. 15, 500–506 
(2008).
48.	 Rayne, S. & Forest, K. Benchmarking semiempirical, Hartree–
Fock, DFT, and MP2 methods against the ionization energies and 
electron affinities of short- through long-chain [n]acenes and [n]
phenacenes. Can. J. Chem. 94, 251–258 (2016).
49.	 Zhan, C.-G., Nichols, J. A. & Dixon, D. A. Ionization potential, 
electron affinity, electronegativity, hardness, and electron 
excitation energy: molecular properties from density functional 
theory orbital energies. J. Phys. Chem. A 107, 4184–4195 (2003).
50.	 Lange, G. et al. Requirements for specific binding of low affinity 
inhibitor fragments to the SH2 domain of pp60Src are identical 
to those for high affinity binding of full length inhibitors. J. Med. 
Chem. 46, 5184–5195 (2003).
51.	 Öster, L., Tapani, S., Xue, Y. & Käck, H. Successful generation  
of structural information for fragment-based drug discovery.  
Drug Discov. Today 20, 1104–1111 (2015).
52.	 Heinzlmeir, S. et al. Chemoproteomics-aided medicinal chemistry 
for the discovery of EPHA2 inhibitors. ChemMedChem 12, 
999–1011 (2017).
53.	 Gaieb, Z. et al. D3R Grand Challenge 2: blind prediction  
of protein–ligand poses, affinity rankings, and relative  
binding free energies. J. Comput. Aided Mol. Des. 32, 1–20 
(2018).
54.	 Whitehouse, A. J. et al. Development of inhibitors against 
Mycobacterium abscessus tRNA (m1G37) methyltransferase 
(TrmD) using fragment-based approaches. J. Med. Chem. 62, 
7210–7232 (2019).
55.	 Menezes, F. & Popowicz, G. M. ULYSSES: an efficient and easy  
to use semiempirical library for C. J. Chem. Inf. Model. 62, 
3685–3694 (2022).
56.	 Bannwarth, C., Ehlert, S. & Grimme, S. GFN2-xTB—an accurate and  
broadly parametrized self-consistent tight-binding quantum 
chemical method with multipole electrostatics and density- 
dependent dispersion contributions. J. Chem. Theory Comput. 15, 
1652–1671 (2019).
57.	 Dewar, M. J. S., Zoebisch, E. G., Healy, E. F. & Stewart, J. J. P. 
Development and use of quantum mechanical molecular 
models. 76. AM1: a new general purpose quantum mechanical 
molecular model. J. Am. Chem. Soc. 107, 3902–3909  
(1985).
58.	 Stewart, J. J. P. Application of the PM6 method to modeling 
proteins. J. Mol. Model. 15, 765–805 (2009).
59.	 Sigalov, G., Fenley, A. & Onufriev, A. Analytical electrostatics  
for biomolecules: beyond the generalized Born approximation.  
J. Chem. Phys. 124, 124902 (2006).
60.	 Christensen, A. S., Kubař, T., Cui, Q. & Elstner, M. Semiempirical 
quantum mechanical methods for noncovalent interactions  
for chemical and biochemical applications. Chem. Rev. 116, 
5301–5337 (2016).
61.	 Dixon, S. L. & Merz, K. M. Fast, accurate semiempirical molecular 
orbital calculations for macromolecules. J. Chem. Phys. 107, 
879–893 (1997).
62.	 O’Boyle, N. M. et al. Open Babel: an open chemical toolbox.  
J. Cheminform. 3, 33 (2011).
63.	 Caldeweyher, E. et al. A generally applicable atomic-charge 
dependent London dispersion correction. J. Chem. Phys. 150, 
154122 (2019).
64.	 Hanwell, M. D. et al. Avogadro: an advanced semantic chemical 
editor, visualization, and analysis platform. J. Cheminform. 4, 17 
(2012).
65.	 Case, D. A. et al. Amber 2021 (Univ. of California, San Francisco, 
2021).
66.	 Wang, J., Wolf, R. M., Caldwell, J. W., Kollman, P. A. & Case, D. A.  
Development and testing of a general Amber force field.  
J. Comput. Chem. 25, 1157–1174 (2004).
67.	 Maier, J. A. et al. ff14SB: improving the accuracy of protein side 
chain and backbone parameters from ff99SB. J. Chem. Theory 
Comput. 11, 3696–3713 (2015).
68.	 Jorgensen, W. L., Chandrasekhar, J., Madura, J. D., Impey, R. W. &  
Klein, M. L. Comparison of simple potential functions for 
simulating liquid water. J. Chem. Phys. 79, 926–935 (1983).
69.	 Townshend, R. J. L. et al. ATOM3D: tasks on molecules in 
three dimensions. Preprint at https://doi.org/10.48550/
arXiv.2012.04035 (2022).

## Page 12 (Section: Acknowledgements)

Nature Computational Science | Volume 4 | May 2024 | 367–378
378
Resource
https://doi.org/10.1038/s43588-024-00627-2
70.	 Kipf, T. N. & Welling, M. Semi-supervised classification with graph 
convolutional networks. Preprint at https://doi.org/10.48550/ 
arXiv.1609.02907 (2017).
71.	 Huang, Y., Niu, B., Gao, Y., Fu, L. & Li, W. CD-HIT Suite: a web 
server for clustering and comparing biological sequences. 
Bioinformatics 26, 680–682 (2010).
72.	 Forli, S. et al. Computational protein–ligand docking and virtual 
drug screening with the AutoDock suite. Nat. Protoc. 11, 905–919 
(2016).
73.	 Zhao, Y., Stoffler, D. & Sanner, M. Hierarchical and multi-resolution 
representation of protein flexibility. Bioinformatics 22, 2768–2774 
(2006).
74.	 Ravindranath, P. A., Forli, S., Goodsell, D. S., Olson, A. J. &  
Sanner, M. F. AutoDockFR: advances in protein–ligand docking 
with explicitly specified binding site flexibility. PLoS Comput. Biol. 
11, e1004586 (2015).
75.	 Delaglio, F. et al. NMRPipe: a multidimensional spectral 
processing system based on UNIX pipes. J. Biomol. NMR 6, 
277–293 (1995).
76.	 Johnson, B. A. & Blevins, R. A. NMR View: a computer program 
for the visualization and analysis of NMR data. J. Biomol. NMR 4, 
603–614 (1994).
77.	 Siebenmorgen, T. et al. MISATO—machine learning dataset for 
structure-based drug discovery. Zenodo https://doi.org/10.5281/
zenodo.7711953 (2023).
78.	 t7morgen/misato-dataset: release for publication. Zenodo  
https://doi.org/10.5281/zenodo.10926008 (2024).
Acknowledgements
This work received funding from BMWi ZIM KK 5197901TS0 (T.S., 
F.M., G.M.P.) and BMBF, SUPREME, 031L0268 (T.S., F.M., G.M.P.). This 
work was supported by the Helmholtz Association’s Initiative and 
Networking Fund on the HAICORE@FZJ partition.
The funders had no role in study design, data collection and analysis, 
decision to publish or preparation of the manuscript.
Author contributions
T.S. and F.M. created and refined the dataset, designed the ML 
experiments, performed the ML experiments, analyzed the data and 
wrote the paper. S.B., E.M. and K.D. performed the ML experiments, 
analyzed the data and contributed to the paper writing. A.S.D.M. 
performed the NMR experiments and analysis and wrote the  
NMR section. R.K. selected and validated the affinity benchmark.  
P.L., S.K., M.P., F.J.T. and M.S. contributed to study design, paper 
writing and funding of the project. G.M.P. conceived and designed the 
ML experiments, analyzed the data and wrote the paper.
Funding
Open access funding provided by Helmholtz Zentrum München - 
Deutsches Forschungszentrum für Gesundheit und Umwelt (GmbH).
Competing interests
The authors declare no competing interests.
Additional information
Supplementary information The online version contains supplementary 
material available at https://doi.org/10.1038/s43588-024-00627-2.
Correspondence and requests for materials should be addressed to 
Grzegorz M. Popowicz.
Peer review information Nature Computational Science thanks 
Martin Zacharias and the other, anonymous, reviewer(s) for their 
contributions to the peer review of this work. Primary Handling Editor: 
Kaitlin McCardle, in collaboration with the Nature Computational 
Science team. Peer reviewer reports are available.
Reprints and permissions information is available at  
www.nature.com/reprints.
Publisher’s note Springer Nature remains neutral with regard to 
jurisdictional claims in published maps and institutional affiliations.
Open Access This article is licensed under a Creative Commons 
Attribution 4.0 International License, which permits use, sharing, 
adaptation, distribution and reproduction in any medium or format, 
as long as you give appropriate credit to the original author(s) and the 
source, provide a link to the Creative Commons licence, and indicate 
if changes were made. The images or other third party material in this 
article are included in the article’s Creative Commons licence, unless 
indicated otherwise in a credit line to the material. If material is not 
included in the article’s Creative Commons licence and your intended 
use is not permitted by statutory regulation or exceeds the permitted 
use, you will need to obtain permission directly from the copyright 
holder. To view a copy of this licence, visit http://creativecommons.
org/licenses/by/4.0/.
© The Author(s) 2024


---

# Model-informed drug discovery and development approaches to inform clinical trial design and regulatory decisions: A primer for the MENA region

- **Authors:** Mohammed S Alasmari, Salwa Albusaysi, Marwa Elhefnawy, Ali M Ali, Khalid Altigani, Mohammed Almoslem, Mohammed Alharbi, Jahad Alghamdi, Abdullah Alsultan
- **Issuer:** Saudi pharmaceutical journal : SPJ : the official publication of the Saudi Pharmaceutical Society
- **Type:** Scientific article
- **Published:** 2024-11-27
- **Language:** en
- **DOI:** 10.1016/j.jsps.2024.102207
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39697476/
- **Licence:** CC-BY

## Section: Abstract

AbstractModel-Informed Drug Discovery and Development (MID3) represents a transformative approach in pharmaceutical research, integrating quantitative models to inform and optimize decision-making throughout the drug development process. This review explores the current applications, challenges, and future prospects of MID3 within the Middle East and North Africa (MENA) region. By leveraging local data and advanced computational techniques, MID3 has the potential to significantly enhance the efficiency and success rates of drug development tailored to regional health priorities. We discussed successful case studies of applying MID3 at different phases of drug development and clinical trials. Furthermore, we emphasized the critical need for MENA countries to embrace MID3 by investing in workforce training, aligning regulatory frameworks, and fostering collaborative research initiatives. This call to action underscores the importance of a robust MID3 ecosystem, urging policymakers, academic institutions, and industry stakeholders to prioritize and support its integration into the MENA region’s healthcare.Keywords: Drug development, PK/PD, PBPK, MENA region, Clinical trials, Pharmacometrics, Quantitative pharmacology, Population pharmacokinetics

## Section: Introduction

Model-Informed Drug Discovery and Development (MID3) is a comprehensive approach that integrates quantitative models to inform decision-making throughout the drug development process (Marshall et al., 2019, 2016). The MID3 concept focuses on the development and application of mathematical models of biological, physiological, pathological, and pharmacological processes based on preclinical and clinical data, aiming to improve the quality, efficiency, and cost-effectiveness of drug development process. The MID3 is the most recent term evolved from earlier terms including Model-Informed Drug Development (MIDD), Model-Based Drug Development (MBDD), Pharmacometrics (PMx), System Pharmacology (SP), and Modeling and Simulation (M&S) (Marshall et al., 2016). In the past two decades, the utilization of MID3 approaches has increased to support regulatory and clinical decision making (Alsultan et al., 2020, Huang et al., 2013, Lavé et al., 2016, Lee et al., 2011, Milligan et al., 2013, Rowland et al., 2011, Tuntland et al., 2014, Wang et al., 2019). The increased interest by regulatory agencies and pharmaceutical companies is mainly due to the high rates of attritions in clinical development (Sun et al., 2022). One of the main reasons for this higher attrition is safety concerns and the inability to demonstrate efficacy during clinical drug development (Lee et al., 2011). MID3 approaches (e.g., population pharmacokinetics/pharmacodynamic, physiologically-based pharmacokinetics (PBPK), quantitative system pharmacology (QSP), exposure–response relationship, model based meta-analysis (MBMA), clinical trial simulation (CTS), disease progression models, drug-trial-disease model) can help with optimizing clinical trial design and drug dosing and supporting safety and efficacy to reduce drugs attrition (Kimko and Pinheiro, 2015, Madabushi et al., 2022, Wang et al., 2019).

As part of the strong interest in this field, several regulatory agencies have published guidelines on using modeling and simulation tools during drug development. The first guide was published by the US Food and Drug Administration (FDA) in 1999 for population pharmacokinetics studies, this was followed by European Medical Agency (EMA) guideline on population pharmacokinetics in 2007, and FDA guide for PBPK in 2007 (Table 1). In Australia, regulatory agencies started discussing the role of PK/PD modeling and simulation in 1997 (Hennig et al., 2019). Over the past 10 years, several other regulatory agencies started emphasizing the role of quantitative methods in drug development such as China, Japan and South Korea (Lee and Jeon, 2019, Li et al., 2019, Sato et al., 2017). Currently, nearly all new submissions for new drug applications (NDA) contains information related to mathematical modeling and simulation.

While several developed countries have made significant strides in incorporating modeling and simulation into their research on drug discovery and development, the Middle East and North Africa (MENA) region still has substantial room for growth in this area. Increasing the application of MID3 approaches in the MENA region is crucial for improving the efficiency of drug development which can lead to faster and more effective production of new drugs into markets. These quantitative methods are also essential for addressing health challenges unique to the region by enabling more precise and tailored treatments. Moreover, they can stimulate local pharmaceutical innovation, drive economic growth, and enhance the region’s competitiveness in the global market. This is important, as MENA population’s representation in clinical trials is low even compared to emerging markets (Ibrahim et al., 2020, Nair et al., 2013). Therefore, it is important to highlight and raise awareness of MID3 concepts in MENA region. The objective of this paper is to provide a summary on quantitative methods used in drug development to enhance the MENA pharmaceutical sector, thereby improving drug development efficiency, addressing regional health challenges more effectively, and fostering local innovation.

FDA and EMA guidelines for modeling and simulation.

## Section: Historical background

The foundations of PK/PD modeling were laid in the early 20th century with the work of scientists A.J. Clark, who developed mathematical models to describe the effects of drugs (B., 1933). The concepts of concentration-effect relationships and the importance of the time course of drug concentration and the field of PK/PD modeling grew significantly during the 1960 s (Csajka and Verotta, 2006). Scientists Lewis Sheiner and Stuart Beal were instrumental in formalizing the principles of PK/PD modeling (Sheiner, 1997, Sheiner and Beal, 1980). With the advent of more powerful computers and software, the 1980 s and 1990 s saw a surge in the use of PK/PD models in drug development. Initially it started with the use of population PK/PD modeling (also known as nonlinear mixed-effects modeling) (Keizer et al., 2013). Later, in the 2000 s, there was a reemergence of PBPK models. Although the concept of PBPK modeling is old and dates back to the work of Teorell in 1937 (Paalzow, 1995, T., T., , 1937), it wasn't until the 1960 s that the first PBPK models, which considered the body as a series of interconnected compartments representing organs and tissues, began to be developed. These models became increasingly sophisticated, incorporating more complex descriptions of physiological processes and drug interactions with the body. Today, population PK/PD and PBPK modeling are the most commonly used modeling tools during drug development (Madabushi et al., 2022, Marshall et al., 2019, Wang et al., 2019). They are used to predict human pharmacokinetics from preclinical data, optimize dosing regimens, and support personalized medicine approaches. The integration of these models into the drug development pipeline has the potential to reduce the time and cost associated with bringing new therapeutics to market, while also improving their safety and efficacy profiles.

## Section: Regulatory perspectives of MID3 applications

Regulatory agencies, including FDA and EMA, require evidence that drugs are safe and effective in the population for which they are intended. Various MID3 approaches have been recognized by regulatory agencies as decision tools to support efficacy and safety of drugs. Modeling approaches, such as population PK/PD and PBPK are often mandated as part of the drug approval process for special populations (Jones et al., 2015, Shepard et al., 2015, Wagner et al., 2015). Starting in the 1990 s and continuing into the 21st century, FDA and EMA have issued guidelines that outline how modeling and simulation can be used to support drug approval processes (Table 1). This has led to an increased use of modeling and simulation in various, if not all, stages of drug development, from preclinical studies to clinical trial design and post-marketing surveillance. Jamei M (2016) compiled a list of approved drugs in which modeling and simulation played a role in informing their labels (Jamei, 2016). Also, several papers have been published summarizing the impact of modeling and simulation on drug approvals and labeling decisions by the FDA, these are summarized in Table 2 (Lee et al., 2011, Ogasawara and Alexander, 2019, Zhang et al., 2020).

For regulatory agencies in the MENA region, the Saudi Food & Drug Authority (SFDA) recently started incorporating MIDD in its evaluation process. This increased adoption of MIDD approaches by applicants submitting to the SFDA reflects the growing recognition of the value that these techniques can bring to the drug development and regulatory decision-making processes. Applications of MIDD include that for new drug applications, applications for adding new indications or extending indications to special populations. This trend is also observed in clinical trial applications, where applicants have applied MIDD to guide the advancement of their clinical development. The types of models encountered by the SFDA include population pharmacokinetics (PPK), mechanistic models such as physiologically-based pharmacokinetics (PBPK), and exposure–response (ER) relationships. The SFDA's evaluation approach for these models typically involves a matrix-based assessment, which aims to identify and manage the risks associated with using such computational models, whether as a replacement for clinical trials, for guiding dose selection, or for other purposes. The SFDA's experience in evaluating these modeling and simulation applications showcases its commitment to staying at the forefront of this evolving field and ensuring the appropriate use of MIDD to support regulatory decisions.

The international council for harmonization of technical requirements for pharmaceuticals for human use (ICH) endorsed the concept paper for general principles related to MIDD in November 2022 (The International Council for Harmonisation, 2022). This recognized that despite the increase in regulatory submissions and industry-regulatory interactions using evidence generated by MIDD, there is an absence of harmonized documentation standards and assessment expectations. The aim of the guideline is to harmonize expectations regarding planning, model evaluation, and documentation of evidence derived from MIDD. A key aspect is also to create a common understanding across scientists, both between and within industry and regulatory bodies. A draft of this guideline will be published for public comments in line with the anticipated 3-year timeline of this project.

Summary of studies assessing the impact of modeling and simulation on drug approvals and labeling by the FDA.

## Section: Various MID3 approaches used in drug discovery and development

In drug discovery and development, a variety of modeling approaches are utilized to enhance the understanding and prediction of drug kinetic and dynamic behaviors. Key approaches include population pharmacokinetics/pharmacodynamic modeling which is empirical in nature, and PBPK/QSP which is mechanistic in nature (Marshall et al., 2016). The empirical model starts from data collection and taking all available pharmacokinetic information such as plasma concentration, dosing information and the time of dosing and sample collections, which is called “top-down”, while the mechanistic model starts from what is understood at the organ, or tissue level such as hepatocytes, human liver microsomes and recombinant CYP450 enzymes, which is called “bottom-up” (Fig. 1). The most widely used empirical approach method is the population pharmacokinetics/pharmacodynamic approach which is known as nonlinear mixed effect model (NLME). On other hand, the most widely used mechanistic modelling method is PBPK/QSP (Aarons, 2005, Marshall et al., 2016).

Population pharmacokinetics is a branch of pharmacokinetics that studies the variability in drug concentrations within a patient population (Ette et al., 2004, Ette and Williams, 2004a, Ette and Williams, 2004b, Vozeh et al., 1996). This approach models how drugs are absorbed, distributed, metabolized, and excreted, accounting for diverse factors that influence these processes, such as age, weight, gender, genetic factors, disease states, and concomitant medications. The key objectives of population pharmacokinetics are to quantify the typical pharmacokinetic parameters (e.g., clearance, volume of distribution) and their variability within a population, identify and understand covariates that explain the variability in drug response, and to predict drug concentrations in patients to optimize dosing regimens (Ette et al., 2004). Population pharmacokinetics employs statistical and mathematical modeling techniques to analyze data from clinical trials and real-world settings. NLME models commonly used to describe the central tendency (fixed effects) and the variability (random effects) of pharmacokinetic parameters in populations (Bauer, 2019a, Bauer, 2019b). Population pharmacokinetics is applicable in individualizing drug therapy, supporting drug development, guiding dose selection, optimizing clinical trial designs, and informing regulatory decisions and labeling by providing comprehensive pharmacokinetic insights across different subpopulations (Ette et al., 2004). Overall, population pharmacokinetics enhances our understanding of drug behavior in diverse populations, contributing to safer and more effective therapeutic interventions.

In population PK/PD modeling, pharmacokinetic behavior of drug (PK) is combined with the drug's biological effects (PD) to optimize therapeutic strategies and ensure safety and efficacy (Derendorf and Meibohm, 1999). PK/PD modeling examines the relationship between drug concentration and its therapeutic or toxic effects (known as exposure–response relationship), providing insights into the drug's efficacy and safety profile at different doses. PK/PD modeling aids in determining the optimal dosing regimen by balancing efficacy and safety, thus reducing the time and cost associated with trial-and-error approaches in clinical trials.

PBPK models integrate physiological, biochemical, and drug-specific data to simulate how drugs are absorbed, distributed, metabolized, and excreted in various populations, especially those underrepresented in clinical trials (e.g., pediatrics, elderly, renal/hepatic impairment) (Zhao et al., 2011). PBPK models can predict drug concentrations and pharmacokinetics in specific populations where clinical data is lacking, such as pediatrics, pregnant, geriatrics, and population with organs dysfunction (Lin et al., 2022). Moreover, PBPK modeling is valuable for predicting drug interactions, especially those mediated by cytochrome P450 enzymes. PBPK models help in determining necessary dose adjustments without requiring additional clinical studies, thus optimizing safety and efficacy. This capability can expedite drug development and broaden drug indications by reducing the need for extensive clinical trials in these groups. There has been a growing acceptance and use of PBPK models in regulatory submissions (Wu et al., 2023, Zhao et al., 2011). This trend is supported by regulatory guidance and ongoing collaboration between industry, academia, and regulatory agencies, aiming to improve the standardization and reliability of these models.

In contrast to empirical approach for exposure response relationship using population PK/PD modeling, QSP represents the mechanistic approach for exposure response relationship. QSP considered as a framework for understanding the complex interactions between drugs and biological systems, such in cascade biomarkers interactions, and it is a more comprehensive and predictive method for drug development (Androulakis, 2016). QSP model integrates mathematical modeling, experimental data, and systems biology to simulate the effects of drugs on biological systems at multiple scales. The key components of a QSP model, including drug pharmacokinetics, target engagement, and downstream effects, and emphasizes the importance of incorporating biological context into drug development. It is very important to integrate quantitative data from multiple sources, such as in vitro and in vivo experiments, to build a comprehensive model of drug action.

Comparison of top-down and bottom-up modeling approaches. The figure illustrates the key differences between the top-down approach which relies on empirical data from clinical studies to describe drug behavior in populations, and the bottom-up approach, which uses mechanistic models, such as PBPK, to predict pharmacokinetic based on physiological and biochemical properties. Together, these approaches offer complementary insights into drug dosing and response.

## Section: Software and tools supporting the MID3

A variety of software and tools are available to facilitate PK and PD analyses, each with its own strengths and applications. For population PK/PD modeling, NONMEM (Nonlinear Mixed Effects Modeling) is a gold-standard software widely used in the industry for its robust data analysis capabilities (Keizer et al., 2013, Nguyen et al., 2017). It was developed by Stuart Beal and Lewis Sheiner in the 1970 s (Keizer et al., 2013, Sheiner and Beal, 1980). Currently it is developed under ICON (https://www.iconplc.com). Another software in the 1970 s was NPEM (non-parametric expectation maximization algorithm) led by Dr. Roger Jelliffe and his team at the University of South California (Jelliffe et al., 2000). Currently, the NPEM software has been updated as an R package named “Pmetrics” (Neely et al., 2012). Both software’s were originally developed with the purpose of using them for drug dosing at the bedside(Keizer et al., 2018). During the 80’s, several other software’s were developed such as ADAPT and PopKinetics (Csajka and Verotta, 2006). In the decades that followed the release of these software’s, the field of population PK/PD modeling and simulation advanced and became an integral part of drug development (Csajka and Verotta, 2006, Holford, 1990, Keizer et al., 2018, Sheiner, 1969). Other software’s developed later include Monolix, PumasAI and Phoenix NLME. Monolix is part of the MonolixSuite and is designed for advanced pharmacometrics analysis (Lavielle and Mentré, 2007, Nguyen et al., 2017, Traynard et al., 2020). Developed by Lixoft, it offers a robust and user-friendly environment for model-based drug development, employing powerful algorithms for population PK/PD modeling. Monolix facilitates the handling of complex datasets and supports a wide range of statistical models, enabling investigators to perform NLME modeling with greater efficiency and precision. With its intuitive graphical user interface and extensive visualization tools, Monolix streamlines the model building and validation process, making it an indispensable tool in the pharmaceutical industry for optimizing dosing regimens, supporting regulatory submissions, and ultimately enhancing patient care. Additionally, Phoenix is a comprehensive software suite for advanced PK/PD modeling and simulation developed by Certara (Nguyen et al., 2017). It is designed to support the entire drug development process, from preclinical to clinical stages. Phoenix includes a range of tools, such as WinNonlin for non-compartmental analysis, NLME (Nonlinear Mixed Effects) for population modeling, and IVIVC (In Vitro-In Vivo Correlation) for establishing relationships between in vitro drug release and in vivo absorption. The platform is known for its scalability, flexibility, and integration with other software tools, making it a versatile choice for researchers and modelers in the pharmaceutical industry. Moreover, Pharmaceutical Modeling and Simulation (Pumas), which is developed by PumasAI, is a comprehensive platform for pharmaceutical modeling and simulation, providing a single tool for the entire drug development pipeline (Rackauckas et al., 2022). It is used for simulation and estimation of quantitative pre-clinical and clinical pharmacological models. It leverages the power of the Julia programming language to combine modern AI with traditional mechanistic models to gain massive computational efficiency.

When it comes to PBPK modeling, Gastroplus, PK-Sim, and Simcyp Simulators stand out as leading platforms, incorporating population-based demographics to predict pharmacokinetic outcomes in virtual patient populations(Agoram et al., 2001, Ezuruike et al., 2022, Romero et al., 2020, Silva et al., 2022, Willmann et al., 2003). These tools are particularly valued for their flexibility and community-driven development. Other noteworthy tools include MATLAB with its SimBiology toolbox, which allows for a more programming-oriented approach for modeling and simulation(Hosseini et al., 2020, Hosseini et al., 2018, Park and Kim, 2019, Vasić et al., 2024). Each of these software solutions offers a unique set of features, and the choice of tool often depends on the specific requirements of the modeling task at hand, including the complexity of the model, the nature of the data, regulatory considerations, and the user's familiarity with the software.

## Section: Examples of MID3 applications to inform decision-making

MID3 applications span various stages, including target identification and validation, where computational models provide insights into disease mechanisms and potential drug targets, and predictive modeling forecasts the efficacy and safety of targeting specific pathways (Marshall et al., 2016). In Fig. 2, we summarized the applications of modeling and simulation across various stages of drug discovery and development.

During lead optimization, MID3 guides the selection of compounds with optimal PK and PD profiles and aids in understanding dose–response relationships to select promising candidates (Marshall et al., 2016). In preclinical development, translational modeling predicts human responses based on animal data, while safety assessment models identify potential toxicity concerns. MID3 supports clinical trial design and execution through adaptive trials and optimal sample size determination, enhancing trial efficiency and reliability (Marshall et al., 2016). It facilitates regulatory interactions by providing robust modeling data for submissions and meeting regulatory requirements. Dose optimization and individualization are achieved by tailoring regimens based on patient characteristics and special populations, such as pediatrics and geriatrics (Marshall et al., 2016). In post-marketing, MID3 supports ongoing monitoring of drug safety and effectiveness through post-marketing surveillance models and continuous benefit-risk assessment. In Fig. 3, we highlighted some types of modeling and simulations that are used in drug discovery and development.

Overall, MID3 enhances the prediction of outcomes, optimizes trial designs, and informs strategic decisions, leading to more efficient and effective development of new therapies. In the following sections, we provided some examples of the applications of MID3 techniques.

General applications of modeling and simulation in drug discovery and development.

Types of modeling and simulation in different stages of the drug discovery and development processes. Preclinical modeling includes using of in vitro and in vivo studies and simulations to provide insights into drug behavior, efficacy, and safety prior to human trials. PK/PD modeling evaluates the relationship of PK data to PD effect (response). Toxicology modeling is used to predict toxicity, assess risk, and understand the mechanism of adverse effects based on exposure to chemical (e.g., dose–response model). Trial simulation helps in optimizing study design, dose, selection, and evaluating potential scenarios before actual trials are conducted. Early clinical modeling integrates preclinical and early-phase clinical trial results to predict drug behavior, help in dose selection, and the design of later-stage clinical trials. Dose-ranging studies modeling allows for exploring the relationship between different drug doses and their PK and PD effects to identify the optimal dose that maximizes efficacy while minimize toxicity. Late clinical modeling allows for integrating data from advanced clinical trials (phase III) to refine dose–response relationships, predict long term efficacy and, support regulatory decision making. Population PK/PD modeling analyzes drug concentration and response across diverse patient populations, accounting for variability in drug exposure and effects which help to identify factors influencing drug behavior, optimize dosing, and improve therapeutic outcomes for different subgroups. Model-based meta-analysis integrates data from multiple studies, allowing for comparison of drug efficacy and safety across studies which help to inform dose selection, predict clinical outcomes, and guide decision-making in drug development.

## Section: Examples of MID3 applications to inform decision-making › Determining the FIH dose for transferring from preclinical to clinical phases

Estimation of the first-in-human (FIH) dose is of critical importance to earlier phases clinical trials (Zou et al., 2012). A well-established starting dose helps minimize the risk of adverse effects, ensures the well-being of study participants, facilitates the design of later-phase trials, helps allocate resources more effectively, and ultimately enables for a more efficient and streamlined development process. Methods for determining the FIH dose involve a combination of preclinical data, pharmacokinetic modeling, and safety considerations, and the most common approaches include allometric scaling, PK/PD, and PBPK(Jones et al., 2019, Jones et al., 2009, Miller et al., 2019). The primary objective of FIH trials is to identify a safe dose range for further investigation in drug development. The FDA and EMA guideline for the first in human dose provided recommendations for determining the initial dose of a new drug when it is first tested in humans (Table 1) (Shen et al., 2019). These guidelines emphasized the importance of conducting thorough preclinical studies to assess the safety and pharmacology of the drug before it is administered to humans. The initial dose should be carefully calculated based on factors such as the pharmacokinetics, pharmacodynamics, and toxicology of the drug.

PBPK models are widely used in drug discovery and development for predicting first in human dose(Miller et al., 2019). The appropriate starting dose for human trials can be estimated using PBPK modeling by integrating preclinical in-vitro and in-vivo data, considering factors like body weight, metabolic rates, gene expression, and other species-specific differences(Jones and Rowland-Yeo, 2013, Thiel et al., 2015). The availability of pharmacokinetic data from animal studies can be incorporated into the established model for qualification and optimization of the model's parameters. After qualification, the model can be extrapolated to predict human pharmacokinetics, accounting for physiological, biochemical, and genetic interspecies-difference.

PBPK modeling and simulation plays a critical role in selecting preclinical drug candidates for future drug development and guides the recommendation for the selection of the FIH dose. For example, when the COVID-19 crisis revealed the importance of an accelerated drug development process, a PBPK model was developed to predict the FIH dose for a monoclonal antibody (mAb) bamlanivimab (Chigutsa et al., 2022, Jones et al., 2019). Pharmacokinetic parameters of the mAb were characterized successfully based on data from preclinical studies. In combination with a SARS-COV2 viral dynamic model, PBPK model of bamlanivimab was used to predict the initial therapeutic dose that maintain lung tissue concentrations at or above the in-vivo IC90 over period of 4 weeks. Ultimately, bamlanivimab was approved for used in patients with COVID-19 under emergency use authorization in November 2020.

## Section: Examples of MID3 applications to inform decision-making › Guiding drug dosing in phase II/III clinical trials

During drug development, one of the main concerns is determining the appropriate dose for phase III or even phase II, in order to meet the pre-specified requirements for safety and efficacy endpoints. Population pharmacokinetics is an essential methodology for predicting PK characteristics and is critically required for drug approval. It offers several advantages over dose-titration studies in dose prediction, as it considers both between- and within-individual variability, as well as demographic characteristics and clinical disease states, including patients with renal/hepatic impairment (Lavé et al., 2016). Several studies have implemented modelling to guide dose selection for clinical trials(Landry et al., 2016, Wang et al., 2013). The robustness of the population pharmacokinetics model provides a solid evidence base for dose recommendations in later phases of drug development (i.e., phase II and phase III), utilizing drug exposure data from the previous phase (phase I) and expected clinical response.

Population pharmacokinetics analysis provides exposure information that is used as input for the exposure response relationship. By combining the estimated exposure (derived from the PK model) and the response (derived from the PD model), exposure response relationship can be predicted. This can then be used to guide dose selection for phase II/III trials using Monte Carlo simulation of varying dose regimens.

The rationale behind using both PK and PD to guide dose selection is that, in order to achieve the desired pre-specified safety and efficacy margins, one must first identify the target effect and use a PD model to predict the target concentration necessary to achieve the desired effect, and then use a PK model to predict the optimal dose required to achieve the target concentration. This approach considers variability in the PK-PD target and effect site exposures in dose prediction (Chien et al., 2005, Derendorf and Meibohm, 1999). Incorporating clinical data allows for the prediction and confirmation of responses in patient subgroups that may be at increased risk for adverse events or decreased efficacy.

## Section: Examples of MID3 applications to inform decision-making › Informing drug label for special populations

In the context of clinical pharmacology, the term “special population” refers to specific groups of individuals who may have unique characteristics or factors that can affect their response to medications (Grimsrud et al., 2015). This can include groups such as pediatrics, elderly individuals, pregnant women, obese, individuals with certain medical conditions such as renal and hepatic impairment, or those taking multiple medications (Marshall et al., 2016). These patients have unique physiological characteristics and drug response profiles compared to adult healthy populations, making it challenging to determine the appropriate dosing and safety profiles for these populations(Anderson and Holford, 2013, Costantine, 2014, Verbeeck, 2008, Verbeeck and Musuamba, 2009). Population PK/PD, as well as PBPK modeling, play crucial roles in drug development in these population where physiological differences from healthy adults significantly affect how drugs are absorbed, distributed, metabolized, and excreted(Han et al., 2021, Heimbach et al., 2021, Malik et al., 2020, Vinks et al., 2015). They help to tailor drug therapy to the unique physiological needs, ensuring that medications are used safely and effectively in these vulnerable populations. These tools also facilitate the rational design of clinical trials and support regulatory decision-making, ultimately improving access to therapeutics.

As examples, we report some of MIDD applications for special populations in relation to anticoagulants. A population pharmacokinetic model for a low molecular weight heparin (dalteparin) was constructed based on a clinical study involving 98 children to recommend starting doses for different pediatric groups (Damle et al., 2021). The clinical observations were best described by two-compartment model using NONMEM software. The analysis suggested that the starting doses of dalteparin administered subcutaneously for pediatrics ages 1 month to 2 years, 2 years to 8 years, and 8 years to 19 years should be 150 IU/kg twice daily, 125 IU/kg twice daily, and 100 IU/kg twice daily, respectively. Results from this study contributed to the approval of dalteparin by the FDA for venous thromboembolism in different pediatrics groups. Terrier et al (2022) reported several population pharmacokinetic models used for dosing optimization of anticoagulants(Terrier et al., 2022). Similarly, PBPK models are widely used and accepted in individualizing drug dosing in special populations. For instance, PBPK models for apixaban and rivaroxaban were constructed to guide dosage regimen in pediatrics, geriatrics, patient taking multiple drugs, and in patients with various degree of renal and hepatic dysfunction(Wen et al., 2022, Willmann et al., 2021, Xu et al., 2021, Xu et al., 2024). The models were able to accurately predict the PK of the drugs when taken alone and when taken concomitantly with other drugs. In patients with varying degrees of kidney and liver impairment, the PBPK models correctly estimated the increase in drug exposure for each class. For pediatrics, PBPK modeling and simulation found that the influence of renal impairment on drug exposure might be greater in infant less than one year compared to older children (Xu et al., 2021).

## Section: Examples of MID3 applications to inform decision-making › Supporting drug development in rare diseases

The term “rare disease” is often defined differently depending on the context and the legislation of different countries. In the context of the United States, the Orphan Drug Act of 1983 is a key piece of legislation that provides a definition for rare diseases and conditions, primarily for the purpose of encouraging the development and commercialization of drugs for the treatment of these diseases. According to the Orphan Drug Act, a rare disease or condition is one that affects fewer than 200,000 people in the United States(Aronson, 2006, Wellman-Labadie and Zhou, 2010). The Act provides incentives for pharmaceutical companies to develop treatments for rare diseases, which are often referred to as “orphan drugs” because without these incentives, the small market would not typically justify the investment required for drug development. Drug development for rare diseases faces several challenges, including lack of knowledge on the natural disease progression, disease heterogeneity, and the small number of eligible patients for randomized controlled trials.

As an example of the successful application of the MID3 to support development of drugs for rare diseases, population pharmacokinetic simulations were performed to predict adalimumab exposure in adolescent hidradenitis suppurativa patients without additional clinical PK data(Bi et al., 2019). Based on these simulations, dosing based solely on body weight resulted in inadequate drug exposure, and the study recommended a weight-tiered dosing regimen for adolescent HS patients to achieve similar drug exposure as adult hidradenitis suppurativa patients across the weight range. Consequently, based on these findings, FDA recommended a weight-tiered dosing regimen for adalimumab in adolescent hidradenitis suppurativa patients.

Furthermore, optimizing the selection of patients in clinical trials is critical to effectively obtain the necessary information on drug safety and efficacy. Disease progression models can serve as a valuable tool to guide patient selection strategies. This is demonstrated in the case of childhood-onset dystrophinopathy(Haber et al., 2021). Disease progression modelling was used to predict the impact of genetic variant and loss of ambulation(Li et al., 2022). The model predicted that subjects with specific genetic variants had a lower risk of loss of ambulation. These results suggest that genotyping may help guide patient selection in clinical trials. These studies highlighted the importance of MID3 in accelerating drug development, particularly in the treatment of rare diseases.

## Section: MID3 considerations for MENA region

The MENA region faces a unique set of health challenges, specific to populations demographics, genetic background, and health and socioeconomic status (Akala and El-Saharty, 2006, Alsultan et al., 2023, Katoue et al., 2022, Nair et al., 2013, Wakil et al., 2015). Developing drugs tailored to these needs can significantly improve public health outcomes. Investing in drug development can boost the pharmaceutical sector, creating jobs, fostering innovation, and contributing to economic diversification. Local drug development can reduce reliance on imported medications, ensuring more stable and affordable access to essential medicines. This is crucial during global supply chain disruptions, such as those seen during the COVID-19 pandemic (Ibrahim et al., 2020). Strengthening drug development capabilities promotes scientific research and innovation. It also helps build local expertise and infrastructure, making the region a hub for pharmaceutical research. Adopting MID3 approach in the MENA region could significantly enhance the efficiency and effectiveness of the pharmaceutical development process. MID3 can help develop personalized treatment plans based on genetic, demographic, and disease-specific data. This is particularly relevant in the MENA region, where the populations have certain genetic and physiological characteristics. Regulatory bodies can use MID3 to make more informed decisions regarding drug approvals, ensuring that new medications are both effective and safe for the MENA populations. MID3 allows for better allocation of resources by identifying promising drug candidates early and discontinuing those with low potential. This optimizes the use of financial and human resources in drug development projects.

It is very important to create a virtual population specific to MENA ethnicity for PBPK modeling to simulate PK profile more precisely. To develop a virtual human individual representing a MENA population in a PBPK platform, comprehensive demographic, physiological, biochemical, and clinical data are essential. Demographic information should include mean body weight, height, and BMI distribution. Physiological data must cover organ sizes, blood flow rates, and tissue compositions. Biochemical data should encompass data such as enzyme activity levels. Additionally, clinical data from studies conducted on the MENA populations, including PK profiles and PD, are necessary. In Table 3, we highlighted some key factors in order to successfully implement the MID3 approaches specific for MENA region.

Key factors to implement MID3 in the MENA region.

## Section: Educational resources

Barrett et al (2008) advocated for structured education and training programs to equip scientists with the necessary skills to excel in the pharmacometrics field(Barrett et al., 2008). They listed academic sites/universities offering curriculum related to pharmacometrics and some centers and web sites providing training programs. They also highlighted multidisciplinary nature of the pharmacometrics requiring expertise in biology, pharmacology and quantitative sciences. Schmidt et al (2023) discussed the comprehensive framework needed to effectively train future pharmacometricians (Schmidt et al., 2023). They outlined several key requirements for training programs, emphasizing the need for a strong foundation in quantitative and system pharmacology and the integration of advanced computational tools. Additionally, there is a call for more collaborative efforts between academia, industry, and regulatory bodies to enhance training quality and relevance. They also advocated for the development of global training networks to facilitate knowledge exchange and foster a diverse and inclusive workforce in pharmacometrics. Expectations for trainees include proficiency in MID3 and continuous professional development to keep pace with the rapidly evolving field.

Moreover, ACCP journal published a collection of educational papers on PBPK modeling and simulation which can be very helpful resources (Chaudhury et al., 2020, Franchetti and Nolin, 2020, Li et al., 2020, Malik et al., 2020, Rostami-Hodjegan and Toon, 2020, Samineni et al., 2020, Sharma et al., 2020). On the other hand, tutorials for using NONMEM for population PK/PD modeling and simulation have been published in more details(Bauer, 2019a, Bauer, 2019b, Bauer et al., 2021, Keizer et al., 2013). We have listed some additional helpful educational resources in Table 4.

Some educational resources for MID3.

## Section: Conclusion

The integration of MID3 presents a unique and significant opportunity for the MENA region to advance its pharmaceutical research and healthcare outcomes. This review highlights the transformative potential of MID3 to address regional health challenges through the use of sophisticated quantitative models such as population PK/PD and PBPK modeling. To fully realize the potential of MID3, it is imperative for MENA countries to invest in developing a skilled workforce adept at utilizing these advanced methodologies. Harmonizing regulatory frameworks to support model-based approaches and fostering collaborative research environments are also critical steps. By prioritizing the integration of MID3, MENA nations can not only enhance their own healthcare systems but also contribute to global advancements in pharmaceutical research. In conclusion, the adoption of MID3 in the MENA is not just an opportunity but a necessity. Policymakers, academic institutions, and industry stakeholders must work together to create a supportive ecosystem that encourages innovation and collaboration.

## Section: CRediT authorship contribution statement

Mohammed S. Alasmari: Writing – review & editing, Writing – original draft, Conceptualization. Salwa Albusaysi: Writing – review & editing, Writing – original draft, Conceptualization. Marwa Elhefnawy: Writing – review & editing, Writing – original draft, Conceptualization. Ali M. Ali: Writing – review & editing, Writing – original draft, Conceptualization. Khalid Altigani: Writing – review & editing, Writing – original draft. Mohammed Almoslem: Writing – review & editing, Writing – original draft. Mohammed Alharbi: Writing – review & editing, Writing – original draft. Jahad Alghamdi: Writing – review & editing, Writing – original draft, Conceptualization. Abdullah Alsultan: Writing – review & editing, Writing – original draft, Conceptualization.

## Section: Declaration of Competing Interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.


---

# MolScore: a scoring, evaluation and benchmarking framework for generative models in de novo drug design

- **Authors:** Morgan Thomas, Noel M O'Boyle, Andreas Bender, Chris De Graaf
- **Issuer:** Journal of cheminformatics
- **Type:** Scientific article
- **Published:** 2024-05-30
- **Language:** en
- **DOI:** 10.1186/s13321-024-00861-w
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38816825/
- **Licence:** CC-BY

## Section: Abstract

Generative models are undergoing rapid research and application to de novo drug design. To facilitate their application and evaluation, we present MolScore. MolScore already contains many drug-design-relevant scoring functions commonly used in benchmarks such as, molecular similarity, molecular docking, predictive models, synthesizability, and more. In addition, providing performance metrics to evaluate generative model performance based on the chemistry generated. With this unification of functionality, MolScore re-implements commonly used benchmarks in the field (such as GuacaMol, MOSES, and MolOpt). Moreover, new benchmarks can be created trivially. We demonstrate this by testing a chemical language model with reinforcement learning on three new tasks of increasing complexity related to the design of 5-HT2a ligands that utilise either molecular descriptors, 266 pre-trained QSAR models, or dual molecular docking. Lastly, MolScore can be integrated into an existing Python script with just three lines of code. This framework is a step towards unifying generative model application and evaluation as applied to drug design for both practitioners and researchers. The framework can be found on GitHub and downloaded directly from the Python Package Index. Scientific Contribution MolScore is an open-source platform to facilitate generative molecular design and evaluation thereof for application in drug design. This platform takes important steps towards unifying existing benchmarks, providing a platform to share new benchmarks, and improves customisation, flexibility and usability for practitioners over existing solutions.Graphical Abstract Supplementary InformationThe online version contains supplementary material available at 10.1186/s13321-024-00861-w.

## Section: Introduction

The influx of modern, distribution-learning based generative models applied to de novo drug design [1, 2] is both exciting and frustrating. It is exciting in the sense that complex objectives can be optimised [3] and de novo designed molecules are beginning to be prospectively validated [4–6]. It is also frustrating in the sense that there is often a lack of consideration for the type of chemistry generated [7], many models are still applied to irrelevant objectives (such as rediscovery of a specific molecule [8] or penalised logP [9]), and scientific significance with respect to the novelty of proposed de novo designs is often overlooked [10]. However, due to the sheer number of approaches not all models can be prospectively validated. Therefore, simple, easy-to-implement objectives are preferred, and benchmarks are still needed to compare approaches. However, these should relate to the real-world challenges of drug discovery as much as possible [11].

We propose MolScore, which addresses these frustrations by providing a simple, flexible, and drug-design-relevant Python framework for generative models (as opposed to more generic workflows like Knime or PipelinePilot [12]). MolScore can be used to design multi-parameter objectives for use in real-world drug design and be coupled with a generative model of choice. Furthermore, it can be used to benchmark generative models by sharing standardised objectives. In addition, MolScore contains two graphical user interfaces (GUIs) to aid both writing configuration files and analysing generated de novo molecules.

## Section: Comparison to related works

Table 1 shows a high-level comparison of MolScore to existing software/benchmarking solutions. GuacaMol [8] was the seminal benchmark, which provided a standardised training dataset and a suite of 20 objectives for generative models to optimise. These tasks all measure the similarity to one or more reference compounds. However, the authors stated that the tasks did not adequately separate top-performing generative models (~ 15/20 tasks are easily solved by generative models). Furthermore, to create a custom task not included in the benchmark, modification of the code is required. More recently, Gao et al. introduced MolOpt [3], adapted this benchmark focusing on sample efficiency (i.e., how many molecules are required to optimise the objective), significantly extending the evaluation of generative models to 25 approaches. However, an appropriate evaluation of the type of chemistry generated was lacking [7]. Both GuacaMol and MolOpt are re-implemented in MolScore. Furthermore, new tasks can be defined and added to these benchmarks without requiring any coding.

The MOSES [13] benchmark introduced another standardised training set and comparison between generative models. Although this was not applicable to molecular optimisation and only aimed at distribution-learning (i.e., how representative de novo molecules are of the respective training molecules), this benchmark proposed a useful suite of performance metrics to evaluate de novo molecules, all of which are integrated into MolScore.

Docking benchmarks such as the smina-docking-benchmark [14] (against four protein targets), DOCKSTRING (against three targets) [15] and a docking benchmark in the Therapeutic Data Commons [16] (against one protein target) have also emerged. Considering that generative models can exploit non-holistic (i.e., the objective does not perfectly describe the desired chemical space) objectives [17, 18], caution should be used when using docking score alone to rank generative models, which can be particularly susceptible. As optimising docking score can lead to large and/or greasy molecules being generated which are not desirable in a medicinal chemistry context, as observed in the DOCKSTRING single docking task. Thus, this docking benchmark will rank highly generative models that are unregularised or can generate out-of-domain molecules, instead of those useful in practice, perhaps more so than other benchmarks. Moreover, none of the docking benchmarks conduct full ligand preparation which should consist of protonating molecules at a biologically relevant pH, enumerating unspecified stereoisomers and enumerating tautomers. MolScore contains functionality to conduct docking via interaction with a variety of docking software, but crucially also contains appropriate ligand preparation protocols that handle stereoisomer numeration, tautomer enumeration and protonation states.

There exists other software for objective design used in conjunction with generative models. REINVENT [19–22], implements a suite of configurable scoring functions for use with its generative model architecture. However, the package is integrated with only the REINVENT provided generative models and it is not trivial or obvious how to use functionality available interchangeably with other generative models for standardised comparison. This contrasts with MolScore which is designed to plug-and-play with different generative models. Another framework, the Therapeutic Data Commons (TDC) platform [16], reimplements the GuacaMol suite (with customizable reference molecules) and provides several additional capabilities such as docking, synthetic accessibility scores, molecular descriptors and pre-trained activity models. However, not all scoring functions are customizable and score transformation or aggregation for use in a multi-parameter setting must be manually coded. This introduces a problem with standardization and reproducibility across users. On the other hand, MolScore contains more scoring functions which are also more configurable, as well as an interface with 2337 activity models compared to the 3 available in TDC. Multi-parameter configuration is handled via the configuration file thereby standardising transformation and aggregation. It should be noted that MolScore is focussed on de novo design while the TDC has a much broader scope.

## Section: Implementation

MolScore is an open-source software written in Python 3, published under an MIT licence and distributed via GitHub and Python Package Index. It depends on several packages such as RDKit [23], PyTorch [24], Streamlit, as well as integrating published works in the field such as RAscore [25], AiZynthFinder [26] and ChemProp [27]. MolScore is split into two sub-packages: (1) molscore for scoring de novo molecules proposed by a generative model, and (2) moleval for post-hoc evaluation using a suite of evaluation metrics. The structure of the python package can be seen in Fig. 1. The following sections provide details of each sub-package.Fig. 1Design of the molscore and moleval sub-packages. The main elements of molscore include the manager.py module that interacts with a generative model and manages scoring of the molecules according to the objective. The gui folder contains the scripts to set write configuration files or monitor de novo molecules. The scoring_functions folder contains modules for individual scoring functions, the folder scaffold_memory contains code that defines the diversity filters [25], and the utils folder contains code for the transformation and aggregation functions. The main elements of the moleval package are the metrics.py module that computes evaluation metrics and the statistics_by_n.py script that computes the evaluation metrics to a molscore output file every n-steps or n-samplesTable 1Comparison between different software and benchmarks for de novo molecule generationFixed/configurable aOptimisation objectivesEvaluation metricsGenerative model agnosticbGraphical user interfaceGuacaMolFixed✔✔✔MOSESFixed✔✔MolOptFixed✔✔Smina-dockingFixed✔✔TDCFixed✔✔DOCKSTRINGFixed✔✔REINVENT (+ DockStream)Configurable✔✔MolScoreConfigurable✔✔✔✔aConfigurable without having to write code to design the objectivebEasily implementable for most generative models

Design of the molscore and moleval sub-packages. The main elements of molscore include the manager.py module that interacts with a generative model and manages scoring of the molecules according to the objective. The gui folder contains the scripts to set write configuration files or monitor de novo molecules. The scoring_functions folder contains modules for individual scoring functions, the folder scaffold_memory contains code that defines the diversity filters [25], and the utils folder contains code for the transformation and aggregation functions. The main elements of the moleval package are the metrics.py module that computes evaluation metrics and the statistics_by_n.py script that computes the evaluation metrics to a molscore output file every n-steps or n-samples

Comparison between different software and benchmarks for de novo molecule generation

Functionality available within the molscore sub-package

Evaluation metrics available in the moleval sub-package. No metrics require a license

## Section: Implementation › Molecule scoring

The sub-package, molscore, handles the scoring of de novo molecules. It is a collection of scoring functions, diversity filters, transformation functions and aggregation functions that can be used interchangeably, all managed by a python class MolScore found in the module manager.py (see Fig. 1). MolScore is initialised with a JSON configuration file that specifies exactly which functionality to use to score molecules. Once initialised, it takes as input a list of molecules (in SMILES representation) and returns a list of their respective scores as output, designed to be repeated in an iterative fashion (e.g., steps/epochs) over the course of a generative model optimisation run. During each iteration, there are several intermediate steps. First, molecules are parsed to check for validity (by parsing with RDKit), their SMILES are canonicalized and intra-batch uniqueness is checked. Inter-batch molecule uniqueness is then cross-referenced with previously generated molecules within the run and if the molecule was previously generated its previous score is reused. This can save valuable time if compute–intensive scoring functions are used and if a generative model is susceptible to generating the same molecules multiple times. User-specified scoring function (s) are run only for valid and unique molecules with invalid molecules being assigned scores of 0. Each score is transformed into a value between 0 and 1 by choosing a transformation function available. Then, these standardised scores are aggregated according to a chosen aggregation function available to result in a final desirability score between 0 and 1 that can represent multiple parameters/objectives. The final desirability score can be further modified in two ways. Optionally diversity filters can be applied to penalise the score of non-diverse molecules, or, any scoring function can be used as a ‘filter’ i.e., the transformed score returned from this function is used to multiply the desirability score. The final results are added to the run record. In addition, a CSV file is output for each iteration in the run, allowing a GUI to analyse intermediate results during the course of a run. Finally, when the run has concluded, a CSV file is written to the output directory with a full record of molecules generated and their scores.

A broad array of functionality is available to define an objective, as outlined in Table 2. The suite of scoring functions includes physicochemical descriptors, 2D and 3D molecular similarity to reference molecules, substructure matching, use of Scikit-Learn [28] models including bioactivity models on 2,337 ChEMBL31 [29] targets with PIDGINv5 [30], interfacing with eight docking software coupled with four ligand preparation protocols, and finally three synthetic accessibility measures.Table 2Functionality available within the molscore sub-packageLicense key requiredReferencesScoring functionsDescriptorsRDKit DescriptorsNo[23]Linker DescriptorsNo[32]Penalised logPNo[9]Maximum number of consecutive rotatable bondsNoSimilarityIsomer similarityNo[8]Fingerprint similarityNo[8]Molecular substructure matchNo[8, 19]Molecular substructure filtersNo[19]ROCSYes[33]Open 3D AlignNo[34]Applicability domainMaximum similarityNo[35]Feature rangeNo[35]Physchem rangeNo[35]Predictive modelsScikit-learn modelsNo[28]PIDGINv5No[30, 36]ChemPropNo[27]ADMET-AINo[37]DockingGlideYes[38]PLANTSYes[39]GOLDYes[40]OEDockYes[41]SminaNo[42]GninaNo[43]VinaNo[44]rDockNo[45]SynthesizabilitySA scoreNo[46]RA ScoreNo[25]AiZynthFinderNo[26]Reaction filtersNo[47]Scoring function utilitiesFingerprintsECFP (Morgan), Atom-pair, Topological-torsions, MACCS keys, RDKit, Avalon, Pharm2DNo[23]Similarity measureTanimoto, All bit, Asymmetric, Braun Blanquet, Cosine, McConnaughey, Dice, Kulczynski, Russel, On bit, Rogot Goldberg, SokalNo[23]Molecule preparation pipelinesGypsumDLNo[48]LigprepYes[49]EpikYes[50]MokaYes[51]Diversity filtersUniqueNoOccurrenceNoIdenticalMurckoScaffoldNo[52]IdenticalTopologicalScaffoldNo[52]CompoundSimilarityNo[52]ScaffoldSimilarityAtomPairNo[52]ScaffoldSimilarityECFPNoTransformation functionsNormaliseNoLinear thresholdNo[8]Gaussian thresholdNo[8]Step thresholdNoAggregation functionsWeighted sumNoAuto-weighted sumNo[53]ProductNoWeighted ProductNoAuto-weighted productNo[53]Geometric MeanNoArithmetic MeanNoPareto frontNo[53]

To accelerate computation of scoring functions, most are parallelisable using Python’s built-in multiprocessing module, while longer running scoring functions such as docking and ligand preparation can be distributed over multiple compute nodes using Dask , to allow parallelisation over a whole compute cluster. Details on each method can be found in the Supplementary Information.

Functionality available within the molscore sub-package

## Section: Implementation › Molecule evaluation

The moleval sub-package is largely an extension of the MOSES [13] suite of evaluation metrics computed for de novo molecules given a set (or sets) of reference molecules. The main element of this sub-package is the GetMetrics class found in the metrics.py module. This is initialised by optionally specifying some reference datasets (for example, train and test sets used for the measurement of extrinsic properties), and it then takes as input a list of de novo molecules and outputs the respective calculated metrics. Additionally, the CSV output file written by molscore can be provided to the statistics_by_n.py script, which computes evaluation metrics and basic statistics (mean, median and standard deviation) per n molecules or n column values (e.g., per 100 steps).

Table 3 highlights all the evaluation metrics available in moleval split into intrinsic properties (based solely on de novo molecules) and extrinsic properties (in reference to an external dataset). Some additional metrics not found in MOSES for intrinsic properties include sphere exclusion diversity (SEDiv) [11], scaffold uniqueness, scaffold diversity, functional group and ring system diversity [54] and a measure of purchasability in the ZINC20 in-stock catalogue using molbloom [55, 56]. Additional metrics for extrinsic properties include analogue similarity [52] and coverage, functional group and ring system similarity [54] and average fraction of outlier bits (a.k.a. ‘Silliness’ [57]) i.e., the average ratio of ECFP4 fingerprint bits not found in the reference dataset indicating idiosyncratic atomic environments. For a more detailed description of each metric see the Supplementary Information.Table 3Evaluation metrics available in the moleval sub-package. No metrics require a licenseReferencesIntrinsic propertiesValidity[8, 13]Uniqueness[8, 13]Scaffold uniquenessInternal diversity (1 & 2)[13, 58]Sphere exclusion diversity[59]Solow Polasky diversity[60]Scaffold diversityFunctional group diversity[54]Ring system diversity[54]Filters (MCF & PAINS)[13]Purchasability[55]Extrinsic propertiesNovelty[8, 13]FCD[61]Analogue similarity[52]Analogue coverageFunctional group similarityRing system similaritySingle nearest neighbour similarity[13]Fragment similarity[13]Scaffold similarity[13]Outlier bits (Silliness)[57]Wasserstein distance (LogP, SA Score, NP score, QED, Weight)[13]

Evaluation metrics available in the moleval sub-package. No metrics require a license

## Section: Implementation › Benchmarking

Given the broad functionality available in MolScore, it is trivial to define new or re-implement existing benchmarks. Therefore, a benchmark mode has been implemented via the MolScoreBenchmark class in manager.py. This takes a list of JSON configuration files and provides an iterator over the singular MolScore class for each objective, and computes evaluation metrics for comparison upon exit. A series of presets are already present including GuacaMol and MolOpt, where benchmark-specific metrics are computed. Or a user can include/exclude objectives from these or specify their own list of configuration files for use a benchmark.

## Section: Implementation › Implementation challenges

A particular challenge when combining a variety of scoring functions and software from published methods is conflicting library dependencies. Furthermore, predictive models should use the same version of a respective library (e.g., Scikit-Learn) during prediction as was used during training where possible, as there may be subtle changes to the source code affecting the prediction. In order to tackle this, scoring functions that require specific library versions that must be consistent with those used during training are run as a local server from their respective fixed environment, as specified by the authors. This currently includes AiZynthFinder [26], RAscore [25], PIDGINv5 [30], ChemProp [27], ADMET-AI [37] and some legacy QSAR models used in benchmarks such as DRD2, GSK3β and JNK3 bioactivity prediction models. To automate this process as much as possible, molscore will check for these separate conda environments and if not present, attempt to create them automatically when the scoring function is used for the first time. One caveat to this approach is the assumption of the use of conda (or mamba) for environment management. Overall this approach allows integration of different scoring components with conflicting dependencies and avoids re-loading of python environments and predictive models at every iteration which improves computational performance. Should any further challenges arise, tutorials can be found on the GitHub page and issues can be raised on the GitHub contributing to further improvement of the software.

## Section: Results and discussion

The core components of MolScore were used to facilitate scoring and evaluation in our previous work [59, 62]. Here we describe its user interface, demonstrate its use to design difficult, drug design relevant objectives, and show how it can be used to quickly evaluate de novo molecules.

Integration of MolScore into a python module, including initialisation with a model name and path to a configuration file, followed by scoring of an arbitrary list of SMILES that require scoring (which would be repeated for generative model optimisation). An explicit step number can be provided during scoring, if not, it will iteratively count up from one

Integration of MolScore benchmark mode into a python module, including initialisation with a specific pre-existing benchmark and budget. Existing benchmarks are stored in MolScoreBenchmark.presets. The budget specifies a number of molecules to be evaluated before task.finished is set to True. Upon exit, benchmark metrics will be automatically calculated and written to CSV in the output directories

a Example configuration file reimplementing the Albuterol Similarity GuacaMol task. b Streamlit app to aid the creation of new configuration files and avoid manual writing of JSON files. The app annotates options available to the user and automatically parses it into the required JSON format

Streamlit app that can be run during or after goal-directed generative model optimisation (here showing optimisation of 5-HT2A predicted probability of activity). This is the main page used to plot training progress and select, visualise, and export molecules. Further pages are shown in Figures S1–S3

De novo optimisation of the first set of objectives designed by molscore by number of optimisation steps (left) with the equivalent score distribution for 3771 real 5-HT2A ligands (right). The dashed line represents the mean of the real ligand distribution and solid lines plus/minus one standard deviation from the mean. a The predicted probability of 5-HT2A activity at a concentration of 1 µM. b The first objective a combined with predicted synthesizability by RAscore. c The first objective a combined with property ranges increasing the probability of BBB. d All three objectives a–c combined

De novo optimisation of the second set of objectives designed by molscore by number of optimisation steps (left) with the equivalent score distribution for 3771 real 5-HT2A ligands (right). The dashed line represents the mean of the real ligand distribution and solid lines plus/minus one standard deviation from the mean. a The predicted probability of 5-HT2A activity at a concentration of 1 µM. b The first objective a combined with predicted selectivity versus membrane receptors. c The first objective a combined with predicted selectivity versus D2. d The first objective a combined with predicted selectivity versus dopamine receptors. e The first objective a combined with predicted selectivity versus other serotonin sub-types. f The first objective a combined with selectivity versus other serotonin sub-types and dopamine receptors

Example nearest neighbour de novo molecules to real 5-HT2A selective ligands (w.r.t D2 binding) a The five most 5-HT2A selective ligands with respect to D2 binding identified in ChEMBL31 that contain a D2 pChEMBL value above 4, respective pChEMBL values are shown. b Nearest neighbour de novo molecules to each molecule in a, identified during the 5-HT2A vs D2 task with respective Tanimoto similarity (Tc) and objective score. c Predicted probabilities of class A GPCR off-targets for real and de novo ligand counterparts using PIDGINv5. d Predicted class A GPCR targets mapped onto a GPCRome tree [62], shared predicted targets are shown in red, predicted only for the real ligand in blue, and predicted only for the de novo ligand in orange

De novo optimisation of the third set of objectives designed by molscore by number of optimisation steps (left) with the equivalent score distribution for 3771 real 5-HT2A ligands (right). The dashed line represents the mean of the real ligand distribution and solid lines plus/minus one standard deviation from the mean. a The optimisation of the MPO score for 5-HT2A docking. b The optimisation of the MPO score for 5-HT2A vs D2. c, d The docking scores obtained during optimisation seen in (a) and (b) respectively. Note that due to the ‘moving goal post’ nature of max min normalisation, the ‘Score’ is not representative of underlying parameter optimisation and so docking score is also shown

Analysis of molecules generated during the ‘5-HT2A vs D2’ task via the molscore GUI. a (left) The multi-parameter page of the GUI enabling the identification of top k compounds according to user-specified parameters with the ability to redefine how scores are aggregated. b An example molecule exported to PyMol via the ‘Send2PyMol’ button. c The reference co-crystal ligand Risperidone bound to 5-HT2A

Analysis of protein–ligand ligand interaction in differences in 5-HT2A between top 10 de novo molecules optimised for 5-HT2A docking score, or top 10 molecules optimised for 5-HT2A vs D2 docking scores. a Protein–ligand interaction fingerprints of the reference co-crystallised ligand Risperidone, 5-HT2A docking objective, and 5-HT2A vs D2. b, c Example docked pose of one of the top 10 molecules from the above objectives respectively

Moleval metrics computed on different fine-tuning epochs. Epoch-0 represents the generative model before fine-tuning. Intrinsic properties a and extrinsic properties in reference to a test set (sample of the training set) b and the set of A2A ligands used for fine-tuning c are shown

## Section: Results and discussion › User interface › Installation

Installation instructions can be found on the GitHub repository, alternatively, it can be installed in an existing environment via the Python Package Index with pip install molscore.

## Section: Results and discussion › Integration into a generative model

MolScore can then be implemented into a generative model optimisation scheme in just three lines of code, as shown in Fig. 2. Alternatively, MolScore can be run in benchmark mode by providing a preset benchmark, as shown in Fig. 3, or a list of configuration files.Fig. 2Integration of MolScore into a python module, including initialisation with a model name and path to a configuration file, followed by scoring of an arbitrary list of SMILES that require scoring (which would be repeated for generative model optimisation). An explicit step number can be provided during scoring, if not, it will iteratively count up from oneFig. 3Integration of MolScore benchmark mode into a python module, including initialisation with a specific pre-existing benchmark and budget. Existing benchmarks are stored in MolScoreBenchmark.presets. The budget specifies a number of molecules to be evaluated before task.finished is set to True. Upon exit, benchmark metrics will be automatically calculated and written to CSV in the output directories

Examples of generative models with MolScore already integrated can be found on GitHub (https://github.com/MorganCThomas/MolScore_examples), including SMILES-RNN [63], CReM [64], and GraphGA [65].

Integration of MolScore into a python module, including initialisation with a model name and path to a configuration file, followed by scoring of an arbitrary list of SMILES that require scoring (which would be repeated for generative model optimisation). An explicit step number can be provided during scoring, if not, it will iteratively count up from one

Integration of MolScore benchmark mode into a python module, including initialisation with a specific pre-existing benchmark and budget. Existing benchmarks are stored in MolScoreBenchmark.presets. The budget specifies a number of molecules to be evaluated before task.finished is set to True. Upon exit, benchmark metrics will be automatically calculated and written to CSV in the output directories

## Section: Results and discussion › Writing a configuration file

Full specification of logging, scoring functions, score transformation, score aggregation, diversity filters or scoring filters is defined in a JSON configuration file. To streamline and document this process, a Streamlit app is provided to easily write configuration files interactively with documentation and default parameters (see Fig. 4). The app can be run via command molscore_config that loads the GUI in a web browser. This facilitates configuration writing and automatically parses the options specified into a correctly formatted JSON configuration file. This is done by docstring and typing interpretation to provide descriptions and widgets automatically, such that if a user implements a custom scoring function (as described in Supplementary Information), it will be automatically parsed and available to specify in the GUI.Fig. 4a Example configuration file reimplementing the Albuterol Similarity GuacaMol task. b Streamlit app to aid the creation of new configuration files and avoid manual writing of JSON files. The app annotates options available to the user and automatically parses it into the required JSON format

a Example configuration file reimplementing the Albuterol Similarity GuacaMol task. b Streamlit app to aid the creation of new configuration files and avoid manual writing of JSON files. The app annotates options available to the user and automatically parses it into the required JSON format

## Section: Results and discussion › Monitoring de novo molecules

A Streamlit app to monitor de novo molecule generation ‘live’ or analyse results post-hoc is also provided (see Fig. 5). This is useful to gain quick insights into generative model behaviour with respect to chemistry generated, without needing to wait until the end of optimisation (especially in the case of computationally expensive scoring functions). This is run automatically during optimisation if specified in the configuration file, alternatively, it can be run manually at any time via the command molscore_monitor. The app loads a graphical user interface in a web browser and contains functionality to check any variable scored including validity and uniqueness, select and visualise 2D molecular graphs, assess clusters identified by an appropriate diversity filter, and export selected or top k molecules. In addition, if a scoring function is used that results in 3D coordinate files and PyMol [66] is installed, PyMol will be loaded and selected molecules can be exported directly into PyMol. Lastly, other pre-existing molscore de novo molecule generation results can be loaded for quick comparison between runs. Fig. 5Streamlit app that can be run during or after goal-directed generative model optimisation (here showing optimisation of 5-HT2A predicted probability of activity). This is the main page used to plot training progress and select, visualise, and export molecules. Further pages are shown in Figures S1–S3

Streamlit app that can be run during or after goal-directed generative model optimisation (here showing optimisation of 5-HT2A predicted probability of activity). This is the main page used to plot training progress and select, visualise, and export molecules. Further pages are shown in Figures S1–S3

## Section: Results and discussion › Molscore case study: designing 5-HT2a receptor ligands

Here we demonstrate the application of molscore for the design of different, drug discovery relevant objectives, with a focus on the generation of de novo Serotonin 5-HT2a receptor ligands as a case study. This is a relevant therapeutic target indicated in psychosis and substance-abuse with numerous antagonistic drugs marketed for their use as atypical antipsychotics—with the most recent being Lumateperone [67] approved in 2019 by the FDA. For the purpose of this demonstration, we use a SMILES-based recurrent neural network generative model trained on ChEMBL compounds in combination with Augmented Hill-Climb [62] for molecular optimisation.

To start, with we use the functionality available in molscore to design the following first set of objectives:5-HT2A—We use a pre-trained random forest classification model with the PIDGINv5 scoring function to score molecules by their predicted probability of activity at a 1 µM concentration by supplying the 5-HT2A uniprot accession.5-HT2A & Synth—To include a measure of synthesizability which is needed in a real-world drug discovery campaign, we additionally score molecules by running the RAscore [25] pre-trained models and compute the arithmetic mean of this score together with the predicted probability of 5-HT2A activity as before.5-HT2A & BBB—Due to the therapeutic targets prevalence and disease relevance in the central nervous system, we run molecular descriptors and specify certain property ranges that increase the probably of blood brain barrier (BBB) permeability. The property ranges were influenced by Pajouhesh et al. [68]: topological polar surface area below 70, number of hydrogen bond donors below 2, logP between 2 and 4, and molecular weight below 400 Da. Each molecules property value is transformed into the range 0–1 (see Figure S4) and combined by arithmetic mean with the predicted probability of 5-HT2A activity as before.5-HT2A & BBB & Synth—This a combination of all three of the above objectives by arithmetic mean.

Each objective was optimised by the generative model in combination with a diversity filter to penalise exploitation and hence, encourage exploration. As shown in Fig. 6, each of these objectives can be improved during generative model optimisation. For reference, 3771 real compounds with bioactivity values against 5-HT2A were extracted from ChEMBL31 [69] and their respective scores based on the first set of objectives are also shown. Surprisingly, the most difficult objective appears to be simple optimisation of the 5-HT2A predicted probability of activity; however, we suspect this is largely due to the effect of the diversity filter more heavily penalising similar molecules for this relatively ‘easy’ task. This is corroborated by running the objective without a diversity filter (see Figure S5) which results in quick maximisation of this objective, but exploitative mode collapse shortly following (which the use of a diversity filter circumvents). Overall, it appears these objectives are relatively easy to optimise numerically.Fig. 6De novo optimisation of the first set of objectives designed by molscore by number of optimisation steps (left) with the equivalent score distribution for 3771 real 5-HT2A ligands (right). The dashed line represents the mean of the real ligand distribution and solid lines plus/minus one standard deviation from the mean. a The predicted probability of 5-HT2A activity at a concentration of 1 µM. b The first objective a combined with predicted synthesizability by RAscore. c The first objective a combined with property ranges increasing the probability of BBB. d All three objectives a–c combined

As with many drug discovery campaigns, a key challenge for 5-HT2A ligands is minimising off-target bioactivity and achieving pharmacological selectivity. In this case, particularly against dopaminergic receptors (especially the Dopamine D2 receptor, from here on just D2) bound by typical antipsychotics) which leads to extrapyramidal symptoms as serious side-effects [70, 71]. As a proxy for desirable selectivity profiles, we design a second set of objectives with molscore particularly utilising PIDGINv5 functionality (as with the first set of objectives a diversity filter is also used):5-HT2A—As before, we use a pre-trained random forest classification model from PIDGINv5 to score molecules by their predicted probability of activity at a 1 µM concentration i.e., no selectivity proxy is used.5-HT2A vs Membrane—As a proxy for a generic off-target assay, a random forest classification model at a 10 µM concentration for every Class A GPCR targets with sufficient bioactivity data in ChEMBL31 is run (266 out of a possible 312). The prediction is classified into active or inactive (as opposed to taking the predicted probability) for each receptor and the ratio of active predictions is returned as the score. This ratio is transformed so that low ratios have a high score, therefore minimising this parameter. The arithmetic mean is taken in combination with the predicted probability of activity against 5-HT2A.5-HT2A vs D2—The predicted probability of D2 bioactivity at a concentration of 10 µM is minimised in addition to maximising the predicted probability of activity against 5-HT2A.5-HT2A vs Dopamine—The average predicted probability of bioactivity against each dopaminergic target at a concentration of 10 µM is minimised in addition to maximising the predicted probability of activity against 5-HT2A.5-HT2A vs Serotonin—The average predicted probability of bioactivity against each serotonin target (excluding 5-HT2A) at a concentration of 10 µM is minimised in addition to maximising the predicted probability of activity against 5-HT2A.5-HT2A vs Dopamine & Serotonin—The average predicted probability of bioactivity against each dopamine and serotonin target (excluding 5-HT2A) at a concentration of 10 µM is minimised in addition to maximising the predicted probability of activity against 5-HT2A.

In contrast to the first set of objectives, this second set of objectives was more difficult for the generative model to optimise, as shown in Fig. 7. The easiest objectives with respect to achieving similar scores to real 5-HT2A ligands were selectivity versus membrane and selectivity versus D2. The former likely due to the number of models run leading to low overall ratios of predicted off-targets. However, as more models are added, as in the dopamine and serotonin families, the objective becomes increasingly difficult to optimise to the standard of real 5-HT2A ligands. With the final objective of selectivity versus dopamine and serotonin barely being improved throughout optimisation. It is worth noting the caveat that real 5-HT2A ligands are likely contained in the training data of the PIDGINv5 models used in these objectives, and so will receive inflated scores compared to ‘active’ unseen molecules (of which most de novo molecules are unseen). Although we can’t know how accurate these models are prospectively, or the maximum score achievable, the scores on real 5-HT2A ligands at least provide a minimal benchmark. Moreover, the models are able to at least distinguish 95 of 126 5-HT2A molecules with selectivity over D2, despite the fact that 124 molecules have a D2 pChEMBL value of 5 or above and therefore, 93 correctly predicted selective are actually false negative predictions with respect to the D2 model at 10 µM threshold (see Figure S6), which is somewhat advantageous behaviour in this case for distinguishing selective compounds. For comparison to real 5-HT2A ligands selective over D2, we extracted the de novo nearest neighbours to the five most selective 5-HT2A ligands (see Fig. 8). Analogues were found in the 0.3–0.6 Tanimoto similarity range, although the identified analogues tend to be a ‘simpler’ version i.e., smaller with fewer heteroatoms and functional groups, indicating that either the objective or the generative model needs to more appropriately account for medicinal chemistry principles. However, the de novo compounds did possess similar predicted off-target profiles to the real 5-HT2A ligands. Overall, this second set of selectivity objectives is a more challenging optimisation problem.Fig. 7De novo optimisation of the second set of objectives designed by molscore by number of optimisation steps (left) with the equivalent score distribution for 3771 real 5-HT2A ligands (right). The dashed line represents the mean of the real ligand distribution and solid lines plus/minus one standard deviation from the mean. a The predicted probability of 5-HT2A activity at a concentration of 1 µM. b The first objective a combined with predicted selectivity versus membrane receptors. c The first objective a combined with predicted selectivity versus D2. d The first objective a combined with predicted selectivity versus dopamine receptors. e The first objective a combined with predicted selectivity versus other serotonin sub-types. f The first objective a combined with selectivity versus other serotonin sub-types and dopamine receptorsFig. 8Example nearest neighbour de novo molecules to real 5-HT2A selective ligands (w.r.t D2 binding) a The five most 5-HT2A selective ligands with respect to D2 binding identified in ChEMBL31 that contain a D2 pChEMBL value above 4, respective pChEMBL values are shown. b Nearest neighbour de novo molecules to each molecule in a, identified during the 5-HT2A vs D2 task with respective Tanimoto similarity (Tc) and objective score. c Predicted probabilities of class A GPCR off-targets for real and de novo ligand counterparts using PIDGINv5. d Predicted class A GPCR targets mapped onto a GPCRome tree [62], shared predicted targets are shown in red, predicted only for the real ligand in blue, and predicted only for the de novo ligand in orange

The use of ligand-based predictive models as scoring functions for de novo molecule optimisation can however lead to sub-optimal behaviour. Predictive models must have a broad enough applicability domain to perform expectedly given the broad scope of initial de novo molecules [19], and generative model optimisation can lead to exploitation of predictive model limitations [17, 18]. In contrast, structure-based scoring functions have been shown to improve de novo molecule diversity, and coverage of bioactive chemical space [59]. Therefore, we design a third set of objectives utilising structure-based principles (as with the other objectives a diversity filter is also used):5-HT2A—As a proxy for on-target binding affinity, de novo molecules are docked into the 5-HT2A co-crystal structure bound to Risperidone (PDB: 6A93) using GlideSP [38] and the docking score is minimised. Molecules first undergo ligand preparation via LigPrep [49] enumerating stereoisomers, tautomers and protonation states. The prepared ligand variant with the best (lowest) docking score is taken as the final docking score. The final docking score is transformed by max min normalisation based on the maximum and minimum values updated during optimisation—such that low (good) docking scores are given a score close to one. To inject knowledge of aminergic binding interactions, a further docking constraint is applied to ensure that a docked pose contains a D1553x32 polar interaction, the molecule is also scored to encourage a formal charge of 0 or 1. To help prevent exploitation of docking score limitations the molecule is scored to encourage the maximum number of consecutive rotatable bonds to be three or below. Thus, this is a multi-parameter optimisation problem (MPO) where final reward is computed as the arithmetic mean of all parameters.5-HT2A vs D2—As a proxy for selective binding affinity compared to a closely related off-target, the docking score of 5-HT2A is improved (i.e., minimised) as described above and the docking score of D2 is worsened (i.e., maximised) using the same protocol as above but using the D2 co-crystal structure also bound to Risperidone (PDB: 6CM4). Th D2 docking score is transformed by max min normalisation based on the maximum and minimum values updated during optimisationsuch that high (bad) docking scores are given a score close to one and therefore rewarded. The same extra parameters are specified as in the multi-parameter objective as described above, except that the final score is the weighted sum of parameters, with the 5-HT2A docking score assigned a weight of 2 and all others assigned a weight of 1 to reflect that optimising 5-HT2A docking score is most important.

While the docking score of de novo molecules can be optimised to approximately the mean of known 5-HT2A ligands within just 200 steps (see Fig. 9a,c), optimising for divergent docking scores of 5-HT2A and D2 is much more difficult achieving only slight separation of docking distributions relative to the beginning of optimisation (see Fig. 9d). This will be in large part due to the close similarity between the binding pockets and binding mode of Risperidone. In fact, the 3771 real 5-HT2A ligands show very limited differences in their docking score distributions between 5-HT2A and D2. In this example, the molscore GUI (Fig. 10a) was then used to select and visualise the best de novo molecules generated. Aggregate scores were re-computed (as the fully range of docking score is now known) but with the additional QED parameter with a weight of 1. For example, the top molecule has been exported via a clickable button to PyMol for visualisation (Fig. 10b) in comparison to the reference pose of Risperidone (Fig. 10c). In this case, the de novo molecule has a cationic piperazine making the required interaction with the D1553x32 residue conserved in aminergic receptors [72, 73], but containing a novel cyclo-propane core with two benzene substituents, one in the deep orthosteric pocket and one towards helix 6. Upon searching known 5-HT2A ligands, a precedence is found for such a di-aryl substructure linked by an sp3 hybridised carbon. To further exemplify the potential benefits of more difficult scoring functions such as this, the protein–ligand interaction fingerprints were computed for the predicted poses of the top 10 5-HT2A de novo molecules and top 10 5-HT2A vs D2 using ProLIF [74]. Fig. 11 displays the resulting fingerprints in comparison to the reference ligand, highlighting key areas of the binding pocket avoided by de novo molecules optimised for selectivity, for example, S1312x60, Y139, I2064x56, S2074x57, P2094x60, I2104x61, L3627x34, N3637x35. Interestingly, the top10 de novo molecules optimised for selectivity mostly interact with D1553x32 via polar interactions and not cationic interactions, which may reflect an attempt to avoid increasing D2 docking score (targeting cationic interactions to this residue was a key observation in previous work to optimise the D2 docking score [59]). Overall, this represents a much more challenging objective for de novo design, however, despite poor numerical divergence of docking scores we have shown that this still impacts de novo chemistry obtained and therefore still has utility in practice.Fig. 9De novo optimisation of the third set of objectives designed by molscore by number of optimisation steps (left) with the equivalent score distribution for 3771 real 5-HT2A ligands (right). The dashed line represents the mean of the real ligand distribution and solid lines plus/minus one standard deviation from the mean. a The optimisation of the MPO score for 5-HT2A docking. b The optimisation of the MPO score for 5-HT2A vs D2. c, d The docking scores obtained during optimisation seen in (a) and (b) respectively. Note that due to the ‘moving goal post’ nature of max min normalisation, the ‘Score’ is not representative of underlying parameter optimisation and so docking score is also shownFig. 10Analysis of molecules generated during the ‘5-HT2A vs D2’ task via the molscore GUI. a (left) The multi-parameter page of the GUI enabling the identification of top k compounds according to user-specified parameters with the ability to redefine how scores are aggregated. b An example molecule exported to PyMol via the ‘Send2PyMol’ button. c The reference co-crystal ligand Risperidone bound to 5-HT2AFig. 11Analysis of protein–ligand ligand interaction in differences in 5-HT2A between top 10 de novo molecules optimised for 5-HT2A docking score, or top 10 molecules optimised for 5-HT2A vs D2 docking scores. a Protein–ligand interaction fingerprints of the reference co-crystallised ligand Risperidone, 5-HT2A docking objective, and 5-HT2A vs D2. b, c Example docked pose of one of the top 10 molecules from the above objectives respectively

All of these objectives can be re-run as benchmarks in MolScore benchmark mode by specifying the benchmark keywords ‘5HT2A_PhysChem’, ‘5HT2A_Selectivity’, ‘5HT2A_Docking’ as the benchmark parameter shown in Fig. 3.

De novo optimisation of the first set of objectives designed by molscore by number of optimisation steps (left) with the equivalent score distribution for 3771 real 5-HT2A ligands (right). The dashed line represents the mean of the real ligand distribution and solid lines plus/minus one standard deviation from the mean. a The predicted probability of 5-HT2A activity at a concentration of 1 µM. b The first objective a combined with predicted synthesizability by RAscore. c The first objective a combined with property ranges increasing the probability of BBB. d All three objectives a–c combined

De novo optimisation of the second set of objectives designed by molscore by number of optimisation steps (left) with the equivalent score distribution for 3771 real 5-HT2A ligands (right). The dashed line represents the mean of the real ligand distribution and solid lines plus/minus one standard deviation from the mean. a The predicted probability of 5-HT2A activity at a concentration of 1 µM. b The first objective a combined with predicted selectivity versus membrane receptors. c The first objective a combined with predicted selectivity versus D2. d The first objective a combined with predicted selectivity versus dopamine receptors. e The first objective a combined with predicted selectivity versus other serotonin sub-types. f The first objective a combined with selectivity versus other serotonin sub-types and dopamine receptors

Example nearest neighbour de novo molecules to real 5-HT2A selective ligands (w.r.t D2 binding) a The five most 5-HT2A selective ligands with respect to D2 binding identified in ChEMBL31 that contain a D2 pChEMBL value above 4, respective pChEMBL values are shown. b Nearest neighbour de novo molecules to each molecule in a, identified during the 5-HT2A vs D2 task with respective Tanimoto similarity (Tc) and objective score. c Predicted probabilities of class A GPCR off-targets for real and de novo ligand counterparts using PIDGINv5. d Predicted class A GPCR targets mapped onto a GPCRome tree [62], shared predicted targets are shown in red, predicted only for the real ligand in blue, and predicted only for the de novo ligand in orange

De novo optimisation of the third set of objectives designed by molscore by number of optimisation steps (left) with the equivalent score distribution for 3771 real 5-HT2A ligands (right). The dashed line represents the mean of the real ligand distribution and solid lines plus/minus one standard deviation from the mean. a The optimisation of the MPO score for 5-HT2A docking. b The optimisation of the MPO score for 5-HT2A vs D2. c, d The docking scores obtained during optimisation seen in (a) and (b) respectively. Note that due to the ‘moving goal post’ nature of max min normalisation, the ‘Score’ is not representative of underlying parameter optimisation and so docking score is also shown

Analysis of molecules generated during the ‘5-HT2A vs D2’ task via the molscore GUI. a (left) The multi-parameter page of the GUI enabling the identification of top k compounds according to user-specified parameters with the ability to redefine how scores are aggregated. b An example molecule exported to PyMol via the ‘Send2PyMol’ button. c The reference co-crystal ligand Risperidone bound to 5-HT2A

Analysis of protein–ligand ligand interaction in differences in 5-HT2A between top 10 de novo molecules optimised for 5-HT2A docking score, or top 10 molecules optimised for 5-HT2A vs D2 docking scores. a Protein–ligand interaction fingerprints of the reference co-crystallised ligand Risperidone, 5-HT2A docking objective, and 5-HT2A vs D2. b, c Example docked pose of one of the top 10 molecules from the above objectives respectively

## Section: Results and discussion › Moleval case study: evaluating fine-tuning epochs

The suite of performance metrics does not necessarily need to be run on a molscore output (for example, Figures S7–10). Instead, it can be used to assess arbitrary datasets for quick comparison to reference datasets. For example, evaluating progress during generative model fine-tuning. In this case study, we use a SMILES-based RNN pre-trained on ChEMBL compounds and fine-tune it (via transfer learning) using a set of known Adenosine A2A receptor (from here on A2A) ligands to bias de novo molecule generation towards A2A-bioactive-like chemotypes. This just requires two lines of Python to instantiate the GetMetrics class specifying any reference datasets and calling calculate to calculate the metrics (in this case, repeated for sampled de novo molecules after each epoch of fine-tuning).

Figure 12 shows the resulting changes in metric values during fine-tuning where Epoch-0 represents the generative model before fine-tuning began. It is quickly possible to assess that some intrinsic properties (Fig. 12a) like novelty and diversity decrease with increasing fine-tuning epochs, while validity has an initial drop that is recovered with further fine-tuning epochs as it adjusts to new chemotypes. Meanwhile, similarity to the initial pre-training dataset (ChEMBL compounds) decreases as shown by an increase in Fréchet ChemNet Distance [61] and decrease in analogue coverage (Fig. 12b). Note that metrics that measure the presence of only a single similar molecule, like analogue similarity and single nearest neighbour increase, as the initial ChEMBL training dataset will likely already contain A2A-like chemotypes. Conversely, similarity to the fine-tuning set of A2A ligands increases especially noticeable by analogue similarity and coverage (Fig. 12c), while novelty also slowly decreases with respect to this fine-tuning set. This overview of property changes allows for interpretation on how many fine-tuning epochs are required. In this case, arguably, just one or two epochs are needed which quickly leads to an increased similarity to the fine-tuning set with marginal improvements with any further epochs; however, further epochs do lead to an undesirable decrease in novelty and diversity. The required balance will vary depending on user and use case, however, quickly assessing changes is always useful.Fig. 12Moleval metrics computed on different fine-tuning epochs. Epoch-0 represents the generative model before fine-tuning. Intrinsic properties a and extrinsic properties in reference to a test set (sample of the training set) b and the set of A2A ligands used for fine-tuning c are shown

Moleval metrics computed on different fine-tuning epochs. Epoch-0 represents the generative model before fine-tuning. Intrinsic properties a and extrinsic properties in reference to a test set (sample of the training set) b and the set of A2A ligands used for fine-tuning c are shown

## Section: Results and discussion › Future developments

Several improvements for MolScore are planned for the future. Further scoring functions and performance evaluation functionality, for example, structure interaction fingerprint rescoring for docked poses. Accepting molecules with 3D conformations as inputs, particularly for structure-based scoring functions such as docking and shape alignment. This will become more useful following the increase in 3D structure-based generative models [75, 76]. Integrating dynamic configuration files that can be updated during the course of optimisation for use in curriculum learning [77]. There still exists many opportunities for improvement depending on community uptake which we will continually endeavour to pursue.

## Section: Conclusion

MolScore is an open-source Python framework for the flexible design of drug design relevant objectives for de novo molecule scoring and evaluation. This framework takes a more flexible approach to generative model benchmarking, acknowledging that benchmarks will never be relevant to all situations. Instead, users can make use of the available functionality, contribute custom scoring functions and share their proposed benchmark objectives in a standardised way. In addition, this framework contains two GUIs to facilitate ease of use and accessibility. We believe this framework combines the best elements of current benchmarks with additional flexibility, leading to an overall improved platform. Lastly, we demonstrate the use of MolScore to design drug design relevant objectives and how it can be used to also evaluate de novo molecules (and therefore differences between generative model hyperparameters, architectures and objective functions).

## Section: Text

Supplementary material 1.

## Section: Supplementary Information

Supplementary material 1.

Supplementary material 1.


---

# MolToxPred: small molecule toxicity prediction using machine learning approach

- **Authors:** Anjali Setiya, Vinod Jani, Uddhavesh Sonavane, Rajendra Joshi
- **Issuer:** RSC advances
- **Type:** Scientific article
- **Published:** 2024-01-30
- **Language:** en
- **DOI:** 10.1039/d3ra07322j
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38292268/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractDifferent types of chemicals and products may exhibit various health risks when administered into the human body. For toxicity reasons, the number of new drugs entering the market through the conventional drug development process has been reduced over the years. However, with the advent of big data and artificial intelligence, machine learning techniques have emerged as a potential solution for predicting toxicity and ensuring efficient drug development and chemical safety. An ML model for toxicity prediction can reduce experimental costs and time while addressing ethical concerns by drastically reducing the need for animals and clinical trials. Herein, MolToxPred, an ML-based tool, has been developed using a stacked model approach to predict the potential toxicity of small molecules and metabolites. The stacked model consists of random forest, multi-layer perceptron, and LightGBM as base classifiers and Logistic Regression as the meta classifier. For training and validation purposes, a comprehensive set of toxic and non-toxic molecules is curated. Different structural and physicochemical-based features in the form of molecular descriptors and fingerprints were employed. MolToxPred utilizes a comprehensive feature selection process and optimizes its hyperparameters through Bayesian optimization with stratified 5-fold cross-validation. In the evaluation phase, MolToxPred achieved an AUROC of 87.76% on the test set and 88.84% on an external validation set. The McNemar test was used as the post-hoc test to determine if the stacked models' performance was significantly different compared to the base learners. The developed stacked model outperformed its base classifiers and an existing tool in the literature, reaffirming its better performance. The hypothesis is that the incorporation of a diverse set of data, the subsequent feature selection, and a stacked ensemble approach give MolToxPred the edge over other methods. In addition to this, an attempt has been made to identify structural alerts responsible for endpoints of the Tox21 data to determine the association of a molecule with a plausible downstream pathway of action. MolToxPred may be helpful for drug discovery and regulatory pipelines in pharmaceutical and other industries for in silico toxicity prediction of small molecule candidates.

## Section: Introduction

In the modern world, the exposure of human beings to a plethora of potentially harmful chemicals is a reality of life. Human bodies process chemicals regularly, ranging from pharmaceuticals to food additives and from natural compounds to cosmetic products. Humans are now even prone to agricultural and industrial chemicals such as pesticide residue in food, contaminants in water, and hazardous gases in the air we breathe.1 People can get exposed to these chemicals simultaneously and/or sequentially through a variety of exposure routes like oral, dermal, or inhalation. Exposure to these chemicals can trigger adverse drug reactions, allergic responses, disruption of the endocrine system, and even disability or morbidity due to carcinogenic pathways and tissue and/or organ damage. The health risk assessment of these chemicals' exposure depends on the dose, frequency, duration, and administration route.2 Furthermore, every year, hundreds of new synthetic chemicals are being released into the environment, which are directly or indirectly accumulating in humans.

All the chemical ingredients for human applications are required to meet certain regulatory requirements to be certified as safe for use. The drug discovery process involves various stages from ideation, to lead identification to development to approval. This process, of drug safety assessment, is a crucial but long, expensive, and very complicated process. Clinical trial data from 2010 to 2017 shows that toxicity is attributed to 30% of clinical failures of drug development.3 The conventional process for toxicity identification involves in vivo and in vitro screening techniques. Although these methods have proven to be helpful, they tend to be time-consuming, inefficient, and highly expensive.2,4,5 The use of animal testing in clinical trials has been under question due to the ethical and accuracy reasons for predicting human toxicity.2 This has led to the emergence of in silico approaches for predicting toxicity which can utilize the inherent properties of the molecules.

Computational approaches have proven to be a promising pre-screening technique for a large number of potential molecules being explored through high-throughput screenings.6–9In silico approaches have the advantage of predicting toxicity even before the compound is synthesized,10 saving time and money over traditional toxicity prediction methods. The in silico approach is based on the concept of the “molecular similarity principle”, which suggests that molecules with similar structures will have similar biological activities.11 These methods use the structural and molecular properties of these molecules to extract the most useful information for the prediction of toxicity.8,12,13

Several in silico methods have been developed for toxicity prediction like structural alerts, read-across, and Quantitative structure–activity relationships (QSAR).14 Structural alert (SA) is a chemical substructure that is associated with toxicity,15 it can be an atom or a collection of atoms. These can be determined by using specialized human expertise16 or statistical analysis of fragmented datasets.17 SAs are usually used in a rule-based fashion and associate the presence of structural alert or its combination with toxicity.18 Another method is read-across which uses information from compound(s) with known properties to infer information for other similar uncharacterized compounds of the same chemical category.19 The similarity of two chemicals can be calculated statistically using different distance metrics like Tanimoto, Euclidean, Hammings, etc19. Although the read-across method is transparent and easy to implement, read-across uses a small dataset as compared to other methods owing to the small number of analogs for a compound. The interpretation of results can be complex depending on the choice of similarity and strength of similarity.20 QSAR methods make use of multiple types of machine learning algorithms to establish a link between chemical structure and toxicity. Unlike other methods, QSAR can quantify the relationship between structure and toxicity on their physiochemical property basis.21 Machine Learning (ML) is one of the most widely used methods for making such predictions. The machine learning algorithms used have the potential to map both linear and non-linear relationships.

Machine Learning has even outperformed animal testing for a few applications like RASAR by Luechtefeld et al. for oral and dermal toxicity, eye and skin irritation, and mutagenicity.22 ML algorithms can be broadly classified into two types – supervised and unsupervised learning. In supervised learning, all data is labeled and the algorithm learns to map the output label from the input data. Unsupervised learning has all the unlabeled data and the algorithm learns the underlying structure of the data. ML can use different algorithms employing a molecule's chemical and structural properties as a feature set for toxicity prediction. Many supervised ML methods have been explored that use these feature sets for toxicity predictions such as ToxiM,12 DeepTox,8 eToxPred,13 and ProTox.9 One of the most used datasets for these studies is the Tox21 dataset,23 which is a collection of in vitro toxicity screening results of thousands of chemicals and approved drugs. DeepTox was one of the best-performing methods in this Tox21 challenge.24 It utilizes the potential of a Deep Neural Network (DNN) trained on molecular descriptors and fingerprints to predict the toxicity of nuclear receptor panels and stress response panels. eToxPred is a method to predict the synthetic accessibility and the toxicity of molecules. It employs an extra Tree Classifier to predict the toxicity by using only fingerprints. It uses publicly available datasets like FDA-approved, KEGG Drug,25 TOXNET,26 T3DB,27 and TCM28 for training and testing the model for toxicity. It reports an AUC of 0.82 for the prediction of toxicity.13 ToxiM is another tool for the prediction of toxicity of molecules using fingerprints and descriptors as input features. It trains a random forest model on self-curated positive and negative datasets, which even includes human metabolites as non-toxic molecules.12 The performance is validated using a validation set and reports an accuracy of 93%. But the drawback of ToxiM is that the dataset used for training is limited by the diversity of data and the number of compounds.

There are several computational methods available for toxicity prediction, but their use is restricted either because the tool is not freely available or because the model was trained on extremely specialized data. So, there is still a need for a method that is not only highly accurate but also fast in training and easily deployable in a classical computing environment. Due to advances in both technology and the exploration of chemical space, the amount of data collected in the pharmaceutical sector is increasing exponentially. To effectively handle the immense amount of data in the chemical–biological space, a machine-learning method that can keep pace is essential. Hence, this study proposes a combination of machine learning and cheminformatics approaches to accurately predict molecule toxicity. The approach involves developing a stacked model utilizing three different base models: LightGBM, random forest, and multi-layer perceptron. These models are selected based on their distinct advantages as individual models and their demonstrated effectiveness in previous studies8,29,30 on toxicity prediction. Model stacking is a popular and successful approach that has been recently applied in many areas of cheminformatics.31–33 Stacking allows the flexibility of varied base models that can be trained using a variety of algorithms, architectures, and hyperparameter configurations. By leveraging the diverse characteristics and capabilities of these models, the stacking approach aims to achieve enhanced predictive power for the task.

In terms of data, most of the available works use either descriptors or fingerprints (or a single type of fingerprint) for training purposes. The current work is one of the few attempts to combine descriptors and fingerprints to harness the maximum information and predict the toxicity of molecules. Extensive effort has been put into curating the dataset on which the proposed model gets trained and assessed. The data has been compiled from diverse fields like natural products, human metabolites, known drug molecules, potentially hazardous chemicals, aerosols, and synthetic bio-active compounds. Toxicity is one of the primary properties that are assessed by any industry dealing with compounds for human consumption. For that matter, “the structure of a chemical substance implicitly determines its physical and chemical properties and reactivity, and these properties interact with biological systems to determine its biological/toxicological properties”,34,35 Hence molecular descriptor and fingerprint-based approach is chosen which represents the structural and physicochemical properties of the compound. Additionally, in the current study an attempt is made to make informed predictions regarding the potential endpoints associated with a molecule, by searching for the defined structural alerts within the molecule in question. For identifying structural alerts in this study Tox21 data is considered. The Tox21 compound library has information about 12 biological receptors: a panel of seven nuclear receptors (NR) and five stress response (SR) pathway assays. Data generated from Tox21 has been used to identify compounds that interact with specific toxic pathways, including some not previously known.36,37 The proposed method, by incorporating the aforementioned factors, aims to handle an ever-increasing number of compounds being tested by pharma and other industries.

The rest of the paper is organized as follows: Section 2 is Materials and Methods. It discusses the dataset i.e. toxic and non-toxic data, the input features i.e. molecular descriptors and fingerprints, and the feature selection methods applied. It further talks about model building and evaluation which describes the Stacked model architecture and the associated classifiers, followed by the proposed workflow and the model evaluation metrics. Section 3 is Results and discussions, which discusses the results of data processing and feature selection, feature importance, the selection of optimal hyperparameters, toxicity label prediction, and discussions. The model was not only compared with a few base model algorithms but also with an existing tool for toxicity prediction. Section 4 is the structural alerts study and Section 5 is Conclusion.

## Section: Materials and Methods

The quality of the data limits the performance of a machine learning (ML) model. Along with data availability, tuned hyperparameters are an important prerequisite for model performance and reproducibility in modern machine learning algorithms. This section discusses data compilation and curation, pre-processing, descriptor and fingerprint calculation, feature selection, data splitting, learning algorithms, and model evaluation.

## Section: Materials and Methods › Datasets

The most important aspect of the supervised machine learning algorithm is a labeled dataset. A robust dataset is required as it will govern the model's performance. In the current study, the data from varied sources were collected, curated, and labeled with two classes viz. toxic and non-toxic depending upon their source. The toxic dataset is labeled as one and consists of known toxins, while the non-toxic dataset is labeled as zero and consists of non-toxins. The dataset was initially cleaned to remove duplicates and salts/metals/duplicates/biologicals. The details of the curated dataset have been given in Table 1.

## Section: Materials and Methods › Datasets › Non-toxic data

The non-toxic dataset comprises the drug molecules that have been approved by regulatory bodies i.e. FDA and KEGG drug database25 and the metabolites present in the human body from the RECON1 model in BIGG database.38 The drugs collected from these regulatory databases might have some side effects but considering their therapeutic advantages it qualifies as non-toxic. FDA-approved drugs (1515) were collected from DrugBank39 and the KEGG drug database contains around ∼3682 drugs approved in U.S., Japan, and Europe. As the human metabolites from pathways have not been reported toxic to humans,12 this data has also been added to the non-toxic molecules. The 1263 human metabolites were retrieved from the RECON1 model in UCSD's BIGG database.38 The rationale behind including the human metabolites is that these are produced by conserved pathways and to date, no reports of toxicity have been reported.

The Tanimoto similarity40 coefficient was used to compare the non-toxic molecules from all the sources, and any molecule with a coefficient of more than 0.95 was excluded as it would be redundant to include because of high similarity. The final non-toxic dataset consists of 5933 non-redundant non-toxic molecules.

## Section: Materials and Methods › Datasets › Toxic data

The toxic dataset contains toxins from two sources (i) 3036 molecules from TOXNET (ii) and 3689 molecules from the Toxin and Toxin Target Database (T3DB) database. The TOXNET data earlier maintained by NIH and NLM has now been moved to HSDB in PubChem. It is an amalgamation of over 15 databases on toxicology, hazardous chemicals, environmental health, and toxic releases.26 T3DB is a collection of common toxins like drugs, pollutants, pesticides, cosmetics, etc., and their specific human target proteins.27 Metals and small peptides were removed from T3DB data for this analysis. Further redundant and similar molecules were removed at a Tanimoto coefficient threshold of 0.95. This resulted in the final 4696 toxic molecules labelled as one.

## Section: Materials and Methods › Input features

The principal information for predicting toxicity is based on a drug's chemical structure, as molecules with similar structures may have similar toxicological pathways and properties.41 In the current work, each compound's chemical molecular structure is expressed in Simplified Molecular-Input Line-Entry System (SMILES) format. The SMILES notation of the molecules obtained from various databases was then converted into canonical SMILES i.e. unique SMILES considering the connectivity and chirality of the molecule using the RDKit library.42 From this data, a set of 180 random molecules were initially set aside to use as an external validation set for assessing the built model performance later. It was made sure that these molecules are representative of new molecules and don't share much similarity with the train or test set. For computers to understand the chemical structure, it must be represented in a machine-readable format, such as numbers or characters. The molecular descriptors and fingerprints are these mathematical representations of chemicals and serve as the input features for further analysis and predictions. The details of molecular descriptors and fingerprints have been given in the below subsections. This numerical representation of the data helps for the faster processing of the chemical structures data in a high-throughput fashion.

## Section: Materials and Methods › Input features › Molecular descriptors

Molecular descriptors are mathematical representations of the molecular properties of compounds/molecules generated by algorithms. These are used to quantitatively define the physical and chemical information of the compounds/molecules.43 The choice of descriptors has a strong influence on the predictive performance of the model. Molecular descriptors can be classified according to dimensionality: 0D, 1D, 2D, 3D, and 4D descriptors. For the purpose of this study 0D, 1D & 2D descriptors have been calculated via RDKit42 library in Python. The missing values were substituted with 0 and the infinite values with 1. 0D-descriptors are independent of molecular connectivity and conformations and refer to atom and bond type counts. 1D-descriptors contain information about fragment counts, and their calculation is independent of information on molecule structure. 2D-descriptors are topological descriptors, derived from molecular graphs, and are conformationally independent.44 These descriptors have two major categories: (1) physicochemical properties and (2) fraction of a substructure. Examples of these descriptors have been given in Table 2.

## Section: Materials and Methods › Input features › Molecular fingerprints

Fingerprints are another form of a descriptor in which molecular structures are encoded to a bit string. It is a series of binary digits (bits), representing the presence or absence of a particular substructure in the molecule indicated by 0 and 1 respectively. These are numeric arrays of n bits long, where n depends on the fingerprint algorithm. The PaDELpy library in Python, which is a wrapper for PaDEL-Descriptor45 software, has been used to calculate the molecular fingerprints for the input data. The list of fingerprints calculated have been mentioned in Table 4.

## Section: Materials and Methods › Feature selection

The molecular descriptors and fingerprints have proved its importance as features over the years for predicting various properties46,47 of the small molecules and not solely toxicity prediction. However, all the molecular features might not be effective for the prediction of the toxicity of the small molecules, and such ineffective features will not only increase the time required for the training but also adversely impact the performance of the model. Feature selection reduces the complexity of a model and makes it easier to interpret. So, this necessitates the use of efficient feature selection methods that can identify and remove irrelevant and redundant information to obtain practical results. The current dataset for the defined problem in this study consists of molecular descriptors which are numeric continuous values & molecular fingerprints which are high-dimension discrete binary values.

As a result, separate univariate feature selection techniques have been used to select fingerprints and descriptors. This aims to select features that are significantly associated with the target variable while removing highly correlated features. This ensures that the selected features capture relevant information about toxicity and minimize multicollinearity, which can improve the performance and interpretability of the model. To carry out feature selection, a cross-validation strategy is implemented, where the dataset is split into training and testing subsets. The feature selection process is performed solely on the training data to prevent any information leakage from the test set, ensuring unbiased results. Stratified k-fold cross-validation is employed, which takes into account the class distribution of the target variable to maintain its proportionality across the folds. The steps involved in feature selection are shown in Fig. 1 and are described in the below subsections.

## Section: Materials and Methods › Feature selection › Feature selection for molecular fingerprints

To characterize molecular structural properties of compounds, 12 types of molecular fingerprints are generated using PaDELPy, a Python wrapper for PaDEL-Descriptor software.45 This representation of the molecular structure through a chain or vector of bits, with a fixed length, can vary from 79 bits to 4860 bits leading to a large feature set. This feature set can affect the reliability of the built model due to the presence of irrelevant and redundant correlated fingerprints. Therefore, to address this issue, each fingerprint type listed in Table 4 (such as the PubChem fingerprint, Estate fingerprint, etc.) has been individually subjected to the feature selection procedure and then combined subsequently for additional model training.

As molecular fingerprints are discrete values, the chi-square method is used to evaluate features individually with respect to classes i.e. toxic or non-toxic in the target variable. It is a statistical test of independence and estimates whether the class label is independent of a feature or not.48 Each PaDEL fingerprint has been treated as an individual feature set, and features have been selected separately. The chi-squared test is based on comparing the obtained values of the frequency of a class to the expected frequency of the class. To use the chi-square test for feature selection, the hypotheses are:

• Null Hypothesis H0: feature & Target Variable are not dependent.

• Alternate Hypothesis H1: feature & Target Variable are dependent.

The criterion for accepting or rejecting the null hypothesis is determined by whether the p-value is more or less than the significance level (α) respectively. Due to the execution of multiple hypothesis tests Bonferroni corrections49 have been applied over the chi-squared test.

Further to deal with multicollinearity i.e. correlated features which may act as redundant features, Cramer's v-test50 is used. Cramer's v-test is a chi-square-based statistic that assesses how strongly two (nominal) categorical variables are associated or dependent on one another.

Cramer's V ranges between 0 ≤ V ≤ 1, the closer V is to 0, the smaller the association between the categorical variables. So highly correlated features i.e. with Cramer's V correlation greater than 0.5 (ref. 51 and 52) were discarded and only small and medium associations were kept. Table 4 lists the features selected for all the fingerprints for further usage in the model.

The feature selection process is integrated with five-fold stratified cross-validation. This helps in performing the feature selection in a more robust and unbiased manner. By repeatedly splitting the training data into training and validation sets, it can be assessed how well the selected features perform across different subsets of the training data.

Within each fold, Bonferroni corrected chi-square test was applied to the training data to select features based on their p-values (<0.05). These selected features in the same fold are then evaluated using Cramer's V test to identify and remove features with high correlations above the threshold of 0.5. Finally, a consensus is determined by considering the occurrence or agreement of each feature across multiple folds. The details of the chi-square test, Bonferroni corrections, and Cramer's v-test are given in ESI.†

## Section: Materials and Methods › Feature selection › Feature selection for molecular descriptors

Molecular descriptors i.e. the molecule level features which comprise structural and physicochemical properties of small molecules are calculated using the RDkit library in Python.42 These consist of 208 descriptors which are ‘numerical’ values, that act as feature sets for predicting toxicity. From this vast set of descriptors, those that significantly affect the performance of the model in predicting toxicity have to be selected. The objective is to choose a set of descriptors that can collectively capture the maximum information about the target variable. For this purpose, mutual information statistics have been used for calculating the relationship between each molecular descriptor and toxicity label.

Mutual information describes relationships in terms of uncertainty i.e. entropy. The mutual information (MI) between two quantities is a measure of the extent to which knowledge of one quantity reduces uncertainty about the other. MI is zero when two quantities are independent and higher values for higher dependency. So, the aim is to select features that have higher mutual information w.r.t to target variable toxicity. The MI between continuous variable X and discrete variable Y represents the reduction in the uncertainty of Y i.e. target variable after observing the X. The mutual information has been calculated using the sklearn library in Python. The function used in this library relies on nonparametric methods based on entropy estimation from k-nearest neighbor distances.53,54 The details and mathematical representation of the M.I. calculations have been described in the ESI.†

After the MI score for each feature X in the train set is computed with stratified five-fold cross-validation, a threshold value of 0.025 is set as a criterion for feature selection. In addition to this, measures have been taken to remove the multicollinearity in the features. This is done using the Pearson correlation55 method to remove redundant highly correlated features which could lead to noise in data. So, highly correlated features i.e. with absolute Pearson correlation greater than 0.9 were discarded within the same fold. Similar to molecular fingerprints a consensus is taken across all folds by considering the occurrence of each feature across multiple folds and final features are selected.

## Section: Materials and Methods › Model building & evaluation › Model stacking

In the current work, the toxicity prediction problem has been treated as a classification task. To improve the overall prediction performance, a stacked model approach has been implemented. This approach leverages the concept of model stacking, which has shown that combining predictions from multiple diverse models can result in better predictions as compared to using models in isolation.56

The architecture of the stacked model consists of two or more well-performing models as base models. These base models get trained on the training data and generate prediction probabilities for each label. These predicted probabilities then serve as input features for a meta-classifier. The meta-classifier is trained on the predictions made by the base models using out-of-sample data. The out-of-sample predictions are generated through k-fold cross-validation and have the same size as the original training set. In other words, the data that was not used to train the base models are utilized to train the meta-classifier, enabling it to make predictions based on the collective insights from the base models. In the current study, three base classifiers were employed followed by a meta-classifier. Each of the base classifiers and the meta classifier has been explained in the below subsection.

## Section: Materials and Methods › Base learners › LightGBM

LightGBM is a gradient-boosting decision tree (GBDT)57 method developed by Microsoft in 2017.29 The LightGBM algorithm is considered as a fast and efficient form of GBDT. It is an ensemble model with a decision tree as its base model, which can be trained sequentially. It works on minimizing the prediction error by combining multiple weak learners to form a strong one. The initial tree will, like other gradient boosting algorithms, learn to fit the target variable, and then each new learner will fit the residual (gradient of loss function) of the previous tree, and minimize the residual. This leads to improved accuracy and reduced bias in the predictions. LightGBM splits the tree in a leaf wise-manner (Fig. 2) with a depth limitation strategy as opposed to the conventional level-wise tree building in other boosting algorithms.29 This means that as a tree grows deeper, it concentrates on extending a single branch rather than growing multiple branches. LightGBM can handle categorical data and provides faster training with techniques like gradient-based one-side sampling (GOSS) and exclusive feature bundling (EFB).

## Section: Materials and Methods › Base learners › Random forest (RF)

Random forest is a decision tree-based ensemble technique, specifically a bagging technique.59 Bagging is a technique where several decision trees are trained in parallel followed by aggregation. These parallel trees are built on various subsets of the training dataset using different subsets of available features which helps reduce the variance. These data points and features are chosen at random with a replacement which is called bootstrapping. Bootstrapping ensures that each decision tree in the forest is unique leading to a reduction in the variance of the classifier.60 For the classification task, a majority vote is taken of all the decision trees i.e. the most frequent categorical variable will lead to the predicted class.

## Section: Materials and Methods › Base learners › Multi-layer perceptron (MLP)

An MLP is an artificial neural network that consists of at least three interconnected neuron layers: an input layer, a hidden layer, and an output layer. The input layer receives the input data to be processed and the output layer performs the required task of prediction.61 A number of hidden layers placed between the input and output layers perform the computational task of the MLP using various activation functions. These activation functions introduce non-linearity into the network, allowing it to learn and model complex relationships in the data. The MLP follows a feed-forward architecture, where data flows from the input layer through the hidden layers to the output layer. The neurons within the MLP are trained using the backpropagation algorithm, which adjusts the weights and biases of the neurons to minimize the error between the predicted and actual outputs.62

## Section: Materials and Methods › Base learners › Logistic regression: meta learner

Logistic regression is employed as the meta learner, it is a simple and efficient statistical method for binary classification problems.63 It uses a logistic function also known as a sigmoid function to return the probability of a label. The output of logistic regression falls within the range of 0 and 1.64 In addition, logistic regression does not necessitate a linear relationship between inputs and output variables. Instead, it applies a nonlinear log transformation to the odds ratio. The output of logistic regression represents the probability of each class, which is obtained by applying the sigmoid function to the log odds:

where g(z) is the probability converted by the sigmoid function and z is log odds in eqn (1).

## Section: Materials and Methods › Proposed workflow

In the current work, a stacked model-based approach has been taken. The method aims to learn from the feature representations of the small molecules to predict toxicity. The performance of the proposed workflow is evaluated on the curated dataset described in section 2.1. The specific steps for predicting small molecule toxicity using LightGBM are described as follows:

(1) Input datasets: the preprocessed dataset after removing duplicates, missing values, biologicals, and faulty SMILES is used as input for the prediction of toxicity. It contains both non-toxic and toxic molecules, which have been compiled from different sources mentioned in Table 1. Data is divided into training and test set in a ratio of 80 : 20 and normalized. To handle the slight imbalance between the two classes of data, sklearn parameter class weight is set to ‘balanced’ for each of the base learners and meta learner.

(2) Feature extraction and feature selection: features are extracted from the SMILES representation of the molecules in the form of molecular descriptors and fingerprints with the help of RDKit42 and PadelPy65 libraries respectively in Python. The redundant and highly correlated features are removed, using the feature selection techniques described in Section 2.3.1 and 2.3.2 for molecular fingerprints and descriptors respectively. It is to be noted that feature selection was performed individually for each molecular fingerprint, to select only optimal features and was combined in the end for further predictions. These molecular representations are then used as input for model building.

(3) Hyperparameter tuning: the selection of hyperparameters plays a crucial role in building a model. Hyperparameters are all the parameters that the user can set before training the model to control the learning process. Therefore, to achieve the best performance on the data in a reasonable time, hyperparameter optimization is required. Bayesian optimisation is a method to find the best values of hyperparameters based on the Bayes theorem which will minimize or maximize an objective function. The two main steps include: it builds a probability model i.e. a primary function that assumes the distribution of the objective function which is to be optimized. This prior function, also called the surrogate model, is updated by using an acquisition function. The acquisition function identifies the next input values to evaluate. The goal of Bayesian optimization (eqn (2)) is to find the global maximum or minimum value of function f(x) in the candidate set S and then generate the corresponding best combination of hyperparameters.66

where the hyperparameters are input to the function f(x) and maximum metric of choice is set to be output of the function f(x).

For learning a generalized model, the training dataset is randomly divided into five equal parts, in which one part is the independent validation set. The remaining parts were used to train the models and find the best hyperparameters using stratified five-fold cross-validation. The workflow utilizes stratified k-fold cross-validation as it uses stratified sampling which ensures that the ratio of the toxicity label remains the same across original data, training data, and test data. This way a more accurate assessment of performance is achieved by ensuring that no value is over- or underrepresented in the training and test sets. This significantly reduces both bias and variance as most of the data is being used for the training set and validation set respectively.

Hyperparameter optimization is done by performing 10 iterations of Bayesian optimization67 with Gaussian processes as a surrogate model and upper confidence bounds as acquisition functions using the scikit BayesOpt68 package for eight hyperparameters of LightGBM. For random forest, the HyperOpt69 package is used for tuning five hyperparameters by performing 10 iterations, with the Tree-structured Parzen Estimators (TPE) algorithm, which uses the Expected Improvement (EI) as the acquisition function. For Multi Layer Perceptron, BayesOpt68 package is used for tuning three hyperparameters of MLP using 10 rounds of optimization with Gaussian processes as a surrogate model.

(4) Model stacking: the best hyperparameters obtained for each base model are then used for training purposes. The stacked model as shown in Fig. 3 has been implemented in the following way:

Step 1: the training set for the Stacking Classifier model is divided into five folds using the Stratified five-fold strategy, preserving the percentage of each class. Cross-validation is applied to avoid overfitting. For all base classifiers i.e. LightGBM, RF, and MLP, the training portion of each fold act as a training set, and the predictions are made on the validation portion of each fold.

Step 2: this validation set prediction probabilities from the base models are concatenated, creating a new training set for the meta-classifier. This new training set represents the predictions from all three base models. The original labels are retained as the labels for this dataset.

Step 3: the meta-classifier i.e. Logistic Regression model in this study, combines the predictions made by the base classifiers. The meta-classifier is trained using the new training set and true target variable from the validation portion of the fold. Following that, the meta-classifier is used to make predictions on the test portion of the fold.

Step 4: the predictions from the meta-classifier are collected for each fold, resulting in multiple sets of predictions for the entire test set. The final predictions are calculated by averaging the predictions from all folds.

This process accounts for the variability in predictions across different folds and provides a more robust estimate of the model's performance on unseen data. It helps mitigate overfitting risks and ensures a reliable evaluation of the model's performance.

(5) Model evaluation: to evaluate the quality of the model's predictions, the model is evaluated on various metrics as mentioned in Section 2.7. Accuracy, AUC, Sensitivity, specificity, MCC, and F1 score are calculated for both training and test dataset. External validation data is used to further analyze the stacked model's performance. The stacked model is also compared with the individual base models. A corrected version of McNemar's test is used to assess the statistical significance of the stacked models' performance w.r.t each of the base classifier's performance.

McNemar's test is non-parametric variant of χ2 test.70 It is based on a 2 times 2 contingency table of the two model's predictions. McNemar's test creates a contingency table that gives the successful and unsuccessful predictions of the two models in question. In Table 3 a sample contingency table has been given, showing b as the number of predictions where model 1 succeeds and model 2 fails, and c as the number of predictions where model 2 succeeds and model 1 fails. If the sum of c and b is sufficiently large, the χ2 value follows a chi-squared distribution with one degree of freedom.

Then McNemar's formula, corrected for continuity given by Edward et al.,71 in equation is written as follows:

After setting a significance threshold, here α = 0.05 the p-value is computed, and the p-value is the probability of observing this empirical (or a larger) chi-squared value. If the p-value is lower than the chosen significance level, the null hypothesis can be rejected that there is no significant difference between the performance of the two models. Along with this, the proposed model has also been compared with one of the existing tools ‘eToxPred’ for better comparative assessment.

## Section: Materials and Methods › Model evaluation

In the context of toxicity binary classification, various metrics are used to assess the performance of the model which are based on the confusion matrix. The confusion matrix comprises True Positives (TP), the number of toxic compounds that are correctly predicted. False Positive (FP), which is the number of non-toxic compounds incorrectly predicted as toxic. True Negatives (TN) refer to the number of correctly predicted non-toxic compounds, and lastly, False Negatives (FN) correspond to the number of incorrectly labeled toxic compounds as non-toxic. The value of sensitivity (recall) eqn (5) reflects the model's ability to correctly predict toxic samples (1), a higher sensitivity value indicates a lower rate of false negatives, indicating that the model is effective in capturing and predicting toxic samples accurately. Whereas the value of specificity eqn (6) represents the model's ability to correctly predict non-toxic samples (0).30 A balance between the two indicates that the model is effective in distinguishing non-toxic samples from toxic ones. Accuracy eqn (7) which is the estimate of the overall performance of the model is also reported, along with the misclassification score. The performance of the classification model across all classification thresholds is represented by the receiver operating characteristic (ROC) curve, which is used to assess a model's robustness. A better metric of evaluation is the area under the curve (AUC), also known as the area under the receiver-operating characteristic (AUROC), for quantifying ROC which is also reported for model performance. This curve is a graphical trade-off between True Positive Rate (TPR) and False Positive Rate (FPR) at different decision thresholds. The probability that a model would score a randomly selected positive sample higher than a randomly selected negative sample is expressed as the area under the ROC curve or AUC. Higher prediction accuracy is indicated by an AUC value that is nearer to 1.13 These evaluation metrics were implemented using the scikit learn package72 in Python.

where, TP = True Positive, TN = True Negative, FP = False Positive, FN = False Negative.

Precision eqn (8) assesses the model's precision in identifying toxic compounds from all the predicted positive cases. Another metric used is the F1 score eqn (9) that combines both precision and recall to provide an overall assessment of the model's performance by taking the harmonic mean of precision in eqn (8) & recall eqn (5). Precision assesses the model's capability in identifying toxic compounds from all the predicted positive cases. While the recall is the proportion of true positive predictions out of all actual positive samples (toxic compounds). A higher F1 score indicates that the model has achieved a good balance between accurately identifying toxic compounds (high precision) and capturing a large proportion of all toxic compounds (high recall). Matthews Correlation Coefficient (MCC) is a metric commonly used to evaluate the performance of binary classification models. It takes into account true positives, true negatives, false positives, and false negatives to provide a balanced measure of the model's overall performance which also has been reported.

## Section: Results and discussions › Data processing

In this study, 14 678 compounds were collected from different publicly available databases as described in Table 1. For the initial pre-processing, SMILES are formatted to the canonical SMILES, duplicates are eliminated and redundant, and similar molecules are removed by using a 0.95 threshold of the Tanimoto coefficient. Finally, 10 449 compounds are obtained for use as the training set (8359) and the test set (2090) for the establishment of toxicity prediction models. A separate set of 180 random small molecules is reserved as an external validation set. The Tanimoto similarity scores were computed to determine the degree of similarity between molecules in different sets. In Fig. 4, a value of 0 indicates low similarity and 1 suggests identical molecules. The results show that there is a relatively low degree of similarity between the compounds in both the train–test data and the train–external validation data.

## Section: Results and discussions › Feature selection

The PaDELpy library is used to calculate nine different types of fingerprints and the RDKit library in Python is used to calculate 208 descriptors and Morgan fingerprints. Separate feature selection techniques are applied to descriptors and fingerprints to select features that are effective for the prediction of the toxicity of the small molecules. Therefore, 76 relevant molecular descriptors get selected from 208 descriptors (ESI 2.3.1†) using mutual information and pearson correlation in a stepwise manner as described in Section 2.3.2. Similarly, as described in Section 2.3.1 both the Bonferroni corrected chi-square test and the Cramer's v test, effectively eliminate a large number of redundant and highly correlated fingerprints, yielding 2237 features from 12 193 features as shown in Table 4.

## Section: Results and discussions › Feature importance

In order to address the black-box nature of machine learning algorithms and make predictions more explainable, feature importance scores are calculated. Feature importance in predicting the toxicity of a molecule is given through the permutation importance method i.e. the contribution of each feature is calculated in order to predict the target variable. Permutation importance measures the decrease in a model's performance when a single feature (i.e., each key or bit in the molecular fingerprint or each molecular descriptor) is randomly shuffled. If shuffling a feature's values has no effect on the model's predictive performance, it indicates that the feature does not make a significant contribution to the model's predictions. On the other hand, if randomly shuffling the values of a feature leads to a substantial decrease in predictive performance, it suggests that the feature plays a more important role in the model's predictions.73 Each feature is shuffled multiple times and the shuffled feature with the highest performance deviation is the most important and vice versa.

The permutation importance of three individual base classifiers (random forest, MLP, and LightGBM) was calculated with ten times repetition using the test data. Due to the black-box nature of the stacked model,74 only individual learners were used to calculate permutation importance.

The systematic and repetitive approach enhances the reliability and confidence in the feature importance assessment, reducing the impact of potential outliers or random fluctuations. To take these repetitions into account in a more robust manner and to understand the influence of the features in each base learner's predictions an optimal estimator from associated uncertainties75 is calculated. It is based on the maximum likelihood considerations and the same has been explained in the ESI.† This optimal estimator provides a refined representation of permutation scores, across the three models considering the associated uncertainties from the repeats of permutation. The features highlighted important from this estimate tells about the features contributing to the model's prediction of classifying a molecule as toxic or non-toxic.

Among the feature importance scores generated the top 50 important features according to their optimal estimate of uncertainty have been depicted in Fig. 5 for illustration purposes. Features identified as relevant have been discussed below:

(1) Topological descriptors: topological descriptors are based on a graph representation of the molecule. These take into consideration the internal atomic arrangements of compounds that encode information regarding molecular size, shape, branching, presence of multiple bonds, number of aromatic rings and heteroatoms.76 Balbanj77 is a distance-based topological descriptor and Ipc index is an information-theory-based topological descriptor.78 BCUT 2D metrics take into account bond-type for both adjacent and non-adjacent atoms79 is another important topological feature which plays a role in classification. These results of feature importance are in line with a number of toxicity prediction studies on Tox21 (ref. 24) like DeepTox,8 and state-of-the-art tools like TOPKAT.80 Other findings also show that molecular connectivity indices are an adequate predictive tool for assessing the level of toxicity of a wide range of chemicals.81,82

(2) Physicochemical descriptors: these consist of the structural and chemical properties of the small molecules. Some of the physicochemical descriptors i.e. min partial charge and max partial charge have the highest feature importance score, these model the distribution of electrons over a molecule. This indicates that electrostatic interactions impact the toxicity profile of the drug. E-state indices play a vital role in toxicity assessment by concurrently encoding the topology and electronic environment of molecular fragments.83 QED (quantitative estimate of drug-likeness)84 is a measure of the drug-likeness of a molecule and reflects many properties like molecular weight, octanol/water coefficient logP, topological polar surface area, etc. These properties can affect how a molecule interacts with biological systems and potentially influence its toxicity. NHOH count: number of NHs or Ohs, number of rotatable bonds, number of aliphatic rings and number of aromatic heterocycles are all part of Rdkit's Lipinski parameters of a molecule and found their place in top 50 important features for toxicity prediction. These factors can contribute to toxicity by influencing a molecule's interaction with biological targets, potential nonspecific binding, metabolic stability, and structural characteristics impacting its bioactivity and potential adverse effects.85

(3) MOE type descriptors: another set of descriptors that find its place in the top 50 important features are the MOE descriptors. These are numerical features calculated from a connection table representing molecular physical properties, partial charge, along with the surface area contributions. This also includes subdivided surface area descriptors which are based on approximate van der Waals surface area calculation for each atom along with its atomic properties.86 These cover contributions to octanol/water coefficient logP (SLogP descriptors) and molecular refractivity (SMR). PEOE descriptors calculate partial charges, which is based on the iterative quantization of atomic orbital electronegativities.87 VSA_Estate is the MOE type descriptor using EState indices and surface area contribution. MOE-based descriptors have shown their importance in predicting in silico toxicity in studies by Su et al.,88 Jain et al.,89 Chavan et al.90 and ToxiM.12

(4) Molecular fragments and substructures: Fingerprints are a way of encoding the structure of a molecule in a binary form representing the presence or absence of particular substructures. Estate fingerprints (electropological), MACCS fingerprints (cover functional groups, ring systems), Morgan fingerprints (circular), Klekota-Roth fingerprint91(chemical substructures enriched for biological activity) and graph-based fingerprints are the crucial fingerprints in the top 50 features. Ext fingerprint is an extension of the CDK fingerprint, which takes into account the nature of the ring, including rich structural information92 and is a part of the important feature list. These features' importance confirms that the structural and molecular properties of the compound are crucial for learning the relationship between molecules and their toxicity. These fingerprints have also been used repeatedly by several methods in this field by Feng et al.,93 Sharma et al. in ToxiM,12 and Zhang et al.94

## Section: Results and discussions › Selection of optimal hyperparameters › LightGBM

The objective function of Bayesian optimization is to maximize the metric ‘AUC’ while finding the best combination of the hyperparameters. The default boosting algorithm used by LightGBM is Gradient Boosting Decision Tree (GBDT). But generally, the gradient-boosting trees suffer from overspecialization i.e. trees added at the later iterations contribute to the prediction of only a few samples and ignore the others. On the other hand, the addition of dropouts in DART (Dropouts meet Multiple Additive Regression Trees) makes it difficult for trees at later iterations to specialize, hence improving performance. Hence, the boosting_type hyperparameter is set to ‘dart’. DART uses dropout similar to the neural network and helps in the regularization of trees.

The eight hyperparameters selected through Bayesian optimization mentioned in Table 5 govern the efficacy and speed of the algorithm. L2 regularization has been applied to determine optimal features through Bayesian optimization without overfitting. The number of leaves (num_leaves) is the maximum number of leaves each weak learner has and is an important parameter that governs the model complexity. The number of leaves should be theoretically less than 2^max_depth, where max depth determines the maximum depth each tree can traverse while still growing leaf-wise.

## Section: Results and discussions › Selection of optimal hyperparameters › Random Forest

Bayesian Optimization was performed to select the optimal hyperparameters for the random forest classifier while maximizing the accuracy. A set of five hyperparameters and their corresponding search spaces used in the optimization process are mentioned in Table 6 The criterion used for splitting nodes was chosen between ‘entropy’ and ‘gini’. The optimal criterion selected was ‘entropy’. Entropy is a measure of impurity in a set of samples. In the context of random forest, it quantifies the disorder or randomness in the target variable i.e. toxicity label distribution within a node. So, the RF algorithm selects the node that minimizes the entropy impurity. Other hyperparameters include the number of decision trees in a random forest, the depth of each tree, and the minimum number of samples required to split the node.

## Section: Results and discussions › Selection of optimal hyperparameters › Multi layer perceptron

The architecture of the MLP used in this study is as follows:

In the input layer, the number of neurons is set to the number of features for a record in the training data. In this case, the number of neurons in the input layer is 2313; one neuron for each feature. For classification tasks, the number of neurons in the output layer corresponds to the number of class labels. In this model, there is one neuron in the output layer with a sigmoid activation function for the binary classification problem. The MLP classifier used in this model consists of three hidden layers with 1024, 256, and 64 neurons, respectively. These hidden layers apply the rectified linear unit (ReLU) activation function, which introduces non-linearity to the model and helps capture complex patterns in the data. In addition to that three dropout layers are also added to prevent overfitting of the model. The optimizer used for weight optimization is the “Adam” optimizer, a stochastic gradient-based optimizer. The model is trained for a maximum of 10 iterations with a batch size of 32. This means that the model processes the training data in batches of 32 samples per iteration. The complete architecture of the neural network architecture is illustrated in Figure S1.† Furthermore, to mitigate overfitting, additional parameters such as learning rate, dropout rate, and regularization strength are optimized. The details of these are provided in Table 7.

## Section: Results and discussions › Toxicity label prediction

In order to predict the toxicity of molecules using machine learning, the choice of model is crucial. The proposed method aims to enhance the efficiency and accuracy of toxicity prediction, with a focus on improving the identification of true positive instances while maintaining overall prediction quality. A stacked model approach is employed, which combines multiple base classifiers including random forest (RF), multi-layer perceptron, and LightGBM.

To assess the performance of our stacked model, it is compared against its base classifiers, namely RF, multi-layer perceptron, and LightGBM. Hyperparameters for all the base models are tuned using stratified 5-fold cross-validation on the training data.

By combining bagging and boosting models in a stacked ensemble, the strengths of both techniques are being leveraged. Bagging models help reduce variance and provide stable predictions while boosting models reduce bias and capture complex relationships.95 Furthermore, by incorporating a neural network into the stacked model, its strengths in capturing non-linear relationships, feature extraction, and generalization,96 lead to improved predictive accuracy and overall model performance.

The prediction results of the test and external validation set under different classifiers are shown in Table 8. In order to evaluate the robustness of the models, ROC and precision–recall curves have been plotted in Fig. 6, which shows the performance of the stacked model as compared to the base classifiers for predicting the toxicity of molecules. Since the stacked model is built on the CV results of its base classifiers, and doesn't have cross-validation results of its own, the test data is used to evaluate and compare its performance with the individual base learners. The AUROC curve in Fig. 6A illustrates that the stacked model outperforms the individual base classifiers, exhibiting a higher AUROC of 87.76% for the test set. This represents a significant improvement compared to the random forest (RF) classifier, which had an AUROC of 1.82% lower, the MLP classifier with an AUROC of 1.58% lower, and the LightGBM classifier with an AUROC of 1.59% lower (AUROC CV results in ESI†). Similarly, for the external validation set, the stacked model achieves an AUROC of 88.84%, surpassing the MLP classifier by 3.76%, the random forest classifier by 2.45%, and the LightGBM classifier by 0.64% as shown in Fig. 6C. These results demonstrate a substantial improvement and further highlight the effectiveness of the developed stacked model in capturing complex patterns and making accurate predictions on unseen data.

Fig. 6B and D depicts Area under precision–recall Curve (AUPRC) for both the test set and external validation set, which is based on precision and recall as described in Section 2.7. AUPR is also one of the most robust evaluation metrics and gives the average of precision scores calculated for each recall threshold, giving a better understanding of positive class as compared to negative class. The stacked model achieves an AUPRC of 86.37% on the test set, outperforming the LightGBM classifier by 2.51%, the random forest classifier by 1.65%, and the MLP classifier by 2.16%. The external validation data also follows the same trend, these values indicate that the stacked model has a higher precision–recall trade-off, resulting in better classification performance and a higher proportion of correctly predicted positive instances.

A classification method with high accuracy and precision, and with the lowest misclassification rate, is considered to be the most intelligent classifier for prediction purposes.97 In Fig. 7A and B, different metrics like accuracy, F1-score, MCC, specificity, and sensitivity have been reported. When comparing the performance of the stacked model with its base classifiers, it can be observed that the stacked model achieves a higher accuracy of 80.91% for the test set and 82.22% for the external validation set. This is an improvement over the individual base classifiers of LightGBM, MLP, and random forest for the test and external validation set. While accuracy is a commonly used metric for evaluating model performance, it alone may not provide a comprehensive assessment of the model's effectiveness.

For this case, the stacked model achieves an F1 score of 76.43% on the test set and 78.67% on the external validation set indicating that it strikes a good balance between correctly identifying toxic molecules (recall) and avoiding misclassification of non-toxic molecules (precision). This implies that the stacked model performs well in correctly predicting both toxic and non-toxic molecules, reducing both false positives and false negatives.

When comparing the performance of the different models based on the Matthews Correlation Coefficient (MCC), it is observed that the Stacked Model achieves an MCC of 0.61 on the test set, outperforming LightGBM with an MCC of 0.5730, MLP with an MCC of 0.5698, and random forest with an MCC of 0.5816. While for the external validation set, the stacked model also shows competitive performance with an MCC of 0.6396.

In the context of toxicity prediction, sensitivity is crucial as it represents the ability of the model to correctly identify true positive i.e. toxic instances. Therefore, it is essential to evaluate the model's performance not only based on accuracy or MCC but also considering sensitivity to ensure correct predictions of toxic molecules. The stacked model has better sensitivity for both datasets i.e. 0.7118 for the test set and 0.7375 for the external validation set. Additionally, the Stacked Model also exhibits good specificity, which corresponds to the non-toxic class, indicating its ability to accurately classify both toxic and non-toxic molecules. Unlike some instances of the base classifiers that may exhibit bias toward a specific class, the stacked model shows balanced classification performance for both classes.

As can be seen from Table 9 the performance of Stacked Model seems to outperform the base learners. To further evaluate the statistical significance of these results a corrected version of McNemar's test is employed. χ2 and p-value have been compared between the stacked model and the base learner models based on McNemar's contingency table. The contingency tables of comparison w.r.t stacked model are mentioned in the ESI.†

McNemar's statistical analysis supports the finding that the stacked model outperforms random forest, multi-layer perceptron, and LightGBM, as their p-values (Table 9) are below significance level of 0.05, indicating significant differences in performance.

## Section: Results and discussions › Comparison with eToxPred

The performance of the proposed method is also compared with an existing publicly available toxicity prediction tool for small molecules i.e. eToxPred.13 It employs an Extra Trees Classifier to compute the Tox-score ranging from 0 (low probability of toxicity) to 1 (high probability of toxicity). The model takes SMILES as input and employs molecular fingerprints directly from compounds to predict toxicity. The eToxPred model has been compared with MolToxPred on the test set and the external validation set.

As can be depicted from Fig. 6A and B, on comparison of AUROC scores of the stacked model and eToxPred classifier, the stacked model clearly outperforms in both the cases of the test set and external validation set by 14.91% and 6.88% respectively.

The performance of the stacked model as compared to eToxPred can be further evaluated on various evaluation metrics. eToxPred shows moderate performance on the test set and external validation set, with accuracy ranging from 62.97% to 71.11%. However, when compared to the stacked model, their performance was lower.

In the case of eToxPred, the F1 score is 0.6593 for the test set and 0.73 for the external validation set. These scores suggest a moderate level of accuracy in predicting toxic molecules. However, when these scores are compared with the stacked model's F1 score of 0.7643 for the test set and 0.7867 for the external validation set, it can be clearly seen that the stacked model outperforms the predictive performance of eToxPred. The stacked model demonstrates a better balance between precision and recall, enabling it to effectively predict both toxic and non-toxic molecules.

Although the goal of any toxicity prediction tool is to accurately predict toxic molecules, but it is equally important to have a tool that generalizes well and is not biased towards any particular class. It can be observed that eToxPred seems to be biased towards one class, as evidenced by the sensitivity and specificity values.

The stacked model, on the other hand, demonstrates better performance in terms of sensitivity, specificity, and other metrics. This suggests that the MolToxPred has a more balanced prediction capability and can better generalize to both toxic and non-toxic molecules.

A few test cases have been mentioned here demonstrating MolToxPred outperforming eToxPred. Aflatoxins, which are carcinogenic mycotoxins produced by Aspergillus fungi, have been associated with contamination of the global food supply. Aflatoxin B1 (AFB1), recognized as the most potent natural carcinogen98 among these compounds, has been scientifically linked to the development of hepatocellular carcinoma (HCC) in both humans and animals.99 Additionally, its hydroxylated metabolite, aflatoxin M1,100 found in milk and milk products, exhibits similar toxicity to AFB1.101 MolToxPred accurately predicts the toxicity of this class of small molecules with high probability, while eToxPred incorrectly categorizes them as non-toxic.

Oleandrin, a plant metabolite plays a role in traditional medicinal practices102 to treat various diseases. At the same time, oleandrin is highly toxic and gets easily accumulated in vivo, which may lead to life-threatening intoxication.103 It can also cause both gastrointestinal and cardiac effects.104 While eToxPred misclassifies this plant toxin as non-toxic, MolToxPred accurately predicts its toxicity.

ε-Amanitin is one of the eight Amatoxins found in different genera of poisonous mushrooms, most notably Amanita phalloides. Its mechanism of action involves inhibiting RNA polymerase II, which results in the halting of protein synthesis and disruption of cell metabolism, ultimately leading to cell death.105 ε-Amanitin is known to cause liver and kidney damage, with the most severe cases being toxic hepatitis characterized by centrilobular necrosis and hepatic steatosis.106 In terms of toxicity prediction, MolToxPred correctly identifies ε-Amanitin as highly toxic, whereas eToxPred may not provide the same level of accuracy.

## Section: Towards identifying the correlation between structural alerts and biological pathways for toxicity

The interaction between a chemical compound and the human body can be a complex cascade of different molecular pathways. Understanding the possible relationship between the biological pathway and the substructures that activate a specific characteristic of a molecule, may be helpful in identifying Structural alerts (SAs). Structural alerts are chemical substructures whose presence in compounds is associated with specific types of toxicity/activity. Structural alerts (SAs) based methods are computationally simple and structurally transparent in silico methods to identify the toxic compounds.107

Typically, methods used to identify structural alerts can be broadly categorized as fragment-based, graph-based, or fingerprint-based approaches. Yang et al.108 demonstrated that fragment-based methods are more effective in accurately identifying structural alerts within chemical structures. In the current study, SARpy,17 a recursive fragmentation-based method, has been employed to identify structural alerts for each assay of Tox21 data. Given the training set of molecular structures from each Tox21 assay, with their experimental activity binary labels, SARpy generates every substructure in the set and mines correlations between the incidence of a particular molecular substructure and the activity of the molecules that contain it.17 Here the target activity label has been set as ‘positive’ for the extraction of structural alerts. In the implementation of SARpy, the fragment size was set to a minimum of 2 and a maximum of 18 atoms. Further to this, a substructure was considered as a SA if it occurs in the minimum of 3 molecules in the dataset for that assay. The precision was set to minimize the false negatives and only the positive rules (active substructures) were extracted with the likelihood ratio threshold of more than 2 for each SA.

These efforts yielded approximately 400 unique SAs across all 12 assays. The specific SAs obtained for each assay are detailed in the ESI in Fig S4–S15.† These SAs may serve as distinctive identifiers for their respective biological pathways. The presence of a particular substructure within a molecule may be helpful in providing a potential correlation with the toxicity-related pathway associated with that molecule.

In order to find an association between a new molecule and any of the Tox21 pathways, substructure matching was conducted on the test set of the Tox21 challenge. This set of 266 molecules encompassed both bioactive molecules with activity in one or more pathways and bioinactive molecules with no activity in any of the pathways across all assays, thereby validating the SAs identified by SARpy from the Tox21 train set.

The substructure-matching results across each assay of the Tox21 test set are mentioned in the ESI.† Across all assays, the test data is aggregated based on whether a molecule exhibits activity in any of the assays within the Tox21 test set. Molecules showing activity are categorized as having a positive label (125), while those consistently showing inactivity across all assays are categorized as having a negative label (171). One critical observation is the relatively high number of True Positives (TP) at 116, signifying the accurate identification of endpoints in molecules because of activity in at least one assay within the Tox21 test set. This is indeed a promising outcome as it demonstrates the approach's ability to detect potentially hazardous compounds effectively. However, it is equally important to address the high number of False Positives (FP) at 150. These false positives represent cases where the algorithm erroneously identified molecules as active when they are, in fact, inactive across all assays. The high number of false positives can also be attributed to the limited number of labeled Tox21 test set. This can also be seen in cases like aniline which is part of FP still, the compound is classified as Group B2, a probable human carcinogen by EPA, and causes serious eye damage and allergic reactions.109 Similarly phenyldiazene is another SA which is FP here but is present in compounds like pesticide fipronil110 and fungicide Pyraclostrobin which can lead to disrupting CNS activity and secondary hepatotoxicity respectively.110,111

To improve the overall performance, it is evident that further refinement is required, particularly in reducing the number of false positives. This is where the availability of more labeled data (quantity and quality both) and expert opinion becomes crucial in identifying the relevance of SAs.

The reported structural alerts belong to phenols, aminophenols, furan, and nitroamine and have also been reported by Dang et al.112 Additionally, this study reports the presence of certain halogen derivatives as SA that have also been identified as potential mutagens113 in the literature. Some small toxic radicals SAs identified in this study like N <svg xmlns="http://www.w3.org/2000/svg" version="1.0" width="13.200000pt" height="16.000000pt" viewBox="0 0 13.200000 16.000000" preserveAspectRatio="xMidYMid meet"><metadata> Created by potrace 1.16, written by Peter Selinger 2001-2019 </metadata><g transform="translate(1.000000,15.000000) scale(0.017500,-0.017500)" fill="currentColor" stroke="none"><path d="M0 440 l0 -40 320 0 320 0 0 40 0 40 -320 0 -320 0 0 -40z M0 280 l0 -40 320 0 320 0 0 40 0 40 -320 0 -320 0 0 -40z"/></g></svg> N, N–N, N <svg xmlns="http://www.w3.org/2000/svg" version="1.0" width="13.200000pt" height="16.000000pt" viewBox="0 0 13.200000 16.000000" preserveAspectRatio="xMidYMid meet"><metadata> Created by potrace 1.16, written by Peter Selinger 2001-2019 </metadata><g transform="translate(1.000000,15.000000) scale(0.017500,-0.017500)" fill="currentColor" stroke="none"><path d="M0 440 l0 -40 320 0 320 0 0 40 0 40 -320 0 -320 0 0 -40z M0 280 l0 -40 320 0 320 0 0 40 0 40 -320 0 -320 0 0 -40z"/></g></svg> O, R–O–X, etc. have also been reported by previous studies.108 Polycyclic aromatic compounds like Anthracene and fluorene have also been identified as SAs. Studies show anthracene and its derivatives bind to estrogen and androgen receptors leading to embryotoxicity.114

It is important to emphasize here that some of the structural alerts are only highlighted here. These structural “alerts” should be regarded as hypotheses for potential undesirable mechanisms rather than strict rules. The generation of structural alerts by SARpy might identify redundant and over specific substructures. Hence more input from experts can help narrow down these SAs, but such approaches can work as providing a head start to pharmaceutical researchers.

## Section: Conclusion

Before releasing a product for human consumption, the computational toxicity prediction of any compound/molecule aids in the risk assessment procedure for both companies and regulatory bodies. A number of criteria, including compositional, structural, and molecular properties, must be considered when determining a chemical's toxicity. Machine learning-based methods have come to the rescue because these can automatically handle large datasets and perform statistical analysis to find patterns in data. As a result, in this study, a machine learning-based classification workflow was developed to predict the toxicity of molecules using a molecule's structural, molecular, and chemical properties.

The training dataset is curated to represent small molecules that humans come into contact with, such as drugs, metabolites, environmental pollutants, food toxins, and so on, and this dataset plays a role in good model performance. A stacked model was used to take advantage of diverse base classifiers each of which bring its own capabilities. An extensive feature selection method has been implemented to reduce redundant features that do not contribute to the prediction of toxicity. To find the best set of hyperparameters, Bayesian optimization with stratified 5-fold cross-validation was used to avoid overfitting. The tool's effectiveness is validated by reported different evaluation metrics such as AUROC, F1-score, and accuracy in predicting a molecule as toxic or non-toxic. Permutation Importance across the base classifiers has been used to explain the significance of the selected features in predicting toxicity. The developed model's performance was evaluated using both a test set and an external validation set. The proposed method also outperformed the eToxPred tool in terms of performance, which shows this method is at par with existing methods. The performance is attributed to robust data curation: a combination of fingerprints & descriptors, the addition of metabolites and intensive feature selection, and rigorous hyperparameter tuning.

The test and validation set results confirm not only the importance of these properties but also lay the ground for machine learning in toxicity applications. In addition to this, the study also identified a number of structural alerts, shedding light on potential toxic pathways and risks associated with various molecules. These findings can serve as valuable hypotheses for further research, emphasizing the need for expert input to refine and optimize these alerts. One significant challenge when employing AI-based methods and structural-based approaches for drug toxicity prediction is the insufficient availability of high-quality data.115,116 The development of high-performing models in both AI and structural-based approaches relies on having an ample quantity of training data, coupled with the verification of its quality. Despite the increasing volume of publicly accessible toxicity data, the quality of such data remains a constraining factor. Nevertheless, this workflow will assist the scientific community in determining a molecule's or compound's physiological and environmental toxicity and its association with toxicity related biological pathways before moving forward in the drug development pipeline.

## Section: Data availability

The tool and data are available at https://github.com/bioinformatics-cdac/MolToxPred.

Given a new molecule as input the MolToxPred CLI tool, will calculate and provide the probability of the molecule being toxic. This probability score indicates the likelihood that the given molecule may exhibit toxic properties. A higher probability suggests a higher likelihood of toxicity. The output will also include information about the plausible Tox21-based endpoints associated with the molecule.

## Section: Conflicts of interest

There are no conflicts of interest to declare.

## Section: Acknowledgments

The authors gratefully acknowledge the Ministry of Electronics and Information Technology (MeitY), Government of India, New Delhi, and National Supercomputing Mission (NSM) for providing financial support.

## Section: Associated Data › Data Availability Statement

The tool and data are available at https://github.com/bioinformatics-cdac/MolToxPred.

Given a new molecule as input the MolToxPred CLI tool, will calculate and provide the probability of the molecule being toxic. This probability score indicates the likelihood that the given molecule may exhibit toxic properties. A higher probability suggests a higher likelihood of toxicity. The output will also include information about the plausible Tox21-based endpoints associated with the molecule.


---

# Morphological profiling for drug discovery in the era of deep learning

- **Authors:** Qiaosi Tang, Ranjala Ratnayake, Gustavo Seabra, Zhe Jiang, Ruogu Fang, Lina Cui, Yousong Ding, Tamer Kahveci, Jiang Bian, Chenglong Li, Hendrik Luesch, Yanjun Li
- **Issuer:** Briefings in bioinformatics
- **Type:** Scientific article
- **Published:** 2024-05-23
- **Language:** en
- **DOI:** 10.1093/bib/bbae284
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38886164/
- **Licence:** CC-BY

## Section: Abstract

AbstractMorphological profiling is a valuable tool in phenotypic drug discovery. The advent of high-throughput automated imaging has enabled the capturing of a wide range of morphological features of cells or organisms in response to perturbations at the single-cell resolution. Concurrently, significant advances in machine learning and deep learning, especially in computer vision, have led to substantial improvements in analyzing large-scale high-content images at high throughput. These efforts have facilitated understanding of compound mechanism of action, drug repurposing, characterization of cell morphodynamics under perturbation, and ultimately contributing to the development of novel therapeutics. In this review, we provide a comprehensive overview of the recent advances in the field of morphological profiling. We summarize the image profiling analysis workflow, survey a broad spectrum of analysis strategies encompassing feature engineering– and deep learning–based approaches, and introduce publicly available benchmark datasets. We place a particular emphasis on the application of deep learning in this pipeline, covering cell segmentation, image representation learning, and multimodal learning. Additionally, we illuminate the application of morphological profiling in phenotypic drug discovery and highlight potential challenges and opportunities in this field.Keywords: artificial intelligence, deep learning, morphological profiling, drug discovery

## Section: Introduction

Phenotypic drug discovery (PDD) plays a crucial role in drug discovery. In contrast to target-based drug discovery (TDD), where compounds are designed to interact with known target molecules, PDD takes a target-agnostic approach and focuses on phenotypic effects of compound treatment in disease-relevant biological systems [1, 2] (Fig. 1A and B). This strategy uses reference compounds with treatment class annotations to uncover previously unknown mechanisms of action (MOAs) of the test compounds. To date, PDD has made a significant contribution to the development of first-in-class drugs and the discovery of novel therapeutic opportunities [1, 2]. For example, PDD is the primary approach in natural products discovery and the basis for identification of new targets and/or MOAs. Natural products are all bioactive, and the most effective way to multiplex and assign function is through phenotypic screening, particularly by analyzing related biased and unbiased nuances from high-content imaging [3–6].

Automated microscopy and image analysis have enabled high-throughput image-based assays for PDD [1, 7]. The two approaches, namely, high-content screening (HCS) and morphological profiling, are both based on imaging experiments at a large scale, yet distinct in strategy (Fig. 1C and D). In HCS, feature measurements are limited to specific phenotypes related to perturbations. In contrast, morphological profiling (also known as image-based profiling or cytological profiling) is an unbiased approach to capture high-dimensional image data consisting of hundreds to thousands of cellular features. Conventionally, bioimage informatics tools can measure these features that span a range of morphological properties to generate phenotypic signatures for clustering and predicting perturbation bioactivity similarity [7, 8]. To this end, this approach not only provides a comprehensive morphological profile in an unbiased manner but also allows for detecting subtle or novel phenotypes.

As a dominant technique in artificial intelligence (AI), deep learning uses deep neural networks to learn representations from raw data format in a data-driven manner, often without the needs of feature engineering [9]. In the context of drug discovery, deep learning enables efficient development of novel therapeutics through various applications, such as target identification [10, 11], protein structure prediction [12, 13], drug–target interaction prediction [14–16], de novo drug design [17, 18], molecular property prediction [19, 20], and biological image analysis for PDD [21, 22]. In recent years, computer vision has led to a profound transformation of image-based profiling analysis in efficiency and performance, thereby expediting drug discovery and reducing computational cost [22, 23].

In this review, we aim to provide a comprehensive overview of the extant computational approaches employed in morphological profiling with a particular emphasis on the deep learning applications. We primarily focus on the analytical pipeline of Cell Painting high-content image data given its wide application in academic research and pharmaceutical industry. We start with an introduction of Cell Painting image analysis workflow with conventional feature-engineering approach (also known as ‘handcrafted’ representation). For the major focus, we provide a thorough summary of recently proposed deep learning approaches in advancing this analytical pipeline, including microscopic image cell segmentation, representation learning from high-content fluorescent images, and multimodal learning to integrate chemical structure and omics data for MOA prediction. With concrete examples in cutting-edge applications, we conclude with our perspectives on future directions in advancing morphological profiling with deep learning solutions (Fig. 2).

Early-stage drug discovery approaches. (A) and (B) illustrate two primary approaches in drug discovery: target-based drug discovery (TDD) and phenotypic drug discovery (PDD). (A) TDD starts with a known drug target, and a target-based assay is established to evaluate the effect of compound–target interaction. (B) In contrast, PDD employs a target-agnostic strategy, screening compounds to determine whether a phenotype of interest is induced. Due to its unbiased nature, a target identification step is required. Within the context of PDD, (C) high-content screening (HCS) and (D) morphological profiling are two commonly used approaches. The major difference is (C) HCS uses a limited number of perturbation-specific phenotypes as assay readout, whereas (D) morphological profiling obtains cellular feature representation with an unbiased approach.

Schematic workflow of morphological profiling. After cells are perturbed and stained, fluorescent images are taken to capture cellular morphology. Single cells are detected and segmented. At the single-cell level, morphological features can be achieved with image analysis software to extract pre-defined features. Alternatively, feature vectors can be obtained through representation learning with a deep neural network. Features from single cells are subsequently aggregated into a treatment-level morphological profile. Certain deep learning models allow end-to-end learning, eliminating the need for cell segmentation. The resulting morphological profile is then applied to downstream tasks such as classification for MOA prediction and clustering for treatment association inference (left panel). Additionally, other profile modalities, such as chemical structure and transcriptomic and metabolomic profiles, can be integrated with the morphological profile to enhance downstream analysis (middle panel). Altogether, these efforts enable many novel downstream applications, such as characterizing perturbation impacts in dynamics, constructing gene function network to map genotype–phenotype relationship, identifying compound MOAs in 3D organoid model, and guiding de novo hit design (right panel).

## Section: Deep learning in morphological profiling analytical pipeline

Publicly available cellular microscopic image datasets for model training and evaluation

Recent publication trend of morphological profiling with deep learning. Pubmed trend demonstrates a growing number of indexed publications on morphological profiling with deep learning, including the keywords ‘deep learning’ with ‘morphological profiling’ or ‘image-based profiling.’ This trend is analyzed from 2014 to 2022.

An overview of key methods and the state-of-the-art approaches in morphological profiling data analysis. Cellular images from morphological profiling assays can be analyzed using two approaches: stage-wise feature-based (top panel) and end-to-end deep learning-based (bottom panel). In the feature-based approach, image data are analyzed in four sequential stages: Stage 1 involves image preprocessing, single-cell segmentation, and feature extraction, Stage 2 aggregates cell-level features into well-level or treatment level profiles, and Stage 3 classifies each profile into the corresponding treatment class and clusters each profile based on phenotypic similarity. In contrast, deep learning–based approaches perform analysis in an end-to-end fashion with different learning paradigms. We illustrate these state-of-the-art approaches on a timeline to highlight their development.

A selection of open-sourced image analysis tools

Representation learning strategies for cell morphology. At the pre-training stage, several learning strategies can be applied. (A) Supervised representation learning employs a deep neural network trained on microscopic image data with the label (treatment class). (B) Transfer learning utilizes a deep neural network initially trained on other types of annotated image data, such as natural images, to learn representations applicable to microscopic images. The pretext task is to predict the image class. (C) Weakly supervised representation learning considers the treatment labels as the weak/noisy labels. A deep neural network is trained on a pretext task to predict the treatment class of the microscopic images. The learned feature embeddings will be used to infer treatment class similarity. (D) Self-supervised representation learning utilizes the data intrinsic information for model pretraining, such as microscopic image reconstruction. These pretext tasks enhance the model's ability to learn effective representations for major tasks. Following the pretraining stage, the fine-tuning stage transfers the learned knowledge to specific downstream tasks, such as classifying query perturbations to reference perturbations for MOA inference.

Model performance comparison by MOA classification accuracy on the BBBC021 dataset

Comparison of transcriptomic and morphological profiling data for drug discovery

Multimodal datasets with matched transcriptomic and morphological profiling data

Combine morphological data with other data modalities. The image data obtained from morphological profiling assays can be combined with other modalities of profiling data to perform downstream tasks jointly. One strategy involves training individual models to extract representations from each data modality, such as image data, chemical structural data, and transcriptomic data. These individual representations contribute to a joint embedding, which is subsequently utilized for downstream analyses.

## Section: Deep learning in morphological profiling analytical pipeline › Cell Painting and benchmark datasets

A state-of-the-art assay for morphological profiling is known as Cell Painting [24]. The canonical protocol on adherent monolayer cells uses six fluorescent dyes to characterize eight cellular components or organelles and images the fixed and stained cells in five channels on a high-throughput microscope [25]. Recent optimization efforts have further improved the assay’s capability in phenotype detection [26]. Whereas canonical Cell Painting captures cellular morphology in snapshots, technical advances now enable live-cell imaging, such as using reporter cell lines that carry organelle or pathway marker with fluorescent tag. This allows for capturing morphological profiles in dynamics [27].

Over the past decade, morphological profiling efforts from academia and pharmaceutical industry have produced several publicly available Cell Painting datasets. These include (i) the Broad Bioimage Benchmark Collection (BBBC) with compound and genetic perturbations [28–30], (ii) The Image Data Resource (IDR) with both HCS images and time-lapse images [31], (iii) the RxRx datasets released from Recursion with compounds, genetic and viral transduction perturbations, and (iv) the CytoImageNet dataset curated from 40 openly available and weakly labeled microscopy images [32]. Notably, the Joint Undertaking in Morphological Profiling Cell Painting (JUMP-CP) Consortium has recently been established as the largest public reference Cell Painting dataset [33], including images from more than 116 000 chemical perturbations and over 15 000 genetic perturbations on human osteosarcoma cells (U2OS), which were systematically acquired from 12 data-generating centers [33]. A subset of the JUMP-CP Consortium, cpg0016-jump, has been used in a recent benchmark study to evaluate self-supervised learning (SSL) methods and feature-based approaches [23]. This dataset includes single-source (data generated from a single laboratory) training set of 391 815 Cell Painting images from 35 892 compound treatments, and multisource (data generated from multiple laboratories) training set of 564 272 images from 10 057 compounds. The evaluation set includes 33 962 single-source images and 75 545 multisource images [23]. The curation of this dataset not only allows for assessing model performance using biological labels but also enables evaluation of batch effect handling [23]. An extension to this dataset, labeled CPJUMP1, has been curated to include pairs of chemical and genetic perturbations that both target the same genes in the settings of U2OS and human lung carcinoma epithelial cells (A549) [34]. This dataset consists of approximately 3 million Cell Painting images along with the feature-based profiles from 75 million single cells are well-level aggregated profiles. This unique dataset of paired annotated chemical and genetic perturbations allow for investigating gene–compound relationship [34]. These public reference datasets have been broadly used to train machine learning and deep learning models for compound bioactivity prediction and image representation learning for feature embedding. Details of these datasets are summarized in Table 1.

Among the above-mentioned datasets, the BBBC021 dataset [35] is the most commonly used benchmark to evaluate the performance of deep learning methods. This dataset, publicly available from the Broad Bioimage Benchmark Collection [28], includes Cell Painting images of human MCF-7 breast cancer cells treated with 113 compounds at eight concentrations. Most of the representation learning methods (section Representation Learning for Morphological Profiling) were compared on a subset of 103 treatments from 38 compounds. These compounds have been manually annotated with one of 12 MOAs as the ground truth. The effectiveness of different MOA prediction methods is assessed using the following evaluation metrics:

Publicly available cellular microscopic image datasets for model training and evaluation

## Section: Deep learning in morphological profiling analytical pipeline › An overview of image-based profiling data analysis

An accurate, efficient, and generalizable imaging data analysis workflow is critical for morphological profiling. Established methods and best practices have been comprehensively documented [39–43]. However, the past few years have witnessed significant strides in the application of deep learning approaches (Fig. 3). In this section, we present an overview of the critical stages in morphological profiling data analysis, with particular emphasis on deep learning advances (Fig. 4).

Recent publication trend of morphological profiling with deep learning. Pubmed trend demonstrates a growing number of indexed publications on morphological profiling with deep learning, including the keywords ‘deep learning’ with ‘morphological profiling’ or ‘image-based profiling.’ This trend is analyzed from 2014 to 2022.

An overview of key methods and the state-of-the-art approaches in morphological profiling data analysis. Cellular images from morphological profiling assays can be analyzed using two approaches: stage-wise feature-based (top panel) and end-to-end deep learning-based (bottom panel). In the feature-based approach, image data are analyzed in four sequential stages: Stage 1 involves image preprocessing, single-cell segmentation, and feature extraction, Stage 2 aggregates cell-level features into well-level or treatment level profiles, and Stage 3 classifies each profile into the corresponding treatment class and clusters each profile based on phenotypic similarity. In contrast, deep learning–based approaches perform analysis in an end-to-end fashion with different learning paradigms. We illustrate these state-of-the-art approaches on a timeline to highlight their development.

A selection of open-sourced image analysis tools

## Section: Deep learning in morphological profiling analytical pipeline › An overview of image-based profiling data analysis › Stage 1: Feature representation

Measuring variations in cell morphology upon perturbation relies on generating effective representations for cellular images. Conventionally, this task is implemented by feature engineering approaches. Bioimaging software like CellProfiler is commonly used to extract predefined features such as cell shape, size, and texture from fluorescent microscopy images [44]. In addition to CellProfiler, we have also summarized other open-source image analysis software and tools in Table 2. While this approach provides biologically insightful results, it requires image preprocessing and manual adjustment of parameters for every new experiment setup [39, 41]. Also, single-cell segmentation is typically required, which will be described in detail in section Deep Learning–Facilitated Cell Segmentation for Image Analysis.

Alternatively, deep neural networks such as pre-trained convolutional neural networks (CNNs) can learn representation directly from a full-field microscopy image without the need for single-cell segmentation [37, 45]. Further, generative adversarial network (GAN)–based models and variational autoencoder (VAE) framework have been proposed to improve the interpretation of cellular structural variations that drive morphological differences [46–48] and to predict morphological responses to perturbations [49]. These advances from deep learning-based analysis approaches will be further discussed in section Representation Learning for Morphological Profiling.

A selection of open-sourced image analysis tools

## Section: Deep learning in morphological profiling analytical pipeline › An overview of image-based profiling data analysis › Stage 2: Morphological profile generation

Once features are extracted from single cells or field images, these measurements will be aggregated into a single feature vector for well-level (also known as treatment-level or population-level) representation. The morphological profile generated from this stage will enable downstream well-level analysis [39].

## Section: Deep learning in morphological profiling analytical pipeline › An overview of image-based profiling data analysis › Stage 3: MOA annotation

With the aggregated treatment-level morphological profiles, a common machine learning task is to predict MOA or toxicity of query perturbagens based on the known morphological profiles of the reference library [40]. This is most commonly achieved by building a feature-based machine learning model such as nearest neighbor classifier, random forests, or Bayesian matrix factorization [39, 40, 50] on top of the extracted morphological profiles. With these supervised machine learning algorithms, query perturbagens can be classified into predefined, annotated classes [40]. The aggregated morphological profiles can also be used to infer treatment-level associations. This task is typically accomplished by employing hierarchical unsupervised clustering algorithms, predicted on the similarity of morphological profiles [40]. A phenotypic similarity matrix of all pair-wise similarities between morphological profiles is computed for similarity-based clustering [40].

Notably, deep learning techniques facilitate an end-to-end learning schema, integrating all the aforementioned stages into a singular, unified process. Within this framework, the phenotypic classification and clustering tasks can be directly accomplished using raw high-content images, circumventing the explicitly image feature representation, morphological profile generation, and other intermediate steps. This end-to-end learning schema will be elaborated in section Representation Learning for Morphological Profiling.

## Section: Deep learning in morphological profiling analytical pipeline › Deep learning–facilitated cell segmentation for image analysis

Cellular object detection and segmentation is a critical yet challenging step of microscopic image analysis. Whereas classical segmentation algorithms such as thresholding and watershed have been commonly used in bioimage analysis software [51], recent advances of deep learning in computer vision have generated various image segmentation models with substantially improved performance [52]. In the 2018 Data Science Bowl, a global competition focusing on 2D nucleus segmentation from high-content images, deep learning approaches such as U-Net, Feature Pyramid Network (FPN), and Mask-Regional Convolutional Neural Network (Mask-RCNN) dominated the leaderboard, achieving state-of-the-art performance [51]. We refer the interested readers to the report of the 2018 Data Science Bowl results for details in method and performance [51]. Each of these approaches demonstrates strengths and drawbacks. Initially designed for segmenting electron microscopy images, the U-Net model uses skip connections to append feature maps of the whole input image from the encoder to the decoder. This preserves global location information and allows for accurate reconstruction by the decoder. It can provide accurate segmentation maps with limited training data [53]. Like U-Net, FPN also leverages lateral connections. However, instead of copying and concatenating feature maps from encoder to decoder, 1 × 1 convolution is applied to allow for flexible processing [54]. In contrast to fully convolutional networks (FCNs) that use the full context of the input image, Mask R-CNN works on selected Regions of Interest (ROIs) of an input image to obtain predicted class, bounding box, and segmentation mask simultaneously. This method performs well on instance segmentation tasks to handle multiple objects with complex shapes, albeit more training examples are needed compared to U-Net [55].

A common limitation of those approaches is that their performances suffer when nuclei are packed densely. To address this challenge, STARDIST was developed to predict a flexible shape representation—a star-convex polygon instead of an axis-aligned bounding box is predicted for each pixel. When benchmarked on the 2018 data science bowl dataset, STARDIST outperformed U-Net or Mask R-CNN based models for intersection over union (IoU) threshold τ < 0.75 [56]. This method has also been successfully extended for 3D nuclei segmentation (STARDIST-3D) [57]. Fully convolutional regression networks (FCRNs) represent another solution to this challenge, regressing a cell spatial density map of the image. FCRNs demonstrated superior performance at microscopic cell counting when traditional single-cell segmentation fails due to cell clumping or overlap [58]. Another object shape representation approach is proposed by the Cellpose segmentation model. This approach generates topological maps through simulated diffusion and uses human-annotated masks as ground truth. The horizontal and vertical gradients of the topological maps are then predicted to form vector fields. Through gradient tracking, pixels that converge to the same center point are assigned to the same mask [59]. With this representation approach, the Cellpose model outperformed STARDIST, Mask R-CNN, and U-Net models at all IoU thresholds on the Cell Image Library dataset [59].

Another limitation of the above-mentioned segmentation approaches is that their training process is fully supervised, thus requiring considerable amount of expert annotations. To alleviate this requirement, Hollandi et al. proposed nucleAlzer, which uses image style transfer approaches to generate a set of representative image–label pairs. Applying this data augmentation paradigm to the Mask R-CNN-based model improved segmentation performance on several image datasets [60].

In addition to CNN-based models, recently, a novel deep learning architecture, CellViT, was proposed for nuclei segmentation in digitized tissue samples based on Vision Transformer (ViT) [61]. In contrast to CNN-based models, ViTs allow input images with arbitrary sizes and can capture long-range dependencies given the self-attention mechanism [62]. CellViT uses a U-Net-shaped encoder–decoder network, which leverages pre-trained ViTs such as ViT256 [63] and Segment Anything Model [64] (SAM) as the encoder network and bridges the encoder and decoder components at multiple network depths via skip connections [61]. Although it demonstrated SOTA performance on a histological image dataset [61], it remains to be investigated whether this model can be generalized to the single-cell segmentation task for Cell Painting datasets.

## Section: Deep learning in morphological profiling analytical pipeline › Representation learning for morphological profiling

Feature representation is a critical step in morphological profiling. Morphological features can either be extracted through feature-engineering approach or learned with deep neural network [65]. The former approach, however, requires manual efforts in fine-tuning software parameters per experiment setup and relies on expert knowledge to decide what phenotypic features should be measured. In contrast, deep neural networks take an unbiased approach to learn features directly from raw pixels of images and encode meaningful representations [66]. Not only do these end-to-end trained deep neural networks obviate the need for any segmentation steps but also the learned representation enables superior performance. Moreover, these networks exhibit improved transferability across different perturbation types (chemical versus genetic) and demonstrate faster pipeline processing speeds in classification tasks compared to models trained on engineered features [23, 67, 68] (Fig. 5).

Representation learning strategies for cell morphology. At the pre-training stage, several learning strategies can be applied. (A) Supervised representation learning employs a deep neural network trained on microscopic image data with the label (treatment class). (B) Transfer learning utilizes a deep neural network initially trained on other types of annotated image data, such as natural images, to learn representations applicable to microscopic images. The pretext task is to predict the image class. (C) Weakly supervised representation learning considers the treatment labels as the weak/noisy labels. A deep neural network is trained on a pretext task to predict the treatment class of the microscopic images. The learned feature embeddings will be used to infer treatment class similarity. (D) Self-supervised representation learning utilizes the data intrinsic information for model pretraining, such as microscopic image reconstruction. These pretext tasks enhance the model's ability to learn effective representations for major tasks. Following the pretraining stage, the fine-tuning stage transfers the learned knowledge to specific downstream tasks, such as classifying query perturbations to reference perturbations for MOA inference.

Model performance comparison by MOA classification accuracy on the BBBC021 dataset

## Section: Deep learning in morphological profiling analytical pipeline › Representation learning for morphological profiling › Supervised representation learning

When extensive annotated training data is available, supervised representation learning become particularly effective [69, 70]. For example, Kraus et al. trained CNNs combined with multiple instances learning on annotated image dataset BBBC021 and yielded higher accuracy in treatment classification compared to the conventional feature-engineering approach [28, 36, 69, 71]. Similarly, Godinez et al. built a multi-scale convolutional neural network (M-CNN) based classifier, which was trained on the same annotated images [70]. This model outperformed other CNN models on classification tasks when benchmarked on several BBBC datasets.

## Section: Deep learning in morphological profiling analytical pipeline › Representation learning for morphological profiling › Transfer learning

However, the availability of relevant annotated image data may not always be assured, and the collection of sufficient training data can be expensive and time-consuming. To that end, transfer learning of pre-trained deep neural networks becomes an alternative solution [72]. Pawlowski et al. for the first time proposed using ImageNet pretrained CNNs for morphological profiling feature representation, and this method achieved superior accuracy and processing speed compared to the feature engineering–based approach [73]. Similarly, Ando et al. proposed Deep Metric Network, a model pre-trained on ~100 million RGB consumer images, to generate embeddings for the BBBC021 image set [37]. Many other CNNs pre-trained on ImageNet have also been used to generate cell morphology embeddings [74, 75].

## Section: Deep learning in morphological profiling analytical pipeline › Representation learning for morphological profiling › Weakly supervised representation learning

In addition to transfer learning, weakly supervised learning (WSL) approach has been proposed to train deep neural networks for learning representations of Cell Painting images [38, 76, 77]. In this learning schema, treatment or compound labels are treated as “weak” or “noisy” labels for several reasons: (i) cells may exhibit heterogeneous responses even to the same treatments; (ii) some treatments are biologically inert; however, in the context of the supervised learning setting with treatments as labels, a deep neural network is nonetheless compelled to identify differences; and (iii) different cell morphology may result from technical artifacts. Therefore, it remains uncertain whether treatment labels accurately reflect cell morphology. To leverage the weak labels, an auxiliary (or pretext) training task is introduced to train a network to classify single cell images to their corresponding treatment labels (the weak labels). Feature embeddings learned from the auxiliary classification task will subsequently be used for the major task, which is to infer the high-level associations between treatments based on similarity. In the setting of drug discovery, this allows for MOA prediction through assigning query compounds to a library of annotated reference compounds [38, 76–78]. Given that these deep neural networks are exposed to the distributions of both true biological phenotypes and confounding factors in the pretext training task, disentangling phenotypes from confounding factors is crucial to the success of this training schema. To achieve this, besides batch correction efforts (summarized in section Challenges and Outlook), a few other strategies have proven to be helpful, such as RNN-based regularization [38], convex combinations of images to generate new samples [38], and combining image datasets with strong perturbations for training [76]. Beyond representation learning with broadly used CNNs, WS-DINO from Cross-Zamirski et al. was proposed to learn representations using a knowledge distillation approach with ViT backbone. In this approach, global and local crops from different images under the same treatment are generated [77]. The teacher network is exposed solely to global crops, whereas the student network sees both, and the objective is to minimize the cross-entropy loss between student and teacher prediction output. Notably, in contrast to many other WSL approaches, WS-DINO does not require single cell cropping for pre-processing [77].

## Section: Deep learning in morphological profiling analytical pipeline › Representation learning for morphological profiling › Unsupervised representation learning

Finally, unsupervised learning approaches provide another avenue for feature representation learning by identifying underlying patterns in raw data or clustering similar data into groups. Examples of such exploitable unlabeled information include whether images belong to the same treatment [79], metadata information [80], and pseudo-labels assigned by K-means clustering on embeddings [81]. Another strategy is to use generative models [82] such as GANs [46] or VAE framework [47, 48] to learn feature representations. They function by learning and generating new data distributions that are similar to the training data, thereby learning inherent structures and patterns within the dataset. In addition, the self-supervised learning (SSL) approach can use a pretext training task, mining the intrinsic information present in the data itself, to train a CNN capable of learning effective feature representation and use it for downstream analysis [83]. For the pretext task, Lu et al. proposed “paired cell inpainting,” whereby the model needs to identify protein localization from the “source” cell and predict the similar localization in the “target” cell [83]. The contrastive loss–based approach can also learn robust cell representations by training the model to bring positive example representations closer in the feature space and push the negative example representations further away from the positive ones [84]. Perakis et al. demonstrated that representations learned with the contrastive learning framework can be used in MOA classification task with the impressive performance on par with the transfer learning approach [37, 84]. Beyond the CNN-based model, the SSL method has also been employed to pre-train the ViT architecture, resulting in significant enhancements even in segmentation-free morphological profiling [23, 85]. In evaluations using subsets of the JUMP-CP Consortium data, the ViT architecture, trained by the recently introduced DINO SSL approach, outperformed both CellProfiler and transfer learning–based methods in several dimensions. Specifically, when trained on multisource data, this approach demonstrated the best performance in classification tasks. The resultant image representations showcased exceptional adaptability, transitioning efficaciously from chemical to genetic perturbations. Moreover, the pipeline functioned at speed 50 times faster than CellProfiler-based feature engineering workflow [23]. It is noteworthy that, unlike CNNs where local features are consolidated into aggregated vectors, ViTs preserve a more refined resolution of inputs across all network layers, and this preservation facilitates the encoding of features that are biologically meaningful at the subcellular level [85]. Notably, ChannelViT has been proposed to make a simple modification to the ViT architecture by constructing patch tokens independently from each input channel and includes a learnable channel embedding. These modifications improve model reasoning across channels, such that the model can generalize efficiently even when limited input fluorescent channels are available. When trained with DINO algorithm, ChannelViT consistently outperforms standard ViT on input images with varying sets of fluorescent channels [86]. Altogether, these findings underscored the formidable efficacy and robustness of SSL approaches in morphological profiling.

Most of the representation learning approaches described in this section have been benchmarked on the BBBC021 dataset with these evaluation metrics. Their performance is summarized in Table 3. From this comparison, WS-DINO, the weakly supervised method from Cross-Zamirski et al. [77] achieved the best performance. The transfer learning method from Ando et al. [37] and the self-supervised contrastive learning method from Perakis et al. [84] also showcased strong performance in learning meaningful phenotypic embeddings.

For deep learning approaches to achieve decent performance in morphological profile analysis, factors such as image dataset characteristics, model complexity, and computational resources must be carefully considered. Increasing the size and diversity of the training set, for example, by including image sets acquired from different laboratories, serves as an effective factor in enhancing performance, more so than simply increasing the model size [23]. In addition, applying appropriate image augmentations significantly benefits the performance of SSL methods such as DINO. Particularly, applying color augmentation on each fluorescent channel independently, through random brightness changes and intensity shifts, has been shown to produce the most significant positive impact on model performance [23]. In terms of computational time and costs, DINO with Graphics Processing Unit (GPU) acceleration can process and analyze data significantly faster than feature-based approaches, and despite requiring GPUs, it incurs lower infrastructure costs for analyzing per cell plate [23].

Model performance comparison by MOA classification accuracy on the BBBC021 dataset

## Section: Deep learning in morphological profiling analytical pipeline › Integrating morphological data in multimodal learning for drug discovery

With the advances in biotechnology, a wealth of data from various modalities can be generated and collected to facilitate drug discovery. Cheminformatics, for example, has made substantial contribution to drug discovery through analysis and representation of chemical structures and exploiting the similarity principle [87]. Chemical structure data of compounds are always readily available, and predicting compound bioactivity based on this data modality can be performed virtually. However, elucidating the intricate relationship between structure and biofunction is a challenging task [87]. On the other hand, ‘Omics’ profiles, such as genomics, transcriptomics, proteomics, and metabolomics, can characterize treatment outcomes from different aspects. However, assay cost and scalability emerge as major concerns for high-throughput studies [88]. Indeed, every modality of data utilized in the drug discovery presents its unique set of advantages and disadvantages. A detailed comparison is summarized in Table 4. Integrating these modalities is promising to maximize their potentials and mitigate the limitations, thereby providing a comprehensive understanding of treatment effects. Notably, recent research has shown that different data modalities, such as chemical structure, morphology, and gene expression, exhibit complementary strengths in predicting treatment effects [89]. Integrating morphological data with other data modalities using machine learning– or deep learning–based approaches has now become an active field of research.

The integration of structural models with cell morphology models has been demonstrated to improve biological assay outcome prediction accuracy. Seal et al. proposed the similarity-based merger model, which combines the scaled predicted probabilities from individual models trained on Cell Painting images and chemical structures, and the morphological and structural similarities between test and training compounds [90]. Specifically, the predictions from individual models and similarity values are used to fit a logistic regression model to predict the test compound activity. The authors demonstrated that the similarity-based merger model outperforms soft-voting ensemble, hierarchical model, or either of the individual models trained on unimodal data [90].

In addition, SSL techniques such as contrastive learning approaches have also been utilized to align multimodal data sources to enrich morphological profiling analysis in drug discovery [91–93]. For example, a method known as Contrastive Leave One Out boost for Molecule Encoders (CLOOME) has been proposed, aiming to learn aligned representations derived from the compound’s chemical structure and the corresponding cellular images obtained after treatment with the same compound [91]. Its learning framework incorporates a microscopy image encoder, a molecule structure encoder, and uses the InfoLOOB objective [94] to learn the aligned embedding of treatment image and compound structure [91]. Similarly, Zheng et al. presented the Molecular graph and hIgh content imaGe Alignment (MIGA) framework with an image encoder and a graph neural network (GNN)–based structural encoder [93]. To align graph embeddings with image embeddings, three contrastive objectives are used: graph-image contrastive learning, masked graph modeling, and generative graph-image matching. The crossmodal representation learned with this framework improves performances on several downstream tasks [93]. This approach is extended further by Nguyen et al. to develop Molecule-Morphology Contrastive Pretraining (MoCoP) [92]. This framework uses a morphology encoder, a gated GNN (GGNN)–based molecule encoder, and the modified InfoNCE objective [95] to learn multimodal representation. The GGNN pretrained with MoCoP can be fine-tuned for downstream quantitative structure–activity relationship (QSAR) tasks [92]. Furthermore, active learning approach has been used to boost the performance of image-based and structure-based models and benefit the downstream QSAR tasks. The initial image-based and structure-based models assist selecting candidate compounds to be validated in toxicity assays. Once the wet-lab assays are completed, assay readouts will be collected as new annotations to continue refining both models. This iterative approach has been applied to detect compounds with mitochondrial toxicity [96].

In addition to chemical structure data, integrating transcriptomic profile with cell morphology serves as another crossmodal combination. A prevalent assay for obtaining gene expression profile is the L1000 assay [97]. Both Cell Painting and L1000 assays are scalable and provide complementary data. Compared to the transcriptomic profile from L1000, the morphological profile from Cell Painting is more reproducible yet susceptible to batch and well position effects. Conversely, L1000 captures more diverse features. Collectively, these two profiling modalities measure overlapping and assay-specific MOAs [98]. Besides the L1000 transcriptomic profile, another gene expression-based assay, Functional Signature Ontology (FUSION), can be fused with morphological profiling data to assign MOAs to complex natural product fractions in pair with metabolomic profiling data [99]. Comparative studies have shown that transcriptome-based and morphology-based models offer comparable or better performance in MOA prediction, compared to the chemical structure-based model [100]. These findings provide rationale and potential advantages of integrating transcriptomic and morphological profiling for drug discovery. More discussions on the applications and concerns of integrating these two data modalities have been recently characterized [101, 102]. Datasets with matched transcriptomic and morphological profiling data are summarized in Table 5.

Data fusion methods have been widely used to integrate multimodal data (Fig. 6). In general, these methods can be categorized as early fusion and late fusion. Early fusion works by integrating the separate raw data modalities into a unified representation before feeding into the deep learning model for feature extraction. In contrast, late fusion combines the predictions of individual models, each built on a specific data modality. Algorithms such as cooperative learning have been proposed to enhance the alignment between predictions [103]. To integrate morphological, transcriptomic, and chemical structure profiles, Seal et al. compared both early and late fusion methods in detecting mitochondrial toxicity. They reported that the late fusion model can accurately determine the mitochondrial toxicity of compounds that have inconclusive toxicity results reported previously [104].

To identify perturbation effects in distinct feature space of morphological and transcriptomic data, Smith et al. proposed Perturbational Metric Learning (PeML) for similarity metric learning for multimodal data representation [105]. This WSL approach aims to learn an embedding to maximize the similarity between replicates, while non-replicates stay dissimilar. This learning methodology can be applied to both morphological and transcriptomic profiles and has demonstrated improved performance in MOA prediction [105].

Although the integration of morphological and transcriptomic (L1000) profiling offer benefits in MOA prediction, this orthogonal platform still faces challenges. These include limited resolution when identifying bioactive compounds that exhibit widespread cellular effects and reduced sensitivity when investigating bioactive compounds that do not induce distinct morphological changes [99]. To address these limitations, researchers have also investigated metabolomics-based approaches combining morphological characteristics to uncover changes in intracellular metabolism under various conditions [106]. Since metabolites in the cell can provide a comprehensive information of the cell state and define cellular phenotype in response to perturbations, combining cell morphology and metabolomics analysis has proven beneficial. For example, untargeted Mass Spectrometry (MS)–based metabolomics can be integrated with morphological profiling into a single platform to facilitate the quick identification and functional annotation of natural products in a high-throughput setting [99]. High-throughput image-based profiling pipeline can also be combined with multiparametric metabolic profiling approaches, such as oxygen consumption measurements and untargeted MS-based metabolomics to investigate the toxicity mechanism of the antiviral drug Tenofovir [107]. Furthermore, this combined approach can help optimizing microbial biosynthesis strategy, such as improving rapamycin production in Streptomyces hygroscopicus [108]. These studies underscore the significant advantages of integrating metabolomics and morphological, along with other data modalities in accelerating drug discovery process. With advances in MS techniques like MALDI-MS continuing to enhance throughput in metabolomic profiling [109], future studies will increasingly integrate these data with morphological profiling. Concurrently, development of these integrated platform calls for deep learning methods capable of facilitating multimodal learning using both morphological and metabolomics profiles.

In summary, applying deep learning approaches to integrate morphological data with other modalities, such as chemical structure, transcriptomic, and metabolomic data, demonstrates growing importance in drug discovery efforts. Techniques like contrastive learning and various data fusion methods are emerging to align multimodal data. The continuous curating of such multimodal datasets will further contribute to this burgeoning field.

Comparison of transcriptomic and morphological profiling data for drug discovery

Multimodal datasets with matched transcriptomic and morphological profiling data

Combine morphological data with other data modalities. The image data obtained from morphological profiling assays can be combined with other modalities of profiling data to perform downstream tasks jointly. One strategy involves training individual models to extract representations from each data modality, such as image data, chemical structural data, and transcriptomic data. These individual representations contribute to a joint embedding, which is subsequently utilized for downstream analyses.

## Section: Novel applications of morphological profiling in drug discovery

Machine and deep learning approaches have significantly contributed to morphological profiling, enriching various aspects of phenotypic drug discovery. Applications such as identifying small-molecule MOAs, lead optimization, and predicting toxicology have been extensively reviewed elsewhere [110–113]. In the following sections, we will discuss the recent advances in several novel applications.

## Section: Novel applications of morphological profiling in drug discovery › Construct genotype–phenotype relationship and gene function network

Mapping genotype to disease-relevant phenotype has been a critical question in genomics. To address this challenge, genome-scale pooled CRISPR screens have been used to provide insights into gene functions. However, conventional screening readouts are relatively low in dimensionality (such as cell viability, proliferation, or expressions of biomarkers), thereby providing a constrained view of disease-relevant phenotype [114]. While high-content transcriptomic data from scRNA-seq can be measured from pooled CRISPR screens, the cost of achieving high-content readout as such from a genome-wide CRISPR screen can be unfeasibly high [114]. To overcome this hurdle, image-based profiling can provide high-content morphological readout for CRISPR screens at the genome scale [33, 115, 116]. Notably, optical-pooled CRISPR screens [117] can be combined with image-based profiling to create a genome-wide perturbation atlas and to construct a gene function network based on the uncovered genotype–phenotype relationships [115, 118, 119]. For example, Ramezani et al. developed a Cell Painting–based optical-pooled cell profiling approach (PERISCOPE) to allow pooled CRISPR screens to have high-dimensional cellular morphological profiles as endpoint readouts. This scalable pipeline has been applied to A549 cells and human cervical cancer cells (HeLa) to investigate gene knockout responses and identify gene clusters based on morphological similarity [118]. Sivanandan et al. introduced a similar technique termed Cell Painting Pooled Optical Screening in Human Cells (CellPaint-POSH). With this approach, a screening with a druggable genome library of 1640 genes has been conducted on A549 cells. Notably, this work applied the SSL DINO-ViT model (section Representation Learning for Morphological Profiling) for image representation and demonstrated decent performance in recovering the gene function network [119]. Such results further attest to the efficacy and robustness of deep learning approaches in generating informative image representations, subsequently leading to valuable biological insights.

In the efforts of mapping genotype to phenotype, the observation of “proximity bias” has been reported, whereby the phenotypes of CRISPR knockouts demonstrate higher similarity to biologically unrelated genomically proximal genes on the same chromosome arm than the biologically related genes. The cause of this artifact arises from widespread chromosome arm truncation due to Cas9 nuclease activity and is not observed in shRNA or CRISPR interference (CRISPRi) perturbations. Performing arm-based geometric normalization of features at gene level can reduce this bias without compromising the recovery of biological relationship [120].

## Section: Novel applications of morphological profiling in drug discovery › Characterize perturbation impacts in dynamics

An emerging advance of morphological profiling is toward live-cell phenotyping, which can be performed by fluorescent or phase-contrast imaging, and by continuous imaging [27, 121] or dynamic imaging [48]. Several advantages accompany this approach. First, adding temporal variables to the morphological profile improves assay predictive power [27]. For example, in a live-cell imaging-based profiling assay, a library of 1008 The United States Food and Drug Administration (FDA)-approved drugs with manual annotations was profiled against 15 reporter cell lines that expressed fluorescent protein–tagged organelle or pathway markers. The morphological profile was generated from 24-h high-content imaging and can be used to accurately infer 41 of 83 testable MOAs [27]. Beyond this, live-cell imaging enables the characterization of cell-state transition dynamics, a critical feature in developmental biology [48, 121]. Human pluripotent stem cells (hPSCs) coexpressing histone H2B and cell cycle reporters can be profiled in a multi-day, high-content manner at single-cell resolution. With this profile, a deep learning model can be trained to provide highly sensitive predictions of spatiotemporal single-cell fate dynamics, as early or even earlier than cell state–specific reporters [121]. Moreover, live-cell morphological features of human-induced pluripotent stem cells (hiPSCs) can even be used to predict differentiation marker gene expression [48]. This approach involves performing phase-contrast imaging and bulk RNA-sequencing at each consecutive passage of hiPSCs. A VAE variant, VQ-VAE [122], learns the image feature vector in a self-supervised approach. A number of Support Vector Regression (SVR) models, each corresponding to a differentiation marker, were trained to predict differentiation marker gene expression from the image feature vector. Bulk RNA-sequencing readouts were used as labels for this supervised learning process. Altogether, this approach builds the relationship between transcriptional and live-cell morphological profiles [48].

Deep learning models such as DynaMorph [123] and DEEP-MAP [121] have been proposed to analyze morphological profiles in dynamics. To take DynaMorph for example, VQ-VAE was trained to learn a representation of cell shape through a self-supervised image reconstruction auxiliary task. To ensure that cell shape changes smoothly between neighboring frames, a temporal matching loss was applied. The representation of cell shape regularized by the temporal continuity can distinguish morphodynamic states of microglia in response to pro- and anti-inflammatory stimuli [123].

## Section: Novel applications of morphological profiling in drug discovery › Guide de novo hit design

Although the typical downstream applications of morphological profiling have been focused on clustering or classification tasks (section An Overview of Image-Based Profiling Data Analysis), Zapata et al. proposed to leverage morphological profiles to guide de novo molecular design with GANs [124]. Compared to using transcriptional profiling for compound de novo design [125], morphological profiling provides higher throughput with less cost. More importantly, more than 40% of the generated molecules have drug-like physicochemical properties, and more than half are expected to be synthesizable. This model can also be generalized to morphological profile with genetic perturbations such as gene overexpression. These findings indicate that this approach is able to effectively translate morphological similarity into chemical similarity with high efficiency [124].

## Section: Novel applications of morphological profiling in drug discovery › Facilitate image-based profiling in advanced biological models

Organoids are hetero-cellular biomimetic tissue models that have become a powerful experimental tool transforming basic science and translational research [126]. While the traditional low-throughput methods provide valuable biological insights, high-throughput methods are needed to fully exploit the potential of organoids as ex vivo models. Modeling the development of disease with organoids that can recapitulate tissue structure, pathology, phenotypes, and differentiation has revolutionized the study of various human diseases including cancer [126, 127]. In a recent study, Silva et al. and Atanasova et al. demonstrated the effect of small molecules in mouse pancreatic acinar that causes inhibition or reversal of acinar-to-acinar ductal metaplasia (ADM) using high-content image-based screening in organoid culture [128, 129]. Advances in technology in organoid culture and the remarkable self-organizing properties reflecting key structural and functional attributes of organs such as brain, kidney, lung, gut, or similar even hold promise to predict drug response in a personalized fashion.

While organoids are normally cultured in bulk in an extracellular matrix, these bulk cultures can physically overlap, which makes it challenging to track the growth and properties of individual organoids in high-throughput assays. Various microwell designs have been introduced to overcome specific challenges associated with image-based analysis but still struggle with large numbers of organoids [130, 131]. Using different organoid culture methods, phenotypic assays can be designed using features like whole organoid morphology, growth rates, or movement with simple brightfield imaging. Many of these methods rely on cellular aggregation to generate spheroids rather than growing organoids from single cells [132–134]. These can cause limitations in understanding the phenotypic heterogeneity, while most of the methods do not employ integrated analytical pipelines into the overall workflow [135–139] or the ability to selectively retrieve organoids for downstream investigations. Overcoming some of these issues, Forsyth and a team of researchers [126] have built an open-source microwell-based platform for high-throughput quantification using image-based parameters. The method utilizes an organoid-optimized deep-learning model that can be integrated with existing culturing protocols and micro-well platforms to investigate phenotypic features across different tissues. Additionally, patient-derived tumor organoids have been developed into powerful organoid-based discovery platforms in recently demonstrated using CRISPR-Cas9 screening for patient-specific functional genomics [140]. Defined mutations are introduced to transform normal organoids to tumorigenic growth upon xenotransplantation, combining the exploratory power of CRISPR-Cas9 screening with 3D organoids [133, 136, 141]. These advances demonstrate that organoids are powerful experimental models for morphological profiling to study the maturation and progression of various diseases.

## Section: Novel applications of morphological profiling in drug discovery › Enable natural product–based drug discovery

Natural products (NPs) and their structural analogues have made a major contribution to pharmacotherapy, playing a key role in drug discovery [3, 4]. Recent years have witnessed that AI approaches have substantially advanced the efficient identification of drug candidates from NPs, marking notable progress in drug discovery [5]. NP-based drug leads are typically identified by phenotypic assays [4]. To that end, an image-based profiling platform has been developed to study toxicity, structure–activity relationship (SAR), MOA, and potential off-target effects of NPs [6]. For example, a high-throughput screening on MIN6 β cells with 6298 marine NP fractions has been performed to select for hit compounds with nontoxic and long-lasting effects in inhibiting glucose-stimulated insulin secretion [142]. In combination with MS analyses and NMR analyses, aureolic acid CMA2 has been identified as the major component of the top hit fraction derived from S. anulatus. Treating MIN6 cells with CMA2 leads to decreased nuclei counts determine by the 4′-6-Diamidino-2-phenylindole (DAPI) staining, attesting to its bioactivity [143]. In another study, botanical NP extracts have been screened for blockade of SARS-CoV-2 infection in human 293TAT cells. A leading hit, the extracts of S. tetrandra, is further investigated on its antiviral MOA through phenotypic assays based on intracellular phospholipids formation [144]. In addition, high-dimensional phenotypic readouts also assist exploring NP MOA. To understand the MOA of the Polyketide Lagriamide B from the Burkholderiales strain, its morphological impact on U2OS cells is investigated through the Cell Painting assay followed by high-content imaging. At low treatment concentration, Lagriamide B leads to disruption in actin polymerization and incomplete cytokinesis, and at high concentration, low cell count and decreased cell size are observed. These phenotypic effects indicate an MOA of Lagriamide B in actin polymerization disruption [145].

Specifically, integrating morphological with multi-omics profiling helps annotate the bioactive components of NPs, which addresses one of the most significant challenges in NP-based drug discovery [99]. For example, an integrated framework of morphological and transcriptomic profiles has been used to annotate marine bacteria extracts based on its untargeted metabolomics profile [99]. This orthogonal platform demonstrated a new paradigm to understand the association between NP components and treatment phenotypes and underscored the importance of integrating multimodal profiling data for drug discovery (section Integrating Morphological Data in Multimodal Learning for Drug Discovery).

## Section: Challenges and outlook

Morphological profiling is poised to have a profound and continuing impact on phenotypic drug discovery in the next decade and beyond. Deep learning approaches will continue to empower morphological profiling with enhanced accuracy and efficiency [110]. However, several challenges await resolution in order to fully leverage cellular images as a reliable and insightful resource, as will be discussed in this section.

Although representation learning (section Representation Learning for Morphological Profiling) has become a robust approach to learn cellular features with less manual input than the conventional feature-engineering approach, it is susceptible to confounding factors such as batch effects. Batch effects are variations in data caused by the differences in the technical execution of each experimental batch. Such confounding factors introduce irrelevant sources of variation into data and can potentially mislead biological conclusions [146]. Disentangling these confounding factors from phenotypes is a crucial step to recover a true biological signal. Significant progress has been made in this regard, with methods such as TVN [37], BEN [147], TEAMS [148], CDCL [80], and GRU-based regularization [38]. Furthermore, batch correction methods for transcriptomic profiles may be applicable. A recent study on subsets of JUMP-CP demonstrated that Harmony, a non-linear method developed for processing scRNA-seq data, consistently outperforms other transcriptomic profile batch correction strategies in balancing batch removal and biological variation conservation [149]. In addition to the aforementioned methods, adding a context token to include batch-specific information during image representation learning also demonstrated decent performance in out-of-distribution generalization and batch variation handling [150]. To evaluate and compare batch correction strategies, RxRx1, a Cell Painting image dataset of genetic perturbations with 51 experimental batches from four cell types, has been systematically designed [146]. With the development and sharing of the benchmarked dataset, future work will continue to enhance upon existing methods. Improved handling of the confounding factors will further facilitate data sharing and reproducibility between data generation sites, thereby bringing significant benefits to the broader scientific community.

The success of phenotypic drug discovery heavily relies on disease relevance of the biological model. Applying relevant cell types and perturbations in morphological profiling assay is essential, but not sufficient to guarantee translatability [1]. Recent efforts have been made to apply increasingly multiplex biological model systems for image-based profiling, such as cocultured 2D cell lines [151] and 3D organoids [152, 153]. However, on the computational side, most approaches have been built upon Cell Painting assay images from mono-cultured 2D cells. Therefore, many challenges remain in generalizing these approaches to a multiplex biological model. For example, how do current cell segmentation (section Deep Learning–Facilitated Cell Segmentation for Image Analysis) and representation learning methods (section Representation Learning for Morphological Profiling) perform on 3D images? How is the quantity and quality of 3D image dataset that can be utilized for effectively training for fine-tuning deep learning models? How generalizable are the representation learning frameworks (section Representation Learning for Morphological Profiling) to cellular images consisting of multiple cell types, each demonstrating different morphology? How to integrate morphological data and other modalities of data (section Integrating Morphological Data in Multimodal Learning for Drug Discovery) from a multiplexed cell system to obtain cell–cell interaction information? Overcoming these hurdles will bring morphological profiling to the next level of clinical translatability.

In terms of integrating morphological profile with omics data (section Integrating Morphological Data in Multimodal Learning for Drug Discovery), compared to bulk transcriptomic readouts, single-cell transcriptomics, spatial transcriptomics and translatomics offer a wealth of gene expression information at individual cellular and subcellular levels [154–157]. Advances such as sci-RNA-seq3 have enabled single-cell transcriptional profiling in high throughput [158]. Given this technical progress, future work may establish an orthogonal profiling platform to combine morphological and single-cell profiling, thereby linking molecular phenotype to cellular phenotype at single-cell resolution. In addition, integrating Perturb-seq with image-based profiling will become a promising future direction to characterize the impact of genetic perturbations with single-cell transcriptomics and morphological readouts [159]. High-quality datasets of such should be established to encourage the development and evaluation of data integration approaches.

Last but not least, despite the impressive inferential capabilities of deep learning approaches, drawbacks remain that the explainability of these ‘black box’ models is unsatisfying [160]. In drug discovery especially, model interpretability is important to ensure that the biological conclusions are valid. To mitigate this, several efforts have been initiated to improve model interpretation in morphological profiling. For example, Chow et al. trained VAEs to interpret latent space feature representations in Cell Painting assay [161]. In the broader field of computer vision, techniques such as class activation mapping [162, 163] have been proposed to provide visual explanations for deep neural networks. Future work should continue to develop or advance techniques as such to morphological profiling to enhance model interpretability [162].

## Section: Concluding remarks

Morphological profiling represents a powerful, high-throughput, data-intensive, and cost-efficient technique for phenotypic drug discovery. It offers an unbiased and high-dimensional image readout of cellular phenotype in response to various perturbations, thereby providing a comprehensive view on compound bioactivity. Emerging techniques from computational biology and deep learning communities have made significant progress in enhancing the analytical pipeline from representation to prediction. While challenges remain in this fast-evolving field, future work will continue to coordinate multidisciplinary efforts in leveraging visual phenotypes to empower drug discovery.

## Section: Acknowledgements

We thank Wenjun Xie and Yuzhao Zhang for helpful discussion and comments that improved the manuscript. Figures 1, 2, 4, 5, and 6 were created with BioRender.com.

## Section: Author Biographies

Qiaosi Tang is a scientist at Calico Life Sciences, an Alphabet-founded research lab for human aging research. Her research focuses on using morphological profiling and machine learning methods to reveal age-related disease phenotype and identify potential therapeutic targets.

## Section: Author Biographies

Ranjala Ratnayake is a Research Associate Professor and Assistant Director of Center for Natural Products, Drug Discovery and Development (CNPD3), in the Department of Medicinal Chemistry at the College of Pharmacy, University of Florida. Her research focuses on using multidimensional screening platforms to identify novel drug therapies from complex natural product libraries.

## Section: Author Biographies

Gustavo Seabra is a Research Associate Professor in the Department of Medicinal Chemistry and the Center for Natural Products, Drug Discovery and Development (CNPD3) at the College of Pharmacy, University of Florida. His research focuses on the development and application of diverse computational chemistry methods and machine learning methods for molecular modeling.

## Section: Author Biographies

Zhe Jiang is an Assistant Professor in Computer & Information Science & Engineering (CISE) at the University of Florida. His lab’s mission is to design and develop accurate, scalable, and robust AI and machine learning algorithms and tools inspired by interdisciplinary applications such as biomedicine.

## Section: Author Biographies

Ruogu Fang is an Associate Professor and Pruitt Family Endowed Faculty Fellow in the J. Crayton Pruitt Family Department of Biomedical Engineering at the University of Florida. Her group’s research revolves around the integration of artificial intelligence (AI) and deep learning with the intricacies of the human brain.

## Section: Author Biographies

Lina Cui is an Associate Professor in the Department of Medicinal Chemistry at the College of Pharmacy, University of Florida. Her group develops and applies molecular tools for molecular imaging in various collaborative projects to explore the progression of diabetes, neurodegeneration, and other age-related diseases.

## Section: Author Biographies

Yousong Ding is an Associate Professor in the Department of Medicinal Chemistry at the College of Pharmacy, University of Florida. His research interests include natural product biosynthesis, drug discovery and development, synthetic biology, protein engineering, and chemical biology.

## Section: Author Biographies

Tamer Kahveci is a Professor and Associate Chair of Academic Affairs in the Computer and Information Science and Engineering Department at the University of Florida, serving as the Associate Chair of Academic Affairs. His research focuses on bioinformatics and has worked on indexing sequence and protein structure databases, sequence alignment, and computational analysis of biological pathways.

## Section: Author Biographies

Jiang Bian is a Professor and Division Director of Biomedical Informatics at the University of Florida and Chief Data Scientist and Chief Research Information officer of UF Health. His research focuses on data-driven medicine and development of novel informatics methods, tools, and systems to support clinical and clinical research activities.

## Section: Author Biographies

Chenglong Li is the Nicholas Bodor Professor in Drug Discovery and Professor in the Department of Medicinal Chemistry at the College of Pharmacy, University of Florida. He is also the Director of the NIGMS-supported CBI (Chemistry-Biology Interface) Graduate Training Program at the University of Florida. His research focuses on molecular recognition, with a strong application to structure-based computer-aided drug design.

## Section: Author Biographies

Hendrik Luesch is a Professor in the Department of Medicinal Chemistry, the endowed Debbie and Sylvia DeSantis Chair in Natural Products Drug Discovery and Development, and the founding Director of Center for Natural Products, Drug Discovery and Development (CNPD3) at the College of Pharmacy, University of Florida. His multidisciplinary research program at the interface of chemistry and biology integrates genome mining, synthetic and chemical biology, isolation and spectroscopic structure determination, chemical synthesis, target identification, and mechanism of action studies, followed by the preclinical development of candidate molecules.

## Section: Author Biographies

Yanjun Li is an Assistant Professor (AI Initiative) in the Department of Medicinal Chemistry at the College of Pharmacy, University of Florida. His research interests span the fields of deep learning, AI-driven drug discovery, and computational biology, with a particular emphasis on deep generative modeling for de novo molecule design and geometric deep learning for molecular recognition.

## Section: Contributor Information

Qiaosi Tang, Calico Life Sciences, South San Francisco, CA 94080, United States.

Ranjala Ratnayake, Department of Medicinal Chemistry, Center for Natural Products, Drug Discovery and Development, University of Florida, Gainesville, FL 32610, United States.

Gustavo Seabra, Department of Medicinal Chemistry, Center for Natural Products, Drug Discovery and Development, University of Florida, Gainesville, FL 32610, United States.

Zhe Jiang, Department of Computer & Information Science & Engineering, University of Florida, Gainesville, FL 32611, United States.

Ruogu Fang, Department of Computer & Information Science & Engineering, University of Florida, Gainesville, FL 32611, United States; J. Crayton Pruitt Family Department of Biomedical Engineering, Herbert Wertheim College of Engineering, University of Florida, Gainesville, FL 32611, United States.

Lina Cui, Department of Medicinal Chemistry, Center for Natural Products, Drug Discovery and Development, University of Florida, Gainesville, FL 32610, United States.

Yousong Ding, Department of Medicinal Chemistry, Center for Natural Products, Drug Discovery and Development, University of Florida, Gainesville, FL 32610, United States.

Tamer Kahveci, Department of Computer & Information Science & Engineering, University of Florida, Gainesville, FL 32611, United States.

Jiang Bian, Department of Health Outcomes and Biomedical Informatics, College of Medicine, University of Florida, Gainesville, FL 32611, United States.

Chenglong Li, Department of Medicinal Chemistry, Center for Natural Products, Drug Discovery and Development, University of Florida, Gainesville, FL 32610, United States.

Hendrik Luesch, Department of Medicinal Chemistry, Center for Natural Products, Drug Discovery and Development, University of Florida, Gainesville, FL 32610, United States.

Yanjun Li, Department of Medicinal Chemistry, Center for Natural Products, Drug Discovery and Development, University of Florida, Gainesville, FL 32610, United States; Department of Computer & Information Science & Engineering, University of Florida, Gainesville, FL 32611, United States.

## Section: Funding

Y.L. is supported by the University of Florida (UF Startup Fund). H.L. is generally supported by the Debbie and Sylvia DeSantis Chair professorship, and for phenotypic screening, HCS and morphological profiling supported by NIH grants R01CA172310 and RM1GM145426 as well as UF Health Cancer Center grant UFS-202307. C.L. has been partially supported by the Bodor Professorship Fund, UF AI Catalyst Fund and NCI R01CA212403. J..B. is supported by the following NIH grants: R01AG076234, RF1AG077820, and UL1TR001427. Y.D. is partially supported by NIH R35GM128742. L.C. is supported by the University of Florida (UF Startup Fund).

## Section: Data availability

Details about the data discussed in this study have been incorporated in the article. No additional data were generated for this study.

## Section: Associated Data › Data Availability Statement

Details about the data discussed in this study have been incorporated in the article. No additional data were generated for this study.
