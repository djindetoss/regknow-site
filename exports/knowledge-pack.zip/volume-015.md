# Machine learning screening for Parkinson's disease-related cuproptosis-related typing development and validation and exploration of personalized drugs for cuproptosis genes

- **Authors:** Ji Wu, Chengjian Qin, Yuankun Cai, Jiabin Zhou, Dongyuan Xu, Yu Lei, Guoxing Fang, Songshan Chai, Nanxiang Xiong
- **Issuer:** Annals of translational medicine
- **Type:** Scientific article
- **Published:** 2023-01-10
- **Language:** en
- **DOI:** 10.21037/atm-22-5756
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36760248/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

BackgroundParkinson’s disease (PD) is a common, degenerative disease of the nervous system that is characterized by the death of dopaminergic neurons in the substantia nigra densa (SNpc). There is growing evidence that copper (Cu) is involved in myelin formation and is involved in cell death through modulation of synaptic activity as well as neurotrophic factor-induced excitotoxicity.MethodsThis study aimed to explore potential cuproptosis-related genes (CRGs) and immune infiltration patterns in PD and the development of Cu chelators relevant for PD treatment. The PD datasets GSE7621, GSE20141, and GSE49036 were downloaded from the Gene Expression Omnibus (GEO) database. The consensus clustering method was used to classify the specimens of PD. Using weighted gene co-expression network analysis (WGCNA) and random forest (RF) tree model, support vector machine (SVM) learning model, extreme gradient boosting (XGBoost) model, and general linear model (GLM) algorithms to screen disease progression-related models, the column charts were created to verify the accuracy of these CRGs in predicting PD progression. Single sample genomic enrichment analysis (ssGSEA) was used to estimate the correlation between genes associated with copper poisoning and genes associated with immune cells and immune function. Molecular docking was used to verify interactions with copper chelating agents associated with cuproptosis for PD treatment.ResultsThrough ssGSEA, we identified three copper poisoning related genes ATP7A, NFE2L2 and MTF1, which are related to immune cells in PD. We also verified that LAGASCATRIOL can bind to NFE2L2 through molecular docking. Consistent cluster analysis identified two subtypes, among which C2 subtype was just enriched in PD. And to more accurately diagnose PD progression, patients can benefit from a feature map based on these genes.ConclusionsCRGs such as NFE2L2, MTF1, and ATP7B were identified to be associated with the pathogenesis of PD and provide a possible new direction for the treatment of PD, which needs further in-depth study.

## Section: Introduction

Parkinson’s disease (PD) is a progressive neurodegenerative disorder with a high prevalence. According to statistics in 2016, over 6 million people had PD worldwide and the number of people with PD is estimated to increase with the age of the population (1). Patients with PD often require the companionship of caregivers, most of whom are under great stress, and this service imposes a heavy socio-economic burden on society (2). The clinical features of the disease include motor symptoms, including bradykinesia, resting tremor, and rigidity, and non-motor symptoms, including loss of smell, autonomic dysfunction, depression, cognitive impairment, and insomnia. The main pathological features of PD are progressive loss of nigrostriatal dopaminergic neurons and abnormal α-synuclein aggregation called Lewy vesicles (3), but the exact etiology of PD is still unclear.

In recent years, the pathological process involved in PD-associated neuronal death has been thought to be apoptosis, and a variety of cell death and mechanisms have been found to be involved in PD pathogenesis, including autophagy, necroptosis, cell death-dependence, iron death, and cell scorching (4-7). It has been shown that corynoxine derivative CB6 inhibits PD progression in mice by inducing PIK3C3 complex-dependent autophagy, whereas metformin ameliorates depression-like behavior in experimental PD by inducing autophagy in the substantia nigra and hippocampus (8,9). There is evidence that excessive copper (Cu) administration leads to a 40–60% reduction in the binding of dopamine (DA) D2 receptors to (3H)-spiperone and results in neuronal cell death and α-synuclein aggregation (10). This confirms the possibility that Cu-induced thiol modifications are involved in an important mechanism of PD progression. Another study found that Cu can be involved in the pathogenesis of PD by catalyzing harmful redox reactions including oxygen derivatives that increase oxidative stress (11). Not only this, but Cu in the brain can be directly responsive to neurotransmitters, leading to the oxidation of DA, which in turn promotes the progression of PD (12). Recently, Tsvetkov et al. revealed that Cu toxicity in human cells occurs through the direct binding of excess Cu to the lipid acylated component of the tricarboxylic acid (TCA) cycle. This leads to the accumulation of lipid acylation-related proteins, loss of iron-sulphur cluster proteins, and ultimately cell death due to intracellular proteotoxic stress, a new form of cell death known as ‘cuproptosis’ (13). Therefore, modulating Cu ions and lipid acylation in the TCA cycle may be a potential therapeutic strategy to improve the prognosis of PD.

Integrated bioinformatics analysis is now widely used to identify potential novel biomarkers and their role in various diseases, A series of bioinformatic analyses using expression profiles of peripheral blood mononuclear cells (PBMC) have been performed to identify differentially expressed genes associated with humoral immunomodulatory mechanisms between PD and healthy controls (14), but a relevant and novel comprehensive bioinformatic analysis of PD patients and healthy controls in the substantia nigra densa (SNpc) is lacking. We aim to screen potential PD patients at the genetic level and explore novel mechanisms of PD pathogenesis and initially explore novel therapeutic targets. We collected a total of 19 genes associated with cuproptosis by reviewing the literature (13,15). The GSE49036 dataset, which contains 8 control brain samples and 20 PD brain samples, was used to look for differentially expressed cuproptosis genes and explore their immune infiltration patterns with immune-related genes and PD, and also further explored these cuproptosis-related differentially expressed genes (CR-DEGs)-targeted small molecule drugs. The PD patients were further clustered, and the clinical and clustering key module genes were obtained using weighted gene co-expression network analysis (WGCNA). The most relevant diagnostic marker genes for PD were screened by machine learning and receiver operating characteristic (ROC) curve analysis was used to distinguish patients with PD from healthy controls. The diagnostic efficacy was finally validated using GSE7621 and GSE20141. In conclusion, this study explored the possible mechanisms of action of cuproptosis-related genes (CRGs) in PD and the combined immune infiltration pattern as a new therapeutic target for them. We present the following article in accordance with the TRIPOD reporting checklist (available at https://atm.amegroups.com/article/view/10.21037/atm-22-5756/rc).

## Section: Methods › Data download

Three tissue sequencing datasets of RNA microarray data on PD nigrostriatal samples were downloaded from the Gene Expression Omnibus (GEO) database (https://www.ncbi.nlm.nih.gov/geo/): GSE7621 (9 control brain samples and 16 PD brain samples), GSE20141 (8 control brain samples and 10 PD brain samples), and GSE49036 (8 control brain samples and 20 PD brain samples). These datasets were analyzed using the Affymetrix Human Genome U133 Plus 2.0 array on the GPL570 (Affymetrix GeneChip Human Genome U133 Plus 2.0 Array) platform. The above data were extracted and transformed with gene names using Perl software (https://www.perl.org/). We then screened 19 Cu amination-associated genes from previous literature (16). The study was conducted in accordance with the Declaration of Helsinki (as revised in 2013).

## Section: Methods › Data processing and CR-DEGs screening

To find differences in the expression of cuproptosis genes in the substantia nigra of PD patients compared to normal controls, CRGs were screened from the GSE49036 dataset using the limma package of R software (The R Foundation for Statistical Computing, Vienna, Austria) and CR-DEGs screening was performed on 20 PD samples and 8 control brain tissues. ggpubr package for box plot and heat map presentation of the results.

## Section: Methods › Gene set enrichment analysis

To understand the impact of CR-DEGs on the mechanisms of PD disease development, we performed a single-sample gene set enrichment analysis (ssGSEA), using the limma package, org.Hs.eg.db, and clusterProfiler package, to an analysis and visualization of the diagnostic genes.

## Section: Methods › Investigation of immune cell infiltration

To understand the immune microenvironment in PD, we used a previously established method (17) to quantify immune infiltration and associated immune functions by ssGSEA, which calculates an enrichment score representing the level of immune cell infiltration and immune-related pathway activity. The “ggplot2” package was used to create a heat map of the distribution and variation of immune cells.

## Section: Methods › Competing endogenous RNA network search

To find possible messenger RNA-microRNA-long noncoding RNA (mRNA-miRNA-lncRNA) network relationships for CR-DEGs, we firstly searched MiRanda (http://www.microRNA.org), miRDB (http://www.miRDB.org/), and TargetScan (http://www.TargetScan.org/vert_71/) to find miRNAs for PD-CR-DEGs. The screening criteria were that the miRNAs predicted by all 3 databases were the mRNA-miRNAs we were looking for, and then the lncRNAs corresponding to the miRNAs were found by using the spongeScan website (18) (spongeScan: a web for detecting microRNA binding elements in lncRNA sequences). Finally, the predictions were visualized using Cytoscape 3.8.2 (https://cytoscape.org/).

## Section: Methods › Drug screening and molecular docking

We used the DGIdb database (https://dgidb.genome.wustl.edu/) for drug prediction of differential genes in order to explore possible targeting small molecule drugs for CR-DEGs. Using the search drug-gene interactions option on the web page, and by entering PD-CR-DEGs into the prediction, results were obtained and downloaded from the webpage by censoring the gene-drugs reported in the literature and visualizing the results of the gene-drug prediction network using Cytoscape 3.8.2. The top 5 gene-drug interaction scores were selected by eliminating chemotherapeutic drugs from the above results and using AutoDock to perform small-molecule drug-large-molecule protein docking, as in our previous studies (19,20). The energy required for docking was heat mapped using the R package pheatmap.

## Section: Methods › Genotyping and enrichment analysis

First, we found CR-DEGs by the methods described above. We used the R package to classify patients into different molecular subtypes based on the expression of CRGs. The R package ConsensusClusterPlus was used to remove the control samples from the GSE49036 dataset, retaining only the experimental samples. We set the cluster maxK =9, selected the most significant clusters by consistency scoring, and used principal component analysis (PCA) to determine whether the clusters were significant. The R software Limma and pheatmap packages were then used to explore the differential PD CR-DEGs after clustering, and to investigate CR-DEGs with molecular subtype salient features, we performed a gene set variation analysis (GSVA) using the marker gene set (c2. c2.cp.kegg.symbols.gmt, c5.go.symbols.gmt) from the MSigDB database derivation. We then used the Profiler package in R to analyze the enrichment features of the genes. The results were visualized using the “ggplot2” package.

## Section: Methods › Weighted co-expression network construction

We constructed a co-expression network of DEGs using the WGCNA package in R. Next, Pearson’s correlation matrix was performed on pairs of genes. To further analyze the sample clustering to detect outliers, we calculated the dissimilarity of the module feature genes, selected tangents to the module dendrogram, and merged some modules. Module assignments determined by dynamic tree cuts were shown using the colored rows below the dendrogram. By analyzing the module-trait relationships between module trait genes and clinical traits, two modules associated with a specific trait were identified. The same approach was used to cluster type the two modules associated with a specific trait and their most significant trait modules were Venn diagrammed to find the clinical traits and the common trait genes that were significant after clustering.

## Section: Methods › Machine learning methods for filtering feature model construction and validation

After clustering, the above obtained clinical traits and significant common trait genes were used to construct a random forest (RF) tree model, support vector machine (SVM) learning model, extreme gradient boosting (XGBoost) model, and general linear model (GLM) using R software, recursive feature elimination (RFE) in Random Forest Algorithm is a supervised machine learning method for sequencing genes associated with copper poisoning in PD. The prediction performance was estimated by ten-fold cross-validation, and the genes whose relative importance was >0.25 were identified as the characteristic genes. SVM is a small sample learning method, which basically bypasses the traditional process of induction to deduction, realizes efficient “reverse reasoning” from training to prediction of samples, and simplifies common classification and regression problems. XGBoost is a representative algorithm based on integrated lift, which complements the overfitting problem of gradient lift model. The GLM is an extension of the traditional linear model, which is an algorithm in which the population mean is passed by a nonlinear join function to better process and obtain non-normally distributed data (21). Using the four methods described above to construct a diagnostic model with characteristics, the data samples were first subjected to residual analysis, and to plot the reverse cumulative distribution of residuals for the four methods. The ROC curves of the four methods were plotted, and the best feature models for machine learning were selected based on the reverse cumulative scores of the residuals and the area under the curve (AUC) values under the ROC curves. The best predictive models were plotted on column line plots, calibration curves, and decision curves using packages such as rms and rmda. Finally, the ROC curves were used to verify the diagnostic performance of the models in the GSE7621 and GSE20141 datasets.

## Section: Methods › Statistical analysis

All statistical analyses were performed using R version 4.1.0, One-way ANOVA was performed to compare the differences among multiple groups (≥2 groups). The Student’s t-test was used to compare the differences between the two groups. Statistical significance was set at P<0.05.

## Section: Results

Flow chart of the systematic analysis of cuproptosis-related diagnostic genes and medication of PD. In WGCNA selection, red represents a positive association with PD, while blue represents a negative association with PD. In the energy heat map, the redder the color, the greater the energy required for intermolecular binding. In PD-immunocorrelation analysis diagnostic genes, red represents high expression in PD tissue, while blue represents low expression in PD tissue. *, P<0.05; **, P<0.01; ***, P<0.001. GEO, gene expression omnibus; CR-DEGs, cuproptosis-related differentially expressed genes; PD, Parkinson’s disease; WGCNA, weighted gene co-expression network analysis; AUC, area under the curve; ROC, receiver operating characteristic; RF, RF random forest tree; SVM, support vector machine; XGB, Tree Ensemble; GLM, generalized linear model.

CR-DEGs in PD. (A) Heat maps of the 3 CR-DEGs in PD; the color of the columns represents the gene expression of the tissue samples, with red indicating high expression and green indicating low expression. (B) The CR-DEGs boxplot in PD. *, P<0.05; **, P<0.01. CR-DEGs, cuproptosis-related differentially expressed genes; PD, Parkinson’s disease.

CR-DEGs in correlations. ATP7B was negatively correlated with NFE2L2 and MTF1, while NFE2L2 was positively correlated with MTF1. CR-DEGs, cuproptosis-related differentially expressed genes.

ATP7B, MTF1 and NFE2L2 pathway correlation exploration. (A) GSEA of ATP7B in the pathway; (B) GSEA of MTF1 in the pathway; (C) GSEA of NFE2L2 in the pathway. GSEA, gene set enrichment analysis.

Immunogene set analysis of immune infiltration patterns in PD and normal conditions. (A) Heat maps of immunogene set analysis of PD samples and the color of the columns represents the gene expression of the tissue samples, with red indicating high expression and green indicating low expression. (B) Violin plot showing the difference in infiltrating immune cells between the two groups. PD, Parkinson’s disease; MDSC, myeloid-derived suppressor cell.

Immunogene set analysis of immune cell in ATP7B, MTF1, and NFE2L2; heat map of ATP7B, MTF1, and NFE2L2 correlation with immune cells. MDSC, myeloid-derived suppressor cell.

ceRNA network in ATP7B, MTF1, and NFE2L2. Red circles represent mRNAs, green triangles represent miRNAs, and purple diamonds represent lncRNAs. mRNAs, messenger RNAs; miRNAs, microRNAs; lncRNAs, long noncoding RNAs.

Search for ATP7B, MTF1 and NFE2L2 targeted drugs AND Molecular docking energy heat map. (A) The ATP7B and NFE2L2 targeted drugs; (B) molecular docking of NFE2L2 proteins in andalusol, chembl128729, dimethyl_fumarate, lagascatriol, suforaphane_isoselenocyanate, the ordinate value is the energy of docking (Kcal/mol). The redder the color, the greater the energy required for intermolecular binding.

NFE2L2 protein docking with LAGASCATRIOL. The molecules and drugs with the lowest docking energies are visualized in Figure 8. (A-C) Visualization of molecular docking results for NFE2L2 proteins in LAGASCATRIOL.

Two different subtypes of PD divided by consensus clustering and GSVA-GO and KEGG enrichment analysis (A) defined two clusters (k=2) and the consensus matrix heat map of their related regions. (B) PCA analysis showed significant transcriptome differences between the two subtypes. C1 is shown in green, C2 in red, and there is no sample overlap between them. (C) Box plots showed that ATP7B, MTF1 and NFE2L2 genes were significantly different between class A and B. Asterisks indicate statistical P values (**P<0.01; ***P<0.001). (D) GSVA-GO enrichment analysis N in the two clusters, where red and blue represent BP, CC, MF in activated GO and BP, CC, MF (E) in inhibited GO, respectively, and GSVA-KEGG enrichment analysis in red and blue represent activation pathway and inhibition pathway. BP, biological process; CC, cell component; MF, molecular function; RIA, ruptured intracranial aneurysm; GO, Gene Ontology; KEGG, Kyoto Encyclopedia of Genes and Genomes; PD, Parkinson’s disease; GSVA, gene set variation analysis; PCA, principal component analysis.

WGCNA selection of PD disease-related modules co-expressed genes. (A) Outliers were detected in the sample cluster. (B) The cut-off point was set as 0.9, and the soft threshold power was set as β=8. (C) Tree diagram of all DEGs based on the cluster of difference measurement. The colored bands show the results from the automated monolithic analysis. (D) Correlation diagram between modules obtained by clustering according to inter-gene expression levels. (E) Heat map of the correlation between module characteristic genes and phenotypes. We chose the MEblack module for subsequent analysis (the ordinate value is the correlation coefficient of feature module). (F) Module membership vs. gene significance, cor is disease correlation coefficient, P is the P value of correlation coefficient. ME, module eigengene; WGCNA, weighted gene co-expression network analysis; PD, Parkinson’s disease; DEGs, differentially expressed genes.

WGCNA selection of PD cluster-related modules co-expressed genes. (A) Outliers were detected in the cluster 1 and 2-sample cluster. (B) The cut-off point was set as 0.9, and the soft threshold power was set as β=7. (C) Tree diagram of all cluster 1 and 2-sample DEGs based on the cluster of difference measurement. The colored bands show the results from the automated monolithic analysis. (D) Correlation diagram between modules obtained by clustering according to inter-gene expression levels. (E) Heat map of the correlation between module characteristic genes and cluster 1 and 2-sample phenotypes. We chose the MEyellow module for subsequent analysis (the ordinate value is the correlation coefficient of feature module). (F) Module membership vs. gene significance, cor is disease correlation coefficient, P is the P value of correlation coefficient. ME, module eigengene; WGCNA, weighted gene co-expression network analysis; PD, Parkinson’s disease.

Machine learning builds models can largely progress between PD and normal samples. (A) The intersection genes of disease feature module and typing feature module were analyzed by WGCNA. (B) RF random forest tree, SVM, XGB, GLM and other algorithms were used to construct the reverse cumulative distribution map of model residuals. The Y-axis value represents the percentile of the outlier. (C) Box plots of sample residuals of the four algorithms. The X-axis value represents the quantile of outliers, and the red dot represents the mean. (D) ROC analysis of RF random forest tree, SVM, XGB, GLM, and other algorithms. The ROC values of RF and SVM were 0.833. (E,F) ROC analysis of XGB model in the GSE7621 and GSE20141 validation set. x-axis: FPR, false positive rate; y-axis: TPR, true positive rate; WGCNA, weighted gene co-expression network analysis; AUC, area under the curve; RF, RF random forest tree; SVM, support vector machine; XGB, Tree Ensemble; GLM, generalized linear model; ROC, receiver operating characteristic; CI, confidence interval.

A nomogram was constructed to predict the probability in PD progress. The values of each variable (SLC35D3, FLJ22184, SYT17, and RIMS3) are summed to obtain a total score. Each variable corresponds to a score, and the total score can be calculated by summing the scores of all variables. PD, Parkinson’s disease.

## Section: Results › Study process

Figure 1 show all the processes analyzed. First, PD-brain nigrostriatal sequencing data were retrieved from the GEO database, and the GSE49036 dataset was used to screen CR-DEGs and explore their correlation and single-gene GSEA pathway analysis. Correlations between individual genes and immune cells were then explored, a CR-DEGs mRNA-miRNA-lncRNA network was constructed, a gene-drug network was constructed, and molecular docking was performed to explore the feasibility of their binding. The molecular subtypes of CR-DEGs present in PD were then explored, WGCNs with clinical and clustering typing were constructed, and the clustered typing was crossed over to the clinical module genes. The crossed genes were then used to construct a diagnostic model using machine learning and the diagnostic model was proved using GSE7621 and GSE20141.

Flow chart of the systematic analysis of cuproptosis-related diagnostic genes and medication of PD. In WGCNA selection, red represents a positive association with PD, while blue represents a negative association with PD. In the energy heat map, the redder the color, the greater the energy required for intermolecular binding. In PD-immunocorrelation analysis diagnostic genes, red represents high expression in PD tissue, while blue represents low expression in PD tissue. *, P<0.05; **, P<0.01; ***, P<0.001. GEO, gene expression omnibus; CR-DEGs, cuproptosis-related differentially expressed genes; PD, Parkinson’s disease; WGCNA, weighted gene co-expression network analysis; AUC, area under the curve; ROC, receiver operating characteristic; RF, RF random forest tree; SVM, support vector machine; XGB, Tree Ensemble; GLM, generalized linear model.

## Section: Results › Identification of CR-DEGs in PD and correlation analysis between genes

The GSE49036 data were normalized and CRGs were extracted using the limma package of R software and screened for DEG analysis. According to the screening criteria: P<0.001, indicated by “***”, P<0.01, indicated by “**” and P<0.05, indicated by “*”, heat maps (Figure 2A) and box plots (Figure 2B) were drawn using pheatmap and ggpubr software packages to visualize the differential gene expression results.

Correlation analysis of expression of the above-mentioned genes in PD patients was performed using the corrplot package of R software and the results showed that ATP7B was negatively correlated with NFE2L2 and MTF1 and that NFE2L2 was positively correlated with MTF1. The results of expression correlation between genes were also visualized using the circlize package (Figure 3).

CR-DEGs in PD. (A) Heat maps of the 3 CR-DEGs in PD; the color of the columns represents the gene expression of the tissue samples, with red indicating high expression and green indicating low expression. (B) The CR-DEGs boxplot in PD. *, P<0.05; **, P<0.01. CR-DEGs, cuproptosis-related differentially expressed genes; PD, Parkinson’s disease.

CR-DEGs in correlations. ATP7B was negatively correlated with NFE2L2 and MTF1, while NFE2L2 was positively correlated with MTF1. CR-DEGs, cuproptosis-related differentially expressed genes.

## Section: Results › GSEA of PD tissue and CR-DEGs

Single-gene GSEA enrichment analysis was performed to explore the potential mechanisms of action of cuproptosis-related genes such as NFE2L2, MTF1 and ATP7B in PD, as shown in Figure 4. Interestingly, all 3 genes were associated with the synaptic vesicle cycle, although they were down-regulated in NFE2L2 and MTF1, down-regulated in ATP7B. In contrast, the ATP7B up-regulated signaling pathway is also related to Citrate cycle (TCA cycle), Nicotine addiction, Retinol metabolism, Starch and sucrose metabolism, etc. whereas NFE2L2 and MTF1 were jointly associated with Proteasome, and MTF1 down-regulation signaling pathway was associated with 2-oxocarboxylic acid metabolism, glycosphingolipid biosynthesis—globo and isoglobo series, and so on. NFE2L2 down-regulation was associated with aminoacyl-tRNA biosynthesis, glycosphingolipid biosynthesis—globo and isoglobo series, and so on.

These results indicate that NFE2L2, MTF1, and ATP7B may be involved in the regulation of the synaptic vesicle cycle, which in turn affects brain neurotransmitter transmission and may be involved in aerobic metabolism of brain tissue, leading to disease progression.

ATP7B, MTF1 and NFE2L2 pathway correlation exploration. (A) GSEA of ATP7B in the pathway; (B) GSEA of MTF1 in the pathway; (C) GSEA of NFE2L2 in the pathway. GSEA, gene set enrichment analysis.

## Section: Results › Immunocorrelation analysis of PD tissue and CR-DEGs

To explore the immune cell infiltration of CR-DEGs in PD, we performed GSEA of dataset GSE49036 using the immune gene set “immune.gmt”, as shown in Figure 5A,5B. CD8 T cell was highly expressed in normal controls with PD tissue, whereas plasmacytoid dendritic cell (DC), macrophage, immature B cell, myeloid-derived suppressor cells (MDSCs), mast cell, neutrophil, natural killer (NK) T cell, type 2 T helper cell, T follicular helper cell, and other immune cells were highly expressed in PD substantia nigra versus normal brain tissue. We also explored the relationship between individual genes of CR-DEGs and immune cells (see Figure 6). ATP7B was associated with activated B cell, CD56 dim NK cell, central memory CD4 T cell, central memory CD8 T cell, macrophage, mast cell, MDSC, monocyte, NK cell, NK T cell, plasmacytoid DC, and T follicular helper cell, and other immune cells were negatively correlated, whereas NFE2L2 was negatively correlated with MTF1 and type 17 T helper cell, plasmacytoid DC, NK T cell, central memory CD8 T cell, NK cell, monocyte. Memory B cell, mast cell, and activated B cell were positively correlated, and interestingly, they were negatively correlated with effector memory CD8 T cell expression; it is possible that these immune cells are involved in the midbrain substantia nigra of PD degenerative death of dopaminergic neurons, and CR-DEGs such as NFE2L2, MTF1, and ATP7B may be promising targets for immunotherapy in PD.

Immunogene set analysis of immune infiltration patterns in PD and normal conditions. (A) Heat maps of immunogene set analysis of PD samples and the color of the columns represents the gene expression of the tissue samples, with red indicating high expression and green indicating low expression. (B) Violin plot showing the difference in infiltrating immune cells between the two groups. PD, Parkinson’s disease; MDSC, myeloid-derived suppressor cell.

Immunogene set analysis of immune cell in ATP7B, MTF1, and NFE2L2; heat map of ATP7B, MTF1, and NFE2L2 correlation with immune cells. MDSC, myeloid-derived suppressor cell.

## Section: Results › PD-CR-DEGs ceRNA network search

To further explore the complex molecular interaction mechanism between the NFE2L2, MTF1, and ATP7B genes, we created an mRNA-miRNA-lncRNA network relationship diagram, as shown in Figure 7. This complex network has 60 nodes and 99 interactions, including 40 miRNAs and 17 lncRNAs, which may provide us with a new idea to explore the pathogenesis of cuproptosis-related PD.

ceRNA network in ATP7B, MTF1, and NFE2L2. Red circles represent mRNAs, green triangles represent miRNAs, and purple diamonds represent lncRNAs. mRNAs, messenger RNAs; miRNAs, microRNAs; lncRNAs, long noncoding RNAs.

## Section: Results › Prospective small molecule drug for PD therapy

In order to explore Prospective small molecule drugs for PD therapy, downloaded the results of NFE2L2, MTF1, and ATP7B targeting drugs from the DGIdb database and selected drugs with documented results (see Table 1) and presented the gene-drug results using Cytoscape (Figure 8A). We finally selected the top 5 NFE2L2 gene-drug interaction scores for small molecule drug-macromolecule protein docking using AutoDock. The energy required for docking is shown in Figure 8B, with the lowest energy required for docking LAGASCATRIOL to NFE2L2. Figure 9A shows a visualisation of the overall picture of the molecular docking results of the NFE2L2 protein in LAGASCATRIOL, Figure 9B shows a local view of the molecular docking results visualising the small molecule drug with the protein, see Figure 9C. LAGASCATRIOL is able to form 1 ionic bond each with arginine at position 456 and 504 of NFE2L2, and 2 ionic bonds with aspartic acid at position 457.

Search for ATP7B, MTF1 and NFE2L2 targeted drugs AND Molecular docking energy heat map. (A) The ATP7B and NFE2L2 targeted drugs; (B) molecular docking of NFE2L2 proteins in andalusol, chembl128729, dimethyl_fumarate, lagascatriol, suforaphane_isoselenocyanate, the ordinate value is the energy of docking (Kcal/mol). The redder the color, the greater the energy required for intermolecular binding.

NFE2L2 protein docking with LAGASCATRIOL. The molecules and drugs with the lowest docking energies are visualized in Figure 8. (A-C) Visualization of molecular docking results for NFE2L2 proteins in LAGASCATRIOL.

## Section: Results › Clustering based on the CR-DEGs in the PD sample

In GSE49036, cluster analysis was performed to classify the PD samples into different molecular subtypes and examine the subtypes using PCA based on the expression of the 3 CR-DEGs selected above (Figure 10A,10B). We named the 2 clusters as CRGClusters C1 and C2, respectively. Differential analysis of the 2 CRGClusters showed that ATP7B expression was significantly higher in C1 compared to C2, whereas NFE2L2 and MTF1 in C1 had significantly higher ATP7B expression compared to C2 expression, which was significantly decreased (Figure 10C). In the Kyoto Encyclopedia of Genes and Genomes (KEGG), comparison between the two clusters in the GSEA also revealed significantly different KEGG pathway enrichment profiles, interestingly on PARKINSONS_DISEASE, but also on ubiquitin-mediated proteolysis, oxidative phosphorylation, and citrate cycle tca cycle, which were up-regulated, whereas tgf beta signaling pathway and spliceosome were down-regulated (Figure 10D). In contrast, among the Gene Ontology (GO) biological down-regulated in pathways: immunological synapse formation, positive regulation of hemopoiesis, positive regulation of b cell differentiation, regulation of endodermal cell differentiation, regulation of synaptic vesicle endocytosis, dendrite extension, presynaptic dense core vesicle exocytosis, regulation of postsynaptic vesicle exocytosis, and regulation of postsynaptic cytosolic calcium ion concentration (Figure 10E). These results suggest a possible involvement in the production and transmission of neurotransmitters in the brain, and possibly in dendritic production related to the progression of PD by causing a significant reduction in striatal DA content.

Two different subtypes of PD divided by consensus clustering and GSVA-GO and KEGG enrichment analysis (A) defined two clusters (k=2) and the consensus matrix heat map of their related regions. (B) PCA analysis showed significant transcriptome differences between the two subtypes. C1 is shown in green, C2 in red, and there is no sample overlap between them. (C) Box plots showed that ATP7B, MTF1 and NFE2L2 genes were significantly different between class A and B. Asterisks indicate statistical P values (**P<0.01; ***P<0.001). (D) GSVA-GO enrichment analysis N in the two clusters, where red and blue represent BP, CC, MF in activated GO and BP, CC, MF (E) in inhibited GO, respectively, and GSVA-KEGG enrichment analysis in red and blue represent activation pathway and inhibition pathway. BP, biological process; CC, cell component; MF, molecular function; RIA, ruptured intracranial aneurysm; GO, Gene Ontology; KEGG, Kyoto Encyclopedia of Genes and Genomes; PD, Parkinson’s disease; GSVA, gene set variation analysis; PCA, principal component analysis.

## Section: Results › WGCNA co-expression analysis of PD samples

We first conducted a WGCNA analysis of clinical trait correlations in order to select the top 25% of genes with the greatest fluctuations for WGCNA analysis and cut off outlier samples, with the remaining samples being included in the analysis (Figure 11A). As shown in Figure 11B, scale independence reached 0.9 when power =8 and mean concordance was high. Therefore, power =8 was used to construct co-expression modules to obtain preliminary module delineation results, and the results of WGCNA showed that different modules were identified with different colors (Figure 11C). To detect outliers, trees were constructed using the eigenvalues of the modules, and then the distances of the trees belonging to the same branch were very close were merged and the intercept value was set to 0.5 (Figure 11D). Co-expression modules were constructed as shown in Figure 11E and the results were obtained after merging similar modules. Based on the eigenvalues of the samples in each module and the characteristics of the samples, correlation analysis was performed to identify modules associated with specific traits, and the genes represented by MEblack were highly positively correlated in PD (Figure 11F).

In the same way that we performed WGCNA analysis of correlations after typing, we cut off outlier samples (Figure 12A) as in Figure 12B when power =7, scale independence reached 0.9, modules were identified by color and eventually found to be characterized after typing (Figure 12C-12F), with the genes represented by MEyellow being highly positively correlated in CRGCluster C1 (Figure 12F).

WGCNA selection of PD disease-related modules co-expressed genes. (A) Outliers were detected in the sample cluster. (B) The cut-off point was set as 0.9, and the soft threshold power was set as β=8. (C) Tree diagram of all DEGs based on the cluster of difference measurement. The colored bands show the results from the automated monolithic analysis. (D) Correlation diagram between modules obtained by clustering according to inter-gene expression levels. (E) Heat map of the correlation between module characteristic genes and phenotypes. We chose the MEblack module for subsequent analysis (the ordinate value is the correlation coefficient of feature module). (F) Module membership vs. gene significance, cor is disease correlation coefficient, P is the P value of correlation coefficient. ME, module eigengene; WGCNA, weighted gene co-expression network analysis; PD, Parkinson’s disease; DEGs, differentially expressed genes.

WGCNA selection of PD cluster-related modules co-expressed genes. (A) Outliers were detected in the cluster 1 and 2-sample cluster. (B) The cut-off point was set as 0.9, and the soft threshold power was set as β=7. (C) Tree diagram of all cluster 1 and 2-sample DEGs based on the cluster of difference measurement. The colored bands show the results from the automated monolithic analysis. (D) Correlation diagram between modules obtained by clustering according to inter-gene expression levels. (E) Heat map of the correlation between module characteristic genes and cluster 1 and 2-sample phenotypes. We chose the MEyellow module for subsequent analysis (the ordinate value is the correlation coefficient of feature module). (F) Module membership vs. gene significance, cor is disease correlation coefficient, P is the P value of correlation coefficient. ME, module eigengene; WGCNA, weighted gene co-expression network analysis; PD, Parkinson’s disease.

## Section: Results › Machine learning builds diagnostic models

We crossed the clinical trait and typed common trait gene modules to find a total of 72 trait genes (Figure 13A). We used the GSE49036 dataset to extract the 72 trait genes and used the RF tree, SVM, XGB, and GLM algorithms to build diagnostic models with the traits. We first analyzed the data samples for residuals, the reverse cumulative distribution of the residuals of the four algorithms is plotted (Figure 13B). The XGB model has smaller residuals for most samples, while the GLM has higher residuals for many samples than the XGB model. The box plots of the residuals of the 4 algorithms (Figure 13C), with the red dots indicating the root mean square of the residuals, were ranked as follows: XGB < SVM < RF < GLM, and the 4 models were validated with ROC curves. The AUC values of the four models were as follows: RF =0.833; SVM =0.833; XGB =0.917; GLM =0.833 (Figure 13D).

Finally, we chose the XGB model and used the GSE7621 and GSE20141 gene sets to validate the ROC curves for the XGB model (Figure 13E,13F), with corresponding AUC values of 0.688 and 0.833. Finally, the genes in the model were plotted in a nomogram (Figure 14), which showed that the genes in the model are SLC35D3, FLJ22184, SYT17184, SLC35D3, FLJ22184, FLJ22184, SYT17, and RIMS3.

Machine learning builds models can largely progress between PD and normal samples. (A) The intersection genes of disease feature module and typing feature module were analyzed by WGCNA. (B) RF random forest tree, SVM, XGB, GLM and other algorithms were used to construct the reverse cumulative distribution map of model residuals. The Y-axis value represents the percentile of the outlier. (C) Box plots of sample residuals of the four algorithms. The X-axis value represents the quantile of outliers, and the red dot represents the mean. (D) ROC analysis of RF random forest tree, SVM, XGB, GLM, and other algorithms. The ROC values of RF and SVM were 0.833. (E,F) ROC analysis of XGB model in the GSE7621 and GSE20141 validation set. x-axis: FPR, false positive rate; y-axis: TPR, true positive rate; WGCNA, weighted gene co-expression network analysis; AUC, area under the curve; RF, RF random forest tree; SVM, support vector machine; XGB, Tree Ensemble; GLM, generalized linear model; ROC, receiver operating characteristic; CI, confidence interval.

A nomogram was constructed to predict the probability in PD progress. The values of each variable (SLC35D3, FLJ22184, SYT17, and RIMS3) are summed to obtain a total score. Each variable corresponds to a score, and the total score can be calculated by summing the scores of all variables. PD, Parkinson’s disease.

## Section: Discussion

PD is considered a progressive neurodegenerative disease that manifests clinically as resting tremor, rigidity, bradykinesia, or dyskinesia, postural gait abnormalities, and other non-motor symptoms. PD is now understood to be a multisystem disorder accompanied by significant nerve inflammation and immune function dysfunction. Its pathogenesis is currently unclear and includes the presence of oxidative stress, protein aggregation, mitochondrial dysfunction, and inflammation as the cause of neuronal death (22). Among the pathological features of PD are the formation of predominantly intracellular alpha-synuclein-containing inclusion bodies, called Lewy vesicles. The current understanding of neural death in PD is the role of α-synaptic nuclear proteins in brain cell death through the formation and assembly of these protein aggregates. In contrast, Cu1+ can also bind directly to two different regions of the α-synaptic nucleoprotein thereby causing oxidative neurological damage degeneration (23). High concentrations of Cu promote α-synaptic protein misfolding leading to PD progression (24). Alternately, 6-OHDA disrupts copper (Cu) homeostasis through dysregulation of cellular Cu transport, leading to neuronal cell dysfunction and cell death (25). Therefore, Cu accumulation and Cu metabolism are important for the development of PD disease, and in this study we explored potential central genes related to cuproptosis and immune infiltration patterns in the substantia nigra of PD patients through bioinformatics analysis, and we found that plasmacytoid DC was upregulated in tissues with the most significant differences in PD. It has been suggested that DC-mediated T-cell differentiation leads to a reduction in recognized antigenic peptides, resulting in the timely degradation of inflammatory proteins associated with α-synuclein synthesis in PD (26), whereas our immune cell analysis of three CR-DEGs found that they were all associated with NK cells, and it has been shown that increased NK cell numbers and cytotoxicity during PD progression can play a neuroprotective role (27), which may further reveal new targets for PD immunotherapy and provide new potential therapeutic biomarkers and treatment strategies for PD.

Our study used three PD patients’ nigrostriatal sequencing datasets to enrich the exploration of cuproptosis genes, firstly to find DEGs related to cuproptosis in PD patients, namely ATP7B, NFE2L2, and MTF1, and to explore their respective possible pathways of action and relationships with individual immune cells. We also explored their possible target miRNAs and lncRNA, mapped the complex network of ceRNAs, and searched for their corresponding small molecule drugs through the DGIdb database. We also conducted an in-depth analysis of PD patients by clustering and typing to explore the possible mechanisms of tissue typing in PD tissues, and constructed a diagnostic model of PD using WGCNA and machine learning methods.

Our results of GSEA revealed that the genes ATP7B, NFE2L2, and MTF1 were all associated with the synaptic vesicle cycle, which may suggest that these three genes could be involved in the synaptic vesicle cycle to reduce neurotransmitter transmission. ATP7B is a key ATPase in the Golgi complex harbors copper-transporting, which transfers Cu from the cytoplasmic matrix to the Golgi lumen for incorporation into the Cu-dependent enzyme. The Golgi complex also sends these ATPases to appropriate post-Golgi destinations to ensure the correct Cu flux in vivo and to avoid potentially toxic Cu accumulation. Mutations in ATP7A or ATP7B or the proteins that regulate their transport can affect their exit from the Golgi or subsequent fetch back to this organelle (28). α-synuclein assemblies need to exhibit seeding capacity, namely, template capacity for further aggregation, and toxicity mediated at least in part by interference with synaptic vesicle or organelle homeostasis (29). NFE2L2 encodes nuclear factor E2 and related factor 2 (NRF2), which are master regulators of antioxidant enzymes that prevent oxidative stress and inflammation, and perillyl is a key inhibitor of α-synuclein protein synthesis, thereby slowing PD progression. In contrast, galangin attenuates neuronal apoptosis via the Nrf2/Keap1 pathway, thereby slowing PD progression (30,31). MTF1, a key regulator of heavy metal homeostasis and detoxification, provides complementary functions in oxidative stress and other cellular stress responses. MTF1 gene polymorphisms have the potential to influence further exacerbation of PD (32). These studies above suggest that genes such as ATP7B, NFE2L2, and MTF1 may have important implications for the pathogenesis and progression of PD, based on which they are expected to be our next therapeutic targets for the study of PD.

The clinical diagnostic criteria for PD are bradykinesia with resting tremor, rigidity, or both (33). In contrast, the location of the DA transporter has been identified in diagnostic imaging primarily by DA transporter single photon emission computed tomography (DaT SPECT) by showing presynaptic DA neuronal hypofunction in PD and other neurodegenerative diseases. Identification of presynaptic dopamine neuronal dysfunction present in PD and other neurodegenerative diseases is used to differentiate PD from primary tremor, but it is not necessary to routinely perform these scans (34). They cannot distinguish PD from other neurodegenerative diseases that also involve DA transporter dysfunction (e.g., multisystem atrophy, progressive supranuclear palsy). There is growing evidence that PD includes a heterogeneous subtype have implications for diagnosis, prognosis, and expected response to treatment. Initial subtyping focused on motor characteristics (35). One typing approach includes three groups: predominantly mild motor: younger age of onset, mild motor and non-motor symptoms, slow progression and good drug response (36). Therefore, the typing of PD may be a better guide for treatment. We also typed PD and divided it into CRGClusters C1 and C2. Our results showed that ATP7B expression was significantly higher in C1 compared to C2, whereas NFE2L2, MTF1, and ATP7B expression was significantly decreased in C1 compared to C2. Our post-typing GSVA-KEGG enrichment analysis showed that in fractions, C2 could be enriched in PD signal path, as well as in the GO biological pathways: immunological synapse formation, regulation of endodermal cell differentiation, and regulation of synaptic vesicle endocytosis, dendrite extension, presynaptic dense core vesicle exocytosis, regulation of postsynaptic cytosolic calcium ion concentration. We obtained a diagnostic line graph by machine learning methods, so that we can diagnose PD by detecting the expression of genes; our research facilitates us to personalize the diagnosis and guide the treatment of PD by typing.

Currently, DA antagonists remain the first-line drugs used clinically for the treatment of PD, and the use of levodopa improves more function but increases the risk of dyskinesia, especially at higher doses (37). If it is necessary to reduce the dosage of levodopa after the development of dopamine-dysregulation syndrome (DDS), we can in turn try to switch to other drugs, which still have their own side effects, such as hallucinations and delirium (38). In contrast, levodopa equivalent daily dose (LEDD) can usually be reduced by 30–50% after deep thalamic nucleus brain stimulation (DBS) surgery is administered to patients, and one study showed that 7% of 150 patients treated with STN-DBS stopped taking the drug after 3 years (39). Complete cessation after STN-DBS dopaminergic medication is usually not possible because the lack of DA in the limbic system and associated circuits can lead to apathy and depression (39,40), so alternative medications with fewer side effects and effective alternatives need to be chosen. We searched the DGidb database for andalusol, chembl128729, dimethyl_fumarate lagascatriol, and suforaphane_isoselenocyanate, and other small molecules were identified through the DGidb database, and molecular docking was performed to initially explore the amino acid residue linkage sites between these drugs and NFE2L2 and their counterparts. There are studies on the Nrf2-dependent neuroprotective activity of diterpenoids isolated from Sideritis spp., counteracting oxidative damage and their potential role as useful agents for the prevention of those with oxidative stress-mediated dementia. ANDALUSOL was the most active of the diterpenoids studied (41). The neuroprotective effect of dimethyl_fumarate in the MPTP-mouse model of PD (42), the findings of the above-mentioned studies led us to search for these small molecules, which provide a new idea for the next targeted drugs for the treatment of PD.

There were some limitations to our study. Firstly, our findings were derived by computer using in-depth calculations using bioinformatics methods and still require in vitro experiments to validate the results. Secondly, further animal models need to be constructed to collect samples of the specific mechanisms by which the central genes associated with cuproptosis contribute to PD, and initial validation of the animal models of PD using our personalized drugs will be required, and ultimately we will use samples from patients in the early stages of PD for validation, combined with clinical data to provide diagnostic biomarkers and timely drug interventions. In future studies, we will focus on the mechanisms of action of ATP7B, NFE2L2, and MTF1 in PD and explore early diagnostic biomarkers for PD.

## Section: Conclusions

Using bioinformatics analysis, CR-DEGs were identified in the substantia nigra of PD patients. ATP7B, together with NFE2L2 and MTF1, were considered as candidate genes for further study. This study provides new genes associated with Cu accumulation leading to cell death in the pathogenesis of PD and explores promising therapeutic targets for related neurodegenerative diseases.


---

# MF-PCBA: Multifidelity High-Throughput Screening Benchmarks for Drug Discovery and Machine Learning

- **Authors:** David Buterez, Jon Paul Janet, Steven J Kiddle, Pietro Liò
- **Issuer:** Journal of chemical information and modeling
- **Type:** Scientific article
- **Published:** 2023-04-14
- **Language:** en
- **DOI:** 10.1021/acs.jcim.2c01569
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37058588/
- **Licence:** CC-BY

## Section: Abstract

High-throughput screening (HTS), as one of the key techniques in drug discovery, is frequently used to identify promising drug candidates in a largely automated and cost-effective way. One of the necessary conditions for successful HTS campaigns is a large and diverse compound library, enabling hundreds of thousands of activity measurements per project. Such collections of data hold great promise for computational and experimental drug discovery efforts, especially when leveraged in combination with modern deep learning techniques, and can potentially lead to improved drug activity predictions and cheaper and more effective experimental design. However, existing collections of machine-learning-ready public datasets do not exploit the multiple data modalities present in real-world HTS projects. Thus, the largest fraction of experimental measurements, corresponding to hundreds of thousands of “noisy” activity values from primary screening, are effectively ignored in the majority of machine learning models of HTS data. To address these limitations, we introduce Multifidelity PubChem BioAssay (MF-PCBA), a curated collection of 60 datasets that includes two data modalities for each dataset, corresponding to primary and confirmatory screening, an aspect that we call multifidelity. Multifidelity data accurately reflect real-world HTS conventions and present a new, challenging task for machine learning: the integration of low- and high-fidelity measurements through molecular representation learning, taking into account the orders-of-magnitude difference in size between the primary and confirmatory screens. Here we detail the steps taken to assemble MF-PCBA in terms of data acquisition from PubChem and the filtering steps required to curate the raw data. We also provide an evaluation of a recent deep-learning-based method for multifidelity integration across the introduced datasets, demonstrating the benefit of leveraging all HTS modalities, and a discussion in terms of the roughness of the molecular activity landscape. In total, MF-PCBA contains over 16.6 million unique molecule–protein interactions. The datasets can be easily assembled by using the source code available at https://github.com/davidbuterez/mf-pcba.

## Section: Introduction

Machine learning (ML) techniques have enabled remarkable progress in the chemical and physical sciences, particularly in terms of fast and precise modeling of computationally expensive processes. Graph neural networks (GNNs), a class of geometric deep learning algorithms, have recently emerged as one of the leading ML paradigms for learning directly on the data types occurring in the life sciences. Thanks to their ability to naturally learn from non-Euclidean data structures, represented as objects (nodes) and their connections (edges), GNNs have the potential to model complex relationships and dependencies between nodes. Successful examples include but are not limited to tasks from particle physics,1 simulations of fluid dynamics and other physical systems,2 quantum chemistry,3 and drug discovery.4 However, such data-driven efforts are highly dependent on the quality, quantity, and availability of suitable data. Thus, a significant amount of research has been devoted to the development of high-quality datasets that support the rapidly advancing field of graph representation learning. In particular, challenging computational chemistry tasks such as quantum property prediction, drug-like molecule generation, and few-shot learning have put molecular data at the forefront of geometric deep learning research.

Publicly available molecular benchmarks span several areas of chemistry and are often tailored to domain-specific needs. For example, MoleculeNet is a suite of 16 molecular datasets and their variations, with tasks from quantum mechanics, physical chemistry, biophysics, and physiology.5 Consequently, there is a large variability in terms of the supervised learning task (regression or classification), number of output predictions/classes (multitask learning), dataset size (ranging from under 1000 compounds to over 430,000), and ML-specific concerns such as the node featurization strategy (atomic coordinates, atom type, etc.) and the random split strategy. A similarly diverse effort is Atom3D, a collection of eight tasks formulated specifically for learning based on three-dimensional molecular structures, for example, protein-interface prediction and prediction of ligand binding affinity and small-molecule properties.6

Experimental and computational advances paved the way to increasingly large, diverse, and challenging datasets. For example, although QM9 is one of the most well-known quantum mechanics benchmarks, concerns regarding its size (around 130,000 compounds) and composition (only five atom types and a maximum of nine heavy atoms per molecule) led to projects such as Alchemy7 (up to 14 heavy atoms), PubChemQC8 (quantum properties for up to 3 million molecules), QMugs9 (over 665,000 diverse molecules, up to 100 heavy atoms per molecule, and quantum properties at multiple levels of theory), and ANI-1x and ANI-1ccx10 (quantum properties at different levels of theory for 5 million and 500,000 molecules, respectively). For drug discovery, the well-known PCBA dataset11 is a collection of high-quality dose response data, formulated as a multitask learning benchmark from 128 high-throughput screening (HTS) assays. Models trained on experimental data of this nature are often used in a virtual screening setting, with the goal of identifying novel compounds of therapeutic interest. For the specific task of virtual screening, an alternative benchmark named LIT-PCBA was developed,12 addressing limitations of existing datasets such as hidden molecular biases.

We identified a lack of machine learning benchmarks that accurately reflect the practical aspects of drug discovery based on HTS, thus also limiting the potential for innovation in early-stage drug discovery projects. HTS follows a multitiered approach consisting of successive screens of drastically varying size and fidelity, most commonly a low-fidelity primary screen consisting of up to 2 million molecules in industrial settings and a high-fidelity confirmatory screen of up to 10,000 compounds. Usually, the screens are used as successive filters to select the most promising molecules for further optimization. Despite the success of HTS in identifying clinical candidates and FDA-approved drugs,13−15 computational methods have traditionally neglected the multitiered design of HTS. Existing datasets and applications, such as PCBA, LIT-PCBA, and approaches based on HTS fingerprints, are formulated on single-fidelity data.11,12,16−19 The single-fidelity measurements generally correspond to the highest-fidelity measurements available (dose response), which leads either to extremely small datasets for machine learning (<10,000 compounds) or to highly sparse representations extracted from hundreds of assays.

Neglecting the multiple modalities of HTS experiments has the major downside of discarding millions of lower-fidelity measurements that cover an orders-of-magnitude larger and more diverse chemical space. Integrating all of the available data has the potential to improve drug potency predictions, help guide the experimental design, save costs associated with multiple expensive experiments, and ultimately lead to the identification of new drugs. Indeed, we have recently demonstrated considerable uplifts in predictive performance when multifidelity data are incorporated through a novel, specifically designed GNN approach.20 We have also demonstrated transfer learning capabilities between the different data modalities, an area that has also recently received interest in quantum machine learning.3,21

In this work, we expand upon our initially reported collection of public multifidelity HTS datasets, reporting a total of 60 datasets with over 16.6 million unique protein–molecule interactions extracted from PubChem. We cover in detail the search, selection, and filtering steps and also provide a performance evaluation based on the methodology proposed by Buterez et al.20 We envision that the provided datasets will motivate the development of new graph representation learning methods capable of multifidelity modeling and transfer learning, thus advancing the state of the art in computational drug discovery projects. At the same time, we believe that the challenging properties of multifidelity HTS data will provide a new benchmark for evaluating machine learning algorithms, particularly in terms of molecule-level regression tasks, which are not well represented at this scale in existing work. It is important to note that the MF-PCBA datasets are representation-agnostic, as the molecular information is presented in the form of SMILES strings, such that a variety of machine learning techniques are applicable (not exclusively deep learning). Ultimately, we hope that the MF-PCBA datasets will motivate further research and competition, thus advancing the field and enabling new possibilities for drug discovery and molecular modeling. The datasets can easily be assembled using the provided scripts (https://github.com/davidbuterez/mf-pcba).

## Section: Methods

Main steps of assembling a multifidelity HTS dataset from the corresponding primary and confirmatory screens, which might be reported in the same or different PubChem assays. First, the SMILES string for each molecule is loaded into RDKit, which removes invalid structures. This procedure is followed by a number of filtering steps that ensure a high-quality data collection for drug discovery and machine learning projects, including selection of only the largest fragments, removal of stereoisomers, and removal of electric charges. Finally, missing DR values in the confirmatory assay are set to a default value corresponding to the minimum activity (“pXC50”) observed in the project.

A multifidelity integration workflow illustrated with three high-level steps. Confirmatory-level data (DR) can be modeled directly using various machine learning techniques such as RF, SVM, or GNN. Despite not leveraging hundreds of thousands of bioaffinity measurements from the primary screens, this is the prevalent type of modeling in early-stage drug discovery. Instead, an alternative is to model the primary screening (SD) separately and incorporate the learned information through techniques such as transfer learning. Here, this is achieved through graph or molecular embeddings. The embeddings can be included (by concatenation) in the DR modeling step, a procedure we denote as augmentation. We also consider the addition of the SD label to the DR model as an alternative augmentation strategy.

## Section: Methods › Data Acquisition

We manually searched the PubChem BioAssays database using the terms “high-throughput screening”, “HTS”, “primary”, “confirmatory”, “single dose”, “dose response”, “SD”, and “DR”. We selected the latest version (at the time of writing) for each assay. The date range of the assays is 2008–2018 (the exact versions, revisions, and dates are provided in the Supporting Information (SI)). The manual search step is necessary due to the nature of reporting HTS results. Primary and confirmatory screening results might be reported in the same bioassay, e.g., assay identifier (AID) 1445, or as separate bioassays that are part of the same project, e.g., primary AID 602261 and confirmatory AID 624326. Furthermore, different primary and confirmatory projects use different formats and conventions when reporting measurements. Among the selected bioassays, primary screens might be reported at different concentrations and with multiple replicates. Similarly, confirmatory screens can be reported in different formats (usually IC50, AC50, or EC50), but the units (e.g., μM or μg/mL) are not always consistent. The smaller collection of 23 datasets previously discussed by Buterez et al. focused on a diverse but restricted number of assays to allow for an in-depth analysis of both PubChem and proprietary data while also emphasizing certain dataset attributes such as the (linear) correlation between the single dose (SD) and dose response (DR) values. The updated collection presented in this work further increases the diversity of the assays and the number of curated datasets, allowing a more comprehensive view of HTS modeling strategies and challenging current methods.

Once our selection of 60 datasets was finished, we could automate the remaining steps. To this end, we used PubChem’s representational state transfer application programming interface (REST API) to retrieve each assay as a comma-separated values (CSV) file based on its AID, downloading at most 10,000 compound rows at a time. The raw CSV files contain the compound ID (CID) for each molecular entry but no molecular structure information. To address this, we again used the REST API to retrieve the Simplified Molecular-Input Line-Entry System (SMILES) string representation for each entry based on the CID. Any replicate measurements present for the primary screens are aggregated by taking the mean. In the associated source code, the option of using the median is also provided. Only 23 out of the 60 primary screens have more than two replicates, and even in these cases only a fraction of the entire compound library is present in the replicates, leading to a small difference between the mean and median (Table S3 and section SI 2). The resulting SD measurements are not further processed. In contrast, for the DR measurements the aggregation step is not necessary, as generally there are no replicates in the same bioassay. However, the DR values, which are often reported as “XC50” (IC50, AC50, or EC50) values or variations involving the logarithm, are always converted to the corresponding pXC50 values (pXC50 = −log XC50). The entire collection of 60 multifidelity datasets is summarized in Table 1 along with details specific to each dataset. These datasets cover a wide spectrum of assay technologies and end points, from biochemical inhibition data to phenotypic experiments on whole organisms.

## Section: Methods › Filtering Steps

The raw molecular information is subjected to a number of filtering steps that ensure a high-quality, consistent representation suitable for various machine learning algorithms. In the majority of cases, the primary and confirmatory screens are reported as separate bioassays in PubChem. Thus, the filtering steps are applied independently on the SD and DR datasets. In the case where the primary and confirmatory data are reported in a single bioassay, the same filtering steps are applied on the single data table. Filtering is always applied after the preprocessing steps described above. The filtering pipeline consists of four major steps implemented using the open-source library RDKit22 (also illustrated in Figure 1):1.Sanitization with RDKit: The function Chem.MolFromSmiles from RDKit was used to construct a molecular object, represented by the Mol class. This representation provides access to the molecular structure and to other filtering-relevant functions regarding stereoisomers, removal of charges, etc. Importantly, loading the SMILES string into RDKit acts as an initial filtering step by itself, as RDKit uses a sanitization procedure internally. This resulted in a number of entries (molecules) being removed, most commonly due to valence errors or SMILES strings consisting only of hydrogen atoms.2.Largest fragment selection: Next, we used RDKit’s rdMolStandardize.LargestFragmentChooser function to remove molecules where the CID contained a combination of compounds, most commonly a counterion. The option to remove smaller fragments but keep the largest one is also provided in the source code. There is also an option to report small fragments that are not encountered in the MF-PCBA collection when assembling data from different assays. For MF-PCBA, almost all encountered small fragments are counterions or solvents.3.Stereoisomer removal: The function rdmolops.RemoveStereochemistry was used to remove all of the stereochemistry information contained within the molecules, followed by generation of new SMILES representations for all of the resulting molecular objects. Molecules that were previously differentiated only by the stereochemical information now have identical representations. Thus, we select only the unique molecules based on the SMILES representation and consider the task of modeling the activity of racemic mixtures. It should be noted that many GNNs operate on molecules only at the level of “2D” graphs, such that the stereochemical information is not considered. An option to keep the molecules that would be removed by this step is also provided, as well as an option to record the number of stereocenters for each molecule.4.Neutralization (removal of electric charges): This step is achieved by adding or removing hydrogens for charged atoms. Only compounds that can be recorded with a formal charge of 0 are retained. Generally, compounds that cannot pass this threshold are difficult to transform into safe drugs, motivating our filtering procedure. The calculations are performed using atom-level RDKit functions such as GetFormalCharge, GetTotalNumHs, SetFormalCharge, SetNumExplicitHs, and the filtering of molecules is based on rdmolops.GetFormalCharge.

We report the average number of compounds removed by each step in the Results. The numbers of SD and DR compounds after each filtering step are reported for all datasets in Tables S1 and S2, respectively. Generally, the filtering steps that removed the most compounds are largest fragment selection and stereoisomer removal. With a few exceptions, the filtering pipeline did not radically change the size of the dataset. However, one important issue was observed for the DR datasets that originated in different PubChem bioassays. Although the confirmatory bioassays contain partial experimental measurements for all of the compounds listed in Table S2, actual DR values such as the IC50 are often reported only for a fraction of the dataset, for example, only for active compounds. Although some DR datasets do not suffer from this issue (e.g., AID 1445), others are at the other extreme of the spectrum, with up to 97.8% of filtered compounds lacking explicit XC50 measurements (AID 1117362). On average, 35.57% of compounds do not possess experimentally derived XC50 labels because they were insufficiently active at the top concentration. To address this limitation, we associated the compounds missing this information with the lowest activity value recorded in each dataset (“Minimum pXC50” in Figure 1), providing a training target for machine learning models. This is done to provide a consistent value for inactive molecules and should be interpreted as a lower bound on the pXC50 value. We maintain a flag for each molecule indicating whether its confirmatory activity was experimentally derived or set to a default value.

Main steps of assembling a multifidelity HTS dataset from the corresponding primary and confirmatory screens, which might be reported in the same or different PubChem assays. First, the SMILES string for each molecule is loaded into RDKit, which removes invalid structures. This procedure is followed by a number of filtering steps that ensure a high-quality data collection for drug discovery and machine learning projects, including selection of only the largest fragments, removal of stereoisomers, and removal of electric charges. Finally, missing DR values in the confirmatory assay are set to a default value corresponding to the minimum activity (“pXC50”) observed in the project.

## Section: Methods › Implementation

The data acquisition and filtering steps are implemented as a Python script (pubchem_retrieve.py) with a simple command-line user interface. The program allows downloading and filtering all 60 MF-PCBA datasets as well as any other PubChem assays with similar formats. The main arguments are --AID, indicating the AID of a PubChem assay corresponding to an SD experiment; --AID_DR, optionally indicating the AID of a PubChem assay corresponding to a DR experiment that is separate from the SD dataset; --list_of_sd_cols, indicating the names of the SD activity value columns (including replicates) as displayed on PubChem; --list_of_dr_cols, indicating the names of the DR activity value columns; and transform_dr, allowing the conversion to the corresponding pXC50 value. More advanced filtering options are documented in the source code. The GitHub repository contains customized scripts (i.e., with all of the arguments already set) for all 60 MF-PCBA datasets, such that they can be simply downloaded and assembled with a single call to the intended script. Once downloaded and filtered, the DR datasets can be split into train, validation, and test sets according to the provided five random seeds, enabling easy comparison to the results obtained by previous work and in this article. Splitting is demonstrated with an interactive notebook that is part of the source code.

## Section: Methods › MF-PCBA Format and Problem Specification

After filtering, each of the 60 multifidelity datasets contains the PubChem CID for each molecule, the corresponding molecular structure (SMILES), and the SD and DR activity values. If the SD and DR data originated from the same bioassay, both the SD and DR modalities are provided in the same CSV file. In this case, the name of the multifidelity dataset is given by the original assay name, e.g., AID 1445. Otherwise, separate SD and DR files are provided, and the naming scheme reflects the two data sources, with the DR dataset first (e.g., AID 624326 – 602261).

One of the intended purposes of MF-PCBA is to enable high-quality confirmatory-level predictions by modeling of DR data. Thus, the prediction problem can be naturally formulated as a supervised regression task. At the same time, the binary activity labels from PubChem are included for each dataset. Large amounts of SD activity values are available to support the goal of multifidelity integration for improving the quality of confirmatory-level predictions. Furthermore, we provide five random splits per dataset (80%/10%/10% split ratios for the train/validation/test sets) for the DR data. The accompanying source code allows easy conversion of the CSV files obtained previously into individual train/validation/test CSV files corresponding to each random split seed. A wide range of machine learning techniques are applicable on MF-PCBA, including any algorithm that operates on fixed-dimension vector representations (molecular fingerprints, physical and chemical descriptors, atom and bond encodings, etc.).

As the MF-PCBA collection is based entirely on real-world data generated by HTS experiments, it enables the design and evaluation of new machine learning architectures specifically for drug discovery. Additionally, MF-PCBA can be used as a suite of benchmarks for evaluating the performance of newly developed machine learning applications. For example, MF-PCBA can support the rapidly developing field of representation learning with graph neural networks, particularly in terms of graph-level regression tasks, which are currently underrepresented. At the same time, the collection offers a unique challenge in the form of multifidelity (multimodality) integration. This is a characteristic of drug discovery by HTS that presents new opportunities for computational modeling and ultimately for improved experimental and hybrid wet-lab and in silico workflows. We also envision that the data curated here can be used for other modern machine learning techniques such as generative approaches and few-shot learning.

## Section: Methods › Assay Overlap and Size Considerations

Since PubChem and ChEMBL23,24 are frequently used as data sources for machine learning, it is important to fully characterize MF-PCBA in terms of size, scope, and intended applications. Although many previous studies considered drug bioaffinity data (the ChEMBL 20-derived subset of Mayr et al.,25 PCBA,11 LIT-PCBA,12 and FS-Mol26 are just a few examples), to the best of our knowledge no previous work explicitly considered HTS data of different fidelities or proposed transfer learning in this context. Despite not being purposefully designed to be orthogonal to existing datasets, MF-PCBA shares no overlap in terms of common assays with the 128 assays of PCBA. Twenty-seven of the confirmatory assays that we use are also present in the 1310 assays reported by Mayr et al. There is no overlap in terms of the primary screening assays. We would like to note that a small level of overlap is expected considering that Mayr et al. focused on a large number of generally confirmatory assays extracted from the ChEMBL 20 database. Furthermore, our motivation and our preprocessing and evaluation pipelines are different.

In terms of size, MF-PCBA consists of over 16.6 million unique compound–target interactions, with over 1.1 million unique compounds. In contrast, the largest dataset based on the number of compounds that is reported in the comparison provided by the FS-Mol study has 955,386 compounds. The number of measurements is also larger than in FS-Mol and LSC.27 Moreover, rigorously tagged primary and confirmatory data are more limited compared to other data types. An example search through PubChem returns 407 confirmatory DR datasets (the search steps are described in section SI 10). However, not all of them qualify for MF-PCBA. For example, some assays study toxicity effects or are missing an associated primary screen. As such, some degree of manual selection is required to satisfy all of the previously defined criteria. Overall, the MF-PCBA collection aims to provide a diverse set of multifidelity datasets that is easily extensible through the open source implementation.

Finally, we note that we currently only consider single-task learning, such that a separate model is trained for each of the datasets present in MF-PCBA. This also has the advantage of enabling the use of a wide range of machine learning algorithms other than deep learning. While multitask learning is a common occurrence in chemical modeling projects (e.g., PCBA, FS-Mol), it is not one of the main objectives for MF-PCBA. Since the data uploaded to PubChem originate from various groups using different compound libraries and protocols, the overlap between the chosen assays in terms of common compounds is limited. If we associate all of the unique compounds of MF-PCBA with their activities in the primary screens (or NaN if a compound is not screened in the assay), we find that over 75.6% of values are NaNs. For confirmatory screens, this grows to over 97.7%. Previous work on HTS fingerprints assigned a default activity value (usually 0) to all missing values. Since the true activity is not known, this would lead to a multitask learning scenario where over two-thirds of the data have false values. Sturm et al.19 succeeded in assembling a collection of only 57,124 molecular fingerprints with reduced sparsity, despite starting with an industrial collection of 1250 HTS assays that are generally expected to use the same or similar compound libraries. However, multitask learning for a subset of MF-PCBA with a larger overlap could be an interesting direction for future research.

## Section: Methods › Evaluation Strategies and Multifidelity Modeling

As a first step, we provide an evaluation of the multifidelity integration performance for all 60 datasets based on the multifidelity modeling workflow recently proposed by Buterez et al.20,28 (Figure 2). In this context, the machine learning task is formulated as a supervised learning problem on confirmatory data, i.e., molecules with DR measurements. Thus, the simplest task is training and evaluating models exclusively on data points with DR labels, corresponding to training sets with typically less than 2000 instances, and ignoring the orders-of-magnitude larger SD datasets. Multifidelity modeling is achieved through two augmentation strategies that integrate information derived from the SD data. The first augmentation corresponds to the inclusion of the experimentally determined SD activity value in the internal representation (fixed-dimension vector) of each compound in a machine learning model, corresponding to an append/concatenation operation. All compounds that possess DR activity values typically have an associated SD value, making this strategy generally applicable to HTS datasets. The second augmentation requires a separate machine learning model (here, a graph neural network) to be trained on the entirety of the available SD data in a supervised fashion. In this process, the GNN learns to produce SD embeddings, low-dimensional vector representations that carry the molecular information and its SD activity. The resulting SD embeddings can be appended to the internal representation of a machine learning model exactly as for the first augmentation, with the important advantage that the embeddings can be produced for molecules that were not seen during training. Both augmentations are applicable to any machine learning method operating on fixed-dimension vectors.

The evaluation includes three machine learning algorithms for DR modeling: random forests (RF), support vector machines (SVM), and deep learning (GNNs). Separately, we use GNNs for the SD modeling step. The same hyperparameter optimization strategy and the same steps for determining the most suitable deep learning architecture as in the aforementioned study were are also applied. When designing models for MF-PCBA, we recommend evaluating in terms of “DR only” models, which are trained exclusively on confirmatory activity data, and “SD + DR” models that integrate the two modalities. In terms of performance metrics, we recommend the use of R2 coupled with an error metric such as the mean absolute error (MAE) or root-mean-square error (RMSE) for regression tasks and the Matthews correlation coefficient (MCC) coupled with the area under the receiver operating characteristic curve (AUROC) for classification. The choice is based on both recent recommendations from the literature29,30 and the nature of the data.

A multifidelity integration workflow illustrated with three high-level steps. Confirmatory-level data (DR) can be modeled directly using various machine learning techniques such as RF, SVM, or GNN. Despite not leveraging hundreds of thousands of bioaffinity measurements from the primary screens, this is the prevalent type of modeling in early-stage drug discovery. Instead, an alternative is to model the primary screening (SD) separately and incorporate the learned information through techniques such as transfer learning. Here, this is achieved through graph or molecular embeddings. The embeddings can be included (by concatenation) in the DR modeling step, a procedure we denote as augmentation. We also consider the addition of the SD label to the DR model as an alternative augmentation strategy.

## Section: Results

In this section, we first report the effect of the filtering steps with regard to the number of removed compounds. We then discuss one of the intended uses of the MF-PCBA datasets by evaluating multifidelity integration machine learning techniques. We use the same modeling techniques previously proposed by Buterez et al., focusing on the analysis of the additional 37 datasets that complete the collection of 60 datasets, as the remaining 23 have already been extensively investigated. In order to highlight meaningful differences between the initial collection of 23 multifidelity datasets and MF-PCBA, we introduce the following naming conventions: the terms MF-PCBA and MF-PCBA-60 are used interchangeably to refer to the entire collection of 60 multifidelity datasets; MF-PCBA-23 refers to the previously analyzed subset;20 and MF-PCBA-37 refers to the remaining 37 datasets that complete the collection of 60 datasets. Thus, MF-PCBA-23 and MF-PCBA-37 are disjoint.

Predictive performance, as measured by R2, on (a) MF-PCBA-37 (the subset of 37 multifidelity datasets not discussed by Buterez et al.), (b) MF-PCBA-60 (the entire collection of 60 multifidelity datasets), and (c, d) two examples of individual multifidelity datasets from the MF-PCBA-37 subset. The results in (a) and (b) aggregate metrics from each individual dataset. For each dataset, results are reported for augmented and nonaugmented RF, SVM, and deep learning models. Each model was trained multiple times based on the five different random splits for each dataset. For (a) and (b), the means across five different random splits for each dataset are used to generate box plots.

Plots of the absolute SD/DR correlation (x axis) against ΔR2 (y axis) for RF, SVM, and deep learning models augmented with SD labels on MF-PCBA-37 and MF-PCBA-60, with the Pearson correlation coefficient (r). Brighter colors correspond to higher ΔR2 values. Plots for the SD embeddings augmentation are available in section SI 4.

(a–c) Plots of the ROGI (x axis) against R2 (y axis) for nonaugmented (base), SD-labels-augmented, and SD-embeddings-augmented SVM models. (d–f) Plots of the ROGI (x axis) against the ΔR2 (y axis) for RF, SVM, and deep learning models augmented with SD labels. All panels include the Pearson correlation coefficient (r). Brighter colors correspond to higher R2 or ΔR2 values. Plots for the rest of the models are available in sections SI 5 and SI 6.

## Section: Results › Effects of Filtering on Dataset Size

1.Sanitization with RDKit: On average, this step led to the removal of 863 ± 1313.8 (average ± standard deviation) compounds for the SD datasets (0.33% of the unfiltered size) and 8.7 ± 42.7 for the DR datasets (0.46% of the unfiltered size). For the DR datasets, more than 10 compounds were removed only for two datasets.2.Largest fragment selection: After this step, 11207.9 ± 3594.3 compounds were removed for the SD datasets (3.62% of the quantity at the previous filtering step) and 115.3 ± 110.3 for the DR datasets (7.83% compared to the previous step).3.Stereoisomer removal: After this step, 11396.3 ± 23859.4 compounds were removed for the SD datasets (3.78% of the quantity at the previous filtering step) and 30.7 ± 92.3 for the DR datasets (2.49% compared to the previous step). We choose to remove this information because stereochemical annotations are not consistently recorded and not effectively exploited by many baseline methods.4.Neutralization (removal of electric charges): After this step, 396.6 ± 94.4 compounds were removed for the SD datasets (0.15% of the quantity at the previous filtering step) and 3.9 ± 5.1 for the DR datasets (0.31% compared to the previous step).

## Section: Results › Integration of SD Information Increases Predictive Performance

Previously it was shown that the integration of primary screening information leads to increased performance for the augmented machine learning models. At the same time, many of the datasets that exhibited considerable improvements by multifidelity integration also possessed certain qualities such as high correlation between the SD and DR experimental measurements.

It is thus encouraging to observe that we are able to obtain similar uplifts in predictive performance for the augmented models on the previously unanalyzed 37 multifidelity datasets (Figure 3a). More specifically, the augmentation with SD labels leads to uplifts in R2, on average, from 0.219 to 0.285 for RF, from 0.228 to 0.279 for SVM, and from 0.244 to 0.312 for deep learning. Similarly, for the SD embeddings augmentation, we observe uplifts in R2, on average, from 0.219 to 0.245 for RF, from 0.228 to 0.252 for SVM, and from 0.244 to 0.277 deep learning. This lower performance compared to the SD labels augmentation should be balanced against its unique ability among these methods to produce predictions for unobserved molecules.

As for MF-PCBA-23, we encounter several datasets that benefit drastically from the augmentation strategies. For example, on AID2247 – AID434942 (Figure 3c), an uplift from 0.048 to 0.435 in average R2 is seen for RF with the SD labels augmentation, and an almost identical uplift to 0.436 is achieved for the SD embeddings augmentation. In this particular case, the SD embeddings augmentation is also substantially more effective in reducing the MAE compared to the nonaugmented and SD-labels-augmented models, by almost halving it (section SI 2). Large uplifts are also observed for other datasets such as AID2237 – AID434937 (Figure 3). We also provide an alternative metric in the form of the “unexplained” variance (1 – R2) in section SI 3.

On average, and compared to the previously studied 23 multifidelity datasets, we generally observe both lower nonaugmented and augmented performance. In particular, the average R2 for the nonaugmented models on MF-PCBA-23 is 0.253, while for MF-PCBA-37 the observed value is 0.230. The average R2 achieved by augmenting with SD labels on MF-PCBA-23 was 0.380, compared with 0.291 on MF-PCBA-37. Finally, augmenting with SD embeddings led to an average R2 of 0.306 on MF-PCBA-23 and 0.257 on MF-PCBA-37. The lower overall performance on MF-PCBA-37 could be explained by lower SD/DR correlation or a notion of dataset difficulty, ideas that are explored further below.

We also studied a variation of the SD labels augmentation where for each compound we computed an “SD fingerprint” (SD FP), a vector consisting of all primary screening activities or 0 if such data are unavailable. The SD fingerprint is used in place of the SD label, similar to an SD embedding. We evaluated this variation using deep learning models on MF-PCBA-60. On the whole, the SD FP augmentation only marginally improved upon the baseline models and severely underperformed compared to the SD labels augmentation (section SI 11). This is not unexpected considering the low compound overlap between assays in MF-PCBA and the low chance of the assay targets being related. When considering individual dataset performance, the SD FP augmentation often performed worse than the baseline, alternatively matching the SD labels performance and rarely improving upon it (section SI 12). We did notice that in seven out of 60 cases the SD-FP augmentation outperformed the SD labels augmentation: AID720632 – AID686996 (Figure S53), AID1465 (Figure S67), AID2382 – AID2098 (Figure S77), AID434954 – AID2097 (Figure S82), AID743267 – AID720511 (Figure S84), AID435004 – AID504408 (Figure S92), and AID463203 – AID2650 (Figure S99). Although this augmentation does not offer consistent performance, it is an interesting alternative for poorly performing datasets like AID1465.

To validate the choice of using average R2 scores as part of the evaluation procedure (e.g., as the basis of Figure 3), we computed the average R2 across the five random splits for each dataset and considered nine groups of 60 scores each (corresponding to the 60 datasets). The nine different groups correspond to the three different ML algorithms (RF, SVM, and deep learning) and the three different augmentations (base models, augmented with SD labels, and augmented with SD embeddings). We performed paired t tests between each group of augmented scores and the baseline scores (for each ML algorithm), for six tests in total. The tests indicated statistically significant results for all SD label augmentation groups (p < 0.0001) as well as for the SD embeddings (p < 0.01).

Predictive performance, as measured by R2, on (a) MF-PCBA-37 (the subset of 37 multifidelity datasets not discussed by Buterez et al.), (b) MF-PCBA-60 (the entire collection of 60 multifidelity datasets), and (c, d) two examples of individual multifidelity datasets from the MF-PCBA-37 subset. The results in (a) and (b) aggregate metrics from each individual dataset. For each dataset, results are reported for augmented and nonaugmented RF, SVM, and deep learning models. Each model was trained multiple times based on the five different random splits for each dataset. For (a) and (b), the means across five different random splits for each dataset are used to generate box plots.

## Section: Results › Relationship between the Predictive Performance and Dataset Attributes

Previous work on multifidelity modeling found the correlation between the SD/DR measurements to be a good indicator of model performance and of possible uplifts.20 Here we also performed an analysis of ΔR2 (the difference in performance between augmented models that perform multifidelity integration of SD and DR and nonaugmented DR-only models) as an indicator of the gains possible through augmentation, using both Pearson’s correlation coefficient and multiple linear regression models, for MF-PCBA-37 and MF-PCBA-60.

On MF-PCBA-37, no linear correlation is observed between ΔR2 and the SD/DR correlation for all three machine learning algorithms when augmenting with SD labels (Figure 4a–c) and when augmenting with SD embeddings (Figures S45a–c). However, on MF-PCBA-60 a moderate positive relationship is still present (Figures 4d–f and S45d–f). Interestingly, this indicates that the level of SD/DR correlation is not always indicative of the performance uplift, as some of the highest gains seen on MF-PCBA-37 were for datasets with extremely low correlation (e.g., AID434942 – AID2247 and AID434937 – AID2237). Multiple linear regression models did not indicate significant contributions from any other dataset attribute other than the SD/DR correlation, such as the number of DR compounds or the number of SD compounds for MF-PCBA-60 (Tables S7–S12).

Plots of the absolute SD/DR correlation (x axis) against ΔR2 (y axis) for RF, SVM, and deep learning models augmented with SD labels on MF-PCBA-37 and MF-PCBA-60, with the Pearson correlation coefficient (r). Brighter colors correspond to higher ΔR2 values. Plots for the SD embeddings augmentation are available in section SI 4.

## Section: Results › Evaluating the Difficulty of Learning with the Roughness Index

The “roughness” of the molecular activity landscape can provide insights into the level of difficulty that machine learning models are expected to encounter and also reveal challenging dataset characteristics such as activity cliffs. To quantify this property, we use the recently introduced roughness index (ROGI),31 which can be applied only to the DR datasets because its computation scales quadratically with the dataset size. Intuitively, the ROGI works by coarse-graining a molecular dataset at different levels and quantifying the change in dispersion, which might be affected rapidly or slowly. The notion of dispersion is quantified using the standard deviation of the molecular property. This is related to the idea that similar molecules with extremely different properties (e.g., activity) lead to rapidly changing dispersion.

We computed the ROGI based on the 208 PhysChem descriptors available in RDKit as of October 2022 (the rdkit.ML.Descriptors.MoleculeDescriptors.MolecularDescriptorCalculator function). The alternative, based on Morgan fingerprints also computed by RDKit, led to small ROGI values for all MF-PCBA datasets. Furthermore, the ROGI computation is applied to the filtered datasets before setting missing DR values to the minimum pXC50 value. This prevents artificially modifying the ROGI, for example by “flattening” the activity space. In contrast, all of the trained machine learning models use the entire set of DR values, including the minimum defaults, to exploit the entire amount of data available.

In general, the datasets introduced in the MF-PCBA-60 collection do not appear difficult in terms of the roughness of the chemical space, with ROGI values ranging from 0.014 to 0.571, with an average ± standard deviation of 0.167 ± 0.135 and most of the datasets scoring below 0.4 (see Figure S48 for a histogram). The performance metric (R2) is not correlated with the ROGI for the RF, SVM, and deep learning nonaugmented (base) models (Figures 5a and S46a,c). However, it is possible to observe statistically significant weak, negative linear correlations for the augmented RF and SVM models (Figures 5b,c and S46d,g). The relationship between the ROGI and ΔR2 is not significant for any model at a significance level of 0.05 (Figures 5d,f and S47d–f), but in the case of SVM and deep learning the p values are close, especially in the case of deep learning (p = 0.05042). The highest uplifts in performance are observed for datasets with relatively low ROGI (<0.3), with extremely small or even negative performance differences for the highest difficulty datasets (ROGI > 0.5). Finally, multiple linear regression models did not indicate significant contributions from the ROGI (section SI 9).

(a–c) Plots of the ROGI (x axis) against R2 (y axis) for nonaugmented (base), SD-labels-augmented, and SD-embeddings-augmented SVM models. (d–f) Plots of the ROGI (x axis) against the ΔR2 (y axis) for RF, SVM, and deep learning models augmented with SD labels. All panels include the Pearson correlation coefficient (r). Brighter colors correspond to higher R2 or ΔR2 values. Plots for the rest of the models are available in sections SI 5 and SI 6.

## Section: Discussion

We have presented MF-PCBA, a new collection of 60 multifidelity molecular datasets that reflect the real-world nature of HTS projects in drug discovery. With over 16.6 million unique protein–molecule interactions in total, MF-PCBA represents one of the largest collections of graph-level regression datasets, with the possibility to easily adapt to classification. The multifidelity aspect, enabled by the inclusion of primary and confirmatory screening data, is underrepresented in existing molecular modeling efforts, most likely due to uncertainties regarding the noisiness of the data and the vastly different numbers of compounds between the primary and confirmatory screens. Here we have further validated the value of utilizing multifidelity bioactivity measurements, for example by observing uplifts in R2, on average, between 33% and 40% when using SD labels and depending on the algorithm, further supporting the need for an effective and public multifidelity benchmark, as provided here. Moreover, we have shown that while the SD/DR correlation is a factor in the level of benefit gained by using multifidelity modeling, it is not as strong a factor as had previously been thought.

We showed some tentative signs that the roughness of the activity landscape, as measured by the ROGI, might be another factor, but further work is needed to clarify this and identify additional factors in similar or larger collections. As shown previously, multifidelity modeling can also lead to other desirable properties such as more selective models and new candidate selection workflows. Thus, we envision multifidelity data and models to be a natural step forward for early-stage drug discovery projects based on high-throughput screening. To support this vision, the 60 MF-PCBA datasets are available publicly, aiming to capture the heterogeneity of HTS campaigns in terms of, for example, assay type, targets, screening technologies, primary and confirmatory screen sizes, concentrations, and scoring metrics. Moreover, due to the challenging nature of multifidelity integration, MF-PCBA can act as a representation learning benchmark for future machine learning research and, in particular, for the rapidly advancing area of graph neural networks. At the same time, MF-PCBA is not limited to deep learning, as a multitude of existing machine learning techniques can be applied, enabling more varied comparisons. Overall, we believe that the presented datasets can be used as a basis for advancing both computational drug discovery efforts and molecular machine learning techniques.

## Section: Data Availability

The source code to download, filter, and assemble all 60 MF-PCBA datasets (individually) is available at https://github.com/davidbuterez/mf-pcba. The run time for AID 504329 (335,445 SD molecules) is 554.52 s (9 min 15 s) on a workstation equipped with an AMD Ryzen 5950X processor with 16 cores and 64 GB of DDR4 RAM running Ubuntu 21.10 with an Internet connection speed of 85.81 Mbps (download).


---

# Navigating bioactivity space in anti-tubercular drug discovery through the deployment of advanced machine learning models and cheminformatics tools: a molecular modeling based retrospective study

- **Authors:** Ratul Bhowmik, Ravi Kant, Ajay Manaithiya, Daman Saluja, Bharti Vyas, Ranajit Nath, Kamal A Qureshi, Seppo Parkkila, Ashok Aspatwar
- **Issuer:** Frontiers in pharmacology
- **Type:** Scientific article
- **Published:** 2023-08-29
- **Language:** en
- **DOI:** 10.3389/fphar.2023.1265573
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37705534/
- **Licence:** CC-BY

## Section: Abstract

Mycobacterium tuberculosis is the bacterial strain that causes tuberculosis (TB). However, multidrug-resistant and extensively drug-resistant tuberculosis are significant obstacles to effective treatment. As a result, novel therapies against various strains of M. tuberculosis have been developed. Drug development is a lengthy procedure that includes identifying target protein and isolation, preclinical testing of the drug, and various phases of a clinical trial, etc., can take decades for a molecule to reach the market. Computational approaches such as QSAR, molecular docking techniques, and pharmacophore modeling have aided drug development. In this review article, we have discussed the various techniques in tuberculosis drug discovery by briefly introducing them and their importance. Also, the different databases, methods, approaches, and software used in conducting QSAR, pharmacophore modeling, and molecular docking have been discussed. The other targets targeted by these techniques in tuberculosis drug discovery have also been discussed, with important molecules discovered using these computational approaches. This review article also presents the list of drugs in a clinical trial for tuberculosis found drugs. Finally, we concluded with the challenges and future perspectives of these techniques in drug discovery.

## Section: Introduction

Tuberculosis (TB) is a bacterial disease caused due to the infection of Mycobacterium tuberculosis (Mtb), which has been a chronic infectious disease for decades. According to the WHO, approximately 30 million persons are expected to be infected with the bacillus within 20 years (Vastrad, 2012). It typically affects the lungs and other regions of the body, such as the spine, kidneys, and brain, if not treated swiftly. Tuberculosis (TB) has been proclaimed a global public health emergency by the WHO (Adeniji et al., 2018). As a result, discovering novel medications effective against MDR (Multidrug-resistant) TB, extensively drug-resistant TB (XDR TB), and latent TB is a key priority (Dwivedi et al., 2011; Gautam et al., 2023). Directly Observed Treatment Short is one of the most common anti-TB strategies (DOTS). This method, however, may be ineffective if performed incorrectly, leading to resistance to anti-TB drugs. MDR-TB will develop if anti-TB drug regimens are provided in incorrect dosages or with low-quality drugs (MDR-TB).

Moreover, if administered to treat individuals who are HIV-positive or have compromised immune systems, it could lead to the emergence of widespread drug-resistant tuberculosis (XDR-TB) (Shetye et al., 2020). Isonicotinic acid, Hydrazide, Rifampicin, Ethambutol, Streptomycin, and other drugs have been used extensively in treating tuberculosis (Vastrad, 2012). Although tuberculosis death is often preventable, the rapid rise in MDR and XDR-TB has necessitated the development of new drug targets for Mtb (Chapman et al., 2012). TB is transferred mainly through the air when a healthy individual inhales these bacteria, which are droplets from air contaminated and take entry into the lungs. Either the host gets a primary infection, or the illness remains dormant. Alveolar macrophages perceive them as external agents who attempt to engulf the bacterium during this process. On the other hand, complete bacterium deactivation is nearly impossible to achieve. As a result, the bacteria multiply and infect macrophages, spreading to other parts of the lung ( Ahamad et al., 2017; Jin et al., 2017). This study aims to enhance anti-tubercular drug discovery by integrating advanced machine learning and cheminformatics tools. Using a molecular modeling-based approach, we aim to quickly identify potential drug candidates and targets against Mycobacterium tuberculosis, addressing drug-resistant strains. We’ll explore computational techniques like QSAR, molecular docking, and pharmacophore modeling to streamline drug discovery. Our goal is to predict, characterize, and prioritize drug molecules, including lead structures and novel targets, while assessing their versatility and utility. We’ll also highlight ongoing clinical trials and evaluate challenges and future prospects in computational drug discovery. Through these efforts, we aim to advance targeted therapies against drug-resistant tuberculosis using advanced computational methods.

Drug design techniques and groups.

Schematic presentation of the drug discovery and development process.

## Section: Introduction › Mechanisms of action and limitations of antitubercular drugs

These drugs are categorized according to their source, like synthetic, semisynthetic, and natural products. Patient situation/stage (lines) and mode of action must be considered during treatment (Ahamad et al., 2017). The finding and creation of new anti-TB therapeutics are widely recognized as one of the world’s most challenging public health issues; however, it is also a significant pharmaceutical challenge. Drug development is a lengthy procedure. Following a clinical trial, it can take decades for a molecule to reach the market. Computational approaches have aided drug development (Doreswamy and Vastrad, 2013; Ojo et al., 2021). The Quantitative Structure-Activity Relationship (QSAR) method is a powerful tool that is used in drug development all over the world. QSAR models are mathematical equations that show how chemical structures and biological processes are linked. The QSAR approach can potentially minimize the time and effort necessary to find novel compounds or increase the efficiency of current ones ( Adeniji et al., 2018). QSAR models are increasingly used with virtual screening and combinatorial libraries to predict the fate of physiologically active compounds (Ahamad et al., 2017). It is possible to use this method in the development of future drugs. Increasing the speed of QSAR-related studies would facilitate the design and optimization of new drug candidates (Adeniji et al., 2018). Another capability of these models is that they can provide a deeper understanding of biological activity mechanisms (Vastrad, 2012). In QSAR modeling, various descriptors were employed, such as constitutional, geometrical, topological, quantum chemical, and other descriptors ( Ojo et al., 2021). This approach might be applied to predict the activity of newly proposed compounds before their synthesis and evaluation ( Vastrad, 2012; Adeniji et al., 2018). Molecular docking is a module that allows two or more molecules to recognize one other by matching their geometry and energy. It is a valuable tool in drug development for establishing the compatibility of molecules (ligands) with their target (receptor). It helps determine how a receptor interacts with its ligand and elucidates its binding process ( Qing et al., 2014; Adeniji et al., 2018).

A pharmacophore must possess several chemical qualities to elicit a response from a receptor target. Pharmacophore models may be created using either a receptor alone or a receptor-ligand combination (Wermuth et al., 1998; Leach et al., 2010; Macalino et al., 2020). Pharmacophores are schematic representations of the main aspects of molecular recognition that may be used to represent and identify compounds on a 2D or 3D level. Physicophore model-based database screening is essential for computer-aided drug development since it gives information on receptor interaction’s geometric and electrical aspects (Qing et al., 2014). According to IUPAC, a Pharmacophore is a combination of steric and electronic qualities required for interaction with a target structure to trigger a biological response. Using a mix of pharmacophore model-based screening and docking studies to find novel drugs has been proven effective (Leach et al., 2010). Pharmacophore screening and docking can be combined to speed up the discovery of new drugs and improve their chances of survival (Macalino et al., 2020). Using molecular docking and other bioinformatic methods to evaluate candidate compounds before in vitro cell culture assays or chemical changes can help speed up drug discovery. Pharmaceutical and medicinal chemists can use QSAR and molecular docking investigations to design and synthesize novel anti-TB drugs (Adeniji et al., 2018).

## Section: Introduction › QSAR, pharmacophore modeling, and molecular docking and their importance in drug discovery

The process of drug discovery and the development of a novel medicine is costly and time-consuming. Several laboratories and in vivo tests are used to determine therapeutic effectiveness and health risks. As a result, new methods are being developed to limit animal use in research, reducing ethical (and budgetary) concerns ( Bajot, 2010).

The computational tools are mainly utilized to.(i) perform the molecular structure confirmation (e.g., molecular dynamics);(ii) characterize the interactions between drugs and targets (e.g., molecular docking);(iii) to assess and optimize the activity of the drug through QSAR techniques.

There are mainly two drug design techniques: structure and ligand-based drug design (SBDD and LBDD). Using SBDD, any target inhibitor molecule can be designed, while LBDD primarily focuses on the chemical interaction between the target receptor and the inhibitor ( Abdel-Ilah et al., 2017). The drug design techniques and groups are presented in Figures 1, 2 (Abdel-Ilah et al., 2017).

Drug design techniques and groups.

Schematic presentation of the drug discovery and development process.

## Section: The significance of QSAR

Quantitative structure-activity relationships (QSARs) utilize computational and mathematical models to identify the correlation between pharmacological activities and chemical structure compounds ( Kwon et al., 2019). QSAR is gaining traction as a less expensive alternative to medium-throughput in vitro and low-throughput in vivo research in the drug development process (Figure 2) (Prachayasittikul et al., 2015; Qureshi et al., 2023). In addition, QSAR models are increasingly used in drug discovery and environmental toxicology to predict and classify drug resistance, toxicity, and physicochemical characteristics (Verma et al., 2010). The QSAR technique is based on the premise that changes in a chemical’s molecular structure may be quantitatively linked to variations in its biological activity ( Testa, 1995). Hammett first discovered the QSAR in the 1930s, and Hansch and Fujita developed it in the mid-1960s ( Tandon et al., 2019). Hammett’s works are significant contributions to the field of chemistry, particularly in the realm of Quantitative Structure-Property Relationships (QSPR). Through his research, Hammett established intricate mathematical connections between the acidity of compounds and the electronic effects of various functional groups. This innovative approach shed light on the underlying principles governing chemical reactivity and laid the groundwork for developing Quantitative Structure-Activity Relationship (QSAR) models. Medicinal chemists may now think about their structures in terms of physical properties rather than only pharmacophore groups due to the QSAR approach and philosophy. As a result of research, new inhibitors may be created from scratch, and existing medicines may be improved regarding absorption, distribution, metabolism, excretion, and toxicity (Abdel-Ilah et al., 2017; Kwon et al., 2019). QSARs are a computerized statistical method for explaining observed variation in replacement structure changes. QSAR modeling has extensively prioritized compounds for manufacture and biological assessment. The QSAR models may be utilized to identify potential hits and enhance hit-to-lead ratios, to aid in the efficient selection and optimization of compounds for further development and biological evaluation ( Neves et al., 2018). Because no chemical needs to be made or tested before computer assessment, QSAR is a labor-, time-, and cost-effective technique for acquiring molecules with desired biological characteristics. As a result, QSAR is extensively employed in businesses, colleges, and research institutions throughout the globe ( Cherkasov et al., 2014). There are five main steps in QSAR, including incorporating molecular structures and creating three-dimensional models. Since geometric descriptor calculations require molecular models in three dimensions: i) developing molecular structure descriptors, ii) selecting the most critical descriptors, which can be accomplished by using feature selection methods, iii) developing QSPR/QSAR models using the descriptor sets, and iv) validating the model by predicting the activity of substances based on external prediction data (Winkler, 2002) (Figure 3) ( Piir et al., 2018).

Virtual screening (VS.) is a common computer approach for screening huge libraries of smaller molecules for novel hits with desirable features that may then be evaluated experimentally. Like other computational techniques, VS. aims to speed up the discovery process by minimizing the number of candidates that must be tested and rationalizing their selection (Neves et al., 2018). Furthermore, due to its time, cost, resource, and labor reductions, VS. has become quite popular in pharmaceutical businesses and academic institutions ( Schaduangrat et al., 2020). QSAR analysis is the most effective VS. technique due to its high throughput and hit rate ( Aparoy et al., 2012). The Organization for Economic Cooperation and Development (OECD) accepted the following five principles for effective QSAR models to be used in regulatory evaluations of chemical safety: 1) a stated end aim; 2) a clear technique; 3) a defined scope of application; 4) appropriate goodness-of-fit, robustness, and predictability metrics; and 5), if feasible, a mechanistic interpretation ( Gandhi et al., 2021).

The Quantitative protein (or proteome)- disease relationships (QPDRs) are extensively utilized for illness prediction, whereas QSAR is frequently employed for pharmacological property prediction ( Munteanu et al., 2010). Although they have been used for decades to predict and correlate the activity of molecules, there are several limitations to them, including i) the lack of training molecules in some cases; ii) they consider only two-dimensional structures; iii) the Hammett constant and other parameters are insufficient to link drug-receptor interactions; vi) there are no certain physiochemical criteria, no stereochemistry representation, and no one-of-a-kind solutions (Patel et al., 2014; Gandhi et al., 2021).

A workflow for QSAR modelling.

Predictive approach for QSAR modelling.

The role of applicability domain in various stages of the QSAR life cycle.

A framework of Pharmacophore architecture.

Schematic presentation of covalent docking.

An overview of the docking process for molecules. (A) The ligand’s three-dimensional structure; (B) the 3D structure of the receptor; (C) The ligand is docked into the receptor’s binding cavity, and potential conformations are investigated.; (D) The detected intermolecular interactions and the most plausible binding conformation.

List of some compounds discovered to target tuberculosis bacteria by using approaches of QSAR, pharmacophore modeling, and molecular docking.

A list of the drugs that are in a clinical trial is discovered with the help of these approaches.

## Section: The significance of QSAR › Classification of QSAR methodologies › Based on the dimensionality of molecular descriptor

i. 0D QSAR- These descriptors are obtained from the molecular formula. 0D-QSAR focuses on zero-dimensional descriptors, such as constitutional descriptors, that include basic molecular information like the number of atoms, bonds, or functional groups (Gackowski et al., 2023).ii. 1D QSAR- This correlates activity with global molecular parameters such as pKa, log P, and others. These descriptors are more straightforward and can be calculated more easily than higher-dimensional QSAR methods. The 1D-QSAR models are usually based on linear regression techniques, and they represent a straightforward approach to correlating molecular properties with biological activity 1D-QSAR has been applied to the study of various biological systems, such as the modeling of anti-cancer activity of a series of benzimidazole derivatives. This study’s models were based on simple one-dimensional descriptors, such as logP (partition coefficient), which provided significant insights into the molecular features responsible for the observed activity (Chandrasekaran et al., 2018).iii. 2D QSAR- A molecular network containing topological or two-dimensional (2D) information is known as a 2D QSAR. The 2D-QSAR methodology involves the relationship between the chemical structure and biological activity of molecules, considering only two-dimensional properties like molecular weight, dipole moment, and hydrogen bond donors/acceptors. A classic application of 2D-QSAR is in drug discovery, where it has been used to model the activity of HIV protease inhibitors (Abdel-Ilah et al., 2017).iv. 3D QSAR- These are calculated from a molecule’s geometrical or 3D representation. 3D-QSAR adds a third dimension to the analysis, considering the three-dimensional spatial arrangement of atoms in a molecule. It is often applied to understand how small molecules interact with a target protein in 3D space. 3D-QSAR has been extensively applied in studying enzyme inhibitors, such as developing new kinase inhibitors for cancer therapy (Ajjarapu et al., 2021).v. 4D QSAR- This model describes four dimensions of information, with the fourth dimension being an ensemble of conformation for each ligand. 4D-QSAR includes the three spatial dimensions and adds the fourth dimension, representing molecular flexibility or time-dependent behavior. This considers how a molecule’s shape might change over time or under different conditions (Hopfinger et al., 1997).vi. 5D QSAR- In 4D-QSAR, 5D-QSAR explicitly represents different induced-fit models (Verma et al., 2010; Patel et al., 2014; Abdel-Ilah et al., 2017). 5D-QSAR adds a fifth dimension, often representing the molecular solvation effects. It considers how solvent molecules interact with the molecule of interest (Good, 2006).

## Section: The significance of QSAR › Classification of QSAR methodologies › Based on the type of chemometric methods used

i. Linear method: Linear methods assume a linear relationship between the structure and activity. Common linear methods include multiple linear regression (MLR), partial least squares (PLS), and principal component regression (PCR).ii. Non-linear method: Non-linear methods are used when the relationship between the structure and activity is complex and non-linear. Techniques include artificial neural networks (ANNs), support vector machines (SVMs), and k-nearest neighbors (k-NN).

## Section: The significance of QSAR › Types of techniques for QSAR modeling

1. The simple linear regression (SLR) method generates a QSAR model in equations using a standard linear regression calculation. This technique has proven to be quite promising for developing structure and activity correlations (Verma et al., 2010). Using a straight line, SLR models the relationship between a single independent variable and a dependent variable. It assumes a linear relationship and is widely used for prediction and understanding how the variables are related. The method is simple, interpretable, and widely applied in various scientific fields. SLR might not capture complex relationships that involve multiple variables (Draper and Smith, 1998). Linear Methods, Used in modeling structure-activity relationships in drug discovery, predicts novel compounds’ biological activity (Krishnapuram et al., 2005). 2. Multiple linear regression (MLR) extends SLR to several dimensions. Standard multivariable regression calculations are used in this procedure. All of the descriptors under study are subjected to identifying a drug property. MLR provides a more nuanced understanding of the system under study by considering more variables. It is a powerful tool for prediction and explanation but requires careful handling of collinearity among predictors. Adequate variable selection is essential for building meaningful models (Schneider et al., 2010 ). 3. Stepwise multiple linear regression- Variation MLR, which yields a multiple-term linear equation but does not use all independent variables, is widely used in this approach. This method works effectively when there are a lot of descriptors and the key ones are not known (Patel et al., 2014). SMLR combines the principles of MLR with a sparsity constraint, ensuring that only the most relevant variables are used in the model. This can lead to better interpretability and prevent overfitting. SMLR is particularly useful when dealing with high-dimensional data requiring feature selection. It is a modern technique that bridges statistical modeling with machine learning (Krishnapuram et al., 2005).4. The partial least square method (PLS) provides a statistically robust solution even when the independent variables are heavily connected, or the number of observations exceeds that ( Verma et al., 2010; Patel et al., 2014). PLS is a sophisticated regression method that extracts latent variables explaining the covariance between independent and dependent variables. It is widely used in chemometrics for handling multicollinearity. PLS provides robust and interpretable models by focusing on the variables most related to the response. It is precious when numerous predictors are highly correlated (Mehmood et al., 2020). Applied in various fields like drug design, metabolomics, and environmental toxicity prediction, where non-linear relationships are common (Everitt et al., 2011).5. Principle components analysis (PCA) is a technique for creating a new set of orthogonal descriptors called principal components (PCs) that describe the bulk of the information in the independent variables in decreasing order of variance. CA is also utilized in PLS approaches for variable selection (Patel et al., 2014). PCA is a dimensionality reduction technique that transforms the data into orthogonal components, capturing the most variance. It is a robust exploratory data analysis, visualization, and preprocessing tool. PCA helps understand the underlying structure of data and is widely used in various scientific fields, including chemometrics and bioinformatics (Prachayasittikul et al., 2015; Jolliffe and Cadima, 2016).6. The genetic function approximation (GFA) method can be used as an alternative to average regression analysis to construct QSAR equations. It can create both linear and higher-order non-linear equations. Genetic algorithm partial least squares (G/PLS or GA-PLS) are a helpful method that combines the most significant features of GFA and PLS. GFA applies genetic algorithms to find the optimal subset of descriptors in regression analysis. It can model complex non-linear relationships and is highly flexible. GFA has been applied successfully to model various chemical and biological systems, especially in QSAR studies. Its ability to navigate vast descriptor spaces makes it a valuable tool in computational chemistry (Rogers and Hopfinger, 1994).7. Cluster analysis is a multivariate approach for classifying structures into subsets (called clusters) that are similar in some manner (Patel et al., 2014). Cluster analysis is a grouping technique used to categorize objects into clusters based on their similarity. It is unsupervised, meaning that the categories are not predefined. Cluster analysis has diverse applications, including market segmentation, image processing, and pattern recognition. It provides insights into the natural groupings within data (Zhang et al., 2023).8. Artificial neural networks (ANNs) are nonlinear computational models that simulate the activity of human neurons to make predictions ( Prachayasittikul et al., 2015). They can be used to model QSAR and solve pattern recognition difficulties (Patel et al., 2014). ANNs are inspired by the human brain’s function and consist of interconnected nodes or neurons. They are capable of modeling complex, non-linear relationships between inputs and outputs. ANNs have been applied in numerous fields, including image recognition, natural language processing, and QSAR modeling. The flexibility and adaptability of ANNs make them a powerful tool, but they require careful tuning and interpretation (Trinh et al., 2021). Used in virtual screening and toxicity prediction, providing accurate models that can handle the complexity of biological systems (Pérez et al., 2021).

## Section: The significance of QSAR › Molecular descriptors and their significance

Despite significant advancements in drug design, descriptors used to designate the molecular structure of biologically active compounds remain the primary method for identifying novel lead molecules. For QSAR/QSPR investigations, descriptors are numerical representations of the chemical properties of a molecule. For statistical model construction to be possible, the mathematical representation of these descriptors must be independent of the molecule’s size and number of elements. In QSAR/QSPR modeling, molecular descriptors have evolved into the most important variables. The information conveyed by descriptors typically depends on the type of molecular representation and the defined algorithm for its calculation. Among these are topological indices, geometrical, structural, and physicochemical descriptors.

Constitutional descriptors are basic, widely-applied descriptors that reflect the molecular composition of a compound without providing information about its topology. The most common constitution descriptors are the number of atoms, number of bonds, variety of atoms, ring count, and molecular weight (MW). These descriptors are insensitive to conformational changes and do not distinguish between isomers.

Recent developments in lead discovery, drug design, virtual screening, combinatorial library design, and database search discrimination also highlight the importance of topological descriptors in drug discovery. Topological indices (TIs) are two-dimensional descriptors that consider the intrinsic atomic arrangement of compounds. These descriptors are derived from the topological representation of molecules and can be considered structure-specific. These indices encode numerical information regarding the molecular size, shape, branching, presence of heteroatoms, and number of bonds. By the nature of chemical bonds, these TIs represent the interconnectedness of atoms within molecules. They play a crucial role in modeling various physicochemical properties, biological activities, and pharmacokinetic properties. A molecular graph represents a topological representation of a molecule. This graph is denoted mathematically as G = (V, E), where V is the set of vertices corresponding to the atoms of the molecule, and E is the set of elements representing the binary relationship between pairs of vertices. These chemical graphs depict the molecular structure in a non-numerical format; however, a numerical translation of the graph is required to calculate topological descriptors. The most commonly used descriptors are the Wiener index, the Connectivity indices, the Kier shape, the Balaban J index, and the Zagreb indices. The primary function of these indices is to classify molecules according to their size, degree of branching, flexibility, and overall morphology (Wiener, 1947; Randic, 1975; Balaban, 1982; Roy, 2004).

The 3D coordinates of the atoms in a given molecule are used to derive geometrical descriptors. In comparison to topological descriptors, these descriptors are abundant in information and discrimination power for analogous chemical structures and molecule conformations. In addition, they contain data acquired from atomic van der Waals regions and their overlap on the molecular surface. Despite their high informational density, these descriptors typically have disadvantages as well. Geometric descriptors necessitate geometry optimization and, consequently, the computational burden to calculate them. Thus, for flexible molecules that can assume multiple conformations, new information can be utilized. Nonetheless, this results in the issue that complexity can increase substantially. Moreover, alignment constraints are required for the majority of these descriptors (grid-based descriptors) to accomplish molecule comparability. A molecule’s physical and chemical properties that can be estimated from its two-dimensional structure are physicochemical descriptors. These properties play a significant role in determining the substance concentration in the body. A drug’s efficacy and, consequently, its market value can be enhanced by its possessing the appropriate properties. Thus, examining these properties of a drug not only contributes to the drug’s safety profile but also plays a crucial role in drug discovery by optimizing the compounds chosen. In addition to selecting candidate compounds with the appropriate physicochemical properties, it is necessary to pay special attention to properties such as lipophilicity, solubility, and permeability, which can ensure optimal potency (Leo et al., 1975; Ghose and Crippen, 1986). In contrast, molecular fingerprints have been utilized for decades to investigate large chemical libraries for similar compounds. The information content of 2D signatures is derived from atoms, bond types, and graph distances derived from chemical graphs, where these are represented as bits. Each bit indicates the presence or absence of a predetermined substructure in a compound. A bit in a structural fingerprint corresponds to a chemical property, typically the presence of some substructure. Based on the similarity to a biologically active molecule, these biomarkers enable researchers to identify additional compounds with a higher probability of displaying similar biological potency against the same target. Molecule properties, such as chemical diversity in chemical space, can be characterized using fingerprints. Such evaluations are crucial in the compound selection process before experimental screening. Numerous fingerprint varieties can be used for structural comparisons of various sorts. Such signatures have become a popular option for drug discovery because they offer a decent balance and empirically reasonable proportionality. By quantifying fingerprint overlap with similarity coefficients and using the resulting values to measure molecular similarity, fingerprint similarity searching generates a database ranking. A Tanimoto coefficient (Tc) value of >0.85 indicates a high probability that the test compounds have similar bioactivity. However, Tc is only useful for data with comparable levels of complexity; other coefficients are preferred for data with varying levels of complexity (Willett, 2006; Rogers and Hahn, 2010; Helal et al., 2016).

Initially, 2D fingerprints were designed for similarity searching using a single template, but some studies claim that search performance is enhanced when multiple reference compounds are employed. MACCS, PubChem, and Extended-Connectivity biometrics (ECFP) are the most commonly used biometrics. MACCS is a compilation of 166 bits that encompasses most of the chemical characteristics important for virtual screening. The PubChem signatures database contains 881 bits of descriptors for element counts, aromatic or nonaromatic ring counts, atom pairs, atom neighborhoods, and particular fragments. These 2D signatures have been successfully utilized in the virtual screening of novel active compounds. Using PubChem bioassays, comprehensive bioactivity profiles, dubbed “PubChem high-throughput screening fingerprints” (PubChem HTSFPs), were recently developed. In addition, these PubChem-HTSFPs were utilized in hit expansion experiments for 33 unique targets. These signatures were useful for retrieving matches with structural diversity and the desired bioactivities. ECFPs are a novel class of 2D circular signatures used for molecular characterization. These signatures are an extension of the Morgan algorithm. These circular fingerprints have numerous advantageous characteristics, including i) being easy to calculate; ii) representing a large number of distinct features; and iii) not being reliant on predefined features; thus, they can represent novel structural variation. These fingerprint types effectively employ encoded rich data for similarity searching, compound clustering, and chemical library analyses. In addition, ECFPs are frequently employed in QSAR and QSPR model development for lead optimization and ADMET property forecasting (Willett, 2006; Rogers and Hahn, 2010; Helal et al., 2016).

Therefore, concerning anti-tubercular drug discovery, a combination of different machine-learning-assisted QSAR models is required while implementing molecular descriptors and molecular fingerprints of molecules’ datasets for feature selection against any biological target. The best way to deal with major demerits of different types of molecular descriptors is to include two or more molecular descriptors while constructing the hybrid descriptors-based QSAR models. Hybrid molecular descriptors incorporate multiple molecular characteristics, including topological, electronic, and geometric properties. This exhaustive representation accounts for a broader range of factors that contribute to the activity of a molecule, thereby enhancing the model’s predictive accuracy. The same approach should be applied while considering molecular fingerprints for anti-tubercular drug design by constructing a hybrid fingerprint-based QSAR. Therefore, the use of both hybrid molecular descriptors and molecular fingerprint-based QSAR models will have a distinct and interpretable relationship with the activity of a molecule that will additionally aid researchers in analyzing the contributions of particular characteristics or substructures to the overall activity, thereby facilitating the design of novel compounds with the desired properties. Apart from this, hybrid molecular descriptors and molecular fingerprints can represent a wide variety of chemical structures, including novel and unconventional compounds. This adaptability is essential for investigating new chemical space and identifying potential drug candidates with distinctive structural characteristics. In ensemble modeling, where multiple QSAR models or screening methods are combined to improve predictive performance, hybrid molecular descriptors and molecular fingerprints can also be used. This strategy combines the advantages of various techniques, resulting in more accurate and robust forecasts. Due to their ability to provide a comprehensive, interpretable, and computationally efficient representation of molecular structure and activity, hybrid molecular descriptors and molecular fingerprints are favored for QSAR modeling and drug design. These techniques have significantly accelerated the drug discovery process by allowing researchers to prioritize and design promising compounds for further experimental evaluation (Willett, 2006; Rogers and Hahn, 2010; Helal et al., 2016). As computational methods continue to advance, hybrid descriptors and molecular signatures will likely play a greater role in shaping the future of drug development against tuberculosis.

## Section: The significance of QSAR › Modeling QSAR using chemical space analysis

Chemical space is vital in drug development for various purposes, including library creation, compound classification, selection, structure-activity relationship (SAR) investigation, and understanding structure-property connections (SPR) (Naveja Medina, 2019). It encompasses all descriptors derived from chemical compounds. The chemical space analysis for FDA-approved drugs showed shared traits, including substantial halogen content and molecular weights below 500, consistent with Lipinski’s rule of five. This rule suggests that drugs with an MW less than 500 have better bioabsorption and bioavailability (Prachayasittikul et al., 2015). Chemical space represents the collection of all potential organic compounds, and as its scale increases, cartographic approaches are used to visualize and conceptualize it. Machine learning methods benefit from chemical space approaches as they identify clusters of related compounds. Lipinski’s rule of five indicates that drug-like compounds exhibit drug resemblance with MW < 500 Da, clogP <5, few H-bond donors (<5), and few H-bond acceptors (<10) (Ganesan, 2008). Optimizing this rule is essential for improving BBB permeability by passive diffusion. Factors like MW, log P, and H-bond donors and acceptors influence drug interaction with the blood-brain barrier (BBB) (Lambrinidis and Tsantli, 2018). By analyzing the chemical composition of natural compounds and determining their molecular structures, the investigation identified 11 novel inhibitors for ß-hydroxysteroid dehydrogenase type 1 ( Koch et al., 2005). According to Reayi, diversity-oriented synthesis (DOS), a chemical synthesis strategy for swiftly building a library of compounds, can help deorphanize druggable protein targets ( Reayi and Arya, 2005). ChemGPS-NP was used to examine the chemical space of natural products from different databases (Larsson et al., 2005). They discovered that 40,348 compounds from the Dictionary of Nature Products Database passed Lipinski’s rule of five ( Rosén et al., 2009). To define “bioactive natural compound-likeness,” (Zhou et al., 2010), used structure-activity relationships to investigate the chemical space of natural products, comparable to Lipinski’s rule of five (drug-likeness) (BNC-likeness). The drug-likeness and BNC-likeness models were utilized to compare the structural properties of bioactive and non-bioactive natural products. The Ethnobotanical Database and Dr. Duke’s Phytochemical Database were used to create a dataset of 1,580 natural products from a total of 7,549 natural product constituents. 790 natural compounds were bioactive, while the remaining 790 were not, resulting in a well-balanced dataset. Bioactive natural compound-likeness models were created using SVM with radial basis function kernels, and the training set consisted of 1,580 bioactive substances. An independent external data set of 81 bioactive and 81 non-bioactive natural compounds from commonly used medicinal plants were used to test the models’ performance. The prediction results effectively classified 75 bioactive chemicals, indicating the robustness of the models and their immunity to overfitting. One of the issues with machine learning is overfitting, which arises when noise data is used as an independent variable in developing highly predictive models ( Zhou et al., 2010).

## Section: The significance of QSAR › Model validation methodology for QSARs

The validation approach tries to provide a model with defined descriptors that is statistically trustworthy because of a cause-and-effect connection rather than a random numerical link. Validation procedures are required to determine a model’s predictive ability. Internal and external validation techniques are the two sorts of validation methods accessible. Training datasets are used by internal techniques such as Q2 (squared correlation coefficient), R 2 (coefficient of determination or coefficient of multiple determination for multiple regression), chi-squared (X2), and root-mean-squared error (RMSE). When applied to new data sets, the model’s lack of predictability is a significant flaw in this technique. External approaches, on the other hand, are based on the testing set and are considered the most reliable validation ( Abdel-Ilah et al., 2017; Kwon et al., 2019). These statistical methods ensure that the models produced are accurate and unbiased. Cross-validation approaches such as accuracy (ACC), sensitivity (SEN), specificity (SPEC), and Matthew’s correlation coefficient (MCC) ( Prachayasittikul et al., 2015) can be used to assess the model’s internal predictive capability. In contrast, its external predictability can be evaluated using a separate set of molecules (the test set) that were not used in the model creation ( Testa, 1995; Verma et al., 2010). The CV method begins by removing one or more compounds from the training set, which serves as a temporary test set. The remaining data points are used to form a CV model, which is then tested on the deleted molecules to see if it can accurately predict bioactivities using the descriptors from the original model (Figures 4, 5).

External validation, the Y-randomization test, the domain of applicability, and the William plot are some statistical techniques that can be used to assess a QSAR/QSPR model’s predictive ability. External validation is a method of testing a QSAR/QSPR model’s external predictivity by omitting a section of data at the start of the experiment and using the remaining internal set to evaluate optimal learning algorithm parameters ( Prachayasittikul et al., 2015).

The accuracy (ACC), sensitivity (SEN), specificity (SPEC), and Matthew’s correlation coefficient MCC) are used to evaluate the prediction performance of the proposed QSAR/QSPR model using cross-validation (CV), which is given by the following formula Eqs 1–4 Accuracy=TP+TNTP+TN+FP+FN×100 (1) Sensitivity=TPTP+FN×100 (2) Specificity=TNTN+FP×100 (3) MCC=TP×TN−FP×FN√TP+FNTN+FPTN+FN (4)

TP, TN, FP, and FN- Numbers of true positive, true negative, false positive, and false negative.

Matthew’s correlation coefficient (MCC) measures the gap between actual and expected values. The coefficient is a balanced measure that can be employed when the classes are of various sizes and take into consideration true negatives (TN), true positives (TP), false negatives (FN), and false positives (FP). The equation is used to derive the formula. In machine learning, Matthew’s correlation coefficient (MCC) is used to assess the quality of binary and multiclass classifications. Like most correlation coefficients, MCC has a range of 1 to 1, with 1 denoting the best agreement between actuals and forecasts, −1 denoting an inverse prediction, and 0 denoting no agreement. Alternatively, the prediction is random in comparison to the actual situation ( Mun and Geng, 2019).

Predictive approach for QSAR modelling.

The role of applicability domain in various stages of the QSAR life cycle.

## Section: The significance of QSAR › Machine learning drug development

Due to an influx of available data and increased computer capacity, machine learning (ML) technologies are coming back in drug development investigations. This has sparked a flurry of artificial intelligence (AI) drug development investigations, in which machine learning (ML) and deep learning (DL) approaches are used to solve issues efficiently and intelligently. Combining structural, sequence, and evolutionary data yields machine-learning models (Verma et al., 2010). An analysis of hydrophobicity, side-chain pKa, solubility, solvent accessibility, and other physiochemical parameters is conducted, as well as the development of a machine-learning model to predict binding and non-binding residues. Only a few models predict binding sites based on one of the binding partners’ structures, whereas others employ information from both partners ( Kumar et al., 2018). The two types of machine learning methodologies are unsupervised and supervised learning. Labels are allocated to training data in supervised learning, and the model can predict labels for specific data inputs once it is ready. On the other hand, unsupervised machine learning algorithms can profit directly from unlabeled molecular pattern data, as they require input data and no output components (Supplementary Table S7) (Singla et al., 2013).

## Section: The significance of QSAR › The significance of pharmacophore

Ehrlich coined the pharmacophore as “a molecular framework that conveys (phoros) the key properties responsible for a drug’s (pharmacon) biological activity” in 1909 ( Yang, 2010). According to the IUPAC nomenclature (Leach et al., 2010), a pharmacophore is a molecule that possesses both steric and electronic properties that enable it to produce efficient supramolecular interactions with a biological target structure and activate or inhibit its biological response (Figure 6).

To better understand ligand-protein interactions, pharmacophore models are developed. They may be utilized to discover new compounds that match the pharmacophore criteria and are thus expected to be active ( Muhammed and Aki-Yalcin, 2021). Using a mix of pharmacophore model-based screening and docking studies to find new drugs has been proven beneficial ( Mesli et al., 2021). If the target’s structure is unknown, a pharmacophore model can be created utilizing structural data from the active ligands that bind to it. The ligand-based pharmacophore modeling technique (Yang, 2010; Muhammed and Aki-Yalcin, 2021) is the name given to this approach.

When the target’s structure is known, pharmacophore models can be constructed utilizing the target’s structural attributes. This is the structure-based pharmacophore modeling approach (Vastrad, 2012). A whole framework of Pharmacophore is shown in Figure 6 (Muhammed and Aki-Yalcin, 2021). A list of pharmacophore modeling software is enlisted in (Supplementary Table S8) (Yang, 2010; Singla et al., 2013; Kumar et al., 2018; Schaller et al., 2020; Muhammed and Aki-Yalcin, 2021).

The pharmacophore analysis has the most important common denominator of the molecular interaction properties shared by a group of active compounds. It is an abstract idea rather than a physical molecule or combination of chemical groups ( Qing et al., 2014). Integrating knowledge about the three-dimensional nature of molecular interactions is another significant component of current pharmacophore research. This point of view is centered on 3d-pharmacophore techniques (Leach et al., 2010), which define the spatial relationship between pharmacophore features. Virtual screening, de novo design, lead optimization, and multitarget drug design have all utilized pharmacophore-based approaches ( Yang, 2010; Kumar et al., 2018; Muhammed and Aki-Yalcin, 2021). There are limitations with pharmacophore scoring functions that limit its ability to realize its intended potential, especially with the current high cost of discovering and developing new medicine. The involvement of other computational methods is critical in overcoming these obstacles. As a result, combining pharmacophore modeling with different computational approaches addresses some of these constraints ( Yang, 2010; Kumar et al., 2018).

A pharmacophore model is comprised of several characteristics that are arranged in a three-dimensional (3D) pattern. The characteristics can be labeled as a single feature or any logic combination consisting of “AND,” “OR,” and “NOT” ( Qing et al., 2014) to blend varied interaction patterns under a single label. Hydrogen bond donors (HBD), hydrogen bond acceptors (HBA), positive features, negative features, aromatic rings, hydrophobic features, and their combinations are all examples of molecular pharmacophore patterns ( Seidel et al., 2020). Different compounds can be compared at the pharmacophore level, known as “pharmacophore fingerprinting.” The pharmacophore is a “query” when only a few pharmacophore properties are analyzed in a 3D model ( Qing et al., 2014). Classification of 3D-QSAR is given in Supplementary Table S4. Pharmacophoric characteristics may be used as a query to search for possible leads from chemical compound databases and produce compounds with specific qualities (lead optimization) ( Qing et al., 2014; Kumar et al., 2018; Muhammed and Aki-Yalcin, 2021). It also uses pharmacophore fingerprints to determine the comparability and diversity of drugs. It may also align molecules based on their three-dimensional arrangement or create a predicted three-dimensional QSAR model ( Kumar et al., 2018). The webservers or databases for QSAR drug design research are given in Supplementary Table S1-3). A list of software used for calculating descriptors and fingerprints is presented in Supplementary Table S5, 6.

Pharmacophore modeling employs organized methods to construct a logical framework to identify other chemical moieties with similar properties against the disease’s target of interest. The steps are as i) ligand synthesis, ii) mapping of pharmacophore features, iii) looking for a common pharmacophore, and iv) calculating the shared pharmacophore score ( Kumar et al., 2018). A pharmacophore can be used to screen new target-specific agonists and antagonists, toxicants, undiscovered targets, and the best molecular docking findings. A pharmacophore model is often used in virtual screens to locate medications that trigger the required biological activity (Yang, 2010; Muhammed and Aki-Yalcin, 2021), as well as fishing drug targets, ligand profiling, docking, and ADMET (absorption, distribution, metabolism, excretion, and toxicity) prediction ( Leach et al., 2010; Yang, 2010; Qing et al., 2014; Muhammed and Aki-Yalcin, 2021).

A framework of Pharmacophore architecture.

## Section: The significance of QSAR › An overview of the importance of molecular docking

The most extensively used strategy for structure-based drug development is molecular docking, which has been around since the early 1980s ( Meng et al., 2012). Molecular docking provides an attractive framework for studying drug biomolecular interactions, which is useful for rational drug design and discovery Dar and Mir, 2017). The molecular docking approach may be used to model an atomic-level interaction between a small molecule and a protein, allowing us to characterize small molecule behavior at target protein binding sites and highlight key biochemical processes ( Meng et al., 2012; Aspatwar et al., 2019) (Figure 7) (Ferreira et al., 2015).

When the target protein’s 3D structure is available, molecular docking is one of the most commonly used virtual screening approaches. It is possible to predict both the affinity of the ligand for a protein and the structure of the protein-ligand complex by using this technique, both of which are vital to lead optimization ( Wang and Zhu, 2016). Molecular docking aims to predict the structure of the ligand-receptor complex using computational methods. Docking is accomplished in two steps: sampling ligand conformations in the protein’s active site and then utilizing a scoring function to rate these conformations (Meng et al., 2012; Ferreira et al., 2015). A complete list of docking and ADME software are enlisted in Supplementary Table S9 (Meng et al., 2012; Singla et al., 2013; Ferreira et al., 2015; Dar and Mir, 2017; Kumar et al., 2018; Zhang et al., 2022) Supplementary Table S10 (Singla et al., 2013), respectively.

Schematic presentation of covalent docking.

## Section: The significance of QSAR › Discovery of covalent and noncovalent anti-tuberculosis drugs using molecular docking techniques

Covalent inhibition is a method for obtaining irreversible inhibition. Because covalent inhibitors may target proteins with shallow binding cleavage, new inhibitors with better efficacy than non-covalent inhibitors can be developed. Covalent molecular docking has recently been used in computer-aided drug design processes to characterize covalent interactions between inhibitors and biological targets. Several computational approaches for modeling covalent interactions have been developed. Autodock, Autodock Vina, GOLD, and FlexX are the most popular docking tools and software.

On the other hand, these and other similar methods primarily focus on non-covalent interactions (van der Waals interactions, electrostatic interactions, and hydrogen bonding) or the use of alternative empirical or knowledge-based scoring functions to characterize these non-covalent interactions ( Kumalo et al., 2015). Non-covalent interactions (van der Waals interaction, electrostatic interaction, and hydrogen bonding, for example,) or alternative empirical or knowledge-based scoring functions to characterize these non-covalent interactions are mainly used in these and other analogous methodologies. However, not all medications attach non-covalently to the active site; other compounds, such as covalent drugs (Singh et al., 2011), bind covalently. The workflow of covalent docking is represented in Figure 8 (Kumalo et al., 2015).

Many techniques have been developed to achieve the covalent docking of inhibitors to target proteins. However, most covalent docking methods can only predict the binding energy between an electrophilic ligand and a nucleophilic receptor. Popular is the “link atom” approach. The software defines a “link atom” in the ligand and the protein in this strategy. The ligand link atom must occupy the same steric volume as the protein link atom to mimic the covalent binding process. The Gold molecular docking program ( Hartshorn et al., 2007) implements this strategy. Autodock, another widely used molecular docking program, uses a “grid-based technique” and a “modification of the flexible side chain” approach to covalently dock inhibitors to receptors. The covalently linked ligand and the protein attachment are sampled as part of the receptor as a single flexible side chain in a flexible side chain. A Gaussian biassing function focused on the protein attachment atom, and grid-based energy is used in the grid-based approach to bias the covalent bonding ligand posture ( Kumalo et al., 2015).

Katritch et al., 2007, used covalent docking and homology modeling to create a detailed structural model of the ubiquitin-like poxvirus proteinase (ULP) I7L substrate-binding site (S2–S2′). The 3D model of the I7L ligand-binding site was utilized to perform covalent docking and virtual screening of a comprehensive library of around 230,000 accessible ketone and aldehyde compounds to uncover novel smallpox antiviral hits. Out of 456 predicted ligands, 97 inhibitors of I7L proteinase activity were found to be active in biochemical studies (20 percent overall hit rate) ( Katritch et al., 2007). In their study, Wang et al. employed covalent and three-dimensional QSAR modeling to investigate the intermolecular interactions of isatin sulfonamide analogs as caspase-3 inhibitors (Wang and Zhu, 2016). Fifty-nine isatin sulfonamide analogs were docked to the binding site of human caspase-3. The docking research showed the inhibitors’ binding mechanism. A 3D-QSAR approach further supplements docking analysis by offering a “custom” scoring function for the protein under research, capable of predicting bioactivities for ligands comparable to those in the training sets. Structure-based design methodologies (such as docking) were shown to aid in constructing trustworthy QSAR models.

Ma et al. developed and covalently docked a novel family of peptide aldehyde derivatives to increase hydrophobic interactions with a bulky P3 moiety. Covalent docking was used to predict the exchange of the peptide aldehyde compounds with the 20S. The P3-position alterations are crucial for inhibitor efficacy. The docking behavior is similar to that of the crystal complex previously described. The hypothesized binding method might be leveraged to generate more potent 20S proteasome inhibitors ( Ma et al., 2011). A bicyclic class of covalent inhibitors was synthesized by Lawandi et al. to study the optimal shape required to target propyl oligopeptidase (POP) and heal human brain disorders. We hypothesized that these structures could bind covalently to the enzyme’s catalytic serine because they contain nitrile functional groups. From the covalent docking study, two compounds were chosen for production and biological testing. The study unveiled the presence of a potent, remarkably selective, and cell-permeable inhibitor for POP.

Furthermore, docking tests (using the FITTED docking engine and default parameters) demonstrated that the stereogenic center’s arrangement at the ring junction is a limiting factor for optimum activity, which may be used to guide future studies ( Lawandi et al., 2009). Saikia et al. study delve into the intriguing interaction between the antitubercular drug isoniazid (INH) and pristine and Si-doped and single-walled carbon nanotubes (SWNTs) (Saikia et al., 2016). The incorporation of silicon dopants significantly enhances the adsorption of INH onto the relatively inert nanotubes, as evidenced by profound alterations in adsorption energies, charge transfer phenomena, and global reactivity descriptor values. Notably, the study highlights noncovalent functionalization’s efficiency and mobility advantages over covalent counterparts, particularly in facilitating INH movement along the nanotube sidewall. Interestingly, parallel adsorption configurations manifest heightened charge transfer dynamics compared to the perpendicular adsorption orientation. The theoretical investigation posits single-wall carbon nanotubes as promising nano vectors for PZA (pyrazinamide) drug delivery, with covalent functionalization via sidewall and edge attachment, presenting a viable strategy. The study’s findings pave the way for further exploration, aiming to unravel the intricacies of therapeutic release from functionalized SWCNTs, ultimately enriching the landscape of future biomedical applications (Saikia et al., 2013). The list of software used is given in Supplementary Table S11 (Singla et al., 2013).

An overview of the docking process for molecules. (A) The ligand’s three-dimensional structure; (B) the 3D structure of the receptor; (C) The ligand is docked into the receptor’s binding cavity, and potential conformations are investigated.; (D) The detected intermolecular interactions and the most plausible binding conformation.

## Section: The significance of QSAR › Post docking simulation studies for tuberculosis drug discovery

Molecular dynamics (MD) are more computationally demanding and sophisticated than simulations of other biomolecules. A collection of biomolecule conformations with distinct initial and boundary conditions can be generated by iteratively integrating (numerically) the equations of motion for specific potential simulations ( Kumar et al., 2018). A structural ensemble derived from an MD simulation is used to explore the conformational space of biomolecules, measure thermodynamic variables, and predict the free energy of biological processes. In calculations involving free energy binding, which encompasses a wide range of accuracies and processing needs, many people have tried the MD method to forecast the strength of non-bonded interactions. A very vital technique for the theoretical and computational studies of biomolecules is molecular dynamics simulation (MDS) ( Huang et al., 2010). Examining molecular systems is exceedingly tricky since they usually comprise many particles. Using numerical approaches in molecular dynamics simulation can avoid this analytical intractability. The atoms and molecules may briefly interact while the simulation is running. Each atom’s motion is calculated, and the overall behavior may be checked. It offers numerous advantages over docking because docking merely provides the ligand’s binding free energy among the receptor. MDS can also be used to predict the ligand’s actual interaction with receptors at the atomic level ( Ferreira et al., 2015; Kumar et al., 2018).

Root means square deviation (RMSD) is applied in MDS to forecast receptor or ligand-receptor complexes for their stability and to explain conformational changes. An alternate conformational state consequently to such ligand-induced structure can be generated using MD simulations ( Khan et al., 2016). The projected ligand-receptor complex can be termed unstable if the A-matched docking solution and the ligand conformation produced by MD are different by more than a particular RMSD value ( Kumar et al., 2018). Coupled docking and MD approaches have been widely used to identify new therapeutic drugs from natural compounds and optimize the more recent lead candidate obtained from the natural compound ( De Vivo et al., 2016). MD is also applicable to produce a section of convenient docking structure, mainly when none of the acceptable crystallographic structures for the specific molecular target are offered ( Harvey and De Fabritis, 2012). MD simulations paired with molecular mechanics/Poisson-Boltzmann surface area (MM/PBSA) approaches can provide precise information on drug-target interaction binding effectiveness. This method has also been used to test the inhibitory efficacy of natural chemicals against various protein targets ( Good, 2006).

Using the MD simulation approach, various ways are available to examine atomic-level alterations in biomolecules (Khan et al., 2016 ). Some, like Desmond, have a graphical user interface, while others, like GROMACS and AMBER, run via command lines. GROMACS (AMBER), Nanoscale MD (NAMD), and (CHARMM-GUI) are some well-known and commonly used MD simulation programs. The rise in software and hardware powers is crucial for executing such MD simulations ( Kumar et al., 2018).

It is a popular method for researching biologically known systems. It is also employed in various domains, including the Prediction of protein-ligand combination stability, protein mutation analysis, conformational protein stability prediction, and protein unfolding investigations. It is a powerful instrument demanding much computing power to solve biological puzzles ( Hansoon et al., 2002; Hospital et al., 2015).

## Section: The significance of QSAR › Molecules discovered by QSAR, pharmacophore modeling, and molecular docking for tuberculosis

A QSAR study was conducted on thirty-four 8-methyl quinolones by Eric et al. to determine their anti-tuberculosis activity. Picking descriptors and building association models relating to structural characteristics of biological activity was done using the genetic algorithm (GA) and multiple linear regression analysis (MLRA). The 3D structure of all compounds was constructed using the SPARTAN “14 v 1.1.0 tool. PADEL software for calculating molecular descriptors of all 34 compounds. The Build QSAR application was used to analyze geometric algorithms and build QSAR models. The internal validation was performed using the cross-validation leave-one-out technique, and external validation was performed by utilizing them to forecast the action of test sets. An examination of the robustness of the QSAR design was also conducted. The GA-MLRA method was used to construct a robust QSAR model to predict the inhibitory action of some quinolones. The results of this study (R 2 Pred = 0.7393) imply that for novel 8-methyl quinoline analogs, the pMIC can be calculated using the QSAR model that comes under the model’s applicability domain before synthesizing them (Eric et al., 2016). It applied various computational methodologies to the 2,4-diamino quinazoline moiety to assess its efficacy in tuberculosis between diverse biological functions (Bose et al., 2019). V-Life MDS software was used to study all QSAR studies. Merck molecular force field was used to get 3D structures from 2D QSAR. In 3D QSAR, conformers were created using the conformational Monte Carlo technique, and the conformers with the lowest energy were chosen to align. The pharmacophore identification investigations were performed in the V-life MDS 4.4 Mol sign module to associate geometrical representation of the properties required for the molecule to show activation. The docking investigation was conducted using GOLD software. Thirty-three molecules were docked with four distinct protein molecules, significant for anti-TB action and crystalline protein structure. The new molecular set was designed depending on the pharmacophore results of docking studies and QSAR. After designing, the new molecule set was optimized, and using Monte Carlo conformation search conformers were generated. The 2,4-diamino quinazolines scaffold is promising for development as a molecular lead set for lead optimization, according to the findings of this study. According to the QSAR study, better moieties require a perfect distribution of steric potential and hydrophobicity in the molecular system. Pharmacophore mapping depends on the quinazoline ring’s 1 and 3 nitrogen atoms, the 4-amino phenolates molecule at location 4, the benzene ring, and the electronegative fluorine replacement. According to QSAR and pharmacophore mapping data, replacing the piperidine ring at the 2-amino position and the 4-amino phenolate group over the 4-amino position is the main necessity, as evidenced by the design and assessment of the activity using a 3D QSAR model. All of the features assessed and assumed to represent an active moiety were included in the final molecule ( Bose et al., 2019). Bhardwaj et al. explored the binding affinity of 70 novel piperine analogs and reported the activity of 23 compounds against Mycobacterium tuberculosis. The antitubercular effects of verapamil analogs, which are derivatives of dimethoxy phenyl rings bound to carbon chains, are significant. However, piperine, which also has a methylenedioxyphenyl ring attached to a carbon chain, is found to be a structural requirement for its activity. The similar action of these two compounds was correlated using in silico approaches. Using DRAGON and Chem office software, descriptors were calculated in QSAR studies. The QSAR models were generated by performing MLRA (Multiple Linear Regression Analysis) analysis using CODESSA®. The structures of the compounds were sketched and optimized using Chem Sketch software. Schrodinger, 2016–1’s GLIDE module investigated drug-receptor interactions and designed new compounds. www.rcsb.org provided the protein structure (3C3W), or the Protein Prep Wizard module was used to make the protein. The binding cavity within the protein was determined using site mapping, which will be utilized in future studies. Using a 2D sketcher, the structure of the ligands was created and optimized. For energy optimization, PLS3 was employed. It was concluded from QSAR and molecular docking studies that the binding energies range of predicted products with one hydrogen bond to five hydrogen bonds was higher than reported compounds with one hydrogen bond to four hydrogen bonds. Compared to reference medications, some predicted molecules have shown good binding affinity. As the docking scores are comparable, we may conclude that the QSAR models created are good, and these are applied for forecasting the anti-TB activity of novel drugs ( Bhardwaj and Dubey, 2017). The findings from the study underscore the power of integrating diverse computational strategies in the pursuit of anti-tubercular drug discovery. The combination of molecular docking, DFT calculations, reactivity descriptors, QSAR modeling, ADMET evaluation, and molecular dynamics simulations presents a formidable approach to expedite the identification of promising drug candidates (Stanzione et al., 2021). Ultimately, these advances contribute significantly to the ongoing battle against TB, offering hope for developing more effective treatments in the near future (Rajkhowa and Deka, 2013; Rajkhowa et al., 2015). A list of products discovered for tuberculosis is presented in Table 1. A list of the drugs (Table 2) in a clinical trial is discovered with the help of these approaches (Ahamad et al., 2017).

List of some compounds discovered to target tuberculosis bacteria by using approaches of QSAR, pharmacophore modeling, and molecular docking.

A list of the drugs that are in a clinical trial is discovered with the help of these approaches.

## Section: The significance of QSAR › The challenges and prospects of QSAR, pharmacophore modeling, and docking of molecules › QSAR challenges and prospects

The chemical descriptors used as input for the QSAR model vary throughout most QSAR research. The quality to predict traditional QSAR approaches reduces when new substituent group traits depart further from the training set. Some of the challenges associated with 3D QSAR are ligand geometry which is essential for computing geometric descriptors and crucial for 3D QSAR. QSAR data sets may contain many chemicals (>100,000) and descriptors. There is a requirement to maintain many models (e.g., dozens) for a variety of targets; these models should be updated regularly (e.g., monthly) (Winkler, 2002; Cherkasov et al., 2014; Saikia and Bordoloi, 2019). Failure to take data heterogeneity into account, unsuitable endpoint units used, confounded and non-interpretable descriptors being used, descriptor value errors, QSARs having a low transferability, applicability domain is insufficient or undefined, omission of data points that are unnoticed, data that is insufficient, chemicals in a data set are replicated, endpoint values within a narrow range, data that has been over-fitted, in a QSAR, using an excessive number of descriptors, Statistics that are insufficient or missing are also misused and misrepresented, incorrect calculation, the complexity of the data set, validation of QSAR models, establishing the models’ scope of application in the chemical space ( Aparoy et al., 2012; Ma et al., 2015)

Significant-scale QSAR research is possible due to large data and processing resources. Graphic processing units, Cloud technology, and servers are very known and have been used in computer-aided drug design and discovery streams ( Aleksandrov and Myllykallio, 2019). The system pharmacology method has gained popularity among scientists due to its ability to conduct pharmacodynamic assessments, discover new targets, and provide a systems-level understanding of drug-disease interactions ( Maltarollo et al., 2017). Combining QSAR with machine learning methods enhances prediction power and is needed for the future development of QSAR ( Sabitov et al., 2017).

## Section: The significance of QSAR › The challenges and prospects of QSAR, pharmacophore modeling, and docking of molecules › Pharmacophore modeling: Challenges and prospects

The pharmacophore approach still faces numerous roadblocks that limit its ability to reach its full potential, especially given the current high Costs involved in medication discovery and development. The following are some of the challenges: The challenge associated with ligand-based pharmacophore modeling is the modeling of ligand flexibility. The second difficulty encountered when adopting the ligand-based strategy is molecular alignment. Screening massive chemical databases with flexible compounds, a fundamental problem in pharmacophore-based VS., could take quite a long time. In many cases, the most challenging issue with pharmacophore-based VS. is that a minor quantity of simulated hits is genuinely bioactive ( Leach et al., 2010; Qing et al., 2014). The absence of a good scoring function in virtual screening by pharmacophore is also one of the challenges faced while using pharmacophore-based virtual screening. A pre-computed conformation database is necessary for a pharmaceutical-based virtual screening which is also a challenge in its application ( Qing et al., 2014). The de novo design using the pharmacophore-based program new LEAD has the limitation that new LEAD can only handle pharmacophore properties that are concrete functional groups rather than abstract chemical features (Leach et al., 2010; Yang, 2010). The correct selection of the training set molecules is also a difficult task. Another drawback is the lack of a clear approach to generating a pharmacophore query. Finding different conformations for each ligand is also challenging using the pharmacophore model. Another significant drawback is that the pharmacophore confirmation may not be a ligand active form based on free energy. Every ligand-based pharmacophore carries this risk (Seidel et al., 2020; Muhammed and Aki, 2021).

A combination of pharmacophore modeling and other computational techniques is needed to overcome some of the limitations of pharmacophore modeling and stay on top of recent discoveries ( Qing et al., 2014). As a result, pharmacophore modeling has been combined using molecular mechanics simulations. This might help to increase some of the difficulties associated with ligand flexibility modeling. Another issue noted is the absence of good scoring functions utilized in virtual screening by pharmacophores. Machine learning, which has been utilized in various computational ways, can be used to improve such scoring functions. As a result of recent improvements in pharmacophore modeling, structure-based models can now be produced with enhanced properties (Yang, 2010; Kumar et al., 2018; Muhammed and Aki-Yalcin, 2021).

## Section: The significance of QSAR › The challenges and prospects of QSAR, pharmacophore modeling, and docking of molecules › The challenges and future of molecular docking

The market for drug discovery informatics is expected to rise from 1.5 billion dollars in 2016 to 2.84 billion dollars in 2022, and it may continue to grow. As a result, there is a growing demand for innovative informatics solutions development and implementation. Moving from pure research to clinical therapy is one of the primary drivers driving the growth of the worldwide market. More qualified individuals, multidisciplinary backgrounds, and the high cost of informatics software might significantly influence the market’s growth. Several well-known programs have recently been made accessible as free or paid software or services. It will take a considerable amount of time, effort, and resources to fully exploit the potential of this robust approach (Meng et al., 2012; Akhter, 2016; Wang and Zhu, 2016; Dar and Mir, 2017; Kumar et al., 2018; Lambrinidis and Tsantli, 2018; Prieto-Martínez et al., 2018).

Here are some of the difficulties that come with molecular docking. Choosing optimal methods, tools, and parameters in molecular docking is difficult ( Naveja and Medina, 2019). Molecular docking methods generally neglect solvent influence, entropic effects, and polarization for binding ligands. Experimental scoring formulas have been developed to overcome such obstacles ( Ganesan, 2008; Benet et al., 2016). Receptor flexibility is a significant challenge in molecular docking. Docking had another issue with the scoring function’s imperfection. When docking molecules, keeping track of their numerous tautomeric and protomeric states can be challenging (Benet et al., 2016). Evaluating molecular docking results without considering the receptor structure’s quality is also difficult. Protein flexibility is also an important point to be considered, as ligand binding to protein produces conformation changes in protein, hence ignoring protein flexibility may produce incorrect results during molecular docking. Handling flexible protein receptors is a major challenge during molecular docking ( Eldridge et al., 1997; Allouche, 2012).

The development of Local Move Monte Carlo (LMMC) based molecular docking in the future, where A sample that considers the backend loops in addition to the main chain in the ligand binding of proteins and flexible ligands may be a workable solution to the flexible receptor docking issue. Docking applications could be propelled to the next level by accurate and low-cost scoring techniques ( Ganesan, 2008; Benet et al., 2016). For continued progress, the molecular structure databases must be improved. Filters must ensure that the structural models inside them are of higher quality, as this will affect the findings’ dependability. In 1971 the protein data bank (PDB) was created as a pioneer crystal structure database. It is now the most widely used molecular in silico modeling resource, with over 150,000 experimentally validated 3D models. However, even with acceptable geometrical parameters, there is no assurance that the selected structures are error-free, which must be considered. The presence of high-quality statistics does not imply that the structure is flawless. As a result, improving their quality, procedures, and validation would allow better models to be built, which would be helpful in the inevitable process of structural refinement.

On the other hand, a better model will not be more instructive in terms of more complex biological information, necessitating a scientist’s interpretation ( Lambrinidis and Tsantli, 2018). Despite this, the accuracy of the docking tool and the validity of the results can be evaluated. Although docking procedures have gotten more complicated, false positives are still a problem with this methodology; refining the PDB structures would surely enhance pharmacodynamics research and yield better findings.

## Section: Conclusion

QSAR models can be used during drug development research and development stages to develop pharmacodynamic and pharmacokinetic profiles. These in silico investigations predict numerous characteristics and actions that aid in optimizing and prioritizing drug molecules. Computational approaches have resulted in lead structures and novel drug targets, which have sped up drug development. The computational technique may find pharmacological leads and targets against them, as well as attraction and effectiveness between them, before the start of clinical trials; it saves time and money. The QSAR is a commonly used statistical method that links a molecule’s structure to its physiological action meant for a function of molecular descriptors. Hence, it plays a vital role in drug development. Pharmacophore is essential for a compound’s biological action. It aids in de novo design, important characteristics, and high-throughput screening in drug development. In addition to their many applications in the examination of specific molecular activities, structure-based virtual screening (SBVS) molecular dynamics (MD), bounding energy, molecular interactions, molecular docking, and structure-based virtual screening (SBVS) are some of the most popular strategies used in structure-based drug discovery (SBDD). The review article concluded that such techniques will reduce traditional resource requirements by increasing prediction based on current information and limiting and focusing on chemical production and biological testing.


---

# New avenues in artificial-intelligence-assisted drug discovery

- **Authors:** Carmen Cerchia, Antonio Lavecchia
- **Issuer:** Drug discovery today
- **Type:** Scientific article
- **Published:** 2023-02-02
- **Language:** en
- **DOI:** 10.1016/j.drudis.2023.103516
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36736583/
- **Licence:** CC-BY

## Section: Abstract

Over the past decade, the amount of biomedical data available has grown at unprecedented rates. Increased automation technology and larger data volumes have encouraged the use of machine learning (ML) or artificial intelligence (AI) techniques for mining such data and extracting useful patterns. Because the identification of chemical entities with desired biological activity is a crucial task in drug discovery, AI technologies have the potential to accelerate this process and support decision making. In addition, the advent of deep learning (DL) has shown great promise in addressing diverse problems in drug discovery, such as de novo molecular design. Herein, we will appraise the current state-of-the-art in AI-assisted drug discovery, discussing the recent applications covering generative models for chemical structure generation, scoring functions to improve binding affinity and pose prediction, and molecular dynamics to assist in the parametrization, featurization and generalization tasks. Finally, we will discuss current hurdles and the strategies to overcome them, as well as potential future directions.


---

# Organ-on-a-chip meets artificial intelligence in drug evaluation

- **Authors:** Shiwen Deng, Caifeng Li, Junxian Cao, Zhao Cui, Jiang Du, Zheng Fu, Hongjun Yang, Peng Chen
- **Issuer:** Theranostics
- **Type:** Scientific article
- **Published:** 2023-08-15
- **Language:** en
- **DOI:** 10.7150/thno.87266
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37649608/
- **Licence:** CC-BY

## Section: Abstract

AbstractDrug evaluation has always been an important area of research in the pharmaceutical industry. However, animal welfare protection and other shortcomings of traditional drug development models pose obstacles and challenges to drug evaluation. Organ-on-a-chip (OoC) technology, which simulates human organs on a chip of the physiological environment and functionality, and with high fidelity reproduction organ-level of physiology or pathophysiology, exhibits great promise for innovating the drug development pipeline. Meanwhile, the advancement in artificial intelligence (AI) provides more improvements for the design and data processing of OoCs. Here, we review the current progress that has been made to generate OoC platforms, and how human single and multi-OoCs have been used in applications, including drug testing, disease modeling, and personalized medicine. Moreover, we discuss issues facing the field, such as large data processing and reproducibility, and point to the integration of OoCs and AI in data analysis and automation, which is of great benefit in future drug evaluation. Finally, we look forward to the opportunities and challenges faced by the coupling of OoCs and AI. In summary, advancements in OoCs development, and future combinations with AI, will eventually break the current state of drug evaluation.Keywords: Organ-on-a-chip, Microfluidics, Drug evaluation, Artificial intelligence, In vitro model.

## Section: Introduction

Drug discovery and development is one of the most significant translational science activities contributing to human health and well-being. Nevertheless, the discovery and development pipelines are time-consuming and incur massive costs, primarily because of the preclinical validation as well as clinical trials involved 1, 2. It is estimated that over 10 years are needed to evaluate a new drug before it enters the market, and the average cost will be $2.5-5 billion 3, 4. Generally, a standard drug discovery process can be conceptually divided into three parts: target selection, lead identification, and preclinical studies 5. In the early preclinical stage of drug development, drug evaluation is crucial for confidently advancing a new drug candidate. Drug evaluation mainly focuses on physicochemical properties, biological activity, toxicity, safety, metabolism, pharmacological efficacy, and medicinal value of newly developed drugs, which in order to preliminarily verify their safety and effectiveness for further clinical trials, and to protect people from drugs which are unsafe, ineffective, or both 6-8. Traditional drug evaluation has mainly relied on cellular monolayer planar culture models and animal experiments. However, traditional methods face several challenges, in part due to the intrinsic limitations of two-dimensional (2D) cell culture models that may not be able to mimic the microenvironment in an organ, and animal models may not accurately represent what occurs in humans 9-11. In addition, animal models are often not suitable for high-throughput bioassays as well as large-scale drug screening 12, and are also often cost-prohibitive. A bill signed in December 2022 allows the United States Food and Drug Administration (FDA) to approve new drugs without being tested on animals. This marks a major change in people's use of animals after more than 80 years of drug safety supervision. Thus, it necessitates quick and robust methods with the goal of discovering, analyzing, and optimizing a reliable drug candidate 1, 13.

Microfluidics is the science and technology of manipulating and detecting fluids on a micro-scale 14. With its obvious advantages, including fast processing speed, high spatial resolution, sensitivity, and integration, easy control, and low cost of reagents, microfluidics has become an increasingly attractive tool for both fundamental and practical research 15. Furthermore, microfluidics has already been utilized to create more in vivo-like models of cell culture because of the dimensional comparisons with biological cells 16, 17. Notably, microfluidics has the ability to capture, align, and manipulate single cells in drug discovery. Furthermore, microfluidic system has the capability for higher-throughput screening, and it could be used for screening drugs at different species and concentrations. As a valuable tool for developing more in vitro models which capture cellular and organ-level responses, microfluidic technology is widely used for fast and animal-free risk evaluation of new drugs 18.

As a product of microfluidic technology gradually developed, OoCs could faithfully mimic the pathophysiological microenvironment of target organs in vivo, offering exciting potential to bridge the gap between in vitro evaluation models and in vivo pathophysiological complexity 19, 20. In 2004, adapting microfluidic technology for modeling organs and systemic-level functions of human physiology or disease research was first published 21. Then, the most famous and landmark OoC device, known as the 'breathing lung' (lung-on-a-chip) was designed in 2010 22, which initiated the advancement of the biologically inspired OoCs today. Since then, examples of single OoCs include brain/blood-brain barrier 23-25, lung 22, 26, 27, heart 28-30, liver 31-33, kidney 34-36, gut 37-39, vasculature 40-42, skin 43, 44, bone/bone marrow 45, 46, retina 47, 48, muscle 49, 50, fat 51, 52, and tumor/cancer 53-56 have been successfully developed, all of these can be used for drug research. Furthermore, it is possible to investigate organ-organ interactions and systemic diseases like drug off-target toxicity, cancer metastasis, and inflammation by coupling multiple OoC platforms together through vascular perfusion of supernatant exchange or a shared blood substitute 57.

The mechanism of action of drugs is diverse, with various phenotypic effects on cells and organs. Simply recognizing and categorizing these features from the perspective of molecular indicator detection is time-consuming and laborious, which has become a challenge for large-scale molecular library (estimated to be more than 1060 molecules 58) drug screening, and it is even more difficult to display real-time changes in cellular mechanisms. Nowadays, the functional disclosure of drug targets tends to reveal their functions in the dynamic process of life. During this process, drug evaluation with the OoC platform will generate many images and datasets, and the feature extraction of these dynamic data cannot be completed manually. In recent years, the application of AI in microfluidics has achieved significant results, with new deep learning methods and deep neural network models constantly emerging. OoCs are now starting to attract AI, especially the machine learning (ML) and deep learning (DL) approaches to experimental design and data interpretation 57. Deep learning was introduced into the field of machine learning by Rina Dechter as early as 1986, and in 2000, Aizenberg introduced Artificial Neural Networks in the field of machine learning 59. Visual recognition and data processing based on AI will bring possibilities to solve the above problems, including culture conditions optimization, image detection and tracking, and processing such a large volume of data.

At present, OoCs and AI are hot topics in research, and researchers hope to generate more possibilities through the combination of the two. Drug discovery and pharmacological researchers also hope to see this type of review article to obtain relevant knowledge simply and directly. However, most of the current reviews are still focused on discussing the combination of microfluidics and AI (machine learning and deep learning) 60-64. Although a recent review focused on the combination of OoCs and deep learning, the core of this review was not specifically on the application of integration in drug evaluation 19. In fact, drug evaluation is one of the most important areas of OoCs application. Thus, a summary of the application of OoCs in drug evaluation, as well as a timely and comprehensive review of the driving role of AI in this field, will facilitate the combination of both for drug evaluation in the future. In this review, we first give a brief overview of basic information on microfluidics-based organ-on-a-chip. Then, we introduce the most recent advances in the field of OoCs, which exhibit clinical mimicry by simulating human patient responses or have utilized this technology to further drug development and personalized medicine. Moreover, we reviewed typical cases of AI application in drug evaluation using OoCs, which will pave the way for future drug development (Figure 1). Finally, we discuss opportunities and challenges for the future of the field. In addition to cells and tissues, the “organ” here also includes organoids, and organoid-on-a-chip has been included in here OoCs.

Schematic of organ-on-a-chip meets artificial intelligence in drug evaluation. OoCs have been utilized to model almost all organs in humans for drug testing, disease modeling, personalized medicine, and others. To improve the physiological relevance of OoCs, various factors including cell types, stimulations, and materials are considered and incorporated. Finally, OoCs combine with AI will be of great benefit in experiment design and control as well as data extraction and analysis, which holds exciting promise for drug evaluation with OoCs. Abbreviations: iPSCs: induced pluripotent stem cells; ECM: extracellular matrix. Created with BioRender (www.biorender.com).

## Section: The background of OoCs invention

In traditional, 2D cultures cells grow in a culture flask or dish as an adherent monolayer, attached to a plastic surface 65. Although 2D monolayer-based assays have proven to be a valuable method for cell-based studies of low cost, ease to use, and high throughput, adherent culture also has numerous disadvantages, and its limitations have been increasingly recognized 66, 67. One such key limitation is that 2D cultured cells fail to accurately reproduce the natural human physiology, which prevents this culture method from replicating the cell-cell and cell-environment interactions present in native tissue. As a result, drugs respond differently between cells cultured in 2D and corresponding tissues 68. In addition, a drawback is that the cells in the monolayer have unrestricted access to the components of the medium, such as nutrients, metabolites, oxygen, and signal molecules 69. Meanwhile, adherent culture usually allows the study of only a single cell type, which results in cells lacking the microenvironment, or niches, in which they reside in vivo. Thus, the predictive value of 2D monoculture models is quite limited.

Efforts to address some limitations of 2D culture models, 3D culture models have been developed, which provide in vivo-like microenvironments and have received much attention. These models use synthetic or natural cell scaffolds (decellularized) to support cell attachment, growth, and morphogenesis in a 3D environment 70. Synthetic cell scaffolds typically contain biocompatible polymer materials, such as a variety of fiber and hydrogel scaffolds 71. Natural cell scaffolds are made from extracellular matrix gels, which contain such as collagen and glycoproteins, and minerals including hydroxyapatite 72. While the 3D conditions more closely resemble the in vivo state, these models remain lack the multiscale structures and tissue interfaces that are meaningful for organ function. In addition, the lack of controlled and precise application of nutrient supply gradients and chemical cues, results in the poor modeling of an in vivo physiological microenvironment. Importantly, cells are typically not exposed to physical stimuli that are essential for organ development and functioning 6. Of note, one of the most significant paradigm changes in medicine recently has been the recognition of the central role displayed by the microbiome, which is made up of host-specific communities of commensal microbes, in human health and disease 39. However, it is not yet possible for human cells to co-culture with complex microbial that come into direct contact, as this frequently leads to culture contamination and cell death within hours 73. These all limit their use in drug screening.

Preclinical animal models are an essential component of the drug discovery and development process. Although animal models have offered a living system to assess the efficacy of drugs on target site and non-target organ toxicity, it captures the physiological complexity with a high degree of fidelity. However, it is not really representative of human physiology, pathological, and genetic characteristics, thus failing to accurately anticipate drug response in humans 74, as the pharmaceutical industry is gradually discovering. Of note, recent systematic studies on the correlation between animal data and human outcomes have shown a weak predictive ability of animal models 75, and the clinical translatability of drug efficacy tests conducted on animal models is highly controversial 76. Furthermore, animal models have been associated with ethical concerns, high costs, and low yields, as well as difficulty in performing high-throughput evaluations of drugs. Thus, preclinical drug testing models with better physiologically relevant are needed to simulate complex human-relevant conditions, enable high-throughput assessment of drug candidates, improve the success of clinical trials, and ultimately deliver safe and effective drugs to the market.

Organ-on-a-chip is an in vitro microphysiological system (MPS) used for mimicking the human body environment, representing a simplified but realistic model of its organ-level and even organism-level functional counterpart with functionality read-outs matching the intended application 77. Microfluidics-based OoCs take advantage of control strategies and multiparametric approaches designed for microfluidics, compared to static culture models, which allows better oxygen perfusion, continuous nutrient exchange, physiological microenvironments, and tissue mechanical forces to provide sufficient nutrients and necessary chemical/mechanical stimuli to better emulation of conditions within the organisms 78, 79. Notably, OoCs have realized co-culture with microorganisms 39, 80-82. Animal models often lack the ability to predict results in human drug response. Humans and animals differ substantially in physiological structure, complexity, tissue/organ function, and other parameters, resulting in reduced accuracy and reproducibility of experimental results 83. For instance, drug metabolism can lead to the production of metabolites with physicochemical and pharmacological properties significantly different from the parent drug, thereby enhancing biological activity or producing adverse biological consequences 84, 85. Thus, species differences in metabolism may result in an inability to predict the efficacy/toxicity of a drug in humans. For the same drug, it may have different or even opposite pharmacological effects between humans and animals due to differences in the species' target expression, binding capacity, and drug pharmacokinetics and pharmacodynamics (PK/PD). Furthermore, other problems such as ethical concerns, which have also greatly limited progress in drug development. To that end, as an emerging in vitro model, OoCs have been envisioned to replace animal studies. Meanwhile, OoCs may improve the current lack of female individuals in human clinical trials 73.

As a type of microfluidic device, OoCs are created with microchip-manufacturing methods with a miniaturization feature. Owing to the intrinsic characteristics of microfluidics (e.g., compact microchannels), OoCs can provide accurate control of biophysical, biochemical, and cellular parameters 86, and reduces the sample sizes and materials consumption required for drug testing 65. Importantly, OoCs can simulate chemical concentration gradients, which are essential for the regulation of various biological processes and drug studies. Furthermore, OoCs with a physiological barrier function can better mimic the delivery and absorption of drug compounds in vivo 87. Polydimethylsiloxane (PDMS) is the preferred choice for manufacturing OoCs, with advantages such as ease of fabrication and handling, gas permeability, low cost, and optical transparency for real-time culture monitoring 88. Finally, membranes can be integrated into the chips to create multiple channels and separate cells 65.

To date, researchers have developed single-organ-on-a-chip for almost organs in the human body, all of which can be used for drug research. Nevertheless, they lack both a systemic dimension and cross-organ communication 89. As the human body is a physiologically complicated system, thus necessary to evaluate drug disposition throughout the whole body as well as to quantify PK/PD parameters that contribute to direct clinical trial design, and try to gain more understanding of diseases which is caused by multiorgan interactions 90, 91. Multi-organ-on-a-chip, coupled single organs by flow, have been created to recapitulate organ-organ interactions and potentially whole-body responses to drugs and to serve as models for diseases 92.

After rapid developments in recent years, OoCs that replicate human organ functions are a promising technology for drug evaluation (e.g., drug transport, metabolism, toxicity, and therapeutic effects), disease modeling, and personalized medicine, which indicates its potential role in all phases of the drug development (Figure 2). The rise of OoCs has brought a new dawn to drug evaluation. Therefore, in the following, we will outline instances of various single and multi-OoCs examples to discuss recent advances in OoCs development, with a focus on their application in drug evaluation in a human-relevant manner.

At various phases of drug development, the comparison of throughput and reproducibility with physiological relevance and complexity of different in vitro drug evaluation models. Created with BioRender (www.biorender.com).

## Section: The application of single-organ-on-a-chip in drug evaluation

The design guidelines for OoCs are founded on the objective of recapitulating the physiology of the organ system under study. Ideally, the OoCs environment should be created using a minimally functional (simplest feasible) unit of each organ system 78. Since 2010, almost all organ systems have been modeled using OoCs to gain a new understanding of the molecular and cellular underpinnings of various physiological and pathophysiological processes, and to recapitulate clinical responses to therapeutics seen in human patients 73. In this section, we review the key human single-organ-on-a-chip studies, especially under the background of drug development (Figure 3 and Table 1).

Representative examples of single OoCs. (A) An OoC platform simulates physiological breathing movements by applying a vacuum to the lateral chambers to produce mechanical stretching of the PDMS membrane that forms the alveolar-capillary barrier. Adapted with permission from 22, copyright 2010 American Association for the Advancement of Science. (B) Reconstitution of BBB in a microfluidic device showed that hypoxia-enhanced BBB OoC platform reproduces the barrier function and outlines the shuttling of drugs and antibodies. Adapted with permission from 23, copyright 2019 Nature Publishing Group. (C) A bone marrow (BM) OoC platform could summarize both the central perivascular BM niche (without OBs) and the vascularized endosteal BM niche (with OBs) that is discovered in the cavities of long bones. Adapted with permission from 46, copyright 2021 Elsevier. (D) A retina microfluidic platform including an RPE monolayer and adjacent perfusable blood vessel network with barrier function of oBRB successfully mimics the pathogenesis of CNV, especially in terms of morphogenesis. Adapted with permission from 48, copyright 2018 Wiley. (E) A patient-specific glioblastoma OoC platform with immunosuppressive tumor microenvironments was used to dissect the heterogeneity of immunosuppressive tumor microenvironments to optimize PD-1 immunotherapy. Adapted with permission from 54, copyright 2020 eLife Sciences Publications. (F) A gut OoC device contains a complex human microbiome, which makes the study of host-microbiome interactions possible. Adapted with permission from 39, copyright 2019 Springer Nature. (G) A vascularized dual-channel microphysiological system provides a platform to evaluate the renal secretion of novel drug candidates. Adapted with permission from 128, copyright 2020 American Chemical Society. (H) A fat OoC platform combines adipocyte and immune cells to model the inflamed adipose tissue for the analysis of immune-metabolic in type II diabetes. Adapted with permission from 51, copyright 2019 Nature Publishing Group.

Representative examples of drug evaluation in single-organ-on-a-chip.

Representative examples of high-throughput implemented in OoCs. (A) An OrganoPlate 2-lane has 96 chip units, with the perfusion and organ channels divided by a Phaseguide. Adapted with permission from 31, copyright 2021 Elsevier. (B) An OrganoPlate contains 40 microfluidic channel networks, each of which consists of three channels (including a tubule with flow, an extracellular matrix gel, and a flow channel) that join in the center. Adapted with permission from 204, copyright 2017 Nature Publishing Group. (C) A platform incorporates 96 independent microfluidics-based organ models, each with two channels separated by a permeable membrane, and the micropumps integrated with the trans-epithelial electrical resistance electrodes and electronics of the micro-pump sensor array. Adapted with permission from 202, copyright 2021 Royal Society of Chemistry. (D) A PREDICT96-ALI platform is a standard 384-well plate layout, which is an individual airway model with an oval-shaped upper chamber and an inverse U-shaped bottom chamber with inlet and outlet ports. Adapted with permission from 203, copyright 2021 Nature Publishing Group.

## Section: The application of single-organ-on-a-chip in drug evaluation › Brain/BBB-on-a-chip

The structural and functional complexity of the human brain presents unique challenges for neurological drug development. A major obstacle is the blood-brain barrier (BBB), which selectively controls the passage of drugs into the central nervous system (CNS) and prevents it from blood-borne neurotoxic substances as well as maintains homeostasis for optimal brain function 93. In addition, the complexity also makes it challenging to research in non-human models. In this context, OoCs emulating the function of BBB is of particular interest as they enable testing of whether drugs used for the treatment of neuro-related diseases could act across the BBB to their designated targets 78, 94. The very first BBB model design consisted of an upper and a lower PDMS channel divided by a porous membrane, similar to a sandwich structure 95. Usually, astrocytes, pericytes, or other types of brain cells are cultured in the lower channel, while endothelial cells are seeded in the upper channel. Moreover, the neurovascular unit OoC systems were created to develop a more faithful model of the BBB 96, as the BBB is a significant obstacle to the delivery of a lot of neuroactive therapeutics. Although sometimes used interchangeably, the BBB is described as the neurovascular unit free of microglial and neuronal components 97. These models employ transendothelial resistance (TEER) as a functional readout, which is a gold standard method for measuring the 'tightness' of the constructed BBB 94. Previously, it has been demonstrated that using microfluidic perfusion improves physiological barrier function and offers a more predictive drug reaction 98. For instance, hypoxia-enhanced BBB OoC platform outlines the shuttling of CNS-targeting drugs and antibodies in vivo, which may contribute to the development of drugs or delivery vehicles (Figure 3B) 23. More recently, a BBB OoC device was employed to investigate stem cell-based therapies' therapeutic potential for ischemic stroke. This model demonstrated clinically relevant responses to an ischemic injury, and recapitulated the interactions between therapeutic stem cells and host cells 24. Therefore, a human-specific model of the BBB would enhance the comprehension of human neurodegenerative diseases and the discovery of neurological drugs.

## Section: The application of single-organ-on-a-chip in drug evaluation › Lung-on-a-chip

As the lung fills with air, the respiratory regions cyclically expand and contract to increase the surface area accessible for gas exchange. When the alveoli were considered the smallest functional unit of the lung, cyclic expansion can be simulated by applying mechanical stretch to the gas exchange surface 78. The most well-known organ-on-a-chip, known as the 'breathing lung' (lung-on-a-chip) was designed in 2010 (Figure 3A) 22. This device has a microporous membrane between two layers of a channel construction which in human alveolar epithelial cells lined the upper layer of the membrane and human pulmonary endothelial cells lined the bottom layer. Once the alveolar cells were confluent, the medium inhaled from the upper channel formed an air-liquid interface with the alveolar cells. The lung structure is replicated on a platform using flowing air and culture medium, respectively, and the extension and contraction of the porous membrane are achieved by varying the internal pressure of the channels on either side of the channel during particular cycles to mimic physiological respiration 70, 99, 100. The subsequent model used a similar chip design and cell seeding with modifications and additional improvements for various applications, including replicating the drug toxicity seen in cancer patients receiving IL-2 26, and investigating the pulmonary toxicity of nanoparticles 101. In addition, the model of lung airway OoCs was designed to reproduce the lung airway microenvironment 102. Taking the presently well-known COVID-19 as an example, the lung airway OoC system was rapidly being used to repurpose FDA-approved drugs as possible treatments against SARS-CoV-2 103, and amodiaquine was discovered through this platform to be a potential entry inhibitor for SARS-CoV-2 27. More recently, a model that simulates alveoli in vivo using collagen and elastin has been developed, which was called the second-generation lung OoCs 104.

## Section: The application of single-organ-on-a-chip in drug evaluation › Heart-on-a-chip

The heart is one of the least regenerative organs in the body 105, which is also a significant target organ for toxicity. Cardiotoxicity as one of the most common causes of drug failures 106, drives the development of heart OoCs. Cardiac muscle is a highly ordered dense tissue that is susceptible to interference from drugs, drug-drug interactions, or off-target side effects 79. So far, a variety of heart OoC platforms have been developed, including co-culture of multiple cell types such as cardiomyocytes, endothelial cells, and cardiac fibroblasts, focused on establishing biomimetic and functional aspects of the heart 107. Interestingly, most cardiac OoCs are primarily used in cardiotoxicity research. In order to improve the assembly of functional tissue models, anchoring pillars, posts, and wires were utilized to stretch cardiac tissues 108. A platform that used a 'Biowire' model showed it enabled the generation of highly aligned heart tissues and matured these microtissues by electrical stimulation to achieve functional characteristics resembling those of native human cardiac muscle 109. In addition, a novel based on 3D bioprinting was used to construct endothelialized human myocardium for cardiovascular toxicity evaluation, reproducing the cancer drug doxorubicin-related myocardial toxicity that has been clinically observed 28. However, a challenge is the limited ability of mature cardiomyocytes to self-renew 110. In this framework, induced pluripotent stem cells-derived cardiomyocytes (iPSC-CMs) hold great promise; yet, the limitation of its immaturity still remains, which ultimately affects the pharmacological response 28, 107. To obtain a cardiac model with adult-like features, methods such as mechanical, electrical, and hydrodynamic stimulation were used to improve tissue maturation 108. Despite this, it still further expands the potential application of heart OoCs in the field of cardiotoxicity. Heart OoCs are also used to evaluate potential treatments for COVID-19. A study found that azithromycin and hydroxychloroquine, two drugs considered to have therapeutic promise for SARS-CoV-2, when used separately or together as a therapy both have a proarrhythmic potential, which is in accordance with clinical literature 29. Another comparable study came to a similar conclusion 111.

## Section: The application of single-organ-on-a-chip in drug evaluation › Liver-on-a-chip

The liver has a complex microarchitecture with various functions and displays a central role in the synthesis and metabolism of various substances 112. Drug-induced liver injury (DILI) is the most frequent reason for drug candidate failure in preclinical and clinical trials, as well as a common reason for withdrawal from the market after drug approval 113. Thus, during the drug discovery process, accurate prediction of its metabolic capacity and toxicity is extremely important 99. Today, a variety of in vitro models have already been developed to accurately mimic the complex liver architecture and physiology, and to generalize the human liver's response to drugs 114. Notably, these liver organoids successfully reproduce express cytochrome P450 and secrete serum albumin of hepatocytes, recapitulating the function of the native liver 115. The liver is constituted of approximately 1 million lobules which are its constitutional unit, and contain the hepatocytes responsible for drug metabolism 116. However, liver OoC systems usually use primary human hepatocytes or cell lines that decline in function with increasing culture time, which challenge could be overcome by co-cultures with like Kupffer cells, fibroblasts, stellate cells, and endothelial cells, as well as perfusion 88. Recently, a high-throughput hepatotoxicity screening OoC device, OrganoPlate LiverTox™, which contains iPSC-derived hepatocytes, endothelial cells, and Kupffer cells, was used to evaluate 159 compounds known to cause hepatotoxicity, and the toxicological prioritization scores were computed (Figure 5A) 31. Another collagen-based liver OoC platform showed better predictive sensitivity than all previously reported in vitro models after screening 122 clinical drugs for liver toxicity 117. Furthermore, a study that investigated the impacts of human population variability on liver drug metabolism with the use of hepatocytes from different donors, and an analysis of six drugs confirmed significant inter-donor variability in hepatocyte function. The predicted clearance values and those observed in vivo had excellent correlations 118. Of note, one of the beneficial applications of liver OoCs is to mimic human-specific hepatotoxicities, which is frequently overlooked in preclinical animal models 73. A study comparing human, dog, and rat liver OoC platform highlighting demonstrated species-specific differences in drug metabolism and toxicity (including hepatocellular injury, steatosis, cholestasis, and fibrosis) 33, showing the significance of employing human-specific cells in some experiments, while confirming the relevance of using non-human models. Meanwhile, the largest OoCs study to date, in which 780 liver OoC devices were used to evaluate the toxicity risk of a blinded group of 27 known hepatotoxic and nontoxic drugs, showed a sensitivity and specificity of 87% and 100% for liver OoCs, respectively 119. These results are superior to animal and microsphere models, and support the application of OoCs in preclinical toxicology evaluation. With further development, liver OoCs will contribute to predicting drug toxicity early and reduce the occurrence of adverse drug events.

Representative examples of high-throughput implemented in OoCs. (A) An OrganoPlate 2-lane has 96 chip units, with the perfusion and organ channels divided by a Phaseguide. Adapted with permission from 31, copyright 2021 Elsevier. (B) An OrganoPlate contains 40 microfluidic channel networks, each of which consists of three channels (including a tubule with flow, an extracellular matrix gel, and a flow channel) that join in the center. Adapted with permission from 204, copyright 2017 Nature Publishing Group. (C) A platform incorporates 96 independent microfluidics-based organ models, each with two channels separated by a permeable membrane, and the micropumps integrated with the trans-epithelial electrical resistance electrodes and electronics of the micro-pump sensor array. Adapted with permission from 202, copyright 2021 Royal Society of Chemistry. (D) A PREDICT96-ALI platform is a standard 384-well plate layout, which is an individual airway model with an oval-shaped upper chamber and an inverse U-shaped bottom chamber with inlet and outlet ports. Adapted with permission from 203, copyright 2021 Nature Publishing Group.

## Section: The application of single-organ-on-a-chip in drug evaluation › Kidney-on-a-chip

The kidney is a significant organ responsible for metabolism, excretion, and reabsorption, which is a frequent site of toxicity during drug discovery 120. Drug-induced kidney injury (DIKI) is frequently observed in drug therapy and may as a dose-limiting factor 121. Accurately identifying nephrotoxic compounds during the preclinical testing stage would enable effectively avoiding nephrotoxic drugs during development. The minimal functional unit of the kidney is the nephron, which contains the glomerulus, proximal convoluted tubule, loop of Henle, distal convoluted tubule, and collecting duct 122, 123. In 2008, a nephron-on-a-chip containing the glomerulus, the proximal tubule, and the loop of Henle was designed to replicate the function of a single nephron 124. Because of their physiological functions and high energy requirements, proximal tubule cells are particularly susceptible to drug toxicity 125. The first nephrotoxicity study was performed using proximal tubule OoC device consisting of Human Renal Proximal Tubular Epithelial Cells (HRPTEpiC), exposed to fluid flow 34, 126. After that, the proximal tubular model is the main type of OoCs to predict drug-induced nephrotoxicity. Recently, a study showed that proximal tubular OoC platform successfully predicted the nephrotoxicity of a drug (SPC5001). Of note, the drug exhibited nephrotoxicity in phase I clinical trials but not in preclinical animal testing on mice and non-human primates 127. A vascularized human proximal tubule model was developed in a dual-channel OoC system, which is an advancement of previous studies (Figure 3G) 128. In addition, glomerulus OoCs have been developed in the OoCs field in recent years. In a model, human glomerular endothelial cells and podocytes were seeded to reproduce the glomerular filtration barrier 35. However, other kidney structures, including the distal tubules and collecting duct, have not yet been replicated by human cells and used for toxicological applications 129.

## Section: The application of single-organ-on-a-chip in drug evaluation › Gut-on-a-chip

For drug administration, the oral route is the most common. As the first step of ADME (absorption, distribution, metabolism, and excretion), absorption is the vital precondition to play the therapeutic effects of oral drugs 130. The gut is the main digestive organ, responsible for the digestion and absorption of drugs. Thus, understanding the absorption and metabolism of drugs in the gut is critical to drug discovery and development 68. The development of gut OoCs has made it feasible to study the absorption, metabolism, and transport of oral drugs. Early gut OoCs consisted of two overlapping cell culture chambers divided by a membrane lined with Caco-2 cells. To reproduce the dynamic mechanical microenvironment of the gut, this system included symbiotic microbial flora and utilized negative pressure-driven membrane stretching to simulate peristaltic movements. Under these physiological conditions, the cultured cells were reprogrammed to undergo spontaneous 3D villus morphogenesis and small intestinal cell differentiation 131, 132. Importantly, except for the barrier function of the human intestine, the model also has absorption properties that can be used for drug absorption studies 87, for example, to analyze the intestinal permeability of the model drug curcumin in real-time and generate data that are consistent with prior research on the function of the human intestinal barrier 37. Furthermore, exposure to associated biomechanical forces, like flow and peristalsis, can mimic some aspects of the drug's bioavailability and activity 79. What's more, gut OoCs are stable to create the physiologically relevant oxygen gradient support co-culture of epithelium cells with stable communities of aerobic and anaerobic gut microbiota (Figure 3F) 39, 80, which is critical for true human relevance.

## Section: The application of single-organ-on-a-chip in drug evaluation › Tumor/Cancer-on-a-chip

It is still a challenge to predict clinical responses to anticancer drugs in cancer treatment 133. Tumors possess a complicated microenvironment, which contains a dense extracellular matrix (ECM), various stromal/stem and immune cells, irregular blood vessels, and limited perfusion of nutrients, all of which have a significant effect on the efficacy of administered therapies 134, 135. The advancement of cancer OoCs has significantly contributed to the capacity of in vitro models to reproduce the tumor microenvironment in vivo, as multiple factors in the tumor microenvironment (TME) can be controlled separately and precisely in microfluidic platforms, which is essential to improve anti-cancer drug selection strategies 65. A breast OoC platform mimicking cancer mammary ducts showed that tumor cells grown in channels have distinct morphologies and exhibit various sensitivities to two anticancer drugs (bleomycin and doxorubicin) compared to traditional flat surface culture 136, which provides novel insight into the development and testing of cancer therapies. Human orthotopic models of non-small-cell lung cancer OoCs can be able to simulate growth patterns observed in patients, and is consistent with the published results of human clinical trials, indicating that under physiological breathing motions, the growth and invasion of cancer cell were suppressed, and almost completely resistant to the inhibitory effects of the rociletinib 53. In addition, a pancreatic ductal adenocarcinoma OoC platform was developed to further comprehend pancreatic ductal adenocarcinoma-vascular interactions. The authors identified the activin-ALK7 pathway as a mediator of endothelial ablation by pancreatic ductal adenocarcinoma, which results in the limitation of the delivery of chemotherapeutic drugs to the tumors at later stages, and they replicated their findings in mice 137. Researchers utilized patient-specific glioblastoma OoCs to anatomize the heterogeneity of immunosuppressive tumor microenvironments and personalize anti-PD-1 immunotherapy for various glioblastoma subtypes (Figure 3E) 54. Hypoxia (Oxygen content below 3%) is a key feature of tumors, which can influence the cancer response to therapies and facilitate immune escape 138. Another bioprinted patient-specific glioblastoma OoC device reproduces clinically reported patient-specific resistances to concurrent chemoradiation and temozolomide treatment by selectively using materials with different gas-permeable properties to generate an oxygen gradient, and exhibits patient-specific sensitivity to possible drug combinations 139.

At present, tumor OoCs also include colorectal 55, 140, ovarian 141, 142, prostate 143, 144, bladder 145, 146, cervical 147, 148, gastric 56, 149, and skin 150, 151 cancer. As described, tumor OoCs have the capacity to reconstruct major tumor microenvironment characteristics and have great potential to study the mechanisms of tumor development, screen anticancer drugs, and evaluate cancer therapeutics, as well as toward precision medicine.

## Section: The application of single-organ-on-a-chip in drug evaluation › Other single-organ-on-a-chip

The vasculature is important for providing adequate gas, transporting nutrients, removing waste, and offering a selective barrier for drugs introduced through the circulatory system 78, 152. As a 3D metabolically active matrix in vitro, which contains a capillary network for the first time that allows operating within physiological pressure gradients and interstitial flow ranges, showed an application in drug discovery 153. Meanwhile, perfusable 3D microvascular networks were successfully designed, promoting the development of vasculature OoCs 154. At present, vasculature OoCs are formed by providing endothelial cells with various chemical, cellular, or biophysical substances to induce self-assembly of the microvascular network; seeding endothelial cells onto preformed support structures (e.g., by injection molding, 3D printing, and the use of sacrificial network) or embedding cells into hydrogels, and then inducing germination by flow and chemical factors (e.g., hypoxia, VEGF, and nutrient deprivation). Recently, a vasculature OoC platform with innate immunity identified angiopoietin-1 derived peptide that can be used to therapeutic SARS-CoV-2 induced inflammation 155.

The skin acts as the largest organ in the human body and severs as the main barrier to the environment, which is critical for evaluating the cutaneous effects of drugs and modeling transdermal drug absorption 78. In recent years, drug delivery through the skin has also been a hot topic of research 112. Thus, when designing skin OoCs, the reproduction of multiple layers of skin is crucial (i.e., epidermis, dermis, and hypodermis). However, because of its complexity, it is challenging to develop a suitable substitute that can simulate all the skin's properties 156. In this context, the most common skin OoCs has been those generated by introducing directly the tissue inside the model, which continues to be regarded as the gold standard method for simulating physiological situations in a realistic setting 157, 158. Nonetheless, the variability of donor skin could affect the analysis and present challenges in evaluating compounds over time, as is typical in the drug development process. In addition, the availability is another limitation 159. Given this, both reconstructed human epidermis (including EpiDermTM, EpiSkinTM, and SkinEthicTM) and full-thickness skin models have been used for many applications, such as pharmacological 160. Despite this, challenges still remain in these models to evaluate the absorption or permeability of drugs and systemic exposure with the use of topically applied drugs.

The bone is one of the active organs which is undergoing a carefully choreographed remodeling process throughout the life course 161. In recent, a microfluidic device fabricated from hydroxyapatite and PDMS provided a highly bionic bone environment. This model successfully produced a concentration gradient of the model drug, demonstrating the tremendous potential for bone-related drug screening in high-throughput 162. In addition, a vascularized human bone marrow OoC platform containing bone marrow-derived stromal cells and CD34+ cells, which can generalize myeloerythroid toxicity following exposure to chemotherapeutic agents 45. Another bone marrow OoC device consists of the human endosteal, central marrow, and perivascular niches, which can be utilized to obtain a better understanding of normal and impaired hematopoiesis, and a variety of bone marrow pathologies (Figure 3C) 46.

Human donor retinal explants offer a fully functional model, but due to inter-donor variability, limited availability, and poor cultivability, it is not suitable for drug development and testing 47. Recently, a study demonstrated that the interaction of mature photoreceptor segments with the retinal pigment epithelium (RPE) can be reproduced in vitro by a retina OoC platform, which was integrated with over seven different hiPSC-derived essential retinal cell types. Importantly, the model recapitulated the retinopathic side effects of the antibiotic gentamicin and the anti-malaria drug chloroquine, exhibiting the potential of facilitating drug development 47. As another example, a model supporting the outer blood-retinal barrier (oBRB) barrier function successfully mimicked the pathogenesis of choroidal neovascularization (CNV, a key pathological step in a variety of ophthalmic diseases), and proved that bevacizumab alleviated pathological angiogenesis (Figure 3D) 48.

Nowadays, muscle OoCs have been employed in mechanistic research to better comprehend the human skeletal muscles and assess the effects and toxicity of drugs 163. The development of safer and more effective drugs could be helped with the obtained accurate contractility data. Given this, a muscle thin-film technology-based muscle OoC platform demonstrated its ability to simultaneously analyze the contractility of both striated and smooth muscle on the same chip 164. Recently, a high-throughput aorta smooth muscle OoC device replicated the abnormal activation of HIF-1α observed in aortas from thoracic aortic aneurysm patients, and finally identified the two most effective drugs (2-methoxyestradiol and digoxin) from the seven specific HIF-1α inhibitors 49.

Fat tissue, as a major energy reserve, will contribute to obesity due to the imbalance between energy intake and expenditure, and its associated comorbidities present a looming challenge to healthcare delivery throughout the world 165, 166. The interaction of immune cells and adipocytes may lead to chronic low-grade inflammation, which will then result in insulin resistance. An OoC system for characterizing the interaction of adipocytes with immune cells displayed increased pro-inflammatory cytokine secretion and insulin resistance, relative to adipocytes alone. Compared to the previously reported data, the known diabetic drug metformin and the nutraceutical compound omega-3 showed satisfactory results (Figure 3H) 51. Another OoC platform allows monitoring of the intake of fatty acids and quantification of metabolite released into the effluent media in real-time, and its applicability for pharmaceutical research has been assessed by using isoproterenol, which is known to induce lipolysis 52.

## Section: The application of multi-organ-on-a-chip in drug evaluation

As the development of single OoCs matures, when these single organs are fully functionally characterized (i.e., when they show the key characteristics of the desired simulated organ), they can be combined to create the proposed multi-organ-on-a-chip (often referred to as body-on-a-chip or human-on-a-chip). Connecting a single OoCs to another by microfluidics simulates the in vivo role of vascular perfusion and allows control of the culture environment to reproduce some aspects of homeostasis 78. The main advantage of multi-OoCs is obvious, that is, these connections enable the complex and dynamic crosstalk between interested organs and promote a more physiological method for drug delivery, distribution, and absorption 167. As reported, there are three main strategies for connecting single OoCs: 1) connecting the single organ modules with the use of capillary tubing; 2) attaching single organ modules to a microfluidic motherboard that contains all fluidic connections; 3) employing a user-friendly plate with all organ models connected to a channel that controls fluid flow in a manner similar to the vasculature 89. So far, multi-OoCs may have from 2 to 10 different organs, generally between 2 to 4 organs, which have been capable of simulating complex physiological and pathophysiological responses in an impressive manner, and also offer new in vitro tools for assessing drug toxicity and PK/PD 73, finally towards personalized medicine. In this section, we focus on reviewing the main application scenarios of multi-OoCs (Figure 4 and Table 2).

Representative examples of multi-OoCs. (A) A Liver-heart platform for studying the effect of liver metabolism on off-target cardiotoxicity. Adapted with permission from 170, copyright 2018 Elsevier. (B) PhysioMimix gut-liver MPS consists of a controller machine with a pump system and a touchscreen that interacts with the user. The system was used for the quantitative pharmacokinetic study of mycophenolate mofetil. Adapted with permission from 180, copyright 2022 Royal Society of Chemistry. (C) A multi-OoC platform consisted of two bionic organ modules, an upstream 'lung' and a downstream 'brain', allowing to study of lung cancer brain metastasis. Adapted with permission from 187, copyright 2019 Elsevier. (D) A four-organ system for mimicking lung cancer cell metastasis to the liver, bone, and brain. Adapted with permission from 188, copyright 2016 American Chemical Society. (E) A multiple vascularized OoC platform utilizing fluid transfer coupling enables quantitative prediction of human PK responses. Adapted with permission from 177, copyright 2020 Springer Nature. (F) The differentiation and generation of hiPSCs-derived liver and islet organoids in a microfluidic device to simulate human-relevant liver-islet axis under both physiological and pathological conditions for future T2DM study and drug development. Adapted with permission from 183, copyright 2022 Wiley. (G) A 3D co-culture microfluidic model for simultaneous assessment of anti-EGFR-induced tumor and adverse skin impacts. Adapted with permission from 198, copyright 2018 Nature Publishing Group. (H) A multi-OoC system containing up to 10 different organs with different flow configurations, which include epithelial barrier tissues and non-barrier organs, for PK analysis of diclofenac metabolism. Adapted with permission from 182, copyright 2018 Nature Publishing Group.

Representative examples of multi-organ-on-a-chip for applications in drug evaluation.

## Section: The application of multi-organ-on-a-chip in drug evaluation › Drug safety evaluation

In most cases, many drugs fail in phase III clinical trials or have serious side effects after marketing 78, leading to failure in the development of new medicine. Thus, the evaluation of toxicity is critical in late-stage preclinical and clinical research. Toxicity is closely related to liver metabolism, so multi-OoCs designed for toxicity purposes typically include a liver (as the primary site of drug metabolism) and at least one other (target) organ. For example, a biomimetic human liver OoC platform with lobule-like microarchitectures successfully analyzed unfavorable reactions caused by drug-drug interactions of clinical pharmaceuticals during hepatic metabolism, providing an evaluation device to assess drug-induced hepatotoxicity in vitro, especially during combinational therapies 168. In addition, the use of the lung-liver OoC system in acute and chronic toxicity studies of drugs provides new opportunities for demonstrating the security and effectiveness of new drug candidates that target the lung 169. A model with primary hepatocytes and iPSC-CMs allows non-invasive readouts of the cardiotoxicity of drugs and their metabolites while also exploring the impact of liver metabolism on off-target cardiotoxicity, which demonstrates the heart-liver crosstalk (Figure 4A) 170. In a subsequent study, a heart-liver platform containing a skin mimic showed the differential effects of acute and chronic drug exposure, which can be utilized to assess potential drug toxicity from dermal absorption 171. Moreover, multi-organ toxicity was exhibited in a four-organ system made up of neuronal, muscle, cardiac, and liver modules, and all drug treatments generally agreed with published toxicity results based on human and animal data 172. Additionally, a system that integrates liver, lung, cardiac, colon, testis, vascular, and brain derived from human primary cells and stem cells, which can stay viable for at least 28 days, responding appropriately to a series of drugs, including those because of toxicity in humans that the FDA has removed from the market 173. The promise of OoCs to promote drug development lies in their ability to provide humanized drug toxicity information, which can be used as a useful tool to assess drug toxicity effectively and accurately prior to the drug being approved for use in clinical trials.

## Section: The application of multi-organ-on-a-chip in drug evaluation › Drug PK/PD modeling

After identifying candidate molecules and targets, PK and PD studies are conducted. On the one hand, PK researches describe drug concentrations at various organ sites during metabolism, which is referred to as the absorption, distribution, metabolism, and elimination (ADME) of drug candidates. On the other hand, PD researches investigate the effects of the drug on target organs or tissues, such as a correlation between drug dose and pharmacological or toxicological response 174. The combination of PK/PD parameters is critical for new drug development because it can predict the drug response that will occur, thus minimizing the production of toxic metabolites and the side effects of drugs 175, 176. For instance, a multi-OoC platform allowed recapitulation of physiological PK modeling of drug absorption, metabolism, and excretion which drugs first-pass. The model was verified using orally administered nicotine (using gut, liver, and kidney chips) and intravenously injected cisplatin (using coupled bone marrow, liver, and kidney chips). Also, the cisplatin PD predictions are consistent with previously published patient data 177. Determination of drug-administration schemes for phase I clinical trials may be improved by the quantitative in-vitro-to-in-vivo translation of PK and PD parameters via fluidically coupled OoCs (Figure 4E) 177. In a recent study, a platform that adopted a multi-layer structure was used to systematic analysis the absorption, metabolism, and toxicity of ginsenoside compound K, and the PK results were consistent with previous reports 178. Another multi-OoC platform called 'HUMIMIC Chip2' was used to integrate liver spheroids and a skin model for PK-PD studies with local exposure to chemicals of hyperforin and permethrin 179. Moreover, integrating gut-liver OoC platform data with in silico modeling allows to investigate complex combinations of intestinal and hepatic processes for quantitative in vitro PK studies (Figure 4B) 180. Recently, OoCs that combine more organs are designed to study PK/PD. A robotic interrogator maintained the viability and organ-specific functions of eight vascularized, two-channel OoC devices (liver, heart, kidney, intestine, skin, lung, brain, and BBB) for 3 weeks in culture, and predicted the distribution of an inulin tracer throughout the entire system 181. Furthermore, a three-layer microbioreactor-based platform containing up to ten different organs, including epithelial barrier tissues and non-barrier organs, which can sustain cell cultures for more than four weeks. The functionality of the platform has been verified by modeling the PK of a nonsteroidal anti-inflammatory drug diclofenac, which revealed that both diclofenac and 4-OH-diclofenac were distributed throughout all the representative organs (Figure 4H) 182. In summary, the outcomes from multi-OoCs provided insightful data that eventually be applied to evaluate the PK/PD of potential new drugs, leading to a more dependable preclinical stage in drug development.

## Section: The application of multi-organ-on-a-chip in drug evaluation › Disease modeling

The dearth of clinically applicable models is a challenge for many human diseases, especially those complex diseases that involve multiorgan interactions. As a systematic multi-organ metabolic disease, Type 2 diabetes mellitus (T2DM) is characterized by the dynamic interplay of various organs 183, and a clinical cure is not yet available. Recently, a multi-OoC platform was used to model the liver-pancreatic islet axis under both normal and type 2 diabetes conditions, which successfully mimicked the functional coupling of the liver and islet organs' response to external hyperglycemic stimulus and drugs is relevant to humans (Figure 4F) 183. An ulcerative colitis multi-organ system was created by connecting the liver, gut, and circulating immune cells, showing that short-chain fatty acids (SCFAs) derived from the microbiome could either improve or worsen the severity of ulcerative colitis, and these converse results resting with the participation of effector CD4+ T cells 184. This study brought new insights into the immune and metabolic regulation of pathophysiology. Moreover, multi-OoCs connected to the vasculature and circulatory system are critical for understanding local and distant disease development, like cancer initiation and metastasis 185, the latter contributes to up to 90% of cancer-related mortality 186. For instance, a methodological platform that was used to study brain metastasis demonstrated that the protein Aldo-keto reductase family 1 B10 (AKR1B10) contributes to brain metastasis of lung cancer cells (Figure 4C) 187. Furthermore, a four-organ platform that reproduced lung cancer metastasis to the liver, bone, and brain, revealed tumor-induced tissue damage in the targeted bone and liver compartments (Figure 4D) 188. These suggest that multi-OoCs are a practical alternative for predicting cancer metastasis and evaluating antimeatstatic therapies. In addition, the advancement of degenerative brain diseases including Parkinson's or Alzheimer's disease has been linked with gut microbiota, this functional relation is often referred to as the microbiota-gut-brain axis (MGBA) 189. However, a comprehensive in vitro model was lacking for researchers to elucidate potential microbiota-neurodegeneration mechanisms. The European Research Council has funded a project called 'MINERVA' (ID 724734), which seeks to build the first multi-OoC device for microbiome-gut-brain engineering to assess the effect of intestinal microflora on neurodegeneration 190. More importantly, multi-OoCs are particularly valuable for clarifying mechanisms and developing treatments for rare diseases affecting multiple organ systems, where drug development is incredibly difficult because of the available human subjects being scarce, like Churg-Strauss syndrome and POEMS syndrome 191. Thus, the application of multi-OoCs to model diseases improves disease comprehension, diagnosis, prevention, and treatment.

## Section: The application of multi-organ-on-a-chip in drug evaluation › Personalized medicine

Although various in vitro platforms have been developed for drug development screening, there are few that exist for clinical deployment to benefit unique patients. This is an unmet clinical need because patient responses to drugs are frequently unpredictable due to genetic and microenvironmental heterogeneities 192. Remarkable strides in the hiPSCs field allow for the development of patient-specific personalized therapies, making it possible to identify more efficient drugs for a particular individual or patient group 175. Recently, the integration of a heart chip and a liver chip, both created with the same hiPSC line, was reported to investigate the drug-drug interaction (DDI) of the fungicide ketoconazole and the arrhythmogenic gastroprokinetic cisapride, which facilitates the screening of DDI 193. In the treatment of COVID-19, more attention should be paid to comorbidities. A lung OoC platform comprising infected cells from COVID-19 patients has the promise to overcome the potential effects, such as liver, cardiovascular, and kidney disease, or malignant tumors, as which have occurred in patients reported previously, and may assist in providing effective treatment for individual patients 175, 194. Oncology diseases, which are characterized by rapid mutations that lead to morphological changes and various phenotypes of multidrug-resistant that affect the patient's response to treatment, are another area where multi-OoCs have gained great attention in personalized treatment 195, 196. A multisensor-integrated multi-OoC system was developed, and by linking iPSC-CMs and primary hepatocytes together to achieve automated sensing of APAP-induced organoid toxicity. Using this model, hepatocytes were replaced by hepatocarcinoma cells to assess the chemotherapeutic drug doxorubicin treatment-induced pronounced cardiotoxicity 197. Thus, this platform can be used in predicting the cardiotoxicity of drugs by using patient-specific iPSC-CMs. Moreover, a commercially available multi-OoC platform coupling two organs (lung cancer and skin) culture compartments fluidically for evaluating the efficacy of therapeutic anti-EGFR monoclonal antibodies while analyzing a side effect of dermatological toxicities. The results showed that it is possible to detect several key side effects on the cetuximab-exposed skin microtissues at a very early stage, as well as reproduce the inhibition of keratinocyte growth and altered expression of CXCL8 and CXCL10 observed in patients 198. We believe it will be achievable to personalize the screening of drugs using patient-specific preclinical models prior to treatment, while monitoring the adverse effects of all organ systems in the platform, and improving treatment outcomes. Of note, a four organ model integrated predifferentiated organs from the same human iPSCs and successful coculture over 14 days (although the renal model did not further differentiate) 199, which demonstrates the promise of taking advantage of OoCs to optimize the selection of therapeutics in a personalized manner.

## Section: Integration OoC technology with artificial intelligence

OoC technology and deep learning are frontier fields in biomedical engineering and AI, respectively, and represent an ideal combination of experimental and analytical throughput 60. Here, we introduce various applications of AI to OoCs, trying to illustrate the power and versatility of integrating OoCs with AI. Although the integration of these two disciplines has not been extensively explored so far, especially in the field of drug evaluation, we can still get a glimpse of the great potential of OoCs combined with AI in future drug evaluation from the existing research.

Representative examples of OoCs integrated with AI for data analysis. (A) A CNN model was developed to identify important tumor cell behavior parameters from fluorescence images in a glioblastoma OoC platform, and combined with an in vitro-in silico approach to achieve real-time prediction of tumor evolution. Adapted with permission from 223, copyright 2021 Elsevier. (B) A deep prior algorithm, called Recursive Deep Prior Video, was developed for addressing the challenge of the low resolution in time-lapse microscope in OoC applications, and the approach was successfully validated. Adapted with permission from 225, copyright 2021 Elsevier. (C) A tumor OoC platform combining cancer, immune, endothelial, and fibroblasts recapitulated an anti-tumoral antibody-dependent cell-mediated cytotoxicity, and CellHunter method was used to track cancer-immune cell interactions. Adapted with permission from 233, copyright 2018 Cell Press. (D) The cells on the OoC are located and tracked through the video sequence obtained by time-lapse microscopy, and then extract relevant features from the visual atlas are for classification tasks with the use of a pre-trained DL-based algorithm. Adapted with permission from 228, copyright 2020 Nature Publishing Group.

Representative examples of OoCs integrated with AI for data analysis. (A) A microfluidic multicellular coculture array (MCA) was developed and combined with ML to assess adverse skin drug responses. Adapted with permission from 224, copyright 2022 Royal Society of Chemistry. (B) The combined anti-tumor activity of immune cells and oncolytic vaccinia virus in tumor OoC device was revealed by direct imaging and automated analysis. Adapted with permission from 237, copyright 2022 Elsevier.

Representative examples of OoCs integrated with AI for data analysis. (A) A biomimetic bone OoC device for high-throughput osteoporosis drug testing with AI-assisted image analysis. Adapted with permission from 226, copyright 2022 Wiley. (B) In a muscle OoC device, temporal prediction of muscle cell morphology was studied with the RNN model with long short-term memory blocks and trained a CNN model with the temporal images of the RNN to judge the cell function. Adapted with permission from 227, copyright 2019 Elsevier. (C) A microfluidic platform with up to 1920 tumor spheres integrated with a CNN model to assess the efficacy of chemotherapy drugs. Adapted with permission from 230, copyright 2019 American Chemical Society. (D) A µBBN platform for identifying the extravasation potential of cancer cells to brain metastasis niches with advanced live cell imaging algorithm and artificial intelligence. Adapted with permission from 232, copyright 2019 Royal Society of Chemistry.

Representative examples of OoCs combined with AI or automation for experimental design and control. (A) A multi-OoC system includes a physical, biochemical, and optical sensing platform that operates organ units continuously, dynamically, and automatically, achieving in situ monitoring of organoid behaviors. Adapted with permission from 197, copyright 2017 National Academy of Sciences. (B) Automatically adjusts flow conditions with reinforcement learning to assist microfluidic platforms in maintaining stable flow conditions over time. Adapted with permission from 248, copyright 2018 American Chemical Society. (C) The utilization of supervised ML to evaluate the morphological and biological functions of vascularized OoCs. Adapted with permission from 249, copyright 2023 Springer International Publishing. (D) A robotic system consists of a 3-axis motion system, automated liquid handler, peristaltic pump, and custom microscope stage that enables the continuous perfusion, linking, and image analysis of up to ten organ models. Adapted with permission from 181, copyright 2020 Springer Nature. (E) A microfluidic platform based on a programmable membrane-valve allows to provision of combinatorial and dynamic drug therapies and enables analysis of organoids in real-time for personalized drug screening. Adapted with permission from 250, copyright 2020 Nature Publishing Group.

## Section: Integration OoC technology with artificial intelligence › The challenges faced by OoCs in higher-throughput

High-throughput platforms for preclinical drug screening are crucial to reducing the cost of drug discovery 200. Nowadays, the relatively low throughput of the majority of OoC platforms has hampered the widespread adoption of organ-on-a-chip for drug screening. More reliable statistical data requires a large number of tests and results, hence the need for higher-throughput studies on OoCs. Recently, a few studies have been proposed to address this need (Figure 5). For instance, a microfluidic device for modeling the human microcirculation was demonstrated, as a protocol extension. This device can self-organize human microvascular networks, and then perfuse the tumor to summarize discrete steps of early metastatic seeding. Combined with high-resolution imaging, reliable and quick scoring of extravascular cells can be easily achieved. In addition, the ability to manufacture and seed up to 36 devices at once while not affecting cell viability was reported, which further allows for highly parametric studies, and generating a significant amount of data 201. A high-throughput OoC platform with 96 devices integrated programmable fluid flow and real-time sensing for physiologically relevant tissue generation and measurement, enabling accelerated optimization of in vitro models (Figure 5C) 202. Another 96-device platform (PREDICT96-ALI) is compatible with high-resolution in situ imaging and real-time sensing for rapid assessment of drug efficacy against viruses including coronaviruses (Figure 5D) 203. In perfused microfluidic devices, extracellular matrix-supported intestinal tubules were introduced. The OrganoPlate platform is a standard 384-well microtiter plate format with 40 microfluidic channel structures. On this platform, a study containing 357 gut tubes was conducted to test against drug compounds at various concentrations to evaluate the impact on epithelial barrier integrity. Notably, the study produced more than 20,000 data points, which makes it the largest reported OoC platform data set to date (Figure 5B) 204. Another microfluidic platform named IFlowPlate was also built on a 384-well plate, which can be used to culture up to 128 organoids, achieved in vitro perfusable culture and vascularization of patient-derived colon organoids, and successfully developed a colon inflammation model with an innate immune function 205. Thus, the higher-throughput nature of these studies suggests the potential of OoCs as novel, effective, and dependable preclinical models with applications in drug evaluation.

However, it must be recognized that growing throughput typically causes large data generation, leading to labor-intensive and time-consuming processes. Thus, in order to streamline the experimental procedures, it is crucial to develop protocols that facilitate efficient device operation, data collection, and data analysis. For instance, robotics can be used to automate tasks (e.g., operating chips and gathering data), while machine learning can be used to speed up data analysis 93.

## Section: Integration OoC technology with artificial intelligence › The increasingly prominent advantages of AI

In the past few years, AI has supplied significant advantages in many areas of healthcare in research and clinical settings, such as disease diagnosis, precision medicine, and drug discovery and development. Notably, opportunities for applying AI arise at all stages of drug discovery and development, including clinical trials 206. Applications include identification and validation of drug targets, designing of new drugs, quantifying structure-activity relationship, drug repurposing, improving the research and development (R&D) efficiency, as well as evaluation of absorption, distribution, metabolism, excretion, and toxicity, and even aggregating and analyzing biomedicine information and refining the decision-making process to recruit patients for clinical trials and so on 207-210. Furthermore, the identification of new disease genes, pathways, and targets using omics analysis with AI becomes possible 211, 212, thereby providing new mechanisms for future drug discovery and development, as well as precision medicine. Facing massive volumes of accumulated data (e.g., medical images and gene expression data), AI-based approaches can further transform these enormous amounts of data into usable knowledge, thus facilitating systematical discovery, understanding, and learning 213. Importantly, the application of AI offers the opportunity to overcome the inefficiencies and uncertainties in traditional drug discovery and development approaches, while also reducing human intervention and personal bias in the process 208. Today, advances in areas OoCs and AI are increasingly providing the basis for more efficient and successful drug evaluation. Notably, multi-OoCs, and future coupling with AI, will provide a powerful tool for the pharmacological research of drugs, especially complex chemical drugs, botanical medicines, and Traditional Chinese Medicines.

ML is a common technical means to achieve AI, and DL is a type of ML algorithm. Of note, DL is the most representative research field in AI 19. ML could be categorized into supervised, unsupervised, semi-supervised, and reinforcement learning based on labels 214. ML provides automated analytical statistical/model-building approaches for machines to make decisions by extracting information from data or identifying patterns (i.e., learning), without explicit human programming 215. ML has been growing utilized to analyze data (e.g., to clarify processes and predict outcomes), which may reduce inter-operator variability during data analysis. Deep learning is a machine learning technique encompassing a variety of learning models known as deep neural networks (DNNs), which are referred to as 'deep' since containing multiple processing layers 213, 216. The blooming of algorithms, including Deep Belief Networks (DBNs), Autoencoder Networks (AEs), Convolutional Neural Networks (CNNs), Recurrent Neural Networks (RNNs), and Generative Adversarial Networks (GANs) 217, 218, leading to various studies with the use of DL-based AI in drug evaluation. In comparison to traditional ML, which has a limited ability in processing natural data in its raw form, while DL directly performs the feature extraction of the data 216, and is easier to have high accuracy by minimizing errors. Moreover, DL models previously trained on one task commonly could be retrained to execute similar tasks, named transfer learning, which typically needs raw data and fewer computational resources, making DL applicable to a variety of tasks 219.

With the development of OoCs, especially utilizing higher-throughput, highly parallelized microfluidic systems, generating unprecedented quantities of data; however, the large amount of data generated has far exceeded researchers' capacity to process it efficiently, creating a bottleneck in the analysis 60. Typically, manually analyzing data is inefficient and is likely to miss trends that are nonobvious or of interest 220, hence the need for appropriate systems to manage and analyze the data. Thus, AI has been applied to address the challenge of analyzing large and multidimensional datasets, and assists researchers to derive meaningful insights. In brief, new data processing systems should contain four main components: 1) the suitable measuring hardware and microchips, with precise sensors and microsystems to effectively monitor the required parameters; 2) the provided appropriate forms of data collection, transmission, and storage; 3) the improved machine learning algorithms which enable to extract desired information from the obtained massive amounts of data sets; 4) the proper explanation of the collected data, and applied to the discovery of new results 65, 213.

## Section: Integration OoC technology with artificial intelligence › AI-based visual recognition in data analysis of OoCs

To date, the most common data output structure for OoCs is fluorescence microscopic images 60, due to the PDMS's transparency and great compatibility with fluorescence microscopy. This is traditionally handled by manual methods, which are frequently inefficient, time-consuming, and error-prone 221. However, it is important to note that DNN has been trained with organ autofluorescence images to achieve virtual histological staining for relevant assays, including hematoxylin-eosin (H&E), Masson's trichrome, and Jones silver stain. The outcomes showed that these computational stains are almost indistinguishable from the corresponding histologically stained tissue 222. Thus, virtual staining of label-free samples on OoCs could be achieved by utilizing deep learning in the near future.

In a recent study, a CNN model was developed to identify important tumor cell behavior parameters from fluorescence images in a glioblastoma OoC platform, and combined with an in vitro-in silico approach to achieve real-time prediction of tumor evolution (Figure 6A) 223. A microfluidic multicellular coculture array (MCA) was developed and combined with ML to assess skin sensitivity to drugs. The performance prediction of MCA and support vector machine (SVM) classification algorithm demonstrated that the model has 87.5% accuracy, 75% specificity, and 100% sensitivity in predicting skin adverse drug reactions, with the potential as a platform for high-throughput drug screening (Figure 8A) 224. For some OoC platforms, the segment of the special parts of the image with great significance is important for the analysis of experimental results. In this case, applying DL models to accomplish pixel-level segmentation of images acquired from OoCs, will help in the analysis of drug therapy 19. Given this, researchers have developed a new DL-based algorithm without requiring any training, called Recursive Deep Prior Video, to address the challenge of the low resolution in time-lapse microscope in OoC applications, and the approach was successfully validated on real videos of OoC experiments associated with tumor-immune interactions (Figure 6B) 225. Furthermore, a biomimetic bone OoC device has been developed to achieve simultaneous and high-throughput drug testing for osteoporosis. This device was integrated with CNN-based image segmentation algorithms for fluorescence image analysis, and successfully validated its feasibility for drug evaluation (Figure 7A) 226, although mouse-derived cells were used, human-derived cells can be used for future studies.

At the same time, the possibility to visualize cell morphology and trajectory in real-time is essential for the study of drug therapy in OoCs, especially in cancer OoCs. For example, in a muscle OoC device, the authors studied the temporal prediction of muscle cell morphology with the use of an RNN model with long short-term memory blocks. Next, a CNN model was trained with the temporal images of the RNN to judge the cell function (Figure 7B) 227. Besides, a cancer OoC system with the use of a DL-based CNN architecture was used to evaluate the effectiveness of cancer drug therapies by discovering the hidden information within cell trajectories. The Deep Tracking was capable of accurately classifying the cells (91.5% on average), indicating that the DL approach is very proficient at identifying how drug treatments affect cell motility behaviors (Figure 6D) 228. Notably, the use of a CNN algorithm for recognition achieved to perform accurate tumor boundary detection and analysis of tumor invasion 229, which could be further applied in OoCs. Another platform supported by automated image acquisition and cropping analysis has successfully implemented a label-free approach to evaluate the viability of tumor spheroids on a microfluidic platform with up to 1920 tumor spheroids. The authors trained a CNN model to estimate sphere viability based on bright-field images, and accurately evaluated the efficacy of three chemotherapeutic drugs, adriamycin, oxaliplatin, and irinotecan. It is important to note that the training networks of doxorubicin and oxaliplatin have been cross validated, indicating the possibility of using representative drugs to train a universal network and applying it to numerous different drugs in large-scale screening (Figure 7C) 230.

A key challenge in cancer studies is the increased complexity of the tumor microenvironment. Recently, a novel 3D microfluidic blood brain niche (µBBN) platform quantified the microenvironment of brain metastatic tumors (breast cancer) by using confocal tomography and machine learning (neural networks and random forest learning algorithms) to identify intrinsic phenotypic differences in tumor cells capable of metastasizing through the model 231. The same group performed a similar study prior to this one, in which breast cancer cell extravasation was analyzed within a μBBN device using an advanced live cell imaging algorithm to detect small differences between cells with and without brain metastasis potential (Figure 7D) 232. The device enables further utilization to assess the molecular determinants of metastatic cancer cell migration and survival, and to evaluate the effectiveness of drug therapy. In addition, a more complex and better replicating breast tumor microenvironment was built and CellHunter was employed to track intercellular interactions between immune cells and tumor cells in OoCs (Figure 6C). Deep learning enables visualization and quantification of the complex dynamics of tumor OoCs, for characterizing drug responses at the ecosystem level, and for dissecting the roles of stromal components 233.

CellHunter is a DL-based cell tracking analysis algorithm. As reported, CellHunter has been successfully applied to reveal the interactions between human peripheral blood mononuclear cells (PBMCs) and tumor cells in OoCs and showed that only cells from 'wild type' donors (FPR1 normal expression) establish sustained interactions with chemotherapy-treated cancer cells 234. Another similar study investigated the effect of spatial and temporal resolutions of cell-cell interaction analysis in OoCs based on the same platform 235. Furthermore, a microfluidic platform combining advanced microscopy and revised CellHunter was developed to assess the effective migration of interferon-α-conditioned dendritic cells (IFN-DCs) toward drug-treated cancer cells, while discovering the involvement of major underlying factors, such as CXCR4 236. The oncolytic vaccinia virus is an emerging agent in cancer immunotherapy. Recently, a tumor OoC device revealed cooperative antitumoral activity of immune cells and oncolytic vaccinia virus by direct imaging and automatic analysis. In this work, the CellHunter algorithm was applied to high-resolution video analysis to localize and track cancer cells, which high-resolution video is aimed at measuring immune kinematics and cancer-immune interactions (Figure 8B) 237.

Angiogenesis has been reported to be associated with more than 70 diseases. Lately, a study has utilized DL-based image processing algorithms to analyze and quantify angiogenesis on a chip. This method allows the assessment of angiogenesis using up to 16 angiogenesis-related metrics and the extraction of 3D indicators from 2D images. In this work, the model successfully showed changes in response to biochemical gradients and can be applied to drug development 238. Moreover, a new OoC platform for growing, vascularized, and perfused microtissues suitable for large-scale drug screening has been applied to assess the effectiveness of antiangiogenic compounds. This platform is based on a CNN method that enables fast and accurate flagging of compounds that effectively disrupt vascular networks from images of before and following drug applications with near-perfect accuracy. The CNN model significantly outperformed well-trained human raters, representing a substantive step in the automated analysis of data toward high-throughput drug screening 239.

Representative examples of OoCs integrated with AI for data analysis. (A) A CNN model was developed to identify important tumor cell behavior parameters from fluorescence images in a glioblastoma OoC platform, and combined with an in vitro-in silico approach to achieve real-time prediction of tumor evolution. Adapted with permission from 223, copyright 2021 Elsevier. (B) A deep prior algorithm, called Recursive Deep Prior Video, was developed for addressing the challenge of the low resolution in time-lapse microscope in OoC applications, and the approach was successfully validated. Adapted with permission from 225, copyright 2021 Elsevier. (C) A tumor OoC platform combining cancer, immune, endothelial, and fibroblasts recapitulated an anti-tumoral antibody-dependent cell-mediated cytotoxicity, and CellHunter method was used to track cancer-immune cell interactions. Adapted with permission from 233, copyright 2018 Cell Press. (D) The cells on the OoC are located and tracked through the video sequence obtained by time-lapse microscopy, and then extract relevant features from the visual atlas are for classification tasks with the use of a pre-trained DL-based algorithm. Adapted with permission from 228, copyright 2020 Nature Publishing Group.

Representative examples of OoCs integrated with AI for data analysis. (A) A microfluidic multicellular coculture array (MCA) was developed and combined with ML to assess adverse skin drug responses. Adapted with permission from 224, copyright 2022 Royal Society of Chemistry. (B) The combined anti-tumor activity of immune cells and oncolytic vaccinia virus in tumor OoC device was revealed by direct imaging and automated analysis. Adapted with permission from 237, copyright 2022 Elsevier.

Representative examples of OoCs integrated with AI for data analysis. (A) A biomimetic bone OoC device for high-throughput osteoporosis drug testing with AI-assisted image analysis. Adapted with permission from 226, copyright 2022 Wiley. (B) In a muscle OoC device, temporal prediction of muscle cell morphology was studied with the RNN model with long short-term memory blocks and trained a CNN model with the temporal images of the RNN to judge the cell function. Adapted with permission from 227, copyright 2019 Elsevier. (C) A microfluidic platform with up to 1920 tumor spheres integrated with a CNN model to assess the efficacy of chemotherapy drugs. Adapted with permission from 230, copyright 2019 American Chemical Society. (D) A µBBN platform for identifying the extravasation potential of cancer cells to brain metastasis niches with advanced live cell imaging algorithm and artificial intelligence. Adapted with permission from 232, copyright 2019 Royal Society of Chemistry.

## Section: Integration OoC technology with artificial intelligence › AI-based in electrochemical detection and analysis of OoCs

Except for microscopic images, various data types, including electrochemical detection data, can serve as inputs for DL model development for training, enabling the detection of organ functions and drug treatment endpoints on OoCs. Electrochemical monitoring technology is automated and noninvasive, making it suitable for long-term operation in the monitoring of OoCs. By integrating a variety of online physical and biological electrochemical sensors to accomplish continual, automated, and in situ sensing of microenvironment biophysical and biochemical parameters (Figure 9A) 197, noninvasive monitoring OoCs and performing real-time data analysis (e.g., measurement of nutrients, metabolites, proteins, growth factors, exosomes, shear forces, current/electrical resistance, pH, oxygen levels, and drug uptake) could be achieved for autonomous decision-making 240. Importantly, all these real-time and continuously collected data could be combined with AI-based data processing for studying and optimizing closed-loop feedback-based experimental parameters. Eventually, the system will be able to automatically regulate and control various functional parameters of OoCs, achieving the development of intelligent OoCs 62, 241.

Representative examples of OoCs combined with AI or automation for experimental design and control. (A) A multi-OoC system includes a physical, biochemical, and optical sensing platform that operates organ units continuously, dynamically, and automatically, achieving in situ monitoring of organoid behaviors. Adapted with permission from 197, copyright 2017 National Academy of Sciences. (B) Automatically adjusts flow conditions with reinforcement learning to assist microfluidic platforms in maintaining stable flow conditions over time. Adapted with permission from 248, copyright 2018 American Chemical Society. (C) The utilization of supervised ML to evaluate the morphological and biological functions of vascularized OoCs. Adapted with permission from 249, copyright 2023 Springer International Publishing. (D) A robotic system consists of a 3-axis motion system, automated liquid handler, peristaltic pump, and custom microscope stage that enables the continuous perfusion, linking, and image analysis of up to ten organ models. Adapted with permission from 181, copyright 2020 Springer Nature. (E) A microfluidic platform based on a programmable membrane-valve allows to provision of combinatorial and dynamic drug therapies and enables analysis of organoids in real-time for personalized drug screening. Adapted with permission from 250, copyright 2020 Nature Publishing Group.

## Section: Integration OoC technology with artificial intelligence › AI-based experimental design and control of OoCs

Although the most of current applications focus on post-experimental data analysis, DL has increasing potential for designing microfluidic systems and controlling systems during experiments 60. Microfluidics represents an excellent platform for supporting automation and intelligent control of reaction conditions 242. In the preparation phase of a project, DL can be employed for devices design and materials selection to make OoCs more suitable for specific applications 19. Traditionally, soft lithography, photolithography, and etching techniques have been widely utilized in the manufacture of OoC devices. However, these methods presented serious limitations that hinder the pace of development and innovation of microfluidic applications 243. Given this, 3D printing has the potential to be a promising solution. This technique provides high-throughput and scalability, and allows for industrial means of mass production. To date, a number of studies have applied 3D printing technology to build molds for manufacturing OoC devices. In a study, 3D printing was utilized in the manufacture of almost all chip components 244. To realize high precision microscale structures, material properties, and printing parameters require delicate control 245. During this process, AI could be applied to provide support to improve accuracy and efficiency, such as 1) the optimization of processes; 2) the detection of manufacturing defects; 3) the evaluation of dimensional accuracy; and 4) the prediction of material properties 246. For instance, a computer vision-based (CNN-aided calibration) approach was used to rapidly and precisely design microfluidic devices and minimize absolute errors in device manufacturing, which offers a convenient, effective, and efficient solution for 3D printing of OoC platforms 247.

During the experiment, reinforcement learning (RL)-based deep Q network can utilize image feedback to assist in retaining stable flow conditions for prolonged periods by automatically adjusting flow conditions to mitigate the inconsistent system performance exhibited in microfluidic platforms during extended experiments (Figure 9B) 248, which could be applied to the control of culture media in OoCs. An emerging direction in the development of OoCs is vascularization, which is becoming a significant and necessary physiological level feature of most OoCs 249. Recently, a study assessed the oxygen transport capacity of vascular network association with the most common morphological indicators through ML algorithms such as multiple linear regression and random forest. This approach will assist in measuring the performance or biological function of vascularized networks in OoCs (Figure 9C) 249. For lung OoCs, mechanical stretch is used to mimic the cyclical expansion, resulting in tissue mechanical force control being critical. Therefore, automatic control of the applied tissue mechanical forces can be achieved by DL of cell morphology and microenvironment. Importantly, DL allows for the real-time monitoring of the entire system performance while continuously detecting cell processes and biomarkers without harming cell viability 19. Researchers have proposed to regulate microenvironmental parameters through spectroscopy, automated multisensor, and microscopy monitoring systems, as well as through machine-intelligent data-driven optimization, as the cell microenvironment is crucial for maintaining physiologically relevant organ functions and responses to drugs 62. A multi-OoC system achieved exact control of flow distribution and drug distribution to different organs using an on-board pneumatically-driven pump with independently programmable flow rates 182. Furthermore, an automated microfluidic platform was developed to accomplish dynamic and combinatorial drug screening, which allows for highly dynamic, reproducible, and reliable analyses of patient-derived organoids (Figure 9E) 250. What's exciting is that liquid-handling robotics control systems allowed the automated culture, perfusion, medium addition, fluidic linking, sample collection, and in situ microscopy imaging of up to ten organ models (Figure 9D) 181, which will be easier to integrate with pharmaceutical robotic pipelines 73. Therefore, automation allows real-time data collection and analysis for feedback on target results. In the near future, it is conceivable that AI-guided organ-on-a-chip may in fact be more fundamentally natural than human control.

In conclusion, even though only a few OoC studies have incorporated AI, we believe that these existing studies are sufficient to indicate exciting prospects for synergy between OoCs and AI in future drug evaluation (Figure 6-9). Nevertheless, much follow-up work and collaboration are still needed to drive the development of the combination of OoCs and AI, and ultimately to contribute to the advancement in the field of drug evaluation.

## Section: The future prospect of OoCs and AI in drug evaluation › OoCs will become an indispensable part of the future drug evaluation system

OoCs using human cell sources (e.g., primary cells, cell lines, iPSCs, or organoids) could possibly eliminate the effects of cross-species differences introduced by utilizing animal models for clinical drug studies. A major obstacle of OoCs is the limited lifespan of cells in the device, and such limitation is exacerbated when not using immortalized cell lines 251. Despite the widespread view that cell lines typically lack the ability to simulate tissue-specific functions with high fidelity; however, cell lines are able to provide a practically limitless supply of similar cells that could be utilized for studies in higher-throughput. This could potentially improve the reproducibility of results, making it highly valuable for drug development in the early stages 73. A study demonstrated that the reproducibility was greatly dependent on the cell source 252. It is noteworthy to mention that iPSCs, while iPSCs provide the same advantages, they are frequently limited the wide applicability by their failure to display a fully mature differentiated phenotype, and the necessary purity for many tissues 73.

OoCs have been extensively used to build a variety of in vitro disease models, an important aspect of which is rare disease models, and OoCs could fill the gaps where animal models do not work or even do not exist. To date, only about 400 of over 7,000 identified rare diseases have active research programs due to the absence of animal models for others, resulting in significant hindrances to the development of new drugs in the field 253. In the past, OoCs have been used to successfully model many rare diseases. Recently, TNT005, a drug received clinical approval from the FDA based on preclinical efficacy data obtained from rare disease-on-a-chip, showing that OoCs have great potential in the field of rare diseases leading to the generation of IND 254. OoCs-based models for rare diseases have the potential to produce significant data that are typically not observable in in vitro and in vivo models or clinical samples, as OoCs enable long-term and real-time monitoring of changes in physiological processes. Through further analysis of these data by ML/DL in real-time, it is possible to analyze the progression at the molecular level of such diseases, and eventually discover the specific mechanisms by which the diseases occur 19. Thus, OoCs have a promising opportunity in rare diseases. Besides, similar approaches are applicable to other diseases as well. Furthermore, OoCs could be seeded with iPSCs and patient-derived organoids to develop patient-specific models, and deliver on the promise of advanced personalized medicine.

Perhaps more importantly, OoCs can be used first time in emergencies for disease mechanism research and drug repurposing, discovery, and toxicity evaluation. For instance, during the COVID-19 global pandemic, several OoC platforms have been successfully used 27, 29, 111, 155, 203, 255-258. A vascularized lung OoC platform was utilized for SARS-CoV-2 infection and to identify the virus-induced vascular damage, including inflammatory response and loss of barrier integrity, the latter can be alleviated by tocilizumab treatment 255. The same team also revealed the SARS-CoV-2-induced intestinal injury and immune responses with the use of a gut OoC platform 256. Moreover, lung airway OoCs have also been used for the reconstruction of clinically relevant influenza virus evolution 257. Meanwhile, OoCs have also been successfully used in the study of other viruses 259, 260. Thus, the development of antiviral drugs will continue to be a major focus of drug discovery in the post-COVID-19 era 261.

## Section: The future prospect of OoCs and AI in drug evaluation › New AI for new OoCs

AI itself is a rapidly developing discipline, and deep learning networks and automated machine learning have promoted the development of generative AI. AI has shown unprecedented creativity, based on OoCs' own needs and new creative needs, the development of OoCs will be greatly accelerated.

Firstly, AI can address the bottleneck issue in the development of OoCs hardware. PDMS is one of the most popular materials for fabricating microfluidic devices. However, there is a common concern that OoCs made out of PDMS are unable to be utilized efficiently for drug research because of drug absorption 262. But this issue has not proven to be as serious a concern as first thought, because only hydrophobic drugs are absorbed by PDMS, which is only a small portion of the drug development pipeline 73. In fact, as previously mentioned, those showing in vivo simulations in response to clinically relevant drug exposures, as well as OoC platforms capable of quantitatively predicting human pharmacokinetic parameters, were manufactured almost by PDMS (Table 1). Despite this, the absorption of PDMS remains a significant challenge for drug screening of hydrophobic compounds like small molecule drugs, which could result in biased experimental results. Now, researchers could avoid the risk of small molecule drugs being absorbed by using alternative materials such as inorganic (e.g., glass and silicon), elastomeric (e.g., polyesters and polyurethane), and thermoplastic (e.g., poly(methyl methacrylate) and polycarbonate) materials, or coating PDMS with non-absorbent coatings 31, 44, 263, 264. Nevertheless, a careful characterization of the adsorption/absorption curves is required for OoC platforms, regardless of the material of manufacture chosen 79. Furthermore, PDMS-based devices frequently need to be manually cast, punched, and assembled, thus significantly reducing the reproducibility and throughput of the fabrication process 265, and that could be addressed by 3D printing/bioprinting 266, 267. 3D bioprinting technology has been widely utilized in the construction of in vitro tissue/organ models and testing devices for drug screening 6, including OoCs. It makes it possible to precisely distribute cells or biomaterial in a target region, which allows the creation of more complex structures and microenvironments that more accurately mimic the function of living organisms 6, 268. In fact, in other fields, AI and 3D bioprinting have been widely combined. AI-assisted artificial design of structures has a much faster optimization iteration speed than engineers, and the identification and discovery of material defects based on AI feature recognition are also faster and more accurate. In the future, generative AI will bring deeper technological changes to the development of OoCs in terms of drawing design, structural optimization, and even full process production.

Despite this, OoCs remain facing various challenges that must get past in order to promote their physiological relevance and facilitate their translation into the clinic. For example, introducing more cell subtypes, metabolites, and microbiomes, as well as biochemical and biophysical gradients 175, or vascularization and innervation of organs 269, to increase the complexity of the models. More importantly, the body-on-a-chip system needs to be scaled according to the sizes of actual organs in vivo, relying on appropriate scaling rules and methods, and the fluid volume and dynamics in chips should be adjusted in accordance with specific human organs 175, which are key to simulate physiological responses. Of note, in the experiment design, a balance between the system's feasibility and complexity should be considered carefully 174. In addition, the use of robust culture media, especially for multi-OoCs, which can help to promote cell survival in different organ types and keep the various organs functional 175, is equally significant, as a key challenge. In microfluidic devices, organ function often declines in long-term culture, and tissue necrosis caused by a lack of oxygen diffusion continues to be a barrier to the use of larger or more complex organs, although vascularization of most organs has been achieved. In view of this, vascularized constructs with a tissue-specific vasculature and perfusable vascular network will offer the foundation for reliable OoCs with sustained functionality 269. Notably, AI can use reinforcement learning to identify optimal medium compositions and dynamic culture conditions for particular cell types, possibly extending the lifespan and functionality of present in vitro organ models 62. More importantly, for integrated multiorgan models, identifying optimal medium compositions and dynamic culture conditions for co-culture of various cell types, would make more sense.

Secondly, AI will increase the detection throughput of OoCs. Typically, OoC devices are low-throughput, which limits their applicability in the early phases of drug discovery 270. However, considering that there are multiple stages in drug discovery and development where OoCs could be implemented, more complex low-throughput to medium-throughput OoC devices may be more useful at later stages, such as drug efficacy studies 79. For pharmaceutical companies, the model can be selected according to the stage of drug development, after considering time, cost, and benefits. Although physiological relevance may be compromised in exchange for high-throughput 93, in fact, the recently developed high-throughput OoC devices still retain the key features required for drug developers 31, 203, 205. Yet, the increase of larger data due to the use of high-throughput platforms is a new challenge, this could probably be solved with AI, as previously discussed. In addition, automation is another key requirement for developing reliable and high-throughput platforms 271, while such devices have been developed, they are extremely rare 181. Importantly, OoCs successfully integrated with AI will be invaluable for its applications in drug development, and investigating how better to integrate is worthwhile.

Finally, AI further promotes the convenience of OoCs data processing. At present, the iterative development speed of AI is astonishing. A simpler, more open, and more user-friendly AI-based algorithm platform will be developed, making image and big data analysis for OoCs dynamic processes simpler. Recently, especially with the emergence of open AI, it will also be applied in the scientific field. The design of OoCs and the extraction of more biological-related features will be completed by AI. Imagine the future, where people will become emitters of commands, AI-controlled automated OoCs production and analysis platforms will present the data we need, and drug evaluation will become an easy task at that time.

We can foresee that AI will further help us invent new OoCs products in the design, production, and control of OoCs, as well as data processing, to expand the application of OoCs. While OoCs' potential is exciting, the technology is still in its early stage 79. Also, despite the significant benefits of coupling OoCs with AI, there are still some challenges ahead, especially as this fall within the healthcare field. For instance, as mentioned in section 5.2, how to achieve the proper explanation of the collected data. A typical issue of machine learning, particularly deep learning models is known as “black box approach”; that is, the lack of interpretability, which limits the obtaining of a suitable explanation from such models on how they arrive at their results 206. This lack of interpretability may significantly hinder their application in the short term. Thus, explainable models are necessary to be developed to improve trust, which will promote the application of models in OoCs. Meanwhile, repeatability is another important issue. It may produce different results by using different algorithms, thereby increasing uncertainty 206. To date, some solutions have been proposed to move AI towards reproducible 272. The quality of the model depends on the quality and characteristics of the data, so the datasets collection and selection are very significant for building a model, which directly impacts the accuracy and predictability of the model. Of note, training, validation, and testing datasets are crucial for model development, but the amounts of datasets required depends on the complexity of the data type and the task 93, 273. Despite such challenges, as both field progresses, the application of AI will undoubtedly bring greater vitality and impetus to the development of OoCs, especially in the area of drug evaluation.

Last but not the least, while OoCs have advanced significantly in the academic environment, and a few OoC platforms have even been successfully converted into commercial products, numerous challenges prevent its complete deployment in an industrial setting, and OoCs are still marginalized in the pharmaceutical industry 14, 174. To bridge the academia-to-industry gap and facilitate the adoption and implementation of OoCs in the drug development process, ongoing engagement, and discussions with OoCs developers, end users, and regulatory bodies are critical 79, 274. From a long-term viewpoint, as technology improves and cost decrease, OoCs will finally be better accepted and adopted by the pharmaceutical industry.

## Section: Conclusion

In summary, organ-on-a-chip successfully replicates the critical physiological functions and environment of the human organs, as a state-of-the-art in vitro model, showing encouraging performances in a variety of drug evaluation platforms. Nevertheless, the current OoCs still must face many challenges that take it from academia to industry. Continuing development with AI, it is undeniable that OoCs will likely dramatically change drug development, disease modeling, and personalized medicine.

## Section: Acknowledgments

This work was supported by the National Natural Science Foundation of China (82274224), China Academy of Chinese Medical Sciences Innovation Fund (CI2021A00610) and the Fundamental Research Funds for the Central Public Welfare Research Institutes of China (JBGS2021001, CI2021B017-2).


---

# Perspective on the challenges and opportunities of accelerating drug discovery with artificial intelligence

- **Authors:** John P Santa Maria, Yuan Wang, Luiz Miguel Camargo
- **Issuer:** Frontiers in bioinformatics
- **Type:** Scientific article
- **Published:** 2023-02-23
- **Language:** en
- **DOI:** 10.3389/fbinf.2023.1121591
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36909937/
- **Licence:** CC-BY

## Page 1 (Section: Perspective on the challenges and opportunities of accelerating drug discovery with artificial intelligence)

Perspective on the challenges and
opportunities of accelerating drug
discovery with artiﬁcial
intelligence
John P. Santa Maria Jr1†, Yuan Wang1 and Luiz Miguel Camargo2*
1Data and Translational Sciences, UCB Biosciences Inc., Cambridge, MA, United States, 217-09, LLC,
Wellesley, MA, United States
KEYWORDS
artiﬁcial intelligence, machine learning, drug discovery and development, data, compute
1 Introduction
Technology has long been a driver of innovation and improvement in drug discovery
(Gershell and Atkins, 2003; Pina, et al., 2009). Advancements within ﬁelds such as chemical
engineering, high-throughput experimentation, and molecular biology have transformed the
process of drug hunting from serendipitous discovery within historic dye collections to
methodical science with empowered understanding of medicines’ impacts on human health.
Despite improvements in scope and cost-efﬁciency brought on by adopted technologies, our
industry follows “Eroom’s Law”, an observed exponential decay in FDA new drug approvals
per billion dollars of R&D investment (Scannell, et al., 2012), highlighting a key expectation-
reward gap between technological investments and payout in therapeutics.
Drug discovery is, in practice, a chain of challenging decisions across diverse disciplines.
In considering the journey of a therapeutic candidate from administration to in vivo target
engagement, a discovery team must address numerous biological and chemical questions. No
single technology or dataset has emerged that is powerful enough to tackle all of these
questions in aggregate, and we must often drive decisions using surrogate or partial readouts
in the absence of ethical and/or practical measurements (Scannell and Bosley, 2016).
Artiﬁcial Intelligence (AI), a technology that has gained a lot of publicity and investment,
is unique in its promise to impact multiple challenges across the drug discovery pipeline
(Lounkine, et al., 2012; Vamathevan, et al., 2019; Bender and Cortés-Ciriano, 2021; Gupta
et al., 2021; Paul, et al., 2021; Renaud and Wang, 2021; Kumar et al., 2023). On one hand,
when appropriately applied, AI can help us leverage advances in laboratory techniques,
generated data, and computational algorithms to make the best decisions we can using the
often incomplete information that we have. On the other hand, AI has already had some
controversial and expensive failures in the industry, such as Watson AI for automated
disease diagnosis and the clinical trial failure of Exscientia’s DSP-1181, touted as the ﬁrst AI-
designed drug (O’Leary, 2022; Raleigh, 2022). History teaches us that technology integration
happens in the context of the present-day and thus implementation is neither seamless nor
immediate. Knowing the strengths and weaknesses of AI can help ensure its correct
application and reduce the risks of both over- and underinvestment.
2 Machine learning (ML) and AI in drug discovery
The recent procurement of diverse biological and chemical data generated by ‘omics
technologies has fueled an AI revolution for biomedical sciences (Biswas and Chakrabarti,
OPEN ACCESS
EDITED BY
Garrett M. Morris,
University of Oxford, United Kingdom
REVIEWED BY
Sabina Podlewska,
Maj Institute of Pharmacology, Polish
Academy of Sciences, Poland
*CORRESPONDENCE
Luiz Miguel Camargo,
luizmiguelc@googlemail.com
†PRESENT ADDRESS
John P. Santa Maria Jr
Computational Drug Discovery,
FogPharma, Cambridge, MA,
United States
SPECIALTY SECTION
This article was submitted to
Drug Discovery in Bioinformatics,
a section of the journal
Frontiers in Bioinformatics
RECEIVED 12 December 2022
ACCEPTED 06 February 2023
PUBLISHED 23 February 2023
CITATION
Santa Maria JP Jr, Wang Y and
Camargo LM (2023), Perspective on the
challenges and opportunities of
accelerating drug discovery with
artiﬁcial intelligence.
Front. Bioinform. 3:1121591.
doi: 10.3389/fbinf.2023.1121591
COPYRIGHT
© 2023 Santa Maria, Wang and Camargo.
This is an open-access article distributed
under the terms of the Creative
Commons Attribution License (CC BY).
The use, distribution or reproduction in
other forums is permitted, provided the
original author(s) and the copyright
owner(s) are credited and that the original
publication in this journal is cited, in
accordance with accepted academic
practice. No use, distribution or
reproduction is permitted which does not
comply with these terms.
Frontiers in Bioinformatics
frontiersin.org
01
TYPE Opinion
PUBLISHED 23 February 2023
DOI 10.3389/fbinf.2023.1121591

## Page 2 (Section: Perspective on the challenges and opportunities of accelerating drug discovery with artificial intelligence)

2020). The charge for data-hungry ML is to help us extract value
from these experiments: identifying patterns beyond human
recognition,
distilling
large
and/or
complex
datasets,
and
generating predictions to inform future experiments. The hope is
that resulting ML models built on biochemical data capture
underlying principles describing molecules and the behaviors of
living systems with implications for disease amelioration. Some of
these principles have direct translation to the drug discovery process,
FIGURE 1
(A) Tasks required and challenges encountered in ML applications for drug discovery. (B) A decision ﬂowchart for applying ML in drug discovery.
Frontiers in Bioinformatics
frontiersin.org
02
Santa Maria et al.
10.3389/fbinf.2023.1121591

## Page 3 (Section: 3 Requirements and challenges for using AI)

such as enabling the engineering of antibodies with improved target
afﬁnity and reduced immunogenicity (Bachas, et al., 2022). Others
have
less
immediate
applicability—for
example,
functional
understanding of AI-predicted RNA spliceoforms (Jaganathan,
et al., 2019) toward new targets may be limited by our
understanding of the nuanced contexts of disease, and ML-
informed protein structures (Jumper, et al., 2021; Lin, et al.,
2022)
may
not
guarantee
the
identiﬁcation
of
therapeutic
binders, due to limitations such as the synthesizable chemical
space of today’s screening libraries. Nevertheless, each advance
improves our ability to answer key scientiﬁc questions and make
informed decisions, with industry impact proportional to the target
and disease focus areas in which it can be applied.
The ability of AI to address diverse problems and data types is
enabled in part by the modularity of ML architectures. In practice,
observed success of an AI method for one task may lead to rapid
trialing, tailoring, or even direct transfer of encoded modules and
learnings for the next. However, domain-speciﬁc performance
boosts are often achieved using customized scoring functions or
connectivities and processing steps adapted to the input data. For
example, advanced algorithms like AlphaFold2 and ESMFold
illustrate how inputting amino acid sequence alignments together
with procedures for facilitating information ﬂow between modules
and continuous reﬁnement signiﬁcantly improved prediction of
protein structure (Jumper, et al., 2021; Lin, et al., 2022).
Understanding input requirements of data and algorithms can
help ensure correct application of these kinds of ML approaches
to impact drug discovery.
3 Requirements and challenges for
using AI
The existence of challenges in drug discovery does not
guarantee AI as an immediate and practical solution. Required
ingredients of data, compute, expertise, business utility, and a
digital-savvy culture must ﬁrst be assembled with conscious
investment to ﬁrst ensure readiness and implementability
(Figure 1). Deﬁciencies in any of these elements limit the
value we can generate with AI.
As the input for ML algorithms, the shape, quality, scope, and
quantity of data matter. Data can be organized in many ways—for
example, time series or multidimensional measurements can be
stored within one wide or multiple narrow arrays—and conscious
data shaping can mitigate misinterpretation and downstream
reorganization. Meanwhile, quantity and type of input data can
dictate AI method selection. Data such as protein structures or
microscopy
images
often
describe
multi-dimensional
interactions
concentrated
within
localized
contexts,
and
architectures best suited to learn from these data are often
different from those that best learn from categorical or single
point measurements. Augmenting limited data with new datasets
or experiments can increase ML power and scope, though caution
is required as diverse sources may introduce unique biases and
noise. Alternatively, algorithms can work to mitigate deﬁciencies
in data, such as inferring missing values, or over/under-sampling
to improve balance in learning (Chawla, et al., 2002; Hessler and
Baringhaus,
2021;
Irwin,
et
al.,
2021).
Spending
time
understanding the data can be helpful in assessing when a
problem is ready to be tackled with AI or when investment is
needed in collecting data that would better inform the task at
hand. Failure to assess and address data can decrease the
accuracy,
conﬁdence,
reproducibility,
and
applicability
of
downstream
ML
applications
(United
States
Government
Accountability
Ofﬁce,
2019),
sometimes
propagating
even
beyond to patient outcomes (Seyyed-Kalantari, et al., 2021).
Regardless of the format of input data, featurization, or the
description of entities/samples based on measured or inherent
properties, must be carefully performed to best complement the
intended ML application. For example, small molecules can be
featurized in many ways (David, et al., 2020): using SMILES, text-
based descriptors of 2D structures; using atom coordinates
describing 3D conformation; using calculated or measured
physicochemical descriptors such as LogD and pKa; or even
using
methods
such
as
extended-connectivity
ﬁngerprints
(Rogers
and
Hahn,
2010)
that
iteratively
capture
atom
connectivities.
Choice
of
featurization
affects
result
interpretability
and
actionability—ML
to
inform
QSAR
decisions for medicinal chemists might favor physicochemical
descriptors that highlight relevant property changes for synthetic
modiﬁcations, while ML for high-throughput screeners might
beneﬁt from topological descriptors to learn diverse scaffold hits
within an experiment. Evaluating feature similarity is particularly
important for generative chemistry endeavors, where AI-
proposed molecules should be compared with training data to
evaluate novelty (Walters and Murcko, 2020; Wills, 2021).
One often under-addressed component of data quality is
metadata.
Because
biological
systems
are
complex,
drug
discovery
experiments
often
possess
conditional
features
whose
importance
is
realized
only
after
subsequent
measurements. Capturing information such as a cell line,
associated genetic engineering, and time of measurements can
enable
downstream
AI-based
detection
of
systematic
measurement biases, such as batch effects (Sprang et al.,
2022), and meta-analyses across experiments. Metadata can
also include interpretations of data—what were the hits in an
experiment and what criteria were employed in their selection?
This information is historically under-reported and difﬁcult to
assemble retrospectively. As a core enabler of ﬁndable, accessible,
interoperable, and reusable (FAIR) data tenets (Wilkinson, et al.,
2016),
metadata
should
also
include
source
information,
especially
when
integrating
external
data.
Because
drug
discovery data are diverse and acquired across disciplines and
sources, (meta) data are rarely uniform. But, extra investment in
data assembly and an infrastructure to enable data storage and
sharing is often worth it, as failure to capture both data and
metadata in the present may impair utility of data assets in future
AI applications.
Compute, comprising algorithms and infrastructure, is the
second requirement for AI. Compute facilitates both the
execution
of
AI
and
interpretation
of
AI
outputs.
Computational algorithms should be selected with careful
consideration of the data available and the problem at hand.
Metrics, such as accuracy and area under the receiver-operator
curve
(AUROC)
can
facilitate
quantitative
evaluation
of
algorithm performance and comparison of new methods to
Frontiers in Bioinformatics
frontiersin.org
03
Santa Maria et al.
10.3389/fbinf.2023.1121591

## Page 4 (Section: 4 Discussion—The future of AI in drug discovery)

the state of the art. Calculating these metrics requires deﬁnition
of ground truth, which is supported by upfront investment in
experimental design and inclusion of labeled control sample
inputs. Published benchmarking datasets and tasks, such as
GuacaMol (Brown, et al., 2019) and MoleculeNet (Wu, et al.,
2018) for small molecules, and TAPE (Rao, et al., 2019) for
protein structures, help standardize and contextualize these
assessments, but may not exist for specialized applications.
Some ML methods, especially deep learning, are data and
compute intensive, which may limit their implementability
within
organizations.
Nevertheless,
sharing
centralized
computational and data infrastructure across groups can help
reduce cost. Computing environments must also be secure to
protect proprietary data and sensitive patient data. Dedicated
support from IT experts and/or cloud platform CROs can better
ensure the timely and secure assembly of data, algorithm, and
computational infrastructure on demand; otherwise time spent
on this is time scientists spend away from solving the problems at
hand. This is a signiﬁcantly underreported and critical issue, as
poor support delays insight delivery, and can decouple ML with
expected time frames of decision making in drug discovery
projects.
As a ﬁnal key ingredient, organizational culture deﬁnes how
AI can be successfully deployed, informing its business use and
intended application. In most organizations, the generation of
required input data, execution of AI, and validation of its impact
can fall within separate groups. This requires machine learners to
establish functional relationships with these key stakeholders to
understand business needs and engineer AI solutions. Well-
maintained
relationships
ensure
continuous
vision
of
actionability and mitigate both the risks of misapplication of
AI and mis-/over-interpretation of data and results.
As data consumers, AI/data scientists are often the translators
that convert data generated by laboratory scientists into viable
inputs for machine learning models. In return, data scientists
must ensure models and their results are continuously accessible
and shared back with benchtop scientists. The two groups must
work together to establish standards and practices for data/model
capture and utilization, ensuring today’s work informs smarter
experiments
tomorrow.
AI-assisted
Design-Make-Test
and
iterative screening cycles are great illustrations of how regular
communication of data and ML results between groups or
functions can accelerate hit identiﬁcation and optimization (Pant,
et
al.,
2018).
Data
and
model
siloing,
especially
in
large
organizations,
impairs
this
communication
and
reduces
accessibility and utility.
ML models are only useful if their outputs are actionable—in
general, that they inform experiments or decision making
toward the business impacts of developing a drug. As an
example, for AI-generated compound hypotheses this can
mean ensuring molecules are synthetically feasible and thus
able
to
be
tested.
Business
understanding
also
informs
performance and time requirements for AI—a model must
have higher speciﬁcity for hit identiﬁcation if only a small
number of generated compounds can be tested versus a large
library. And, training a model for a week is infeasible if outputs
are needed on shorter timescales. A breakdown in business
understanding can lead to the problems of data scientists
building hammers with no nails, or for securing screws.
Establishing a data-aware and AI-supportive culture can
sometimes be a roadblock for AI utilization. This can manifest
as organizational inertia or politics when AI automation obviates
work that was previously performed with an established way of
working, or when employees are asked to allot already limited
time to new data initiatives. Hype and endorsements from
executive leadership can be helpful in motivating diverse
teams to support new AI endeavors, but can also lead to an
expectation-reward error, as incidences of overpromising and
under-delivering sever trust between computational and bench
scientists.
To summarize, without good data, compute, people, and
culture, including business utility, AI is not possible. Nor is AI
the panacea for the absence of one of these components.
Tapping into the true and sustainable impact of AI means
maintaining these dependencies while tackling challenges
that can arise.
4 Discussion—The future of AI in drug
discovery
The generation of new quantities and types of biomedical data,
together with continuous improvements in computation and lessons
learned from ML applications, have driven evolution of the pharma
AI landscape. There are key challenges ahead such as bringing ML to
new data types and domains and in integrating diverse data to better
inform current implementations. Some initial barriers to entry have
fallen: democratization of data and algorithms with databases and
code repositories have enabled sharing both within an organization
and externally with the larger community. Even consortia, such as
MELLODDY,
facilitate
federated
learning,
preserving
conﬁdentiality while pooling data across companies to improve
ML
models
(for
some;
Blackburn-Owkin,
2022).
Similarly,
improvement of hardware and a growth in CROs providing
infrastructure and workﬂow solutions make computation more
accessible than ever. Nevertheless, the training of revolutionary
transformer-based large language models like GPT-3 can cost
tens of thousands or even millions in US$, requiring both big
data and “big compute” (Sharir et al., 2020). Companies and
institutions with the means to generate data at a scale beyond
what is available to the public and those who can afford the
compute requirements to train and deploy models at scale, will
have a signiﬁcant advantage over others. Though many large models
are hosted openly for use, this also raises a reproducibility challenge
as only those with access to big data and big compute will be able to
validate them, compromising a key tenet of the scientiﬁc method.
The future of drug discovery will bring disruptive technologies
and data that are unimaginable to us today. While it is possible that
future AI will deliver a new generation of medicines, the belief that it
will do so independently belies the complexity of the drug discovery
process and undervalues the many scientiﬁc teams that contribute
required inputs. Employing frameworks of cultural and data
preparedness can ready us to tap into the data we have today
with sustainable, thoughtful application of AI, and improve our
Frontiers in Bioinformatics
frontiersin.org
04
Santa Maria et al.
10.3389/fbinf.2023.1121591

## Page 5 (Section: Author contributions)

probability of success in impacting human health through
therapeutics.
Author contributions
All authors listed have made a substantial, direct, and intellectual
contribution to the work and approved it for publication.
Acknowledgments
The authors would like to thank friends and family for help in editing
the manuscript, especially Mark Kalinich and Massimo de Francesco.
Conﬂict of interest
JS, YW were employed by UCB Biosciences Inc. LC was
employed by 17-09, LLC.
Publisher’s note
All claims expressed in this article are solely those of the authors
and
do
not
necessarily
represent
those
of
their
afﬁliated
organizations, or those of the publisher, the editors and the
reviewers. Any product that may be evaluated in this article, or
claim that may be made by its manufacturer, is not guaranteed or
endorsed by the publisher.
References
Bachas, S., Rakocevic, G., Spencer, D., Sastry, A. V., Haile, R., and Sutton, J. M. (2022).
Antibody optimization enabled by artiﬁcial intelligence predictions of binding afﬁnity and
naturalness. bioRxiv 2022, 504181. doi:10.1101/2022.08.16.504181
Bender, A., and Cortés-Ciriano, I. (2021). Artiﬁcial intelligence in drug discovery:
What is realistic, what are illusions? Part 1: Ways to make an impact, and why we are not
there yet. Drug Disc Today 26 (2), 511–524. doi:10.1016/j.drudis.2020.12.009
Biswas, N., and Chakrabarti, S. (2020). Artiﬁcial intelligence (AI)-based systems
biology approaches in multi-omics data analysis of cancer. Front. Oncol. 10, 588221.
doi:10.3389/fonc.2020.588221
Blackburn-Owkin, A. (2022). Melloddy ﬁnal results. Available at: https://www.
melloddy.eu/y3announcement (Accessed October 17, 2022).
Brown, N., Fiscato, M., Segler, M. H. S., and Vaucher, A. C. (2019). GuacaMol:
Benchmarking models for de novo molecular design. J. Chem. Inf. Model. 59 (3),
1096–1108. doi:10.1021/acs.jcim.8b00839
Chawla, N. V., Bowyer, K. W., Hall, L. O., and Kegelmeyer, W. P. (2002). Smote: Synthetic
minority over-sampling technique. J. Art. Intell. Res. 16, 321–357. doi:10.1613/jair.953
David, L., Thakkar, A., Mercado, R., and Engkvist, O. (2020). Molecular
representations
in
AI-driven
drug
discovery:
A
review
and
practical
guide.
J. Cheminform. 12, 56. doi:10.1186/s13321-020-00460-5
Gershell, L. J., and Atkins, J. H. (2003). A brief history of novel drug discovery
technologies. Nat. Rev. Drug Disc. 2, 321–327. doi:10.1038/nrd1064
Gupta, R., Srivastava, D., Sahu, M., Tiwari, S., Ambasta, R. K., and Kumar, P. (2021).
Artiﬁcial intelligence to deep learning: Machine intelligence approach for drug
discovery. Mol. Divers 2021, 1315–1360. doi:10.1007/s11030-021-10217-3
Hessler, G., and Baringhaus, K. H. (2021). Artiﬁcial intelligence in drug design.
Molecules 23, 2520. doi:10.3390/molecules23102520
Irwin, B. W. J., Whitehead, T. M., Rowland, S., Mahmoud, S. Y., Conduit, G. J., and
Segall, M. D. (2021). Deep imputation on large scale drug discovery data. Appl. AI Lett.
2, e31. doi:10.1002/ail2.31
Jaganathan, K., Panagiotopoulou, S. K., McRae, J. F., Darbandi, S. F., Knowles, D., Li,
Y. I., et al. (2019). Predicting splicing from primary sequence with deep learning. Cell
176 (3), 535–548.e24. doi:10.1016/j.cell.2018.12.015
Jumper, J., Evans, R., Pritzel, A., Green, T., Figurnov, M., Ronneberger, O., et al.
(2021). Highly accurate protein structure prediction with AlphaFold. Nature 596,
583–589. doi:10.1038/s41586-021-03819-2
Kumar, M., Nguyen, T. P. N., Kaur, J., Singh, T. G., Soni, D., Singh, R., et al. (2023).
Opportunities and challenges in application of artiﬁcial intelligence in pharmacology.
Pharmacol. Rep. 75, 3–18. doi:10.1007/s43440-022-00445-1
Lin, Z., Akin, H., Rao, R., Hie, B., Zhu, Z., Lu, W., et al. (2022). Language models of
protein sequences at the scale of evolution enable accurate structure prediction. bioRxiv
2022, 500902. doi:10.1101/2022.07.20.500902
Lounkine, E., Keiser, M. J., Whitebread, S., Mikhailov, D., Hamon, J., Jenkins, J. L.,
et al. (2012). Large-scale prediction and testing of drug activity on side-effect targets.
Nature 486 (7403), 361–367. doi:10.1038/nature11159
O’Leary, L. (2022). How IBM’s Watson went from the future of health care to sold
off for parts. Available at: https://slate.com/technology/2022/01/ibm-watson-health-
failure-artiﬁcial-intelligence.html (Accessed October 11, 2022).
Pant, S. M., Mukonoweshuro, A., Desai, B., Ramjee, M. K., Selway, C. N., Tarver, G. J.,
et al. (2018). Design, synthesis, and testing of potent, selective hepsin inhibitors via
application of an automated closed-loop optimization platform. J. Med. Chem. 61 (10),
4335–4347. doi:10.1021/acs.jmedchem.7b01698
Paul, D., Sanap, G., Shenoy, S., Kalyane, D., Kalia, K., and Tekade, R. K. (2021).
Artiﬁcial intelligence in drug discovery and development. Drug Discov. Today 26, 80–93.
doi:10.1016/j.drudis.2020.10.010
Pina, A. S., Hussain, A., and Roque, A. C. A. (2009). An historical overview of
drug
discovery
ligand-macromolecular
interactions
in
drug
discovery:
Methods and protocols. Methods Mol. Biol. 572, 3–12. doi:10.1007/978-1-
60761-244-5_1
Raleigh, N. (2022). The future of AI drug discovery and development in immunology and
GPCR research. Available at : https://pharmaphorum.com/digital/the-future-of-ai-drug-
discovery-development-in-immunology-and-gpcr-research/(Accessed October 11, 2022).
Rao, R., Bhattacharya, N., Thomas, N., Duan, Y., Chen, X., Canny, J., et al. (2019).
Evaluating protein transfer learning with TAPE. Adv. Neural Inf. Process Syst. 32,
9689–9701.
Renaud, N., and Wang, Y. (2021). Artiﬁcial intelligence as an enabler for phenotypic
drug discovery. Phenotypic Drug Discov. 77, 104–117. doi:10.1039/9781839160721-
00104
Rogers, D., and Hahn, M. (2010). Extended-connectivity ﬁngerprints. J. Chem. Inf.
Model 50 (5), 742–754. doi:10.1021/ci100050t
Scannell, J., and Bosley, J. (2016). When quality beats quantity: Decision theory, drug
discovery, and the reproducibility crisis. PLoS ONE 11 (2), e0147215. doi:10.1371/
journal.pone.0147215
Scannell, J. W., Blanckley, A., Boldon, H., and Warrington, B. (2012). Diagnosing the
decline in pharmaceutical R&D efﬁciency. Nat. Rev. Drug Disc. 11, 191–200. doi:10.
1038/nrd3681
Seyyed-Kalantari, L., Zhang, H., McDermott, M. B. A., Chen, I. Y., and Ghassemi, M.
(2021). Underdiagnosis bias of artiﬁcial intelligence algorithms applied to chest
radiographs in under-served patient populations. Nat. Med. 27, 2176–2182. doi:10.
1038/s41591-021-01595-0
Sharir, O., Peleg, B., and Shoham, Y. (2020). The cost of training NLP models: a
concise overview. arXiv [Preprint]. Available at: https://arxiv.org/abs/2004.08900
(Accessed February 5, 2023).
Sprang, M., Andrade-Navarro, M. A., and Fontain, J-F. (2022). Batch effect detection
and correction in RNA-seq data using machine-learning-based automated assessment
of quality. BMC Bioinform 23, 279. doi:10.1186/s12859-022-04775-y
United States Government Accountability Ofﬁce (2019). Artiﬁcial intelligence in
health care: Beneﬁts and challenges of machine learning in drug development.
Washington, DC: United States Government Accountability Ofﬁce.
Vamathevan, J., Clark, D., Czodrowski, P., Dunham, I., Ferran, E., Lee, G., et al.
(2019). Applications of machine learning in drug discovery and development. Nat. Rev.
Drug Disc 18, 463–477. doi:10.1038/s41573-019-0024-5
Walters, W. P., and Murcko, M. (2020). Assessing the impact of generative AI on
medicinal chemistry. Nat. Biotechnol. 38, 143–145. doi:10.1038/s41587-020-0418-2
Wilkinson, M. D., Dumontier, M., Aalbersberg, I. J., Appleton, G., Axton, M., Baak,
A., et al. (2016). The FAIR Guiding Principles for scientiﬁc data management and
stewardship. Sci. Data 3, 160018. doi:10.1038/sdata.2016.18
Wills, T. (2021). Assessing structural novelty of the ﬁrst AI-designed drug candidates
to go into human clinical trials. Available at: https://www.cas.org/resources/blog/ai-
drug-candidates (Accessed October 11, 2022).
Wu, Z., Ramsundar, B., Feinberg, E. N., Gomes, J., Geniesse, C., Pappu, A. S., et al.
(2018). MoleculeNet: A benchmark for molecular machine learning. Chem. Sci. 9,
513–530. doi:10.1039/c7sc02664a
Frontiers in Bioinformatics
frontiersin.org
05
Santa Maria et al.
10.3389/fbinf.2023.1121591


---

# Privacy-preserving techniques for decentralized and secure machine learning in drug discovery

- **Authors:** Aljoša Smajić, Melanie Grandits, Gerhard F Ecker
- **Issuer:** Drug discovery today
- **Type:** Scientific article
- **Published:** 2023-11-05
- **Language:** en
- **DOI:** 10.1016/j.drudis.2023.103820
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37935330/
- **Licence:** CC-BY

## Section: Abstract

Data availability, data security, and privacy concerns often hamper optimal performance efficiency of machine learning (ML) techniques. Therefore, novel techniques for the utilization of private/sensitive data in the field of drug discovery have been proposed for ML model-building tasks. Some examples of the different techniques are secure multiparty computation, distributed deep learning, homomorphic encryption, blockchain-based peer-to-peer networking, differential privacy, and federated learning, as well as combinations of such techniques. In this paper, we present an overview of these techniques for decentralized ML to illustrate its benefits and drawbacks in the field of drug discovery.


---

# Real-world evidence for regulatory decision-making: updated guidance from around the world

- **Authors:** Leah Burns, Nadege Le Roux, Robert Kalesnik-Orszulak, Jennifer Christian, Jennifer Dudinak, Frank Rockhold, Sean Khozin, John O'Donnell
- **Issuer:** Frontiers in medicine
- **Type:** Scientific article
- **Published:** 2023-10-30
- **Language:** en
- **DOI:** 10.3389/fmed.2023.1236462
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38020096/
- **Licence:** CC-BY

## Page 1 (Section: Real-world evidence for regulatory decision-making: updated guidance from around the world)

Frontiers in Medicine
01
frontiersin.org
Real-world evidence for 
regulatory decision-making: 
updated guidance from around 
the world
Leah Burns 1*, Nadege Le Roux 2, Robert Kalesnik-Orszulak 3, 
Jennifer Christian 4, Jennifer Dudinak 5, Frank Rockhold 6, 
Sean Khozin 7 and John O’Donnell 1
1 Worldwide Health Economics and Outcomes Research, Bristol Myers Squibb, Princeton, NJ, United 
States, 2 Regulatory Intelligence, Bristol Myers Squibb, Boudry, Switzerland, 3 Global Regulatory Sciences, 
Bristol Myers Squibb, Princeton, NJ, United States, 4 Target RWE, Durham, NC, United States, 5 Global 
Regulatory Sciences, Bristol Myers Squibb, Summit, NJ, United States, 6 Department of Biostatistics and 
Bioinformatics, Duke Clinical Research Institute, Durham, NC, United States, 7 Massachusetts Institute of 
Technology, Cambridge, MA, United States
Leveraging the value of real-world evidence (RWE) to make informed regulatory 
decisions in the field of health care continues to gain momentum. Improving clinical 
evidence generation by evaluating the outcomes and patient experiences at the 
point-of-care would help achieve the ultimate aim of ensuring that effective and 
safe treatments are rapidly approved for patient use. In our previous publication, 
we assessed the global regulatory landscape with respect to RWE and provided a 
review of the regional availability of frameworks and guidance through May 2021 
on the basis of 3 key regulatory elements: regulatory RWE frameworks, data quality 
guidance, and study methods guidance. In the current review, we have updated 
and elaborated upon recent developments in the regulatory RWE environment 
from a regional perspective under the same 3 regulatory elements stated above. 
In addition, we have also included a new category on procedural guidance. The 
review also discusses the perceived gaps and potential opportunities for future 
development and harmonization in this field to support framework establishment 
in regions without pre-existing RWE policies. Additionally, the article reviews 
current developments of health technology assessment (HTA) bodies pertaining 
to RWE and discusses the status of evidentiary alignment among regulators and 
HTA agencies.
KEYWORDS
real-world evidence, real-world data, regulatory decision-making, real-world evidence 
regulatory frameworks, real-world data quality methods, real-world study methods, 
health technology assessment
Introduction
Real-world evidence (RWE) continues to receive global attention with growing use in 
supporting regulatory decision-making for drugs and biologics. Accordingly, regulatory bodies 
across the globe have continued to release several guidance documents on RWE. Still, the use 
of RWE in regulatory decision-making for effectiveness remains an emerging area, where in 
addition to guidance, there continues to be a role for the experience from precedents and pilots 
in informing best practices.
OPEN ACCESS
EDITED BY
Christine Gispen-de Wied, 
Gispen4RegulatoryScience, Netherlands
REVIEWED BY
Padmaja Mummaneni, 
United States Food and Drug Administration, 
United States 
Segundo Mariz, 
European Medicines Agency, Netherlands
*CORRESPONDENCE
Leah Burns 
 leah.burns@bms.com
RECEIVED 07 June 2023
ACCEPTED 26 September 2023
PUBLISHED 30 October 2023
CITATION
Burns L, Le Roux N, Kalesnik-Orszulak R, 
Christian J, Dudinak J, Rockhold F, 
Khozin S and O’Donnell J (2023) Real-world 
evidence for regulatory decision-making: 
updated guidance from around the world.
Front. Med. 10:1236462.
doi: 10.3389/fmed.2023.1236462
COPYRIGHT
© 2023 Burns, Le Roux, Kalesnik-Orszulak, 
Christian, Dudinak, Rockhold, Khozin and 
O’Donnell. This is an open-access article 
distributed under the terms of the Creative 
Commons Attribution License (CC BY). The 
use, distribution or reproduction in other 
forums is permitted, provided the original 
author(s) and the copyright owner(s) are 
credited and that the original publication in this 
journal is cited, in accordance with accepted 
academic practice. No use, distribution or 
reproduction is permitted which does not 
comply with these terms.
TYPE  Policy and Practice Reviews
PUBLISHED  30 October 2023
DOI  10.3389/fmed.2023.1236462

## Page 2 (Section: Methods)

Burns et al.
10.3389/fmed.2023.1236462
Frontiers in Medicine
02
frontiersin.org
In our previous publication, we  described and compared 
regulatory RWE frameworks and guidance documents for drugs and 
biologics from different countries around the world, available through 
May 2021, highlighting key areas for convergence, as well as gaps in 
the evidence generation process (1). We  recommended further 
harmonization of guidance across geographies, including the 
encouragement of continued cross-country and cross-stakeholder 
collaboration, and standardizing the regulatory submission process 
for RWE, including the development of real-world data (RWD) 
standards (1). Additionally, we also recommended the development 
of further guidance on RWE trial design (e.g., randomized controlled 
registry studies, pragmatic trials, and hybrid studies) (1).
Since then, many regulatory authorities have moved beyond 
general frameworks to release several RWE guidance documents. This 
review discusses new regulatory guidance documents published from 
June 1, 2021 to January 31, 2023. These have been systematically 
organized and described under 3 main categories: regulatory RWE 
frameworks, RWD quality guidance, and real-world study methods 
guidance (1). Further, we  have also included a fourth ancillary 
category on procedural guidance, considering the content of some 
recently released guidance pertaining to submission of RWE 
documents and related processes. Additionally, this review discusses 
the harmonization efforts and challenges facing regulators and health 
technology assessment (HTA) bodies on the alignment of the use of 
RWE for decision-making.
Methods
We performed a targeted literature search of all relevant articles 
from June 1, 2021 to January 31, 2023 related to regulatory RWE 
frameworks and policies, RWD data quality methods, and real-world 
study methods. An initial search was performed on all International 
Coalition of Medicines Regulatory Authorities (ICMRA) member 
sites for relevant guidance and reports based on the search parameters 
(2). Additional literature searches were conducted on databases 
(PubMed, Google) using specific keywords (real-world evidence; real-
world data; regulatory guidance; regulatory guidance and RWE) to 
check for relevant academic publications, white papers, and/or news 
reports. Subsequently, cited references from the previous publication 
were reviewed and checked for updates within the current period of 
study to ensure that all relevant publications were captured. The 
selected articles were organized for qualitative synthesis under the 
following subheadings: the 3 key regulatory elements namely, 
regulatory RWE frameworks, RWD quality guidance, and real-world 
study methods guidance; and a fourth category on procedural 
guidance. An additional search on relevant HTA guidance related to 
RWE released in the current search period was also performed. The 
detailed methodology has been presented in Table 1.
Global RWE regulatory environment
In our previous publication (1), we  proposed that countries 
leveraging RWE for making regulatory decisions for drugs and 
biologics were trending toward a stepwise approach for developing the 
following 3 key regulatory elements: (a) regulatory RWE frameworks, 
(b) RWD quality guidance, and (c) real-world study methods guidance 
(Figure  1). With the recent RWE guidance documents released 
through January 2023, we have continued to observe this trend. Many 
major regulatory authorities have now shifted from the previously 
released initial frameworks or position papers to issuing fully detailed 
practical guidance documents on RWE in regulatory decision-
making. Most of these guidance documents discuss data quality and 
standards (Figure 2). Regulatory authorities have also begun to release 
guidance on study methodology for different real-world study designs 
(Figure 2). In addition, there are a few guidance documents focused 
on the procedural aspects of engaging with regulatory agencies to 
discuss RWE and submit documents containing RWD/E (Figures 1, 2). 
Overall, the extent to which the above stepwise criteria have 
progressed (i.e., some countries may adopt existing frameworks 
instead of developing their own) indicates how advanced the RWE 
environment is as well as the feasibility of using such evidence for 
regulatory decisions in a specific location.
Updates on regulatory RWE frameworks 
across the globe
Regulatory RWE frameworks in a given region can help provide 
an important grounding on the accepted RWE use during the life cycle 
of a product, including any pre-marketing activities and post-
marketing labeling changes for safety and effectiveness. They may also 
provide clarification on the plans of regulatory agencies regarding the 
future release and adoption of more detailed guidance. In the last 
TABLE 1  Methodology.
RWE and regulatory decision-making
(Updates from June** 2021 to January 2023)
Literature search
Screening parameters:
	1.	 Relevant articles from June 1, 2021 to January 31, 2023
	2.	 Topic of article: Regulatory frameworks and policies, 
data quality methods, study methods, and procedural 
guidance
Step 1
Initial search performed on all ICMRA member sites for 
relevant guidance and reports based on the screening 
parameters (2)
Step 2
Additional literature searches were conducted (PubMed, 
Google) using specific keywords (real-world evidence; 
real-world data; regulatory guidance; regulatory guidance 
and RWE) to check for relevant academic publications, 
white papers, and news reports
Step 3
Reviewed cited references from previous publication and 
checked them for updates within current time period to 
ensure that all relevant publications were captured
Selected articles for qualitative synthesis under:
	(a).	 Regulatory frameworks and policies (n = 32)*
	(b).	 Data quality methods (n = 20)*
	(c).	 Study design methods (n = 10)*
	(d).	 Procedural guidance (n = 5)
*Indicates that the articles are not exclusive and can fall under more than 1 subheading. 
**Please note that the publication date of 1 article (3) included in the current manuscript 
precedes the search period. Additionally, 5 HTA documents (guidance/frameworks/
initiatives) related to RWE were also identified in the literature search.

## Page 3 (Section: North America)

Burns et al.
10.3389/fmed.2023.1236462
Frontiers in Medicine
03
frontiersin.org
review, up to May 2021, most of the major regulatory agencies 
including the United States Food and Drug Administration (US FDA), 
European Medicines Agency (EMA), Health Canada, Medicines and 
Healthcare products Regulatory agency [MHRA, United Kingdom 
(UK)], Pharmaceuticals and Medical Devices Agency (PMDA, Japan), 
National Medical Products Administration (NMPA, China), and 
Taiwan Food and Drug Administration (TFDA) had released 
frameworks on RWE (1).
Since then, many additional regulatory agencies have also released 
initial frameworks/positions, including Swissmedic (Switzerland), 
Ministry of Food and Drug Safety (MFDS, South Korea), and 
Therapeutic Goods Administration (TGA, Australia). Table  2 
summarizes the regulatory RWE frameworks available across the 
globe, grouped by North America, Europe, and Asia-Pacific regions.
North America
In the US, passing of the Prescription Drug User Fee Act 
(PDUFA) VII (5) has added further clarity regarding RWE use in 
FIGURE 1
Key regulatory real-world evidence (RWE) elements. RWD, Real-world data.
FIGURE 2
Trends in regulatory real-world evidence (RWE) guidance documents released across the world. EU, European Union; FDA, Food and Drug 
Administration; HC, Health Canada; FW, Framework; DQ, Real-world data quality guidance; MHRA, Medicines and Healthcare products Regulatory 
Agency; MFDS, Ministry of Food and Drug Safety; NMPA, National Medical Products Administration; PG, Procedural Guidance; PMDA, Pharmaceuticals 
and Medical Devices Agency; SM, Real-world study methods guidance; TFDA, Taiwan Food and Drug Administration; TGA, Therapeutic Goods 
Administration.

## Page 4 (Section: Europe)

Burns et al.
10.3389/fmed.2023.1236462
Frontiers in Medicine
04
frontiersin.org
regulatory decision-making into the legislation, including the 
launch of FDA’s Advancing Real-World Evidence (RWE) Program 
(26, 27), a pilot program seeking improvement in the quality and 
acceptability of RWE-based approaches to support new intended 
labeling claims or satisfy post-approval study requirements. In 
addition, the FDA clarified the applicability of Investigational 
New Drug regulations to non-interventional real-world studies in 
its draft guidance on considerations for the use of RWD and RWE 
to support regulatory decision-making released in December 
2021 (7).
Europe
The European Union (EU) has seen further advancement of 
legislation relevant to RWE use in drugs and biologics. Notably, the 
European Commission (EC) presented a legislative proposal in May 
2022 for the establishment of a European Health Data Space (EHDS) 
to harness the maximum potential of digitalized health data (28). The 
EHDS would be a health-based ecosystem where rules, standards, 
practices, and infrastructures can be  brought under a common 
governance framework via the establishment of a secure centralized 
TABLE 2  Regulatory RWE frameworks and policies in North America, Europe, and Asia-Pacific.
Regulatory body
Framework or policy
Legislation
RWE frameworks
North America
US Food and Drug Administration (FDA)
21st Century Cures Act (2016) (4)
PDUFA VII (2022) (5)
FDA RWE Framework (2018) (6)
Draft guidance: Considerations for the use of real-world 
data and real-world evidence to support regulatory 
decision-making for drug and biological products (2021) 
(7) (New)
Health Canada (HC)
NA
Optimizing the use of RWE to inform regulatory decision-
making (2019) (8)
Europe
European Medicines Agency (EMA) /European 
Commission (EC)
Pharmaceutical Strategy for Europe (Ongoing) (9)
Data Act (2022) (10)
Regulatory science to 2025 (2020) (11)
European medicines agencies network strategy to 2025 
(2020) (12)
HMA/EMA Big data task force recommendations and big 
data steering group (2020) (13, 14)
Medicines and Healthcare products Regulatory 
Agency (MHRA), United Kingdom (UK)
NA
MHRA guidance on the use of real-world data in clinical 
studies to support regulatory decisions (2021) (15) (New)
MHRA guideline on randomized controlled trials using 
real-world data to support regulatory decisions (2021) 
(16) (New)
Swissmedic, Switzerland
NA
Swissmedic position paper on the use of real-world 
evidence (2022) (17) (New)
Asia-Pacific
National Medical Products Administration (NMPA, 
China)
NA
Guidelines for Real-World Evidence to Support Drug 
Development and Review (Interim) (2020) (18)
Technical Guidelines for Real-World Research Supporting 
the R&D and Review of Pediatric Drugs (Trial) (2020) (19)
Guiding principles of real-world data used to generate 
real-world evidence (Trial) (2021) (20)
Taiwan Food and Drug Administration (TFDA)
NA
Basic considerations for real-world evidence supporting 
drug research and development (2020) (21)
Pharmaceuticals and Medical Devices Agency 
(PMDA, Japan)
NA
Basic principles on utilization of registry for applications 
(2021) (22)
Points to consider for ensuring the reliability in utilization 
of registry data for applications (2021) (23)
Ministry of Food and Drug Safety (MFDS, South 
Korea)
NA
Medical information database studies guideline (2021) 
(24) (New)
Therapeutic Goods Administration (TGA, Australia)
NA
Real-world evidence and patient-reported outcomes in 
the regulatory context (2021) (25) (New)
RWE, Real-world evidence; NA, Not applicable. Bold font denotes new guidance updates from June 2021 to January 2023.

## Page 5 (Section: Asia-Pacific)

Burns et al.
10.3389/fmed.2023.1236462
Frontiers in Medicine
05
frontiersin.org
data system. It aims to streamline the processes of primary use of data, 
i.e., increased digital access of electronic health record systems to 
patients, and to facilitate secondary data use among researchers, 
policymakers, and regulators. In July 2022, the EC chose a consortium 
led by the French Health Data Hub to launch a pilot project for the 
EHDS (29). The pilot aims to address the obstacles in accessing health 
data across Europe, such as data fragmentation, and to set up a 
concrete foundation for the EHDS over the next 2 years. The 
practicality of data reuse from different European countries is being 
tested via use cases spanning a multitude of research themes including 
infectious disease surveillance and disease care pathways (30).
The EHDS further builds on the Data Act that was adopted by the 
EC on February 23, 2022 (10). It is a regulation for harmonized rules 
on fair data access and use and constitutes a key pillar of the European 
data strategy. The Heads of Medicines Agencies (HMA)/EMA Big 
Data Steering Group (BDSG) also announced the launch of the Data 
Analysis and Real World Interrogation Network (DARWIN) EU 
platform (13, 31, 32), which is expected to act as a pathfinder to 
coordinate with the EHDS in order to enable EMA and national 
competent authorities to use RWD from the DARWIN EU network 
for regulation of medicinal products throughout their lifecycle. 
DARWIN EU constitutes a single, centralized data, expertise, and 
services network for improved decision-making via timely and reliable 
evidence generation from real-world healthcare databases across the 
EU (33). In January 2023, the EMA selected the first set of data 
partners, from different countries across the EU, to collaborate with 
the DARWIN EU platform (34). In addition, the EU Pharmaceutical 
Strategy (9),1 which included a plan to update the legislation for 
incorporating new approaches of evidence generation and assessment, 
such as the analysis of big data and RWD for supporting new medicine 
authorization, is continuing efforts to streamline processes. Several 
workshops and stakeholder engagement initiatives also continue to 
be organized to drive forward the other recommendations of the 
HMA/EMA joint Big Data Task Force (35–38). Acting on the focus 
areas set forth by the Network Strategy to 2025 and BDSG workplan 
2021–2023, the BDSG has continued to make significant progress in 
the transformation to a data-driven regulatory ecosystem throughout 
2021 and 2022 (12, 39–41). The HMA-EMA BDSG published its 
updated workplan (3rd in the series) in July 2022 that outlines key 
deliverable actions in relation to the 10 recommendations, including 
DARWIN EU, data quality, data discoverability, and EU network skills 
for 2022–2025, so as to further the effective integration of data analysis 
into medicinal product evaluation by regulators (42). These will 
be discussed in the subsequent sections.
Further, at the committee level, the Committee for Medicinal 
Products for Human Use (CHMP), the Committee for Advanced 
Therapies (CAT), the Pharmacovigilance Risk Assessment Committee 
(PRAC), the Pediatric Committee (PDCO), the Committee for 
Orphan Medicinal Products (COMP), and the Scientific Advice 
Working Party with the Biostatistics Working Party and others, play a 
key role in contributing to the EU regulatory guidelines and running 
their own pilots on the use of RWE to inform the guidelines and where 
RWE may be  most appropriate in their decision making. This is 
1  https://health.ec.europa.eu/system/files/2021-02/pharma-strategy_report_
en_0.pdf
particularly important considering their role in scientific advice, 
designation, and review assessment including marketing authorization.
In the United Kingdom, the MHRA released the final guidance on 
the use of RWD in clinical studies to support regulatory decisions, 
which introduces the MHRA’s overall RWD guideline series and 
covers general principles for the use of RWE in the United Kingdom 
(15, 16).
In Switzerland, Swissmedic released a position paper on the use 
of RWE, which clarified that although the agency accepts the use of 
RWE as supportive evidence to complement clinical trial data, new 
marketing applications based on RWE only are currently not accepted 
(17). As per legislation, the market authorization documentation for 
applications to Swissmedic must include the results of Good Clinical 
Practices (GCP)-compliant clinical trials (17).
Asia-Pacific
In South Korea, the MFDS released an RWE guideline on medical 
information database studies (24). Additionally, the MFDS and the 
Korean Academy of Medical Sciences jointly held the 3rd Regulatory 
Science Innovation Forum, “Utilizing Big Data for Regulatory Science 
Decision-Making,” where the MFDS committed to innovation in drug 
data in 2022 to meet industry needs, including the re-assessment of 
the use of real data (43, 44).
The TGA in Australia published a report reviewing RWE use and 
patient-reported outcomes, which was based on a consultation 
conducted by the agency (25). This has prompted the TGA to plan 
implementation of a number of activities, including establishment of 
a central point for information regarding RWE on the TGA website 
and communicating when RWE is used for making regulatory 
decisions (25). The TGA has also adopted FDA’s definition of 
RWE (45).
South America
In South America, although no formal RWE frameworks have 
been released, Anvisa, the Brazilian Health Regulatory Agency, allows 
the use of RWD/E in regulatory submissions. According to a survey 
of industrial stakeholders, the use of RWD/E by the pharmaceutical 
industry in Brazil has evolved, with a majority (76% of respondents) 
using RWE for supporting drug access and 56% (of respondents) 
using RWE for regulatory submissions to Anvisa (46). The growing 
use of RWE in regulatory decision-making across the globe was also 
discussed in a multi-part workshop in 2021 as part of the knowledge 
expansion (ECHO) program conducted by Anvisa and Interfarma 
(47). Further, the new regulatory framework approved by Anvisa in 
2022 favors the registration of new and innovative drugs aligned with 
the international scenario, via input of technical data including 
RWD/E (48).
Third-party initiatives
As a third-party initiative (Supplementary Table S1), the Duke-
Margolis Center for Health Policy RWE Collaborative actively engages 
stakeholders to enhance RWE development and use with the following

## Page 6 (Section: Updates on RWD quality guidance)

Burns et al.
10.3389/fmed.2023.1236462
Frontiers in Medicine
06
frontiersin.org
2022 priorities: (a) regulatory acceptability of RWD/E, (b) learning 
health care systems: RWD for evidence-based decision-making and 
shared learning, (c) master RWE protocols, and (d) real-world efficacy: 
patient subgroups (49). The European Health Data and Evidence 
Network (EHDEN) Academy, launched as part of the Innovative 
Medicines Initiative’s (IMI’s) EHDEN project in April 2020, has been a 
resource that provides tools, skills, and methods training for researchers 
conducting real-world studies (50). In October 2022, EHDEN joined a 
European stakeholders’ consensus encouraging decision-makers to 
support the EHDS regulation and also proposed a set of 
recommendations for successfully achieving digital transformation 
across Europe (51). The GetReal Institute conducted its inaugural annual 
conference in March 2023 to keep the RWE community informed of 
global developments and the future direction of RWE (52, 53), providing 
a platform to highlight ongoing initiatives and emerging challenges as 
well as an opportunity for collaboration to address these challenges.
Updates on RWD quality guidance
Once a country establishes a general RWE framework, developing 
guidance on the components of high-quality RWD and the key criteria 
for assessment of RWD quality is an important subsequent step to 
clarify regulatory standards and ensure that data are fit-for-use. In our 
last publication, the NMPA and PMDA had released dedicated 
guidance documents on data quality while regulatory agencies such 
as FDA, EMA, and TFDA had released guidance that included data 
quality among other topics (1).
Since then, additional regulatory agencies have released their 
own guidance documents dedicated to RWD quality, including the 
FDA and EMA. Multi-topic guidance which also touch upon data 
quality have also been released by EMA and the MHRA. Table 3 
summarizes the regulatory RWD quality guidance available across 
the globe.
TABLE 3  Regulatory guidance on real-world data (RWD) quality in Asia-Pacific, North America, and Europe.
Regulatory body
Guidance documents
North America
U.S. Food and Drug Administration
Best practices for conducting and reporting pharmacoepidemiologic safety studies using electronic 
healthcare data (2013) (54)
Use of electronic health record data in clinical investigations (2018) (55)
FDA RWE framework (2018) (6)
Draft guidance: Assessing electronic health records and medical claims data to support regulatory 
decision-making for drug and biological products (2021) (56) (New)
Draft guidance: Data standards for drug and biological product submissions containing real-world 
data (2021) (57) (New)
Draft guidance: Assessing registries to support regulatory decision-making for drug and biological 
products guidance for industry (2021) (58) (New)
Health Canada (HC)
Elements of real-world data/evidence quality throughout the prescription drug product life cycle (2019) 
(59)
Europe
European Medicines Agency (EMA, European Union)
Guideline on registry-based studies (2021) (60) (New)
Draft guidance: Good practice guide for the use of the metadata catalog of RWD Sources (2022) (61) 
(New)
Draft guidance: Data quality framework for EU medicines regulation (2022) (62) (New)
Medicines and Healthcare products Regulatory Agency 
(MHRA, United Kingdom)
MHRA guidance on the use of real-world data in clinical studies to support regulatory decisions 
(2021) (15) (New)
List of metadata for Real World Data catalogs (2022) (New)
Asia-Pacific
National Medical Products Administration (NMPA, China)
Guidelines for Real-World Evidence to Support Drug Development and Review (Interim) (Interim) (2020) 
(18)
Guiding principles of real-world data used to generate real-world evidence (trial) (2021) (20)
Taiwan Food and Drug Administration
Basic considerations for real-world evidence supporting drug research and development (2020) (21)
Pharmaceuticals and Medical Devices Agency (PMDA, Japan)
Guidelines for conducting pharmacoepidemiological studies in drug safety evaluation using medical 
information databases (2014) (63)
Basic policy on the use of medical information databases in post-marketing pharmacovigilance (2017) 
(64)
Points to consider for ensuring the reliability in utilization of registry data for applications (2021) (23)
Ministry of Food and Drug Safety (MFDS, Korea)
Medical information database studies guideline (2021) (24) (New)
Bold font denotes new guidance updates from June 2021 to January 2023.

## Page 7 (Section: North America)

Burns et al.
10.3389/fmed.2023.1236462
Frontiers in Medicine
07
frontiersin.org
North America
In the United States, the FDA released several draft guidance 
documents (7, 56–58) focusing specifically on data quality and data 
standards, including guidance on the use of electronic health records 
(EHRs)/claims data (56), use of registry data (58), and data standards 
for real-world datasets (57). Overall, the draft guidance documents, 
particularly 
the 
EHR/claims 
guidance, 
discuss 
detailed 
recommendations for data source selection, study variable definitions 
and validation, quality control/assurance processes, documentation, 
and data source information that should be included in the protocol 
and statistical analysis plan. These guidance documents reflect an 
effort by the agency to increase the rigor and amount of information 
received on the data source in industry RWE proposals. All these 
guidance documents are draft versions (or updated draft versions) that 
have received abundant public interest and feedback; the final versions 
following consideration of the feedback are expected later in 2023 
(within 18 months of the closing period of prior comment, as stated 
in the 21st Century Cures Act).
In Canada, the draft guidance from CADTH published in 
November 2022 provides best practices for attaining the maximum 
level of transparency in reporting relevant and useful RWE during 
submissions to Canadian regulatory and HTA bodies (65). The draft 
was developed with support from Canadian and international RWE 
experts [Health Canada, FDA, and National Institute for Health and 
Care Excellence (NICE)], and includes a checklist of items that should 
be reported during submissions on aspects related to RWD quality 
and characterization (65).
Europe
In the EU, the EMA, in collaboration with HMA and TEHDAS 
(Joint Action Toward the European Health Data Space), released a 
draft “Data Quality Framework,” which serves as a general guideline 
encompassing considerations on data quality across data types and 
regulatory submissions, including definitions for data dimensions and 
sub-dimensions, as well as their characterization and related metrics 
(39, 62). The EMA also released a draft “Good Practice Guide for the 
Use of the EU Metadata Catalog of RWD Sources” (61) to enable data 
discoverability. It provides recommendations on use of the agency’s 
real-world metadata catalog, which will replace the existing catalog of 
the European Network of Centers for Pharmacoepidemiology and 
Pharmacovigilance (ENCePP) by late 2023 (66–68). Further, the EMA 
released the final version of the “Guideline on Registry-Based Studies” 
(60), which discusses various data quality considerations for registry 
data sources, generally consistent with the draft version discussed in 
the previous publication (1). Further, in order to assess the utility of 
raw data (i.e., clinical study-derived individual patient data available 
in electronic structured format for analysis and visualization) in 
improving and accelerating the process of medicine evaluation, the 
EMA launched a pilot initiative in July 2022, which will run for 2 years 
and include about 10 regulatory procedures submitted to the EMA 
(68–70). As part of the pilot, the EMA has received an initial 
marketing authorization application, with raw data, for the treatment 
of a neurological disorder. The Danish Medicines Agency will 
be responsible for conducting the analysis and visualization of the data 
as part of a contract with EMA following a procurement procedure 
(37). Currently, applicants submit data in an aggregated format, which 
can hinder its analysis and slow down the process of evaluation (69, 
70). This pilot initiative aligns with the priority recommendation of 
building network capability to analyze big data, as per the Big Data 
Task Force (69, 70). Overall, regulators in the EU are consistently 
striving toward enabling and supporting data harmonization to 
minimize the administrative efforts involved in receiving, processing, 
and reusing scientific data across the EU, as well as at a global level. 
Thus, based on stakeholder consultations, the European Medicines 
Regulatory Network (EMRN) Data Standardization Strategy was 
developed that aligns with the HMA-EMA joint Big Data Task Force 
recommendations (71). The strategy outlines key principles for 
defining, adopting, and implementing international data standards by 
the EMRN (71, 72).
In the United Kingdom, the MHRA released guidance on the use 
of RWD in clinical studies to support regulatory decisions (15). 
Beyond the general introductions to the guidance series, this guidance 
also includes a dedicated section on MHRA’s recommendations 
around RWD quality.
Asia-Pacific
In South Korea, the RWE guideline on medical information 
database studies also discusses attributes related to RWD quality (24).
Third-party initiatives
In addition to formal regulatory guidance, several third-party 
initiatives are also working to help provide standards and tools for 
improving RWD quality and access (Supplementary Table S1). The 
One Source Program, a collaborative initiative by researchers from the 
University of California, San Francisco-Stanford University Center of 
Excellence in Regulatory Science and Innovation, and the FDA, aims 
to develop tools and methods for automation of structured EHR data 
flow into external systems, so as to reduce operational costs, time, and 
improve data quality for clinical studies (73). The FDA Oncology 
Center of Excellence (OCE) started the Quality Characteristics and 
Assessment of Real-world Data (QCARD) initiative in 2022, in 
collaboration with the Reagan-Udall Foundation, to develop a 
standardized approach for RWD characterization and evaluation of 
oncology RWD quality for regulatory submissions (74). The Audit 
Readiness Tool by TransCelerate BioPharma Inc. intends to promote 
best practices for quality management of RWD, such as inspection 
readiness, which is suitable for regulatory decision-making (75).
The ICARE data® (Integrating Clinical Trials and Real-World 
Endpoints) project aims to support the collection of high-quality 
RWD, based on Minimal Common Oncology Data Elements 
(mCODE™), to enable clinical oncology research (76). The 
HARMONY (Healthcare Alliance for Resourceful Medicine Offensive 
against Neoplasms in Hematology) Big Data platform provides access 
to a data lake and advanced analytic tools for the accelerated 
development of more innovative and effective treatments against 
hematological malignancies (77). The Clinical Data Interchange 
Standards Consortium (CDISC) has successfully standardized clinical 
trial-based data for regulation on a global scale. CDISC standards are 
required for regulatory submissions to the FDA and PMDA (78).

## Page 8 (Section: Updates on study methods guidance)

Burns et al.
10.3389/fmed.2023.1236462
Frontiers in Medicine
08
frontiersin.org
However, more effort toward the adoption of an RWD standard that 
is fit-for-purpose is warranted. There are several challenges with 
adopting such data standards for RWD, including: (a) complexity of 
data, (b) concerns due to data being originally collected for different 
purposes, (c) lack of awareness and incentives to adopt new standards, 
and (d) inadequate implementation support and training (78). 
Potential solutions might result from further collaboration with other 
standards development organizations, establishing controlled 
terminologies and models which can be used to represent data from 
varied sources, as well as the development of tools and training to 
support the RWD community (78). An example of such a tool can 
be found in the Registry Evaluation and Quality Standards (REQueST) 
Tool, from the EUnetHTA Joint Action 3, which promises to maximize 
the utilization of registry data in decision-making by regulatory as 
well as HTA bodies (79).
Updates on study methods guidance
Regulatory authorities have now begun to address study design 
methods for RWE studies intended for regulatory decision-making. 
In the last review until May 2021, the MHRA had released a draft 
guidance on evaluating methods for a specific study design, 
randomized clinical trials (RCTs) incorporating RWE (80). Guidance 
documents discussing multiple topics including general study 
methods (among other topics) were also released by the FDA, EMA, 
NMPA, PMDA, and TFDA (1).
Since then, additional regulatory authorities, including the FDA 
and MFDS, have begun to release their own guidance documents, 
focusing on study methods for various real-world study designs. 
Updated or additional guidance on study methods have also been 
released by the EMA, MHRA, and NMPA. Table 4 summarizes the 
regulatory real-world study methods guidance available across 
the globe.
North America
In the US, the FDA released its draft guidance in 2023, 
“Considerations for the Design and Conduct of Externally Controlled 
Trials,” which includes recommendations for external controls 
consisting of other clinical trial data or RWD (81). Overall, the 
guidance discusses numerous study design and analysis considerations 
centered around commonly encountered challenges for this type of 
study design when intended to be used for regulatory purposes. The 
FDA is also expected to publish two additional draft guidance 
documents in 2023 on non-interventional studies and the use of 
clinical practice data in randomized clinical trials.
The CADTH draft guidance on reporting RWE also highlights 
methodological considerations for RWE studies and their submission 
to regulators and HTA bodies in Canada (65).
Europe
In the EU, the EMA’s final “Guideline on Registry-Based Studies” 
includes methodology recommendations related to registry-based 
study designs, including expected protocol elements and areas of 
anticipated bias (60), and is generally consistent with the draft version 
of the guidance included in our prior review (1). The DARWIN EU 
also supports in making regulatory decisions by addressing specific 
questions through high-quality, non-interventional studies, including 
the development of scientific protocols, examination of relevant 
sources of data, and analysis and reporting of the results (31).
In the United  Kingdom, the MHRA’s final “Guideline on 
Randomized Controlled Trials Using RWD to Support Regulatory 
Decisions” contains various methodology recommendations with 
regard to the appropriate design and operation of such studies (16), 
and is generally consistent with the draft version of the guidance 
described in our previous review (1).
TABLE 4  Regulatory guidance on real-world study methods in Asia-
Pacific, North America, and Europe.
Regulatory body
Guidance documents
North America
US Food and Drug Administration 
(FDA)
Best practices for conducting and reporting 
pharmacoepidemiologic safety studies 
using electronic healthcare data (2013) (54)
FDA RWE framework (2018) (6)
Draft guidance: Considerations for the 
Design and Conduct of Externally 
Controlled Trials for Drug and Biological 
Products (2023) (81) (New)
Health Canada (HC)
Elements of real-world data/evidence 
quality throughout the prescription drug 
product life cycle (2019) (59)
Europe
European Medicines Agency 
(EMA)
Guideline on registry-based studies 
(2021) (60) (New)
Medicines and Healthcare products 
Regulatory Agency (MHRA, 
United Kingdom)
MHRA guideline on randomized 
controlled trials using real-world data to 
support regulatory decisions (2021) (16) 
(New)
Asia-Pacific
National Medical Products 
Administration (NMPA, China)
Guidelines for Real-World Evidence to 
Support Drug Development and Review 
(Interim) (2020) (18)
Draft guidance: Guiding Principles for 
Drug Real-World Research Design and 
Protocol Framework (2022) (82) (New)
Taiwan Food and Drug 
Administration (TFDA)
Basic considerations for real-world 
evidence supporting drug research and 
development (2020) (21)
Pharmaceuticals and Medical 
Devices Agency (PMDA, Japan)
Guidelines for conducting 
pharmacoepidemiological studies in drug 
safety evaluations using medical 
information databases (2014) (63)
Basic principles on utilization of registry 
for applications (2021) (22)
Ministry of Food and Drug Safety 
(Korea)
Medical information database studies 
guideline (2021) (24) (New)
Bold font denotes new guidance updates from June 2021 to January 2023.

## Page 9 (Section: Asia-Pacific)

Burns et al.
10.3389/fmed.2023.1236462
Frontiers in Medicine
09
frontiersin.org
Asia-Pacific
In China, the NMPA’s Center for Drug Evaluation issued a draft 
guideline in 2022 dedicated to study methods and protocol 
development for any real-world study design, including observational 
studies, external controls, and pragmatic trials. The guidance 
emphasized the need for a strong scientific approach and also clarified 
the content/section expectations for real-world research protocols in 
China (82).
In South Korea, the MFDS also provides considerations for RWE 
study designs in its “Medical Information Database Studies Guideline,” 
including protocol and study report writing methods (24).
Third-party initiatives
Apart from the formal regulatory agency guidance, several third-
party initiatives have continued to work on topics concerning RWE 
study methods (Supplementary Table S1). The RCT DUPLICATE 
(Randomized, Controlled Trials Duplicated Using Prospective 
Longitudinal 
Insurance 
Claims: 
Applying 
Techniques 
of 
Epidemiology) initiative has been using RWD to reproduce RCTs to 
further inform when it is possible to use RWD successfully, the best 
methods to implement such studies, and the future of quality 
assurance processes. An interim report on the initial findings of this 
project has been published (3). The Duke-Margolis Center for Health 
Policy has also continued to release whitepapers and conduct 
workshops on point-of-care trials, i.e., RCTs using RWD, or pragmatic 
trials (83). Friends of Cancer Research has also been conducting a 
pilot program on developing real-world endpoints (84). The IMI’s 
GetReal Institute launched in April 2021 also provides RWE training 
through its GetReal Academy (53). With a mission to facilitate RWE 
adoption and implementation in healthcare decision-making across 
Europe, the institute works on three key focus areas: reducing barriers 
in secondary data use, bridging the gap between RWE and RCTs, and 
addressing evidence needs of decision-makers.
Updates on procedural guidance
Several regulatory authorities have also released procedural 
guidance related to RWE (Table 5). The TFDA released a guideline for 
categorizing submissions as containing RWE for agency-tracking 
purposes (87), similar to the FDA’s draft guidance on the same topic 
released in 2019. The final version of the FDA guidance was released 
in late 2022 (85). Additionally, the NMPA released a draft guidance on 
meetings with CDE regarding RWE studies planned to support 
registrational applications (86). In Europe, the adoption of the 
Interoperable Europe Act by the EC in November 2022 was an 
important step to strengthen cooperation among EU member states 
and institutions for a secure cross-border exchange of data and its 
interoperability (88).
Gaps in RWE guidance and future 
directions to improve RWE use in 
regulatory decision-making
In our previous publication (1), key gaps and future directions 
that were identified to further advance in the field of RWE included 
the need for more detailed guidance on RWD quality and study 
methods, standardizing the submission process for RWD, 
international regulatory harmonization, and the impact of the 
COVID-19 pandemic in accelerating the need for cross-country 
collaborations. Much of this has been addressed with the recent, more 
detailed regulatory guidance documents described in the preceding 
sections. Additionally, funding opportunities, as recently announced 
by the FDA, also help promote advancements in RWD quality and use, 
study designs, and developing tools for evaluating different aspects of 
RWE generation (89). However, regulatory harmonization remains an 
area for further development with respect to convergence/divergence 
between regulatory and HTA guidance around RWE and the practical 
challenges of implementing existing regulatory guidance.
Implementing RWE guidance into practice
Despite the extensive regulatory guidance released by numerous 
countries, there is still room for further improvement to fully 
implement many of the principles into practice. For example, with the 
release of several guidance documents on data quality principles, more 
clarity around best practices for sponsors and agencies to assess and 
document the level of adherence to these principles is needed. This is 
where further efforts, such as the TransCelerate BioPharma Inc.’s 
Audit Readiness Tool (75) described earlier, are being directed. Pilot 
programs, including the FDA’s Advancing RWE Program (26), may 
also help in further developing the learnings in this area by identifying 
evidence generation strategies that meet regulatory or post-approval 
study requirements, developing and promoting agency processes for 
consistent decision-making, and creating awareness of RWE 
characteristics to support regulatory decisions. Generating a 
substantial industry response to such pilot programs is highly 
recommended to enhance learnings and to inform future guidance. 
Although new guidance has been issued on data quality standards, 
there exists a lack of clear and standardized terminology that can 
be used for all planning and reporting processes to reduce variability, 
TABLE 5  Procedural guidance on real-world evidence (RWE) application 
submissions in Asia-Pacific and North America.
Regulatory body
Guidance documents
North America
US Food and Drug Administration 
(FDA)
Submitting documents using real-
world data and real-world evidence to 
FDA for drug and biological products 
(2022) (85) (New)
Asia-Pacific
National Medical Products 
Administration (NMPA, China)
Draft guidance: Guidelines for 
communication and exchange of 
real-world evidence supporting drug 
registration applications (2022) (86) 
(New)
Taiwan Food and Drug Administration 
(TFDA)
Precautions for the use of real-world 
data/real-world evidence as technical 
documents for drug review 
applications (2021) (87) (New)
Bold font denotes new guidance updates from June 2021 to January 2023.

## Page 10 (Section: Regulatory harmonization)

Burns et al.
10.3389/fmed.2023.1236462
Frontiers in Medicine
10
frontiersin.org
skepticism, and confusion among industry stakeholders (90). Further, 
industry involvement is also critical in developing a consensus on best 
practices, especially around data quality, integrity, and analytical 
methods, which may have a higher likelihood of adoption if consensus 
reaches a certain threshold.
In addition, although the importance of regulatory authority 
engagement is clearly described throughout many of the guidance 
documents, more detailed guidance on best practices for agency 
engagement on RWE continues to be  a point of discussion. 
TransCelerate BioPharma Inc. has been developing best practices for 
such engagements on RWE proposals based on member company 
experience via its Health Authority Engagement Framework (75). 
Further, there is a lack of comprehensive information on the RWE 
being submitted to support regulatory decisions and the extent to 
which this evidence is influencing such decisions. However, regulatory 
agencies are planning to develop and generate reports for the 
ecosystem to better understand this.
The US and some other markets require access to patient-level 
datasets to support marketing applications and efficacy supplements. 
With access to big data on the horizon, the submission of (properly 
anonymized) individual patient-level data will aid in credibility and 
transparency. The data management and sharing policy by the Patient-
Centered Outcomes Research Institute (PCORI) is one such example. 
It requires PCORI research-awardee institutions to generate and 
preserve research data and document it systematically for ease of data 
sharing, thereby maximizing the utility and usability of the data (91). 
Although draft guidance has been released by the FDA in an attempt 
to harmonize real-world datasets to CDISC format, document areas 
of infeasibility, and characterize completed transformations, there 
remains a need for RWD standards for datasets to be established. In 
addition, the establishment and enforcement of standardized 
procedures for data derivation and curation would aid in consistency 
of evidence and should ideally be embedded into the electronically 
stored health information. In the long term, this could result in 
different paradigms than the historical clinical trial CDISC format.
Considering all of these, although substantial guidance has been 
issued, there still remains a key role for experience through individual 
project proposals and regulatory precedents in informing best 
practices and the most appropriate regulatory use-cases.
Regulatory harmonization
With the high number of guidance documents released 
independently by various countries, harmonization is still just as 
relevant today as in the last review. Previously, activities by the 
International Council for Harmonization, Council for International 
Organizations of Medical Sciences, International Society for 
Pharmacoeconomics and Outcomes Research, and ICMRA were 
described (1). Fortunately, these international collaborations continue 
to be  strengthened, in many cases by the experience from the 
COVID-19 pandemic. In particular, ICMRA facilitated a workshop in 
June 2022 co-chaired by the EMA, FDA, and Health Canada, in which 
it issued a formal statement on international collaboration to enable 
RWE integration into regulatory decision-making. Four key areas for 
regulatory cooperation were identified, including (a) harmonization 
of terminologies for RWD/E, (b) regulatory convergence on RWD/E 
guidance and best practice, (c) readiness to address challenges in 
public health and prevent emerging health threats, and (d) 
transparency (92). In addition, the FDA OCE Project Orbis is a 
potential driver of multinational standards in oncology trial design 
and best practices, and currently helps provide concurrent cross-
agency submission and review of oncology products containing RWE 
(93). The Society for Translational Oncology’s Global Harmonization 
of Cancer Trials initiative intends to harmonize universal standards 
for clinical trial protocols, so as to enhance and support the 
development of novel strategies for improved treatment and 
prevention of cancer (94).
Regulatory vs. HTA convergence/
divergence
While RCTs are often the preferred study design by regulatory and 
HTA bodies, different trial designs are increasingly under 
consideration in efforts to address the growing unmet medical needs 
and provide faster access to new and innovative medical therapies for 
patients. Drug developers are actively seeking to introduce new 
medicines into the market via a coordinated development program 
that leverages RWD (as external control groups) to generate evidence 
that aligns concurrently with the requirements of both regulatory and 
HTA bodies. In fact, to generate effective medicines that can 
be approved as well as reimbursed, health care companies feel the need 
to include HTA requirements early during the development plan (95). 
Challenges in developing a framework of such synergized evidentiary 
requirements are not surprising, as regulatory agencies focus on the 
safety and efficacy of new medicines, while HTA bodies evaluate the 
relative effectiveness of a new intervention compared to existing ones.
In a survey conducted among stakeholders from the healthcare 
ecosystem to understand the regulatory and HTA landscape on RWE, 
pharmaceutical industry stakeholders specified a lack of coordination 
among regulators and HTA agencies in two major areas: (a) drugs 
under conditional approval, and (b) medical products associated with 
clinical uncertainty, such as orphan drugs (95). Additionally, all three 
stakeholders (industry, regulators, and HTA agencies) frequently 
perceived divergences in areas related to: (a) acceptable primary 
endpoints, (b) inclusion of an active comparator arm in trials, and (c) 
choice and use of surrogate endpoints (95). Other methodological 
issues to be addressed for improving synchrony were reported to 
be study design and target patient population (96).
Researchers have proposed that a comprehensive guidance should 
contain: (a) a well-defined, possibly consensus-based, description of the 
components involved in each building block pertaining to RWE (namely 
study design, data sources, analytic methods, transparency and 
reproducibility, and final report evaluation); (b) a step-by-step procedure 
that researchers may follow to fulfill regulatory and HTA expectations; 
(c) a checklist to confirm inclusion of all essential conditions and criteria; 
and (d) a decision tool for justification, to decision-makers, for adoption 
of a particular study design (90). Additionally, a few key steps have been 
recommended by the Duke-Margolis Center for Health Policy to build 
a robust and aligned ecosystem of RWD for payers and regulators, 
namely: (a) RWE-driven studies post-regulatory approval of therapies 
for evidence generation to determine their comparative and/or combined 
effectiveness, (b) interoperability of data systems for easy use, sharing, 
and exchange of RWD among multiple systems, (c) linking databases to 
enhance data analysis potential, (d) standardization of outcomes and

## Page 11 (Section: Conclusion)

Burns et al.
10.3389/fmed.2023.1236462
Frontiers in Medicine
11
frontiersin.org
endpoints to gage the real-world effectiveness of therapies, (e) supporting 
collaborations to facilitate data sharing, (f) moving toward robust data 
collection systems by building on existing databases, and (g) funding and 
incentives for supporting RWD collection and analysis in the long term 
(97). The Duke-Margolis Center for Health Policy also recommends a 
“totality of evidence” approach to generate evidence that is informative 
not only for regulators, but also for payers (98). The approach suggests 
that RWE studies should contribute to an evidence package and 
be  considered a part of the totality of evidence when making 
regulatory decisions.
The last decade has witnessed a significant degree of alignment 
between regulatory and HTA stakeholders, with a reduction in 
disparities between regulatory and HTA requirements (95, 96). In the 
current period of study, we found that several HTA bodies, especially 
in Europe and Canada, have also started releasing frameworks and 
guidance focused on RWE. In France, the Haute Autorité de Santé 
(HAS) published a guide for developing high quality RWE studies on 
health products, including post-authorization studies, observational 
studies, and pragmatic trials (99). The guide aims to deliver practical 
benchmarks pertaining to the methodological aspects for optimizing 
the level of evidence of these studies and enhancing confidence in the 
results (99). IMPACT-HTA, the EU’s Horizon-2020 initiative, has also 
developed recommendations to improve the quality and value of 
nonrandomized evidence by researchers and HTA bodies (100). The 
recommendations for researchers include: (a) justifying the need for a 
nonrandomized study and ensuring that the data are identified via a 
systematic and transparent process; (b) planning prospective studies to 
minimize risk of selection bias; and (c) maintaining transparency in 
reporting 
data, 
methods, 
and 
results 
(100). 
Additional 
recommendations for HTA bodies include strengthening early 
scientific advice and investing in resources to efficiently design, analyze, 
and interpret RWE (100). Furthermore, NICE, the United Kingdom 
HTA body, released an RWE framework that (a) evaluates and 
identifies situations where RWD can be applied to reduce uncertainty 
and improve decision-making, and (b) details best practices to plan, 
conduct, and report RWE studies to enhance evidence quality and 
transparency (101). This framework is a part of NICE’s 5-year strategic 
plan (2021–2026) focused on resolving evidence gaps through the use 
of RWD and promoting innovative health technology solutions for 
patients (101). NICE has developed a Data Suitability Assessment Tool 
(DataSAT), which focuses on data provenance, quality, and reliance, all 
of which are important considerations for assessing data fitness (101). 
As per the framework, researchers are expected to justify the choice of 
RWD source transparently via the use of previously published 
frameworks, such as Structured Process to Identify Fit-for-Purpose 
Data (SPIFD) or NICE’s DataSAT (101). NICE hosted a workshop in 
October 2022 as part of the IMI-EHDEN project highlighting the 
recent developments in the use of RWE for regulatory decision-making 
and the implications and opportunities for European HTA agencies to 
advance adoption of RWE for HTA (102).
Similar to the recently released regulatory guidelines by the FDA, 
EMA, and MHRA, the guidance issued by HTA bodies aligns with 
respect to providing recommendations for data quality, reliability, 
fitness for use, and transparency, so as to promote confidence in RWD 
studies. This signals an increasing synergy in evidence requirements 
among regulators and HTA bodies.
Pilot projects to obtain parallel scientific advice on drug 
development were launched in Australia and Europe involving 
pharmaceutical companies, HTA agencies, and regulators to address 
discrepancies in requirements by decision-making bodies (103, 104). In 
2022, the EMA launched an initiative to offer parallel joint scientific 
consultation with the EUnetHTA 21 to generate evidence that is optimal 
and robust and caters to the requirements of both regulators and HTA 
bodies (105). To this end, a guidance was published in September 2022 
describing the actions and timelines for each party undertaking the 
parallel EMA/EUnetHTA 21 Joint Scientific Consultation (106). It also 
discusses practical issues related to the process, such as fees, points of 
contact, and processing of documents to ensure that all parties are in 
possession of appropriate document(s) at the correct time (106). The 
routine inclusion of patients and clinical experts is expected during the 
joint consultation (106). In Canada, following on its 2019 framework 
(107), the CADTH announced the expansion of its Scientific Advice 
Program, which now includes applications for advice on RWE 
generation plans upon the finalization of protocols for pivotal trials 
(108). In particular, the jointly developed 2022 RWE-reporting draft 
guidance from CADTH and Health Canada is a commendable example 
of regulatory-HTA harmonization and establishes a set of common 
standards for submissions to both HTA and regulatory agencies (65). 
The guidance aligns with existing international guidance while 
providing consideration from the Canadian healthcare perspective.
Indeed, early scientific advice was reported to be a key strategy for 
evidentiary alignment by agencies and companies, according to a 
stakeholder survey (95). In fact, it has been observed that 
manufacturers are more likely to implement changes to the drug 
development plan based on advice received from both decision-
making bodies during such consultations regarding the choice of the 
primary endpoint and comparator (109). However, a survey 
emphasized that joint advice discussions were predominantly focused 
on the regulatory aspect of drug development (95). The consequences 
of lack of complete alignment could be approval only from one of the 
authorities (either the regulator or the HTA body). For example, in 
2018, axicabtagene ciloleucel received regulatory approval in Europe 
to treat patients with diffuse large B-cell lymphoma after 2 prior 
therapies but NICE was unable to recommend its use in the NHS in 
England at the proposed cost per patient. At that time, this treatment 
was neither cost-effective nor contained direct comparative evidence 
to the best supportive treatment care option in England (which was 
determined to be salvage chemotherapy) (110).
Conclusion
There have been rapid evolutions in the RWE environment, from 
the release of general high-level frameworks, to the development and 
publication of comprehensive, practical guidance documents for RWE 
practitioners, including industry. This is illustrated by the recent wave 
of regulatory guidance documents released by several major health 
authorities focusing on data quality and study methods for RWE. The 
US and EU continue to lead from the forefront in releasing guidelines 
to promote the adoption of RWE for regulatory decision-making 
processes, and China is now also taking a leading role in releasing a 
number of RWE guidelines in Asia. New frameworks and guidance on 
RWE are also being issued in many other countries and regions, 
including the United Kingdom, Taiwan, South Korea, Switzerland, and 
Australia. However, there is still a global need for the development of 
guidance using a practical approach to support implementation and 
adoption. Practical application will rely upon the ability to 
communicate all aspects of the RWE study design, study conduct, and

## Page 12 (Section: Author contributions)

Burns et al.
10.3389/fmed.2023.1236462
Frontiers in Medicine
12
frontiersin.org
results clearly and succinctly in situations where large volumes of 
information often exist. Gaining additional experience and sharing 
best practices and successful use cases will be important in progressing 
toward practical data quality reporting standards. Data validation 
efforts may be expensive and inconsistent in methodologic approach. 
Multi-stakeholder action will be  critical for efficient and robust 
validation efforts. Additionally, there is also a need for harmonization 
of guidance across countries and with payers, to expedite the 
submission and review process with the final goal of access to 
treatment. Future research evaluating shared aspects and discrepancies 
among regulatory agencies could advanceharmonization efforts.
Author contributions
LB: conception, data collection, analysis, interpretation, and 
critical revision of the article. NR, RK-O, and JC: conception, data 
collection, and interpretation. JD, SK, and JO’D: conception and data 
interpretation. FR: data interpretation. All authors contributed to the 
article and approved the submitted version.
Funding
The authors declare that this study received funding from Bristol 
Myers Squibb. BMS employees were involved in the study design, 
collection, analysis, interpretation of data, the writing of this article, 
or the decision to submit it for publication.
Acknowledgments
Judith Lytle, Courtney Ramus, and Jennifer D. Clayton from 
IQVIA have supported in providing valuable insights for drafting this 
manuscript. Medical writing and editorial assistance were provided by 
Adivitiya, Smitha Sreedharan, and Shlok Kumar from IQVIA.
Conflict of interest
LB, RK-O, NR, JD, and JO’D were employed by and held stock in 
Bristol Myers Squibb (BMS). JC was employed by and held stock in 
IQVIA and Target RWE; was an advisory board member of PCORI 
Clinical Trials Advisory Panel; and received grants or contracts from 
BMS. SK was a Senior Partner at investment firm Braven and an 
advisor to Owkin Inc. FR was employed by Duke Clinical Research 
Institute, which received grants or contracts from NIH, PCORI, Gates 
National Philanthropic Trust, Alzheimer’s Drug Discovery 
Foundation, AstraZeneca, Eidos, American Regent, and Bayer; has 
received consulting fees from Janssen, Intercept, Clover, and the 
California Institute for Regenerative Medicine; has participated on 
Data Safety Monitoring Boards of AstraZeneca, Novartis, Lilly, Gilead, 
Merck, Sanofi, UCB, Amgen, Icosavax, Biogen, BMS, and Alkermes; 
was an Advisory Board member of Dr. Evidence; was chair of the 
Frontier Science Foundation board; held stock in GSK and Clover; 
and has held stock options in Ciox-Odyssey, Athira, Dr. Evidence, and 
Adaptic Health.
Publisher’s note
All claims expressed in this article are solely those of the 
authors and do not necessarily represent those of their affiliated 
organizations, or those of the publisher, the editors and the 
reviewers. Any product that may be evaluated in this article, or 
claim that may be made by its manufacturer, is not guaranteed or 
endorsed by the publisher.
Supplementary material
The Supplementary material for this article can be found online 
at: https://www.frontiersin.org/articles/10.3389/fmed.2023.1236462/
full#supplementary-material
References
	1.	Burns L, Roux NL, Kalesnik-Orszulak R, Christian J, Hukkelhoven M, Rockhold F, 
et al. Real-world evidence for regulatory decision-making: guidance from around the 
world. Clin Ther. (2022) 44:420–37. doi: 10.1016/j.clinthera.2022.01.012
	2.	International Coalition of Medicines Regulatory Authorities. ICMRA membership 
country/region and regulatory Authority’s website. (2022). Available at: https://www.
icmra.info/drupal/en/participatingRegulatoryAuthorities. (Accessed May, 2022).
	3.	Franklin JM, Patorno E, Desai RJ, Glynn RJ, Martin D, Quinto K, et al. Emulating 
randomized clinical trials with nonrandomized real-world evidence studies: first results 
from the RCT DUPLICATE initiative. Circulation. (2021) 143:1002–13. doi: 10.1161/
CIRCULATIONAHA.120.051718
	4.	Public Law. Public law 114–255 114th congress 13 December. 21st century cures act. 
(2016). Available at: https://www.congress.gov/114/plaws/publ255/PLAW-114publ255.
pdf. (Accessed June, 2022).
	5.	U.S. Food and Drug Administration. PDUFA VII: Fiscal years 2023–2027. (2022). 
Available at: https://www.fda.gov/industry/prescription-drug-user-fee-amendments/
pdufa-vii-fiscal-years-2023-2027. (Accessed September, 2022).
	6.	U.S. Food and Drug Administration. Framework for FDA’s real-world evidence 
program. (2018). Available at: https://www.fda.gov/media/120060/download. (Accessed 
June, 2022).
	7.	U.S. Food and Drug Administration. Considerations for the use of real-world data 
and real-world evidence to support regulatory decision-making for drug and biological 
products. (2021). Available at: https://www.fda.gov/regulatory-information/search-fda-
guidance-documents/considerations-use-real-world-data-and-real-world-evidence-
support-regulatory-decision-making-drug. (Accessed May, 2022).
	8.	Government of Canada. Optimizing the use of real world evidence to inform 
regulatory decision-making. (2019). Available at: https://www.canada.ca/en/health-
canada/services/drugs-health-products/drug-products/announcements/optimizing-
real-world-evidence-regulatory-decisions.html. (Accessed Septmeber, 2022).
	9.	European Commission. Pharmaceutical strategy for Europe (2020). Available at: 
https://health.ec.europa.eu/system/files/2021-02/pharma-strategy_report_en_0.pdf. 
(Accessed June, 2022).
	10.	European Commission. Data Act. (2022). Available at: https://digital-strategy.
ec.europa.eu/en/policies/data-act. (Accessed February 2023).
	11.	European Medicines Agency. Regulatory science to 2025. (2020). Available at: 
https://www.ema.europa.eu/en/about-us/how-we-work/regulatory-science-strategy. 
(Accessed June, 2022).
	12.	European Medicines Agency. European medicines agencies network strategy to 
2025. (2020). Available at: https://www.ema.europa.eu/en/documents/report/european-
union-medicines-agencies-network-strategy-2025-protecting-public-health-time-rapid-
change_en.pdf. (Accessed June, 2022).
	13.	European Medicines Agency. Ham/Ema big data steering group. (2022). Available 
at: https://www.ema.europa.eu/en/about-us/how-we-work/big-data#hma/ema-big-data-
steering-group-section. (Accessed June, 2022).
	14.	European Medicines Agency. HMA/EMA joint big data steering group. (2022). 
Available at: https://www.ema.europa.eu/en/documents/other/membership-list-hma/
ema-joint-big-data-steering-group_en.pdf. (Accessed June, 2022).
	15.	Medicines and Healthcare products Regulatory Agency. MHRA guidance on the 
use of real-world data in clinical studies to support regulatory decisions. (2021). Available

## Page 13 (Section: Author contributions)

Burns et al.
10.3389/fmed.2023.1236462
Frontiers in Medicine
13
frontiersin.org
at: https://www.gov.uk/government/publications/mhra-guidance-on-the-use-of-real-
world-data-in-clinical-studies-to-support-regulatory-decisions. (Accessed May, 2022).
	16.	Medicines and Healthcare products Regulatory Agency. Mhra guideline on 
randomised controlled trials using real-world data to support regulatory decisions. (2021). 
Available at: https://www.gov.uk/government/publications/mhra-guidance-on-the-use-
of-real-world-data-in-clinical-studies-to-support-regulatory-decisions/mhra-guideline-
on-randomised-controlled-trials-using-real-world-data-to-support-regulatory-
decisions. (Accessed May, 2022).
	17.	Swissmedic. Swissmedic position paper on the use of real world evidence. (2022). 
Available at: https://www.swissmedic.ch/swissmedic/en/home/news/mitteilungen/
positionspapier-verwendung-real-world-evidence.html. (Accessed August, 2022).
	18.	National Medical Products Administration. Guidelines for real-world evidence to 
support drug development and review (interim). (2020). Available at: http://english.nmpa.
gov.cn/2020-01/07/c_456245.htm. (Accessed June, 2022).
	19.	National Medical Products Administration. Technical guidelines for real-world 
research supporting the R&D and review of pediatric drugs (trial). (2020). Available at: 
https://www.nmpa.gov.cn/directory/web/nmpa/xxgk/ggtg/qtggtg/20200901104448101.
html. (Accessed June, 2022).
	20.	National Medical Products Administration. Guiding principles of real world data 
used to generate real world evidence (trial). (2021). Available at: https://redica.com/wp-
content/uploads/NMPA_-Attachment_-_Guiding-Principles-of-Real-World-Data-
Used-to-Generate-Real-World-Evidence-Trial_.pdf. (Accessed June, 2022).
	21.	Taiwan Food and Drug Administration. Basic considerations for real-world 
evidence supporting drug Research and Development. (2020). Available at: https://www.
fda.gov.tw/TC/siteListContent.aspx?sid=9354&id=33972. (Accessed June, 2022).
	22.	Pharmaceuticals and Medical Devices Agency. Basic principles on utilization of 
registry for applications. (2021). Available at: https://www.pmda.go.jp/files/000240810.
pdf. (Accessed June, 2022).
	23.	Pharmaceuticals and Medical Devices Agency. Points to consider for ensuring the 
reliability in utilization of registry data for applications. (2021). Available at: https://www.
pmda.go.jp/files/000240811.pdf. (Accessed June, 2022).
	24.	Ministry of Food and Drug Safety. Medical information database studies guideline 
(article in Korean). (2021). Available at: https://www.mfds.go.kr/brd/m_1060/view.do?s
eq=14861&srchFr=&srchTo=&srchWord=&srchTp=&itm_seq_1=0&itm_
seq_2=0&multi_itm_seq=0&company_cd=&company_nm=&page=1. (Accessed May, 
2022).
	25.	Therapeutic Goods Administration. Real world evidence and patient reported 
outcomes in the regulatory context. (2021). Available at: https://www.tga.gov.au/sites/
default/files/real-world-evidence-and-patient-reported-outcomes-in-the-regulatory-
context.pdf. (Accessed May, 2022).
	26.	U.S. Food and Drug Administration. PDUFA reauthorization performance goals 
and procedures fiscal years 2023 through 2027. (2021) Available at: https://www.fda.gov/
media/151712/download. (Accessed September, 2022).
	27.	U.S. Food and Drug Administration. Advancing real-world evidence program. 
(2022). Available at: https://www.fda.gov/drugs/development-resources/advancing-real-
world-evidence-program. (Accessed October, 2022).
	28.	European Commission. European health data space. (2022). Available at: https://
health.ec.europa.eu/ehealth-digital-health-and-care/european-health-data-space_en. 
(Accessed July, 2022).
	29.	Health Data Hub. Launch of a pilot project for the European health data space: 
Towards new opportunities for Health Research in Europe. (2022). Available at: https://
www.health-data-hub.fr/sites/default/files/2022-07/Press%20release%20-%20
EHDS2%20pilot%20launch.pdf. (Accessed February, 2023).
	30.	Health Data Hub. European health data space pilot project: The 5 use cases. (2022). 
Available 
at: 
https://www.health-data-hub.fr/actualites/projet-pilote-de-lespace-
europeen-des-donnees-de-sante-les-5-cas-dusage. (Accessed February, 2023).
	31.	European Medicines Agency. Data analysis and real world interrogation network 
(DARWIN EU). (2021) Available at: https://www.ema.europa.eu/en/about-us/how-we-
work/big-data/data-analysis-real-world-interrogation-network-darwin-eu. (Accessed 
May, 2022).
	32.	European Medicines Agency. Initiation of DARWIN EU® coordination Centre 
advances integration of real-world evidence into assessment of medicines in the EU. (2022). 
Available at: https://www.ema.europa.eu/en/news/initiation-darwin-eur-coordination-
centre-advances-integration-real-world-evidence-assessment. (Accessed May, 2022).
	33.	DARWIN EU Coordination Centre. Introduction of the DARWIN EU® 
coordination Centre. (2022). Available at: https://www.ohdsi.org/wp-content/
uploads/2022/05/Rijnbeek-DARWIN-EU_v2.pdf. (Accessed February, 2023).
	34.	European Medicines Agency. DARWIN EU® data partners Onboarded in phase I*. 
(2023). Available at: https://www.ema.europa.eu/en/documents/other/darwin-eu-data-
partners-onboarded-phase-i_en.pdf. (Accessed February, 2023).
	35.	European Medicines Agency. Learnings initiative for optimal use of big data for 
regulatory purpose. (2022). Available at: https://www.ema.europa.eu/en/documents/
report/meeting-report-learnings-initiative-webinar-optimal-use-big-data-regulatory-
purpose_en.pdf.
	36.	European Medicines Agency. Meetings and workshops. (2023). Available at: https://
www.ema.europa.eu/en/about-us/how-we-work/big-data#meetings-and-workshops-
section. (Accessed February, 2023).
	37.	European Medicines Agency. Big data highlights issue 4. (2022). Available at: 
https://www.ema.europa.eu/en/documents/newsletter/big-data-highlights-issue-4_
en.pdf. (Accessed February, 2023).
	38.	European Medicines Agency. EMA/HMA Big Data Stakeholder Forum 2022. 
(2022). Available at: https://www.ema.europa.eu/en/events/ema-hma-big-data-
stakeholder-forum-2022. (Accessed February, 2023).
	39.	European Medicines Agency. Big Data Steering Group (BDSG). Report. (2023). 
Available at: https://www.ema.europa.eu/en/documents/report/big-data-steering-
group-bdsg-2022-report_en.pdf. (Accessed February 2023).
	40.	European Medicines Agency. Big Data Steering Group. Report. (2022). Available 
at: 
https://www.ema.europa.eu/en/documents/report/big-data-steering-group-
bdsg-2021-report_en.pdf. (Accessed February 2023).
	41.	European Medicines Agency. Big data steering group Workplan 2021–2023. (2021). 
Available 
at: 
https://www.ema.europa.eu/en/documents/work-programme/
workplan-2021-2023-hma/ema-joint-big-data-steering-group_en.pdf. 
(Accessed 
February 2023).
	42.	European Medicines Agency. Big data use for public health: Publication of big data 
steering group Workplan 2022–25. (2022). Available at: https://www.ema.europa.eu/en/
news/big-data-use-public-health-publication-big-data-steering-group-
workplan-2022-25. (Accessed July, 2022).
	43.	Korea Biomedical Review. Government to innovate drug data to meet industry 
needs. 
(2021). 
Available 
at: 
http://www.koreabiomed.com/news/articleView.
html?idxno=12771. (Accessed June, 2022).
	44.	Korean Academy of Medical Sciences. [Event] the 3rd regulatory science innovation 
forum - utilization of big data for regulatory science decision making. (2021). Available at: 
https://www.kams.or.kr/bbs/index.php?code=notice&keyfield=all&page=12&numbe
r=6191&mode=view. (Accessed June, 2022).
	45.	Therapeutic Goods Administration. Real world evidence (RWE) and patient 
reported outcomes (PROs). (2023). Available at: https://www.tga.gov.au/real-world-
evidence-rwe-and-patient-reported-outcomes-pros#2021-review. (Accessed February, 
2023).
	46.	DIA Global Forum. Pharmaceutical industry perspective on use of RWD/RWE in 
Brazil. (2022). Available at: https://globalforum.diaglobal.org/issue/april-2022/
pharmaceutical-industry-perspective-on-use-of-rwd-rwe-in-brazil/. (Accessed May, 
2022).
	47.	Interfarma. Interfarma. (2021). Available at: https://www.youtube.com/c/
INTERFARMAbrasil/videos. (Accessed September, 2022).
	48.	National Health Surveillance Agency - Anvisa. Anvisa approves new regulatory 
framework for registration of new and innovative medicines (article in Portuguese). (2022) 
Available at: https://www.gov.br/anvisa/pt-br/assuntos/noticias-anvisa/2022/anvisa-
aprova-novo-marco-normativo-para-registro-de-medicamentos-novos-e-inovadores-1. 
(Accessed January, 2023).
	49.	Duke-Margolis Center for Health Policy. Real-world evidence collaborative. (2022). 
Available at: https://healthpolicy.duke.edu/projects/real-world-evidence-collaborative. 
(Accessed October, 2022).
	50.	EHDEN. Ehden Academy. (2022). Available at: https://academy.ehden.eu/. 
(Accessed February, 2023).
	51.	EHDEN. EHDEN joins stakeholders’ consensus response to the proposed European 
health data space. (2022). Available at: https://www.ehden.eu/ehden-joins-stakeholders-
consensus-response-to-the-proposed-european-health-data-space/?utm_
source=rss&utm_medium=rss&utm_campaign=ehden-joins-stakeholders-consensus-
response-to-the-proposed-european-health-data-space. (Accessed February, 2023).
	52.	GetReal Institute. Getreal Institute Annual Conference 2023. (2023). Available at: 
https://www.getreal-institute.org/annual-conference-2023/. (Accessed February, 2023).
	53.	GetReal Institute. Getreal institute: Homepage. (2023). Available at: https://www.
getreal-institute.org/. (Accessed February, 2023).
	54.	U.S. Food and Drug Administration. Best practices for conducting and reporting 
Pharmacoepidemiologic safety studies using electronic healthcare data. (2013). Available 
at: 
https://www.fda.gov/files/drugs/published/Best-Practices-for-Conducting-and-
Reporting-Pharmacoepidemiologic-Safety-Studies-Using-Electronic-Healthcare-Data-
Sets.pdf. (Accessed September, 2022).
	55.	U.S. Food and Drug Administration. Use of electronic health record data in clinical 
investigations. (2018). Available at: https://www.fda.gov/regulatory-information/search-
fda-guidance-documents/use-electronic-health-record-data-clinical-investigations-
guidance-industry. (Accessed September, 2022).
	56.	U.S. Food and Drug Administration. Real-world data: Assessing electronic health 
records and medical claims data to support regulatory decision-making for drug and 
biological products. (2021). Available at: https://www.fda.gov/regulatory-information/
search-fda-guidance-documents/real-world-data-assessing-electronic-health-records-
and-medical-claims-data-support-regulatory. (Accessed May, 2022).
	57.	U.S. Food and Drug Administration. Data standards for drug and biological product 
submissions containing real-world data. (2021). Available at: https://www.fda.gov/
regulatory-information/search-fda-guidance-documents/data-standards-drug-and-
biological-product-submissions-containing-real-world-data. (Accessed May, 2022).
	58.	U.S. Food and Drug Administration. Real-world data: Assessing registries to support 
regulatory decision-making for drug and biological products guidance for industry. (2021). 
Available 
at: 
https://www.fda.gov/regulatory-information/search-fda-guidance-

## Page 14 (Section: Author contributions)

Burns et al.
10.3389/fmed.2023.1236462
Frontiers in Medicine
14
frontiersin.org
documents/real-world-data-assessing-registries-support-regulatory-decision-making-
drug-and-biological-products. (Accessed May, 2022).
	59.	Government of Canada. Elements of real world data/evidence quality throughout 
the prescription drug product life cycle. (2019). Available at: https://www.canada.ca/en/
services/health/publications/drugs-health-products/real-world-data-evidence-drug-
lifecycle-report.html. (Accessed September, 2022).
	60.	European Medicines Agency. Guideline on registry-based studies. (2021). Available 
at: https://www.ema.europa.eu/en/guideline-registry-based-studies-0. (Accessed May, 
2022).
	61.	European Medicines Agency. Good practice guide for the use of the metadata 
catalogue of real-world data sources. (2022). Available at: https://www.ema.europa.eu/
en/documents/regulatory-procedural-guideline/good-practice-guide-use-metadata-
catalogue-real-world-data-sources_en.pdf. (Accessed October, 2022).
	62.	European Medicines Agency. Data quality framework for EU medicines regulation. 
(2022). Available at: https://www.ema.europa.eu/en/documents/regulatory-procedural-
guideline/data-quality-framework-eu-medicines-regulation_en.pdf. 
(Accessed 
September, 2022).
	63.	Pharmaceuticals and Medical Devices Agency. Guidelines for conducting 
Pharmacoepidemiological studies in drug safety evaluation using medical information 
databases. (2014). Available at: https://www.pmda.go.jp/safety/mid-net/0006.html. 
(Accessed September, 2022).
	64.	Pharmaceuticals and Medical Devices Agency. Basic policy on the use of medical 
information databases in post-marketing pharmacovigilance. (2017). Available at: https://
www.pmda.go.jp/safety/mid-net/0006.html. (Accessed September, 2022).
	65.	Canada’s Drug and Health Technology Agency. RWE reporting guidance. (2022). 
Available at: https://www.cadth.ca/sites/default/files/RWE/pdf/RWE%20Reprting%20
Guidance%20-%20Draft%20for%20Consultation.pdf. (Accessed January, 2023).
	66.	European Medicines Agency. Metadata list describing real world data. (2022). 
Available 
at: 
https://www.ema.europa.eu/en/about-us/how-we-work/big-
data#metadata-list-describing-real-world-data-section. (Accessed July, 2022).
	67.	European Medicines Agency. List of metadata for real world data catalogues. 
(2022). Available at: https://www.ema.europa.eu/en/documents/other/list-metadata-
real-world-data-catalogues_en.pdf. (Accessed July, 2022).
	68.	European Medicines Agency. Big data highlights issue 3. (2022). Available at: 
https://www.ema.europa.eu/en/documents/newsletter/big-data-highlights-issue-3_
en.pdf. (Accessed February, 2023).
	69.	European Medicines Agency. Pilot on using raw data in medicine evaluation (new). 
(2022). Available at: https://www.ema.europa.eu/en/about-us/how-we-work/big-
data#pilot-on-using-raw-data-in-medicine-evaluation-(new)-section. (Accessed July, 
2022).
	70.	European Medicines Agency. Information about the raw data proof-of-concept pilot 
for industry. (2022). Available at: https://www.ema.europa.eu/en/documents/other/
information-about-raw-data-proof-concept-pilot-industry_en.pdf. (Accessed July, 
2022).
	71.	European Medicines Agency. European medicines regulatory network data 
standardisation strategy. (2021). Available at: https://www.ema.europa.eu/en/
documents/other/european-medicines-regulatory-network-data-standardisation-
strategy_en.pdf. (Accessed July, 2022).
	72.	European Medicines Agency. Data Standardisation Strategy. (2021). Available at: 
https://www.ema.europa.eu/en/about-us/how-we-work/big-data#data-standardisation-
strategy-section. (Accessed July, 2022).
	73.	U.S. Food and Drug Administration. Source data capture from electronic health 
records (EHRs): Using standardized clinical research data (Onesource phase I). (2021). 
Available at: https://www.fda.gov/science-research/advancing-regulatory-science/
source-data-capture-electronic-health-records-ehrs-using-standardized-clinical-
research-data. (Accessed July, 2022).
	74.	U.S. Food and Drug Administration. Driving medical product development. (2022). 
Available at: https://www.fda.gov/about-fda/2021-oce-annual-report/driving-medical-
product-development. (Accessed September, 2022).
	75.	Transcelerate Biopharma Inc. Real world data. (2022). Available at: https://www.
transceleratebiopharmainc.com/initiatives/real-world-data/. (Accessed July, 2022).
	76.	Collaborative TSHR. Icaredata® Project. (2022). Available at: http://icaredata.org/. 
(Accessed September, 2022).
	77.	Harmony Alliance. Big data platform. (2021). Available at: https://www.harmony-
alliance.eu/bigdata-platform/big-data-platform. (Accessed May, 2022).
	78.	Facile R, Muhlbradt EE, Gong M, Li Q, Popat V, Petavy F, et al. Use of clinical data 
interchange standards consortium (Cdisc) standards for real-world data: expert 
perspectives from a qualitative Delphi survey. JMIR Med Inform. (2022) 10:e30363. doi: 
10.2196/30363
	79.	Allen A, Patrick H, Ruof J, Buchberger B, Varela-Lema L, Kirschner J, et al. 
Development and pilot test of the registry evaluation and quality standards tool: an 
information technology-based tool to support and review registries. Value Health. 
(2022) 25:1390–8. doi: 10.1016/j.jval.2021.12.018
	80.	Medicines and Healthcare products Regulatory Agency. Consultation document: 
MHRA draft guidance on randomised controlled trials generating real-world evidence to 
support regulatory decisions. (2020). Available at: https://www.gov.uk/government/
consultations/mhra-draft-guidance-on-randomised-controlled-trials-generating-real-
world-evidence-to-support-regulatory-decisions/consultation-document-mhra-draft-
guidance-on-randomised-controlled-trials-generating-real-world-evidence-to-support-
regulatory-decisions. (Accessed July, 2020).
	81.	U.S. Food and Drug Administration. Considerations for the design and conduct of 
externally controlled trials for drug and biological products. (2023). Available at: https://
www.fda.gov/media/164960/download. (Accessed February, 2023).
	82.	National Medical Products Administration. Center for Drug Evaluation. Notice on 
public comments on the "guidelines for the design and protocol framework of drug real-
world research (draft for comment). (2022). Available at: https://www.cde.org.cn/main/
news/viewInfoCommon/ea778658adc3d1ae3ffe3f1cc0522e5e. (Accessed July, 2022).
	83.	Duke-Margolis Center for Health Policy. Point-of-care clinical trials: Integrating 
research and care delivery. (2022). Available at: https://healthpolicy.duke.edu/publications/
point-care-clinical-trials-integrating-research-and-care-delivery. (Accessed May, 2022).
	84.	Friends of Cancer Research. Scientific report: Regulatory advancements for patients. 
(2021). Available at: https://friendsofcancerresearch.org/wp-content/uploads/2021-
Friends-of-Cancer-Research-Scientific-Report.pdf. (Accessed May, 2022).
	85.	U.S. Food and Drug Administration. Submitting documents using real-world data 
and real-world evidence to FDA for drug and biological products. (2022). Available at: 
https://www.fda.gov/media/124795/download. (Accessed September, 2022).
	86.	National Medical Products Administration. Center for Drug Evaluation. Notice on 
public comments on "guidelines for communication and exchange of real-world evidence 
supporting drug registration applications (draft for comment)" (article in Chinese). (2022). 
Available at: https://www.cde.org.cn/main/news/viewInfoCommon/615fd3bb95212b
ff2076c9091958aed2. (Accessed October, 2022).
	87.	Taiwan Food and Drug Administration. Precautions for the use of real-world data/
real-world evidence as technical documents for drug review applications (article in 
Chinese). 
(2021). 
Available 
at: 
https://www.fda.gov.tw/TC/siteListContent.
aspx?sid=9354&id=37181. (Accessed June, 2022).
	88.	European Commission. New interoperable Europe act to deliver more efficient public 
services through improved cooperation between National Administrations on data 
exchanges and IT solutions. (2022). Available at: https://ec.europa.eu/commission/
presscorner/detail/%20en/ip_22_6907. (Accessed February, 2023).
	89.	U.S. Food & Drug Administration. FDA announces new funding opportunity for 
using real-world data to generate real-world evidence in regulatory decision-making. 
(2022). Available at: https://grants.nih.gov/grants/guide/rfa-files/RFA-FD-23-025.html. 
(Accessed January, 2023).
	90.	Jaksa A, Wu J, Jonsson P, Eichler HG, Vititoe S, Gatto NM. Organized structure of 
real-world evidence best practices: moving from fragmented recommendations to 
comprehensive guidance. J Comp Eff Res. (2021) 10:711–31. doi: 10.2217/cer-2020-0228
	91.	Patient-Centered Outcomes Research Institute. Policy for data management and 
data sharing. (2018). Available at: https://www.pcori.org/sites/default/files/PCORI-
Policy-for-Data-Management-and-Data-Sharing.pdf. (Accessed February, 2023).
	92.	International Coalition of Medicines Regulatory Authorities. ICMRA statement on 
international collaboration to enable real-world evidence (Rwe) for regulatory decision-
making. (2022). Available at: https://www.icmra.info/drupal/sites/default/files/2022-07/
icmra_statement_on_rwe.pdf. (Accessed July, 2022).
	93.	U.S. Food & Drug Administration. Project Orbis. (2022). Available at: https://www.
fda.gov/about-fda/oncology-center-excellence/project-orbis. (Accessed September, 2022).
	94.	Scoiety for Translational Oncology. Global harmonization of Cancer trials. (2022). 
Available at: https://sto-online.org/Initiatives/GHCT. (Accessed December, 2022).
	95.	Wang T, McAuslane N, Liberti L, Leufkens H, Hovels A. Building synergy between 
regulatory and HTA agencies beyond processes and procedures-can we effectively align 
the evidentiary requirements? A survey of stakeholder perceptions. Value Health. (2018) 
21:707–14. doi: 10.1016/j.jval.2017.11.003
	96.	Ofori-Asenso R, Hallgreen CE, De Bruin ML. Improving interactions between 
health technology assessment bodies and regulatory agencies: a systematic review and 
cross-sectional survey on processes, Progress, outcomes, and challenges. Front Med 
(Lausanne). (2020) 7:582634. doi: 10.3389/fmed.2020.582634
	97.	Duke-Margolis Center for Health Policy. Aligning shared evidentiary needs among 
payers and regulators for a real-world data ecosystem. Duke-Margolis Center for Health 
Policy (2022).
	98.	Duke-Margolis Center for Health Policy. Adding real-world evidence to a totality 
of evidence approach for evaluating marketed product effectiveness. (2019). Available at: 
https://healthpolicy.duke.edu/sites/default/files/2020-08/Totality%20of%20
Evidence%20Approach.pdf. (Accessed September, 2022).
	99.	De Sante HA. Real-world studies for the assessment of medicinal products and 
medical devices. (2021). Available at: https://www.has-sante.fr/jcms/p_3284524/en/real-
world-studies-for-the-assessment-of-medicinal-products-and-medical-devices. 
(Accessed June, 2022).
	100.	Kent S, Salcher-Konrad M, Boccia S, Bouvy JC, Waure C, Espin J, et al. The use 
of nonrandomized evidence to estimate treatment effects in health technology 
assessment. J Comp Eff Res. (2021) 10:1035–43. doi: 10.2217/cer-2021-0108
	101.	National Institute for Health and Care Excellence. Nice real-world evidence 
framework. (2022). Available at: https://www.nice.org.uk/corporate/ecd9/chapter/
introduction-to-real-world-evidence-in-nice-decision-making. (Accessed June, 2022).

## Page 15 (Section: Author contributions)

Burns et al.
10.3389/fmed.2023.1236462
Frontiers in Medicine
15
frontiersin.org
	102.	European Health Data and Evidence Network. Regulators are formally adopting 
real world evidence, when will health technology assessment? (2022). Available at: https://
www.ehden.eu/regulators-are-formally-adopting-real-world-evidence-when-will-
health-technology-assessment/. (Accessed February, 2023).
	103.	Tafuri G, Pagnini M, Moseley J, Massari M, Petavy F, Behring A, et al. How aligned 
are the perspectives of EU regulators and HTA bodies? A comparative analysis of regulatory-
HTA parallel scientific advice. Br J Clin Pharmacol. (2016) 82:965–73. doi: 10.1111/bcp.13023
	104.	Wonder M, Backhouse ME, Hornby E. Early scientific advice obtained 
simultaneously from regulators and payers: findings from a pilot study in Australia. 
Value Health. (2013) 16:1067–73. doi: 10.1016/j.jval.2013.07.007
	105.	European Medicines Agency. Parallel joint scientific consultation with regulators and 
health technology assessment bodies. (2022). Available at: https://www.ema.europa.eu/en/
human-regulatory/research-development/scientific-advice-protocol-assistance/parallel-joint-
scientific-consultation-regulators-health-technology-assessment-bodies. (Accessed May, 2022).
	106.	European Medicines Agency. Guidance on parallel EMA/EUnetHTA 21 joint 
scientific consultation. (2022). Available at: https://www.ema.europa.eu/en/documents/
regulatory-procedural-guideline/guidance-parallel-ema/eunethta-21-joint-scientific-
consultation_en.pdf. (Accessed January, 2023).
	107.	Government of Canada. Optimizing the use of real world evidence to inform 
regulatory decision-making. (2019). Available at: https://www.canada.ca/en/health-
canada/services/drugs-health-products/drug-products/announcements/optimizing-
real-world-evidence-regulatory-decisions.html. (Accessed June, 2022).
	108.	Canada's Drug and Health Technology Agency. CADTH expands scientific advice 
program to include advice on real-world evidence. (2022). Available at: https://www.cadth.
ca/news/cadth-expands-scientific-advice-program-include-advice-real-world-evidence. 
(Accessed May, 2022).
	109.	Tafuri G, Lucas I, Estevao S, Moseley J, d'Andon A, Bruehl H, et al. The 
impact of parallel regulatory-health technology assessment scientific advice on 
clinical development. Assessing the uptake of regulatory and health technology 
assessment recommendations. Br J Clin Pharmacol. (2018) 84:1013–9. doi: 10.1111/
bcp.13524
	110.	National Institute for Health and Care Excellence. Appraisal consultation 
document [Ta559]-Axicabtagene Ciloleucel for treating diffuse large B-cell lymphoma and 
primary mediastinal B-cell lymphoma after 2 or more systemic therapies. (2018). Available 
at: 
https://www.nice.org.uk/guidance/ta559/documents/appraisal-consultation-
document. (Accessed September, 2022).


---

# Recent trends in RNA informatics: a review of machine learning and deep learning for RNA secondary structure prediction and RNA drug discovery

- **Authors:** Kengo Sato, Michiaki Hamada
- **Issuer:** Briefings in bioinformatics
- **Type:** Scientific article
- **Published:** 2023-07-20
- **Language:** en
- **DOI:** 10.1093/bib/bbad186
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37232359/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractComputational analysis of RNA sequences constitutes a crucial step in the field of RNA biology. As in other domains of the life sciences, the incorporation of artificial intelligence and machine learning techniques into RNA sequence analysis has gained significant traction in recent years. Historically, thermodynamics-based methods were widely employed for the prediction of RNA secondary structures; however, machine learning-based approaches have demonstrated remarkable advancements in recent years, enabling more accurate predictions. Consequently, the precision of sequence analysis pertaining to RNA secondary structures, such as RNA–protein interactions, has also been enhanced, making a substantial contribution to the field of RNA biology. Additionally, artificial intelligence and machine learning are also introducing technical innovations in the analysis of RNA–small molecule interactions for RNA-targeted drug discovery and in the design of RNA aptamers, where RNA serves as its own ligand. This review will highlight recent trends in the prediction of RNA secondary structure, RNA aptamers and RNA drug discovery using machine learning, deep learning and related technologies, and will also discuss potential future avenues in the field of RNA informatics.Keywords: RNA informatics, RNA secondary structure prediction, RNA-based therapeutics

## Section: INTRODUCTION

The central dogma posits that RNA functions solely as a conduit for the transfer of genetic information from DNA to proteins. Messenger RNAs (mRNAs) perform this role as information carriers. However, a number of exceptions to this paradigm have been discovered, involving RNA molecules participating in a diversity of functions. Transfer RNAs (tRNAs) function in the translation of the triplet codons of mRNAs into amino acids according to the genetic code. Ribosomal RNAs (rRNAs) constitute a primary component of ribosomes and catalyze protein synthesis as ribozymes. Micro RNAs (miRNAs) are involved in RNA silencing and post-transcriptional regulation of gene expression. Small nuclear RNAs (snRNAs) participate in the processing of pre-messenger RNAs within the nucleus. Long noncoding RNAs (lncRNAs), non-protein-coding RNAs with sequences longer than 200 bases, have been demonstrated to have various functions such as gene transcriptional regulation, translational regulation and epigenetic regulation [1]. The diversity of RNA species has been cataloged in databases such as Rfam [2–5] and RNAcentral [6], and the number of RNA species continues to grow.

Many of these functional RNAs execute their functions by adopting tertiary structures that are evolutionarily conserved among RNA species. The experimental determination of RNA tertiary structures can be achieved through techniques such as X-ray crystallography, nuclear magnetic resonance (NMR) and cryo-electron microscopy (cryo-EM); however, these methods are both labor-intensive and cost-prohibitive for high-throughput analysis. As an alternative, RNA secondary structures are often targeted for structural and functional analysis of functional RNAs. An RNA secondary structure is defined as a set of base pairs with hydrogen bonds between two nucleotides, which makes a significant contribution to the tertiary structure in terms of free energy. This means that the folding of RNA is hierarchical in that tertiary interactions can be added without much distortion of the secondary structure [7]. It is well established that RNA secondary structures are also evolutionarily conserved among RNA species. For instance, a multiple sequence alignment of 10 tRNAs extracted from the Rfam database (Figure 1A), in which secondary structures are considered, yields the well-known and evolutionarily conserved cloverleaf shape (Figure 1C). In contrast, a multiple sequence alignment based on sequence identity alone, calculated using Clustal Omega [8], does not preserve the secondary structure at all, as shown in Figure 1B. This suggests that functional RNAs are evolutionarily conserved in their structures, rather than in their sequences and that structure correlates with function. Thus, RNA informatics has extensively studied RNA sequence analysis based on their secondary structures.

RNA secondary structure prediction, which has been a subject of study since the 1970s, constitutes a foundational technology in RNA sequence analysis. One of the pioneered works in this field was the Nussinov algorithm [10], which used dynamic programming to calculate the secondary structure with the maximum number of base pairs, under the assumption that the free energy of RNA structures decreases as base pairs are formed, thereby resulting in greater stability. Minimizing free energy using thermodynamic free energy parameters, such as Turner’s free energy parameters [11–13], is a widely used approach for predicting RNA secondary structures [11, 14–18]. However, these thermodynamics-based methods have a drawback in that they are limited by experimental technicalities in increasing the number and improving the quality of the free energy parameters. To address this issue, ‘assisted folding’ with high-throughput experiments involving chemical probing has been frequently employed. Selective 2’-hydroxyl acylation analyzed by primer extension (SHAPE) [19] and dimethyl sulphate (DMS) [20] are examples of high-throughput experiments that can induce chemical modifications on unpaired nucleotides, which can improve the accuracy of secondary structure prediction.

To address the drawback of the thermodynamics-based methods without wet-laboratory experiments, machine learning-based methods have been widely used. These methods learn their parameters from training data that include RNA sequences and their corresponding secondary structures, thus, more accurate models can be constructed by increasing the number of parameters if a sufficient amount of non-biased training data can be obtained. For example, compared with CONTRAfold [21, 22], which has approximately 300 parameters, ContextFold [23] learns a much richer parameter set of approximately 200k parameters from training data, resulting in the ability to predict RNA secondary structures with remarkable accuracy at the time. However, as discussed later, it has been shown that ContextFold’s rich parameterization can easily lead to low prediction accuracy due to overfitting to the training data [24, 25].

Another approach to further improve prediction accuracy is to incorporate evolutionary information from homologous sequences [26–31]. This approach is potentially very powerful, but it is a different problem from the de novo prediction from single sequences discussed in this review, because this approach incorporates much more information from homologous sequences. In addition, there are few RNA secondary structure prediction algorithms that incorporate evolutionary information in machine learning, and thus this category will not be addressed in this review.

Subsequent tasks include analyses utilizing the results of RNA secondary structure predictions, such as clustering [32, 33], family classification [34, 35], structural RNA detection [36, 37] and degradation prediction [38]. Machine learning techniques are frequently employed in these tasks as well.

With the aforementioned fundamental advancements in RNA informatics, the practical application of RNA research is also progressing at a rapid pace. One such application is RNA drug discovery, which is highly anticipated as a next-generation drug discovery modality. Research on RNA aptamers and mRNA vaccines, in which RNA itself serves as a therapeutic agent, and RNA-targeted drug discovery, in which RNA functions as an alternative drug target to proteins, is of particular interest. Additionally, the application of RNA bioinformatics research utilizing technologies such as machine learning and deep learning is required in these areas, and research is being conducted from various perspectives, including RNA structure.

In this review, we will present recent trends in the prediction of RNA secondary structures utilizing machine learning, deep learning and related technologies. Additionally, we will provide an overview of significant advancements in computational tasks that employ RNA secondary structure information, including the prediction of RNA–protein interactions and RNA drug discovery.

Conserved secondary structures of transfer RNAs. (A) A multiple sequence alignment of 10 tRNAs extracted from the Rfam database is depicted, along with the annotated secondary structure. A string consisting of ‘.’, ‘(’ and ‘)’ at the top of the multiple alignment is the dot-bracket notation that represents the secondary structure. (B) A multiple sequence alignment based on sequence identity was calculated with Clustal Omega [8] for the 10 tRNAs. (C) The conserved secondary structure annotated by the Rfam database was visualized using VARNA [9]. Each colored region of base pairs corresponds to the acceptor stem (blue), D arm (red), anticodon arm (yellow) and T arm (green), respectively.

## Section: RNA SECONDARY STRUCTURE PREDICTION

An RNA secondary structure with pseudoknots. The arcs connecting the two nucleotides represent base pairs. Since pseudoknot structures are non-nested, the arcs representing base pairs cross each other when the structure is drawn on a 2D plane.

A schematic diagram of de novo RNA secondary structure prediction algorithms. Most RNA secondary structure prediction algorithms can be categorized by three aspects: ‘Architecture’, ‘Parameterization’ and ‘Inference’. Rivas et al. [25] added ‘Scoring scheme’ to these aspects, which is uniquely determined by ‘Parameterization’, and thus ‘Scoring scheme’ is omitted in this paper. From the ‘Architecture’ aspect, RNA secondary structure prediction algorithms can be categorized into nearest neighbor models, probabilistic generative models and deep learning models, depending on the RNA computational models. These are further sub-categorized according to their parameter assignment, fine-grainedness, grammatical rules etc. The ‘Parameterization’ aspect classifies RNA secondary structure prediction algorithms into three types, depending on how they find optimal parameter values for the parameter set defined in the ‘Architecture’: wet-lab experiments, machine learning and deep learning. Finally, the ‘Inference’ aspect classifies RNA secondary structure prediction algorithms according to how they use the models determined in the ‘Archtecture’ and ‘Parameterization’ to make secondary structure predictions.

The nearest neighbor model decomposes RNA secondary structures into loop substructures. Hairpin loops are closed by a single base pair. Loop substructures that are closed by two base pairs with no unpaired bases are called stackings, those with unpaired bases on one strand are called bulge loops and those with unpaired bases on both strands are called internal loops. Multi-branch loops are loop substructures that are closed by three or more base pairs. Loop substructures closed by no base pairs are called external loops.

List of de novo RNA secondary structure prediction tools presented in this paper that are currently available.

Benchmark datasets commonly used in recent machine learning- and deep learning-based methods.

## Section: RNA SECONDARY STRUCTURE PREDICTION › What is RNA secondary structure prediction?

An RNA sequence is a sequence composed of four types of nucleotides: adenine (A), cytosine (C), guanine (G) and uracil (U). An RNA secondary structure is defined as a set of base pairs with hydrogen bonds between two nucleotides. Thus, the problem of RNA secondary structure prediction is to predict which two nucleotides in a given RNA sequence form base pairs. Typically, we consider only the Watson–Crick base pairs (A-U and G-C), which are the most prevalent, as well as the wobble base pairs (G-U), which are the next most common, in RNA secondary structure predictions. Other non-canonical base pairs are of great significance for tertiary structures, but they are much more challenging to model computationally, since each base is not guaranteed to form a base pair with at most one other base. An RNA secondary structure can be represented by a string in the dot-bracket notation, where two bases at the corresponding open and close brackets (‘(’ and ‘)’) form a base pair, while a base at the dot (‘.’) does not form a base pair with any base, as shown at the top of the multiple alignment in Figure 1A. A secondary structure that requires only one type of bracket for its dot-bracket notation, resulting in fully nested base pairs, is referred to as a pseudoknot-free secondary structure. Conversely, a substructure consisting of non-nested base pairs, as depicted in Figure 2, where the bases inside the loop form base pairs with the bases outside the loop, is called a pseudoknot. To describe a pseudoknot in the dot-bracket notation, two or more types of brackets (e.g. ‘[’ and ‘]’) are required. RNA secondary structure prediction including pseudoknots has been proven to be NP-hard for optimal solutions with no limitations on the complexity of pseudoknots [39, 40]. Therefore, approximations that restrict the complexity of pseudoknots or introduce heuristics are common approaches.

An RNA secondary structure with pseudoknots. The arcs connecting the two nucleotides represent base pairs. Since pseudoknot structures are non-nested, the arcs representing base pairs cross each other when the structure is drawn on a 2D plane.

## Section: RNA SECONDARY STRUCTURE PREDICTION › Computational models

De novo computational modeling of RNA secondary structures can be broadly classified into three categories: nearest neighbor models, probabilistic generative models and deep learning models. This subsection provides an overview of these models and their implementations, along with a comparison of the three models. Figure 3 shows a schematic diagram of de novo RNA secondary structure prediction algorithms discussed in this subsection. Additionally, the datasets utilized for constructing models for predicting RNA secondary structures will be discussed.

A schematic diagram of de novo RNA secondary structure prediction algorithms. Most RNA secondary structure prediction algorithms can be categorized by three aspects: ‘Architecture’, ‘Parameterization’ and ‘Inference’. Rivas et al. [25] added ‘Scoring scheme’ to these aspects, which is uniquely determined by ‘Parameterization’, and thus ‘Scoring scheme’ is omitted in this paper. From the ‘Architecture’ aspect, RNA secondary structure prediction algorithms can be categorized into nearest neighbor models, probabilistic generative models and deep learning models, depending on the RNA computational models. These are further sub-categorized according to their parameter assignment, fine-grainedness, grammatical rules etc. The ‘Parameterization’ aspect classifies RNA secondary structure prediction algorithms into three types, depending on how they find optimal parameter values for the parameter set defined in the ‘Architecture’: wet-lab experiments, machine learning and deep learning. Finally, the ‘Inference’ aspect classifies RNA secondary structure prediction algorithms according to how they use the models determined in the ‘Archtecture’ and ‘Parameterization’ to make secondary structure predictions.

The nearest neighbor model decomposes RNA secondary structures into loop substructures. Hairpin loops are closed by a single base pair. Loop substructures that are closed by two base pairs with no unpaired bases are called stackings, those with unpaired bases on one strand are called bulge loops and those with unpaired bases on both strands are called internal loops. Multi-branch loops are loop substructures that are closed by three or more base pairs. Loop substructures closed by no base pairs are called external loops.

List of de novo RNA secondary structure prediction tools presented in this paper that are currently available.

## Section: RNA SECONDARY STRUCTURE PREDICTION › Computational models › Nearest neighbor models

The nearest neighbor model, which has been extensively utilized in the prediction of RNA secondary structures [11, 41–43], decomposes an RNA secondary structure into loop substructures with hairpin loops, stackings, bulge loops, internal loops, multi-branch loops and external loops, depending on the number of closing base pairs, as depicted in Figure 4. Each loop substructure is parametrized with several types of components, characterized by nucleotides in loops, the length of loops and other such factors, which are referred to as the energy parameters. The values assigned to each energy parameter are determined through either experimental methods or machine learning techniques. The free energy of each decomposed loop substructure is computed as the sum of the values of the energy parameters that characterize the loop substructure. The free energy of a given RNA secondary structure can be calculated as the sum of the free energies of the loop substructures that are decomposed from the given RNA secondary structure. Zuker et al. [44] established an efficient algorithm, known as the Zuker algorithm, which is based on the dynamic programming technique to find a secondary structure that minimizes the free energy among all possible secondary structures formed by a given RNA sequence. Many RNA secondary structure prediction methods that model RNA secondary structures without pseudoknots and employ the nearest neighbor model use the Zuker algorithm to find the minimum free energy (MFE) structures. The Zuker algorithm has a computational complexity of in time and in space for an RNA sequence of length . Recently, the LinearFold algorithm [45] has been developed, which finds MFE structures accurately and approximately with computational complexity in both time and space using the beam search technique. The key differences among the implementations of the Zuker algorithm or the LinearFold algorithm are the parametrization of the loop substructures and the determination of each value assigned to their energy parameters.

The methodology used to determine the energy parameters can be broadly classified into two approaches. The first approach involves determining the free energy parameters through wet-laboratory experiments, which is beyond the scope of this review; for further details, see the reference [46]. Examples of tools that fall under this approach include Mfold/UNAfold [14, 15], RNAfold in the ViennaRNA package [16, 17] and RNAstructure [11, 18]. Turner’s free energy parameters [11–13] are widely used in these thermodynamics-based approaches, and consist of up to approximately 12 700 parameters.

The second approach to determining energy parameters utilizes machine learning techniques to learn them from a large dataset of pairs of RNA sequences and their corresponding secondary structures. CONTRAfold [21, 22] used conditional log-linear models (CLLMs) to train approximately 300 parameters of the nearest neighbor model, resulting in high accuracy in predicting RNA secondary structures with significantly fewer parameters than Turner’s free energy parameters. Since the machine learning-based approach does not depend on wet-lab experiments, it allows for the development of a more comprehensive parametrization. For example, ContextFold [23] employed a fine-grained RNA secondary structure model with a parameter set of more than 200 000, resulting in the state-of-the-art prediction accuracy at the time. However, Rivas et al. [24, 25] pointed out that ContextFold had poor accuracy in predicting secondary structures for families not included in the training data, and was likely to fall into overfitting.

Several hybrid tools that combine both the thermodynamics- and machine learning-based approaches have been developed. SimFold [47, 48] modifies Turner’s free energy parameters to fit training data through the machine learning-based approach using training data including triplets of RNA sequences and their secondary structure as well as their free energies. MXfold [49] combines Turner’s energy parameters with rich-parametrized parameters trained by a max-margin framework, called structured support vector machines. It learns more precise parameters for substructures observed in the training data, reducing overfitting using thermodynamic parameters for unobserved substructures. MXfold2 [50], the successor of MXfold, utilizes deep learning to compute four types of scores for loop substructures: helix stacking scores, helix opening scores, helix closing scores and unpaired region scores, and combines them with Turner’s energy parameters, resulting in highly accurate and robust secondary structure prediction with a reduced risk of overfitting.

The majority of methods developed thus far predict RNA secondary structures based on the MFE under a given set of energy parameters. As the distribution of RNA secondary structures follows the Boltzmann distribution, the MFE is equivalent to the maximum likelihood estimation (MLE), which predicts a secondary structure with the maximum probability under the Boltzmann distribution. An alternative scheme, known as the maximum expected accuracy (MEA) approach, has been proposed, which predicts a secondary structure that maximizes the expected number of correctly predicted base pairs under the Boltzmann distribution, rather than predicting the MFE or MLE structure. The expected number of correctly predicted base pairs is calculated using the McCaskill algorithm [51], which is derived by replacing the ‘min’ operation of the Zuker algorithm with the ‘logsumexp’ operation. This scheme, first proposed in Knudsen et al.[52], is also implemented in various tools, such as CONTRAfold, RNAfold and RNAstructure. Additionally, Hamada et al.[53] have redefined MEA to be more compatible with the accuracy metrics for predicting RNA secondary structures, and developed CentroidFold [53, 54] using Turner’s parameters, CONTRAfold’s parameters and the Boltzmann likelihood parameters by Andronescu et al. [48].

The nearest neighbor model for pseudoknot-free structures was extended by incorporating additional parameters for pseudoknot substructures, and thus nearest neighbor models for pseudoknots, such as the Rivas–Eddy model [55], the Dirks–Pierce model [56] and the Cao–Chen model [57], were developed to model RNA secondary structures that include pseudoknots. Algorithms to compute exact minimum free energies on these models through dynamic programming have been implemented as PKNOTS [55] and NUPACK [56], with a significant computational cost of time for PKNOTS, time for NUPACK, and space for both for the limited complexity of pseudoknotted structures. For more accurate prediction of secondary structures including pseudoknots, further efforts were made to use machine learning techniques to estimate more accurate energy parameters. Andronescu et al. [58] used HotKnots [59], which can rapidly predict pseudoknotted structures through heuristics on the Dirks–Pierce model, to train its parameters from training data using the same methodology as SimFold. In contrast, IPknot [60, 61] utilizes the results of learning the parameters of the nearest neighbor model for pseudoknot-free structures, such as CONTRAfold, from training data and forcibly predicts pseudoknotted structures through a heuristic using integer programming.

The nearest neighbor model decomposes RNA secondary structures into loop substructures. Hairpin loops are closed by a single base pair. Loop substructures that are closed by two base pairs with no unpaired bases are called stackings, those with unpaired bases on one strand are called bulge loops and those with unpaired bases on both strands are called internal loops. Multi-branch loops are loop substructures that are closed by three or more base pairs. Loop substructures closed by no base pairs are called external loops.

## Section: RNA SECONDARY STRUCTURE PREDICTION › Computational models › Probabilistic generative models

The use of stochastic context-free grammars (SCFGs) as a probabilistic generative model for modeling RNA secondary structures without pseudoknots was first proposed by Eddy and Durbin [62] and Sakakibara et al. [63]. A variant of this approach, known as covariance models, has been applied to the popular RNA homology search tool, Infernal [64]. Building covariance models requires highly accurate RNA multiple sequence alignments, which enable accurate and robust homology searches due to the evolutionary information provided by the alignment. Pfold [52, 65] is a method for RNA secondary structure prediction that utilizes simple context-free grammars. Dowell et al. [66] compared nine lightweight grammars for RNA secondary structure prediction, including the Pfold grammar. Sato et al. [67] proposed a method for learning RNA grammars with appropriate complexity using a non-parametric Bayesian approach. TORNADO [24] is a flexible framework that can describe a variety of RNA grammars, allowing SCFGs to emulate the nearest neighbor model with Turner’s parameters or CONTRAfold, and demonstrated prediction accuracy comparable with their counterparts.

Since RNA secondary structure prediction including pseudoknots is beyond the capacity of context-free grammars, context-sensitive grammars, such as tree-adjoining grammars [68, 69] and multiple context-free grammars [70], are alternatively used for predicting pseudoknotted structures. However, due to their large computational complexity, it is impractical to use them for secondary structure prediction including pseudoknots.

## Section: RNA SECONDARY STRUCTURE PREDICTION › Computational models › Deep Learning models

Deep learning techniques have been leveraged to achieve groundbreaking advancements in a plethora of fields, including the life sciences, and have been applied to the prediction of RNA secondary structures. A majority of deep learning-based methods for RNA secondary structure prediction make no assumptions about the structures themselves, such as the nearest neighbor model and probabilistic generative models. Instead, these methods perform secondary structure prediction by solving multiple binary classification problems for all combinations of two bases in a given RNA sequence, determining whether each of the two bases form a base pair or not. In order to address the constraints that RNA secondary structures must satisfy, such as the restriction that each base can only form a base pair with at most one other base, methods such as E2Efold [71] and UFold [72] utilize linear programming, while Akiyama et al. [73] employ integer programming, originated from IPknot [60, 61]. SPOT-RNA [74] did not aim to solve such constraints, instead attempting to predict base triplets, and employed ensemble of multiple networks with different hyperparameters to mitigate overfitting. UFold, on the other hand, aimed to reduce overfitting by utilizing data augmentation, through the random generation of a large number of artificial RNA sequences and their secondary structures predicted by CONTRAfold, as additional training data.

Unlike other deep learning-based approaches, MXfold2 [50] employs deep learning to infer the energy of decomposed loop substructures within the nearest neighbor model, subsequently utilizing the Zuker algorithm to predict RNA secondary structures. To mitigate overfitting, MXfold2 introduces thermodynamic regularization, ensuring that the energy of the secondary structure calculated by MXfold2 does not deviate significantly from the free energy calculated using Turner’s parameters.

It has been acknowledged that the utilization of deep learning for RNA secondary structure prediction can easily result in overfitting, owing to the high number of parameters that require training. This implies that the accuracy of secondary structure prediction for structurally dissimilar RNA sequences from the training data is not particularly high if no efforts are taken to prevent overfitting [50, 73, 75, 76]. For example, E2Efold [71] was not designed against overfitting, and in their benchmark experiments, the training and test datasets were created by randomly splitting a single dataset. Consequently, overfitting could not be detected because structurally similar sequences were included in training and test datasets. This resulted in very low prediction accuracy of E2Efold for families not included in the training data, which is unfortunately not practical.

## Section: RNA SECONDARY STRUCTURE PREDICTION › Computational models › Comparison of the three computational models

Table 1 summarizes the de novo RNA secondary structure prediction tools presented in this review that are currently available. The nearest neighbor model is based on the knowledge of RNA secondary structures, which has been extensively studied for a long time. To date, the mainstream approach for predicting RNA secondary structures has been to conduct wet-lab experiments or employ machine learning techniques to determine the energy parameters of the nearest neighbor model. Probabilistic generative models, on the other hand, provide a framework for describing RNA structure modeling through the use of formal grammars. As demonstrated by Rivas et al. [24], the nearest neighbor model can be articulated by SCFGs, with prediction accuracy that is comparable with that of its nearest neighbor model counterpart. However, to date, no RNA grammar has been developed that surpasses the prediction accuracy of the nearest neighbor model.

Conversely, full deep learning methods, with the exception of MXfold2, do not rely on knowledge of RNA secondary structures, thereby allowing for a high degree of freedom in model construction. This can lead to improved fitting of the training data, and thus high prediction accuracy for RNA sequences with structures similar to those in the training data. However, this also increases the risk of overfitting and poor prediction accuracy for structurally dissimilar sequences. The problem of overfitting is a prevalent issue not only in deep learning but also in other machine learning techniques with rich parametrization; it is particularly acute in deep learning as models can easily be scaled to an enormous number of parameters [75, 78].

List of de novo RNA secondary structure prediction tools presented in this paper that are currently available.

## Section: RNA SECONDARY STRUCTURE PREDICTION › Datasets for building models

Frequently employed benchmark datasets for RNA secondary structure prediction are summarized in Table 2, which include RNA STRAND dataset [79], Archive II dataset [80] and RNAStralign dataset [81]. These benchmark datasets were constructed by compiling RNA sequences with known and reliable secondary structures from various databases such as Comparative RNA Web (CRW) Site [83], tmRNA database [84], Sprinzl tRNA Database [85], RNase P Database [86], SRP Database [84] and others. These benchmark datasets, however, are limited in their diversity of RNA secondary structures, containing only 8–10 RNA families. More recently, a more comprehensive dataset, bpRNA-1m dataset [82], has been constructed by incorporating RNA sequences with secondary structure annotations from Rfam 12.2 [4] in addition to RNA sequences derived from the aforementioned databases, comprising 102 318 sequences from approximately 2600 RNA families.

In many previously conducted benchmark experiments for RNA secondary structure prediction methods, these datasets have been randomly partitioned into training and test data for cross-validation. This means that the test data may not contain highly homologous sequences to those in the training data, but structurally similar sequences from the same families.

Rivas et al. [24, 25] have highlighted that accuracy evaluations utilizing ‘sequence-wise cross-validation’ cannot detect overfitting, and subsequently established TrainSetA, TestSetA, TrainSetB and TestSetB. TrainSetA and TestSetA were compiled from literature sources [21, 47, 48, 66, 85, 87], while TrainSetB and TestSetB, comprising 22 families with 3D structure annotations, were extracted from Rfam 10.0 [3]. The sequences in Train/TestSetB share less than 70% sequence identity with the sequences in TrainSetA. It is worth mentioning that the literature-based TrainSetA and Rfam-based TestSetB share no families and are structurally dissimilar, while TrainSetA and TestSetA exhibit some structural similarity. By conducting ‘family-wise cross-validation’, in which training is performed using TrainSetA and subsequently testing with TestSetB, Rivas et al. [24, 25] demonstrated that ContextFold, which exhibits an extremely high prediction accuracy in sequence-wise cross-validation, is prone to overfitting. Similar trends have been reported for deep learning-based methods by Szikszai et al. [75].

To further perform family-wise cross-validation on models trained from a bpRNA-1m-based dataset, Sato et al. [50] constructed bpRNAnew dataset from approximately 1500 families newly discovered and registered with Rfam since the release of Rfam version 12.2 (January 2017), on which bpRNA-1m dataset is based.

In general, machine learning and deep learning algorithms operate under the assumption that training data are randomly and uniformly sampled from the population. However, this assumption is often invalidated, even in large datasets such as bpRNA-1m dataset, as novel RNA families continue to be discovered to this day. If prior knowledge of the family of a sequence of interest is available, a homology search tool such as Infernal [64] can be more accurate in predicting its structure. However, when no knowledge of the family is available, it is necessary to make RNA secondary structure predictions solely from the sequence in order to perform structural and functional analyses. Therefore, it is crucial to evaluate prediction accuracy in such situations through the use of family-wise cross-validation, avoiding methods with significantly lower accuracy for unknown families.

Benchmark datasets commonly used in recent machine learning- and deep learning-based methods.

## Section: APPLICATIONS OF RNAs TO THERAPEUTICS

Currently, the majority of pharmaceuticals consist of small molecules that target disease-associated proteins in small molecule drug discovery. However, the limitations of this approach are well known, and there is a pressing need for alternative drug modalities. To address these limitations, synthetic and natural RNAs have garnered significant attention as potential drug candidates and targets, respectively. This section outlines the use of machine-learning and deep-learning techniques in the discovery and development of RNA-based drugs, including the use of synthetic RNAs as drugs and natural RNAs as targets for drug discovery. We will also discuss the importance of RNA structures in these approaches (Figure 5B).

(A) Schematic representation of the RNA aptamer development process and (B) the significance of RNA structure in each RNA therapeutic approach. (A) The basic and exploratory research comprises multiple stages, encompassing HT-SELEX, candidate identification from the HT-SELEX output, assessment of the selected candidates’ activity and sequence truncation/optimization. (B) The importance of RNA structure (right) in three RNA-based therapeutics (left) that have been highlighted in this review.

## Section: APPLICATIONS OF RNAs TO THERAPEUTICS › RNA drug discovery—making RNAs into drugs › RNA aptamers

RNA aptamers are single-stranded RNA molecules that range in length from 20 to 50 bases and form specific three-dimensional structures based on their nucleotide sequence. These structures allow RNA aptamers to fit into the shape of target substances, such as disease-related proteins, and act as drugs; it is therefore important to consider RNA structures in aptamer design. RNA aptamers have several advantages over traditional drugs, including high affinity and specificity, the ability to be designed for a wide range of target molecules, including membrane proteins, and low immunogenicity. As a result, RNA aptamers are considered to be potential next-generation drugs. As of February 2022, only one RNA aptamer, Macugen® (pegaptanib), has been approved for the treatment of age-related macular degeneration.

The process of creating RNA aptamers follows a similar path to traditional drug development, comprising several stages such as basic and exploratory research, preclinical study, clinical study, application and production and distribution (Figure 5A). Many computational studies on RNA aptamers focus on the initial stage of basic and exploratory research, which is further divided into several steps. The first step involves obtaining candidate aptamer sequences using a technique called SELEX (Systematic Evolution of Ligands by EXponential enrichment) [88]. This process involves repeatedly binding and amplifying RNA sequences that bind strongly to the target from a pool of random sequences, enriching for aptamers with high binding activity. High-throughput sequencing techniques, known as HT-SELEX (High-Throughput SELEX), enable comprehensive measurement of the sequence information in the enriched sequence pool at each round, generating a large amount of sequence data in each round of HT-SELEX.

A number of computational approaches have been proposed to improve the identification of aptamers from HT-SELEX data [89–91], including sequence/structure clustering-based methods [92–94], motif-based methods [95, 96], scoring-based methods [97, 98] and so forth. Here, we review some of these approaches that utilize machine learning and deep learning and discuss their effective utilization.

Bashir et al. [99] proposed a machine learning (ML)-guided Particle Display methodology (MLPD), which integrates physical experiments and machine learning. They used particle display (PD) to partition aptamer libraries according to affinity and used these data to train machine learning models. This method allows for the in silico prediction of aptamer affinity, and the authors were able to successfully identify novel aptamers with enhanced affinity.

RaptGen [100] employs a combination of a variational autoencoder (VAE) and a profile hidden Markov model (HMM) to effectively model aptamers with local motifs that contain substitutions and indels. The latent spaces learned by RaptGen are used for several purposes: (i) visualizing SELEX data and generating novel aptamers, (ii) optimizing aptamers using Bayesian optimization with additional information, such as detailed affinity scores obtained through surface plasmon resonance experiments and (iii) designing shortened (truncated) aptamers, which is realized using shorter profile HMM in RaptGen model. While the current version of RaptGen does not take structural information of RNA into account, this can be addressed using a profile stochastic context grammar (SCFG; see the previous section) instead of a profile HMM.

Di Gioacchino et al. [101] created a restricted Boltzmann machine (RBM) model using SELEX data for thrombin, which is a probabilistic generative model capable of generating novel aptamer sequences (similar with RaptGen). They demonstrated that the log-likelihood of sequences correlates with their fitness (i.e. binding ability to the target).

Recently, Andress et al. [102] proposed a method called Daptev, which combines a deep generative model (VAE) and molecular simulation (molecular docking). As both data-driven and simulation-based approaches (considering tertiary structures of aptamers) can be useful for in silico aptamer design, this may be a promising approach.

Note that the above-mentioned approaches, such as RaptGen and MLPD, assume a target protein with experimental data (e.g. SELEX). More general (and difficult) problem setting that predicts pairs of aptamer-protein is introduced. AptaNet [103] uses a multi-layer perceptron (MLP) to predict aptamer–protein pairs, taking a pair of RNA and amino acid sequences as input. The training dataset for this model was compiled from Aptagen and Aptamer Base and consists of 850 positive and 2554 negative instances. In Torkamanian-Afshar et al. [104], a classifier for aptamer–protein pairs was trained using the sequential and structural properties of known aptamer–protein complexes, utilizing positive and negative data from RPINBASE [105]. This classifier was then used to select target-binding RNA sequences as a potential biomarker for aminopeptidase N (CD13). These sequences were utilized as the starting population for a genetic algorithm (GA) to generate new aptamers that exhibit higher selectivity for binding to CD13 compared with the original ones.

In contrast, a wealth of data on RNA sequences that bind to various natural RNA-binding proteins (RBPs) have been accumulated, and research utilizing these data through machine learning and deep learning methods is ongoing [106]. For example, Yamada et al. [107] proposed a BERT (Bidirectional Encoder Representations from Transformers)-based model for predicting RNA–protein interactions with biological implications, and Kashiwagi et al. [108] introduced a max-margin model for predicting residue-level contact in RNA–protein interactions. These studies on natural RBPs could potentially inform the design of artificial RNA aptamers that target proteins; for further details, see the reference [109].

As previously mentioned, beneficial machine learning techniques for in silico aptamer design have been developed in recent years and are anticipated to aid in the expansion of aptamer drug discovery in the future. Furthermore, the refinement of RNA structure prediction contributes significantly to the development of highly effective RNA aptamers.

## Section: APPLICATIONS OF RNAs TO THERAPEUTICS › RNA drug discovery—making RNAs into drugs › mRNA vaccines

Since 2020, the development of coronavirus disease 2019 vaccines such as BNT162b2 (Pfizer/BioNTech) and mRNA-1273 (Moderna) has been active, and the drug discovery modality of mRNA medicine has garnered significant attention [110–112]. mRNA vaccines have also been proposed as a potential therapeutic approach for cancer [113]. To facilitate the rapid production of mRNA vaccines, computational design of mRNA sequences is crucial, involving the comprehensive design of 5’ untranslated region (UTR), coding sequence (CDS) and 3’UTR sequences.

The sequence of the 5’UTR is closely correlated with translation efficiency. A study by Sample et al. [114] developed a convolutional neural network (CNN) model to predict Mean Ribosome Load (MRL), a measure of ribosome association, for given 5’UTR sequence. The authors used MRL measurements from 280 000 random 5’UTRs as a training dataset for the model. Utilizing this CNN model and a GA, the authors were able to generate 5’UTR sequences with a desired MRL value. These comprehensive data will be beneficial for 5’UTR design in the development of mRNA vaccines.

The sequence of CDS also impacts the abundance of translation. iCodon [115] is a tool designed to optimize coding regions that contain synonymous codon substitutions in order to increase mRNA stability and protein expression (e.g. designing high-expression reporters) or de-optimize sequences containing synonymous codon substitutions (e.g. designing sequences with reduced expression). The prediction model of mRNA stability is proposed in Medina-Muñoz et al. [116]. Zhang et al. [117] proposed an efficient method, named LinearDesign, for mRNA design by reducing it to a problem in computational linguistics. The optimal mRNA is analogous to finding the most probable sentence among similar-sounding alternatives. The algorithm takes 11 min for the Spike protein and can optimize stability and codon usage concurrently.

According to Leppek et al. [118], a method for optimizing the structure, stability and translation of mRNA through combinatorial means was introduced. Initially, viral and cellular UTRs mined from literature were procured, followed by structure-informed CDS design in which Eterna (crowdsourced) [77] and the LinearDesign were utilized as efficient design tools.

## Section: APPLICATIONS OF RNAs TO THERAPEUTICS › RNA-targeted drug discovery—making RNAs into drug target

Another challenge in drug discovery is the depletion of potential drug targets. Currently, disease-related proteins are the primary targets for drug discovery. Recent research has shown that lncRNAs play a vital role in a variety of intracellular regulatory processes in eukaryotes, including humans [119, 120]. Moreover, many lncRNAs have been found to be associated with serious diseases such as cancer and neurodegenerative disorders, making them potential new drug targets [121–123].

A strategy for RNA-targeted drug discovery is to design small molecules (i.e., traditional drugs) that bind to RNA structures in lncRNAs [124–126] and ribo-switches [127], indicating that the consideration of RNA structures is essential in this kind of researches. Although there exists limited studies for RNA–target drug discovery using machine learning [128], we will introduce a few studies in the following.

RNAmigos [129] is a tool that constructs and encodes network representations of RNA structures and predicts potential ligands for novel binding sites. It employs a graph convolutional neural network (GCN) to represent RNA structures as an Augmented Base Pairing Network (ABPN), including both canonical and non-canonical base-pairs. The training data were sourced from the RNA–ligand pairs in the RCSB PDB Data Bank [130].

A recent study by Yazdani et al. [131] that analyzed data from screening experiments suggests that there may be a correlation between the properties of RNA and the properties of small molecule ligands that bind to RNA. Using machine learning methods to analyze their own library of RNA-bound small molecules, the authors found that general chemical properties of RNA-bound small molecule compared with protein-bound small molecules and FDA-approved drugs.

Stefaniak et al. [132] developed AnnapuRNA, a machine-learning statistical scoring function, to accurately predict the structure of RNA-ligand complexes. Their program utilizes a coarse-grained representation for both the RNA and small molecule ligands involved in the interaction. On the other hand, Chhabra et al. [133] used a distance-dependent fingerprint to characterize the binding pose of a ligand in an RNA binding pocket (RNAPosers). They trained a machine-learning algorithm using data from 80 experimentally determined RNA–ligand complexes and used it to score docking poses.

Grimberg et al. [134] sought to design novel small molecule inhibitors that would bind to the RNA hairpin within the ribosomal peptidyl transferase center (PTC) of Mycobacterium tuberculosis through the use of computational optimization models integrating CNNs with classical machine learning regression and decision tree models, using approximately 800 training data points [135]. Upon synthesizing the 10 small molecules identified by these computational means, functional validation was conducted, revealing that four of the molecules were potent inhibitors targeting hairpin 91 in the ribosomal PTC of M. tuberculosis, thereby inhibiting translation. This study demonstrates the potential for optimizing RNA-binding drugs with sufficient training data.

It should be noted that all of the aforementioned methods assume targeted RNA elements of relatively small size. However, it is crucial to identify specific RNA elements (such as structures, modifications and binding sites of other biomolecules) that are suitable for drug targeting, as lncRNAs are lengthy and the location of functional elements can be challenging to determine. To this end, various approaches have been proposed, including infoRNA [136]. While machine learning-based approaches in this direction are limited, these approaches may prove useful in identifying functional elements in lncRNAs in the future if sufficient data are available.

## Section: CHALLENGES AND OPPORTUNITIES

The accuracy of RNA secondary structure prediction has considerably improved in recent years due to the utilization of machine learning and deep learning techniques. One potential avenue for further enhancement in prediction accuracy is the incorporation of evolutionary information from homologous sequences, which can be achieved through methods such as common secondary structure prediction from multiple sequence alignments [26, 27], probabilistic consistency transformation of base-pairing probabilities from homologous sequences [28, 29], MSA transformers [137] and the utilization of pre-trained large language models, such as BERT [107, 138, 139].

Additionally, high-throughput experiments such as selective 2’-hydroxyl acylation analyzed by primer extension (SHAPE) [19] and dimethyl sulphate (DMS) [20], which can stochastically induce chemical modifications on unpaired nucleotides, have been shown to improve the accuracy of secondary structure predictions. The incorporation of pseudo-free energy calculated using the reactivity of chemical probing from high-throughput experiments has also been shown to substantially enhance the accuracy of thermodynamics-based RNA secondary structure prediction [140]. However, despite the potential benefits, few machine learning methods have been developed to predict RNA secondary structures from RNA sequences with chemical reactivity due to a lack of a large amount of training data including not only RNA sequences and their structure, but also their chemical reactivities. EternaFold [77] augmented the accuracy of secondary structure prediction by refining the parameters of the nearest neighbor model via multitask learning with high-throughput experimental data that lack secondary structure annotations, thereby demonstrating the potential of using high-throughput experimental data in machine learning-based RNA secondary structure prediction. Currently, the accuracy of RNA secondary structure prediction is still insufficient for long RNA sequences longer than 500 bases. One of the reasons for this is that the number of long RNAs with known secondary structures is small, and models that can handle long sequences cannot be sufficiently trained by machine learning or deep learning. If secondary structure prediction models can be trained from high-throughput experimental data, which are easily available even for long sequences, the accuracy of secondary structure prediction for long sequences is expected to improve.

RNA modifications play a significant role in various biological processes including splicing, translation, cell development and disease [141, 142]. In mRNA vaccines, all uridines are modified to N1-methylpseudouridines, which enables them to bypass the Toll-like receptors (TLRs) that detect RNA viruses and thus produce viral proteins [143]. Due to the need for modified free energy parameters and potential alteration of base pairing partners, the development of RNA secondary structure prediction methods that can consider RNA modifications is limited [144]. However, as RNA modifications are more prevalent in vivo than previously thought, and the increasing demand for mRNA vaccine stability prediction and other applications make the development of highly accurate RNA modification-aware RNA secondary structure prediction by machine learning an urgent task. However, this is a challenging task due to the scarcity of data of RNA sequences containing modified bases with secondary structures available.

It is highly demanding to establish high-throughput methods for determining RNA 3D structures, not only for RNA structural and functional analysis, but also for RNA drug discovery and RNA-targeted drug discovery. AlphaFold2 [145] has achieved highly accurate protein 3D structure prediction comparable with experimental structure determination. Inspired by AlphaFold2, similar deep learning approaches have been applied to tackle RNA 3D structure prediction and have been reported to perform well on their datasets [146–148]. However, in the competition for RNA 3D structure prediction held at the most recent CASP 15 (https://predictioncenter.org/casp15/), these deep learning-based RNA 3D structure prediction methods were not at all comparable with conventional approaches. The number of 3D structures registered in Protein Data Bank (PDB) [149] is 173 649 for proteins, but only 1682 for RNAs (December 2022). Therefore, highly accurate RNA 3D structure prediction without falling into overfitting is presumed to be challenging with fully deep learning-based approaches like AlphaFold2.

## Section: CONCLUSION

In recent years, there has been a growing interest in structure-based RNA analysis, as it is believed that the function of many RNAs is closely related to their structures. In this paper, we have reviewed the latest advancements in RNA secondary structure prediction, which is a fundamental technique for structure-based RNA analysis, particularly in methods that utilize machine learning and deep learning. We have also discussed the use of machine learning and deep learning in RNA drug discovery and RNA-targeted drug discovery, which are among the most notable applications of structure-based RNA analysis in recent times. It is important to note that compared with proteins, there are orders of magnitude fewer known samples of RNA structures and interactions with other molecules. Therefore, when applying machine learning and deep learning techniques to analyze RNAs, it is essential to be cognizant of the fact that the training data may be small, biased or both, and to implement various strategies to enhance generalization capabilities.

## Section: ACKNOWLEDGMENTS

The authors thank the organizers and the attendees of the RNA Informatics Dojo 2022 in Miyazaki, Japan for fruitful discussions.

## Section: Author Biographies

Kengo Sato is a professor at Tokyo Denki University, Japan. He received his Ph.D. in Computer Science from Keio University, Japan, in 2003. His research interests include bioinformatics, computational linguistics and machine learning.

## Section: Author Biographies

Michiaki Hamada is a professor at Waseda University in Japan, and is concurrently appointed at National Institute of Advanced Industrial Science and Technology (AIST) and Nippon Medical University. He obtained his Ph.D. in Science from the Tokyo Institute of Technology in 2009. His research interests encompass RNA bioinformatics, drug discovery and artificial intelligence.

## Section: Contributor Information

Kengo Sato, School of System Design and Technology, Tokyo Denki University, 5 Senju Asahi-cho, Adachi-ku, Tokyo 120-8551, Japan.

Michiaki Hamada, Department of Electrical Engineering and Bioscience, Faculty of Science and Engineering, Waseda University, 55N-06-10, 3-4-1, Okubo, Shinjuku-ku, Tokyo 169-8555, Japan; Computational Bio Big-Data Open Innovation Laboratory (CBBD-OIL) , National Institute of Advanced Industrial Science and Technology (AIST), 3-4-1, Okubo, Shinjuku-ku, Tokyo 169-8555, Japan; Graduate School of Medicine, Nippon Medical School, 1-1-5, Sendagi, Bunkyo-ku, Tokyo 113-8602, Japan.

## Section: FUNDING

This work was partially supported by a Grant-in-Aid for Scientific Research (B) (No. 22H03689) from the Japan Society for the Promotion of Science (JSPS) to K.S., and by JST CREST (grant nos. JPMJCR1881 and JPMJCR21F1), AMED (Nos. 21479280, JP22ama121055) and JSPS KAKENHI (Nos. 22H04925, 20H00624, 17K20032) to M.H.


---

# Regulatory, health technology assessment and company interactions: the current landscape and future ecosystem for drug development, review and reimbursement

- **Authors:** Ting Wang, Neil McAuslane, Wim G Goettsch, Hubert G M Leufkens, Marie L De Bruin
- **Issuer:** International journal of technology assessment in health care
- **Type:** Scientific article
- **Published:** 2023-04-11
- **Language:** en
- **DOI:** 10.1017/s0266462323000144
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37039100/
- **Licence:** CC-BY

## Page 1 (Section: Regulatory, health technology assessment and company interactions: the current landscape and future ecosystem for drug development, review and reimbursement)

Regulatory, health technology assessment and
company interactions: the current landscape
and future ecosystem for drug development,
review and reimbursement
Ting Wang1,2
, Neil McAuslane1, Wim G. Goettsch2,3
, Hubert G.M. Leufkens2 and
Marie L. De Bruin2
1Centre for Innovation in Regulatory Science (CIRS), London, UK; 2Division of Pharmacoepidemiology and Clinical
Pharmacology, Utrecht Institute for Pharmaceutical Sciences, Utrecht University, Utrecht, The Netherlands and 3National
Health Care Institute, Diemen, The Netherlands
Abstract
Background: Multi-stakeholder interactions have evolved at product and policy levels. There is
a need to assess the current and future landscape of interactions between companies, and
regulatory and HTA agencies to address challenges and identify areas for improvement.
Objectives: The aims of this study were to review the current interactions within and across
regulatory and HTA agencies, and companies’ experiences in engaging in these activities; to
assess the added value of interactions as well as limitations; to explore the future ecosystem for
stakeholder interactions.
Method: Three separate questionnaires were developed for companies, regulators and HTA
agencies, respectively, to assess their experiences and perceptions. The responses were analyzed
using descriptive statistics and discussed at a multi-stakeholder workshop. Key outcomes from
the surveys and workshop discussion were reported.
Results: All seven regulators and seven HTA agencies in the survey indicated that they had
stakeholder interactions. More formal collaboration occurred with regulators compared with
HTA agencies. All nine companies have taken early advice but indicated the need for future
prioritization. Success indicators can be built at the product and therapy levels, with the added
value of faster patient access. Four principles were proposed for the future ecosystem: separate
remit and functions between regulators and HTA; align processes; converge evidence require-
ments where possible; increase transparency.
Conclusions: This research brought together regulators, HTA agencies, companies to examine
how they interact with one another. We propose measures of value and make recommendations
on future evolution to enable better evidence generation and improve regulatory and HTA
decision-making.
Introduction
The process of bringing new medicines to market involves multiple stakeholders: pharmaceutical
companies as the developer, regulators to grant market authorization based on quality, safety and
efficacy, and health technology assessment (HTA) agencies to provide the recommendation for
reimbursement. The patient’s role in the development, regulation and HTA processes for new
medicines also continues to grow in importance to all decision makers, as the ultimate aim of all
stakeholders in healthcare systems is to provide innovative medicine to patients in a timely and
financially sustainable manner.
Nevertheless, the remit of regulators and HTA agencies may not fully align. Regulators aim to
improve their pathways to provide a flexible mechanism for faster market authorization. HTA
agencies and payers are under pressure to recommend reimbursement for new medicines within
the constraint of the healthcare budget. In turn, companies need to generate evidence during
development to ensure the product is approvable as well as reimbursable (1–3). Realizing the
challenges and potential delay in patient access, stakeholders have started to work collaboratively
to improve the efficiency of the decision-making process.
Over the last decade, regulatory and HTA interactions, as well as multi-HTA and multi-
regulatory interactions, have evolved in theory and in practice. This has occurred at a product
level as well as at a policy level, and spanned both national and cross-jurisdictional systems.
Regulators have a long history of collaboration. Since its initiation in the 1990s, the Inter-
national Council for Harmonization of Technical Requirements for Pharmaceuticals for
Human Use (ICH) has been bringing together regulators and companies to develop harmon-
ized guidelines that help to ensure that evidence submitted to regulators is presented in a
International Journal of
Technology Assessment in
Health Care
www.cambridge.org/thc
Policy
Cite this article: Wang T, McAuslane N,
Goettsch WG, Leufkens HGM, De Bruin ML
(2023). Regulatory, health technology
assessment and company interactions: the
current landscape and future ecosystem for
drug development, review and
reimbursement. International Journal of
Technology Assessment in Health Care, 39(1),
e20, 1–8
https://doi.org/10.1017/S0266462323000144
Received: 11 August 2022
Revised: 29 November 2022
Accepted: 15 December 2022
Keywords:
Health technology assessment; Early scientific
advice; Stakeholder interactions;
Collaboration; Evidentiary requirement
Corresponding author:
Ting Wang;
Email: twang@cirsci.org
© The Author(s), 2023. Published by Cambridge
University Press. This is an Open Access article,
distributed under the terms of the Creative
Commons Attribution licence (http://
creativecommons.org/licenses/by/4.0), which
permits unrestricted re-use, distribution and
reproduction, provided the original article is
properly cited.
https://doi.org/10.1017/S0266462323000144 Published online by Cambridge University Press

## Page 2 (Section: Objectives and methods)

consistent manner (4). For maturing regulatory agencies, reliance
models have been put in place to facilitate the efficiency of the
review process (5;6). For mature regulatory agencies, collaborative
initiatives have been set up, such as Project Orbis for concurrent
submission and review of oncology products (7) and the Access
Consortium for medium-sized agencies to reduce duplication and
align regulatory requirements (8). For HTA agencies, networks
have been established to enable capacity building and shared
learning, such as HTA international (HTAi) and The Inter-
national Network of Agencies for Health Technology Assessment
(INAHTA) at the global level, and HTAsiaLink and Health
Technology Assessment Network of the Americas (RedETSA)
at the regional level (9–11). Within Europe, the European Net-
work for Health Technology Assessment (EUnetHTA) has been
established to create an effective and sustainable network for
HTA (12;13). Agencies also actively engage with companies to
provide scientific advice to facilitate evidence generation during
development. This advice comes either from the regulator, from
the HTA agency, or jointly from both stakeholders (14–17). More
recently, it has been suggested that scientific advice should
expand from development to post-licensing evidence generation
(PLEG) for life-cycle data collection (18).
Responding to the abundance of various stakeholder inter-
actions, research has been undertaken to assess the learnings of
these activities. Most studies to date focused on early scientific
advice in terms of processes, discussion content and potential
impact (15;16;19;20). A recent study by Ofori-Asenso et al. (21)
examined the interactions between regulatory and HTA agencies
and identified areas for further collaboration, such as early tripartite
advice, parallel submission, adaptive licensing and PLEG. More
recently, these channels of communication and the networks for
interactions have been tested by the coronavirus disease-2019
(COVID-19) pandemic, illuminating both challenges and oppor-
tunities as new and repurposed medicines are developed and their
assessment accelerated (22;23). Regulators, HTA agencies/payer
agencies, pharmaceutical companies, patients and clinicians have
a large influence on the development, approval and access to new
medicines. Therefore, there is a need to identify not only the current
but also the future landscape of stakeholder interactions. Our
research focuses on the interactions among companies, regulators
and HTA agencies to address challenges and examine potential
solutions for the evolution of these interactions. This paper is based
on the outcomes of a multi-stakeholder survey and workshop with
the aim of identifying the current landscape and future ecosystem of
stakeholder interactions to support drug development and patient
access.
Objectives and methods
Survey
Centre for Innovation in Regulatory Science (CIRS) conducted a
multi-stakeholder survey in February 2021 with the main objectives
being to:
•
Identify the current landscape of interactions within and across
regulatory and HTA agencies, as well as companies’ experiences
in engaging in these activities.
•
Assess the added value of these interactions from each stake-
holder’s perspective and identify how to measure success.
•
Explore what the future ecosystem could be for interactions
across stakeholders.
Three separate questionnaires were developed for companies, regu-
lators and HTA agencies, respectively (Supplementary Materials 1–
3). The pilot surveys were developed in January 2021 by the first
author and were reviewed by all the coauthors with the purpose
being to validate the clarity, format and applicability of the surveys.
Feedback provided by coauthors was used to refine the wording of
questions and to finalize the surveys on 3 February 2021. The
questionnaires were distributed via email on 4 February 2021 to
invited participants, who were asked to complete the questionnaire
by 25 February 2021. A reminder email was sent on 22 February
2021 for returning the survey. The agency surveys were sent to CIRS
contacts holding senior positions within 17 regulatory agencies and
15 HTA agencies in Australia, Canada, Europe and Asia. The
agencies selected were either considered major international regu-
lators/HTA agencies, or had been invited to the workshop. The
agency surveys were made up of four multiple-choice, closed ques-
tions and three open-ended questions. The surveys focused on
three sections: assessing the current interactions with different
stakeholders; identifying the characteristics of an effective inter-
action model; and recommending an effective model for future
interaction.
The company questionnaire was sent to senior management at
19 international pharmaceutical companies that were members of
CIRS to ensure timeliness of the study and to maximize the
response rate. The company survey consisted of six multiple-choice
closed questions and three open-ended questions that focused on
current interactions between stakeholders. The survey was com-
posed of four sections: effective models of stakeholder interactions;
convergence through interactions; focus on 2030 and improving
the ecosystem for interactions; and ensuring interactions between
different stakeholders are adding value. The company, regulator
and HTA agency questionnaires contained analogous questions
where appropriate. A free-text comment option was provided for
each question to allow further clarification or comments.
Workshop
A multi-stakeholder workshop was held virtually on 10–11 March
2021 on the topic of “Regulatory, HTA and payer interactions and
collaborations: optimizing their use and outcome success” (24). The
objectives of the workshop included to:
•
Identify through case studies the key areas, types of interactions
and collaborations between stakeholders that are effective, as
well as the challenges and opportunities.
•
Understand the value-add these interactions and collaborations
bring to enabling improved decision-making by the stake-
holders as well as how to address divergences and limitations.
•
Make recommendations on what can be learnt across jurisdic-
tions from the current initiatives so as to inform the future
evolution of stakeholder interactions and collaborations to
enable better evidence generation as well as improved outcomes
for patient access.
Ninety-two senior representatives from regulatory agencies, indus-
try, payers, HTA bodies, patient organizations, healthcare and
academia participated in the workshop (the list of participating
organizations is provided as Supplementary Material 4). The results
from the survey were presented at the meeting, followed by keynote
speakers, case studies and panel discussion. Participants were then
arranged into four breakout groups. Each group was designed such
that there was an even distribution of participants from each
stakeholder type, with individual participants being selected
2
Wang et al.
https://doi.org/10.1017/S0266462323000144 Published online by Cambridge University Press

## Page 3 (Section: Data processing and analysis)

randomly for any given group. The breakout topics were aligned
with the survey topics and each breakout group was led by a
chairperson selected by CIRS based on their expertise. A rapporteur
for each group was also selected to document the discussion and
present a summary of the discussion back to all workshop partici-
pants. This paper focused on the discussion output from the
breakout groups.
Data processing and analysis
The responses from the survey were tabulated into an Excel file
manually and analyzed using descriptive statistics. Data were calcu-
lated as the absolute number of responses if respondents were less
than 10, and the percentage of total responses if respondents were
10 or more. Ranking was applied where suitable. The first author
conducted content analysis for free-text comments and open ques-
tions to identify key themes, before employing the constant compara-
tive method. The results were reviewed by the second author to verify
the phases and themes expressed by thestudyparticipants.The results
for the breakout discussions were summarized by the first author
based on the rapporteur presentations, as well as meeting recordings.
Results
Survey results
Representatives of seven (41 percent response rate) regulatory
agencies and 7 HTA agencies (47 percent response rate) responded
to the survey, which included key stakeholders from a mix of
geographical locations. The regulatory agencies were Health
Canada, the European Medicines Agency (EMA), Sweden’s
Medical Products Agency (MPA), Switzerland’s Swissmedic, the
Netherlands’ Medicines Evaluation Board (MEB), Singapore’s
Health Sciences Authority (HSA) and China’s Center for Drug
Evaluation
(CDE).
The
responding
HTA
agencies
were
Australia’s
Pharmaceutical
Benefits
Advisory
Committee
(PBAC), the Canadian Agency for Drugs and Technology in Health
(CADTH), England’s National Institute for Health and Care Excel-
lence (NICE), Sweden’s Tandvårds-Och Läkemedelsförmånsverket
(TLV), China’s National Health Development Research Center,
Singapore’s Agency for Care Effectiveness (ACE) and Thailand’s
Health
Intervention
and
Technology
Assessment
Program
(HITAP). Nine out of the 19 pharmaceutical companies completed
the survey (47 percent response rate). These companies were in the
top 25 companies by R&D expenditure in 2019 (25), reflecting the
research intensity of the companies and the innovativeness of their
development pipelines.
Agencies’ experiences and perception of value of stakeholder
interactions
All participating agencies indicated that they have interactions with
other agencies. For regulatory–regulatory interactions, the top
areas of interaction were formal work-sharing during review, regu-
latory strengthening through workshops, and training and informal
exchange of knowledge and information. Respondents saw value in
reducing duplication of work and providing an opportunity for
capacity building, enabling more efficient drug development and
support for post-approval activities. For HTA–HTA interactions,
the top areas of interaction focused on HTA methodology/frame-
work, HTA capacity building, and informal exchange of knowledge
and information. These interactions were reported as being useful
to improve understanding of the divergences in evidence
Figure 1. Overview of current interactions between agencies. HTA, health technology assessment; PLEG, post-licensing evidence generation.
International Journal of Technology Assessment in Health Care
3
https://doi.org/10.1017/S0266462323000144 Published online by Cambridge University Press

## Page 4 (Section: Companies’ experiences and perceptions of value of stakeholder interactions)

requirements and to validate agency internal thinking (Figure 1).
Two European HTA respondents were experienced in joint assess-
ment through EUnetHTA.
For cross-stakeholder interactions, the top areas of regulatory–
HTA interaction were the exchange of knowledge and information
during regulatory and HTA review (85 percent of total respond-
ents) and PLEG (46 percent of total respondents). Only 2 of
14 agencies reported on alignment/harmonization of evidence
requirements. Regulatory–HTA interactions were seen to have
fewer practical advantages but provided the opportunity to learn
about the complexity of different systems. Both regulators and HTA
agencies reported having interactions with payers to facilitate the
informal exchange of knowledge and information. HTA–payer
interactions primarily focused on the implementation of HTA
recommendations, discussion of pricing and budget impact, as well
as discussion of conditional reimbursement/managed entry
schemes.
Companies’ experiences and perceptions of value of stakeholder
interactions
All nine companies reported having experiences in seeking early
scientific advice with a regulator, HTA agency or through parallel
regulatory–HTA advice. Five companies had experience with
multi-HTA joint advice and four with joint multi-regulator advice.
Advice on PLEG plans tended to be more common with regulators
than with HTA agencies (five vs. two companies). Companies
indicated that this interaction should be prioritized for products
responding to unmet medical need, or new technologies such as
cell/gene therapies. Companies also had interactions through
public–private partnerships such as Get-Real-Initiatives to facili-
tate alignment of evidence requirements (eight respondents), as
well as input into evidence standards at the policy level (seven
respondents).
Six companies reported that external interactions were a
priority and that there were plans for future engagement, while
three companies had agreed on this in principle, but were
subject to the resource available to support these interactions.
Six companies indicated that the “success of interactions are
measured subjectively” with a partially developed set of indica-
tors, while three companies did not have any indicators in place
to measure external interactions. All companies responded on
the key areas that potential success indicators could be built on
at both the product and therapy level (Figure 2). At the policy
level, the value of stakeholder interactions could be measured by
“input into guideline development”, promoting “good HTA
review practice”, supporting “HTA capacity building” and
“Regulatory strengthening.”
Effective model of current interaction between regulators, HTA
agencies and companies
Respondents noted that interactions were effective if the outcome
aligned with the aim of the activities. ICH was rated by both
companies and agencies as an effective model to support the
harmonization of technical requirements. EUnetHTA early sci-
entific advice was voted as an effective collaboration to support
evidence generation. Access Consortium and Orbis projects were
selected as an effective way of formal regulatory work sharing,
while the Medicines Evaluation Board (MEB) and the National
Health Care Institute (ZIN) parallel process in the Netherlands
and the Innovative Licensing and Access Pathway in the UK were
viewed as good models to align regulatory and HTA process.
With regard to improving agency decision-making, international
advisory committee and international collaboration programs
were seen as effective, while national regulatory and HTA infor-
mal information exchange were recommended to enable process
efficiency.
Figure 2. Companies’ perspectives on indicators to measure the value of stakeholder interactions. HTA, health technology assessment; PLEG, post-licensing evidence generation.
4
Wang et al.
https://doi.org/10.1017/S0266462323000144 Published online by Cambridge University Press

## Page 5 (Section: Future ecosystem for interaction between regulators, HTA agencies and companies)

Future ecosystem for interaction between regulators, HTA
agencies and companies
When asked about the ideal ecosystem for multi-stakeholder inter-
actions in the future, four key principles emerged from the
responses:
1)
Separate remit and functions of the regulator and HTA agency:
to acknowledge and provide clarification on scope and remit
between regulators and HTA agencies while increasing mutual
understanding between the two stakeholders.
2)
Convergences of evidence: develop common methodology
and evidence standards where possible, so that drug develop-
ment is primed to meet both regulatory and HTA require-
ments.
3)
Align process and use reliance: where appropriate, further
align regulatory and HTA processes with formal and/or infor-
mal information exchange to ensure process efficiency,
advance reliance mechanisms for regulators and enhance
collaboration among HTA agencies such as work sharing or
leveraging other agencies’ work.
4)
Transparency: increase trust between multiple stakeholders
and propose a transparency agreement for information shar-
ing. At the jurisdictional level, there should be collaborative
approaches to horizon scanning to support innovation and
facilitate patient access.
Workshop breakout groups
Details of workshop presentations, case studies and panel discus-
sions have been published (24). This paper focuses on the break-
out discussions during the workshop. The discussion participants
reviewed the survey results and reflected on their own experiences
of stakeholder interactions. EUnetHTA parallel advice was
reported to promote cross-functional collaboration within
companies and among agencies. Nevertheless, challenges were
identified by participants, for example, companies need to achieve
consensus on the evidence-generation plan between internal
regulatory and HTA functions; companies may assume that not
following the scientific advice will impact the HTA recommen-
dation; there is a lack of consensus on post-licensing data sharing
between regulatory and HTA agencies; and multiple data sources
can be an issue. Participants emphasized the evidence needs for
comparative effectiveness post-approval and suggested that HTA
agencies and payers align on affordability. Four success indicators
to measure interactions were recommended: speed (time to
patient access), “correctness” of decisions (subject to each stake-
holder’s perspective), patient relevance of the evidence generated
and equity of access (Figure 3). However, participants noted that
measures should not be unidimensional; the speed to patient
access cannot be compromised by the quality of decision-making.
It was suggested that the correctness of decisions needs to balance
with the speed of decision-making, though different stakeholders
held different views on the nature of the trade-off between quality
and speed. Further research is needed to understand and define
these indicators. Agencies indicated that the intangible aspects of
interactions were important, such as building relationships and
trust with their peer agencies, and improving knowledge of a new
technology, which were difficult to measure quantitatively. It was
suggested to assess the change of decision-making behaviors of
stakeholders as a consequence of interactions.
Finally, the breakout group participants reviewed different types
of stakeholder interaction and their future evolution (Figure 4).
They also considered the impact of the COVID-19 pandemic,
which has changed ways of working and accelerated the decision-
making process. There was a concern that “vaccine nationalism”
may reverse this and potentially lead to more divergence among
jurisdictions. The participants illuminated the future ecosystem for
interactions. During drug development, stakeholders would have
shared language to agree on the unmet need, clinical effectiveness,
uncertainty and methodology; a stable platform for early dialogue
that would enable alignment at the start of process, and strengthen
networks to help foster valuable collaborations. During the post-
licensing stage, there would be clear requirements and standards for
Figure 3. Recommended indicators to measure the impact of stakeholder interactions. HTA, health technology assessment.
International Journal of Technology Assessment in Health Care
5
https://doi.org/10.1017/S0266462323000144 Published online by Cambridge University Press

## Page 6 (Section: Discussion)

post-approval data collection and better use of historical control
data. Participants also suggested that further interaction could take
the form of an informal network that may focus on public health-
related or policy-related topics.
Discussion
Over the past decade, interactions between regulators and HTA
agencies, as well as multi-regulator and multi-HTA interactions,
have taken place to better support companies on clinical develop-
ment, align the decision-making process among agencies to
encourage efficiency and better-informed decision-making, and
promote trust and reliance between all stakeholders (21;26;27).
This multi-stakeholder survey and workshop assessed the current
landscape of multi-stakeholder interactions, their added value and
the future development of these activities.
The survey illustrated different levels of interactions, particu-
larly more formal work sharing between regulators compared with
the informal exchange of information among HTA agencies. This
may relate to the longer history of regulatory agencies compared
with the formal initialization of HTA, which has allowed mechan-
isms to be tested, and trust to be built. Formal processes such as
reliance models and standardized technical requirements through
ICH fostered collaboration between regulators (26;28). EUnetHTA
has provided the platform to test multi-HTA collaboration, which
led to the formal production of joint clinical assessment (JCA) to be
fully implemented by 2029 (29). It is, however, critical for
stakeholders in member states to collaborate in coming years to
ensure that JCA will be used effectively in local decision-making,
rather than being a duplicative process. Our study also identified
the appetite for HTA agencies to learn from the collaborative
models of regulators, such as the Orbis project, to expand collab-
oration outside Europe. We note that since the study was con-
ducted, 6 HTA agencies from Australia, Canada and the UK
agencies started to explore the possibility of work sharing to
improve efficiency (30). To achieve this goal, capacity building
and alignment in the HTA methodology/framework will be import-
ant; these two areas were rated as the top areas of focus by HTA
respondents in the study.
The most important measure identified by companies was faster
patient access. HTA-regulatory procedural and timeline alignment is
viewed as a valuable interaction. For example, parallel HTA and
regulatory reviews available in Australia and Canada have shortened
the time to HTA decision/recommendation and by extension have
led to quicker patient access (31). In the Netherlands, a pilot was
launched in 2019 for a parallel process with formal coordination
between MEB and ZIN. A recent example for Astellas’ roxadustat
showed that the parallel process allowed ZIN to rule on the reim-
bursement immediately after registration (32). The successful pilot
demonstrated a time saving of 3 months and has moved into a more
structural collaboration. The Dutch model provided learnings for
future national regulatory and HTA collaboration. Our findings
acknowledged that regulators and HTA agencies should remain
separate in function and remit, but more work could be done to
Figure 4. Direction of evolution of interactions between different stakeholders. EU, European union; HTA, health technology assessment.
6
Wang et al.
https://doi.org/10.1017/S0266462323000144 Published online by Cambridge University Press

## Page 7 (Section: Study limitation)

converge evidence requirements where possible. For example,
palbociclib was approved by EMA in 2016 for the treatment of breast
cancer. However, the uncertainty due to lack of evidence on overall
survival and treatment length led to divergent HTA recommenda-
tions in Europe. To investigate the evidence gap for palbociclib, a
EUnetHTA PLEG pilot was conducted in 2021; this interaction
identified common research recommendations among participating
agencies, and saw the opportunity for collaboration between HTA
agencies using cross-nationwidereal-worldevidence(RWE) tofacili-
tate the initial HTA decision and subsequent reassessment (33).
Early scientific advice developed in recent years supported the
development and PLEG for companies, facilitated conversations
among agencies and enabled better understanding between stake-
holders. Nevertheless, these activities are resource-consuming, and
the workshop participants raised the question of the capacity of
companies and agencies to participate in such activities. This in
turn requires prioritization. EUnetHTA joint scientific consult-
ation listed its essential criteria: unmet medical needs; first in class;
potential impact on patients/public health; significant cross-border
dimension; major union-wide added value or research priorities;
and breakthrough technology for oncology products and/or
advanced therapy medicinal products (34). The criteria ensured
that the resources from agencies were prioritized, in particular for
interactions involving multiple agencies. These principles are mir-
rored with companies’ priorities, as noted in our survey results.
Studies on aligning each stakeholder’s definition on unmet
medical need contributed to mutual understanding of stakeholders’
priorities (18;35).
Planning for early advice is also key; this needs to be early
enough to shape the development plan, but not too early in order
to ensure that sufficient evidence has been generated to support a
meaningful dialogue. Therefore, future improvement should focus
on clarifying the optimal timing to seek advice from regulators and
HTA agencies. Our research suggested that the interaction should
not be a one-off activity but allow for a more flexible and iterative
process for advice, especially considering the life cycle approach to
collect data for medicines’ review and reimbursement. In addition,
early advice could be more transparent in a later stage of life-cycle
decision-making. Operational actions were suggested to improve
efficiency, including consolidating learnings from scientific advice
and speeding up administration steps. The current early advice
activities are mainly provided by established HTA agencies in
Europe and Canada, which are important markets for companies
from a commercial perspective. As HTA systems are continuously
developing and improving in other jurisdictions, agencies could
consider further stakeholder interactions, such as providing advice
to companies on the development plan and local submission.
Companies should in turn decide strategically when and which
agencies to seek advice from. Further research can be conducted to
investigate the stakeholder interactions within emerging markets.
We also saw an opportunity for informal networks to complement
formal advice and contribute to not only product-related topics but
also policy and public health-related discussions.
Stakeholder interactions were seen as critical and beneficial for
future drug development and availability; the workshop breakout
groups pictured the ideal future ecosystem. However, the agility of
regulatory and HTA systems have been tested during the COVID-19
pandemic. Researchers have analyzed potential scenarios for the
future of medicines and social policy in 2030; increased knowledge
sharing, trust and openness in science, as well as partnership have
been identified as key drivers for sustainable flow and transformative
healing scenarios (36). The optimal direction of travel requires
further dialogue, interaction and trust among stakeholders. Sugges-
tions were proposed to improve current experiences, such as patient
centricity, sharing common objectives among stakeholders and
establishing a stable platform for continuous dialogue. Tomove from
identifying divergence to enabling more convergence, the breakout
groups suggested more work-sharing and reliance models between
regulators, alignment on affordability between HTA agencies and
payers, and increased transparency of PLEG requirements between
regulators and HTA agencies.
Our research identified four potential areas to measure value:
time to access, correctness of decision, and patient-centric meas-
ures of value and equity. Findings from this study will contribute to
further discussions on building good practice into stakeholder
interactions. An immediate next step can be a study to develop
performance metrics to measure the value of interactions from the
perspectives of regulators, HTA agencies and companies. Apart
from potential quantitative indicators, the participants also raised
the qualitative value of interacting with other stakeholders, such as
learning about new technology, validating internal thinking and
building trust with (and improving understanding of) other agen-
cies. An interesting suggestion for further discussion was the pos-
sibility to assess behavior changes in decision-making following
these interactions.
Study limitation
This study addressed the key components of stakeholder inter-
actions from the regulator, HTA agency and company perspective.
Its limitation is the lack of patient and payer feedback in the survey.
Nevertheless, patient representatives and payer organizations were
present at the workshop, which added their voice to the overall
discussion and development of suggestions. Another limitation is
the number of survey respondents, which, due to the study time
frame, was limited to seven regulators, seven HTA agencies and
nine companies. However, this is complemented by the larger
number of participants at the workshop, which provided further
insights on the topics addressed in the survey.
Conclusions
The multi-stakeholder interactions among regulators and HTA
agencies, as well as between regulators and HTA agencies, are
important for ensuring a more efficient process from development
to patient access. The outcome of the survey and workshop identi-
fied current interactions, challenges and gaps, and suggested indi-
cators that could be built to measure the value of interactions. This
research also assessed perceptions of the future evolution of these
activities. Four key principles were identified for further develop-
ment of interactions: keep the remit and functions of stakeholders
separate; align processes; converge evidence requirements when it is
scientifically justifiable; and increase transparency to build trust.
Supplementary material. The supplementary material for this article can be
found at https://doi.org/10.1017/S0266462323000144.
Acknowledgments. The authors thank the regulatory agencies, HTA agencies
and pharmaceutical companies that took part in the study survey and workshop
discussion. The authors would also like to acknowledge Dr. Jenny Sharpe for her
support in the editing and submission of this manuscript.
Funding statement. This work was supported by the Division of Pharmacoe-
pidemiology and Clinical Pharmacology, Utrecht Institute for Pharmaceutical
International Journal of Technology Assessment in Health Care
7
https://doi.org/10.1017/S0266462323000144 Published online by Cambridge University Press

## Page 8 (Section: Competing interest)

Sciences, Utrecht University, The Netherlands, and the Centre for Innovation in
Regulatory Science (CIRS), London, UK.
Competing interest. The authors declare none.
References
1. Honig PK. Comparative effectiveness: The fourth hurdle in drug develop-
ment and a role for clinical pharmacology. Clin Pharmacol Ther. 2011;89(2):
151–156.
2. Liberti L, McAuslane N, Stolk P, Breckenridge A, Leufkens H. A proposed
framework for a globally applicable pragmatic approach to using facilitated
regulatory pathways. Ther Innov Regul Sci. 2020;54(1):55–68.
3. Wang T, McAuslane N, Liberti L, et al. Companies’ health technology
assessment strategies and practices in Australia, Canada, England, France,
Germany, Italy and Spain: An industry metrics study. Front Pharmacol.
2020;11:594549.
4. International Council for Harmonization of Technical Requirements for
Pharmaceuticals for Human Use (ICH). ICH Guidelines [Internet] [cited
2022 July 29th]. Available from: https://www.ich.org/page/ich-guidelines.
5. Duran CE, Canas M, Urtasun MA, et al. Regulatory reliance to approve
new medicinal products in Latin American and Caribbean countries. Rev
Panam Salud Publica. 2021;45:e10.
6. Keyter A, Salek S, Danks L, et al. South African regulatory authority: The
impact of reliance on the review process leading to improved patient access.
Front Pharmacol. 2021;12:699063.
7. Food and Drug Administration (FDA). Project Orbis. [Internet] [cited
2022 July 29th]. 2022. Available from: https://www.fda.gov/about-fda/
oncology-center-excellence/project-orbis.
8. Australian Department of Health Therapeutic Goods Administration
(TGA). Australia-Canada-Singapore-Switzerland-United Kingdom (Access)
Consortium. [Internet] 2021 [cited 2022 July 29th]. Available from: https://
www.tga.gov.au/australia-canada-singapore-switzerland-united-kingdom-
access-consortium.
9. Longson C. Htai Policy Forum: Keeping Hta on Track. Int J Technol Assess
Health Care. 2014;30(3):251–252.
10. Teerawattananon Y, Luz K, Yothasmutra C, et al. Historical development
of the Htasialink network and its key determinants of success. Int J Technol
Assess Health Care. 2018;34(3):260–266.
11. Schuller T, Soderholm Werko S. Insights from the front lines: A collection
of stories of Hta impact from Inahta member agencies. Int J Technol Assess
Health Care. 2017;33(4):409-410.
12. Nielsen CP, Lauritsen SW, Kristensen FB, et al. Involving stakeholders
and developing a policy for stakeholder involvement in the European
network for health technology assessment, EUnetHTA. Int J Technol Assess
Health Care. 2009;25:84–91.
13. Luhnen M, Ormstad SS, Willemsen A, et al. Developing a quality man-
agement system for the European Network for Health Technology Assess-
ment (EUnetHTA): Toward European HTA collaboration. Int J Technol
Assess Health Care. 2021;37:e59.
14. Katsnelson A. FDA and EMEA pool scientific advice. Nat Biotechnol. 2004;
22(12):1490–1491.
15. Seldrup J. Regulatory advice and drug development–A case study in
negotiating with regulators. Stat Med. 2011;30:1628–1635.
16. Wang T, McAuslane N, Gardarsdottir H, Goettsch WG, Leufkens HGM.
Building HTA insights into the drug development plan: Current approaches
to seeking early scientific advice from HTA agencies. Drug Discov Today.
2022;27(1):347–353.
17. Wonder M, Backhouse ME, Hornby E. Early scientific advice obtained
simultaneously from regulators and payers: Findings from a pilot study in
Australia. Value Health. 2013;16:1067–1073.
18. Moseley J, Vamvakas S, Berntgen M, et al. Regulatory and health technol-
ogy assessment advice on postlicensing and postlaunch evidence generation
is a foundation for lifecycle data collection for medicines. Br J Clin Phar-
macol. 2020;86:1034–1051.
19. Maignen FM, Osipenko L, Gajraj E, Chivers R. Trends In early engage-
ment between industry and HTA: Analysis of scientific advice service
provided by Nice since 2009. Value Health. 2014;17:A441.
20. Tafuri G, Pagnini M, Moseley J, et al. How aligned are the perspectives of
EU regulators and HTA bodies? A comparative analysis of regulatory-HTA
parallel scientific advice. Br J Clin Pharmacol. 2016;82:965–973.
21. Ofori-Asenso R, Hallgreen CE, De Bruin ML. Improving interactions
between health technology assessment bodies and regulatory agencies: A
systematic review and cross-sectional survey on processes, progress, out-
comes, and challenges. Front Med. 2020;7:582634.
22. Soumyanarayanan U, Choong M, Leong J, et al. The COVID-19 crisis as
an opportunity to strengthen global regulatory coordination for sustained
enhanced access to diagnostics and therapeutics. Clin Transl Sci. 2021;14:
777–780.
23. PharmacoEcon_Outcomes. Impact of COVID-19 pandemic on HTA.
PharmacoEcon Outcomes News. 2020;853(1):2.
24. Centre for Innovation in Regulatory Science (CIRS). Regulatory, HTA
and payer interactions and collaborations: Optimising their use and out-
come success. 10-11th March 2021 [Workshop Report]. 2021 August 26th
2021. Report No.
25. Cristel M. Pharm Exec’s top 50 companies 2019. Pharm Exec. 2019; 2019:
12–19.
26. Keyter A, Salek S, McAuslane N, et al. Implementation of a framework for
an abridged review using good reliance practices: Optimising the medicine
regulatory review process in South Africa. Ther Innov Regul Sci. 2020;54:
1199–1207.
27. Tafuri G, Lucas I, Estevao S, et al. The impact of parallel regulatory-health
technology assessment scientific advice on clinical development. Assessing
the uptake of regulatory and health technology assessment recommenda-
tions. Br J Clin Pharmacol. 2018;84:1013–1019.
28. O’Brien J, Lumsden RS, Diehl DH, Macdonald JC. Building a better
approach for the benefit of patients: 10 pillars to strengthen regulatory
review systems globally. Ther Innov Regul Sci. 2020;54:283–292.
29. REGULATION (EU) 2021/2282 of The European Parliament and of the
Council of 15 December 2021 on health technology assessment and amend-
ing Directive 2011/24/EU, (2021).
30. Canadian Agency for Drugs and Technologies in Health (CADTH).
CADTH Partners With International Health Technology Assessment Bod-
ies to Boost Collaboration on Shared Challenges. [Internet] [cited
2022 November 19th]. 2022. Available from: https://www.cadth.ca/news/
cadth-partners-international-health-technology-assessment-bodies-boost-
collaboration-shared.
31. Wang T, Sola B, McAuslane N. CIRS R&D Briefing 83: Review of HTA
outcomes and timelines in Australia, Canada and Europe 2016–2020.
London, UK: Centre for Innovation in Regulatory Science (CIRS). 2021.
32. Zorginstituut Nederland (ZIN). Parallel procedure: Faster drug evalu-
ation. [Internet] [cited 2022 July 29th]. Available from: https://www.zorgin
stituutnederland.nl/over-ons/werkwijzen-en-procedures/adviseren-over-
en-verduidelijken-van-het-basispakket-aan-zorg/beoordeling-van-genees
middelen/parallelle-procedure.
33. Team EPFP. PLEG pilot on Palbociclib (Ibrance®). Common Evidence
Gaps report. Diemen (The Netherlands): May 2021. Report No.: PLEG_
FP_02. 2021.
34. European Network for Health Technology Assessment (EUnetHTA).
Joint Scientific Consultations (JSC). [Internet] [cited 2022 July 29th].
Available from: https://www.eunethta.eu/jsc/.
35. Vreman RA, Heikkinen I, Schuurman A, et al. Unmet medical need: An
introduction to definitions and stakeholder perceptions. Value Health.
2019;22:1275–1282.
36. Leufkens HG, Kusynova Z, Aitken M, et al. Four scenarios for the future
of medicines and social policy in 2030. Drug Discov Today. 2022;27:
2252–2260.
8
Wang et al.
https://doi.org/10.1017/S0266462323000144 Published online by Cambridge University Press


---

# [Reporting guidelines for clinical trial reports for interventions involving artificial intelligence: the CONSORT-AI extensionDiretrizes para relatórios de ensaios clínicos com intervenções que utilizam inteligência artificial: a extensão CONSORT-AI]

- **Authors:** Xiaoxuan Liu, Samantha Cruz Rivera, David Moher, Melanie J Calvert, Alastair K Denniston, Grupo de Trabajo SPIRIT-AI y CONSORT-AI, GRUPO DE DIRECCIÓN SPIRIT-AI Y CONSORT-AI, Grupo de Consenso SPIRIT-AI y CONSORT-AI
- **Issuer:** Revista panamericana de salud publica = Pan American journal of public health
- **Type:** Scientific article
- **Published:** 2023-02-12
- **DOI:** 10.26633/rpsp.2024.13
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38352035/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

RESUMENLa declaración CONSORT 2010 proporciona unas directrices mínimas para informar sobre los ensayos clínicos aleatorizados. Su uso generalizado ha sido fundamental para garantizar la transparencia en la evaluación de nuevas intervenciones. Más recientemente, se ha reconocido cada vez más que las intervenciones con inteligencia artificial (IA) deben someterse a una evaluación rigurosa y prospectiva para demostrar su impacto en la salud. La extensión CONSORT-AI (Consolidated Standards of Reporting Trials-Artificial Intelligence) es una nueva pauta de información para los ensayos clínicos que evalúan intervenciones con un componente de IA, esta se desarrolló en paralelo con su declaración complementaria para los protocolos de ensayos clínicos: SPIRIT-AI (Standard Protocol Items – Artificial Intelligence: Recomendaciones para ensayos clínicos de intervención - Inteligencia Artificial). Ambas directrices se desarrollaron a través de un proceso de consenso por etapas que incluía la revisión de la literatura y la consulta a expertos para generar 29 elementos candidatos, que fueron evaluados por un grupo internacional de múltiples partes interesadas en una encuesta Delphi de dos etapas (103 partes interesadas congregados en una reunión de consenso de dos días (31 partes interesadas) y refinados a través de una lista de verificación piloto (34 participantes). La ampliación del CONSORT-AI incluye 14 nuevos elementos que se consideraron lo suficientemente importantes para las intervenciones de IA como para que se informen de forma rutinaria, además de los elementos básicos del CONSORT 2010. CONSORT-AI recomienda que los investigadores proporcionen descripciones claras de la intervención de IA, incluyendo las instrucciones y las habilidades requeridas para su uso, el entorno en el que se integra la intervención de IA, el manejo de los datos de entrada y los datos de salida de la intervención de IA, la interacción entre el ser humano y la IA y la provisión de un análisis de los casos de error. CONSORT-AI ayudará a promover la transparencia y la exhaustividad en los informes de los ensayos clínicos de las intervenciones de AI, también ayudará a los editores y revisores, así como a los lectores en general, a entender, interpretar y valorar críticamente la calidad del diseño del ensayo clínico y el riesgo de sesgo en los resultados comunicados.

## Section: Text

Los ensayos clínicos controlados aleatorizados (ECA) se consideran el diseño experimental de referencia para proporcionar pruebas de la seguridad y la eficacia de una intervención1, 2. Los resultados de los ensayos clínicos, si se comunican adecuadamente, tienen el potencial de informar sobre las decisiones reguladoras, las directrices clínicas y la política sanitaria. Por lo tanto, es crucial que los ECA se comuniquen con transparencia y exhaustividad para que los lectores puedan valorar críticamente los métodos y los resultados del ensayo clínico y evaluar la presencia de sesgos en los resultados3-5.

La declaración CONSORT proporciona recomendaciones basadas en la evidencia para mejorar la exhaustividad de los informes de los ECA. La declaración se introdujo por primera vez en 1996 y desde entonces ha sido ampliamente respaldada por las revistas médicas a nivel internacional5. En las últimas dos décadas, ha sido objeto de dos actualizaciones y ha demostrado un impacto positivo sustancial en la calidad de los informes de los ECA6, 7. La declaración CONSORT 2010 más reciente proporciona una lista de control de 25 elementos del contenido mínimo de los informes aplicable a todos los ECA, pero reconoce que ciertas intervenciones pueden requerir la ampliación o aclaración de estos elementos. Existen varias extensiones de este tipo8-13.

La IA es un área de enorme interés con fuertes impulsos para acelerar las nuevas intervenciones desde su publicación, aplicación hasta su comercialización14. Aunque los sistemas de IA se han investigado durante algún tiempo, los recientes avances en el aprendizaje profundo y las redes neuronales han ganado un considerable interés por su potencial en las aplicaciones sanitarias. Los ejemplos de estas aplicaciones son muy variados e incluyen sistemas de IA para el cribado y el triaje15, 16, el diagnóstico17-20, el pronóstico21, 22, el apoyo a la toma de decisiones23 y la recomendación de tratamientos24. Sin embargo, en los casos más recientes, las pruebas publicadas han consistido en una validación in silico en fase inicial. Se ha reconocido que la mayoría de los estudios recientes de IA están informados de forma inadecuada y las directrices de información existentes no cubren completamente las fuentes potenciales de sesgo específicas de los sistemas de IA25. La aparición de ECAs que buscan evaluar intervenciones más nuevas basadas en, o que incluyen, un componente de IA (denominadas aquí “intervenciones de IA”)23, 26-31 se ha encontrado igualmente con preocupaciones sobre el diseño y la presentación de informes25, 32-34. Esto ha puesto de manifiesto la necesidad de proporcionar una guía para la presentación de informes que sea “adecuada para el propósito” en este ámbito.

CONSORT-AI (como parte de la iniciativa SPIRIT-AI y CONSORT-AI) es una iniciativa internacional apoyada por CONSORT y la red EQUATOR (Enhancing the Quality and Transparency of Health Research. Mejorando la calidad y transparencia de la investigación de la salud, por sus siglas en inglés) que busca evaluar la declaración CONSORT 2010 existente y ampliar o aclarar puntos en esta guía cuando sea necesario, para apoyar la presentación de informes de ensayos clínicos para intervenciones de IA35, 36. Es complementaria a la declaración SPIRIT-AI, cuyo objetivo es promover reportes de protocolos de alta calidad para los ensayos clínicos de IA. Esta Declaración de Consenso describe los métodos utilizados para identificar y evaluar los elementos candidatos y obtener un consenso. Además, también proporciona la lista de verificación CONSORT-AI, que incluye los nuevos elementos de ampliación y las explicaciones que los acompañan.

## Section: MÉTODOS

Las extensiones de SPIRIT-AI y CONSORT-AI se desarrollaron simultáneamente para los protocolos e informes de ensayos clínicos. En octubre de 2019 se publicó un anuncio para la iniciativa SPIRIT-AI y CONSORT-AI (ref. 35), y las dos directrices se registraron como directrices de reporte en desarrollo en la biblioteca de directrices de reporte de EQUATOR en mayo de 2019. Ambas directrices se desarrollaron de acuerdo con el marco metodológico de EQUATOR Network37. El Grupo Directivo de SPIRIT-AI y CONSORT-AI, compuesto por 15 expertos internacionales, se formó para supervisar la realización y la metodología del estudio. Las definiciones de los términos clave se incluyen en el glosario (recuadro 1).

## Section: MÉTODOS › Aprobación ética

Este estudio fue aprobado por el comité de revisión ética de la Universidad de Birmingham, Reino Unido (ERN_19-1100). La información de los participantes en el Delphi se proporcionó por vía electrónica antes de completar la encuesta y antes de la reunión de consenso. Los participantes en el Delphi dieron su consentimiento informado por vía electrónica, y se obtuvo el consentimiento por escrito de los participantes en la reunión de consenso.

## Section: MÉTODOS › Revisión de la literatura y generación de ítems candidatos

Se generó una lista inicial de ítems candidatos para las listas de verificación SPIRIT-AI y CONSORT-AI mediante la revisión de la literatura publicada y la consulta con el Grupo Directivo y expertos internacionales conocidos. Se realizó una búsqueda el 13 de mayo de 2019 utilizando los términos “artificial intelligence”, “machine learning” y “deep learning” para identificar los ensayos clínicos existentes para las intervenciones de IA que figuran dentro del registro de ensayos clínicos de la Biblioteca Nacional de Medicina de los Estados Unidos (ClinicalTrials.gov). Había 316 ensayos clínicos registrados, de los cuales 62 se habían completado y 7 habían publicado resultados30, 38-43. Dos estudios se informaron con referencia a la declaración CONSORT30, 42, y un estudio proporcionó un protocolo de ensayo clínico no publicado42. El equipo de operaciones (X.L., S.C.R., M.J.C. y A.K.D.) identificó las consideraciones específicas de la IA de estos estudios y las reformuló como elementos de información candidatos. Los elementos candidatos también se basaron en los resultados de una revisión sistemática anterior que evaluó la precisión diagnóstica de los sistemas de aprendizaje profundo para la imagen médica25. Después de consultar con el Grupo Directivo y otros expertos internacionales (n = 19), se generaron 29 ítems candidatos, 26 de los cuales eran relevantes tanto para SPIRIT-AI como para CONSORT-AI y 3 de los cuales eran relevantes sólo para CONSORT-AI. El equipo de operaciones asignó estos ítems a los ítems correspondientes de SPIRIT y CONSORT, revisando la redacción y proporcionando el texto explicativo necesario para contextualizar los ítems. Estos ítems se incluyeron en las encuestas Delphi posteriores.

## Section: MÉTODOS › Proceso de consenso Delphi

En septiembre de 2019, se invitó a 169 expertos internacionales clave a participar en la encuesta Delphi en línea para votar sobre los elementos candidatos y sugerir elementos adicionales. Los expertos fueron identificados y contactados a través del Grupo Directivo y se les permitió una ronda de reclutamiento “bola de nieve” en la que los expertos contactados podían sugerir expertos adicionales. Además, se incluyó a las personas que se pusieron en contacto tras la publicación del anuncio35. El Grupo Directivo acordó que las personas con experiencia en ensayos clínicos y en IA y aprendizaje automático (ML), así como los usuarios clave de la tecnología, deberían estar bien representados en la consulta. Entre las partes interesadas se encontraban profesionales sanitarios, metodólogos, estadísticos, informáticos, representantes de la industria, editores de revistas, responsables políticos, “informáticos” sanitarios, expertos en derecho y ética, reguladores, pacientes y financiadores. Las características de los participantes se describen en la tabla suplementaria 1. Se realizaron dos encuestas Delphi en línea. Se utilizó el software DelphiManager (versión 4.0), desarrollado y mantenido por la iniciativa COMET (Core Outcome Measures in Effectiveness Trials), para realizar la encuesta e-Delphi. Los participantes recibieron información escrita sobre el estudio y se les pidió que indicaran su nivel de experiencia en los campos de (i) IA/ML, y (ii) ensayos clínicos. Se presentó cada punto para su consideración (26 para SPIRIT-AI y 29 para CONSORT-AI). Se pidió a los participantes que votaran sobre cada punto utilizando una escala de 9 puntos, de la siguiente manera 1-3, no importante; 4-6, importante pero no crítico; y 7-9, importante y crítico. Los encuestados proporcionaron calificaciones separadas para SPIRIT-AI y CONSORT-AI. Había una opción para no votar por cada ítem, y cada ítem incluía un espacio para comentarios de texto libre. Al final de la encuesta Delphi, los participantes tuvieron la oportunidad de sugerir nuevos elementos. Se recibieron 103 respuestas para la primera ronda Delphi, y 91 respuestas (el 88% de los participantes de la primera ronda) para la segunda ronda. Los resultados de la encuesta Delphi sirvieron de base para la posterior reunión de consenso internacional. Los participantes en el estudio Delphi propusieron 12 nuevos puntos que se añadieron para su discusión en la reunión de consenso. Los datos recogidos durante la encuesta Delphi se anonimizaron, y los resultados a nivel de ítems se presentaron en la reunión de consenso para su discusión y votación.

La reunión de consenso, de dos días de duración, tuvo lugar en enero de 2020 y fue organizada por la Universidad de Birmingham, Reino Unido, para buscar el consenso sobre el contenido de SPIRIT-AI y CONSORT-AI. Se invitó a 31 interesados internacionales de entre los participantes en la encuesta Delphi a debatir los puntos y votar sobre su inclusión. Los participantes se seleccionaron para lograr una representación adecuada de todos los grupos interesados. Se discutieron 41 ítems, que incluían los 29 ítems generados en la revisión inicial de la literatura y la fase de generación de ítems (26 ítems relevantes tanto para SPIRIT-AI como para CONSORT-AI; 3 ítems relevantes sólo para CONSORT-AI) y los 12 nuevos ítems propuestos por los participantes durante las encuestas Delphi. Cada ítem se presentó al grupo de consenso, junto con su puntuación en el ejercicio Delphi (mediana y rangos Inter cuartiles) y cualquier comentario realizado por los participantes en el Delphi relacionado con ese ítem. Se invitó a los participantes en la reunión de consenso a comentar la importancia de cada elemento y si éste debía incluirse en la ampliación de la IA. Además, se invitó a los participantes a comentar la redacción del texto explicativo que acompañaba a cada ítem y la posición de cada ítem en relación con las listas de verificación SPIRIT 2013 y CONSORT 2010. Tras la discusión abierta de cada ítem y la opción de ajustar la redacción, se realizó una votación electrónica, con la opción de incluir o excluir el ítem. Se preespecificó un umbral del 80% para la inclusión, que el Grupo Directivo consideró razonable para demostrar el consenso de la mayoría. Cada parte interesada votó de forma anónima utilizando los cuadernos de votación Turning Point (Turning Technologies, versión 8.7.2.14).

## Section: MÉTODOS › Lista de comprobación piloto

Tras la reunión de consenso, los asistentes tuvieron la oportunidad de hacer comentarios finales sobre la redacción y acordar que los ítems actualizados de SPIRIT-AI y CONSORT-AI reflejaran las discusiones de la reunión. El equipo de operaciones asignó cada elemento como extensión o aclaración sobre la base de un árbol de decisiones y elaboró un penúltimo borrador de las listas de comprobación de SPIRIT-AI y CONSORT-AI (figura 1 suplementaria). Se realizó una prueba piloto de las penúltimas listas de verificación con 34 participantes para garantizar la claridad de la redacción. Los expertos que participaron en el piloto fueron los siguientes (a) participantes en el Delphi que no asistieron a la reunión de consenso, y (b) expertos externos que no habían participado en el proceso de desarrollo pero que se habían puesto en contacto con el Grupo Directivo después de que comenzara el estudio Delphi. El equipo de operaciones introdujo los últimos cambios en la redacción, únicamente para mejorar la claridad para los lectores (figura 2 suplementaria).

## Section: MÉTODOS › Recomendaciones

Elementos de la lista de verificación CONSORT-AI y explicación. La extensión del CONSORT AI recomienda que se añadan 14 nuevos ítems de la lista de verificación a la declaración CONSORT 2010 existente (11 extensiones y 3 aclaraciones). Estos ítems se consideraron lo suficientemente importantes para los informes de ensayos clínicos de intervenciones de IA como para que se informen de forma rutinaria, además de los ítems de la lista de comprobación básica del CONSORT 2010. El cuadro 1 enumera los ítems de CONSORT-AI.

Los 14 ítems siguientes superaron el umbral del 80% para su inclusión en la reunión de consenso. CONSORT-AI 2a, CONSORT-AI 5 (ii) y CONSORT-AI 19 fueron el resultado de la fusión de dos ítems tras la discusión con el grupo de consenso. CONSORT-AI 4a (i) y (ii) se dividió en dos puntos para mayor claridad y se votó por separado. CONSORT-AI 5(iii) no cumplía los criterios de inclusión sobre la base de su redacción inicial (77% de votos a favor de su inclusión); sin embargo, tras un amplio debate y una nueva redacción, el grupo de consenso apoyó unánimemente una nueva votación, momento en el que superó el umbral de inclusión (97% a favor de su inclusión). Los resultados del Delphi y de la votación para cada elemento incluido y excluido se describen en el cuadro suplementario 2.

## Section: MÉTODOS › Título y resumen

CONSORT-AI 1a, b (i) Aclaración: indique que la inter­vención implica inteligencia artificial/aprendizaje automático en el título y/o el resumen y especifique el tipo de modelo. Explicación. Se recomienda indicar en el título y/o el resumen del informe del ensayo clínico que la intervención implica una forma de IA, ya que identifica inmediatamente la intervención como una intervención de IA/ML y también sirve para facilitar la indexación y la búsqueda del informe del ensayo clínico. El título debe ser comprensible para un público amplio; por lo tanto, se recomienda utilizar un término general más amplio, como “inteligencia artificial” o “aprendizaje automático”. Los términos más precisos deben utilizarse en el resumen, en lugar del título, a menos que se reconozca ampliamente que son una forma de IA/ML. La terminología específica relacionada con el tipo de modelo y la arquitectura debe detallarse en el resumen.

CONSORT-AI 1a,b (ii) Aclaración: Indique el uso previsto de la intervención de IA dentro del ensayo clínico en el título y/o el resumen. Explicación. Describa el uso previsto de la intervención de IA en el título y/o el resumen del informe del ensayo clínico. Esto debe describir el propósito de la intervención de IA y el contexto de la enfermedad26, 44. Algunas intervenciones de IA pueden tener múltiples usos previstos, o el uso previsto puede evolucionar con el tiempo. Por lo tanto, documentar esto permite a los lectores comprender el uso previsto del algoritmo en el momento del ensayo.

## Section: INTRODUCCIÓN

CONSORT-AI 2a (i) Extensión: explique el uso previsto para la intervención de IA en el contexto de la vía clínica, incluyendo su propósito y sus usuarios previstos (por ejemplo, profesionales sanitarios, pacientes, público). Explicación. Para aclarar cómo se pretende que la intervención de IA encaje en un flujo de trabajo clínico, debe incluirse una descripción detallada de su función en los antecedentes del informe del ensayo clínico. Las intervenciones de IA pueden estar diseñadas para interactuar con diferentes usuarios, incluidos los profesionales de la salud, los pacientes y el público, y sus funciones pueden ser muy variadas (por ejemplo, la misma intervención de IA podría teóricamente sustituir, aumentar o adjudicar componentes de la toma de decisiones clínicas). Aclarar el uso previsto de la intervención de IA y su usuario previsto ayuda a los lectores a comprender el propósito para el que se evaluó la intervención de IA en el ensayo.

## Section: MÉTODOS

CONSORT-AI 4a (i) Aclaración: indique los criterios de inclusión y exclusión a nivel de participantes. Explicación. Los criterios de inclusión y exclusión deben definirse a nivel de los participantes, según la práctica habitual en los informes de ensayos de intervención no relacionados con la IA (Fig. 1). Esto es distinto de los criterios de inclusión y exclusión realizados a nivel de los datos de entrada, que se abordan en el punto 4a (ii).

CONSORT-AI 4ª Extensión (ii): indique los criterios de inclusión y exclusión a nivel de los datos de entrada. Explicación. Los “datos de entrada” se refieren a los datos requeridos por la intervención de IA para cumplir con su propósito (por ejemplo, para un sistema de diagnóstico de cáncer de mama, los datos de entrada podrían ser la mamografía no procesada o el postprocesamiento específico del proveedor sobre el que se realiza el diagnóstico; para un sistema de alerta temprana, los datos de entrada podrían ser las mediciones fisiológicas o los resultados de laboratorio de la historia clínica electrónica). El informe del ensayo debe especificar previamente si existen requisitos mínimos para los datos de entrada (como la resolución de la imagen, las métricas de calidad o el formato de los datos) que determinen la elegibilidad previa a la aleatorización. Debe especificar cuándo, cómo y quién lo evaluó. Por ejemplo, si un participante cumplía los criterios de elegibilidad para estar tumbado para una TC según el punto 4a (i), pero la calidad de la exploración estaba comprometida (por cualquier razón) a tal nivel que se consideraba inadecuada para su uso por el sistema de IA, esto debería ser informado como un criterio de exclusión a nivel de datos de entrada. Nótese que cuando los datos de entrada se adquieren después de la aleatorización, cualquier exclusión se considera del análisis, no de la inscripción (punto 13b de CONSORT y Fig. 1).

CONSORT-AI 4b Extensión: describa cómo se integró la intervención de IA en el entorno del ensayo, incluyendo cualquier requisito in situ o externo. Explicación. La generalización de los algoritmos de IA tiene limitaciones, una de las cuales es cuando se utilizan fuera de su entorno de desarrollo 45,46. Los sistemas de IA dependen de su entorno operativo, y el informe debe proporcionar detalles de los requisitos de hardware y software para permitir la integración técnica de la intervención de IA en cada centro de estudio. Por ejemplo, debe indicarse si la intervención de IA requirió dispositivos específicos del proveedor, si hubo hardware informático especializado en cada centro, o si el centro tuvo que soportar la integración en la nube, particularmente si esto fue específico del proveedor. Si fue necesario realizar algún cambio en el algoritmo en cada centro de estudio como parte del procedimiento de implementación (como el ajuste fino del algoritmo en los datos locales), este proceso también debe describirse claramente.

CONSORT-AI 5 (i) Extensión: indique qué versión del algoritmo de IA se utilizó. Explicación. Al igual que otras formas de software como dispositivo médico, es probable que los sistemas de IA sufran múltiples iteraciones y actualizaciones durante su vida útil. Por lo tanto, es importante especificar qué versión del sistema de IA se utilizó en el ensayo clínico, si es la misma que la versión evaluada en estudios anteriores que se han utilizado para justificar la justificación del estudio, y si la versión cambió durante la realización del ensayo. Si es el caso, el informe debe describir lo que ha cambiado entre las versiones pertinentes y la justificación de los cambios. Cuando esté disponible, el informe debe incluir una referencia de marcado reglamentario, como un identificador único de dispositivo, que requiere un nuevo identificador para las versiones actualizadas del dispositivo47.

CONSORT-AI 5 (ii) Extensión: describa cómo se adquirieron y seleccionaron los datos de entrada para la intervención de IA. Explicación. El desempeño de cualquier sistema de IA puede depender críticamente de la naturaleza y la calidad de los datos de entrada48. Debe proporcionarse una descripción del tratamiento de los datos de entrada, incluida la adquisición, la selección y el preprocesamiento antes del análisis por parte del sistema de IA. La exhaustividad y la transparencia de esta descripción son esenciales para la replicabilidad de la intervención más allá del ensayo clínico en el mundo real. También ayuda a los lectores a identificar si los procedimientos de manejo de datos de entrada se estandarizaron en todos los centros del ensayo clínico.

CONSORT-AI 5 (iii) Extensión: describa cómo se evaluaron y manejaron los datos de entrada de mala calidad o no disponibles. Explicación. Al igual que en CONSORT-AI 4a (ii), los “datos de entrada” se refieren a los datos requeridos por la intervención de IA para cumplir su propósito. Como se discute en el punto 4a (ii), el rendimiento de los sistemas de IA puede verse comprometido como resultado de la mala calidad o la falta de datos de entrada49 (por ejemplo, un artefacto de movimiento excesivo en un electrocardiograma). El informe del ensayo clínico debe informar de la cantidad de datos que faltan, así como de la forma en que se identificaron y gestionaron. El informe también debe especificar si había un estándar mínimo requerido para los datos de entrada y, cuando no se alcanzó este estándar, cómo se manejó esto (incluyendo el impacto en, o cualquier cambio en, la vía de atención del participante).

Los datos de mala calidad o no disponibles también pueden afectar a las intervenciones no relacionadas con la IA. Por ejemplo, una calidad inferior a la óptima de una exploración podría afectar a la capacidad de un radiólogo para interpretarla y realizar un diagnóstico. Por lo tanto, es importante que esta información se comunique igualmente en la intervención de control, cuando sea pertinente. Si esta norma de calidad mínima fuera diferente de los criterios de inclusión de los datos de entrada utilizados para evaluar la elegibilidad antes de la aleatorización, debería indicarse.

CONSORT-AI 5 (iv) Extensión: especifique si hubo interacción entre humanos y la IA en el manejo de los datos de entrada, y qué nivel de experiencia se requirió de los usuarios. Explicación. Debe proporcionarse una descripción de la interfaz persona-IC y de los requisitos para una interacción satisfactoria cuando se manejan datos de entrada; por ejemplo, la selección por parte del clínico de regiones de interés de un portaobjetos de histología que luego interpreta un sistema de diagnóstico de IA50, o la selección por parte de un endoscopista de un vídeo de colonoscopia como datos de entrada para un algoritmo diseñado para detectar pólipos28. La descripción de la formación del usuario y las instrucciones sobre cómo deben manejar los datos de entrada aportan transparencia y posibilidad de reproducción de los procedimientos del ensayo clínico. La falta de claridad en la interfaz persona-IC puede conducir a la falta de un enfoque estándar y puede tener implicaciones éticas, especialmente en caso de daño51, 52. Por ejemplo, puede no estar claro si un caso de error se produjo debido a una desviación humana del procedimiento instruido, o si fue un error cometido por el sistema de IA.

CONSORT-AI 5 (v) Extensión: especificar el resultado de la intervención de IA. Explicación. El resultado de la intervención de IA debe especificarse claramente en el informe del ensayo clínico. Por ejemplo, un sistema de IA puede producir una clasificación o probabilidad diagnóstica, una acción recomendada, una alarma que alerte sobre un evento, una acción instigada en un sistema de bucle cerrado (como la titulación de infusiones de medicamentos) u otra salida. La naturaleza del resultado de la intervención de la IA tiene implicaciones directas en su capacidad de uso y en cómo puede conducir a acciones y resultados posteriores.

CONSORT-AI 5 (vi) Extensión: expliqué cómo los resultados de la intervención de IA contribuyeron a la toma de decisiones u otros elementos de la práctica clínica. Explicación. Dado que los resultados de salud también pueden depender críticamente de la forma en que los seres humanos interactúan con la intervención de IA, el informe debe explicar cómo se utilizaron los resultados del sistema de IA para contribuir a la toma de decisiones u otros elementos de la práctica clínica. Esto debe incluir una descripción adecuada de las intervenciones posteriores que pueden afectar a los resultados. Al igual que en CONSORT-AI 5 (iv), cualquier efecto de la interacción entre el ser humano y la IA en los resultados debe describirse en detalle, incluyendo el nivel de experiencia requerido para entender los resultados y cualquier formación y/o instrucciones proporcionadas para este fin. Por ejemplo, un sistema de detección de cáncer de piel que produzca un porcentaje de probabilidad como resultado debe ir acompañado de una explicación de cómo se interpretó este resultado y cómo actuó el usuario, especificando tanto las vías previstas (por ejemplo, la escisión de la lesión cutánea si el diagnóstico es positivo) como los umbrales para entrar en estas vías (por ejemplo, la escisión de la lesión cutánea si el diagnóstico es positivo y la probabilidad es > 80%). La información producida por las intervenciones de comparación debe describirse de forma similar, junto con una explicación de cómo se utilizó dicha información para llegar a las decisiones clínicas sobre el tratamiento del paciente, cuando sea pertinente. Debe informarse de cualquier discrepancia en la forma en que se tomó la decisión en comparación con la forma en que se pretendía que se tomara (es decir, según lo especificado en el protocolo del ensayo).

CONSORT-AI 4a (i): indique los criterios de inclusión y exclusión a nivel de participantes. CONSORT-AI 4a (ii): indicar los criterios de inclusión y exclusión a nivel de los datos de entrada. CONSORT 13b (elemento central de CONSORT): Para cada grupo, las pérdidas y exclusiones después de la aleatorización, junto con las razones

## Section: RESULTADOS

CONSORT-AI 19 Extensión: describa los resultados de cualquier análisis de los errores de ejecución y cómo se identificaron los errores, cuando corresponda. Si no se planificó o se hizo tal análisis, explique por qué no. Explicación. Informar sobre los errores de rendimiento y el análisis de los casos de fracaso es especialmente importante para las intervenciones de IA. Los sistemas de IA pueden cometer errores que pueden ser difíciles de prever pero que, si se permite su despliegue a escala, podrían tener consecuencias catastróficas53. Por lo tanto, la reporte de casos de error y la definición de estrategias de mitigación de riesgos son importantes para informar sobre cuándo, y para qué poblaciones, puede aplicarse la intervención con seguridad. Los resultados de cualquier análisis de errores de funcionamiento deben ser comunicados y las implicaciones de los resultados deben ser discutidas.

## Section: RESULTADOS › Otra información

CONSORT-AI 25 Extensión: indique si se puede acceder a la intervención de IA y/o a su código y cómo, incluyendo cualquier restricción de acceso o reutilización. Explicación. El informe del ensayo clínico debe aclarar si se puede acceder a la intervención de IA y/o a su código o reutilizarlos, y cómo hacerlo. Debe incluir detalles sobre la licencia y cualquier restricción de acceso.

## Section: DISCUSIÓN

CONSORT-AI es una nueva extensión de las directrices de reporte desarrollada mediante un consenso internacional de múltiples partes interesadas. Su objetivo es promover el reporte transparente de los ensayos de intervenciones de IA y pretende facilitar la evaluación crítica y la síntesis de la evidencia. Los ítems de la extensión añadidos en CONSORT-AI abordan una serie de cuestiones específicas de la implementación y evaluación de las intervenciones de IA, que deben considerarse junto con la lista de verificación básica de CONSORT 2010 y otras extensiones de CONSORT54. Es importante tener en cuenta que se trata de requisitos mínimos y que puede ser útil incluir elementos adicionales no incluidos en las listas de verificación en el informe o en los materiales suplementarios (Cuadro suplementario 2).

Tanto en CONSORT-AI como en su proyecto complementario, SPIRIT-AI, se hizo hincapié en la adición de varios ítems nuevos relacionados con la propia intervención y su aplicación en el contexto clínico. Los puntos 5 (i)-5 (vi) se añadieron para abordar las consideraciones específicas de la IA en las descripciones de la intervención. Se hicieron recomendaciones específicas relativas a los sistemas de IA en relación con la versión del algoritmo, los datos de entrada y salida, la integración en los entornos de los ensayos clínicos, la experiencia de los usuarios y el protocolo para actuar según las recomendaciones del sistema de IA. Se acordó que estos detalles son críticos para la evaluación independiente o la replicación del ensayo clínico. Los editores de las revistas informaron de que, a pesar de la importancia de estos elementos, en la actualidad suelen faltar en los informes de los ensayos en el momento de su presentación para la publicación, lo que da más peso a su inclusión como elementos de extensión específicamente enumerados.

Un tema recurrente en los comentarios del Delphi y en el debate del grupo de consenso fue la seguridad de los sistemas de IA. Esto se debe al reconocimiento de que los sistemas de IA, a diferencia de otras intervenciones sanitarias, pueden producir errores impredecibles que no son fácilmente detectables o explicables por el juicio humano. Por ejemplo, los cambios en las imágenes médicas que son invisibles, o parecen aleatorios, para el ojo humano pueden cambiar por completo la probabilidad del resultado del diagnóstico55, 56. La preocupación es que, dada la facilidad teórica con la que los sistemas de IA podrían desplegarse a escala, cualquier consecuencia perjudicial no intencionada podría ser catastrófica. El punto 19 de CONSORT-AI, que requiere la especificación de cualquier plan para analizar los errores de rendimiento, se añadió para enfatizar la importancia de anticipar los errores sistemáticos cometidos por el algoritmo y sus consecuencias. Más allá de esto, también se debe alentar a los investigadores a explorar las diferencias en las tasas de rendimiento y error entre los subgrupos de población. Se ha demostrado que los sistemas de IA pueden estar sistemáticamente sesgados hacia diferentes resultados, lo que puede conducir a un tratamiento diferente o incluso injusto, sobre la base de las características existentes53, 57-59.

El tema de los sistemas de IA de “evolución continua” (también conocidos como sistemas de IA de “adaptación continua” o “aprendizaje continuo”) se debatió ampliamente durante la reunión de consenso, pero se acordó excluirlo del CONSORT-AI. Se trata de sistemas de IA con capacidad para entrenarse continuamente con nuevos datos, lo que puede provocar cambios en el rendimiento a lo largo del tiempo. El grupo señaló que, si bien es interesante, este campo se encuentra en una fase relativamente temprana de su desarrollo, sin ejemplos tangibles en aplicaciones sanitarias, y que no sería apropiado que se incluyera en CONSORT- IA en esta fase60. Este tema será objeto de seguimiento y se revisará en futuras iteraciones de CONSORT-AI. Cabe señalar que los cambios incrementales del software ya sean continuos o iterativos, intencionados o no, podrían tener graves consecuencias en el rendimiento de la seguridad después de su despliegue. Por lo tanto, es de vital importancia que dichos cambios se documenten e identifiquen por versión de software y que se establezca un sólido plan de vigilancia posterior al despliegue.

Este estudio se enmarca en el contexto actual de la IA en la salud, por lo que hay que señalar varias limitaciones. En primer lugar, hay relativamente pocos ensayos de intervención publicados en el campo de la IA para la salud; por lo tanto, los debates y las decisiones tomadas durante este estudio no siempre se apoyaron en los ejemplos existentes de ensayos clínicos completados. Esto se debe a nuestro objetivo declarado de abordar los problemas de información deficiente en este campo tan pronto como sea posible, reconociendo los fuertes impulsores en el campo y los desafíos específicos del diseño de estudios y la presentación de informes para la IA. A medida que la ciencia y el estudio de la IA evolucionan, acogemos con agrado la colaboración con los investigadores para coevolucionar estas normas de reporte y garantizar su continua relevancia. En segundo lugar, la búsqueda bibliográfica de ECA de IA utilizó terminología como “inteligencia artificial”, “aprendizaje automático” y “aprendizaje profundo”, pero no términos como “sistemas de apoyo a la decisión clínica” o “sistemas expertos”, que se utilizaron más comúnmente en la década de 1990 para las tecnologías respaldadas por sistemas de IA y comparten riesgos similares a los de los ejemplos recientes61. Es probable que tales sistemas, si se publicaran hoy en día, se indexarían bajo “inteligencia artificial” o “aprendizaje automático”; sin embargo, los sistemas de apoyo a la decisión clínica no se discutieron activamente durante este proceso de consenso. En tercer lugar, la lista inicial de elementos candidatos fue generada por un grupo relativamente pequeño de expertos formado por los miembros del grupo de dirección y otros expertos internacionales; sin embargo, los elementos adicionales del grupo Delphi más amplio se sometieron a la consideración del grupo de consenso, y no se sugirieron nuevos elementos durante la reunión de consenso o la evaluación posterior a la reunión. Al igual que la declaración CONSORT, la extensión CONSORT-AI pretende ser una guía mínima para la presentación de informes, y hay consideraciones adicionales específicas de la IA para los informes de los ensayos que pueden justificar su consideración (Cuadro suplementario 2). Esta extensión está dirigida particularmente a los investigadores y lectores que informan o evalúan ensayos clínicos; sin embargo, también puede servir como guía útil para los desarrolladores de intervenciones de IA en las primeras etapas de validación de un sistema de IA. Los investigadores que deseen informar sobre estudios que desarrollen y validen las propiedades diagnósticas y predictivas de los modelos de IA deben remitirse a TRIPOD-ML (Transparent Reporting of a Multivariable Prediction Model for Individual Prognosis or Diagnosis-Machine Learning, Informes transparentes de un modelo de predicción multivariable para el pronóstico individual o el aprendizaje de la máquina de diagnóstico) y a STARD-AI (Standards for Reporting Diagnostic Accuracy Studies-Artificial Intelligence), ambas en fase de desarrollo32, 62. Otras directrices potencialmente relevantes, que son agnósticas al diseño del estudio, están registradas en la red EQUATOR63. Se espera que la ampliación del CONSORT-AI fomente la planeación temprana y cuidadosa de las intervenciones de IA para los ensayos clínicos y esto, junto con el SPIRIT-AI, debería ayudar a mejorar la calidad de los ensayos para las intervenciones de IA. El desarrollo de la guía CONSORT-AI no incluye elementos adicionales dentro de la sección de discusión de los informes de los ensayos. Se consideró que las orientaciones proporcionadas por el CONSORT 2010 sobre las limitaciones, la generalización y la interpretación de los ensayos eran trasladables a los ensayos de intervenciones de IA.

También se reconoce que la IA es un campo que evoluciona rápidamente y que será necesario actualizar el CONSORT-AI a medida que se desarrolle la tecnología y sus nuevas aplicaciones. En la actualidad, la mayoría de las aplicaciones de la IA implican la detección, el diagnóstico y el triaje de enfermedades, y es probable que esto haya influido en la naturaleza y el orden de prioridad de los elementos del CONSORT-AI. A medida que surjan aplicaciones más amplias que utilicen la “IA como terapia”, será importante seguir evaluando el CONSORT-AI a la luz de dichos estudios. Además, los avances en las técnicas computacionales y la capacidad de integrarlas en los flujos de trabajo clínicos aportarán nuevas oportunidades de innovación que beneficien a los pacientes. Sin embargo, pueden ir acompañados de nuevos retos en torno al diseño de los estudios y la presentación de informes. Con el fin de garantizar la transparencia, minimizar los posibles sesgos y promover la fiabilidad de los resultados y el grado en que pueden ser generalizables, el Grupo Directivo de SPIRIT-AI y CONSORT-AI seguirá vigilando la necesidad de actualizaciones.

## Section: Agradecimientos y financiación.

Damos las gracias a los participantes en el estudio Delphi y el estudio piloto (Nota complementaria); a E. Marston (Universidad de Birmingham, Reino Unido) por su apoyo estratégico; a C. Radovanovic (University Hospitals Birmingham NHS Foundation Trust, Reino Unido) y A. Walker (Universidad de Birmingham, Reino Unido) por el apoyo administrativo. Las opiniones expresadas en esta publicación son las de los autores, participantes en el Delphi y de las partes interesadas y pueden no representar las opiniones de la institución anfitriona. Este trabajo ha sido financiado por Wellcome Trust Institutional

Strategic Support Fund: Digital Health Pilot Grant, Research England (parte de investigación e innovación del Reino Unido), Health Data Research UK y a Alan Turing Institute.

El estudio fue patrocinado por la Universidad de Birmingham, Reino Unido. Los financiadores y patrocinadores del estudio no intervinieron en el diseño ni en la realización del estudio, ni en la recopilación, gestión, análisis e interpretación de los datos, ni en la preparación de los informes; preparación, revisión o aprobación del manuscrito; ni en la decisión de presentar el manuscrito para su publicación. M.J.C. es investigador principal del National Institute for Health Research (NIHR) y recibe financiación del NIHR, de Birmingham; Birmingham Biomedical Research Centre; el

NIHR Surgical Reconstruction and Microbiology Research Centre y NIHR ARC West Midlands, University of Birmingham y University Hospitals Birmingham NHS Foundation Trust; Health Data Research UK; Innovate UK (parte de investigación e innovación del Reino Unido) Research and Innovation); the Health Foundation; Macmillan Cancer Support; and UCB Pharma. A.D.y J.D. son también investigadores principales del NIHR. Las opiniones expresadas en este artículo son de los autores y no necesariamente las del NIHR o el Departamento de Salud y Asistencia Social. S.J.V. recibe financiación del Engineering and Physical Sciences Investigación e Innovación del Reino Unido (UKRI), Accenture, Warwick Impact Fund, Health Data Research UK y el Fondo Europeo de Desarrollo Regional. S.R. Es empleado del Consejo de Investigación Médica (UKRI). D.M. Cuenta con el apoyo de una cátedra de investigación de la Universidad de Ottawa. M.K.E. Cuenta con el apoyo de la Administración de Alimentos y Medicamentos de EE.UU. (FDA), y D.P. Cuenta en parte con el apoyo de la Oficina del director de la Biblioteca Nacional de Medicina de EE.UU. (NLM) de los Institutos Nacionales de Salud (NIH). A.B. Cuenta con el apoyo de los 7K01HL141771-02 de los Institutos Nacionales de Salud (NIH). Este artículo puede no coincidir con las opiniones o políticas del NIH y de la FDA. Refleja únicamente los puntos de vista y opiniones de los autores. Agradecemos también al Comité de Inteligencia artificial de la Asociación Colombiana de Radiología (ACR) por su traducción, Mauricio De Jesús Solano Diaz (Universidad de Antioquia) por su apoyo administrativo y editorial.

## Section: Contributor Information

GRUPO DE DIRECCIÓN SPIRIT-AI Y CONSORT-AI:

Alastair K. Denniston, An-Wen Chan, Ara Darzi, Christopher Holmes, Christopher Yau, David Moher, Hutan Ashrafian, Jonathan J. Deeks, Lavinia Ferrante di Ruffano, Livia Faes, Melanie J. Calvert, Pearse A. Keane, Samantha Cruz Rivera, Sebastian J. Vollmer, and Xiaoxuan Liu

Grupo de Consenso SPIRIT-AI y CONSORT-AI:

Aaron Y. Lee, Adrian Jonas, Andre Esteva, Andrew L. Beam, An-Wen Chan, Maria Beatrice Panico, Cecilia S. Lee, Charlotte Haug, Christophe J. Kelly, Christopher Yau, Cynthia Mulrow, Cyrus Espinoza, John Fletcher, David Moher, Dina Paltoo, Elaine Manna, Gary Price, Gary S. Collins, Hugh Harvey, James Matcham, Joao Monteiro, M. Khair ElZarrad, Lavinia Ferrante di Ruffano, Luke Oakden-Rayner, Melanie J. Calvert, Melissa McCradden, Pearse A. Keane, Richard Savage, Robert Golub, Rupa Sarkar, and Samuel Rowley


---

# Revolutionizing Medicinal Chemistry: The Application of Artificial Intelligence (AI) in Early Drug Discovery

- **Authors:** Ri Han, Hongryul Yoon, Gahee Kim, Hyundo Lee, Yoonji Lee
- **Issuer:** Pharmaceuticals (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2023-09-06
- **Language:** en
- **DOI:** 10.3390/ph16091259
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37765069/
- **Licence:** CC-BY

## Section: Abstract

Artificial intelligence (AI) has permeated various sectors, including the pharmaceutical industry and research, where it has been utilized to efficiently identify new chemical entities with desirable properties. The application of AI algorithms to drug discovery presents both remarkable opportunities and challenges. This review article focuses on the transformative role of AI in medicinal chemistry. We delve into the applications of machine learning and deep learning techniques in drug screening and design, discussing their potential to expedite the early drug discovery process. In particular, we provide a comprehensive overview of the use of AI algorithms in predicting protein structures, drug–target interactions, and molecular properties such as drug toxicity. While AI has accelerated the drug discovery process, data quality issues and technological constraints remain challenges. Nonetheless, new relationships and methods have been unveiled, demonstrating AI’s expanding potential in predicting and understanding drug interactions and properties. For its full potential to be realized, interdisciplinary collaboration is essential. This review underscores AI’s growing influence on the future trajectory of medicinal chemistry and stresses the importance of ongoing synergies between computational and domain experts.

## Section: 1. Introduction

Artificial intelligence (AI), a field within computer science, focuses on developing methods that empower computers to perform tasks typically associated with human intelligence, such as thinking and learning. AI is having a revolutionary impact on various facets of our lives and spanning across numerous industry sectors, with the pharmaceutical sector experiencing no exception to this transformation [1]. Also, in the medical field, deep learning techniques classify lung cancer with high accuracy, and AI addresses challenges in processing continuous streams of big data from medical IoT devices [2,3]. The emergence of AI has ushered in a new era in drug discovery research, delivering a paradigm shift from traditional trial-and-error-based or hypothesis-driven methods toward more rational and data-driven approaches [1]. The value of AI is immense as it serves as a technology that can significantly reduce the extensive time and financial investments required for the discovery of a new drug.

When used properly, AI technologies can help analyze vast amounts of data, such as genomic, proteomic, and chemical information, to identify potential drug molecules and predict drug efficacy or toxicity [4]. By analyzing complex datasets and identifying hidden patterns, machine learning (ML) or deep learning (DL) algorithms can find novel targets associated with multi-omics data and help search for novel chemical entities with biological activities. They have not only expedited the identification of potential drug candidates but have also proven invaluable in the process of drug repurposing [5]. AI can predict potential new uses for existing drugs, a breakthrough that has the potential to accelerate the drug development process and reduce associated costs [5]. This capability is particularly significant in addressing urgent medical needs, as repurposing existing drugs can bypass lengthy and costly phases of preclinical testing and safety evaluation. Moreover, AI has emerged as a key tool for personalized medicine by aiding the development of drugs that are tailored to individual patients’ genetic profiles. In the future, the demand for AI in drug discovery is expected to grow as the technology becomes more advanced and many more data become available [1].

In the realm of medicinal chemistry, AI has shown promising results in the discovery of new chemical scaffolds with therapeutic potential. It has the capacity to scrutinize vast chemical spaces and extract meaningful patterns, thereby significantly reducing the time required for identifying potential drug candidates [4,6]. ML/DL algorithms can be trained to predict the biological activities, pharmacokinetic properties, and also toxicity profiles of molecules [7]. In addition, the current DL methods can generate novel molecular structures that match desired therapeutic profiles [8,9]. Building on the past decade’s remarkable advances, AI is now being harnessed to automate the process of drug design. Molecular docking, the method that predicts the interaction between a small molecule and a protein, has traditionally been a computationally intensive task. Today, AI is being utilized to predict the likelihood of molecular binding, its strength, and the most energetically favorable position, thereby automating this critical process. In addition, it can be utilized to optimize the chemical structures of drug candidates for enhanced efficacy and reduced toxicity.

While the promise of AI in medicinal chemistry is profound, the integration of AI into drug discovery pipelines presents ongoing challenges [4,10]. Issues related to the quality and availability of data, interpretability of AI models, and regulatory considerations persist [4]. However, as we navigate the ongoing digital transformation, it becomes increasingly evident that AI-based approaches hold immense potential to revolutionize drug discovery and reshape the field of medicinal chemistry. By leveraging AI’s capabilities and addressing the associated challenges, we can harness the power of this technology to accelerate the discovery of safe and effective molecules, ultimately revolutionizing the drug discovery process.

In this article, we provide a comprehensive review of the state-of-the-art technologies that employ AI in medicinal chemistry. We explore the current advancements and future prospects in this rapidly evolving field, shedding light on the transformative role of AI and its potential impact on drug discovery. The main purpose of this article is not only to outline the breakthroughs AI has facilitated but also to critically evaluate where it falls short or poses new challenges. By considering both the promises and pitfalls of AI in this domain, we aim to offer a balanced perspective that will guide future endeavors. Through a holistic understanding of the state of AI in drug discovery, we aspire to foster a foundation for its more robust and insightful application in the efficient and innovative drug discovery.

## Section: 2. AI/ML Algorithms and Bio Big Data Utilized in Drug Discovery Research

Bio big data encompass a wide range of data types, such as genomic, proteomic, and transcriptomic data, collected from various sources such as high-throughput experiments and clinical studies, providing invaluable insights for drug discovery [6]. AI/ML algorithms, which are computational methods that allow computers to learn from data and recognize patterns, help researchers navigate these vast amounts of bio big data and identify potential drug candidates more effectively and accurately, revolutionizing the drug discovery process [4,11]. In order to optimally exploit AI and ML strategies within the context of drug discovery, it is essential to grasp the fundamental principles that underpin a range of machine learning methodologies. These methodologies, including supervised, unsupervised, and reinforcement learning, are employed to address a diverse array of research challenges within this domain.

## Section: 2. AI/ML Algorithms and Bio Big Data Utilized in Drug Discovery Research › 2.1. Overview of ML Algorithms

AI is a broad field that encompasses various computational techniques, enabling machines to mimic human-like intelligence capabilities, such as learning, reasoning, and problem-solving. ML is a subset of AI specifically focusing on the development of algorithms that learn, adapt, and perform tasks through data processing and analysis [12]. By identifying patterns, making predictions, and refining algorithms based on input data, ML allows machines to improve their prediction performance and decision-making capabilities autonomously over time. ML algorithms can be broadly categorized into three types: supervised learning, unsupervised learning, and reinforcement learning.

## Section: 2. AI/ML Algorithms and Bio Big Data Utilized in Drug Discovery Research › 2.1. Overview of ML Algorithms › 2.1.1. Supervised Learning

Supervised learning is a type of machine learning where algorithms are trained using labeled data, meaning each input data sample is paired with the appropriate or correct output [12]. The algorithm uses these input–output pairs to learn a model that can make accurate predictions for new, unseen data. Supervised learning algorithms, such as support vector machine (SVM), support vector regression (SVR), naïve Bayes, tree-based, and random forest (RF), can identify potential drug candidates by analyzing large datasets and identifying patterns and relationships that humans may not easily detect (Figure 1) [13,14].

The support vector machine (SVM) is a powerful tool, rooted in the principle of structural risk minimization, and is capable of classifying data, identifying outliers, and performing regression analysis. The core of the SVM methodology is the identification of an optimal decision boundary (i.e., hyperplane) that best separates data points across different classes [15]. This hyperplane is constructed by maximizing the margin, which represents the distance between the decision boundary and the closest training samples, also referred to as support vectors. In drug discovery, SVM is primarily employed to predict the biological activity of compounds or to classify molecular properties. One of the key strengths of SVM in such tasks is its ability to handle high-dimensional data and detect complex patterns, particularly within large and noisy datasets [16,17,18]. This makes SVM one of the top performers in predicting chemical and biological properties. However, it is crucial to note that SVM’s performance can be sensitive to the selection of the kernel function and its parameters [19]. Additionally, when dealing with imbalanced datasets, where one class significantly outnumbers the other, SVM may require additional processing steps to balance the data before application [19].

SVMs have established themselves as a significant tool in drug discovery due to their superior ability to analyze complex cheminformatics data. Their use extends to various tasks: they help in virtual screening processes [20,21], predicting drug–target interactions [22,23], and identifying new drug targets [24,25]. They are instrumental in predicting drug similarity in the quantitative structure–activity relationship (QSAR) domain, where the assumption is that structurally similar compounds will exhibit similar drug activities [23,26]. Furthermore, SVMs are employed to forecast activity cliffs, pairs of structurally similar compounds with a significant activity difference towards a specific target, thereby contributing to our understanding of critical drug–target interactions and aiding in new drug development [16,17,18].

The naïve Bayes algorithm is a probabilistic machine learning model rooted in Bayes’ theorem, a principle in probability theory that describes how to update the probabilities of hypotheses when given evidence [12,14]. Specifically, Bayes’ theorem is a mathematical principle that provides a way to update the probabilities of our previous hypotheses based on new evidence [14]. In other words, when new information is given, it helps us decide how to apply it to a hypothesis. The naïve Bayes algorithm takes this principle and applies it with a “naïve” assumption of conditional independence between features [27]. Essentially, it considers each data attribute as independent, thus, simplifying multivariate problems into separate univariate issues. This strong assumption simplifies computations and enables the handling of high-dimensional data with ease. In practice, naïve Bayes has been widely adopted in various fields, such as document analysis, spam detection, and cheminformatics, particularly in drug discovery and drug–target interaction prediction [14]. It is noted for its robustness and versatility. However, despite its simplicity and speed, naïve Bayes has its limitations. It assumes that the attributes in the dataset are entirely independent, which might not accurately reflect the actual dependencies present in the data. Moreover, while naïve Bayes performs reasonably well as a classifier, it is known to be a less reliable probability estimator, so its output probabilities should be interpreted cautiously.

In drug design, the naïve Bayes algorithm has been widely applied, helping predict the biological activities of compounds, assisting in the early selection of promising candidates, and estimating results before laboratory experiments [7,28]. It can predict protein–protein [29] and drug–drug interactions [30], which is vital for understanding cellular pathways and managing polypharmacy, where patients take multiple drugs. This algorithm can also anticipate drug–target interactions, facilitating drug repurposing and side effect prediction [31,32,33,34]. Lastly, it can classify compounds into specific categories quickly, although it operates on the assumption of feature independence, which may not always hold [27,35].

Tree-based ML algorithms use decision trees (DTs) to predict target values based on observed features. DTs are flowchart-like structures where each internal node represents a feature, branches represent decision rules, and leaf nodes indicate outcomes, allowing for classification and regression tasks. However, single decision trees are prone to overfitting and struggle to generalize to new data. To overcome this limitation, ensemble methods, such as random forest (RF), prove to be particularly beneficial [12,13] The RF algorithm creates an ensemble of DTs, each built on a different sample of the data [14]. Each split in these DTs is determined from a different subset of features, leading to decorrelation between the trees. This strategy combats the overfitting problem often encountered with single DTs. By aggregating results from numerous, ideally uncorrelated, DTs, RF leverages the power of ensemble learning, enhancing its predictive power and stability. RF provides benefits in early drug discovery, including enhanced feature selection and predictive ability in QSAR analysis, making it useful for handling large, high-dimensional datasets in virtual screening [36]. However, to manage overfitting risks, careful data partitioning, model complexity control, and cross-validation are necessary. Analyzing feature importance can improve interpretability [12].

Building on these strengths, RF has been integrated into various stages of drug development, such as predicting chemical and drug properties, protein-related predictions, conducting virtual screening and docking studies, drug response prediction, polypharmacology research, and drug side effects prediction. Specifically, RF has proven helpful in QSAR modeling to correlate a drug’s chemical structure with its biological activity, estimating key parameters such as drug solubility and solvent density [36]. In protein-related predictions, RF assists in determining protein pKa values and protein–protein affinity, as well as identifying protein function and type, which is vital in target-based drug design [37]. Additionally, RF models facilitate efficient virtual screening of compound libraries to predict potential binding with target proteins, making them indispensable in integrated virtual screening and docking studies, including peptide docking studies [38].

## Section: 2. AI/ML Algorithms and Bio Big Data Utilized in Drug Discovery Research › 2.1. Overview of ML Algorithms › 2.1.2. Unsupervised Learning

Unsupervised learning is a method that trains a machine in the absence of any correct answers. It traverses unlabeled data, striving to decipher latent patterns or structures devoid of pre-defined output [5]. In this case, the learning process often involves grouping vast amounts of data based on similar characteristics, a process known as clustering. Even though the correct answer for the input value is not known, unsupervised learning can be used to uncover hidden patterns or features within the data, making it a powerful strategy for clustering and dimensionality reduction. Unsupervised learning algorithms, encompassing hidden Markov models (HMMs), growing self-organizing maps (GSOMs), k-means clustering, principal component analysis (PCA), autoencoders, and t-SNE, exhibit the capacity to cluster similar molecules, unearth novel molecular scaffolds, or reveal previously unknown correlations between biological entities (Figure 2).

Hidden Markov models (HMMs) are probabilistic models developed to work with sequential data. These models rely on a set of unobserved, hidden states and the probability of observable outputs that each state generates [39]. In a specific state, an outcome or observation can be produced according to an associated probability distribution, making HMMs an instrumental tool for various applications. HMMs excel at processing sequential data, modeling temporal dependencies, and managing missing and noisy data, making them robust against overfitting due to their probabilistic nature [40]. However, since HMMs rely on the Markov assumption, asserting that future states depend only on the current state, it might not always be a realistic presumption for many real-world scenarios.

HMMs have proven to be an invaluable tool in drug discovery, primarily due to their prowess in analyzing sequential biological data. They find extensive applications in various pivotal tasks. HMMs are critical in protein homology detection, efficiently identifying and classifying protein families within sequences [41,42]. This ability is vital in discovering new proteins that serve as potential targets for novel drugs. Further, HMMs play a significant role in protein sequence analysis, a critical process in understanding the function of a protein and selecting it as a target in the early stages of drug development [43,44]. Through augmenting sequence analysis, HMMs reveal more accurate and profound insights, thereby enhancing the outcomes. Lastly, HMMs are instrumental in predicting protein structures and 3D modeling. Accurately predicting and modeling complex protein structures is a crucial part of drug discovery, as it assists in predicting the efficacy and binding characteristics of a potential drug [45].

K-means clustering is a powerful tool, grounded in the partitioning principle, adept at classifying data into distinct ‘k’ clusters. A centroid, the mean of all data points within that cluster, characterizes each cluster. This algorithm aims to assign each data point to the nearest cluster, creating homogeneous groups of similar data points [1]. In drug discovery, k-means clustering is primarily used to define proper molecular descriptors, compute the similarities between compound samples, and group compound features based on computed similarities. A key strength of k-means in drug development is its ability to handle high-dimensional data and discern complex patterns, particularly within large and noisy datasets. This capability makes k-means one of the foremost performers in predicting chemical and biological properties. However, it is essential to note that k-means performance can be sensitive to the initial selection of centroids and the predetermined number of clusters. Furthermore, when dealing with imbalanced datasets, k-means may require additional pre-processing steps to balance the data before application. Despite these challenges, the simplicity, scalability, and flexibility of the k-means algorithm make it a vital tool in drug discovery.

Building upon the basic principles, k-means clustering finds extensive use in drug discovery, primarily due to its ability to handle multidimensional data. It helps define molecular descriptors, numerical entities that represent a compound’s physicochemical properties, thereby aiding in predicting its behavior [46,47]. The technique is also proficient in calculating similarities between compound samples, revealing relationships among compounds, and selecting potential drug candidates [48,49]. In addition, k-means clustering is used for clustering compound properties and selecting protein structures based on similarities [46,48,50]. Such grouping helps analyze a drug’s effect, and by identifying similar protein conformations, it enhances the performance of ensemble docking [51,52].

T-distributed stochastic neighbor embedding (t-SNE) is a technique that simplifies high-dimensional data into a more digestible, low-dimensional form while preserving the relative similarities of data points [1]. In short, t-SNE evaluates the similarity of data points in a high-dimensional space, giving higher probabilities to those more similar [53,54]. It maps these points to a lower-dimensional space, aiming to keep these similarities intact [1,53]. The ultimate goal is to create an easier-to-understand visualization while respecting the original data structure. A key advantage of t-SNE is its unique ability to maintain local and global high-dimensional data structures, unveiling patterns other reduction techniques such as PCA might overlook [54]. While t-SNE is effective for visualizing data, it does have limitations. It requires calculating pairwise similarities for all data points, which can be computationally demanding for large datasets [55]. Also, it often struggles to identify relevant clusters at varying scales and is sensitive to hyperparameters, necessitating careful tuning.

As a result, t-SNE plays a central role in drug design, particularly in compound clustering, drug target exploration, molecular representation, and drug design. t-SNE enables a comprehensive understanding and analysis of complex biological data and compound similarity by visualizing high-dimensional data in low-dimensional space. In particular, t-SNE assists in predicting the behavior of compounds through molecular descriptors, which are unique physicochemical characteristics, ultimately playing a crucial role in selecting potential drug candidates [56]. Moreover, t-SNE is employed to visualize biological data, aiding in the understanding of the relationship between drugs and their targets [57,58]. This can help discover new drug targets or identify new uses for existing drugs. Lastly, in visualizing complex biological data such as protein structures and gene expression profiles in lower dimensions, t-SNE enhances the technical aspects of molecular representation and drug design [59]. Due to its versatility and efficiency, t-SNE is expected to continue to play an essential role in shaping drug development strategies.

## Section: 2. AI/ML Algorithms and Bio Big Data Utilized in Drug Discovery Research › 2.1. Overview of ML Algorithms › 2.1.3. Reinforcement Learning

Reinforcement learning, a unique branch of machine learning, fine-tunes decision-making strategies through rewards or penalties for each action. Akin to learning via trial and error, a reward is given when the desired result is achieved, and the machine is trained to maximize this reward. If supervised learning and unsupervised learning proceed in a given static environment with the provided data, reinforcement learning, on the other hand, includes the process of collecting data in a dynamic environment. Reinforcement learning algorithms such as Q-learning and Monte Carlo tree search (MCTS) started to be used to revolutionize processes such as molecular docking, de novo drug design, and drug property optimization. These algorithms navigate molecular configurations, assist in constructing novel drug molecules, and balance objectives such as efficacy and side effects to produce promising drug candidates. It can aid the discovery of effective drug molecules and novel therapeutic strategies in a more creative, innovative way.

For example, Q-learning, a specific application of reinforcement learning, optimizes decisions through an intricate balance of ‘exploration’ and ‘exploitation,’ thus, enabling the model to continue learning while maximizing rewards [60]. Despite potential challenges such as computational intensity and the risk of suboptimal results if not properly balanced, Q-learning proves its worth by aiding in the discovery and optimization of molecular structures and compound characteristics [61]. It particularly excels in multi-property optimization, relationship identification among compounds, and the exploration of molecular space to identify promising candidates.

Further augmenting the capabilities of reinforcement learning in drug discovery is MCTS, another critical tool that enhances decision-making by deftly balancing ‘exploration’ and ‘exploitation’ [62]. Despite its computationally intensive nature and the challenge of striking the right balance, MCTS is indispensable due to its proficiency in navigating vast and complex molecular landscapes. It not only assists in the discovery and design of potential drug candidates but can also customize drugs to bind to specific targets [63,64,65]. MCTS particularly shines in retrosynthetic planning by offering a systematic approach to deconstructing complex organic molecules, thereby streamlining the planning of synthetic routes. By exploring a multitude of synthetic pathways, it helps chemists plan and execute synthesis more efficiently [66]. Additionally, MCTS enhances data mining in drug discovery, unearthing hidden patterns and structures in vast datasets.

## Section: 2. AI/ML Algorithms and Bio Big Data Utilized in Drug Discovery Research › 2.2. Deep Learning Method

A pivotal advancement in the field of AI was the introduction of deep learning (DL), a subset of ML algorithms, designed to mimic the information-processing mechanism of the human brain. The human brain contains approximately 100 billion neurons, the cells that make up the nervous system. These neurons are intricately connected in multiple layers through a structure called synapses, transmitting signals by exchanging electrochemical signals. This structure of the human nervous system inspired the creation of artificial neurons, leading to the concept of ‘perceptrons’, which marked the beginning of artificial neural networks (ANN). A multilayer perceptron (MLP) is a type of neural network that possesses multiple layers, known as hidden layers, situated between the input and output layers. When there are two or more hidden layers, the term ‘deep’ is used, highlighting the use of consecutive layers.

In DL algorithms, predicted outcomes are generated through multiple layers using the input data, and this prediction is then compared to the actual value to calculate the difference (Figure 3). To reduce this difference, the weights of the previous layers are adjusted in a process called back-propagation. This process is repeatedly performed to continually refine the model. Examples of popular deep learning algorithms include convolutional neural networks (CNNs), often used in image processing tasks; recurrent neural networks (RNNs), particularly effective for sequence data such as time series or natural language; and deep belief networks (DBNs), which utilize unsupervised learning with generative models. Other examples are autoencoders for creating compact representations and generative adversarial networks (GANs) for generating new data that resemble the input data. These diverse algorithms reflect the breadth and depth of deep learning’s potential applications.

Convolutional neural networks (CNNs) utilize small filters in several layers to detect patterns within data. Initially, CNNs extract simple features from the data and then combine them to extract more complex features. CNNs can extract useful features from images of molecular structures in drug discovery. CNNs have the primary advantage of effectively learning complex features from visual data. However, they require large amounts of data and significant computational resources, which can make model results difficult to interpret. Leveraging their fundamental capabilities, CNNs have found expansive usage in drug design, primarily for their proficiency in handling complex, multidimensional data.

In the field of molecular structure analysis, a CNN aids in deriving purposeful features or ‘descriptors’ that represent a compound’s physicochemical properties. For instance, BindScope employs deep convolutional neural networks to classify and visualize compounds on a large scale, based on their activity or inactivity in structure-based drug discovery [67]. Likewise, the use of artificial intelligence (AI) and machine learning technologies, such as a graph convolutional neural network (Graph-CNN), has facilitated the investigation and implementation of diverse molecular representations in drug discovery screening for identifying and predicting inhibitors of SARS-CoV-2 3CLpro [68]. These descriptors allow for accurate prediction of a compound’s behavior, while CNN excels at assessing similarities between different molecular structures, revealing intricate relationships among compounds. For example, in the ligand-based virtual screening approach, the L3D-PLS model employs CNN to extract crucial interaction features from grids surrounding aligned ligands, outperforming traditional methods in the lead optimization of small datasets [69]. In another application, the CAT–CPI model combines CNN with transformers to improve the prediction of compound-protein interactions, accelerating drug development [70]. Additionally, the FRSite method uses a faster R-CNN-based approach to accurately predict protein binding sites, introducing multi-source 3D data and RPN-3D networks to simultaneously predict the center and size of the binding site [71].

Moreover, CNNs are used to group molecular structures based on similarities, which is crucial for comprehending a drug’s impact and improving the performance of ensemble docking by identifying comparable molecular conformations. For instance, a recent study developed a deep learning model for compound classification using a distributed representation of compounds based on the SMILES notation [72]. Using this representation in a convolutional neural network (CNN), the model could process various compound types while obtaining low-dimensional representations of input features and outperforming standard methods in discriminating compound structures, including identified and unidentified motifs. This approach highlights CNNs’ adaptability and effectiveness in medicinal chemistry and enables a more nuanced understanding of the characteristics of compounds and potential drug interactions. Furthermore, in the context of large-scale data mining in drug design, CNNs assist in revealing patterns, correlations, and structures within enormous datasets.

Recurrent neural networks (RNNs) are a type of neural network designed to process continuous information. Over time, patterns are learned by these networks, which makes them suitable for natural language processing and time-series data analysis. In the case of drug development, RNNs can be beneficial in learning the amino acid sequence of a protein and predicting its impact on a specific illness. The primary benefit of RNNs lies in their ability to understand sequence information. However, as the sequence grows longer, they often fail to retain the initial information, which is a significant drawback.

They aid in constructing innovative drug molecules through various methods, enhancing the field of medicinal chemistry. For instance, combining stack-augmented recurrent neural networks with multi-objective reward-weighted sums in reinforcement learning optimizes the efficient drug design process, proposing a novel way to generate molecules with desired molecular characteristics [73]. By utilizing RNN models, the development of new derivatives of metronidazole and the synthesis and validation of compounds that inhibit bacterial strains such as E. coli, P. aeruginosa, B. subtilis, and S. aureus is explained [74]. The application of memory-augmented techniques using RNN-based architectures such as neural Turing machine (NTM) and differentiable neural computer (DNC) in creating new small molecules, analyzing their performance against simple RNNs, and assessing their validity, novelty, and attribute bias in de novo drug design are also explored [63]. These strategies translate chemical attributes into sequences such as simplified molecular-input line-entry system (SMILES), thus, assisting in forecasting novel potential drug candidates. Moreover, the effectiveness of neural networks, including RNNs, in forecasting drug–target interactions has been recognized. For example, a new deep learning approach using graph neural networks based on 3D structural information has been proposed to predict drug–target interactions [75]. The scope of RNN usage further spans the synthesis and testing of drug efficacy, offering a shift from traditional methods to a more data-centric approach, yielding more precise predictions and superior drug candidates.

A deep belief network (DBN) is a type of deep neural network structure that employs multiple restricted Boltzmann machines (RBMs) to stack layers of neurons. DBNs are utilized in drug development as a powerful tool to comprehend complex molecular properties. These learned properties are instrumental in the synthesis of potential drug candidates. DBNs exhibit strength in their capability to learn in an unsupervised manner, which enables them to discern intricate patterns within the input data. However, the down side associated with DBNs is that the learning process is intricate and a demands substantial amount of data and computational resources.

Drawing upon foundational concepts, DBNs demonstrate vast potential in drug discovery, particularly due to their capability to model complex, non-linear relationships in multi-dimensional data. They help to define molecular features and accurately predict the biological activity of novel compounds, thereby aiding in the identification of potential new drug candidates. For instance, AI-driven natural language processing and machine learning algorithms have been applied to explore challenges and opportunities in natural product (NPs) drug discovery, with specific AI approaches developed to identify biologically active natural products and capture the molecular ‘patterns’ of these privileged structures [76]. Notably, DBNs augment data mining in drug discovery, aiding in deciphering patterns, correlations, and structures within large datasets. For example, the application of a deep belief network (DBN) with a dropout mechanism to overcome the overfitting problem associated with small sample sizes has introduced a rapid and non-destructive drug identification method using near-infrared spectroscopy [77].

An autocoder comprises an encoder that compresses input data and a decoder that restores compressed data. In drug discovery, an autoencoder compresses complex molecular properties. These properties are then used to synthesize new drug candidates. Autoencoders have the advantage of learning unsupervised and effectively compressing important characteristics of input data. The disadvantages of autoencoders include their sensitivity to noise in data that contains noise.

Autoencoders have emerged as a powerful tool in drug design, offering promising applications in predicting drug–target binding affinity and generating novel compounds. Specifically, in drug design and synthesis, techniques such as variational autoencoders can be instrumental in engineering novel molecules by decoding latent spaces to generate valid, novel molecular structures that could serve as potential drugs. For example, the problem of generating invalid molecular structures in automated chemical design can be alleviated by recasting it as a constrained Bayesian optimization problem within the latent space of a variational autoencoder, thereby significantly enhancing the validity of the generated molecules [78]. By utilizing their ability to capture and compress high-dimensional data, autoencoders can effectively extract latent features from chemical structures and learn representations that capture the underlying relationships between drugs and their targets. This enables accurate prediction of binding affinities and facilitates the identification of potential drug candidates. For instance, a deep-unsupervised-learning-based method called AutoDTI++ has been proposed to enhance the performance of drug–target interaction (DTI) predictions [79]. Furthermore, autoencoders excel in predicting drug–protein interactions by learning the intricate patterns and dependencies between chemical compounds and protein structures. By encoding the molecular features of drugs and proteins into a lower-dimensional space, autoencoders can effectively capture complex interactions and predict the likelihood of binding events. This capability enhances the performance of virtual screening methods and enables efficient exploration of the vast chemical space. Specifically, a deep learning framework that combines variational autoencoders and attention mechanisms, using CNNs to extract local features, has been proposed to obtain crucial information about drugs and proteins and improve drug–protein interaction (DPI) predictions [80].

Generative adversarial networks (GANs) comprise a generator and a discriminator, two neural networks that learn from their interactions with each other. GANs can create new data that closely resemble real-world data. In drug development, GANs can produce new drug candidates that resemble real-world drugs. GANs have the advantage of being generative models that can learn from unsupervised data, but the disadvantage is their unstable learning process that makes it challenging to maintain a balance between the generator and discriminator.

Drawing upon their foundational principles, generative adversarial networks (GANs) have seen substantial application in drug discovery, primarily owing to their ability to learn complex data distributions. They play a crucial role in de novo molecular design, wherein deep generative models can effectively learn from existing data and generate novel molecules, addressing the inefficiencies and time-consuming aspects of traditional methods. In particular, recent developments in deep generative models for de novo molecular design have been reviewed, categorizing these models into two types, examining their strengths and weaknesses, and identifying current challenges [9]. Moreover, a new technique utilizing a deep learning GAN called “DNMG” has been proposed to integrate the 3D information of molecules and effectively predict and explore drug properties and binding affinities for new drug design [81].

GANs are also pivotal in the generation and analysis of high-content images in drug discovery assays. Specifically, a computer-based framework that employs three variations of GANs has been proposed for the automatic analysis of large-scale image data generated from drug tests. Among them, the DCGAN, in particular, has been applied to create realistic synthetic images that can be used to study the effects of drugs on cells and bacteria [82]. By learning data distribution, GANs can create synthetic images, enhancing the automatic analysis of voluminous image data generated in drug screening processes. Moreover, they prove instrumental in predicting drug–drug interactions (DDIs) by learning the patterns within large-scale data, leading to an understanding of unforeseen interactions. Specifically, a novel deep learning model known as DGANDDI utilizes two GAN architectures to deeply explore complementary knowledge between drug attributes and DDI network topology [83]. Another significant utilization of GANs is in predicting drug–target interactions, where they can learn the potential interactions between drugs and their respective protein targets, thereby directing the process of drug discovery. In particular, a novel approach using GANs implements a semi-supervised learning method that leverages both labeled and unlabeled data to predict the binding affinity between drugs and targets [84].

## Section: 2. AI/ML Algorithms and Bio Big Data Utilized in Drug Discovery Research › 2.3. Performance Metrics

Performance metrics are tools for evaluating a model’s efficacy, with different metrics utilized for classification and regression tasks. Accuracy, precision, recall, and the F1 score are commonly used to assess how accurately the model categorizes data. On the other hand, for regression, the mean squared error (MSE), mean absolute error (MAE), and root mean squared error (RMSE) measure the discrepancy between predicted and actual values. These metrics play a crucial role in understanding and enhancing model performance.

Classification models are supervised learning algorithms that categorize given data into one of the predefined classes. Key terminologies for evaluating the performance of the model include true positive (TP), true negative (TN), false positive (FP), and false negative (FN). TP represents the number of positive cases correctly detected by the model, making it an important metric for evaluating model performance. TN represents the number of negative cases correctly ignored by the model, which is especially crucial when wanting to avoid incorrect positive predictions. FP is when the model incorrectly predicts a data point that is actually negative as positive. Such predictions can give users incorrect information or unnecessary alerts. FN is when the model incorrectly predicts a data point that is actually positive as negative. FNs are missed positive cases by the model, which can have severe consequences. For instance, in a medical diagnostic model detecting diseases, an FN could result in a patient with the disease not receiving a diagnosis. Such terminology forms the basis for calculating performance metrics of classification models, which are essential to accurately determine the strengths, weaknesses, and areas of improvement of the model. Based on these terms, several performance metrics are calculated. These metrics reflect various aspects of classification model performance such as accuracy, sensitivity, and specificity, and their importance can vary depending on the specific application area [85].

The accuracy (ACC) indicates the proportion of data correctly classified by the model among its predictions. It is useful when the class distribution of the data is uniform. If one class greatly outnumbers the other, it can be challenging to fully assess the model’s performance based solely on accuracy. ACC=#correctly classified samples# All samples=TP+TNTP+FP+TN+FN

The precision (PREC) denotes the ratio of data points that are actually positive among those the model classified as positive. This metric becomes important when the cost of incorrect positive predictions is high. PREC=#samples correctly classified# samples assigned to class=TCTC+FP

The recall (REC) or sensitivity represents the ratio of data points the model predicted as positive among the actual positive data points. It is critical when the cost of incorrect negative predictions is high. REC=#true positive samples# samples classified positive=TPTP+FN

The F1 score is the harmonic mean of precision and recall, indicating a balance between the two metrics. It is especially useful when one class’s sample size is much smaller than the other. F1=2×precision×recallprecision+recall=2×TP2×TP+FP+FN

The specificity (SPEC) illustrates the ratio of actual negative class data points correctly predicted as negative by the model. SPEC=#true negative samples#samples classified negative=TNTN+FP

All these metrics fall within the [0, 1] range, where 1 indicates perfect prediction based on the metric, and 0 indicates an entirely incorrect prediction. Each performance metric emphasizes different aspects of the model, so the importance of a particular metric can increase depending on the specific application or problem. Therefore, it is crucial to consider these metrics comprehensively when evaluating and optimizing model performance.

A regression model is an algorithm that models the relationship between one or more independent variables and a continuous dependent variable. Such models are used to predict a continuous output value for given input variables. Various metrics are employed to assess the performance of a regression model by measuring the difference between the predicted and actual values.

The mean squared error (MSE) is the average of the squared differences between predicted and actual values. Due to its squaring of prediction errors, large errors can significantly inflate this value. MSE=1n∑i=1n(yi−y˜i)2

The mean absolute error (MAE) is the average of the absolute differences between predicted and actual values. It calculates the absolute error for each prediction and then averages those values. MAE=1n∑i=1n|xi−x|

The root mean squared error (RMSE) is the positive square root of MSE. RMSE provides an interpretation of the prediction error size in the original unit. While it gives greater weight to large errors, RMSE can be more interpretable as it represents the actual size of the prediction error. RMSE=1n∑i=1n(yi−y˜i)2

The R-squared, also known as the coefficient of determination, is a metric that illustrates the predictive power of a regression model. It indicates how well the model explains the variability in the data. R2=1−∑(yi−y˜i)2∑(yi−yˇi)2 y˜=predicted value of yyˇ=mean value of y

These metrics play a crucial role in evaluating the performance of a model, emphasizing different aspects. Therefore, when assessing and optimizing the performance of a regression model, it is essential to consider these metrics comprehensively.

## Section: 2. AI/ML Algorithms and Bio Big Data Utilized in Drug Discovery Research › 2.4. Databases in Drug Research

The effectiveness of ML or DL methods is predominantly contingent upon the availability of substantial, accurate, and reliable data. As technological advances continue to make data generation faster and more affordable, the volume of chemical, biological, and medical data has grown exponentially. There is a continuous effort to centralize these datasets and make them publicly available for research around the globe. This crucial information can be procured from many public databases, which serve as rich repositories of information that are indispensable for drug discovery. These databases encapsulate a wide array of knowledge about the efficacy of various drugs, potential side effects, the nature of drug targets, and intricate chemical structures. However, it is essential to understand that not all databases are equivalent in terms of the type and depth of information they contain. Each database is unique, housing specific sets of data. Therefore, gaining a robust understanding of the nature of the information these databases provide, and how to utilize it effectively, is essential for researchers. Table 1 summarizes the publicly available databases that contain various aspects of data utilized in drug discovery.

## Section: 3. AI in Structural Biology

Structural biology, encompassing the study of the three-dimensional (3D) structures of biological macromolecules, is essential for understanding the precise mechanisms underlying living organisms. Experimental techniques such as X-ray crystallography, nuclear magnetic resonance (NMR) spectroscopy, and cryo-electron microscopy (cryo-EM) have been employed to elucidate numerous structures. However, these experimental methods often require extensive labor, time, and financial resources, posing limitations for specific molecules or complexes. AI has advanced structural biology by providing computational approaches to overcome these experimental limitations [118,119]. AI techniques, especially DL methods, and data-driven modeling, have been applied by extracting meaningful patterns and features from vast and complex biological sequence and structural data. AI offers innovative tools for researchers, enabling protein structure prediction, protein design, and more, and continues to evolve alongside advancements in hardware and algorithm.

## Section: 3. AI in Structural Biology › 3.1. Protein Folding and Its Prediction

Protein folding, a highly intricate process, plays a fundamental role in determining the functional properties of biological macromolecules. Despite the limited number of around 20 amino acids, the varying structures and functions depending on their arrangements are of significant research interest in life sciences. Therefore, structural studies on protein folding are essential for understanding biological mechanisms and developing therapeutic strategies for diseases. However, observing the actual structure of proteins requires substantial resources and time. Hence, researchers attempt to predict protein folding and 3D structures using genetic information.

Despite the high demand for protein structure prediction, it remains challenging, and achieving perfect prediction is still elusive. Even minor variations in protein sequences can lead to drastic changes in overall structure and, in some cases, result in loss of function. On the other hand, certain amino acids share similar chemical properties, which can lead to minimal structural differences in some mutations. Additionally, despite the astronomical range of conformational possibilities resulting from the rotations of amino acids in flexible polypeptide chains, most small proteins fold spontaneously on a millisecond or even microsecond timescale. In order to address these Levinthal’s paradoxes, scientists have conducted extensive research in this area [120,121]. Researchers have attempted to predict structures using computational thermodynamic hypotheses, but this method has not yielded perfect results. For instance, predicting conformations of a protein within a biological system is challenging because even slight inaccuracies in the computation of the significant free energy difference between folded and unfolded states can lead to incorrect predictions. Therefore, recent arguments suggest that instead of traditional thermodynamic hypotheses, the non-equilibrium and active nature of proteins within the biological context requires modeling using fluctuating free-energy landscapes [122].

To overcome these limitations, various advancements and refinements have been made in the field of homology modeling techniques. Homology modeling, also known as comparative modeling, predicts the structure of a target protein using experimentally determined structures of homologous proteins as templates. Homology modeling contributes to understanding protein structure and function, aiding hypothesis generation and experimental design. This approach leverages the principle that proteins with similar sequences adopt similar structures. Key steps include selecting a suitable template with high sequence similarity, aligning the target sequence with the template, generating a model, and model optimization followed by validation [123]. The model accuracy largely depends on sequence similarity, and adopting strategies such as utilizing multiple templates, along with implementing processes such as energy minimization and loop modeling, can significantly enhance this precision.

## Section: 3. AI in Structural Biology › 3.2. Biomolecular Structure Prediction by Computational Methods

As research methods and technologies have advanced, protein structure and sequencing data accumulation has been accelerating. The Protein Data Bank (PDB), established in 1971, serves as the primary archive housing the largest collection of protein 3D structures [124]. As of 2022, the number of experimentally determined 3D protein structures has exceeded 200,000, with the pace of data accumulation steadily increasing [125]. Additionally, the UniProt Knowledgebase (UniProtKB) [109] provides information on protein sequences including functional annotations and currently holds over 220 million sequences as of 2023. This database also encompasses protein structure visualization data, including predicted structures by AI (i.e., AlphaFold, which is described in the following section).

MODELLER [126], which started development in 1993, is a representative program that can generate homology models using these accumulated databases. When researchers provide the sequence of the desired protein and structures of similar sequences, the program automatically creates models that satisfy spatial restraints using comparative protein structure modeling [127]. The SWISS-MODEL server, another tool in the field, provides an automated web service for generating homology models, with the ProMod3 modeling engine at its core [128]. This program utilizes QMEANDisCo [129] for model quality estimation and has demonstrated excellence through the CAMEO project, showcasing its effectiveness [130]. I-Tasser [131] has garnered significant attention due to an outstanding performance. I-Tasser combines various methods, including threading, ab initio modeling, and structure assembly, to generate models [132]. It utilizes a hierarchical approach, starting with the identification of template structures through threading, followed by fragment assembly simulations and refinement. The program has demonstrated competitive performance in several international structure prediction competitions, such as critical assessment of protein structure prediction (CASP) [133].

Collaborative efforts such as CASP are underway, providing a valuable platform for evaluating AI-based biomolecule structure prediction research [134,135]. Various research teams engage in structure prediction by categorizing protein sequences into cases amenable to template-based modeling (TBM) or those requiring free modeling (FM) and then evaluating their predictions. In 2018, DeepMind’s AlphaFold participated in CASP13 and introduced a novel approach by enhancing the traditional fragment assembly technique using deep learning (DL) methods. AlphaFold utilizes a deep residual convolutional neural network (CNN) to effectively capture intricate patterns within the protein data (Figure 4). The neural network undergoes training to make predictions about protein structures, and through gradient descent, it minimizes the potential energy to stabilize and achieve accurate structure prediction [136]. AlphaFold2 emerged during CASP14, introducing a novel neural network block called Evoformer [119,135]. Evoformer enhances the accuracy of structure prediction by facilitating the exchange of information within the multiple sequence alignment (MSA) and learning the relationships between sequences. It captures intricate spatial relationships, thereby improving the prediction of protein structures. trRosetta is also an approach that incorporates CNN into the existing RosettaFold framework [137]. By utilizing CNN, it directly predicts inter-residue distances and torsion angles from protein sequences and MSAs. These predictions are then integrated with the fragment assembly approach of RosettaFold to generate protein structure models.

## Section: 3. AI in Structural Biology › 3.3. Advancements in Protein Structural Research through AI

With the successful application of AI in predicting the structures of individual proteins, there has been a growing interest in applying AI to a broader range of structural biology research. One such area is the prediction of protein complex structures, which is expected to make significant contributions to the study of host–pathogen interactions [118]. DeepMind has released AlphaFold-Multimer to predict protein complex structures [138,139]. However, the coevolution within a protein and between proteins exhibits distinct patterns, posing limitations to complex prediction using MSA-based methods. Moreover, there are challenges in accurately predicting heterodimeric complexes compared to homodimeric ones, and the accuracy tends to decrease as the number of chains increases. In response to these issues, efforts have been made to address them by introducing ESMFold [140], a language model-based approach, aimed at improving the prediction accuracy.

The epigenetic dimension of protein structure (EDPS) represents another important objective that needs to be addressed [141]. Currently, neural network (NN)-based modeling algorithms face significant limitations in epigenetic protein structure prediction. This is particularly evident in membrane proteins [142], where template-based modeling (TBM) demonstrates higher accuracy than NN-based modeling, owing to the incorporation of lipid bilayer template data. This observation suggests that specific lipid species in the membrane environment may influence protein structure formation [143,144]. Comparative studies on G-protein-coupled receptor (GPCR) structure prediction supports this notion [145], as TBM exhibits relatively higher accuracy in loop regions, possibly due to the influence of the surrounding environment. Consequently, further research is required to explore additional methods that can improve the accuracy of EDPS prediction, especially for membrane proteins, even in the absence of suitable templates.

The integration of AI in protein structural research has shown notable advancements and potential in this field. While some challenges persist, particularly in predicting complex interactions and navigating the epigenetic aspects of protein structure, AI’s adaptability and the ongoing refinement of its methodologies have shown promise in overcoming these hurdles. Tools such as AlphaFold or ESMFold represent the innovative solutions developed to address existing limitations. However, the journey towards the comprehensive and accurate prediction of protein structures, including complex and epigenetically influenced structures, is ongoing. As AI technologies continue to evolve, it is anticipated that they will play an increasingly critical role in unfolding the mysteries of protein structures, thereby revolutionizing our approach to structure-based drug discovery.

## Section: 4. AI in Medicinal Chemistry or Cheminformatics

AI has also revolutionized medicinal chemistry and cheminformatics by providing innovative tools and approaches for drug discovery, such as deep generative models for molecular design, as well as the prediction of drug–target interactions or drug toxicity [47]. AI-driven approaches enable the exploration of vast chemical space, leading to the discovery of novel compounds with therapeutic potential. They can also facilitate drug repurposing by analyzing large-scale data to identify connections between drugs and diseases, expanding the possibilities for addressing unmet medical needs. Regarding chemical structures, AI methods generally use molecular fingerprints as input data. They are trained to find patterns in these fingerprints that correlate with the properties of interest, such as biological activity or physicochemical properties. This process is crucial in various cheminformatics tasks such as virtual screening, QSAR modeling, and de novo drug design. Thus, the relationship between molecular fingerprints and AI methods in cheminformatics is one of symbiosis, with each enabling the other’s functionality.

Various types of molecular fingerprints.

## Section: 4. AI in Medicinal Chemistry or Cheminformatics › 4.1. Molecular Fingerprints

Molecular fingerprints are binary or count-based representations that encode the chemical structure into a format that computational models can readily process. They can be seen as a bit string (usually several hundreds or thousands of bits long), where each bit represents the presence or absence of a particular substructure or property within the molecule [146]. Capturing different aspects of the molecular structure, such as the presence of certain functional groups, topological features, or 3D properties, it can transform these complex structures into simplified, standardized vectors [147]. The primary use of the molecular fingerprint is for creating a simplified digital representation of complex molecules, which allows efficient comparisons and searches in large molecular databases. It can be also used as a particular form of molecular descriptor that is commonly applied to a wide range of tasks, from virtual screening to prediction model building [148].

Molecular fingerprints can be categorized into the following classes [149,150,151]: (1) substructure keys-based fingerprints that generate bit strings depending on the presence or absence of substructures in the compound, (2) topological fingerprints that focus on topological routes and represent all possible connectivity routes between atoms, (3) circular fingerprints that are also related to atom paths similar to topological fingerprints but represent the connectivity of atoms not in a linear way but in a radius way, illustrating the atom’s environment [152], and (4) pharmacophore fingerprints that encode atoms by the pharmacophoric functional groups and atom bonds by several distance ranges [153]. Some fingerprints cannot be in these classes. SMIfp [154], which is calculated from SMILES, is a good example of that exception. Figure 5 and Table 2 summarizes the representative fingerprints commonly used in drug discovery research.

Fingerprints can be used to calculate molecular similarity or distance and help identify molecules with similar structures or properties, clustering molecules into groups, or predict the properties or activities of new molecules based on their similarity to known ones. As a tool in machine learning, molecular fingerprints can be used as input features for models predicting the properties or activities of molecules. In this context, the model learns to associate certain patterns in the fingerprint with the property or activity being predicted. The major drawback of molecular fingerprints is that they generally ignore biological context and do not contain 3D information. Various approaches have been proposed to overcome these limitations. For example, atom pair 3D fingerprints are developed from 2D atom pair fingerprints to contain 3D information [155]. Protein–ligand interaction fingerprints (PLIF) encode information about protein–ligand interactions, such as hydrogen bonds, ionic interactions, and surface contacts according to the residues [156].

Various types of molecular fingerprints.

## Section: 4. AI in Medicinal Chemistry or Cheminformatics › 4.2. Deep Generative Model for Molecular Design

A deep generative model is a type of neural network trained on existing data with a high-dimensional probability distribution, which it then uses to create new samples from that distribution [10]. In drug discovery research, deep generative models can be utilized in the area of de novo molecular design, a computational methodology that generates novel molecules with desired properties [8,161,162]. While QSAR models can be used to predict the biological activities of unknown chemicals based on their structures, which are derived from other chemicals with various known biological activities, de novo design is employed to generate novel chemical structures with desired pharmacological properties, using structure–bioactivity data as a basis [161]. They are trained on large databases of known molecules to learn the underlying patterns and structures in the data. This learned knowledge is then leveraged to generate new, unseen molecules that are likely to be physicochemically promising or biologically active.

Popular DL algorithms, such as recurrent neural networks (RNNs), variational autoencoders (VAEs), and generative adversarial networks (GANs), have been applied to de novo molecular design. RNNs are commonly used for data sequence modeling and generation and sequence-to-sequence mapping. In de novo design, they can also be used for analyzing molecular sequence data, such as SMILES [162]. Once the RNNs are trained by target sequences, they can generate new sequences that follow the conditional probability distributions learned from the training set [162]. VAEs can represent high-dimensional complex data by learning a low-dimensional latent space in an unsupervised manner [163]. When the VAE model is applied to de novo design, the encoder converts the molecule to a latent vector representation, and the decoder generates a novel chemical space from the latent vector representation [164]. GANs contain a generator and a discriminator. The generator creates new data based on input data, and the discriminator identifies whether the data are real or generated. During the training, these two components compete against each other, and when the discriminator cannot distinguish between generated data and real input data, the training ends [164]. In this process, GANs can generate novel molecules by using patterns and structures in a pre-existing training dataset.

Deep generative models, despite facing certain challenges, have shown remarkable potential for de novo design in early discovery stages. These models can be utilized to generate novel and diverse chemical scaffolds with desirable predicted values. However, to fully realize their potential, further research is needed to address key issues, such as lack of interpretability. Nonetheless, the early successes of these models have opened up exciting avenues for innovation and creativity that were previously unattainable.

## Section: 4. AI in Medicinal Chemistry or Cheminformatics › 4.3. Prediction of Drug–Target Interaction (DTI)

Drugs control our body’s physiological activities to exert therapeutic effects, which are achieved through the interaction between the drug and its target protein, known as drug–target interaction (DTI) [165]. A drug, which serves as a ligand, binds to the pocket in a protein, often referred to as a binding site, inducing changes in physiological activity. These pockets can vary in size and depth, and ligand binding can alter the protein structure, impacting its function through molecular interactions such as ionic bonds, van der Waals interactions, and hydrogen bonds [166,167,168]. They can prevent the protein from interacting with endogenous molecules or cause changes in its activity [165]. This activity can be affected not only by the ligand itself but also by water molecules, metal ion coordination, and various other circumstances [166].

Traditionally, the drug discovery approach has been based on the “one molecule–one target–one disease” paradigm, where the drug produces therapeutic effects by regulating its target. In this approach, it is necessary to test whether a particular protein could be a specific drug target for treatment [169]. However, a single target is not exclusively associated with one disease, and the onset of complex diseases may involve multiple factors. Depending on the circumstances, it may be necessary to intervene in multiple areas along the pathologic mechanism for effective treatment [170]. From this perspective, the importance of DTI research is increasingly recognized, especially regarding side effects, drug repositioning, and drug resistance [171].

The power of AI is apparent in this target identification and virtual screening [172]. ML algorithms, especially during the virtual screening process, follow an approach that differs from conventional structure-based virtual screening (SBVS) or ligand-based virtual screening (LBVS) [35]. They generate statistical models to anticipate the conditions of undiscovered ligands–proteins based on the recognized configurations of protein–ligand compounds and physicochemical characteristics [166]. The research carried out on the three aspects of ML-based DTIs, namely, prediction of existing ligand binding sites, binding affinity, and binding poses, is ultimately aimed at bringing us closer to more efficient drug discovery [170]. Table 3 summarizes a recent application of AI in DTI prediction.

## Section: 4. AI in Medicinal Chemistry or Cheminformatics › 4.4. Toxicity Prediction

The significant increase in chemical usage has intensified the need for reliable toxicity prediction, leading to the establishment of the Tox21 program in 2008, a collaborative endeavor undertaken by the U.S. governments, such as the Environmental Protection Agency (EPA). Further strengthening this initiative, the U.S. Food and Drug Administration (FDA) became a part of the consortium in 2010. This program employs high-throughput screening (HTS), an in vitro assay, to scrutinize the biochemical activity of various substances. This methodology has the advantage of not only reducing the time and cost associated with toxicity testing but also mitigating ethical concerns [187,188]. The culmination of these efforts resulted in the creation of the Tox21 10K library, which subsequently fostered the inception of the Tox21 data challenge, an initiative designed to enhance the precision of predictions about holistic human responses utilizing computational methodologies [189]. In parallel, EPA’s Toxicity Forecaster (ToxCast) program, instituted in 2007, assesses materials that could be harmful to human health and the environment via bioactivity profiling [190]. Distinguished from Tox21, ToxCast covers a broader chemical space and grapples with less specific mechanisms of action. Implementing methods analogous to HTS, it endeavors to categorize chemicals and advocate for the appropriate regulation of environmental pollutants [191]. These initiatives persist as critical contributions to the progression of toxicity prediction models.

These valuable Tox21 and ToxCast datasets have been monumental in driving advancements in the field of ADME/Tox prediction. Compounds that enter the human body commonly undergo absorption, distribution, metabolism, and excretion (ADME), with some leading to toxicity [192]. Efforts to decode these processes from a pharmacokinetic/pharmacodynamics (PK/PD) perspective have been put forth but given their interactions with numerous human body structures such as membranes, proteins, and the intra/extracellular environment, the ADME–Tox (ADMET) processes are viewed as multifactorial and intricate. Factors such as the compound’s solubility, membrane permeability, consumed concentration, and partition coefficient play a significant role in the absorption process [193,194]. AI algorithms can be trained on the Tox21/ToxCast datasets to predict the potentially toxic effects of a new compound, which are critical aspects of the drug discovery process [195]. Here, we describe recent applications in three representative endpoints, i.e., hepatotoxicity, cardiotoxicity, and carcinogenicity.

Given the crucial role the liver plays in drug metabolism, assessing the potential for drug-induced liver injury (DILI) is vital for safety reasons [196,197]. Hepatotoxicity, in particular, is a significant issue in drug development, leading to a significant number of drugs being withdrawn due to DILI or not being launched at all [198,199]. Safety concerns mean that only about 31.8% of potential drug candidates progress from preclinical testing to clinical trials [200]. Even among the drugs that are successfully launched, 58% of FDA drugs approved in 2020 and 2021 show signs of hepatotoxicity [201]. Traditional methods of DILI evaluation, such as in vitro and in vivo studies, are both costly and time-consuming [202]. In response to this, there has been a shift towards developing computational methods that can predict DILI quickly and accurately using AI methods.

Cardiotoxicity is a paramount concern in the creation of innovative pharmaceuticals [203]. In line with the International Conference of Harmonization’s guideline (S7B), it is obligatory for all emergent drugs to undergo a pre-clinical examination of their potential to inhibit hERG activities before they are considered for regulatory appraisals [31,204]. The hERG channel, alternatively known as Ether-à-go-go (EAG) proteins, constitutes potassium channels that are manifested in diverse brain areas, endocrine cells, muscles, and the heart [205,206]. These channels play an indispensable role in cardiac function by facilitating the heart’s electrical activity [205]. The blockade of these channels by small molecules can precipitate QT interval prolongation, which may culminate in lethal cardiotoxicity [207,208]. Consequently, it is essential that drug candidates demonstrate minimal hERG inhibition to circumvent such deleterious effects [209].

Mutagenicity and carcinogenicity are key considerations in the risk assessment of chemicals and pharmaceuticals [210,211]. Mutagenicity refers to a substance’s ability to cause genetic mutations, potentially leading to various disorders, including cancer, while carcinogenicity is a compound’s potential to cause cancer [212,213,214]. Given the correlation between these two and the global burden of cancer, it is vital to evaluate mutagenicity and carcinogenicity [215,216,217]. Challenges in this task include mutagenicity, inconsistencies in Ames test results, false positives and negatives, and reproducibility issues among labs [218,219]. The 1995 ICH guidelines provided a structure for carcinogenicity studies, yet these studies require two years, approximately $1.1 million, and about 500 rodents, making it a laborious and costly process [220]. As such, in silico predictive methods are gaining popularity, with several proposals suggesting the use of ML approaches to increase efficiency [221]. Table 4 summarizes the additional case studies for predicting various toxicity.

## Section: 5. Conclusions and Future Perspectives

In conclusion, the integration of AI in drug discovery represents a significant paradigm shift in medicinal chemistry, rather than just a technological addition. AI unlocks insights from complex datasets that were previously unreachable, and its value in data-driven drug discovery is poised to become increasingly prominent. However, alongside the high expectations for AI’s potential, it is vital to exercise caution. AI models heavily rely on large amounts of high-quality data, making access to diverse and sufficient data crucial for accurate learning and prediction. In the context of drug discovery, these data encompass information about known compounds, biological processes, disease mechanisms, clinical data, patient adverse events, and more. Due to the intricate nature of biological processes, the multitude of variables impacting drug action, and individual variations, many aspects cannot be interpreted or applied in isolation. This complexity presents challenges for achieving full automation, often requiring domain knowledge-based optimization and expert-guided manual curation. Efforts to address these limitations of AI applications have gained momentum across multiple domains. A significant emphasis is now on gathering or digitalizing diverse datasets, ensuring that AI tools represent a comprehensive spectrum of the data. To overcome data deficiency, researchers are using pre-trained models and fine-tuning them on specific, smaller datasets. This approach makes AI applications more adaptable and data efficient. There is also a concerted effort to bolster the robustness of AI, certifying that it performs reliably on previously unseen data.

Drug discovery and development, especially within the life-critical industry, necessitate human involvement for real-world experimental validation and clinical trials, extending beyond virtual simulations alone. Incorporating AI into these fields amplifies some of the ethical considerations, especially around data privacy, transparency, or potential bias. Furthermore, using AI on electronic medical records could risk patient privacy breaches. Nevertheless, AI technology can greatly enhance the efficiency of experiments for researchers, particularly in computationally intensive tasks or in identifying intricate patterns that might evade human observation. The optimal scenario is one where humans and AI technology collaborate, each leveraging their respective strengths. Addressing technical challenges, ensuring data robustness, validating AI models, and considering ethical implications requires a continuous collaborative approach involving academia, industry, and regulatory agencies.


---

# Risk factors and drug discovery for cognitive impairment in type 2 diabetes mellitus using artificial intelligence interpretation and graph neural networks

- **Authors:** Xin Zhang, Jiajia Xie, Xiong You, Houwu Gong
- **Issuer:** Frontiers in endocrinology
- **Type:** Scientific article
- **Published:** 2023-08-25
- **Language:** en
- **DOI:** 10.3389/fendo.2023.1213711
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37693358/
- **Licence:** CC-BY

## Page 1 (Section: Risk factors and drug discovery for cognitive impairment in type 2 diabetes mellitus using artificial intelligence interpretation and graph neural networks)

Risk factors and drug discovery
for cognitive impairment in type
2 diabetes mellitus using artiﬁcial
intelligence interpretation and
graph neural networks
Xin Zhang 1†, Jiajia Xie 2†, Xiong You 3 and Houwu Gong 4,5*
1Department of Pediatric, The First Afﬁliated Hospital of Hunan College of Traditional Chinese
Medicine, Zhuzhou, China, 2Department of Ultrasound Imaging, The First Hospital of Hunan
University of Chinese Medicine, Changsha, China, 3Center of Rehabilitation diagnosis and Treatment,
Hunan Provincial Rehabilitation Hospital, Changsha, China, 4College of Computer Science and
Electronic Engineering, Hunan University, Changsha, China, 5Military Medical Research Institute,
Academy of Military Sciences, Beijing, China
Background: Among the 382 million diabetic patients worldwide, approximately
30% experience neuropathy, and one-ﬁfth of these patients eventually develop
diabetes cognitive impairment (CI). However, the mechanism underlying
diabetes CI remains unknown, and early diagnostic methods or effective
treatments are currently not available.
Objective: This study aimed to explore the risk factors for CI in patients with type
2 diabetes mellitus (T2DM), screen potential therapeutic drugs for T2DM-CI, and
provide evidence for preventing and treating T2DM-CI.
Methods: This study focused on the T2DM population admitted to the First
Afﬁliated Hospital of Hunan College of Traditional Chinese Medicine and the First
Afﬁliated Hospital of Hunan University of Chinese Medicine. Sociodemographic
data and clinical objective indicators of T2DM patients admitted from January
2018 to December 2022 were collected. Based on the Montreal Cognitive
Assessment (MoCA) Scale scores, 719 patients were categorized into two
groups, the T2DM-CI group with CI and the T2DM-N group with normal
cognition. The survey content included demographic characteristics,
laboratory serological indicators, complications, and medication information.
Six machine learning algorithms were used to analyze the risk factors of T2DM-
CI, and the Shapley method was used to enhance model interpretability.
Furthermore, we developed a graph neural network (GNN) model to identify
potential drugs associated with T2DM-CI.
Results: Our results showed that the T2DM-CI risk prediction model based on
Catboost exhibited superior performance with an area under the receiver
operating characteristic curve (AUC) of 0.95 (speciﬁcity of 93.17% and
sensitivity of 78.58%). Diabetes duration, age, education level, aspartate
aminotransferase (AST), drinking, and intestinal ﬂora were identiﬁed as risk
factors for T2DM-CI. The top 10 potential drugs related to T2DM-CI, including
Metformin, Liraglutide, and Lixisenatide, were selected by the GNN model. Some
Frontiers in Endocrinology
frontiersin.org
01
OPEN ACCESS
EDITED BY
Youxin Wang,
Capital Medical University, China
REVIEWED BY
Juexian Song,
Capital Medical University, China
Yunfeng Xi,
Inner Mongolia Center for Disease Control
and Prevention, China
*CORRESPONDENCE
Houwu Gong
hwgong@hnu.edu.cn
†These authors share ﬁrst authorship
RECEIVED 28 April 2023
ACCEPTED 04 August 2023
PUBLISHED 25 August 2023
CITATION
Zhang X, Xie J, You X and Gong H (2023)
Risk factors and drug discovery for
cognitive impairment in type 2 diabetes
mellitus using artiﬁcial intelligence
interpretation and graph neural networks.
Front. Endocrinol. 14:1213711.
doi: 10.3389/fendo.2023.1213711
COPYRIGHT
© 2023 Zhang, Xie, You and Gong. This is an
open-access article distributed under the
terms of the Creative Commons Attribution
License (CC BY). The use, distribution or
reproduction in other forums is permitted,
provided the original author(s) and the
copyright owner(s) are credited and that
the original publication in this journal is
cited, in accordance with accepted
academic practice. No use, distribution or
reproduction is permitted which does not
comply with these terms.
TYPE Methods
PUBLISHED 25 August 2023
DOI 10.3389/fendo.2023.1213711

## Page 2 (Section: Introduction)

herbs, such as licorice and cuscutae semen, were also included. Finally, we
discovered the mechanism of herbal medicine interventions in gut microbiota.
Conclusion: The method based on Interpreting AI and GNN can identify the risk
factors and potential drugs associated with T2DM-CI.
KEYWORDS
type 2 diabetes mellitus, cognitive impairment, risk factors, drug discovery, graph neural
network (GNN)
Introduction
Cognition is the natural process whereby the brain recognizes
and acquires information (1). Cognitive impairment (CI) refers to
decreased cognitive processing speed and efﬁciency, affecting
functions such as working memory, task execution, and attention
(2). Memory impairment is the most common cognitive change and
may progress to dementia in severe cases (3). In recent years, CI has
become increasingly recognized as one of the most important
cerebrovascular complications of type 2 diabetes (T2DM) (4).
There is an increasing consensus suggesting that T2DM is one of
the most important causes of CI (5), with reports suggesting that
diabetes can lead to a 20%–70% decline in cognitive ability, and the
risk of dementia is 60% higher in diabetic patients than in non-
diabetic patients (6). Diabetes is the most prevalent metabolic
disease worldwide, with 500 million T2DM patients globally, one-
third of whom are in China (7). With the changing social structure
and the global aging trend, the number of CI cases caused by T2DM
is expected to increase exponentially. Studies have shown that the
incidence of mild CI in T2DM patients is signiﬁcantly higher than
in non-diabetic patients (8, 9). Mild CI may affect daily activities,
such as impaired intelligence, slow thinking speed, reduced
ﬂexibility, and lack of concentration (10). CI caused by diabetes
can be classiﬁed into diabetes-related cognitive decline, mild CI
(MCI), and dementia according to severity (11). Therefore, CI can
be considered as an intermediate transition between diabetes and
dementia, and this process is reversible. Therefore, it is urgent to
identify the risk factors for T2DM-CI and prevent its occurrence
and development. Research on the risk factors for T2DM-CI has
gained signiﬁcant momentum in recent years. However, no
consensus has been reached, and the literature has been
predominantly based on foreign populations. The risk factors for
T2DM-CI in China have been largely underinvestigated, and the
clinical and demographic data included are not comprehensive and
cannot reﬂect the real risk factors for T2DM patients with CI. This
study aims to comprehensively analyze the risk factors for T2DM-
CI, focusing on demographic characteristics and relevant clinical
and physical indicators, to identify T2DM patients with possible CI
early, discover potential drugs, improve patient quality of life, and
reduce the burden on society.
Materials and methods
Study design and patients selection
The study included a population of patients with type 2 diabetes
mellitus (T2DM) who were admitted to the Endocrinology
Department of the First Afﬁliated Hospital of Hunan College of
Traditional Chinese Medicine and the First Afﬁliated Hospital of
Hunan University of Chinese Medicine between January 2018 and
December 2022, and who met the speciﬁed inclusion criteria. The
selection of research subjects involved a rigorous screening process
conducted by at least two medical professionals, who assessed the
patients using cognitive scales. Based on the assessment criteria, the
patients were divided into two groups: the T2DM group with
normal cognition (T2DM-N group) and the T2DM group with
cognitive impairment (T2DM-CI group).
Diagnostic criteria
The diagnosis criteria for T2DM were based on the “Chinese
Guidelines for the Prevention and Treatment of Type 2 Diabetes
(2013 edition)” (12). According to these criteria, T2DM can be
diagnosed if patients presenting with diabetes-related symptoms
(such as polyphagia, polydipsia, polyuria, and unexplained weight
loss) meet any of the following three conditions: (1) random blood
glucose (blood glucose at any time within a day) ≥11.1mmol/L; (2)
fasting blood glucose (without calorie intake in 8 h) ≥7.0mmol/L;
(3) blood glucose value ≥11.1mmol/L measured 2 h after 75 g oral
glucose tolerance test. For individuals without diabetes symptoms,
the blood glucose is re-tested on another day to conﬁrm
the diagnosis.
The diagnostic criteria for cognitive impairment are based on
the 5th edition of the “Diagnostic and Statistical Manual of Mental
Disorders” (DSM-5) and the ofﬁcial manual of the Montreal
Cognitive Assessment (MoCA) scale (13). The following three
conditions must be met to diagnose cognitive impairment: (1)
The Chinese version of the MoCA score is<26 points; (2) the
patient, their family, or those who know the patient well provide
relevant descriptions of memory decline; (3) the patient has basic
Zhang et al.
10.3389/fendo.2023.1213711
Frontiers in Endocrinology
frontiersin.org
02

## Page 3 (Section: Inclusion and exclusion criteria)

daily living abilities, with a score ≥16 on the instrumental activities
of daily living scale (IADL).
Inclusion and exclusion criteria
The inclusion criteria for the study population were as follows:
1. T2DM-N group: patients diagnosed with type 2 diabetes
mellitus according to the diagnostic criteria outlined in the
“China Type 2 Diabetes Prevention and Control Guidelines
(2013 Edition).”
2. T2DM-CI group: patients diagnosed with both T2DM and
cognitive impairment.
3. Age between 30 and 85 years.
4. T2DM disease duration of more than 1 year.
5. Patients with complete data on relevant indicators.
The exclusion criteria were as follows:
1. Patients who have experienced acute metabolic
complications of diabetes, such as diabetic ketoacidosis or
hyperosmolar hyperglycemic state, within the past month.
2. Patients who recently experienced diseases that may affect
glucose and lipid metabolism, such as infection, trauma,
stress, or surgery.
3. Patients with severe cardiovascular disease, hematological
system disease, malignant tumor, or other serious primary
diseases, severe liver or kidney dysfunction, or mental
illness.
4. Patients who have experienced serious acute brain diseases
within the past 3 months, such as acute cerebral infarction,
intracranial hemorrhage, or acute meningitis.
5. Pregnant or lactating women, or those planning to become
pregnant.
6. Patients who have participated in other clinical trials within
the past 3 months.
Analysis variables
This study extracted patients’ personal information and
laboratory examination data from the hospital information
system. The analyzed variables included gender, age, body mass
index (BMI), heart rate, blood pressure, duration of type 2 diabetes
mellitus (T2DM), family history, smoking and drinking history,
exercise habits, and more. Laboratory indicators encompassed total
cholesterol (TC), triglycerides (TGs), high-density lipoprotein
cholesterol (HDL-C), low-density lipoprotein cholesterol (LDL-
C), very-low-density lipoprotein cholesterol (VLDL-C),
homocysteine (HCY), fasting blood glucose (FBG), 2-h
postprandial blood glucose (2hPBG), glycosylated hemoglobin
(HbA1c), fasting plasma insulin (FINS), fasting C-peptide,
creatinine (Crea), aspartate aminotransferase (AST), alanine
aminotransferase (ALT), and gut microbiota. In addition, this
study utilized data from various databases, including Traditional
Chinese Medicine Systems Pharmacology (TCMSP) (14), Online
Mendelian Inheritance in Man (OMIM) (15), Therapeutic Target
Database (TTD) (16), Pharmacogenomics Knowledgebase (Pharm
Gkb) (17), and Drug Bank (18), to conduct drug discovery research
for T2DM-CI.
Machine learning methods
The raw data were processed by organizing and standardizing
them. Any feature with missing values exceeding 50% was removed
from the dataset. For the remaining features with missing values,
continuous features were imputed using the mean and categorical
features using the mode. Six machine learning models were selected
as candidates for analysis, which included random forest (RF),
gradient boosted decision tree model (GBDT), light gradient
boosting machine (LGBM), extreme gradient boosting (XGBoost),
and categorical features gradient boosting (CatBoost) (19).
•
Random Forest is an algorithm that utilizes multiple
decision trees to train and predict samples. The output
category is determined by the mode of the individual
decision tree output categories. Random Forest is
insensitive to missing values, capable of handling
imbalanced data, and exhibits robustness to outliers.
•
Gradient Boosting Decision Tree (GBDT) is a boosting
ensemble algorithm based on decision trees incorporating
gradient descent. The algorithm consists of multiple
decision trees, and the conclusions of all trees are
accumulated to provide the ﬁnal answer. GBDT can
handle various types of data, including continuous and
discrete values, in a ﬂexible manner. It exhibits high
prediction accuracy with relatively less parameter tuning
time. Moreover, it demonstrates strong robustness to
outliers by utilizing robust loss functions.
•
LightGBM is a decision tree algorithm based on histograms,
which transforms the storage of feature values into the
storage of bin values and does not require the indexing of
feature values to samples. LightGBM employs an exclusive
feature bundling algorithm to reduce the number offeatures
during the training process, resulting in exceptionally fast
training speeds. Therefore, it is highly suitable for
classiﬁcation problems involving high-dimensional
datasets.
•
XGBoost is a boosting algorithm based on CART trees.
XGBoost uses the second-order Taylor expansion of the loss
function as a surrogate function, which is then minimized
to determine the optimal split point and leaf node output
value of the regression tree. XGBoost offers reduced
learning time and exhibits high ﬂexibility in its approach.
•
CatBoost is an algorithm that utilizes symmetric decision
trees (oblivious trees) as its base learner. It incorporates a
Zhang et al.
10.3389/fendo.2023.1213711
Frontiers in Endocrinology
frontiersin.org
03

## Page 4 (Section: Evaluation indicators)

specialized method to handle categorical features and
employs ordered boosting with combined categorical
features to prevent gradient estimation bias. CatBoost
demonstrates exceptional performance, reduces the need
for hyperparameter tuning, and exhibits strong robustness.
The characteristics of logistic regression are simple calculation
and strong interpretability, which are widely used in ﬁelds such as
ﬁnance, healthcare, social networks, and marketing. Random Forest
is characterized by no need for feature normalization and feature
selection. Random Forest is mainly used for training sets with high
square error and low deviation. The characteristics of Adaboost are
low generalization error rate, easy coding, and sensitivity to outliers.
Adaboost is suitable for baseline classiﬁcation tasks. CatBoost is
particularly adept at handling category features. CatBoost is suitable
for processing categorical data. The characteristic of GBDT is high
prediction accuracy, suitability for low dimensional data, and ability
to handle nonlinear data. GBDT is applicable to regression
problems (linear and nonlinear), and it is also applicable to
binary classiﬁcation problems and multiclassiﬁcation problems.
The characteristic of XGBoost is its support for parallel
computing, fast training speed, suitability for high bias, low
variance training sets, and suitability for numerical vectors.
The entire dataset was randomly split into an 80% training set
and a 20% testing set for model training and evaluation.
Performance metrics from the validation set were utilized to
compare the models and estimate their generalization ability. The
Shapley method was employed to enhance the interpretability of the
model, providing insights into the factors inﬂuencing T2DM-CI at a
local level. Furthermore, a graph neural network model was utilized
for drug discovery research on T2DM-CI, identifying potential
therapeutic drugs with beneﬁcial effects on T2DM-CI.
Evaluation indicators
This study employed k-fold cross-validation for model validation
to evaluate the robustness of the models. The training set was divided
into K subsets, with one subset reserved as the validation data, while
the remaining K-1 subsets were used for model training. The cross-
validation process was repeated K times, with each subset being used
as the validation set once, and the results were averaged or combined
using other methods to obtain a single estimate. The key advantage of
this method is that it repeatedly utilizes randomly generated subsets
for training and validation, ensuring a comprehensive evaluation of
the models. In this study, the value of k was set to 5.
The experiment adopts the area under the ROC curve (AUC) as
the main evaluation indicator and speciﬁcity (Spe) and sensitivity
(Sen) as secondary indicators. The higher the speciﬁcity, the higher
the probability of accurate diagnosis; the higher the sensitivity, the
lower the probability of missed diagnosis. The calculation formula is
as follows:
Spe =
TN
FP + TN
1
Sen =
TP
TP + FN
2
where TP represents the number of true positive samples, TN
represents the number of true negative samples, FP represents the
number of false-positive samples, and FN represents the number of
false-negative samples.
Statistical analysis
The statistical analysis in this study was conducted using SPSS
22.0 software. Continuous data were reported as mean ± standard
deviation (x ± s). Prior to analysis, normal distribution and
homogeneity of variance tests were performed. If the data
satisﬁed the assumptions of normal distribution and homogeneity
of variance, t-tests or ANOVA were employed for analysis. On the
other hand, if the data did not meet these assumptions, non-
parametric Wilcoxon rank sum tests were utilized. The
comparison of count data was assessed using a chi-square test. A
p-value< 0.05 was statistically signiﬁcant.
GCNN4Micro-Dis model for discovery of
potential drugs
We obtained 269 drugs, 598 diseases, and 18,416 disease–drug
associations from the Comparative Toxicology Database (CTD).
Then, we obtained more information from LTM-TCM, including
1,928 disease symptoms, 9,122 herb medicines, and 1,170,133
associations. In this study, the performance parameters of the
ROC and AUPR curves are used as the criteria for selecting drugs
based on the graph neural network model. The GCNN4Micro-Dis
model evidently performed well and can help identify potential
disease–drug associations. The correlation scores were calculated
through the model to ensure the relevance between the selected
drugs and T2DM-CI.
The model GCNN4Micro-Dis (20), previously developed by a
research team, was used to predict potential drugs. The structure of
GCNN4Micro-Dis is shown in Figure 1. The model consists of three
main steps: (1) performing a graphic Fourier transform on the input
data, (2) convolving the transformed result in the spectral domain,
and (3) processing the convolution result using inverse
Fourier transform.
Results
Demographic and clinical characteristics of
study participants
This study involved 719 patients, with 255 (33.62%) diagnosed
with type 2 diabetes cognitive impairment and 464 (66.38%)
without cognitive impairment. A comparison of the data between
patients with and without the endpoint event indicated no
Zhang et al.
10.3389/fendo.2023.1213711
Frontiers in Endocrinology
frontiersin.org
04

## Page 5 (Section: Comparison of performance of T2DM-CI risk prediction models)

signiﬁcant differences in gender, BMI, smoking, total cholesterol
(TC), triglycerides (TGs), and other variables (p>0.05). However,
signiﬁcant differences were observed in age, education level,
duration of diabetes, hypertension, intestinal ﬂora, and LDL-C
value (p<0.05). More details are provided in Table 1.
Comparison of performance of T2DM-CI
risk prediction models
In this study, the performance of six machine learning
algorithms, namely, Logistic Regression, Random Forest, GBDT,
Adaboost, XGBoost, and CatBoost, was compared in predicting the
risk of T2DM-CI. The results (Table 2, Figure 2) showed that
CatBoost exhibited higher AUC and Spe values than the other
models in the validation set. The AUC value in the validation set
was 95.34%, surpassing the AUC values of the other ﬁve models.
Additionally, the speciﬁcity was 93.17%, outperforming the other
four models. The Random Forest model achieved the highest
sensitivity (78.58%). Overall, the experimental data from this
study demonstrated that the CatBoost model was superior to
other models in predicting the risk of T2DM-CI.
Discovery of risk factors for T2DM-CI
To explore the risk factors inﬂuencing T2DM-CI, this study
introduced an interpretive T2DM-CI prediction model based on
FIGURE 1
The ﬂowchart of GCNN4Micro-Dis.
TABLE 1 Comparison of information among T2DM patients.
T2DM-CI (n=255)
T2DM-N (n=464)
c2/t/Z
p-value
Gender
1.34
0.26
Male
135(52.94%)
244(52.59%)
Female
120(47.06%)
220(47.41%)
Age (year)
64.32±8.32
60.12±10.85
−3.37
<0.01
Education level
18.51
<0.01
Below middle
110(43.14%)
166(35.78%)
Middle and above
145(56.86%)
298(64.22%)
BMI(kg/m2)
24.01±2.25
25.93±3.12
2.53
0.08
Diabetes duration (year)
13.85±8.11
11.36±6.49
−0.37
<0.01
Smoke
0.02
0.96
No
131(51.37%)
221(47.63%)
Yes
124(48.63%)
243(52.37%)
Drink
1.12
0.04
No
117(45.88%)
207(44.61%)
Yes
138(54.12%)
257(55.39%)
Hypertension
7.29
<0.01
(Continued)
Zhang et al.
10.3389/fendo.2023.1213711
Frontiers in Endocrinology
frontiersin.org
05

## Page 6 (Section: Discovery of potential drugs related to T2DM-CI)

CatBoost and TreeSHAP (21). From a global perspective, the
importance of features contributing to T2DM-CI was ranked and
presented in Figure 3. The analysis revealed that T2DM-CI might be
associated with factors such as diabetes duration, age, education
level, AST, drinking habits, and intestinal ﬂora.
Discovery of potential drugs related
to T2DM-CI
In the previous section, intestinal ﬂora was identiﬁed as a risk
factor for T2DM-CI. In this section, we analyzed the relationship
TABLE 1 Continued
T2DM-CI (n=255)
T2DM-N (n=464)
c2/t/Z
p-value
Normal
129(50.59%)
231(49.78%)
Abnormal
126(49.41%)
233(50.22%)
Cerebral infarction
8.28
<0.01
Normal
117(45.88%)
196(42.24%)
Abnormal
138(54.12%)
268(57.76%)
Intestinal ﬂora
7.67
<0.01
Normal
129(50.59%)
188(40.52%)
Abnormal
126(49.41%)
276(59.48%)
TC (mmol/L)
8.91±3.01
8.85±3.65
−0.53
0.61
TG (mmol/L)
11.79±3.04
11.37±3.86
−0.96
0.38
LDL-C (mmol/L)
11.15±9.93
16.21±10.98
−1.88
0.04
HCY (µmol/L)
13.72±10.41
14.73±11.28
−0.83
0.45
FBG (mmol/L)
9.11±3.44
9.01±3.81
−0.57
0.59
2hPBG (mmol/L)
11.85±3.53
11.48±3.77
−0.89
0.34
HbA1c (%)
9.44±2.04
9.13±1.99
−1.89
0.05
FINS (µIU/ml)
12.55±10.21
16.94±11.17
−1.76
0.03
HoMA-IR
4.64±4.11
7.94±4.73
−0.37
0.74
Crea (µmol/L)
73.83±27.36
72.11±21.66
−0.55
0.63
AST (U/L)
15.75±8.23
18.93±13.84
−1.84
0.04
ALT (U/L)
15.42±7.79
17.91±7.26
−0.72
0.47
TABLE 2 Comparison of results among different machine learning algorithms.
DataSet
Algorithms
AUC (%)
Speciﬁcity(%)
Sensitivity(%)
Training set
Logistic regression
96.94
93.76
80.35
Random Forest
99.99
99.99
99.99
GBDT
99.46
98.83
90.32
Adaboost
98.35
96.18
88.86
XGBoost
99.99
99.99
99.99
CatBoost
99.81
98.12
94.51
Test set
Logistic regression
95.14
90.92
77.27
Random Forest
93.24
91.27
78.58
GBDT
93.17
90.23
72.73
Adaboost
93.15
91.15
72.73
XGBoost
94.28
91.19
77.27
CatBoost
95.34
93.17
77.27
The bold values means the highest value.
Zhang et al.
10.3389/fendo.2023.1213711
Frontiers in Endocrinology
frontiersin.org
06

## Page 7 (Section: Discussion)

between “T2DM-CI_intestinal ﬂora_drug.” Subsequently, we
utilized the GCNN4Micro-Dis model (20) to identify potential
drugs associated with T2DM-CI. Table 3 presents the top 10
drugs ranked by their association scores with T2DM-CI. Some
herbs were included, such as licorice and cuscutae semen. It is worth
mentioning that the results obtained have been validated in the
published literature (22).
Discussion
In this study, our approach based on artiﬁcial intelligence
interpretation and graph neural networks enabled the
identiﬁcation of risk factors and potential drugs that impact the
progression of T2DM to cognitive impairment. These ﬁndings offer
valuable insights for the comprehensive treatment of T2DM and the
prevention of dementia. The analysis highlighted the signiﬁcance of
diabetes duration, age, education level, AST, alcohol consumption,
and intestinal ﬂora as important risk factors for T2DM-CI.
Importantly, the present study focused on the T2DM population
and assessed relevant risk factors, enabling more accurate and
convenient screening and early prevention in clinical practice.
Furthermore, this study encompassed a comprehensive range of
potential risk indicators. While previous research primarily
concentrated on common clinical indicators, this study
incorporated emerging potential risk indicators such as HoMA-
IR, FINS, and intestinal ﬂora. This expansion of the risk screening
scope provides a valuable reference value for future research and
enhances our understanding of the multifaceted nature of
T2DM-CI.
However, it should be borne in mind that this study has some
limitations. The available case data were limited, which restricted
the ability to conduct a stratiﬁed analysis of certain inﬂuencing
factors, and the ﬁndings may be biased to some extent. Therefore,
our results can only reﬂect the inﬂuencing factors of cognitive
impairment in the T2DM population to some extent and should be
interpreted with caution. Nonetheless, the ﬁndings still provide
valuable guidance for preventing and treating cognitive impairment
in T2DM patients. Clinical data comprise patient visit information,
yet accurately reﬂecting all patients’ symptoms through electronic
medical records can be challenging for doctors, resulting in
incomplete data. Indeed, some symptoms that go unnoticed by
doctors may go unrecorded, leading to missing records in hospital
documentation of patient visits. Furthermore, different hospitals
may have varying records for the same disease, and symptoms can
vary among patients. Consequently, there is a limited availability of
clinical samples for real-world data. The sample size in this study
was determined based on the existing data, without prior power
calculation for sample size. Consequently, the study is limited by a
small sample size of clinical samples, which impacts the research
quality. To enhance the robustness of the results, this study
necessitates a larger sample size and a more standardized research
paradigm. On the one hand, we plan to explore alternative methods
to increase the sample size or utilize additional data sources from
public databases to complete multicenter validation studies, such as
the Pima Indians Diabetes Database. On the other hand, we plan to
create a questionnaire and distribute it to third-party survey teams,
such as the PowerCX Wind Chime System, which can target a
sample of people to answer the questionnaire. Over the past decade,
third-party survey teams have become increasingly popular and
even trusted by professional research companies. With the advent of
big data and the continuous improvement of multisystem network
connections, favorable conditions should be established to facilitate
further research into the inﬂuencing factors. This will contribute to
FIGURE 2
ROC curves of different machine learning algorithms on the test set.
FIGURE 3
T2DM-CI features importance.
Zhang et al.
10.3389/fendo.2023.1213711
Frontiers in Endocrinology
frontiersin.org
07

## Page 8 (Section: Discussion)

the generation of more optimized clinical evidence, enabling a
deeper understanding of the complex interactions and variables
involved in various medical conditions.
The results of this study highlight several important ﬁndings
regarding the relationship between type 2 diabetes and mild
cognitive impairment. First, the duration of diabetes was
identiﬁed as a potential risk factor for cognitive impairment. A
longer duration of diabetes (more than 20 years) was associated
with a higher likelihood of cerebral vascular injury, brain atrophy,
and impaired cognitive function. This can be attributed to the
chronic metabolic dysfunction associated with diabetes, which leads
to ischemic and hypoxic changes in brain tissue and increased
inhibitory neurotransmitters (23). Additionally, age was a
signiﬁcant factor in the development of mild cognitive
impairment in patients with type 2 diabetes. Older patients,
particularly those between 60 and 75, were more susceptible to
cognitive impairment. This observation is consistent with previous
research, suggesting that age-related decline in dopamine
neurotransmission efﬁciency and frontal gyrus system function
contribute to the deterioration of cognitive function over time (24).
Furthermore, education level was identiﬁed as a strong
determinant of cognitive impairment in individuals with type 2
diabetes. Higher education levels were associated with better
cognitive function, attributed to engaging in intellectual labor,
maintaining good learning habits, and keeping brain cells
active. Conversely, lower education levels, often associated with
more physical labor and limited brain usage, led to a decline in
brain neuron reserve and decreased awareness of health
management (25).
Furthermore, this study revealed that intestinal ﬂora may be a
potential risk factor for mild cognitive impairment in patients with
type 2 diabetes. Intestinal ﬂora primarily inﬂuences the host
through its bacterial bodies and metabolic byproducts (26).
Intestinal dysbiosis in individuals with diabetes can directly affect
central function and promote other pathways that impact cognitive
function. These pathways are interconnected. Intestinal ﬂora can
inﬂuence metabolic and neurological diseases, offering a novel
perspective for treating T2DM-CI. The altered ﬂora in diabetic
patients plays a crucial role in their cognitive impairment,
highlighting the potential of regulating intestinal ﬂora as an
effective treatment target for T2DM-CI (Figure 4).
Most traditional Chinese medicine formulas can modulate the
composition of the symbiotic ﬂora. A multicenter, randomized,
open-label clinical trial demonstrated that a combination of
metformin and a traditional Chinese medicine formula
containing Salvia miltiorrhiza, Anemarrhena asphodeloides,
Schisandra chinensis, Coptis chinensis, red yeast rice, aloe vera,
bitter melon, and dried ginger could improve type 2 diabetes with
hyperlipidemia by promoting the growth of beneﬁcial ﬂora, such as
Blautia and Faecalibacterium (27). Furthermore, another Chinese
medicine formula Ge-Gen-Qin-Lian decoction, has been found to
enrich beneﬁcial ﬂora, including Faecalibacterium, in the gut,
associated with its anti-diabetic effects (28). Chinese medicine
exerts its regulatory effects through intricate chemical interactions
in the gut, thereby maintaining a healthy gut ecosystem, controlling
insulin resistance, and reducing host inﬂammation.
Considering further experimental validation of our results, the
planned experiments and validation methods are as follows. First
are the molecular and cellular experiments. In vitro experiments
TABLE 3 Top 10 potential drugs related to T2DM-CI.
Rank
Related drugs
Scores
Evidence
1
Metformin
0.00061
PMID: 31975558
2
Liraglutide
0.00060
PMID: 31790314
3
Lixisenatide
0.00059
PMID: 21391833
4
Liquorice
0.00058
PMID: 36232291
5
Dulaglutide
0.00057
PMID: 30394576
6
3-n-Butylphthalide
0.00056
Unconﬁrmed
7
Cuscutae Semen
0.00056
Unconﬁrmed
8
Lycii Fructus
0.00055
PMID: 16689001
9
DPP-4i
0.00054
PMID: 30394576
10
Rhizoma Dioscoreae
0.00054
PMID: 31717456
FIGURE 4
Mechanism of herbal medicine interventions in gut microbiota.
Zhang et al.
10.3389/fendo.2023.1213711
Frontiers in Endocrinology
frontiersin.org
08

## Page 9 (Section: Data availability statement)

involve applying this candidate drug to the cell model of the
relevant disease, observing whether it can affect the related
pathological changes of this disease model. The techniques we
may use include immunoﬂuorescence staining, Western blot,
qPCR, etc., to detect changes in key biomarkers. Second are
animal experiments. If in vitro experiments prove that the drug
has an effect on speciﬁc targets or pathways, then in vivo research is
conducted, usually in animal models. At this stage, we need to
observe whether the administration of the candidate drug in a
speciﬁc disease model can improve symptoms or pathological
changes. Third are clinical trials. If in both in vitro and in vivo
experiments, the drug demonstrates the potential to alter biological
processes and exhibits good safety, a clinical trial is then conducted
to verify the drug’s effects and safety in humans. This is a key step in
our ﬁnal conﬁrmation of the drug’s applicability and safety.
Data availability statement
The original contributions presented in the study are included
in the article/supplementary material. Further inquiries can be
directed to the corresponding author.
Author contributions
Study concept and design: HG. Acquisition of data: XZ, JX.
Analysis and interpretation of data: XY. Drafting of the manuscript:
XZ, JX. Critical revision of the manuscript for important intellectual
content: HG. Statistical analysis: XY. Obtained funding: HG.
Technical or material support: XZ, JX. Study supervision: HG. All
authors contributed to the article and approved the
submitted version.
Funding
This work was supported by the Natural Sciences Foundation of
Hunan Province (Grant No. 2021JJ30139), the National Natural
Science Foundation of China (Grant No. 61773157), the China
Postdoctoral Science Foundation (Grant No. 2022M711113), the
2021 Scientiﬁc Research Plan Project of Hunan Provincial Health
Commission (202109021496), and the Rehabilitation Project of
Hunan Disabled Persons’ Federation in 2022 (Grant No. 2022XK0305).
Conﬂict of interest
The authors declare that the research was conducted in the
absence of any commercial or ﬁnancial relationships that could be
construed as a potential conﬂict of interest.
Publisher's note
All claims expressed in this article are solely those of the authors
and do not necessarily represent those of their afﬁliated
organizations, or those of the publisher, the editors and the
reviewers. Any product that may be evaluated in this article, or
claim that may be made by its manufacturer, is not guaranteed or
endorsed by the publisher.
References
1. Desikan RS, Cabral HJ, Hess CP, Dillon WP, Glastonbury CM, Weiner MW, et al.
Automated MRI measures identify individuals with mild cognitive impairment and
Alzheimer's disease. Brain (2009) 132(Pt 8):2048–57. doi: 10.1093/brain/awp123
2. Petersen RC, Negash S, Selamawit . Mild cognitive impairment: an overview. CNS
spectrums (2008) 13(1):45–53. doi: 10.1017/S1092852900016151
3. Mezrar S, Bendella F. A systematic review of serious games relating to cognitive
impairment and dementia. J digital Inf Manage (2022) 2022(1):20. doi: 10.6025/jdim/
2022/20/1/01-09
4. Ebady AS, Arami MA, Shaﬁgh MH. Investigation on the relationship between
diabetes mellitus type 2 and cognitive impairment. Diabetes Res Clin Pract (2008) 82
(3):305–9. doi: 10.1016/j.diabres.2008.08.020
5. Zhang Y, Zhang X, Zhang J, Liu C, Yuan Q, Yin X, et al. Gray matter volume
abnorMalities in type 2 diabetes mellitus with and without mild cognitive impairment.
Neurosci Lett (2014) 562:1–6. doi: 10.1016/j.neulet.2014.01.006
6. Bahorun T, Narrain D, Indelicato J, Aruoma OI, Murad F. Cognitive impairment
in patients with type 2 diabetes mellitus: Perspectives and challenges. Arch Med Biomed
Res (2014).
7. Lee Y, Smofsky A, Nykoliation P, Allain SJ, Lewis-Daly L, Schwartz J, et al.
Cognitive impairment mediates workplace impairment in adults with type 2 diabetes
mellitus: results from the motivaction study. Can J Diabetes 42(3):289–95. doi: 10.1016/
j.jcjd.2017.06.013
8. Rizzo MR, Meo ID, Polito R, Auriemma MC, Gambardella A, Mauro GD, et al.
Cognitive impairment and type 2 diabetes mellitus: Focus of SGLT2 inhibitors
treatment. Pharmacol Res (2022) 176:106062. doi: 10.1016/j.phrs.2022.106062
9. Chen Y, Zhou Z, Liang Y, Tan X, Li Y, Qin C, et al. Classiﬁcation of type 2 diabetes
mellitus with or without cognitive impairment from healthy controls using high-order
functional connectivity. Hum Brain Mapp (2021) 42(14):4671–84. doi: 10.1002/hbm.25575
10. Qin D, Qian H, Shouliang QI, Teng Y, Jianlin WU. ANALYSIS OF RS-FMRI
IMAGES CLARIFIES BRAIN ALTERATIONS IN TYPE 2 DIABETES MELLITUS
PATIENTS WITH COGNITIVE IMPAIRMENT. J Mechanics Med Biol (2021)
21:2140015. doi: 10.1142/S0219519421400157
11. Balashova AV, Glinkina IV, Fadeev V. The Epidemiology of Cognitive impairment
in elderly patients with type 2 diabetes mellitus: prevalence and related clinical factors.
Russian J Geriatric Med (2021) 2021(2):259. doi: 10.37586/2686-8636-2-2021-249
12. Ji L, Lu J, Weng J, Jia W, Tian H, Zhu D, et al. China type 2 diabetes treatment
status survey of treatment pattern of oral drugs users. J Diabetes (2015) 7(2):166–73.
doi: 10.1111/1753-0407.12165
13. Adrian, Wong, Lorraine, et al. Montreal cognitive assessment. Stroke (2015).
14. Fan Y, Sun L, Xu LJ, Peng Y, Liu HB, He CN, et al. In silico approach for anti-
thrombosis drug discovery: P2Y1R structure-based TCMs screening. Front Pharmacol
(2016) 7:531. doi: 10.3389/fphar.2016.00531
15. Hamosh A, Scott AF, Amberger JS, Bocchini CA, McKusick VA. Online
Mendelian Inheritance in Man (OMIM), a knowledgebase of human genes and
genetic disorders. Nucleic Acids Res (2002) 33:D514–7. doi: 10.1093/nar/30.1.52
16. Chen X, Ji ZL, Chen YZ. TTD: therapeutic target database. Nucleic Acids Res
(2002) 30(1):412–5. doi: 10.1093/nar/30.1.412
17. Hewett M, Oliver DE, Rubin DL, Easton KL, Stuart JM, Altman RB, et al.
PharmGKB: the pharmacogenetics knowledge base. Nucleic Acids Res (2002) 311:179–
91. doi: 10.1093/nar/30.1.163
18. Wishart DS. DrugBank: A general resource for pharmaceutical and
pharmacological research. Mol Cell Pharmacol (2010) 2(1):D901–6. doi: 10.1093/nar/
gkm958
Zhang et al.
10.3389/fendo.2023.1213711
Frontiers in Endocrinology
frontiersin.org
09

## Page 10 (Section: Data availability statement)

19. Gong H, Wang M, Zhang H, Elahe MF, Jin M. An explainable AI approach for
the rapid diagnosis of COVID-19 using ensemble learning algorithms. Front Public
Health (2022) 10:874455. doi: 10.3389/fpubh.2022.874455
20. Gong H, You X, Jin M, Meng Y, Zhang H, Yang S, et al. Graph neural network
and multi-data heterogeneous networks for microbe-disease prediction. Front
Microbiol (2022) 13:1077111. doi: 10.3389/fmicb.2022.1077111
21. Zeng W, Davoodi A, Topaloglu RO. (2020). Explainable DRC hotspot prediction
with random forest and SHAP tree explainer[C]// 2020 Design, in: 2020 Design,
Automation & Test in Europe Conference & Exhibition, Grenoble, France: Institute of
Electrical and Electronics Engineers (IEEE).
22. Wang J, Yue RS, Wang XM, Liu RR, Zhao WW, Yang MY, et al. Effects of the
method of promoting spleen and dispersing essence on intestinal ﬂora and immune
function of T2DM patients based on the theory of'spleen qi dispersing essence. China J
Traditional Chin Med Pharm (2019).
23. Ghatan S, Ahmadizar F, Li R, Ling O. Type 2 diabetes clusters indicate diabetes
duration key in fracture risk. J Endocrine Soc (2021). doi: 10.1530/endoabs.73.PEP2.2
24. Vega T, Gil M, Lozano J. Age and sex differences in the incidence of diabetes
mellitus in a population-based Spanish cohort. J Diabetes (2015) 7(3):411. doi: 10.1111/
1753-0407.12183
25. Dunkley AJ, Tyrer F, Spong R, Gray LJ, Gillett M, Doherty Y, et al. Screening for
glucose intolerance and development of a lifestyle education programme for prevention
of Type 2 diabetes in a population with intellectual disabilities. Programme Grants Appl
Res (2016) 5(11). doi: 10.3310/pgfar05110
26. Cai X, Lei W, Wang X, Liu S. Effect of high dietary ﬁber low glycemic index diet
on intestinal ﬂora, blood glucose and inﬂammatory response in T2DM patients. Allied
Academies (2018) 2017(21):9371–5.
27. Ma Q, Li Y, Li P, Wang M, Wang J, Tang Z, et al. Research progress in the
relationship between type 2 diabetes mellitus and intestinal ﬂora. Biomed Pharmacother
(2019) 117:109138–. doi: 10.1016/j.biopha.2019.109138
28. Li Y, Chen D, Zhang F, Lin Y, Liu J. Preventive effect of pressed degreased walnut
meal extracts on T2DM rats by regulating glucolipid metabolism and modulating gut
bacteria ﬂora. J Funct Foods (2020) 64:103694. doi: 10.1016/j.jff.2019.103694
Zhang et al.
10.3389/fendo.2023.1213711
Frontiers in Endocrinology
frontiersin.org
10


---

# ROAD2H: Development and evaluation of an open-source explainable artificial intelligence approach for managing co-morbidity and clinical guidelines

- **Authors:** Jesús Domínguez, Denys Prociuk, Branko Marović, Kristijonas Čyras, Oana Cocarascu, Francis Ruiz, Ella Mi, Emma Mi, Christian Ramtale, Antonio Rago, Ara Darzi, Francesca Toni, Vasa Curcin, Brendan Delaney
- **Issuer:** Learning health systems
- **Type:** Scientific article
- **Published:** 2023-09-12
- **Language:** en
- **DOI:** 10.1002/lrh2.10391
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38633019/
- **Licence:** CC-BY

## Section: Abstract

AbstractIntroductionClinical decision support (CDS) systems (CDSSs) that integrate clinical guidelines need to reflect real‐world co‐morbidity. In patient‐specific clinical contexts, transparent recommendations that allow for contraindications and other conflicts arising from co‐morbidity are a requirement. In this work, we develop and evaluate a non‐proprietary, standards‐based approach to the deployment of computable guidelines with explainable argumentation, integrated with a commercial electronic health record (EHR) system in Serbia, a middle‐income country in West Balkans.MethodsWe used an ontological framework, the Transition‐based Medical Recommendation (TMR) model, to represent, and reason about, guideline concepts, and chose the 2017 International global initiative for chronic obstructive lung disease (GOLD) guideline and a Serbian hospital as the deployment and evaluation site, respectively. To mitigate potential guideline conflicts, we used a TMR‐based implementation of the Assumptions‐Based Argumentation framework extended with preferences and Goals (ABA+G). Remote EHR integration of computable guidelines was via a microservice architecture based on HL7 FHIR and CDS Hooks. A prototype integration was developed to manage chronic obstructive pulmonary disease (COPD) with comorbid cardiovascular or chronic kidney diseases, and a mixed‐methods evaluation was conducted with 20 simulated cases and five pulmonologists.ResultsPulmonologists agreed 97% of the time with the GOLD‐based COPD symptom severity assessment assigned to each patient by the CDSS, and 98% of the time with one of the proposed COPD care plans. Comments were favourable on the principles of explainable argumentation; inclusion of additional co‐morbidities was suggested in the future along with customisation of the level of explanation with expertise.ConclusionAn ontological model provided a flexible means of providing argumentation and explainable artificial intelligence for a long‐term condition. Extension to other guidelines and multiple co‐morbidities is needed to test the approach further.

## Section: BACKGROUND

Increasingly, developers of clinical guidelines, such as the World Health Organization (WHO) and the National Institute for Health and Care Excellence (NICE) 1 in the United Kingdom, have sought to implement aspects of guidance via encouraging the creation of computational algorithms, often proprietary, within electronic health records (EHR). However, multimorbidity, defined as the coexistence of two or more chronic medical conditions in an individual patient, 2 is common in the real world and presents a multitude of competing priorities, potential contraindications, and guideline exceptions to the clinician. Although studies have shown clinical decision support (CDS) improves clinicians' adherence to clinical and operational guidelines for medication, prevention, and treatment, 3 , 4 , 5 , 6 problems with ‘alert fatigue’, confusion and contradiction between different CDS alerts can represent a threat to patient safety. 7 ​​Computable guidelines (CGs), machine‐interpretable versions of guidelines, have the potential to alleviate some of this burden on the clinician by using ‘argumentation’, that is, defining the ‘best’ option from a series of logical statements. 8 However, in low‐ and middle‐income countries (LMIC), the resources required for proprietary EHR‐integrated CDS systems (CDSSs), localization and maintenance are often not available. 9 In contrast, open source code can be written to extract data and trigger a rule externally. For example, using both the FHIR API, a global standard to promote data‐level interoperability among disparate EHRs, and CDS Hooks, 10 a specification for standardising the seamless integration of external services in EHRs. Growing functionality in CDS can be represented as multiple interacting models and ontologies as written rules are replaced by computable ones, 11 allowing, for example, a model of the patient's current clinical state to present data to a model of appropriate guideline statements, applied to derive a care recommendation.

To meet the challenge of co‐morbidity, a model of clinical reasoning between conflicting statements is required. Argumentation models amount to automated systems that emulate human reasoning, 12 positioning arguments and counterarguments for a given issue to find the ‘winning’ arguments. Argumentation is a good fit for modelling patient‐centric reasoning with multiple guidelines where interacting recommendations and alerts give rise to conflicts, and the context of a patient brings in various conditions, goals, and preferences. 13

The EPSRC‐funded ROAD2H project aimed to develop and evaluate a representative CDSS for embedding and enacting the internationally accepted Global Initiative for Chronic Obstructive Lung Disease 14 (GOLD) guideline, illustrating the role of argumentation‐based techniques in presenting conflict‐safe care plan proposals to clinicians, and integrating the system with a modern standards‐based commercial EHRs in a middle income country (Heliant, 15 the largest healthcare information systems provider in Serbia) using a combination of knowledge representation and interoperability standards.

## Section: METHODS

Recommendations based on GOLD guideline, represented as TMR knowledge.

Graphical representation of the recommendations in Table 1, and their identified potential interactions when administered together. Adm. stands for administer, recs for recommendations, CB for causation belief (there are exclusively one per recommendation for the iteration of the TMR model applied in this project), SABA (SAMA) stands for short‐acting beta‐agonist (muscarinic antagonist) bronchodilator.

Response example by the conflict resolution service from Figure 2 using the TMR‐based knowledge from Figure 1.

Architecture of the multipurpose, argumentation‐based TMR‐driven CDS system. The interoperability service is labelled as the CDS hooks manager microservice. The TMR‐based conflict resolution microservice implements ABA+G to handle TMR‐based knowledge. Similarly, the reasoner and CGs store microservices implement the TMR model and reasoning logic, the former, and a SPARQL server, the latter. Both managed by the CGs interaction microservice. The CDS services manager encapsulates the semantics of CDS services and the conversion of TM—based CIG‐specific knowledge into FHIR artifacts.

Workflow of the TMR‐based COPD framework. Modelled workflow of how CDS calls are handled by the CDS Services Manager microservice in the argumentation‐based, TMR‐driven CDS system.

Contextual information for hook ‘copd‐assess’.

Contextual information for hook ‘copd‐careplan’.

Clinical case vignette of patient introduced in Figure 4.

## Section: METHODS › Clinical case study

We chose the management of chronic obstructive pulmonary disease (COPD) with cardiovascular (CVD) or chronic kidney disease (CKD) co‐morbidities as an exemplar. The GOLD guideline classifies the COPD symptom severity as a series of stages or groups, each with recommended treatments in a ‘step up’ fashion. In addition, some of the therapies are contraindicated in co‐morbidity, for example, beta agonist medications with angina. 14 COPD is increasingly common in LMIC, so we aimed at designing a CDSS that integrates both COPD symptom severity assessment and treatment planning with the workflow of pulmonologists in the EHR. Requirements were to identify potential treatment conflicts and suggest alternative care plans.

## Section: METHODS › The Transition‐based Medical Recommendation (TMR) model

To reason about potential interactions among, or within, guidelines, we adopted the TMR model, 3 , 16 a formalism to represent guidelines and detect conflicts using semantic web technologies and logic rules. TMR‐represented recommendations (see Table 1) comprise a care action and its causation belief, that is, the expected effect on the measured property the care action affects. Care actions promote transitions which comprise the initial (clinical) state and the expected state of the affected measured property. Care action effects potentially increase or decrease the value of the measured property associated with a recommendation. There are implementations of TMR for prototyping guideline representation (using the RDF model for guideline representation and SPARQL 17 as its query language) and interactions theory (using the logic‐based programming language SWI‐Prolog); however, neither implementation offers enactment nor automated merging of CG statements. Like other multimorbidity‐oriented formalisms, 4 , 5 TMR currently lacks the reasoning capabilities to resolve the identified interactions and does not consider patient‐specific conditions, goals, or treatment and lifestyle preferences. 6 The computational argumentation formalism described next aims to integrate all these elements to provide automated reasoning with interacting TMR‐based CGs, considering the patient's context and preferences.

Recommendations based on GOLD guideline, represented as TMR knowledge.

## Section: METHODS › Explainable argumentation

To reason over the guideline conflicts, we made use of the Assumption‐Based Argumentation with Preferences and Goals 13 (ABA+G) technique, which represents knowledge using a formal (logical) language, rules, and defeasible assumptions. Rules and assumptions allow for a transparent and interpretable representation of the TMR concepts, particularly recommendations and their components, as illustrated in Figure 1, where interactions among recommendations can likewise be captured via rules. For example, and following Figure 1, the contradictory interaction between recommendations R saba and R beta is expressed via two rules that assume R saba leads to an objection against R beta , and vice versa. Moreover, since R sama is identified as an alternative recommendation to R saba , then acceptance of R beta leads to the acceptance of R sama by application of a rule which assumes both that R beta and R Saba object each other and that R beta and R sama do not object each other.

Explainability, as in not only providing explanations accompanying reasoning outcomes, but also the overall transparency in knowledge representation and reasoning mechanisms, is a fundamental requirement of CDSS. 18 Argumentation is itself an explainable reasoning paradigm, 19 and it has also given rise to explanations in various settings, including AI. 20 , 21 , 22 ABA+G natively affords means to explain its reasoning outcomes. Specifically, ABA+G yields explanations of the reasoning trace, its actions and expected effects. Explanations summarise the considered interactions and preferences, and accompany each proposed set of recommendations (eg, Table 2). A TMR‐based implementation of ABA+G (hereinafter the conflict resolution service) was utilized in this project. 23

Graphical representation of the recommendations in Table 1, and their identified potential interactions when administered together. Adm. stands for administer, recs for recommendations, CB for causation belief (there are exclusively one per recommendation for the iteration of the TMR model applied in this project), SABA (SAMA) stands for short‐acting beta‐agonist (muscarinic antagonist) bronchodilator.

Response example by the conflict resolution service from Figure 2 using the TMR‐based knowledge from Figure 1.

## Section: METHODS › Integration with heterogeneous EHR systems

We designed a general‐purpose ontology‐based CDSS architecture based on open‐source and industry standards that consists of an interoperability service, and a CGs enactment architecture which includes ABA+G and extends on an existing CGs authoring microservice architecture. 24 The interoperability service is common to any implementation and uses SNOMED CT and FHIR standards to exchange healthcare data with EHRs. In addition, CDSS‐subscribed EHRs invoke event‐specific CDS according to CDS hooks specification standards where notifications for CDS and their responses are delivered in the form of hooks and cards, respectively. 10 Cards convey information determined by implementations of the CDSS architecture for specific CG formalisms and CDS events (eg, TMR and COPD treatment planning, respectively). Appendix A.2 furthers this description. A TMR‐based implementation of the generic CDSS architecture is illustrated in Figure 2 and discussed next.

To enable argumentation over TMR, we developed a suite of microservices (hereinafter the [TMR‐based] CDS framework) to enact, and personalise, TMR‐based CGs that includes the conflict resolution service and leverages a TMR‐based implementation of the CGs authoring microservice architecture. 24 This implementation encapsulated the previously mentioned existing TMR technology to store, query, and reason about TMR‐based knowledge. 24

Patient‐relevant parts of implemented TMR‐based CGs are triggered in the CDS framework by event‐specific data included in the context of the CDS call. Each triggered recommendation is identified by a pair of unique RDF URIs referencing the recommendation and its CG, and combined into a volatile dataset using SPARQL. TMR interaction detection rules are then applied to this dataset. The dataset and detected potential interactions are encoded in JSON alongside user‐defined preferences included in the hook's context, then forwarded to the conflict resolution service. The response of this service consists of a collection of ‘extensions’ originating from the dataset, where each extension comprises TMR recommendations aggregated by considering potential interactions within the extension and preferences. The explainability component then refactors the encoded knowledge from each recommendation into information for CDS in both computer‐interpretable and textual form. Finally, the response is embedded into a card by mapping extensions to FHIR carePlan types, resulting in personalized conflict‐free care plan proposals comprising triggered recommendations potentially from multiple CGs and which include mitigation information on potential interactions among triggered recommendations from the source dataset (eg, alternative recommendations distributed into distinct proposals). Figure 3 provides a modelled workflow of the system.

Architecture of the multipurpose, argumentation‐based TMR‐driven CDS system. The interoperability service is labelled as the CDS hooks manager microservice. The TMR‐based conflict resolution microservice implements ABA+G to handle TMR‐based knowledge. Similarly, the reasoner and CGs store microservices implement the TMR model and reasoning logic, the former, and a SPARQL server, the latter. Both managed by the CGs interaction microservice. The CDS services manager encapsulates the semantics of CDS services and the conversion of TM—based CIG‐specific knowledge into FHIR artifacts.

Workflow of the TMR‐based COPD framework. Modelled workflow of how CDS calls are handled by the CDS Services Manager microservice in the argumentation‐based, TMR‐driven CDS system.

## Section: METHODS › Evaluation framework

To evaluate our proposed CDS approach, we aimed to formalise key aspects of GOLD for stable COPD, including pharmacological, vaccination, physiotherapy, and smoking cessation therapies, plus drug‐disease warnings for CVD and CKD co‐morbidities. Appendix A.1 discusses the steps towards GOLD guideline formalisation using TMR. Subsequently, we defined hook specifications ‘copd‐assess’ (Table 3) and ‘copd‐careplan‐review’ for COPD management CDS (Table 4) and worked with Heliant to integrate the remote CDSS with their EHR via a graphical user interface (GUI) add‐on embedded in the EHR's COPD tab.

We used simulated case vignettes to create dummy EHRs as access to real patients was prohibited by COVID‐19 restrictions. Two clinical authors (Ella Mi, Emma Mi) created 20 cases. Each case contained data as illustrated in Table 5. All GUI textual outputs were rendered in Serbian and validated by a Serbian clinician.

This was a mixed‐methods evaluation to analyse quantitatively the validity of the recommendations and qualitatively the clinicians' impressions of the approach. We recruited a purposive sample of five pulmonologists from Clinical Hospital Centre Zvezdara in Serbia to use the extended Heliant EHR with each of the 20 cases, providing 100 cases in total. First, we aimed to determine their agreement with the results of both CDS services for each clinical case. Second, after operating the system we interviewed each clinician using a structured questionnaire.

Contextual information for hook ‘copd‐assess’.

Contextual information for hook ‘copd‐careplan’.

Clinical case vignette of patient introduced in Figure 4.

## Section: RESULTS

To evaluate our CDS approach for the management of patients with stable COPD, TMR representations of selected GOLD recommendations were defined and loaded into a dedicated SPARQL database. Similarly for the pair of hook context processing instructions described in Tables 6 and 7 (NoSQL database linked to the CDS hooks manager microservice), based on the specifications in Tables 3 and 4. This resulted in the specialisation of the TMR‐based CDSS for COPD symptom severity assessment and treatment planning decision‐making, hereinafter the COPD‐CDSS.

The COPD‐specialised GUI interacts with the COPD‐CDSS by collecting COPD‐related measurements and other relevant clinical details stated in both hooks' specifications, to aid with both clinical events. Each event invokes a CDS service, triggered their respective buttons in the GUI (see Figure 4). Using a GUI form to collect or modify input was a design choice made by Heliant that benefitted the pulmonologists when evaluating the COPD‐CDSS and was preferred by Heliant over the direct collection of relevant EHR data, which was perceived as less transparent and insufficiently interactive.

Figure 5 shows the clinical contents of the card responding to hook ‘copd‐assess’ integrated with the GUI, that is, the personalized GOLD group and treatments preference order suggested by the COPD‐CDSS. However, no preference ordering is maintained when launching hook ‘copd‐careplan‐review’ via button ‘Personalised care plan’, that is, ticked checkboxes linked to field ‘Suggested treatments’ are considered equally preferred. This design choice was made by Heliant to simplify user interaction. Consequently, preferences and goals were left out of the COPD‐CDSS evaluation.

Figure 6 shows the selection made by the pulmonologist when triggering hook ‘copd‐careplan‐review’ and the resulting EHR‐integrated card. The COPD‐CDS response proposed three personalized care plans, the top one has SABA as COPD treatment, which was the sole selection made by the pulmonologist in field ‘Suggested treatments’. The additional proposals provide alternative COPD treatments for the user‐selected COPD group as taken from the ‘copd‐assess’ response. Additional proposals are added due to detected contradictory recommendations involving beta‐agonists (see Figure 1). As a beta‐agonist, SABA is not recommended for susceptible COPD patients with comorbid CVD. Application of the SABA‐based care plan does not resolve the conflict, some of the other proposals do, so the drug‐disease conflict warning was included as an explanation in the proposal with no beta‐agonists. In addition, there are recommendations for pulmonary rehabilitation therapy and for the pneumococcal vaccination. The former is common to all COPD patients, the latter is due to the patient's age (66). The rationale behind each proposed recommendation (Figure 6, right tab) is depicted in a structured form, generated from the encoded terms provided by the explainability algorithm, part of the conflict resolution engine. This design choice was chosen over the generated (English) textual representation (eg, Table 2, column Explanation) as it enhances scalability and simplifies translation: encoded TMR terms support formal interpretation (eg, finding SNOMED CT representatives, however mapping back TMR‐based knowledge to SNOMED CT was not part of the evaluation). The right tab in Figure 6 enumerates potential interactions found in the SABA‐driven care plan (depicted in Figure 1) and how they were resolved (here, by excluding interacting treatments from this proposed care plan). The text utilises a mix of FHIR detectedIssue resources and ROAD2H‐defined nomenclature to describe conflicts and their resolutions.

Collection of JSON‐based documents applied to contextual data of CDS hook ‘copd‐assess’.

Collection of JSON‐based documents applied to contextual data of CDS hook ‘copd‐careplan‐review’.

The COPD‐CDSS GUI presented on Heliant's EHR's COPD tab. The opened EHR belongs to a male patient with no previous COPD history. The COPD‐CDSS GUI is displaying the result of the patient's first COPD symptom severity assessment, entered by the pulmonologist. The ‘COPD assessment’ button triggers hook ‘copd‐assess’. The hook's response provides the content to fields ‘Suggested COPD group’ and ‘Suggested treatments’.

COPD severity assessment response as invoked by the CDS hook ‘copd‐assess’ in the COPD‐CDSS for the patient introduced in Figure 4.

COPD treatment planning response by COPD‐CDSS for the patient with EHR and COPD severity assessment displayed in Figure 5. Results are split into two tabs, presented here as one image for the sake of readability. The left tab displays the rationale behind each proposed recommendation; the right tab displays mitigation results for the identified potential interactions among proposed recommendations. A black arrow was added to the image to indicate the button that displays each tab when clicked.

## Section: EVALUATION › Agreement with COPD‐CDSS results

Data derived from 99 EHRs were returned by the events log of both the COPD‐CDSS and Heliant's EHR system when each pulmonologist assessed their 20 cases once. When verifying each EHR, we found 65 cases where entry data did not match that of the provided case vignettes. Many of these modifications were dynamically inserted by pulmonologists at evaluation using the provided GUI, so we deduced they chose to challenge the COPD‐CDSS outside the boundaries of the provided cases. However, as we focus on the pulmonologist behaviour for each EHR and associated CDS service, these discrepancies do not affect the overall evaluation. We found two Serbian mistranslations of clinical recommendations that may have left clinicians with a misleading understanding (see Appendix B.2, Table 8).

Reported results matched proposed COPD‐CDSS outcomes with pulmonologists' decisions for the same cases. Pulmonologists agreed 97% of the time with the GOLD group assigned by COPD‐CDSS to each EHR. The remaining 3% found a discrepancy between the use case and the EHR‐stored data. Personalised COPD‐related therapies were also suggested, and prioritized, for each case. Our analysis indicated pulmonologists corroborated the most favoured therapy for 31.3% of the cases whereas second, third, and fourth preferences had 33.3, 24.2, and 9.1 selection rates, respectively. Rejection of all suggested therapies was 2% and accordant with the previous 3% of discrepancy.

Next, the COPD‐CDSS presented one or more alternative care plan proposals for each case, based on the pulmonologist's selected GOLD group and corresponding therapy. Each proposal incorporated personalised recommendations and warnings. Pulmonologists rejected all alternative proposals in the same selection for 1% of the cases while at least one of the proposals was deemed suitable for 71.7% of the cases. A satisfactory proposal was derived by the pulmonologists for the remaining 27.3% of the cases by de‐selecting a pair of mistranslated recommendations (English to Serbian) from some results. Incorporating recommendations from alternative proposals was allowed; however, none of the pulmonologists deemed necessary to augment their selected proposal for each case. Interestingly, for 72% of the cases, clinicians selected the topmost displayed proposal from the unordered collection presented on the GUI.

## Section: EVALUATION › Qualitative analysis

Following use of the COPD‐CDSS integrated with Heliant's EHR and the 20 vignettes, five pulmonologists were invited to take part in individual interviews and responses were documented by the researcher. A structured protocol was used as a guide to explore perceptions in using the COPD‐CDSS with case vignettes. For a full list of evaluation questions and answers, see Appendix B.3. The following themes were developed from examining all clinicians' responses:

## Section: EVALUATION › Qualitative analysis › Treatment and management options

All five pulmonologists agreed the CDS offered a wide range of treatment options. One respondent suggested the CDS offered appropriate treatment choices including alternative therapeutic options.

Offered options for medication, based on the entered parameters on severity and discomfort of disease. Also, the idea of non‐medical recommendations. (Doctor 2).

One respondent suggested the drug therapies presented could be more precise.

The data must be more precise. E.g., drugs from the group of beta‐agonists are divided into SABA and LABA, and it must be clear to which therapeutic option the data refers to… (Doctor 1).

## Section: EVALUATION › Qualitative analysis › Functionality and usability

All five clinicians agreed there were no features of the COPD‐CDSS they found unhelpful or ‘least useful’.

The CDS was positively regarded as a “Clear and concise software” (Doctor 3). Although technical issues related to data entry were raised, one respondent stated these were easily resolved.

… Minor technical problems (that) were easily resolved in consultations and with the support of the IT specialist (Doctor 3).

One respondent suggested future development of the CDS should aim to be more streamlined.

“The goal of every system is simplicity, speed, and efficiency, with as few unnecessary pop‐ups and additional questions as possible. (Doctor 5).

One way of using the CDS efficiently is integration into existing systems to reduce workload.

Integration with the existing hospital information system, so that all required data for the patient is already present in the EHR system … Avoiding the unnecessary entering of the same data is a waste of time (Doctor 2).

## Section: EVALUATION › Qualitative analysis › Patient monitoring and data capture

The CDS was thought to be useful for continual health monitoring purposes.

In situations when the patient comes regularly for examinations, for better monitoring (Doctor 4).

However, most respondents suggested a wider range of patient data should be captured including co‐morbidities, diagnostic investigations, and other therapeutic options.

As much patient data as possible should be entered into the system (from the EHR) (Doctor 4).

Not enough options for entering the data on associated diseases of importance (Doctor 1).

Functions of including other aspects (findings) such as spirometry, lab tests, X‐rays (Doctor 3).

No therapeutic option for ICS in deciding on a therapeutic option when entering data for patients who also have asthma (Doctor 3).

## Section: EVALUATION › Qualitative analysis › Additional uses of the CDS

One respondent thought the CDS would be an effective companion tool for less experienced clinicians.

The system is a very good idea and a kind of guideline for doctors with little clinical experience at the very beginning of independent management of patients, and then their outpatient examinations. (Doctor 5).

Respondents also said that CDS could be used to aid decisions for other diseases.

It can serve as an advising tool and as a reminder of other guidelines if they exist in other diseases (Doctor 2).

It would not be bad to expand the field of action to other specialties (gastroenterology, endocrinology, cardiology…) and thus help in deciding the patient with co‐morbidities initially during outpatient consultations. (Doctor 5).

## Section: DISCUSSION

We successfully extended the TMR ontological framework for expressing guideline recommendations to provide individual patient‐based reasoning and explanation via argumentation. In addition, a CDS microservices architecture based on open standards (SNOMED CT, HL7 FHIR and CDS Hooks) was used to embed the resulting TMR‐based CDS framework into a commercial EHR platform. Although the system can manage more than two interactions at a time, our evaluation was limited to interactions arising from a single guideline because of the nature of the clinical use case. In clinical practice patients with co‐morbidities will have multiple applicable guidelines, potentially increasing the complexity of interactions. Further development of the TMR‐based CDS framework to cover multiple guidelines is needed to fully evaluate the robustness of our approach. Furthermore, due to the COVID‐19 pandemic, the evaluation in Serbia was delayed for 12 months and was eventually only able to go ahead with five pulmonologists and 20 clinical vignettes rather than live in a COPD clinic as planned. The EHR vendor also introduced several restrictions in that some of the clinical vignette data had to be entered by the clinician at the start, rather than being already present in the EHR, and the ability to order recommendations by prior patient preference and overall clinical goals, for example, cost/effectiveness, was omitted. Many of the comments in the qualitative analysis reflect these limitations rather than inherent issues with the approach.

In the practical application of the approach, we note several limitations. First, the representation of the GOLD statements in TMR is time‐consuming, requiring input from experienced clinicians and knowledge engineers. This problem is common to all knowledge representation approaches including PROFORMA, 25 Arden Syntax, 26 and CQL. 27 However, as TMR relationships are defined using the semantic web, this may offer a potential route for semi‐automation of the guideline representation process. A combination of natural language processing and expression of found concepts and relationships as knowledge graphs, constrained by the TMR ontology, would be the next research step. The current version of TMR was suitable to represent the cyclic workflow style of managing a chronic condition like stable COPD; however, more complex scenarios will require for TMR to handle temporal reasoning, drug dosing and guideline flow control. Future research will explore these topics. In terms of integration with EHRs, FHIR is being increasingly adopted and CDS Hooks is a non‐proprietary standard, so the approach we took with Heliant should be widely replicable in other LMIC where open‐source EHRs based on standards are of value. Guidelines represented in TMR are also a shareable open resource, with potential for local adaptation and optimisation in a transparent way. Although existing syntaxes such as CQL have much greater maturity than TMR, TMR being an ontological approach is much more extensible (as in our addition of argumentation) and a better fit with advances in ontology‐based knowledge extraction methods such as neural‐symbolic reasoning. 28

Arguably, the ABA+G explanations delineated above do not make use of the full spectrum of explanation techniques available in argumentation. Nevertheless, together with the explainable nature of argumentation, they are a steppingstone in meeting explainability guidelines for the deployment of AI‐assisted systems produced by the UK Information Commissioner's Office and the Turing Institute. These explanations indicate the reasoning underlying the recommendations in the spirit of Explainable AI methods drawn from argumentative abstractions. As future work, we would explore whether interactive forms of explanations, as in asking questions, naturally supported by argumentation, could be an alternative approach to providing explanation in our context. 29

Microservices are independently manageable services, creating applications that improve scalability, are more resilient and have better fault isolation. For instance, a strategy to extend the reach of the COPD‐CDSS to multiple Serbian healthcare institutions would entail the distribution of incoming CDS requests among multiple instances of each microservice in the TMR‐based architecture. Then, a load balancer server would act as proxy between the clients and the CDS hooks manager service instances, distributing CDS requests according to an algorithm. Similarly for the interaction among the components of the CGs enactment engine. Furthermore, the enhancement of the generic CDS system to manage other chronic diseases such as diabetes or cardiovascular disease could be achieved by formalising the respective guideline(s) using TMR and by deploying a separate TMR‐based CDS services manager microservice linked to the other existing CGs enactment engine components. Then, new CDS services would be registered by designing both dedicated CDS hooks and their corresponding JSON‐based documents (the latter added to the CDS hooks manager microservice database). In this context, the COPD‐CDSS would not be affected by the deployment or execution of the newly registered CDS services, for instance if some complex functionality applicable to the parameters in the corresponding JSON‐based document fails (see point number 2 in Figure 3).

The ROAD2H approach to embedding computable guidelines into decision support tools is very much aligned with the WHO SMART guideline initiative which aims to support translation of existing knowledge into computable guidelines using Digital Adaptation Kits (DAKs). The TMR model provides a blueprint for implementing the business processes & workflows and decision support elements of a DAK, and we are currently looking into developing ROAD2H‐based DAKs for multimorbidity scenarios.

## Section: CONCLUSION

We approached the problem of supplying explainable AI in the form of a CDSS for guidelines by representing guideline statements and an assessment of the patient's disease stage using an existing ontological model of guideline recommendations, the TMR model, and building argumentation as an additional reasoning layer on top of it. On the example of COPD, we proved that it is possible to transact guideline statements, recommendations and contraindications using this approach and to implement them using a microservice model incorporating widely used standards (SNOMED CT, FHIR API and CDS Hooks). In addition, the system was implemented in integration with a commercial EHR widely used in Serbia and other West Balkans LMICs. A mixed‐method evaluation using vignettes also showed high agreement with pulmonologists and favourable views on the implementation and the potential of such systems. Thus, the strategy of providing standard‐based, explainable, and reproducible CDS that integrate in real‐time with clinical systems shows promise and should be explored further.

## Section: AUTHOR CONTRIBUTIONS

Jesús Domínguez: Software engineering; computing design; writing; final draft approval. Denys Prociuk: Software engineering; data collection; analysis; writing; final draft approval. Branko Marović: Conceptualisation and funding; software engineering; computing design; data collection; analysis; project administration and leadership; writing; final draft approval. Kristijonas Čyras: Final draft approval. Oana Cocarascu: Software engineering; computing design; analysis; final draft approval. Francis Ruiz: Conceptualisation and funding; analysis; project administration and leadership; writing; final draft approval. Ella Mi: Clinical feedback; data collection; analysis; writing; final draft approval. Emma Mi: Clinical feedback; data collection; analysis; writing; final draft approval. Christian Ramtale: Data collection; analysis; writing; final draft approval. Antonio Rago: Software engineering; computing design; analysis; final draft approval. Ara Darzi: Conceptualisation and funding; clinical feedback; project administration and leadership; writing; final draft approval. Francesca Toni: Conceptualisation and funding; software engineering; computing design; project administration and leadership; writing; final draft approval. Vasa Curcin: Conceptualisation and funding; software engineering; computing design; project administration and leadership; writing; final draft approval. Brendan Delaney: Conceptualisation and funding; software engineering; clinical feedback; analysis; project administration and leadership; writing, final draft approval.

## Section: FUNDING INFORMATION

The study was funded by the Engineering and Physical Sciences Research Council Global Challenges Research Fund grant ROAD2H: Resource Optimisation, Argumentation, Decision Support, and Knowledge Transfer to Create Value via Learning Health Systems (EP/P029558/1), the UK Research and Innovation, and Health Data Research UK. The authors gratefully acknowledge infrastructure support from the National Institute for Health and Care Research (NIHR) Imperial Patient Safety Translational Research Centre, the NIHR Imperial Biomedical Research Centre.

## Section: CONFLICT OF INTEREST STATEMENT

The authors declare that they have no financial or non‐financial competing interests.

## Section: Supporting information

Data S1. Supporting Information.

Appendix S1. Supporting Information.


---

# Secondary Use Provisions in the European Health Data Space Proposal and Policy Recommendations for Korea

- **Authors:** Won Bok Lee, Sam Jungyun Choi
- **Issuer:** Healthcare informatics research
- **Type:** Scientific article
- **Published:** 2023-07-31
- **Language:** en
- **DOI:** 10.4258/hir.2023.29.3.199
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37591675/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractObjectivesThis article explores the secondary use provisions of the European Health Data Space (EHDS), proposed by the European Commission in May 2022, and offers policy recommendations for South Korea.MethodsThe authors analyzed the texts of the EHDS proposal and other documents published by the European Union, as well as surveyed the relevant literature.ResultsThe EHDS proposal seeks to create new patient rights over electronic health data collected and used for primary care; and establish a data sharing system for the re-use of electronic health data for secondary purposes, including research, the provision of personalized healthcare, and developing healthcare artificial intelligence (AI) applications. These provisions envisage requiring both private and public data holders to share certain types of electronic health data on a mandatory basis with third parties. New government bodies, called health data access bodies, would review data access applications and issue data permits.ConclusionsThe overarching aim of the EHDS proposal is to make electronic health data, which are currently held in the hands of a small number of organizations, available for re-use by third parties to stimulate innovation and research. While it will be very challenging for South Korea to adopt a similar scheme and require private entities to share their proprietary data with third parties, the South Korean government should consider making at least health data collected through publicly funded research more readily available for secondary use.Keywords: European Health Data Space, Health Data, Electronic Health Records, Secondary Use, Privacy

## Section: I. Introduction

On May 3, 2022, the European Commission published its proposal to create a European Health Data Space (the “EHDS Proposal”) [1]. The EHDS Proposal aims to introduce a new, unprecedented framework to make electronic health data available for re-use for various purposes, including research. This proposal is groundbreaking on two counts: (1) the electronic health data to be made available for re-use include data held by both public sector bodies and private sector organizations—meaning that private companies would be required to disclose certain electronic health data to third parties for re-use; and (2) the recipients of the data (called data users) are allowed to use the data for a number of purposes, including, among others, scientific research, product development, artificial intelligence (AI) training, and personalized healthcare—meaning that data can be used for commercial purposes. The background to this proposal is that, in the eyes of European policymakers, the coronavirus disease 2019 (COVID-19) pandemic highlighted the importance of having up-to-date health data to respond to public health crises.

The EHDS Proposal is anticipated to have wide-reaching consequences for the healthcare sector, transforming the way in which electronic health data will be shared and reused in Europe. The EHDS Proposal is still in draft form and progressing through the European legislative process, so it is likely to change. This article analyzes the EHDS Proposal as first published by the European Commission, with a focus on the provisions on secondary use of electronic health data. This article discusses the newly proposed mandatory data sharing regime for secondary use of electronic health data, and the responses to this proposal from industry and academia. The final section of this article discusses the potential policy implications of the EHDS Proposal in Korea.

## Section: II. Methods

The European Commission published the initial text of the EHDS Proposal on May 3, 2022. The draft is now under review by the European Parliament and the Council of the European Union (EU). Each of these institutions will formulate their own version of the proposal, and they will then enter into negotiations to agree on a compromise text to be adopted. Agreement on the EHDS Proposal is expected at the end of 2023 or early 2024. The authors of this paper analyzed the EHDS Proposal and surveyed other documents published by the EU that provide insights into the EHDS Proposal, as well as the relevant literature.

## Section: III. Results

Overview of the provisions in the EHDS Proposal

Key definitions in the EHDS Proposal

Minimum categories of electronic data for secondary use

Allowed and prohibited purposes for secondary use of electronic health data under the EHDS Proposal

Flowcharts for secondary use in the EHDS Proposal. (A) For data access applications and data requests to multiple data holders in more than one member state. (B) For data access applications and data requests to a single data holder in one member state. HDAB: health data access body, EHDS: European Health Data Space, EHD: electronic health data.

## Section: III. Results › 1. Background

The EHDS Proposal is a sector-specific component of the EU’s European Strategy for Data, announced in 2020 (EU Data Strategy) [2]. The EU Data Strategy recognizes data as “the lifeblood of economic development.” The ultimate aim of the strategy is to ensure that Europe is able to capture the benefits of better use of data by increasing the use of, and demand for, data and data-enabled products and services throughout the EU.

The EU Data Strategy is operationalized through numerous horizontal legislative reforms—such as the Data Governance Act (entered into force in June 2022) and the Data Act (proposed in February 2022, not yet adopted)—and sector-specific, vertical legislative reforms targeting key sectors [3]. Through the vertical legislative reforms, the EU will create “European Data Spaces” focused on specific sectors, such as healthcare, manufacturing, mobility, and energy. The EHDS is the first of the European Data Spaces to be formally proposed by the European Commission. Each of these legislative reforms are aimed at unlocking access to data—currently held in the hands of a few organizations—and making it available to a greater number of actors for re-use.

## Section: III. Results › 2. Overview

The EHDS Proposal is a lengthy and complex piece of proposed legislation [4]. An overview of the EHDS Proposal can be found in (Table 1). The EHDS Proposal creates a wide range of new rights and obligations in relation to access to and use of “electronic health data.” A chart setting out the defined terms in the EHDS Proposal can be found in Table 2. The key components of the EHDS Proposal are as follows.

Overview of the provisions in the EHDS Proposal

Key definitions in the EHDS Proposal

## Section: III. Results › 2. Overview › 1) Primary use

The EHDS Proposal creates new rights for patients over their electronic health data processed in the context of primary use of electronic health data [5]. The new rights granted to patients include the right to access, modify, and restrict access to electronic health data by healthcare professionals. The EHDS Proposal would also grant healthcare professionals access to electronic health data of their patients across EU member states, irrespective of the member state of affiliation and the member state of treatment. Patients are allowed to restrict access to certain electronic health data by their healthcare professionals on an “opt-out” basis.

## Section: III. Results › 2. Overview › 2) EHR systems

The EHDS Proposal establishes a pre-market conformity assessment requirement for Electronic Health Record systems (EHR systems) and a voluntary labeling scheme for wellness applications. The conformity assessment would evaluate whether the service meets certain mandatory requirements relating to fitness for purpose and interoperability [6].

## Section: III. Results › 2. Overview › 3) Secondary use

The EHDS Proposal introduces new obligations for “data holders” to provide electronic health data for secondary use by third parties. Access to electronic health data would be mediated through a data permit system run by government-designated health data access bodies. The rules for secondary use of electronic health data are the focus of this article.

## Section: III. Results › 3. Rules for Secondary Use of Electronic Health Data

Chapter IV of the EHDS Proposal sets out rules applicable to the “secondary use” of electronic health data. Under these rules, “data holders” must make a wide range of specified categories of electronic health data available for secondary use by third parties, called “data users.” The term “data holder” is broad enough to include hospitals, biobanks, research institutes, academic institutions, and commercial companies, such as pharmaceutical companies and medical device manufacturers. The EHDS Proposal is clear that electronic health data “entailing protected intellectual property and trade secrets from private enterprises shall be made available for secondary use” (our emphasis), although in such cases “all measures necessary to preserve the confidentiality of intellectual property (IP) rights and trade secrets shall be taken” (Art. 33(4)). A full list of the types of electronic health data that data holders would be required to share pursuant to these rules can be found in Table 3.

To access the data for secondary use, any “natural or legal person may submit a data access application” to the health data access body “for the purposes referred to in Article 34” (Art. 45(1)). These purposes include, among others, “scientific research related to health or care sectors,” “development and innovation activities for products or services contributing to public health or social security, or ensuring high levels of quality and safety of health care, of medicinal products or of medical devices,” and “training, testing and evaluating of algorithms, including in medical devices, AI systems and digital health applications, contributing to the public health or social security, or ensuring high levels of quality and safety of health care, of medicinal products or of medical devices” (Art. 34(1)(e)–(g)). A full list of the allowed and prohibited purposes for which electronic health data can be re-used under the EHDS Proposal are set out in Table 4.

It is notable that these allowed purposes may include revenue-generating commercial purposes, such as product development. It is also notable that the data user is not restricted to being in a particular sector, or to being an academic or public institution. This means that commercial organizations, such as technology companies, pharmaceutical companies, and medical device manufacturers can all take advantage of the EHDS rules on secondary use to gain access to data held by third parties. Before granting a permit, health data access bodies must assess “if the application fulfills one of the purposes listed in Article 34(1) of this regulation, if the requested data is necessary for the purpose listed in the application and if the requirements in this chapter are fulfilled by the applicant” (Art. 46(1)). If the applicant meets these requirements, the health data access body is required to issue a data permit within 2 months. Once the data permit is issued, the health data access body will request the data holder to provide the data to the health data access body, which will then make it available in a secure processing environment.

Where the applicant seeks data only from a single data holder in a single member state, the data user may submit a data access application to the data holder directly (Art. 49(1)), without going through a health data access body. A direct data access application must include the same elements required for an application to a health data access body, and the data holder must consider the same criteria that health data access bodies consider when determining whether to issue a data access permit (Arts. 49(1)–(2)). Where the criteria are met, the data holder “may issue a data permit” (Art. 49(2)) and grant access to the requested data.

Flowcharts showing the process for making data access applications and granting data permits are presented in Figure 1.

Minimum categories of electronic data for secondary use

Allowed and prohibited purposes for secondary use of electronic health data under the EHDS Proposal

Flowcharts for secondary use in the EHDS Proposal. (A) For data access applications and data requests to multiple data holders in more than one member state. (B) For data access applications and data requests to a single data holder in one member state. HDAB: health data access body, EHDS: European Health Data Space, EHD: electronic health data.

## Section: III. Results › 4. Responses to the EHDS

In the EU, the EHDS has generally received positive feedback from the research community and some industry groups [7,8]. However, there are some aspects of the EHDS Proposal that have been called out as raising certain concerns. Some of these concerns are as follows.

## Section: III. Results › 4. Responses to the EHDS › 1) Intellectual property/trade secrets protections

The current text of the EHDS Proposal contains only vague, high-level references to protecting IP and trade secrets for data holders. Article 33(4) states that “all measures” must be taken to protect such rights, and that public bodies should take “all specific measures” to protect IP and trade secrets. Many industry players are calling for strengthened protections in this regard [9].

## Section: III. Results › 4. Responses to the EHDS › 2) Fees

Health data access bodies and data holders are allowed to charge a fee to data users for making electronic health data available for secondary use (Art. 42). This fee must be “transparent and proportionate to the cost of collecting and making electronic health data available for secondary use, objectively justified and shall not restrict competition” (Art. 42(4)). This means that although data holders may be able to recoup the costs of making data available to data users, they are unlikely to be able to generate profit—or in some cases recoup the full cost of investments required to collect the data—from data sharing under the EHDS framework. The EHDS data sharing scheme may also threaten the business models of existing for-profit data sharing frameworks already in operation.

## Section: III. Results › 4. Responses to the EHDS › 3) Medical confidentiality and ethics laws

Currently in the EU, medical confidentiality and ethics laws apply to patient health data. Concerns have been raised that the EHDS may challenge the differing traditions of member states regarding medical confidentiality and ethics relating to secondary use of data. This has led to the CPME (Standing Committee of European Doctors), an association representing European doctors, calling for granting patients the right to opt-out or opt-in to the collection and use of electronic health data for secondary use [10]. The CPME has also called for systematically involving ethics committees or review boards within the EHDS framework.

## Section: III. Results › 4. Responses to the EHDS › 4) Privacy and data protection law

The interplay between the EU’s General Data Protection Regulation (GDPR) and the EHDS is also unclear in places [11]. The GDPR will apply to personal data processed under the EHDS framework. However, the EHDS Proposal does not create a legal basis under the GDPR for data users to access (pseudonymized) personal data, even if they obtain a data access permit. Rather, data users are responsible for identifying such a legal basis under EU or member state law, meaning that data users must identify the legal basis that would apply under both Article 6 and 9 of the GDPR. Currently in the EU, different member states take different approaches to whether patient consent is required to use data for research (Article 9(2)(a)) or whether organizations may rely on the research exemption in Article 9(2)(j) and Article 89(1) [12]. The EHDS Proposal fails to harmonize the rules in this regard, leaving it open for the data user to identify the legal basis appropriate to the data processing in question. Without this harmonization, data users may in fact be limited in the types of data they will be able to access lawfully for secondary use.

## Section: IV. Discussion

The European Union has served as the model for Korea’s privacy and personal information policies. The EU’s GDPR has influenced Korea’s Personal Information Protection Act (PIPA) [13]. The first question that pops into anyone’s mind, thus, is whether Korea can implement a secondary use pathway similar to that in the EHDS Proposal. It is undeniable that putting health datasets held by private entities to secondary use has the potential to benefit society. That said, requiring privately held datasets to be made available for secondary use by third parties on a mandatory basis will likely meet significant legal challenges under Korean law.

The Korean constitution provides that the property rights of citizens must be protected and that the scope and limitations of property rights are to be set forth in a statute (Constitution, Art. 23, Para. 1). The constitution also provides that commandeering, using, or limiting a citizen’s property out of public necessity must have legal basis in a statute and be justly compensated (Constitution, Art. 23, Para. 3). The concept of trade secrets is defined broadly as information, including a production method, sale method, useful technical or business information for business activities, which is not known publicly, is managed as a secret, and has independent economic value (Unfair Competition Prevention and Trade Secret Protection Act, Art. 2, Para. 2). This means that proprietary datasets will likely constitute a trade secret, a type of property protected by the constitution [14].

Even if proprietary datasets constitute trade secrets or otherwise protected property under the constitution, one can argue that the takings clause under the Korean constitution will permit mandatory sharing of proprietary datasets for secondary use, provided that the legislature passes a law allowing it with just compensation [15]. Besides, unlike tangible properties that can be used by only a single party at a time, intangible properties, such as datasets, do not necessarily diminish in value when used by multiple parties. However, it is not clear whether the “public necessity” component of the takings clause will be met if secondary use includes research and development activities with a commercial aim. In recent years, Korean authorities have rarely granted compulsory licenses on the grounds of public necessity, although the relevant IP law allows this if just compensation is also granted [16].

This does not mean that creating a “health data space” of some kind in Korea would be impossible altogether. Many publicly held health datasets are already available for secondary use, mostly for research or public health endeavors (Table 5). Korea could conceivably create a “health data space” that includes health datasets that have been created with research grants from the government. The current government research funding regulation bestows the property rights to all byproducts of research to the research institution or the individual researcher (National Research and Development Innovation Act [NRDIA], Art. 16, Paras 1 and 2), in a manner similar to the US Bayh-Dole Act [17]. This property rights scheme was a utilitarian contrivance, after government ownership of IP created from government-funded research had failed to see active downstream development [18]. By the same utilitarian token, permitting wider access to datasets created by government-funded research may bring about even more downstream use of the datasets than proprietary control by a single entity. There are three hurdles that need to be overcome to implement wider access to health datasets generated by government-funded research: legal basis for mandatory sharing of health datasets, privacy of research participants, and IP rights embedded in datasets.

The NRDIA would be the natural place to provide a legal basis to require sharing of scientific data, including health data, created during government-funded research. The current NRDIA conceptualizes a “data management plan” as a part of research proposals, which should include the researcher’s plan to generate, store, maintain and share scientific data created by government-funded research [19]. However, a data management plan is required only selectively at the discretion of the funding ministry. The first step in widening access to health data for secondary research is to make data sharing the rule in publicly funded research, rather than the exception, as is the case in some jurisdictions [20].

For health data, the privacy of the data subjects represented in the datasets will add to the legal complexity of mandatory sharing of health datasets for secondary use by third parties. In this regard, the government must provide guidance as to how health data may be made available for secondary research without compromising the privacy of research participants. The United States’ National Institutes of Health offers a good example [21]. The “scientific research exemptions” under the PIPA as amended in 2020 provides some insights too [22]. The research exemptions under the PIPA allow pseudonymized personal data to be used for statistical purposes, scientific research purposes, and archiving purposes in the public interest—without the consent of the data subject (PIPA Art. 28-2). This provision is similar to GDPR Article 9(2)(j) and Article 89(1), although the issue in the EU is one of fragmentation of how this provision is interpreted by different member states [23]. While the constitutionality of the scientific research exemptions has not yet been tested, designing a Korean “health data space” along similar lines of the scientific research exemptions will at least find precedential support in the PIPA [24].

Safeguarding IP rights embedded in or arising from the datasets will also be a critical issue. The EHDS Proposal reads “(e)lectronic health data entailing protected IP and trade secrets from private enterprises shall be made available for secondary use. Where such data is made available for secondary use, all measures necessary to preserve the confidentiality of IP rights and trade secrets shall be taken” (EHDS Proposal, Art. 33.4; similar provisions are found in Arts. 34.4 and 37.1). The proposed text is not clear on what “all measures necessary” would entail, and how any disputes that will surely arise between the parties about the appropriate measures to take would be resolved. It will be interesting to watch how the EU solves the puzzle [25]. Interestingly, the European Commission’s Data Act Proposal contains more detailed provisions relating to dispute resolution in this regard, and we may see this being reflected in future iterations of the EHDS Proposal. The same issue will have to be overcome as well if Korea were to adopt the authors’ suggestion of making datasets from government-funded research available to the public for secondary use. Regardless of whether datasets are made available to the public or not, some IP rights may have to remain proprietary to the research organization or the individual researcher in order to make downstream development feasible, especially in the life sciences industry where IP rights become key assets [26].

In conclusion, the EHDS Proposal is a reminder that facilitating secondary research by widening access to health data, whether held by the public sector or the private sector, will add value to society. It is a policy that Korea should consider in the long run. If a similar piece of legislation is not feasible in the short term in Korea, mandatory sharing of scientific data, including health data, generated by government-funded research will be a feasible and beneficial alternative.

Representative types of big data available for health research in Korea

## Section: Acknowledgments

This work was supported by the Ministry of Education of the Republic of Korea and the National Research Foundation of Korea (No. NRF-2021S1A5A2A01066230).


---

# Structural modeling of antibody variable regions using deep learning-progress and perspectives on drug discovery

- **Authors:** Igor Jaszczyszyn, Weronika Bielska, Tomasz Gawlowski, Pawel Dudzic, Tadeusz Satława, Jarosław Kończak, Wiktoria Wilman, Bartosz Janusz, Sonia Wróbel, Dawid Chomicz, Jacob D Galson, Jinwoo Leem, Sebastian Kelm, Konrad Krawczyk
- **Issuer:** Frontiers in molecular biosciences
- **Type:** Scientific article
- **Published:** 2023-07-07
- **Language:** en
- **DOI:** 10.3389/fmolb.2023.1214424
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37484529/
- **Licence:** CC-BY

## Page 1 (Section: Structural modeling of antibody variable regions using deep learning—progress and perspectives on drug discovery)

Structural modeling of antibody
variable regions using deep
learning—progress and
perspectives on drug discovery
Igor Jaszczyszyn1,2†, Weronika Bielska1,3†, Tomasz Gawlowski1,
Pawel Dudzic1, Tadeusz Satława1, Jarosław Kończak1,
Wiktoria Wilman 1, Bartosz Janusz1, Sonia Wróbel1,
Dawid Chomicz1, Jacob D. Galson4, Jinwoo Leem4,
Sebastian Kelm5 and Konrad Krawczyk1*
1NaturalAntibody, Kraków, Poland, 2Medical University of Warsaw, Warsaw, Poland, 3Medical University of
Lodz, Lodz, Poland, 4Alchemab Therapeutics Ltd., London, United Kingdom, 5UCB, Slough,
United Kingdom
AlphaFold2 has hallmarked a generational improvement in protein structure
prediction.
In
particular,
advances
in
antibody
structure
prediction
have
provided
a
highly
translatable
impact
on
drug
discovery.
Though
AlphaFold2 laid the groundwork for all proteins, antibody-speciﬁc applications
require adjustments tailored to these molecules, which has resulted in a handful of
deep learning antibody structure predictors. Herein, we review the recent
advances in antibody structure prediction and relate them to their role in
advancing biologics discovery.
KEYWORDS
deep learning, structural modeling, drug discovery, antibody therapeutics, antibody
structure prediction
1 Introduction
Antibodies are the largest class of biotherapeutics, with more than 100 approved
molecules (Kaplon et al., 2023). The antibody drug market is rapidly growing, and it is
predicted to reach approximately $300 billion by 2025 (Lu et al., 2020). As a result, there is
much interest in streamlining antibody discovery methods by tapping into recent
computational advances in deep learning.
One of the most striking computational advances has taken place in structure prediction,
with the development of tools such as AlphaFold2 (Jumper et al., 2021). For antibodies, the
determination of the proper antibody structure is key to many downstream drug discovery
tasks, such as developability annotation (Raybould et al., 2019) or antibody–antigen docking
(Krawczyk et al., 2014; Schneider et al., 2021). Though AlphaFold2 works well for general
proteins, it falls short on the speciﬁc case of antibodies (Ruffolo et al., 2022a; Abanades et al.,
2022b; Cohen et al., 2022), prompting the development of antibody-speciﬁc modeling
protocols.
In this review, we describe the methods which contribute to the improvement of
computational structure modeling for antibodies and provide context to the role they
play in designing antibody-based therapeutics.
OPEN ACCESS
EDITED BY
Traian Sulea,
National Research Council Canada
(NRC), Canada
REVIEWED BY
Monica Lisa Fernández-Quintero,
University of Innsbruck, Austria
Andreas Evers,
Merck, Germany
*CORRESPONDENCE
Konrad Krawczyk,
konrad@naturalantibody.com
†These authors have contributed equally
to this work and share ﬁrst authorship
RECEIVED 29 April 2023
ACCEPTED 12 June 2023
PUBLISHED 07 July 2023
CITATION
Jaszczyszyn I, Bielska W, Gawlowski T,
Dudzic P, Satława T, Kończak J,
Wilman W, Janusz B, Wróbel S,
Chomicz D, Galson JD, Leem J, Kelm S
and Krawczyk K (2023), Structural
modeling of antibody variable regions
using deep learning—progress and
perspectives on drug discovery.
Front. Mol. Biosci. 10:1214424.
doi: 10.3389/fmolb.2023.1214424
COPYRIGHT
© 2023 Jaszczyszyn, Bielska, Gawlowski,
Dudzic, Satława, Kończak, Wilman,
Janusz, Wróbel, Chomicz, Galson, Leem,
Kelm and Krawczyk. This is an open-
access article distributed under the terms
of the Creative Commons Attribution
License (CC BY). The use, distribution or
reproduction in other forums is
permitted, provided the original author(s)
and the copyright owner(s) are credited
and that the original publication in this
journal is cited, in accordance with
accepted academic practice. No use,
distribution or reproduction is permitted
which does not comply with these terms.
Frontiers in Molecular Biosciences
frontiersin.org
01
TYPE Mini Review
PUBLISHED 07 July 2023
DOI 10.3389/fmolb.2023.1214424

## Page 2 (Section: 2 Antibody structure in the context of 3D modeling)

2 Antibody structure in the context of
3D modeling
Antibody structure prediction is primarily focused on the
variable domains of the heavy chain (Vh) and the light chain (Vl)
(Figure 1A). Each domain is relatively small, comprising
~110 residues each. There are two major hurdles within the
overall antibody structure prediction problem: determining the
relative orientation of the two domains (Figure 1B) and
predicting
the
complementarity-determining
region
(CDR)
loop
structures.
The
two
domains
can
be
juxtaposed
differently, which affects the overall shape of the antibody
binding site. For this reason, orientating the multimer of the
heavy and light chains is crucial (Dunbar et al., 2013; Bujotzek
et al., 2015).
The CDR prediction problem can be further subdivided into
classifying the “canonical” CDRs (CDR-L1, CDR-L2, CDR-L3,
CDRH1, and CDR-H2) or modeling the CDR-H3. The canonical
CDRs have reasonably conserved folds (Nowak et al., 2016; Kelow
et al., 2022) (Figure 1C). The latter problem is arguably the most
difﬁcult and critical, as the CDR-H3 is the most variable (Figure 1D),
and also plays the major role in binding (Marks and Deane, 2017; Regep
et al., 2017; Ruffolo et al., 2020; Abanades et al., 2022a).
There is a diversity of methods to approach any of these sub-
problems individually, or predicting the entire multimeric gamut of
variable domains. However, attention is often focused around CDR-
H3 prediction accuracy given its central role in binding and
function.
Compilation
of
the
available
antibody
structure
prediction methods that leverage recent advances in machine
learning are listed in Table 1.
3 Current machine learning methods
tackling antibody structure prediction
3.1 What data fuel the models?
Antibody-based
deep learning methods
require antibody
structures
for
training
and
validation
which
are
typically
downloaded from the Protein Data Bank (PDB). At the time of
writing, there were approximately 7,000 redundant antibody
structures. Although this sample of the antibody sequence space
represents a small subset of all possible antibody molecules (>1015),
it can still be used to model most naturally occurring antibodies
(Krawczyk et al., 2018).
Databases such as AbDb (Ferdous and Martin, 2018) and
SAbDab (Dunbar et al., 2014) curate such antibody-speciﬁc
information. Most of the antibody structure prediction tools use
these two resources that facilitate the creation of training, validation,
and test datasets.
3.2 How is the antibody model quality
assessed?
In the original AlphaFold2 work and CASP competition in
general, the structural accuracy is calculated using GDT_TS
(Kryshtafovych et al., 2021). This score is a measure of structural
alignment between the model and native structure that is capable of
indicating fold similarities. All antibodies are already of the same
fold and one needs to account for differences in single loops (e.g.,
CDR-H3), where the RMSD is more suitable.
FIGURE 1
Speciﬁcs of the antibody structure in the context of modeling. (A) Variable region in the context of the entire antibody structure. The antibody
binding site is located in the variable region composed of the variable heavy (Vh) and variable light (Vl) polypeptide chains associated with the constant
portions (HC/LC). (B) Heavy/light chain orientation. The orientation of the Vh and Vl is not constant, and differing angles can affect the shape of the
binding site. (C) Canonical structures of CDRs. Most of the binding residues (the paratope) are found in the complementarity-determining regions
(CDRs). There are three CDRs on each of the heavy and light chains. All the CDRs except the CDR-H3 cluster into a set of “canonical shapes” depending on
residues in key positions. (D) Heterogeneity of CDR-H3. CDR-H3 is not only the most variable of the regions but also usually the most important for
antigen binding.
Frontiers in Molecular Biosciences
frontiersin.org
02
Jaszczyszyn et al.
10.3389/fmolb.2023.1214424

## Page 3 (Section: 2 Antibody structure in the context of 3D modeling)

TABLE 1 Compilation of the available antibody structure prediction methods that leverage recent advances in machine learning. For each method, we describe the
general goal (e.g., CDR prediction or whole variable region prediction), the accuracy of the most difﬁcult region, the CDR-H3, its code/server availability, and the
source paper. Please note that the CDR-H3 root mean square deviations (RMSDs) are not directly comparable as they could have been obtained from a different
test set and are sometimes calculated in a different fashion, e.g., based on Cα or main chain heavy atom positions. As a baseline and reference point, we also
include the AlphaFold2 predictions since many methods report values with respect to that method.
Method
Problem
addressed
Model
characteristic
CDR-H3 prediction
accuracy
Corresponding
AlphaFold2 accuracy
Availability
Source
DeepH3
CDR
prediction
Residual neural network
2.2 Å backbone atoms are used
N/a
https://github.com/
Graylab/deepH3-
distances-orientations
Ruffolo et al.
(2020)
Quaternion and
Euler angle
combined
method
CDR
prediction
Graph neural network
SAbDab benchmark: 2.29 Å
N/a
N/a
Son et al.
(2022)
ABlooper
CDR
prediction
Graph neural network
based
RosettaAntibody benchmark:
2.49 Å; SAbDab latest
structures: 2.72 Å. Backbone
atoms were used
RosettaAntibody benchmark:
2.87 Å
https://github.com/
oxpig/ABlooper
Abanades
et al. (2022a)
DeepSCAb
Antibody side
chain
prediction
Residual neural network
Not applicable (side chain
prediction)
N/a
https://github.com/
Graylab/DeepSCAb
Akpinaroglu
et al. (2022)
NanoNet
Heavy chain
prediction
Residual network
RosettaAntibody benchmark:
2.38 Å; Nanobodies: 3.16 Å.
Backbone atoms were used
Nanobodies: 2.88 Å
https://github.com/
dina-lab3D/NanoNet
Cohen et al.
(2022)
AbodyBuilder2
Variable region
prediction
Based on
AlphaFold2 structural
module
AbodyBuilder2 benchmark:
2.81 Å. Backbone atoms were
used
AbodyBuilder2 benchmark:
2.90 Å
https://github.com/
oxpig/
ImmuneBuilder
Abanades
et al. (2022b)
EquiFold
Variable region
prediction
SE(3)-equivariant neural
network
IgFold benchmark: 2.86 Å (only
N, Cα, C, and O RMSD)
IgFold benchmark: 3.02 Å
https://github.com/
Genentech/equifold
Lee et al.
(2022)
tfold-Ab
Variable region
prediction
Based on AlphaFold2,
using language models in
the place of Evoformer
IgFold benchmark: 2.74 Å;
SAbDab-22H1-Ab benchmark:
3.03 Å. Backbone atoms were
used
IgFold benchmark: 3.02 Å;
SAbDab-22H1-Ab
benchmark: 3.18 Å
https://
drug.ai.tencent.com/
en
Wu et al.
(2022)
xTrimoABfold
Variable region
prediction
Based on AlphaFold2,
using language models in
place of Evoformer
1.25 Å (Cα only)
1.47 Å
N/a
Wang et al.
(2022)
IgFold
Variable region
prediction
Graph transformer using
language model
AntiBERTy
IgFold benchmark: 2.99 Å
(backbone heavy atoms)
IgFold benchmark: 3.02Å
https://github.com/
Graylab/IgFold
Ruffolo et al.
(2022a)
AbFold
Variable region
prediction
Based on AlphaFold2
AbFold benchmark: 3.04 Å,
(backbone heavy atoms)
AbFold benchmark: 3.14 Å
(backbone heavy atoms)
N/a
Peng et al.
(2023)
AbBERT-
HMPN
Sequence and
structure
generation
Deep graph neural
network employing
language models with
generative capabilities
2.38 Å backbone atoms were
used
N/a
N/a
Gao et al.
(2022)
ReﬁneGNN
CDR
prediction and
design
Graph neural network
with generative
capabilities
2.50 Å (Cα only)
N/a
https://github.com/
wengong-jin/
ReﬁneGNN
Jin et al.
(2021)
AbDockGen
CDR-H3
prediction,
design, and
antigen
docking
Graph neural network-
based with generative
capabilities
Not applicable (docking scores
reported)
N/a
https://github.com/
wengong-jin/
abdockgen
Jin et al.
(2022)
DiffAb
Antibody
sequence and
the structure
design
Diffusion method
Test set of 19 complexes: 3.246
Å (Cα only)
N/a
https://github.com/
luost26/diffab
Luo et al.
(2022)
DeepAb
Variable region
prediction
Residual neural network
RosettaAntibody benchmark:
2.33 Å; therapeutics: 2.52 Å.
Backbone heavy atoms were
used
N/a
https://github.com/
RosettaCommons/
DeepAb
Ruffolo et al.
(2022b)
Frontiers in Molecular Biosciences
frontiersin.org
03
Jaszczyszyn et al.
10.3389/fmolb.2023.1214424

## Page 4 (Section: 3.3 What methods and techniques are used for modeling individual antibody loops and individual chains?)

Methods that attempt the modeling of the entire variable region
report the entire chain RMSD, further dividing it into the individual
CDR RMSDs. Nevertheless, here, the gains in structure prediction
accuracy are typically small as such predictions are already of very
good quality, excluding the CDR-H3.
Since the CDR-H3 is the most difﬁcult to predict, it is the
benchmark point of reference for accuracy across different models.
Methods typically report the RMSD of the prediction versus the
native structure. RMSD can be calculated using two different
approaches.
Typically,
RMSD
is
calculated
based
on
the
backbone atoms (N, C, CA, and O) or C-alpha (Cα) carbons
only, with the latter always being lower. RMSD can also be
calculated after aligning the entire variable region or only after
aligning the CDR-H3 atoms. The latter method leads to a slightly
lower reported RMSD, as it causes bias in the structural alignment
for a better ﬁt.
3.3 What methods and techniques are used
for modeling individual antibody loops and
individual chains?
Due to the importance of the CDR-H3 loop, many methods
focus exclusively on modeling this region. For instance, DeepH3 and
ABlooper were designed for CDR-H3 loop prediction, rather than
addressing the entire variable region. DeepH3 is based on a residual
network architecture that receives one-hot encoding of the sequence
to be predicted as input. In terms of residual network size, it is much
smaller than RaptorX (Källberg et al., 2012) on which it is based (6
1D + 60 2D) with only 3 1D + 25 2D blocks. It operates by predicting
discretized inter-residue distances (assigning distances into equally
spaced intervals) and orientation angles which are employed for full
structure reconstruction by RosettaAntibody. In contrast, ABlooper
is based on equivariant graph neural networks [E(G)NNs], which
are equivariant to translations and rotations in 3D space (Satorras
et al., 2021). ABlooper allows for coordinate uncertainty estimation
by calculating the agreement between ﬁve independently trained
neural network models. The chief advantage of ABlooper is speed, as
it can produce hundreds of structures within seconds as opposed to
previously available homology modeling methods that required
around a minute.
Beyond
CDR-H3-focused
predictions,
one
needs
to
contextualize this loop to the rest of the heavy chain. One of the
early machine learning models that could perform whole chain
predictions is NanoNet. Originally designed as a predictor of single-
chain antibodies (Deszyński et al., 2022), it can also predict heavy
chains of canonical antibodies. Similar to DeepH3, it is a residual
neural
network
(ResNet)
that
relies
on
one-dimensional
convolutions to map sequence elements to three-dimensional
coordinates. Unlike DeepH3, which operates on invariant features
(residue distances and orientation angles), NanoNet operates on a
single frame of reference by aligning all PDB heavy chains to a single
reference structure. Owing to this, the predictions of the NanoNet
are 3D coordinates, not requiring further translation into the
structure as is the case with invariant features. In the context of
the entire heavy chain prediction, authors report 2.38 Å accuracy for
CDR-H3 (solutions in the region of 1 Å can be considered near-
native). Similar to ABlooper, NanoNet is rapid, allowing for
predicting thousands of structures in a matter of seconds.
However, the predicted structures are often of bad physical
quality [e.g., atomic clashes,
D-amino acids, etc. (Fernández-
Quintero et al., 2023)], requiring reﬁnement.
3.4 What architectures and techniques are
currently used to predict the entire antibody
variable region structure?
Prediction of the entire variable region requires modeling and
multimeric assembly of both heavy and light chains. Herein,
DeepAb is a network that predicts discretized residue distances
and orientation angle bins that are then passed for structure
realization using Rosetta. The chief innovation of DeepAb is the
usage of a language model as an input to the network. Employing
embedding (internal efﬁcient representations of input antibody
sequences) for prediction offers an opportunity for the network
to perform prediction on more efﬁcient features extracted by the
language model. Furthermore, the network employs attention
mechanisms that allow tracking of which residues contribute to
each other’s predictive signal.
Residual neural networks provide limited ways to abstract
invariant three-dimensional information. Representing the entire
variable region structure as a graph (as was the case with ABlooper)
offers a solution to this problem. For instance, one can encode amino
acids as nodes (using features such as amino acid and position) and
draw edges between nodes/residues in proximity (e.g., within 8 Å
heavy atom distance). Graph neural networks (GNNs) have
increasingly gained popularity; this is hallmarked by ABlooper,
IgFold, and EquiFold. The authors of EquiFold employed a
coarse-grained representation for nodes to demonstrate its power
within the framework of a SE (3) (special Euclidean (3) group
ensuring
rotation
and
translation
equivariance)
equivariant
network. Ensuring geometric equivariance helps the network in
learning features that can be rotated and translated. A more abstract
representation using quaternions and Euler angles to encode the
amino acids as invariant representations and as an extension of
ReﬁneGNN
residues
has
been
shown
to
achieve
CDR-H3
predictions in the region of 2.5 Å. IgFold is another GNN-based
method that also employs embeddings from AntiBERTy, which is
trained on 500-m antibody sequences to supplement its prediction
of the entire variable region.
Three key components have contributed to the success of
AlphaFold2: the Evoformer, invariant point attention (IPA), and
recycling. First, AlphaFold2 infers spatial constraints between amino
acids by extracting evolutionary information embedded within
multiple
sequence
alignments
(MSAs)
using
its
Evoformer
module. In parallel, this information is fed into a structural
module that leverages IPA to predict coordinates. IPA is a novel
attention mechanism designed to be invariant to rotations and
translations
by
aligning
the
feature
vectors
based
on
the
geometric relationship between the residues without changing
their 3D positions. It has been shown that it improves the
accuracy of protein structure prediction by enabling the network
to better capture the complex spatial relationships between residues
in a protein. Finally, the whole workﬂow is repeated or “recycled”
three times to reﬁne the prediction.
Frontiers in Molecular Biosciences
frontiersin.org
04
Jaszczyszyn et al.
10.3389/fmolb.2023.1214424

## Page 5 (Section: 3.5 How do networks approach fine-structural details beyond the backbone?)

While AlphaFold2 was designed for predicting any arbitrary
protein sequence, its main components have inﬂuenced the
design of antibody-speciﬁc tools. There are variations in the
implementation
of
each
of
the
aforementioned
three
components. For example, IgFold uses separated weights for
each IPA layer and gradient propagation through rotations.
xTrimoFoldAb and tfold-Ab use language model embeddings
to replace the Evoformer, before applying the learned constraints
into
the
structural
module.
Other
methods,
such
as
ABodyBuilder2, demonstrated that one can use only the
structural
module
without
resorting
to
antibody-speciﬁc
embeddings or modiﬁed Evoformers. The antibody-focused
methods
are
more
accurate
than
AlphaFold2,
but
these
improvements are limited. One major advantage of antibody-
speciﬁc methods is their efﬁcient running time. For instance,
ABodyBuilder2 achieves predictions in a matter of seconds,
compared to tens of minutes for AlphaFold2. AlphaFold2’s
running time is comparatively long because of the MSA search
step, which is unnecessary for antibody-speciﬁc methods.
The loss function drives the training of a model as it penalizes
wrong predictions and rewards better ones. It is extremely
important as one of the chief innovations of AlphaFold2 was
the introduction of the frame aligned point error (FAPE) loss.
This component exposes the model to information related to
physicochemical constraints, such as proper chemical bond
distances and angles, as well as penalizing atom clashes and
other structural violations, and is also used in some of the
antibody-speciﬁc models. However, because of the skewed
difﬁculty in structure prediction, applying the same loss to
each antibody region is not an ideal approach. For instance,
xTrimoABFold employs focal loss focused on CDRs that are
more
difﬁcult
to
predict.
On
the
other
hand,
ABodyBuilder2 treats framework and CDR regions differently,
clamping framework regions at a FAPE loss of 30 Å and the
CDRs’ FAPE loss at 10 Å.
3.5 How do networks approach ﬁne-
structural details beyond the backbone?
Despite the progress in predictions, a seemingly trivial
problem faced by the networks is the physical plausibility of
the produced models (Fernández-Quintero et al., 2022). It was
observed in AlphaFold2 that the structure module can produce
predictions violating physical constraints, such as atomic
clashes. This is not only a problem of AlphaFold2-based
methods, and methods such as NanoNet and EquiFold are
also afﬂicted. Methods such as ABodyBuilder2 and IgFold
employed OpenMM and Rosetta, respectively, to reduce the
number of physical clashes in the model produced by a
neural network. The number of non-physical distances can
also
be
reduced
by
introducing
various
physical
constraints
at
the
training
time
(Eguchi
et
al.,
2022;
Kończak et al., 2022).
Although structure prediction is typically evaluated on its
ability to recapitulate the backbone, the determination of the side
chains is important for ﬁne-grained modeling of molecular
function,
such
as
binding
afﬁnity.
Methods
such
as
ABodyBuilder2 and IgFold produce the backbone structures
annotated with side chains. Other methods such as EquiFold
use a novel coarse-graining scheme where atoms are mapped to
coarse-grained “superatom” prior to structural modeling and
then
reverse-mapped
to
the
individual
atoms
once
the
backbone is constructed (Akpinaroglu et al., 2022). Other
methods such as NanoNet only produce the backbone. Side
chains are typically added by algorithms such as SCWRL
(Krivov et al., 2009) or PEARS (Leem et al., 2018), but
recently an antibody-speciﬁc side chain prediction mechanism
using
convolutional
neural
networks
has
been
introduced—DeepSCAb (Akpinaroglu et al., 2022). Altogether,
fast and accurate prediction of all-atom models is key to using the
antibody structures for practical drug discovery purposes.
4 Drug discovery perspective of
antibody structure prediction
Antibodies are a well-established drug format, with the structure
as a key component in aiding their discovery and development,
paving ground for real-world applications of 3D modeling.
Antibody structures provide rich information that can be used to
improve various prediction features, such as molecular recognition
(Oh et al., 2021), liability detection (Irudayanathan et al., 2022), or
developability screening (Jain et al., 2023). These models can
complement
wet-lab
antibody
discovery
methods,
such
as
immunization or phage display, to ultimately improve the
selection of binders. For instance, the identiﬁcation of antigen-
speciﬁc antibodies was typically tackled using clonotype/sequence
clustering methods. Machine learning has shown alternative ways to
group these molecules such as by embeddings from variational
autoencoders
(VAEs)
(Friedensohn
et
al.,
2020),
predicting
paratope
residues
(Richardson
et
al.,
2021),
or
clustering
structures
(Robinson
et
al.,
2021).
In
particular,
structural
clustering can provide a highly translational interpretation of
antibody binding. The methods described in this Review are
highly scalable, making it possible to group thousands of structures.
The optimization of biologics is the process of improving an
existing molecule, which already displays a variety of desirable
properties, with regard to a set of physicochemical properties.
Structural features can be employed to guide the optimization
process. A trivial example would be to focus existing liability
removal (e.g., deamidation) protocols on only surface-exposed
residues, which can be identiﬁed based on a reasonably accurate
three-dimensional model (Irudayanathan et al., 2022). Structural
features can be indicative of successful therapeutics (Raybould et al.,
2019; Ahmed et al., 2021), with some differences in the calculated
results based on the underlying modeling method (Jain et al., 2023).
In some cases, such as antibody–antigen docking, good quality
models are needed to reach the results achieved by docking
crystal structures (Schneider et al., 2021).
The most ambitious use of antibody structure prediction is for
the de novo antibody design, where the goal is to computationally
deﬁne an antibody sequence that can bind to a given target epitope.
One approach to the de novo design that relies on structural
predictions is “virtual screening,” a methodology that has been
practiced in small molecule drug discovery for decades but has
Frontiers in Molecular Biosciences
frontiersin.org
05
Jaszczyszyn et al.
10.3389/fmolb.2023.1214424

## Page 6 (Section: 5 Conclusion)

only been recently applied to antibodies. This can involve the
modeling of and selection from millions of antibody molecules,
which are then funneled into a molecular docking approach
(Schneider et al., 2021; Jin et al., 2022) or alternative binding site
design methods (Rangel et al., 2022). The quality of the models is a
key consideration as subtle changes in Vh/Vl arrangement,
backbone, or side chain orientation can affect the quality of the
predictions (Fernández-Quintero et al., 2022). In addition, any such
efforts hinge on linking the antibody structural predictions to
paratope–epitope interaction prediction. In this context, “zero-
shot” predictions require the models to propose sequences
binding a speciﬁc epitope without observing it, or any close
variants of it, in the training/test sets.
Another approach to the de novo design is using generative
methods. Herein, the latent space of the input (e.g., antibody
sequences) is learned, providing a way to sample novel
elements. Producing novel sequences based on transformer
models has already been shown in general proteins (Rives
et al., 2021) as well as in the antibody world (Melnyk et al.,
2021; Saka et al., 2021; Shin et al., 2021; Shuai et al., 2021).
Autoregressive methods such as IgLM (Shuai et al., 2021) offer
a way to generate new binder sequences based on millions of
sequences from natural repertoires. Such generation can also
be biased toward sequences with certain biophysical properties
by GANs (Amimeur et al., 2020). Most such methods, however,
are currently sequence-driven but not structure-driven.
Structure holds the potential to provide more information
than sequence alone (Kovaltsuk et al., 2017). Encoding the
structural space, in the form of torsional angles using VAEs,
has shown potential in generating novel 3D shapes (Eguchi et al.,
2022).
Leveraging
structural
information
for
generating
paratopes to speciﬁc antigens should produce better results
than using sequence alone (Jin et al., 2022). Higher quality
structural
models
have
the
potential
to
inform
better
structure-generation
methods,
leading
to
more
accurate
emulation
of
molecular
space
than
sequence
alone.
Embeddings
generated
by
the
inverse-folding
of
general
proteins have already shown potential to be useful for B-cell
epitope prediction (Hsu et al., 2022; Høie et al., 2023).
In the context of structure-conditioned generative methods,
ReﬁneGNN, AbDockGen, AbBERT-HMPN, and DiffAb go a step
further than the modeling methods described in this review. They
also provide a “compatibility” score for the structure and designed
sequence. ReﬁneGNN, AbDockGen, and AbBERT-HMPN are
based on the iterative reﬁnement of latent representations from
graph neural networks, whereas DiffAb samples via a denoising
diffusion model. The integration of structure prediction and
sequence design is the next intuitive step superseding structure
prediction, which holds the promise to enhance antibody-based
drug discovery.
5 Conclusion
Advances
in
protein
structure
prediction
have
practical
application in the discovery of new antibody drugs.
In general, accuracy increasing with respect to the pioneer in
ML-based accurate structure prediction, AlphaFold2, is noticeable,
but stay within an order of magnitude. Predictions of the CDR-H3
structure in particular appear to be “stuck” in the 2–3 Å heavy atom
backbone RMSD interval. Difﬁculty in the prediction of CDR-H3
conformation could stem from the loops’ ﬂexibility (Wong et al.,
2011; Fernández-Quintero et al., 2018; Jeliazkov et al., 2018) as well
as the possible inﬂuence of the Vh/Vl orientation (Marze et al., 2016;
Boucher et al., 2023). With only several thousand antibody
structures at hand (Dunbar et al., 2014), it is challenging to study
any ﬂexibility or allosteric effects, but perhaps with a larger number
of better quality cryo-EM structures we will increase the volume of
structural information available. Efforts in improving antibody
structure prediction might take the ﬂexibility into account by
scoring the CDR-H3 conformational ensemble rather than single
“best structure” produced.
The main advantage of the antibody-speciﬁc methods with
respect to AlphaFold2 is the speed. The antibody sequence
space in a single individual [~109–1011 (Briney et al., 2019)]
easily surpasses the human proteome (~20 k). The speed of
antibody modeling methods is of utmost importance, as it
directly translates to the mapping of the available antibody
sequence space (Kovaltsuk et al., 2018; Olsen et al., 2022),
antibody virtual screening (Schneider et al., 2021; Rangel
et al., 2022), and the development of novel generative models
(Eguchi et al., 2022).
Given the number of currently available antibody-speciﬁc
structure predictions, it might be suitable to take stock of the
state of the ﬁeld and devote efforts into benchmarking the
different methods as was the case with the two rounds of the
Antibody Modeling Assessment competition (Almagro et al.,
2011; Almagro et al., 2014). In the ﬁeld of antibody discovery
speciﬁcally, we could use the tools not only to test by a single
measure of RMSD but also to assess how useful the structural
predictions are for therapeutically minded tasks, such as lead
optimization, docking, epitope, or paratope prediction.
Altogether the accuracy, speed, and accessibility of the
current antibody modeling methods make it possible to apply
structural information to various aspects of biologics discovery
pipelines today. An incremental improvement to existing
discovery approaches using structure-guided computational
methods appears entirely feasible, while the ﬁeld continues to
move ever forward toward the “holy grail” of the true de novo
antibody design.
Author contributions
IJ, WB, and KK contributed to the conception and design of the
study. IJ and WB wrote the ﬁrst draft of the manuscript. IJ, WB, PD,
TS, JK, WW, BJ, SW, DC, JG, JL, SK, and KK wrote sections of the
manuscript. TG prepared the ﬁgures. All authors contributed to the
article and approved the submitted version.
Funding
This
work
was
co-ﬁnanced
by
the
European
Regional
Development
Fund
within
the
Smart
Growth
Operational
Programme 2014–2020 POIR.01.01.01-00-0962/21 (to KK).
Frontiers in Molecular Biosciences
frontiersin.org
06
Jaszczyszyn et al.
10.3389/fmolb.2023.1214424

## Page 7 (Section: Conflict of interest)

Conﬂict of interest
IJ, WB, TG, PD, TS, JK, WW, BJ, SW, DC, and KK are
employees of NaturalAntibody that develops data, software and
machine learning solutions for the therapeutic antibody industry. JG
and JL are employees of Alchemab. SK is an employee of UCB
Pharma.
Publisher’s note
All claims expressed in this article are solely those of the authors and
do not necessarily represent those of their afﬁliated organizations, or
those of the publisher, the editors, and the reviewers. Any product that
may be evaluated in this article, or claim that may be made by its
manufacturer, is not guaranteed or endorsed by the publisher.
References
Abanades, B., Georges, G., Alexander, B., and Deane, C. M. (2022a). ABlooper: Fast
accurate
antibody
CDR
loop
structure
prediction
with
accuracy
estimation.
Bioinformatics 38 (7), 1877–1880. doi:10.1093/bioinformatics/btac016
Abanades, B., Wong, W. K., Boyles, F., Georges, G., Alexander, B., and Charlotte, M.
D. (2022b). ImmuneBuilder: Deep-Learning models for predicting the structures of
immune proteins. Available at: https://www.biorxiv.org/content/10.1101/2022.11.04.
514231v1 (Accessed November 4, 2022).
Ahmed, L., Gupta, P., Martin, K. P., Scheer, J. M., Nixon, A. E., and Kumar, S. (2021).
Intrinsic physicochemical proﬁle of marketed antibody-based biotherapeutics. Proc.
Natl. Acad. Sci. 118 (37), 577118. doi:10.1073/pnas.2020577118
Akpinaroglu, D., Ruffolo, J. A., Mahajan, S. P., and Gray, J. J. (2022). Simultaneous
prediction of antibody backbone and side-chain conformations with deep learning. PloS
One 17 (6), 0258173. doi:10.1371/journal.pone.0258173
Almagro, J. C., Beavers, M. P., Hernandez-Guzman, F., Maier, J., Shaulsky, J.,
Butenhof, K., et al. (2011). Antibody modeling assessment. Proteins 79 (11),
3050–3066. doi:10.1002/prot.23130
Almagro, J. C., Teplyakov, A., Luo, J., Sweet, R. W., Kodangattil, S., Hernandez-
Guzman, F., et al. (2014). Second antibody modeling assessment (AMA-II). Proteins 82
(8), 1553–1562. doi:10.1002/prot.24567
Amimeur, T., Shaver, J. M., Ketchem, R. R., Taylor, J. A., Clark, R. H., Smith, J., et al.
(2020). Designing feature-controlled humanoid antibody discovery libraries using
generative adversarial networks. Available at: https://www.biorxiv.org/content/10.
1101/2020.04.12.024844v1 (Accessed April 13, 2020).
Boucher, L. E., Prinslow, E. G., Feldkamp, M., Yi, F., Nanjunda, R., Wu, S.-J., et al.
(2023). ‘Stapling’ scFv for multispeciﬁc biotherapeutics of superior properties. mAbs 15
(1), 2195517. doi:10.1080/19420862.2023.2195517
Briney, B., Inderbitzin, A., Joyce, C., and Burton, D. R. (2019). Commonality despite
exceptional diversity in the baseline human antibody repertoire. Nature 566 (7744),
393–397. doi:10.1038/s41586-019-0879-y
Bujotzek, A., Dunbar, J., Lipsmeier, F., Schäfer, W., Antes, I., Deane, C. M., et al.
(2015). Prediction of VH-vl domain orientation for antibody variable domain modeling.
Proteins 83 (4), 681–695. doi:10.1002/prot.24756
Cohen, T., Halfon, M., and Schneidman-Duhovny, D. (2022). NanoNet: Rapid and
accurate end-to-end nanobody modeling by deep learning. Front. Immunol. 13, 958584.
doi:10.3389/ﬁmmu.2022.958584
Deszyński, P., Młokosiewicz, J., Adam, V., Jaszczyszyn, I., Castellana, N., Bonissone,
S., et al. (2022). INDI—Integrated nanobody database for immunoinformatics. Nucleic
Acids Res. 50 (1), D1273–D1281. doi:10.1093/nar/gkab1021
Dunbar, J., Fuchs, A., Shi, J., and CharlotteDeane, M. (2013). ABangle: Characterising
the VH-VL orientation in antibodies. Protein Eng. Des. Sel. PEDS 26 (10), 611–620.
doi:10.1093/protein/gzt020
Dunbar, J., Krawczyk, K., Leem, J., Baker, T., Fuchs, A., Georges, G., et al. (2014).
SAbDab: The structural antibody database. Nucleic Acids Res. 42, D1140–D1146. doi:10.
1093/nar/gkt1043
Eguchi, R. R., Choe, C. A., and Huang, P.-S. (2022). Ig-VAE: Generative modeling of
protein structure by direct 3D coordinate generation. PLoS Comput. Biol. 18 (6),
1010271. doi:10.1371/journal.pcbi.1010271
Ferdous, S., and Martin, A. C. R. (2018). AbDb: Antibody structure database-a
database of PDB-derived antibody structures. Database J. Biol. Databases Curation
2018, bay040. doi:10.1093/database/bay040
Fernández-Quintero, M. L., Kokot, J., Waibl, F., Fischer, A. M., Quoika, P. K., Deane,
C. M., et al. (2023). Challenges in antibody structure prediction. mAbs 15 (1), 2175319.
doi:10.1080/19420862.2023.2175319
Fernández-Quintero, M. L., Kokot, J., Franz, W., Fischer, A.-L. M., Quoika, P. K.,
Deane, C. M., et al. (2022). Challenges in antibody structure prediction. Available at:
https://www.biorxiv.org/content/10.1101/2022.11.09.515600v1 (Accessed November 9,
2022).
Fernández-Quintero, M. L., Loefﬂer, J. R., Kraml, J., Kahler, U., Kamenik, A. S., and
Liedl, K. R. (2018). Characterizing the diversity of the CDR-H3 loop conformational
ensembles in relationship to antibody binding properties. Front. Immunol. 9, 3065.
doi:10.3389/ﬁmmu.2018.03065
Friedensohn, S., Neumeier, D., Khan, T. A., Csepregi, L., Parola, C., Arthur, R. G. D.
V., et al. (2020). Convergent selection in antibody repertoires is revealed by deep
learning. Available at:https://www.biorxiv.org/content/10.1101/2020.02.25.965673v1
(Accessed February 26, 2020).
Gao, K., Wu, L., Zhu, J., Peng, T., Xia, Y., Liang, H., et al. (2022). Incorporating pre-
training paradigm for antibody sequence-structure Co-design. Available at: https://
arxiv.org/abs/2211.08406 (Accessed October 26, 2022).
Høie, M. H., Gade, F. S., Johansen, J. M., Würtzen, C., Winther, O., Nielsen, M., et al.
(2023). DiscoTope-3.0 - improved B-cell epitope prediction using AlphaFold2 modeling
and inverse folding latent representations. Available at: https://www.biorxiv.org/
content/10.1101/2023.02.05.527174v1 (Accessed February 5, 2023).
Hsu, C., Verkuil, R., Liu, J., Lin, Z., Hie, B., Tom, S., et al. (2022). Learning inverse
folding from millions of predicted structures. Available at: https://www.biorxiv.org/
content/10.1101/2022.04.10.487779v1 (Accessed April 10, 2022).
Irudayanathan, F. J., Zarzar, J., Lin, J., and Izadi, S. (2022). Deciphering deamidation
and isomerization in therapeutic proteins: Effect of neighboring residue. mAbs 14 (1),
2143006. doi:10.1080/19420862.2022.2143006
Jain, T., Todd, B., and Vásquez, M. (2023). Identifying developability risks for clinical
progression of antibodies using high-throughput in vitro and in silico approaches. mAbs
15 (1), 2200540. doi:10.1080/19420862.2023.2200540
Jeliazkov, J. R., Sljoka, A., Kuroda, D., Tsuchimura, N., Katoh, N., Tsumoto, K., et al. (2018).
Repertoire analysis of antibody CDR-H3 loops suggests afﬁnity maturation does not typically
result in rigidiﬁcation. Front. Immunol. 9, 413. doi:10.3389/ﬁmmu.2018.00413
Jin, W., Barzilay, D. R., and Jaakkola, T. (2022). “Antibody-antigen docking and
design via hierarchical structure reﬁnement,” in Proceedings of the 39th International
Conference on Machine Learning, Baltimore, MA, July 17-23, 2022 (Proceedings of
Machine Learning Research. PMLR).
Jin, W., Wohlwend, J., Barzilay, R., and Jaakkola, T. (2021). Iterative reﬁnement graph
neural network for antibody sequence-structure Co-design. Available at: http://arxiv.
org/abs/2110.04624 (Accessed October 9, 2021).
Jumper, J., Evans, R., Alexander, P., Green, T., Figurnov, M., Ronneberger, O., et al.
(2021). Highly accurate protein structure prediction with AlphaFold. Nature 596
(7873), 583–589. doi:10.1038/s41586-021-03819-2
Källberg, M., Wang, H., Wang, S., Peng, J., Wang, Z., Lu, H., et al. (2012). Template-
based protein structure modeling using the RaptorX web server. Nat. Protoc. 7 (8),
1511–1522. doi:10.1038/nprot.2012.085
Kaplon, H., Crescioli, S., Visweswaraiah, J., and Reichert, J. M. (2023). Antibodies to
watch in 2023. mAbs 15 (1), 2153410. doi:10.1080/19420862.2022.2153410
Kelow, S., Faezov, B., Xu, Q., Parker, M., Adolf-Bryfogle, J., and Roland, L. D. (2022).
A penultimate classiﬁcation of canonical antibody CDR conformations. Available at:
https://www.biorxiv.org/content/10.1101/2022.10.12.511988v1 (Accessed October 16,
2022).
Kończak, J., Janusz, B., Młokosiewicz, J., Satława, T., Wróbel, S., Dudzic, P., et al.
(2022). Structural pre-training improves physical accuracy of antibody structure
prediction using deep learning. Available at: https://www.biorxiv.org/content/10.
1101/2022.12.06.519288v1 (Accessed December 9, 2022).
Kovaltsuk, A., Krawczyk, K., Galson, J. D., Kelly, D. F., Deane, C. M., and Trück, J.
(2017). How B-cell receptor repertoire sequencing can Be enriched with structural
antibody Data. Front. Immunol. 8, 1753. doi:10.3389/ﬁmmu.2017.01753
Kovaltsuk, A., Leem, J., Kelm, S., James, S., Deane, C. M., and Krawczyk, K. (2018).
Observed antibody space: A resource for Data mining next-generation sequencing of
antibody repertoires. J. Immunol. 201 (8), 2502–2509. doi:10.4049/jimmunol.1800708
Krawczyk, K., Kelm, S., Kovaltsuk, A., Galson, J. D., Kelly, D., Trück, J., et al. (2018).
Structurally mapping antibody repertoires. Front. Immunol. 9, 1698. doi:10.3389/
ﬁmmu.2018.01698
Krawczyk, K., Liu, X., Baker, T., Shi, J., and CharlotteDeane, M. (2014). Improving
B-cell epitope prediction and its application to global antibody-antigen docking.
Bioinformatics 30 (16), 2288–2294. doi:10.1093/bioinformatics/btu190
Krivov, G. G., Shapovalov, M. V., and Dunbrack, R. L., Jr. (2009). Improved
prediction of protein side-chain conformations with SCWRL4. Proteins 77 (4),
778–795. doi:10.1002/prot.22488
Frontiers in Molecular Biosciences
frontiersin.org
07
Jaszczyszyn et al.
10.3389/fmolb.2023.1214424

## Page 8 (Section: Conflict of interest)

Kryshtafovych, A., Schwede, T., Topf, M., Fidelis, K., and Moult, J. (2021). Critical
assessment of methods of protein structure prediction (CASP)-Round XIV. Proteins 89
(12), 1607–1617. doi:10.1002/prot.26237
Lee, J. H., Yadollahpour, P., Watkins, A., Frey, N. C., Leaver-Fay, A., Stephen, R., et al.
(2022). EquiFold: Protein structure prediction with a novel coarse-grained structure
representation. Available at: https://www.biorxiv.org/content/10.1101/2022.10.07.
511322v1 (Accessed October 8, 2022).
Leem, J., Georges, G., Shi, J., and CharlotteDeane, M. (2018). Antibody side chain
conformations are position-dependent. Proteins 86 (4), 383–392. doi:10.1002/prot.
25453
Lu, R.-M., Hwang, Y.-C., Liu, I -J., Lee, C.-C., Tsai, H. Z., Li, H. J., et al. (2020).
Development of therapeutic antibodies for the treatment of diseases. J. Biomed. Sci. 27
(1), 1. doi:10.1186/s12929-019-0592-z
Luo, S., Su, Y., Peng, X., Wang, S., Peng, J., and Ma, J. (2022). Antigen-speciﬁc
antibody design and optimization with diffusion-based generative models for protein
structures. Available at: https://www.biorxiv.org/content/10.1101/2022.07.10.499510v1
(Accessed July 11, 2022).
Marks, C., and Deane, C. M. (2017). Antibody H3 structure prediction. Comput.
Struct. Biotechnol. J. 15, 222–231. doi:10.1016/j.csbj.2017.01.010
Marze, N. A., Lyskov, S., and Gray, J. J. (2016). Improved prediction of antibody VL-
VH orientation. Protein Eng. Des. Sel. PEDS 29 (10), 409–418. doi:10.1093/protein/
gzw013
Melnyk, I., Das, P., Chenthamarakshan, V., and Lozano, A. (2021). Benchmarking
deep generative models for diverse antibody sequence design. Available at:http://
arxiv.org/abs/2111.06801 (Accessed November 12, 2021).
Nowak, J., Baker, T., Georges, G., Kelm, S., Klostermann, S., Shi, J., et al. (2016).
Length-independent structural similarities enrich the antibody CDR canonical class
model. mAbs 8, 751–760. doi:10.1080/19420862.2016.1158370
Oh, L., Dai, B., and Bailey-Kellogg, C. (2021). “A multi-resolution graph convolution
network for contiguous epitope prediction,” in Proceedings of the 12th ACM
Conference on Bioinformatics, Computational Biology, and Health Informatics BCB
’21 38, Chicago, IL, August 7-10, 2022 (Association for Computing Machinery).
Olsen, T. H., Boyles, F., and Deane, C. M. (2022). Observed antibody space: A diverse
database of cleaned, annotated, and translated unpaired and paired antibody sequences.
Protein Sci. A Publ. Protein Soc. 31 (1), 141–146. doi:10.1002/pro.4205
Peng, C., Wang, Z., Zhao, P., Ge, W., and Huang, C. (2023). AbFold - an AlphaFold
based transfer learning model for accurate antibody structure prediction. Available at:
https://www.biorxiv.org/content/10.1101/2023.04.20.537598v1
(Accessed
April
21,
2023).
Rangel Aguilar, M., Bedwell, A., Costanzi, E., Taylor, R. J., Russo, Rosaria, Bernardes,
G. J. L., et al. (2022). Fragment-based computational design of antibodies targeting
structured epitopes. Sci. Adv. 8 (45), eabp9540. doi:10.1126/sciadv.abp9540
Raybould, M. I. J., Marks, C., Krawczyk, K., Taddese, B., Nowak, J., Claire, M., et al.
(2019). Five computational developability guidelines for therapeutic antibody proﬁling.
Proc. Natl. Acad. Sci. U. S. A. 116 (10), 4025–4030. doi:10.1073/pnas.1810576116
Regep, C., Georges, G., Shi, J., Popovic, B., and Charlotte, M. D. (2017). The H3 loop
of antibodies shows unique structural characteristics. Proteins 85 (7), 1311–1318. doi:10.
1002/prot.25291
Richardson, E., Galson, J. D., Paul, K., Kelly, D. F., Anne Palser, S. E. S., Watson, S.,
et al. (2021). A computational method for immune repertoire mining that identiﬁes
novel binders from different clonotypes, demonstrated by identifying anti-pertussis
toxoid antibodies. mAbs 13 (1), 1869406. doi:10.1080/19420862.2020.1869406
Rives, A., Meier, J., Tom, S., Goyal, S., Lin, Z., Liu, J., et al. (2021). Biological structure
and function emerge from scaling unsupervised learning to 250 million protein
sequences. Proc. Natl. Acad. Sci. U. S. A. 118 (15), 239118. doi:10.1073/pnas.2016239118
Robinson, S. A., Raybould, M. I. J., Schneider, C., Wong, W. K., Marks, C., and Deane,
C. M. (2021). Epitope proﬁling using computational structural modelling demonstrated
on coronavirus-binding antibodies. PLoS Comput. Biol. 17 (12), 1009675. doi:10.1371/
journal.pcbi.1009675
Ruffolo, J. A., Chu, L.-S., Mahajan, S. P., and Gray, J. J. (2022a). Fast, accurate
antibody structure prediction from deep learning on massive set of natural antibodies.
Available at: https://www.biorxiv.org/content/10.1101/2022.04.20.488972v1 (Accessed
April 21, 2022).
Ruffolo, J. A., Guerra, C., Mahajan, S. P., Sulam, J., and Gray, J. J. (2020). Geometric
potentials from deep learning improve prediction of CDR H3 loop structures.
Bioinformatics 36 (1), i268–i275. doi:10.1093/bioinformatics/btaa457
Ruffolo, J. A., Sulam, J., and Gray, J. J. (2022b). Antibody structure prediction using
interpretable deep learning. Patterns (New York, N.Y.) 3 (2), 100406. doi:10.1016/j.
patter.2021.100406
Saka, K., Kakuzaki, T., Metsugi, S., Kashiwagi, D., Yoshida, K., Wada, M., et al. (2021).
Antibody design using LSTM based deep generative model from phage display library
for afﬁnity maturation. Sci. Rep. 11 (1), 5852. doi:10.1038/s41598-021-85274-7
Satorras, V. G., Hoogeboom, E., and Welling, M. (2021). “E(n) equivariant graph
neural networks,” in Proceedings of the 38th International Conference on Machine
Learning, July 18-24, 2021 (Proceedings of Machine Learning Research. PMLR).
Schneider, C., Buchanan, A., Taddese, B., and CharlotteDeane, M. (2021). DLAB-
deep
learning
methods
for
structure-based
virtual
screening
of
antibodies.
Bioinformatics 38, 377–383. doi:10.1093/bioinformatics/btab660
Shin, J.-E., Riesselman, A. J., Kollasch, A. W., McMahon, C., Simon, E., Sander, C.,
et al. (2021). Protein design and variant prediction using autoregressive generative
models. Nat. Commun. 12 (1), 2403–2411. doi:10.1038/s41467-021-22732-w
Shuai, R. W., Ruffolo, J. A., and Gray, J. J. (2021). Generative Language modeling for
antibody design. Available at: https://www.biorxiv.org/content/10.1101/2021.12.13.
472419v2 (Accessed December 20, 2022).
Son, Y.-H., Shin, D.-H., Han, J.-W., Won, S.-H., and Kam, T.-E. (2022). “GNN-based
antibody
structure
prediction
using
quaternion
and
euler
angle
combined
representation,”
in
2022
IEEE
International
Conference
on
Consumer
Electronics-Asia (ICCE-Asia), Yeosu, South Korea, October 26-28, 2022, 1–4.
Wang, Y., Gong, X., Li, S., Yang, B., Sun, Y., Shi, C., et al. (2022). xTrimoABFold: De
novo antibody structure prediction without MSA. Available at: http://arxiv.org/abs/
2212.00735 (Accessed November 30, 2022).
Wong, S. E., Sellers, B. D., and Jacobson, M. P. (2011). Effects of somatic mutations on CDR
loop ﬂexibility during afﬁnity maturation. Proteins 79 (3), 821–829. doi:10.1002/prot.22920
Wu, J., Wu, F., Jiang, B., Liu, W., and Zhao, P. (2022). tFold-Ab: Fast and accurate
antibody structure prediction without sequence homologs. Available at: https://www.
biorxiv.org/content/10.1101/2022.11.10.515918v1 (Accessed November 13, 2022).
Frontiers in Molecular Biosciences
frontiersin.org
08
Jaszczyszyn et al.
10.3389/fmolb.2023.1214424


---

# Structure-based drug design with geometric deep learning

- **Authors:** Clemens Isert, Kenneth Atz, Gisbert Schneider
- **Issuer:** Current opinion in structural biology
- **Type:** Scientific article
- **Published:** 2023-02-24
- **Language:** en
- **DOI:** 10.1016/j.sbi.2023.102548
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36842415/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Structure-based drug design uses three-dimensional geometric information of macromolecules, such as proteins or nucleic acids, to identify suitable ligands. Geometric deep learning, an emerging concept of neural-network-based machine learning, has been applied to macromolecular structures. This review provides an overview of the recent applications of geometric deep learning in bioorganic and medicinal chemistry, highlighting its potential for structure-based drug discovery and design. Emphasis is placed on molecular property prediction, ligand binding site and pose prediction, and structure-based de novo molecular design. The current challenges and opportunities are highlighted, and a forecast of the future of geometric deep learning for drug discovery is presented.
