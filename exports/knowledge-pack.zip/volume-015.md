# Generalizability of machine learning methods in detecting adverse drug events from clinical narratives in electronic medical records

- **Authors:** Md Muntasir Zitu, Shijun Zhang, Dwight H Owen, Chienwei Chiang, Lang Li
- **Issuer:** Frontiers in pharmacology
- **Type:** Scientific article
- **Published:** 2023-07-12
- **Language:** en
- **DOI:** 10.3389/fphar.2023.1218679
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37502211/
- **Licence:** CC-BY

## Section: Abstract

AbstractWe assessed the generalizability of machine learning methods using natural language processing (NLP) techniques to detect adverse drug events (ADEs) from clinical narratives in electronic medical records (EMRs). We constructed a new corpus correlating drugs with adverse drug events using 1,394 clinical notes of 47 randomly selected patients who received immune checkpoint inhibitors (ICIs) from 2011 to 2018 at The Ohio State University James Cancer Hospital, annotating 189 drug-ADE relations in single sentences within the medical records. We also used data from Harvard’s publicly available 2018 National Clinical Challenge (n2c2), which includes 505 discharge summaries with annotations of 1,355 single-sentence drug-ADE relations. We applied classical machine learning (support vector machine (SVM)), deep learning (convolutional neural network (CNN) and bidirectional long short-term memory (BiLSTM)), and state-of-the-art transformer-based (bidirectional encoder representations from transformers (BERT) and ClinicalBERT) methods trained and tested in the two different corpora and compared performance among them to detect drug–ADE relationships. ClinicalBERT detected drug–ADE relationships better than the other methods when trained using our dataset and tested in n2c2 (ClinicalBERT F-score, 0.78; other methods, F-scores, 0.61–0.73) and when trained using the n2c2 dataset and tested in ours (ClinicalBERT F-score, 0.74; other methods, F-scores, 0.55–0.72). Comparison among several machine learning methods demonstrated the superior performance and, therefore, the greatest generalizability of findings of ClinicalBERT for the detection of drug–ADE relations from clinical narratives in electronic medical records. Keywords: adverse drug events, electronic health records, machine learning, natural language processing, relation extraction

## Section: 1 Introduction

Adverse drug events (ADEs) are unintended harmful effects of taking medication (Hohl et al., 2018), which is a leading cause of death in the United States (Classen et al., 1997; Binkheder et al., 2022) and responsible for the hospitalization of 9,440,757 patients from 2008 to 2011, with an increasing trend over time (Poudel et al., 2017). The estimated annual cost of drug-related morbidity and mortality resulting from non-optimized medication therapy was $528.4 billion, equivalent to 16% of total US healthcare expenditures, in 2016 (Watanabe et al., 2018). Patients with ADEs have demonstrated significantly longer hospital stays and an almost two-fold greater risk of death than patients without ADEs (Classen et al., 1997). Nevertheless, ADEs are mostly preventable (Rommers et al., 2007), and early detection can substantially reduce morbidity and, thereby, decrease associated healthcare costs (Classen et al., 1997; Kaushal et al., 2006; Handler et al., 2007).

ADEs are largely detected after marketing, so timely surveillance at this time is important for patient safety (Botsis et al., 2011; Polepalli Ramesh et al., 2014). Pharmacovigilance has traditionally employed spontaneous reporting systems (SRSs), but as many as 90% of ADEs may remain unreported in this voluntary scheme (Hazell and Shakir, 2006). In contrast, electronic health records (EHR) represent a potentially great source for post-marketing surveillance of drug safety, accommodating real-time clinical data gathered from routine clinical care (Coloma et al., 2013). One study revealed relevant ADE information, for example, in the structured data of 9,020 of 31,531 patients (28.6%) with side effects of statin documented in provider notes (Skentzos et al., 2011). Furthermore, clinical notes in EHRs provide longitudinal information related to drug-induced adverse events, but the manual review and extraction of ADEs from enormous clinical narratives is labor intensive, and clinical notes in EHRs vary from patient to patient, physician to physician, and hospital to hospital. Therefore, an automated system that utilizes artificial intelligence (AI) is needed to extract ADEs from clinical notes, and attempts have been made to build such a system.

The Medication and Adverse Drug Events Challenge (MADE1.0) (Jagannatha et al., 2019) aimed to automatically identify clinical concepts and relations from clinical narratives that included ADEs. The Challenge included three tasks: 1) naming the recognized entity (NER) and identifying the medication and its route, dosage, duration, frequency, and indication, as well as associated ADEs and their severity; 2) identifying relations (RI) of medications with ADEs, indications, and other entities; and 3) performing the NER and RI tasks jointly. The Challenge released 1,089 fully de-identified clinical notes from 21 randomly selected patients with cancer at the University of Massachusetts Memorial Hospital that included 2,612 drug–ADE relations. Methods used to classify relations ranged from statistical machine learning (ML)-based methods, such as support vector machine learning (SVM), random forest, and others, to neural-network-based bidirectional long short-term memory (BiLSTM). The best-performing model for the classification of ADE–drug name relations achieved an F-score of 0.72.

Another effort, the n2c2 Shared Task Challenge (Henry et al., 2020), mirrored MADE1.0 and included similar tasks. The n2c2 dataset comprised 505 discharge summaries taken from the Medical Information Mart for Intensive Care-III (MIMIC-III) clinical care database (Johnson et al., 2016). Records were selected by searching ADEs in the International Classification of Diseases (ICD) code descriptions of the records, which yielded a total of 1,840 ADE-drug relations. Methods used for the relation-classification task ranged from SVM to attention-based BiLSTM, with the best-performing model for ADE-drug name relation yielding an F-score of 0.85.

The use of data from a single EHR source in the two challenges allowed NLP approaches developed from these models to be data-specific. The model that performed the best (Wei et al., 2020) in relation extraction for the n2c2 Shared Task, for example, contained a post-processing technique that was dependent on the n2c2 annotation guideline to improve the performance of their BiLSTM conditional random field (CRF) algorithm. This n2c2 paper (Wei et al., 2020) also suggested that language models like BERT (Devlin et al., 2018) in the biomedical domain may further improve the NLP performance, and it remains to be an interesting topic for future research. In the best-performing model (Chapman et al., 2019) from the MADE 1.0 Challenge, the best model was random forest. The paper (Chapman et al., 2019) stated that generalizability of the best-performing model was unclear.

Though transformer-based methods like BERT (Devlin et al., 2018), BioBERT (Lee et al., 2020), and ClinicalBERT (Alsentzer et al., 2019) have become popular in recent years, they have not been applied to identify ADEs from the clinical notes of EHRs. Therefore, it is critical to implement the same model on data from different data sources to assess the generalizability of a model. No study has been conducted yet that used EHRs from different data sources to address the issue of generalizability. BERT-based methods have performed better than other machine and deep learning methods (Sun et al., 2019; González-Carvajal and Garrido-Merchán, 2020; Minaee et al., 2022) in mining biomedical texts, and methods that integrate biomedical corpora, such as ClinicalBERT, outperformed BERT models (Huang et al., 2019). In this article, we investigate the performance of deep learning (CNN, BiLSTM) and transformer-based (BERT and ClinicalBERT) methods, as well as classical SVM, in clinical notes of two different EHR systems.

The preprocessing of data is important in NLP in clinical text and challenged by the inherent variations in EHRs, and the preprocessing of clinical text in EHRs, such as tokenization, which breaks the text into meaningful elements and detects sentence boundaries, is different and more challenging than the processing of data in the literature (Griffis et al., 2016). Publications often inadequately present the end-to-end data preprocessing method, but in this paper, we sufficiently detail the end-to-end data preprocessing for all NLP methods used.

Our primary goal is to address whether and how ADE NLP algorithms developed from the n2c2 Shared Task can be generalized to a drug-specific ADE in a different EHR. There are two types of generalizability in the NLP algorithm development for detecting drug-induced ADEs. First, we want to know whether the NLP model developed in one dataset maintains a comparable performance in a different dataset. Second, if one NLP method has a better performance than the others, will it maintain its supreme performance in a different dataset? In this paper, we study both types of generalizability for NLP algorithms designed for drug–ADE relationship detection. We will use ADEs induced by immune checkpoint inhibitors (ICI) (Nashed et al., 2021) as recorded in clinical notes as examples for analysis. MADE1.0 (Jagannatha et al., 2019) data were not available to us when we conducted this study.

## Section: 2 Materials and methods

Annotation example for different entities in the ICI-OSU corpus.

ICI-OSU data processing pipeline. Python and C++ programming were used at different steps to automate the process.

List of drug names and adverse drug events. We used all possible mentions of these drugs and ADEs in our study.

(A) Input text processing from single-sentence drug–ADE relation. (B–F) Implementation details of (B) SVM, (C) BiLSTM, (D) CNN, (E) BERT, and (F) clinicalBERT models.

## Section: 2 Materials and methods › 2.1 Datasets

We used two datasets to analyze the generalizability of ADE detection from EHRs; one was developed from the EHR system of The Ohio State University James Cancer Hospital, and the second was that of the n2c2 Shared Task (Henry et al., 2020).

## Section: 2 Materials and methods › 2.2 ICI-OSU corpus

We built the ICI-OSU corpus by manually annotating 1,394 clinical notes of 47 randomly selected patients who received immune checkpoint inhibitors (ICIs) from 2011 to 2018 at The Ohio State University James Cancer Hospital. Supplementary materials contain a detailed annotation guideline that we developed to assist the annotators with manual annotation. Supplementary Table S1 contains the annotation guideline for entity annotation, whereas Supplementary Table S2 contains the guideline for relation annotation. Figure 1 shows different types of entity tags and relation annotations.

The entities included drug names, mentions of ADEs, dates drugs were taken, dates of ADEs, terms drawing causal relation between a drug and an ADE, and grades of ADE intensity. It is worth mentioning that reasons for drug administration were not considered as ADEs. Supplementary Figure S1 shows the difference between ADE and reason for drug administration with an example. Relations were annotated for entities located within a single sentence and across sentences. Two annotators with informatics skills and knowledge in cancer clinical trials independently annotated each note, and a third annotator performed the validation for inconsistent annotations between the two annotators. One annotator was a resident physician with hands-on experience with EHRs; the second had a master’s degree in biology with 7 years of experience in corpus development and annotation; the third annotator, who performed the validation, was a graduate student in biomedical informatics. The institutional review board of The Ohio State University approved this study (#2020C0145).

Annotation example for different entities in the ICI-OSU corpus.

## Section: 2 Materials and methods › 2.3 ICI-OSU data processing pipeline

Figure 2 illustrates the data processing pipeline we built that feeds processed data to the ADE NLP models for generalizability analysis.

In the first step, we collected the clinical notes of the targeted patient. The ICI-OSU corpus contains the patient’s notes for the first 12 months from the date of the first ICI dose in the structured data. The order of note dates is maintained to keep track of longitudinal data, such as the date of first drug use, date of first ADE, and date of drug discontinuation.

In the second step, we cleaned data using regular expression techniques (Wang et al., 2019), which included but were not limited to normalizing uneven spaces and drug names and manipulating abbreviations. For drug name normalization, we used the DrugBank database (Wishart et al., 2008) as our primary source, and we built a lookup table that contained all possible mentions (such as the generic and brand name) of a drug. Supplementary Figure S2 shows a raw original clinical note, and Supplementary Figure S3 shows the cleaned data.

In the third step, we performed automatic screening for drugs and ADEs, tagging predefined drug and ADE terms for follow-up manual annotation. Table 1 delineates the drug names and the ADE list of our study. We used the Common Terminology Criteria for Adverse Events (CTCAE) (Freites-Martinez et al., 2021) and the DrugBank database as our primary guidelines for ADE and drug mentions, respectively. Then, we built a lookup table for screening that contained all possible mentions of these drugs and ADEs found in EHRs. We discussed with a physician and annotators who had hands-on experience working with EHRs, thus enriching and verifying our lookup table to ensure accuracy.

In the fourth step, we used the Apache clinical Text Analysis and Knowledge Extraction System (cTAKES)™ (Savova et al., 2010), an open-source NLP tool, to segment sentences in the EHRs, which is one of the most challenging tasks because of variations, such as in use of punctuation and abbreviations, that are unique to the recorder (Griffis et al., 2016). To optimize cTAKES™ performance on sentence segmentation, we also encrypted the unexpected line breakers to be consistent with the cTAKES™ segmentation rules. After segmentation, we decrypted the data to preserve their originality. Supplementary Figure S4 shows the data’s appearance after sentence segmentation in cTAKES™.

In the fifth step, we performed automatic de-identification using de-identification software (Neamatullah et al., 2008) from PhysioNet (Goldberger et al., 2000) followed by manual de-identification by the annotators to ensure accuracy. The recall value of PhysioNet was over 98% in the de-identification task on our dataset. Supplementary Figure S5 shows the data after de-identification.

In the sixth step, we performed automatic tagging, annotating the drug name, mention of ADE, and date of ADE, to reduce the burden of subsequent manual annotation. For drug and ADE annotation, we performed exact matching of the data with our predefined drug and ADE lists. We used a rule-based method to annotate the dates in the clinical text automatically, and this annotation was consistent with that of the web-based brat rapid annotation tool (BRAT) (Stenetorp et al., 2012), which we used later for manual annotation. Though automatic annotation greatly reduced the burden of manual annotation, the annotators were free to annotate any new form of a drug name, mention of ADE, or date of ADE. The annotators could also correct anything incorrectly tagged in automatic tagging. Supplementary Figure S6 shows the automatically annotated notes.

In the seventh step, our annotators performed manual annotation in BRAT following the well-defined guideline mentioned previously and included in the supplementary materials. Supplementary Figure S7 shows the manually annotated notes.

In the eighth and final step, we extracted relevant annotation information automatically after manual annotation to build our corpus. Information extracted to prepare the data for machine learning models included drug–ADE relations, drug–ADE pairs, and neighboring words. We built an automatic system to extract that information from the annotated corpus based on the input format of the ML models. Due to the repetitive nature of EHRs, several drug–ADE relations were repeated when the text between a drug and an ADE, as well as the context, were exactly the same. We removed those duplicates in the automatic extraction.

ICI-OSU data processing pipeline. Python and C++ programming were used at different steps to automate the process.

List of drug names and adverse drug events. We used all possible mentions of these drugs and ADEs in our study.

## Section: 2 Materials and methods › 2.4 n2c2 Shared Task corpus

The n2c2 data consisted of information from 505 discharge summaries taken originally from the MIMIC-III clinical care database (Johnson et al., 2016). The data provider described their process as first searching for ADEs in the ICD code description of each record and then manually screening the records with at least one ADE and dividing the data into a training set comprising 303 annotated files and a testing set that included 202 files (Henry et al., 2020). The n2c2 data contained several clinical concepts and relations as well as drug and ADE annotations, and we performed preprocessing as described previously to prepare the data for the ML models, first cleaning the n2c2 data, then segmenting sentences using cTAKES™, and finally using our automatic system to extract relevant annotations.

## Section: 2 Materials and methods › 2.5 The definition of positive and negative drug–ADE relations in the n2c2 and ICI-OSU corpora

Like other researchers (Wei et al., 2020), we considered all possible combinations of drugs and ADEs to build positive and negative data for training and validating NLP models. Our generalizability analysis focused on drug–ADE relations within a single sentence; so, for example, for a sentence containing the drugs d1 and d2 and the ADEs a1 and a2, the four possible drug–ADE combinations are (d1, a1), (d1, a2), (d2, a1), and (d2, a2). A drug–ADE relation was considered positive if the drug induced the ADE. We collected the positive samples directly from annotation to build the positive dataset. A relation was considered negative if the drug did not induce the ADE and was, therefore, not annotated in the corpus. We derived the negative dataset from all the drug–ADE combinations by subtracting the annotated positive set from the corpus. After removing duplicates, we obtained 189 positive samples and 698 negative samples from our annotated ICI-OSU data. The default n2c2 training and test data yielded 1,355 positive and 865 negative samples after duplicates were removed.

## Section: 2 Materials and methods › 2.6 Machine learning deep learning models

We implemented several machine learning, deep learning, and transformer-based models, including SVM (Joachims, 1998), CNN (Kim, 2014), BiLSTM (Sherstinsky, 2018; Xu et al., 2019), BERT (Devlin et al., 2018), and ClinicalBERT (Alsentzer et al., 2019), to analyze the n2c2 and ICI-OSU datasets, and we trained these models on one dataset and validated them on the other to analyze the generalizability of their findings.

(A) Input text processing from single-sentence drug–ADE relation. (B–F) Implementation details of (B) SVM, (C) BiLSTM, (D) CNN, (E) BERT, and (F) clinicalBERT models.

## Section: 2 Materials and methods › 2.6 Machine learning deep learning models › 2.6.1 Training and validation data

Training and validation data were speculated under the intra- and inter-dataset settings. The intra-dataset setting comprised training and validation data allocated from the same data source, either n2c2 or ICI-OSU. When training and validating the model on the same n2c2 dataset in the intra-set setting, we used the default training and validation data of the n2c2 dataset given by the data providers. Because the ICU-OSU dataset was relatively smaller, we applied five-fold cross-validation to avoid overfitting when we trained and validated our model on the same ICU-OSU dataset in the intra-set setting. In the inter-set setting, training was performed on one dataset, and its validation was performed in the other. We also withheld 30 percent of the data from the training set to serve as the internal validation set in the inter-dataset setting.

## Section: 2 Materials and methods › 2.6 Machine learning deep learning models › 2.6.2 Hyperparameter selection and embedding

In the deep learning and transformer-based models, we studied different dropout rates ranging between 0.1 and 0.8 and learning rates (0.1, 0.01, 0.001, and 0.0001) with batch sizes of 16, 32, and 64. In those models, we used embedding (Mikolov et al., 2013) techniques and pre-trained word-embedding models, such as Stanford’s global vectors for word representation (GloVe) (300-dimensional) (Pennington et al., 2014). In our transformer-based model, we also incorporated biomedical domain knowledge.

## Section: 2 Materials and methods › 2.6 Machine learning deep learning models › 2.6.3 Preparation of input data, feature selection, and model implementation

We focused on the contextual features while building the models. Because the text between a drug and an ADE contains most of the contextual information regarding a drug–ADE relation, we considered the drug name, the ADE, and the text between them as the input for all models. However, feature selection varied from model to model. Our SVM model, for example, used character-level n-grams, whereas the CNN model considered n-grams at the token level. Figure 3A shows how we extracted the input text from a drug–ADE relation.

(A) Input text processing from single-sentence drug–ADE relation. (B–F) Implementation details of (B) SVM, (C) BiLSTM, (D) CNN, (E) BERT, and (F) clinicalBERT models.

## Section: 2 Materials and methods › 2.7 Implementation of the support vector machine model

We generated character n-grams from the first character of a sample to the last character of the input text using a range of values for n, converted those n-grams in term frequency (TF)-inverse document frequency (IDF) (Qaiser and Ali, 2018) vectorization, and then finally fed the feature vector into the model to predict the output y (0 or 1). We searched a range of values for c and gamma to obtain the best hyperparameter set and used the radial basis function (RBF) kernel in our SVM model. Figure 3B details the implementation of our SVM model with an example bigram.

## Section: 2 Materials and methods › 2.8 Bidirectional long short-term memory (BiLSTM)

Understanding the context of a sentence is critical and requires that classification of the sentence includes information in both directions, from the beginning of the sentence to its end and from its end to its beginning. Previous studies showed promising results using BiLSTM to extract contextual information (Xu et al., 2019). BiLSTM algorithms can learn long-term dependencies and work in both directions of text and learn contextual features in a given time stamp. For our model, the input was a sequence from the start to the end of an entity of a sample. Figure 3C shows the architecture of the BiLSTM model. We performed text vectorization on the input and then used the pre-trained word embedding of GloVe (300d) (Pennington et al., 2014) in the embedding layer. The BiLSTM layer was used over the embedding layer, and finally, the dense layer was used, producing the output, y.

## Section: 2 Materials and methods › 2.9 Convolutional neural network (CNN)

We implemented the standard CNN model (Kim, 2014), in which we focused on contextual information while extracting features. The CNN model applies a filter to extract features from text and uses those features to classify the text. As mentioned earlier, we used the text between the start of an entity and its end to analyze sequential words to learn features to extract. We used multiple filters of different sizes (2, 3, and 4) to examine different n-grams within the text. Figure 3D shows the architecture of the CNN model. We built a sentence matrix, with rows indicating the tokens of a sentence and columns indicating the features in which we implemented pre-trained word embedding. S n is the number of tokens in a sentence; S d is the feature dimension of a token; W h is the kernel size. We then applied weight filters for the convolution operation and feature mapping and, finally, applied max pooling and fully connected the output layer to generate output. We used the rectified linear unit (ReLU) activation function and the pre-trained word embedding of GloVe (300d) in the embedding layer (Pennington et al., 2014).

## Section: 2 Materials and methods › 2.10 Bidirectional encoder representations from transformers (BERT)

The BERT (Lee et al., 2020) model is based on a transformer encoder that uses a self-attention mechanism for sequence modeling (Vaswani et al., 2017). For our classification task, the sequential information of the text could be important. We selected a segment from the start to the end of an entity of a sample and then used the tokenized segment as input in the BERT model. The class token cls was added with the input. To obtain embeddings for our text, we used the pre-trained transformer model rather than an embedding layer. For our analysis, we used BERT-base, which consists of transformer blocks of 12 layers with 12 self-attention heads, a hidden size of 768, and 110 M trainable parameters (Lee et al., 2020). Figure 3E shows the architecture of the BERT model.

## Section: 2 Materials and methods › 2.11 ClinicalBERT

The implementation of the ClinicalBERT (Alsentzer et al., 2019) model was similar to that of our BERT model, but ClinicalBERT incorporated pre-trained biomedical domain knowledge. We used the model that was initialized on BioBERT (Lee et al., 2020) and trained on all notes of the MIMIC-III dataset (Johnson et al., 2016). The model had a batch size of 32 and a maximum sequence length of 128 (Alsentzer et al., 2019). Figure 3F shows the architecture of the ClinicalBERT model.

## Section: 3 Results

Annotation performance: we performed annotation in two rounds. In round one, we annotated 118 single-sentence positive drug–ADE relations and 24 cross-sentence positive drug–ADE relations. In round two, we labeled 163 single-sentence positive drug–ADE relations and 27 cross-sentence positive drug–ADE relations. Table 2 shows the average inter-annotator agreement (IAA) results of our two rounds of annotations. We calculated Cohen’s kappa (McHugh, 2012) to measure IAA. The results indicate considerable disagreement between the two annotators regarding the identification of drug–ADE relations, which is probably attributable to the diverse nature of ADE mentions in clinical notes. Supplementary Table S3 shows more annotation results and findings details of our corpus. Our OSU-ICI corpus is the first drug class-specific drug–ADE corpus. By specifically targeting ICIs, it also becomes a golden standard for developing immunotherapy-induced adverse event phenotypes.

Agreement between annotators.

Comparison of precision, recall, and F-score among different models in intra- and inter-dataset settings. (A, B) show the performance of the different machine learning models when trained and tested on the same data source (intra dataset). (C, D) show the performance of the different machine learning models when trained and tested on different data source (inter dataset).

Cluster maps of results comparing predicted labels with true labels for every sample of positive and negative classes in inter dataset settings. Yellow: predicted and true label matched; blue: labels did not match. (A, C) shows the results for positive class. (B, D) shows the results for negative class.

## Section: 3 Results › 3.1 Performance evaluation and error analysis

To analyze the generalizability of findings among the models, we trained and tested each model on the dataset of the same data source (intra-data) and a different source (inter-data). Figures 4A, B show the performance of the different models in the intra-dataset setting. The CNN-based deep learning model performed the best, with an F-score of 80% for the ICI-OSU dataset, whereas the transformer-based ClinicalBERT model achieved the best F-score (87%) for the n2c2 data. The SVM model was also competitive and showed stable performance in the intra-dataset setting. Our results demonstrate that we did not get the best performance from either the BERT or ClinicalBERT model when training and testing on the ICI-OSU dataset. This is probably because the transformer models usually perform better on a large dataset, and the ICI-OSU dataset is small. Figures 4C, D show the performance of the different models in the inter-dataset setting, with the transformer-based models showing superior performance. The ClinicalBERT model achieved the highest F-score in both combinations of inter-data training and testing, probably because of the incorporation of domain knowledge as ClinicalBERT was trained on the MIMIC-III dataset. These performances indicate the importance of incorporating domain knowledge in models. Figure 5 shows the cluster map for the results of different models in the inter-dataset setting. In this NLP analysis of four combinations of training sets and test sets from n2c2 and ICI-OSU datasets, it is evident that ClinicalBERT has the best performance in three out of four combinations.

Figures 5A, B show the cluster map while training on the n2c2 dataset and testing on the ICI-OSU dataset. The BERT and ClinicalBERT models performed similarly for positive sample prediction, whereas the SVM and BiLSTM models clustered together with similar results. BiLSTM and ClinicalBERT models performed similarly for negative sample prediction. Figures 5C, D show the cluster map while training on the ICI-OSU dataset and testing on the n2c2 dataset. The BERT and ClinicalBERT models performed similarly for both positive and negative sample prediction, and the SVM and BiLSTM models clustered together with similar results. Comparison of the results of Figures 4 and 5 demonstrates the better performances of the machine learning and deep learning models in the intra-dataset setting and of the transformer-based models in the inter-dataset settings. Along with the internal capacity of the models to recognize patterns, the variable length of the datasets might contribute to such performance. Supplementary Tables S4 and S5 further detail the results.

Comparison of precision, recall, and F-score among different models in intra- and inter-dataset settings. (A, B) show the performance of the different machine learning models when trained and tested on the same data source (intra dataset). (C, D) show the performance of the different machine learning models when trained and tested on different data source (inter dataset).

Cluster maps of results comparing predicted labels with true labels for every sample of positive and negative classes in inter dataset settings. Yellow: predicted and true label matched; blue: labels did not match. (A, C) shows the results for positive class. (B, D) shows the results for negative class.

## Section: 3 Results › 3.2 Factors contributing to error 1 (differences in data sources)

The n2c2 dataset was the more general of the two sets and looked for all drug mentions in a clinical note, whereas the ICI-OSU dataset focused on ICI drugs and annotated a specific set of ADEs. The use of these differing types of data challenged training on one source and testing on the other.

## Section: 3 Results › 3.3 Factors contributing to error 2 (differences in annotation guidelines and causal terms)

The annotation guidelines for the two datasets differed. The guideline for the n2c2 dataset, for example, looked for the closest entity rather than causation to draw a relation, whereas the guideline for the ICI-OSU dataset looked for the presence of causal terms to identify a causal relation between entities.

## Section: 4 Discussion › 4.1 Incorporation of domain knowledge

We attempted to analyze the generalizability of ADE detection from clinical notes using several machine learning, deep learning, and transformer-based models and observed promising performance, particularly when we applied state-of-the-art transformer-based models. The superior performance of ClinicalBERT indicated the importance of incorporating domain knowledge when using pre-trained data. Thus, future studies should incorporate more domain knowledge to further enhance the performance of the models.

## Section: 4 Discussion › 4.2 Cross-sentence relation

Our study focused on single-sentence drug–ADE relations, in which the drug and ADE occurred in the same sentence, and after sentence segmentation and annotation, we ended with only a few cross-sentence relations. However, it is also important to identify cross-sentence relations. Our primary challenge in identifying cross-sentence relations was the imbalance within a dataset that could pose a very large number of negative relations against a very small number of positive relations. In addition, our experience in manual annotation showed that a drug and ADE could be distantly related across sentences with numerous sentences in between. Nevertheless, limiting the number of sentences between two entities to draw a relation could help limit the search space to accommodate most of the positive relations across sentences. It would also keep the number of negative relations considerably low.

## Section: 4 Discussion › 4.3 Variation in sentence length

Variations in sentence lengths, some only a few words and some extraordinarily long, made it difficult to train the model and contributed greatly to the error. The ICI-OSU dataset included two positive samples consisting of 30 tokens each, where every single model except BERT classified them incorrectly. BERT was able to predict the true label of one of those two samples correctly. A lack of similar training data probably contributed to the error. Having more training data of similar length or building a separate rule-based approach could facilitate the management of extraordinarily long sentences.

## Section: Acknowledgments

We would like to acknowledge and thank Andrew Nashed for his support in this work.

## Section: Data availability statement

The datasets presented in this article are not readily available because the clinical notes of EHRs were used in this study. Therefore, data could not be published at this point. Requests to access the datasets should be directed to LL, Lang.Li@osumc.edu.

## Section: Ethics statement

The studies involving human participants were reviewed and approved by the institutional review board of The Ohio State University (#2020C0145). Written informed consent for participation was not required for this study in accordance with the national legislation and the institutional requirements.

## Section: Author contributions

MZ and LL were responsible for the overall study design and writing the manuscript. MZ and SZ performed the end-to-end annotation task from the definition of annotation guidelines to the validation of manual annotation. MZ performed the implementation task, which included data processing and modeling. DO provided, enriched, and validated the drug and ADE lists. CC provided logistic support and made the original data available for study with the environmental setup. LL supervised the overall study. All authors contributed to the article and approved the submitted version.

## Section: Conflict of interest

The authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.

## Section: Publisher’s note

All claims expressed in this article are solely those of the authors and do not necessarily represent those of their affiliated organizations, or those of the publisher, the editors, and the reviewers. Any product that may be evaluated in this article, or claim that may be made by its manufacturer, is not guaranteed or endorsed by the publisher.

## Section: Supplementary material

The supplementary material for this article can be found online at: https://www.frontiersin.org/articles/10.3389/fphar.2023.1218679/full#supplementary-material

Click here for additional data file.

## Section: Associated Data

Click here for additional data file.

## Section: Associated Data › Supplementary Materials

Click here for additional data file.

## Section: Associated Data › Data Availability Statement

The datasets presented in this article are not readily available because the clinical notes of EHRs were used in this study. Therefore, data could not be published at this point. Requests to access the datasets should be directed to LL, Lang.Li@osumc.edu.


---

# Generative Models Should at Least Be Able to Design Molecules That Dock Well: A New Benchmark

- **Authors:** Tobiasz Ciepliński, Tomasz Danel, Sabina Podlewska, Stanisław Jastrzȩbski
- **Issuer:** Journal of chemical information and modeling
- **Type:** Scientific article
- **Published:** 2023-05-24
- **Language:** en
- **DOI:** 10.1021/acs.jcim.2c01355
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37224003/
- **Licence:** CC-BY

## Section: Abstract

AbstractDesigning compounds with desired properties is a key element of the drug discovery process. However, measuring progress in the field has been challenging due to the lack of realistic retrospective benchmarks, and the large cost of prospective validation. To close this gap, we propose a benchmark based on docking, a widely used computational method for assessing molecule binding to a protein. Concretely, the goal is to generate drug-like molecules that are scored highly by SMINA, a popular docking software. We observe that various graph-based generative models fail to propose molecules with a high docking score when trained using a realistically sized training set. This suggests a limitation of the current incarnation of models for de novo drug design. Finally, we also include simpler tasks in the benchmark based on a simpler scoring function. We release the benchmark as an easy to use package available at https://github.com/cieplinski-tobiasz/smina-docking-benchmark. We hope that our benchmark will serve as a stepping stone toward the goal of automatically generating promising drug candidates.

## Section: Introduction

Designing compounds with some desired chemical properties is the central challenge in the drug discovery process.1,2De novo drug design is one of the most successful computational approaches that involves generating new potential ligands from scratch, which avoids enumerating explicitly the vast space of possible structures. Recently, deep learning has unlocked new progress in drug design. Promising results using deep generative models have been shown in generating soluble,3 bioactive,4 and drug-like5 molecules. The history of de novo compound design dates back to the 1980s.6 Since then, numerous other approaches emerged, from both ligand- and structure-based path.7,8 Despite existing cheminformatic approaches to new compounds generation, it was the introduction of machine learning (ML) into the field of the computer-aided drug design that revolutionized also the task of de novo ligand design. In recent years, the combination of ML with the information on the target is gaining significant popularity.

A key challenge in the field of drug design is the lack of realistic benchmarks.2 Ideally, the generated molecule by a de novo method should be tested in the wet lab for the desired property. In practice, typically, a proxy is used. For example, the octanol–water partition coefficient or bioactivity is predicted using a computational model.3,4 However, these models are often too simplistic.2 This is aptly summarized by Coley et al.10 who notice that the current generative model benchmarks fail to capture the complexity of real discovery problems. In contrast to drug design, more realistic benchmarks have been used in the design of photovoltaics11 or in the design of molecules with certain excitation energies,12 where a physical calculation was carried out both to train models and to evaluate generated compounds. A huge step toward unifying chemical benchmark was made by Huang et al.13 who introduced an open-source benchmark, Therapeutics Data Commons, and showed that current algorithms are yet not primed to solve all the key therapeutic challenges. Despite this, the recent advances in deep learning have already led to numerous successful applications in drug discovery projects.14

Recently, an increasing number of methods adopts molecular docking as a means of evaluation for generative models in drug design.15−17 More specifically, in computer-aided drug discovery pipelines, docking scores are often used to preliminarily assess proposed drug candidates before reaching for costly laboratory experiments.18−20 With an advent of geometric deep learning for molecular graphs, the structure-based generative models, often employing roto-translationally equivariant neural networks, began to develop rapidly.21−24 Many of these methods use molecular docking to guide the generative process, so the docking scores are the most natural way of the compound evaluation.

Our main contribution is a realistic benchmark for de novo drug design (Figure 1). We base our benchmark on docking, a popular computational method for predicting molecule binding to a protein. Concretely, the goal is to generate molecules that are scored highly by SMINA.25 We picked Koes et al.25 due to its popularity and being available under a free license. While we focus on de novo drug design, our methodology can be extended to evaluate retrospectively other approaches to designing molecules. Code to reproduce results and evaluate new models is available online at https://github.com/cieplinski-tobiasz/smina-docking-benchmark. Notably, our benchmark26 was already adopted by Nigam et al.27 to demonstrate the effectiveness of their genetic algorithm for molecular design.

Our second contribution is exposing the limitation of currently popular de novo drug design methods for generating bioactive molecules. When trained using a few thousands compounds, a typical training set size, the tested methods fail to generate highly active structures according to the docking software. The highest scoring molecules in most cases did not outperform the top 10% molecules found in either the ZINC database or the training set. This suggests we should exercise caution when applying them in drug discovery pipelines, where we seldom have a larger number of known ligands. We hope our benchmark will serve as a stepping stone to further improve these promising models.

The paper is organized as follows. We first discuss prior work and introduce our benchmark. Next, we use our benchmark to evaluate two popular models for de novo drug design. Finally, we analyze why the tested models fail on the most difficult version of the benchmark.

Visualization of the proposed docking-based benchmark for de novo drug design methods. First, the generative model is trained for a selected drug target and generates 250 ligand proposals. The model score is a combination of the mean docking score (or single docking score component, e.g., repulsion or hydrogen bonding) of the generated compounds and their diversity. As a reference value, we use the scores of the top K% of a random ZINC subset (depicted on the right side).

## Section: Docking-Based Benchmark

We begin by briefly discussing prior work and motivation. Next, we introduce our benchmark.

## Section: Docking-Based Benchmark › Why Do We Need Yet Another Benchmark?

Standardized benchmarks are critical to measure progress in any field. Development of large-scale benchmarks such as the ImageNet was critical for the recent developments in artificial intelligence.28,29 Many new methods for de novo drug design are conceived every year, which motivates the need for a systematic and efficient way to compare them.30

De novo drug design methods are typically evaluated using proxy tasks that circumvent the need to test the generated compounds experimentally.3,5,31−33 Optimizing the octanol–water partition coefficient (log P) is a common example. The log P coefficient is commonly computed using an atom-based method that involves summing contribution of individual atoms,5,34 which is available in the RDKit package.35 Due to the fact that it is easy to optimize the atom-based method by producing unrealistic molecules,36 a version that heuristically penalizes hard to synthesize compounds is used in practice.5 This example illustrates the need to develop more realistic ways to benchmark these methods. Another example is QED score,37 which is designed to capture the drug likeliness of a compound. Finally, some approaches use a model (e.g., a neural network) to predict bioactivity of the generated compounds.4 Similarly to log P, these two tasks are also possible to optimize while producing unrealistic molecules. This is aptly summarized in Coley et al.10 as

Interestingly, besides the aforementioned proxy tasks, more realistic proxy tasks are rarely used in the context of evaluating de novo drug design methods. This is in contrast to evaluation of generative models for generating photovoltaics11 or molecules with certain excitation energies.12 One notable exception is Aumentado-Armstrong38 who try to generate compounds that are active according to the DrugScore39 and then evaluate the generated compounds using rDock.40 This lack of the overall diversity and realism in the typically used evaluation methods motivates us to propose our benchmark, which uses molecular docking as a more realistic proxy task.

Arguably, docking-based scoring of compounds has serious limitations,41 and similarity-based models36 are often chosen in commercial projects over molecular docking.42 However, the idea of our benchmark is that docking, even if simplistic, proves to be challenging for generative models. Our setup aims to imitate real drug discovery scenarios by employing this simple docking proxy.

## Section: Docking-Based Benchmark › Docking-Based Benchmark

Our docking-based benchmark is defined by (1) docking software that computes for a generated compound its pose in the binding site, (2) a function that scores the pose, and (3) a training set of compounds with an already computed docking score.

The goal is to generate 250 molecules that achieve the maximum possible docking score. We find this number of compounds large enough to make the optimization of diversity nontrivial, but small enough to make testing feasible in practice (in terms of either computational resources or the cost of ordering compounds for wet lab experiments). For the sake of simplicity, we do not impose limits on the distance of the proposed compounds to the training set. Thus, a simple baseline is to return the training set. Finding similar compounds that have a higher docking score is already prohibitively challenging for current state-of-the-art methods. As the field progresses, our benchmark can be easily extended to account for the similarity between the generated compounds and the training set.

Finally, we would like to stress that the benchmark is not limited to de novo methods. The benchmark is applicable to any other approaches such as virtual screening. The only limitation required for a fair comparison is that docking is performed only on the supplied training set.

## Section: Docking-Based Benchmark › Instantiation

As a concrete instantiation of our docking-based benchmark, we use SMINA v. 2017.11.925 due to its widespread use and its being offered under a free license. To create the training set, we download from the ChEMBL43 database molecules tested against selected drug targets: 5-HT1B, 5-HT2B, ACM2, and CYP2D6. In the extended variant of our benchmark, we include four additional drug targets: ADRB1, MOR, A2A, and D2. For instance, the final 5-HT1B data set consists in 1,878 molecules, out of which 1,139 are active (Ki < 100 nM) and 739 are inactive molecules (Ki > 1,000 nM). Only molecules that dock successfully are retained. We list the resulting data set sizes in Table 1.

We dock each molecule using default settings in SMINA to a manually selected binding site coordinate. Protein structures were downloaded from the Protein Data Bank, cleaned and prepared for docking using Schrödinger modeling package. The resulting protein structures are provided in our code repository. We describe further details on the preparation of the data sets in the Supporting Information.

Starting from the above, we define the following three variants of the benchmark. In the first variant (Docking Score Function), the goal is to propose molecules that achieve the smallest Vinardo docking score44 (based on the Vina docking score45) used in the score_only mode of the SMINA package, defined as follows:

where all terms are computed based on the final docking pose. The first three terms measure the steric interaction between ligand and the protein. The fourth and the fifth terms look for hydrophobic and hydrogen bonds between the ligand and the protein. We include a detailed description of all the terms in the Supporting Information.

Next, we propose two simpler variants of the benchmark based on individual terms in the Vinardo scoring function. We select optimization targets that have clear interpretations: repulsion that minimizes clashes with protein and hydrogen bonding that maximizes interactions stabilizing the compound pose in the binding site. In the Repulsion task, the goal is to only minimize the repulsion component, which is defined as

where ddiff(a1, a2) is the distance between the atoms minus the sum of their van der Waals radii. The distance unit is Angstrom (10–10 m).

The third task, Hydrogen Bonding, is to maximize the non_dir_h_bond term:

To make the results more stable, we average the score over the top 5 best-scoring binding poses. Finally, to make the benchmark more realistic, we filter the generated compounds using the Lipinski rule and discard molecules with molecular weights lower than 100.

## Section: ZINC Baseline

The premise behind de novo drug discovery is that it enables access to structurally novel and potent molecules. To contextualize results in the benchmark, we included as the baseline sampling from the subset of ZINC database containing 9,204,719 molecules.46 We selected molecules having the following properties: 3D representation, standard reactivity, in-stock purchasability, ref pH, charges from −2 to +2 inclusive, and a used drug-like preferred subset. For each protein we have sampled a set of molecules from aforementioned ZINC subset of the protein’s training set size. In each task, we compare to the mean value of the top 50%, 10%, and 1% of scores.

t-SNE maps of compound fingerprints (ECFP) for each protein. Each point is a molecule, and the distances between points are proportional to the dissimilarity of compounds. The training set is marked with red dots, and the compounds generated by REINVENT by enhancing different optimization targets are colored in blue (Docking Score Function), orange (Hydrogen Bonding), and green (Repulsion).

## Section: ZINC Baseline › Diversity

To better understand the performance of each model, besides the mean score, we also evaluate the diversity of the proposed molecules. Concretely, we compute the mean Tanimoto distance between all pairs of molecules in the generated sample. We use the 1024-bit ECFP representation47 with radius 2. The diversity score is reported in the benchmark along with the docking score results. We observe that the optimized models narrow down to a less diverse subspace of compounds that are dissimilar to the training set. This can also be observed in the t-SNE plots of the generated compounds compared to the training set (Figure 2). In this figure, compounds are grouped together based on their structural similarity. The small focused clouds of compounds generated using different optimization targets always concentrate at one side of the map. This suggests that there is similar bias of the model independent of the optimization target, which can be the ChEMBL prior to the REINVENT model48 (described below as one of the compared generative models). The separation between the optimized compounds and the training set suggests that these are novel molecules (similar structures are rarely present in the training set). Besides that observation, we note that the generated compounds are less diverse, creating one dense blob instead of multiple clusters, where all compounds are similar to each other inside one optimization target.

t-SNE maps of compound fingerprints (ECFP) for each protein. Each point is a molecule, and the distances between points are proportional to the dissimilarity of compounds. The training set is marked with red dots, and the compounds generated by REINVENT by enhancing different optimization targets are colored in blue (Docking Score Function), orange (Hydrogen Bonding), and green (Repulsion).

## Section: ZINC Baseline › When Is a Task Solved?

In the experiments, we compare to two baselines: (i) random compounds from ZINC as the baseline and (ii) compounds from the training set. In each case we report the mean score, the top 10% of scores, and the top 1% of scores. We also report diversity of the results.

Roughly speaking, we consider a given optimization task solved by a generative model if the molecules generated by this model achieve a mean score that exceeds the score of top 1% compounds in the ZINC subset (the values provided in theResultssection), while achieving at least the same diversity as observed in the training set of activity data extracted from ChEMBL (also provided below for each protein). This criterion is necessarily arbitrary. It is inspired by a natural baseline—comparing against a random sample of several thousands of drug-like compounds from the ZINC database.

## Section: ZINC Baseline › Model Evaluation Workflow

Below, we summarize all the steps necessary to evaluate a generative model and compare it with our benchmark. A general overview of this workflow is depicted in Figure 1, and the step-by-step evaluation procedure is shared in our code repository in the Python notebook named getting-started.ipynb.

## Section: Results and Discussion

In this section, we evaluate three popular models for de novo drug design on our docking-based benchmark.

Best scoring molecules generated by REINVENT in each of the three tasks composing the benchmark.

Best scoring molecules generated by CVAE in each of the three tasks composing the benchmark. Missing compounds correspond to the failed optimizations.

Best scoring molecules generated by GVAE in each of the three tasks composing the benchmark. Missing compounds correspond to the failed optimizations.

Correlation between docking score and molecular weight. The training set is marked with red dots, and the compounds generated by REINVENT by enhancing different optimization targets are colored in blue (Docking Score Function), orange (Hydrogen Bonding), and green (Repulsion).

Correlation between docking score and the number of rotatable bonds. The training set is marked with red dots, and the compounds generated by REINVENT by enhancing different optimization targets are colored in blue (Docking Score Function), orange (Hydrogen Bonding), and green (Repulsion).

## Section: Results and Discussion › Models

We compare three popular models for de novo drug design. Chemical Variational Autoencoder (CVAE)49 applies Variational Autoencoder50 by representing molecules as strings of characters (using SMILES encoding). This approach was later extended by Grammar Variational Autoencoder (GVAE),3 which ensures that generated compounds are grammatically correct. The third model, REINVENT,48 is a recurrent neural network that generates SMILES strings. It is first trained in a supervised manner to produce correct drug-like compounds similar to the ChEMBL data set (prior). Next, it is trained using reinforcement learning to optimize docking scores, which are provided as a training reward.

We note that CVAE and GVAE were not designed for small sample sizes, so they may not fully exploit their potential in our benchmark since they are used out of context. On the other hand, it was shown that REINVENT is a representative method in terms of achieving high sample efficiency.51

## Section: Results and Discussion › Experimental Details

To generate active compounds, we follow an approach similar to the one in Jin et al.,5 disregarding the penalty for insufficient similarity. Analogous methods using the sparse Gaussian Process instead of a multilayer perceptron are also employed in Gómez-Bombarelli et al.49 and Kusner et al.3 The exact algorithm for training our generative models is described below.

First, we fine-tune a given generative model for 5 epochs on the training set ligands, starting from weights made available by the authors. All hyperparameters are set to default values used in Gómez-Bombarelli et al.49 and Kusner et al.3 Additionally, we use the provided scores to train a multilayer perceptron (MLP) to predict the optimization target (e.g., the SMINA scoring function) based on the latent space representation of the molecule.

For CVAE and GVAE, to generate compounds, we first take a random sample from the latent space by sampling from a Gaussian distribution with the standard deviation of 1 and the mean of 0. Starting from this point in the latent space, we take 50 gradient steps to optimize the output of the MLP. Based on this approach we generate 250 compounds from the model.

For the REINVENT model, we use pretrained weights on the ChEMBL database provided by Olivecrona et al.48 As there is no latent space in this model, we train a random forest model to predict the optimization target directly from the molecule structure. We use the ECFP fingerprint to encode the molecule.47 The reward is computed based on the random forest prediction multiplied by the QED score calculated using RDKit.

The key limitation of all the generative methods above is the use of an ML model, either an MLP or a random forest, to predict docking scores. This is an important design decision in this study. Our benchmark aims to simulate a setting in which a drug discovery campaign involves designing a small batch of compounds to be tested for biological activity based on prior biological data. This is different from searching for a highly docking compound, in which case a reasonable approach would be to compute docking scores for a large number of test compounds.

All other experimental details, including hyperparameter values used in the experiments, can be found in the appendix.

## Section: Results and Discussion › Optimization of Docking Objectives

Tables 2 and 3 summarize the results on all three tasks. Recall that we generally consider a given task solved if the generated molecules exceed the top 1% score found in the ZINC database, while achieving at least the same diversity as in the training set. Below we make several observations.

Best scoring molecules generated by REINVENT in each of the three tasks composing the benchmark.

Best scoring molecules generated by CVAE in each of the three tasks composing the benchmark. Missing compounds correspond to the failed optimizations.

Best scoring molecules generated by GVAE in each of the three tasks composing the benchmark. Missing compounds correspond to the failed optimizations.

Correlation between docking score and molecular weight. The training set is marked with red dots, and the compounds generated by REINVENT by enhancing different optimization targets are colored in blue (Docking Score Function), orange (Hydrogen Bonding), and green (Repulsion).

Correlation between docking score and the number of rotatable bonds. The training set is marked with red dots, and the compounds generated by REINVENT by enhancing different optimization targets are colored in blue (Docking Score Function), orange (Hydrogen Bonding), and green (Repulsion).

## Section: Results and Discussion › Optimization of Docking Objectives › Docking Score Function Task

The key task in the benchmark is Docking Score Function. We observe that CVAE and GVAE models fail to generate compounds that achieve a higher docking score compared to the mean docking score in the ZINC data set (−8.785 for 5-HT1B compared to −4.647 and −4.955 achieved by CVAE and GVAE, respectively). The REINVENT model achieves much better performance (−9.774 for 5-HT1B). However, while docking scores attained by the molecules generated by REINVENT generally outperform the mean docking in the ZINC data set and the training set, they fall short of outperforming the top 10% molecules found in ZINC (−9.894 for 5-HT1B, with the exception of ACM2). We also draw attention to the fact that the generated molecules by REINVENT are markedly less diverse than the diversity of the training set (0.506 mean Tanimoto distance compared to 0.787 in the training set).

These results suggest that generative models applied to de novo drug discovery might require substantial more data to generate well-binding compounds than is typically available for training. In the key Docking Score Function task, models generally fail to outperform the top 10% from the ZINC database. It should worry us that optimizing for the docking score, which seems to be a simpler optimization target than true biological binding affinity, is already challenging given realistically sized training sets (between 1,193 and 10,225 molecules).

## Section: Results and Discussion › Optimization of Docking Objectives › Repulsion Task

Interestingly, REINVENT performs significantly worse than GVAE and CVAE on the Repulsion task. All models fail to outperform the top 10% found in the ZINC data set. We observe markedly lower diversity of molecules generated by REINVENT compared to the training set.

## Section: Results and Discussion › Optimization of Docking Objectives › Hydrogen Bonding Task

The Hydrogen Bonding task is the simplest, and both GVAE and REINVENT generate molecules that almost match the top 1% molecules found in the ZINC database and the training set. We again observe relatively low diversity of molecules generated by REINVENT.

## Section: Results and Discussion › Optimization of Docking Objectives › Generated Molecules

Figure 3 shows the best scoring molecules generated by REINVENT. We observe that optimizing each objective promotes different structural motifs. For example, the best scoring molecules in the Repulsion task are small, which intuitively enables them to easily fit into the binding pocket, achieving lower repulsion values than the top 1% molecules in the training set.

Similarly, there are clear patterns visible in the top molecules of CVAE and GVAE (Figures 4 and 5). For example, CVAE generates macrocycles in the task of docking score optimization, while GVAE generates long chains with no cycles when optimizing the same objective. These models also create oxygen or nitrogen chains when optimizing Hydrogen Bonding, and very small molecules (often less than 3 heavy atoms) for the Repulsion task.

We noticed a moderately strong correlation between docking scores and the number of rotatable bonds or molecular weight. Figures 6 and 7 show that, with the increasing number of rotatable bonds or molecular weight, the docking scores improve. For the number of rotatable bonds, the generated compounds are well mixed with the training data marginal distribution. On the other hand, the distribution of generated compounds is shifted toward better docking scores and smaller molecular weights in the case of the weight-to-docking-score relation. In other words, molecules achieve better docking scores at the same molecular weight after the optimization. The correlations are weaker for CYP2D6, which may be caused by a bigger binding site of this enzyme. However, the last observation about molecular weights holds.

From the chemical point of view, REINVENT produced the most consistent ligands with the highest possibility of desired biological activity. When different optimization approaches are considered, the best results were produced during the docking score optimization. Nondir h-bond optimization produced compounds with sometimes a high number of moieties able to produce a hydrogen bond. In the repulsion task, the produced compounds are correct from the chemical point of view. The drug-likeliness of compounds produced by CVAE and GVAE is lower (although they still meet criteria included in the Lipiski Rule of Five), but they still can be used in the docking benchmark task. The poor quality of the generated compounds is not surprising, as this issue was previously observed for other unrestricted de novo generative models.36

Best scoring molecules generated by REINVENT in each of the three tasks composing the benchmark.

Best scoring molecules generated by CVAE in each of the three tasks composing the benchmark. Missing compounds correspond to the failed optimizations.

Best scoring molecules generated by GVAE in each of the three tasks composing the benchmark. Missing compounds correspond to the failed optimizations.

Correlation between docking score and molecular weight. The training set is marked with red dots, and the compounds generated by REINVENT by enhancing different optimization targets are colored in blue (Docking Score Function), orange (Hydrogen Bonding), and green (Repulsion).

Correlation between docking score and the number of rotatable bonds. The training set is marked with red dots, and the compounds generated by REINVENT by enhancing different optimization targets are colored in blue (Docking Score Function), orange (Hydrogen Bonding), and green (Repulsion).

## Section: Conclusion

As concluded by Coley et al.,10 “the current evaluations for generative models do not reflect the complexity of real discovery problems”. Motivated by this, we proposed a new, more realistic, benchmark tailored to de novo drug design, using docking score as the optimization target. Code to evaluate new models is available at https://github.com/cieplinski-tobiasz/smina-docking-benchmark.

Our results suggest that generative models applied to de novo drug discovery pipelines might require substantially more data to generate realistic compounds than is typically available for training. Despite using over 1,000 compounds for training (between 1,074 and 3,780), the best docking scores generally do not outperform the top 10% docking scores in the ZINC data set. The docking score is only a simple proxy of the actual binding affinity, and as such, it should worry us that it is already challenging to optimize.

On a more optimistic note, the tested models achieved much better performance on the simplest task in the benchmark, which is to optimize a single term in the SMINA scoring function involving the number of hydrogen bonds to the binding site. This suggests that producing compounds that optimize the docking score based on the provided data set is an attainable, albeit challenging, task. We hope our benchmark better reflects the complexity of real discovery problems and will serve as a stepping stone toward developing better de novo models for drug discovery.

## Section: Acknowledgments

The work of Tomasz Danel is supported by National Centre of Science (Poland) Grant No. 2020/37/N/ST6/02728. Stanisław Jastrzȩbski thanks FNP START stipend and IPUB project at Jagiellonian University for supporting this work.

## Section: Data Availability Statement

The data and code used in this project are available at https://github.com/cieplinski-tobiasz/smina-docking-benchmark.

## Section: Supporting Information Available

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acs.jcim.2c01355.

## Section: Text

The authors declare no competing financial interest.

## Section: Supplementary Material

ci2c01355_si_001.pdf

## Section: Associated Data

ci2c01355_si_001.pdf

## Section: Associated Data › Supplementary Materials

ci2c01355_si_001.pdf

## Section: Associated Data › Data Availability Statement

The data and code used in this project are available at https://github.com/cieplinski-tobiasz/smina-docking-benchmark.


---

# [Guidelines for clinical trial protocols for interventions involving artificial intelligence: the SPIRIT-AI extensionDiretrizes para protocolos de ensaios clínicos com intervenções que utilizam inteligência artificial: a extensão SPIRIT-AI]

- **Authors:** Samantha Cruz Rivera, Xiaoxuan Liu, An-Wen Chan, Alastair K Denniston, Melanie J Calvert, Grupo de Trabajo SPIRIT-AI y CONSORT-AI, Grupo Directivo SPIRIT-AI y CONSORT-AI, Grupo de Consenso SPIRIT-AI y CONSORT-AI
- **Issuer:** Revista panamericana de salud publica = Pan American journal of public health
- **Type:** Scientific article
- **Published:** 2023-12-08
- **DOI:** 10.26633/rpsp.2023.149
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38361499/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

ABSTRACTObjective.To determine if there was an association between intrapartum stillbirths and both traveled distance for delivery and delivery care accessibility, assessing periods before and during the COVID-19 pandemic.Methods.This is a population-based cohort study. Patients had birth occurring after the onset of labor; the primary outcome was intrapartum stillbirth. City of residence was classified according to the ratio between deliveries performed and total births among its residents; values lower than 0.1 indicated low delivery care accessibility. Travel distance was calculated using the Haversine formula. Education level, maternal age, and birth sex were included. In each period, relative risk was assessed by generalized linear model with Poisson variance.Results.There were 2 267 534 deliveries with birth occurring after the onset of labor. Most patients were between age 20 and 35 years, had between 8 and 11 years of education, and resided in cities with high delivery care accessibility. Low delivery care accessibility increased risk of intrapartum stillbirth in the pre-pandemic (relative risk [RR] 2.02; 95% CI [1.64, 2.47]; p < 0.01) and the pandemic period (RR 1.69; 95% CI [1.09, 2.55]; p = 0.015). This was independent of other risk-increasing factors, such as travel distance and fewer years of education.Conclusions.Low delivery care accessibility is associated with the risk of intrapartum stillbirths, and accessibility reduced during the pandemic. Delivery of patients by family physicians and midwives, as well as official communication channels between primary care physicians and specialists, could improve patient healthcare-seeking behavior.

## Section: Text

During pregnancy, the intrapartum period brings increased risk for both mother and fetus. The most severe complication is intrapartum perinatal death, which is the sum of neonatal deaths and stillbirths attributable to asphyxia (1). Both share similar precursors (2), albeit not identical, as accessibility and adequacy of delivery room resuscitation techniques impact neonatal deaths (1, 3).

Globally, more than 1 million stillbirths occur in the intrapartum period each year (2, 3). Precise rates vary substantially, as the definition of intrapartum death changes in low- and high-resource settings (3). Nevertheless, it has been demonstrated that stillbirth rates are higher in resource-poor countries (1, 4), and the percentage of those stillbirths attributable to asphyxia is higher in most socially vulnerable localities (4, 5).

Brazil has a stillbirth rate of 10.97 per 1 000 births, which sets it at an intermediate level when considering the rate of 34 per 1 000 births in Pakistan, while developed countries reach rates as low as 2 per 1 000 births (1, 4, 6). Depending on methodology and location, between 7.5% and 22% of such stillbirths would be attributable to intrapartum asphyxia (5, 7). In Brazil, stillbirth rates dropped between 1996 and 2010 (4) but have since become relatively stable (5). Both the rate of this reduction and the percentage of asphyxia-attributable intrapartum deaths are not homogeneous. Poorer regions display higher rates and slower rate reductions compared to richer regions (5).

Even within the State of São Paulo, asphyxia-related perinatal deaths are not homogenously distributed: those residing in the rural areas more often had birthweights of 2 500 grams or greater, as well as gestational age of 37 weeks or over, when compared to deaths of residents of the metropolitan area (7).

While significant focus has been dedicated to the role of medical care, it has been demonstrated that sociodemographic and economic factors substantially impact the patient’s healthcare-seeking behavior and ability to reach proper care (1, 4, 5). Thaddeus and Maine (8) proposed the Three Delays Model, which encompasses delays in the decision to seek care in its Phase I, delays in reaching the appropriate health facility in its Phase II, and delays in receiving adequate medical care in its Phase III (8). Importantly, patients expecting delays in Phases II and III could have their behavior modified and delay even further in seeking medical attention in Phase I. Further research has brought attention to new variables, either by incorporating them into the existing framework or by changes in the perceived interconnection between these variables (9–11).

The range of variables acting upon each phase is significant, ranging from awareness regarding symptoms, women’s autonomy, cost of care, perceived quality of healthcare services, distance traveled for care, and availability of transportation, among others (8, 11, 12). How these variables interact with one another depends on several factors, such as the country studied, education level, and socioeconomic status. Research in Brazil found adverse obstetric outcomes were associated with Phase I and Phase II delays; however, these variables were not separately studied to understand if they act independently of each other (13).

The complex social system that dictates patient behavior and impacts timely access to health care was further impacted by COVID-19, which was declared a pandemic in March 2020 (14). The first case in Brazil was described in February 2020, followed by rapid spread (15, 16). Brazil has significant focus on hospital-based obstetric care, high cesarean rates, and inequality of access associated with ethnicity and education level (17). The impact of the pandemic on obstetric care is not fully understood and could deepen inequalities in access to obstetric health care (18).

This study aims to identify if there is a higher risk of intrapartum death among patients who began labor with a live fetus in the State of São Paulo from 2015 to 2021, independently assessing the distance traveled for delivery and the accessibility of delivery care provided by the city of the residence itself. Analysis was performed separately for pre-pandemic and pandemic groups.

## Section: MATERIALS AND METHODS › Study design and data sources

This study is a retrospective population-based cohort study. It is based on the Ministry of Health of Brazil databanks of all live births (SINASC) and all deaths (SIM), both publicly accessible. The cohort included all patients with a city of residence and delivery in the State of São Paulo who went into labor with a live fetus, and the primary outcome assessed was intrapartum fetal death. We downloaded publicly available files from SINASC and SIM containing live birth and fetal death records in the State of São Paulo from 2015 to 2021. All variables come from the SINASC and SIM databases. These databases provide individual-level, anonymized data for each delivery for all variables used in this research.1

## Section: MATERIALS AND METHODS › Setting

São Paulo, one of the 27 states of Brazil, is divided into 645 municipalities with a total area of 248 219.481 km2 and a population of 44 420 459 people. Its Human Development Index value is 0.806 (19).

## Section: MATERIALS AND METHODS › Participants

We included data of patients if their cities of residence and delivery were in São Paulo State, considering that some patients may seek medical assistance in another state when their city of residence is close to the border with neighboring states. We did not consider them eligible for the study if the gestational age at the end of pregnancy was less than 20 weeks, or if there was missing information regarding gestational age, maternal age, sex, and city of residence or delivery. All patients who fulfilled these conditions were used to calculate the delivery accessibility ratio for each municipality.

We classified patients according to the city of residence and date of delivery; events occurring from March 2020 onwards were classified as the pandemic group, as opposed to the pre-pandemic group.

We proceeded with further exclusion criteria to develop the cohort of patients who delivered after starting labor with a live fetus. Among live births, we excluded patients with cesarians happening before the beginning of labor or without information. Stillbirth death certificates classify the moment of death as antepartum, intrapartum, postpartum, or unknown; we excluded those with an antepartum or unknown moment.

## Section: MATERIALS AND METHODS › Delivery care accessibility ratio

Using the first step described in the participants section, we were able to determine two values for each municipality. First, the total number of hospital deliveries occurring in each city, regardless of these patients’ residences. Secondly, for each city, the total number of patients residing there who gave birth in a hospital in any city of the State. The ratio of hospital deliveries in a given city over the total deliveries among that same city’s residents was named the delivery care accessibility ratio. Cities with ratios less than 0.1 were classified as having low delivery care accessibility, since even though some deliveries were performed there, most patients residing there would need to seek medical attention elsewhere. Those with ratios equal to or greater than 0.1 were classified as high accessibility. The decision for a value of 0.1 was taken considering the rates of public healthcare coverage in Brazil (20) and percentage of dual-use of both public and private health care (21), as to reflect a local level of delivery care that, while existent, might be either the result of sporadic and unexpected events, or expensive and widely unavailable for the majority of patients.

## Section: MATERIALS AND METHODS › Distance from residence to the delivery unit

We calculated the distance traveled from the city of residence to the city of delivery. It was determined by the Haversine formula as a straight line, using publicly available coordinates for the city of residence and city of delivery. If they were the same city, travel distance was zero.

## Section: MATERIALS AND METHODS › Study size

When designing the study, we estimated that more than 1 000 000 patients would be included in this population study. We considered the rate of the outcome, stillbirth, which is 8.34 cases per 1 000 deliveries in the southeast region of Brazil (22), where São Paulo State is located. Sample size was adequate because the logistic regression adjustment comprised fewer than 10 factors.

## Section: MATERIALS AND METHODS › Statistical methods

Descriptive statistics were used to display the results. Categorical variables were compared using the Chi-square test, and continuous variables used the Wilcoxon–Mann–Whitney test. To assess the relative risk of intrapartum fetal death, we used a generalized linear model with Poisson distribution and log link, using delivery care accessibility, travel distance, education level, maternal age, and birth sex. The alpha value was used as 0.05 for the significance of all tests.

As an exploratory analysis, we focused on the population of residents of low delivery care accessibility cities. We compared the characteristics of those who delivered in that city and all others who traveled to another city for delivery. We restricted this analysis to live births, since the live birth database has more sociodemographic information, such as ethnicity and place of delivery. Ethnicity could be classified as White, Mixed-race, Black, Asian, or Indigenous. Place of delivery could be hospital, another healthcare service, home, another, or unknown. Groups were compared with the same statistical tests as described above.

All analyses were performed separately for each time period. Data manipulation and statistical analysis were conducted using the software RStudio version 4.2.2 (2022-10-31).

## Section: MATERIALS AND METHODS › Ethics

All data are publicly available and anonymized. According to the Brazilian National Commission of Ethics in Research, research employing public domain data that does not identify participants does not require ethics board approval.

## Section: RESULTS

The initial data included 2 895 045 live births and 63 981 stillbirths. Exclusion criteria regarding gestational age, birth sex, unspecified city of residence or delivery, and maternal age led to inclusion of 2 886 947 live births and 42 392 stillbirths, which were used to calculate the delivery care accessibility ratio in each period. Of this total, 697 109 occurred during the COVID-19 pandemic, and 2 232 230 happened in the pre-pandemic period. These allowed us to classify all municipalities in the state according to their delivery care accessibility ratio. In the pre-pandemic period, 274 were classified as high accessibility and 371 as low accessibility; during the pandemic, 248 cities were classified as high accessibility and 397 as low accessibility.

The cohort itself included only patients who underwent delivery after starting labor with a live fetus. After excluding 619 707 cesareans without prior labor and 532 live birth deliveries without information regarding type of birth, there were 2 266 708 live births. As for stillbirths, 27 526 were excluded due to fetal demise occurring antepartum, and 14 040 did not have information about moment of death, thus leading to 826 stillbirths. When adding live births and stillbirths who began labor with a live fetus, there were 2 267 534 deliveries, with 1 717 399 patients in the pre-pandemic period and 550 135 during the COVID-19 pandemic.

Patients in the pre-pandemic period mostly lived in high delivery care accessibility cities, had predominantly 8 to 11 years of education, and had a mean age of 27.7 years, while the median was 28 years, with a standard deviation of 6.7 years. When comparing both outcomes, patients with intrapartum fetal death in the pre-pandemic period had a higher proportion of residents in cities with a low delivery care accessibility ratio, traveled longer distances for delivery, were younger, had fewer years of education, and had a higher proportion of male fetuses. All tests had a p-value < 0.01. Chi-square post hoc analysis for education level had all categories being statistically significant with a p-value < 0.01; the same analysis for age group revealed statistically significant differences in the proportion of patients aged younger than 20 years (p = 0.04) and from 20 to 35 years (p < 0.01). These results are summarized in Table 1. During the pandemic, only differences in the proportion of low delivery care accessibility ratio, travel distance for delivery, and education level remained statistically significant (p < 0.01), with a higher proportion of patients with intrapartum fetal deaths residing in cities classified as low accessibility. Post hoc analysis of education level differences found significant results (p < 0.01) solely among the unknown education level group. These findings are detailed in Table 2.

In the pre-pandemic period, an unadjusted relative risk (RR) of 2.58 for intrapartum fetal death (95% CI [2.12, 3.11]; p < 0.01) and an adjusted RR of 2.02 (95% CI [1.64, 2.47]; p < 0.01) was found among patients residing in cities with a low delivery care accessibility ratio. Other variables produced significant relative risks as well, such as travel distance, with both an unadjusted and adjusted RR of 1.01 per kilometer in a straight line (95% CI [1.01, 1.01], p < 0.01 for the unadjusted model; 95% CI [1.00, 1.01], p < 0.01 for the adjusted model). Maternal age above 35 years, fewer years of education, and male birth sex all had statistically significant RR in the adjusted model. A summary of these results can be found in Table 3.

The overall characteristics of patients in the pandemic period were similar to the pre-pandemic period. Most patients lived in municipalities with high delivery care accessibility, had between 8 and 11 years of education, and had a mean age of 28.3 years and a median age of 28 years, with standard deviation of 6.7 years. When considering both outcomes, residents in a low delivery care accessibility ratio city displayed an unadjusted RR for intrapartum fetal death of 2.47 (95% CI [1.62, 3.65]; p < 0.01) and an adjusted RR of 1.69 (95% CI [1.09, 2.55]; p = 0.015). Each kilometer of travel distance in a straight line had an impact of an RR of 1.01 for both the unadjusted and adjusted analysis (95% CI [1.01, 1.01], p < 0.01 for the unadjusted model; 95% CI [1.00, 1.01], p < 0.01 for the adjusted model). Only fewer years of education yielded statistically significant RR in the adjusted model. These results are shown in Table 4.

In the exploratory analysis, in both periods, live birth patients residing in a low delivery care accessibility city who had their delivery in a different city had a higher proportion of White ethnicity, had more years of education, and had higher proportions of hospital birth. The proportion of hospital births among low delivery care accessibility city residents who had their live birth delivery in the same city was 49.2% in the pandemic period and 59.8% in the pre-pandemic period. In comparison, patients who went to another city for delivery had 99.5% proportion of hospital births in both periods. This relationship is shown in Figure 1.

## Section: DISCUSSION › Main findings

We identified a higher risk of intrapartum fetal death among pregnant patients who began labor with a live fetus when residing in cities with low delivery care accessibility ratios. Notably, this result was also independent of and more clinically impactful than the distance between the city of residence and childbirth.

During the COVID-19 pandemic, hospital deliveries among patients both residing and giving birth in low delivery care accessibility cities reduced even further. There was also an increase in the number of cities with low delivery care accessibility compared to the previous period.

## Section: DISCUSSION › Interpretation

Travel distance may hold ambiguous and divergent meanings in retrospective studies, mainly when analyzed in the context of the superposition of private and public healthcare providers. Patients may face long distances between their hometowns and cities of delivery due to the inexistence of adequate care nearby or as part of a planned approach to receive the best possible private care in the state, even if reasonable care was provided closer to their residence. Conversely, a patient might display low travel distance if they were incorrectly diagnosed as not requiring specialized care in the public sector or if they had enough resources to access private care in cities that do not have equally specialized public services. Distance is a component of the Phase II delay in the Three Delays Model proposed by Thaddeus and Maine (8); it is contextual and requires consideration regarding the origin’s conditions.

We interpret these results as evidence favoring a Phase I delay among patients residing in low delivery care accessibility ratio, resulting in intrapartum fetal death. Patients could be less motivated to seek care when presenting symptoms if their hometowns are not equipped well enough to judiciously select which patients require further assessment in a maternity hospital and which can safely wait for the next prenatal visit. Patients could be discouraged from seeking their local health service if they are frequently referred to nearby cities, just to be discharged hours later without needing further intervention, spending significant time on what could potentially be solved at the primary care level. This hypothesis is partially corroborated by research in Brazil, which observed high rates of nonurgent or low-priority cases among pregnant patients of all gestational ages in obstetric emergency departments (23, 24) or high discharge rates from the specialized obstetric emergency department after clinical assessment and verbal orientation (25).

A study from the Netherlands found regional differences in perinatal mortality rates (26). A subsequent study from the same country identified a higher risk of neonatal and perinatal mortality among patients with travel time to the hospital equal to or greater than 20 minutes (27). The Dutch obstetric healthcare system significantly differs from the Brazilian system; patients are described as beginning labor at home, even when hospital birth is planned. This matter obscures the comparison regarding healthcare-seeking behavior and Phase I delays and further reflects the importance of the overall healthcare structure in which patients are inserted.

These differences in overall structural conditions are seen not only between countries but also between regions within countries. A study from Benin found that while travel distance impacted both antenatal care and delivery service utilization, the magnitude of this impact was higher in the northern part of the country, reflecting local conditions beyond the simple measurement of travel distance (28). These findings concur with our results, demonstrating travel distance and accessibility conditions as independent variables inside the region of the study.

A study in the Republic of Korea aimed to assess the impact of residence in areas underserved in obstetric care. This research found higher rates of adverse obstetric outcomes in these regions, such as abortion, obstetric hemorrhage, and pyelonephritis (29). These results concur with our own, as they describe the negative impact that could arise from living in cities with suboptimal access to medical services. As the Republic of Korea has a single public healthcare insurance system, their definition of underserved areas ends up being different than the delivery care accessibility ratio described in this research; when both private and public health care coexist, the presence of care does not equate to accessibility, as deep socioeconomic divisions segregate healthcare access.

Available research is not unanimous regarding how the COVID-19 pandemic might have impacted medical-seeking behavior among pregnant patients. A report from the beginning of the outbreak demonstrated a reduction in visits and births in a tertiary center (30). Conversely, a cross-sectional study using web-based surveys in California did not find a reduction in perinatal healthcare access between the first and second COVID-19 waves (31). Our findings suggest reduced delivery care accessibility during the pandemic. Differences in the COVID-19 response, previous healthcare structure, and outcome definition could be associated with these divergences.

## Section: DISCUSSION › Strengths and limitations

This study has several strengths. It utilizes databases with individual-level data from birth and death certificates, which are mandatory in Brazil, reducing the chance of data loss. It also includes a large number of patients during a significant period. Limitations include the retrospective nature of the study. Linear distance, as calculated, does not consider terrain and is likely to underestimate actual distance traveled; furthermore, it does not consider in-city distance from home to hospital. There are also limitations inherent in using administrative databases, such as potential errors or missing information. Notably, of all variables, moment of death for stillbirths was the most impacted, with about one-third of stillbirths being excluded for this reason. However, there is no indication this failure to record would happen more often in one group than another, representing an inherent deficiency in the recording system as a whole. Thus, missing information and exclusion should not, on its own, change the overall results. Analysis comparing live births and stillbirths was also limited due to differences in how both are recorded; stillbirths in Brazil follow a death certificate model very similar to the adult death certificate model, with little additional information. For example, the current system does not record the mother’s ethnicity in stillbirths. Despite these limitations, these do not seem to invalidate the current findings.

## Section: DISCUSSION › Conclusion

In summary, pregnant patients residing in low delivery care accessibility cities have a higher risk for intrapartum fetal death in the State of São Paulo, independently of the distance traveled for delivery. This represents a delayed decision to seek medical care due to a possible combination of disincentives caused by the known travel distance and perceived efficacy of care. The COVID-19 pandemic seems to have reduced delivery care accessibility.

Delivery care accessibility could be improved by reconsidering the hospital-based delivery system and increasing focus on family physicians or midwives for low-risk pregnant patients. Another option to reduce Phase I delays and improve primary care in these cities could be investment in official communication channels between primary care physicians and specialists in tertiary centers. This could potentially avoid unnecessary time spent traveling to and from tertiary centers and improve efficacy as perceived by patients, thus increasing the likelihood the patient will actually seek medical care when necessary. Finally, stillbirth death certificate models should be revised in order to register more obstetric information, such as the mother’s ethnicity.

## Section: Disclaimer.

Authors hold sole responsibility for the views expressed in the manuscript, which may not necessarily reflect the opinion or policy of the RPSP/PAJPH and/or the Pan American Health Organization (PAHO).


---

# Harnessing the power of synthetic data in healthcare: innovation, application, and privacy

- **Authors:** Mauro Giuffrè, Dennis L Shung
- **Issuer:** NPJ digital medicine
- **Type:** Scientific article
- **Published:** 2023-10-09
- **Language:** en
- **DOI:** 10.1038/s41746-023-00927-3
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37813960/
- **Licence:** CC-BY

## Section: Abstract

Data-driven decision-making in modern healthcare underpins innovation and predictive analytics in public health and clinical research. Synthetic data has shown promise in finance and economics to improve risk assessment, portfolio optimization, and algorithmic trading. However, higher stakes, potential liabilities, and healthcare practitioner distrust make clinical use of synthetic data difficult. This paper explores the potential benefits and limitations of synthetic data in the healthcare analytics context. We begin with real-world healthcare applications of synthetic data that informs government policy, enhance data privacy, and augment datasets for predictive analytics. We then preview future applications of synthetic data in the emergent field of digital twin technology. We explore the issues of data quality and data bias in synthetic data, which can limit applicability across different applications in the clinical context, and privacy concerns stemming from data misuse and risk of re-identification. Finally, we evaluate the role of regulatory agencies in promoting transparency and accountability and propose strategies for risk mitigation such as Differential Privacy (DP) and a dataset chain of custody to maintain data integrity, traceability, and accountability. Synthetic data can improve healthcare, but measures to protect patient well-being and maintain ethical standards are key to promote responsible use.

## Section: Introduction

Data is the lifeblood of modern healthcare bearing the potential to improve patient care by powering clinical research, and advancing public health initiatives. However, the promise of real-world data to enable personalized medical care, to guide policymaking, and to respond to rapidly changing conditions is tempered by the significant challenges inherent in accessing high-quality datasets. Synthetic data offers an attractive alternative that addresses privacy concerns, streamlines data utility agreements, protocol submissions, and ethics review approvals, and decreases costs. In light of this potential, synthetic data has been utilized in other fields such as finance and economics to evaluate risk management, to optimize complex portfolios, and to enhance algorithmic trading particularly when access to real-world financial data is limited or privacy concerns are raised by financial agencies1. However, the use of synthetic clinical data to evaluate risk in clinical decision-making is modulated by the following challenges: the liability with modeling error is more consequential and the stakes for patients and providers are high2,3. Healthcare stakeholders are typically risk-averse and prefer precise replication of the original healthcare records and have decreased trust in clinical diagnosis derived from AI-based prediction models using synthetic datasets3,4. In this article we review the generation techniques, applications, and definitions of synthetic data in the context of healthcare and explore associated privacy issues. We highlight these concerns and propose strategies to mitigate harm, aiming to harness the full potential of synthetic data in advancing medical research and patient care.

## Section: What is synthetic data?

Despite the interest in synthetic data, the field is still developing and has no clear consensus regarding a unified definition. The absence of a universally accepted definition of synthetic data leads to inconsistent use of the term and interpretations that vary across contexts, thereby affecting reproducibility and transparency in research involving synthetic data. A working definition has been recently proposed by the Royal Society and The Alan Turing Institute, where synthetic data is “data that has been generated using a purpose-built mathematical model or algorithm, with the aim of solving a (set of) data science task(s)”5. This proposed definition is particularly interesting when compared to the alternative definitions emphasizing the creation of new data values mirroring the original data’s statistical characteristics6. This new working definition stresses the functional and intentional aspects of synthetic data, shifting focus from mere replication of statistical properties to the strategic use of these artificial constructs in addressing complex scientific challenges. The main types of synthetic data in clinical settings include tabular, time-series, or text-based synthetic data. Additional categories also include synthetic images, video, or audio simulation.

## Section: What is synthetic data? › Synthetic data generation and types

The concept of using synthetic data, originating from computer-based generation, to solve specific tasks is not novel. This approach traces back to the foundational work of Stanislaw Ulam and John von Neumann in the 1940s, focusing on Monte Carlo simulation methods7. Modern synthetic data generators range from deep learning structures like Generative Adversarial Networks (GANs)8 and Variational Auto-encoders (VAEs)9, to agent-based econometric models10, or stochastic differential equations simulating physical or economic systems11. The growing interest in the medical use of synthetic data has led companies to develop open source (e.g., Synthea)12 or commercial (e.g., MDClone’s Synthetic Data Engine)13 tools that can automate the generation of high-quality and clinically realistic synthetic datasets.

Regardless of the methodology, the classification of synthetic data is not rigid and often represents a spectrum that ranges from partially to fully synthetic. Partially synthetic data incorporates real-world data with synthetic data14. In healthcare, partially synthetic data has been used as a proxy for real-world data to protect patient privacy while still allowing researchers to conduct analyses. For example, Loong et al.15 investigated the use of partially synthetic data as a proxy for real-world data in large-scale health surveys. The study reviewed inferential methods for partially synthetic data, including the selection of high disclosure risk variables for synthesis, specification of imputation models, and identification of disclosure risk assessment. The results showed that partially synthetic data can be used to protect patient privacy while still allowing researchers to conduct analyses.

Fully synthetic data is created entirely de novo based on predefined rules, models, or simulations16. It does not rely on or represent real-world data but is instead designed to replicate the kinds of complexity and variability that might be seen in real-world scenarios. Other than data quality, fully synthetic data can address the issue of data scarcity that may affect both linear and non-linear models as well as the rapidly proliferating large language models by creating supplementations to the available datasets.

## Section: Applications of synthetic data in healthcare

Synthetic data has the potential to estimate the benefit of screening and healthcare policies, treatments, or clinical interventions, augment machine learning algorithms (e.g., image classification pipelines), pre-train machine learning models that can then be fine-tuned for specific patient populations, and improve public health models to predict outbreaks of infectious diseases17–27.

Building upon the potential uses of synthetic data mentioned earlier, the study by Davis et al.28 serves as a tangible example of how these datasets can be generated and utilized to investigate healthcare policy implications, particularly in the context of demographic aging. The authors explored the use of micro-simulation techniques to create a synthesized dataset and test policy options, focusing on the case of health service effects under demographic aging. The study integrates multiple data sources, including the New Zealand Health Survey (NZHS), Australian Health Survey (ANHS), and National Primary Medical Care Survey (NPMCS) to create a synthetic dataset for microsimulation in healthcare policy analysis. The process involved imputation techniques to enrich the representative sample from NZHS with data from ANHS and NPMCS. Subsequently, the synthesized dataset could be used to evaluate the impact of various policy scenarios on health service outcomes, such as variations in morbidity and disability, community support, and doctor behavior. These scenarios are presented as binary alternatives, enabling the exploration of both optimistic and pessimistic policy outcomes on healthcare demand and resource utilization. Furthermore, the authors analyzed the impact of demographic aging by re-weighting the 2002 population to a 2021 projection based on medium birth, mortality, and migration rates. The average number of visits increased slightly from 6.7 to 6.9 per year for general practitioner (GP) users. The researchers tested three components: morbidity, social support, and practitioner behavior. For the 65+ age group, average GP visits doubled from 8.8 to 15.3 for higher morbidity scenarios, while social support remained unaffected. The authors also found that prescription rates for more interventionist GPs were nearly double compared to least interventionist colleagues. Referral rates for the most interventionist GPs were six times higher than the most conservative (30% vs. 5%). The use of synthetic data in this example is an approach that could allow policymakers to make decisions on resource allocation after analyzing a range of possible scenarios to gain insights into healthcare demand and resource utilization.

The broad applicability and adaptability of synthetic datasets extend beyond their use in policy simulation and across multiple data modalities. A different but equally innovative approach to using synthetic data is illustrated in a study by Julia et al. in 2020 leveraged a Natural Language Processing (NLP) model by training it with synthetic datasets created from patient discharge reports29. The model effectively targets mental health diseases to predict the corresponding diagnosis and phenotypes. Electronic Health Records (EHRs) provide NLP data that can be utilized for specifying the critical aspects of a patient’s disease and anticipated pathways. For patients with mental health issues, the EHRs are typically based on an unstructured text that can be generated synthetically for training language models to classify complex diseases. Since mental health information is considered particularly sensitive, the use of synthetic text mitigates the risk for compromising sensitive information for individual patients. Synthetic datasets can also be useful in clinical challenges that involve large populations and epidemiological phenomenon, such as in the COVID-19 pandemic. Synthetic datasets were useful in improving the challenge of improving data scarcity in augmenting data volume in imaging studies in the COVID-19 pandemic30. In particular, Das et al.31 created conditional synthetic datasets for chest CT scans to classify COVID-19 patients from a population of normal individuals and pneumonia patients. The authors demonstrated that using synthetic datasets could improve the accuracy COVID-19 detection process compared to the original datasets. The discussed studies illustrate the multifaceted potential and adaptability of synthetic data in healthcare. Whether for probing healthcare policy impacts in an aging demographic, enhancing NLP models for mental health diagnoses, or bolstering COVID-19 detection in CT scans, synthetic datasets provide invaluable tools for researchers. By bolstering the volume and variability of available data, synthetic datasets facilitate more robust and comprehensive analyses, thereby informing and improving healthcare strategies, machine learning models, and disease detection methods.

## Section: Applications of synthetic data in healthcare › Synthetic data and digital twins

Synthetic data is also helpful for digital twins, which are virtual replicas of physical systems or processes that can be used to simulate and predict their behavior in real time. The use of digital twins in healthcare is still underdeveloped, but synthetic data could be used to create personalized models of patients, needed to optimize treatment plans, and improve patient outcomes. One area where digital twins are being increasingly used is in hospital efficiency and operations, where synthetic data is used to create realistic models that can simulate different scenarios and predict outcomes. In the creation of a hospital digital twin, synthetic data can be used to simulate different scenario, such as changes in patient volume, staff level of training, and equipment availability, thus hypothetically allowing administrators to optimize staffing levels and resource allocation, reducing cost and improve patient outcomes32,33. Synthetic data can also be used to create digital twins of patients and their trajectories, which can be used to optimize treatment plans and improve patient outcomes34–37. By creating a personalized model of a patient, synthetic data can be employed to simulate different treatment options and predict their effectiveness, thus improving patient outcomes and possibly reducing costs.

## Section: Applications of synthetic data in healthcare › Potential pitfalls: bias and interpretability

The incorporation of synthetic data in healthcare has been lauded for its potential to circumvent the challenges surrounding data scarcity and privacy. However, this potential carries concerns such as the risk of bias amplification, low interpretability, and an absence of robust methods for auditing data quality.

Bias is defined as a systematic discrepancy or persistent deviation that originates during the data sampling or testing process. This can lead to an overestimation or underestimation of the risks associated with specific clinical outcomes. Consequently, if the primary dataset used to generate synthetic data carries inherent biases, the synthetic data could unintentionally magnify these biases. This can result in misinformed or discriminatory outcomes in medical research and practice, further perpetuating existing inequalities and placing vulnerable populations at heightened risk of harm and discrimination38,39. This bias could originate from the population under study, the techniques employed to collect data, or the methods used to derive the new dataset40–42.

For instance, if a synthetic dataset is trained on a dataset of facial images that majorly includes people from a certain ethnicity, the synthetic images generated will naturally reflect this imbalance, thus perpetuating the initial bias. This leads to AI systems being “blind” to data beyond their training sets, unable to accurately represent or make fair decisions about the unrepresented categories. This is known as the “out-of-distribution” (OOD) problem, a key challenge for AI systems working with synthetic data43. Despite synthetic data may potentially solve this limitation by oversampling under-represented characteristics, the danger lies in the risk of overgeneralization and potential creation of non-existent or incorrect correlations. This artificial augmentation may in fact worsen the out-of-distribution issue, by falsely representing certain demographics and their associated medical profiles. Hence, it is crucial that the generation of synthetic data is accompanied by scrutiny and consistent evaluations to minimize these biases. Automatic AI-based methods can be used to address the OOD problem, such as the incorporation of anomaly detection techniques which can identify instances that deviate significantly from the training data distribution, helping to detect and handle OOD examples44. By flagging or rejecting such examples, AI systems can avoid making unreliable predictions or decisions.

Bias can also be derived from the generative methods used to derive the synthetic dataset. There are considerable challenges associated with interpreting synthetic data generation models, including the black-box nature of generation algorithms, limitations in the evaluation metrics, and the potential for overfitting or underfitting. This lack of transparency can erode trust in the generated synthetic data, making it difficult for healthcare professionals and researchers to make reliable conclusions or informed decisions based on the data45. Explainable AI (XAI) techniques play a crucial role in ensuring the interpretability and transparency of AI systems, particularly when dealing with synthetic data. XAI methods enable users to understand the underlying mechanisms and decision-making processes of AI models, providing insights into the input-output relationships and the presence of biases46. In the context of healthcare, XAI techniques such as SHAP (SHapley Additive exPlanations) have been used to interpret the predictions made by machine learning models, ensuring transparency and accountability in decision-making47. XAI methods allow users to scrutinize and understand the decisions made by AI systems, which is particularly crucial in domains where decision-making should be transparent, such as healthcare47. In the context of synthetic data, XAI techniques can help assess if the synthetic data maintains the desired input-output relationships similar to those found in real data46. By using XAI methods, it becomes possible to identify biases and assess the extent to which the synthetic data represents real-world scenarios. However, it is important to note that XAI methods are not without challenges. The interpretability of AI models and the explanations provided by XAI techniques can be subjective and context-dependent48. Different stakeholders may have different requirements and interpretations of what constitutes a satisfactory explanation48. Additionally, the trade-off between accuracy and interpretability should be carefully considered, as more interpretable models may sacrifice some level of predictive performance49.

A significant challenge that arises in the realm of synthetic data pertains to the necessity for robust auditing methods, particularly when XAI methods prove insufficient in evaluating the accuracy and representativeness of the data. The crux of the issue lies in the fact that conventional techniques used to generate synthetic data may inadequately capture the rich complexity and diverse array of real-world medical scenarios. Consequently, the development of novel auditing methods becomes imperative to ensure the true representativeness of synthetic data. One potential approach to auditing methods involves leveraging advanced statistical techniques and machine learning models to accurately assess the similarity between synthetic and real-world datasets. Techniques such as distribution matching50, correlation analysis51, and dimensionality reduction52 can capture the intricate correlations and patterns inherent in real-world medical scenarios, enhancing the data’s representativeness.

Another strategy would involve creating domain-specific evaluation metrics and benchmark datasets, particularly tailored for healthcare applications. By curating benchmarks that accurately represent a wide spectrum of real-world medical scenarios, researchers and practitioners can effectively compare the performance of various synthetic data generation techniques53. It’s also important to involve patients and healthcare professionals in the development and validation of synthetic data to ensure its relevance and representation of real-world medical scenarios. By involving human input, AI systems can learn from the expertize and domain knowledge of humans to improve their performance. This human-in-the-loop approach can help address the challenges posed by synthetic data scenarios and enhance the reliability and robustness of generative models54.

Lastly, transparency in the form of clear documentation of the data generation process, potential limitations, and data biases can help identify actual and potential errors. In balancing the benefits of synthetic data with the challenges of bias, interpretability, and the need to audit data quality, it becomes crucial to prioritize patient well-being and maintain ethical standards in healthcare.

## Section: Privacy concerns and regulatory agencies

Synthetic data poses serious risks to data privacy and protection. As argued in a recent scoping review55, privacy is not something to be considered on as an afterthought once a system has already been designed and deployed; a “privacy-by-design” mindset should proactively be applied, particularly when working with clinical data. The key challenge is to ensure that synthetic data derived from sensitive medical information does not unintentionally disclose identifiable details about individuals or lead to re-identification, violating privacy and data protection principles.

## Section: Privacy concerns and regulatory agencies › Regulatory blind spots and proposals

At present, there is no clear legislation surrounding the use of synthetic data56 and current data protection regulations such as the General Data Protection Regulation (GDPR) and the Health Insurance Portability and Accountability Act (HIPAA) are limited in their ability to address all the potential risks associated with synthetic data57. The two sets of regulations follow the principle that all patients must give their consent before their data are processed or shared, with exceptions when data processing is mandatory, such as for payment or treatment purposes. The simplest method of privacy protection is to remove all fields that could directly and uniquely identify an individual as recommended by HIPAA, which identified 18 such items (e.g., name, social security number, phone number). This was deemed sufficient to de-identify data until the middle of the 2000s, and following the HIPAA Privacy Rule 45 CFR 164, such data is no longer considered Protected Health Information (PHI)58. The underlying premise was that the disclosure did not pose a material risk to privacy once these 18 types of information were deleted, and the disclosing entity did not actually know that the data in the de-identified dataset could be used to identify an individual. However, it has recently become evident that a variety of other data fields can be used to identify people59. GDPR expands the scope of protected information beyond the definition of PHI, using the term “personal data”, which relates to any information related to an identified or identifiable natural individual. While HIPAA is limited to information generated by healthcare providers related to the medical treatment of patients, the GDPR refers to a natural individual as an entity that can be identified directly or indirectly by other indicators such as physiological, genetic, mental, and cultural identity58. The GDPR delineates two forms of data de-identification: pseudonymization and anonymization. Data pseudonymized under GDPR, which is still subject to its legal constraints, often resembles de-identified data under HIPAA. Encrypted with a patient key, data could be de-identified under HIPAA, but it would only be pseudonymized under GDPR, and thus still subject to its regulations. Full anonymization under GDPR is hard to achieve and offers minimal analytical value. Using GDPR-protected data necessitates substantial legal compliance, especially for non-EU entities60. Identifying what constitutes “identifiable” data is complicated by re-identification potential. Recent studies have disproved the that de-identification definitively prevents re-identification, citing examples of predictability using accessible personal details. While the challenges of synthetic data regulation are not confined to the field of medical research alone, they also permeate into other facets of healthcare, like the development of medical devices. The work by Chen et al.61 sheds light on this broader perspective, underscoring the crucial role of regulatory bodies in facilitating the judicious application of synthetic data in healthcare, specifically within the arena of medical devices incorporating artificial intelligence and machine learning algorithms. The Artificial Intelligence Synthetic Data for Medical Devices (AISAMD) program, a joint venture between the US Food and Drug Administration (FDA) and Standards and Technology (NIST), endeavors to create a framework for the utilization of synthetic data for evaluating such medical devices62. This initiative underscores the potential of synthetic data in machine learning for medical applications while stressing the need for stringent validation methods and guidelines for responsible usage in regulatory submissions. This regulation of synthetic data, bears implications not just for patient privacy and data security, but also for the advancement of technological innovation in healthcare. However, incorporating the ethical and legal challenges63 associated with synthetic data sharing and usage often straddle the definitions set by existing data protection regulations, thereby creating a regulatory blind spot. This loophole could potentially be exploited by malicious entities, leading to discriminatory use of synthetic data and exacerbating health disparities, undermining efforts to improve patient outcomes. Given this regulatory ambiguity, it behooves systems to revise current data protection legislation with precise definitions and more stringent controls for synthetic data. The proposed measures include updating data protection regulations to encompass synthetic data, establishing a centralized regulatory body for oversight, and promoting transparency and accountability in the development and application of synthetic data. Additionally, it is equally important that future research continues to explore potential privacy risks associated with synthetic data and devise strategies for mitigating these risks. This research should also scrutinize the technical, social, and ethical implications of synthetic data usage in healthcare, offering a holistic examination of this emergent field.

## Section: Privacy concerns and regulatory agencies › Regulatory blind spots and proposals › The opportunity of differential privacy

Brauneck et al.63 recently reviewed privacy-enhancing technologies (PETs) from a legal standpoint to engage in a thoughtful discussion of how GDPR legislation in the European Union (EU) relates to commonly used PETs including federated learning (FL), secure multiparty computation (SMPC), and differential privacy (DP). DP a concept first proposed in 2006 by Dwork et al.64, is gaining broad acceptance as a solid, practical, and trustworthy privacy framework and its application has been also explored with synthetic data65–67. DP is a precise mathematical constraint that ensures the privacy of individual pieces of information in a database while answering queries about the aggregate. The concept of DP is based on the notion of adding noise to the data to protect the privacy of individuals. This noise introduction is governed by two parameters—epsilon and delta. Epsilon is a parameter that controls the amount of noise added to the data by varying the privacy budget, which represents the maximum amount of privacy loss that can be tolerated. A smaller value of epsilon indicates a higher level of privacy protection, but it also results in a higher level of noise in the data. Delta is a parameter that controls the probability of a privacy breach. It is a measure of the probability that the privacy of an individual is compromised. A smaller value of delta indicates a lower likelihood of a privacy breach but also results in higher noise in the data. The choice of the Epsilon parameter to achieve a balance between privacy and statistical utility may result difficult, with researchers proposing the institution of an “Epsilon Registry” to help make informed implementation choices68. As argued by Ficek et al.69 despite its robust protections, DP has not yet seen widespread adoption in the health sector. The focus so far has been primarily on creating predictive algorithms, sanitized data publishing, and training machine learning algorithms, particularly in the areas of genomics, neuroimaging, and personal device-derived health data streams. However, significant gaps are crucial for epidemiology and clinical research, especially for explanatory modeling and statistical inference. Another challenge is the privacy-utility trade-off; hence, experimental deployment and real-world case studies are required to understand this better.

Bridging this gap between the theoretical robustness of differential privacy and its practical implementation in the health sector, groundbreaking efforts such as the one by Jordon et al.70 have started to emerge, utilizing differential privacy in the context of synthetic data generation. Their novel approach incorporates a modification to the Private Aggregation of Teacher Ensembles (PATE) methodology, incorporating it into GANs for the creation of privacy-preserving synthetic data. Named PATE-GAN, this system utilizes a generator network for synthetic data production from random noise, which is then appraised by a discriminator network. This innovative approach replaces the single discriminator network with multiple teacher networks. Each network is trained on a separate segment of the initial dataset and provides feedback to the generator. This aggregation ensures a balance in model influence and upholds robust differential privacy. PATE-GAN has proven superior to conventional, yet outdated benchmarks, such as Differential Private-GAN (DP-GAN)71 and excels in generating synthetic data that closely resemble the original dataset. To evaluate the similarity of synthetic samples with the original data, the authors propose a new metric, termed “synthetic similarity.” This cutting-edge technique offers enhanced performance and a unique evaluation metric, making it adaptable across a variety of datasets and applications. In essence, PATE-GAN constitutes a significant stride forward in the realms of machine learning and privacy. In summary, PATE-GAN, through its innovative approach to differential privacy and the introduction of a unique “synthetic similarity” metric, represents a major advancement in the intersection of machine learning and data privacy, enabling the production of high-quality synthetic data that balances privacy protection with utility across various datasets and applications.

In conclusion, as privacy-enhancing technologies evolve to meet the challenges posed by data privacy regulations and the need for practical implementation in health research, differential privacy emerges as a robust, reliable, and promising approach. Despite its current limitations, particularly in the context of explanatory modeling and statistical inference, its adoption in cutting-edge frameworks such as PATE-GAN highlights its versatility and potential. PATE-GAN’s innovative approach, the introduction of the “synthetic similarity” metric, and the ability to generate high-fidelity synthetic data show a significant advancement in the delicate balance between data privacy and utility.

## Section: Privacy concerns and regulatory agencies › Establishing a digital chain-of-custody

Despite the promise of DP to mitigate risk, it is not a panacea. The healthcare community must consider safeguards on the diffusion of synthetic datasets by developing and implementing appropriate regulations. For example, it is crucial to establish a robust digital chain of custody to ensure the integrity, security, and privacy of data throughout its lifecycle and it must encompass data sharing, storing, and disposal to provide transparency, traceability, and accountability at each stage.

The application of a digital chain of custody in data sharing is crucial for ensuring the integrity, security, and accountability of shared data. The digital chain of custody refers to the process and documentation that tracks the custody and movement of data from its collection to its final destination72,73. Digital chain of custody applications and software have been developed to document and track digital evidence, ensuring its integrity and providing a verifiable record of its custody72,73. Blockchain technology has also been utilized to enhance the chain of custody in data sharing. Blockchain-based systems provide a decentralized and immutable ledger that records the transactions and movements of data74. For example, Wang et al.75 proposed a chain-of-custody system is needed to document the sequence of custody of sensitive big data. They designed a prototype of a block-chain big-data sharing system (BBS), where a user can register a dataset with BBS for sharing. To acquire the shared file an authenticated and authorized recipient must use transactions and interacts with BBS across four stages including file transfer request, encrypted data transfer, file key retrieval, and file decryption. Each transaction is recorded in the ledger and serve as chain of custody to document the trail of the data.

This example, among others, has been previously employed to share real-world data, but there is no current process in place for synthetic datasets. The digital chain of custody should begin with generating synthetic data, outlining the methodologies and techniques used to create the data, as well as any privacy-preserving measures implemented, such as differential privacy. This information should be documented and accompany the synthetic data as it moves through various stages of its lifecycle. During data sharing, a secure and controlled process should be established for transferring synthetic data between different parties, such as healthcare providers, researchers, and policymakers. This process should include the use of encryption, secure authentication, and access control mechanisms to protect the data from unauthorized access or tampering. Furthermore, each data-sharing transaction should be logged, detailing the data transfer’s sender, receiver, timestamp, and purpose. For data storage, the chain of custody should ensure that synthetic data is securely stored using encryption and access control mechanisms to protect it from unauthorized access, modification, or leakage. Data storage locations and associated security measures should be documented and regularly audited to confirm compliance with established data protection standards and regulations. Finally, when it comes to data disposal, a clear protocol should be in place for the secure deletion or destruction of synthetic data once it is no longer needed. It involves using secure erasure methods to prevent the recovery of deleted data and maintaining disposal records that detail the time, method, and reason for data destruction.

In addition to these measures, it is vital to implement regulations that mandate a comprehensive research proposal evaluation before granting access to synthetic data. It ensures that the research plan is robust, genuine, and has a clear data analysis objective. Furthermore, researchers should be required to provide timed-release updates on the progress of their analysis and usage of the synthetic data, fostering transparency and allowing for better monitoring and evaluation of the data’s impact. Implementing these regulatory requirements makes it possible to mitigate potential risks associated with the misuse of synthetic data while promoting responsible research practices and maximizing the benefits of synthetic data in healthcare.

## Section: Discussion & conclusion

AI applications in medicine can improve research capabilities and create cost-effective solutions but require careful consideration of potential biases in synthetic data to ensure accurate representation and adequate safeguards for privacy such as differential privacy and a digital chain of custody. As summarized by Fig. 1, the creation and application of synthetic data should be tailored to specific use cases. In healthcare, significant privacy concerns underscore the need for the implementation of privacy-preserving techniques to protect sensitive medical data. We propose the concept of a digital chain of custody for synthetic data to ensure data integrity, security, and confidentiality throughout its lifecycle. To navigate these intricacies, collaborative efforts between the healthcare community and regulatory agencies are imperative in developing and implementing laws and regulations governing synthetic data. Moreover, to establish comprehensive guidelines and best practices for the responsible use of synthetic data in medicine and healthcare, it is crucial for healthcare providers, researchers, technology developers, and patients to be actively engaged and collaboratively involved.Fig. 1Highlights on Synthetic Data and their application in healthcare research, reviewing bias, quality, and privacy concerns.Despite the first attempt to generate synthetic data dates bate to the 1940s, current state of the art methods use Generative Adversarial Networks (GANs) or Variational Auto-encoders (VAEs). In terms of classification, synthetic data encompasses a spectrum that ranges from partially to fully synthetic. While partially synthetic incorporates real-world data, fully synthetic data are generated de novo. As reported in the text, synthetic data can have several applications in healthcare research, including imaging, infective disease prevention and outbreaks prediction, and digital twins. However, the lack of robust methods to audit the perpetration of bias, accuracy, and representativeness of real-world medical scenarios, has severely limited interpretability, use and trust from the healthcare sector. One of the greatest concerns related to synthetic data involves patients’ privacy. Current regulations from General Data Protection Regulation (GDPR) and the Health Insurance Portability and Accountability Act (HIPAA) are not sufficient or up-to-date to cover possible leakage of patients’ information from synthetic dataset. In this context, differential privacy may result valuable, but its usage has been limited by the privacy-utility trade-off. The definition of a clear chain of custody, can ensure integrity, security, and data privacy throughout data lifecycle providing transparency, traceability, and accountability at each stage.

In conclusion, while synthetic data possess the potential to revolutionize healthcare by offering improved research capabilities and cost-effective solutions, overcoming the challenges related to biased information, data quality concerns, and potential privacy risks are of paramount importance. This calls for the healthcare community’s active participation in discussions and collaborations with regulatory bodies, technology developers, and patients, thus fostering a proactive approach to harness the transformative power of synthetic data. Such a process will prioritize patient well-being and uphold ethical standards in medicine and healthcare.

Despite the first attempt to generate synthetic data dates bate to the 1940s, current state of the art methods use Generative Adversarial Networks (GANs) or Variational Auto-encoders (VAEs). In terms of classification, synthetic data encompasses a spectrum that ranges from partially to fully synthetic. While partially synthetic incorporates real-world data, fully synthetic data are generated de novo. As reported in the text, synthetic data can have several applications in healthcare research, including imaging, infective disease prevention and outbreaks prediction, and digital twins. However, the lack of robust methods to audit the perpetration of bias, accuracy, and representativeness of real-world medical scenarios, has severely limited interpretability, use and trust from the healthcare sector. One of the greatest concerns related to synthetic data involves patients’ privacy. Current regulations from General Data Protection Regulation (GDPR) and the Health Insurance Portability and Accountability Act (HIPAA) are not sufficient or up-to-date to cover possible leakage of patients’ information from synthetic dataset. In this context, differential privacy may result valuable, but its usage has been limited by the privacy-utility trade-off. The definition of a clear chain of custody, can ensure integrity, security, and data privacy throughout data lifecycle providing transparency, traceability, and accountability at each stage.


---

# Hybrid quantum-classical machine learning for generative chemistry and drug design

- **Authors:** A I Gircha, A S Boev, K Avchaciov, P O Fedichev, A K Fedorov
- **Issuer:** Scientific reports
- **Type:** Scientific article
- **Published:** 2023-05-22
- **Language:** en
- **DOI:** 10.1038/s41598-023-32703-4
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37217521/
- **Licence:** CC-BY

## Section: Abstract

AbstractDeep generative chemistry models emerge as powerful tools to expedite drug discovery. However, the immense size and complexity of the structural space of all possible drug-like molecules pose significant obstacles, which could be overcome with hybrid architectures combining quantum computers with deep classical networks. As the first step toward this goal, we built a compact discrete variational autoencoder (DVAE) with a Restricted Boltzmann Machine (RBM) of reduced size in its latent layer. The size of the proposed model was small enough to fit on a state-of-the-art D-Wave quantum annealer and allowed training on a subset of the ChEMBL dataset of biologically active compounds. Finally, we generated 2331 novel chemical structures with medicinal chemistry and synthetic accessibility properties in the ranges typical for molecules from ChEMBL. The presented results demonstrate the feasibility of using already existing or soon-to-be-available quantum computing devices as testbeds for future drug discovery applications.Subject terms: Quantum information, Quantum simulation, Computational biophysics, Medicinal chemistry

## Section: Introduction

Drug design is the process of identifying biologically active compounds and relies on the efficient generation of novel, drug-like, and yet synthetically accessible compounds. So far, only about 108 substances have ever been synthesized1, whereas the total number of realistic drug-like molecules is estimated to be in the range between 1023 and 10602. This is why deep learning3 and particularly deep generative models4–7 are believed to be helpful in generative chemistry and computational drug discovery applications involving sampling and scoring novel chemical structures from the very large and hitherto unknown distributions of possible drug-like molecules (see examples and benchmarks in Refs.8–10).

A fully developed generative model should implicitly estimate the fundamental molecular properties, such as stability and synthetic accessibility for each generated compound and its intermediate products. All those features depend on the ability of the network architecture to approximate the solutions of the underlying quantum mechanical problems, which is computationally hard for molecules of realistic size. Quantum computers are naturally good for solving complex quantum many-body problems11 and thus may be instrumental in applications involving quantum chemistry12–15. Moreover, quantum algorithms can speed up machine learning14,16. Therefore, one can expect that quantum-enhanced generative models17, including quantum GANs18, may eventually be developed into ultimate generative chemistry algorithms.

Exploring the full potential of quantum machine-learning algorithms requires the development of fault-tolerant hardware16, which is not yet accessible. Meanwhile, readily available noisy intermediate-scale quantum (NISQ) devices19 provide a test-bed for the development and testing of quantum machine-learning algorithms for practical problems of modest size. For example, quantum annealing processors20 could potentially enable more efficient solving quadratic unconstrained binary optimization problems and approximating sampling from the thermal distributions of transverse Ising systems. These applications are attractive in the context of machine learning as tools both for solving optimization problems21–24 and sampling25–28. Gate-based architectures are also of interest for machine learning16, in particular, in the context of quantum GANs, which are a subject of intensive research29–33 including recent demonstration of learning and generation of hand-written digit images on a quantum processor33.

In this work, we prototyped a discrete variational autoencoder (DVAE, see Ref.34), whose latent generative process is implemented in the form of a Restricted Boltzmann Machine (RBM) of a small enough size to fit readily available annealers. We trained the network on D-Wave annealer and generated 2331 novel chemical structures with medicinal chemistry and synthetic accessibility properties in the ranges typical for molecules from ChEMBL. Hence, we demonstrated that the hybrid architecture might allow practical machine-learning applications for generative chemistry and drug design. Once the hardware matures, the RBM could be turned into Quantum Boltzmann Machine (QBM), and the whole system might be transformed into a Quantum VAE (QVAE34) and sample from richer non-classical distributions.

## Section: Results

We proposed and characterized a generative model (see Fig. 1) in the form of a combination of a Discrete Variational Autoencoder (DVAE) model with a Restricted Boltzmann Machine (RBM) in the latent space34,35 and the Transformer model36. The model learns good representations of chemical structures from ChEMBL, which is the manually curated database of biologically active molecules with drug-like properties37.

Following Ref.4, we used common SMILES38 encoding for organic molecules and trained the system to encode and subsequently decode molecular representations via optimizing evidence lower bound (ELBO) for DVAE log-likelihood34:

Here, E denotes the expectation value, DKL is the Kullback–Leibler (KL) divergence, and pθ(z) is the prior distribution in the latent variable space and is encoded by RBM as in Ref.34 (see MM). The two layers of RBM contain 128 units each. An RBM of this size can be sampled on readily available quantum annealers. We used the spike-and-exponential transformation34 as a smoothing probability distribution between the discrete z and continuous ζ variables and employed the standard reparameterization trick to avoid calculating derivatives over random variables.

The respective encoder and decoder functions, qϕ(z|x) and pθ(x|ζ), are approximated by the deep neural networks with Transformer layers each depending on its own set of adjustable parameters ϕ and θ. We modified the KL divergence term with β=0.1 to avoid posterior collapse39.

We trained the network for 300 epochs until apparent convergence using Gibbs sampling (see the red and yellow lines in Fig. 2 representing the total loss over the validation and train sets, respectively). In what follows, we discuss the two checkpoints: the fully trained (Gibbs-300) and, for reference purposes, the intermediate model (Gibbs-75) appearing by the end of the 75th epoch. We expect that with improvements in quantum hardware (in particular, coherence times of qubits), training the DVAE with quantum annealing technique could be comparable to or overcome existing techniques.

VAE is a probabilistic model. In particular, this means that each of the discrete states in the latent variables is decoded into a probability distribution of SMILES-encoded molecules. On top of Fig. 1 we provide an example of encoding a particular molecule (diaveridine) and its reconstruction by the Gibbs-300 network (see the structures at the bottom). In this case, the target molecule was reconstructed exactly in 46% runs (see the reconstruction probabilities and Tanimoto similarities to the target molecule next to the reported structures).

DVAE is a generative model that can produce novel molecules with properties that presumably match those in the training set. In Fig. 3 and Table 1, we compare the distributions of the basic biochemical properties of the molecules in the training set and among molecules generated by each of the models with discrete latent variables trained and discussed in this work. The novel molecules were mainly valid (55% and 69% in Gibbs-75 (10k molecules) and Gibbs-300 (50k molecules) models, respectively). We kept track of molecular weight (MW), the water-octanol partition coefficient (logP), the synthetic accessibility (SA40) score, and the quantitative estimation of drug-likeness (QED41) score, which are common physico-chemical properties for benchmarking molecular generative models9.

Aside from the biochemical and drug-likeness properties, we also measured the novelty of generated molecules. Less than 1% of the generated molecules (0.36% and 0.22% in Gibbs-75 and Gibbs-300 models, respectively) had Tanimoto similarity larger than 0.9 to any molecule in the training set , and less than 10% of the generated molecules are similar to any molecule in the training set with T>0.7 in both models. Extra training time improved both the validity of the generated molecules and brought the molecular properties closer to those found in the training set (see the relevant Gibbs-75 and Gibbs-300 columns in Table 1).

The proposed network architecture is sufficiently compact to fit the D-Wave hardware. Hence, we were able to train the network using the annealer instead of Gibbs sampling. The learning of the hybrid model on D-Wave progressed slower than that on a classical computer using Gibbs sampling (see the blue solid and cyan dashed lines in Fig. 2 corresponding to the total loss of the model on the validation and the training sets). We had, however, to stop the training before reaching convergence at the 75th epoch due to the limited performance of the available quantum hardware. With its further improvements, we expect to have the ability to prolong the training. Eventually, we used D-Wave to generate 4290 molecular structures (2331 of which are grammatically correct, see Fig. 3 and the corresponding column in Table 1). As expected, the distributions of basic properties of the generated molecules were close to those obtained from the Gibbs-75 model and could be improved if more training time were available.

Scheme of the DVAE learning a joint probability distribution over the molecular structural features x and their latent variable-representations (discrete z and continuous ζ). Here, qϕ(z|x) and pθ(x|ζ) are the encoder and decoder distributions, respectively, whereas pθ(z) is the prior distribution in the latent variable space and is encoded by RBM. We provide an example of the reconstruction of a target molecule (diaveridine) using the Gibbs-300 model saved after 300 epochs of training (here t∈[0,1] is the Tanimoto similarity between the initial molecule and its reconstruction, t=1.0 corresponds to perfect reconstruction, p is the output probability).

Learning curves of DVAE trained with classical Gibbs sampling (red, yellow) and samples from D-Wave annealer (blue, cyan). Training on D-Wave was suspended before reaching convergence due to resource limitations. Also, the learning curve of a simpler model with continuous latent variables is shown (magenta, green).

Distributions of physico-chemical properties of the molecules produced by the proposed generative models (same as in Table 1).

The parameters of distributions of physico-chemical properties of the molecules produced by the generative models discussed in this work.

## Section: Discussion and outlook

VAEs are powerful generative machine learning models capable of learning and sampling from the unknown distribution of input data43,44. As a first step towards building a hybrid quantum generative model, we prototyped the DVAE (along the lines of Ref.34) with the RBM in its latent space34,35. If provided with a large dataset of drug-like molecules, such a system should learn implicit rules governing the stability and synthetic accessibility of small molecules and produce useful representations of molecular structure, which could be used to generate novel and still drug-like molecules for drug design applications such as virtual screening.

As a proof of concept, we built a DVAE involving transformer layers36 in the encoder and decoder components along with additional preprocessing layers that allowed our model to operate at the character-level (rather than on the word-level) to parse SMILES, the textual representations of the input molecules. Using SMILES is not necessarily the best option since these strings are not 100% valid. The only property of SMILES that is essential in our approach is that it is a representation of molecules in terms of character strings and hence we believe that DVAEs can be built to operate with alternative character string representations of molecules, such as SELFIES45.

We trained a compact DVAE with the RBM consisting of two layers of just 128 units each on a small subset containing almost 200,000-random molecules from the ChEMBL database of manually curated and biologically active molecules as the training set. On classical hardware, the system could be trained with Gibbs sampling. We were able to show that the training converged and used the network to generate molecules with the distribution of the basic properties, such as logP, and QED, closely matching those in the training set. Simultaneously, the average size of the molecules increased as the training of the network was progressing. There are relatively harder-to-synthesize compounds among the molecules generated by the network4.

Our generative model outputs drug-like molecules and may be deployed on already existing quantum annealing devices (such as D-Wave Advantage processor). Training of the same architecture network on the quantum annealer proceeded slower per epoch than on the classical computer, most probably due to noise. Nevertheless, the distributions of the molecular properties of generated molecules were sufficiently close to those in the training set or among the molecules generated by classical counterparts Gibbs-75 and 300. While certain discrepancies between distributions were present, these results have been computed only after a limited number of training epochs due to the restrictions on public access to the quantum computer.

Computational drug design applications depend on but are not limited to the generation of novel and synthetically accessible molecules, which is the focus of this work. The authors of the original paper4 have already proposed training additional properties, such as the prediction of the binding constant to a particular target on top of the autoencoder loss. Although a direct extension of VAE for these tasks may be challenging and require further refinements6, in such a form, the network could be used in problems involving actual drug design, i.e., for generating of novel compounds binding specific medically relevant targets. We did not attempt to demonstrate such a capability. However, we have no doubts that DVAE and, eventually, its hybrid implementations, such as QVAE, can be appropriately refitted by adding the extra loss.

The RBM could be turned into Quantum Boltzmann Machine (QBM) so that the whole system might be transformed into a Quantum VAE (QVAE,34) and sample from potentially richer non-classical distributions. Using genuine QBMs should speed up the training of the system (O(logN) vs. O(N) with N being the size of the network16). There was a demonstration in Ref.34, where “quantum” samplers with the non-vanishing transverse fields outperformed DVAE if assessed by metrics achieved at the same number of training cycles (epochs). Construction of QVAE with the controllable non-zero transverse field can, in principle, be performed on the existing generation of D-Wave chips. However, it would require additional hardware tuning and applying a combination of extra tricks such as reverse anneal schedule, pause-and-quench, etc46.

We demonstrated that a useful VAE can be built and trained to generate drug-like molecules while keeping the size of latent representation small and hence practically attainable on already existing quantum annealing devices. We expect that with further developments in the engineering of quantum computing devices, hybrid architectures similar to QVAE would surpass their classical counterparts. More specifically, the network architecture proposed in this work may provide the baseline for further refinements required for running genuinely quantum generative models. The benefit may be especially large in problems potentially involving rules of quantum chemistry, such as learning efficient representations of molecular structures for applications related to generative chemistry and drug design.

## Section: Methods

We proposed and characterized classical and quantum annealer models, which are a combination of Discrete Variational Autoencoder (DVAE) with Restricted Boltzmann Machine (RBM) in the latent space34,35 and the Transformer model36. Original Transformer model was proposed for word-level natural language processing tasks and has encoder-decoder architecture. We used original Transformer layers and developed additional preprocessing layers that allowed us to process character-level SMILES descriptions of molecules. We trained the proposed models on a subset of the ChEMBL dataset by optimizing evidence lower bound (ELBO) for DVAE log-likelihood34, modified with additional coefficient β that multiplies KL divergence term39, see Eq. (1). The sketch of the architecture of our models is illustrated in Fig. 1.

Below we describe in details the dataset, the network architecture, the training parameters, and the training schedule of the classical and quantum annealer models. Also, we describe a simpler classical model with continuous latent variables, which we used in the experiment shown in Fig. 2.

## Section: Methods › Dataset

We used a subset of molecules from the ChEMBL (release 26) database47,48. Our dataset consisted of the 192,000 structures encoded by SMILES strings of the maximum length of 200 symbols and containing the atoms from the organic subset only (B, C, N, O, P, S, F, Cl, Br, I). To focus on the relevant biologically active compounds, we removed salt residuals. Finally, we converted all SMILES into the canonical format with the help of RDKit42.

The processed molecules were randomly assigned into train and validation sets each containing 80% and 20% of all samples (153,600 and 38,400 molecules), respectively.

## Section: Methods › Training DVAE using Gibbs-sampling

Molecular SMILES strings are tokenized with the regular expression from Ref.49, which produced 42 unique tokens. Standard trainable embedding layer and positional encoding from Ref.36 are used. Our implementation utilized a combination of embedding and positional encoding, in which positional encoding is multiplied by an additional correction factor:

where xemb is embedding tensor, pe is positional encoding tensor and demb is the dimensionality of the embedding. This factor is required to make the proportion between embedding tensor and positional encoding closer to that in the original model36. The dimension of embeddings is a model hyperparameter which was set to 32.

We employed a layer of one-dimensional convolutions and a highway layer50 as additional preprocessing layers between the embedding layer and the encoder component. The convolution layer with 160 filters and the kernel size equal to 5 was developed based on Ref.51. We used highway layers since such layers have been shown to improve the quality of character-level models51,52.

The preprocessed 160-dimensional tensor is passed from the highway layer to the encoder, consisting of the stack of 5 Transformer encoder layers. The width of the feed-forward part of the layers is equal to 320. The number of heads in Multi-Head attention is 10. We used GeLU activation53 functions and Dropout with the rate of 0.1.

Original Transformer encoder layers produce output tensor of variable length. The length of the tensor is equal to the size of the input string. In order to further reduce the dimensionality of the latent space layer in the model, we construct a fixed-length tensor from the Transformer encoder output tensor u by calculating the fixed number of vectors from u, which we then concatenate in one tensor. The first two of these vectors are the vector with index 0 from Transformer layers output u and the vector equal to the arithmetic mean of all vectors along the length of the tensor u. Next, we consider the subsets Snm, each consisting of vectors with indices that have the same remainder after division by n for n=2,3,4,5:

For each Snm, we compute the arithmetic mean and concatenate all calculated vectors into the fixed-length output tensor.

Restricted Boltzmann machine (RBM) is implemented in the latent space as presented in papers34,35. The probability distribution of RBM is

where hl are bias weights for units zl and each Wlm is the weight associated with the connection between units zl and zm. The effective temperature is supposed to be equal to 1.0 and is not presented in the formulas. RBM in the proposed model consists of two layers of 128 units each. RBM of this size can be sampled using existing quantum annealing devices. It is worth noting that all the units of RBM in DVAE are latent variables and connected to the rest of the model. Hence, there is no distinction between “hidden” and “visible” units as for standalone RBM34,35.

An informal description of the internal working of the model in the latent space is as follows. The output of the encoder is the vector of probabilities of the discrete latent variables zi being equal to 1, which are conditioned on the input x of the model. These probabilities are sampled to obtain latent binary vector z. Continuous variables ζ are sampled using spike-and-exponential smoothing probability distribution r(ζ|z)34. Vector ζ is used as an input to the decoder module. During training, the parameters of the RBM are adjusted in order to memorize the statistics of the binary vectors z that appear in the latent space. The calculation of the gradient of the parameters of the RBM consists of two parts: the so-called “positive” and “negative” phases. The “positive” phase is calculated using the backpropagation algorithm after the application of the reparameterization trick, which is used to avoid calculating of derivatives over random variables. The “negative” phase of the gradient is estimated using sampling from the RBM distribution.

For molecule reconstruction or generation of similar molecules to a given molecule, the preprocessed SMILES description of the given molecule is passed to the input of the encoder and the whole model is executed. An example of molecule reconstruction and generation of similar molecules is depicted in Fig. 1. For generation of an entirely new molecule the encoder is not used, the trained RBM is sampled to obtain latent binary vector z. This vector is then used to calculate the latent vector of continuous variables ζ, which is given as an input to the decoder. Table 1 and Fig. 3 show results for newly generated molecules.

RBM is sampled by performing 30 steps of Gibbs updates using persistent contrastive divergence (PCD)54.

The decoder works in two modes: training and inference (generation). In the inference mode, decoder uses preprocessing layers. The main part of data processing in both training and inference modes of the decoder consists of Transformer decoder layers. Altogether, we used 5 Transformer decoder layers of the size dmodel=160 (GeLU activation, dropout = 0.1). The width of the feed-forward part of the layers was equal to 320, and the number of heads in Multi-Head attention was 10.

To train the model, we used the rebalanced objective function, in which the KL divergence term is multiplied by the additional coefficient β=0.139 to avoid the posterior collapse problem, and employed the Adam optimizer.

In contrast to the original Transformer model, we used a different learning rate schedule: we trained the model for 300 epochs using the MultiStep learning rate schedule with the initial learning rate equal to 6×10-5. The learning rate was subsequently reduced by the factor of 0.5 at points corresponding to 50%, 75%, and 95% of the length of the training process.

For estimation of the logarithm of the partition function of Boltzmann distribution, we used annealed importance sampling (AIS) algorithm55 during the evaluation of the model at the end of each epoch using 10 intermediate distributions and 500 samples.

Due to resource constraints, we did not have a chance to optimize the hyperparameters or too many architectural variants of the model. The presented variant of the network just worked and can be considered the first step toward a real and effective solution.

## Section: Methods › Training DVAE on a quantum annealer

We used exactly the same network architecture on the quantum annealer with the only difference from the classical case being that the RBM in the latent space was sampled using D-Wave Advantage processor. Also, the quantum model was trained during 75 epochs with constant learning rate equal to 6×10-5.

For estimating the logarithm of the partition function of the Boltzmann distribution during the evaluation of the model, we used a different version of annealed importance sampling (AIS; see Ref.56) with the same parameters as in the classical case.

## Section: Methods › Training model with continuous latent variables

The model with continuous variables in the latent space has similar architecture to the discrete one but is smaller in size. The latent space contains 32+32 normally distributed continuous random variables.

The preprocessing convolution layer consists of 100 filters with kernel size equal to 5. The encoder/decoder consists of 2 Transformer encoder/decoder layers with the width of feed-forward part equal to 200.

The fixed length tensor is calculated in the similar way as in the discrete model. The model is trained using the same initial learning rate and learning rate schedule as in the discrete case.

## Section: Methods › Calculation of molecular similarity with fingerprint

Fingerprints for each molecule are generated using a default function RDKFingerprint in RDKit42. This algorithm produces a topological fingerprint represented by a bit vector with the size of 2048 bits. The Tanimoto similarity is known as a reasonable metric for matching molecules sharing similar fragments57 and is defined for two fingerprints a, b as:

where C is a number of common non-zero bits in a and b; A and B are numbers of non-zero bits that are present in a and b, respectively. The Tanimoto distance could be defined as D(a,b)=1-T(a,b). From the definition, it follows that completely similar molecules (shared identical set of fragments) have Tanimoto similarity equal to 1, while dissimilar molecules (no common fragments) have T=0.

## Section: Acknowledgements

We thank S. Usmanov for help in performing the experiment. P.O.F and A. K. would like to thank Dr. A. Tarkhov from Gero and Daria Orhunova for fruitful discussion and help with the data analysis. We acknowledge online cloud access to the quantum annealing device produced by D-Wave Systems (all experiments with D-wave hardware were performed within the program of global response to COVID-19 and completed in 2021). A.K.F. thanks Russian Science Foundation grant (19-71-10092). P.O.F. and K. A. are supported by Gero PTE. LTD. (Singapore).

## Section: Author contributions

All the authors jointly developed the problem statement and analyzed existing state-of-the-art techniques. A.I.G. and A.S.B. implemented the considered methods and performed the simulation of molecules. All the authors contributed to discussions of the results and writing the manuscript. P.O.F. and A.K.F. supervised the project.

## Section: Code availability

The code that is deemed central to the conclusions is available from the corresponding author upon reasonable request. The data that supports the findings of this study (generated molecules) are available at 10.5281/zenodo.7827952

## Section: Competing interests

Owing to the employments and consulting activities of A.I.G., A.S.B., and A.K.F., they have financial interests in the commercial applications of quantum computing. P.O.F. and K.A. are employees of (P.O.F. is a stake holder in) Gero PTE. LTD. and hence may have financial interests in commercial applications of quantum or hybrid AI/ML systems for drug discovery.

## Section: Contributor Information

P. O. Fedichev, Email: peter.fedichev@gero.ai

A. K. Fedorov, Email: akf@rqc.ru

## Section: Associated Data › Data Availability Statement

The code that is deemed central to the conclusions is available from the corresponding author upon reasonable request. The data that supports the findings of this study (generated molecules) are available at 10.5281/zenodo.7827952


---

# [Identification of Characteristic lncRNA Molecular Markers in Osteoarthritis by Integrating GEO Database and Machine Learning Strategies and Experimental Validation]

- **Authors:** Qiao Zhou, Jian Liu, Ling Xin, Yanyan Fang, Yajun Qi, Yuedi Hu
- **Issuer:** Sichuan da xue xue bao. Yi xue ban = Journal of Sichuan University. Medical science edition
- **Type:** Scientific article
- **Published:** 2023-09-01
- **DOI:** 10.12182/20230960101
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37866944/
- **Licence:** CC-BY-NC

## Section: Abstract

Abstract目的利用GEO（Gene Expression Omnibus）数据库联合机器学习筛选骨关节炎（osteoarthritis, OA）特征性的长链非编码RNA（lncRNA）分子标志物。方法纳入185例OA及76例正常健康人样本，GEO数据库筛选数据集得出差异表达lncRNA，通过随机森林（randomforest, RF）、最小绝对收缩和选择算子（LASSO）逻辑回归、支持向量机递归特征消除（SVM-RFE）3种算法筛选候选的lncRNA模型，绘制受试者操作特征曲线评价模型。收集临床OA患者30例和正常对照15例的外周血，测定免疫炎症指标，RT-PCR定量分析外周血单核细胞lncRNA分子标志物的表达，Pearson分析lncRNA与免疫炎症指标的相关性。结果LASSO得出14个关键标志物，SVM-RFE算法确定6个基因，RF算法确定24个基因。Venn图筛选得出3种算法的重叠基因，包括HOTAIR、H19、MIR155HG和NKILA。受试者工作特征曲线显示这4个lncRNA的曲线下面积均大于0.7。RT-PCR法发现与正常对照组相比，HOTAIR、H19、MIR155HG在OA患者外周血单核细胞中相对表达量升高，NKILA表达量下降（均P<0.01），结果与生物信息学预测结果相一致。Pearson相关性分析表明选定的lncRNA与临床免疫炎症指标相关。结论HOTAIR、H19、MIR155HG和NKILA可作为OA临床诊断分子标志物，且与临床免疫炎症指标相关。Keywords: 骨关节炎, 长链非编码RNA, 机器学习策略, 诊断标志物, 免疫炎症

## Section: Text

骨关节炎（osteoarthritis, OA）是慢性关节疼痛和残疾的主要原因之一[1]。OA早期诊断困难，目前对OA的治疗限于症状缓解药物和全膝关节置换术，故寻找新的、可行的生物标志物对OA的早期诊断和治疗具有重要意义[2]。

长链非编码RNA（long non-coding, lncRNA）是长度超过200个核苷酸非编码内源RNA，参与OA的发病[3]。lncRNA H19在OA患者外周血[4]中和软骨细胞[5]中高表达，参与炎症反应和软骨细胞代谢；lncRNA HOTAIR在OA患者的外周血单核细胞（peripheral blood mononuclear cell, PBMC）[6]和软骨细胞[7]中均高表达；lncRNA GAS5参与骨疾病的发生发展[8]。这些lncRNA参与OA关节内或外周血免疫炎症细胞浸润过程。免疫浸润的枢纽基因和调控机制是OA研究的热点。文献研究也揭示了外周免疫细胞比值在OA中的预后价值[9]。但鲜有文献研究OA免疫炎症细胞浸润相关的lncRNA分子标志物，及其与OA患者免疫炎症指标的相关性。机器学习则是从大数据中进行算法模型的构建，在疾病亚型识别、生物标志物发现等方面有广泛的应用空间[10]。

本研究从GEO（Gene Expression Omnibus）数据库中获取OA的RNA测序数据，结合机器学习，对差异表达lncRNA进行深度筛选。受试者工作特征（receiver operating characteristic, ROC）曲线评估算法的准确性，以鉴定候选的lncRNA分子诊断标志物。临床试验中加以验证，分析候选lncRNA与OA患者免疫炎症的相关性，以期发现OA中可行的免疫炎症相关生物标志物，为临床OA的早期诊断和治疗提供新的方向。

## Section: 资料和方法

基因数据集信息

特异基因引物序列

## Section: 资料和方法 › 数据收集和数据处理

数据集（GEO）数据库（https://www.ncbi.nlm.nih.gov/geo/）的搜索关键词: “Osteoarthritis” “Homo sapiens” “Expression profiling by array”。筛选标准如下：微阵列数据集参考骨关节炎RNA测序数据；包括OA患者样本和健康正常人样本。最终，筛选出5个数据集：GSE43270[11]、GSE51588[12]、GSE117999[13]、GSE169077和GSE48556[14]，下载芯片中矩阵及平台文件，共有261个组织样本，包括72个软骨组织（GSE43270、GSE117999和GSE169077），50个胫骨平台样本（GSE51588）和139个外周血单核细胞样本（GSE48556），共包括76个正常健康人样本和185个OA患者样本，具体数据见表1。基于R语言的combat消除多个数据的批次效应[15]，RMA（robust multichip average）[16]对数据进行预处理（如表达式计算、归一化、背景校正）。

基因数据集信息

## Section: 资料和方法 › 差异表达的lncRNA筛选

使用R软件（4.2.0版本）中的Limma包筛选整合的基因表达矩阵中OA的差异表达的lncRNA。以矫正后的adj.P<0.05和|log2FC(fold change)|≥1作为筛选条件，筛选上调和下调的差异基因，基于R中的“RobustRankAggreg, RRA”包对差异表达的lncRNA进行进一步识别，得到稳定的lncRNA分子标志物。这种RRA方法可以最小化多个数据集的偏差。

## Section: 资料和方法 › 候选的lncRNA分子标志物的筛选与验证

3种算法被用于筛选候选的lncRNA，包括随机森林（randomforest, RF）[17]、最小绝对收缩和选择算子（LASSO）逻辑回归[18]、支持向量机递归特征消除（SVM-RFE）[19]。RF算法运用R包“randomForest”（包含mtry和trees参数）构建RF分类识别模型，其中mtry参数的取值方法为输入变量数量开平方根，trees为RF中包含的决策树数目（默认为500）。使用R包“glmnet”进行LASSO逻辑回归调查。该法有赖于交叉验证（cross validation）方法筛选参数，方法如下：用训练集（正常健康人数据）算参数及系数，用验证集（OA患者数据）来算对应的残差平方和，然后根据10次交叉验证结果的残差平方和的平均值选取LASSO中参数，binomial回归算法得最优模型，最小lambda被认为是最优的。SVM-RFE算法是采用5倍交叉验证的方法，对插入符号包中具有RFE功能的特征基因进行筛选。利用训练数据集训练SVM，得到相应的参数；选择公式(1)的排序准则计算所有特征在该准则下的排序准则分数；在验证集中剔除对应于最小得分的特征。执行上述过程进行5次交叉验证。这种特征选择的过程实际上是一个序列后向选择（sequence backward selection, SBS）的过程。排序准则公式如(1)，其中和分别表示完整SVM的权重和假设剔除第P个特征后SVM的权重，的表示形式如(2)，i、j表示循环变量；y表示类别标记；N表示样本数目；表示核函数；和由解算SVM对偶优化问题得到。绘制SVM-error和SVM-Accuracy图形。上述过程都是基于R包构建。然后，维恩图（venn diagram, Venn）绘制上述3种分类模型中的重叠基因。为了深入检测重叠基因的功性，在ROC曲线调查的基础上进行评估，并计算曲线下面积（area under the curve, AUC），评估算法的预测效果。双侧P<0.05为差异有统计学意义。

## Section: 资料和方法 › 临床标本收集

本研究选取安徽中医药大学第一附属医院风湿免疫科于2022年11月–2023年2月确诊的30例未接受药物治疗的OA患者。诊断标准参考2018年中华医学会风湿病学分会修订的《骨关节炎诊断及治疗指南》[20]。X线检查根据Kellgren-Lawrence标准[21]符合1、2、3级的患者。其中11名男性，19名女性，平均年龄为（56.63±12.06）岁。此外，还招募了同期体检中心健康个体作为对照组，排除标准：①合并骨关节炎、类风湿关节炎等风湿病的患者；②合并循环系统、呼吸系统、造血系统等疾病的患者；③孕妇或哺乳期女性的患者；④精神病患者。对年龄、性别进行一对一倾向性匹配，纳入15例作为对照组，其中8例男性，12例女性，平均年龄为（53.60±7.72）岁。两组一般资料差异无统计学意义。安徽中医药大学附属第一医院伦理委员会对这项工作进行了评审和批准（伦理号：No. 2022MCZQ01）。

## Section: 资料和方法 › 免疫炎症指标测定

采用全自动生化分析仪（日立HITACHI7600）检测全血生化指标，包括免疫球蛋白A（immunoglobulin A, IgA）、C反应蛋白（C-reactive protein, CRP）、白细胞介素6（interleukin 6, IL-6）、补体4（complement 4, C4）、补体3（complement 3, C3）、免疫球蛋白M（immunoglobulin M, IgM）、红细胞沉降率（erythrocyte sedimentation rate, ESR）、免疫球蛋白E（immunoglobulin E, IgE）、免疫球蛋白G（immunoglobulin G, IgG）。

## Section: 资料和方法 › RT-PCR定量分析

采用密度梯度离心法分离两组样本PBMC。收集细胞沉淀，用Trizol法提取RNA。RNA的数量使用Nano Drop分光光度计（NanoDrop Technologies, Wilmington, NC, USA）测量。RT试剂盒中使用gDNA Eraser（TaKaRa, Shiga, Japan）生成cDNA。表2列出了qRT-PCR中使用的引物。内参基因为GAPDH。相对表达值均计算为2−ΔΔCt。

特异基因引物序列

## Section: 资料和方法 › 统计学方法

计量资料采用表示，所有样本均用Kolmogorov-Smirnov检验正态性，若符合正态性和方差齐的数据，组间比较采用两独立样本t检验，不符合则选取非参数检验。相关性分析采用Spearman或Pearson分析。一对一倾向性匹配法运用SPSS中倾向匹配得分工具实现。 P<0.05为差异有统计学意义。

## Section: 结果

Eliminating the batch effect of the data with combat function

Combat函数消除数据的批次效应

A, Five data sets before normalization. B, After normalization of the five data sets.

Volcano plot of differentially expressed lncRNAs in the five datasets

5个数据集差异表达lncRNA火山图

Black represents all differentially expressed lncRNAs, red represents lncRNAs with log2FC>0, and green represents lncRNAs with log2FC<0.

差异表达最显著的前10个lncRNA

LASSO algorithm was used to screen out 14 lncRNAs

LASSO算法筛选14个lncRNA

A, Each curve in the figure represents the change trajectory of each independent variable coefficient, the vertical coordinate is the value of the coefficient, the lower horizontal coordinate is log (λ), and the upper horizontal coordinate is the number of non-zero coefficients in the model at this time. B, The vertical coordinate is Binomial Deviance (dichotomous anomaly), which can be interpreted as the magnitude of the error of the model. There are two dashed lines of values in the figure, the left is the line with the lowest error and the right is the line with fewer features.

Support vector machine recursive feature elimination (SVM-RFE) algorithm was used to screen out 6 key lncRNAs

SVM-RFE算法筛选出6个关键lncRNA

Graph A is SVM error and graph B is SVM accuracy. 5×CV represents 5-fold cross-validation. The number 6-0.173 in Fig 4A indicates that the error rate for the six trait genes screened out was 0.173. The number 6-0.827 in Fig 4B indicates that the accuracy rate of the six trait genes screened out was 0.827.

Random forest (RF) algorithm was used to screen out 24 feature lncRNAs

RF算法筛选24个特征lncRNA

A, The dynamics of the random forest prediction error versus the number of random trees, with the vertical axis of error representing the error; the horizontal axis of trees representing the tree number. The black, red, and green lines show how the false positive rate varies with the number of decision trees for all samples, samples from osteoarthritis patients, and samples from normal healthy people in the five datasets, respectively. B, The 24 genes sorted by importance.

Screening and validation of key lncRNAs

关键lncRNA的筛选及验证

A, Venn diagram was used to screen for overlapping genes identified by the three algorithms. B, ROC curves for validating diagnostic efficacy after fitting key lncRNA to one variable.

两组免疫炎症指标的变化

RT-PCR to detect the expression of lncRNAs molecular markers

RT-PCR检测lncRNA分子标志物的表达

lncRNA分子标志物与免疫炎症指标的Pearson分析

## Section: 结果 › 差异表达的lncRNA识别

对5组数据集进行了标准化处理，从图1A看出不同的批次之间各自成团，批次之间有比较明显的差别，存在一定的批次效应。图1B不同批次的样品重叠在一起，表明批次效应校正成功。使用OriginLab构建整合基因集中差异表达lncRNA的火山图，见图2。进一步通过R语言RRA法筛选出105个差异lncRNA，包括30个上调和75个下调的lncRNA。将所得差异表达lncRNA对应统计量进行汇总，按校正后的P值即adj.P.Val从小到大进行排序，一般认为adj.P.Val值越小代表差异表达越显著，依据adj.P.Val值选择差异表达最显著的前10个lncRNA，见表3。

Eliminating the batch effect of the data with combat function

Combat函数消除数据的批次效应

A, Five data sets before normalization. B, After normalization of the five data sets.

Volcano plot of differentially expressed lncRNAs in the five datasets

5个数据集差异表达lncRNA火山图

Black represents all differentially expressed lncRNAs, red represents lncRNAs with log2FC>0, and green represents lncRNAs with log2FC<0.

差异表达最显著的前10个lncRNA

## Section: 结果 › 候选的lncRNA分子标志物的筛选与验证

运用3种算法对候选的105个差异lncRNA进行识别，其中LASSO算法得出14个关键的生物标志物（图3）。SVM-RFE算法确定了6个基因作为必要的生物标志物（图4），图4A是5倍交叉验证后曲线变化的错误率，图中6-0.173表示筛选出的6个特征性基因的错误率是0.173，越接近0，表明错误率越低；图4B是5倍交叉验证后曲线变化的准确率，图中6-0.827表示筛选出6个特征性基因的准确率是0.827，越接近1，表明准确率越高。除此之外，RF算法认为24个基因是重要的生物标志物（图5A，5B）。Venn图绘制3种算法的重叠基因（图6A），最终得到4个lncRNA，其中HOTAIR、H19、MIR155HG上调（log2FC≥1），NKILA下调（ log2FC<−1）。ROC曲线显示，它们可能是有价值的生物标志物，AUC分别为0.9415〔95%置信区间（confidence interval, CI）：0.9010～0.9820〕（HOTAIR）、0.8016（95%CI：0.7244～0.8788）（H19）、0.9751（95%CI：0.9475～0.9991）（MIR155HG）、0.7957（95%CI：0.7165～0.8748）（NKILA）（图6B）。

LASSO algorithm was used to screen out 14 lncRNAs

LASSO算法筛选14个lncRNA

A, Each curve in the figure represents the change trajectory of each independent variable coefficient, the vertical coordinate is the value of the coefficient, the lower horizontal coordinate is log (λ), and the upper horizontal coordinate is the number of non-zero coefficients in the model at this time. B, The vertical coordinate is Binomial Deviance (dichotomous anomaly), which can be interpreted as the magnitude of the error of the model. There are two dashed lines of values in the figure, the left is the line with the lowest error and the right is the line with fewer features.

Support vector machine recursive feature elimination (SVM-RFE) algorithm was used to screen out 6 key lncRNAs

SVM-RFE算法筛选出6个关键lncRNA

Graph A is SVM error and graph B is SVM accuracy. 5×CV represents 5-fold cross-validation. The number 6-0.173 in Fig 4A indicates that the error rate for the six trait genes screened out was 0.173. The number 6-0.827 in Fig 4B indicates that the accuracy rate of the six trait genes screened out was 0.827.

Random forest (RF) algorithm was used to screen out 24 feature lncRNAs

RF算法筛选24个特征lncRNA

A, The dynamics of the random forest prediction error versus the number of random trees, with the vertical axis of error representing the error; the horizontal axis of trees representing the tree number. The black, red, and green lines show how the false positive rate varies with the number of decision trees for all samples, samples from osteoarthritis patients, and samples from normal healthy people in the five datasets, respectively. B, The 24 genes sorted by importance.

Screening and validation of key lncRNAs

关键lncRNA的筛选及验证

A, Venn diagram was used to screen for overlapping genes identified by the three algorithms. B, ROC curves for validating diagnostic efficacy after fitting key lncRNA to one variable.

## Section: 结果 › 临床患者免疫炎症指标变化

与正常对照组相比，OA患者中炎症指标（ESR、CRP、IL-6）、免疫球蛋白（IgA、IgE）、补体C4升高，差异有统计学意义（P<0.05）。见表4。

两组免疫炎症指标的变化

## Section: 结果 › RT-PCR法检测lncRNA分子标志物的表达和相关性分析

RT-PCR结果显示，与正常人相比，OA患者PBMC中HOTAIR、H19、MIR155HG相对表达量升高（P<0.01），NKILA相对表达量下降（P<0.01），与生物信息学分析结果一致（图7）。Pearson相关性分析表明，H19与IgA（r=0.439，P=0.018）呈正相关，MIR155HG与CRP（r=0.785，P<0.001）、IgM（r=0.454，P=0.008）、IL-6（r=0.610，P<0.001）呈正相关，NKILA与ESR（r=−0.425，P=0.021）呈负相关，与IL-6（r=0.650，P<0.001）呈正相关，HOTAIR与CRP（r=0.589，P=0.001）、IL-6（r=0.492，P=0.006）和IgE（r=0.445，P=0.014）呈正相关。表明筛选出的4个特征性lncRNA与免疫炎症指标存在相关性（表5）。

RT-PCR to detect the expression of lncRNAs molecular markers

RT-PCR检测lncRNA分子标志物的表达

lncRNA分子标志物与免疫炎症指标的Pearson分析

## Section: 讨论

OA的发生发展涉及复杂的生物学反应[22]。由于缺乏早期检测和评估治疗结果的有效方法，目前，生物标志物的发现成为辅助疾病监测的前瞻性方法。本研究基于GEO测序数据集，结合机器学习策略，寻找OA新的免疫炎症相关的分子标志物，并在OA患者外周血标本中进行验证，为OA的早期诊断和治疗提供新的思路和研究方向。

在本研究中，通过筛选5个OA软骨细胞全基因组基因表达谱，整合差异表达的lncRNA，确定了105个差异lncRNA，包括30个上调和75个下调的lncRNA。根据adj.P.Val值从小到大排序，表3列出前10的lncRNA，包括下调的NKILA、MEG3和C15orf54（log2FC<-1），上调的MIR155HG、HOTAIR、H19、LINC00973、MEG9、PART1和C3orf79（log2FC≥1）。 还有一些lncRNA值得关注，如上调的XIST[23]、TUG1[24]、DANCR[25]、MIAT[26]，下调的MEG3[27]、THRIL[28]、GAS5[8]、ATB[29]。这些lncRNA可能与OA的发病机制有关。

通过集成3种不同的算法，得到3种算法的重叠基因，分别是HOTAIR、H19、MIR155HG和NKILA。ROC曲线结果也表明，4个生物标志物AUC均大于0.7，表明预测结果具有较强的准确性。HOTAIR在OA组织中高表达，通过抑制软骨细胞增殖，促进细胞凋亡和细胞外基质降解导致软骨细胞的功能障碍[30]。lncRNA NKILA通过与核因子κB/核因子κB的抑制蛋白（nuclear factor kappa-B/inhibitor of NF-κB, NF-κB/IκB）复合物结合来覆盖IκB的磷酸化位点，从而抑制NF-κB的过度活化[31]。lncRNA MIR155HG也称为B细胞整合簇。MIR155HG的表达与免疫细胞、分子和免疫检查点分子的浸润水平显著相关[32]。MIR155HG参与破骨细胞的调节。在骨质疏松小鼠中，MIR155HG通过AMP依赖的蛋白激酶（AMP-activated protein kinase, AMPK）途径靶向瘦素受体基因来抑制破骨细胞活化[33]。MIR155HG上调可能是OA炎症过程的重要因素。lncRNA H19在OA中高度表达，可能通过白介素(Interleukin，IL)-38和IL-36之间的相互作用促进OA中的炎症反应[5]。综上所述，基于3种算法的机器学习组合模型和文献调研，均表明HOTAIR、H19、MIR155HG和NKILA与OA中免疫炎症存在相关性，可作为特征性诊断的标志物，但其诊断意义还需要大量的实验来验证。

临床样本验证结果显示，与正常健康组相比，HOTAIR、H19、MIR155HG相对表达量升高，NKILA相对表达量下降，结果与生物信息学预测结果相一致，表明本研究整合预测策略的可行性。相关性分析显示4个特征性lncRNA与免疫炎症指标的相关性。IL-6在软骨病理的发展中起着关键作用，OA患者血清或滑液中IL-6水平的增加与疾病的严重程度相关；然而，IL-6也增加了抗分解代谢因子的表达，具有保护作用；表明IL-6在OA中起双重作用，可能是由IL-6经典与反式信号传导的不同效应引起的[34]。IgE介导的肥大细胞通过高亲和力IgE受体（FcεRI），导致促炎细胞和降解介质（包括类胰蛋白酶）的释放，导致组织损伤、炎症和肥大细胞活化，导致OA的发展和进展[35]。CRP和ESR可作为炎症反应的非特异性指标[36]。研究发现CRP是影响OA诊断和严重程度分级的独立因素[37]。免疫球蛋白亚型在OA患者血清中表达升高，参与了OA发病过程[38]。例如，IgA[39]和 IgM[40]作为机体内高亲和力抗体，参与免疫应答反应。相关性分析也表明，MIR155HG、NKILA、HOTAIR与炎症指标（CRP、ESR和IL-6）、免疫指标（IgE、IgA和IgM）存在相关性，表明特征性的lncRNA参与了OA的免疫炎症反应，在OA临床患者应用中有重要意义。

本研究预测的结果来源于GEO数据库多个实验测序数据的组合，多个算法整合机器学习策略来识别特征性基因，信息利用度方面较单个数据集和小样本的实验验证更全面和完善。然而，本研究存在一定的局限性：样本量相对较小，软骨标本难获取，因此选择外周血标本进行验证。此外，OA患者之间的个体差异，包括社会经济地位、疾病严重程度和疾病持续时间，可能会影响结果的准确性。因此，进一步大样本的体内外实验验证特征性的lncRNA在OA免疫炎症中的确切机制将是我们下一步研究的目标。

* * *

作者贡献声明 刘健负责论文构思，忻凌负责正式分析，周巧和齐亚军负责调查研究，周巧、方妍妍和胡月迪负责可视化，周巧负责初稿写作和审读与编辑写作。所有作者已经同意将文章提交给本刊，且对将要发表的版本进行最终定稿，并同意对工作的所有方面负责。

利益冲突 所有作者均声明不存在利益冲突

## Section: Funding Statement

安徽省高等学校科学研究项目（自然科学类）重点项目（No. 2022AH050449）、安徽省第12批“115”创新团队（皖人才办〔2019〕1号）、安徽省名中医刘健工作室建设项目（中医药发展秘〔2018〕11号）和安徽省中医药领军人才项目（中医药发展秘〔2018〕23号）资助

## Section: Contributor Information

巧 周 (Qiao ZHOU), Email: 780149795@qq.com.

健 刘 (Jian LIU), Email: liujianahzy@126.com.


---

# iEdgeDTA: integrated edge information and 1D graph convolutional neural networks for binding affinity prediction

- **Authors:** Natchanon Suviriyapaisal, Duangdao Wichadakul
- **Issuer:** RSC advances
- **Type:** Scientific article
- **Published:** 2023-08-24
- **Language:** en
- **DOI:** 10.1039/d3ra03796g
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37636509/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractArtificial intelligence has become more prevalent in broad fields, including drug discovery, in which the process is costly and time-consuming when conducted through wet experiments. As a result, drug repurposing, which tries to utilize approved and low-risk drugs for a new purpose, becomes more attractive. However, screening candidates from many drugs for specific protein targets is still expensive and tedious. This study aims to leverage computational resources to aid drug discovery by utilizing drug-protein interaction data and estimating their interaction strength, so-called binding affinity. Our estimation approach addresses multiple challenges encountered in the field. First, we employed a graph-based deep learning technique to overcome the limitations of drug compounds represented in string format by incorporating background knowledge of node and edge information as separate multi-dimensional features. Second, we tackled the complexities associated with extracting the representation and structure of proteins by utilizing a pre-trained model for feature extraction. Also, we employed graph operations over the 1D representation of a protein sequence to overcome the fixed-length problem typically encountered in language model tasks. In addition, we conducted a comparative analysis with a baseline model that creates a protein graph from a contact map prediction model, giving valuable insights into the performance and effectiveness of our proposed method. We evaluated the performance of our model using the same benchmark datasets with a variety of matrices as other previous work, and the results show that our model achieved the best prediction results while requiring no contact map information compared to other graph-based methods.

## Section: Introduction

The typical drug development process is expensive, time-consuming, and requires considerable time to confirm a drug's safety. Over the past few years, COVID-19 has had direct and indirect effects worldwide. We could treat it quickly through drug repurposing, using the existing medicines with safety approval for purposes different than their original intent.1–3

With the evolution of machine learning, several computational techniques and strategies demonstrated their effectiveness for various applications, including predicting drug-target binding affinity (DTA),4,5 which is a task predicting a score that indicates the strength of drug-target pair interaction and can be used to estimate how well a candidate drug can bind with a target protein. As a result, binding affinity has become a criterion for selecting candidate compounds and sped up the entire drug development process. Furthermore, the predicted compounds from DTA can be used in further experiments to obtain a final result rather than developing a new drug whose time cost and financial expenses are incredibly high.6,7

Although early computational models for predicting drug-protein interactions were developed by manually extracting drug and target properties, they required much biological and chemical knowledge. Because drugs and proteins are represented as text sequences by manual extraction, some information, such as structural information, was lost. While known structural proteins having crucial information, such as docking sites, can use computational techniques to carry out the results, unknown-structural proteins, which have less information except for the sequence, become challenging.

In earlier research, DTA prediction is often treated as a binary classification task8–10 by predicting whether a drug and target protein interact. However, to make it more realistic, most recent works predict a value of affinity score to determine the strength of interaction and switching to a regression task.

Recently, several machine learning models have shown remarkable results in DTA prediction. For example, the early work DeepDTA11 took an advancement of convolution neural network (CNN) applied to DTA prediction by using a 1-dimensional (1D) convolution technique to capture the patterns of data from drug and protein sequences, then passed those representations through several hidden layers and regressed to get the DTA scores. On the other hand, MT-DTI12 took advantage of a natural language processing (NLP) technique called “Transformer” to extract molecular representation by treating a molecule sequence as a text and applying the same method as DeepDTA to get a prediction result.

To acquire a better representation of data, GraphDTA13 proposed a graph-based representation learning of drug molecules capable of extracting the structural information and enhancing the predictive performance while representing a protein in a 1D-CNN network. The DGraphDTA14 was an extension of the GraphDTA in which drug molecules and protein sequences were defined as a 2D graph, employing a protein structure prediction approach called contact map to predict protein structure. The authors of GraphDTA also proposed GEFA,15 an early fusion method that combined drug and protein features in the early stage before extracting their representations. The authors contrasted GEFA with GraphDTA, a late fusion method that learned the representations of drug and protein separately. In addition to DGraphDTA, the same authors also released a new work called WGNN,16 which improved the representation using weighted graphs with the weights determined from the contact strength of the contact map prediction.

Another graph-CNN method called MGraphDTA17 used a technique called multi-scale to help a model learn to capture the local and global structures of a compound or a protein simultaneously by learning a variety of scales from shallow to deep and aggregating features from all scales to get a multi-scale feature for each drug and protein. Apart from the graph-based method, SMT-DTA18 achieved a promising result for this task using a transformer-based model trained with a semi-supervised technique by setting one task as a masked language model and another as a DTA task where both shared parameters.

However, these models frequently describe drug and protein structures but ignore the relationship and information between nodes, which is not a natural way to represent compounds or proteins formed by atoms and bonds. In this paper, we propose an approach called iEdgeDTA to predict binding affinity by utilizing one of the variants of graph neural network (GNN) known as graph convolutional network (GCN)19 and improve it by including a multi-dimensional edge feature in an encoding space of the compound. We also considered using a pre-trained model for extracting a node embedding to use as a protein node (an amino acid) representation fed to GNN by constructing a 1D graph from the sequence and incorporating the global feature of the protein. It is noteworthy that the whole process used only SMILES and protein sequences.

The main contribution of this study can be summarized as follows.

• We enhanced drug molecular representation by adding edge information between each node of a drug molecule into graph operation.

• We introduced a 1D sequential graph and pseudo structure to represent the protein sequence and utilized GNN to overcome a fix-length problem.

• We extracted protein features from a sizeable pre-trained model and used it to obtain a global feature. So our method uses both node-level and sequence-level features to learn a variety of scales and get a better representation.

## Section: Materials and methods › Benchmark datasets

To compare the performance of our model with other previous works, we followed DeepDTA to use the same benchmark datasets, Davis11,20 and KIBA.11,21

Davis dataset contains 30 056 drug-target interactions of 68 inhibitors and 442 kinase proteins that cover more than 80% of the human catalytic protein kinome. It uses the dissociation constant (Kd) value to describe the strength of the interaction. Similar to DeepDTA and other works, we transformed the Kd value into a log scale called pKd (see DeepDTA11).

KIBA dataset also comprises interactions of kinase inhibitors but constructed from a different bioactivity source, including Ki, Kd, and IC50. The KIBA score was made by optimizing these values, and we used this score to determine the binding affinity for this task. The original KIBA database contains a bioactivity matrix comprising 52 498 compounds and 467 targets, including 246 088 observations, and He et al.22 removed all drugs and proteins with fewer than ten interactions to get a filtered dataset, which we used in this work. The filtered KIBA dataset comprises 118 254 drug-target interactions of 2111 and 229 unique drugs and proteins.

## Section: Materials and methods › Drug representation

Provided by the benchmark datasets, our input drug compound is in SMILES format, and we utilized TorchDrug23 and RDKit library24 to extract node feature, edge features, and adjacency lists from drug SMILES to generate a graph as illustrated in Fig. 1. We represented node and edge features as shown in Table 1 with one-hot vectors (see ESI Table S1† for detailed features). Edge features make our data more elaborate and informative. In contrast, earlier work only used edges to connect nodes or weighted edges to express an edge's importance. Other work, for example, RGCN,25 proposed using independent weight computation for different edge types.

We employed a multidimensional edge feature in this study to pass additional information to each convolution layer. The edge characteristics comprise bond type, bond stereo, and stereo atom, and the drug compound graph is a symmetric network representing a bidirectional graph for our configuration. To capture comprehensive information, including both the neighborhood and the individual node itself, we incorporated self-loops for all nodes in the graph. This self-loop ensures that the model learns the state embedding, which contains the surrounding nodes' context and the node's features.

## Section: Materials and methods › Protein representation

One of the most difficult protein-related issues is how we can extract helpful protein features based on only its sequence. In contrast to drugs, whose structure information is given in SMILES format, proteins are considerably more complex. Although we can independently extract protein characteristics based on each amino acid property, such as residue-symbol, aliphatic, and polarity, the function is altered when amino acids link together and form a complex structure. Therefore, in this study, we adopted a pre-trained model known as “Evolutionary Scale Modeling” or ESM,26 a transformer protein language model, to extract valuable and dependable protein features from its sequence (details in Pre-trained protein language section).

Many proteins have unknown structures. To extract structural information, we require a very complex model, such as AlphaFold,27 which is resource-intensive to yield a precise result. In addition, prior work learned patterns from protein sequences using CNN or NLP, whereas other structural models used the predicted protein structure of other trained models. This paper proposes a novel way to solve the fixed-length problem of CNN and NLP using a GNN. First, we establish a pseudo-structure in which each amino acid represents a node and create an edge from its adjacency node in the sequence. This pseudo-structure allows us to utilize graph message-passing operations in a sequence string. We illustrate the process of protein graph construction in Fig. 2.

With the constrained sequence length to be fewer than 1024 amino acids of the ESM, while about 20–25% of our protein sequences comprise more than 1024 amino acids (ESI Fig. S1†), we must introduce a way to approximate long-sequence protein feature. Our approach divided a protein sequence into several pieces to make sub-sequences, where one sub-sequence with a fixed length of 500 (windows) and a step of 5 (stride), having 495 amino acids overlapping with the consecutive sub-sequence for a better approximation, and the final sequence feature being the average of all sub-sequences as described in Algorithm 1 and depicted in Fig. 3.

## Section: Materials and methods › Pre-trained protein language

To achieve a more accurate representation of a protein sequence than its amino acid features, we employed a model that has been pre-trained with a vast amount of protein data and can predict a node feature from a protein sequence.

In our study, we conducted experiments using two pre-trained models, namely ProtTrans28 and Evolutionary Scale Modeling (ESM).26 The findings of these experiments are presented in the Module analysis section. Both pre-trained models employ a self-supervised transformer-based model with masking, in which each input token is corrupted by randomly substituting an amino acid with a unique token. Then, they were trained to predict the missing token from the corrupted sequence to learn a pre-training task.

ProtTrans28 is a language model taken from the NLP technique. It has many variants, and the one we experimented on was the T5-XL model, an encoder-decoder model trained on the BFD dataset29,30 and fine-tuned on the UniRef50 dataset,31 which contains 2122 and 45 million protein sequences, respectively. The T5-XL model extracts protein features by employing a transformer model and predicting token-level and protein-level classification tasks. We extracted the embedding features with 1024 dimensions per residue from the last hidden layer before predicting both tasks of the transformer model.

ESM26 is also a transformer-based language model developed by Facebook research, trained on only the UniRef90 dataset32 comprising 98 million diverse protein sequences with 1280 dimensions of embedded features per residue. However, ESM has a restriction on sequence length, as it was trained with a fixed context size of 1024 tokens for positional embedding. Therefore, for protein sequences that are longer than 1024 amino acids, they used the random crop to reduce the protein sequence length to 1024 tokens for every training epoch to get sample sequences.

## Section: Materials and methods › Model architecture

The model used in our study takes both inputs, a protein sequence and a drug compound in SMILES format, and transforms them into graph structures (Fig. 4). The drug branch (Edge-GCN layer) creates a graph using an actual contact, e.g., the graph's edges representing bonds between two atoms. On the other hand, the protein branch (GCN layer) creates a 1D graph from its sequence by sequentially connecting each amino acid to its adjacent neighbors instead of an actual contact, which is a complex piece of information. Instead of employing a fixed-length technique, such as padding or truncating, which is necessary for CNN and NLP, we used the whole sequence for feature extraction and model calculation with the GNN technique, which accepts an arbitrary-length input. Furthermore, due to the potentially extensive length of protein sequences, which requires a vast number of GCN layers to acquire information from the entire sequence (a single GCN layer can only gather information from neighboring nodes within one hop), we introduced an additional branch (Linear layer) for extracting a global feature, a sequence level feature. This feature is achieved by averaging the node-level features from the sub-sequences of the entire sequence and passing them through a linear layer to learn a comprehensive representation.

In this study, our focus is on predicting affinity scores, which are continuous values. To accomplish this, we employed GCN as a layer for feature extraction to produce the node-level representation of both drug and protein, using sequence-level features to create the whole protein sequence representation and a fully connected layer to gather information and produce the predicted affinity scores.

## Section: Materials and methods › Model architecture › Graph neural network

Convolutional Neural Network (CNN) is widely used in many tasks involving data in Euclidean space, such as 1D (sequence) or 2D (grid) data, but in a task with non-euclidean data like a graph, we need a new method to handle this. Due to their capacity to handle graph structure data, GNN have recently garnered a great deal of attention, and several graph data types, such as social networks and drug-protein graphs, have become popular. This paper focuses on one of the variations of GNN that apply convolution over a graph, the Graph Convolutional Network (GCN),19 initially developed to address semi-supervised tasks like node classification. In this work, we will use GCN for graph-level feature extraction. The propagation rule of GCN consists of message passing, aggregate, and feature update, formulated as eqn (1),19 and illustrated in Fig. 5A.

where Ã is an adjacency matrix of a graph with a self-loop connection. D̃ is the diagonal node degree matrix of Ã in measuring the degree of each node to maintain the scale of the output feature vector, while H(l) is a previous hidden layer output. W(l) represents learnable parameters, and σ is an activation function such as the Rectified Linear Unit (ReLU).

## Section: Materials and methods › Model architecture › Graph convolutional network with edge feature

To better represent a drug graph with a multi-dimensional edge feature from the preprocessing stage, we improved a graph message passing by including an edge feature in every convolution step as part of the GCN propagation rule in eqn (2) called Edge-GCN illustrated in Fig. 5B.

In which H(l) in eqn (1) is replaced with H(l) + EW(l)e, where E is a multi-dimensional edge feature and W(l)e is a learnable parameter that transforms the dimension of an edge feature into the dimension of a node feature. Note that the edge in the drug graph is undirected, which means that the connected nodes utilize the same edge feature for message propagation.

In our architecture, we transformed drug SMILES and protein sequences into a graph before giving them to two GCNs, each consisting of a three-layer convolutional network for extracting a representation from a graph. A global pooling layer is placed after the two GCNs to ensure that a graph-level representation with the same dimension is obtained. Each operation may be regarded as a hyperparameter when calculating a global pooling layer as a sum, mean, or max. In this work, we used the global mean pooling layer, eqn (3), where x is a feature matrix for each node in the GCN output. N is the number of nodes in the sequence, and r is the pooling output representation with a size of (1, F), where F is the number of output channels for the last layer.

## Section: Materials and methods › Model architecture › Protein global feature

Since a protein is a highly complicated substance, it is challenging to discern its general function from node-level data. Since a pre-trained model learned from an extensive model and dataset, we considered extracting the global feature by averaging a node feature from a pre-trained to obtain a per-sequence feature with 1280 dimensions for each sequence, which then passed through three fully connected layers before being concatenated to the structural representation of drug and protein.

We added batch normalization (BatchNorm)33 after every output layer in fully connected layers and graph normalization (GraphNorm)34 for GCN layers, each activated by the Rectified Linear Unit (ReLU) function. We then concatenated the representation of the drug's latent feature, protein's latent feature, and protein's global feature to two fully connected layers to predict an affinity score.

## Section: Materials and methods › Model architecture › Loss function and hyperparameter tuning

Our task is to minimize the affinity score difference between our model prediction and ground truth label during training. Since our task is a regression task, we use mean square error (MSE) as a loss function, which is calculated as the summed square of the difference between the predicted value (P) and ground truth label (Y), as shown in eqn (4).

We optimized our model via AdamW35 optimization algorithm, which improves regularization in Adam by decoupling the weight decay from the gradient update. We set a weight decay parameter as 0.01 for both datasets to prevent overfitting. In addition, we used the learning rate decay, starting from 0.001 and decaying by scaling down to 80% for every 100 epochs to improve the learning of complex patterns in the late iteration process.

We tuned most of the hyperparameters manually and selected some others from the prior work, as shown in Table 2 as we employed cross-validation techniques, and the training process took a significant amount of time to complete.

## Section: Results and discussion

We used Nvidia DGX A100 for training and testing and built our model with PyTorch and PyTorch Geometric (PyG),36 conducted model comparisons and selections based on five-fold cross-validation, and chose a candidate model to evaluate the performance over the independence test set. First, we selected the candidate model with the best result averaged from the validation set result of each fold and then evaluated the candidate model by using each fold's weight for predicting the independent test set (unseen data). Then, we calculated the final result by averaging the test results obtained from each fold. Note that we used the training part of each fold, excluding the validation part, to train the model for final evaluation (see ESI Fig. S2†).

## Section: Results and discussion › Evaluation metrics

We implemented the same metrics used by the baseline and state-of-the-art methods to make our work comparable. Since we are working on a regression problem, we used MSE and Concordance Index (CI) as the primary metrics of the DTA task. MSE is a prevalent metric used in regression tasks. It measures the difference between the predicted and actual values. A smaller MSE means the predicted value from our model is closer to the true value. Unlike MSE, the CI score is interested in the order of predictions, not the prediction value itself, and calculated by eqn (5), where bi is the prediction value for the larger affinity di, bj is the prediction value for the smaller affinity dj, Z is a normalization constant, and h(x) is the step function as shown in eqn (6).

Another metric used by some work is the Pearson correlation coefficient, eqn (7), which measures the strength of the linear relationship between two variables, predicted and ground truth in our case, where cov is the covariance between the predicted value p and the actual value y, and σ(p), σ(y) indicates the standard deviation of the predicted p and actual y respectively.

## Section: Results and discussion › Benchmarking with the state-of-the-art models

We compared our method with the previous works. To make a fair comparison, we tested the performance with the unseen data on the independent test set and reported the same evaluation metrics, including MSE, CI, and Pearson correlation coefficient with standard deviation. Note that due to different evaluation settings, we reproduced the final result of some previous work in this benchmarking section and also provided the original results reported in their papers along with the modified evaluation of our model based on their setting in ESI Table S2.†

Tables 3 and 4 show the benchmarking results of our model compared with other methods, differently representing drug compounds and proteins, including CNN-based, graph-based, and transformer. Our technique combining Edge-GCN and 1D-GCN achieved considerable improvements in MSE and CI on the Davis dataset, reaching 0.216 for MSE, 0.897 for CI, and 0.855 for Pearson correlation on the independence test set. The KIBA dataset showed that our model outperformed other methods by having the lowest MSE and highest Pearson correlation. It also had the highest CI score among other graph-based methods (same rank as MGraphDTA), while SMT-DTA, a transformer-based model, had the highest CI score at 0.894. Our model is highly effective compared to the graph-based methods, e.g., GEFA, which previously got the lowest MSE of 0.228 on Davis. Notably, our model does not use protein structure compared to existing graph-based methods that extract protein graphs from contact map prediction, and our model still gets a better result. Therefore, it may imply that the pre-trained model, i.e., ESM, learned how proteins are formed or learned some structural information.

## Section: Results and discussion › Module analysis › Batch normalization

The implementation of batch normalization was an additional effective strategy we utilized to improve the regularization of our model. Deep learning commonly uses batch normalization to normalize the input data within each mini-batch during training. By normalizing the activations, batch normalization reduces the internal covariate shift, which is the phenomenon of a shift in the distribution of layer inputs as model parameters change. This stabilization effect helps the model converge more quickly. In addition, estimating expectations and variance from many small data subsets also provides a model's regularization effect.

We illustrate the impact of batch normalization in Fig. 6. During the early epochs before the red dashed line, the model incorporating batch normalization exhibits faster convergence than the model without. However, in the later epochs, the model's mean squared error (MSE) without batch normalization decreases, indicating a better fit to the training set. Nevertheless, the results on the validation set depicted in Fig. 7 reveal that the model without batch normalization performs worse than the other models, suggesting the presence of an overfitting issue and showing how the batch normalization helps generalize the model. In summary, we achieved additional regularization without a dropout layer by incorporating batch normalization into our model, expedited the training process, and improved overall performance (see ESI Fig. S3† for the performance of the dropout layer).

## Section: Results and discussion › Module analysis › Pre-trained models

This study aims to apply graph neural network to a protein based on the protein's sequence, assuming that we cannot obtain the actual or predicted protein structure. Therefore, it would be best to utilize a pre-trained model because it has learned a massive dataset and might implicitly store some information about the protein structure. Consequently, we chose two pre-trained models to create a protein input feature for our model and evaluated their prediction performance on the Davis dataset, as shown in Table 5.

The findings indicated that both pre-trained models performed better than the baseline model (DGraphDTA), which relied on manually crafted features for protein representation. However, ESM-1v provided superior performance to PortT5, where the MSE value was 0.201, and the CI value was 0.898. As a result, we selected ESM-1v as our pre-trained model for final evaluation.

## Section: Results and discussion › Module analysis › Edge and global features

Since we could extract an edge feature of the drug compound, we also passed it to our modified GNN model to include the edge feature for every message-passing process. However, extracting an edge feature for protein is still challenging. Hence, we instead pulled out an independent global feature by averaging its pre-trained node-level feature and learning to draw out a latent property via three dense layers. The performance of introducing the compound's edge and protein's global features into the model is shown in Table 5.

The results indicated that edge features on only the drug branch could improve the performance to achieve 0.198 for the MSE value and 0.899 for the CI value. Then, we assessed the performance of the protein's global feature, and the findings indicated that this feature also helped improve the prediction result, with MSE lowering to 0.195 and CI score increasing to 0.901 for the optimal iteration.

Besides, we compared our edge feature integration method to existing methods such as RGCN, which improves prediction by employing independent weights for each relation type rather than sharing weights across all nodes and edges. In this task, the bond type is passed as a relation type consisting of a single bond, double bond, triple bond, aromatic, and self-loop, resulting in five distinct weights. As shown in Table 6, utilizing RGCN does not increase model performance on a five-fold cross-validation set. This result may be related to our approach leveraging multidimensional edge features, whereas RGCN can only accept a single feature as the relation type.

Furthermore, we incorporated our Edge-GCN approach into our baseline model, DGraphDTA, to assess the efficacy of integrating an edge feature into drug representations. In this experiment, we replaced the original GCN layers with our Edge-GCN layers in the drug branch, using the same edge feature introduced in this paper. The results are shown in Table 7, revealing that introducing an edge feature to the graph neural network improves both MSE and CI scores.

To assess the impact of individual contributions of node-level and sequence-level features for protein feature extraction, we selected a CNN architecture as our baseline due to its prevalence in prior studies and its suitability for assessing the effectiveness of our 1D-GCN in addressing the fixed-length problem. We set the hyperparameters of the CNN following GraphDTA13 work. Specifically, we fixed the protein sequence length at 1000 amino acids, padded shorter sequences, and truncated longer sequences. In Table 8, we present the results obtained from the experiment, showing the performance of the individual node-level and sequence-level features as standalone versions. These results demonstrate the improvement achieved by each feature independently and highlight their respective contributions. Moreover, integrating both node-level and sequence-level features within the 1D-GCN model yielded significant enhancements, surpassing the performance of the baseline model. This outcome shows the benefits of combining these features, further improving prediction accuracy.

## Section: Results and discussion › Module analysis › Contact map performance

Lastly, we conducted an additional analysis to investigate the influence of protein structure on our model. Specifically, we replaced a 1D sequence graph with a contact map obtained from various contact map model predictions. For this experiment, we selected three works: pconsc4,14,37 utilized by our baseline model DGraphDTA, RaptorX38 employed by GEFA, and the ESM26 contact map prediction model. These models provide a probability indicating the likelihood of an amino acid pair being in contact, where contact determination is based on a threshold set as 0.5. To conduct this analysis, we maintained consistent model architecture and froze all hyperparameters while modifying the construction of the protein graph. Additionally, we employed our 1D sequence graph in the DGraphDTA model to assess the impact of 1D-GCN in a different model setting. The results of this analysis are presented in Table 9.

Our findings revealed that the performance of the 1D-GCN setting is on par with that of a model utilizing a contact map. Furthermore, the 1D-GCN approach exhibited slightly superior performance in our work and the DGraphDTA experiment compared to the contact maps derived from other prediction models. These results indicated that the structural information obtained from contact map predictions might contain noise that could potentially degrade model performance, suggesting that achieving enhanced performance requires either a genuine contact map or highly accurate predictions. Nonetheless, our comparative evaluation highlights that the 1D-GCN approach delivers similar performance without using contact maps. Moreover, given that actual protein contact maps are a limited resource, generating experimentally determined contact maps for proteins can be difficult and time-consuming, requiring specific equipment, specialized knowledge, and substantial resources, making them less accessible and limited to specific research facilities. Many strategies employ machine learning algorithms or statistical methods to infer residue–residue contacts based on the available protein sequence. However, due to the complexity of the nature of proteins, accurately predicting contact maps remains a challenging problem that requires substantial computational resources. Our model holds promise for real-world applications, such as high-throughput virtual screening, using only protein sequences.

However, iEdgeDTA does have limitations. First, using a 1D representation poses a drawback, as the protein's folding determines the binding pocket, and the 1D model does not guarantee that the binding pocket will correspond to a series of adjacent amino acids in the sequence string. Therefore, visualizing or predicting the binding pocket solely from the 1D representation remains a challenging problem. Second, a limitation lies in the pre-trained model, which may generate noise during extracting long protein sequences, as estimated in Algorithm 1. Using a more accurate pre-trained model that can handle arbitrary sequence lengths will reduce the model's sensitivity to noise, which may improve its performance.

## Section: Conclusions

Accurate drug target affinity prediction is essential for identifying promising candidates in developing and optimizing the design of new drugs. It can also help reduce drug discovery costs and time via drug repositioning to assess if existing drugs can bind to a specific protein target. In this study, we introduced a graph-based deep learning model that enhanced the prediction performance by incorporating background knowledge, adding a multidimensional edge feature, and using a more complicated node feature of proteins from the pre-trained model. By comparing the performance of our model to other recent research employing a range of methodologies, we found that our method improves prediction accuracy. In addition, we evaluated the effectiveness of our model when we included protein structure based on a contact map, and the results indicated that protein structure is optional for our model to achieve good prediction accuracy. As our model only incorporates an edge feature in the drug branch, future work could improve the model's accuracy by enhancing the protein node and edge feature extraction.

## Section: Author contributions

N. N. primarily designed the study and supervised model development and testing. D. W. supervised the overall research project and reviewed and provided valuable feedback on the manuscript, contributing to its improvement. The original draft was written by N.N. and reviewed/edited by D. W.

## Section: Data availability

https://github.com/cucpbioinfo/iEdgeDTA.

## Section: Conflicts of interest

There are no conflicts to declare.

## Section: Acknowledgments

This work was partially supported by the National Research Council of Thailand (NRCT) under contract number N34A640454 and the Program Management Unit for Competitiveness (PMU-C), Office of National Higher Education Science Research and Innovation Policy Council, Thailand, under contract number C10F640366. We want to thank Chulalongkorn University Technology Center (UTC) for facilitating the GPU infrastructure for our model development and testing.

## Section: Associated Data › Data Availability Statement

https://github.com/cucpbioinfo/iEdgeDTA.


---

# In-Context Retrieval-Augmented Language Models

- **Authors:** Ori Ram, Yoav Levine, Itay Dalmedigos, Dor Muhlgay, Amnon Shashua, Kevin Leyton‐Brown, Yoav Shoham
- **Issuer:** Transactions of the Association for Computational Linguistics
- **Type:** Scientific article
- **Published:** 2023-01-01
- **DOI:** 10.1162/tacl_a_00605
- **Source:** https://doi.org/10.1162/tacl_a_00605
- **Licence:** CC-BY

## Section: Abstract

Abstract Retrieval-Augmented Language Modeling (RALM) methods, which condition a language model (LM) on relevant documents from a grounding corpus during generation, were shown to significantly improve language modeling performance. In addition, they can mitigate the problem of factually inaccurate text generation and provide natural source attribution mechanism. Existing RALM approaches focus on modifying the LM architecture in order to facilitate the incorporation of external information, significantly complicating deployment. This paper considers a simple alternative, which we dub In-Context RALM: leaving the LM architecture unchanged and prepending grounding documents to the input, without any further training of the LM. We show that In-Context RALM that builds on off-the-shelf general purpose retrievers provides surprisingly large LM gains across model sizes and diverse corpora. We also demonstrate that the document retrieval and ranking mechanism can be specialized to the RALM setting to further boost performance. We conclude that In-Context RALM has considerable potential to increase the prevalence of LM grounding, particularly in settings where a pretrained LM must be used without modification or even via API access.1


---

# Integrated Molecular Modeling and Machine Learning for Drug Design

- **Authors:** Song Xia, Eric Chen, Yingkai Zhang
- **Issuer:** Journal of chemical theory and computation
- **Type:** Scientific article
- **Published:** 2023-10-26
- **Language:** en
- **DOI:** 10.1021/acs.jctc.3c00814
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37883810/
- **Licence:** CC-BY

## Section: Abstract

AbstractModern therapeutic development often involves several stages that are interconnected, and multiple iterations are usually required to bring a new drug to the market. Computational approaches have increasingly become an indispensable part of helping reduce the time and cost of the research and development of new drugs. In this Perspective, we summarize our recent efforts on integrating molecular modeling and machine learning to develop computational tools for modulator design, including a pocket-guided rational design approach based on AlphaSpace to target protein–protein interactions, delta machine learning scoring functions for protein–ligand docking as well as virtual screening, and state-of-the-art deep learning models to predict calculated and experimental molecular properties based on molecular mechanics optimized geometries. Meanwhile, we discuss remaining challenges and promising directions for further development and use a retrospective example of FDA approved kinase inhibitor Erlotinib to demonstrate the use of these newly developed computational tools.

## Section: Introduction

The cost of research and development of new drugs has risen over the past decade.1−3 There is great interest in advancing computational methods, including molecular modeling and machine learning (ML), to greatly accelerate the process of drug discovery and development.4−10 The goal of drug discovery is to find small molecules that inhibit the disease-related target and, therefore, modulate the disease. Meanwhile, the pharmacokinetic properties including absorption, distribution, metabolism, excretion, and toxicity (ADME/T) of small molecules also need to be considered in the drug development process.11 The success of drug development requires both good efficacy and the desired pharmacokinetic properties of the drug molecules. Computer-aided drug design (CADD) offers valuable tools in finding candidate compounds in all stages of drug discovery and development.

It should be noted that a modern therapeutic development process often involves multiple nonlinearly interconnected stages.12Figure 1A shows a simplified “pipeline” of therapeutic development where CADD tools are playing important roles. Hit identification is the first step which involves finding the compounds with desired bioactivity.13 Ligand based methods use prior knowledge to predict new drug compounds with similar bioactivities (Figure 1B).14 Similarity search,15 pharmacophore modeling,16,17 and quantitative structure–activity relationships18,19 are common tools for ligand based drug screening. Structure based methods such as molecular docking20−26 and molecular dynamics simulations27−32 are common computational tools used to predict the binding affinity between the protein and ligand (Figure 1C). Binding site prediction tools33−39 offer information on the protein surface where a ligand molecule binds to produce the desired output (activation, inhibition, or modulation).5 If the structure of the protein is not solved experimentally, homology modeling40−43 and ab initio protein structure modeling44−47 approaches can be used to predict the protein structure.

After discovering the hit compounds, subsequent steps involve producing more potent and selective compounds with desirable physicochemical properties.13 It is estimated that over 40% of drug candidates are withdrawn in preclinical tests due to ADME/T concerns.48 To address the problem, a number of computational models have been developed to predict the ADME/T properties of small molecules.49−60 The accurate prediction of molecular properties requires models to learn more robust molecular representations for 1D SMILES,61 2D graph,62 and 3D geometry.63

As computational tools at all stages of drug discovery and development have been extensively reviewed recently,64,65 in this perspective, we focus on the recent progress related to our group. Specifically, we first summarize protein pocket identification and analysis methods based on fragment-centric topographical mapping. Subsequently, we discuss recent advances and promising directions in developing ML and deep learning (DL)-based molecular docking models. Finally, we describe our recent efforts to improve small molecule representation learning and explore chemical space66 more efficiently.

Roles of computational models at the stages of drug discovery and development.

## Section: Protein Pocket Identification and Representation

Workflow of AlphaSpace to optimize a ligand to bind to a protein begins with a selected PDB structure and follows the purple arrows until the optimization is validated experimentally. The additions introduced by AlphaSpace2.0 follow the orange arrows.

## Section: Protein Pocket Identification and Representation › Protein Pocket Identification: Fragment-Centric Topographical Mapping

In contemporary approaches to structure-based drug design, focus is placed on the analysis of concave regions found on biomolecular surfaces. These regions can vary from well-defined small-molecule binding sites to extensive protein–protein interaction (PPI) interfaces.67 Gaining a deeper understanding of concave biomolecular surfaces holds immense potential for various applications in modulator design, such as lead optimization, enhanced ligand screening, and even the identification of previously undiscovered druggable sites.67−69 Furthermore, comparisons of these surfaces investigate ligand selectivity, off-target effects, and polypharmacological activity.70,71

One of the main tasks in analyzing the protein surfaces is identifying binding sites. There are a number of algorithms that do this, and these can be broadly classified as geometry-35,37,72−76 or energy-based methods.68,77−81 Geometry-based methods map out the concavities on the surface using grids or alpha-spheres, while energy-based methods calculate the interaction energy or surface accessibility between the protein and diverse small-molecule probes. The next step usually requires ML methods to characterize the binding site. For example, some methods use clustering to agglomerate data points into binding pockets and others use regression to score the concavities on the protein surface for their ligandability.82 Most methods can correctly predict and rank the voluminous and well-defined ligand binding pockets in holo structures.72,83,84

The alpha-sphere geometry-based representation of the concavities is an established strategy that relies on Voronoi diagrams.34,35,73,74,85−87 Voronoi diagrams form polyhedra defined by the planes that bisect adjacent atoms, resulting in a tessellation of the concave region. Alpha-spheres are placed at the vertices of the Voronoi diagram. These alpha-spheres are then clustered to represent binding pockets. Rooklin et al. developed a python program named AlphaSpace, an alpha-sphere-based method developing on the popular method fpocket,35 that leverages concepts of fragment-based drug discovery and caters to the analysis of PPI (Figure 2).34 To this aim, AlphaSpace uses a tuned clustering method to demarcate pockets that reflect on average one fragment per pocket and defines alpha-atoms, a theoretical ligand atom whose properties reflect a docked fragment. It represents entire PPI surfaces by retaining shallower fragment-centric pockets during the evaluation stage and suggests targetable pockets near the binding partner for ligand optimization. Furthermore, Katigbak et al. developed AlphaSpace 2.0, a python package that clusters the alpha-atoms to a β-cluster, a pseudomolecular representation of the concave site comprised of β-atoms (Figure 2).33 Each β-atom is replaced with a probe atom that iterates through different Vina atom types. The AutoDock Vina score is calculated for each atom type of each probe atom. Then the best Vina score for each probe atom is summed to generate the overall β-score. This β-score reflects the maximum theoretical docking score of the β-cluster.

Both AlphaSpace and AlphaSpace2 offer alignment-free and alignment-based pocket matching protocols, respectively, allowing for comparisons of binding sites between structures within the alpha-sphere framework.33,34 Both methods assess the change in the inhibitor binding site of PPI interfaces using the curated 2P2I database, which provides structures of a protein in the apo, PPI complex, or inhibitor bound PPI complex states. In both cases they can observe the binding pockets on the apo structure that corresponds to the inhibitor binding site, and AlphaSpace2 reports similar ligand-ability estimates of that binding site across structures. However, on the CryptoSite database consisting of structures where a pocket forms in the holo state but not the apo state, AlphaSpace2 reports differences in ligand-ability estimates.

DL methods are also gaining prominence due to their ability to learn complex relationships from raw protein data and predict binding surfaces.82,88 DL architectures can learn the representation and functional roles of the binding pockets without first preprocessing the data to explicitly detect the pockets. Mylonas et al. developed DeepSurf, a 3D-convolutional neural network (CNN) trained on voxels placed on the protein surface.89 It had superior performance compared to other methods tested in the SHREC 2022 contest at identifying druggable sites on diverse data sets of apo and holo structures.83,89 Gainza et al. proposed MaSIF, a surface representation framework that uses overlapping radial patches characterized by a chemical and geometric fingerprint.90,91 These patches can be input into geometric neural network architectures and trained to perform particular tasks, including predicting PPI and ligand sites. Most recently, Smith et al. developed Graph Attention Site Prediction (GrASP) which uses a graph attention network (GAT) architecture to encode the binding site from a protein structure graph. This model is trained on a modified version of sc-PDB to predict the likelihood of an atom to be part of the binding site. These atoms are then clustered and aggregated into binding sites with ligand-ability scores.92 This results in superior precision and recall compared to another graph neural network (GNN)-based method, P2Rank, on the COACH420 and HOLO4K benchmarks.92

Workflow of AlphaSpace to optimize a ligand to bind to a protein begins with a selected PDB structure and follows the purple arrows until the optimization is validated experimentally. The additions introduced by AlphaSpace2.0 follow the orange arrows.

## Section: Protein Pocket Identification and Representation › Experimentally Validating Predictions of Underutilized but Targetable Regions › AlphaSpace has guided the optimization of minimal protein mimetics that target PPIs by expanding mimetics to target secondary binding sites and incorporating noncanonical amino acids to reach untargeted binding pockets

(93−95) Guided by the binding pocket analysis, researchers introduced a terminal tryptophan of a p53 mimetic to interact with a previously untargeted secondary site which resulted in an ∼10-fold improvement of binding affinity to MdmX and Mdm2.95 This interaction was verified to bind to the secondary site through NMR. In another case, optimization steps were able to reverse the loss of binding affinity resulting from truncating the full length protein to a minimal mimetic. The truncated helical MML-mimetic bound poorly to the KIX domain of the p300/CBP coactivator (Kd: >100 μm), but a MML mimetic mutated with noncanonical amino acids was optimized to a similar binding affinity (Kd: 3.3 ± 0.5 μm) as the full-length wildtype MML (Kd: 1.0 ± 0.3 μm).93 Moreover, suggested mutations to the cross-linked helix dimers of the NEMO coiled coil reversed the binding affinity loss due to the aforementioned. These mimetics were also able to inhibit the native PPI in vivo.94 In these cases, the role of AlphaSpace was to suggest initial fragments for improvement, but expertise and further experimental optimization were necessary to generate stable mimetics and maximize protein–ligand binding affinity.93−96

AlphaSpace has also guided the analysis of protein structures for targetable binding sites to design small molecule inhibitors and understand their binding mechanisms. Some computational experiments qualitatively studied the interaction mechanisms and binding modes by docking inhibitors to the most targetable pockets of the transmembrane protein ABCG2 and by running molecular dynamics (MD) simulations of the complexes.97,98 Other binding pocket analyses led to successful prospective docking studies. Hou et al. detected a cryptic pocket in a metastable state of the apo striatal-enriched protein tyrosine phosphatase (STEP) from MD simulations. Ensemble docking to this state at the cryptic pocket resulted in 11 novel inhibitors (IC50 = 9.7–47.7 μm).99 These experimental validations highlight the utility and role that AlphaSpace can play in identifying pockets to develop ligands with improved binding.

## Section: Protein–Ligand Docking in the Machine-Learning Era

Employing computational methods to discover bioactive compounds is becoming an indispensable technique to accelerate the process of drug discovery,100−107 leading to the successful discovery of several approved drugs.104,108−110 The drug discovery process encompasses two major categories: ligand-based drug discovery (LBDD) and structure-based drug discovery (SBDD). LBDD is an indirect approach that employs quantitative structure–activity relationship methods, molecular similarity, and pharmacophore modeling to predict various properties of compounds.14 On the other hand, SBDD involves using the three-dimensional structures of the protein and small molecule to identify or optimize drug compounds.101,111 SBDD focuses on recognizing binding sites and essential interactions crucial to the biological functions of the target. By doing so, it suggests therapeutic compounds that can compete with these crucial interactions, thereby disrupting biological pathways effectively.

Virtual screening (VS) is a method within SBDD where extensive libraries of commercially available, druglike chemical compounds are computationally screened against target proteins with known or predicted 3D structures in a high-throughput manner. The primary goal of VS is to identify potential compounds that exhibit a high predicted binding affinity for the target protein. These selected compounds are then subjected to experimental testing to validate their actual binding capabilities.112,113

Molecular docking is a widely used computational procedure in VS protocols.114−117 It operates based on the lock-and-key118 model of drug action and predicts the noncovalent interactions between the target and small molecules. In structure-based VS, molecular docking methods are commonly used to assess large libraries of molecules.26

Biased protein pockets when evaluating the docking power and screening power on the CASF-2016 data set. (A) Protein and ligand structures. (B) The biased protein pocket resulting from using the binder ligand structure to cut the protein. (C) The unbiased protein pocket without using the binding structure.

## Section: Protein–Ligand Docking in the Machine-Learning Era › Protein–Ligand Scoring Functions

Molecular docking programs rely on a scoring function to evaluate the binding affinity and optimize the binding orientation between protein and ligand.21−23,25,119−121 The scoring function plays a pivotal role in accurately predicting how well the ligand binds to the target protein. Consequently, developing a robust, efficient, and accurate scoring function is a critical component of molecular docking.107

A rigorous theoretical prediction of protein–ligand binding affinity requires the calculation of the free energy difference between the bound and unbound state. However, existing methods for free energy calculation, such as free energy perturbation122,123 and thermodynamic integration,124,125 are computationally expensive, making them impractical for virtual screening over a large set of compounds. To overcome this limitation, scoring functions serve as fast and approximate computational methods to evaluate the strength of noncovalent interactions between proteins and ligands, based on their 3D binding poses.126−128 They are widely used in SBDD to determine the binding mode of ligands (docking power), predict the binding affinity between proteins and ligands (scoring power), identify hits from a large compound library for given protein targets (screening power), and perform structure–activity relationship analyses for hit-to-lead and lead optimization.105,129,130 It is important to note that scoring functions provide estimations of ligand binding affinity, and these predicted scores may not align closely with binding affinities determined through rigorous methods, such as free energy perturbation. For an in-depth understanding of terms such as “scoring power”, “docking power”, and “screening power”, we direct readers to the comprehensive definitions provided in the paper “Comparative Assessment of Scoring Functions: The CASF-2016 Update”.131

Classical scoring functions use a linear combination of force-field or interaction descriptors to evaluate the binding affinity between proteins and ligands. They can be categorized into different types based on their underlying principles. Physics-based scoring functions use the fundamental molecular physics terms derived from experimental data and/or QM calculations;21,119,121 knowledge-based scoring functions use the statistical potentials derived from experimentally determined protein–ligand structures;132−135 and empirical scoring functions make predictions by fitting experimentally measured binding affinity data using linear regression on a set of physical descriptors.21−23,120,136−139

In recent years, ML-based scoring functions have garnered increasing attention due to the rapid growth of experimental data and advancements in computational infrastructure.140,141 Unlike classical scoring functions that adopt linear forms, ML-based scoring functions have the capability to learn more complex functional forms using ML algorithms such as support vector machine (SVM),142 random forest (RF),143 and extreme gradient boosting (XGB).144 In 2010, Ballester et al. introduced RF-score which is the first ML-based scoring function that outperforms classical scoring functions in terms of scoring power.145 In 2013, Zillian et al. developed SFCscoreRF which achieved significantly higher scoring power on common benchmarks.146 However, both models performed much worse when performing docking and screening tasks compared to classical scoring functions.147,148 The reader is directed to this review by Chao et al.107 for more in-depth discussion on scoring functions.

Biased protein pockets when evaluating the docking power and screening power on the CASF-2016 data set. (A) Protein and ligand structures. (B) The biased protein pocket resulting from using the binder ligand structure to cut the protein. (C) The unbiased protein pocket without using the binding structure.

## Section: Protein–Ligand Docking in the Machine-Learning Era › Protein–Ligand Scoring Functions › The Δ-ML strategy improves the scoring-ranking-docking-screening power of ML-based scoring functions

To address this problem, Wang et al. applied a Δ-ML strategy, which involves using ML to predict the correction between experimental binding affinity and computationally predicted binding affinity. The final predicted score is obtained by adding this ML correction to classical scoring functions. The first model to employ this strategy is ΔVinaRF20,149 a random forest model that predicts the corrections to the Vina score. It uses pharmacophore-based solvent-accessible surface area descriptors and AutoDock Vina features as input. ΔVinaRF20 demonstrated superior performance in all power tests on both CASF-2013 and CASF-2007 benchmarks compared to classical scoring functions.150,151 Subsequently, Lu et al. have proposed the ΔVinaXGB model which uses XGB trees.152,153 This model incorporates features from explicit water molecules, metal ions, and ligand conformational stability in addition to the ΔVinaRF20 features.152 The ΔVinaXGB model outperformed other scoring functions on the CASF-2016 benchmark data set.131 Recently, Yang et al. have developed the ΔLin_F9XGB model154 based on a classical scoring function named Lin_F9.139 Lin_F9 is a linear empirical scoring function that builds on AutoDock Vina, overcoming some of Vina’s limitations by introducing new empirical terms for better scoring accuracy. By applying the Δ-ML strategy to the Lin_F9 scoring function, and improving feature selection and the training set, ΔLin_F9XGB achieves superior scoring, ranking, and screening performance on the CASF-2016 benchmark.154

In addition to the CASF-2016 benchmark data set, previous models have undergone extensive testing on the LIT-PCBA data set, specifically designed for virtual screening and ML purposes.155 Preliminary results have shown that the LIT-PCBA data set is challenging due to the high imbalance of active/inactive compounds, common molecular properties shared between active and inactive compounds, and weak potencies of the active compounds.154,156 The average top 1% enrichment factor achieved by ΔLin_F9XGB is 5.55, which outperforms other scoring methods such as AutoDock Vina, ΔVinaRF20, and Lin_F9.

## Section: Protein–Ligand Docking in the Machine-Learning Era › Protein–Ligand Scoring Functions › Learning distance likelihood potential boosts the docking and screening performance of DL-based scoring functions

Aside from traditional ML-based scoring functions, the emergence of DL methods has introduced new strategies for developing scoring functions in drug discovery. Neural network-based models use hand-crafted features as input, including protein–ligand interactions and ligand-dependent descriptors.147,157,158 Convolutional neural network (CNN)-based scoring functions adopt a different approach by using vectorized 3D grids that cover the protein–ligand binding region as input. These grids are processed through CNN layers, followed by readout layers to make predictions about the binding affinity.159−164 Graph neural networks (GNNs) represent molecules as graphs and can learn on the protein–ligand binding system through graph convolutions.165−169 However, despite the increasing popularity of DL-based scoring functions, it is worth noting that these models have not significantly outperformed traditional ML-based scoring functions on well-established benchmark data sets like CASF.107

Recently, Méndez-Lucio et al. proposed a geometric DL-based model named DeepDock170 which learns the probability density distribution of the distance between ligand atom and the protein surface. This approach showed competitive performance in docking and screening tasks when compared to those with well-established scoring functions. Building on the concept of distance likelihood, Shen et al. developed RTMScore.171 Unlike DeepDock, RTMScore overcomes the need for protein surface triangulation by using the probability density distribution of distances between ligand atoms and protein amino acids at the residue level. To achieve this, RTMScore represents proteins as undirect graphs at the residue level and leverages graph transformers to learn the representation of both proteins and ligands. As a result, RTMScore achieves top docking and screening power on the CASF-2016 data set, outperforming state-of-the-art ML- and DL-based scoring functions.

However, RTMScore utilizes biased protein pockets generated from known binder structures as the input protein structure. For example, when evaluating the binding score of the ligand 1A30 on the protein 1E66 (Figure 3A), only the protein structure within 10 Å of the binder ligand 1E66 is used along with the docked ligand 1A30 structure as model input (Figure 3B). This selection method may lead to two potential problems. First, this method requires the binder structure to cut the protein, while in real world virtual screening scenarios, the protein may not have a known binder, or the binder structure may be unknown. Second, the selected pocket is biased toward the binder ligand, potentially neglecting essential interactions between the decoy ligands and the protein when the decoy structures are far from the binder ligand (Figure 3B and C).

The influence of the biased pocket selection was investigated by using docked decoy structures to cut the proteins (Figure 3C) and retesting RTMScore on the CASF-2016 data set. The results, as presented in Table 1, revealed a performance drop when the unbiased pocket was used as the model input for RTMScore models. Despite this drop in performance, the unbiased model still outperformed most of the state-of-the-art models in terms of docking and screening power. This finding highlights the importance of addressing the issue of biased pocket selection in DL-based scoring functions. Although the performance of RTMScore was affected by the unbiased pocket, the fact that it still outperformed many state-of-the-art models indicates that learning distance likelihood potential is a promising direction to improve the docking and screening performance of DL scoring functions.

The very recent work by Shen et al. extends the RTMScore model to the GenScore framework.177 By introducing an adjustable binding affinity term during the training of the probability density distribution, GenScore successfully addresses the issue of low scoring and ranking power experienced by RTMScore, achieving balanced scoring, ranking, docking, and screening power on the CASF-2016 data set. Furthermore, the evaluation of GenScore on the LIT-PCBA data set for real-world screening power is particularly noteworthy. Their best-performing GenScore model exhibits an impressive average top 1% enhancement factor of 6.80 among all targets, demonstrating an excellent screening power.

However, it is important to acknowledge that the biased pocket problem, as mentioned earlier, is not explicitly addressed by GenScore. The reliance on pocket selection using binder ligand structures limits its applicability in real-world virtual screening protocols, especially for novel targets for which binder ligands might not be known or available. Addressing the biased pocket problem would undoubtedly enhance the utility and versatility of RTMScore, GenScore, and other DL-based scoring functions in real-world virtual screening scenarios, making them more effective in identifying potential drug candidates for novel targets with unknown binder structures. Future research in this direction may help overcome this limitation and further establish DL-based scoring functions as valuable tools in drug discovery efforts.

Biased protein pockets when evaluating the docking power and screening power on the CASF-2016 data set. (A) Protein and ligand structures. (B) The biased protein pocket resulting from using the binder ligand structure to cut the protein. (C) The unbiased protein pocket without using the binding structure.

## Section: Protein–Ligand Docking in the Machine-Learning Era › Molecular Docking in the Deep Learning Era

Traditional molecular docking methods such as AutoDock Vina22 and Lin_F9139 rely on the scoring functions and optimization algorithms that search for the global maximum of the scoring functions. The optimization algorithm rotates the rotatable bonds in the molecule, translates the molecule, and rotates the whole molecule until it finds the best conformation with the highest score predicted by the scoring function. In principle, the optimization algorithms can also be applied to DL-based scoring functions. However, in practice, the optimization algorithms often fail to converge when using DL-based scoring functions, especially for those compounds with a high number of rotatable bonds.170 Recently, researchers have developed DL-based docking models to predict binding poses in one shot by treating molecular docking as a regression task.178,179 Although these models are faster than traditional docking methods, they do not significantly outperform traditional docking methods in terms of accuracy.

In late 2022, Corso et al. introduced DiffDock,180 a diffusion generative model which learns the ligand pose distribution from ligand and protein structures. The model employs a diffusion process over the ligand center position, orientation, and torsional angles of each rotatable bond. By iteratively refining ligand poses through updates of translations, rotations, and torsion angles, DiffDock can sample binding poses from random initial ligand conformations.

On the PDBBind blind docking task, DiffDock achieves a 38% top-1 accuracy, significantly outperforming state-of-the-art molecular docking models.180 This success demonstrates the potential of DL methods in improving the ligand binding pose prediction. By combination of DiffDock with modern DL-based scoring functions, a more robust virtual screening protocol can be developed for real-world drug discovery applications.

## Section: Molecular Representation Learning with Deep Learning Methods

Overall workflow using sPhysNet-MT-ens5 for energetics prediction. (A) MMFF geometry generation protocol. (B) The prediction of electronic energies and transfer free energies with sPhysNet-MT-ens5.

Model performance comparison between sPhysNet-MT and other state-of-the-art models on the experimental hydration free energy and logP prediction. Results are adapted from the sPhysNet-MT manuscript.51

## Section: Molecular Representation Learning with Deep Learning Methods › Exploring Chemical Space Efficiently with Force-Field Optimized 3D Geometry and 2D Molecular Graphs

In theoretical chemistry, the Schrödinger equation (SE) serves as the “standard model” because it represents the physics of the charged particles that make up almost all of the molecules and materials. Unfortunately, the analytical solution to SE is only available for systems with a few degrees of freedom. Numerical solutions such as high-accurate quantum mechanics (QM) calculations impose prohibitive computational cost.181−184 To overcome this challenge, ML approaches to predict molecular energies have been crafted to circumvent the task of solving SE of the system by learning the mapping from the geometry to the energy through supervised learning.185−191 With advances in computer infrastructure and the availability of organized chemistry data sets, DL192 methods are gaining popularity. DL methods utilize the atomic coordinates {RI} and atom types {ZI} to predict molecular energetics directly, avoiding the need for hand-crafted molecular descriptors used in ML methods.193−203 In the past few years, many DL models204−213 with distinct model architectures have been developed for the prediction of molecular energetics with better performance on the QM9 benchmark data set.214−216 This data set contains minimized structures and molecular properties calculated using the density functional theory217 (DFT) method for 133,885 molecules composed of H, C, N, O, and F atoms with up to nine heavy atoms. However, despite the progress, many DL models developed on the QM9 data set still require DFT-optimized geometries as input for prediction, which leads to the original problem of computational expense not being fully addressed.

Overall workflow using sPhysNet-MT-ens5 for energetics prediction. (A) MMFF geometry generation protocol. (B) The prediction of electronic energies and transfer free energies with sPhysNet-MT-ens5.

## Section: Molecular Representation Learning with Deep Learning Methods › Exploring Chemical Space Efficiently with Force-Field Optimized 3D Geometry and 2D Molecular Graphs › Force-field optimized geometries can be used to predict DFT-level molecular energetics

In 2019, Lu et al. have demonstrated the feasibility of using Merck Molecular Force Field (MMFF)183 optimized geometry for gas phase DFT-level electronic energy prediction.209 They first train a model called DTNN_7ib on the QM9 data set using DFT-optimized geometries as input and then retrain the readout layer of the model on their prepared MMFF-optimized geometries. The trained DTNN_7ib achieves a mean-absolute-error (MAE) of 0.79 kcal/mol on DFT-level electronic energy by using MMFF-optimized geometry.

In 2021, Lu et al. extended the effectiveness of MMFF-optimized geometry beyond the QM9 benchmark data set by constructing the Frag20 data set.63 These data consisted of DFT-calculated properties for over half a million molecules, with both MMFF and DFT-optimized geometries, and consisted of elements H, B, C, O, N, F, P, S, Cl, and Br, with no more than 20 heavy atoms. They train a model named sPhysNet on the Frag20 data set and achieve better than or close to chemical accuracy (1 kcal/mol) on multiple test sets, including two external test sets based on experimental crystal structures. The work indicated the potential of using MMFF-optimized geometries as a more computationally efficient alternative to explore chemical space66 compared to solely relying on DFT-optimized geometries.

## Section: Molecular Representation Learning with Deep Learning Methods › Exploring Chemical Space Efficiently with Force-Field Optimized 3D Geometry and 2D Molecular Graphs › MMFF geometry also proves useful for predicting experimental properties

In 2022, Xia et al.51 developed a DL model named sPhysNet-MT-ens5 for predicting experimental hydration free energy and octanol/water partition coefficient (logP) using MMFF optimized geometry. Figure 4 shows the overall workflow using the model for prediction. For each compound, up to 300 conformations are generated using EDKTG218 implemented in RDKit219 and then optimized with MMFF. The conformation with the lowest MMFF energy is then selected as the input geometry for the prediction of experimental hydration free energy and logP, as well as other properties of the compound. An ensemble of five independently trained sPhysNet-MT models is used for prediction, and the average of the five predictions is used as the ensemble prediction. The model achieves a root-mean-square error (RMSE) of 0.620 kcal/mol on the FreeSolv220 data set for experimental hydration free energy prediction, as well as an RMSE of 0.393 on the PHYSPROP18,221−223 data set for experimental logP prediction.

Overall workflow using sPhysNet-MT-ens5 for energetics prediction. (A) MMFF geometry generation protocol. (B) The prediction of electronic energies and transfer free energies with sPhysNet-MT-ens5.

## Section: Molecular Representation Learning with Deep Learning Methods › Exploring Chemical Space Efficiently with Force-Field Optimized 3D Geometry and 2D Molecular Graphs › Spatial information computed from MMFF geometry enhances 2D molecular representations

Unlike models that use 3D molecular geometry as input, many DL models use 2D molecular graphs to predict various chemical properties.224−231 While they have shown success in these tasks, their limitations in representing molecules with 2D graphs have been widely discussed.232−236 This is because models based solely on 2D connection graphs may not distinguish between molecules with 3D spatial structures. For example, message passing GNNs cannot distinguish decaprismane237 C20H20 from dodecahedrane238 C20H20 purely based on their 2D graphs.235

To address this limitation, models that incorporate geometry information can achieve better performance.52,239 In 2022, Zhang et al. developed A3D-PNAConv52 which uses both 2D and 3D information on molecules. They demonstrate that incorporating 3D atomic features obtained from MMFF-optimized geometries enhances the learning power of GNN models in predicting calculated solvation free energies. The 3D atomic features are calculated by atom-centered symmetry functions (ACSFs),200 which are sets of many-body interaction functions encoding atomic environments in 3D structures. The GNNs use the 3D atomic features as the initial atomic embedding and then perform several iterations of message passing on the 2D molecular graphs. In comparison, they have also trained GNNs without 3D atomic features. The GNNs with 3D atomic features as initialization outperform their 2D counterpart for predicting calculated water solvation free energy on their Frag20-Aqsol-100k data set. This indicates that using 3D atomic features obtained from MMFF geometries can enhance the learning capability of GNN-based models.

## Section: Molecular Representation Learning with Deep Learning Methods › Enhancing Downstream Tasks through Transfer Learning with Pretrained Molecular Modeling Data

In the early stages of the drug discovery process, data scarcity is the most common issue for DL models in the prediction of experimental physicochemical properties. DL models heavily rely on the size and quality of the training data, and they tend to overfit on small data sets, leading to poor generalizability and performance.240 In contrast, molecular modeling data can be obtained in larger quantities within a reasonable time frame, thanks to advancements in high-performance computing. As shown in Table 2, publicly available data sets generated using molecular modeling methods are significantly larger than experimental data sets in terms of size. To address the scarcity of experimental values, calculated data sets should be fully utilized when training DL models on experimental data.

Model performance comparison between sPhysNet-MT and other state-of-the-art models on the experimental hydration free energy and logP prediction. Results are adapted from the sPhysNet-MT manuscript.51

## Section: Molecular Representation Learning with Deep Learning Methods › Enhancing Downstream Tasks through Transfer Learning with Pretrained Molecular Modeling Data › Pretraining on DFT-calculated energetics aids in improving the prediction of downstream tasks on related experimental properties

The fine-tuning strategy is commonly employed in training DL models. First, a model is pretrained on a source task, and then, its trained weights are transferred as the initialization for a related target task. This fine-tuning approach often yields better performance compared to random initialization.243 For instance, Zhang et al. developed a data set named Frag20-Aqsol-100k which contains 100k diverse molecules sampled from Frag20 and CSD20 data sets, along with their calculated hydration free energy using their SMD_B3LYP protocol.52 They pretrained DL models on the Frag20-Aqsol-100k data set and fine-tuned the models on the FreeSolv data set, which contains 640 compounds with experimentally measured hydration free energy. Their fine-tuned model achieved state-of-the-art performance and can even achieve chemical accuracy with a very small training data size of just 100 molecules.52

Xia et al.51 extended the work and develop Frag20-solv-678k which contains 678,916 conformations and their calculated energetics in gas, water, and octanol phases. They pretrained a DL model on all three electronic energetics and the transfer free energies between the three phases, and fine-tuned the model on a combined data set composed of molecules from FreeSolv with experimental hydration free energy and PHYSPROP with experimental logP. The fine-tuned model predicts experimental hydration free energy with an RMSE of 0.620 kcal/mol on the FreeSolv data set, as well as experimental logP with an RMSE of 0.393 on the PHYSPROP data set, achieving state-of-the-art performance on both tasks simultaneously (Figure 5).

Model performance comparison between sPhysNet-MT and other state-of-the-art models on the experimental hydration free energy and logP prediction. Results are adapted from the sPhysNet-MT manuscript.51

## Section: Molecular Representation Learning with Deep Learning Methods › Improving Molecular Representations through Mutual Learning with Multitask Training

There are a wide range of ML and DL models that have been developed for a variety of chemical tasks. Although some chemical tasks are related, they are treated by different models with distinct model architectures. For example, the models developed for the prediction of high-level QM calculated molecular energetics204−212 and the models for predicting of experimental transfer free energies52,225,228,229,239,244,245 are often developed separately. While separate models may be more effective for accurate predictions for weakly related tasks,210,211 multitask models can be advantageous when tasks are well-related.246,247

## Section: Molecular Representation Learning with Deep Learning Methods › Improving Molecular Representations through Mutual Learning with Multitask Training › Multitask training on related tasks leads to more robust molecular representation learning

Motivated by the fact that many molecular modeling methods use the direct relationship between absolute energies and transfer energies to predict experimental properties with satisfactory results,248−251 Xia et al. developed a multitask DL model named sPhysNet-MT.51 This model simultaneously predicts electronic energies of molecules in gas, water, and octanol as well as the transfer free energies between these phases. On their calculated data set, which includes molecules with energetics computed at the DFT-level, the sPhysNet-MT model achieves chemical accuracy on all tasks. Additionally, on the experimental data set containing molecules with experimental hydration free energy and logP, the model achieves state-of-the-art performance on both tasks simultaneously (Figure 5).

Similarly, Lu et al. developed the T5Chem model for multitask reaction prediction, which encompasses forward reaction prediction, reactant prediction, reagent prediction, reaction yield prediction, and reaction type classification.252 On the test set of their reaction prediction data set called USPTO_500_MT, T5Chem achieves top-1 accuracy of 97.5%, 72.9%, and 24.9% for forward prediction, retrosynthesis, and reagents prediction, respectively. The model also achieves an accuracy of 99.4% in reaction type classification, R2 of 0.22, and MAE of 17.8 in reaction yield prediction, showing competitive performance compared to models trained solely on individual tasks.

## Section: Case Study: 1M17

To illustrate the computational tools described in this paper, we show a case study using the crystal structure of the FDA approved inhibitor Erlotinib bound to the kinase domain of the epidermal growth factor receptor (EGFR) from PDB 1M17 (Figure 6).

We first use AlphaSpace to analyze the binding of Erlotinib to EGFR kinase. The crystal receptor and crystal ligand are the inputs for AlphaSpace and AlphaSpace2.0 analysis. To calculate the AlphaSpace 2.0 β-score, hydrogens and partial charges are added to the ligand and protein input files. The AlphaSpace output characterizes the pockets that are in contact with the ligand, provides a binding score, and suggests undertargeted pockets (Figure 6A). The alpha-atoms and β-atoms are colored by the pockets which they belong to.

We then apply ΔLin_F9XGB for the prediction of the binding affinity. Similarly to the preparation of the AlphaSpace 2.0 input files, we add hydrogens and generate the partial charges to the crystal ligand and crystal protein input files. We apply Lin_F9 local optimization on the ligand binding orientation and get the Lin_F9 binding score. The Vina, solvent accessible surface area, water, metal, and ligand descriptors are calculated for the optimized geometry. These are input to an ensemble of 10 XGB models, the average output of which is used as correction of the Lin_F9 binding affinity. The sum of the Lin_F9 and XGB correction is the final ΔLin_F9XGB score or the predicted binding affinity. The predicted binding affinity of Erlotnib to EGFR kinase from the structure 1M17 (pKdpred = 8.46, Kdpred = 3.5 nM, Figure 6B) closely matches the experimental binding affinity found in BindingDB (with an average of pKdexp and pKiexp = 8.9 ± 0.9).253 It is worth noting that BindingDB contains 45 entries for Ki (ranging from 0.1 to 136 nM) and Kd (ranging from 0.35 to 190 nM), indicating a wide range of experimentally measured binding affinities. Our predicted Kd value of 3.5 nM falls comfortably within this spectrum of binding affinities.

Finally, we use sPhysNet-MT to predict the physicochemical properties of the ligand molecule Erlotinib. Starting from the SMILES of Erlotinib, we first generate up to 300 conformations using EDKTG and optimize them with MMFF. 291 conformations are successfully generated, and the one with the lowest MMFF energy is selected as the input geometry for sPhysNet-MT. The average output of an ensemble of 5 independently trained sPhysNet-MT models is used as the final prediction. The model predicts the logP of the molecule to be 2.76 which is close to the experimental measured value queried from the DrugBank database, 2.7 (Figure 6C).254 The detailed scripts to carry out these calculations and analysis can be found at: https://github.com/SongXia-NYU/drug_discovery_perspective.

Case study of PDB 1M17 with models mentioned in the paper. (A) AlphaSpace and AlphaSpace 2.0 binding pocket analysis. (B) Binding affinity prediction was done using Lin_F9 and ΔLinF9XGB. (C) Prediction of physicochemical properties of the ligand molecule using sPhysNet-MT.

## Section: Concluding Remarks and Perspective

The success of developing computational tools for drug design requires the integration of both molecular modeling and ML techniques. Models for small molecules, protein surfaces, and protein–ligand interactions are all required during different stages of the drug design process, and there is still room for development and research in these methods.

The AlphaSpace methods can be more robust and applicable. Further improvements can account for the role of protein conformational stability in pocket ligand-ability. This can make pocket comparisons more robust, especially when large conformational changes or comparisons between apo and holo structures are involved. When apo structures result in lower ligand-ability estimates, it limits confidence in using apo structures for downstream structure-based design. Quantified comparisons between different proteins and between orthosteric and allosteric pockets can also provide insights into ligand selectivity and off-target effects. Future versions can address these limitations by leveraging deep learning approaches to learn the representation of these relationships and improve ligand-ability estimates. Smith et al. suggest that there are opportunities to apply advanced deep learning image vision techniques to this research question.92 AlphaSpace2 and future versions can be tested on recently developed benchmarks for protein–ligand binding site prediction such as SHREC,83 HOLO4K, COACH420,78 and for binding site comparisons such as ProSPECCTs.70,255 Additionally, a Web server can be developed to give medicinal chemists a more user-friendly experience.

Despite the improved performance of ML- and DL-based molecular docking and scoring methods on the CASF-2016 data set, these methods tend to have a high false positive rate and lack generalizability on real-world VS data sets. More consideration should be given to the curation of the training data sets and to introducing regularization techniques to current VS protocol. Computationally generated decoy poses and training data sets should be generated carefully to prevent the model from having noncausal bias, an issue where the model learns specific data patterns instead of meaningful ligand–protein interactions.256,257 Training data sets tend to have many positive labels that lack diversity and have few or biased negative labels.83,88,258,259 Non- and poor-binders are under-reported, and computationally selected nonbinders should be verified experimentally.260,261 There is a lack of quality and standardized data for some targets. Methods such as data set debiasing262 and introducing specific models to classify and rank actives from inactives171,263−265 are promising regularization techniques to tackle this problem. Furthermore, it is necessary to test models in fair benchmarking data sets akin to real-world conditions.155,266

The size and quality of the training data are also important considerations for the prediction of molecular properties with DL models. More diverse data sets are required to further explore the chemical space. The Frag20 data preparation protocol63 can be used to carefully select diverse molecules, and modern high performance computing platforms can with the help generate labels for DFT calculations for calculated data sets. Collaboration with experimental groups is needed to enlarge and standardize experimental training sets. More careful pretraining protocols and model architecture designs should be developed to fully take advantage of the existing experimental data. Another disadvantage of sPhysNet-MT as well as many other DL-based models is that they can run into problems when considering charged molecules, because they do not explicitly express molecular charge in the model. For example, when predicting pKa, the molecule may be ionized and the model may have problems learning the molecular representation without knowing the total charge of the system.

Additionally, structure-based drug design methods are limited by the exclusion of protein dynamics in most current protein–ligand representations. Protein flexibility can range from slight perturbation of the ligand binding pockets to reconstitution of the binding site to large-scale conformational changes. In the case of binding site prediction, the introduction of the protein dynamics to the model can lead to the detection of cryptic pockets that are not seen in the static crystal structures and to better predictors of binding site ligandability.82 Cryptic pockets can be teased out using standard MD simulations or specialized MD simulations where the solvent molecules are altered to act as probes to tease out these pockets.80 Researchers are also using ML models that have learned the aspects of protein flexibility that lead to cryptic pockets from MD simulations to predict cryptic sites.267,268

Researchers have addressed this limitation of protein flexibility within the context of docking and binding affinity prediction as well.269 Some methods introduce side chain flexibility to the receptor binding pocket,270 others include MD simulations to probe the stability of the predicted binding pose,271 while some DL methods learn the features that drive protein–ligand interactions in MD simulations to predict binding affinity.272 The most common method is ensemble docking, which performs docking on a diverse selection of static receptor structures.273,274 Although rigorous in concept, ensemble docking can actually lead to a decrease in performance when using too many structures and thus researchers propose additional ML methods to select the best subset of structures.275−277 The use of technology, like cryo-EM that can determine diverse receptor structures, enhanced sampling MD simulations that speed conformational sampling, and DL protein structure prediction methods that can predict previously undetermined protein structures and conformations will drive the research in understanding the role of protein conformation in ligand binding. The decision to introduce protein flexibility to structure-based drug design comes with additional computational cost, a factor that must be aligned with the scope and goals of every screening campaign and currently does not guarantee improved performance.

## Section: Acknowledgments

This work was supported by the U.S. National Institutes of Health (R35-GM127040). S.X. and E.C. were also partially supported by a graduate fellowship from the Simons Center for Computational Physical Chemistry (SCCPC) at NYU. We thank NYU-ITS for providing computational resources.

## Section: Author Contributions

∥ S.X. and E.C. contributed equally.

## Section: Text

The authors declare no competing financial interest.


---

# Integration of Machine Learning and Structural Analysis for Predicting Peptide Antibiofilm Effects: Advancements in Drug Discovery for Biofilm-Related Infections

- **Authors:** Fatemeh Ebrahimi Tarki, Mahboobeh Zarrabi, Ahya Abdiali, Mahkame Sharbatdar
- **Issuer:** Iranian journal of pharmaceutical research : IJPR
- **Type:** Scientific article
- **Published:** 2023-09-30
- **Language:** en
- **DOI:** 10.5812/ijpr-138704
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38450220/
- **Licence:** CC-BY

## Section: Abstract

The rise of antibiotic resistance has become a major concern, signaling the end of the golden age of antibiotics. Bacterial biofilms, which exhibit high resistance to antibiotics, significantly contribute to the emergence of antibiotic resistance. Therefore, there is an urgent need to discover new therapeutic agents with specific characteristics to effectively combat biofilm-related infections. Studies have shown the promising potential of peptides as antimicrobial agents. This study aimed to establish a cost-effective and streamlined computational method for predicting the antibiofilm effects of peptides. This method can assist in addressing the intricate challenge of designing peptides with strong antibiofilm properties, a task that can be both challenging and costly. A positive library, consisting of peptide sequences with antibiofilm activity exceeding 50%, was assembled, along with a negative library containing quorum-sensing peptides. For each peptide sequence, feature vectors were calculated, while considering the primary structure, the order of amino acids, their physicochemical properties, and their distributions. Multiple supervised learning algorithms were used to classify peptides with significant antibiofilm effects for subsequent experimental evaluations. The computational approach exhibited high accuracy in predicting the antibiofilm effects of peptides, with accuracy, precision, Matthew's correlation coefficient (MCC), and F1 score of 99%, 99%, 0.97, and 0.99, respectively. The performance level of this computational approach was comparable to that of previous methods. This study introduced a novel approach by combining the feature space with high antibiofilm activity. In this study, a reliable and cost-effective method was developed for predicting the antibiofilm effects of peptides using a computational approach. This approach allows for the identification of peptide sequences with substantial antibiofilm activities for further experimental investigations. Accessible source codes and raw data of this study can be found online (hiABF), providing easy access and enabling future updates.


---

# Machine learning and drug discovery for neglected tropical diseases

- **Authors:** William Breslin, Doan Pham
- **Issuer:** BMC bioinformatics
- **Type:** Scientific article
- **Published:** 2023-04-24
- **Language:** en
- **DOI:** 10.1186/s12859-022-05076-0
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37095460/
- **Licence:** CC-BY

## Section: Abstract

AbstractNeglected tropical diseases affect millions of individuals and cause loss of productivity worldwide. They are common in developing countries without the financial resources for research and drug development. With increased availability of data from high throughput screening, machine learning has been introduced into the drug discovery process. Models can be trained to predict biological activities of compounds before working in the lab. In this study, we use three publicly available, high-throughput screening datasets to train machine learning models to predict biological activities related to inhibition of species that cause leishmaniasis, American trypanosomiasis (Chagas disease), and African trypanosomiasis (sleeping sickness). We compare machine learning models (tree based models, naive Bayes classifiers, and neural networks), featurizing methods (circular fingerprints, MACCS fingerprints, and RDKit descriptors), and techniques to deal with the imbalanced data (oversampling, undersampling, class weight/sample weight).Keywords: Machine learing, Drug discovery, Tropical disease

## Section: Introduction

Leishmaniasis, African trypanosomiasis (sleeping sickness), and American trypanosomiasis (Chagas disease) have been listed in the top list of global burden diseases by the World Health Organization. Leishmaniasis affects 12 million people worldwide, and is considered to be one of the world’s most neglected diseases [1–3]. It is caused by a Trypanosomatid protozoan parasite from the genus Leishmania. American trypanosomiasis, also known as Chagas disease, affects more than 7 million people worldwide and is caused by the protozoan parasite Trypanosoma cruzi [2–4]. African Trypanosomiasis, also known as sleeping sickness, affects 300,000 people worldwide and is caused by the parasite Trypanosoma brucei.

The only approved therapeutics for the treatment of these diseases are expensive, not very effective and have adverse side effects [5–7]. Thus it is important to keep searching for new treatments. Target-based drug discovery involves “screening a library of compounds against a protein and then optimizing the compounds for potency against the enzyme, selectivity, cellular activity, and pharmacokinetic properties” [8]. As the screening process can involve tens of thousands of compounds, it is often costly and time-consuming. We hope to save time and cut costs by using machine learning in the screening process and only testing compounds in the lab which are predicted to be useful by the models. In this study, we train machine learning models (using data from high-throughout screenings) to predict whether a compound will inhibit a disease-causing parasite. Different models, types of features, and techniques to deal with imbalance datasets are compared. For more on using machine learning in drug discovery for neglected tropical diseases, see [5, 6, 9–12].

## Section: Methods › Bioassays and data sources

The three datasets used were downloaded from PubChem, a database collecting information on small molecules and datasets on high throughput biological assays and maintained by the National Center for Biotechnology Information.

Leishmaniasis The assay used to train models for Leishmaniasis has PubChem AID 1721. The target is the enzyme pyruvate kinase from Leishmania mexicana. Of the 292,732 compounds tested, only 1088 are active (≈0.37% active).

African trypanosomiasis The assay used to train models for African trypanosomiasis has PubChem AID 485367. The target is the enzyme phosphofructokinase from T. brucei. Of the 330,677 compounds tested, only 557 are active (≈0.17% active).

American trypanosomiasis The assay used to train models for American trypanosomiasis has PubChem AID 1885. Of the 303,218 compounds tested, only 4394 are active (≈1.45% active).

All three assays were luminescence-based assays. Decreased luminescence indicates inhibition of the target and therefore the corresponding compound may kill the parasite.

## Section: Methods › Preprocessing and featurizing

The structure of each compound was downloaded from PubChem in the Structural Data Format (SDF). We then used the python packages DeepChem [13] and RDKit [14] to generate descriptors for each compound.

Circular fingerprints Circular fingerprints are a type of hashed fingerprint. All substructures up to a given diameter are enumerated and converted to numeric values using a hash function. These values are used to indicate bit positions in the fingerprints. Thus each compound is represented by a vector of 0s and 1s, with the 1s indicating presence of a substructure. Each position in the vector corresponds to more that one possible substructure (leading to possible “bit collisions”), with longer fingerprints having fewer bit collisions [15]. We used fingerprints of sizes 256 and 1024 in this study.

MACCS fingerprints The MACCS (Molecular ACCess System) fingerprints are similar to circular fingerprints because they are vectors of 0s and 1s with each 1 indicating presence of a substructure. MACCS fingerprints are generated using a fixed list of 166 substructures and were developed by Molecular Design Limited, Inc. [16].

RDKit descriptors The python package RDKit has a module RDKit.Chem.Descriptors that calculates 208 chemical properties of each compound. A list can be found at [17].

Concatenations of different descriptors We also trained our models using concatenations of different features. We used the concatenation of MACCS fingerprints with RDKit features, the concatenation of 1024 fingerprints with RDKit features, and the concatenation of MACCS fingerprints, 1024 fingerprints, and RDKit features.

Since the data is so imbalanced, we used a random stratified splitter to split the entire set of compounds into 80% training set and 20% test set. This preserves the ratio of active to inactive. We used three different splits for training and testing and averaged the results.

## Section: Methods › Machine learning models

We trained our machine learning models using the scikit-learn (sklearn) library in python [18] and used the default parameters from sklearn. It should be noted that the performance of the models will most likely improve with hyperparameter tuning. The Keras library was used for neural networks. Early stopping with a patience of 2 was used for the neural network models. A 10% validation set was split from the training set for this.

Naive Bayes classifiers The Naive Bayes classifier (NB) is based on Bayes’ Theorem. The “naive” assumption we make is that the descriptors are independent.

Tree based classifiers Both of the tree-based models we used are examples of “boosting”. In machine learning, boosting is used to convert many weak models into a single strong model. Gradient Boosted Decision Tree (GBDT) models are based on a method introduced by Friedman [19]. The idea is to use gradient descent to adjust the parameters of a tree in order to decrease a differentiable loss function. The default loss function for GBDT in sklearn is Friedman mean squared error. Adaboost can be thought of as a special case of GBDT in which the loss function is the exponential loss function. It was introduced by Freund and Schapire [20].

Neural networks Artificial Neural Networks are models that (very roughly) mimic the complex structure and functioning of the brain [21]. A fully connected neural network can be described by the number of neurons in each hidden layer. We used two different networks, one with a single hidden layer of 100 neurons and one with five hidden layers: 100–100–100–100–20.

## Section: Methods › Imbalanced data

The three datasets used to train our models are all very imbalanced. The ratio of active to inactive compounds is very low (ranging from 0.17 to 1.45%), This presents difficulties in both training and evaluation of the models.

## Section: Methods › Imbalanced data › Measuring success of a model

A common metric for measuring success of a classifier is accuracy score:

If a model were to predict all 330,677 compounds in PubChem AID 485367 are inactive, then the accuracy of that model would be ≈0.9983. However, we would miss all 557 active compounds and we are interested in identifying active compounds. A metric better suited to imbalanced data sets is the balanced accuracy score (BA). It is the average of the true positive rate TPR (also known as sensitivity) and true negative rate TNR (also known as specificity):

where TPR=TPP and TNR=TNN. The balanced accuracy score of a model predicting all compounds in PubChem AID 485367 to be inactive would only be 0.5. We use the balanced accuracy as our primary measure of success of our models, but also report accuracy, true positive rate and false positive rate (FPR=FPN).

## Section: Methods › Imbalanced data › Training models with imbalanced data

We used three techniques to adjust our models to perform better with imbalanced data: oversampling, undersampling, and sample weights.

When we train models using oversampling, active compounds in the training dataset are randomly duplicated until the dataset has the same number of actives and inactives. When using undersampling, a subset with the same size as the set of active compounds is randomly selected from the set of inactive compounds in order to create a balanced training set.

If the sample weights of active compounds are higher than that of inactive compounds, then a misclassified active compound results in a greater contribution to the loss function than a misclassified inactive compound. This also causes the model to predict more active compounds. In our study, all inactive compounds had weight 1. We started with (# of compounds)/(# of active compounds) and experimented to find a range of weights for the active compounds to test.

It should be noted that models trained using oversampling, undersampling, or class weights (with actives weighted more than inactives) also tend to predict more false positives. We stopped increasing the class weights of the actives when the false positive rate exceeded 20%.

## Section: Results and discussion

For each of the three PubChem datasets, we trained five different types of models: Two neural networks (NN1: one hidden layer with 100 neurons, NN2: five hidden layers 100–100–100–100–20), naive Bayes classifier (NB), adaboost tree model (Adaboost), and gradient boosted decision tree (GBDT). Each of these models was trained using five different types of features: Circular fingerprints of size 256 (256FP), circular fingerprints of size 1024 (1024FP), MACCS fingerprints (MACCS), RDKit descriptors (RDKit), and the concatenations (MACCS/RDKit, 1024FP/RDKit, 1024FP/MACCS/RDKit). For each model-feature combination, we trained a model using no imbalance technique, one using oversampling, one using undersampling, and six using different sample weights. Every combination was trained three times using different train-test splits, giving a total of 2520 trained models.

Overall model performance

Top model performance on AID 1721

Top model performance on AID 1885

Top model performance on AID 485367

Performance of models on different assays

Using imbalance techniques versus not. These plots were created using the entire set of trained models

Using oversampling (OS), undersampling (US), or sample weights (SW) versus not

Comparison of imbalance techniques

Performance of each feature type when using different models

Same scores as shown in Fig. 5, grouped by model

Top performing models (highest balanced accuracy score) by model and feature type

Mean training and prediction times by model

Mean training and prediction times by feature type

## Section: Results and discussion › Models

Figure 1 shows overall performance of the models, with balanced accuracy score shown on the vertical axis. This includes all 2520 models, including training without oversampling, undersampling, or sample weights. Overall, the highest median and mean balanced accuracy score is achieved by GBDT models, with a median balanced accuracy score of 0.762 and mean of 0.738. The neural networks have the highest individual scores but also have higher variance. NN2 has the lowest median balanced accuracy score of 0.705 while NN2 has the second lowest at 0.708.

Tables 1, 2 and 3 show the top model of each type for each of the three assays. The top models for both AID 1721 and AID 1885 are the neural networks. The neural networks had the second and third highest balanced accuracy scores on AID 485367 behind GBDT. The best performance among the three assays is achieved by NN1 on AID 1721 with a balanced accuracy score of 0.875, TPR 0.844, and FPR 0.094.

Figure 2 shows model performance on each of the three bioassays.

Overall model performance

Top model performance on AID 1721

Top model performance on AID 1885

Top model performance on AID 485367

Performance of models on different assays

## Section: Results and discussion › Imbalance techniques

Without oversampling, undersampling, or using sample weights, the performance of all the models is poor. Over 80% of these models have TPR<0.1 and over 44% have TPR=0 (i.e., predicting every compound is inactive). Of the Adaboost models without oversampling, undersampling, or sample weights, over 60% have TPR=0. Only two models trained without oversampling, undersampling, or sample weights have balanced accuracy score above 0.70. Both are Naive Bayes classifiers.

Figure 3 shows the effect of using imbalance techniques for each model. The performance increases significantly for all models. Table 4 shows mean scores for models trained with oversampling, undersampling, or sample weights versus those trained without oversampling, undersampling, or sample weights.

In Fig. 4, oversampling, undersampling, and class weights are compared for each model type. The boosts in performance of the Naive Bayes models and decision tree classifiers are similar for the three imbalance techniques, while the same is not true for the neural networks. Oversampling does not work as well as using class weights or undersampling for the neural networks.

Using imbalance techniques versus not. These plots were created using the entire set of trained models

Using oversampling (OS), undersampling (US), or sample weights (SW) versus not

Comparison of imbalance techniques

## Section: Results and discussion › Features

Figure 5 shows performance of the models, grouped by type of features used. The 1024 circular fingerprints outperform the 256 circular fingerprints, but the results are similar in terms of which models perform better or worse when using circular fingerprints. The 1024FP/RDKit and 1024FP/MACCS/RDKit features have a similar pattern to the circular fingerprints. For these feature types, gradient boosted decision trees are the top performer, followed by naive Bayes classifier and then adaboost. The neural networks were the worst performers when using circular fingerprints, 1024FP/RDKit, or 1024FP/MACCS/RDKit.

However, the neural networks outperformed all other models when using RDKit descriptors, MACCS fingerprints, or the MACCS/RDKit features. It is interesting to note that dropping 1024FP from 1024FP/RDKit or 1024FP/MACCS/RDKit significantly improves performance of the neural networks.

Figure 6 is another look at how the different models perform when using different types of features. The highest median and overall highest balanced accuracy score were obtained when using MACCS/RDKit features with NN1.

Table 5 shows the top balanced accuracy scores by model and feature type.

Performance of each feature type when using different models

Same scores as shown in Fig. 5, grouped by model

Top performing models (highest balanced accuracy score) by model and feature type

## Section: Results and discussion › Training and prediction time

Table 6 shows mean training and prediction times by model. The decision tree models take much longer to train than the neural networks or Naive Bayes classifier. Training the gradient boosted decision trees is very time-intensive, taking 10 times longer than the neural networks and over 4000 times longer than the Naive Bayes classifier. On the other hand, the neural networks take longer during the inference stage.

Table 7 shows mean training and prediction times by feature type. It is not surprising that combined features take the longest for training and predicting, while the times were shortest for MACCS fingerprints (the shortest fingerprints used).

Using undersampling is fast compared to using class weights or oversampling. The mean training time for a model using undersampling is 3.8 s. The mean training times when using class weights and oversampling are 314.9 s and 551.6 s respectively.

Mean training and prediction times by model

Mean training and prediction times by feature type

## Section: Conclusion

Neglected tropical diseases affect millions of people worldwide and there is an urgent need to develop new treatments. Identifying compounds that interact with appropriate drug targets is an important part of the drug discovery process. In this project, we trained machine learning models to predict biological activity of drug compounds and compared the results using test data. We used publicly available data to train and test our models. All three datasets are very imbalanced with many more inactive compounds than active. We compared different models, feature types, and ways to deal with the data imbalance.

Without using oversampling, undersampling, or class weights, the models did not perform well, with balanced accuracy scores not much higher than 0.5. After either using class weights or oversampling, many of the models were quite accurate. Oversampling, undersampling, and class weights resulted in a similar boost in performance for the Naive Bayes, Adaboost, and gradient boosted decision tree models, while oversampling did not perform as well as undersampling and class weights for the neural networks. Undersampling has the additional advantage of using less time and memory.

The gradient boosted decision tree models were consistently accurate while using different feature types, but took far longer to train than the other models. The Naive Bayes classifiers have an acceptable performance and are much faster to train. Several of the best single models were neural networks, but the neural networks had a larger range of balanced accuracy scores and more worse performing models.

Overall, training with concatenations of the RDKit features, 1024 fingerprints, and MACCS fingerprints yielded more accurate models than using a single type of feature, but also lead to longer training times. The neural networks performed better when using only MACCS/RDKit features while other models performed better when using all three 1024FP/MACCS/RDKit features. Among the single feature types, the RDKit descriptors produced the best models.

These models can used to prioritize compounds in screening experiments and we hope such techniques lead to a more efficient drug discovery process.

## Section: Acknowledgements

Not applicable.

## Section: Author contributions

WB wrote the code to process the data and train/test the models. DP and WB found and collected the data, and wrote the manuscript. Both authors approved the manuscript and agree with its submission to BMC Bioinformatics.

## Section: Funding

Partial financial support was provided by Pacific University.

## Section: Availability of data and materials

The unprocessed datasets are available from PubChem (https://pubchem.ncbi.nlm.nih.gov/): AID 1721, AID 1885, AID 485367. The code and processed data will be available for research purposes upon request. Interested readers can contact William Breslin at breslin@pacificu.edu.

## Section: Declarations › Ethics approval and consent to participate

Not applicable.

## Section: Declarations › Consent for publication

Not applicable.

## Section: Declarations › Competing interests

The authors declare that they have no competing interests.

## Section: Contributor Information

William Breslin, Email: breslin@pacificu.edu.

Doan Pham, Email: doan.pham.gr@dartmouth.edu.

## Section: Associated Data › Data Availability Statement

The unprocessed datasets are available from PubChem (https://pubchem.ncbi.nlm.nih.gov/): AID 1721, AID 1885, AID 485367. The code and processed data will be available for research purposes upon request. Interested readers can contact William Breslin at breslin@pacificu.edu.


---

# Machine learning model for anti-cancer drug combinations: Analysis, prediction, and validation

- **Authors:** Jing-Bo Zhou, Dongyang Tang, Lin He, Shiqi Lin, Josh Haipeng Lei, Heng Sun, Xiaoling Xu, Chu-Xia Deng
- **Issuer:** Pharmacological research
- **Type:** Scientific article
- **Published:** 2023-06-19
- **Language:** en
- **DOI:** 10.1016/j.phrs.2023.106830
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37343647/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Drug combination therapy is a highly effective approach for enhancing the therapeutic efficacy of anti-cancer drugs and overcoming drug resistance. However, the innumerable possible drug combinations make it impractical to screen all synergistic drug pairs. Moreover, biological insights into synergistic drug pairs are still lacking. To address this challenge, we systematically analyzed drug combination datasets curated from multiple databases to identify drug pairs more likely to show synergy. We classified drug pairs based on their MoA and discovered that 110 MoA pairs were significantly enriched in synergy in at least one type of cancer. To improve the accuracy of predicting synergistic effects of drug pairs, we developed a suite of machine learning models that achieve better predictive performance. Unlike most previous methods that were rarely validated by wet-lab experiments, our models were validated using two-dimensional cell lines and three-dimensional tumor slice culture (3D-TSC) models, implying their practical utility. Our prediction and validation results indicated that the combination of the RTK inhibitors Lapatinib and Pazopanib exhibited a strong therapeutic effect in breast cancer by blocking the downstream PI3K/AKT/mTOR signaling pathway. Furthermore, we incorporated molecular features to identify potential biomarkers for synergistic drug pairs, and almost all potential biomarkers found connections between drug targets and corresponding molecular features using protein-protein interaction network. Overall, this study provides valuable insights to complement and guide rational efforts to develop drug combination treatments.


---

# Machine learning models to accelerate the design of polymeric long-acting injectables

- **Authors:** Pauric Bannigan, Zeqing Bao, Riley J. Hickman, Matteo Aldeghi, Florian Häse, Alán Aspuru‐Guzik, Christine J. Allen
- **Issuer:** Nature Communications
- **Type:** Scientific article
- **Published:** 2023-01-10
- **Language:** en
- **DOI:** 10.1038/s41467-022-35343-w
- **Source:** https://doi.org/10.1038/s41467-022-35343-w
- **Licence:** CC-BY

## Section: Abstract

Long-acting injectables are considered one of the most promising therapeutic strategies for the treatment of chronic diseases as they can afford improved therapeutic efficacy, safety, and patient compliance. The use of polymer materials in such a drug formulation strategy can offer unparalleled diversity owing to the ability to synthesize materials with a wide range of properties. However, the interplay between multiple parameters, including the physicochemical properties of the drug and polymer, make it very difficult to intuitively predict the performance of these systems. This necessitates the development and characterization of a wide array of formulation candidates through extensive and time-consuming in vitro experimentation. Machine learning is enabling leap-step advances in a number of fields including drug discovery and materials science. The current study takes a critical step towards data-driven drug formulation development with an emphasis on long-acting injectables. Here we show that machine learning algorithms can be used to predict experimental drug release from these advanced drug delivery systems. We also demonstrate that these trained models can be used to guide the design of new long acting injectables. The implementation of the described data-driven approach has the potential to reduce the time and cost associated with drug formulation development.

## Section: Introduction

Long-acting injectables (LAI) are a class of advanced drug delivery systems that are designed to release their cargo over extended periods of time in order to achieve a prolonged therapeutic effect. LAIs that are amenable to parenteral administration can confer several advantages over conventional drug formulations, including increased patient compliance and bioavailability of drug1. Moreover, LAIs can be engineered to provide either local (e.g., Zilretta®) or systemic (e.g., Lupron Depot®) drug exposure over a prolonged period, making them ideal formulation strategies for the treatment of chronic diseases2. The unparalleled chemical and physical diversity afforded by these materials makes polymer-based LAIs a particularly apt version of this drug delivery strategy. These systems can be engineered to entrap drugs within a polymer matrix with release occurring via various mechanisms, including erosion, diffusion, or simultaneous erosion and diffusion3. In addition to achieving sustained or controlled drug release, the encapsulation of drugs into these polymeric matrices can often protect therapeutic cargo4. To date, various polymer-based LAI technologies administered via the intramuscular5, subcutaneous6, and intra-articular7 routes have received regulatory approval (Fig. 1a).Fig. 1Schematic demonstrating traditional and data-driven formulation development approaches for long-acting injectables (LAIs).a Selected routes of administration for FDA-approved LAI formulations. b Typical trial-and-error loop commonly employed during the development of LAIs termed “traditional LAI formulation development”. c Workflow employed in this study to train and analyze machine learning (ML) models to accelerate the design of new LAI systems, termed “Data-driven LAI formulation development”.

Despite the advantages associated with polymeric LAIs, their translation from bench to bedside remains non-trivial. In the past two decades, only about 30 polymeric LAI products have received regulatory approval, in contrast to the thousands of conventional oral formulations approved in the same period3,8. Several pivotal challenges limit the development and clinical translation of polymeric LAIs. Firstly, there are few biodegradable polymer materials that are generally recognized as safe (GRAS) for parenteral administration. To date, the polymeric LAIs that have received clinical approval are largely based on a single polymer: poly(lactide-co-glycolide) (PLGA)2,3,9. The use of a material, such as PLGA, with an established safety profile, may accelerate the regulatory approval of new LAI formulations. However, it is well recognized that drug-polymer compatibility significantly influences the performance of a formulation, including drug loading capacity, drug release, and stability10. Given that each drug has its own unique physicochemical properties, it is unlikely that any one polymer material is ideally suited for the formulation of all drugs. Thus, reliance on the relatively small subset of polymeric materials that have GRAS status likely restricts our ability to develop polymer-based LAIs for many classes of drugs. Moreover, for a given polymer material, there is a wide range of variables that must be optimized during LAI preparation. Furthermore, changes to any of these variables have the potential to impact formulation performance, and the net effect of such alterations cannot be known a priori. Often, initially, promising formulations can fail at various stages during development due to unwanted drug release rates, making their re-formulation and re-evaluation necessary (Fig. 1b). This trial-and-error-based approach represents a significant bottleneck in LAI development11.

To date, several strategies have been investigated to inform decision-making and expedite the drug formulation development process. For instance, mathematical models have been used to describe and greatly enhance our understanding of drug release mechanisms12. However, the application of these empirical models is limited to post hoc analysis of the in vitro drug release profiles of LAIs, and they do not offer information on in vitro drug release from LAIs a priori. More recently, molecular dynamics simulations have been investigated13. These techniques have been useful in quantifying links between drug release rates and formulation parameters (including particle size and drug loading levels)14. While the development of these techniques is an active area of research, molecular scale simulations of entire drug delivery systems are computationally intensive. These approaches can be used to confer useful information on potential LAI systems; however, they cannot currently be used in place of experimental drug release assays14. Several studies have also investigated machine learning (ML) approaches11.

The application of ML in the pharmaceutical sciences is generally limited by a lack of available open-source datasets to train models11. Past efforts to predict in vitro drug release from LAIs using ML have exclusively considered neural network (NN) based models, and have examined narrow application domains. For example, Szlęk et al. used NNs to predict the drug release of proteins and peptides from PLGA-based microparticles (MPs) using a dataset of 68 PLGA formulations extracted from the literature15. Small molecule studies have also employed NNs to predict drug release, and these have generally been limited to less than 20 data instances16. The use of NNs for supervised learning tasks in the low-data regime may be associated with an increased risk of overfitting compared to alternative ML algorithms, such as tree-based models or Gaussian processes, which are usually better suited for sparse data problems.

The current study pursued the investigation and refinement of ML models for accurate prediction of fractional drug release from polymeric LAIs (Fig. 1c). To achieve this, we trained and evaluated a series of eleven different ML algorithms, including multiple linear regression (MLR), MLR with least absolute shrinkage and selection operator regularization (lasso), partial least squares (PLS), decision tree (DT), random forest (RF), light gradient boosting machine (LGBM), extreme gradient boosting (XGB), natural gradient boosting (NGB), support vector regressor (SVR), k-nearest neighbors (k-NN), and NN. The LGBM model was found to have the best performance: predicting fractional drug release with a high degree of accuracy.

a Selected routes of administration for FDA-approved LAI formulations. b Typical trial-and-error loop commonly employed during the development of LAIs termed “traditional LAI formulation development”. c Workflow employed in this study to train and analyze machine learning (ML) models to accelerate the design of new LAI systems, termed “Data-driven LAI formulation development”.

## Section: Results and discussion

Mean absolute error (MAE) values, as well as the standard error of the mean (σM; shown in brackets), obtained using the different ML algorithms following prediction of fractional drug release during nested cross-validation (i.e., n = 10 trials)

The data represent the absolute error (AE) obtained for fractional drug release predictions during nested cross-validation (i.e., n = 10 trials). Each column represents the AE value for 8013 data instances from the collective nested cross-validation test sets (light gray circles). The mean absolute error (MAE) and median AE values for each model are displayed within the boxes as closed black circles, and black dashed lines, respectively. The first and second quartiles are shown by the upper and lower edges of the respective boxes. The whiskers extend to show the rest of the distribution, excluding points determined to be “outliers” using the interquartile range method. Source data are provided as a Source Data file.

Dark blue signifies an absolute Spearman’s Rank correlation = 1, and pink represents an absolute Spearman’s Rank correlation of 0. Attached to the heatmap is a dendrogram that displays the hierarchies of feature clusters that were determined via agglomerative hierarchical clustering analysis. Source data are provided as a Source Data file.

Table summarizes the impact of feature cluster removal (i.e., based on their respective linkage distances) on the predictive performance of the LGBM model

a Select examples of experimental fractional drug release profiles (orange circles) in comparison to predicted fractional drug release profiles (blue circles) generated by the LGBM model. These include dexamethasone-loaded PLGA MPs (DEX-PLGA); temozolomide-loaded PLGA MPs (TMZ-PLGA); fluorouracil-loaded PLGA MPs (5-FU-PLGA); and paclitaxel-loaded PVL-co-PAVL cross-linked cylinders. b Shapley additive explanations (SHAP) analysis for the 15-feature LGBM model. The impact of each feature on fractional drug release is illustrated through a swarm plot of their corresponding SHAP values. The color of the dot represents the relative value of the feature in the dataset (high-to-low depicted as pink-to-blue). The horizontal location of the dots shows whether the effect of that feature value contributed positively or negatively in that prediction instance (x-axis). Source data are provided as a Source Data file.

a Experimental fractional drug release profile (orange circles) for 5-FU-PLGA plotted against the predicted fractional drug release profile (blue circles) generated by the LGBM model. b Decision path taken for each fractional drug release prediction for the 5-FU-PLGA system. This plot illustrates how the LGBM model combines the relative contribution of each input feature to return the predicted fractional drug release value. c Shapley additive explanations (SHAP) force plots for the three selected data instances (i.e., fractional drug release prediction 0.01, 0.61, and 0.82) showing a decomposition of predicted fractional drug release values into the relative SHAP contribution values for each input feature. The relative SHAP values for each input feature are shown by pink (positive) or blue (negative) bands on the force plot, with the width of the band representing the numerical contribution to the final model output. Source data are provided as a Source Data file.

Two-dimensional visualization of the SHAP values calculated for the input features of the LGBM model. The SHAP values for the 15 input features were condensed into two principal components using principal component analysis (PCA) and then grouped together using a simple unsupervised clustering algorithm (T-distributed Stochastic Neighbor Embedding). This low-dimensional/clustered plot was then utilized to visualize and compare the location of data instances corresponding to different input features, including T = 1.0; CL_Ratio; Polymer_MW; and Drug_Mw. In each case, the attached colorbar depicts the relative value of that feature in the dataset ranked from high (blue) to low (pink). Source data are provided as a Source Data file.

Table highlighting key design criteria for “fast” and “slow” release PLGA MPs based on SHAP analysis of the 15-feature LGBM model and the observed trends in the PCA plots

The design of both the SA-PLGA and OLA-PLGA was based on SHAP analysis of the trained LGBM model. Three independent batches of both formulations were prepared, and their experimental drug release was characterized in 0.5 wt% sodium dodecyl sulfate (SDS) to ensure sink conditions throughout the experiments. The fractional experimental drug release profiles for SA-PLGA and OLA-PLGA are plotted together as pink circles with a solid line (SA-PLGA) and blue hexagons with a solid line (OLA-PLGA), respectively. In both cases, the standard deviation (STD) observed for these experimental drug release measurements is displayed as a colored halo (n = 3). The fractional drug release profiles predicted by the LGBM model are also shown as pale pink circles with a broken line (SA-PLGA) and pale blue hexagons with a broken line (OLA-PLGA), respectively. Source data are provided as a Source Data file.

## Section: Results and discussion › Model selection

The dataset used to train ML models was constructed from previously published studies by our group and other research groups10,17–44. The studies performed by our group included spherical and cylinder-shaped polymeric LAIs10,18,38. Data from external sources were identified using the Web of Science search engine and the keyword combination “polymeric microparticle” and “drug delivery”17,19–37,39–44. In each research article selected for dataset construction, the in vitro release of the drug from the respective formulation was characterized. The final dataset was composed of descriptors for a range of small molecule drugs, polymer materials, and LAIs, as well as the in vitro drug release profiles and experimental conditions under which the drug release profiles were generated. In total, this included 181 drug release profiles with 3783 individual fractional release measurements for 43 unique drug-polymer combinations. The LAIs were mostly formed from commercially available polymers, such as PLGA, polylactic acid (PLA), and polycaprolactone (PCL), of various molecular weights and lactide-to-glycolide ratios (for PLGA systems). A visual representation of the fractional drug release profiles for all formulations within the collected dataset is shown in Supplementary Fig. 1. A summary of this dataset in terms of drug–polymer combinations is included in Supplementary Fig. 2.

Seventeen molecular and physicochemical descriptors were initially selected based on domain knowledge as input features to describe the LAI formulations of the various ML models. This included input features that described the physicochemical properties of the drug, polymer and LAI system and features that accounted for experimental conditions under which the in vitro release studies were conducted. As shown in Supplementary Table 1, the models were trained in such a way that for each drug release profile for a specific LAI, only the input feature, the timepoint for drug release measurements (Time), varied with all other input features remaining constant. These included the drug’s molecular weight (Drug_MW), topical polar surface area (Drug_TSPA), number of heteroatoms (Drug_NHA), melting temperature (Drug_Tm), acid dissociation constant (Drug_pKa), and calculated partition coefficient (Drug_LogP) as well as polymer molecular weight (Polymer_MW), molar cross-linking ratio (CL_Ratio), and lactide-to-glycolide ratio (LA/GA), the drug loading capacity of the LAI expressed as a fraction (DLC), the initial drug-to-polymer ratio used to prepare the LAIs (Initial D/M ratio), the surface area-to-volume ratio of the LAI (SA-V), the percent of surfactant in the experimental release media (SE), fractional drug release at 6 h (T = 0.25), fractional drug release at 12 h (T = 0.5), and fractional drug release at 24 h (T = 1.0).

The selected panel of ML models was trained and evaluated using a nested cross-validation strategy that included an inner loop (i.e., model training and hyperparameter tuning) and an outer loop (i.e., model evaluation). Briefly, for each ML model, 20% of the drug–polymer groups in the dataset were randomly selected as a test set. The remaining 80% were used for model development. Within the inner loop, each model was subject to a hyperparameter optimization procedure using group k-fold (k = 10) cross-validation. Model hyperparameters were tuned using a random grid search, where the objective function was the average model performance across these k-fold groups of drug-polymer combinations. The range of model hyperparameters considered, as well as the final selected values, are shown in Supplementary Tables 2–8. Following the selection of the “best” hyperparameters within the inner loop, the model was then evaluated on the test set within the outer loop. This nested cross-validation strategy was implemented ten times for each ML model to determine the average model performance across randomly generated test sets. This cross-validation strategy resulted in some overlap for specific drugs between the inner and outer loops, as well as a similar overlap for specific polymers. However, grouping by drug–polymer combination ensured that there were no specific LAI systems (i.e., drug–polymer combinations) present in both the training/validation (i.e., inner loop) and test (i.e., outer loop) sets, thus allowing for cross-validation against drug–polymer based splits. In all cases, model performance was assessed using mean absolute error (MAE), the average absolute difference between predicted and experimental fractional drug release values.

The overall predictive performance of each ML model on the inner (i.e., training/validation) and outer (i.e., test) nested cross-validation loops are summarized in Table 1. The results obtained for each individual trial for all models are also shown in Supplementary Tables 9–12. Overall, the predictive performance of the outer loop largely reflected the respective accuracies found in the inner loop: indicating good model fitting. Specifically, the tree-based ML models were, on average, more accurate (MAE < 0.16) than the linear, instance-based, and deep learning models investigated. This is consistent with a recent study demonstrating that tree-based models remain state-of-the-art for medium-sized datasets (~10 K samples)45. The LGBM model had the highest overall prediction accuracy, with MAE values of 0.125 (±0.039) and 0.114 (±0.036) obtained for the inner and outer loops, respectively. Considering the MAE values across the various nested cross-validation trials, the performance of the LGBM model appeared to be closely matched by RF, NGB, and XGB models. To better illustrate the performance of these models, the absolute error values generated for all predictions across the ten nested cross-validation trials are summarized in Fig. 2. While the mean values for the LGBM, RF, NGB, and XGB models are close, the deviation of absolute error values varied between these forest-based models. Overall, the LGBM model afforded the most narrow distribution in absolute error values for the test data. There was found to be a statistically significant difference between the absolute error values generated by the LGBM model compared to the other models (p < 0.05). Thus, the LGBM model was selected for further development.Table 1Mean absolute error (MAE) values, as well as the standard error of the mean (σM; shown in brackets), obtained using the different ML algorithms following prediction of fractional drug release during nested cross-validation (i.e., n = 10 trials)LGBMRFNGBXGBDTNNk-NNSVRlassoPLSMLRThe inner loop (validation)0.125 (0.039)0.130 (0.041)0.128 (0.040)0.133 (0.042)0.154 (0.049)0.166 (0.053)0.179 (0.057)0.206 (0.065)0.242 (0.076)0.246 (0.078)0.244 (0.081)Outer loop (test)0.114 (0.036)0.119 (0.038)0.122 (0.039)0.126 (0.040)0.154 (0.049)0.184 (0.058)0.176 (0.056)0.248 (0.079)0.255 (0.081)0.252 (0.080)0.255 (0.081)Fig. 2Summary of the overall predictive performance of the various ML models represented as a box and whisker plot.The data represent the absolute error (AE) obtained for fractional drug release predictions during nested cross-validation (i.e., n = 10 trials). Each column represents the AE value for 8013 data instances from the collective nested cross-validation test sets (light gray circles). The mean absolute error (MAE) and median AE values for each model are displayed within the boxes as closed black circles, and black dashed lines, respectively. The first and second quartiles are shown by the upper and lower edges of the respective boxes. The whiskers extend to show the rest of the distribution, excluding points determined to be “outliers” using the interquartile range method. Source data are provided as a Source Data file.

For comparison, we also trained and evaluated a series of ML models without any initial drug release measurements included as input features (i.e., without the features T = 0.25, T = 0.5, and T = 0.1). Models that include initial experimental measurements as input are referred to as few-shot models, and models without such inputs are referred to as zero-shot models. Few-shot models necessitate the measurement of the first few experimental points before the predictions can be performed; however, the result is often a more accurate model. In this study, it was found that the addition of initial drug release measurements (i.e., few-shot models) resulted in better performance than the corresponding models without these features (Supplementary Tables 9–13, and Supplementary Fig. 3).

Mean absolute error (MAE) values, as well as the standard error of the mean (σM; shown in brackets), obtained using the different ML algorithms following prediction of fractional drug release during nested cross-validation (i.e., n = 10 trials)

The data represent the absolute error (AE) obtained for fractional drug release predictions during nested cross-validation (i.e., n = 10 trials). Each column represents the AE value for 8013 data instances from the collective nested cross-validation test sets (light gray circles). The mean absolute error (MAE) and median AE values for each model are displayed within the boxes as closed black circles, and black dashed lines, respectively. The first and second quartiles are shown by the upper and lower edges of the respective boxes. The whiskers extend to show the rest of the distribution, excluding points determined to be “outliers” using the interquartile range method. Source data are provided as a Source Data file.

## Section: Results and discussion › Model refinement

When trained using the 17 input features mentioned above, the LGBM model was identified as the most accurate at predicting fractional drug release. In general, input feature sets for ML models should be comprehensive and encode all relevant physical information to make accurate predictions. The use of too many, possibly irrelevant features can increase the risk of introducing spurious correlations between individual features and observed release profiles which can eventually degrade the model’s generalizability. Thus, the 17-feature LGBM model was assessed, refined, and optimized through agglomerative hierarchical clustering analysis to identify potentially redundant input features. The input features were arranged into a hierarchy of clusters using the farthest neighbor clustering algorithm (Fig. 3 and Supplementary Fig. 4). With this approach, strong correlations were observed between the input features Drug_NHA, Drug_TPSA, and Drug_Mw (>0.94), with Drug_NHA and Drug_TPSA displaying the strongest correlation (0.99). A similar cluster of strong correlations was observed between T = 0.5, T = 0.25, and T = 1.0 (>0.92), with T = 0.5 and T = 1.0 displaying the strongest correlation (0.97). Thus, there was some redundancy between the 17 features. The performance of the LGBM model was then assessed following the removal of select feature clusters based on their linkage distances (Table 2 and Supplementary Table 14). The optimal version of the LGBM model was determined to be the model that could achieve the lowest MAE while minimizing the number of features. This was identified to be a 15-feature LGBM model that did not include Drug_NHA or T = 0.5. Interestingly, despite the strong correlation between Drug_TPSA, and Drug_Mw as well as between T = 0.5 and T = 1.0 it was found that the removal of any additional feature clusters resulted in a reduction in model accuracy (Table 2). In the case of Drug_NHA and Drug_TPSA, both values were generated by RDKit (based on SMILES codes), and these predictions may be incorrect and, therefore, irrelevant to the final model. For the T = 0.5 and T = 1.0 features, there may not be a sufficient number of fractional drug release values with meaningful differences at these time points. This final 15-feature LGBM model was then analyzed and deployed in a prospective study. To confirm that suitable hyperparameters were selected for the 15-feature LGBM, the nested cross-validation strategy was conducted again with this reduced number of input features. The performance was consistent with that of the 17-feature model, while the resulting hyperparameter configuration differed slightly.Fig. 3Heatmap of the absolute Spearman’s Rank correlation between the initial 17 input features.Dark blue signifies an absolute Spearman’s Rank correlation = 1, and pink represents an absolute Spearman’s Rank correlation of 0. Attached to the heatmap is a dendrogram that displays the hierarchies of feature clusters that were determined via agglomerative hierarchical clustering analysis. Source data are provided as a Source Data file.Table 2Table summarizes the impact of feature cluster removal (i.e., based on their respective linkage distances) on the predictive performance of the LGBM modelNo. of featuresMean absolute error (n = 10)Standard deviation (n = 10)Wards linkage distance170.1160.0180.00150.1160.0170.06130.1420.0170.12120.1430.0170.24110.1430.0180.29100.1430.0190.3590.1390.0220.5380.1500.0210.7650.2960.0230.8240.2960.0240.88The performance of the LGBM model with various numbers of input features was assessed by comparing the average and standard deviation of the AE values obtained from a series of trials (n = 10 trials) that randomly grouped 20% of the drug–polymer combinations as a holdout test set.

Dark blue signifies an absolute Spearman’s Rank correlation = 1, and pink represents an absolute Spearman’s Rank correlation of 0. Attached to the heatmap is a dendrogram that displays the hierarchies of feature clusters that were determined via agglomerative hierarchical clustering analysis. Source data are provided as a Source Data file.

Table summarizes the impact of feature cluster removal (i.e., based on their respective linkage distances) on the predictive performance of the LGBM model

## Section: Results and discussion › Model interpretation

To illustrate the predicted fractional drug release profiles generated by the trained LGBM model, test set drug–polymer combinations were extracted from the nested cross-validation and plotted against their respective experimental drug release profiles (Fig. 4 and Supplementary Fig. 5). Figure 4a shows the predicted and experimental drug release profiles for select LAIs from the dataset. Overall, there was good agreement between the predicted and experimental drug release profiles. The importance of the various input features in generating such fractional drug release predictions was then determined via Shapley additive explanation (SHAP) analysis of the final 15-feature LGBM model. Figure 4b shows the global contribution of each feature in terms of SHAP values. In Fig. 4b, the input features are arranged from top to bottom in order of decreasing the impact on model output. Time is listed in the top row, indicating that it had the greatest impact on the fractional drug release predictions. In addition, each row of the swarm plot in Fig. 4b also depicts an individual dot plot, with each dot representing a separate instance in the dataset. Blue dots indicate lower values for that feature in the dataset, while pink dots represent higher values. For example, blue dots in the Time row represent low values for drug release timepoints, while pink dots in the Polymer_MW row represent instances for LAIs composed of polymers with higher molecular weights in the dataset. The distance between an individual dot and the gray vertical central line reflects the extent to which that fractional drug release value deviates from the mean value of the initial dataset. For example, lower Time values (i.e., blue dots in the Time row, Fig. 4b) resulted in a strong negative contribution to fractional drug release, while higher Time values (i.e., pink dots in the Time row, Fig. 4b) resulted in a strong positive contribution. After Time, the next most influential features were T = 1.0, Drug_Mw, and Polymer_MW. T = 1.0 was observed to have a similar relative contribution to fractional drug release as Time. Specifically, lower values of T = 1.0 resulted in a strong negative contribution to fractional drug release, while higher values resulted in a strong positive contribution. Interestingly, two of the most important features are descriptors of the physicochemical properties of the drug and polymer (i.e., Drug_Mw, and Polymer_MW). This indicates that, of the components of the LAI system, the LGBM model has recognized that the molecular weight of the drug and the molecular weight of the polymer has the most significant influence on fractional drug release. The remaining molecular and physicochemical descriptors appear to have minimal contribution to fractional drug release prediction for this model. However, it should be noted that Fig. 4b only shows the effect of each individual feature and does not account for potential synergy between input features. Moreover, we know from the agglomerative hierarchical clustering analysis (Fig. 3) that a reduction in any of the remaining features has a negative impact on the performance of the model.Fig. 4Deployment of the trained 15-feature lightGBM (LGBM) model.a Select examples of experimental fractional drug release profiles (orange circles) in comparison to predicted fractional drug release profiles (blue circles) generated by the LGBM model. These include dexamethasone-loaded PLGA MPs (DEX-PLGA); temozolomide-loaded PLGA MPs (TMZ-PLGA); fluorouracil-loaded PLGA MPs (5-FU-PLGA); and paclitaxel-loaded PVL-co-PAVL cross-linked cylinders. b Shapley additive explanations (SHAP) analysis for the 15-feature LGBM model. The impact of each feature on fractional drug release is illustrated through a swarm plot of their corresponding SHAP values. The color of the dot represents the relative value of the feature in the dataset (high-to-low depicted as pink-to-blue). The horizontal location of the dots shows whether the effect of that feature value contributed positively or negatively in that prediction instance (x-axis). Source data are provided as a Source Data file.

The decision path function from the SHAP library was utilized to better visualize the collective effect of the 15 input features on model outputs. This type of analysis highlights the combined effect of the input features and allows for individual data instances to be followed and interpreted. Figure 5 illustrates how the LGBM model determines fractional drug release predictions, using a single LAI formulation from the dataset. 5-FU-PLGA (index 84 in the attached dataset) is a spherical MP (~30 µm) formulation of fluorouracil (L/G = 50:50, Mw = 104 kDa) with a DLC of 18% (wt%). Figure 5a shows a visual comparison of the experimental and predicted fractional drug release values for 5-FU-PLGA (index 84 in the attached dataset) and highlights three arbitrary prediction instances (i) Time = 0 days, predicted fractional drug release (i.e., f(x)) = 0.01; (ii) Time \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\simeq$$\end{document}≃7 days, f(x) = 0.61; and (iii) Time ≃ 20 days, f(x) = 0.82. Figure 5b shows the decision path for each of the predicted fractional drug release values. Each prediction begins at the base value for the model and migrates through the LGBM model based on the contributions of each input feature. Figure 5c shows a breakdown of the exact contribution of each input feature on the prediction of fractional drug release for the three highlighted data instances, as SHAP force plots. In Fig. 5c, the relative values of each input feature are shown by a pink (positive) or blue (negative) band on the force plot, with the width of this band representing the numerical contribution to the final model output. The contributions of each input feature are summed with the base value of the model to derive the model output.Fig. 5A visual representation of how the 15-feature LGBM model generates fractional drug release predictions using the example of 5-FU-PLGA (index 84 in the attached dataset).a Experimental fractional drug release profile (orange circles) for 5-FU-PLGA plotted against the predicted fractional drug release profile (blue circles) generated by the LGBM model. b Decision path taken for each fractional drug release prediction for the 5-FU-PLGA system. This plot illustrates how the LGBM model combines the relative contribution of each input feature to return the predicted fractional drug release value. c Shapley additive explanations (SHAP) force plots for the three selected data instances (i.e., fractional drug release prediction 0.01, 0.61, and 0.82) showing a decomposition of predicted fractional drug release values into the relative SHAP contribution values for each input feature. The relative SHAP values for each input feature are shown by pink (positive) or blue (negative) bands on the force plot, with the width of the band representing the numerical contribution to the final model output. Source data are provided as a Source Data file.

a Select examples of experimental fractional drug release profiles (orange circles) in comparison to predicted fractional drug release profiles (blue circles) generated by the LGBM model. These include dexamethasone-loaded PLGA MPs (DEX-PLGA); temozolomide-loaded PLGA MPs (TMZ-PLGA); fluorouracil-loaded PLGA MPs (5-FU-PLGA); and paclitaxel-loaded PVL-co-PAVL cross-linked cylinders. b Shapley additive explanations (SHAP) analysis for the 15-feature LGBM model. The impact of each feature on fractional drug release is illustrated through a swarm plot of their corresponding SHAP values. The color of the dot represents the relative value of the feature in the dataset (high-to-low depicted as pink-to-blue). The horizontal location of the dots shows whether the effect of that feature value contributed positively or negatively in that prediction instance (x-axis). Source data are provided as a Source Data file.

a Experimental fractional drug release profile (orange circles) for 5-FU-PLGA plotted against the predicted fractional drug release profile (blue circles) generated by the LGBM model. b Decision path taken for each fractional drug release prediction for the 5-FU-PLGA system. This plot illustrates how the LGBM model combines the relative contribution of each input feature to return the predicted fractional drug release value. c Shapley additive explanations (SHAP) force plots for the three selected data instances (i.e., fractional drug release prediction 0.01, 0.61, and 0.82) showing a decomposition of predicted fractional drug release values into the relative SHAP contribution values for each input feature. The relative SHAP values for each input feature are shown by pink (positive) or blue (negative) bands on the force plot, with the width of the band representing the numerical contribution to the final model output. Source data are provided as a Source Data file.

## Section: Results and discussion › Prospective study

Utilizing SHAP analysis allowed us to establish the importance ranking of the 15-feature LGBM model (Fig. 4) and to better understand their combined contributions in generating fractional drug release predictions (Fig. 5). This analysis also revealed that the input features which had the greatest influence on the fractional drug release predictions were Time and T = 1.0. While these are certainly features that reflect the performance of an LAI, they are not known by formulation scientists a priori. This information only becomes available once the LAIs have been prepared and characterized. However, the importance of Time and T = 1.0 to the model is intuitive, given that Time is the only feature of the model that varies for a given LAI system. T = 1.0 provides the model with fractional drug release values after one day and could be considered a proxy for the initial drug release rate. For instance, low values of T = 1.0 are likely to be indicative of sustained release profiles compared to LAIs with high fractional drug release at T = 1.0. Thus, using T = 1.0 as a proxy for initial drug release rates might inform the design attributes of new LAIs. We were interested in determining the impact of input features that are more easily manipulatable by formulation scientists (e.g., drug properties, polymer types, LAI morphology, etc.). To investigate this, we used a simple unsupervised clustering approach (i.e., T-distributed stochastic neighbor embedding; t-SNE) to group the input features of the LGBM model by their respective SHAP values, Supplementary Fig. 6.

With the assumption that lower drug release values at T = 1.0 are indicative of an LAI that provides sustained drug release (and vice versa), it is possible to identify other features of the LAI systems that are correlated with low values of T = 1.0. This was done by highlighting relative feature values in the low-dimensional cluster map of the dataset and comparing across features. Select examples of T = 1.0, CL_Ratio, Polymer_MW, and Drug_Mw are shown in Fig. 6. This information can be used to guide the design of new LAI systems. As a starting point, we focused on the design of PLGA-based MPs. PLGA was selected for the preparation of the formulations due to its commercial availability (including a wide range of molecular weights), relatively straightforward methodology for MP production (compared to cross-linked systems), and widespread use in commercially available LAI products8. Thus, our design criteria were immediately limited to systems with CL_ratio values equal to zero to exclude any of the cross-linked particles or cylinders in the collected dataset. This subset of the dataset can be seen by the pink circles (i.e., low values) in the CL Ratio subplot of Fig. 6). Following this subset of the data to the other subplots, it was noted that certain feature values were loosely associated with drug release at T = 1.0, and therefore indicative of whether an LAI would release drug faster or slower. For instance, medium-high values for Polymer_MW, medium-high values for Drug_Mw, and low-to-medium values of DLC were generally associated with low values for T = 1.0 for the PLGA LAIs. While lower values for Polymer_MW, low values for Drug_Mw, and low values for DLC were generally associated with high values for T = 1.0, for the PLGA LAIs. These trends are further highlighted in Supplementary Fig. 7, with the inclusion of an expanded series of input features. Thus, based on this analysis, we devised a table of key design criteria for PLGA MPs (Table 3). It should be noted that the relative values for these features are constrained to the values described in the initial dataset that was used to train and evaluate the model.Fig. 6Dimensionality reduction combined with Shapley additive explanations (SHAP) analysis.Two-dimensional visualization of the SHAP values calculated for the input features of the LGBM model. The SHAP values for the 15 input features were condensed into two principal components using principal component analysis (PCA) and then grouped together using a simple unsupervised clustering algorithm (T-distributed Stochastic Neighbor Embedding). This low-dimensional/clustered plot was then utilized to visualize and compare the location of data instances corresponding to different input features, including T = 1.0; CL_Ratio; Polymer_MW; and Drug_Mw. In each case, the attached colorbar depicts the relative value of that feature in the dataset ranked from high (blue) to low (pink). Source data are provided as a Source Data file.Table 3Table highlighting key design criteria for “fast” and “slow” release PLGA MPs based on SHAP analysis of the 15-feature LGBM model and the observed trends in the PCA plotsFeature/propertyValue for “fast” releaseValue for “slow” releaseDrug MWLowMedium/highPolymer MWLowMedium/highDrug TPSALowLow/mediumSA-VLowLow/mediumInitial D/M ratioLowLowDLCLowLow/medium

Based on the results of the SHAP analysis, we proceeded to prepare and characterize two separate LAIs which fulfilled the design criteria identified for fast-release and slow-release PLGA formulations (Table 3). Specifically, for the “fast” release LAI, which required a relatively low Polymer_MW, a 10 kDa PLGA was selected. While for the “slow” release LAI, which required a medium-to-high Polymer_MW, a 50 kDa PLGA was selected. The drugs to be encapsulated in the respective polymers were selected based on two criteria (i) physicochemical properties in the range determined by SHAP analysis and (ii) exclusion from the dataset used to train the model. Specifically, salicylic acid (SA) was selected as the drug for the “fast” release PLGA formulation due to its relatively low values for Drug_Mw (138.12 g/mol), Drug_TPSA (57.53 Å), Drug_pKa (1.79), Drug_logP (1.09), and Drug_Tm (159.6 °C). Olaparib (OLA) was selected for the “slow” release PLGA-based formulation due to its relatively high values for Drug_Mw (434.47 g/mol), Drug_TPSA (86.37 Å), Drug_pKa (9.96), Drug_logP (2.35), and Drug_Tm (208.5 °C).

The LAIs were then prepared using a well-established emulsion-based method at drug-to-material ratios such that the values for DLC (and Initial D/M ratio) were within the LGBM model’s design criteria for the “fast” and “slow” release formulations. Specifically, the DLC was <0.1 for the “fast” release formulation and >0.2 for the “slow” release formulation. For both the “fast” and “slow” systems, the values obtained for SA-V are indicative of spherical particle morphologies. However, the “slow” release LAIs had some medium dataset values, thus, the OLA-PLGA system was prepared with a larger particle size than the SA-PLGA. The physicochemical properties of the OLA-PLGA and SA-PLGA LAIs are summarized in Supplementary Table 15. The average particle size of the MPs was determined using laser diffraction particle size analysis, and the morphology was evaluated using scanning electron microscopy (Supplementary Fig. 8). Once prepared and characterized, the in vitro release profiles of drugs from the LAIs were evaluated in 0.5 wt% SDS and the resulting experimental release profiles were compared with the LGBM model predictions. The results of this prospective study are shown in Fig. 7 (Supplementary Fig. 9). Overall, there was good agreement between the predicted and experimental release profiles for both the “fast” and “slow” release PLGA systems. However, it was noted that the experimental release of OLA-PLGA increased significantly after day 15 compared to the predicted release profile. This increase in experimental release rate is most likely the result of PLGA hydrolysis in the release media, which is known to result in a change in release rate46. This highlights the need for more data on slow-release PLGA-based formulations and/or integration of information related to the time-dependent hydrolysis of PLGA into the model.Fig. 7Comparison of the experimental and predicted fractional drug release profiles for the salicylic acid-PLGA MP (SA-PLGA) and olaparib-PLGA MP (OLA-PLGA) formulations.The design of both the SA-PLGA and OLA-PLGA was based on SHAP analysis of the trained LGBM model. Three independent batches of both formulations were prepared, and their experimental drug release was characterized in 0.5 wt% sodium dodecyl sulfate (SDS) to ensure sink conditions throughout the experiments. The fractional experimental drug release profiles for SA-PLGA and OLA-PLGA are plotted together as pink circles with a solid line (SA-PLGA) and blue hexagons with a solid line (OLA-PLGA), respectively. In both cases, the standard deviation (STD) observed for these experimental drug release measurements is displayed as a colored halo (n = 3). The fractional drug release profiles predicted by the LGBM model are also shown as pale pink circles with a broken line (SA-PLGA) and pale blue hexagons with a broken line (OLA-PLGA), respectively. Source data are provided as a Source Data file.

Despite this potential limitation of the current model, the results for the OLA-PLGA system are promising. OLA is a poly ADP ribose polymerase (PARP) inhibitor that is commercially approved (Lynparza®) for the treatment of advanced ovarian cancer, metastatic prostate cancer, metastatic pancreatic cancer, and early (or metastatic) breast cancer47. The recommended dose of Lynparza is 300 mg (two 150 mg tablets) taken orally twice a day, and treatment continues until disease progression or unacceptable toxicity is observed48. Thus, OLA is an example of a therapeutic agent that could potentially benefit from the formulation as an LAI. While it remains to be seen if additional optimization is required to arrive at a version of OLA-PLGA that is efficacious in vivo, the deployment of the LGBM model here has directed the design of an LAI (OLA-PLGA) with significant potential.

In summary, cutting-edge ML technologies are now freely available to pharmaceutical and materials scientists. The results obtained in this study demonstrate the potential for ML to expedite the development of innovative drug-delivery technologies. Among the strengths of modern ML techniques are their ability to provide insights into how models reach their predictions. Herein we demonstrate that ML models can not only be used to predict in vitro drug release from LAIs with a high degree of accuracy but also that interpretation of such models can be used to guide the design of new formulation candidates. In the current study, we found that for this dataset, the tree-based LGBM model provided the most accurate prediction of fractional drug release. Given the small size of the dataset (<4000 observations) and that most of the data points contain variables that are properties of the drug or polymer, it is perhaps not surprising that the neural network models investigated did not perform well. As the use of ML in drug formulation development increases, we anticipate that larger datasets will become available, leading to an increase in the utility of neural networks. In the meantime, the implementation of tree-based models such as LGBM has the potential to reduce the time and cost associated with the development of LAI formulations. For instance, the data-driven approach used here directs the design of a promising LAI for the drug olaparib (OLA-PLGA). However, it remains to be seen if additional optimization is required to arrive at a version of OLA-PLGA that is efficacious in vivo. Overall, these results demonstrate a promising application of ML in drug formulation development. It is our hope that this proof-of-concept study, and its associated dataset, will aid in fostering the development of more advanced, tailored, and accurate ML approaches for the design of new drug formulations.

Two-dimensional visualization of the SHAP values calculated for the input features of the LGBM model. The SHAP values for the 15 input features were condensed into two principal components using principal component analysis (PCA) and then grouped together using a simple unsupervised clustering algorithm (T-distributed Stochastic Neighbor Embedding). This low-dimensional/clustered plot was then utilized to visualize and compare the location of data instances corresponding to different input features, including T = 1.0; CL_Ratio; Polymer_MW; and Drug_Mw. In each case, the attached colorbar depicts the relative value of that feature in the dataset ranked from high (blue) to low (pink). Source data are provided as a Source Data file.

Table highlighting key design criteria for “fast” and “slow” release PLGA MPs based on SHAP analysis of the 15-feature LGBM model and the observed trends in the PCA plots

The design of both the SA-PLGA and OLA-PLGA was based on SHAP analysis of the trained LGBM model. Three independent batches of both formulations were prepared, and their experimental drug release was characterized in 0.5 wt% sodium dodecyl sulfate (SDS) to ensure sink conditions throughout the experiments. The fractional experimental drug release profiles for SA-PLGA and OLA-PLGA are plotted together as pink circles with a solid line (SA-PLGA) and blue hexagons with a solid line (OLA-PLGA), respectively. In both cases, the standard deviation (STD) observed for these experimental drug release measurements is displayed as a colored halo (n = 3). The fractional drug release profiles predicted by the LGBM model are also shown as pale pink circles with a broken line (SA-PLGA) and pale blue hexagons with a broken line (OLA-PLGA), respectively. Source data are provided as a Source Data file.

## Section: Methods › Machine learning › Data collection

The dataset was constructed from previously published studies by our group and other research groups10,17–44. The studies performed by our group include spherical and cylinder-shaped polymeric LAIs10,18,38. Data from external sources were identified using the Web of Science search engine and the keyword combination “polymeric microparticle” and “drug delivery”17,19–37,39–44. Information related to the preparation, final composition, and release kinetics of drugs from LAIs was collected. The latter was primarily extracted from figures of in vitro drug release profiles using the “GetData Graph Digitizer” application. The final dataset contained 181 drug release profiles for 43 unique drug-polymer combinations. In total, this comprised 3783 individual fractional release measurements. The initially collected dataset was composed of a table of drug and polymer names, as well as physicochemical properties of the formulation, and fractional drug release values at various timepoints. In order to use this data to construct and train ML models, it is necessary to describe various elements using machine-readable descriptors which were generated using RDkit. The polymers and LAI formulations were described exclusively using information reported in the relevant published articles; these included; polymer_MW, LA/GA (for non-PLGA systems, this was set as zero), molecular CL_Ratio (for non-cross-linked systems, this was set as zero), initial D/M ratio, DLC, SA-V ratio for the LAI system, fractional drug release at 6 h (T = 0.25), fractional drug release at 12 h (T = 0.5), fractional drug release at 24 h (T = 1.0), and the percent of surfactant present in the release media (SE; where no surfactant was present in the release media, this was set as zero). With the exception of SA-V, T = 0.25, T = 0.5, and T = 1.0, the 17 input features were either extracted from original publications or calculated using the RDkit package. SA-V was constructed and implemented for this study as it confers information that is related to the size and shape of the LAI system. This enables the inclusion of both spherical and cylindrical-shaped LAIs in one model. For studies wherein values for fractional drug release were not available at early timepoints (i.e., T = 0.25, T = 0.5, and T = 1.0) they were imputed using best-fit polynomial curves that range from T = 0 to T = 2 days.

## Section: Methods › Machine learning › Data splitting strategy for ML model training

ML models were trained and evaluated using a nested cross-validation approach. The nested cross-validation approach consisted of an inner (training and validation) and outer (test) loop. To implement the nested cross-validation approach, the collected dataset was grouped by drug-polymer combinations (43 unique drug–polymer combinations in total), to allow cross-validation against drug–polymer based splits. For each ML model, ten trials of the nested cross-validation method were conducted to assess the general performance of each algorithm. For each implementation of the nested cross-validation method, 20% of the drug-polymer groups in the dataset were randomly held back for evaluation using the group-shuffle-split method from the Scikit-learn library in Python49. The remaining 80% of the drug-polymer groups were then used for hyperparameter selection of models in the inner loop. This was done using the random grid search method from the Scikit-learn library in Python49, with 100 random hyperparameter configurations being assessed in each case. Within the inner loop, data were again grouped and split by drug–polymer combination using the Group k-fold cross-validation strategy from the Scikit-learn library in Python49 (where k = 10). Thus, 10% of the drug-polymer groups within the inner loop were used for hyperparameter evaluation, while the other 90% were employed to train the various model architectures selected using the random grid search method. The outer loop was used to test the performance of the model structure (i.e., fixed hyperparameters) selected by the inner loop using a holdout dataset (i.e., 20% of the drug-polymer combinations in the initial dataset).

## Section: Methods › Machine learning › ML model development

In total eleven ML algorithms were trained and investigated for this task. These included MLR, lasso, PLS, DT, RF, LGBM, XGB, NGB, SVR, k-NN, and NN models. All of these models were built and evaluated in Python. NN models were built using the Keras package with the backend of TensorFlow50, LGBM models were built using the lightGBM package51, XGB models were built using the XGBoost package52, NGB models were implemented using the NGBoost package53, and all other models were built using the Scikit learn library49. In all cases, prior to training any of the ML models, a data preprocessing step was conducted to standardize the data prior to input into the ML models. This was done using the standard scalar package available in the Scikit learn library49. ML model hyperparameters were tuned using the randomized grid search package in Scikit learn49, and the negative mean absolute error metric was employed.

## Section: Methods › Machine learning › ML model evaluation

To assess the predictive performance of all trained ML models, the predictions for each outer loop (n = 10) split from the nested cross-validation were compiled into a data frame for analysis. This amounted to ~8000 data samples and enabled a more quantitative evaluation of general prediction accuracy for each model. This was done by determining the absolute error (AE) for each prediction made for each sample in each of the ten outer loops. The AE and MAE were determined using the equations shown below1\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${{{{{\rm{Absolute}}}}}}\; {{{{\rm{error}}}}}\;({{{{\rm{AE}}}}})=\left|{\hat{y}}_{i}-{y}_{i}\right|$$\end{document}Absoluteerror(AE)=y^i−yi2\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${{{{{\rm{Mean}}}}}}\; {{{{\rm{absolute}}}}}\; {{{{\rm{error}}}}}\;({{{{\rm{MAE}}}}})=\frac{\mathop{\sum }\limits_{i=1}^{n}\left|{\hat{y}}_{i}-{y}_{i}\right|}{n}$$\end{document}Meanabsoluteerror(MAE)=∑i=1ny^i−yinWhere \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${\hat{y}}_{i}$$\end{document}y^i is the predicted fraction drug release value; yi is the experimental fractional drug release value obtained from either the training or external validation datasets; n is the total number of data points.

## Section: Methods › Machine learning › Feature engineering

Agglomerative hierarchical clustering analysis was performed using the hierarchical clustering package from SciPy in Python54 to arrange the initial input features into a hierarchy of clusters using the farthest neighbor clustering algorithm. The performance of the optimal ML algorithm (LGBM) was then assessed following the removal of select clusters based on their linkage distance. Here, the hyperparameter structure for the LGBM model identified during preliminary screening (i.e., nested cross-validation) was utilized, and only the number of input features was varied.

## Section: Methods › Machine learning › Model interpretation

SHAP analysis was conducted on the trained 15-feature LGBM model. The effect of the various input features on the fractional drug release prediction for the initial dataset was assessed using the TreeSHAP package and the force plot visualizations from the SHAP library in Python55,56.

## Section: Methods › Machine learning › Principal component analysis

Dimensionality reduction was necessary to better visualize the impact of the model input features on initial drug release values. We used t-SNE to cluster the input features of the LGBM model by their respective SHAP values. To employ the t-SNE algorithm, we first utilized PCA to reduce the dimensionality of the 15-feature LGBM dataset into two principal components.

## Section: Methods › Prospective study › Materials

Resomer® RG 504 H (PLGA, LA:GA = 50:50, Mw = 38–54 k), Resomer® RG 502 H (PLGA, LA:GA = 50:50, Mw = 7–17 k,), salicylic acid (SA, ≥99.0%), poly(vinyl alcohol) (PVA, Mw = 13–23 k, 87–89% hydrolyzed), sodium dodecyl sulfate (SDS, ≥98.5%), and dimethyl sulfoxide (DMSO, ≥99.9%) were purchased from Sigma Aldrich (ON, CA). Acetonitrile (ACN, HPLC grade) and formic acid (FA, LC/MS grade) were purchased from Fisher Chemical (ON, CA). Dichloromethane (DCM, HPLC grade) and methanol (HPLC grade) were purchased from Caledon Laboratories Ltd. (ON, CA). Olaparib (OLA, ≥99%) was purchased from MedKoo Bioscience (NC, US). Phosphate buffered saline (PBS, Gibco, pH = 7.4) was purchased from Thermofisher (Massachusetts, USA). Tween 80 (reagent grade) was purchased from BioShop (ON, CA).

## Section: Methods › Prospective study › Formulation preparation

PLGA MPs were prepared based on a modified version of a previously reported oil-in-water (o/w) emulsion method25. For OLA MPs, 300 mg of RG 504 H and 200 mg of OLA were dissolved in 6 mL of a solvent mixture (DCM:DMSO = 50:50, v/v) in a 20 mL scintillation vial to produce the organic phase. The organic phase was then emulsified in 200 mL of MilliQ water (0.01 wt% PVA, previously cooled to 4 °C) using a homogenizer (L5M-A Lab Mixer, Silverson, MA, US) at 1500 rpm for 30 min. After homogenization, the emulsion was added to 500 mL of MilliQ water (without PVA, previously cooled to 4 °C) and stirred at 500 rpm for 60 min. The MPs were then filtered using a 100 µm cell strainer (Fisherbrand Sterile Cell Strainers, ON, CA), followed by a 70 µm cell strainer (Fisherbrand Sterile Cell Strainers, ON, CA) to retain the MPs within the size cut-off (i.e., 70–100 µm). MPs were then collected and frozen at −80 °C for 30 min prior to lyophilization overnight. For SA MPs, 300 mg of RG 502 H and 150 mg of SA were dissolved in 4 mL of a solvent mixture (DCM:DMSO = 75:25, v/v) in a 20 mL scintillation vial to produce the organic phase. SA MPs were then formulated as described for the OLA MP formulation, except for the filtration step, where 70 µm and 40 µm cell strainers (Fisherbrand Sterile Cell Strainers, ON, CA) were utilized to retain the MPs with diameters ranging from 40 to 70 µm.

## Section: Methods › Prospective study › Size measurement

Measurements of particle size were conducted via laser diffraction, using a Mastersizer 300 (Malvern, ON, CA) equipped with a Hydro SV accessory. For both OLA and SA MPs, around 5–10 mg of lyophilized MPs were suspended in 100 µL of MilliQ water (with 0.2 wt% Tween 80). The 100 µL MP suspensions were then added to the system for evaluation.

## Section: Methods › Prospective study › Morphology

The morphologies of lyophilized OLA and SA MPs were evaluated using scanning electron microscopy (SEM, Quanta FEG 250 ESEM) at the Centre for Nanostructure Imaging at the University of Toronto.

## Section: Methods › Prospective study › Drug loading analysis

To evaluate drug loading, ~10 mg of lyophilized MPs were weighed, and the drug was extracted using 4 mL of a DCM:DMSO solvent mixture (50:50 for OLA and 75:25 for SA, v/v) in a 20 mL scintillation vial. This solution was then vortexed until the MPs were fully dissolved in the solvent. Following this, the resulting solution was filtered (0.45 µm, Millex-HV PVDF Syringe Filters, Sigma Aldrich, CA) and appropriately diluted in methanol prior to drug quantification via high-performance liquid chromatography (HPLC). HPLC analysis of OLA and SA was performed using an Agilent Technologies 1260 Infinity II (Agilent Technologies, Santa Clara, CA, USA) with a photodiode array (PDA) detector and an XDB-C18 column (4.6 × 150 mm, ZORBAX Eclipse, Agilent). The mobile phase was composed of MilliQ water:ACN (70:30 wt%, with 0.1 wt% FA), and the flow rate was 1.2 mL/min. OLA and SA were analyzed at wavelengths of 254 nm and 303 nm, respectively. The experimental drug loading capacity (i.e., DLC) was calculated as follows:3\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${{{{{{\mathrm{Drug}}}}}\; {{{{\mathrm{loading}}}}}\; {{{{\mathrm{capacity}}}}}}}\,\left(\%\right)=\frac{{{{{\mathrm{Mass}}}}}\; {{{{\mathrm{of}}}}}\; \,{{{{\mathrm{drug}}}}}\; {{{{\mathrm{extracted}}}}}}{{{{{\mathrm{Mass}}}}}\; {{{{\mathrm{of}}}}}\; {{{{\mathrm{drug}}}}}\; {{{{\mathrm{loaded}}}}}\; {{{{\mathrm{MPs}}}}}}\times 100\%$$\end{document}Drugloadingcapacity%=MassofdrugextractedMassofdrugloadedMPs×100%

## Section: Methods › Prospective study › Drug solubility in the release media

To ensure the in vitro drug release studies were conducted under sink conditions, the solubility of the drug in the release media (PBS with 0.5 wt% SDS) was measured. Specifically, an excess amount of drug (~10 mg of OLA and ~30 mg of SA) was added to 5 mL of release media (i.e., PBS with 0.5% Tween) in scintillation vials. The scintillation vials were incubated at 37 °C with gentle stirring (50–100 rpm) overnight, followed by filtration using a filter membrane (0.45 µm, Millex-HV PVDF Syringe Filters, Sigma Aldrich, CA). The drug concentrations were then quantified using HPLC as described in the previous section.

## Section: Methods › Prospective study › Drug release assay

To characterize the in vitro drug release profiles, 8–10 mg of OLA MPs (corresponding to ~2.5 mg of drug) and 20–40 mg of SA MPs (corresponding to ~0.5 mg of drug) were weighed for each release assay. The MPs were then suspended in centrifuge tubes (15 mL, Corning, Sigma Aldrich, CA) containing 15 mL of release media. The tubes were incubated at 37 °C with gentle mixing using a tube shaker (Labquake, Fisher Scientific). At predetermined timepoints, the release samples were centrifuged at 45 × g for 3 min to pellet MPs at the bottom of the tube. Aliquots (1 mL) of the supernatant were analyzed, the remaining media was discarded, and fresh release media (15 mL) was added to each tube to ensure sink conditions. Drug release was quantified using HPLC as previously described. Fractional drug release was calculated as follows:4\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${{{{{\mathrm{Fractional}}}}}\; {{{{\mathrm{drug}}}}}\; {{{{\mathrm{release}}}}}}=\frac{{{{{\mathrm{Mass}}}}}\; {{{{\mathrm{of}}}}}\; {{{{\mathrm{drug}}}}}\; {{{{\mathrm{released}}}}}}{{{{{\mathrm{Mass}}}}}\; {{{{\mathrm{of}}}}}\; {{{{\mathrm{drug}}}}}\; {{{{\mathrm{loaded}}}}}}$$\end{document}Fractionaldrugrelease=MassofdrugreleasedMassofdrugloaded

## Section: Methods › Reporting summary

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article.

## Section: Supplementary information

Supplementary Information

Peer Review File

Description of Additional Supplementary Files

Supplementary Data 1

Reporting Summary

## Section: Supplementary information

Supplementary Information Peer Review File Description of Additional Supplementary Files Supplementary Data 1 Reporting Summary

Supplementary Information

Peer Review File

Description of Additional Supplementary Files

Supplementary Data 1

Reporting Summary


---

# Machine Learning Scoring Functions for Drug Discovery from Experimental and Computer-Generated Protein-Ligand Structures: Towards Per-Target Scoring Functions

- **Authors:** Francesco Pellicani, Diego Dal Ben, Andrea Perali, Sebastiano Pilati
- **Issuer:** Molecules (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2023-02-09
- **Language:** en
- **DOI:** 10.3390/molecules28041661
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36838647/
- **Licence:** CC-BY

## Page 1 (Section: Introduction)

Citation: Pellicani, F.; Dal Ben, D.;
Perali, A.; Pilati, S. Machine Learning
Scoring Functions for Drug
Discovery from Experimental and
Computer-Generated Protein–Ligand
Structures: Towards Per-Target
Scoring Functions. Molecules 2023, 28,
1661. https://doi.org/10.3390/
molecules28041661
Academic Editors: Chung F. Wong
and Alessandro Pedretti
Received: 7 December 2022
Revised: 5 February 2023
Accepted: 6 February 2023
Published: 9 February 2023
Copyright:
© 2023 by the authors.
Licensee MDPI, Basel, Switzerland.
This article is an open access article
distributed
under
the
terms
and
conditions of the Creative Commons
Attribution (CC BY) license (https://
creativecommons.org/licenses/by/
4.0/).
molecules
Article
Machine Learning Scoring Functions for Drug Discovery from
Experimental and Computer-Generated Protein–Ligand
Structures: Towards Per-Target Scoring Functions
Francesco Pellicani 1
, Diego Dal Ben 2
, Andrea Perali 3
and Sebastiano Pilati 1,4,*
1
Physics Division, School of Science and Technology, University of Camerino, I-62032 Camerino, MC, Italy
2
Medicinal Chemistry Unit, School of Pharmacy, University of Camerino, I-62032 Camerino, MC, Italy
3
Physics Unit, School of Pharmacy, University of Camerino, I-62032 Camerino, MC, Italy
4
INFN-Sezione di Perugia, I-06123 Perugia, PG, Italy
*
Correspondence: sebastiano.pilati@unicam.it
Abstract: In recent years, machine learning has been proposed as a promising strategy to build
accurate scoring functions for computational docking ﬁnalized to numerically empowered drug
discovery. However, the latest studies have suggested that over-optimistic results had been reported
due to the correlations present in the experimental databases used for training and testing. Here, we
investigate the performance of an artiﬁcial neural network in binding afﬁnity predictions, comparing
results obtained using both experimental protein–ligand structures as well as larger sets of computer-
generated structures created using commercial software. Interestingly, similar performances are
obtained on both databases. We ﬁnd a noticeable performance suppression when moving from
random horizontal tests to vertical tests performed on target proteins not included in the training data.
The possibility to train the network on relatively easily created computer-generated databases leads
us to explore per-target scoring functions, trained and tested ad-hoc on complexes including only one
target protein. Encouraging results are obtained, depending on the type of protein being addressed.
Keywords: molecular docking; scoring functions; machine learning
1. Introduction
Scoring functions (SFs) are popular models often adopted by medicinal chemists to
perform computational docking and to score poses of candidate ligands in the pockets of
target proteins [1,2]. They are expected to attribute the best score to the correct pose, to ac-
curately predict the binding afﬁnity (or a score proportional to the afﬁnity), and to prioritize
active ligands over inactive ones. The latter task, in particular, plays a pivotal role in virtual
screening [3]. It allows for identifying the most promising drug molecules, thus reducing
the time and the cost otherwise spent for in vitro screening [4]. Due to their importance in
drug discovery [5], the development of SFs has been the focus of intense research endeavors
for decades. Modern SFs are often grouped [6] into empirical [7], knowledge based [8],
and force ﬁelds [9] SFs. More recently, SFs have been implemented also using data-based
approaches via machine-learning (ML) techniques [10–12]. This strategy is favored by
the increasing amount of crystallographic protein–ligand structures [13], and it aims at
exploiting the effectiveness of ML techniques in extracting useful information from big
databases. An inﬂuential article was published in 2010 [14]. Therein, the authors adopted
a relatively simple ML model, namely, random forest regression [15], and they trained it
to predict binding afﬁnities using about 1200 protein–ligand complexes extracted from
the PDBBind databases [16,17]. They reported a promising Pearson correlation coefﬁcient
Rp = 0.776, which indicates a strong correlation between predicted and experimental
binding afﬁnities [18]. Notably, the ML-based SF outperformed all considered classic ones.
Later, a similar ML-based SF was specialized to virtual screening tasks, thus also addressing
Molecules 2023, 28, 1661. https://doi.org/10.3390/molecules28041661
https://www.mdpi.com/journal/molecules

## Page 2 (Section: Introduction)

Molecules 2023, 28, 1661
2 of 15
the comments of Ref. [19] on the poor performance of ML-based SFs in this task. Various
subsequent studies have adopted more advanced ML models, such as dense neural net-
works (NNs) [20], convolutional NNs [21–24], and graph NNs [25], often further increasing
the performance in binding afﬁnity prediction. For a recent review on neural networks
and deep learning techniques, see, e.g., Ref. [26]. Different complex representations have
been explored, ranging from distance-counts of protein–ligand atomic pairs (combined
with kernel ridge regression) [14,27] to three-dimensional (3D) grids of atomic features
(combined with convolutional NNs) [21–24]. However, very recent studies have put these
optimistic results into question [28]. They reported a drastic performance reduction when
ML SFs are subjected to more stringent benchmarks. Noticeable examples are so-called
vertical tests, whereby predictions are made for proteins not included in the training set,
as opposed to the more common and less stringent horizontal tests, whereby a protein
might be present both in the training and in the test sets, albeit bound to a different ligand.
Along this line, Refs. [22,27] considered scaffolding tests designed to quantify how the
prediction accuracy varies with the degree of structural similarity between the proteins
in the training and in the test sets. Notably, Ref. [28] reported that the performance of an
exemplary ML-based SF did not change when it was fed with only the protein structure, or
only the ligand structure (as opposed to the whole complex). The authors thus suggested
that the ML-based SF had not learned any information about the actual protein–ligand
binding mechanism.
A critical problem for the development of ML techniques for computational docking
is the limited number of experimental structures available for model training [18,29].
From the most relevant database, namely, the PDBBind repository, one may extract a
few thousand complex structures, depending on the required resolution [29]. While this
number is steadily increasing, it is still orders of magnitude smaller than the amount of data
typically used in other ﬁelds where ML has proven astonishingly successful, such as, e.g.,
computer vision. For example, state-of-the-art NNs for object detection are usually trained
on databases including millions of images, e.g., the ImageNet database [30]. This issue is
particularly relevant for deep NNs. These are often preferred to simpler ML regression
models, such as kernel ridge regression or support vector machines, due to their superior
generalization properties. However, in general, they require larger training databases to
avoid overﬁtting problems. Beyond the small size, training databases might be affected
by anthropogenic factors, leading to a biased selection towards particularly favourable
instances, as recently found in studies on chemical reactions [31]. The contrasting ﬁndings
discussed above call for further quantitative performance analyses on ML-based SFs,
considering in particular the role of the training set and of the test type. One of the main
questions we aim to address in this article is whether ML-based SFs can be trained using
computer-generated complex structures created using docking software, providing access
to larger and more tunable databases.
In this Article, we implement an SF using an NN with fully connected layers (FCNN).
Following Refs. [14,27], the descriptors used to represent the complex structures are counts
of atomic pairs, one belonging to the protein and the other to the ligand, within various
distance intervals. Two databases are used for training and testing. The ﬁrst includes 2408
crystallographic structures extracted from the PDBBind database. Notably, we carefully
check and prepare these structures with the inclusion of hydrogen atoms, in contrast to
previous related studies that only considered heavy atoms. The second database includes
28,200 computer-generated structures created using the CCDC Gold docking engine within
the MOE (Molecular Operating Environment) software interface [32–34]. In both databases,
the complex structures are associated with the corresponding experimental binding afﬁni-
ties. The FCNN is trained to predict binding afﬁnities of previously unseen complexes via a
supervised learning algorithm. One of our goals is to quantify the performance of a FCNN
combined with a distance-count description of protein–ligand complexes. Chieﬂy, we
compare the performances reached using experimental and computer-generated databases,
considering in both cases both horizontal as well as more challenging vertical tests. Fi-

## Page 3 (Section: Materials and Methods)

Molecules 2023, 28, 1661
3 of 15
nally, taking advantage of the creation of computer-generated databases, we explore the
development of per-target SFs designed to predict binding afﬁnities for a speciﬁc target
protein. We consider 17 exemplary targets, training a speciﬁc SF for each of them using
computer-generated databases including many complexes with different ligands docked
into the same target protein. The performances obtained on the exemplary targets are
analysed, also varying the size of the training set. In general, the obtained performances
are encouraging, with noticeable variations depending on the target. To shed some light on
these different performances, we make a comparison against basic linear regression models
based on the molecular weight, optimized for each target.
2. Materials and Methods
2.1. Experimental Database
The ﬁrst database includes 2408 complex structures obtained through X-ray crystal-
lography [35] and deposited into the Protein Data Bank [36,37] . With this experimental
technique, the positions of the heavy atoms, i.e., excluding hydrogen atoms, are estimated
with a ﬁnite resolution. We select structures with a resolution degree lower than 3 Å and
whose ligand–target interaction information is available from the PDBbind database [16,17].
The 3D structures are manually checked for possible inconsistencies and curated with the
addition of the hydrogen atoms, using the MOE software. This process is time consuming,
thus limiting the size of the experimental database. However, it allows us to adopt a more
complete representation, as opposed to various previous related studies that considered
only heavy atoms. Furthermore, the inclusion of hydrogen atoms allows for performing
a more direct comparison against the computer-generated complexes described below.
The target–ligand structures are associated with the corresponding dissociation constant
Kd. In fact, we consider the values of pKd ≡−log10(Kd). These values are retrieved
from the PDBbind database. For completeness, we report here the formal deﬁnition of
dissociation constant:
pKd = −log10(Kd) = −log10
[P][L]
[C]

,
(1)
where [P], [L], and [C] represent the concentrations of the protein, of the ligand, and of the
complex, respectively. Some relevant details on our databases are summarized in Table 1.
Table 1. Brief description of the experimental and the computer-generated databases. (*) The sign of
the docking score is changed from negative to positive for consistency with the afﬁnity values. These
databases are freely accessible using the link in Ref. [38].
Database
Number of Complexes
Mean Afﬁnity
Mean Docking Score (*)
Experimental
2408
5.98 (pKd)
Computer generated
28,200
7.48 (pKi)
11.43
2.2. Computer-Generated Database
The second database includes structures generated via computer simulations. We
refer to it as the computer-generated database. To build it, the 3D structures of 17 selected
target proteins are retrieved from the PDB repository. The selection focuses on diverse
targets with many ligands deposited in the BindingDB database [39–41]. Only complexes
with a single ligand at the binding site and no cofactors are considered. For each target,
a numerous set of ligands is retrieved. The choice of ligands is restricted among those
whose experimental binding afﬁnity for each selected target is available as expressed by
the pKi score. This score measures the target–ligand afﬁnity using a reference radio-ligand.
Its value is generally close to pKd. These ligands are docked into the respective target
using the GOLD docking engine through the MOE software. Our simulations produce
ten poses for each target–ligand pair using the GOLD docking engine. These poses are

## Page 4 (Section: Complex Representation)

Molecules 2023, 28, 1661
4 of 15
then rescored within MOE by the GBVI/WSA dG scoring function, following the protocols
of previous studies; see., e.g., Refs. [42,43]. The target–ligand pose assigned of the best
docking score is selected. The ﬁnal computer-generated database includes only the poses
corresponding to the best score for each ligand at the respective target, totalling 28,200
protein–ligand complexes. It is worth pointing out that, due to the possible inaccuracy of
the classical SF, the best pose does not necessarily match the correct experimental one. Still,
avoiding mediocre scores likely increases the chances of excluding odd poses featuring
clear inconsistencies, which might prevent the NN from learning to predict the correct
afﬁnity. The number of pairs per target ranges from 384 for the PIM2 protein, to 6568 for
the D2 protein. The selected target proteins and the corresponding number of complexes
are summarized in Table 2. Evidently, the computer-generated database is signiﬁcantly
larger than the experimental one. This allows us to better analyse the learning speed of
NNs. However, it is worth emphasizing that the docking pose created by the docking
software is affected by the possible inaccuracy of the chosen docking engine. Instead, the 3D
crystallographic structures are expected to correspond to the actual spatial conﬁguration.
It is worth pointing out that, in fact, spurious distortions might be present also in the
crystallographic structures, but this is believed to rarely happen. Clearly, while the binding
afﬁnity information present in the computer-generated database is, in fact, experimental,
the 3D complex structure is affected by the choice of the SF used by the docking engine
and, henceforth, by its possible inaccuracies. It should be noted, however, that this does
not necessarily represent a drawback. Indeed, in virtual screening campaigns, SFs are often
used to select promising ligands from software-generated poses. Therefore, training the SF
on the type of structures it will be asked to rank might actually be instrumental.
Table 2. Breakdown of the protein–ligand complexes included in the computer-generated database.
The following legend deﬁnes the protein acronyms: 5HT2A: human 5-HT2A receptor (pdbcode: 6A94);
A2A: human A2A Adenosine receptor (pdbcode: 5NM4); ACE: Human acetylcholinesterase (pdbcode:
4EY5); BACE1: human BACE-1 enzyme (pdbcode: 6UVP); D2: human D2 dopamine receptor
(pdbcode: 6CM4); DOP: human delta opioid receptor (pdbcode: 4N6H); FAAH: humanized variant of
fatty acid amide hydrolase (pdbcode: 3PPM); GR: human glucocorticoid receptor (pdbcode: 4UDD);
H1: human histamine H1 receptor (pdbcode: 3RZE); JAK1: human Janus kinase 1 (pdbcode: 6N7A);
JAK2: human Janus kinase 2 (pdbcode: 6VN8); KOP: human kappa opioid receptor (pdbcode: 4DJH);
M1: human M1 muscarinic acetylcholine receptor (pdbcode: 5CXV); MCL1: human Mcl-1 (pdbcode:
6UDV); OX2: human orexin 2 receptor (pdbcode: 5QWC); PI3K: human Phosphatidylinositol 4,5-
bisphosphate 3-kinase catalytic subunit alpha isoform (pdbcode: 6PYS); PIM2: human PIM2 kinase
(pdbcode: 4X7Q).
Protein
5HT2A
A2A
BACE1
DOP
FAAH
GR
H1
JAK1
PI3K
N. of complexes
2763
2914
1413
1243
508
843
1070
1213
1064
Protein
PIM2
ACE
KOP
M1
MCL1
JAK2
OX2
D2
N. of complexes
384
488
2431
1056
688
1394
2160
6568
2.3. Complex Representation
The input provided to the FCNN must be designed to represent, with good approx-
imation, the 3D structure of the protein–ligand complexes. The description we adopt
follows the archetypes proposed in previous studies [14,27]. Speciﬁcally, each descriptor
corresponds to the count of atom pairs within a speciﬁed distance interval, whereby the
ﬁrst atom belongs to the target, the second to the ligand. We consider the following 10
atomic species: H, C, N, O, F, P, S, Cl, Br, and I. This choice follows the study of Ref. [14]
(apart for hydrogen). See also the following studies of Refs. [23,24,27]. For the ligands, only
the species H, C, N, O, P, and S are considered here. This restriction is due to our choice of
addressing only ligands not including halogens and metallic atoms. While this is a possible
limitation of our analysis, the selected atomic species are sufﬁcient to describe many drug

## Page 5 (Section: Target Values)

Molecules 2023, 28, 1661
5 of 15
molecules and, therefore, we expect that our ﬁndings concerning training and testing proto-
cols and per-target SFs are sufﬁciently general. The above choices lead to 60 descriptors per
distance interval. Notice that halogens could be avoided also for proteins. However, NNs
quickly learn to ignore constant descriptors. Notably, our representation takes into account
H atoms. Furthermore, originally, Ref. [14] considered only one distance interval, namely,
0–12 Å. Subsequently, Ref. [27] adopted a more detailed representation, dividing the 12 Å
range into six intervals. In this article, we explore different representations, varying both
the number of intervals and their width. The goal is to identify the optimal compromise
between representation accuracy and conciseness. We point out that the original training
matrix includes descriptors which might differ by orders of magnitudes. For this reason,
a normalization operation is helpful. Our analysis on the experimental database shows
that the most effective operation is dividing by the maximum value of all descriptors. To
formally deﬁne this normalization procedure and, more in general, the descriptor vector, it
is useful to introduce the following notation: the (unnormalized) number of pairs of atomic
species A ∈(H, C, N, O, F, P, S, Cl, Br, I) (for the target) and A′ ∈(H, C, N, O, P, S) (for the
ligand) that lie in the distance interval labeled by the index k = 1, 2, . . . , kmax, where kmax is
the chosen number of intervals, is denoted as NAA′
k
. Therefore, we have 60 pairs of atomic
species, meaning that each complex is characterized by 60kmax descriptors. The interval
widths we consider are ℓ= 1.5 Å, ℓ= 2 Å, or ℓ= 3 Å. The intervals are deﬁned by the
following minimum and maximum distances: rmin = (k −1)ℓand rmax = kℓ. Different
numbers of intervals kmax are addressed. The smallest value is kmax = 1 for all three inter-
val widths. Instead, the largest number differs depending on the interval width, namely,
kmax = 6 for ℓ= 1.5 Å, kmax = 7 for ℓ= 2 Å, and kmax = 5 for ℓ= 3 Å. The normalized
descriptors are NAA′
k
/max{NAA′
k
}, where the maximum value is taken over all descriptors
of all instances in the corresponding database. This normalization is adopted for all results
reported below.
2.4. Target Values
SFs are designed to predict a score proportional to the binding afﬁnity. As already
mentioned, we train and test our FCNN SFusing, as regression target, the pKd and the pKi
values, for the experimental and the computer-generated databases, respectively. For the
latter database, in only one analysis aiming at verifying if and to what extent a ML-based
SF can mimic a classic SF, we also consider the docking score. For convenience, we adopt
as a target value the negative of the docking score, so that higher values correspond to
putatively higher afﬁnities. The mean target values of our databases are summarized in
Table 1.
Notice that, during training, we adopt the standardized targets d′ = d−µ
σ , where d is
the original value of binding afﬁnity (pKd or pKi, depending on the considered database)
or negative docking score (only when the FCNN SFis trained to reproduce the prediction
of the classic SF), µ the database mean, and σ the corresponding standard deviation. This
(linear) standardization does not affect the correlation coefﬁcient Rp, and it is introduced
only to allow us to better compare the phenomenology of the training processes on different
databases. Furthermore, to favor comparison with other studies, the mean squared error
(MSE) values reported below are computed considering un-normalized predictions and
targets d, obtained by inverting the standardization formula.
2.5. Regression Model and Training Protocol
The goal of supervised learning is to train a regression model to map the complex
descriptors to the target value, namely, the binding afﬁnity (or the negative docking score).
The regression model adopted in this article is an FCNN, namely, a dense NN with all-to-all
interlayer connectivity. The numbers of (hidden) layers Nl and of hidden neurons per
layer Nh are chosen through the analysis described in Section 3. Note that Nl does not
count the descriptor layer, nor the output layer featuring a single neuron. The activation
function in the hidden layers is the hyperbolic tangent. The network weights and biases

## Page 6 (Section: Results)

Molecules 2023, 28, 1661
6 of 15
are optimized by minimizing the loss function, namely, the MSE between the network’s
predictions and the ground-truth target values. To contrast possible overﬁtting phenomena,
the loss function is augmented with a standard L2 regularization term [44]. However,
this does not lead to signiﬁcant beneﬁts, and the results we report hereafter correspond
to a negligibly small regularization parameter. Our neural networks are implemented
and trained using a very popular framework for deep learning, namely, the Keras Python
library [45]. Furthermore, we provide the code with the trained model corresponding to
one of our most relevant SFs (see Section 3.3) at the repository of Ref. [38]. The optimization
is performed using a variant of stochastic gradient descent, named ADAM [? ]. An
adequate mini-batch size turns out to be around 50 and 200, for the experimental and the
computer-generated databases, respectively.
The training epochs are iterated until the prediction accuracy on the test set stops
improving, i.e., before entering the regime where overﬁtting phenomena dominate. Due to
the small size of the experimental database, introducing a validation set is not practical.
For consistency, the same protocol is adopted also for the computer-generated database.
This is intended to estimate the optimal potential performance. While, in principle, it might
lead to a slight overestimation, this effect is found not to be important. In particular, in
the most critical per-target FCNN SFtests, the prediction accuracy is found to be quite
stable as a function of the training epochs. To monitor the prediction accuracy, two metrics
are considered, namely, the Pearson correlation coefﬁcient Rp and the MSE. These are
computed on a test set which includes around 20% of the whole database, while the
remaining instances are used for training. The training and testing process is repeated
ten times, considering just as many different random splittings between training and test
instances, or simply different (random) selections of training data and mini-batches for
gradient descent. The accuracy scores reported hereafter correspond to the average of the
test scores, while error bars correspond to the estimated standard deviation of the average.
This averaging procedure avoids spurious ﬂuctuations due to accidentally favourable or
adverse selections of the test instances, providing a more reliable estimate of the prediction
accuracy in a realistic scenario.
3. Results
3.1. Selection of Descriptors and Network Structure
To identify the optimal choice for the complex–structure representation, we analyse
the prediction accuracy on test sets of 300 randomly chosen experimental complexes,
as a function of the number of distance intervals of atom-pair counts. The choice of
considering 300 complexes (randomly selected from the whole experimental database)
for testing is a trade off between the need of the largest possible training set and the
minimal number required for a reliable test. As discussed in Section 2.5, 10 random non-
overlapping splittings are considered to reduce the role of statistical ﬂuctuations due to
particularly favourable or adverse testing complexes. Notice that, while the test protein–
ligand complexes are distinct from those used for the optimization of weights and biases,
some target proteins might occur in both training and test sets, albeit bound to a different
ligand. This is what we refer to as a horizontal test. The results are shown in Figure 1,
considering the three interval widths, namely, ℓ= 1.5 Å, ℓ= 2 Å, and ℓ= 3 Å. For a
complete deﬁnition of the descriptor vector, we refer the reader to Section 2.3. One notices
that the maximum Rp score, which corresponds to the optimal representation, is obtained
using kmax = 4 intervals of width ℓ= 2 Å, meaning that atom pairs are counted only
if the two atoms are less than 8 Å apart. Considering that 60 pairs of atom species are
considered, the total number of descriptors is 240. This representation is adopted for all
results reported hereafter.

## Page 7 (Section: Results)

Molecules 2023, 28, 1661
7 of 15
Figure 1. Pearson correlation coefﬁcient Rp for the predictions of binding afﬁnity provided by the
FCNN SF, as a function of the number of descriptors Nf . This FCNN SFis trained and tested on the
experimental database. The protein–ligand complex structure is represented by atomic-pair counts
within a variable number of distance intervals. The three datasets correspond to different interval
widths. Sixty pairs of atomic species are considered, including pairs with hydrogen.
We identify the optimal depth and width of the neural network by analysing the Rp
score on the experimental test set. The results are shown in Figure 2 as a function of the
number of training instances Nt. Different numbers of layers Nl and of neurons per (hidden)
layer Nh are considered. The highest performance is obtained for Nl × Nh = 2 × 20. An
analogous analysis performed on the computer-generated data (not shown) indicates that,
in that case, the optimal network structure is Nl × Nh = 4 × 40. The need of a deeper
network can be attributed to the larger size of the computer-generated database. Indeed, it
is known that deeper NNs are more effective in extracting useful information from larger
databases, while they are more susceptible to overﬁtting phenomena when the database
is sparse. These two NN structures are adopted for all results reported below, unless
otherwise speciﬁed.
Figure 2. Rp score for binding afﬁnity prediction as a function of the size Nt of the (experimental)
training set. Each dataset corresponds to a choice Nl × Nh for the number of hidden layers Nl and of
neurons per layer Nh in the fully connected neural network (FCNN). The complex representation
includes Nd = 60 descriptors, with four distance intervals of width 2A.

## Page 8 (Section: Horizontal Tests on Experimental and Computer-Generated Structures)

Molecules 2023, 28, 1661
8 of 15
3.2. Horizontal Tests on Experimental and Computer-Generated Structures
One of our main goals is to compare the performances of ML-based SFs trained and
tested on experimental and on computer-generated databases. The two learning curves
for our FCNN SFare compared in Figure 3, where the Rp score for the binding afﬁnity
prediction is plotted as a function of the training set size Nt. As a term of comparison, the
Rp value obtained when the (negative) docking score is used as target value, both during
training and testing phases, is also shown. Noticeably, remarkably high performances are
obtained in this latter test, namely, Rp ≃0.82. This indicates that the chosen combination
of representation and regression models is capable of learning, within good approximation,
the function corresponding to the docking score. Clearly, while this result suggests that
a ML-based SF can at least imitate a classic SF, it does not imply a good performance for
binding afﬁnity prediction since, as already discussed, classic SFs do not always perform
well in this task. Indeed, the maximum Rp score corresponding to the binding afﬁnity
prediction is somewhat smaller, namely, Rp ≃0.55 and Rp ≃0.60, for the experimental
and the computer-generated databases, respectively. These scores still correspond to
moderately strong correlations between predictions and ground-truth (i.e., experimental)
binding afﬁnities. The lower score at the maximum Nt on the experimental database can be
attributed to the larger size of the computer-generated one. Actually, it appears that the
learning is faster on the experimental database, since higher accuracies are in fact obtained
when the training set size Nt is comparable. To further inspect this effect, the same Rp
scores are plotted in Figure 4 as a function of the percentage of training instances compared
to the size N of the whole database. One observes an approximately linear increase. The
slopes corresponding to the experimental and to the computer-generated databases are
comparable. This suggests that the performance improves due to the increasing probability
of ﬁnding the same or similar proteins in both the training and the test sets. In concord with
this supposition, the Rp score is consistently higher on the computer-generated database,
whereby the number of proteins is lower. A similar supposition has been put forward in
Ref. [28], and it is supported also by the vertical tests discussed below.
Figure 3. Rp prediction–accuracy score as a function of the training set size Nt. The green squares
and the red rhombi correspond to the binding afﬁnity prediction by the FCNN SFtrained on the
experimental complexes and on the computer-generated databases, respectively. The blue triangles
correspond to the predictions of the docking score by the FCNN SFtrained on the computer-generated
database. The network structure is described in Figures 1 and 2.

## Page 9 (Section: Vertical Tests)

Molecules 2023, 28, 1661
9 of 15
Figure 4. Rp prediction–accuracy score as a function of the percentage of the training set size Nt
compared to the whole database size N, namely, 100Nt/N. The red rhombi and the blue squares
correspond to the FCNN SFtrained on the experimental complexes and on the computer-generated
complexes, respectively.
3.3. Vertical Tests
The horizontal tests described above provide encouraging results. As anticipated,
however, these might be over-optimistic, being biased by the similarities among the com-
plexes present in the training and in the test sets. In a real-case scenario, universal SFs
are expected to describe the binding strength of candidate ligands into novel proteins
under investigation. Quite likely, these proteins are dissimilar from those included in the
databases available at the time of model deﬁnition. A fairer performance assessment is
therefore provided by so-called vertical tests, whereby complexes made from proteins
present in the test set are excluded from the training set. The ﬁrst vertical test we consider
is performed on computer-generated complexes made from the four proteins FAAH, PIM2,
ACE, and MCL1, totaling 2068 complexes. The FCNN SFis trained on Nt complexes made
from the remaining 13 proteins of our computer-generated database (see Table 2). The
Rp score is shown in Figure 5 as a function of Nt. One notices a signiﬁcantly reduced
performance compared to the horizontal test. The accuracy score, Rp ≈0.4, corresponds to
an only moderate correlation between predicted and experimental binding afﬁnities. It is
worth mentioning that a similar vertical test on computer-generated complex structures
was performed also in Ref. [27] using a random-forest regression model. That study reports
an even lower score, namely, Rp ≃0.2. We attribute the better performance of our FCNN
SFto the use of an FCNN, which is more suited for extracting useful information from
large databases. It is also worth comparing the performance of our FCNN SFwith the one
displayed by a popular classic SF. We consider the GBVI/WSA dG scoring function of
the MOE software. Since the corresponding docking score is negative, with lower values
corresponding to more favourable poses, we consider the negative of the docking score.
Its correlation with the binding afﬁnity turns out to be only marginal, corresponding to
Rp ≃0.2. To favor further comparative studies, the code with our FCNN SF, trained on
the whole subset including the 13 groups of complexes discussed above, is provided via
the repository of Ref. [38]. While our FCNN SFseems to perform relatively better than
the two considered benchmarks, its performance is not fully satisfactory. Chieﬂy, one
notices that the performance does not improve with the training set size Nt. To further
elucidate this ﬁnding, we perform a series of per-target vertical tests. Seventeen FCNN
SF’s are trained on just as many computer-generated databases obtained by excluding
all complexes made from each of the 17 proteins. The excluded complexes are used as

## Page 10 (Section: Vertical Tests)

Molecules 2023, 28, 1661
10 of 15
test sets for the corresponding SF. The 17 corresponding Rp scores are shown in Figure 6.
Again, the performance is, on average, appreciably lower compared to the horizontal test
discussed above. This corroborates the claim that horizontal tests provide over-optimistic
performance measures, probably due to the correlations and similarities among training
and test complexes. In addition, the large performance ﬂuctuations among the 17 FCNN
SF’s corresponding to the different targets are noteworthy. For example, remarkably high
scores are obtained for the JAX1 and JAX2 proteins. These might be attributed to the
similarity between these two proteins, meaning that including in the training set complexes
derived from one of them allows the FCNN SFlearning how to predict binding afﬁnities
for the other. However, the close relationship between binding afﬁnity and the ligand
molecular weight might also play a role. This is further discussed below.
Figure 5. Mean squared error (MSE, upper panel) and Rp score (lower panel) for binding afﬁnity
prediction in the vertical test, as a function of the training set size Nt. The FCNN SFis trained on a
computer-generated database including complexes made from 13 proteins, and tested on complexes
made from four proteins not included in the training set.
Figure 6. Accuracy scores Rp for binding afﬁnity afﬁnity predictions for 17 FCNN SF’s in per-target
vertical tests. Each SF is trained on the computer-generated database excluding the complexes
made from the protein indicated on the horizontal axis, and tested on the excluded complexes. The
horizontal red line indicates the average score.

## Page 11 (Section: Per-Target Scoring Functions)

Molecules 2023, 28, 1661
11 of 15
3.4. Per-Target Scoring Functions
The unremarkable performances displayed by the universal ML-based SF in the verti-
cal tests lead us to explore different strategies. As discussed in Section 3.2, the experimental
and the computer-generated databases appear to be comparably effective for training
SFs for binding afﬁnity predictions. Clearly, the computer-generated complexes can be
relatively easily generated. This suggests the idea of developing per-target SFs on-demand,
whenever a novel protein is targeted. Such a SF would be trained on a purposely created
database including only complexes made from the target protein. To explore this direction,
we consider the six proteins with more complexes in our computer-generated database,
namely, D2, A2A, 5HT2A, KOP, OX2, and JAX2. Six per-target FCNN SF’s are trained
and tested only on complexes made from one protein. Motivated by the sizes of the six
databases, we adopt FCNNs with Nl × Nh = 2 × 20, apart for the D2 target, for which the
parameters Nl × Nh = 3 × 20 are expected to be more adequate. The corresponding Rp
scores for binding afﬁnity prediction are shown in Figure 7, as a function of the training
set size Nt. The tests are performed on 300 complexes. The performances are relatively
high. The average Rp obtained using, for each target, Nt = 900 training instances, is
Rp = 0.44. When the largest available Nt for each target is employed, the average score
is Rp = 0.52. These scores are to be compared with the average vertical test on these six
targets, corresponding to Rp = 0.30. Chieﬂy, in all six tests, the Rp score systematically
increases with Nt, suggesting that sufﬁciently performant per-target SFs can be obtained
when adequately large computer-generated training databases are available. There are
also noticeable performance differences among the six targets, ranging from Rp ≈0.4
for D2, to Rp ≈0.67 for JAK2. To shed some light on these differences, we compare the
per-target FCNN SF’s to simple linear regression models. Speciﬁcally, we assume the linear
law pKi = A + mB, where m is the ligand molecular weight (MW), and A and B are the
ﬁtting coefﬁcients. These are ﬁxed via MSE minimization on the whole per-target database.
The comparison between the per-target FCNN SFand the corresponding MW SF is shown
in Figure 8, for two exemplary targets, namely the JAK2 and OX2 proteins. Notice that the
corresponding scores in the per-target vertical tests are also shown. One notices that, for
the JAK2 protein, even the simple MW SF provides a remarkable performance, namely,
Rp ≃0.62. Tentatively, this effect might be attributed to the large pocket size at the binding
site for this particular protein, meaning that the binding strength is simply proportional
to the ligand size. Clearly, additional analyses would be required to further corroborate
this tentative explanation. Assuming this explanation is indeed sound, it not so surprising
that both the per-target FCNN SFand the universal FCNN SFin the per-target vertical test
provide comparable (but still superior) scores. Instead, for the OX2 protein, the predictions
of the MW SF have essentially zero correlation with the binding afﬁnity, corresponding
to Rp ≈0. The per-target FCNN SFreaches an encouraging Rp ≃0.53 at the largest Nt.
Notably, this per-target FCNN SFsigniﬁcantly overcomes the score of the universal FCNN
SFin the corresponding per-target vertical test (Rp ≃0.18). These ﬁndings suggest that
per-target FCNN SF’s are able to learn non-trivial mappings from computationally feasible
computer-generated databases.

## Page 12 (Section: Discussion)

Molecules 2023, 28, 1661
12 of 15
Figure 7. Rp score for binding afﬁnity predictions from six per-target FCNN SF’s, as a function of the
training set size Nt. Each SF is trained and tested on computer-generated complexes made from the
protein indicated in the legend.
Figure 8. Rp accuracy scores as a function of the training set size Nt, for two exemplary target proteins,
namely, JAK2 (cyan) and OX2 (red). The performances of the per-target FCNN SF’s (cyan triangles
for JAK2 and red circles for OX2) are compared to the corresponding scores of the FCNN SFin the
vertical test (cyan full diamond and red full square) and of the molecular weight linear regression
(cyan empty diamond and red empty square). The large green x’s correspond to the universal FCNN
SFin the horizontal test on the experimental database, while the small blue x’s correspond to the
analogous test of the computer-generated database. The horizontal gray line represents the average
score on the 17 per-target vertical tests.
4. Discussion
We have analysed the performance of scoring functions (SFs) based on fully-connected
neural networks (dubbed FCNN SF’s) in predicting the binding afﬁnities of protein–ligand
complexes from a representation of the 3D complex structure. Our choice for the structure
representation is based on atomic-pair counts within suitably chosen distance intervals, and
we investigated the optimal number and width of such intervals. The effectiveness of crys-

## Page 13 (Section: Discussion)

Molecules 2023, 28, 1661
13 of 15
tallographic 3D structures for SF training has been compared to that of computer-generated
structures created with popular commercial docking-simulation software. Notably, the
two types of data turn out to be comparably effective, suggesting that more accessible
computer-generated database can be used for SF development, rather than the less copious
experimental structures. Importantly, our FCNN SF’s have been assessed in horizontal
tests as well as in vertical tests, whereby no protein is included both in the training and in
the test databases. A signiﬁcant performance degradation is found in the latter, as in fact
reported also in the study of Ref. [27] using different regression models compared to the
neural networks adopted here. This corroborates the contention of the authors of Ref. [28],
who argued that SFs based on machine learning might not learn the ligand–target binding
mechanism, but rather the correlations among complexes present in the training and in
the test sets. These ﬁndings indicate that vertical tests represent fairer assessments for the
performances of SFs in real-case scenarios. The relative easy of creating computer-generated
databases led us to explore the development of per-target FCNN SF’s. Six exemplary targets
have been considered, obtaining encouraging results. Chieﬂy, a systematic performance
improvement with the training set size was observed. Furthermore, we found instructive
results by comparing the FCNN SF’s to linear-regression models based on the molecular
weights. Interestingly, in some cases, even such simple theories reach high correlation with
experimental binding afﬁnities.
SFs are an important tool to accelerate drug discovery. Massive research endeavours
have been devoted to implementing different families of SFs. However, the development
of SFs based on machine learning is still in an early stage. The variable and sometimes
contrasting results reported in the literature indicate that more research is due to establish
reliable benchmarking protocols. We argue that the ease of generating training data via
computer simulations, together with the ﬁrst encouraging ﬁndings reported in this article,
will favour further research endeavours aiming at developing per-target SFs based on
machine learning, tailored at speciﬁc proteins or protein families. Additional techniques
borrowed from the ﬁeld of artiﬁcial intelligence might help with facing the problems
associated with sparse, possibly biased training databases [47]. Along this line, generative
neural networks have been employed to implement de-novo molecular design, avoiding
virtual screening of excessively large databases [? ]. Further research should also consider
the use of additional complex descriptors, taking into account, e.g., entropic contributions,
hydrogen-bond information, and/or pharmacophore models. Extending the considered
atomic species, addressing, e.g., halogens, is also important; indeed, halogens species are
included in many drug-like molecules. To facilitate future comparative studies, we provide
our databases (experimental and computer-generated) via the link available in Ref. [38],
including the 3D structures, deposited in PDB ﬁles, as well as the binding afﬁnities and
the docking scores. This repository also stores the code with one of our FCNN SF’s. The
provided SF is trained on a subset of our computer-generated database, as discussed in
Section 3.3.
Author Contributions: Conceptualization, F.P., D.D.B., A.P. and S.P.; methodology, F.P., D.D.B., A.P.
and S.P.; software, F.P., D.D.B. and S.P.; formal analysis, F.P., D.D.B., A.P. and S.P.; validation, F.P.,
D.D.B., A.P. and S.P.; investigation, F.P. and S.P.; data curation, F.P., D.D.B. and S.P.; writing—original
draft preparation, F.P., D.D.B. and S.P.; writing—review and editing, F.P., D.D.B., A.P. and S.P.; funding
acquisition, D.D.B., A.P. and S.P. All authors have read and agreed to the published version of the
manuscript.
Funding: This research was funded by the University of Camerino under the FAR2018 project
titled “Supervised machine learning for quantum matter and computational docking” and by the
Italian MIUR under the project PRIN2017 CEnTraL 20172H2SC4. S.P. acknowledges PRACE for
awarding access to the Fenix Infrastructure resources at Cineca, which are partially funded by the
European Union’s Horizon 2020 research and innovation program through the ICEI project under
Grant Agreement No. 800858.
Institutional Review Board Statement: Not applicable.

## Page 14 (Section: Discussion)

Molecules 2023, 28, 1661
14 of 15
Informed Consent Statement: Not applicable.
Data Availability Statement: The databases employed in this study are available from the Zenodo
repository using the link at Ref. [38].
Acknowledgments: Fruitful discussions with Pierbiagio Pieri and Andrea De Simone are acknowl-
edged. We also thank Andrea Spinaci for support during data preparation. We also acknowledge 6
Tour S.r.l for the fruitful interactions in the initial phase of this work.
Conﬂicts of Interest: The authors declare no conﬂict of interest.
References
1.
Kulharia, M.; Goody, R.S.; Jackson, R.M. Information Theory-Based Scoring Function for the Structure-Based Prediction of
Protein- Ligand Binding Afﬁnity. J. Chem. Inf. Model. 2008, 48, 1990–1998. [CrossRef] [PubMed]
2.
Jain,
A.N.
Scoring functions for protein–ligand docking.
Curr.
Protein Pept.
Sci.
2006,
7, 407–420.
. [CrossRef] [PubMed]
3.
Walters, W.P.; Stahl, M.T.; Murcko, M.A. Virtual screening—An overview. Drug Discov. Today 1998, 3, 160–178. . [CrossRef]
4.
Wienkers, L.C.; Heath, T.G. Predicting in vivo drug interactions from in vitro drug discovery data. Nat. Rev. Drug Discov. 2005,
4, 825–833. [CrossRef] [PubMed]
5.
Drews, J. Drug discovery: A historical perspective. Science 2000, 287, 1960–1964. . [CrossRef] [PubMed]
6.
Liu,
J.;
Wang,
R.
Classiﬁcation of current scoring functions.
J. Chem.
Inf.
Model.
2015,
55, 475–482.
. [CrossRef]
7.
Gohlke, H.; Klebe, G. Statistical potentials and scoring functions applied to protein–ligand binding. Curr. Opin. Struct. Biol. 2001,
11, 231–235. . [CrossRef]
8.
Gohlke, H.; Hendlich, M.; Klebe, G. Knowledge-based scoring function to predict protein–ligand interactions. J. Mol. Biol. 2000,
295, 337–356. [CrossRef]
9.
Yin, S.; Biedermannova, L.; Vondrasek, J.; Dokholyan, N.V. MedusaScore: An accurate force ﬁeld-based scoring function for
virtual drug screening. J. Chem. Inf. Model. 2008, 48, 1656–1662. [CrossRef]
10.
Ain, Q.U.; Aleksandrova, A.; Roessler, F.D.; Ballester, P.J. Machine-learning scoring functions to improve structure-based binding
afﬁnity prediction and virtual screening. Wiley Interdiscip. Rev. Comput. Mol. Sci. 2015, 5, 405–424. [CrossRef]
11.
Li, H.; Sze, K.H.; Lu, G.; Ballester, P.J. Machine-learning scoring functions for structure-based drug lead optimization. Wiley
Interdiscip. Rev. Comput. Mol. Sci. 2020, 10, e1465. [CrossRef]
12.
Li, H.; Sze, K.H.; Lu, G.; Ballester, P.J. Machine-learning scoring functions for structure-based virtual screening. Wiley Interdiscip.
Rev. Comput. Mol. Sci. 2021, 11, e1478. [CrossRef]
13.
Palmer, R.A.; Niwa, H. X-ray crystallographic studies of protein–ligand interactions. Biochem. Soc. Trans. 2003, 31, 973–979.
[CrossRef]
14.
Ballester, P.J.; Mitchell, J.B.O. A machine learning approach to predicting protein–ligand binding afﬁnity with applications to
molecular docking. Bioinformatics 2010, 26, 1169–1175. [CrossRef] [PubMed]
15.
Svetnik, V.; Liaw, A.; Tong, C.; Culberson, J.C.; Sheridan, R.P.; Feuston, B.P. Random forest: A classiﬁcation and regression tool for
compound classiﬁcation and QSAR modeling. J. Chem. Inf. Comput. Sci. 2003, 43, 1947–1958. [CrossRef] [PubMed]
16.
Wang, R.; Fang, X.; Lu, Y.; Wang, S. The PDBbind database: Collection of binding afﬁnities for protein- ligand complexes with
known three-dimensional structures. J. Med. Chem. 2004, 47, 2977–2980. [CrossRef] [PubMed]
17.
Wang, R.; Fang, X.; Lu, Y.; Yang, C.Y.; Wang, S. The PDBbind database: Methodologies and updates. J. Med. Chem. 2005,
48, 4111–4119. [CrossRef]
18.
Liu, Z.; Su, M.; Han, L.; Liu, J.; Yang, Q.; Li, Y.; Wang, R. Forging the basis for developing protein–ligand interaction scoring
functions. Accounts Chem. Res. 2017, 50, 302–309. [CrossRef]
19.
Gabel, J.; Desaphy, J.; Rognan, D. Beware of Machine Learning-Based Scoring Functions: On the Danger of Developing Black
Boxes. J. Chem. Inf. Model. 2014, 54, 2807–2815. [CrossRef]
20.
Zhu, F.; Zhang, X.; Allen, J.E.; Jones, D.; Lightstone, F.C. Binding afﬁnity prediction by pairwise function based on neural network.
J. Chem. Inf. Model. 2020, 60, 2766–2772. [CrossRef]
21.
Jiménez, J.; Skalic, M.; Martinez-Rosell, G.; De Fabritiis, G. Kdeep: Protein–ligand absolute binding afﬁnity prediction via
3d-convolutional neural networks. J. Chem. Inf. Model. 2018, 58, 287–296. [CrossRef]
22.
Gomes, J.; Ramsundar, B.; Feinberg, E.N.; Pande, V.S. Atomic convolutional networks for predicting protein–ligand binding
afﬁnity. arXiv 2017, arXiv:1703.10603.
23.
Seo, S.; Choi, J.; Park, S.; Ahn, J. Binding afﬁnity prediction for protein–ligand complex using deep attention mechanism based on
intermolecular interactions. BMC Bioinform. 2021, 22, 542. [CrossRef] [PubMed]
24.
Stepniewska-Dziubinska, M.M.; Zielenkiewicz, P.; Siedlecki, P. Development and evaluation of a deep learning model for
protein–ligand binding afﬁnity prediction. Bioinformatics 2018, 34, 3666–3674. [CrossRef] [PubMed]

## Page 15 (Section: Discussion)

Molecules 2023, 28, 1661
15 of 15
25.
Li, S.; Zhou, J.; Xu, T.; Huang, L.; Wang, F.; Xiong, H.; Huang, W.; Dou, D.; Xiong, H. Structure-aware interactive graph
neural networks for the prediction of protein–ligand binding afﬁnity. In Proceedings of the 27th ACM SIGKDD Conference on
Knowledge Discovery & Data Mining, Virtual Event, 14–18 August 2021; pp. 975–985. [CrossRef]
26.
Emmert-Streib, F.; Yang, Z.; Feng, H.; Tripathi, S.; Dehmer, M. An Introductory Review of Deep Learning for Prediction Models
With Big Data. Front. Artif. Intell. 2020, 3, 4. [CrossRef]
27.
Wójcikowski, M.; Ballester, P.J.; Siedlecki, P. Performance of machine-learning scoring functions in structure-based virtual
screening. Sci. Rep. 2017, 7, 46710. [CrossRef] [PubMed]
28.
Yang, J.; Shen, C.; Huang, N. Predicting or pretending: Artiﬁcial intelligence for protein–ligand interactions lack of sufﬁciently
large and unbiased datasets. Front. Pharmacol. 2020, 11, 69. [CrossRef]
29.
Warren, G.L.; Do, T.D.; Kelley, B.P.; Nicholls, A.; Warren, S.D. Essential considerations for using protein–ligand structures in drug
discovery. Drug Discov. Today 2012, 17, 1270–1281. [CrossRef]
30.
Deng, J.; Dong, W.; Socher, R.; Li, L.J.; Li, K.; Fei-Fei, L. ImageNet: A large-scale hierarchical image database. In Proceedings of the
2009 IEEE Conference on Computer Vision and Pattern Recognition, Miami, FL, USA, 20–25 June 2009; pp. 248–255. [CrossRef]
31.
Jia, X.; Lynch, A.; Huang, Y.; Danielson, M.; Lang’at, I.; Milder, A.; Ruby, A.E.; Wang, H.; Friedler, S.A.; Norquist, A.J.; et al.
Anthropogenic biases in chemical reaction data hinder exploratory inorganic synthesis. Nature 2019, 573, 251–255. [CrossRef]
32.
Molecular Operating Environment (MOE), 2022.02 Chemical Computing Group ULC, 1010 Sherbooke St. West, Suite #910,
Montreal, QC, Canada, H3A 2R7, 2023. Available online: https://www.chemcomp.com/index.htm (accessed on 1 February
2020).
33.
Jones, G.; Willett, P.; Glen, R.C.; Leach, A.R.; Taylor, R. Development and validation of a genetic algorithm for ﬂexible docking. J.
Mol. Biol. 1997, 267, 727–748. [CrossRef]
34.
Greenidge, P.A.; Lewis, R.A.; Ertl, P. Boosting Pose Ranking Performance via Rescoring with MM-GBSA. Chem. Biol. Drug Des.
2016, 88, 317–328.
35.
Drenth, J. Principles of Protein X-ray Crystallography; Springer Science & Business Media: Berlin/Heidelberg, Germany, 2007.
36.
Berman, H.M.; Westbrook, J.; Feng, Z.; Gilliland, G.; Bhat, T.N.; Weissig, H.; Shindyalov, I.N.; Bourne, P.E. The Protein Data Bank.
Nucleic Acids Res. 2000, 28, 235–242. [CrossRef]
37.
The Protein Data Bank. Available online: https://www.rcsb.org/ (accessed on 1 February 2020).
38.
Pellicani, F.; Dal Ben, D.; Perali, A.; Pilati, S. Data for “Machine Learning Scoring Functions for Drug Discovery from Experimental
and Computer-Generated Protein–Ligand Structures: Towards Per-Target Scoring Functions”. Available online: https://zenodo.
org/record/7514055#.Y-SoVEFBxD8 (accessed on 1 December 2022).
39.
Chen, X.; Liu, M.; Gilson, M.K. BindingDB: A web-accessible molecular recognition database. Comb. Chem. High Throughput
Screen. 2001, 4, 719–725. [CrossRef] [PubMed]
40.
Chen, X.; Lin, Y.; Liu, M.; Gilson, M.K. The Binding Database: Data management and interface design. Bioinformatics 2002,
18, 130–139. [CrossRef] [PubMed]
41.
Liu, T.; Lin, Y.; Wen, X.; Jorissen, R.N.; Gilson, M.K. BindingDB: A web-accessible database of experimentally determined
protein–ligand binding afﬁnities. Nucleic Acids Res. 2007, 35, D198–D201. [CrossRef] [PubMed]
42.
Falsini, M.; Catarzi, D.; Varano, F.; Dal Ben, D.; Marucci, G.; Buccioni, M.; Volpini, R.; Di Cesare Mannelli, L.; Ghelardini, C.;
Colotta, V. Novel 8-amino-1,2,4-triazolo[4,3-a]pyrazin-3-one derivatives as potent human adenosine A1 and A2A receptor
antagonists. Evaluation of their protective effect against β-amyloid-induced neurotoxicity in SH-SY5Y cells. Bioorganic Chem.
2019, 87, 380–394. [CrossRef]
43.
Ceni, C.; Catarzi, D.; Varano, F.; Ben, D.D.; Marucci, G.; Buccioni, M.; Volpini, R.; Angeli, A.; Nocentini, A.; Gratteri, P.; et al.
Discovery of ﬁrst-in-class multi-target adenosine A2A receptor antagonists-carbonic anhydrase IX and XII inhibitors. 8-Amino-
6-aryl-2-phenyl-1,2,4-triazolo [4,3-a]pyrazin-3-one derivatives as new potential antitumor agents. Eur. J. Med. Chem. 2020,
201, 112478. [CrossRef]
44.
Goodfellow, I.; Bengio, Y.; Courville, A. Deep Learning; MIT Press: Cambridge, MA, USA, 2016.
45.
Chollet, F. Keras. 2015. Available online: https://keras.io (accessed on 1 June 2020).
48.
Kingma, D.P.; Ba, J. Adam: A Method for Stochastic Optimization. arXiv 2014,
47.
Brown, N.; Cambruzzi, J.; Cox, P.J.; Davies, M.; Dunbar, J.; Plumbley, D.; Sellwood, M.A.; Sim, A.; Williams-Jones, B.I.; Zwierzyna,
M.; et al. Big Data in Drug Discovery. Prog. Med. Chem. 2018, 57, 277–356. [CrossRef]
48.
Brown, N.; Fiscato, M.; Segler, M.H.; Vaucher, A.C. GuacaMol: Benchmarking Models for de Novo Molecular Design. J. Chem. Inf.
Model. 2019, 59, 1096–1108. . [CrossRef]
Disclaimer/Publisher’s Note: The statements, opinions and data contained in all publications are solely those of the individual
author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to
people or property resulting from any ideas, methods, instructions or products referred to in the content.


---

# Machine learning screening for Parkinson's disease-related cuproptosis-related typing development and validation and exploration of personalized drugs for cuproptosis genes

- **Authors:** Ji Wu, Chengjian Qin, Yuankun Cai, Jiabin Zhou, Dongyuan Xu, Yu Lei, Guoxing Fang, Songshan Chai, Nanxiang Xiong
- **Issuer:** Annals of translational medicine
- **Type:** Scientific article
- **Published:** 2023-01-10
- **Language:** en
- **DOI:** 10.21037/atm-22-5756
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36760248/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

BackgroundParkinson’s disease (PD) is a common, degenerative disease of the nervous system that is characterized by the death of dopaminergic neurons in the substantia nigra densa (SNpc). There is growing evidence that copper (Cu) is involved in myelin formation and is involved in cell death through modulation of synaptic activity as well as neurotrophic factor-induced excitotoxicity.MethodsThis study aimed to explore potential cuproptosis-related genes (CRGs) and immune infiltration patterns in PD and the development of Cu chelators relevant for PD treatment. The PD datasets GSE7621, GSE20141, and GSE49036 were downloaded from the Gene Expression Omnibus (GEO) database. The consensus clustering method was used to classify the specimens of PD. Using weighted gene co-expression network analysis (WGCNA) and random forest (RF) tree model, support vector machine (SVM) learning model, extreme gradient boosting (XGBoost) model, and general linear model (GLM) algorithms to screen disease progression-related models, the column charts were created to verify the accuracy of these CRGs in predicting PD progression. Single sample genomic enrichment analysis (ssGSEA) was used to estimate the correlation between genes associated with copper poisoning and genes associated with immune cells and immune function. Molecular docking was used to verify interactions with copper chelating agents associated with cuproptosis for PD treatment.ResultsThrough ssGSEA, we identified three copper poisoning related genes ATP7A, NFE2L2 and MTF1, which are related to immune cells in PD. We also verified that LAGASCATRIOL can bind to NFE2L2 through molecular docking. Consistent cluster analysis identified two subtypes, among which C2 subtype was just enriched in PD. And to more accurately diagnose PD progression, patients can benefit from a feature map based on these genes.ConclusionsCRGs such as NFE2L2, MTF1, and ATP7B were identified to be associated with the pathogenesis of PD and provide a possible new direction for the treatment of PD, which needs further in-depth study.

## Section: Introduction

Parkinson’s disease (PD) is a progressive neurodegenerative disorder with a high prevalence. According to statistics in 2016, over 6 million people had PD worldwide and the number of people with PD is estimated to increase with the age of the population (1). Patients with PD often require the companionship of caregivers, most of whom are under great stress, and this service imposes a heavy socio-economic burden on society (2). The clinical features of the disease include motor symptoms, including bradykinesia, resting tremor, and rigidity, and non-motor symptoms, including loss of smell, autonomic dysfunction, depression, cognitive impairment, and insomnia. The main pathological features of PD are progressive loss of nigrostriatal dopaminergic neurons and abnormal α-synuclein aggregation called Lewy vesicles (3), but the exact etiology of PD is still unclear.

In recent years, the pathological process involved in PD-associated neuronal death has been thought to be apoptosis, and a variety of cell death and mechanisms have been found to be involved in PD pathogenesis, including autophagy, necroptosis, cell death-dependence, iron death, and cell scorching (4-7). It has been shown that corynoxine derivative CB6 inhibits PD progression in mice by inducing PIK3C3 complex-dependent autophagy, whereas metformin ameliorates depression-like behavior in experimental PD by inducing autophagy in the substantia nigra and hippocampus (8,9). There is evidence that excessive copper (Cu) administration leads to a 40–60% reduction in the binding of dopamine (DA) D2 receptors to (3H)-spiperone and results in neuronal cell death and α-synuclein aggregation (10). This confirms the possibility that Cu-induced thiol modifications are involved in an important mechanism of PD progression. Another study found that Cu can be involved in the pathogenesis of PD by catalyzing harmful redox reactions including oxygen derivatives that increase oxidative stress (11). Not only this, but Cu in the brain can be directly responsive to neurotransmitters, leading to the oxidation of DA, which in turn promotes the progression of PD (12). Recently, Tsvetkov et al. revealed that Cu toxicity in human cells occurs through the direct binding of excess Cu to the lipid acylated component of the tricarboxylic acid (TCA) cycle. This leads to the accumulation of lipid acylation-related proteins, loss of iron-sulphur cluster proteins, and ultimately cell death due to intracellular proteotoxic stress, a new form of cell death known as ‘cuproptosis’ (13). Therefore, modulating Cu ions and lipid acylation in the TCA cycle may be a potential therapeutic strategy to improve the prognosis of PD.

Integrated bioinformatics analysis is now widely used to identify potential novel biomarkers and their role in various diseases, A series of bioinformatic analyses using expression profiles of peripheral blood mononuclear cells (PBMC) have been performed to identify differentially expressed genes associated with humoral immunomodulatory mechanisms between PD and healthy controls (14), but a relevant and novel comprehensive bioinformatic analysis of PD patients and healthy controls in the substantia nigra densa (SNpc) is lacking. We aim to screen potential PD patients at the genetic level and explore novel mechanisms of PD pathogenesis and initially explore novel therapeutic targets. We collected a total of 19 genes associated with cuproptosis by reviewing the literature (13,15). The GSE49036 dataset, which contains 8 control brain samples and 20 PD brain samples, was used to look for differentially expressed cuproptosis genes and explore their immune infiltration patterns with immune-related genes and PD, and also further explored these cuproptosis-related differentially expressed genes (CR-DEGs)-targeted small molecule drugs. The PD patients were further clustered, and the clinical and clustering key module genes were obtained using weighted gene co-expression network analysis (WGCNA). The most relevant diagnostic marker genes for PD were screened by machine learning and receiver operating characteristic (ROC) curve analysis was used to distinguish patients with PD from healthy controls. The diagnostic efficacy was finally validated using GSE7621 and GSE20141. In conclusion, this study explored the possible mechanisms of action of cuproptosis-related genes (CRGs) in PD and the combined immune infiltration pattern as a new therapeutic target for them. We present the following article in accordance with the TRIPOD reporting checklist (available at https://atm.amegroups.com/article/view/10.21037/atm-22-5756/rc).

## Section: Methods › Data download

Three tissue sequencing datasets of RNA microarray data on PD nigrostriatal samples were downloaded from the Gene Expression Omnibus (GEO) database (https://www.ncbi.nlm.nih.gov/geo/): GSE7621 (9 control brain samples and 16 PD brain samples), GSE20141 (8 control brain samples and 10 PD brain samples), and GSE49036 (8 control brain samples and 20 PD brain samples). These datasets were analyzed using the Affymetrix Human Genome U133 Plus 2.0 array on the GPL570 (Affymetrix GeneChip Human Genome U133 Plus 2.0 Array) platform. The above data were extracted and transformed with gene names using Perl software (https://www.perl.org/). We then screened 19 Cu amination-associated genes from previous literature (16). The study was conducted in accordance with the Declaration of Helsinki (as revised in 2013).

## Section: Methods › Data processing and CR-DEGs screening

To find differences in the expression of cuproptosis genes in the substantia nigra of PD patients compared to normal controls, CRGs were screened from the GSE49036 dataset using the limma package of R software (The R Foundation for Statistical Computing, Vienna, Austria) and CR-DEGs screening was performed on 20 PD samples and 8 control brain tissues. ggpubr package for box plot and heat map presentation of the results.

## Section: Methods › Gene set enrichment analysis

To understand the impact of CR-DEGs on the mechanisms of PD disease development, we performed a single-sample gene set enrichment analysis (ssGSEA), using the limma package, org.Hs.eg.db, and clusterProfiler package, to an analysis and visualization of the diagnostic genes.

## Section: Methods › Investigation of immune cell infiltration

To understand the immune microenvironment in PD, we used a previously established method (17) to quantify immune infiltration and associated immune functions by ssGSEA, which calculates an enrichment score representing the level of immune cell infiltration and immune-related pathway activity. The “ggplot2” package was used to create a heat map of the distribution and variation of immune cells.

## Section: Methods › Competing endogenous RNA network search

To find possible messenger RNA-microRNA-long noncoding RNA (mRNA-miRNA-lncRNA) network relationships for CR-DEGs, we firstly searched MiRanda (http://www.microRNA.org), miRDB (http://www.miRDB.org/), and TargetScan (http://www.TargetScan.org/vert_71/) to find miRNAs for PD-CR-DEGs. The screening criteria were that the miRNAs predicted by all 3 databases were the mRNA-miRNAs we were looking for, and then the lncRNAs corresponding to the miRNAs were found by using the spongeScan website (18) (spongeScan: a web for detecting microRNA binding elements in lncRNA sequences). Finally, the predictions were visualized using Cytoscape 3.8.2 (https://cytoscape.org/).

## Section: Methods › Drug screening and molecular docking

We used the DGIdb database (https://dgidb.genome.wustl.edu/) for drug prediction of differential genes in order to explore possible targeting small molecule drugs for CR-DEGs. Using the search drug-gene interactions option on the web page, and by entering PD-CR-DEGs into the prediction, results were obtained and downloaded from the webpage by censoring the gene-drugs reported in the literature and visualizing the results of the gene-drug prediction network using Cytoscape 3.8.2. The top 5 gene-drug interaction scores were selected by eliminating chemotherapeutic drugs from the above results and using AutoDock to perform small-molecule drug-large-molecule protein docking, as in our previous studies (19,20). The energy required for docking was heat mapped using the R package pheatmap.

## Section: Methods › Genotyping and enrichment analysis

First, we found CR-DEGs by the methods described above. We used the R package to classify patients into different molecular subtypes based on the expression of CRGs. The R package ConsensusClusterPlus was used to remove the control samples from the GSE49036 dataset, retaining only the experimental samples. We set the cluster maxK =9, selected the most significant clusters by consistency scoring, and used principal component analysis (PCA) to determine whether the clusters were significant. The R software Limma and pheatmap packages were then used to explore the differential PD CR-DEGs after clustering, and to investigate CR-DEGs with molecular subtype salient features, we performed a gene set variation analysis (GSVA) using the marker gene set (c2. c2.cp.kegg.symbols.gmt, c5.go.symbols.gmt) from the MSigDB database derivation. We then used the Profiler package in R to analyze the enrichment features of the genes. The results were visualized using the “ggplot2” package.

## Section: Methods › Weighted co-expression network construction

We constructed a co-expression network of DEGs using the WGCNA package in R. Next, Pearson’s correlation matrix was performed on pairs of genes. To further analyze the sample clustering to detect outliers, we calculated the dissimilarity of the module feature genes, selected tangents to the module dendrogram, and merged some modules. Module assignments determined by dynamic tree cuts were shown using the colored rows below the dendrogram. By analyzing the module-trait relationships between module trait genes and clinical traits, two modules associated with a specific trait were identified. The same approach was used to cluster type the two modules associated with a specific trait and their most significant trait modules were Venn diagrammed to find the clinical traits and the common trait genes that were significant after clustering.

## Section: Methods › Machine learning methods for filtering feature model construction and validation

After clustering, the above obtained clinical traits and significant common trait genes were used to construct a random forest (RF) tree model, support vector machine (SVM) learning model, extreme gradient boosting (XGBoost) model, and general linear model (GLM) using R software, recursive feature elimination (RFE) in Random Forest Algorithm is a supervised machine learning method for sequencing genes associated with copper poisoning in PD. The prediction performance was estimated by ten-fold cross-validation, and the genes whose relative importance was >0.25 were identified as the characteristic genes. SVM is a small sample learning method, which basically bypasses the traditional process of induction to deduction, realizes efficient “reverse reasoning” from training to prediction of samples, and simplifies common classification and regression problems. XGBoost is a representative algorithm based on integrated lift, which complements the overfitting problem of gradient lift model. The GLM is an extension of the traditional linear model, which is an algorithm in which the population mean is passed by a nonlinear join function to better process and obtain non-normally distributed data (21). Using the four methods described above to construct a diagnostic model with characteristics, the data samples were first subjected to residual analysis, and to plot the reverse cumulative distribution of residuals for the four methods. The ROC curves of the four methods were plotted, and the best feature models for machine learning were selected based on the reverse cumulative scores of the residuals and the area under the curve (AUC) values under the ROC curves. The best predictive models were plotted on column line plots, calibration curves, and decision curves using packages such as rms and rmda. Finally, the ROC curves were used to verify the diagnostic performance of the models in the GSE7621 and GSE20141 datasets.

## Section: Methods › Statistical analysis

All statistical analyses were performed using R version 4.1.0, One-way ANOVA was performed to compare the differences among multiple groups (≥2 groups). The Student’s t-test was used to compare the differences between the two groups. Statistical significance was set at P<0.05.

## Section: Results

Flow chart of the systematic analysis of cuproptosis-related diagnostic genes and medication of PD. In WGCNA selection, red represents a positive association with PD, while blue represents a negative association with PD. In the energy heat map, the redder the color, the greater the energy required for intermolecular binding. In PD-immunocorrelation analysis diagnostic genes, red represents high expression in PD tissue, while blue represents low expression in PD tissue. *, P<0.05; **, P<0.01; ***, P<0.001. GEO, gene expression omnibus; CR-DEGs, cuproptosis-related differentially expressed genes; PD, Parkinson’s disease; WGCNA, weighted gene co-expression network analysis; AUC, area under the curve; ROC, receiver operating characteristic; RF, RF random forest tree; SVM, support vector machine; XGB, Tree Ensemble; GLM, generalized linear model.

CR-DEGs in PD. (A) Heat maps of the 3 CR-DEGs in PD; the color of the columns represents the gene expression of the tissue samples, with red indicating high expression and green indicating low expression. (B) The CR-DEGs boxplot in PD. *, P<0.05; **, P<0.01. CR-DEGs, cuproptosis-related differentially expressed genes; PD, Parkinson’s disease.

CR-DEGs in correlations. ATP7B was negatively correlated with NFE2L2 and MTF1, while NFE2L2 was positively correlated with MTF1. CR-DEGs, cuproptosis-related differentially expressed genes.

ATP7B, MTF1 and NFE2L2 pathway correlation exploration. (A) GSEA of ATP7B in the pathway; (B) GSEA of MTF1 in the pathway; (C) GSEA of NFE2L2 in the pathway. GSEA, gene set enrichment analysis.

Immunogene set analysis of immune infiltration patterns in PD and normal conditions. (A) Heat maps of immunogene set analysis of PD samples and the color of the columns represents the gene expression of the tissue samples, with red indicating high expression and green indicating low expression. (B) Violin plot showing the difference in infiltrating immune cells between the two groups. PD, Parkinson’s disease; MDSC, myeloid-derived suppressor cell.

Immunogene set analysis of immune cell in ATP7B, MTF1, and NFE2L2; heat map of ATP7B, MTF1, and NFE2L2 correlation with immune cells. MDSC, myeloid-derived suppressor cell.

ceRNA network in ATP7B, MTF1, and NFE2L2. Red circles represent mRNAs, green triangles represent miRNAs, and purple diamonds represent lncRNAs. mRNAs, messenger RNAs; miRNAs, microRNAs; lncRNAs, long noncoding RNAs.

Search for ATP7B, MTF1 and NFE2L2 targeted drugs AND Molecular docking energy heat map. (A) The ATP7B and NFE2L2 targeted drugs; (B) molecular docking of NFE2L2 proteins in andalusol, chembl128729, dimethyl_fumarate, lagascatriol, suforaphane_isoselenocyanate, the ordinate value is the energy of docking (Kcal/mol). The redder the color, the greater the energy required for intermolecular binding.

NFE2L2 protein docking with LAGASCATRIOL. The molecules and drugs with the lowest docking energies are visualized in Figure 8. (A-C) Visualization of molecular docking results for NFE2L2 proteins in LAGASCATRIOL.

Two different subtypes of PD divided by consensus clustering and GSVA-GO and KEGG enrichment analysis (A) defined two clusters (k=2) and the consensus matrix heat map of their related regions. (B) PCA analysis showed significant transcriptome differences between the two subtypes. C1 is shown in green, C2 in red, and there is no sample overlap between them. (C) Box plots showed that ATP7B, MTF1 and NFE2L2 genes were significantly different between class A and B. Asterisks indicate statistical P values (**P<0.01; ***P<0.001). (D) GSVA-GO enrichment analysis N in the two clusters, where red and blue represent BP, CC, MF in activated GO and BP, CC, MF (E) in inhibited GO, respectively, and GSVA-KEGG enrichment analysis in red and blue represent activation pathway and inhibition pathway. BP, biological process; CC, cell component; MF, molecular function; RIA, ruptured intracranial aneurysm; GO, Gene Ontology; KEGG, Kyoto Encyclopedia of Genes and Genomes; PD, Parkinson’s disease; GSVA, gene set variation analysis; PCA, principal component analysis.

WGCNA selection of PD disease-related modules co-expressed genes. (A) Outliers were detected in the sample cluster. (B) The cut-off point was set as 0.9, and the soft threshold power was set as β=8. (C) Tree diagram of all DEGs based on the cluster of difference measurement. The colored bands show the results from the automated monolithic analysis. (D) Correlation diagram between modules obtained by clustering according to inter-gene expression levels. (E) Heat map of the correlation between module characteristic genes and phenotypes. We chose the MEblack module for subsequent analysis (the ordinate value is the correlation coefficient of feature module). (F) Module membership vs. gene significance, cor is disease correlation coefficient, P is the P value of correlation coefficient. ME, module eigengene; WGCNA, weighted gene co-expression network analysis; PD, Parkinson’s disease; DEGs, differentially expressed genes.

WGCNA selection of PD cluster-related modules co-expressed genes. (A) Outliers were detected in the cluster 1 and 2-sample cluster. (B) The cut-off point was set as 0.9, and the soft threshold power was set as β=7. (C) Tree diagram of all cluster 1 and 2-sample DEGs based on the cluster of difference measurement. The colored bands show the results from the automated monolithic analysis. (D) Correlation diagram between modules obtained by clustering according to inter-gene expression levels. (E) Heat map of the correlation between module characteristic genes and cluster 1 and 2-sample phenotypes. We chose the MEyellow module for subsequent analysis (the ordinate value is the correlation coefficient of feature module). (F) Module membership vs. gene significance, cor is disease correlation coefficient, P is the P value of correlation coefficient. ME, module eigengene; WGCNA, weighted gene co-expression network analysis; PD, Parkinson’s disease.

Machine learning builds models can largely progress between PD and normal samples. (A) The intersection genes of disease feature module and typing feature module were analyzed by WGCNA. (B) RF random forest tree, SVM, XGB, GLM and other algorithms were used to construct the reverse cumulative distribution map of model residuals. The Y-axis value represents the percentile of the outlier. (C) Box plots of sample residuals of the four algorithms. The X-axis value represents the quantile of outliers, and the red dot represents the mean. (D) ROC analysis of RF random forest tree, SVM, XGB, GLM, and other algorithms. The ROC values of RF and SVM were 0.833. (E,F) ROC analysis of XGB model in the GSE7621 and GSE20141 validation set. x-axis: FPR, false positive rate; y-axis: TPR, true positive rate; WGCNA, weighted gene co-expression network analysis; AUC, area under the curve; RF, RF random forest tree; SVM, support vector machine; XGB, Tree Ensemble; GLM, generalized linear model; ROC, receiver operating characteristic; CI, confidence interval.

A nomogram was constructed to predict the probability in PD progress. The values of each variable (SLC35D3, FLJ22184, SYT17, and RIMS3) are summed to obtain a total score. Each variable corresponds to a score, and the total score can be calculated by summing the scores of all variables. PD, Parkinson’s disease.

## Section: Results › Study process

Figure 1 show all the processes analyzed. First, PD-brain nigrostriatal sequencing data were retrieved from the GEO database, and the GSE49036 dataset was used to screen CR-DEGs and explore their correlation and single-gene GSEA pathway analysis. Correlations between individual genes and immune cells were then explored, a CR-DEGs mRNA-miRNA-lncRNA network was constructed, a gene-drug network was constructed, and molecular docking was performed to explore the feasibility of their binding. The molecular subtypes of CR-DEGs present in PD were then explored, WGCNs with clinical and clustering typing were constructed, and the clustered typing was crossed over to the clinical module genes. The crossed genes were then used to construct a diagnostic model using machine learning and the diagnostic model was proved using GSE7621 and GSE20141.

Flow chart of the systematic analysis of cuproptosis-related diagnostic genes and medication of PD. In WGCNA selection, red represents a positive association with PD, while blue represents a negative association with PD. In the energy heat map, the redder the color, the greater the energy required for intermolecular binding. In PD-immunocorrelation analysis diagnostic genes, red represents high expression in PD tissue, while blue represents low expression in PD tissue. *, P<0.05; **, P<0.01; ***, P<0.001. GEO, gene expression omnibus; CR-DEGs, cuproptosis-related differentially expressed genes; PD, Parkinson’s disease; WGCNA, weighted gene co-expression network analysis; AUC, area under the curve; ROC, receiver operating characteristic; RF, RF random forest tree; SVM, support vector machine; XGB, Tree Ensemble; GLM, generalized linear model.

## Section: Results › Identification of CR-DEGs in PD and correlation analysis between genes

The GSE49036 data were normalized and CRGs were extracted using the limma package of R software and screened for DEG analysis. According to the screening criteria: P<0.001, indicated by “***”, P<0.01, indicated by “**” and P<0.05, indicated by “*”, heat maps (Figure 2A) and box plots (Figure 2B) were drawn using pheatmap and ggpubr software packages to visualize the differential gene expression results.

Correlation analysis of expression of the above-mentioned genes in PD patients was performed using the corrplot package of R software and the results showed that ATP7B was negatively correlated with NFE2L2 and MTF1 and that NFE2L2 was positively correlated with MTF1. The results of expression correlation between genes were also visualized using the circlize package (Figure 3).

CR-DEGs in PD. (A) Heat maps of the 3 CR-DEGs in PD; the color of the columns represents the gene expression of the tissue samples, with red indicating high expression and green indicating low expression. (B) The CR-DEGs boxplot in PD. *, P<0.05; **, P<0.01. CR-DEGs, cuproptosis-related differentially expressed genes; PD, Parkinson’s disease.

CR-DEGs in correlations. ATP7B was negatively correlated with NFE2L2 and MTF1, while NFE2L2 was positively correlated with MTF1. CR-DEGs, cuproptosis-related differentially expressed genes.

## Section: Results › GSEA of PD tissue and CR-DEGs

Single-gene GSEA enrichment analysis was performed to explore the potential mechanisms of action of cuproptosis-related genes such as NFE2L2, MTF1 and ATP7B in PD, as shown in Figure 4. Interestingly, all 3 genes were associated with the synaptic vesicle cycle, although they were down-regulated in NFE2L2 and MTF1, down-regulated in ATP7B. In contrast, the ATP7B up-regulated signaling pathway is also related to Citrate cycle (TCA cycle), Nicotine addiction, Retinol metabolism, Starch and sucrose metabolism, etc. whereas NFE2L2 and MTF1 were jointly associated with Proteasome, and MTF1 down-regulation signaling pathway was associated with 2-oxocarboxylic acid metabolism, glycosphingolipid biosynthesis—globo and isoglobo series, and so on. NFE2L2 down-regulation was associated with aminoacyl-tRNA biosynthesis, glycosphingolipid biosynthesis—globo and isoglobo series, and so on.

These results indicate that NFE2L2, MTF1, and ATP7B may be involved in the regulation of the synaptic vesicle cycle, which in turn affects brain neurotransmitter transmission and may be involved in aerobic metabolism of brain tissue, leading to disease progression.

ATP7B, MTF1 and NFE2L2 pathway correlation exploration. (A) GSEA of ATP7B in the pathway; (B) GSEA of MTF1 in the pathway; (C) GSEA of NFE2L2 in the pathway. GSEA, gene set enrichment analysis.

## Section: Results › Immunocorrelation analysis of PD tissue and CR-DEGs

To explore the immune cell infiltration of CR-DEGs in PD, we performed GSEA of dataset GSE49036 using the immune gene set “immune.gmt”, as shown in Figure 5A,5B. CD8 T cell was highly expressed in normal controls with PD tissue, whereas plasmacytoid dendritic cell (DC), macrophage, immature B cell, myeloid-derived suppressor cells (MDSCs), mast cell, neutrophil, natural killer (NK) T cell, type 2 T helper cell, T follicular helper cell, and other immune cells were highly expressed in PD substantia nigra versus normal brain tissue. We also explored the relationship between individual genes of CR-DEGs and immune cells (see Figure 6). ATP7B was associated with activated B cell, CD56 dim NK cell, central memory CD4 T cell, central memory CD8 T cell, macrophage, mast cell, MDSC, monocyte, NK cell, NK T cell, plasmacytoid DC, and T follicular helper cell, and other immune cells were negatively correlated, whereas NFE2L2 was negatively correlated with MTF1 and type 17 T helper cell, plasmacytoid DC, NK T cell, central memory CD8 T cell, NK cell, monocyte. Memory B cell, mast cell, and activated B cell were positively correlated, and interestingly, they were negatively correlated with effector memory CD8 T cell expression; it is possible that these immune cells are involved in the midbrain substantia nigra of PD degenerative death of dopaminergic neurons, and CR-DEGs such as NFE2L2, MTF1, and ATP7B may be promising targets for immunotherapy in PD.

Immunogene set analysis of immune infiltration patterns in PD and normal conditions. (A) Heat maps of immunogene set analysis of PD samples and the color of the columns represents the gene expression of the tissue samples, with red indicating high expression and green indicating low expression. (B) Violin plot showing the difference in infiltrating immune cells between the two groups. PD, Parkinson’s disease; MDSC, myeloid-derived suppressor cell.

Immunogene set analysis of immune cell in ATP7B, MTF1, and NFE2L2; heat map of ATP7B, MTF1, and NFE2L2 correlation with immune cells. MDSC, myeloid-derived suppressor cell.

## Section: Results › PD-CR-DEGs ceRNA network search

To further explore the complex molecular interaction mechanism between the NFE2L2, MTF1, and ATP7B genes, we created an mRNA-miRNA-lncRNA network relationship diagram, as shown in Figure 7. This complex network has 60 nodes and 99 interactions, including 40 miRNAs and 17 lncRNAs, which may provide us with a new idea to explore the pathogenesis of cuproptosis-related PD.

ceRNA network in ATP7B, MTF1, and NFE2L2. Red circles represent mRNAs, green triangles represent miRNAs, and purple diamonds represent lncRNAs. mRNAs, messenger RNAs; miRNAs, microRNAs; lncRNAs, long noncoding RNAs.

## Section: Results › Prospective small molecule drug for PD therapy

In order to explore Prospective small molecule drugs for PD therapy, downloaded the results of NFE2L2, MTF1, and ATP7B targeting drugs from the DGIdb database and selected drugs with documented results (see Table 1) and presented the gene-drug results using Cytoscape (Figure 8A). We finally selected the top 5 NFE2L2 gene-drug interaction scores for small molecule drug-macromolecule protein docking using AutoDock. The energy required for docking is shown in Figure 8B, with the lowest energy required for docking LAGASCATRIOL to NFE2L2. Figure 9A shows a visualisation of the overall picture of the molecular docking results of the NFE2L2 protein in LAGASCATRIOL, Figure 9B shows a local view of the molecular docking results visualising the small molecule drug with the protein, see Figure 9C. LAGASCATRIOL is able to form 1 ionic bond each with arginine at position 456 and 504 of NFE2L2, and 2 ionic bonds with aspartic acid at position 457.

Search for ATP7B, MTF1 and NFE2L2 targeted drugs AND Molecular docking energy heat map. (A) The ATP7B and NFE2L2 targeted drugs; (B) molecular docking of NFE2L2 proteins in andalusol, chembl128729, dimethyl_fumarate, lagascatriol, suforaphane_isoselenocyanate, the ordinate value is the energy of docking (Kcal/mol). The redder the color, the greater the energy required for intermolecular binding.

NFE2L2 protein docking with LAGASCATRIOL. The molecules and drugs with the lowest docking energies are visualized in Figure 8. (A-C) Visualization of molecular docking results for NFE2L2 proteins in LAGASCATRIOL.

## Section: Results › Clustering based on the CR-DEGs in the PD sample

In GSE49036, cluster analysis was performed to classify the PD samples into different molecular subtypes and examine the subtypes using PCA based on the expression of the 3 CR-DEGs selected above (Figure 10A,10B). We named the 2 clusters as CRGClusters C1 and C2, respectively. Differential analysis of the 2 CRGClusters showed that ATP7B expression was significantly higher in C1 compared to C2, whereas NFE2L2 and MTF1 in C1 had significantly higher ATP7B expression compared to C2 expression, which was significantly decreased (Figure 10C). In the Kyoto Encyclopedia of Genes and Genomes (KEGG), comparison between the two clusters in the GSEA also revealed significantly different KEGG pathway enrichment profiles, interestingly on PARKINSONS_DISEASE, but also on ubiquitin-mediated proteolysis, oxidative phosphorylation, and citrate cycle tca cycle, which were up-regulated, whereas tgf beta signaling pathway and spliceosome were down-regulated (Figure 10D). In contrast, among the Gene Ontology (GO) biological down-regulated in pathways: immunological synapse formation, positive regulation of hemopoiesis, positive regulation of b cell differentiation, regulation of endodermal cell differentiation, regulation of synaptic vesicle endocytosis, dendrite extension, presynaptic dense core vesicle exocytosis, regulation of postsynaptic vesicle exocytosis, and regulation of postsynaptic cytosolic calcium ion concentration (Figure 10E). These results suggest a possible involvement in the production and transmission of neurotransmitters in the brain, and possibly in dendritic production related to the progression of PD by causing a significant reduction in striatal DA content.

Two different subtypes of PD divided by consensus clustering and GSVA-GO and KEGG enrichment analysis (A) defined two clusters (k=2) and the consensus matrix heat map of their related regions. (B) PCA analysis showed significant transcriptome differences between the two subtypes. C1 is shown in green, C2 in red, and there is no sample overlap between them. (C) Box plots showed that ATP7B, MTF1 and NFE2L2 genes were significantly different between class A and B. Asterisks indicate statistical P values (**P<0.01; ***P<0.001). (D) GSVA-GO enrichment analysis N in the two clusters, where red and blue represent BP, CC, MF in activated GO and BP, CC, MF (E) in inhibited GO, respectively, and GSVA-KEGG enrichment analysis in red and blue represent activation pathway and inhibition pathway. BP, biological process; CC, cell component; MF, molecular function; RIA, ruptured intracranial aneurysm; GO, Gene Ontology; KEGG, Kyoto Encyclopedia of Genes and Genomes; PD, Parkinson’s disease; GSVA, gene set variation analysis; PCA, principal component analysis.

## Section: Results › WGCNA co-expression analysis of PD samples

We first conducted a WGCNA analysis of clinical trait correlations in order to select the top 25% of genes with the greatest fluctuations for WGCNA analysis and cut off outlier samples, with the remaining samples being included in the analysis (Figure 11A). As shown in Figure 11B, scale independence reached 0.9 when power =8 and mean concordance was high. Therefore, power =8 was used to construct co-expression modules to obtain preliminary module delineation results, and the results of WGCNA showed that different modules were identified with different colors (Figure 11C). To detect outliers, trees were constructed using the eigenvalues of the modules, and then the distances of the trees belonging to the same branch were very close were merged and the intercept value was set to 0.5 (Figure 11D). Co-expression modules were constructed as shown in Figure 11E and the results were obtained after merging similar modules. Based on the eigenvalues of the samples in each module and the characteristics of the samples, correlation analysis was performed to identify modules associated with specific traits, and the genes represented by MEblack were highly positively correlated in PD (Figure 11F).

In the same way that we performed WGCNA analysis of correlations after typing, we cut off outlier samples (Figure 12A) as in Figure 12B when power =7, scale independence reached 0.9, modules were identified by color and eventually found to be characterized after typing (Figure 12C-12F), with the genes represented by MEyellow being highly positively correlated in CRGCluster C1 (Figure 12F).

WGCNA selection of PD disease-related modules co-expressed genes. (A) Outliers were detected in the sample cluster. (B) The cut-off point was set as 0.9, and the soft threshold power was set as β=8. (C) Tree diagram of all DEGs based on the cluster of difference measurement. The colored bands show the results from the automated monolithic analysis. (D) Correlation diagram between modules obtained by clustering according to inter-gene expression levels. (E) Heat map of the correlation between module characteristic genes and phenotypes. We chose the MEblack module for subsequent analysis (the ordinate value is the correlation coefficient of feature module). (F) Module membership vs. gene significance, cor is disease correlation coefficient, P is the P value of correlation coefficient. ME, module eigengene; WGCNA, weighted gene co-expression network analysis; PD, Parkinson’s disease; DEGs, differentially expressed genes.

WGCNA selection of PD cluster-related modules co-expressed genes. (A) Outliers were detected in the cluster 1 and 2-sample cluster. (B) The cut-off point was set as 0.9, and the soft threshold power was set as β=7. (C) Tree diagram of all cluster 1 and 2-sample DEGs based on the cluster of difference measurement. The colored bands show the results from the automated monolithic analysis. (D) Correlation diagram between modules obtained by clustering according to inter-gene expression levels. (E) Heat map of the correlation between module characteristic genes and cluster 1 and 2-sample phenotypes. We chose the MEyellow module for subsequent analysis (the ordinate value is the correlation coefficient of feature module). (F) Module membership vs. gene significance, cor is disease correlation coefficient, P is the P value of correlation coefficient. ME, module eigengene; WGCNA, weighted gene co-expression network analysis; PD, Parkinson’s disease.

## Section: Results › Machine learning builds diagnostic models

We crossed the clinical trait and typed common trait gene modules to find a total of 72 trait genes (Figure 13A). We used the GSE49036 dataset to extract the 72 trait genes and used the RF tree, SVM, XGB, and GLM algorithms to build diagnostic models with the traits. We first analyzed the data samples for residuals, the reverse cumulative distribution of the residuals of the four algorithms is plotted (Figure 13B). The XGB model has smaller residuals for most samples, while the GLM has higher residuals for many samples than the XGB model. The box plots of the residuals of the 4 algorithms (Figure 13C), with the red dots indicating the root mean square of the residuals, were ranked as follows: XGB < SVM < RF < GLM, and the 4 models were validated with ROC curves. The AUC values of the four models were as follows: RF =0.833; SVM =0.833; XGB =0.917; GLM =0.833 (Figure 13D).

Finally, we chose the XGB model and used the GSE7621 and GSE20141 gene sets to validate the ROC curves for the XGB model (Figure 13E,13F), with corresponding AUC values of 0.688 and 0.833. Finally, the genes in the model were plotted in a nomogram (Figure 14), which showed that the genes in the model are SLC35D3, FLJ22184, SYT17184, SLC35D3, FLJ22184, FLJ22184, SYT17, and RIMS3.

Machine learning builds models can largely progress between PD and normal samples. (A) The intersection genes of disease feature module and typing feature module were analyzed by WGCNA. (B) RF random forest tree, SVM, XGB, GLM and other algorithms were used to construct the reverse cumulative distribution map of model residuals. The Y-axis value represents the percentile of the outlier. (C) Box plots of sample residuals of the four algorithms. The X-axis value represents the quantile of outliers, and the red dot represents the mean. (D) ROC analysis of RF random forest tree, SVM, XGB, GLM, and other algorithms. The ROC values of RF and SVM were 0.833. (E,F) ROC analysis of XGB model in the GSE7621 and GSE20141 validation set. x-axis: FPR, false positive rate; y-axis: TPR, true positive rate; WGCNA, weighted gene co-expression network analysis; AUC, area under the curve; RF, RF random forest tree; SVM, support vector machine; XGB, Tree Ensemble; GLM, generalized linear model; ROC, receiver operating characteristic; CI, confidence interval.

A nomogram was constructed to predict the probability in PD progress. The values of each variable (SLC35D3, FLJ22184, SYT17, and RIMS3) are summed to obtain a total score. Each variable corresponds to a score, and the total score can be calculated by summing the scores of all variables. PD, Parkinson’s disease.

## Section: Discussion

PD is considered a progressive neurodegenerative disease that manifests clinically as resting tremor, rigidity, bradykinesia, or dyskinesia, postural gait abnormalities, and other non-motor symptoms. PD is now understood to be a multisystem disorder accompanied by significant nerve inflammation and immune function dysfunction. Its pathogenesis is currently unclear and includes the presence of oxidative stress, protein aggregation, mitochondrial dysfunction, and inflammation as the cause of neuronal death (22). Among the pathological features of PD are the formation of predominantly intracellular alpha-synuclein-containing inclusion bodies, called Lewy vesicles. The current understanding of neural death in PD is the role of α-synaptic nuclear proteins in brain cell death through the formation and assembly of these protein aggregates. In contrast, Cu1+ can also bind directly to two different regions of the α-synaptic nucleoprotein thereby causing oxidative neurological damage degeneration (23). High concentrations of Cu promote α-synaptic protein misfolding leading to PD progression (24). Alternately, 6-OHDA disrupts copper (Cu) homeostasis through dysregulation of cellular Cu transport, leading to neuronal cell dysfunction and cell death (25). Therefore, Cu accumulation and Cu metabolism are important for the development of PD disease, and in this study we explored potential central genes related to cuproptosis and immune infiltration patterns in the substantia nigra of PD patients through bioinformatics analysis, and we found that plasmacytoid DC was upregulated in tissues with the most significant differences in PD. It has been suggested that DC-mediated T-cell differentiation leads to a reduction in recognized antigenic peptides, resulting in the timely degradation of inflammatory proteins associated with α-synuclein synthesis in PD (26), whereas our immune cell analysis of three CR-DEGs found that they were all associated with NK cells, and it has been shown that increased NK cell numbers and cytotoxicity during PD progression can play a neuroprotective role (27), which may further reveal new targets for PD immunotherapy and provide new potential therapeutic biomarkers and treatment strategies for PD.

Our study used three PD patients’ nigrostriatal sequencing datasets to enrich the exploration of cuproptosis genes, firstly to find DEGs related to cuproptosis in PD patients, namely ATP7B, NFE2L2, and MTF1, and to explore their respective possible pathways of action and relationships with individual immune cells. We also explored their possible target miRNAs and lncRNA, mapped the complex network of ceRNAs, and searched for their corresponding small molecule drugs through the DGIdb database. We also conducted an in-depth analysis of PD patients by clustering and typing to explore the possible mechanisms of tissue typing in PD tissues, and constructed a diagnostic model of PD using WGCNA and machine learning methods.

Our results of GSEA revealed that the genes ATP7B, NFE2L2, and MTF1 were all associated with the synaptic vesicle cycle, which may suggest that these three genes could be involved in the synaptic vesicle cycle to reduce neurotransmitter transmission. ATP7B is a key ATPase in the Golgi complex harbors copper-transporting, which transfers Cu from the cytoplasmic matrix to the Golgi lumen for incorporation into the Cu-dependent enzyme. The Golgi complex also sends these ATPases to appropriate post-Golgi destinations to ensure the correct Cu flux in vivo and to avoid potentially toxic Cu accumulation. Mutations in ATP7A or ATP7B or the proteins that regulate their transport can affect their exit from the Golgi or subsequent fetch back to this organelle (28). α-synuclein assemblies need to exhibit seeding capacity, namely, template capacity for further aggregation, and toxicity mediated at least in part by interference with synaptic vesicle or organelle homeostasis (29). NFE2L2 encodes nuclear factor E2 and related factor 2 (NRF2), which are master regulators of antioxidant enzymes that prevent oxidative stress and inflammation, and perillyl is a key inhibitor of α-synuclein protein synthesis, thereby slowing PD progression. In contrast, galangin attenuates neuronal apoptosis via the Nrf2/Keap1 pathway, thereby slowing PD progression (30,31). MTF1, a key regulator of heavy metal homeostasis and detoxification, provides complementary functions in oxidative stress and other cellular stress responses. MTF1 gene polymorphisms have the potential to influence further exacerbation of PD (32). These studies above suggest that genes such as ATP7B, NFE2L2, and MTF1 may have important implications for the pathogenesis and progression of PD, based on which they are expected to be our next therapeutic targets for the study of PD.

The clinical diagnostic criteria for PD are bradykinesia with resting tremor, rigidity, or both (33). In contrast, the location of the DA transporter has been identified in diagnostic imaging primarily by DA transporter single photon emission computed tomography (DaT SPECT) by showing presynaptic DA neuronal hypofunction in PD and other neurodegenerative diseases. Identification of presynaptic dopamine neuronal dysfunction present in PD and other neurodegenerative diseases is used to differentiate PD from primary tremor, but it is not necessary to routinely perform these scans (34). They cannot distinguish PD from other neurodegenerative diseases that also involve DA transporter dysfunction (e.g., multisystem atrophy, progressive supranuclear palsy). There is growing evidence that PD includes a heterogeneous subtype have implications for diagnosis, prognosis, and expected response to treatment. Initial subtyping focused on motor characteristics (35). One typing approach includes three groups: predominantly mild motor: younger age of onset, mild motor and non-motor symptoms, slow progression and good drug response (36). Therefore, the typing of PD may be a better guide for treatment. We also typed PD and divided it into CRGClusters C1 and C2. Our results showed that ATP7B expression was significantly higher in C1 compared to C2, whereas NFE2L2, MTF1, and ATP7B expression was significantly decreased in C1 compared to C2. Our post-typing GSVA-KEGG enrichment analysis showed that in fractions, C2 could be enriched in PD signal path, as well as in the GO biological pathways: immunological synapse formation, regulation of endodermal cell differentiation, and regulation of synaptic vesicle endocytosis, dendrite extension, presynaptic dense core vesicle exocytosis, regulation of postsynaptic cytosolic calcium ion concentration. We obtained a diagnostic line graph by machine learning methods, so that we can diagnose PD by detecting the expression of genes; our research facilitates us to personalize the diagnosis and guide the treatment of PD by typing.

Currently, DA antagonists remain the first-line drugs used clinically for the treatment of PD, and the use of levodopa improves more function but increases the risk of dyskinesia, especially at higher doses (37). If it is necessary to reduce the dosage of levodopa after the development of dopamine-dysregulation syndrome (DDS), we can in turn try to switch to other drugs, which still have their own side effects, such as hallucinations and delirium (38). In contrast, levodopa equivalent daily dose (LEDD) can usually be reduced by 30–50% after deep thalamic nucleus brain stimulation (DBS) surgery is administered to patients, and one study showed that 7% of 150 patients treated with STN-DBS stopped taking the drug after 3 years (39). Complete cessation after STN-DBS dopaminergic medication is usually not possible because the lack of DA in the limbic system and associated circuits can lead to apathy and depression (39,40), so alternative medications with fewer side effects and effective alternatives need to be chosen. We searched the DGidb database for andalusol, chembl128729, dimethyl_fumarate lagascatriol, and suforaphane_isoselenocyanate, and other small molecules were identified through the DGidb database, and molecular docking was performed to initially explore the amino acid residue linkage sites between these drugs and NFE2L2 and their counterparts. There are studies on the Nrf2-dependent neuroprotective activity of diterpenoids isolated from Sideritis spp., counteracting oxidative damage and their potential role as useful agents for the prevention of those with oxidative stress-mediated dementia. ANDALUSOL was the most active of the diterpenoids studied (41). The neuroprotective effect of dimethyl_fumarate in the MPTP-mouse model of PD (42), the findings of the above-mentioned studies led us to search for these small molecules, which provide a new idea for the next targeted drugs for the treatment of PD.

There were some limitations to our study. Firstly, our findings were derived by computer using in-depth calculations using bioinformatics methods and still require in vitro experiments to validate the results. Secondly, further animal models need to be constructed to collect samples of the specific mechanisms by which the central genes associated with cuproptosis contribute to PD, and initial validation of the animal models of PD using our personalized drugs will be required, and ultimately we will use samples from patients in the early stages of PD for validation, combined with clinical data to provide diagnostic biomarkers and timely drug interventions. In future studies, we will focus on the mechanisms of action of ATP7B, NFE2L2, and MTF1 in PD and explore early diagnostic biomarkers for PD.

## Section: Conclusions

Using bioinformatics analysis, CR-DEGs were identified in the substantia nigra of PD patients. ATP7B, together with NFE2L2 and MTF1, were considered as candidate genes for further study. This study provides new genes associated with Cu accumulation leading to cell death in the pathogenesis of PD and explores promising therapeutic targets for related neurodegenerative diseases.


---

# MF-PCBA: Multifidelity High-Throughput Screening Benchmarks for Drug Discovery and Machine Learning

- **Authors:** David Buterez, Jon Paul Janet, Steven J Kiddle, Pietro Liò
- **Issuer:** Journal of chemical information and modeling
- **Type:** Scientific article
- **Published:** 2023-04-14
- **Language:** en
- **DOI:** 10.1021/acs.jcim.2c01569
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37058588/
- **Licence:** CC-BY

## Section: Abstract

High-throughput screening (HTS), as one of the key techniques in drug discovery, is frequently used to identify promising drug candidates in a largely automated and cost-effective way. One of the necessary conditions for successful HTS campaigns is a large and diverse compound library, enabling hundreds of thousands of activity measurements per project. Such collections of data hold great promise for computational and experimental drug discovery efforts, especially when leveraged in combination with modern deep learning techniques, and can potentially lead to improved drug activity predictions and cheaper and more effective experimental design. However, existing collections of machine-learning-ready public datasets do not exploit the multiple data modalities present in real-world HTS projects. Thus, the largest fraction of experimental measurements, corresponding to hundreds of thousands of “noisy” activity values from primary screening, are effectively ignored in the majority of machine learning models of HTS data. To address these limitations, we introduce Multifidelity PubChem BioAssay (MF-PCBA), a curated collection of 60 datasets that includes two data modalities for each dataset, corresponding to primary and confirmatory screening, an aspect that we call multifidelity. Multifidelity data accurately reflect real-world HTS conventions and present a new, challenging task for machine learning: the integration of low- and high-fidelity measurements through molecular representation learning, taking into account the orders-of-magnitude difference in size between the primary and confirmatory screens. Here we detail the steps taken to assemble MF-PCBA in terms of data acquisition from PubChem and the filtering steps required to curate the raw data. We also provide an evaluation of a recent deep-learning-based method for multifidelity integration across the introduced datasets, demonstrating the benefit of leveraging all HTS modalities, and a discussion in terms of the roughness of the molecular activity landscape. In total, MF-PCBA contains over 16.6 million unique molecule–protein interactions. The datasets can be easily assembled by using the source code available at https://github.com/davidbuterez/mf-pcba.

## Section: Introduction

Machine learning (ML) techniques have enabled remarkable progress in the chemical and physical sciences, particularly in terms of fast and precise modeling of computationally expensive processes. Graph neural networks (GNNs), a class of geometric deep learning algorithms, have recently emerged as one of the leading ML paradigms for learning directly on the data types occurring in the life sciences. Thanks to their ability to naturally learn from non-Euclidean data structures, represented as objects (nodes) and their connections (edges), GNNs have the potential to model complex relationships and dependencies between nodes. Successful examples include but are not limited to tasks from particle physics,1 simulations of fluid dynamics and other physical systems,2 quantum chemistry,3 and drug discovery.4 However, such data-driven efforts are highly dependent on the quality, quantity, and availability of suitable data. Thus, a significant amount of research has been devoted to the development of high-quality datasets that support the rapidly advancing field of graph representation learning. In particular, challenging computational chemistry tasks such as quantum property prediction, drug-like molecule generation, and few-shot learning have put molecular data at the forefront of geometric deep learning research.

Publicly available molecular benchmarks span several areas of chemistry and are often tailored to domain-specific needs. For example, MoleculeNet is a suite of 16 molecular datasets and their variations, with tasks from quantum mechanics, physical chemistry, biophysics, and physiology.5 Consequently, there is a large variability in terms of the supervised learning task (regression or classification), number of output predictions/classes (multitask learning), dataset size (ranging from under 1000 compounds to over 430,000), and ML-specific concerns such as the node featurization strategy (atomic coordinates, atom type, etc.) and the random split strategy. A similarly diverse effort is Atom3D, a collection of eight tasks formulated specifically for learning based on three-dimensional molecular structures, for example, protein-interface prediction and prediction of ligand binding affinity and small-molecule properties.6

Experimental and computational advances paved the way to increasingly large, diverse, and challenging datasets. For example, although QM9 is one of the most well-known quantum mechanics benchmarks, concerns regarding its size (around 130,000 compounds) and composition (only five atom types and a maximum of nine heavy atoms per molecule) led to projects such as Alchemy7 (up to 14 heavy atoms), PubChemQC8 (quantum properties for up to 3 million molecules), QMugs9 (over 665,000 diverse molecules, up to 100 heavy atoms per molecule, and quantum properties at multiple levels of theory), and ANI-1x and ANI-1ccx10 (quantum properties at different levels of theory for 5 million and 500,000 molecules, respectively). For drug discovery, the well-known PCBA dataset11 is a collection of high-quality dose response data, formulated as a multitask learning benchmark from 128 high-throughput screening (HTS) assays. Models trained on experimental data of this nature are often used in a virtual screening setting, with the goal of identifying novel compounds of therapeutic interest. For the specific task of virtual screening, an alternative benchmark named LIT-PCBA was developed,12 addressing limitations of existing datasets such as hidden molecular biases.

We identified a lack of machine learning benchmarks that accurately reflect the practical aspects of drug discovery based on HTS, thus also limiting the potential for innovation in early-stage drug discovery projects. HTS follows a multitiered approach consisting of successive screens of drastically varying size and fidelity, most commonly a low-fidelity primary screen consisting of up to 2 million molecules in industrial settings and a high-fidelity confirmatory screen of up to 10,000 compounds. Usually, the screens are used as successive filters to select the most promising molecules for further optimization. Despite the success of HTS in identifying clinical candidates and FDA-approved drugs,13−15 computational methods have traditionally neglected the multitiered design of HTS. Existing datasets and applications, such as PCBA, LIT-PCBA, and approaches based on HTS fingerprints, are formulated on single-fidelity data.11,12,16−19 The single-fidelity measurements generally correspond to the highest-fidelity measurements available (dose response), which leads either to extremely small datasets for machine learning (<10,000 compounds) or to highly sparse representations extracted from hundreds of assays.

Neglecting the multiple modalities of HTS experiments has the major downside of discarding millions of lower-fidelity measurements that cover an orders-of-magnitude larger and more diverse chemical space. Integrating all of the available data has the potential to improve drug potency predictions, help guide the experimental design, save costs associated with multiple expensive experiments, and ultimately lead to the identification of new drugs. Indeed, we have recently demonstrated considerable uplifts in predictive performance when multifidelity data are incorporated through a novel, specifically designed GNN approach.20 We have also demonstrated transfer learning capabilities between the different data modalities, an area that has also recently received interest in quantum machine learning.3,21

In this work, we expand upon our initially reported collection of public multifidelity HTS datasets, reporting a total of 60 datasets with over 16.6 million unique protein–molecule interactions extracted from PubChem. We cover in detail the search, selection, and filtering steps and also provide a performance evaluation based on the methodology proposed by Buterez et al.20 We envision that the provided datasets will motivate the development of new graph representation learning methods capable of multifidelity modeling and transfer learning, thus advancing the state of the art in computational drug discovery projects. At the same time, we believe that the challenging properties of multifidelity HTS data will provide a new benchmark for evaluating machine learning algorithms, particularly in terms of molecule-level regression tasks, which are not well represented at this scale in existing work. It is important to note that the MF-PCBA datasets are representation-agnostic, as the molecular information is presented in the form of SMILES strings, such that a variety of machine learning techniques are applicable (not exclusively deep learning). Ultimately, we hope that the MF-PCBA datasets will motivate further research and competition, thus advancing the field and enabling new possibilities for drug discovery and molecular modeling. The datasets can easily be assembled using the provided scripts (https://github.com/davidbuterez/mf-pcba).

## Section: Methods

Main steps of assembling a multifidelity HTS dataset from the corresponding primary and confirmatory screens, which might be reported in the same or different PubChem assays. First, the SMILES string for each molecule is loaded into RDKit, which removes invalid structures. This procedure is followed by a number of filtering steps that ensure a high-quality data collection for drug discovery and machine learning projects, including selection of only the largest fragments, removal of stereoisomers, and removal of electric charges. Finally, missing DR values in the confirmatory assay are set to a default value corresponding to the minimum activity (“pXC50”) observed in the project.

A multifidelity integration workflow illustrated with three high-level steps. Confirmatory-level data (DR) can be modeled directly using various machine learning techniques such as RF, SVM, or GNN. Despite not leveraging hundreds of thousands of bioaffinity measurements from the primary screens, this is the prevalent type of modeling in early-stage drug discovery. Instead, an alternative is to model the primary screening (SD) separately and incorporate the learned information through techniques such as transfer learning. Here, this is achieved through graph or molecular embeddings. The embeddings can be included (by concatenation) in the DR modeling step, a procedure we denote as augmentation. We also consider the addition of the SD label to the DR model as an alternative augmentation strategy.

## Section: Methods › Data Acquisition

We manually searched the PubChem BioAssays database using the terms “high-throughput screening”, “HTS”, “primary”, “confirmatory”, “single dose”, “dose response”, “SD”, and “DR”. We selected the latest version (at the time of writing) for each assay. The date range of the assays is 2008–2018 (the exact versions, revisions, and dates are provided in the Supporting Information (SI)). The manual search step is necessary due to the nature of reporting HTS results. Primary and confirmatory screening results might be reported in the same bioassay, e.g., assay identifier (AID) 1445, or as separate bioassays that are part of the same project, e.g., primary AID 602261 and confirmatory AID 624326. Furthermore, different primary and confirmatory projects use different formats and conventions when reporting measurements. Among the selected bioassays, primary screens might be reported at different concentrations and with multiple replicates. Similarly, confirmatory screens can be reported in different formats (usually IC50, AC50, or EC50), but the units (e.g., μM or μg/mL) are not always consistent. The smaller collection of 23 datasets previously discussed by Buterez et al. focused on a diverse but restricted number of assays to allow for an in-depth analysis of both PubChem and proprietary data while also emphasizing certain dataset attributes such as the (linear) correlation between the single dose (SD) and dose response (DR) values. The updated collection presented in this work further increases the diversity of the assays and the number of curated datasets, allowing a more comprehensive view of HTS modeling strategies and challenging current methods.

Once our selection of 60 datasets was finished, we could automate the remaining steps. To this end, we used PubChem’s representational state transfer application programming interface (REST API) to retrieve each assay as a comma-separated values (CSV) file based on its AID, downloading at most 10,000 compound rows at a time. The raw CSV files contain the compound ID (CID) for each molecular entry but no molecular structure information. To address this, we again used the REST API to retrieve the Simplified Molecular-Input Line-Entry System (SMILES) string representation for each entry based on the CID. Any replicate measurements present for the primary screens are aggregated by taking the mean. In the associated source code, the option of using the median is also provided. Only 23 out of the 60 primary screens have more than two replicates, and even in these cases only a fraction of the entire compound library is present in the replicates, leading to a small difference between the mean and median (Table S3 and section SI 2). The resulting SD measurements are not further processed. In contrast, for the DR measurements the aggregation step is not necessary, as generally there are no replicates in the same bioassay. However, the DR values, which are often reported as “XC50” (IC50, AC50, or EC50) values or variations involving the logarithm, are always converted to the corresponding pXC50 values (pXC50 = −log XC50). The entire collection of 60 multifidelity datasets is summarized in Table 1 along with details specific to each dataset. These datasets cover a wide spectrum of assay technologies and end points, from biochemical inhibition data to phenotypic experiments on whole organisms.

## Section: Methods › Filtering Steps

The raw molecular information is subjected to a number of filtering steps that ensure a high-quality, consistent representation suitable for various machine learning algorithms. In the majority of cases, the primary and confirmatory screens are reported as separate bioassays in PubChem. Thus, the filtering steps are applied independently on the SD and DR datasets. In the case where the primary and confirmatory data are reported in a single bioassay, the same filtering steps are applied on the single data table. Filtering is always applied after the preprocessing steps described above. The filtering pipeline consists of four major steps implemented using the open-source library RDKit22 (also illustrated in Figure 1):1.Sanitization with RDKit: The function Chem.MolFromSmiles from RDKit was used to construct a molecular object, represented by the Mol class. This representation provides access to the molecular structure and to other filtering-relevant functions regarding stereoisomers, removal of charges, etc. Importantly, loading the SMILES string into RDKit acts as an initial filtering step by itself, as RDKit uses a sanitization procedure internally. This resulted in a number of entries (molecules) being removed, most commonly due to valence errors or SMILES strings consisting only of hydrogen atoms.2.Largest fragment selection: Next, we used RDKit’s rdMolStandardize.LargestFragmentChooser function to remove molecules where the CID contained a combination of compounds, most commonly a counterion. The option to remove smaller fragments but keep the largest one is also provided in the source code. There is also an option to report small fragments that are not encountered in the MF-PCBA collection when assembling data from different assays. For MF-PCBA, almost all encountered small fragments are counterions or solvents.3.Stereoisomer removal: The function rdmolops.RemoveStereochemistry was used to remove all of the stereochemistry information contained within the molecules, followed by generation of new SMILES representations for all of the resulting molecular objects. Molecules that were previously differentiated only by the stereochemical information now have identical representations. Thus, we select only the unique molecules based on the SMILES representation and consider the task of modeling the activity of racemic mixtures. It should be noted that many GNNs operate on molecules only at the level of “2D” graphs, such that the stereochemical information is not considered. An option to keep the molecules that would be removed by this step is also provided, as well as an option to record the number of stereocenters for each molecule.4.Neutralization (removal of electric charges): This step is achieved by adding or removing hydrogens for charged atoms. Only compounds that can be recorded with a formal charge of 0 are retained. Generally, compounds that cannot pass this threshold are difficult to transform into safe drugs, motivating our filtering procedure. The calculations are performed using atom-level RDKit functions such as GetFormalCharge, GetTotalNumHs, SetFormalCharge, SetNumExplicitHs, and the filtering of molecules is based on rdmolops.GetFormalCharge.

We report the average number of compounds removed by each step in the Results. The numbers of SD and DR compounds after each filtering step are reported for all datasets in Tables S1 and S2, respectively. Generally, the filtering steps that removed the most compounds are largest fragment selection and stereoisomer removal. With a few exceptions, the filtering pipeline did not radically change the size of the dataset. However, one important issue was observed for the DR datasets that originated in different PubChem bioassays. Although the confirmatory bioassays contain partial experimental measurements for all of the compounds listed in Table S2, actual DR values such as the IC50 are often reported only for a fraction of the dataset, for example, only for active compounds. Although some DR datasets do not suffer from this issue (e.g., AID 1445), others are at the other extreme of the spectrum, with up to 97.8% of filtered compounds lacking explicit XC50 measurements (AID 1117362). On average, 35.57% of compounds do not possess experimentally derived XC50 labels because they were insufficiently active at the top concentration. To address this limitation, we associated the compounds missing this information with the lowest activity value recorded in each dataset (“Minimum pXC50” in Figure 1), providing a training target for machine learning models. This is done to provide a consistent value for inactive molecules and should be interpreted as a lower bound on the pXC50 value. We maintain a flag for each molecule indicating whether its confirmatory activity was experimentally derived or set to a default value.

Main steps of assembling a multifidelity HTS dataset from the corresponding primary and confirmatory screens, which might be reported in the same or different PubChem assays. First, the SMILES string for each molecule is loaded into RDKit, which removes invalid structures. This procedure is followed by a number of filtering steps that ensure a high-quality data collection for drug discovery and machine learning projects, including selection of only the largest fragments, removal of stereoisomers, and removal of electric charges. Finally, missing DR values in the confirmatory assay are set to a default value corresponding to the minimum activity (“pXC50”) observed in the project.

## Section: Methods › Implementation

The data acquisition and filtering steps are implemented as a Python script (pubchem_retrieve.py) with a simple command-line user interface. The program allows downloading and filtering all 60 MF-PCBA datasets as well as any other PubChem assays with similar formats. The main arguments are --AID, indicating the AID of a PubChem assay corresponding to an SD experiment; --AID_DR, optionally indicating the AID of a PubChem assay corresponding to a DR experiment that is separate from the SD dataset; --list_of_sd_cols, indicating the names of the SD activity value columns (including replicates) as displayed on PubChem; --list_of_dr_cols, indicating the names of the DR activity value columns; and transform_dr, allowing the conversion to the corresponding pXC50 value. More advanced filtering options are documented in the source code. The GitHub repository contains customized scripts (i.e., with all of the arguments already set) for all 60 MF-PCBA datasets, such that they can be simply downloaded and assembled with a single call to the intended script. Once downloaded and filtered, the DR datasets can be split into train, validation, and test sets according to the provided five random seeds, enabling easy comparison to the results obtained by previous work and in this article. Splitting is demonstrated with an interactive notebook that is part of the source code.

## Section: Methods › MF-PCBA Format and Problem Specification

After filtering, each of the 60 multifidelity datasets contains the PubChem CID for each molecule, the corresponding molecular structure (SMILES), and the SD and DR activity values. If the SD and DR data originated from the same bioassay, both the SD and DR modalities are provided in the same CSV file. In this case, the name of the multifidelity dataset is given by the original assay name, e.g., AID 1445. Otherwise, separate SD and DR files are provided, and the naming scheme reflects the two data sources, with the DR dataset first (e.g., AID 624326 – 602261).

One of the intended purposes of MF-PCBA is to enable high-quality confirmatory-level predictions by modeling of DR data. Thus, the prediction problem can be naturally formulated as a supervised regression task. At the same time, the binary activity labels from PubChem are included for each dataset. Large amounts of SD activity values are available to support the goal of multifidelity integration for improving the quality of confirmatory-level predictions. Furthermore, we provide five random splits per dataset (80%/10%/10% split ratios for the train/validation/test sets) for the DR data. The accompanying source code allows easy conversion of the CSV files obtained previously into individual train/validation/test CSV files corresponding to each random split seed. A wide range of machine learning techniques are applicable on MF-PCBA, including any algorithm that operates on fixed-dimension vector representations (molecular fingerprints, physical and chemical descriptors, atom and bond encodings, etc.).

As the MF-PCBA collection is based entirely on real-world data generated by HTS experiments, it enables the design and evaluation of new machine learning architectures specifically for drug discovery. Additionally, MF-PCBA can be used as a suite of benchmarks for evaluating the performance of newly developed machine learning applications. For example, MF-PCBA can support the rapidly developing field of representation learning with graph neural networks, particularly in terms of graph-level regression tasks, which are currently underrepresented. At the same time, the collection offers a unique challenge in the form of multifidelity (multimodality) integration. This is a characteristic of drug discovery by HTS that presents new opportunities for computational modeling and ultimately for improved experimental and hybrid wet-lab and in silico workflows. We also envision that the data curated here can be used for other modern machine learning techniques such as generative approaches and few-shot learning.

## Section: Methods › Assay Overlap and Size Considerations

Since PubChem and ChEMBL23,24 are frequently used as data sources for machine learning, it is important to fully characterize MF-PCBA in terms of size, scope, and intended applications. Although many previous studies considered drug bioaffinity data (the ChEMBL 20-derived subset of Mayr et al.,25 PCBA,11 LIT-PCBA,12 and FS-Mol26 are just a few examples), to the best of our knowledge no previous work explicitly considered HTS data of different fidelities or proposed transfer learning in this context. Despite not being purposefully designed to be orthogonal to existing datasets, MF-PCBA shares no overlap in terms of common assays with the 128 assays of PCBA. Twenty-seven of the confirmatory assays that we use are also present in the 1310 assays reported by Mayr et al. There is no overlap in terms of the primary screening assays. We would like to note that a small level of overlap is expected considering that Mayr et al. focused on a large number of generally confirmatory assays extracted from the ChEMBL 20 database. Furthermore, our motivation and our preprocessing and evaluation pipelines are different.

In terms of size, MF-PCBA consists of over 16.6 million unique compound–target interactions, with over 1.1 million unique compounds. In contrast, the largest dataset based on the number of compounds that is reported in the comparison provided by the FS-Mol study has 955,386 compounds. The number of measurements is also larger than in FS-Mol and LSC.27 Moreover, rigorously tagged primary and confirmatory data are more limited compared to other data types. An example search through PubChem returns 407 confirmatory DR datasets (the search steps are described in section SI 10). However, not all of them qualify for MF-PCBA. For example, some assays study toxicity effects or are missing an associated primary screen. As such, some degree of manual selection is required to satisfy all of the previously defined criteria. Overall, the MF-PCBA collection aims to provide a diverse set of multifidelity datasets that is easily extensible through the open source implementation.

Finally, we note that we currently only consider single-task learning, such that a separate model is trained for each of the datasets present in MF-PCBA. This also has the advantage of enabling the use of a wide range of machine learning algorithms other than deep learning. While multitask learning is a common occurrence in chemical modeling projects (e.g., PCBA, FS-Mol), it is not one of the main objectives for MF-PCBA. Since the data uploaded to PubChem originate from various groups using different compound libraries and protocols, the overlap between the chosen assays in terms of common compounds is limited. If we associate all of the unique compounds of MF-PCBA with their activities in the primary screens (or NaN if a compound is not screened in the assay), we find that over 75.6% of values are NaNs. For confirmatory screens, this grows to over 97.7%. Previous work on HTS fingerprints assigned a default activity value (usually 0) to all missing values. Since the true activity is not known, this would lead to a multitask learning scenario where over two-thirds of the data have false values. Sturm et al.19 succeeded in assembling a collection of only 57,124 molecular fingerprints with reduced sparsity, despite starting with an industrial collection of 1250 HTS assays that are generally expected to use the same or similar compound libraries. However, multitask learning for a subset of MF-PCBA with a larger overlap could be an interesting direction for future research.

## Section: Methods › Evaluation Strategies and Multifidelity Modeling

As a first step, we provide an evaluation of the multifidelity integration performance for all 60 datasets based on the multifidelity modeling workflow recently proposed by Buterez et al.20,28 (Figure 2). In this context, the machine learning task is formulated as a supervised learning problem on confirmatory data, i.e., molecules with DR measurements. Thus, the simplest task is training and evaluating models exclusively on data points with DR labels, corresponding to training sets with typically less than 2000 instances, and ignoring the orders-of-magnitude larger SD datasets. Multifidelity modeling is achieved through two augmentation strategies that integrate information derived from the SD data. The first augmentation corresponds to the inclusion of the experimentally determined SD activity value in the internal representation (fixed-dimension vector) of each compound in a machine learning model, corresponding to an append/concatenation operation. All compounds that possess DR activity values typically have an associated SD value, making this strategy generally applicable to HTS datasets. The second augmentation requires a separate machine learning model (here, a graph neural network) to be trained on the entirety of the available SD data in a supervised fashion. In this process, the GNN learns to produce SD embeddings, low-dimensional vector representations that carry the molecular information and its SD activity. The resulting SD embeddings can be appended to the internal representation of a machine learning model exactly as for the first augmentation, with the important advantage that the embeddings can be produced for molecules that were not seen during training. Both augmentations are applicable to any machine learning method operating on fixed-dimension vectors.

The evaluation includes three machine learning algorithms for DR modeling: random forests (RF), support vector machines (SVM), and deep learning (GNNs). Separately, we use GNNs for the SD modeling step. The same hyperparameter optimization strategy and the same steps for determining the most suitable deep learning architecture as in the aforementioned study were are also applied. When designing models for MF-PCBA, we recommend evaluating in terms of “DR only” models, which are trained exclusively on confirmatory activity data, and “SD + DR” models that integrate the two modalities. In terms of performance metrics, we recommend the use of R2 coupled with an error metric such as the mean absolute error (MAE) or root-mean-square error (RMSE) for regression tasks and the Matthews correlation coefficient (MCC) coupled with the area under the receiver operating characteristic curve (AUROC) for classification. The choice is based on both recent recommendations from the literature29,30 and the nature of the data.

A multifidelity integration workflow illustrated with three high-level steps. Confirmatory-level data (DR) can be modeled directly using various machine learning techniques such as RF, SVM, or GNN. Despite not leveraging hundreds of thousands of bioaffinity measurements from the primary screens, this is the prevalent type of modeling in early-stage drug discovery. Instead, an alternative is to model the primary screening (SD) separately and incorporate the learned information through techniques such as transfer learning. Here, this is achieved through graph or molecular embeddings. The embeddings can be included (by concatenation) in the DR modeling step, a procedure we denote as augmentation. We also consider the addition of the SD label to the DR model as an alternative augmentation strategy.

## Section: Results

In this section, we first report the effect of the filtering steps with regard to the number of removed compounds. We then discuss one of the intended uses of the MF-PCBA datasets by evaluating multifidelity integration machine learning techniques. We use the same modeling techniques previously proposed by Buterez et al., focusing on the analysis of the additional 37 datasets that complete the collection of 60 datasets, as the remaining 23 have already been extensively investigated. In order to highlight meaningful differences between the initial collection of 23 multifidelity datasets and MF-PCBA, we introduce the following naming conventions: the terms MF-PCBA and MF-PCBA-60 are used interchangeably to refer to the entire collection of 60 multifidelity datasets; MF-PCBA-23 refers to the previously analyzed subset;20 and MF-PCBA-37 refers to the remaining 37 datasets that complete the collection of 60 datasets. Thus, MF-PCBA-23 and MF-PCBA-37 are disjoint.

Predictive performance, as measured by R2, on (a) MF-PCBA-37 (the subset of 37 multifidelity datasets not discussed by Buterez et al.), (b) MF-PCBA-60 (the entire collection of 60 multifidelity datasets), and (c, d) two examples of individual multifidelity datasets from the MF-PCBA-37 subset. The results in (a) and (b) aggregate metrics from each individual dataset. For each dataset, results are reported for augmented and nonaugmented RF, SVM, and deep learning models. Each model was trained multiple times based on the five different random splits for each dataset. For (a) and (b), the means across five different random splits for each dataset are used to generate box plots.

Plots of the absolute SD/DR correlation (x axis) against ΔR2 (y axis) for RF, SVM, and deep learning models augmented with SD labels on MF-PCBA-37 and MF-PCBA-60, with the Pearson correlation coefficient (r). Brighter colors correspond to higher ΔR2 values. Plots for the SD embeddings augmentation are available in section SI 4.

(a–c) Plots of the ROGI (x axis) against R2 (y axis) for nonaugmented (base), SD-labels-augmented, and SD-embeddings-augmented SVM models. (d–f) Plots of the ROGI (x axis) against the ΔR2 (y axis) for RF, SVM, and deep learning models augmented with SD labels. All panels include the Pearson correlation coefficient (r). Brighter colors correspond to higher R2 or ΔR2 values. Plots for the rest of the models are available in sections SI 5 and SI 6.

## Section: Results › Effects of Filtering on Dataset Size

1.Sanitization with RDKit: On average, this step led to the removal of 863 ± 1313.8 (average ± standard deviation) compounds for the SD datasets (0.33% of the unfiltered size) and 8.7 ± 42.7 for the DR datasets (0.46% of the unfiltered size). For the DR datasets, more than 10 compounds were removed only for two datasets.2.Largest fragment selection: After this step, 11207.9 ± 3594.3 compounds were removed for the SD datasets (3.62% of the quantity at the previous filtering step) and 115.3 ± 110.3 for the DR datasets (7.83% compared to the previous step).3.Stereoisomer removal: After this step, 11396.3 ± 23859.4 compounds were removed for the SD datasets (3.78% of the quantity at the previous filtering step) and 30.7 ± 92.3 for the DR datasets (2.49% compared to the previous step). We choose to remove this information because stereochemical annotations are not consistently recorded and not effectively exploited by many baseline methods.4.Neutralization (removal of electric charges): After this step, 396.6 ± 94.4 compounds were removed for the SD datasets (0.15% of the quantity at the previous filtering step) and 3.9 ± 5.1 for the DR datasets (0.31% compared to the previous step).

## Section: Results › Integration of SD Information Increases Predictive Performance

Previously it was shown that the integration of primary screening information leads to increased performance for the augmented machine learning models. At the same time, many of the datasets that exhibited considerable improvements by multifidelity integration also possessed certain qualities such as high correlation between the SD and DR experimental measurements.

It is thus encouraging to observe that we are able to obtain similar uplifts in predictive performance for the augmented models on the previously unanalyzed 37 multifidelity datasets (Figure 3a). More specifically, the augmentation with SD labels leads to uplifts in R2, on average, from 0.219 to 0.285 for RF, from 0.228 to 0.279 for SVM, and from 0.244 to 0.312 for deep learning. Similarly, for the SD embeddings augmentation, we observe uplifts in R2, on average, from 0.219 to 0.245 for RF, from 0.228 to 0.252 for SVM, and from 0.244 to 0.277 deep learning. This lower performance compared to the SD labels augmentation should be balanced against its unique ability among these methods to produce predictions for unobserved molecules.

As for MF-PCBA-23, we encounter several datasets that benefit drastically from the augmentation strategies. For example, on AID2247 – AID434942 (Figure 3c), an uplift from 0.048 to 0.435 in average R2 is seen for RF with the SD labels augmentation, and an almost identical uplift to 0.436 is achieved for the SD embeddings augmentation. In this particular case, the SD embeddings augmentation is also substantially more effective in reducing the MAE compared to the nonaugmented and SD-labels-augmented models, by almost halving it (section SI 2). Large uplifts are also observed for other datasets such as AID2237 – AID434937 (Figure 3). We also provide an alternative metric in the form of the “unexplained” variance (1 – R2) in section SI 3.

On average, and compared to the previously studied 23 multifidelity datasets, we generally observe both lower nonaugmented and augmented performance. In particular, the average R2 for the nonaugmented models on MF-PCBA-23 is 0.253, while for MF-PCBA-37 the observed value is 0.230. The average R2 achieved by augmenting with SD labels on MF-PCBA-23 was 0.380, compared with 0.291 on MF-PCBA-37. Finally, augmenting with SD embeddings led to an average R2 of 0.306 on MF-PCBA-23 and 0.257 on MF-PCBA-37. The lower overall performance on MF-PCBA-37 could be explained by lower SD/DR correlation or a notion of dataset difficulty, ideas that are explored further below.

We also studied a variation of the SD labels augmentation where for each compound we computed an “SD fingerprint” (SD FP), a vector consisting of all primary screening activities or 0 if such data are unavailable. The SD fingerprint is used in place of the SD label, similar to an SD embedding. We evaluated this variation using deep learning models on MF-PCBA-60. On the whole, the SD FP augmentation only marginally improved upon the baseline models and severely underperformed compared to the SD labels augmentation (section SI 11). This is not unexpected considering the low compound overlap between assays in MF-PCBA and the low chance of the assay targets being related. When considering individual dataset performance, the SD FP augmentation often performed worse than the baseline, alternatively matching the SD labels performance and rarely improving upon it (section SI 12). We did notice that in seven out of 60 cases the SD-FP augmentation outperformed the SD labels augmentation: AID720632 – AID686996 (Figure S53), AID1465 (Figure S67), AID2382 – AID2098 (Figure S77), AID434954 – AID2097 (Figure S82), AID743267 – AID720511 (Figure S84), AID435004 – AID504408 (Figure S92), and AID463203 – AID2650 (Figure S99). Although this augmentation does not offer consistent performance, it is an interesting alternative for poorly performing datasets like AID1465.

To validate the choice of using average R2 scores as part of the evaluation procedure (e.g., as the basis of Figure 3), we computed the average R2 across the five random splits for each dataset and considered nine groups of 60 scores each (corresponding to the 60 datasets). The nine different groups correspond to the three different ML algorithms (RF, SVM, and deep learning) and the three different augmentations (base models, augmented with SD labels, and augmented with SD embeddings). We performed paired t tests between each group of augmented scores and the baseline scores (for each ML algorithm), for six tests in total. The tests indicated statistically significant results for all SD label augmentation groups (p < 0.0001) as well as for the SD embeddings (p < 0.01).

Predictive performance, as measured by R2, on (a) MF-PCBA-37 (the subset of 37 multifidelity datasets not discussed by Buterez et al.), (b) MF-PCBA-60 (the entire collection of 60 multifidelity datasets), and (c, d) two examples of individual multifidelity datasets from the MF-PCBA-37 subset. The results in (a) and (b) aggregate metrics from each individual dataset. For each dataset, results are reported for augmented and nonaugmented RF, SVM, and deep learning models. Each model was trained multiple times based on the five different random splits for each dataset. For (a) and (b), the means across five different random splits for each dataset are used to generate box plots.

## Section: Results › Relationship between the Predictive Performance and Dataset Attributes

Previous work on multifidelity modeling found the correlation between the SD/DR measurements to be a good indicator of model performance and of possible uplifts.20 Here we also performed an analysis of ΔR2 (the difference in performance between augmented models that perform multifidelity integration of SD and DR and nonaugmented DR-only models) as an indicator of the gains possible through augmentation, using both Pearson’s correlation coefficient and multiple linear regression models, for MF-PCBA-37 and MF-PCBA-60.

On MF-PCBA-37, no linear correlation is observed between ΔR2 and the SD/DR correlation for all three machine learning algorithms when augmenting with SD labels (Figure 4a–c) and when augmenting with SD embeddings (Figures S45a–c). However, on MF-PCBA-60 a moderate positive relationship is still present (Figures 4d–f and S45d–f). Interestingly, this indicates that the level of SD/DR correlation is not always indicative of the performance uplift, as some of the highest gains seen on MF-PCBA-37 were for datasets with extremely low correlation (e.g., AID434942 – AID2247 and AID434937 – AID2237). Multiple linear regression models did not indicate significant contributions from any other dataset attribute other than the SD/DR correlation, such as the number of DR compounds or the number of SD compounds for MF-PCBA-60 (Tables S7–S12).

Plots of the absolute SD/DR correlation (x axis) against ΔR2 (y axis) for RF, SVM, and deep learning models augmented with SD labels on MF-PCBA-37 and MF-PCBA-60, with the Pearson correlation coefficient (r). Brighter colors correspond to higher ΔR2 values. Plots for the SD embeddings augmentation are available in section SI 4.

## Section: Results › Evaluating the Difficulty of Learning with the Roughness Index

The “roughness” of the molecular activity landscape can provide insights into the level of difficulty that machine learning models are expected to encounter and also reveal challenging dataset characteristics such as activity cliffs. To quantify this property, we use the recently introduced roughness index (ROGI),31 which can be applied only to the DR datasets because its computation scales quadratically with the dataset size. Intuitively, the ROGI works by coarse-graining a molecular dataset at different levels and quantifying the change in dispersion, which might be affected rapidly or slowly. The notion of dispersion is quantified using the standard deviation of the molecular property. This is related to the idea that similar molecules with extremely different properties (e.g., activity) lead to rapidly changing dispersion.

We computed the ROGI based on the 208 PhysChem descriptors available in RDKit as of October 2022 (the rdkit.ML.Descriptors.MoleculeDescriptors.MolecularDescriptorCalculator function). The alternative, based on Morgan fingerprints also computed by RDKit, led to small ROGI values for all MF-PCBA datasets. Furthermore, the ROGI computation is applied to the filtered datasets before setting missing DR values to the minimum pXC50 value. This prevents artificially modifying the ROGI, for example by “flattening” the activity space. In contrast, all of the trained machine learning models use the entire set of DR values, including the minimum defaults, to exploit the entire amount of data available.

In general, the datasets introduced in the MF-PCBA-60 collection do not appear difficult in terms of the roughness of the chemical space, with ROGI values ranging from 0.014 to 0.571, with an average ± standard deviation of 0.167 ± 0.135 and most of the datasets scoring below 0.4 (see Figure S48 for a histogram). The performance metric (R2) is not correlated with the ROGI for the RF, SVM, and deep learning nonaugmented (base) models (Figures 5a and S46a,c). However, it is possible to observe statistically significant weak, negative linear correlations for the augmented RF and SVM models (Figures 5b,c and S46d,g). The relationship between the ROGI and ΔR2 is not significant for any model at a significance level of 0.05 (Figures 5d,f and S47d–f), but in the case of SVM and deep learning the p values are close, especially in the case of deep learning (p = 0.05042). The highest uplifts in performance are observed for datasets with relatively low ROGI (<0.3), with extremely small or even negative performance differences for the highest difficulty datasets (ROGI > 0.5). Finally, multiple linear regression models did not indicate significant contributions from the ROGI (section SI 9).

(a–c) Plots of the ROGI (x axis) against R2 (y axis) for nonaugmented (base), SD-labels-augmented, and SD-embeddings-augmented SVM models. (d–f) Plots of the ROGI (x axis) against the ΔR2 (y axis) for RF, SVM, and deep learning models augmented with SD labels. All panels include the Pearson correlation coefficient (r). Brighter colors correspond to higher R2 or ΔR2 values. Plots for the rest of the models are available in sections SI 5 and SI 6.

## Section: Discussion

We have presented MF-PCBA, a new collection of 60 multifidelity molecular datasets that reflect the real-world nature of HTS projects in drug discovery. With over 16.6 million unique protein–molecule interactions in total, MF-PCBA represents one of the largest collections of graph-level regression datasets, with the possibility to easily adapt to classification. The multifidelity aspect, enabled by the inclusion of primary and confirmatory screening data, is underrepresented in existing molecular modeling efforts, most likely due to uncertainties regarding the noisiness of the data and the vastly different numbers of compounds between the primary and confirmatory screens. Here we have further validated the value of utilizing multifidelity bioactivity measurements, for example by observing uplifts in R2, on average, between 33% and 40% when using SD labels and depending on the algorithm, further supporting the need for an effective and public multifidelity benchmark, as provided here. Moreover, we have shown that while the SD/DR correlation is a factor in the level of benefit gained by using multifidelity modeling, it is not as strong a factor as had previously been thought.

We showed some tentative signs that the roughness of the activity landscape, as measured by the ROGI, might be another factor, but further work is needed to clarify this and identify additional factors in similar or larger collections. As shown previously, multifidelity modeling can also lead to other desirable properties such as more selective models and new candidate selection workflows. Thus, we envision multifidelity data and models to be a natural step forward for early-stage drug discovery projects based on high-throughput screening. To support this vision, the 60 MF-PCBA datasets are available publicly, aiming to capture the heterogeneity of HTS campaigns in terms of, for example, assay type, targets, screening technologies, primary and confirmatory screen sizes, concentrations, and scoring metrics. Moreover, due to the challenging nature of multifidelity integration, MF-PCBA can act as a representation learning benchmark for future machine learning research and, in particular, for the rapidly advancing area of graph neural networks. At the same time, MF-PCBA is not limited to deep learning, as a multitude of existing machine learning techniques can be applied, enabling more varied comparisons. Overall, we believe that the presented datasets can be used as a basis for advancing both computational drug discovery efforts and molecular machine learning techniques.

## Section: Data Availability

The source code to download, filter, and assemble all 60 MF-PCBA datasets (individually) is available at https://github.com/davidbuterez/mf-pcba. The run time for AID 504329 (335,445 SD molecules) is 554.52 s (9 min 15 s) on a workstation equipped with an AMD Ryzen 5950X processor with 16 cores and 64 GB of DDR4 RAM running Ubuntu 21.10 with an Internet connection speed of 85.81 Mbps (download).


---

# Navigating bioactivity space in anti-tubercular drug discovery through the deployment of advanced machine learning models and cheminformatics tools: a molecular modeling based retrospective study

- **Authors:** Ratul Bhowmik, Ravi Kant, Ajay Manaithiya, Daman Saluja, Bharti Vyas, Ranajit Nath, Kamal A Qureshi, Seppo Parkkila, Ashok Aspatwar
- **Issuer:** Frontiers in pharmacology
- **Type:** Scientific article
- **Published:** 2023-08-29
- **Language:** en
- **DOI:** 10.3389/fphar.2023.1265573
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37705534/
- **Licence:** CC-BY

## Section: Abstract

Mycobacterium tuberculosis is the bacterial strain that causes tuberculosis (TB). However, multidrug-resistant and extensively drug-resistant tuberculosis are significant obstacles to effective treatment. As a result, novel therapies against various strains of M. tuberculosis have been developed. Drug development is a lengthy procedure that includes identifying target protein and isolation, preclinical testing of the drug, and various phases of a clinical trial, etc., can take decades for a molecule to reach the market. Computational approaches such as QSAR, molecular docking techniques, and pharmacophore modeling have aided drug development. In this review article, we have discussed the various techniques in tuberculosis drug discovery by briefly introducing them and their importance. Also, the different databases, methods, approaches, and software used in conducting QSAR, pharmacophore modeling, and molecular docking have been discussed. The other targets targeted by these techniques in tuberculosis drug discovery have also been discussed, with important molecules discovered using these computational approaches. This review article also presents the list of drugs in a clinical trial for tuberculosis found drugs. Finally, we concluded with the challenges and future perspectives of these techniques in drug discovery.

## Section: Introduction

Tuberculosis (TB) is a bacterial disease caused due to the infection of Mycobacterium tuberculosis (Mtb), which has been a chronic infectious disease for decades. According to the WHO, approximately 30 million persons are expected to be infected with the bacillus within 20 years (Vastrad, 2012). It typically affects the lungs and other regions of the body, such as the spine, kidneys, and brain, if not treated swiftly. Tuberculosis (TB) has been proclaimed a global public health emergency by the WHO (Adeniji et al., 2018). As a result, discovering novel medications effective against MDR (Multidrug-resistant) TB, extensively drug-resistant TB (XDR TB), and latent TB is a key priority (Dwivedi et al., 2011; Gautam et al., 2023). Directly Observed Treatment Short is one of the most common anti-TB strategies (DOTS). This method, however, may be ineffective if performed incorrectly, leading to resistance to anti-TB drugs. MDR-TB will develop if anti-TB drug regimens are provided in incorrect dosages or with low-quality drugs (MDR-TB).

Moreover, if administered to treat individuals who are HIV-positive or have compromised immune systems, it could lead to the emergence of widespread drug-resistant tuberculosis (XDR-TB) (Shetye et al., 2020). Isonicotinic acid, Hydrazide, Rifampicin, Ethambutol, Streptomycin, and other drugs have been used extensively in treating tuberculosis (Vastrad, 2012). Although tuberculosis death is often preventable, the rapid rise in MDR and XDR-TB has necessitated the development of new drug targets for Mtb (Chapman et al., 2012). TB is transferred mainly through the air when a healthy individual inhales these bacteria, which are droplets from air contaminated and take entry into the lungs. Either the host gets a primary infection, or the illness remains dormant. Alveolar macrophages perceive them as external agents who attempt to engulf the bacterium during this process. On the other hand, complete bacterium deactivation is nearly impossible to achieve. As a result, the bacteria multiply and infect macrophages, spreading to other parts of the lung ( Ahamad et al., 2017; Jin et al., 2017). This study aims to enhance anti-tubercular drug discovery by integrating advanced machine learning and cheminformatics tools. Using a molecular modeling-based approach, we aim to quickly identify potential drug candidates and targets against Mycobacterium tuberculosis, addressing drug-resistant strains. We’ll explore computational techniques like QSAR, molecular docking, and pharmacophore modeling to streamline drug discovery. Our goal is to predict, characterize, and prioritize drug molecules, including lead structures and novel targets, while assessing their versatility and utility. We’ll also highlight ongoing clinical trials and evaluate challenges and future prospects in computational drug discovery. Through these efforts, we aim to advance targeted therapies against drug-resistant tuberculosis using advanced computational methods.

Drug design techniques and groups.

Schematic presentation of the drug discovery and development process.

## Section: Introduction › Mechanisms of action and limitations of antitubercular drugs

These drugs are categorized according to their source, like synthetic, semisynthetic, and natural products. Patient situation/stage (lines) and mode of action must be considered during treatment (Ahamad et al., 2017). The finding and creation of new anti-TB therapeutics are widely recognized as one of the world’s most challenging public health issues; however, it is also a significant pharmaceutical challenge. Drug development is a lengthy procedure. Following a clinical trial, it can take decades for a molecule to reach the market. Computational approaches have aided drug development (Doreswamy and Vastrad, 2013; Ojo et al., 2021). The Quantitative Structure-Activity Relationship (QSAR) method is a powerful tool that is used in drug development all over the world. QSAR models are mathematical equations that show how chemical structures and biological processes are linked. The QSAR approach can potentially minimize the time and effort necessary to find novel compounds or increase the efficiency of current ones ( Adeniji et al., 2018). QSAR models are increasingly used with virtual screening and combinatorial libraries to predict the fate of physiologically active compounds (Ahamad et al., 2017). It is possible to use this method in the development of future drugs. Increasing the speed of QSAR-related studies would facilitate the design and optimization of new drug candidates (Adeniji et al., 2018). Another capability of these models is that they can provide a deeper understanding of biological activity mechanisms (Vastrad, 2012). In QSAR modeling, various descriptors were employed, such as constitutional, geometrical, topological, quantum chemical, and other descriptors ( Ojo et al., 2021). This approach might be applied to predict the activity of newly proposed compounds before their synthesis and evaluation ( Vastrad, 2012; Adeniji et al., 2018). Molecular docking is a module that allows two or more molecules to recognize one other by matching their geometry and energy. It is a valuable tool in drug development for establishing the compatibility of molecules (ligands) with their target (receptor). It helps determine how a receptor interacts with its ligand and elucidates its binding process ( Qing et al., 2014; Adeniji et al., 2018).

A pharmacophore must possess several chemical qualities to elicit a response from a receptor target. Pharmacophore models may be created using either a receptor alone or a receptor-ligand combination (Wermuth et al., 1998; Leach et al., 2010; Macalino et al., 2020). Pharmacophores are schematic representations of the main aspects of molecular recognition that may be used to represent and identify compounds on a 2D or 3D level. Physicophore model-based database screening is essential for computer-aided drug development since it gives information on receptor interaction’s geometric and electrical aspects (Qing et al., 2014). According to IUPAC, a Pharmacophore is a combination of steric and electronic qualities required for interaction with a target structure to trigger a biological response. Using a mix of pharmacophore model-based screening and docking studies to find novel drugs has been proven effective (Leach et al., 2010). Pharmacophore screening and docking can be combined to speed up the discovery of new drugs and improve their chances of survival (Macalino et al., 2020). Using molecular docking and other bioinformatic methods to evaluate candidate compounds before in vitro cell culture assays or chemical changes can help speed up drug discovery. Pharmaceutical and medicinal chemists can use QSAR and molecular docking investigations to design and synthesize novel anti-TB drugs (Adeniji et al., 2018).

## Section: Introduction › QSAR, pharmacophore modeling, and molecular docking and their importance in drug discovery

The process of drug discovery and the development of a novel medicine is costly and time-consuming. Several laboratories and in vivo tests are used to determine therapeutic effectiveness and health risks. As a result, new methods are being developed to limit animal use in research, reducing ethical (and budgetary) concerns ( Bajot, 2010).

The computational tools are mainly utilized to.(i) perform the molecular structure confirmation (e.g., molecular dynamics);(ii) characterize the interactions between drugs and targets (e.g., molecular docking);(iii) to assess and optimize the activity of the drug through QSAR techniques.

There are mainly two drug design techniques: structure and ligand-based drug design (SBDD and LBDD). Using SBDD, any target inhibitor molecule can be designed, while LBDD primarily focuses on the chemical interaction between the target receptor and the inhibitor ( Abdel-Ilah et al., 2017). The drug design techniques and groups are presented in Figures 1, 2 (Abdel-Ilah et al., 2017).

Drug design techniques and groups.

Schematic presentation of the drug discovery and development process.

## Section: The significance of QSAR

Quantitative structure-activity relationships (QSARs) utilize computational and mathematical models to identify the correlation between pharmacological activities and chemical structure compounds ( Kwon et al., 2019). QSAR is gaining traction as a less expensive alternative to medium-throughput in vitro and low-throughput in vivo research in the drug development process (Figure 2) (Prachayasittikul et al., 2015; Qureshi et al., 2023). In addition, QSAR models are increasingly used in drug discovery and environmental toxicology to predict and classify drug resistance, toxicity, and physicochemical characteristics (Verma et al., 2010). The QSAR technique is based on the premise that changes in a chemical’s molecular structure may be quantitatively linked to variations in its biological activity ( Testa, 1995). Hammett first discovered the QSAR in the 1930s, and Hansch and Fujita developed it in the mid-1960s ( Tandon et al., 2019). Hammett’s works are significant contributions to the field of chemistry, particularly in the realm of Quantitative Structure-Property Relationships (QSPR). Through his research, Hammett established intricate mathematical connections between the acidity of compounds and the electronic effects of various functional groups. This innovative approach shed light on the underlying principles governing chemical reactivity and laid the groundwork for developing Quantitative Structure-Activity Relationship (QSAR) models. Medicinal chemists may now think about their structures in terms of physical properties rather than only pharmacophore groups due to the QSAR approach and philosophy. As a result of research, new inhibitors may be created from scratch, and existing medicines may be improved regarding absorption, distribution, metabolism, excretion, and toxicity (Abdel-Ilah et al., 2017; Kwon et al., 2019). QSARs are a computerized statistical method for explaining observed variation in replacement structure changes. QSAR modeling has extensively prioritized compounds for manufacture and biological assessment. The QSAR models may be utilized to identify potential hits and enhance hit-to-lead ratios, to aid in the efficient selection and optimization of compounds for further development and biological evaluation ( Neves et al., 2018). Because no chemical needs to be made or tested before computer assessment, QSAR is a labor-, time-, and cost-effective technique for acquiring molecules with desired biological characteristics. As a result, QSAR is extensively employed in businesses, colleges, and research institutions throughout the globe ( Cherkasov et al., 2014). There are five main steps in QSAR, including incorporating molecular structures and creating three-dimensional models. Since geometric descriptor calculations require molecular models in three dimensions: i) developing molecular structure descriptors, ii) selecting the most critical descriptors, which can be accomplished by using feature selection methods, iii) developing QSPR/QSAR models using the descriptor sets, and iv) validating the model by predicting the activity of substances based on external prediction data (Winkler, 2002) (Figure 3) ( Piir et al., 2018).

Virtual screening (VS.) is a common computer approach for screening huge libraries of smaller molecules for novel hits with desirable features that may then be evaluated experimentally. Like other computational techniques, VS. aims to speed up the discovery process by minimizing the number of candidates that must be tested and rationalizing their selection (Neves et al., 2018). Furthermore, due to its time, cost, resource, and labor reductions, VS. has become quite popular in pharmaceutical businesses and academic institutions ( Schaduangrat et al., 2020). QSAR analysis is the most effective VS. technique due to its high throughput and hit rate ( Aparoy et al., 2012). The Organization for Economic Cooperation and Development (OECD) accepted the following five principles for effective QSAR models to be used in regulatory evaluations of chemical safety: 1) a stated end aim; 2) a clear technique; 3) a defined scope of application; 4) appropriate goodness-of-fit, robustness, and predictability metrics; and 5), if feasible, a mechanistic interpretation ( Gandhi et al., 2021).

The Quantitative protein (or proteome)- disease relationships (QPDRs) are extensively utilized for illness prediction, whereas QSAR is frequently employed for pharmacological property prediction ( Munteanu et al., 2010). Although they have been used for decades to predict and correlate the activity of molecules, there are several limitations to them, including i) the lack of training molecules in some cases; ii) they consider only two-dimensional structures; iii) the Hammett constant and other parameters are insufficient to link drug-receptor interactions; vi) there are no certain physiochemical criteria, no stereochemistry representation, and no one-of-a-kind solutions (Patel et al., 2014; Gandhi et al., 2021).

A workflow for QSAR modelling.

Predictive approach for QSAR modelling.

The role of applicability domain in various stages of the QSAR life cycle.

A framework of Pharmacophore architecture.

Schematic presentation of covalent docking.

An overview of the docking process for molecules. (A) The ligand’s three-dimensional structure; (B) the 3D structure of the receptor; (C) The ligand is docked into the receptor’s binding cavity, and potential conformations are investigated.; (D) The detected intermolecular interactions and the most plausible binding conformation.

List of some compounds discovered to target tuberculosis bacteria by using approaches of QSAR, pharmacophore modeling, and molecular docking.

A list of the drugs that are in a clinical trial is discovered with the help of these approaches.

## Section: The significance of QSAR › Classification of QSAR methodologies › Based on the dimensionality of molecular descriptor

i. 0D QSAR- These descriptors are obtained from the molecular formula. 0D-QSAR focuses on zero-dimensional descriptors, such as constitutional descriptors, that include basic molecular information like the number of atoms, bonds, or functional groups (Gackowski et al., 2023).ii. 1D QSAR- This correlates activity with global molecular parameters such as pKa, log P, and others. These descriptors are more straightforward and can be calculated more easily than higher-dimensional QSAR methods. The 1D-QSAR models are usually based on linear regression techniques, and they represent a straightforward approach to correlating molecular properties with biological activity 1D-QSAR has been applied to the study of various biological systems, such as the modeling of anti-cancer activity of a series of benzimidazole derivatives. This study’s models were based on simple one-dimensional descriptors, such as logP (partition coefficient), which provided significant insights into the molecular features responsible for the observed activity (Chandrasekaran et al., 2018).iii. 2D QSAR- A molecular network containing topological or two-dimensional (2D) information is known as a 2D QSAR. The 2D-QSAR methodology involves the relationship between the chemical structure and biological activity of molecules, considering only two-dimensional properties like molecular weight, dipole moment, and hydrogen bond donors/acceptors. A classic application of 2D-QSAR is in drug discovery, where it has been used to model the activity of HIV protease inhibitors (Abdel-Ilah et al., 2017).iv. 3D QSAR- These are calculated from a molecule’s geometrical or 3D representation. 3D-QSAR adds a third dimension to the analysis, considering the three-dimensional spatial arrangement of atoms in a molecule. It is often applied to understand how small molecules interact with a target protein in 3D space. 3D-QSAR has been extensively applied in studying enzyme inhibitors, such as developing new kinase inhibitors for cancer therapy (Ajjarapu et al., 2021).v. 4D QSAR- This model describes four dimensions of information, with the fourth dimension being an ensemble of conformation for each ligand. 4D-QSAR includes the three spatial dimensions and adds the fourth dimension, representing molecular flexibility or time-dependent behavior. This considers how a molecule’s shape might change over time or under different conditions (Hopfinger et al., 1997).vi. 5D QSAR- In 4D-QSAR, 5D-QSAR explicitly represents different induced-fit models (Verma et al., 2010; Patel et al., 2014; Abdel-Ilah et al., 2017). 5D-QSAR adds a fifth dimension, often representing the molecular solvation effects. It considers how solvent molecules interact with the molecule of interest (Good, 2006).

## Section: The significance of QSAR › Classification of QSAR methodologies › Based on the type of chemometric methods used

i. Linear method: Linear methods assume a linear relationship between the structure and activity. Common linear methods include multiple linear regression (MLR), partial least squares (PLS), and principal component regression (PCR).ii. Non-linear method: Non-linear methods are used when the relationship between the structure and activity is complex and non-linear. Techniques include artificial neural networks (ANNs), support vector machines (SVMs), and k-nearest neighbors (k-NN).

## Section: The significance of QSAR › Types of techniques for QSAR modeling

1. The simple linear regression (SLR) method generates a QSAR model in equations using a standard linear regression calculation. This technique has proven to be quite promising for developing structure and activity correlations (Verma et al., 2010). Using a straight line, SLR models the relationship between a single independent variable and a dependent variable. It assumes a linear relationship and is widely used for prediction and understanding how the variables are related. The method is simple, interpretable, and widely applied in various scientific fields. SLR might not capture complex relationships that involve multiple variables (Draper and Smith, 1998). Linear Methods, Used in modeling structure-activity relationships in drug discovery, predicts novel compounds’ biological activity (Krishnapuram et al., 2005). 2. Multiple linear regression (MLR) extends SLR to several dimensions. Standard multivariable regression calculations are used in this procedure. All of the descriptors under study are subjected to identifying a drug property. MLR provides a more nuanced understanding of the system under study by considering more variables. It is a powerful tool for prediction and explanation but requires careful handling of collinearity among predictors. Adequate variable selection is essential for building meaningful models (Schneider et al., 2010 ). 3. Stepwise multiple linear regression- Variation MLR, which yields a multiple-term linear equation but does not use all independent variables, is widely used in this approach. This method works effectively when there are a lot of descriptors and the key ones are not known (Patel et al., 2014). SMLR combines the principles of MLR with a sparsity constraint, ensuring that only the most relevant variables are used in the model. This can lead to better interpretability and prevent overfitting. SMLR is particularly useful when dealing with high-dimensional data requiring feature selection. It is a modern technique that bridges statistical modeling with machine learning (Krishnapuram et al., 2005).4. The partial least square method (PLS) provides a statistically robust solution even when the independent variables are heavily connected, or the number of observations exceeds that ( Verma et al., 2010; Patel et al., 2014). PLS is a sophisticated regression method that extracts latent variables explaining the covariance between independent and dependent variables. It is widely used in chemometrics for handling multicollinearity. PLS provides robust and interpretable models by focusing on the variables most related to the response. It is precious when numerous predictors are highly correlated (Mehmood et al., 2020). Applied in various fields like drug design, metabolomics, and environmental toxicity prediction, where non-linear relationships are common (Everitt et al., 2011).5. Principle components analysis (PCA) is a technique for creating a new set of orthogonal descriptors called principal components (PCs) that describe the bulk of the information in the independent variables in decreasing order of variance. CA is also utilized in PLS approaches for variable selection (Patel et al., 2014). PCA is a dimensionality reduction technique that transforms the data into orthogonal components, capturing the most variance. It is a robust exploratory data analysis, visualization, and preprocessing tool. PCA helps understand the underlying structure of data and is widely used in various scientific fields, including chemometrics and bioinformatics (Prachayasittikul et al., 2015; Jolliffe and Cadima, 2016).6. The genetic function approximation (GFA) method can be used as an alternative to average regression analysis to construct QSAR equations. It can create both linear and higher-order non-linear equations. Genetic algorithm partial least squares (G/PLS or GA-PLS) are a helpful method that combines the most significant features of GFA and PLS. GFA applies genetic algorithms to find the optimal subset of descriptors in regression analysis. It can model complex non-linear relationships and is highly flexible. GFA has been applied successfully to model various chemical and biological systems, especially in QSAR studies. Its ability to navigate vast descriptor spaces makes it a valuable tool in computational chemistry (Rogers and Hopfinger, 1994).7. Cluster analysis is a multivariate approach for classifying structures into subsets (called clusters) that are similar in some manner (Patel et al., 2014). Cluster analysis is a grouping technique used to categorize objects into clusters based on their similarity. It is unsupervised, meaning that the categories are not predefined. Cluster analysis has diverse applications, including market segmentation, image processing, and pattern recognition. It provides insights into the natural groupings within data (Zhang et al., 2023).8. Artificial neural networks (ANNs) are nonlinear computational models that simulate the activity of human neurons to make predictions ( Prachayasittikul et al., 2015). They can be used to model QSAR and solve pattern recognition difficulties (Patel et al., 2014). ANNs are inspired by the human brain’s function and consist of interconnected nodes or neurons. They are capable of modeling complex, non-linear relationships between inputs and outputs. ANNs have been applied in numerous fields, including image recognition, natural language processing, and QSAR modeling. The flexibility and adaptability of ANNs make them a powerful tool, but they require careful tuning and interpretation (Trinh et al., 2021). Used in virtual screening and toxicity prediction, providing accurate models that can handle the complexity of biological systems (Pérez et al., 2021).

## Section: The significance of QSAR › Molecular descriptors and their significance

Despite significant advancements in drug design, descriptors used to designate the molecular structure of biologically active compounds remain the primary method for identifying novel lead molecules. For QSAR/QSPR investigations, descriptors are numerical representations of the chemical properties of a molecule. For statistical model construction to be possible, the mathematical representation of these descriptors must be independent of the molecule’s size and number of elements. In QSAR/QSPR modeling, molecular descriptors have evolved into the most important variables. The information conveyed by descriptors typically depends on the type of molecular representation and the defined algorithm for its calculation. Among these are topological indices, geometrical, structural, and physicochemical descriptors.

Constitutional descriptors are basic, widely-applied descriptors that reflect the molecular composition of a compound without providing information about its topology. The most common constitution descriptors are the number of atoms, number of bonds, variety of atoms, ring count, and molecular weight (MW). These descriptors are insensitive to conformational changes and do not distinguish between isomers.

Recent developments in lead discovery, drug design, virtual screening, combinatorial library design, and database search discrimination also highlight the importance of topological descriptors in drug discovery. Topological indices (TIs) are two-dimensional descriptors that consider the intrinsic atomic arrangement of compounds. These descriptors are derived from the topological representation of molecules and can be considered structure-specific. These indices encode numerical information regarding the molecular size, shape, branching, presence of heteroatoms, and number of bonds. By the nature of chemical bonds, these TIs represent the interconnectedness of atoms within molecules. They play a crucial role in modeling various physicochemical properties, biological activities, and pharmacokinetic properties. A molecular graph represents a topological representation of a molecule. This graph is denoted mathematically as G = (V, E), where V is the set of vertices corresponding to the atoms of the molecule, and E is the set of elements representing the binary relationship between pairs of vertices. These chemical graphs depict the molecular structure in a non-numerical format; however, a numerical translation of the graph is required to calculate topological descriptors. The most commonly used descriptors are the Wiener index, the Connectivity indices, the Kier shape, the Balaban J index, and the Zagreb indices. The primary function of these indices is to classify molecules according to their size, degree of branching, flexibility, and overall morphology (Wiener, 1947; Randic, 1975; Balaban, 1982; Roy, 2004).

The 3D coordinates of the atoms in a given molecule are used to derive geometrical descriptors. In comparison to topological descriptors, these descriptors are abundant in information and discrimination power for analogous chemical structures and molecule conformations. In addition, they contain data acquired from atomic van der Waals regions and their overlap on the molecular surface. Despite their high informational density, these descriptors typically have disadvantages as well. Geometric descriptors necessitate geometry optimization and, consequently, the computational burden to calculate them. Thus, for flexible molecules that can assume multiple conformations, new information can be utilized. Nonetheless, this results in the issue that complexity can increase substantially. Moreover, alignment constraints are required for the majority of these descriptors (grid-based descriptors) to accomplish molecule comparability. A molecule’s physical and chemical properties that can be estimated from its two-dimensional structure are physicochemical descriptors. These properties play a significant role in determining the substance concentration in the body. A drug’s efficacy and, consequently, its market value can be enhanced by its possessing the appropriate properties. Thus, examining these properties of a drug not only contributes to the drug’s safety profile but also plays a crucial role in drug discovery by optimizing the compounds chosen. In addition to selecting candidate compounds with the appropriate physicochemical properties, it is necessary to pay special attention to properties such as lipophilicity, solubility, and permeability, which can ensure optimal potency (Leo et al., 1975; Ghose and Crippen, 1986). In contrast, molecular fingerprints have been utilized for decades to investigate large chemical libraries for similar compounds. The information content of 2D signatures is derived from atoms, bond types, and graph distances derived from chemical graphs, where these are represented as bits. Each bit indicates the presence or absence of a predetermined substructure in a compound. A bit in a structural fingerprint corresponds to a chemical property, typically the presence of some substructure. Based on the similarity to a biologically active molecule, these biomarkers enable researchers to identify additional compounds with a higher probability of displaying similar biological potency against the same target. Molecule properties, such as chemical diversity in chemical space, can be characterized using fingerprints. Such evaluations are crucial in the compound selection process before experimental screening. Numerous fingerprint varieties can be used for structural comparisons of various sorts. Such signatures have become a popular option for drug discovery because they offer a decent balance and empirically reasonable proportionality. By quantifying fingerprint overlap with similarity coefficients and using the resulting values to measure molecular similarity, fingerprint similarity searching generates a database ranking. A Tanimoto coefficient (Tc) value of >0.85 indicates a high probability that the test compounds have similar bioactivity. However, Tc is only useful for data with comparable levels of complexity; other coefficients are preferred for data with varying levels of complexity (Willett, 2006; Rogers and Hahn, 2010; Helal et al., 2016).

Initially, 2D fingerprints were designed for similarity searching using a single template, but some studies claim that search performance is enhanced when multiple reference compounds are employed. MACCS, PubChem, and Extended-Connectivity biometrics (ECFP) are the most commonly used biometrics. MACCS is a compilation of 166 bits that encompasses most of the chemical characteristics important for virtual screening. The PubChem signatures database contains 881 bits of descriptors for element counts, aromatic or nonaromatic ring counts, atom pairs, atom neighborhoods, and particular fragments. These 2D signatures have been successfully utilized in the virtual screening of novel active compounds. Using PubChem bioassays, comprehensive bioactivity profiles, dubbed “PubChem high-throughput screening fingerprints” (PubChem HTSFPs), were recently developed. In addition, these PubChem-HTSFPs were utilized in hit expansion experiments for 33 unique targets. These signatures were useful for retrieving matches with structural diversity and the desired bioactivities. ECFPs are a novel class of 2D circular signatures used for molecular characterization. These signatures are an extension of the Morgan algorithm. These circular fingerprints have numerous advantageous characteristics, including i) being easy to calculate; ii) representing a large number of distinct features; and iii) not being reliant on predefined features; thus, they can represent novel structural variation. These fingerprint types effectively employ encoded rich data for similarity searching, compound clustering, and chemical library analyses. In addition, ECFPs are frequently employed in QSAR and QSPR model development for lead optimization and ADMET property forecasting (Willett, 2006; Rogers and Hahn, 2010; Helal et al., 2016).

Therefore, concerning anti-tubercular drug discovery, a combination of different machine-learning-assisted QSAR models is required while implementing molecular descriptors and molecular fingerprints of molecules’ datasets for feature selection against any biological target. The best way to deal with major demerits of different types of molecular descriptors is to include two or more molecular descriptors while constructing the hybrid descriptors-based QSAR models. Hybrid molecular descriptors incorporate multiple molecular characteristics, including topological, electronic, and geometric properties. This exhaustive representation accounts for a broader range of factors that contribute to the activity of a molecule, thereby enhancing the model’s predictive accuracy. The same approach should be applied while considering molecular fingerprints for anti-tubercular drug design by constructing a hybrid fingerprint-based QSAR. Therefore, the use of both hybrid molecular descriptors and molecular fingerprint-based QSAR models will have a distinct and interpretable relationship with the activity of a molecule that will additionally aid researchers in analyzing the contributions of particular characteristics or substructures to the overall activity, thereby facilitating the design of novel compounds with the desired properties. Apart from this, hybrid molecular descriptors and molecular fingerprints can represent a wide variety of chemical structures, including novel and unconventional compounds. This adaptability is essential for investigating new chemical space and identifying potential drug candidates with distinctive structural characteristics. In ensemble modeling, where multiple QSAR models or screening methods are combined to improve predictive performance, hybrid molecular descriptors and molecular fingerprints can also be used. This strategy combines the advantages of various techniques, resulting in more accurate and robust forecasts. Due to their ability to provide a comprehensive, interpretable, and computationally efficient representation of molecular structure and activity, hybrid molecular descriptors and molecular fingerprints are favored for QSAR modeling and drug design. These techniques have significantly accelerated the drug discovery process by allowing researchers to prioritize and design promising compounds for further experimental evaluation (Willett, 2006; Rogers and Hahn, 2010; Helal et al., 2016). As computational methods continue to advance, hybrid descriptors and molecular signatures will likely play a greater role in shaping the future of drug development against tuberculosis.

## Section: The significance of QSAR › Modeling QSAR using chemical space analysis

Chemical space is vital in drug development for various purposes, including library creation, compound classification, selection, structure-activity relationship (SAR) investigation, and understanding structure-property connections (SPR) (Naveja Medina, 2019). It encompasses all descriptors derived from chemical compounds. The chemical space analysis for FDA-approved drugs showed shared traits, including substantial halogen content and molecular weights below 500, consistent with Lipinski’s rule of five. This rule suggests that drugs with an MW less than 500 have better bioabsorption and bioavailability (Prachayasittikul et al., 2015). Chemical space represents the collection of all potential organic compounds, and as its scale increases, cartographic approaches are used to visualize and conceptualize it. Machine learning methods benefit from chemical space approaches as they identify clusters of related compounds. Lipinski’s rule of five indicates that drug-like compounds exhibit drug resemblance with MW < 500 Da, clogP <5, few H-bond donors (<5), and few H-bond acceptors (<10) (Ganesan, 2008). Optimizing this rule is essential for improving BBB permeability by passive diffusion. Factors like MW, log P, and H-bond donors and acceptors influence drug interaction with the blood-brain barrier (BBB) (Lambrinidis and Tsantli, 2018). By analyzing the chemical composition of natural compounds and determining their molecular structures, the investigation identified 11 novel inhibitors for ß-hydroxysteroid dehydrogenase type 1 ( Koch et al., 2005). According to Reayi, diversity-oriented synthesis (DOS), a chemical synthesis strategy for swiftly building a library of compounds, can help deorphanize druggable protein targets ( Reayi and Arya, 2005). ChemGPS-NP was used to examine the chemical space of natural products from different databases (Larsson et al., 2005). They discovered that 40,348 compounds from the Dictionary of Nature Products Database passed Lipinski’s rule of five ( Rosén et al., 2009). To define “bioactive natural compound-likeness,” (Zhou et al., 2010), used structure-activity relationships to investigate the chemical space of natural products, comparable to Lipinski’s rule of five (drug-likeness) (BNC-likeness). The drug-likeness and BNC-likeness models were utilized to compare the structural properties of bioactive and non-bioactive natural products. The Ethnobotanical Database and Dr. Duke’s Phytochemical Database were used to create a dataset of 1,580 natural products from a total of 7,549 natural product constituents. 790 natural compounds were bioactive, while the remaining 790 were not, resulting in a well-balanced dataset. Bioactive natural compound-likeness models were created using SVM with radial basis function kernels, and the training set consisted of 1,580 bioactive substances. An independent external data set of 81 bioactive and 81 non-bioactive natural compounds from commonly used medicinal plants were used to test the models’ performance. The prediction results effectively classified 75 bioactive chemicals, indicating the robustness of the models and their immunity to overfitting. One of the issues with machine learning is overfitting, which arises when noise data is used as an independent variable in developing highly predictive models ( Zhou et al., 2010).

## Section: The significance of QSAR › Model validation methodology for QSARs

The validation approach tries to provide a model with defined descriptors that is statistically trustworthy because of a cause-and-effect connection rather than a random numerical link. Validation procedures are required to determine a model’s predictive ability. Internal and external validation techniques are the two sorts of validation methods accessible. Training datasets are used by internal techniques such as Q2 (squared correlation coefficient), R 2 (coefficient of determination or coefficient of multiple determination for multiple regression), chi-squared (X2), and root-mean-squared error (RMSE). When applied to new data sets, the model’s lack of predictability is a significant flaw in this technique. External approaches, on the other hand, are based on the testing set and are considered the most reliable validation ( Abdel-Ilah et al., 2017; Kwon et al., 2019). These statistical methods ensure that the models produced are accurate and unbiased. Cross-validation approaches such as accuracy (ACC), sensitivity (SEN), specificity (SPEC), and Matthew’s correlation coefficient (MCC) ( Prachayasittikul et al., 2015) can be used to assess the model’s internal predictive capability. In contrast, its external predictability can be evaluated using a separate set of molecules (the test set) that were not used in the model creation ( Testa, 1995; Verma et al., 2010). The CV method begins by removing one or more compounds from the training set, which serves as a temporary test set. The remaining data points are used to form a CV model, which is then tested on the deleted molecules to see if it can accurately predict bioactivities using the descriptors from the original model (Figures 4, 5).

External validation, the Y-randomization test, the domain of applicability, and the William plot are some statistical techniques that can be used to assess a QSAR/QSPR model’s predictive ability. External validation is a method of testing a QSAR/QSPR model’s external predictivity by omitting a section of data at the start of the experiment and using the remaining internal set to evaluate optimal learning algorithm parameters ( Prachayasittikul et al., 2015).

The accuracy (ACC), sensitivity (SEN), specificity (SPEC), and Matthew’s correlation coefficient MCC) are used to evaluate the prediction performance of the proposed QSAR/QSPR model using cross-validation (CV), which is given by the following formula Eqs 1–4 Accuracy=TP+TNTP+TN+FP+FN×100 (1) Sensitivity=TPTP+FN×100 (2) Specificity=TNTN+FP×100 (3) MCC=TP×TN−FP×FN√TP+FNTN+FPTN+FN (4)

TP, TN, FP, and FN- Numbers of true positive, true negative, false positive, and false negative.

Matthew’s correlation coefficient (MCC) measures the gap between actual and expected values. The coefficient is a balanced measure that can be employed when the classes are of various sizes and take into consideration true negatives (TN), true positives (TP), false negatives (FN), and false positives (FP). The equation is used to derive the formula. In machine learning, Matthew’s correlation coefficient (MCC) is used to assess the quality of binary and multiclass classifications. Like most correlation coefficients, MCC has a range of 1 to 1, with 1 denoting the best agreement between actuals and forecasts, −1 denoting an inverse prediction, and 0 denoting no agreement. Alternatively, the prediction is random in comparison to the actual situation ( Mun and Geng, 2019).

Predictive approach for QSAR modelling.

The role of applicability domain in various stages of the QSAR life cycle.

## Section: The significance of QSAR › Machine learning drug development

Due to an influx of available data and increased computer capacity, machine learning (ML) technologies are coming back in drug development investigations. This has sparked a flurry of artificial intelligence (AI) drug development investigations, in which machine learning (ML) and deep learning (DL) approaches are used to solve issues efficiently and intelligently. Combining structural, sequence, and evolutionary data yields machine-learning models (Verma et al., 2010). An analysis of hydrophobicity, side-chain pKa, solubility, solvent accessibility, and other physiochemical parameters is conducted, as well as the development of a machine-learning model to predict binding and non-binding residues. Only a few models predict binding sites based on one of the binding partners’ structures, whereas others employ information from both partners ( Kumar et al., 2018). The two types of machine learning methodologies are unsupervised and supervised learning. Labels are allocated to training data in supervised learning, and the model can predict labels for specific data inputs once it is ready. On the other hand, unsupervised machine learning algorithms can profit directly from unlabeled molecular pattern data, as they require input data and no output components (Supplementary Table S7) (Singla et al., 2013).

## Section: The significance of QSAR › The significance of pharmacophore

Ehrlich coined the pharmacophore as “a molecular framework that conveys (phoros) the key properties responsible for a drug’s (pharmacon) biological activity” in 1909 ( Yang, 2010). According to the IUPAC nomenclature (Leach et al., 2010), a pharmacophore is a molecule that possesses both steric and electronic properties that enable it to produce efficient supramolecular interactions with a biological target structure and activate or inhibit its biological response (Figure 6).

To better understand ligand-protein interactions, pharmacophore models are developed. They may be utilized to discover new compounds that match the pharmacophore criteria and are thus expected to be active ( Muhammed and Aki-Yalcin, 2021). Using a mix of pharmacophore model-based screening and docking studies to find new drugs has been proven beneficial ( Mesli et al., 2021). If the target’s structure is unknown, a pharmacophore model can be created utilizing structural data from the active ligands that bind to it. The ligand-based pharmacophore modeling technique (Yang, 2010; Muhammed and Aki-Yalcin, 2021) is the name given to this approach.

When the target’s structure is known, pharmacophore models can be constructed utilizing the target’s structural attributes. This is the structure-based pharmacophore modeling approach (Vastrad, 2012). A whole framework of Pharmacophore is shown in Figure 6 (Muhammed and Aki-Yalcin, 2021). A list of pharmacophore modeling software is enlisted in (Supplementary Table S8) (Yang, 2010; Singla et al., 2013; Kumar et al., 2018; Schaller et al., 2020; Muhammed and Aki-Yalcin, 2021).

The pharmacophore analysis has the most important common denominator of the molecular interaction properties shared by a group of active compounds. It is an abstract idea rather than a physical molecule or combination of chemical groups ( Qing et al., 2014). Integrating knowledge about the three-dimensional nature of molecular interactions is another significant component of current pharmacophore research. This point of view is centered on 3d-pharmacophore techniques (Leach et al., 2010), which define the spatial relationship between pharmacophore features. Virtual screening, de novo design, lead optimization, and multitarget drug design have all utilized pharmacophore-based approaches ( Yang, 2010; Kumar et al., 2018; Muhammed and Aki-Yalcin, 2021). There are limitations with pharmacophore scoring functions that limit its ability to realize its intended potential, especially with the current high cost of discovering and developing new medicine. The involvement of other computational methods is critical in overcoming these obstacles. As a result, combining pharmacophore modeling with different computational approaches addresses some of these constraints ( Yang, 2010; Kumar et al., 2018).

A pharmacophore model is comprised of several characteristics that are arranged in a three-dimensional (3D) pattern. The characteristics can be labeled as a single feature or any logic combination consisting of “AND,” “OR,” and “NOT” ( Qing et al., 2014) to blend varied interaction patterns under a single label. Hydrogen bond donors (HBD), hydrogen bond acceptors (HBA), positive features, negative features, aromatic rings, hydrophobic features, and their combinations are all examples of molecular pharmacophore patterns ( Seidel et al., 2020). Different compounds can be compared at the pharmacophore level, known as “pharmacophore fingerprinting.” The pharmacophore is a “query” when only a few pharmacophore properties are analyzed in a 3D model ( Qing et al., 2014). Classification of 3D-QSAR is given in Supplementary Table S4. Pharmacophoric characteristics may be used as a query to search for possible leads from chemical compound databases and produce compounds with specific qualities (lead optimization) ( Qing et al., 2014; Kumar et al., 2018; Muhammed and Aki-Yalcin, 2021). It also uses pharmacophore fingerprints to determine the comparability and diversity of drugs. It may also align molecules based on their three-dimensional arrangement or create a predicted three-dimensional QSAR model ( Kumar et al., 2018). The webservers or databases for QSAR drug design research are given in Supplementary Table S1-3). A list of software used for calculating descriptors and fingerprints is presented in Supplementary Table S5, 6.

Pharmacophore modeling employs organized methods to construct a logical framework to identify other chemical moieties with similar properties against the disease’s target of interest. The steps are as i) ligand synthesis, ii) mapping of pharmacophore features, iii) looking for a common pharmacophore, and iv) calculating the shared pharmacophore score ( Kumar et al., 2018). A pharmacophore can be used to screen new target-specific agonists and antagonists, toxicants, undiscovered targets, and the best molecular docking findings. A pharmacophore model is often used in virtual screens to locate medications that trigger the required biological activity (Yang, 2010; Muhammed and Aki-Yalcin, 2021), as well as fishing drug targets, ligand profiling, docking, and ADMET (absorption, distribution, metabolism, excretion, and toxicity) prediction ( Leach et al., 2010; Yang, 2010; Qing et al., 2014; Muhammed and Aki-Yalcin, 2021).

A framework of Pharmacophore architecture.

## Section: The significance of QSAR › An overview of the importance of molecular docking

The most extensively used strategy for structure-based drug development is molecular docking, which has been around since the early 1980s ( Meng et al., 2012). Molecular docking provides an attractive framework for studying drug biomolecular interactions, which is useful for rational drug design and discovery Dar and Mir, 2017). The molecular docking approach may be used to model an atomic-level interaction between a small molecule and a protein, allowing us to characterize small molecule behavior at target protein binding sites and highlight key biochemical processes ( Meng et al., 2012; Aspatwar et al., 2019) (Figure 7) (Ferreira et al., 2015).

When the target protein’s 3D structure is available, molecular docking is one of the most commonly used virtual screening approaches. It is possible to predict both the affinity of the ligand for a protein and the structure of the protein-ligand complex by using this technique, both of which are vital to lead optimization ( Wang and Zhu, 2016). Molecular docking aims to predict the structure of the ligand-receptor complex using computational methods. Docking is accomplished in two steps: sampling ligand conformations in the protein’s active site and then utilizing a scoring function to rate these conformations (Meng et al., 2012; Ferreira et al., 2015). A complete list of docking and ADME software are enlisted in Supplementary Table S9 (Meng et al., 2012; Singla et al., 2013; Ferreira et al., 2015; Dar and Mir, 2017; Kumar et al., 2018; Zhang et al., 2022) Supplementary Table S10 (Singla et al., 2013), respectively.

Schematic presentation of covalent docking.

## Section: The significance of QSAR › Discovery of covalent and noncovalent anti-tuberculosis drugs using molecular docking techniques

Covalent inhibition is a method for obtaining irreversible inhibition. Because covalent inhibitors may target proteins with shallow binding cleavage, new inhibitors with better efficacy than non-covalent inhibitors can be developed. Covalent molecular docking has recently been used in computer-aided drug design processes to characterize covalent interactions between inhibitors and biological targets. Several computational approaches for modeling covalent interactions have been developed. Autodock, Autodock Vina, GOLD, and FlexX are the most popular docking tools and software.

On the other hand, these and other similar methods primarily focus on non-covalent interactions (van der Waals interactions, electrostatic interactions, and hydrogen bonding) or the use of alternative empirical or knowledge-based scoring functions to characterize these non-covalent interactions ( Kumalo et al., 2015). Non-covalent interactions (van der Waals interaction, electrostatic interaction, and hydrogen bonding, for example,) or alternative empirical or knowledge-based scoring functions to characterize these non-covalent interactions are mainly used in these and other analogous methodologies. However, not all medications attach non-covalently to the active site; other compounds, such as covalent drugs (Singh et al., 2011), bind covalently. The workflow of covalent docking is represented in Figure 8 (Kumalo et al., 2015).

Many techniques have been developed to achieve the covalent docking of inhibitors to target proteins. However, most covalent docking methods can only predict the binding energy between an electrophilic ligand and a nucleophilic receptor. Popular is the “link atom” approach. The software defines a “link atom” in the ligand and the protein in this strategy. The ligand link atom must occupy the same steric volume as the protein link atom to mimic the covalent binding process. The Gold molecular docking program ( Hartshorn et al., 2007) implements this strategy. Autodock, another widely used molecular docking program, uses a “grid-based technique” and a “modification of the flexible side chain” approach to covalently dock inhibitors to receptors. The covalently linked ligand and the protein attachment are sampled as part of the receptor as a single flexible side chain in a flexible side chain. A Gaussian biassing function focused on the protein attachment atom, and grid-based energy is used in the grid-based approach to bias the covalent bonding ligand posture ( Kumalo et al., 2015).

Katritch et al., 2007, used covalent docking and homology modeling to create a detailed structural model of the ubiquitin-like poxvirus proteinase (ULP) I7L substrate-binding site (S2–S2′). The 3D model of the I7L ligand-binding site was utilized to perform covalent docking and virtual screening of a comprehensive library of around 230,000 accessible ketone and aldehyde compounds to uncover novel smallpox antiviral hits. Out of 456 predicted ligands, 97 inhibitors of I7L proteinase activity were found to be active in biochemical studies (20 percent overall hit rate) ( Katritch et al., 2007). In their study, Wang et al. employed covalent and three-dimensional QSAR modeling to investigate the intermolecular interactions of isatin sulfonamide analogs as caspase-3 inhibitors (Wang and Zhu, 2016). Fifty-nine isatin sulfonamide analogs were docked to the binding site of human caspase-3. The docking research showed the inhibitors’ binding mechanism. A 3D-QSAR approach further supplements docking analysis by offering a “custom” scoring function for the protein under research, capable of predicting bioactivities for ligands comparable to those in the training sets. Structure-based design methodologies (such as docking) were shown to aid in constructing trustworthy QSAR models.

Ma et al. developed and covalently docked a novel family of peptide aldehyde derivatives to increase hydrophobic interactions with a bulky P3 moiety. Covalent docking was used to predict the exchange of the peptide aldehyde compounds with the 20S. The P3-position alterations are crucial for inhibitor efficacy. The docking behavior is similar to that of the crystal complex previously described. The hypothesized binding method might be leveraged to generate more potent 20S proteasome inhibitors ( Ma et al., 2011). A bicyclic class of covalent inhibitors was synthesized by Lawandi et al. to study the optimal shape required to target propyl oligopeptidase (POP) and heal human brain disorders. We hypothesized that these structures could bind covalently to the enzyme’s catalytic serine because they contain nitrile functional groups. From the covalent docking study, two compounds were chosen for production and biological testing. The study unveiled the presence of a potent, remarkably selective, and cell-permeable inhibitor for POP.

Furthermore, docking tests (using the FITTED docking engine and default parameters) demonstrated that the stereogenic center’s arrangement at the ring junction is a limiting factor for optimum activity, which may be used to guide future studies ( Lawandi et al., 2009). Saikia et al. study delve into the intriguing interaction between the antitubercular drug isoniazid (INH) and pristine and Si-doped and single-walled carbon nanotubes (SWNTs) (Saikia et al., 2016). The incorporation of silicon dopants significantly enhances the adsorption of INH onto the relatively inert nanotubes, as evidenced by profound alterations in adsorption energies, charge transfer phenomena, and global reactivity descriptor values. Notably, the study highlights noncovalent functionalization’s efficiency and mobility advantages over covalent counterparts, particularly in facilitating INH movement along the nanotube sidewall. Interestingly, parallel adsorption configurations manifest heightened charge transfer dynamics compared to the perpendicular adsorption orientation. The theoretical investigation posits single-wall carbon nanotubes as promising nano vectors for PZA (pyrazinamide) drug delivery, with covalent functionalization via sidewall and edge attachment, presenting a viable strategy. The study’s findings pave the way for further exploration, aiming to unravel the intricacies of therapeutic release from functionalized SWCNTs, ultimately enriching the landscape of future biomedical applications (Saikia et al., 2013). The list of software used is given in Supplementary Table S11 (Singla et al., 2013).

An overview of the docking process for molecules. (A) The ligand’s three-dimensional structure; (B) the 3D structure of the receptor; (C) The ligand is docked into the receptor’s binding cavity, and potential conformations are investigated.; (D) The detected intermolecular interactions and the most plausible binding conformation.

## Section: The significance of QSAR › Post docking simulation studies for tuberculosis drug discovery

Molecular dynamics (MD) are more computationally demanding and sophisticated than simulations of other biomolecules. A collection of biomolecule conformations with distinct initial and boundary conditions can be generated by iteratively integrating (numerically) the equations of motion for specific potential simulations ( Kumar et al., 2018). A structural ensemble derived from an MD simulation is used to explore the conformational space of biomolecules, measure thermodynamic variables, and predict the free energy of biological processes. In calculations involving free energy binding, which encompasses a wide range of accuracies and processing needs, many people have tried the MD method to forecast the strength of non-bonded interactions. A very vital technique for the theoretical and computational studies of biomolecules is molecular dynamics simulation (MDS) ( Huang et al., 2010). Examining molecular systems is exceedingly tricky since they usually comprise many particles. Using numerical approaches in molecular dynamics simulation can avoid this analytical intractability. The atoms and molecules may briefly interact while the simulation is running. Each atom’s motion is calculated, and the overall behavior may be checked. It offers numerous advantages over docking because docking merely provides the ligand’s binding free energy among the receptor. MDS can also be used to predict the ligand’s actual interaction with receptors at the atomic level ( Ferreira et al., 2015; Kumar et al., 2018).

Root means square deviation (RMSD) is applied in MDS to forecast receptor or ligand-receptor complexes for their stability and to explain conformational changes. An alternate conformational state consequently to such ligand-induced structure can be generated using MD simulations ( Khan et al., 2016). The projected ligand-receptor complex can be termed unstable if the A-matched docking solution and the ligand conformation produced by MD are different by more than a particular RMSD value ( Kumar et al., 2018). Coupled docking and MD approaches have been widely used to identify new therapeutic drugs from natural compounds and optimize the more recent lead candidate obtained from the natural compound ( De Vivo et al., 2016). MD is also applicable to produce a section of convenient docking structure, mainly when none of the acceptable crystallographic structures for the specific molecular target are offered ( Harvey and De Fabritis, 2012). MD simulations paired with molecular mechanics/Poisson-Boltzmann surface area (MM/PBSA) approaches can provide precise information on drug-target interaction binding effectiveness. This method has also been used to test the inhibitory efficacy of natural chemicals against various protein targets ( Good, 2006).

Using the MD simulation approach, various ways are available to examine atomic-level alterations in biomolecules (Khan et al., 2016 ). Some, like Desmond, have a graphical user interface, while others, like GROMACS and AMBER, run via command lines. GROMACS (AMBER), Nanoscale MD (NAMD), and (CHARMM-GUI) are some well-known and commonly used MD simulation programs. The rise in software and hardware powers is crucial for executing such MD simulations ( Kumar et al., 2018).

It is a popular method for researching biologically known systems. It is also employed in various domains, including the Prediction of protein-ligand combination stability, protein mutation analysis, conformational protein stability prediction, and protein unfolding investigations. It is a powerful instrument demanding much computing power to solve biological puzzles ( Hansoon et al., 2002; Hospital et al., 2015).

## Section: The significance of QSAR › Molecules discovered by QSAR, pharmacophore modeling, and molecular docking for tuberculosis

A QSAR study was conducted on thirty-four 8-methyl quinolones by Eric et al. to determine their anti-tuberculosis activity. Picking descriptors and building association models relating to structural characteristics of biological activity was done using the genetic algorithm (GA) and multiple linear regression analysis (MLRA). The 3D structure of all compounds was constructed using the SPARTAN “14 v 1.1.0 tool. PADEL software for calculating molecular descriptors of all 34 compounds. The Build QSAR application was used to analyze geometric algorithms and build QSAR models. The internal validation was performed using the cross-validation leave-one-out technique, and external validation was performed by utilizing them to forecast the action of test sets. An examination of the robustness of the QSAR design was also conducted. The GA-MLRA method was used to construct a robust QSAR model to predict the inhibitory action of some quinolones. The results of this study (R 2 Pred = 0.7393) imply that for novel 8-methyl quinoline analogs, the pMIC can be calculated using the QSAR model that comes under the model’s applicability domain before synthesizing them (Eric et al., 2016). It applied various computational methodologies to the 2,4-diamino quinazoline moiety to assess its efficacy in tuberculosis between diverse biological functions (Bose et al., 2019). V-Life MDS software was used to study all QSAR studies. Merck molecular force field was used to get 3D structures from 2D QSAR. In 3D QSAR, conformers were created using the conformational Monte Carlo technique, and the conformers with the lowest energy were chosen to align. The pharmacophore identification investigations were performed in the V-life MDS 4.4 Mol sign module to associate geometrical representation of the properties required for the molecule to show activation. The docking investigation was conducted using GOLD software. Thirty-three molecules were docked with four distinct protein molecules, significant for anti-TB action and crystalline protein structure. The new molecular set was designed depending on the pharmacophore results of docking studies and QSAR. After designing, the new molecule set was optimized, and using Monte Carlo conformation search conformers were generated. The 2,4-diamino quinazolines scaffold is promising for development as a molecular lead set for lead optimization, according to the findings of this study. According to the QSAR study, better moieties require a perfect distribution of steric potential and hydrophobicity in the molecular system. Pharmacophore mapping depends on the quinazoline ring’s 1 and 3 nitrogen atoms, the 4-amino phenolates molecule at location 4, the benzene ring, and the electronegative fluorine replacement. According to QSAR and pharmacophore mapping data, replacing the piperidine ring at the 2-amino position and the 4-amino phenolate group over the 4-amino position is the main necessity, as evidenced by the design and assessment of the activity using a 3D QSAR model. All of the features assessed and assumed to represent an active moiety were included in the final molecule ( Bose et al., 2019). Bhardwaj et al. explored the binding affinity of 70 novel piperine analogs and reported the activity of 23 compounds against Mycobacterium tuberculosis. The antitubercular effects of verapamil analogs, which are derivatives of dimethoxy phenyl rings bound to carbon chains, are significant. However, piperine, which also has a methylenedioxyphenyl ring attached to a carbon chain, is found to be a structural requirement for its activity. The similar action of these two compounds was correlated using in silico approaches. Using DRAGON and Chem office software, descriptors were calculated in QSAR studies. The QSAR models were generated by performing MLRA (Multiple Linear Regression Analysis) analysis using CODESSA®. The structures of the compounds were sketched and optimized using Chem Sketch software. Schrodinger, 2016–1’s GLIDE module investigated drug-receptor interactions and designed new compounds. www.rcsb.org provided the protein structure (3C3W), or the Protein Prep Wizard module was used to make the protein. The binding cavity within the protein was determined using site mapping, which will be utilized in future studies. Using a 2D sketcher, the structure of the ligands was created and optimized. For energy optimization, PLS3 was employed. It was concluded from QSAR and molecular docking studies that the binding energies range of predicted products with one hydrogen bond to five hydrogen bonds was higher than reported compounds with one hydrogen bond to four hydrogen bonds. Compared to reference medications, some predicted molecules have shown good binding affinity. As the docking scores are comparable, we may conclude that the QSAR models created are good, and these are applied for forecasting the anti-TB activity of novel drugs ( Bhardwaj and Dubey, 2017). The findings from the study underscore the power of integrating diverse computational strategies in the pursuit of anti-tubercular drug discovery. The combination of molecular docking, DFT calculations, reactivity descriptors, QSAR modeling, ADMET evaluation, and molecular dynamics simulations presents a formidable approach to expedite the identification of promising drug candidates (Stanzione et al., 2021). Ultimately, these advances contribute significantly to the ongoing battle against TB, offering hope for developing more effective treatments in the near future (Rajkhowa and Deka, 2013; Rajkhowa et al., 2015). A list of products discovered for tuberculosis is presented in Table 1. A list of the drugs (Table 2) in a clinical trial is discovered with the help of these approaches (Ahamad et al., 2017).

List of some compounds discovered to target tuberculosis bacteria by using approaches of QSAR, pharmacophore modeling, and molecular docking.

A list of the drugs that are in a clinical trial is discovered with the help of these approaches.

## Section: The significance of QSAR › The challenges and prospects of QSAR, pharmacophore modeling, and docking of molecules › QSAR challenges and prospects

The chemical descriptors used as input for the QSAR model vary throughout most QSAR research. The quality to predict traditional QSAR approaches reduces when new substituent group traits depart further from the training set. Some of the challenges associated with 3D QSAR are ligand geometry which is essential for computing geometric descriptors and crucial for 3D QSAR. QSAR data sets may contain many chemicals (>100,000) and descriptors. There is a requirement to maintain many models (e.g., dozens) for a variety of targets; these models should be updated regularly (e.g., monthly) (Winkler, 2002; Cherkasov et al., 2014; Saikia and Bordoloi, 2019). Failure to take data heterogeneity into account, unsuitable endpoint units used, confounded and non-interpretable descriptors being used, descriptor value errors, QSARs having a low transferability, applicability domain is insufficient or undefined, omission of data points that are unnoticed, data that is insufficient, chemicals in a data set are replicated, endpoint values within a narrow range, data that has been over-fitted, in a QSAR, using an excessive number of descriptors, Statistics that are insufficient or missing are also misused and misrepresented, incorrect calculation, the complexity of the data set, validation of QSAR models, establishing the models’ scope of application in the chemical space ( Aparoy et al., 2012; Ma et al., 2015)

Significant-scale QSAR research is possible due to large data and processing resources. Graphic processing units, Cloud technology, and servers are very known and have been used in computer-aided drug design and discovery streams ( Aleksandrov and Myllykallio, 2019). The system pharmacology method has gained popularity among scientists due to its ability to conduct pharmacodynamic assessments, discover new targets, and provide a systems-level understanding of drug-disease interactions ( Maltarollo et al., 2017). Combining QSAR with machine learning methods enhances prediction power and is needed for the future development of QSAR ( Sabitov et al., 2017).

## Section: The significance of QSAR › The challenges and prospects of QSAR, pharmacophore modeling, and docking of molecules › Pharmacophore modeling: Challenges and prospects

The pharmacophore approach still faces numerous roadblocks that limit its ability to reach its full potential, especially given the current high Costs involved in medication discovery and development. The following are some of the challenges: The challenge associated with ligand-based pharmacophore modeling is the modeling of ligand flexibility. The second difficulty encountered when adopting the ligand-based strategy is molecular alignment. Screening massive chemical databases with flexible compounds, a fundamental problem in pharmacophore-based VS., could take quite a long time. In many cases, the most challenging issue with pharmacophore-based VS. is that a minor quantity of simulated hits is genuinely bioactive ( Leach et al., 2010; Qing et al., 2014). The absence of a good scoring function in virtual screening by pharmacophore is also one of the challenges faced while using pharmacophore-based virtual screening. A pre-computed conformation database is necessary for a pharmaceutical-based virtual screening which is also a challenge in its application ( Qing et al., 2014). The de novo design using the pharmacophore-based program new LEAD has the limitation that new LEAD can only handle pharmacophore properties that are concrete functional groups rather than abstract chemical features (Leach et al., 2010; Yang, 2010). The correct selection of the training set molecules is also a difficult task. Another drawback is the lack of a clear approach to generating a pharmacophore query. Finding different conformations for each ligand is also challenging using the pharmacophore model. Another significant drawback is that the pharmacophore confirmation may not be a ligand active form based on free energy. Every ligand-based pharmacophore carries this risk (Seidel et al., 2020; Muhammed and Aki, 2021).

A combination of pharmacophore modeling and other computational techniques is needed to overcome some of the limitations of pharmacophore modeling and stay on top of recent discoveries ( Qing et al., 2014). As a result, pharmacophore modeling has been combined using molecular mechanics simulations. This might help to increase some of the difficulties associated with ligand flexibility modeling. Another issue noted is the absence of good scoring functions utilized in virtual screening by pharmacophores. Machine learning, which has been utilized in various computational ways, can be used to improve such scoring functions. As a result of recent improvements in pharmacophore modeling, structure-based models can now be produced with enhanced properties (Yang, 2010; Kumar et al., 2018; Muhammed and Aki-Yalcin, 2021).

## Section: The significance of QSAR › The challenges and prospects of QSAR, pharmacophore modeling, and docking of molecules › The challenges and future of molecular docking

The market for drug discovery informatics is expected to rise from 1.5 billion dollars in 2016 to 2.84 billion dollars in 2022, and it may continue to grow. As a result, there is a growing demand for innovative informatics solutions development and implementation. Moving from pure research to clinical therapy is one of the primary drivers driving the growth of the worldwide market. More qualified individuals, multidisciplinary backgrounds, and the high cost of informatics software might significantly influence the market’s growth. Several well-known programs have recently been made accessible as free or paid software or services. It will take a considerable amount of time, effort, and resources to fully exploit the potential of this robust approach (Meng et al., 2012; Akhter, 2016; Wang and Zhu, 2016; Dar and Mir, 2017; Kumar et al., 2018; Lambrinidis and Tsantli, 2018; Prieto-Martínez et al., 2018).

Here are some of the difficulties that come with molecular docking. Choosing optimal methods, tools, and parameters in molecular docking is difficult ( Naveja and Medina, 2019). Molecular docking methods generally neglect solvent influence, entropic effects, and polarization for binding ligands. Experimental scoring formulas have been developed to overcome such obstacles ( Ganesan, 2008; Benet et al., 2016). Receptor flexibility is a significant challenge in molecular docking. Docking had another issue with the scoring function’s imperfection. When docking molecules, keeping track of their numerous tautomeric and protomeric states can be challenging (Benet et al., 2016). Evaluating molecular docking results without considering the receptor structure’s quality is also difficult. Protein flexibility is also an important point to be considered, as ligand binding to protein produces conformation changes in protein, hence ignoring protein flexibility may produce incorrect results during molecular docking. Handling flexible protein receptors is a major challenge during molecular docking ( Eldridge et al., 1997; Allouche, 2012).

The development of Local Move Monte Carlo (LMMC) based molecular docking in the future, where A sample that considers the backend loops in addition to the main chain in the ligand binding of proteins and flexible ligands may be a workable solution to the flexible receptor docking issue. Docking applications could be propelled to the next level by accurate and low-cost scoring techniques ( Ganesan, 2008; Benet et al., 2016). For continued progress, the molecular structure databases must be improved. Filters must ensure that the structural models inside them are of higher quality, as this will affect the findings’ dependability. In 1971 the protein data bank (PDB) was created as a pioneer crystal structure database. It is now the most widely used molecular in silico modeling resource, with over 150,000 experimentally validated 3D models. However, even with acceptable geometrical parameters, there is no assurance that the selected structures are error-free, which must be considered. The presence of high-quality statistics does not imply that the structure is flawless. As a result, improving their quality, procedures, and validation would allow better models to be built, which would be helpful in the inevitable process of structural refinement.

On the other hand, a better model will not be more instructive in terms of more complex biological information, necessitating a scientist’s interpretation ( Lambrinidis and Tsantli, 2018). Despite this, the accuracy of the docking tool and the validity of the results can be evaluated. Although docking procedures have gotten more complicated, false positives are still a problem with this methodology; refining the PDB structures would surely enhance pharmacodynamics research and yield better findings.

## Section: Conclusion

QSAR models can be used during drug development research and development stages to develop pharmacodynamic and pharmacokinetic profiles. These in silico investigations predict numerous characteristics and actions that aid in optimizing and prioritizing drug molecules. Computational approaches have resulted in lead structures and novel drug targets, which have sped up drug development. The computational technique may find pharmacological leads and targets against them, as well as attraction and effectiveness between them, before the start of clinical trials; it saves time and money. The QSAR is a commonly used statistical method that links a molecule’s structure to its physiological action meant for a function of molecular descriptors. Hence, it plays a vital role in drug development. Pharmacophore is essential for a compound’s biological action. It aids in de novo design, important characteristics, and high-throughput screening in drug development. In addition to their many applications in the examination of specific molecular activities, structure-based virtual screening (SBVS) molecular dynamics (MD), bounding energy, molecular interactions, molecular docking, and structure-based virtual screening (SBVS) are some of the most popular strategies used in structure-based drug discovery (SBDD). The review article concluded that such techniques will reduce traditional resource requirements by increasing prediction based on current information and limiting and focusing on chemical production and biological testing.


---

# New avenues in artificial-intelligence-assisted drug discovery

- **Authors:** Carmen Cerchia, Antonio Lavecchia
- **Issuer:** Drug discovery today
- **Type:** Scientific article
- **Published:** 2023-02-02
- **Language:** en
- **DOI:** 10.1016/j.drudis.2023.103516
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36736583/
- **Licence:** CC-BY

## Section: Abstract

Over the past decade, the amount of biomedical data available has grown at unprecedented rates. Increased automation technology and larger data volumes have encouraged the use of machine learning (ML) or artificial intelligence (AI) techniques for mining such data and extracting useful patterns. Because the identification of chemical entities with desired biological activity is a crucial task in drug discovery, AI technologies have the potential to accelerate this process and support decision making. In addition, the advent of deep learning (DL) has shown great promise in addressing diverse problems in drug discovery, such as de novo molecular design. Herein, we will appraise the current state-of-the-art in AI-assisted drug discovery, discussing the recent applications covering generative models for chemical structure generation, scoring functions to improve binding affinity and pose prediction, and molecular dynamics to assist in the parametrization, featurization and generalization tasks. Finally, we will discuss current hurdles and the strategies to overcome them, as well as potential future directions.
