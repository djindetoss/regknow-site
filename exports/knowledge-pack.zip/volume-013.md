# Artificial intelligence in multi-objective drug design

- **Authors:** Sohvi Luukkonen, Helle W van den Maagdenberg, Michael T M Emmerich, Gerard J P van Westen
- **Issuer:** Current opinion in structural biology
- **Type:** Scientific article
- **Published:** 2023-02-10
- **Language:** en
- **DOI:** 10.1016/j.sbi.2023.102537
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36774727/
- **Licence:** CC-BY

## Section: Abstract

The factors determining a drug's success are manifold, making de novo drug design an inherently multi-objective optimisation (MOO) problem. With the advent of machine learning and optimisation methods, the field of multi-objective compound design has seen a rapid increase in developments and applications. Population-based metaheuris-tics and deep reinforcement learning are the most commonly used artificial intelligence methods in the field, but recently conditional learning methods are gaining popularity. The former approaches are coupled with a MOO strat-egy which is most commonly an aggregation function, but Pareto-based strategies are widespread too. Besides these and conditional learning, various innovative approaches to tackle MOO in drug design have been proposed. Here we provide a brief overview of the field and the latest innovations.


---

# Artificial Intelligence, Machine Learning, and Big Data for Ebola Virus Drug Discovery

- **Authors:** Samuel K Kwofie, Joseph Adams, Emmanuel Broni, Kweku S Enninful, Clement Agoni, Mahmoud E S Soliman, Michael D Wilson
- **Issuer:** Pharmaceuticals (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2023-02-21
- **Language:** en
- **DOI:** 10.3390/ph16030332
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36986432/
- **Licence:** CC-BY

## Page 1 (Section: Introduction )

Citation: Kwoﬁe, S.K.; Adams, J.;
Broni, E.; Enninful, K.S.; Agoni, C.;
Soliman, M.E.S.; Wilson, M.D.
Artiﬁcial Intelligence, Machine
Learning, and Big Data for Ebola
Virus Drug Discovery.
Pharmaceuticals 2023, 16, 332.
https://doi.org/10.3390/
ph16030332
Academic Editor: Osvaldo
Andrade Santos-Filho
Received: 26 December 2022
Revised: 30 January 2023
Accepted: 3 February 2023
Published: 21 February 2023
Copyright:
© 2023 by the authors.
Licensee MDPI, Basel, Switzerland.
This article is an open access article
distributed
under
the
terms
and
conditions of the Creative Commons
Attribution (CC BY) license (https://
creativecommons.org/licenses/by/
4.0/).
pharmaceuticals
Perspective
Artiﬁcial Intelligence, Machine Learning, and Big Data for
Ebola Virus Drug Discovery
Samuel K. Kwoﬁe 1,2,*
, Joseph Adams 3, Emmanuel Broni 1,3,4
, Kweku S. Enninful 3,5
, Clement Agoni 6,7
,
Mahmoud E. S. Soliman 6 and Michael D. Wilson 3,4
1
Department of Biomedical Engineering, School of Engineering Sciences, College of Basic and Applied
Sciences, University of Ghana, Accra P.O. Box LG 77, Ghana
2
West African Centre for Cell Biology of Infectious Pathogens, Department of Biochemistry, Cell and Molecular
Biology, University of Ghana, Accra P.O. Box LG 54, Ghana
3
Department of Parasitology, Noguchi Memorial Institute for Medical Research, University of Ghana,
Accra P.O. Box LG 581, Ghana
4
Department of Medicine, Loyola University Medical Center, Maywood, IL 60153, USA
5
Department of Biomedical Engineering, McKelvey School of Engineering, Washington University in St. Louis,
St. Louis, MO 63105, USA
6
Discipline of Pharmaceutical Sciences, School of Health Sciences, University of KwaZulu-Natal,
Westville Campus, Durban 4001, South Africa
7
Conway Institute of Biomolecular and Biomedical Research, School of Medicine, University College of Dublin,
D04 V1W8 Dublin 4, Ireland
*
Correspondence: skkwoﬁe@ug.edu.gh; Tel.: +233-20-3797922
Abstract: The effect of Ebola virus disease (EVD) is fatal and devastating, necessitating several
efforts to identify potent biotherapeutic molecules. This review seeks to provide perspectives on
complementing existing work on Ebola virus (EBOV) by discussing the role of machine learning (ML)
techniques in the prediction of small molecule inhibitors of EBOV. Different ML algorithms have been
used to predict anti-EBOV compounds, including Bayesian, support vector machine, and random
forest algorithms, which present strong models with credible outcomes. The use of deep learning
models for predicting anti-EBOV molecules is underutilized; therefore, we discuss how such models
could be leveraged to develop fast, efﬁcient, robust, and novel algorithms to aid in the discovery
of anti-EBOV drugs. We further discuss the deep neural network as a plausible ML algorithm for
predicting anti-EBOV compounds. We also summarize the plethora of data sources necessary for
ML predictions in the form of systematic and comprehensive high-dimensional data. With ongoing
efforts to eradicate EVD, the application of artiﬁcial intelligence-based ML to EBOV drug discovery
research can promote data-driven decision making and may help to reduce the high attrition rates of
compounds in the drug development pipeline.
Keywords: drug discovery; deep learning; artiﬁcial intelligence; big data; Ebola virus; classiﬁers;
machine learning
1. Introduction
Since the emergence of Ebola virus disease (EVD), concerted efforts have been em-
ployed in the quest to identify inhibitors as potential biotherapeutic molecules. EVD is a
deadly zoonotic disease caused by the Ebola virus from the ﬁloviridae family [1]. Although
the exact source of EBOV remains unknown, it believed to be animal-borne and associated
with monkeys, chimpanzees, and apes, including humans [2]. EBOV is transmitted from
human to human via direct contact or contact with the body ﬂuid of an infected person [3].
A person infected with EVD shows symptoms of fever, aches, and pains such as severe
headache; gastrointestinal symptoms, including diarrhea and vomiting; and multiple organ
dysfunction syndromes [4]. The Ebola virus (EBOV) is an enveloped, single-stranded,
negative-sense RNA virus [5]. It forms a threadlike shape, with a uniform diameter of
Pharmaceuticals 2023, 16, 332. https://doi.org/10.3390/ph16030332
https://www.mdpi.com/journal/pharmaceuticals

## Page 2 (Section: Introduction )

Pharmaceuticals 2023, 16, 332
2 of 12
80 nm and a typical length between 970 nm and 1200 nm [6]. The genome of EBOV
encodes seven structural proteins comprising nucleoprotein (NP), polymerase cofactor
(VP35), Virion matrix protein (VP40), Glycoprotein, transcription activator (VP30), VP24,
and RNA-dependent RNA-polymerase (L) [7].
A total of 33,604 Ebola virus infections in humans were recorded, with an average
death rate of 43.8%, constituting more than 14,000 deaths, during the 2014–2016 outbreak
in Guinea, Liberia, and Sierra Leone, as well as the 2018–2020 outbreak in Congo [3]. There
is a re-emergence of the outbreak in Guinea and the Democratic Republic of Congo [8].
The highly virulent and lethal nature of EVD highlights the need to develop therapeutic
agents that could limit the spread of the virus. This had led to several efforts to prioritize
compounds in the search for small molecule inhibitors of the Ebola virus [9].
Currently, there are two Food and Drug Administration (FDA)-approved treatments
for the Ebola virus. The ﬁrst, Inmazeb, is a mixture of three monoclonal antibodies that
targets the glycoprotein of the Ebola virus and blocks attachment and entry of the virus [10].
The second is a human monoclonal antibody, Ebanga, which blocks the binding of the virus
to the cell receptor [11]. Nonetheless, several EVD drug discovery studies are underway.
The advancement in large-scale biological experiments and data collection initiatives
has spurred in silico studies geared towards the identiﬁcation of small molecule inhibitors
of disease targets [12]. Big data describes a voluminous amount of data that can be
analyzed computationally to unravel trends and patterns [13,14]. Big data-driven drug
development was employed in drug repurposing of FDA-approved drugs against other
disease targets [12,15,16]. Other advanced applications of big data include the integration of
gene expression analysis, cellular screening systems, and healthcare informatics to identify
chemical structures of therapeutic relevance [17].
With the growth of chemical data from high-throughput screening for a target of
interest, the search for a small molecule to interact with these targets is essential. Artiﬁcial
intelligence (AI) and machine learning approaches provide a faster alternative to categorize
compounds that possess therapeutic indications [18–20]. Big data has therefore heavily
inﬂuenced the recent drug discovery paradigm. This article discusses perspectives on the
role that AI plays in the identiﬁcation of small molecule inhibitors and ML approaches
utilized in the search for small molecule inhibitors of EVD. Furthermore, it highlights
large-scale databases containing multitudes of bioactive compounds that could be utilized
to train machine learning models. It also shows how novel ML techniques such as deep
neural networks could be leveraged to develop efﬁcient and robust models to prioritize
compounds with high propensity to possess anti-Ebola virus activity.
Drug discovery and development are time-consuming and expensive, with numerous
compounds failing at various stages during clinical trials [21,22]. AI and ML approaches
applied to various stages of the drug development pipeline provide data-driven decision
making and can reduce the timeline for drug development via predictions [18,23]. These
predictions are faster and cheaper than wet laboratory experiments, which are laborious.
AI approaches in drug discovery result in generating potential lead-like ligands for drug
targets, and when predictions are based on suitable data, the likelihood of potent thera-
peutic compounds going into clinical trial stages increases [24]. ML is any technique that
makes computers learn from previous data observations and improve their behavior for a
given task [25]. ML models change their inputs into meaningful outputs, a process that is
learned from exposure to known examples of input and output data. ML is categorized
into three, namely supervised, unsupervised, and reinforcement learning [26]. Numerous
ML algorithms have been exploited in the paradigm of drug discovery. The use of ML in
drug discovery addresses the issue of drug candidate identiﬁcation via the prediction of
drug–target interactions [27]. More so, molecules emanating from de novo design generate
chemical structures with desirable characteristics, which are leveraged computationally for
the synthesis of novel molecules [28].

## Page 3 (Section: Machine Learning Algorithms Deployed in Ebola Virus Drug Discovery )

Pharmaceuticals 2023, 16, 332
3 of 12
2. Machine Learning Algorithms Deployed in Ebola Virus Drug Discovery
ML algorithms are key determinants of the effectiveness and efﬁciency of ML in drug
discovery. As such, employing an appropriate learning algorithm that is suitable for the
respective application is prudent. Notable algorithms include artiﬁcial neural networks
(ANN) [29,30], decision trees (DT) [31,32], support vector machines (SVM) [33], and cluster
analysis (CA) [34–36].
Several reports have thus employed some of these algorithms in EBOV drug dis-
covery. One of such earlier reports was a study by Erkins et al. in 2015, in which two
different anti-EBOV-predicting Bayesian ML models were trained [9] on two groups of
datasets comprising the viral pseudotype entry and the EBOV replication assays, with
both constituting 868 compounds [37]. The trained models were then used to screen the
MicroSource (http://www.msdiscovery.com/spectrum.html) (accessed on 26 January 2023)
library of drugs to predict potential anti-EBOV compounds. For each of the training assay
data, molecules with IC50 values < 50 µM were classiﬁed as actives and all others were
considered inactive. The half-maximal inhibitory concentration (IC50) is a quantitative
measure that shows how much of a particular inhibitory substance is required to inhibit a
particular biological process by half, thus providing a measure of the drug’s efﬁcacy [38].
The Bayesian model was trained on this dataset together with two other ML algorithms
comprising SVM and Recursive Partitioning Forest using a 5-fold cross-validation tech-
nique. The Bayesian model performed the best, with a receiver operating characteristic
(ROC) value of 0.86. The MicroSource library with 2320 drugs was scored with the trained
Bayesian model, predicting tilorone, quinacrine, and pyronaridine tetraphosphate as po-
tential anti-EBOV drugs. Tilorone, quinacrine, and pyronaridine tetraphosphate which
had the highest scores from the ML predictions were experimentally validated in vitro and
found to possess EC50 values of 350, 420, and 230 nM, respectively. These EC50 values were
much lower than the positive control, chloroquine, with EC50 value of 4.0 µM. [9]. EC50 is
a measure of the pharmacological effectiveness of a compound. It is the concentration of
a compound at which the biological response is half of the maximum response [39]. The
three compounds with lower EC50 values are able to achieve the same biological effect at
lower concentration, indicating that they are more effective.
Moreover, the Bayesian approach employed in the prediction of activity spectra of
substances [40] can be used to predict the antiviral activity of compounds to facilitate the
identiﬁcation of potentially bioactive molecules against the EBOV protein VP24 [41,42].
So far, the Bayesian, SVM, and recursive partitioning forest are the available algorithms
that have been used to develop models to predict potential anti-EBOV compounds. Other
machine learning algorithms, including single-layer artiﬁcial neural networks, decision
trees, and logistic regression, have also been applied to other ﬁelds of EVD other than pre-
dicting biotherapeutic compounds [43,44]. For instance, an ensemble of the aforementioned
algorithms was used to predict the disease prognosis and outcomes of EBOV patients with
appreciable levels of performance [44].
A more recent application of ML in EBOV drug discovery is the work by Rajput
and Kumar (2022) [45] in which SVM, random forest, and artiﬁcial neural networks were
employed using tenfold cross-validation (Table 1). In their report, the best predictive model
showed a Pearson’s correlation coefﬁcient ranging from 0.83 to 0.98 on training/testing
(T274) dataset. These models were subsequently cross-validated for robustness using
William’s plot, following which the models were integrated into a web server. Another
such recent application of ML in EBOV drug discovery is a report from our group (Table 1)
where predictive models developed using ﬁve algorithms comprising random forest (RF),
SVM, naïve Bayes (NB), k-nearest neighbor (kNN), and logistic regression were used to
predict potential anti-Ebola virus small molecule inhibitors of EBOV glycoprotein and
VP40 [46]. Our study employed EBOV cell entry inhibitors from the PubChem database
as training data, where RF, LR, and SVM models also showed plausible performances
with overall accuracy values of 0.89, 0.84, and 0.86, respectively. These three models were
implemented as a web server known as “EBOLApred” which assigns a conﬁdence score to

## Page 4 (Section: Limitations on the Use of Conventional ML Models to Predict Anti-EBOV Compounds )

Pharmaceuticals 2023, 16, 332
4 of 12
the predicted bioactivity validated using the applicability domain concept [46]. Collectively,
these reports highlight the crucial role of ML in EBOV drug discovery, leaving room for
further exploration.
Table 1. Machine learning algorithms employed anti-EBOV research work with their varying perfor-
mances. The models consisted of support vector machines (SVM), recursive partitioning forest (RPF),
random forest models (RF), artiﬁcial neural network (ANN), naïve Bayes models (NB) and k-nearest
neighbor models (kNN). Evaluation metrics included accuracy (ACC), Pearson correlation coefﬁcient
(PCC), mean absolute error (MAE), and root-mean-square error (RMSE).
Applications (URLs)
Model Used
ACC
PCC
MAE
RMSE
Anti-EBOV machine learning models [9]
(http://molsync.com/ebola/) (accessed on
26 January 2023)
Bayesian model
0.82–0.86
RPF
0.75–0.85
SVM
0.73–0.76
Anti-Ebola initiative [45]
(https://bioinfo.imtech.res.in/manojk/antiebola)
(accessed on 26 January 2023)
SVM
0.83
0.33
0.47
RF
0.98
0.19
0.28
ANN
0.95
0.23
0.29
EBOLApred [46]
(http://197.255.126.13:8000/) (accessed on
26 January 2023)
RF
0.80
SVM
0.86
NB
0.65
kNN
0.80
3. Limitations on the Use of Conventional ML Models to Predict Anti-EBOV Compounds
Conventional ML algorithms have certain drawbacks when used to predict Ebola
virus inhibitors. One signiﬁcant issue is the high dimensional data required to predict
inhibitors. The complexity of the data needed to predict inhibitors poses a challenge for
most conventional ML models to manage [47]. Another limitation is that predictive models
may not be able to generalize well to new data. These models are often trained on a limited
set of data and may not perform well when applied to new or unseen data [48]. This is
particularly problematic when dealing with diseases such as Ebola, where the amount
of data available may be limited. The risk of overﬁtting exists when using conventional
ML techniques to predict Ebola virus inhibitors. Even while these models may perform
well on training data, they have trouble generalizing to fresh data [49]. To overcome these
limitations, researchers may need to turn to more advanced machine learning techniques
such as deep learning, which have shown to be more effective in handling large and
complex data [50]. Additionally, the use of more diverse and comprehensive data sets can
also help to improve the accuracy of predictions. With the ongoing efforts to combat EVD, it
is crucial to continue to develop and improve predictive models to aid in the identiﬁcation
of potential drug candidates and management of the disease.
4. Deep Neural Network as an Efﬁcient and Robust Alternative to Predict
Anti-EBOV Compounds
Deep learning has become the most dominant component of ML and an emerging
technique for accelerating the prediction of small molecules of therapeutic relevance [51–54].
Deep learning algorithms are classic models in pattern recognition tasks, and due to their
robustness, good performance, and simple form, they are widely used in solving nonlinear
classiﬁcation problems [55,56]. In a comparative study of various screening methods on the
ChEMBL database as the benchmark, deep learning outperformed the other seven screening
methods for the mean area under the curve (AUC) across 1230 drug targets [48]. The AUC
of deep learning (0.830) surpassed the threshold of 0.8 for commercial models used for
virtual screening of compounds, thus having the potential to become a standard method in
drug design [52]. Another comparative study corroborated the efﬁciency of the deep neural

## Page 5 (Section: Limitations on the Use of Conventional ML Models to Predict Anti-EBOV Compounds )

Pharmaceuticals 2023, 16, 332
5 of 12
network (DNN) over other ML methods, including support vector machines, random
forests, naïve Bayes, and logistic regression models [57]. The superiority of DNN was
further demonstrated in a report by Wallach et al. in 2015, in which AtomNet, a structure-
based bioactivity prediction for small molecules, was built using a deep convolutional
neural network and was shown to outperform Smina [58]. AtomNet was even shown to
also predict active compounds for drug targets that have no known modulators [58,59]. In
a separate report by Bilsland et al. in 2015, 3517 compounds were used to train a neural
network in a machine learning-based virtual screening study, leading to the identiﬁcation
of potential senescence agonists [60]. The resulting classiﬁcation model in the report was
subsequently employed to screen about 2 million lead-like compounds, of which 147 hits
were identiﬁed [61]. Among the 147 hits, CB-20903630, a benzimidazolone, demonstrated
low micromolar IC50 via in vitro assays, and could be explored in the development of
selective cell cycle inhibitors [60]. In 2020, Rifaioglu et al. [61] also employed a deep
convolutional neural network to develop DEEPScreen, a drug–target interaction (DTI)
predictive model. DEEPScreen predicted JAK proteins as new targets of the drug cladribine,
which were conﬁrmed experimentally [61]. Altogether, these reports highlight robust
performance of deep learning; as such, its role in current-day drug design cannot be
overemphasized.
Deep learning models have been used to predict inhibitors of drug targets [62,63].
With the emergence of severe acute respiratory syndrome coronavirus 2 (SARS-CoV2), the
search for highly efﬁcacious compounds to inhibit the activities of the virus has become
more urgent and needful [64–66]. Among such reports is a study by Ton et al., in which
Deep Docking (DD), a novel deep learning platform for structure-based virtual screening
(SBVS) was developed and applied to screen 1.3 billion compounds to identify 1000 po-
tential compounds for the SAR-CoV-2 main protease (Mpro) [67]. Though these predicted
compounds need experimental validation, they serve as an essential prioritized list for fur-
ther development. In another report, HIV-1 sequence data and drug resistance assays for 18
antiretroviral therapy (ART) drugs were used to develop three deep learning architectures
to predict drug resistance [68]. The report identiﬁed a convolutional neural network as
the best architecture when compared to multilayer perceptron and bidirectional recurrent
neural networks [68]. A report by Yao et al. in 2020 and Wang et al. in 2021 also employed
an artiﬁcial neural network (ANN) to develop an ontology-based model for predicting
the side-effect of compounds, which was employed to evaluate the traditional Chinese
medicine (TCM) prescriptions ofﬁcially recommended for the treatment of coronavirus
disease 2019 (COVID-19) [55,69].
Apart from antiviral compound prediction, deep learning has also been employed
in other drug discovery efforts. One of such efforts was a study by Zhavoronkov et al.
in 2019 [66], in which a DNN-based generative reinforcement learning model was devel-
oped to predict Discoidin domain receptor 1 (DDR 1) inhibitors. Two of the predicted
compounds from the model strongly inhibited DDR1 activity in vitro, with IC50 of 10 and
21 nM [70]. In a recent report, Bhagwati et al. in developed a DNN model from the ChEMBL
datasets to virtually screen the Mabridge database (https://www.maybridge.com) (ac-
cessed on 26 January 2023) [71]. The model from their report identiﬁed potential inhibitory
molecules of renin protein, a protein involved in the development of hypertension and
other cardiovascular diseases. In total, 8701 compounds were used for the training, of
which 2628 compounds were classiﬁed as active. After validation, the DNN model had
an accuracy of 99.83% and a Matthew correlation coefﬁcient (MCC) value of 0.975, which
represents a strong correlation between the actual and the predicted classiﬁcation [71].
Deep learning algorithms, despite their outstanding performance in comparison to
several machine learning algorithms in the prediction of small molecules or inhibitors of
drug targets [72], are yet to be implemented in the quest to identify anti-EBOV compounds.
DNN learns meaningful representations from data through successive layers. The layered
representations are learned through models called neural networks, structured in layers
stacked on top of each other. DNN can be viewed as a model that maps input to targets via

## Page 6 (Section: Data Sources for Ebola Machine Learning Studies )

Pharmaceuticals 2023, 16, 332
6 of 12
a deep sequence of data transformations that are learned by exposure to examples [56]. It
is therefore worth utilizing DNN models to predict anti-EBOV compounds since they have
been shown to produce better performance.
Although deep learning models are effective techniques to predict Ebola virus in-
hibitors, they do have some shortcomings that must be taken into account. The challenge
of hyperparameter tuning is one of the key difﬁculties [73]. Before training the model,
hyperparameters, which are parameters that govern the model’s behavior, are deﬁned.
The learning rate, the number of hidden layers, and the number of neurons in each layer
are a few examples [74]. It can be difﬁcult to optimize these hyperparameters, since there
are frequently a large number of alternative combinations to explore, and ﬁnding the
ideal combination might take a lot of computing effort [74]. Another drawback of using
deep learning models for predicting Ebola virus inhibitors is the lack of computational
tools for reproducibility. Deep learning models are frequently complicated and tricky to
comprehend, and it might be difﬁcult to replicate the outcomes of a certain study or experi-
ment [75]. Due to this, it may be challenging to conﬁrm a research’s ﬁndings or corroborate
a similar study in another environment. This lack of reproducibility can pose a signiﬁcant
challenge when predicting inhibitors, where accurate and reproducible results are crucial.
Furthermore, deep learning models are also computationally expensive; they require a
signiﬁcant amount of computational power and time to train [76]. This can be a signiﬁcant
obstacle, especially for researchers working in resource-constrained environments. Lastly,
selecting the right ML model out of other predictive models can be a difﬁcult task, as the
performance of a model can vary depending on the speciﬁc task and dataset. Different
models may perform well on different metrics, such as accuracy, precision, recall, F1 score,
and AUC-ROC [77]. Some models may perform well on a speciﬁc subset of the data but
poorly on the rest of it, which highlights the importance of considering the distribution and
characteristics of the data. Furthermore, there may be trade-offs between different metrics,
such as a model with high accuracy but low recall, and it is important to consider the
speciﬁc requirements and goals of the task when selecting a model [77]. Overall, selecting
the right ML model requires a thorough understanding of the data, the task, and the speciﬁc
metrics that are relevant for that task.
5. Data Sources for Ebola Machine Learning Studies
Finding anomalies or patterns and correlations within a large dataset to predict out-
comes is a relevant technique in drug discovery [78]. With the advancement in the studies
of the composition, structure, and interactions of cellular molecules, much information
about drugs and targets is generated. Molecules with their structural features and biologi-
cal activity data are curated in various databases for use in ML [79]. Many databases are
available with increasing numbers of data sizes due to the accessibility of high-throughput
data from around the globe [80]. As data and statistics about drugs and targets are gath-
ered, it sets the pace for drug discovery studies. There are a number of databases with
bioassay data on EVD that could be exploited for machine learning projects. Notable
amongst such databases are PubChem [81], ChEMBL [82], BindingDB [83], DrugRepV [84]
and Ebolabase [85], as highlighted in Figure 1. A search for the Ebola virus on PubChem
yielded 597 bioassay data, whereas ChEMBL yielded 47 bioassay data assays (Table 2) that
can be exploited for ML-based EBOV drug discovery studies. A search for Ebola virus data
via BindingDB produced only 2, while a total of 868 compounds in DrugRepV were experi-
mentally validated for anti-Ebola activities. A more comprehensive Ebola–human–drug
interaction database was also recently created by Muthaiyan et al. in 2021 [85], curating
270 human proteins that interacted with EBOV, a database that was exploited for training
models. Altogether, these datasets could be pooled to train ML models towards predicting
anti-EBOV compounds with a good degree of therapeutic potential.

## Page 7 (Section: Data Sources for Ebola Machine Learning Studies )

Pharmaceuticals 2023, 16, 332
7 of 12
Figure 1. Schematic highlighting the integration of available resources and machine learning models
(ML) to aid in potential anti-EBOV molecule prediction.
Table 2. Ebola virus-related bioassay data available in ChEMBL [72]. The table consists of numbers
of compounds, the description of the assays, and IDs. Assays with number of compounds less than
100 were excluded.
ChEMBL ID
Description
No. of Compounds
CHEMBL3562085
PubChem BioAssay. qHTS Assay for Identifying
Compounds that block Entry of Ebola Virus: Screen1,
ratio channel. (Class of assay: conﬁrmatory).
558
CHEMBL3562152
PubChem BioAssay. qHTS Assay for Identifying
Compounds that block Entry of Ebola Virus: Screen2,
ratio channel. (Class of assay: conﬁrmatory).
1822
CHEMBL3562088
PubChem BioAssay. qHTS Assay for Identifying
Compounds that block Entry of Ebola Virus: Screen1,
green channel. (Class of assay: conﬁrmatory).
570
CHEMBL3562112
PubChem BioAssay. qHTS Assay for Identifying
Compounds that block Entry of Ebola Virus: Screen1,
blue channel. (Class of assay: conﬁrmatory).
556
CHEMBL3562133
PubChem BioAssay. qHTS Assay for Identifying
Compounds that block Entry of Ebola Virus, Screen1
green channel. (Class of assay: conﬁrmatory).
570
CHEMBL3561981
PubChem BioAssay. qHTS Assay for Identifying
Compounds that block Entry of Ebola Virus: Screen 4,
blue channel. (Class of assay: conﬁrmatory).
168
CHEMBL3562144
PubChem BioAssay. qHTS Assay for Identifying
Compounds that block Entry of Ebola Virus: Screen 4,
green channel. (Class of assay: conﬁrmatory).
170
CHEMBL3562135
PubChem BioAssay. qHTS Assay for Identifying
Compounds that block Entry of Ebola Virus, Screen 1
blue channel. (Class of assay: conﬁrmatory).
556
CHEMBL3562064
PubChem BioAssay. qHTS Assay for Identifying
Compounds that block Entry of Ebola Virus: Screen 2,
blue channel. (Class of assay: conﬁrmatory).
1996

## Page 8 (Section: Conclusions )

Pharmaceuticals 2023, 16, 332
8 of 12
Table 2. Cont.
ChEMBL ID
Description
No. of Compounds
CHEMBL3562033
PubChem BioAssay. qHTS Assay for Identifying
Compounds that block Entry of Ebola Virus: Screen 4,
ratio channel. (Class of assay: conﬁrmatory)
170
CHEMBL3562136
PubChem BioAssay. qHTS Assay for Identifying
Compounds that block Entry of Ebola Virus, Screen 2
blue channel. (Class of assay: conﬁrmatory).
1968
CHEMBL3562119
PubChem BioAssay. qHTS Assay for Identifying
Compounds that block Entry of Ebola Virus, Screen 2
green channel. (Class of assay: conﬁrmatory).
2170
CHEMBL3561990
PubChem BioAssay. qHTS Assay for Identifying
Compounds that block Entry of Ebola Virus: Screen 2,
green channel. (Class of assay: conﬁrmatory).
2189
CHEMBL3562146
PubChem BioAssay. qHTS Assay for Identifying
Compounds that block Entry of Ebola Virus, Screen 2
ratio channel. (Class of assay: conﬁrmatory).
1812
CHEMBL3561973
PubChem BioAssay. qHTS Assay for Identifying
Compounds that block Entry of Ebola Virus, Screen 1
ratio channel. (Class of assay: conﬁrmatory).
558
Though the application of ML algorithms tends to hasten the pace in the quest for
biotherapeutic compounds, the absence of vast and diverse datasets to train and test
models on is one of the primary research gaps in the application of machine learning and
big data for Ebola medication development [72]. Despite continuing initiatives to gather
and exchange data, larger and more varied datasets are still required in order to create
reliable and accurate models [86]. This is crucial for creating ML models that generalize
well to new data and can be used in a variety of situations and populations. There is a need
for greater study on the best ways to create and test novel compounds in clinical settings
as well as how to transfer the ﬁndings from ML models into new medicines. This entails
creating strategies for discovering novel therapeutic targets, forecasting the effectiveness of
various drugs against the virus, and enhancing the planning and evaluation of clinical trials
for the treatment of Ebola [87]. Additional studies are required to create numerous online
platforms and applications, which are easy to utilize to support high-throughput screening
of drugs with more precision and effectiveness. Overall, the application of big data and
ML techniques have the potential to hasten the identiﬁcation and creation of novel Ebola
therapeutics, but more work remains to fully fulﬁll this promise.
6. Conclusions
Machine-learning algorithms such as support vector machines, Bayesian models, and
recurrent partitioning forest have been used to predict potential anti-EBOV molecules
from FDA-approved compounds. The full clinical potential of drug repurposing for EBOV
treatment is yet to be realized. The dearth of available alternative FDA-approved drugs
for the treatment of EBOV is a global concern. ML techniques are cost-effective and time-
efﬁcient strategies in developing predictive models for drugs. It is therefore imperative
to leverage the vast amount of knowledge related to ML and available EBOV bioassay
data to identify EBOV therapeutics to augment existing efforts geared towards eradicating
the disease. The increasing amount of biological and pharmacological data coupled with
existing and new ML methods will certainly provide new perspectives into therapeutic
mechanisms. Furthermore, with increasing biological data, model applicability will be
enhanced as better data integration techniques will emerge. The deep neural network is
robust, with better performance in antiviral prediction, and can be employed to predict
small molecule inhibitors of Ebola virus disease.

## Page 9 (Section: Conclusions )

Pharmaceuticals 2023, 16, 332
9 of 12
Author Contributions: S.K.K., J.A. and M.D.W. conceptualized the review article; E.B., K.S.E. and
M.E.S.S. contributed to the various techniques; S.K.K., J.A. and C.A. cowrote the ﬁrst draft of the
manuscript. All authors have read and agreed to the published version of the manuscript.
Funding: This research received no external funding.
Institutional Review Board Statement: Not applicable.
Informed Consent Statement: Not applicable.
Data Availability Statement: Data sharing not applicable.
Conﬂicts of Interest: The authors declare no conﬂict of interest.
References
1.
Emanuel, J.; Marzi, A.; Feldmann, H. Filoviruses: Ecology, Molecular Biology, and Evolution. Adv. Virus Res. 2018, 100, 189–221.
[PubMed]
2.
Sivanandy, P.; Jun, P.H.; Man, L.W.; Wei, N.S.; Mun, N.F.K.; Yii, C.A.J.; Ying, C.C.X. A systematic review of Ebola virus disease
outbreaks and an analysis of the efﬁcacy and safety of newer drugs approved for the treatment of Ebola virus disease by the US
Food and Drug Administration from 2016 to 2020. J. Infect. Public Health 2022, 15, 285–292. [CrossRef] [PubMed]
3.
Jacob, S.T.; Crozier, I.; Fischer, W.A.; Hewlett, A.; Kraft, C.S.; de La Vega, M.-A.; Soka, M.J.; Wahl, V.; Grifﬁths, A.; Bollinger, L.; et al.
Ebola virus disease. Nat. Rev. Dis. Prim. 2020, 6, 13. [CrossRef]
4.
Rajak, H.; Jain, D.K.; Singh, A.; Sharma, A.K.; Dixit, A. Ebola virus disease: Past, present and future. Asian Pac. J. Trop. Biomed.
2015, 5, 337–343. [CrossRef]
5.
Farman, A. Ebola, the Negative Stranded RNA Virus. In Some RNA Viruses; Badshah, S.L., Ed.; IntechOpen: Rijeka, Croatia, 2020;
p. Ch. 5. ISBN 978-1-83962-926-6.
6.
Wan, W.; Kolesnikova, L.; Clarke, M.; Koehler, A.; Noda, T.; Becker, S.; Briggs, J.A.G. Structure and assembly of the Ebola virus
nucleocapsid. Nature 2017, 551, 394–397. [CrossRef]
7.
Qureshi, A.I. Ebola Virus Disease: From Origin to Outbreak; Academic Press: Cambridge, MA, USA, 2016; pp. 23–37. ISBN
9780128042304.
8.
World Health Organization Ebola Virus Disease. Available online: https://www.who.int/news-room/fact-sheets/detail/ebola-
virus-disease (accessed on 26 January 2023).
9.
Ekins, S.; Freundlich, J.S.; Clark, A.M.; Anantpadma, M.; Davey, R.A.; Madrid, P. Machine learning models identify molecules
active against the Ebola virus in vitro. F1000Research 2015, 4, 1091. [CrossRef]
10.
Markham, A. REGN-EB3: First Approval. Drugs 2021, 81, 175–178. [CrossRef]
11.
Lee, A. Ansuvimab: First Approval. Drugs 2021, 81, 595–598. [CrossRef]
12.
Qian, T.; Zhu, S.; Hoshida, Y. Use of big data in drug development for precision medicine: An update. Expert Rev. Precis. Med.
Drug. Dev. 2019, 4, 189–200. [CrossRef]
13.
Brown, N.; Cambruzzi, J.; Cox, P.J.; Davies, M.; Dunbar, J.; Plumbley, D.; Sellwood, M.A.; Sim, A.; Williams-Jones, B.I.;
Zwierzyna, M.; et al. Big Data in Drug Discovery. Prog. Med. Chem. 2018, 57, 277–356.
14.
Mallappallil, M.; Sabu, J.; Gruessner, A.; Salifu, M. A review of big data and medical research. SAGE Open. Med. 2020, 8,
2050312120934839. [CrossRef]
15.
Glicksberg, B.S.; Li, L.; Chen, R.; Dudley, J.; Chen, B. Leveraging Big Data to Transform Drug Discovery. Methods Mol. Biol. 2019,
1939, 91–118.
16.
Zhu, H. Big Data and Artiﬁcial Intelligence Modeling for Drug Discovery. Annu. Rev. Pharmacol. Toxicol. 2020, 60, 573–589.
[CrossRef]
17.
Cha, Y.; Erez, T.; Reynolds, I.J.; Kumar, D.; Ross, J.; Koytiger, G.; Kusko, R.; Zeskind, B.; Risso, S.; Kagan, E.; et al. Drug
repurposing from the perspective of pharmaceutical companies. Br. J. Pharmacol. 2018, 175, 168–180. [CrossRef]
18.
Dara, S.; Dhamercherla, S.; Jadav, S.S.; Babu, C.H.M.; Ahsan, M.J. Machine Learning in Drug Discovery: A Review. Artif. Intell.
Rev. 2022, 55, 1947–1999. [CrossRef]
19.
Sarker, I.H.; Furhad, M.H.; Nowrozy, R. AI-Driven Cybersecurity: An Overview, Security Intelligence Modeling and Research
Directions. SN Comput. Sci. 2021, 2, 173. [CrossRef]
20.
Priya, S.; Tripathi, G.; Singh, D.B.; Jain, P.; Kumar, A. Machine learning approaches and their applications in drug discovery and
design. Chem. Biol. Drug. Des. 2022, 100, 136–153. [CrossRef]
21.
Xue, H.; Li, J.; Xie, H.; Wang, Y. Review of Drug Repositioning Approaches and Resources. Int. J. Biol. Sci. 2018, 14, 1232–1244.
[CrossRef]
22.
Sun, D.; Gao, W.; Hu, H.; Zhou, S. Why 90% of clinical drug development fails and how to improve it? Acta Pharm. Sin. B 2022,
12, 3049–3062. [CrossRef]
23.
Vamathevan, J.; Clark, D.; Czodrowski, P.; Dunham, I.; Ferran, E.; Lee, G.; Li, B.; Madabhushi, A.; Shah, P.; Spitzer, M.; et al.
Applications of machine learning in drug discovery and development. Nat. Rev. Drug. Discov. 2019, 18, 463–477. [CrossRef]

## Page 10 (Section: Conclusions )

Pharmaceuticals 2023, 16, 332
10 of 12
24.
Bender, A.; Cortés-Ciriano, I. Artiﬁcial intelligence in drug discovery: What is realistic, what are illusions? Part 1: Ways to make
an impact, and why we are not there yet. Drug. Discov. Today 2020, 26, 511–524. [CrossRef] [PubMed]
25.
Helm, J.M.; Swiergosz, A.M.; Haeberle, H.S.; Karnuta, J.M.; Schaffer, J.L.; Krebs, V.E.; Spitzer, A.I.; Ramkumar, P.N. Machine
Learning and Artiﬁcial Intelligence: Deﬁnitions, Applications, and Future Directions. Curr. Rev. Musculoskelet. Med. 2020, 13,
69–76. [CrossRef] [PubMed]
26.
Nguyen, G.; Dlugolinsky, S.; Bobák, M.; Tran, V.; López García, Á.; Heredia, I.; Malík, P.; Hluchý, L. Machine Learning and Deep
Learning frameworks and libraries for large-scale data mining: A survey. Artif. Intell. Rev. 2019, 52, 77–124. [CrossRef]
27.
Rifaioglu, A.S.; Atas, H.; Martin, M.J.; Cetin-Atalay, R.; Atalay, V.; Do˘gan, T. Recent applications of deep learning and machine
intelligence on in silico drug discovery: Methods, tools and databases. Brief. Bioinform. 2019, 20, 1878–1912. [CrossRef]
28.
Schneider, G.; Clark, D.E. Automated De Novo Drug Design: Are We Nearly There Yet? Angew. Chem. Int. Ed. 2019, 58,
10792–10803. [CrossRef]
29.
Deng, J.; Yang, Z.; Ojima, I.; Samaras, D.; Wang, F. Artiﬁcial intelligence in drug discovery: Applications and techniques. Brief.
Bioinform. 2022, 23, bbab430. [CrossRef]
30.
Jiménez-Luna, J.; Grisoni, F.; Schneider, G. Drug discovery with explainable artiﬁcial intelligence. Nat. Mach. Intell. 2020, 2,
573–584. [CrossRef]
31.
Blower, E.P.; Cross, P.K. Decision Tree Methods in Pharmaceutical Research. Curr. Top. Med. Chem. 2006, 6, 31–39. [CrossRef]
32.
Schöning, V.; Hammann, F. How far have decision tree models come for data mining in drug discovery? Expert Opin. Drug.
Discov. 2018, 13, 1067–1069. [CrossRef]
33.
Rodríguez-Pérez, R.; Bajorath, J. Evolution of Support Vector Machine and Regression Modeling in Chemoinformatics and Drug
Discovery. J. Comput. Aided. Mol. Des. 2022, 36, 355–362. [CrossRef]
34.
Ma, J.; Wang, J.; Ghoraie, L.S.; Men, X.; Haibe-Kains, B.; Dai, P. A Comparative Study of Cluster Detection Algorithms in
Protein–Protein Interaction for Drug Target Discovery and Drug Repurposing. Front. Pharmacol. 2019, 10, 109. [CrossRef]
35.
Lund, B.; Ma, J. A review of cluster analysis techniques and their uses in library and information science research: And clustering.
Perform. Meas. Metr. 2021, 22, 161–173. [CrossRef]
36.
Jaeger, A.; Banks, D. Cluster analysis: A modern statistical review. WIREs Comput. Stat. 2022, n/a, e1597. [CrossRef]
37.
Jiang, X.; Kopp-Schneider, A. Summarizing EC50 estimates from multiple dose-response experiments: A comparison of a
meta-analysis strategy to a mixed-effects model approach. Biom. J. 2014, 56, 493–512. [CrossRef]
38.
Madrid, P.B.; Chopra, S.; Manger, I.D.; Gilﬁllan, L.; Keepers, T.R.; Shurtleff, A.C.; Green, C.E.; Iyer, L.V.; Dilks, H.H.;
Davey, R.A.; et al. A systematic screen of FDA-approved drugs for inhibitors of biological threat agents. PLoS ONE 2013,
8, e60579. [CrossRef]
39.
Aykul, S.; Martinez-Hackert, E. Determination of half-maximal inhibitory concentration using biosensor-based protein interaction
analysis. Anal. Biochem. 2016, 508, 97–103. [CrossRef]
40.
Parasuraman, S. Prediction of activity spectra for substances. J. Pharmacol. Pharmacother. 2011, 2, 52–53.
41.
Kwoﬁe, S.K.; Broni, E.; Teye, J.; Quansah, E.; Issah, I.; Wilson, M.D.; Miller, W.A.; Tiburu, E.K.; Bonney, J.H.K. Pharmacoinformatics-
based identiﬁcation of potential bioactive compounds against Ebola virus protein VP24. Comput. Biol. Med. 2019, 113, 103414.
[CrossRef]
42.
Darko, L.K.S.; Broni, E.; Amuzu, D.S.Y.; Wilson, M.D.; Parry, C.S.; Kwoﬁe, S.K. Computational Study on Potential Novel
Anti-Ebola Virus Protein VP35 Natural Compounds. Biomedicines 2021, 9, 1796. [CrossRef]
43.
Loubet, P.; Palich, R.; Kojan, R.; Peyrouset, O.; Danel, C.; Nicholas, S.; Conde, M.; Porten, K.; Augier, A.; Yazdanpanah, Y.
Development of a prediction model for ebola virus disease: A retrospective study in nzérékoré ebola treatment center, Guinea.
Am. J. Trop. Med. Hyg. 2016, 95, 1362–1367. [CrossRef]
44.
Colubri, A.; Silver, T.; Fradet, T.; Retzepi, K.; Fry, B.; Sabeti, P. Transforming Clinical Data into Actionable Prognosis Models:
Machine-Learning Framework and Field-Deployable App to Predict Outcome of Ebola Patients. PLoS Negl. Trop. Dis. 2016,
10, e0004549. [CrossRef] [PubMed]
45.
Rajput, A.; Kumar, M. Anti-Ebola: An initiative to predict Ebola virus inhibitors through machine learning. Mol. Divers. 2022, 26,
1635–1644. [CrossRef] [PubMed]
46.
Adams, J.; Agyenkwa-Mawuli, K.; Agyapong, O.; Wilson, M.D.; Kwoﬁe, S.K. EBOLApred: A machine learning-based web
application for predicting cell entry inhibitors of the Ebola virus. Comput. Biol. Chem. 2022, 101, 107766. [CrossRef] [PubMed]
47.
Bai, Z.; Krishnaiah, P.R. Reduction of Dimensionality. In Encyclopedia of Physical Science and Technology, 3rd ed.; Meyers, R.A., Ed.;
Academic Press: New York, NY, USA, 2003; pp. 55–73. [CrossRef]
48.
Hussain, J.N. High Dimensional Data Challenges in Estimating Multiple Linear Regression. J. Phys. Conf. Ser. 2020, 1591, 012035.
[CrossRef]
49.
Peng, Y.; Nagata, M.H. An empirical overview of nonlinearity and overﬁtting in machine learning using COVID-19 data. Chaos
Solitons Fractals 2020, 139, 110055. [CrossRef]
50.
Wang, H.; Hu, X. Deep Learning in Bioinformatics and Biomedicine. Methods 2023, 209, 38–39. [CrossRef]
51.
Carpenter, K.A.; Cohen, D.S.; Jarrell, J.T.; Huang, X. Deep learning and virtual drug screening. Future Med. Chem. 2018, 10,
2557–2567. [CrossRef]
52.
Unterthiner, T.; Mayr, A.; Klambauer, G.; Steijaert, M.; Wegner, J.; Ceulemans, H.; Hochreiter, S. Deep learning as an opportunity
in virtual screening. Adv. Neural Inf. Process. Syst. 2014, 27, 1–9.

## Page 11 (Section: Conclusions )

Pharmaceuticals 2023, 16, 332
11 of 12
53.
Goh, G.B.; Hodas, N.O.; Vishnu, A. Deep learning for computational chemistry. J. Comput. Chem. 2017, 38, 1291–1307. [CrossRef]
54.
Nag, S.; Baidya, A.T.K.; Mandal, A.; Mathew, A.T.; Das, B.; Devi, B.; Kumar, R. Deep learning tools for advancing drug discovery
and development. 3 Biotech 2022, 12, 110. [CrossRef]
55.
Wang, Z.; Li, L.; Yan, J.; Yao, Y. Evaluating the Traditional Chinese Medicine (TCM) Ofﬁcially Recommended in China for
COVID-19 Using Ontology-Based Side-Effect Prediction Framework (OSPF) and Deep Learning. 2020. Available online:
https://Www.Preprints.Org/Manuscript/202002.0230/V1 (accessed on 26 January 2023).
56.
Chen, H.; Engkvist, O.; Wang, Y.; Olivecrona, M.; Blaschke, T. The rise of deep learning in drug discovery. Drug. Discov. Today
2018, 23, 1241–1250. [CrossRef]
57.
Lenselink, E.B.; Ten Dijke, N.; Bongers, B.; Papadatos, G.; Van Vlijmen, H.W.T.; Kowalczyk, W.; Ijzerman, A.P.; Van Westen,
G.J.P. Beyond the hype: Deep neural networks outperform established methods using a ChEMBL bioactivity benchmark set.
J. Cheminform. 2017, 9, 45. [CrossRef]
58.
Wallach, I.; Dzamba, M.; Heifets, A. AtomNet: A Deep Convolutional Neural Network for Bioactivity Prediction in Structure-
based Drug Discovery. arXiv 2015, arXiv:1510.02855.
59.
Stecula, A.; Hussain, M.S.; Viola, R.E. Discovery of novel inhibitors of a critical brain enzyme using a homology model and a
deep convolutional neural network. J. Med. Chem. 2020, 63, 8867–8875. [CrossRef]
60.
Bilsland, A.E.; Pugliese, A.; Liu, Y.; Revie, J.; Burns, S.; McCormick, C.; Cairney, C.J.; Bower, J.; Drysdale, M.; Narita, M.; et al.
Identiﬁcation of a Selective G1-phase Benzimidazolone Inhibitor by a Senescence-Targeted Virtual Screen Using Artiﬁcial Neural
Networks. Neoplasia 2015, 17, 704–715. [CrossRef]
61.
Rifaioglu, A.S.; Nalbat, E.; Atalay, V.; Martin, M.J.; Cetin-Atalay, R.; Doˇgan, T. DEEPScreen: High performance drug-target
interaction prediction with convolutional neural networks using 2-D structural compound representations. Chem. Sci. 2020, 11,
2531–2557. [CrossRef]
62.
Karki, N.; Verma, N.; Trozzi, F.; Tao, P.; Kraka, E.; Zoltowski, B. Predicting Potential SARS-COV-2 Drugs-In Depth Drug Database
Screening Using Deep Neural Network Framework SSnet, Classical Virtual Screening and Docking. Int. J. Mol. Sci. 2021, 22, 1573.
[CrossRef]
63.
Zhang, Y.; Ye, T.; Xi, H.; Juhas, M.; Li, J. Deep Learning Driven Drug Discovery: Tackling Severe Acute Respiratory Syndrome
Coronavirus 2. Front. Microbiol. 2021, 12, 739684. [CrossRef]
64.
Zhang, H.; Saravanan, K.M.; Yang, Y.; Hossain, M.T.; Li, J.; Ren, X.; Pan, Y.; Wei, Y. Deep Learning Based Drug Screening for
Novel Coronavirus 2019-nCov. Interdiscip. Sci. Comput. Life Sci. 2020, 12, 368–376. [CrossRef]
65.
Beck, B.R.; Shin, B.; Choi, Y.; Park, S.; Kang, K. Predicting commercially available antiviral drugs that may act on the novel
coronavirus (SARS-CoV-2) through a drug-target interaction deep learning model. Comput. Struct. Biotechnol. J. 2020, 18, 784–790.
[CrossRef]
66.
Bung, N.; Krishnan, S.R.; Bulusu, G.; Roy, A. De novo design of new chemical entities (NCEs) for SARS-CoV-2 using artiﬁcial
intelligence. ChemRxiv 2020, 13, 575–585.
67.
Ton, A.T.; Gentile, F.; Hsing, M.; Ban, F.; Cherkasov, A. Rapid Identiﬁcation of Potential Inhibitors of SARS-CoV-2 Main Protease
by Deep Docking of 1.3 Billion Compounds. Mol. Inform. 2020, 39, e2000028. [CrossRef] [PubMed]
68.
Steiner, M.C.; Gibson, K.M.; Crandall, K.A. Drug resistance prediction using deep learning techniques on HIV-1 sequence data.
Viruses 2020, 12, 560. [CrossRef] [PubMed]
69.
Yao, Y.; Wang, Z.; Li, L.; Lu, K.; Liu, R.; Liu, Z.; Yan, J. An Ontology-Based Artiﬁcial Intelligence Model for Medicine Side-Effect
Prediction: Taking Traditional Chinese Medicine as an Example. Comput. Math. Methods Med. 2019, 2019, 1–7. [CrossRef]
70.
Zhavoronkov, A.; Ivanenkov, Y.A.; Aliper, A.; Veselov, M.S.; Aladinskiy, V.A.; Aladinskaya, A.V.; Terentiev, V.A.; Polykovskiy,
D.A.; Kuznetsov, M.D.; Asadulaev, A.; et al. Deep learning enables rapid identiﬁcation of potent DDR1 kinase inhibitors. Nat.
Biotechnol. 2019, 37, 1038–1040. [CrossRef]
71.
Bhagwati, S.; Siddiqi, M.I. Deep neural network modeling based virtual screening and prediction of potential inhibitors for renin
protein. J. Biomol. Struct. Dyn. 2022, 40, 4612–4625. [CrossRef]
72.
Wang, M.; Hou, S.; Wei, Y.; Li, D.; Lin, J. Discovery of novel dual adenosine A1/A2A receptor antagonists using deep learning,
pharmacophore modeling and molecular docking. PLoS Comput. Biol. 2021, 17, e1008821. [CrossRef]
73.
Mahdaddi, A.; Meshoul, S.; Belguidoum, M. EA-based hyperparameter optimization of hybrid deep learning models for effective
drug-target interactions prediction. Expert Syst. Appl. 2021, 185, 115525. [CrossRef]
74.
Koutsoukas, A.; Monaghan, K.J.; Li, X.; Huan, J. Deep-learning: Investigating deep neural networks hyper-parameters and
comparison of performance to shallow methods for modeling bioactivity data. J. Cheminform. 2017, 9, 42. [CrossRef]
75.
Isdahl, R.; Gundersen, O.E. Out-of-the-Box Reproducibility: A Survey of Machine Learning Platforms. eScience: San Diego, CA,
USA, 2019; pp. 86–95. [CrossRef]
76.
Thompson, N.C.; Greenewald, K.; Lee, K.; Manso, G.F. The Computational Limits of Deep Learning. 2020. Available online:
http://arxiv.org/abs/2007.05558 (accessed on 26 January 2023).
77.
Dinga, R.; Penninx, B.W.J.H.; Veltman, D.J.; Schmaal, L.; Marquand, A.F. Beyond accuracy: Measures for assessing machine
learning models, pitfalls and guidelines. BioRxiv 2019, 743138.
78.
Rodrigues, T.; Bernardes, G.J.L. Machine learning for target discovery in drug development. Curr. Opin. Chem. Biol. 2020, 56,
16–22. [CrossRef]

## Page 12 (Section: Conclusions )

Pharmaceuticals 2023, 16, 332
12 of 12
79.
Papadatos, G.; Gaulton, A.; Hersey, A.; Overington, J.P. Activity, assay and target data curation and quality in the ChEMBL
database. J. Comput. Aided. Mol. Des. 2015, 29, 885–896. [CrossRef]
80.
Potemkin, V.; Potemkin, A.; Grishina, M. Internet Resources for Drug Discovery and Design. Curr. Top. Med. Chem. 2018, 18,
1955–1975. [CrossRef]
81.
Kim, S.; Thiessen, P.A.; Bolton, E.E.; Chen, J.; Fu, G.; Gindulyte, A.; Han, L.; He, J.; He, S.; Shoemaker, B.A.; et al. PubChem
substance and compound databases. Nucleic Acids Res. 2016, 44, D1202–D1213. [CrossRef]
82.
Gaulton, A.; Bellis, L.J.; Bento, A.P.; Chambers, J.; Davies, M.; Hersey, A.; Light, Y.; McGlinchey, S.; Michalovich, D.;
Al-Lazikani, B.; et al. ChEMBL: A large-scale bioactivity database for drug discovery. Nucleic Acids Res. 2012, 40, D1100–D1107.
[CrossRef]
83.
Wassermann, A.M.; Bajorath, J. BindingDB and ChEMBL: Online compound databases for drug discovery. Expert Opin. Drug.
Discov. 2011, 6, 683–687. [CrossRef]
84.
Rajput, A.; Kumar, A.; Megha, K.; Thakur, A.; Kumar, M. DrugRepV: A compendium of repurposed drugs and chemicals targeting
epidemic and pandemic viruses. Brief. Bioinform. 2021, 22, 1076–1084. [CrossRef]
85.
Muthaiyan, M.; Naorem, L.D.; Seenappa, V.; Pushan, S.S.; Venkatesan, A. Ebolabase: Zaire ebolavirus-human protein interaction
database for drug-repurposing. Int. J. Biol. Macromol. 2021, 182, 1384–1391. [CrossRef]
86.
Sarker, I.H. Machine Learning: Algorithms, Real-World Applications and Research Directions. SN Comput. Sci. 2021, 2, 160.
[CrossRef]
87.
Jarada, T.N.; Rokne, J.G.; Alhajj, R. A review of computational drug repositioning: Strategies, approaches, opportunities,
challenges, and directions. J. Cheminform. 2020, 12, 46. [CrossRef]
Disclaimer/Publisher’s Note: The statements, opinions and data contained in all publications are solely those of the individual
author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to
people or property resulting from any ideas, methods, instructions or products referred to in the content.


---

# Assessment of artificial intelligence (AI) reporting methodology in glioma MRI studies using the Checklist for AI in Medical Imaging (CLAIM)

- **Authors:** Abhishta Bhandari, Luke Scott, Manuela Weilbach, Ravi Marwah, Arian Lasocki
- **Issuer:** Neuroradiology
- **Type:** Scientific article
- **Published:** 2023-02-07
- **Language:** en
- **DOI:** 10.1007/s00234-023-03126-9
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36746792/
- **Licence:** CC-BY

## Section: Abstract

The Checklist for Artificial Intelligence in Medical Imaging (CLAIM) is a recently released guideline designed for the optimal reporting methodology of artificial intelligence (AI) studies. Gliomas are the most common form of primary malignant brain tumour and numerous outcomes derived from AI algorithms such as grading, survival, treatment-related effects and molecular status have been reported. The aim of the study is to evaluate the AI reporting methodology for outcomes relating to gliomas in magnetic resonance imaging (MRI) using the CLAIM criteria. A literature search was performed on three databases pertaining to AI augmentation of glioma MRI, published between the start of 2018 and the end of 2021 RESULTS: A total of 4308 articles were identified and 138 articles remained after screening. These articles were categorised into four main AI tasks: grading (n= 44), predicting molecular status (n= 50), predicting survival (n= 25) and distinguishing true tumour progression from treatment-related effects (n= 10). The average CLAIM score was 20/42 (range: 10-31). Studies most consistently reported the scientific background and clinical role of their AI approach. Areas of improvement were identified in the reporting of data collection, data management, ground truth and validation of AI performance. AI may be a means of producing high-accuracy results for certain tasks in glioma MRI; however, there remain issues with reporting quality. AI reporting guidelines may aid in a more reproducible and standardised approach to reporting and will aid in clinical integration.


---

# Bioactive Molecules from the Innate Immunity of Ascidians and Innovative Methods of Drug Discovery: A Computational Approach Based on Artificial Intelligence

- **Authors:** Laura La Paglia, Mirella Vazzana, Manuela Mauro, Alfonso Urso, Vincenzo Arizza, Aiti Vizzini
- **Issuer:** Marine drugs
- **Type:** Scientific article
- **Published:** 2023-12-20
- **Language:** en
- **DOI:** 10.3390/md22010006
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38276644/
- **Licence:** CC-BY

## Section: Abstract

AbstractThe study of bioactive molecules of marine origin has created an important bridge between biological knowledge and its applications in biotechnology and biomedicine. Current studies in different research fields, such as biomedicine, aim to discover marine molecules characterized by biological activities that can be used to produce potential drugs for human use. In recent decades, increasing attention has been paid to a particular group of marine invertebrates, the Ascidians, as they are a source of bioactive products. We describe omics data and computational methods relevant to identifying the mechanisms and processes of innate immunity underlying the biosynthesis of bioactive molecules, focusing on innovative computational approaches based on Artificial Intelligence. Since there is increasing attention on finding new solutions for a sustainable supply of bioactive compounds, we propose that a possible improvement in the biodiscovery pipeline might also come from the study and utilization of marine invertebrates’ innate immunity.Keywords: bioactive molecules, marine invertebrate, artificial intelligence, innate immunity

## Section: 1. Introduction

Ascidians are tunicates, marine invertebrate chordates, considered the sister group of vertebrates [1,2,3,4]. They owe their name to the tunic, an epidermally secreted external layer that envelops the body. The tunic is composed of an ECM rich in collagen and tunicin (a form of cellulose) and also rich in immune cells [5,6,7,8,9]. The tunic also contains proteins with 3,4-dihydroxyphenylalanine (DOPA), with a catechol moiety involved in the first line of immune reaction [10] and wound healing [11,12], and 3,4,5-trihydroxyphenylalanine (TOPA) with a pyrogallol moiety [13]. Ascidians are the source of many bioactive molecules belonging to a wide variety of chemical categories [14,15] and with potential health applications, including cytotoxic, antimitotic, antiviral and antimicrobial compounds [16,17,18,19]. Most of the metabolites synthesized by ascidians contribute to creating the physico-chemical barrier preventing the entrance of foreign organisms into the internal fluids or the colonization of the tunic by encrusting organisms. The most represented chemical classes among the bioactive secondary metabolites isolated from tunicates are alkaloids, polyketides, and peptides [18]. Cytotoxicity against mammalian cell lines and anti-proliferative activity were the most frequently assigned bioactivities. Compounds with cytotoxic and antineoplastic properties isolated from ascidians belong to disparate chemical classes, and three of them have entered clinical trials [20]. Due to their key phylogenetic position in chordate evolution, the ascidians are a powerful model for studying innate immunity [4]. They possess an exclusively innate immune system, including inflammatory, humoral, and cellular responses. On an evolutionary level, inflammation is a highly conserved phenomenon and appears to be an essential first line of defense for both invertebrates and vertebrates. The innate immune system is the major contributor to acute inflammation [21,22], a rapid protective response to microbial infection, tissue injury, and insults [23], and the principal promoter of inflammatory responses often involves infection by microbial invaders or exposure to foreign particles/irritants/pollutants [24].

When host cells capable of innate immune responses encounter pathogenic microbes or other foreign or host irritants, the inflammatory response initiates within minutes. The host cells recognize the stimulus through various sensing mechanisms involving trans-membrane receptors. In Ciona robusta (previously Ciona intestinalis), these interactions transmit signals to the nucleus, resulting in the activation and regulation of numerous genes via both transcriptional and post-transcriptional mechanisms [21,25,26,27,28,29,30,31,32,33], such as antimicrobial peptides and complement factors [34,35] and proinflammatory cytokines and chemokines which activate endothelial cells and recruit immune system cells to the infection site [36,37,38].

The immune system is made up of a complex and dynamic network of cell subsets and mediators that promote host defense from infectious agents or tumor cells and maintain immunological tolerance in the organisms [39,40]. Vertebrate immunity is classically divided into innate and adaptive immune systems that act interdependently based on bidirectional crosstalk [41]. It is well known that the innate immune system provides the first line of defense in immune response and can induce and regulate many different adaptive immunity functions [42].

This review provides an overview of the bioactive molecules isolated from the innate immune system response of ascidians and, at the same time, describes a new approach combining omics technologies and new bioinformatic strategies for drug discovery based on Artificial Intelligence to reduce costly and time-consuming conventional laboratory testing, validation, and synthetic procedures and accelerate the drug discovery process. We also propose the study of omics data obtained from the innate immune processes of ascidians as an excellent source of innovative bioactive molecules such as antimicrobial, anticancer, and immunomodulatory peptides.

## Section: 2. Bioactive Molecules in Ascidians

Bioactive peptides (BPs) are composed of protein fragments or peptides with beneficial metabolic and physiological functions that promote human health; thus, they are excellent molecules for studying human health and disease and potential therapeutics [43,44]. Most have similar structures, such as <20 amino acid residue lengths, and contain hydrophobic residues [45,46]. Based on their modes of action, different classes of BP are evidenced: anticancer (ACP), antiviral, antimicrobial (AMP), anti-oxidative stress, and immunomodulatory peptides [15,16,17,18,19,47,48].

In the following sections, only AMP and immunomodulatory peptides will be discussed, as they are the only bioactive molecules shown in ascidians.

Bioactive molecules in ascidians from immunocytes: antimicrobial and immunomodulator peptides.

## Section: 2. Bioactive Molecules in Ascidians › 2.1. Bioactive Molecules with Antimicrobial Activity

AMPs are a class of small peptides that exist widely in nature, and they are an important part of the innate immune system of different organisms. AMPs have a broad range of inhibitory effects against bacteria, fungi, parasites, and viruses. The emergence of antibiotic-resistant microorganisms and increasing concerns about the use of antibiotics have resulted in the development of AMPs, which have good application prospects in medicine, food, animal husbandry, agriculture, and aquaculture. Microorganism resistance to antimicrobials is becoming increasingly severe with the abuse of antibiotics in medicine, agriculture, and animal husbandry. The prevalence of vancomycin-resistant enterococcus (VRE) and methicillin-resistant Staphylococcus aureus (MRSA) is increasing in clinical medicine, so countermeasures are urgently needed to address these bacterial infections. Research on AMPs is continuously developing, and AMP databases store a considerable amount of data on AMPs. A massive variety of antimicrobials has been extracted from tunicates. They belong to disparate chemical classes, such as polysulfides, alkyl sulfates, terpenes, amino alcohols, spiroketals, alkaloids, furanones, peptides, and others [15]. Some of them are synthesized by symbiotic organisms colonizing the tunic or the internal fluids [49,50].

Most of the known AMPs are produced by ascidian-circulating cells, mainly immunocytes (i.e., cells involved in immune responses) for defense purposes [51,52,53,54,55,56,57,58,59,60] (Table 1).

In Halocynthia roretzi, the tetrapeptides halocyamines A and B are produced by cytotoxic morula cells (MCs) [51], and their cytotoxic activity is likely related to their diphenol rings, representing suitable substrates for the enzyme phenoloxidase (PO), which is also stored inside MCs. The enzyme induces oxidative stress by oxidizing phenols to quinones with the consequent production of ROS [64]. The hemocytes of species H. aurantium synthesize the peptide dicynthaurin and the cationic peptide halocidin [54]. The native peptide of halocidin has a mass of 3443 Da and comprises two different subunits containing 18 amino acid residues and 15 residues which are linked covalently by a single cystine disulfide bond. Two different monomers were separately synthesized to make three additional isoforms (15-residue homodimer, 18-residue homodimer, heterodimer). Antimicrobial assays performed with synthetic peptides of halocidin confirmed that congeners of the 18-residue monomer were more active than those of the 15-residue monomer MRSA and multidrug-resistant Pseudomonas aeruginosa.

Hemocytes from the solitary tunicate Styela clava contained a family of four α-helical antimicrobial peptides that were purified, sequenced, and named clavanins A, B, C, and D. Clavanins A–D (histidine-rich, -helix peptides) [49] and clavaspirin are synthesized by Styela clava MCs [56]. In lysates of hemocytes of the same species, five cationic antimicrobial peptides, called styelins, were identified and isolated [57,58]. In hemocytes of Styela plicata, the octapeptide plicatamide was isolated [59]. In the tunicates Microcosmus sabatieri and Halocynthia papillosa, antimicrobial activities were detected, and two novel peptides, halocyntin and papillosin, were isolated and characterized. These molecules display antibacterial activity against Gram-positive and Gram-negative bacteria. A combination of Edman degradation and mass spectrometry obtained a complete peptide characterization. The mature molecules of halocyntin and papillosin comprise 26 and 34 amino acid residues, respectively [60].

The enormous quantity of genomic data has become a promising source of putative AMPs due to progress in bioinformatics [65,66,67,68]. In C. intestinalis, using genome and expressed sequence tag (EST) data, a putative gene family has been identified exhibiting several structural features typical of AMPs. The synthetic peptide exerted potent antimicrobial activity against various bacteria and against the yeast Candida albicans, but it was not cytolytic for mammalian erythrocytes. Using the synthetic peptide as an antigen, specific antibodies were generated, and the natural parent molecule was localized to a compartment of a distinct hemocyte type, the univacuolar refractile granulocytes [53]. Furthermore, a gene family coding for putative AMPs was identified in the EST database of C. intestinalis and subsequently identified and cloned from the Northern European Ciona subspecies. Molecular analysis revealed that the natural peptide is synthesized and stored in a distinct hemocyte type, the univacuolar non-refractile granulocytes, and that the expression of the gene is markedly upregulated in hemocytes after immune challenge. The peptide proved highly effective against Gram-negative and Gram-positive bacteria, including several human and marine pathogens, as well as the yeast C. albicans. Using two different methods, it was demonstrated that the peptide kills Gram-negative and Gram-positive bacteria by permeabilizing their cytoplasmic membranes. Circular Dichroism (CD) spectroscopy revealed that in the presence of liposomes composed of negatively charged phospholipids, the peptide undergoes a conformational change and adopts an alpha-helical structure. Moreover, the peptide was virtually non-cytolytic for mammalian erythrocytes. Hence, this designed AMP may represent a valuable template for developing novel antibiotics [52].

Ci-MAM-A24, a synthetic AMP derived from a peptide precursor from immune cells of C. intestinalis, is potently active against representatives of Gram-positive and Gram-negative bacteria by permeabilizing their cytoplasmic membrane. The activity of Ci-MAM-A24 against different bacterial pathogens which frequently cause therapeutic problems was tested. Fedders et al. tested the killing capacity of Ci-MAM-A24 against clinically important anaerobic bacteria as well as multiresistant aerobic strains such as MRSA, VRE, extended-spectrum α-lactamase-producers, and multiple-resistant Pseudomonas aeruginosa, and all strains proved to be highly susceptible to Ci-MAM-A24 at low concentrations [69].

Furthermore, an in silico screening method has been developed based on further criteria such as size, amphipathicity, and aggregation propensity, by which 22 potential LCAMP candidates in the Ciona genome were computationally predicted. Among these LCAMP candidates, five novel salt-resistant LCAMPs with broad-spectrum antimicrobial activity were experimentally confirmed. This strategy was also successfully applied to the Xenopus tropicalis genome, suggesting that this method could apply to the in silico screening of any genome [34].

Finally, Lu et al. [61] investigated the potential sORFs encoding AMPs in C. intestinalis, and over 180 peptides deduced from the sORFs were predicted to be AMPs. Among the ten peptides tested, six were found to have significant EST matches, providing strong evidence for gene expression; five were proved to be active against the bacterial strains.

Bioactive molecules in ascidians from immunocytes: antimicrobial and immunomodulator peptides.

## Section: 2. Bioactive Molecules in Ascidians › 2.2. Bioactive Molecules with Immunomodulatory Effects

A recent idea is to use invertebrates as a source of molecules with potential immunoregulatory activities to improve strategies for modulating human immune system responses [65,66]. The innate immune system is composed of many interdependent cell types and mediators. It is one of the most critical natural systems for protection against many harmful bacteria, viruses, parasites, and fungi in human health, and against autoimmune diseases, cancer, allergies, and infections [70,71].

Preliminary studies have shown evidence supporting a complex interaction between the immune system and tumors [72]. Several innate system immunomodulators have been identified; these include cytokines (interleukins, interferons, and chemokines), substances isolated from microorganisms and fungi (lipopolysaccharides; LPS), and substances isolated from plants (polysaccharides and phenolic compounds) [73]. Tumor cells secrete altered protein products that must be recognized as foreign by the immune effector cells such as B, T, natural killer and natural killer T cells, and type I and II interferons, and perforin which are able to destroy tumor cells [74,75]. Therefore, the enhancement of the host immune response is one of the most important methods for inhibiting tumor growth and maintaining cellular homeostasis without harming the host.

The selective modulation of immunity is an emerging concept driven by the tremendous advances in our understanding of this crucial host defense system. Invertebrates have drawn researchers’ interest as potential sources of new bioactive molecules owing to their immunomodulatory activities. An LPS challenge in the ascidian C. intestinalis generates the transcript, Ci8 short, with cis-regulatory elements in the 3′ UTR region which is essential for shaping innate immune responses. The derived amino acidic sequence from in silico analysis showed specific binding to human major histocompatibility complex (MHC) class I and class II alleles. The role of Ci8 short peptide (Table 1) was investigated in a more evolved immune system using human peripheral blood mononuclear cells (PBMCs) as an in vitro model. The biological activities of this molecule include the activation of the 70 kDa TCR ζ chain associated protein kinase (ZAP-70) and T cell receptor (TCR) Vβ oligo clonal selection on CD4+ T lymphocytes as well as increased proliferation and IFN-γ secretion. Furthermore, Ci8 short affects CD4+/CD25high-induced regulatory T cells (iTreg) subset selection, which co-expressed the functional markers TGF-β1/latency-associated protein (LAP) and CD39/CD73 [62].

Furthermore, Colombo et al. [63] evaluated the 3D structure of the C8 short-derived C. robusta chemo-attractive peptide (CrCP) (Table 1) by homology modeling, which showed that CrCP displayed structural characteristics already reported for a short domain of the vertebrate CRK gene, suggesting its possible involvement in cell migration mechanisms. The biological activity of CrCP was studied in vitro using a primary human dermal cell line. In vitro assays demonstrated that CrCP could induce the motility of HuDe cells in both wound healing and chemo-attractive experiments. Furthermore, CrCP modulates the expression of the matrix metalloproteinase-7 (MMP-7) and E-cadherin genes, and it induces the activation of the NF-κB signaling pathway.

## Section: 3. Bioactive Molecule Identification through Omics Technologies

Classical methods for peptide analysis have relied principally on targeted immunoassays which enable the biochemical purification of bioactive peptides from tissues or cells by identifying fractions with a desired bioactivity [76]. By performing multiple rounds of purification, bioactive peptides could be subsequently identified. This approach discovered many peptides in ascidians, including the isolation of Clavanins in Styela clava hemocytes [55] and Halocyamine in the ascidian Halocynthia roretzi [51]. During the last decade, technological innovations and the advent of omics data have led to an explosion of biological information. Indeed, different strategies, including transcriptomics and proteomics approaches, such as next-generation sequencing or mass spectrometry, have substituted the classical methods for peptide analysis, producing a considerable amount of biological data. The increasing amount of biological data produced was accompanied by the use of bioinformatics tools to support big data analysis.

Fedders et al.’s initial efforts to integrate genomic data and bioinformatics [53] proceeded through a reverse search for AMPs in C. robusta. They used the completed genome project and the substantial amount of EST data available as a screening matrix in association with bioinformatics techniques for the design of synthetic AMPs with in silico tools. Another recent approach to investigating bioactive peptides in C. robusta by integrating omics data analysis with bioinformatics focused on the study of the 3D structure of the C8short-derived CrCP, which was evaluated by homology modeling. In vitro studies using a primary human dermal cell line (HuDe) evaluated the biological activity of CrCP. A short domain of the vertebrate CRK gene was identified, suggesting its possible involvement in cell migration mechanisms [75].

Later, Kawada et al. [77] showed how omics studies associated with AI algorithms could contribute to the elucidation of gene expression profiles. These revealed key regulatory genes for Ciona follicle growth, maturation, and ovulation, verifying essential and novel molecular mechanisms underlying these biological events with the contribution of machine learning techniques. Furthermore, AI has been employed to solve some of the most challenging issues of bioinformatics, including protein structure prediction, homology searches, multiple alignment and phylogeny construction, genomic sequence analysis, gene finding, and more. Thus, combining omics data with AI and single-cell technologies, Kawada et al. [77] paved the way for investigating in greater detail the nervous, neuroendocrine, and endocrine systems of ascidians and the molecular and functional evolution and diversity of peptidergic regulatory networks throughout chordates. Franchi et al. [78] reported the identification, by mining the B. schlosseri transcriptome, of a transcript for a putative styelin-like AMP named botryllin, which is actively transcribed by morula cells (MCs). The synthetic peptide, obtained from in silico translation of the transcript, exerted toxic activity toward bacterial and unicellular yeast cells.

Additional omics data may come from proteome analyses and can also be useful for identifying proteins and peptides with molecule bioactive features, such as AMPs [79]. One of the most widespread proteomic approaches is liquid chromatography coupled with mass spectrometry (LC-MS) [80]. The analysis of spectra obtained by mass spectrometry consists of protein profiling, peptide mapping and identification, and protein quantification. Matos et al. [81], through shotgun proteomics of the ascidian tunic, provided new insights on host–microbe interactions by revealing diverse AMPs. They reported different proteins associated with immune mechanisms of invertebrates, as in the case of the metazoan Down syndrome cell adhesion molecule-like protein, which was detected in Molgula sp. samples and related to immune mechanisms mediating phagocytosis and adherence of bacteria [82], or the barrier to autointegration factor (BAF), involved in innate immune response as an inhibitor of exogenous viral DNA replication and involved in host defense response [83], revealing the tunic as a very active tissue in terms of bioactive compound production [81].

A recent study on innate immune response mechanisms to microbial stimuli in a C. robusta invertebrate model showed the importance of multi-omics analysis and bioinformatics approaches. Indeed, the intersection of large-scale sequencing or other “-omics” approaches, as the combination of transcriptomic and proteomic data analysis, allows the better investigation of the cellular pathways and biological processes affected by microbial treatments and the investigation of host responses to PAMPs in different physiological conditions and at various stages of maturation of the immune system, thus filling potential gaps concerning expression differences observed in the synthesis of proteins related to mRNA expression [84].

## Section: 4. AI-Based Computational Approaches and Their Role in Drug Discovery

To guide the reader in the following methodological sections, we will briefly introduce the main concepts of AI and its principal subclasses, and then we will focus on AI approaches applied to drug discovery.

AI is a technology-based system that can mimic human intelligence through features such as reasoning, knowledge representation, and solution research. At the same time, it does not threaten to completely replace human physical presence. Moreover, AI can help manage the massive amount of data produced and give decision-making support in clinical and translational research.

Machine learning (ML) is a subclass of AI. Through ML processes, computers can learn without explicitly being programmed. It performs prediction and classification tasks through pattern detection without using defined rules [85]. There are two ML algorithm classes: supervised and unsupervised learning.

In supervised learning, the datasets are designed to train or “supervise” algorithms to classify data or to accurately predict outcomes. Moreover, supervised learning problems can further be divided into “classification” and “regression” tasks: classification assigns test data to specific categories, and regression can predict a continuous numerical output, helping in establishing a relationship among the variables by estimating how one variable affects the other. Another subclass of ML is classification, which is “unsupervised” as it takes references from datasets consisting of input data without labeled responses [85,86,87,88,89,90,91,92].

Due to the massive amount of data produced by NGS techniques, AI has made a significant contribution to data analysis. Also, in bioactive compound analysis, ML algorithms are the basis of many prediction and analysis methods. Deep Learning (DL) algorithms are a subset of ML [93,94,95,96,97,98].

Drug discovery is the process through which new medications against diseases are discovered. It consists of a combination of a wide variety of technologies and expertise aimed at finding potential drugs against specific targets. Typical examples of drug discovery tasks are drug-target prediction [99], bioavailability prediction [100], and de novo drug design [101]. Moreover, there is also the main category of pharmaceutical analysis that groups these examples of drug discovery, involving different subtasks such as toxicity analysis, bioactivity evaluation, and physiochemical property analysis.

Advancements in AI techniques have revolutionized their applications to this field of research (Figure 1). Indeed, many AI approaches have been developed during the last decade specifically for this aim, allowing the acceleration of the drug discovery process and, at the same time, reducing the high-cost characteristics of conventional methods in terms of money and time [102].

Drug toxicity prediction is one of the subtasks of drug discovery, and it allows us to predict how much a molecule could adversely affect humans. The use of AI technologies allows the testing of a specific molecule’s toxicity, avoiding animal tests and high costs (Figure 2) [103,104]. The physico-chemical properties of molecules are another essential feature to assess in drug discovery studies. Their knowledge allows the understanding and modeling of the action of drugs. Among the numerous types of physico-chemical properties are the solubility, molar mass, charge, hydrophobicity, isoelectric point, and percentage of hydrophobic amino acids [105,106]. About 65% of the small molecule drugs are derived from natural products or their derivatives [107]; hence, drug bioactivity assessment has become an active area in drug discovery. AI techniques have been effectively applied to predicting drug bioactivities, such as anticancer, antiviral, and antibacterial activities (Figure 2) [108,109]. Among the different types of bioactive features, antimicrobial properties are gaining much attention as AMPs can be cutting-edge treatments for many infectious disorders. The effectiveness of AMPs against bacteria, fungi, and viruses has persisted for an extended period, making them the best option for addressing the growing problem of antibiotic resistance. Due to their wide-ranging actions, AMPs have become more prominent, particularly in therapeutic applications.

The prediction of AMPs has become difficult for academics due to the explosive increase of AMPs documented in databases. Wet-lab investigations to find antimicrobial peptides are exceedingly costly, time-consuming, and even impossible for some species. Therefore, to choose the optimal AMP candidates before in vitro trials, an efficient computational method must be developed [110]. Bioactive compounds can also assert an essential role as anticancer molecules. Indeed, most of them exert their antiproliferative effects by inhibiting different signaling pathways or intervening in cell-cycle arrest [111]. Various AI-based tools have recently been developed to help solve this aim. Another important subtask of drug discovery is the accurate binding prediction between a major histocompatibility complex (MHC) allele and bioactive peptides, as these last molecules are essential players in the synthesis of personalized cancer vaccines [112]. The immune system struggles to distinguish between a cancerous and a healthy cell. In a patient who has cancer with a particular MHC allele, only those peptides that bind with the MHC allele with high affinity help the immune system recognize the cancerous cells. AI approaches can help predict MHC-II binding, a fast alternative to wet-laboratory investigations, since experiments for MHC class II binding peptide identification are expensive and time consuming.

Finally, the protein structure is another important aspect to investigate in drug discovery as it allows us to understand the structural interactions, investigating the potential functionality of a protein and acquiring information on important binding domains for target proteins. Indeed, most drug targets are proteins that play essential roles in enzymatic activities, cell signaling, and cell–cell transduction. Although conventional experimental techniques, such as X-ray crystallography, cryogenic electron microscopy, and nuclear magnetic resonance spectroscopy have been proposed to investigate potential protein structures, they are still time-consuming and costly. Therefore, AI technology can help develop novel methods to fill the gap between the number of protein sequences and known protein structures. Virtual Screening (VS) is a computational approach that allows the prediction of the 3D structure of a chemical compound or a potential bioactive molecule against a specific target (Figure 3). It can be divided into ligand-based and structure-based methods. The former is used when very little structural information is available for the target and a set of active ligand molecules is known. Ligand-based methods include pharmacophore modeling and quantitative structure–activity relationship (QSAR) methods. The latter is used to model the interaction between a small molecule with a target protein at the atomic level, thus characterizing the behavior of small molecules in the binding site of target proteins and elucidating fundamental biochemical processes [113].

Principal classes and subclasses of AI algorithms and their involvement in drug discovery.

Schematic examples of the main tasks of pharmaceutical analysis and their possible resolution by AI techniques.

Structure-based and ligand-based VS approaches in protein docking.

## Section: 5. AI-Based Web Tools for Bioactive Compound Identification and Analysis

As omics technologies have led to a vast increase in biological knowledge, this raises the necessity of figuring out how to mine helpful knowledge from it, which requires sophisticated data analysis and data-mining methods. To this aim, high-performance computing analysis methods have been developed to support the massive amount of data produced and, at the same time, give decision-making support to clinical and translational research [114,115].

By using ML algorithms, computers can learn without explicitly being programmed. It accomplishes prediction and classification tasks through pattern detection without using defined rules. Many bioactive compound analysis and identification methods use ML [116]. Several types of omics data, such as transcriptomics and proteomics, can be used alone or can be integrated into a multi-omics approach to be further analyzed by different computational methods based on AI (Figure 4). Different steps can be completed starting from genome or proteomic sequences to identify and analyze different features of potential bioactive molecules.

Indeed, different tools have been developed based on AI (Table 2):

Several types of omics data can be used alone or in an integrated multi-omics approach to be further analyzed by different computational methods based on AI.

AI-based tools developed for bioactive peptide analyses.

Example of a pipeline used in the study of bioactive molecules with high-throughput omics technologies.

## Section: 5. AI-Based Web Tools for Bioactive Compound Identification and Analysis › 5.1. To predict the Antimicrobial Activity of Peptides

CAMPR3 (http://www.camp3.bicnirrh.res.in/, accessed on 1 October 2023) (Collection of Antimicrobial Peptides) [117,118] allows the expansion and acceleration of AMP family-based studies. It uses information on the conserved sequence signatures captured as patterns and Hidden Markov Models (HMMs) [90]; AmPEPpy is a web tool for predicting AMP sequences using a random forest classifier (https://github.com/tlawrence3/amPEPpy, accessed on 1 October 2023) [119]; InverPrep contains the CALCAMPI algorithm that can calculate the physico-chemical properties (molar mass, charge, hydrophobicity, Boman index, aliphatic index, isoelectric point, and percentage of hydrophobic amino acids) of multiple peptides simultaneously (http://ciencias.medellin.unal.edu.co/gruposdeinvestigacion/prospeccionydisenobiomoleculas/InverPep/public/home_en) accessed on 2 October 2023 [120]; AntiBP2 (http://crdd.osdd.net/raghava/antibp2/, accessed on 2 October 2023) [121] is based on the support vector machine (SVM) algorithm using the composition of peptide sequences. The overall accuracy of the web server is about 92%, and the source of antibacterial peptides can also be predicted; AMPA is a web tool for the prediction of protein antimicrobial regions (http://tcoffee.crg.cat/apps/ampa, accessed on 4 October 2023), and its main application is the fast automatic detection of antimicrobial regions in proteins that can serve as new templates for AMP design. AMPA-derived AI values can be used to classify proteins or domains as antimicrobial or non-antimicrobial automatically and compare different protein sequences in this regard. When used in conjunction with the T-coffee alignment tool, antimicrobial regions can be checked to identify potentially conserved antimicrobial domains [122].

## Section: 5. AI-Based Web Tools for Bioactive Compound Identification and Analysis › 5.2. To Identify Peptides with Anticancer Properties

The AntiCP tool (https://webs.iiitd.edu.in/raghava/anticp/, accessed on 4 October 2023) [123] is a web-based prediction server based on machine learning techniques such as SVMs. It can predict every possible single-mutant/analog of a given peptide, and it can also predict their anticancer activity along with all the essential physico-chemical properties like hydrophobicity, charge, isoelectric point, etc. Other anticancer prediction tools using ML or DL models have been developed. Between them is a novel meta-approach which implements a user-friendly webserver for accurately identifying ACPs, which is called MLACP 2.0 [124]. The tool employs 11 different encoding schemes and eight different classifiers, including convolutional neural networks, to create a stable meta-model (https://balalab-skku.org/mlacp2, accessed on 6 October 2023); ACP-MCAM can automatically learn adaptive embedding and the context sequence features of ACP [125]. Chen et al. used the features of amino acid dipeptide composition and pseudo-amino acid composition, combined with an SVM, to construct an ACP prediction algorithm called iACP (http://crdd.osdd.net/raghava/anticp/multi_pep.php, accessed on 6 October 2023) [126].

Other methods can discriminate between ACPs and non-ACPs, and they include ACPP [127], iACP-GAEnsC [128], TargetACP [129], ACPred [130], ACPred-FL [131], ACPred-Fuse [132], ACP-DL [133] and iACP-FSCM [134].

## Section: 5. AI-Based Web Tools for Bioactive Compound Identification and Analysis › 5.3. To Predict Peptide Binding with Immune Protein Classes

The automated platform to benchmark peptide–MHC class II binding prediction tools, called the Immune Epitope Database (IEDB), includes different prediction servers, such as NetMHCII 2.3 for T cell epitope prediction, along with other B cell epitope prediction tools (http://tools.iedb.org/main/, accessed on 10 October 2023) [135]. NetMHCII 2.3 (https://services.healthtech.dtu.dk/services/NetMHCII-2.3/, accessed on 10 October 2023) [136,137] uses artificial neuron networks (ANNs) to predict the binding of peptides to HLA-DR, HLA-DQ, HLA-DP, and mouse MHC class II alleles. The user is also guided in their choice of binding strength by strong and weak binding indicated in the output. Other computational methods for the prediction of MHC class II binding include ARB (http://epitope.liai.org:8080/matrix, accessed on 11 October 2023) [138], MHCpred (http://SVRMHC.umn.edu/SVRMHCdb, accessed on 11 October 2023) [139], TEPITOPE (https://github.com/dmnfarrell/epitopepredict, accessed on 11 October 2023) [140], and several others [141].

## Section: 5. AI-Based Web Tools for Bioactive Compound Identification and Analysis › 5.4. To Predict AMPs

Prediction tools can be applied to protein sequences from the proteome. A peptide must have many different features to be considered potentially bioactive, such as physico-chemical characteristics, signal peptides, and the location of their cleavage sites. Web tools such as SignalP 5.0 can achieve this aim (https://services.healthtech.dtu.dk/services/SignalP-5.0/, accessed on 13 October 2023) [142]. This web tool can predict the presence of signal peptides or the location of their cleavage sites in proteins from different species through evolution, such as Archaea, Gram-positive Bacteria, Gram-negative Bacteria, and Eukarya. This method uses a combination of several ANNs and HMMs to predict cleavage sites and signal peptides/non-signal peptides. Both ANN and HMM are algorithms belonging to a subset of ML algorithms which are DL models. In ANN, the nodes of the networks are considered to be the neurons of the brain, and the edges connecting the nodes are considered to be “synapses”. DL models have also been applied among AMP predictors. Indeed, a key issue concerning DL models in AMP prediction is the need for samples in the positive class and their ambiguity in the negative class [106]. MultiPep (https://agbg.shinyapps.io/MultiPep/, accessed on 15 October 2023) is a hierarchical DL approach to the multi-label classification of peptide bioactivities [143]. PeptideRanker (http://distilldeep.ucd.ie/PeptideRanker/, accessed on 15 October 2023) [144] predicts peptide bioactivity using bioactivity probability scores. PeptideLocator (http://bioware.ucd.ie/, accessed on 15 October 2023) [145] is based on a BRNN algorithm. Other DL approaches used for different types of peptide analyses are Antimicrobial Peptide Scanner vr.2 (https://www.dveltri.com/ascan/v2/ascan.html, accessed on 16 October 2023) [146] and Deep-AmPEP30 (https://cbbio.cis.um.edu.mo/AxPEP, accessed on 16 October 2023) [147]. Antimicrobial Peptide Scanner vr.2 proposes a neural network model with convolutional and recurrent layers that leverage primary sequence composition to predict AMP properties.

A recent work by Hussain [148] describes an AMP prediction tool called AMP-PFPDeep, which is based on a deep neural network. It improves the accuracy of short antimicrobial peptide prediction using three different sequence encodings and an NN algorithm. The different sequences of the benchmark datasets used in the study were converted into three-channel images comprising information related to the position, frequency, and sum of 12 physiochemical features as the first, second, and third channels, respectively.

AMPGANv2 is a bidirectional conditional generative adversarial network-based approach for rational AMP design (https://gitlab.com/vail-uvm/amp-gan, accessed on 18 October 2023). AMPGAN v2 uses generator–discriminator dynamics to learn data-driven priors and control generation using conditioning variables [149]. The bidirectional component, implemented using a learned encoder to map data samples into the latent space of the generator, aids in the iterative manipulation of candidate peptides.

## Section: 5. AI-Based Web Tools for Bioactive Compound Identification and Analysis › 5.5. To Predict Secondary Protein Structure

Web tools that use DL include the PSIPRED Protein Structure Prediction Server from the University College London Bioinformatics Unit (http://bioinf.cs.ucl.ac.uk/psipred/psiform.html, accessed on 20 October 2023) [150], which consists of a two-stage neural network and is based on the position-specific scoring matrices generated by PSI-BLAST. It predicts highly accurate secondary structure predictions.

Another secondary structure prediction method is PSSpred (Protein Secondary Structure prediction) (https://zhanggroup.org/PSSpred/, accessed on 20 October 2023). It also uses PSI-BLAST to collect multiple sequence alignments. Then, amino-acid frequency and log-odds data are used to train the secondary structure, based on the Rumelhart error backpropagation method, and finally, a consensus of seven neural network predictors is used to predict the secondary structure prediction [151]. Among secondary structure prediction tools using DL approaches, there is also the APSSP2: Advanced Protein Secondary Structure Prediction Server [152] http://crdd.osdd.net/raghava/apssp2/ (accessed on 20 October 2023).

## Section: 5. AI-Based Web Tools for Bioactive Compound Identification and Analysis › 5.6. To 3D Modeling

The AlphaFold method (https://alphafold.ebi.ac.uk/, accessed on 21 October 2023) [153] is a program that performs predictions of 3D protein structures and is designed as a DL system. IntFOLD (Integrated Fold Recognition) (https://www.reading.ac.uk/bioinf/IntFOLD/, accessed on 21 October 2023) is a fully automated, integrated pipeline for the prediction of 3D structures and functions from amino acid sequences [154]. RaptorX is another DL-based web server predicting both secondary predictions and 3D modeling (raptorx.uchicago.edu, accessed on 24 October 2023) [155]. ESyPred3D is an automated homology modeling program. Alignments are obtained by combining, weighing, and screening the results of several multiple alignment programs. The final three-dimensional structure is built using the MODELLER modeling package [156] (http://www.fundp.ac.be/urbm/bioinfo/esypred/, accessed on 24 October 2023).

## Section: 5. AI-Based Web Tools for Bioactive Compound Identification and Analysis › 5.7. Web Tools Employed in VS Techniques

Docking and molecular modeling allow us to know information about molecule orientation and the spatial conformation of the molecule under investigation to infer potential interactions with specific targets as proteins involved in immunity [157]. Some examples of ML-based web servers are OCHEM (https://ochem.eu/home/show.do, accessed on 30 October 2023) [158,159,160,161] and ChemSAR (http://chemsar.scbdd.com, accessed on 30 October 2023) [162], which are both employed in target prediction.

Finally, we show one example of a pipeline used in the study of bioactive molecules with high-throughput omics technologies. Starting from transcriptomics or proteomics of a whole dataset, candidate peptide can be identified and further analyzed through different bioinformatics web tools that allow the evaluation the bioactivity of the putative peptide sequences, the AMP, and the anticancer activity. Moreover, the protein structure of putative peptides and the interaction with target proteins can be predicted. The candidate peptides identified can be then synthetized, and finally, in vitro testing can be used to validate the in silico predictions (Figure 5).

AI-based tools developed for bioactive peptide analyses.

Example of a pipeline used in the study of bioactive molecules with high-throughput omics technologies.

## Section: 6. Conclusions

Drug discovery has always been a complex and time-consuming endeavor that traditionally relies on labor-intensive techniques, such as trial-and-error experimentation and high-throughput screening. However, these methods can be slow, costly, and often yield results with low accuracy. AI techniques such as ML and natural language processing, combined with the experimental production of omics data, offer the potential to accelerate and improve this process by enabling more efficient and accurate analyses of large amounts of data. This combined approach allows researchers to examine a large number of potential drug compounds to identify those with the desired properties. Classic methods can be limited by the availability of suitable test compounds and the difficulty of accurately predicting their pharmacological behavior. Different algorithms based on AI, including supervised and unsupervised learning methods, reinforcement, and evolutionary or rule-based algorithms, can potentially contribute to solving these problems. For instance, the efficacy and toxicity of new drug compounds can be predicted using these approaches with greater accuracy and efficiency than when using traditional methods. Furthermore, AI-based algorithms can also be employed to identify new targets for drug development, such as the specific proteins or genetic pathways involved in diseases. This can expand the scope of drug discovery beyond the limitations of more conventional approaches and may lead to the development of novel and more effective drugs. AI-based methods, on the other hand, can improve the efficiency and accuracy of drug discovery processes and lead to the development of more effective drugs. Furthermore, high-throughput gene sequencing has revolutionized the method used to identify novel molecular targets for drug discovery.

Since there has been increasing attention to finding new solutions for a sustainable supply of bioactive compounds, we would like evidence of the most recent bioinformatics methods to be connected to bioactive compound research. We also propose that a promising source of bioactive molecules, such as ACPs, antiviral, antimicrobial, anti-oxidative stress and immunomodulatory compounds, along with innovative solutions as therapeutic strategies, might come from the study of ascidian innate immunity processes.

Finally, the research’s expected impacts are therefore multiple: from the standardization of a workflow of several techniques that can be replicated by using omics data coming from the study of immune processes of different animal models and different AI based algorithms to the identification of various classes of bioactive molecules that can form the basis for a new groups of drugs which are pharmacologically more efficient and have fewer side effects.

## Section: Author Contributions

Conceptualization, L.L.P. and A.V.; methodology, L.L.P. and A.V.; data curation, L.L.P., A.V., M.V., A.U., V.A. and M.M.; writing—original draft preparation, L.L.P. and A.V.; writing—review and editing, L.L.P. and A.V.; supervision, L.L.P. and A.V. All authors have read and agreed to the published version of the manuscript.

## Section: Conflicts of Interest

The authors declare no conflict of interest.

## Section: Funding Statement

This research received no external funding.


---

# ChatGPT or LLM in next-generation drug discovery and development: pharmaceutical and biotechnology companies can make use of the artificial intelligence-based device for a faster way of drug discovery and development

- **Authors:** Soumen Pal, Manojit Bhattacharya, Md Aminul Islam, Chiranjib Chakraborty
- **Issuer:** International journal of surgery (London, England)
- **Type:** Scientific article
- **Published:** 2023-12-01
- **Language:** en
- **DOI:** 10.1097/js9.0000000000000719
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37707542/
- **Licence:** CC-BY-SA

## Section: Text

Dear Editor,

Two recent correspondence articles published in this journal about artificial intelligence (AI) in drug discovery and development are timely. The first article by Chakraborty C. et al. discussed AI in drug discovery and development, and the second article by Chakraborty C. illustrated AI in clinical trials1,2. These two articles elucidate the readers about the recent trend of AI in drug discovery and development. Recently, the increased application of AI has been observed in various sectors of society, including the healthcare sector. AI has been used in healthcare, from disease diagnosis to therapeutic discovery. AI-based drug discovery has played a significant role as a whole process of drug discovery and development. These two articles also provide significant information on AI-enabled drug discovery and development. However, one of the significant milestones of AI-based discovery was achieved by two companies, Exscientia and Sumitomo Dainippon Pharma, through the collaboration. Their discovered drug has entered into the clinical trial. Exscientia is a British start-up, and Sumitomo Dainippon Pharma is a Japanese pharmaceutical company. The drug molecule was developed using sophisticated AI methodologies, and the name of the molecule was DSP-11813. Recently, AI-enabled ChatGPT has shown its application in other areas of medicine and healthcare, including drug discovery and development.

ChatGPT was popularized very fast after its first introduction in November 2022. It has been noted that more than one million users have utilized the AI-enabled device within 5 days after its release4. The ChatGPT's is a state-of-the-art natural language processing system ingeniously developed by OpenAI in 20225. This cutting-edge system is endowed with the remarkable ability to generate human-like conversations by adroitly comprehending a conversation’s context and producing appropriate responses. Using this characteristic, researchers and users have explored ChatGPT’s several medical applications. Similarly, the AI-enabled ChatGPT application has been used in drug discovery and development. Recently, an article published in Nature Biotechnology has highlighted that he ChatGPT or large language models (LLM) are helping scientists to discover new drug targets. The article describes that AI-driven ChatGPT can map several potential drug targets, which helps drug discovery researchers from pharmaceutical companies in faster methods of drug discovery6. Therefore, there are immense possibilities that ChatGPT or LLM can be used in the different steps of drug discoveries. In this direction, we illustrate the possible contribution of ChatGPT or LLM in next-generation drug discovery and development. It has been noted that discovering drugs and their development is an intricate and multifaceted endeavor encompassing many stages, from the initial identification of a potential therapeutic target to the rigorous testing and eventual regulatory approval of a successful drug candidate. In this direction, ChatGPT or LLM are helping to perform all these steps successfully.

The conventional drug discovery and development approach has been arduous, expensive, and time-consuming. The pharmaceutical industry invests billions of dollars in introducing a potential drug candidate into the market, and it typically takes 15–20 years of research to identify a novel drug candidate7,8. Several researchers calculated the drug development cost, and the investment for a new drug molecule was estimated from research and development to market at about $1141.7 million9. Traditional drug discovery faces challenges, including high failure rates, low efficiency, and high costs. The high failure rate is attributed to the inability to predict drug candidates’ efficacy and toxicity accurately. Low efficiency is due to the demanding and labor-intensive nature of the process, which requires synthesizing and testing many compounds. The high-cost results from the need for expensive equipment, facilities, and personnel. An additional essential constraint in the initial stages of drug exploration has been the absence of unanimity concerning a suitable in vivo experimental model that can effectively imitate human ailments10. Recently, Sharma and Thakur illustrated that AI-assisted ChatGPT performs various steps of drug discovery, such as calculating the compound multiplicity, file conversion input file generation for Gaussian software, searching the pdb files, input file generation for docking, etc. All these activities help develop highly effective drug molecules11. ChatGPT or LLMs have been able to perform the different trajectories towards the discovery to development. Its robust and sophisticated features have contributed immensely to drug discovery by providing many advantageous outcomes. Among these benefits is the ability to analyze high-content screening data and design and synthesize new molecules. LLM models have facilitated the prognostication of biological activities and ADME properties encompassing absorption, distribution, metabolism, and excretion. Simultaneously, the techniques employed to depict molecules are incessantly progressing. Despite the LLM’s recent inception and limited experimentation, the techniques utilized for molecule generation present considerable promise in facilitating the exploration of unexplored realms within biochemical space11–13.

Understanding pharmacokinetics and pharmacodynamics is necessary during drug discovery and development. ChatGPT or LLM helps provide information about a particular compound’s pharmacokinetics and pharmacodynamics during the drug discovery and development process. It can provide the toxicity features of drug-like molecules during drug discovery and development11,14. AI has already been applied in the phases of a clinical trial of a molecule during the development process and it reduces the clinical trial time2. At the same time, AI-enabled ChatGPT might help in clinical trials. Its robust network can significantly decrease clinical trial time14. Another parameter studied during drug discovery and development is drug-drug interactions (DDIs). DDIs help us to understand the reaction interface with one or other molecules. Juhi et al. have informed us that ChatGPT helps us to understand the DDIs of a molecule. Due to incorrect information by ChatGPT, researchers are talking about the domain-specific ChatGPT. A domain-specific next-generation LLM may support providing accurate information16. Researchers are trying to develop domain-specific LLM in the drug discovery and development domain. Recently, DrugChat, a drug discovery domain-specific LLM, was developed and it can produce drug molecular graphs. DrugChat device consists of three essential items: a LLM, an adapter, and a graph neural network17. However, ChatGPT or LLM will improve during the future drug discovery and development process, and it will help pharmaceutical companies with more innovative drug discovery and development methods, accelerating the drug development process15.

Recently, AI has revolutionized drug discovery. Biotechnology and pharmaceutical companies have discovered over 150 small-molecule drugs using an AI-first approach. At the same time, it has been noted that more than 15 drug molecules have already entered the clinical trials developed by the AI-first approach. Therefore, AI has shown its potential for generating new chemical entities to lead molecule generation with desired properties, minimizing the labor-intensive methods18. Therefore, all pharmaceutical and biotechnology companies whose drug discovery and development activity can use AI-enabled ChatGPT’s transformative potential for faster drug discovery and development. However, pharmaceutical and biotechnology companies should set a roadmap for action and AI-based vision and strategy can speed up and more successful drug discovery and development.

## Section: Ethical approval

This article does not require any human/animal subjects to acquire such approval.

## Section: Sources of funding

This study received no specific grant from any funding agency in the public, commercial, or not-for-profit sectors.

## Section: Author contribution

S.P.: investigation, writing – original draft; M.B. and M.A.I.: validation; C.C.: conceptualization, data curation, investigation, writing – original draft, writing – review and editing. All authors critically reviewed and approved the final version of the manuscript.

## Section: Conflicts of interest disclosures

All authors report no conflicts of interest relevant to this article.

## Section: Guarantor

Md. Aminul Islam, Department of Microbiology, COVID-19 Diagnostic Lab, Noakhali Science and Technology University, Noakhali 3814, Bangladesh. E-mail: aminulmbg@gmail.com

## Section: Provenance and peer review

Not commissioned, internally peer-reviewed.

## Section: Data availability statement

The data in this correspondence article is not sensitive in nature and is accessible in the public domain. The data is therefore available and not of a confidential nature.

## Section: Contributor Information

Soumen Pal, Email: soumenpal12@gmail.com.

Manojit Bhattacharya, Email: mbhattacharya09@gmail.com.

Md. Aminul Islam, Email: aminulmbg@gmail.com.

Chiranjib Chakraborty, Email: drchiranjib@yahoo.com.

## Section: Associated Data › Data Availability Statement

The data in this correspondence article is not sensitive in nature and is accessible in the public domain. The data is therefore available and not of a confidential nature.


---

# Computational drug discovery on human immunodeficiency virus with a customized long short-term memory variational autoencoder deep-learning architecture

- **Authors:** Mucahit Kutsal, Ferhat Ucar, Nida Kati
- **Issuer:** CPT: pharmacometrics & systems pharmacology
- **Type:** Scientific article
- **Published:** 2023-12-05
- **Language:** en
- **DOI:** 10.1002/psp4.13085
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38010989/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractDespite attempts to control the spread of human immunodeficiency virus (HIV) through the use of anti‐HIV medications, the absence of an effective vaccine continues to present a significant obstacle. In addition, the development of drug resistance by HIV underscores the necessity for computational drug discovery methods to identify novel therapies. This investigation specifically focused on employing a long short‐term memory (LSTM) variational autoencoder deep‐learning architecture for computational drug discovery in relation to HIV. Our data set comprised simplified molecular input line entry system (SMILES)–encoded compounds, which were used to train the LSTM autoencoder. Remarkably, our model achieved a training accuracy of 91%, with a data set containing 1377 compounds. Leveraging the generative model derived from the training phase, we generated potential new drugs for combating HIV and assessed their interaction with the virus using a previously developed artificial intelligence model. Lastly, we verified the drug likeliness of our computationally generated compounds in accordance with Lipinski's rule of five. Overall, our study presents a promising approach to computational drug discovery in the ongoing battle against HIV.

## Section: INTRODUCTION

The global health landscape has been significantly impacted by the emergence of human immunodeficiency virus (HIV), an infectious pandemic that originated in Africa and subsequently spread across the world. According to the World Health Organization's published data, approximately 1.5 million new infections occurred in 2021, resulting in a staggering global estimate of 38.4 million individuals living with HIV. In the same report, it is projected that around 650,000 people lost their lives as a result of HIV‐related illnesses. 1 Research conducted from 1990 to the early 2000s reveals a notable upward trend in the HIV epidemic, followed by a decline from 2004 to 2019. However, despite a decrease in HIV‐related deaths during the past two decades, the prevalence of the virus has continued to rise, accumulating an alarming number of cases. 2 This study emphasizes the significance and achievements of drug discovery endeavors targeting HIV as well as the effectiveness of antiviral medications in suppressing the virus.

HIV is a group of viruses that belong to the family of retroviruses. Retroviruses are viruses that encode their own DNA polymerase and use the host cell's DNA polymerase to replicate its own DNA. Retroviruses have single‐stranded, positive‐sense RNA genomes that are transcribed into double‐stranded, proviral DNA after the reverse transcription stage. HIV specifically targets cluster of differantiation CD4+ T lymphocytes and destroys them, which ultimately leads to the immune system's collapse. HIV is able to escape the immune system by using several mechanisms, including the following: (1) the virus expresses several proteins that act to block the effects of the immune system, (2) the virus expresses proteins that block the effect of antiviral drugs, and (3) the virus mutates rapidly. 3 Several drugs have been developed that are able to suppress HIV. However, the virus is able to mutate rapidly and develops resistance to these drugs; therefore, drug discovery studies are constantly being conducted to identify new drugs that can suppress HIV. 4

Drug discovery is a pharmacological process where time, cost, and accuracy are crucial, and this is confirmed given one successful drug discovery takes about 10–15 years and costs $1.1 billion, and 90% of candidate drugs fail in clinical testing. 5 , 6 , 7 At present, with the development of technology, computer‐aided drug discovery (CAAD) methods are actively used to shorten the research cycle and reduce the cost and risk of clinical failure in the drug discovery process. The drug discovery process consists of several stages and a series of actions as shown in Figure 1. Typically, the process can be divided into the following four main stages: early drug discovery, preclinical phase, clinical phases, and regulatory approval. CAAD techniques help this process in the early stages, where researchers collaborate to identify and optimize potential candidate drugs. 8

There are numerous methods used for drug discovery in the literature, such as in silico, in vitro, de novo, and so on. 9 In this research, we studied de novo drug discovery with a deep‐learning approach for HIV. De novo drug discovery is basically based on the discovery of compounds with desired properties. However, the methods used to predict the reactivity and interaction of the novel‐discovered compounds are as important as their discovery process. 10 , 11 In a previous study conducted with another research team for a different purpose, in order to test the interactions of potential compounds that have been obtained against HIV, 12 a geometric deep‐learning approach was proposed to predict drug resistance to HIV, and for the virus–drug interaction, the authors used a different artificial intelligence (AI) model. In the previous study, the main purpose of the AI model developed with a different research team was not to produce a new drug, but was designed to measure the efficacy of an existing drug and to predict drug resistance to HIV and virus–drug interaction.

In the current research, to prove the drug likeliness and oral administration of our computationally generated drugs, we tested those drugs with the Lipinski rule of five (LRoF). 13 Oral administration is a desirable but not mandatory method during the drug treatment of diseases. 14 The LRoF is conceived to aid the development of orally bioavailable small‐molecule drugs. LRoF was proposed to detect drugs with high feasibility and potential among the high number of candidate compounds. Reviewing the study published by Zhang et al. in 2007, 15 we observe that 51% of Food and Drug Administration (FDA)–approved drugs comply with LRoF, and thus we can say that LRoF can be accepted as an auxiliary standard during drug discovery. Another factor we had to consider in the drug discovery process was toxicity. Toxicity is a critical consideration as it can limit the safety and efficacy of a drug candidate. 16 Therefore, toxicity testing is an integral part of the drug development process, and it is typically performed at various stages of the drug discovery process, including preclinical and clinical trials. In this study, we used the ProTox‐II toxicity prediction tool, 17 which employs computational models to predict the toxicity of chemicals to aquatic organisms. The selection of aquatic organisms as a focus for toxicity prediction is based on their use as a preliminary indicator in environmental toxicity studies, providing insights that can be extrapolated to potential toxicity in humans. All candidate drugs proposed in this study have passed all 17 toxicity tests in ProTox‐II, and none had a lethal dose 50 (LD50) 18 value less than 2000 mg/kg, indicating low acute toxicity.

In recent years, the application of deep‐learning models in the field of drug discovery has garnered significant attention, offering the possibility of tailoring drug candidates for specific biological targets. 19 One promising area in this domain is the use of molecular generative models. These models, by leveraging the power of deep learning, can potentially identify molecules with desired properties. Notably, a challenge that has emerged is the generation of syntactically invalid molecules by these deep‐learning models, which poses a bottleneck for their application in drug discovery processes. 20 To address this challenge, 21 a novel approach is introduced that hinges on the use of a conditional variational autoencoder (CVAE) for generating drug candidates. Instead of relying on diverse physical properties for training, the method uniquely employs molecular fingerprints coupled with the results of the growth inhibition of 50% (a metric used to assess the concentration of a compound required to inhibit 50% of cell growth), pertaining to the inhibition of growth by 50% for breast cancer cell lines. Their findings demonstrate that the CVAE can generate fingerprints, which, even if absent from the training data set, encapsulate the desired molecular properties. Furthermore, the versatility of their approach extends beyond just molecular generation; it holds potential for query expansion, enabling the search of databases using generated fingerprints as expanded queries.

The advancement of deep‐generative models tailored for graph‐structured data has ushered in novel perspectives on chemical synthesis. 22 A salient feature of these models is their potential to maneuver directly through the expansive and discrete landscape of chemical structures, therefore eliminating the need for resource‐intensive search processes. An innovative model in this category, introduced as molecular generative adversarial network (MolGAN) by De Cao and Kipf, 23 brings to light an implicit, likelihood‐free generative approach specifically designed for small‐molecular graphs. Contrary to prior likelihood‐based techniques that necessitated costly graph‐matching processes or specific node‐ordering heuristics, MolGAN ingeniously repurposes generative adversarial networks to interact directly with graph‐structured data. To enhance its generative prowess, 23 integrating MolGAN with a reinforcement learning objective, thereby it was fostered the creation of molecules enriched with particular chemical attributes. Empirical evaluations conducted on the renowned QM9 chemical database underscored MolGAN's competence, showcasing its ability to produce nearly 100% valid chemical compounds. This makes MolGAN particularly commendable, especially when juxtaposed against recent methodologies that are rooted in string‐based (simplified molecular input line entry system [SMILES]) representations or those that directly generate graphs through likelihood‐based approaches.

Another groundbreaking development in the field of chemical synthesis has been the introduction of methods to seamlessly transition between discrete and continuous representations of molecules. 24 A pioneering study by Gómez‐Bombarelli et al. 25 delineates an innovative methodology that facilitates not only the conversion of discrete molecular representations into a multidimensional continuous form but also the reverse transformation. Such a continuous framework has a myriad of applications. Not only does it enable the automatic generation of novel chemical entities through elementary operations in the latent space, such as decoding random vectors, slight perturbations of known structures, or even interpolations between distinct molecules, but also it ushers in the potential for gradient‐based optimization. This optimization harnesses the power of continuous representations, providing a more directed and efficient pathway to discover optimized functional compounds. As a testament to its versatility, Gómez‐Bombarelli et al. 25 showcased its efficacy in the realm of drug‐like molecules and further among molecules characterized by fewer than nine heavy atoms.

The domain of de novo molecular design has witnessed the inception of various sophisticated models aimed at generating chemical entities with specified properties. One such promising approach was proposed by Lim et al., 26 wherein they used a molecular generative model grounded on the CVAE framework. A distinct hallmark of their methodology is its specialization in modulating multiple molecular attributes concurrently. This is achieved by enforcing these properties directly upon the latent space of the model, ensuring a harmonized generation process. Validating the prowess and versatility of their approach, Lim et al. 26 conducted a proof‐of‐concept study in which their model adeptly generated drug‐like molecules, targeting an impressive array of five distinct properties.

In this study, we used a long‐short term memory (LSTM) variational autoencoder (VAE) architecture as the computational method for drug discovery. We would like to explain the concept of LSTM VAE as LSTM and VAE separately. First, LSTM 27 is a deep‐learning architecture that has been proposed as a remedy for the long‐term dependence issue of recurrent neural networks (RNNs). Unlike standard feedforward neural networks such as dense neural networks, 28 convolutional neural networks (CNNs), 29 and graph neural networks (GNNs), 30 LSTM has feedback connections as well. As a result of the feedback connections in LSTM, it is capable of learning sequence features from data, and thus LSTM is widely used for natural language processing (NLP) problems because those kinds of problems require learning grammatical rules and past‐linked information and understanding time series. As our data set is in the SMILES 31 format, which is developed for computers to understand and has its own grammatical rules and conventions, we thought an LSTM architecture would be suitable for the main task. Second, VAE 32 is a generative deep‐learning technique that can learn the probabilistic distribution underlying the data set and describes a latent space (also called embedding space) for the source data set. VAEs are a type of machine‐learning model that belong to the family of generative models. They are designed to learn the underlying probability distribution of a data set, enabling them to generate new data points that resemble the training data. VAEs achieve this by encoding the input data into a lower dimensional latent space and then reconstructing the data from this space. The “variational” aspect of VAEs comes from the use of probabilistic graphical models and the application of Bayesian inference, making them capable of handling a wide variety of data types. In the context of drug discovery, VAEs can be particularly powerful, as they enable the generation of novel molecular structures that maintain the properties of known compounds, therefore facilitating the exploration of chemical space for potential drug candidates. 32 The VAE technique can be used with different deep‐learning architectures, such as LSTM, CNN, and GNN. In this study, because we have a mainly generative task and a sequential data set, we combined the generative abilities of VAE and the learning abilities of LSTM from sequential data.

This article makes significant contributions to the field of drug discovery for HIV, aiming to accelerate and optimize the identification of potential therapeutic compounds. By leveraging innovative computational techniques, particularly the LSTM VAE architecture, we present a novel approach that holds great promise for combating HIV. To provide a clearer overview of our work, we have outlined our primary contributions as follows:

Overview of drug discovery processes. FDA, Food and Drug Administration.

## Section: METHODS

Appendix S1 contains an exhaustive discourse on the innovative deep‐learning algorithm devised for efficacious drug discovery targeting HIV, using an LSTM VAE. The procedural implementation of the research encompasses the distinct phases delineated as follows:

The SMILES representation and one‐hot encoding for benzene. 34 SMILES, simplified molecular input line entry system.

Computationally generated drugs by our long short‐term memory variational autoencoder model. SMILES, simplified molecular input line entry system.

## Section: METHODS › Data

In this study, we obtained data from the MoleculeNet database 33 for the training phase of the proposed generative deep‐learning model. We used text data in SMILES format to train our LSTM network. SMILES is a notation to describe the structure of chemical entities using American Standard Code for Information Interchange characters. There are 17 different data sets in the MoleculeNet database for different tasks, such as quantum mechanics, biophysics, and physiochemistry. The data set we used in our study consists of experimentally measured HIV replication inhibiting compounds.

The SMILES representation and one‐hot encoding for benzene. 34 SMILES, simplified molecular input line entry system.

## Section: METHODS › Data › Vectorization (Preprocessing)

In NLP applications, extracting meaningful information from the given text requires the text encoded into vectors such that the texts can share a similar context closely in a vector space; this technique is called vectorization. In this study, we used one‐hot encoding technique as the vectorization technique. To perform one‐hot vectorization in classic NLP tasks, each word in a sentence is represented as a one‐hot vector, and thus a vectorized sentence is represented as a matrix. As our data set is in SMILES format, we considered each character in SMILES as a one‐hot vector; therefore, each SMILES is represented as an array of one‐hot vectors or an M × N matrix (M is the embedding size, and N is the vocabulary size). As an example, Figure 2 from the study by Griffiths et al. 34 is a good example of one‐hot vectorization for SMILES data. In the context of one‐hot encoded SMILES, the term vocabulary refers to the particular group of tokens that are contained in the SMILES strings. Element, unique symbol, and bond representations are some of these tokens. For instance, the vocabulary would include the letters ['C', 'O', '=', '(', ')'] if we take the SMILES strings 'CCO' and 'C=C' into consideration. As a result, the model can describe and handle the various structural features found in the SMILES data. To explain further, the vocabulary would be restricted to ['1', 'c', 'n'] if our data set contained SMILES such as 'c1ccccc1' (benzene) and 'n1ccccc1' (pyridine). This is because of the specific characters presented in these SMILES representations. In the construction of our one‐hot matrixes for each of the SMILES, we defined the embedding size as 128 to not lose the valuable information from long SMILES and to add less padding to the shorter SMILES, and we have set the vocabulary size as 57, which is the same as the dictionary size of the data set. Therefore, each one‐hot vectorized matrix corresponding to each SMILES has the size of 128 × 57.

The SMILES representation and one‐hot encoding for benzene. 34 SMILES, simplified molecular input line entry system.

## Section: METHODS › Model validation

The detailed model development explanation can be found in Appendix S1. Figures S4–S7 depict the Kullback–Leibler (KL) divergence score, mean squared error (MSE), mean absolute error (MAE), and mean absolute percentage error (MAPE) of our proposed LSTM VAE model, respectively.

In our proposed model, KL divergence is used as a regularization term to encourage the model to learn the latent space that is more likely to produce samples that resemble the training data. It is obvious to say a steadily decreasing KL divergence score indicates that the model can learn a good representation of the latent space, where the distribution of latent variables is close to the assumed prior distribution.

MSE is a metric for evaluating regression models, including LSTM VAEs. It measures the average squared difference between the predicted and actual values. A steady decrease in the MSE of our proposed model indicates that the model's predictions are close to the actual values.

However, MSE is sensitive to outliers because it squares the difference, so it may not be the best metric to use in cases where there are extreme observations. Hence, we thought it was also important to consider the MAE metric, which is less sensitive to outliers compared with MSE because it does not square the difference. As can be seen in the performance graphics, the MAE metric also indicates stable learning along 250 epochs.

Finally, we examined how our model performed according to the MAPE metric during training. Unlike MSE and MAE, which are expressed in the same units as the original data, MAPE is expressed as a percentage and can be useful for understanding the magnitude of the error. In the supplementary figures, Figure S7 demonstrates the MAPE performance, in there we can easily observe that in the training and validation data, MAPE scores are very close to each other, which indicates good learning quality, and there is no overfit through training.

## Section: METHODS › Candidate drug generation and evaluation

After training our VAE model, we generated candidate SMILES. Figure 3 displays some of the computationally generated drugs and their interaction percentages, which were determined using another deep‐learning model that we developed and previously published. 12 All generated drugs in Figure 3 adhere to LRoF. In addition, the LD50 values of all compounds were above 2000 mg/kg, indicating low acute toxicity. The four molecules depicted in Figure 3 are among the generated drugs, with their interaction scores exceeding the 50% threshold. The given interaction scores are numerical values generated by our predictive model, 12 indicating the likelihood of effective interaction between the candidate compound and HIV, with higher scores representing a greater potential for efficacy.

Computationally generated drugs by our long short‐term memory variational autoencoder model. SMILES, simplified molecular input line entry system.

## Section: RESULTS AND DISCUSSION

The findings of this study demonstrated the effectiveness of using an LSTM autoencoder for computational drug discovery for HIV. The LSTM network was trained on a data set of SMILES‐encoded compounds, which were one‐hot encoded to create a matrix representation of each compound. The generative model obtained from the training phase was used to generate potential new drugs for HIV. Finally, the drug likeliness of the computationally generated drugs was confirmed according to LRoF.

The use of deep learning for drug discovery has become increasingly popular in recent years, as it provides a powerful tool for generating new drugs with desirable properties. The LSTM network used in this study is a type of RNN that is specifically designed for processing sequential data, such as SMILES‐encoded compounds. The LSTM network can capture long‐term dependencies in the data, which is essential for identifying the complex relationships between molecular structure and drug activity.

The one‐hot encoding technique used in this study is a widely used approach for encoding categorical data. In NLP applications, one‐hot encoding is used to represent words as vectors, where each dimension represents a specific word in the vocabulary. In this study, each character in the SMILES sequence was represented as a one‐hot vector, which allowed the LSTM network to learn the relationships between different chemical groups and their impact on drug activity.

The results of this study showed that the LSTM autoencoder was able to achieve an accuracy of 92% during training using a data set of 1377 compounds. The generative model obtained from the training phase was then used to generate potential new drugs for HIV. The results of this evaluation were promising, suggesting that the computationally generated drugs may have potential therapeutic effects. To provide a comprehensive overview of our model's performance, we analyzed the distribution of predicted interaction scores for the generated molecules. Specifically, we highlighted the proportion of molecules that achieved interaction scores above the 0.9 threshold, showcasing the model's ability to generate compounds with high predicted efficacy against HIV.

Finally, the drug likeliness of the computationally generated drugs was confirmed according to LRoF. This rule provides a set of guidelines for predicting the pharmacokinetic properties of potential drug candidates based on their molecular properties. The rule states that a drug candidate is likely to have good oral bioavailability and be well tolerated if it has a molecular weight of less than 500 Da, a log P value less than 5, no more than five hydrogen bond donors, and no more than 10 hydrogen bond acceptors. The fact that the computationally generated drugs satisfied LRoF suggests that they have the potential to be developed as new drugs for HIV.

## Section: RESULTS AND DISCUSSION › Limitations and future studies

Although our study provides promising results for computational drug discovery for HIV, there are several limitations that need to be acknowledged.

First, the accuracy of our model is dependent on the quality and quantity of the training data. In this study, we used a data set of 1377 compounds to train our LSTM autoencoder model. Although this data set is relatively large, it is possible that a larger data set could lead to even more accurate generations. In addition, the quality of the data set may also affect the accuracy of the model. Second, although this evaluation method is prevalent in computational drug discovery, it cannot replace in vitro or in vivo testing. Although we highlighted the uniqueness of the generated compounds based on existing compound databases, we acknowledge that a more detailed similarity analysis would contribute to a deeper understanding of the model's performance. To calculate similarity/diversity between generated drugs and the drugs in the training data set, a Tanimoto coefficient would provide a valuable layer of analysis. 35 Therefore, further testing is necessary to confirm the effectiveness of the computationally generated drugs. Third, our model only considered LRoF as a measure of drug likeliness. Although this is a widely used rule in drug discovery, it is not the only factor that determines the success of a drug. Other factors such as toxicity, pharmacokinetics, and pharmacodynamics should also be considered in future studies. Finally, our study focused specifically on HIV drug discovery. Although the LSTM autoencoder model can be applied to other drug discovery efforts, the specific features of the target disease or condition must be considered when developing the model.

## Section: CONCLUSION

In conclusion, the development of our proposed generative AI model, based on the LSTM VAE architecture, has demonstrated the remarkable potential of computational drug discovery in revolutionizing the drug development process. By leveraging the capabilities of this model, we have showcased the ability to discover candidate compounds with desired properties for combating HIV. The application of advanced computational tools and techniques has allowed us to screen a vast number of compounds in a remarkably short period, enabling the identification of potential drug candidates in a more efficient and cost‐effective manner. Also, the ProTox‐II toxicity prediction program, 17 which uses computational models to foretell the toxicity of chemicals to aquatic organisms, was used in this study. All of the candidate drugs put forth in our study passed all 17 ProTox‐II toxicity tests, and none of them had an LD50 value of less than 2000 mg/kg, which denotes minimal acute toxicity. Furthermore, our study highlights the significant role of computational methods in optimizing the structures of potential drug candidates. By leveraging the power of the LSTM VAE, the proposed model could show a potential for enhanced efficacy and safety after clinical tests are performed. Although challenges remain, such as the accuracy of computational models and the need for experimental validation, our study serves as a testament to the potential of computational drug discovery to revolutionize the development of therapeutics. Through continued research and development, including the refinement of algorithms and the integration of experimental validation, the accuracy and reliability of computational models can be further enhanced.

## Section: AUTHOR CONTRIBUTIONS

M.K., F.U., and N.K. wrote the manuscript. M.K. and F.U. designed the research. M.K. and F.U. performed the research. M.K. analyzed the data. F.U. and N.K. contributed new reagents/analytical tools.

## Section: CONFLICT OF INTEREST STATEMENT

The authors declared no competing interests for this work.

## Section: Supporting information

Appendix S1.

Click here for additional data file.

## Section: Text

Kutsal M, Ucar F, Kati N. Computational drug discovery on human immunodeficiency virus with a customized long short‐term memory variational autoencoder deep‐learning architecture. CPT Pharmacometrics Syst Pharmacol. 2024;13:308‐316. doi: 10.1002/psp4.13085

## Section: DATA AVAILABILITY STATEMENT

The source code and the data of this study are shared in the given GitHub repository: https://github.com/McahitKutsal/lstm‐drug‐discovery

## Section: Associated Data

Appendix S1.

Click here for additional data file.

## Section: Associated Data › Supplementary Materials

Appendix S1.

Click here for additional data file.

## Section: Associated Data › Data Availability Statement

The source code and the data of this study are shared in the given GitHub repository: https://github.com/McahitKutsal/lstm‐drug‐discovery


---

# Deep Learning and Drug Discovery for Healthy Aging

- **Authors:** Peter Wang, Dean Ho
- **Issuer:** ACS central science
- **Type:** Scientific article
- **Published:** 2023-10-17
- **Language:** en
- **DOI:** 10.1021/acscentsci.3c01212
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37901176/
- **Licence:** CC-BY

## Section: Text

Osteoporosis is a globally prevalent disorder that leads to substantial increases in mortality, morbidity, and healthcare costs.1 In the United States alone, approximately 1.5 million osteoporosis-driven fractures have led to hundreds of thousands of hospitalizations annually. In parts of the world characterized by rapidly aging populations and superaged societies, as high as 30% of women aged 40 and up are estimated to be affected by osteoporosis.2 Given the rising life expectancy of countries in Asia Pacific, osteoporotic and other bone disorders merit major attention in order to address healthcare costs and patient mortality and morbidity. One key strategy to address these issues is the rapid development of safe and effective therapies.

Toward the development of potential interventions for bone diseases, a long-standing barrier in bone tissue engineering—from fundamental research to patient-level applications—has been the identification of clinically actionable agents to maintain the stemness of bone marrow mesenchymal stem cells (BMMSCs). Due to the role of BMMSCs in regeneration and homeostasis of bone tissue, preserving stemness has been long sought after in the development of effective treatments for bone diseases. Prior approaches have involved hormone or bone resorption treatment.3,4 However, these strategies do not address the core issue of stemness. Other approaches that address stemness included cytokine therapy and gene editing.5,6 Beyond rapidly developing bone disease treatment options that are safe and effective, their accessibility and affordability remain key attributes that also need to be considered.

In this issue of ACS Central Science, Liu, Li, Xie, and co-workers have harnessed a deep learning (DL) platform to rapidly pinpoint a potential drug candidate for osteoporosis.7 Specifically, this study prioritized dihydroartemisinin (DHA), a broadly available natural compound to maintain desired differentiation and self-renewal properties in vitro and bone density and architectural integrity in vivo. The DL platform used in this study, termed the deep learning efficacy prediction system (DLEPS), functions by harnessing data that correlates drug interactions with the transcriptome. This information can then be used for additional assessment against differentially expressed genes (DEGs) to produce an efficacy score to prioritize drug testing. To provide further insight into the development of this efficacy score, this study used RNA sequencing to assess which DEGs, measured from day 1 postnatal to 6–8-week-old adult mice, were downregulated during the aging process. The DLEPS produced a ranking from a 12,328-gene set to predict DEG reversal in order to preserve stemness. From this data set, a bone score was generated by integrating DEG up-/downregulation analysis in order to prioritize compounds for further evaluation.

In this study, DLEPS prediction identified DHA as a promising agent for further evaluation. The administration of 0.1 μm DHA to human BMMSCs (hBMMSCs) increased OCT4 and SOX2 expression. Of note, adding DHA to the culture media sustained increased OCT4 and SOX2 expression for five passages. This was accompanied by Ki67 staining, which further demonstrated improved hBMMSC proliferation when treated with DHA. In addition, to assess hBMMSC capacity for osteogenic differentiation, DHA administration resulted in enhanced mineralization (alizarin red staining/ARS) as well as alkaline phosphatase (ALP) activity compared to controls. To demonstrate DHA-driven reduction of adipogenic differentiation capacity, Oil red O-labeling revealed a reduced lipid droplet presence compared to controls.

To acquire deeper insights into the mechanistic basis for DHA-enhanced stemness, the team further examined the histone deacetylase (HDAC) and histone acetyltransferase (HAT) enzymes, as the levels of these enzymes were substantially differentiated from nonosteoporotic mice. Given the previously reported role of compounds similar to DHA in H3K9 (Histone 3 Lysine 9) upregulation of acetylation in other cell types, this study then evaluated the role of DHA specifically in regulating the genes that drive stemness in a preclinical setting.8 Among a series of HAT (GCN5, P200, PCAF) and HDAC (SIRT6, HDAC1, HDAC2, and HDAC8) enzymes, GCN5 expression increased 1.5× following DHA administration alongside increased H3K9 acetylation in osteoporotic BMMSCs, which matched in vitro findings. Furthermore, knockdown of GCN5 after sustained DHA administration (Passage 8) reduced the expression of stemness markers and capacity for osteogenesis, and DHA administration in these cells did not increase stemness marker expression.

To further increase the localization of DHA delivery to the bone, the team utilized mesoporous silica nanoparticles (MSNs) conjugated to alendronates (ALNs), which target bone tissue, to form MSN-ALN vehicles. When loaded with DHA, the MSN-ALN vehicles markedly improved bone architecture and retention of bone mass in osteoporotic mice compared to the sham cohort. Of note, since ALNs have been previously shown to mitigate osteoclast functionality, it is believed that the integration of MSN-ALN vehicles with DHA collectively even further impeded osteoclast activity. Collectively, the MSN-ALN vehicles loaded with DHA also substantially enhanced osteoblast functionality over unmodified MSN-ALN, demonstrating a promising path forward for the continued evaluation of DHA-loaded nanoparticles.

This work represents important validation for the role of DL in rapid drug discovery. In evaluating the broader role of artificial intelligence (AI)-driven therapy, it is important to note that drug discovery is one segment that resides within a larger drug optimization workflow that includes drug development—involving the design of drug combinations among other factors—and drug dosing. Taken as a complete workflow, these three segments can profoundly impact the clinical actionability and sustained response of patients to single agent or combination regimens (Figure 1).9

Expanding the use of DL within the larger context of AI to rapidly discover and recommend compounds for further evaluation has opened a gateway to a wider array of potential drug candidates (Figure 1).10 To properly steward these promising candidates forward, harnessing true optimization to find suitable partner therapies for combination regimens may be essential. This has been especially true for other indications such as oncology, cardiac diseases, diabetes, infectious diseases, and beyond. Natural compounds are receiving increased attention due to AI/DL-predicted applications toward disease management.11 As they are evaluated further, toward preclinical and potential clinical studies, it is likely that combination regimens will be needed to realize their full potential for clinically significant efficacy. While mechanism-of-action (MOA) and drug sensitivity assays have traditionally been used for combination design, the use of AI may uncover unpredictable or unforeseen interactions that can markedly increase treatment efficacy. To achieve this outcome, a large parameter space needs to be explored, as even a 10-drug set with each drug studied at 10 dose levels can lead to billions of possible permutations. This would preclude conventional, iterative experiments. Fortunately, emerging AI-based strategies can interrogate parameter spaces of this magnitude by pairing prospective experiments with established optimization methods to yield globally optimized drug combinations. Examples include recent work to address SARS-CoV-2 drug development, blood cancers in patients, and antimicrobial resistance.12−15 In addition, a newly developed DL model, DrugCell, simulates the response of human cancer cells when treated with therapeutics and subsequently predicts synergistic drug combinations that may improve treatment outcomes.16

Following the drug development segment of the workflow, preclinical and clinical drug dosing optimization follows. Importantly, once DL-discovered drug candidates are validated and combination regimens are developed, optimized dosing can have a profound effect on the clinical efficacy of the candidates. Traditional approaches have defined dose optimization through dose escalation until a maximum tolerated dose (MTD) is reached. However, emerging strategies have shown that truly optimized dosing is a dynamic process, and treatment should evolve alongside the patient. Specifically, dose adjustments should potentially be modulated longitudinally in order to sustain the best outcomes possible for a patient. This is due to the observations that drug synergy is dose-dependent, time-dependent, and subject to individualized patient responses. In the case of the work reported by Liu, Li, Xie, and co-workers, there may be interactions between the MSN-ALN vehicles and DHA that collectively improve the antiosteoporotic outcomes. Recent work has shown that substantial dose reductions can maintain stable disease in human solid cancer treatment.17 In addition, evolutionary dynamics has been used to reduce total drug doses needed for human prostate cancer therapy.18 Given the aging-related nature of osteoporosis and other bone diseases, modulated dosing in accordance with physiological and disease changes that inevitably take place during chronological age progression may help prolong efficacy. The work of Liu, Li, Xie, and co-workers can potentially play an important role toward accessible and sustained intervention against age-related diseases to align healthspan with lifespan—so that the duration of a person’s health matches their duration of life.

Studies such as the work reported by Liu, Li, Xie, and co-workers represent a promising step in advancing AI/DL-identified compounds toward clinically relevant validation. In particular, expanding the repertoire of potential agents to address disorders that increase in prevalence with aging enhances the range of interventional strategies available for increasing healthspan alongside lifespan. These are particularly critical needs in many parts of the world today. In this context, when promising drug candidates are evaluated as part of an integrated workflow of drug discovery, development, and dosing, this brings to role of AI in the comprehensive and sustained optimization of patient treatment closer to validation.


---

# Deep Learning Approach Based on Transcriptome Profile for Data Driven Drug Discovery

- **Authors:** Eun-Ji Kwon, Hyuk-Jin Cha
- **Issuer:** Molecules and cells
- **Type:** Scientific article
- **Published:** 2023-01-20
- **Language:** en
- **DOI:** 10.14348/molcells.2023.2167
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36697239/
- **Licence:** CC-BY-NC-SA

## Section: Text

Once a target protein has been associated with the onset and progression of a certain disease, the initial ‘hit’ compounds are largely discovered by either high-throughput screening (HTS) or chemical design based on the target protein structure (Schenone et al., 2013). This process, which is commonly referred to as target-based drug discovery (TDD), has been quite successful. However, the TDD approach requires ‘target identification,’ which demands tremendous efforts during the pre-discovery process. However, once a cellular platform to explore pathogenic phenotypes is established (e.g., disease-in-a-dish from patient-derived stem cells), HTS (or content screening) can be performed to identify candidate compounds to alleviate or reverse the pathogenic phenotypes (Schenone et al., 2013). The recent advances in phenotype-based drug discovery and gene editing technology have enabled the establishment of isogenic pairs of patient-derived stem cells (Park et al., 2022). Disease-induced transcriptome profiles are not only the consequences of disease but can also provide clues regarding its potential causes (i.e., the mechanism of disease onset). Therefore, in-depth analyses of transcriptome profiles from disease models often provide crucial insights into the mechanisms of pathogenesis and enable the discovery of valuable target proteins (Casamassimi et al., 2017). Furthermore, a growing number of studies have incorporated disease-associated transcriptome signatures into the drug discovery process (Kwon et al., 2019). For example, the connectivity Map (CMap) approach can be used to inversely match drug- or compound-induced transcriptome profiles with disease signatures (Kwon et al., 2020).

Zhu et al. (2021) developed a deep learning-based efficacy prediction system (DLEPS) model to facilitate drug discovery. Unlike CMAP, where chemically inducible changes in transcriptional profiles (CTPs) are experimentally assessed, the DLEPS model is a deep neural network that is trained using input from simplified molecular-input line-entry system (SMILES) data (i.e., a line-based specification for the description of chemical structures) and CTPs from the L1000 project (Subramanian et al., 2017), an extended transcriptome profile of chemical or genetic perturbations. First, each small molecule, which is first represented by SMILES, is vectorized into a single array and projected into a two-dimensional latent space. This latent space is a virtual space that is further decoded into 978 landmark gene signatures. These landmark genes, which are converted into 12,328 genes via linear transformation, are used as input to perform gene set enrichment analysis based on the ranks of their expression levels. Through DLEPS, the authors virtually produce a correlation network between the chemical structure of small molecules and putative gene expression signatures. Therefore, this DLEPS algorithm allows for the establishment of links between gene signatures, pathogenic responses, and specific small molecules.

To validate this system, the authors first attempted to predict putative anti-obesity molecules based on 150 unbiased up- and down-regulated genes identified by comparing brown adipose tissue (BAT) to white adipose tissue (WAT) using a library containing a total of 3680 small molecules (D3680 library: including U.S. Food and Drug Administration approved drug or natural compounds). The four predicted molecules, including isoginkgetin, chelidonine, loureirin B, and chikusetsusaponin IV, were tested in a high-fat diet mouse model to confirm their weight reduction effect. Interestingly, such weight loss is achieved through the activation of genes associated with BAT and adaptive thermogenesis without significant alterations in food intake or daily exercise activity, suggesting the potential of these compounds as novel anti-obesity drug candidates. Therefore, the authors concluded that treating the mice with the natural compounds predicted by the DLEPS model promotes the browning of WAT. Similarly, this model was applied to identify candidate drugs for the treatment of hyperuricemia (HUA), a chronic metabolic disorder characterized by the occurrence of inflammation and renal fibrosis. Based on the corresponding gene signature, the authors calculated an HUA score and inflammation/fibrosis score as the inputs for the DLEPS model and identified four candidate compounds out of the D3680 library. Experimental validation with an HUA mouse model demonstrated that perillene, a natural compound derived from ‘Perilla frutescens,’ could effectively lower blood uric acid levels and this therapeutic effect was similar to that of commercial anti-HUA drugs such as allopurinol, benzbromarone, topiroxostat, and febuxostat. Other HUA symptoms such as blood urea nitrogen, serum creatinine, alanine aminotransferase (ALT), aspartate aminotransferase (AST), kidney index (ratio of kidney and body weight), and the level of fibrosis of renal tubules were also ameliorated by perillene treatment. The authors also reported that perillene inhibits xanthine oxidase by direct interaction, which was likely the mode of action of this compound. A similar approach was adopted to identify drug candidates for nonalcoholic steatohepatitis (NASH) from a clinical trial database including 11,293 compounds (D11294 library). The two predicted compounds trametinib and GI02002 effectively reduced the level of ALT, AST, and triglyceride levels in a NASH mouse model, which was established by feeding the mice with a methionine-and choline-deficient diet. Trametinib is an inhibitor of MEK1 and impedes ERK1/2 activation, which was previously demonstrated to inhibit glucose and lipid metabolism. The authors also examined the effectiveness of other ERK inhibitors such as ravoxertinib and FR180204.

The continuous development of large-scale datasets of drug (or small molecule)-induced transcriptomic patterns (i.e., drug-omics datasets) will thus enable the creation of learning models to link small molecules to gene signatures associated with specific diseases. In turn, this would greatly promote the development of data-driven drug discovery. The refinement of deep learning models also poses several important challenges (Zhao and So, 2019) and therefore additional efforts are needed to experimentally validate these models. The accuracy of a deep learning model greatly depends on the size of the training dataset. However, current datasets from compounds and transcriptomes of disease models are relatively insufficient. Therefore, alternative approaches such as ‘transfer learning’ could enable the development of deep learning-based drug discovery (Chiu et al., 2021) by minimizing overfitting and uncertainty.

The study by Zhu et al. (2021) successfully validated the efficacy of drugs and natural compounds predicted by their deep learning model based on disease-specific gene signatures. Considering the complexity of the molecular mechanisms that underly disease onset and progression, disease-specific gene signatures must be precisely characterized and defined to avoid overlap with other similar diseases for further clinical applications. Various deep learning systems are also being extensively developed to interpret biological networks such as complex protein-protein interactions and signaling cascades (Muzio et al., 2021). Therefore, highly sophisticated deep learning systems for drug prediction could be developed by training the algorithms with disease-specific gene signatures and biological network datasets.


---

# Deep learning driven de novo drug design based on gastric proton pump structures

- **Authors:** Kazuhiro Abe, Mami Ozako, Miki Inukai, Yoe Matsuyuki, Shinnosuke Kitayama, Chisato Kanai, Chiaki Nagai, Chai C Gopalasingam, Christoph Gerle, Hideki Shigematsu, Nariyoshi Umekubo, Satoshi Yokoshima, Atsushi Yoshimori
- **Issuer:** Communications biology
- **Type:** Scientific article
- **Published:** 2023-09-19
- **Language:** en
- **DOI:** 10.1038/s42003-023-05334-8
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37726448/
- **Licence:** CC-BY

## Page 1 (Section: Deep learning driven de novo drug design based on gastric proton pump structures)

ARTICLE
Deep learning driven de novo drug design based on
gastric proton pump structures
Kazuhiro Abe
1,2,3✉, Mami Ozako2, Miki Inukai2, Yoe Matsuyuki2, Shinnosuke Kitayama2, Chisato Kanai4,
Chiaki Nagai2, Chai C. Gopalasingam
5, Christoph Gerle
5, Hideki Shigematsu
6, Nariyoshi Umekubo
2,
Satoshi Yokoshima
2✉& Atsushi Yoshimori
7✉
Existing drugs often suffer in their effectiveness due to detrimental side effects, low binding
afﬁnity or pharmacokinetic problems. This may be overcome by the development of distinct
compounds. Here, we exploit the rich structural basis of drug-bound gastric proton pump to
develop compounds with strong inhibitory potency, employing a combinatorial approach
utilizing deep generative models for de novo drug design with organic synthesis and cryo-EM
structural analysis. Candidate compounds that satisfy pharmacophores deﬁned in the drug-
bound proton pump structures, were designed in silico utilizing our deep generative models, a
workﬂow termed Deep Quartet. Several candidates were synthesized and screened according
to their inhibition potencies in vitro, and their binding poses were in turn identiﬁed by cryo-
EM. Structures reaching up to 2.10 Å resolution allowed us to evaluate and re-design com-
pound structures, heralding the most potent compound in this study, DQ-18 (N-methyl-4-
((2-(benzyloxy)-5-chlorobenzyl)oxy)benzylamine), which shows a Ki value of 47.6 nM.
Further high-resolution cryo-EM analysis at 2.08 Å resolution unambiguously determined the
DQ-18 binding pose. Our integrated approach offers a framework for structure-based de novo
drug development based on the desired pharmacophores within the protein structure.
https://doi.org/10.1038/s42003-023-05334-8
OPEN
1 Cellular and Structural Physiology Institute, Nagoya University, Nagoya, Aichi 464-8601, Japan. 2 Graduate School of Pharmaceutical Sciences, Nagoya
University, Nagoya, Aichi 464-8601, Japan. 3 Center for One Medicine Innovative Translational Research (COMIT), Nagoya University, Nagoya, Aichi 464-8601,
Japan. 4 INTAGE Healthcare, Inc., 3-5-7, Kawaramachi Chuo-ku, Osaka 541-0048, Japan. 5 RIKEN SPring-8 Center, Kouto, Sayo-gun, Hyogo 679-5148, Japan.
6 Japan Synchrotron Radiation Research Institute (JASRI), SPring-8, 1-1-1 Kouto, Sayo, Hyogo 679-5148, Japan. 7 Institute for Theoretical Medicine, Inc., 26-1,
Muraoka-Higashi 2-chome, Fujisawa, Kanagawa 251-0012, Japan. ✉email: kabe@cespi.nagoya-u.ac.jp; yokosima@ps.nagoya-u.ac.jp; yoshimori@itmol.com
COMMUNICATIONS BIOLOGY | (2023) 6:956 | https://doi.org/10.1038/s42003-023-05334-8 | www.nature.com/commsbio
1
1234567890():,;

## Page 2 (Section: Results and discussion)

T
o better meet medical needs, improvement of existing
drugs’ efﬁcacy is highly desired due to problems caused by
harmful side effects, poor pharmacokinetics or low binding
afﬁnity. Designing new compounds by derivation, sometimes
prevented by patent restriction, and phenotype screening often
leads to unsatisfactory results. Recent advances in structural
biology eases access to drug bound protein structures. However,
even when available, structural data on the drug-target interaction
remains hard to exploit for the design of novel compounds. To
this end, establishing a framework that enables the production of
a compound with a radically different chemical skeleton and
effectiveness is required, which we attempt to address here by
exploiting the accumulation of structural and functional infor-
mation of drug-bound gastric proton pump1,2.
Painful symptoms of acid-related gastric diseases such as peptic
ulcers or gastroesophageal reﬂux disease are associated with dis-
orders of the gastrointestinal tract3. Gastric mucosal injury due to
continuous
use
of
nonsteroidal
anti-inﬂammatory
drugs
(NSAIDs)4 or gastrin-producing tumors may also cause peptic
ulcers5. Current therapies to treat these conditions either prevent
the stimulation of parietal cells by antagonizing histamine H2
receptors6 or inhibit the ﬁnal step in acid production by targeting
the gastric proton pump, H+,K+-ATPase. Eradication of Heli-
cobacter pylori, the main cause of gastric ulcers and gastric cancer,
has been accomplished by the suppression of gastric acid secre-
tion in combination with antibiotic treatment7. The molecular
targets of acid suppressants, H+,K+-ATPase, is a gastric proton
pump that mediates H+ export in exchange for luminal K+ across
the parietal cell membrane accompanied by ATP hydrolysis8,9.
Like other P-type ATPases10,11, vectorial cation transport is
accomplished by the cyclical conversion of the pump consisting
of four cornerstone states; E1 −E1P −E2P −E2, according to the
so-called Post-Albers scheme12, which describes alternating
access
and
afﬁnity
for
the
H+
and
its
counterion
K+.
Cytoplasmic-facing E1 and luminal-facing E2P states show high
afﬁnity for H+ and K+, respectively13. H+,K+-ATPase consists of
two subunits. The catalytic α-subunit (100 kDa) comprises 10
transmembrane (TM) helices in which the cation and inhibitor
binding sites are located and three cytoplasmic domains (the
nucleotide-binding (N), phosphorylation (P), and actuator (A)
domains) executing ATP hydrolysis and autophosphorylation. An
accessory β-subunit (35 kDa) has a single TM helix with a short
N-terminal tail and an ectodomain with six N-linked glycosyla-
tion sites, and is required for the folding of the complex and
membrane trafﬁcking14.
Proton pump inhibitors (PPIs) such as omeprazole have been
utilized for acid suppression. The PPI drug itself is a prodrug,
requiring acid activation to irreversibly inhibit H+,K+-ATPase by
forming a covalent bond with its Cys813 residue15. However,
given its relatively short plasma half-life and requirement for an
acidic pH to convert the prodrug to the active compound, con-
siderable effort has been expended to develop different types of
H+,K+-ATPase inhibitors. The K+-competitive acid blockers
(P-CABs) differ from the PPIs in that they are not dependent on
acid activation, are rather stable in the acidic canaliculus, and
bind directly to the proton pump, thereby providing a more rapid
onset and better inhibition of acid secretion3. The binding of
omeprazole and P-CABs is mutually exclusive, indicating these
drugs share an overlapping binding site16. They are currently in
clinical use in some Asian countries. Although the prototypic P-
CAB, the imidazo[1,2-a]pyridine derivative SCH2808017, is
unsuitable for clinical use due to its hepatotoxicity, its benzimi-
dazole derivative tegoprazan18 was approved in 2018 in South
Korea. Besides SCH28080-related compounds, chemically distinct
pyrimidine-based revaprazan19 (approved for clinical use in 2007
in South Korea) and pyrrole derivative vonoprazan20 (approved
for clinical use in 2015 in Japan), have been developed (Supple-
mentary Fig. 1). These P-CABs are proving to be successful,
providing rapid and reliable cures for acid-related gastrointestinal
diseases. On the other hand, the relationship between long-term
administration of PPI or P-CAB and their effects on intestinal
microﬂora21, interstitial nephritis22 and gastric cancer23 have also
received attention. Therefore, further pharmacokinetic improve-
ment and increased binding afﬁnity is desired to reduce the
required drug dosage. Furthermore, the availability of alternative
compounds is expected to broaden the treatment options and
expand its clinical use. Because all the above drugs have been
developed based on phenotypic screening, there is room for
further improvement, speciﬁcally, the development of novel drugs
using structure-based rational design.
So far we have reported X-ray crystal and cryo-EM derived
structures of H+,K+-ATPase complexed with seven different P-
CABs;
SCH280802,
vonoprazan2,
BYK9924,
tegoprazan1,
PF037165561,
soraprazan1
and
revaprazan1
(Supplementary
Fig. 1). All P-CABs bind to the luminal-facing cavity leading to
the cation-binding site in the luminal-open E2P state, and phy-
sically block K+-entry to the cation-binding site, hence prevent-
ing luminal gate closure which is induced by K+-binding to the
cation-binding site. The binding mode of some of P-CABs are,
however, signiﬁcantly distinct; while SCH28080 (Fig. 1b, c) and
its related compounds bind around the entrance of the luminal
cavity, vonoprazan (Fig. 1d) and to some extent revaprazan binds
more deeply toward the cation-binding site, indicating there are
multiple pharmacophores in the P-CAB binding site. To date,
however, not a single P-CAB satisﬁes all these pharmacophores.
Therefore, if a compound that satisﬁes the greatest common
denominator of these pharmacophores can be created, it is
expected to be highly potent in gastric acid suppression.
Deep generative models (DGMs) have been successfully
applied in various ﬁelds, including image processing25, language
translation26 and the generation of chemical structures for drug
development27–30. Despite its remarkable advances, most of the
previous studies utilizing DGMs for compound generation
focused on optimizing molecular properties such as logP (lipo-
philicity), QED (Quantitative Estimate Drug-likeness score)31
and SA (Synthetic Accessibility) score calculated on a 2D repre-
sentation of the molecule32, and the application of DGMs to the
actual drug discovery for the speciﬁc target is surprisingly limited
so far28,30. Given the potential of DGMs to optimize compound
chemical structures based on a biological target derived phar-
macophore 3D coordinates, the appropriate application of DGMs
is expected to signiﬁcantly accelerate drug discovery.
Here, we demonstrate the approach by focusing on improving
gastric proton pump blockers, where our deep learning-driven
drug design based on the desired pharmacophores in the target
protein structure (Fig. 1a) was capable of suggesting useful
compounds with distinct chemical skeletons. Subsequent rounds
of candidate selection, synthesis, in vitro drug screening and
high-resolution cryo-EM structure analysis allows for successful
de novo drug design resulting in a greatly facilitated process of
drug discovery.
Results and discussion
De novo design of P-CABs based on the desired pharmaco-
phores. Based on the reported structures of the H+,K+-ATPase
complexed with different P-CABs, we tried to deﬁne the vital
pharmacophores for P-CAB binding. SCH28080, known as an
ancestor compound of P-CABs, and its related compounds
(BYK99, PF-03716556 and soraprazan) or a drug (tegoprazan)
(Supplementary Fig. 1), share a similar binding site at the
entrance of the luminal cavity leading to the cation-binding site
ARTICLE
COMMUNICATIONS BIOLOGY | https://doi.org/10.1038/s42003-023-05334-8
2
COMMUNICATIONS BIOLOGY | (2023) 6:956 | https://doi.org/10.1038/s42003-023-05334-8 | www.nature.com/commsbio

## Page 3 (Section: Results and discussion)

where Rb+ is bound as a congener of K+ in the SCH28080-bound
form (Fig. 1b, c, e). The imidazo[1,2-a]pyridine ring of SCH28080
is bound to Tyr799 via π-π interaction33, and its benzyl group
makes hydrophobic contacts with residues in TM1 (Ala123),
TM2 (Asn138) and TM4 (Val331, Ala335)34. On the other hand,
vonoprazan has a unique chemical structure and harbors thus far,
to the best of our knowledge, the most potent in vitro inhibition
activity amongst P-CAB. Its methylamino group reaches near the
cation-binding site located deep in the conduit thus preventing
K+-binding, while its pyridine ring keeps Tyr799 at the luminal
entrance (Fig. 1d, e)2. A recently reported revaprazan bound
structure
shows
the
intermediate
binding
pose
between
SCH28080-type compounds and vonoprazan; while the pyr-
imidine and ﬂuorophenyl rings of revaprazan overlap the binding
pose of SCH28080, its tetrahydroisoquinoline moiety is accom-
modated in the middle of conduit and faces toward the cation-
binding site1.
In order to design unique P-CABs by “Deep Quartet” (DQ), a
de novo design workﬂow for generating molecules with a desired
pharmacophore (Fig. 1a), we deﬁned multiple features for
pharmacophores,
based
on
the
above-described
structural
information (Fig. 1e and Supplementary Fig. 2).
(I)
A cationic and hydrogen bond donor pharmacophore
feature near the cation-binding site: the amino group of
vonoprazan binds close to the K+-binding site where three
glutamates (Glu343, Glu795 and Glu820) are located.
(II)
A hydrophobic pharmacophore feature between TM1 and
TM4, near the residue Ala123: the terminal hydrophobic
group of SCH28080-related P-CABs binds at this position;
the Ala123Val mutant shows signiﬁcantly reduced afﬁnity
for SCH28080 and related compounds, but almost no effect
for vonoprazan2.
(III)
An aromatic pharmacophore feature close to Tyr799: the
aromatic group of all P-CABs interacts with the side chain
of Tyr799, and mutation of this residue (Tyr799Ala)
severely reduces the apparent afﬁnity of all P-CABs1,2,34.
(IV)
A hydrophobic pharmacophore feature connecting I and
III: the conduit connecting cation-binding site and luminal
solution
is
mostly
hydrophobic;
the
aromatic
ﬁve-
membered ring of vonoprazan, and the hydrophobic
tetrahydroisoquinoline moiety of revaprazan occupy this
position.
These four pharmacophore features (I–IV) were set alongside
the crystal structure of SCH28080- (PDB ID: 5YLV) or
vonoprazan-bound (PDB ID: 5YLU) forms, and we subsequently
generated candidate compound structures by DQ. After iterative
processing, compounds having a methylamino group were
extracted. Although the two crystal structures used as templates
Fig. 1 De novo drug design based on the desired pharmacophores. a Workﬂow of “Deep Quartet”. See main text and “Methods” for details. b Crystal
structure of the gastric H+,K+-ATPase complexed with SCH28080 (PDB ID: 5YLV, gray) in ribbon representation, viewed parallel to the membrane plane
with its luminal-side facing upwards. c, d Close-up view of the P-CAB-binding site (indicated as a red box in b). Clipped cross section of the luminal-facing
conduit (surface) of SCH28080- (gray) and vonoprazan- (PDB ID: 5YLU, wheat) bound forms from the viewpoint similar to (b). Positions of P-CAB binding
are indicated as purple or pink surface for SCH28080 or vonoprazan, respectively. e Deﬁned pharmacophore features (I–IV, see text for details) on the
luminal-facing cavity of the H+,K+-ATPase structure. Navy and yellow ovals, and blue triangle indicates pharmacophore features with aromatic,
hydrophobic or cationic properties, respectively. f Binding poses of candidate compounds in the template structure (5YLV) calculated by Deep Quartet.
g Same as (f) but with vonoprazan-bound form used as a template (5YLU). The most constrained positions of the lumina-facing conduit in each structure
are indicated as dotted lines and blue arrows, with accompanying distance in Å. Two distinct binding modes of candidates from vonoprazan-bound form
are displayed separately in (h) and (i). In (c, d, f–i), TM2 is omitted for clarity.
COMMUNICATIONS BIOLOGY | https://doi.org/10.1038/s42003-023-05334-8
ARTICLE
COMMUNICATIONS BIOLOGY | (2023) 6:956 | https://doi.org/10.1038/s42003-023-05334-8 | www.nature.com/commsbio
3

## Page 4 (Section: Alkyne-backbone of DQ-02 and related compounds)

are almost identical (RMSD for Cα atoms = 0.755 Å), at least
same
conformation,
to
our
surprise,
generated
candidate
compounds from each template structures are distinct. Char-
acteristic compound structures with an alkyne moiety were
generated when SCH28080-bound structure is used as a template
(Fig. 1f and Supplementary Fig. 2 Type A). Likewise, when we set
two aromatic rings at pharmacophore feature III position (akin to
the heterocyclic ring structure of the imidazo[1,2-a]pyridine ring
of SCH28080 is in mind) of the SCH28080-bound form, similarly
alkyne-connecting, but incorporating heteroaromatic ring struc-
tures were generated (Fig. 1f and Supplementary Fig. 2 Type B).
In contrast, aromatic-rich compounds were generated from the
vonoprazan-bound structure (Fig. 1g–i and Supplementary Fig. 2
Type C). DQ generated diverse compounds for each pharmaco-
phore type, among which 71, 10 and 181 compounds were
selected as candidates with pharmacophore scores (see “Meth-
ods”) above 0.90 (Supplementary Fig. 3). Synthetic accessibility
scores32 suggest that most of the DQ-generated candidates show
mean values of around 3, which is similar to the score for most
drug-like compounds available for clinical use, thus capable to
synthesize (Supplementary Fig. 3). From the suggested candidates
by DQ, several compounds were selected and synthesized
(Supplementary Fig. 4), and their inhibition potencies and
binding poses are characterized in the following sections.
Alkyne-backbone of DQ-02 and related compounds. From the
candidate compound structures with an alkyne moiety (Fig. 1f and
Supplementary Fig. 2) as a reference, we chemically synthesized sev-
eral compounds taking into account their synthetic feasibility. Because
most of the suggested compounds have various modiﬁcations, and
different functional groups were employed even for similar chemical
skeletons (Supplementary Fig. 2), we synthesized simple and repre-
sentative compounds after examining these candidates (Supplemen-
tary Figs. 3 and 4, see also Supplementary Data 2 for details), and then
evaluated their potency by measuring dose-dependence of ATPase
activity inhibition using H+,K+-ATPase-enriched membrane frac-
tions (Fig. 2a). Among them, although exhibiting lower apparent
afﬁnity than SCH28080 (IC50,SCH = 1.97 ± 0.12 μM), DQ-02 and DQ-
04 inhibit H+,K+-ATPase activity in a dose-dependent manner with
similar apparent afﬁnities (IC50,DQ02 = 39.9 ± 3.3 μM, IC50,DQ04 =
33.9 ± 3.8 μM), suggesting that halogen modiﬁcation to a benzene
ring does not make a large difference for the apparent inhibition
afﬁnity. Others showed lower apparent afﬁnity than DQ-02 (IC50s for
DQ-09: >2000 μM, DQ-14: >120 μM, DQ-15: 49.5 ± 4.9 μM, DQ-16:
89.4 ± 13.5 μM), and some compounds gave scattered values due to
low water solubility. Regardless of the low apparent afﬁnity of DQ-02,
its double reciprocal plot analysis (Supplementary Fig. 5) shows a
typical competitive inhibition pattern (estimated inhibition constant
(K i,DQ02) is 4.65 μM), suggesting that DQ-02 binds to the luminal-
facing cavity as other P-CABs do.
To determine the DQ-02 binding pose, we performed cryo-EM
analysis of H+,K+-ATPase, bound with DQ-02 and obtained a
structure at 2.10 Å overall resolution (Fig. 2b, Supplementary
Fig. 6 and Table 1). Counterintuitively, however, the EM density
map corresponding to DQ-02 was poorly deﬁned, and does not
account for a single binding pose of the compound (Fig. 2c and
Supplementary Movie 1). We therefore modeled two possible
conformations of DQ-02 in the binding cavity. In both binding
poses, the terminal secondary amine moiety reaches close to the
cation-binding site, as seen in the vonoprazan binding mode. Two
benzene rings are likely bound to the Tyr799 and Ala123 similar
to SCH28080 and related P-CABs. The structure of the alkyne
backbone may be too thin to stably bind in a single conformation
to the hydrophobic conduit, and the nearly symmetrical structure
of two benzene rings also allows for multiple binding poses of
DQ-02. Because alkyne backbone structures were generated using
the SCH28080-bound structure as a template, we compared the
dimension of its P-CAB binding pocket with another template,
the vonoprazan-bound form (Fig. 1f, g). The comparison revealed
that the width of the most constricted portion of the luminal
conduit in SCH28080-bound form (5.6 Å) is narrower than that
in the vonoprazan-bound form (7.2 Å), which may be one reason
for the production of the alkyne-connecting candidates by DQ.
Given the relatively low afﬁnity and instable binding mode of
DQ-02, we halted further improvement of DQ-02 and other
alkyne-backbone compounds.
DQ-06: satisfying the pharmacophore of H+,K+-ATPase Deep
Quartet assisted drug design. In contrast to DQ-02 and other
alkyne-backbone compounds, another variety of candidates were
suggested by DQ, when using the vonoprazan-bound template
structure which has a much wider hydrophobic conduit (Fig. 1g and
Supplementary Fig. 2). With reference to these candidates, we
designed and synthesized a simple compound that has three benzene
rings connected via ether linkers and has a terminal secondary amine
moiety (DQ-06, Supplementary Data 2). To our surprise, DQ-06
shows an apparent afﬁnity (IC50,DQ06 = 0.70 ± 0.04 μM) signiﬁcantly
higher than SCH28080 (Fig. 3a), and its inhibition mode is pure-
ly competitive with K+ (Supplementary Fig. 5, Ki,DQ06 = 93.8 nM).
To evaluate the importance of this terminal secondary amine,
systematic modiﬁcations were made on the secondary amine
moiety of DQ-06, generating DQ-10 ~ 12. Comparison of the inhi-
bition potencies of DQ-06-related compounds, which have a
hydroxy (IC50,DQ10 = 292 ± 67 μM), dimethylamino (IC50,DQ11 =
5.57 ± 0.45 μM), or amino (IC50,DQ12 = 1.54 ± 0.07 μM) group,
shows clear structure-activity relationships (SAR), indicating that the
compounds with a secondary amine moiety showed the best inhi-
bition potency (Fig. 3a).
The binding pose of DQ-06 to the H+,K+-ATPase was
analyzed by using a 2.19 Å resolution cryo-EM structure (Fig. 3b,
Supplementary Fig. 6, Supplementary Movie 2 and Table 1). In
contrast to the blurred EM density observed for the DQ-02 bound
to H+,K+-ATPase (Fig. 2c), the EM density clearly deﬁnes the
binding pose of DQ-06, with several bound water molecules
visualized. The initial DQ calculation suggests roughly two
different binding poses for DQ-06 related candidates (Fig. 1h, i
and Supplementary Fig. 2); starting from the cationic secondary
amine (pharmacophore feature I), ~60% of DQ-06 related
candidates took a binding pose that connected the pharmaco-
phore features in the order (I)→(IV)→(III)→(II) (Fig. 1h), and
others took a different binding pose (I)→(IV)→(II)→(III)
(Fig. 1i). The binding pose of DQ-06 in the cryo-EM structure
is unambiguously determined as a single conformation (Fig. 3b),
which
agrees
with
the
former
binding
pose
[(I)→(IV)→(III)→(II)] (Fig. 3c, d, g for simpliﬁed schematics).
The cationic secondary amine reaches the cation-binding site, and
is located within hydrogen bond distance to Glu795 side chain
oxygen (3.0 Å), main chain carbonyl from the Ala339 located on
the unwound portion of TM4 (3.2 Å) and an accompanied water
molecule (3.1 Å) (Fig. 3c, d), help fulﬁll the requirement of
“pharmacophore feature I” (Fig. 1e). The SAR of DQ-06-related
compounds shows the importance of the methylamino group
(Fig. 3a), which is now explained from the structural viewpoint.
The terminal methyl group is in van der Waals contact with the
surrounding side chains including Glu343 (3.4 Å), Asn792 (3.4 Å)
and Glu820 (3.3 Å). The benzene ring III (see Fig. 3a for the
nomenclature of the benzene rings in DQ-06) is located close to
Tyr799 (3.5 Å) with a nearly parallel relationship, supposedly
interacting
via
their
π
electron
systems
(“pharmacophore
feature III”). These two portions (pharmacophore features I and
ARTICLE
COMMUNICATIONS BIOLOGY | https://doi.org/10.1038/s42003-023-05334-8
4
COMMUNICATIONS BIOLOGY | (2023) 6:956 | https://doi.org/10.1038/s42003-023-05334-8 | www.nature.com/commsbio

## Page 5 (Section: Chloro derivatives of DQ-06)

III) are connected by the benzene ring IV, which now occupies
the space at the hydrophobic conduit (pharmacophore feature
IV) surrounded by side chains of Leu141 (4.2 and 4.3 Å), Ala339
(3.5 Å) and Ile816 (3.6 and 3.7 Å) and Cβ of Glu795 (3.6 Å). The
terminal benzene ring II is located near Ala123 (3.6 Å) and
making further hydrophobic contacts with Cys120 (3.9 Å),
Asn138 (3.4 Å) and Ala335 (3.5 Å), thus ﬁxing its azimuthal
position is ﬁxed in a thin, restricted pocket formed between TM1
and TM4 (pharmacophore feature III) (Fig. 3e, f). In contrast to
above-described portions that match the deﬁned pharmacophore
features, EM density corresponding to the ether linker connecting
benzene rings II and III is relatively weak (Fig. 3b), indicating its
ﬂexibility, also seen in the SCH28080 binding mode1,35.
Because of the simple chemical structure of two benzene rings II
and III in DQ-06, which are bound to the luminal entrance of the
binding cavity, there is some vacant space in the binding site (Fig. 3e,
f). This observation let us consider the possibility that a simple
modiﬁcation in this portion (ring II or III) of the compound may
improve the apparent afﬁnity, given that the much tighter binding
mode may enhance van der Waals interaction.
Chloro derivatives of DQ-06. For further improvement of the
binding afﬁnity, we synthesized a series of DQ-06 chloro
derivatives (Fig. 4a and Supplementary Data 2). Compared to the
original DQ-06, introduction of three chloro groups (DQ-07)
signiﬁcantly reduced its inhibition potency (IC50,DQ07 = 3.20 ±
0.20 μM). As for compounds with a single modiﬁcation on ring
C, the apparent afﬁnity of 5-chloro derivative (DQ-18) is
improved by a factor of two (IC50,DQ18 = 0.31 ± 0.02 μM) relative
to DQ-06, while that of 6-chloro derivative (DQ-19) is sig-
niﬁcantly reduced (IC50,DQ19 = 3.52 ± 0.22 μM), indicating that
the effect is position-speciﬁc (Fig. 4a). We also conﬁrmed the K+-
competitive inhibition mode of DQ-18 (Supplementary Fig. 5,
Ki,DQ18 = 47.6 nM).
The binding pose of DQ-18 was determined by a cryo-EM
reconstruction at 2.08 Å resolution (Supplementary Fig. 6 and
Table 1), in which the chloro group is clearly seen as a protruded
density at the C5 position of benzene ring III (Fig. 4a, b). Due to
the modiﬁcation by the chloro group, the binding position of the
terminal (II) and central (III) benzene rings are offset by 0.6 Å
compared to DQ-06 (Fig. 4c and Supplementary Movie 3), which
gives DQ-18 a much closer contact to the surface of the binding
pocket (Fig. 4d–h). The high-resolution EM map unambiguously
determined the 5-chloro moiety (Fig. 4b, d, e), which is now in
close contact with the main chain oxygen of Leu811 (2.9 Å)
presumably interacting via a halogen bond, and the main chain
nitrogen of Cys813 (3.3 Å), thus enhanced van der Waals
Fig. 2 Inhibition potency and the binding pose of DQ-02. a Dose-dependent inhibition of H+,K+-ATPase activity by indicated synthesized compounds
(SCH28080 as a control, gray circles and a dashed line). Data plotted represent each data point from triplicate of three independent measurement at 12
different concentrations of P-CABs, using membrane fractions puriﬁed from pig stomach. b EM potential map (colored surface) and cartoon model of the
gastric H+,K+-ATPase complexed with DQ-02 (α-subunit, skyblue; β-subunit, gray; lipids, orange; waters, red). c Close-up view of the DQ-02 binding site
indicated by the red box in (b). Transparent blue surface and black mesh represent EM potential maps in high and low-contour levels, respectively. Only
the EM density around DQ-02 is displayed for low-contour map (mesh). Two possible conformations of DQ-02 (gold and yellow sticks) are shown.
COMMUNICATIONS BIOLOGY | https://doi.org/10.1038/s42003-023-05334-8
ARTICLE
COMMUNICATIONS BIOLOGY | (2023) 6:956 | https://doi.org/10.1038/s42003-023-05334-8 | www.nature.com/commsbio
5

## Page 6 (Section: Chloro derivatives of DQ-06)

Table 1 Cryo-EM data collection, reﬁnement and validation statistics.
DQ-02 (EMDB-35500) (PDB 8IJV)
DQ-06 (EMDB-35501) (PDB 8IJW)
DQ-18 (EMDB-35502) (PDB 8IJX)
DQ-21 (EMDB-36424) (PDB 8JMN)
Data collection and processing
Magniﬁcation
60,000
60,000
60,000
60,000
Voltage (kV)
300
300
300
300
Electron exposure (e–/Å2)
60
60
60
60
Defocus range (μm)
0.8–1.8
0.8–1.8
0.8–1.8
0.8–1.8
Pixel size (Å)
0.752
0.580
0.752
0.752
Symmetry imposed
C1
C1
C1
C1
Initial particle images (no.)
2,832,257
1,564,257
3,387,269
2,230,909
Final particle images (no.)
354,147
168,758
288,130
599,919
Map resolution (Å)
2.10
2.19
2.08
2.26
FSC threshold
0.143
0.143
0.143
0.143
Reﬁnement
Initial model used (PDB)
5ylu
5ylu
5ylu
8IJX
Model resolution (Å)
2.16
2.27
2.15
2.30
FSC threshold
0.5
0.5
0.5
0.5
Map sharpening B factor (Å2)
−49.6
−46.5
−47.1
−79.4
Model composition
Non-hydrogen atoms
10,533
10,543
10,545
10,491
Protein residues
1251
1251
1251
1251
Waters
370
379
373
373
Ligands
DQ02,Mg2+,5PCW,2CLR,3NAG
DQ06,Mg2+,5PCW,2CLR,3NAG
DQ18,Mg2+,6PCW,CLR,3NAG
DQ21,Mg2+,5PCW,CLR,3NAG
B factors (Å2)
Protein
49.75
52.98
48.68
94.43
Ligand
54.70
58.78
53.09
84.62
Waters
46.13
44.69
44.86
66.10
R.m.s. deviations
Bond lengths (Å)
0.003
0.003
0.003
0.003
Bond angles (°)
0.945
0.796
0.778
0.779
Validation
MolProbity score
1.69
1.78
1.35
1.76
Clashscore
5.79
7.00
4.84
5.76
Poor rotamers (%)
2.92
2.44
1.32
3.29
Ramachandran plot
Favored (%)
97.9
97.5
98.3
97.8
Allowed (%)
2.1
2.5
1.7
2.2
Disallowed (%)
0.0
0.0
0.0
0.0
ARTICLE
COMMUNICATIONS BIOLOGY | https://doi.org/10.1038/s42003-023-05334-8
6
COMMUNICATIONS BIOLOGY | (2023) 6:956 | https://doi.org/10.1038/s42003-023-05334-8 | www.nature.com/commsbio

## Page 7 (Section: Potential further improvements of compound binding)

interactions can be expected. Due to the 0.6 Å offset of the
binding position of DQ-18 relative to that of DQ-06, the benzene
ring II is in much closer contact to amino acids surrounding
pharmacophore feature II position near Ala123, and thus the
number of amino acids located within 3.9 Å is increased at this
position (Fig. 4f, ﬁve residues for DQ-06 →eight for DQ-18). In
contrast to the relatively large difference in the binding pose
between DQ-06 and DQ-18 at the luminal side of the cavity,
the effect for cationic secondary amine (I) and connecting
benzene ring (IV) is limited (Fig. 4c). Similar to the case for DQ-
06, the secondary amine moiety of DQ-18 also reaches the cation-
binding site, and is surrounded by three oxygen atoms within
3.5 Å distance. Likewise, the terminal methyl group on the amino
group is accommodated with amino acids located at the cation-
binding site, including main chain oxygen of Val341 (3.6 Å) and
side chains of Asn792 (3.3 Å), Glu795 (3.4 Å) and Glu820 (3.6 Å),
within van der Waals distance (Fig. 4e, f). Therefore, based on the
high-resolution cryo-EM structure, we conclude the rationale for
the improved afﬁnity of DQ-18 to be most likely due to tighter
packing of the terminal and central benzene rings (ring II and III)
into the binding pocket, enhancing hydrophobic interaction
between DQ-18 and H+,K+-ATPase.
This hypothesis is conﬁrmed by structural and functional
analysis of DQ-21, a chloro-modiﬁed DQ-06 at para-position of
ring II (Fig. 5 and Supplementary Data 2). DQ-18 and DQ-21 have
a chloro group on just opposite sides of ring II and ring III,
respectively, and the spatial volume in this part of the compound is
the same. Therefore, if the improvement of apparent afﬁnity of DQ-
18 would be due to the tighter packing of DQ-18 compared to DQ-
06, similar improvement would be observed for DQ-21. As shown
in Fig. 5a, DQ-21 shows an apparent afﬁnity (IC50,DQ21 = 0.28 ±
0.02 μM) similar to that of DQ-18 (IC50,DQ18 = 0.31 ± 0.02 μM). As
we expected, cryo-EM analysis at 2.26 Å reveals that the binding
pose of DQ-21 is 1.2 Å offset toward the TM6 side (Fig. 5b, c), and
the chloro group at ring II is embedded in the cleft formed between
TM1 and TM4, close to Ala123 (Fig. 5d, e). We have thus succeeded
in further increasing the afﬁnity of the DQ-suggested compound by
its tailored modiﬁcation based on the high-resolution structural
information.
Potential further improvements of compound binding. High-
resolution cryo-EM structures of DQ-06, DQ-18 and DQ-21
bound forms allowed us to visualize several water molecules in
their direct vicinity. This includes a water located in the pocket
surrounded by Pro798, Pro810 and Leu811, stabilized by the
hydrogen-bond network connecting main chain carbonyl of
Glu795 and main chain amide of Tyr799 in DQ-06, DQ-18 and
DQ-21 bound forms (Figs. 3c–e, 4d, e, g and 5b–d). In the
SCH28080-bound structure, this water-ﬁlled pocket is occupied
with its cyanomethyl group and thus excluded from the binding
pocket (c.f., Fig. 1d, see ref. 2), which would give a favorable
increase in the entropy of the whole system. In fact, an SCH28080
derivative without a cyanomethyl group shows more than 20-
times reduced afﬁnity34. Given the C6 position of the benzene
ring III of DQ-06 (Fig. 3a, c, e) is the closest to the aforemen-
tioned water molecule in the pocket, it was expected that the
6-chlorobenzyl derivative (DQ-19) may exclude it, and resulting
in an improvement of its apparent afﬁnity. Thus, a question arises
as to why DQ-19 does not improve, rather reduces, the binding
afﬁnity compared to DQ-06 (Fig. 4a). We speculate that a bulky
chlorine modiﬁcation at C6 position of the ring III may interfere
with the oxygen atom of the ether linker connecting two benzene
rings III and IV, and prevents the adoption of this particular
binding pose. Modiﬁcation of C6 position of ring III with a
smaller atom, or a much longer functional group at C5 position
leading to the water-ﬁlled pocket, may instead exclude this water
molecule. Alternatively, it would be possible to try different
compound skeletons; e.g., replacement of the benzene ring III to a
5-membered aromatic ring or a heterocyclic ring like imi-
dazo[1,2-a]pyridine of SCH28080 (Supplementary Fig. 1) that
could change the direction of the side chain, whilst preserving the
π electron donation system bound to Tyr799.
In contrast to the clear EM densities for the most of the
functional groups of DQ-06 and DQ-18, the EM densities
corresponding to their ether linkers that connecting ring II and
III are weak, indicating this portion is mutually ﬂexible for both
compounds. This is in good agreement with the conclusion from
a previously reported systematic SAR of SCH28080 derivatives
with ﬁxed ring analogs (BYK99 and soraprazan, Supplementary
Fig. 1)35, which show more than 25 and 7 times higher apparent
afﬁnity than SCH28080, respectively1,34. We also reported that
the dihedral angle at the connecting oxygen atom of SCH28080 in
solution distributed three metastable positions in the molecular
dynamics simulation, indicating its conformational freedom1.
Such ﬂexibility in the relative orientation of two benzene rings II
and III connected by an ether linker is also expected for the DQ-
06-related compounds. By ﬁxing the linker structure and thereby
restricting the conformation that DQ-06-related compounds can
adopt, a dramatic improvement in their apparent afﬁnities could
be anticipated. However, we cannot exclude the possibility that
the ﬂexibility of the linker region helps DQ-06 and DQ-18
binding, as chemical backbone of these compounds is different
from that of SCH28080.
In this manuscript, all the ATPase measurements for the
determination of apparent afﬁnities of the compounds were
performed at neutral (pH 7) condition. In the case of SCH28080,
because of its pKa value of 5.6 for imidazo[1,2-a]pyridine amine,
its apparent afﬁnity differs around neutral (Ki = 66 nM at pH
7.35) and weakly acidic (Ki = 20 nM at pH 6.11) conditions36.
However, expected pKa value of secondary amine groups of DQ-
related compounds are in the range of 9-11, indicating they are
mostly protonated at neutral pH, and also at highly acidic
condition in the stomach. According to Henderson-Hasselbalch
equation, ratio of protonated : free amine is expected to be 1:25 at
pH 7 and 1:10 at pH 6.6 for SCH28080 with pKa of 5.6. In
contrast, it is expected to be 100:1 ~ 10,000:1 for the secondary
amine of DQ-related compounds with pKa of 9–11, and this ratio
does not largely change around neutral (pH 7), weakly acidic (for
example, pH 6.0) and even strongly acidic condition in the
stomach, thus the apparent afﬁnities of DQ-related compounds
unlikely affected by the in vitro solution pH.
A unique framework for de novo drug generation. Here, a
combination of AI-driven compound design, chemical synthesis
and cryo-EM analysis of drug bound structures underpinned the
development of P-CAB candidates that have de novo chemical
structures (Fig. 1a). Recent advances in structural analysis by
single particle cryo-EM37,38 renders drug-bound protein struc-
tures signiﬁcantly more accessible and reliable than previously.
This enables the determination of pharmacophores, relevant
structure-based modiﬁcations, and iterative repetition of these
cycles to improve afﬁnity, potencies and other pharmacokinetic
parameters. To address unforeseen side effects and expanding
medical needs, the development of alternative drugs with distinct
chemical skeletons is highly desired. However, when creating new
compounds based on the original drug-bound structure, it is
often difﬁcult to generate a truly different chemical skeleton
derived far from the original drug structures. As highlighted in
our case, even if several pharmacophore features have been
determined on the protein structure, it is not easy to manually
COMMUNICATIONS BIOLOGY | https://doi.org/10.1038/s42003-023-05334-8
ARTICLE
COMMUNICATIONS BIOLOGY | (2023) 6:956 | https://doi.org/10.1038/s42003-023-05334-8 | www.nature.com/commsbio
7

## Page 8 (Section: Potential further improvements of compound binding)

create the optimal chemical structure to link them with. Deep
Quartet, a deep learning based de novo design workﬂow, gen-
erates chemical structures that satisfy the desired pharmaco-
phores on the protein structure29,30. Since the software “learns”
chemical structures from the database ChEMBL39 (https://www.
ebi.ac.uk/chembl/) in which more than 2-million bioactive
molecules are stored, generated candidates have mostly “drug-
like” chemical structures (Fig. 1a and Supplementary Fig. 2).
However, in some cases DQ generates too many candidate
compounds, and some of them are not trivial to synthesize, or,
compounds themselves are instable in aqueous solution. We
therefore
selected
candidates
“heuristically”,
based
on
the
knowledge of organic chemistry and previous functional analysis
of H+,K+-ATPase with P-CABs, and started with simple
ARTICLE
COMMUNICATIONS BIOLOGY | https://doi.org/10.1038/s42003-023-05334-8
8
COMMUNICATIONS BIOLOGY | (2023) 6:956 | https://doi.org/10.1038/s42003-023-05334-8 | www.nature.com/commsbio

## Page 9 (Section: Methods)

compounds, like DQ-02 (Fig. 2) or DQ-06 (Fig. 3), for stream-
lined structure-activity studies. This strategy may be particularly
useful to determine the direction of which compounds are pro-
mising in the very early stages of drug development.
Pharmacophore-based
de
novo
design
of
the
chemical
structure may also be applied for the replacement of large
molecular weight drugs such as polypeptides, nucleic acids and
antibodies by small molecule compounds. Recent technological
innovations enabled the identiﬁcation of high-afﬁnity cyclic
peptides
through
DNA-encoded
library
screening40.
Many
antibody-based medicines are also available for the clinical
treatment. These large molecules often suffer from pharmacoki-
netic issues including their low permeability to the cell membrane
or expensive production cost. When the target structures
complexed with these large molecules are available, our strategy
may offer a promising option to develop small compounds that
satisfy the greatest common denominator of pharmacophores on
the protein structure.
“Deep Quartet” (Fig. 1a) consists of a series of ﬂows including
(1) deep reinforcement learning, (2) LigandScout, a software
using pharmacophore models, and (3) Sub-structure ﬁltering to
select candidates that match the desired target. In addition to
(1)–(3), (4) knowledge of medicinal or organic chemistry, is also
included in the ﬂow, to create an AI-platform for the drug
discovery achieved by the “quartet” (Fig. 1a). Now Deep Quartet
has been added a ﬁfth ﬂow (5) high-resolution cryo-EM
structural analysis. Thus, this platform now is “Deep Quintet”,
providing a distinct and more powerful framework for the drug
discovery.
Methods
De novo drug design by Deep Quartet. Deep Quartet (DQ) is a
workﬂow for generating chemical structures with desired phar-
macophore (Fig. 1a)29,30. REINVENT41, which is an open-source
Python application, is used as DGMs in DQ. The DGMs consist
of two recurrent neural network models named as Prior and
Agent networks. The Prior network is trained using SMILES
representation of molecules obtained from ChEMBL39. The
Agent network is initialized by Prior network and then trained
using reinforcement learning41. During the training, the prob-
ability distribution of the Agent network shifts toward a dis-
tribution modulated by a scoring function. After the training,
Agent network generates SMILES with a desired property
obtained from a scoring function. In this study, to generate
diverse chemical structure, two approaches, early stop & refresh
and tabu list, were implemented in REINVENT. In early stop &
refresh, when averaged scores exceeded a pre-deﬁned score (set to
0.8) threshold or training steps exceed pre-deﬁned steps (set to
1000) during the training, the training was stopped. Then, the
Agent network was initialized and the training was re-started.
This process was done up to a pre-deﬁned number of total
training steps. The top 50 scoring structures generated from each
Agent network were stored. In tabu list approach, scaffolds of the
structures generated from each Agent network are appended to
the tabu list. The scaffolds were calculated using MurckoScaffold
function implemented in RDKit (https://www.rdkit.org)42. When
the Agent network generated a chemical structure with the same
scaffold as the scaffolds included in the tabu list, the score of
the compound was set to zero. The tabu list was updated each
time the Agent network was initialized. In REINVENT, training
of the Agent network was done with sigma (a parameter related
to learning rate) of 120, set to experience_replay and total
training steps of 10,000. All other parameters were set to default
values and pre-trained Prior network provided from REINVENT
is used. To generate chemical structure with desired pharmaco-
phore, the Agent networks were trained using the scoring func-
tion (Relative Pharmacophore-Fit) of LigandScout 4.443. The
Relative Pharmacophore-Fit outputs a pharmacophore score that
is normalized to [0, 1] range based on the number of matching
pharmacophore features and the RMSD of the pharmacophore
alignment. Based on the gastric proton pump complexed with its
blockers derived from X-ray crystallography (PDB ID: 5ylv and
5ylu), three different types of pharmacophore models (Type A, B,
and C) were deﬁned as shown in Supplementary Fig. 2. A DQ run
using Type A pharmacophore generated 550 chemical structures.
Among them, compounds with methylamino group and phar-
macophore score of 0.9 or higher were selected, and the resulting
71 compounds were considered as candidates for synthesis. In the
same manner, a DQ run using Type B pharmacophore generated
600 chemical structures from which 10 compounds were con-
sidered as candidates for synthesis. A DQ run using Type C
pharmacophore generated 650 chemical structures where 181
compounds were considered as candidates for synthesis.
Selection and synthesis of candidate compounds. DQ-02, DQ-
04 (Type A) and DQ-07 (Type C) were selected from the list of
the above candidates. The structures of DQ-06 (Type C) and DQ-
09 (Type A) were generated by removing halogen substituents of
the compounds in the list. The structure of DQ-10, DQ-11 or
DQ-12 were systematically generated by replacing the methyla-
mino group of DQ-06 with a hydroxy, dimethylamino or amino
group, respectively. The structures of DQ-18, DQ-19 and DQ-21
were designed by adding a chloro group onto DQ-06. The list
generated by using Type B pharmacophore included bicyclic
heteroaromatic compounds having two alkyne units. Based on
these structural features, DQ-14, DQ-15 and DQ-16 were newly
designed from the viewpoint of synthetic accessibility, and were
evaluated by the pharmacophore scores before the synthesis. All
the compounds were synthesized according to the synthetic
procedures provided in the Supplementary Data 2.
ATPase activity measurement. H+,K+-ATPase-enriched mem-
brane fractions were puriﬁed from pig stomach according to the
previously reported procedures44. These membrane fractions
Fig. 3 Inhibition potency and the binding pose of DQ-06. a Dose-dependent inhibition of H+,K+-ATPase activity by indicated compounds as shown in
Fig. 2a. Data plotted represent each data point from triplicate of three independent measurement at 12 different concentrations of P-CABs. Three benzene
rings in DQ-06 are attributed as illustrated in the ﬁgure, which corresponds to the deﬁned pharmacophore features (II)–(IV). b EM potential map (mesh)
and the atomic model of the gastric H+,K+-ATPase complexed with DQ-06 (green sticks). Shown is a close-up view of the DQ-06 binding site as in Fig. 2c.
c, d Molecular interactions between H+,K+-ATPase and DQ-06 in stick representation. Hydrophilic and hydrophobic atoms of DQ-06 within 3.5 and 4.0 Å
distance from amino acids of H+,K+-ATPase are connected by orange and gray dotted lines, respectively. Panels are viewed from luminal side (c), or
parallel to the membrane plane with luminal-side up (d). e, f Clipped cross sections of the DQ-06 binding site from the viewpoints approximately similar to
(c) and (d). Molecular surface (gray) of H+,K+-ATPase shows the dimension of the binding site in which DQ-06 is accommodated (green stick with
transparent van der Waals spheres). Except for TM2, which is removed from the ﬁgure for clarity, TM helices and some of the key amino acids are shown
in ribbon and stick representations. g A schematic 2D representation of DQ-06 binding pose. Hydrophobic residues that are located within 3.9 Å from DQ-
06 are shown, and those within 3.5 Å are highlighted as red. Expected polar interactions within 3.5 Å are indicated as orange dotted lines.
COMMUNICATIONS BIOLOGY | https://doi.org/10.1038/s42003-023-05334-8
ARTICLE
COMMUNICATIONS BIOLOGY | (2023) 6:956 | https://doi.org/10.1038/s42003-023-05334-8 | www.nature.com/commsbio
9

## Page 10 (Section: Methods)

Fig. 4 Inhibition potency and the binding pose of DQ-18. a Dose-dependent inhibition of H+,K+-ATPase activity by indicated P-CABs (DQ-06, 07, 18, 19
and SCH28080) as shown in Fig. 2a. Data plotted represent each data point from triplicate of three independent measurement at 12 different
concentrations of P-CABs. b EM potential map (mesh) and atomic model of the gastric H+,K+-ATPase complexed with DQ-18 (blue sticks). c Comparison
of the binding poses between DQ-06 (green) and DQ-18 (blue). Arrow indicates the displacement of the binding position from DQ-06 to DQ-18 (0.6 Å).
d, e Molecular interactions between H+,K+-ATPase and DQ-18 in stick representation as shown in Fig. 3c, d. f A schematic 2D representation of DQ-18
binding pose as shown in Fig. 3g. g, h Clipped cross sections of the DQ-18 binding site as in Fig. 3e, f.
ARTICLE
COMMUNICATIONS BIOLOGY | https://doi.org/10.1038/s42003-023-05334-8
10
COMMUNICATIONS BIOLOGY | (2023) 6:956 | https://doi.org/10.1038/s42003-023-05334-8 | www.nature.com/commsbio

## Page 11 (Section: Methods)

Fig. 5 Inhibition potency and the binding pose of DQ-21. a Dose-dependent inhibition of H+,K+-ATPase activity by indicated P-CABs (DQ-06, 18 and 21)
as shown in Fig. 2a. Data plotted represent each data point from triplicate of three independent measurement at 12 different concentrations of P-CABs.
b EM potential map (mesh) and atomic model of the gastric H+,K+-ATPase complexed with DQ-21 (purple sticks). c Comparison of the binding poses
between DQ-18 (blue) and DQ-21 (purple). Arrow indicates the displacement of the binding position from DQ-18 to DQ-21 (1.2 Å). d, e Clipped cross
sections of the DQ-21 binding site as in Fig. 3e, f.
COMMUNICATIONS BIOLOGY | https://doi.org/10.1038/s42003-023-05334-8
ARTICLE
COMMUNICATIONS BIOLOGY | (2023) 6:956 | https://doi.org/10.1038/s42003-023-05334-8 | www.nature.com/commsbio
11

## Page 12 (Section: Expression and purification of recombinant H+,K+-ATPase)

(~0.05 μg protein/40 μl solution in each well) were suspended in
buffer containing 40 mM PIPES/Tris (pH 7.0), 2 mM MgCl2,
2 mM ATP di-tris salt and 10 mM KCl in the presence of different
concentrations of SCH28080 or synthesized compounds in 96-
well microtubes34. Reactions were initiated by incubating the
fractions at 37 °C using a thermal cycler and maintained for 1 h.
Reactions were terminated by adding 2 M HCl, and the amount
of
released
inorganic
phosphate
was
determined
colorimetrically45 using a microplate reader (TECAN). The spe-
ciﬁc H+,K+-ATPase activity was calculated by subtracting the
activities in the presence of 0.5 mM SCH28080. The IC50 value
was estimated by the sigmoidal curve ﬁtting using software
PRISM 9.
Data measured from 96-well plate contained triplicates of four
different sets of K+-dependent ATPase assays in the absence or
presence
of
three
different
concentrations
of
synthesized
compounds. Data were corrected for background values in the
absence of K+ at each compound concentration, and plot them
against the double reciprocal axes in Supplementary Fig. 5. Data
were also ﬁtted by using simultaneous nonlinear regression as
described previously to estimate their Ki values34.
Raw data for the ATPase measurement can be found in
Supplementary Data 1.
Expression and puriﬁcation of recombinant H+,K+-ATPase.
Procedures for protein expression are essentially the same as
those
reported
previously2,46.
Brieﬂy,
Flag
epitope
tag
(DYKDDDDK), a hexa-histidine tag and the enhanced green
ﬂuorescence protein (EGFP) were inserted in the amino terminal
side of Met48 of the pig gastric H+,K+-ATPase α-subunit, fol-
lowed by a tobacco etch virus (TEV) protease recognition
sequence and subcloned into a hand-made vector2. The wild type
pig gastric H+,K+-ATPase β-subunit was also cloned. The αβ-
complex of H+,K+-ATPase were expressed in the plasma mem-
brane using baculovirus-mediated transduction of mammalian
HEK293S GnT1- cells (BacMam)47 purchased from ATCC.
For cryo-EM analysis, cells were directly solubilized with 1%
lauryl maltose neopentyl glycol (LMNG)48 in the presence of
40 mM MES/Tris (pH 6.5), 10% glycerol, 5 mM dithiothreitol,
1 mM MgCl2, in the presence of 1 mM BeSO4, 3 mM NaF and
protease inhibitor cocktail (Roche) on ice for 20 min. After
removing insoluble material by ultracentrifugation, the super-
natant was mixed with anti-GFP nanobody resin49 at 4 °C for 2 h,
which was followed by washing with buffer containing 40 mM
MES/Tris (pH 6.5), 5% glycerol, 1 mM MgCl2, 1 mM BeSO4,
3 mM NaF, 50 mM NaCl and 0.06% glyco-diosgenin (GDN)50.
After addition of TEV protease and endoglycosidase, anti-GFP
nanobody was incubated at 4 °C overnight. Digested peptide
fragments containing EGFP and endoglycosidase were removed
by passing the fractions through Ni-NTA resin (Qiagen). Flow-
through fractions were concentrated and subjected to size-
exclusion column chromatography using a Superose6 Increase
column (Cytiva) equilibrated in buffer comprising 20 mM MES/
Tris (pH 6.5), 1 mM MgCl2, 1 mM BeSO4, 3 mM NaF, 50 mM
NaCl and 0.06% GDN. Peak fractions were collected and
concentrated to 8 mg/ml. A ﬁnal concentration of 0.1 mM
synthesized compound (DQ-02, DQ-06 or DQ-18) was added
to the protein sample.
Cryo-EM structural analysis. Preparation of sample and cryo-
EM grids were done according to a previous report1,51. The
puriﬁed protein samples (at 8 mg/ml) containing 0.1 mM syn-
thesized compound were applied to a freshly glow-discharged
Quantifoil holey carbon grids (R1.2/1.3, Cu/Rh, 200 mesh), using
a Vitrobot Mark IV (Thermo Fisher) at 4 °C with a blotting time
of 4 s under 99% humidity, and then plunge-frozen in liquid
ethane. The prepared grids were transferred to a CRYO ARM 300
microscope (JEOL), operated at 300 kV, with a cold-ﬁeld emis-
sion gun as the electron source, an in-column Ω ﬁlter and
equipped with a Gatan K3 direct electron detector in the electron
counting mode. Imaging was performed at a nominal magniﬁ-
cation of ×60,000 for DQ-02 and DQ-18 bound forms, and
×80,000 for DQ-06 bound one, corresponding to a calibrated
pixel size of 0.753 and 0.580 Å/pix, respectively (EM01CT at
SPring-8). Each movie was recorded in correlated-double sam-
pling (CDS) mode for 2.6 s and subdivided into 60 frames. The
electron ﬂux was set to 8.46 e−/pix/s at the detector, resulting in
an accumulated exposure of 60 e−/Å2 at the specimen. The data
were automatically acquired by the image shift method using
SerialEM software52, with a defocus range of −0.8 to −1.8 μm.
The dose-fractionated movies were subjected to beam-induced
motion correction, using RELION 3.153, and the contrast transfer
function (CTF) parameters were estimated using patch CTF
estimation in cryoSPARC (v4, Structura Biotechnology)54.
For each dataset, particles were initially picked by blob picker
using cryoSPARC (v4), and extracted with down-sampling to a
pixel size of 3.24 Å/pix. These particles were subjected to several
rounds of 2D classiﬁcations. Good-looking classes were then
subjected to ab initio reconstruction in three models, and reﬁned by
non-uniform reﬁnement55. The particles from the best class was
then re-extracted to the full pixel size and subjected to non-uniform
reﬁnement with per-particle defocus reﬁnement, beam-tilt reﬁne-
ment in cryoSPARC (v4). The particle stack was then transferred to
RELION 3.1, and subjected to Bayesian polishing56. Polished
particles were re-imported to cryoSPARC (v4), and subjected to
non-uniform reﬁnement. The resolution of the analyzed map was
deﬁned according to the FSC = 0.143 criterion57 (Supplementary
Fig. 6). The local resolution and angular distributions for each
structure were estimated by cryoSPARC (v4). All the models were
manually built in Coot58 using the crystal structure of SCH28080-
bound H+,K+-ATPase (5ylu) as a starting template2. Phenix59
(version 20) was used for reﬁnement.
Reporting summary. Further information on research design is
available in the Nature Portfolio Reporting Summary linked to
this article.
Data availability
The structural data generated in this study have been deposited in the Protein Data Bank
and EM Data Bank under accession codes 8IJV and EMD-35500; Cryo-EM structure of
the gastric proton pump with bound DQ-02, 8IJW and EMD-35501; Cryo-EM structure
of the gastric proton pump with bound DQ-06, 8IJX and EMD-35502; Cryo-EM
structure of the gastric proton pump with bound DQ-18; Cryo-EM structure of the
gastric proton pump with bound DQ-21, 8JMN and EMD-36424. Source data are
provided as Supplementary Data.
Code availability
Deep Quartet is a software developed by Intage Healthcare Inc., is provided as
Supplementary_Software.zip.
Received: 11 August 2023; Accepted: 8 September 2023;
References
1.
Tanaka, S. et al. Structural basis for binding of potassium-competitive acid
blockers to the gastric proton pump. J. Med. Chem. 65, 7843–7853 (2022).
2.
Abe, K., Irie, K., Nakanishi, H., Suzuki, H. & Fujiyoshi, Y. Crystal structures of
the gastric proton pump. Nature 556, 214–229 (2018).
ARTICLE
COMMUNICATIONS BIOLOGY | https://doi.org/10.1038/s42003-023-05334-8
12
COMMUNICATIONS BIOLOGY | (2023) 6:956 | https://doi.org/10.1038/s42003-023-05334-8 | www.nature.com/commsbio

## Page 13 (Section: Expression and purification of recombinant H+,K+-ATPase)

3.
Shin, J. M. & Sachs, G. Pharmacology of proton pump inhibitors. Curr.
Gastroenterol. Rep. 10, 528–534 (2008).
4.
Wallace, J. L. How do NSAIDs cause ulcer disease? Best Pract. Res. Clin.
Gastroenterol. 14, 147–159 (2000).
5.
Hain, E., Coriat, R., Dousset, B. & Gaujoux, S. Prise en charge du gastrinome.
Presse Med. 45, 986–991 (2016).
6.
Black, J. W., Duncan, W. A. M., Durant, C. J., Ganellin, C. R. & Parsons, E. M.
Deﬁnition and antagonism of histamine H2-receptors. Nature 236, 385–390
(1972).
7.
Wroblewski, L. E., Peek, R. M. & Wilson, K. T. Helicobacter pylori and gastric
cancer: factors that modulate disease risk. Clin. Microbiol. Rev. 23, 713–739
(2010).
8.
Ganser, A. L. & Forte, J. G. K+-stimulated ATPase in puriﬁed microsomes of
bullfrog oxyntic cells. BBA Biomembr. 307, 169–180 (1973).
9.
Chang, H., Saccomani, G., Rabon, E., Schackmann, R. & Sachs, G. Proton
transport by gastric membrane vesicles. BBA Biomembr. 464, 313–327 (1977).
10. Palmgren, M. G. & Axelsen, K. B. Evolution of P-type ATPases. Biochim.
Biophys. Acta Bioenerg. 1365, 37–45 (1998).
11. Toyoshima, C., Nakasako, M., Nomura, H. & Ogawa, H. Crystal structure of
the calcium pump of sarcoplasmic reticulum Ê resolution. Nature 405,
647–655 (2000).
12. Post, R. L., Kume, S., Tobin, T., Orcutt, B. & Sen, A. K. Flexibility of an active
center in sodium-plus-potassium adenosine triphosphatase. J. Gen. Physiol.
54, 306–326 (1969).
13. Rabon, E. C. & Reuben, M. A. The mechanism and structure of the gastric
H,K-ATPase. Annu. Rev. Physiol. 52, 321–344 (1990).
14. Vagin, O., Turdikulova, S. & Tokhtaeva, E. Polarized membrane distribution
of potassium-dependent ion pumps in epithelial cells: different roles of the
N-glycans of their beta subunits. Cell Biochem. Biophys. 47, 376–391 (2007).
15. Shin, J. M., Cho, Y. M. & Sachs, G. Chemistry of covalent inhibition of the
gastric (H+, K +)-ATPase by proton pump inhibitors. J. Am. Chem. Soc. 126,
7800–7811 (2004).
16. Hersey, S. J., Steiner, L., Mendlein, J., Rabon, E. & Sachs, G. SCH28080
prevents omeprazole inhibition of the gastric H + / K +-ATPase. Biochim.
Biophys. Acta 956, 49–57 (1988).
17. Wallmark, B. et al. Inhibition of gastric H+,K+-ATPase and acid secretion by
SCH 28080, a substituted pyridyl(1,2a)imidazole. J. Biol. Chem. 262,
2077–2084 (1987).
18. Kim, D. K. et al. Effects of tegoprazan, a novel potassium-competitive acid
blocker, on rat models of gastric acid-related disease. J. Pharmacol. Exp. Ther.
369, 318–327 (2019).
19. Han, K. S., Kim, Y. G., Yoo, J. K., Lee, J. W. & Lee, M. G. Pharmacokinetics of
a new reversible proton pump inhibitor, YH1885, after intravenous and oral
administrations to rats and dogs: hepatic ﬁrst-pass effect in rats. Biopharm.
Drug Dispos. 19, 493–500 (1998).
20. Otake, K. et al. Characteristics of the novel potassium-competitive acid
blocker vonoprazan fumarate (TAK-438). Adv. Ther. 33, 1140–1157 (2016).
21. Nagata, N. et al. Population-level metagenomics uncovers distinct effects of
multiple medications on the human gut microbiome. Gastroenterology 163,
1038–1052 (2022).
22. Nochaiwong, S. et al. The association between proton pump inhibitor use and
the risk of adverse kidney outcomes: a systematic review and meta-analysis.
Nephrol. Dial. Transplant. 33, 331–342 (2018).
23. Hagiwara, T., Mukaisho, K.-I., Nakayama, T., Sugihara, H. & Hattori, T. Long-
term proton pump inhibitor administration worsens atrophic corpus gastritis
and promotes adenocarcinoma development in Mongolian gerbils infected
with Helicobacter pylori. Gut 60, 624–630 (2011).
24. Abe, K., Yamamoto, K., Irie, K., Nishizawa, T. & Oshima, A. Gastric proton
pump with two occluded K+ engineered with sodium pump-mimetic
mutations. Nat. Commun. 12, 1–11 (2021).
25. Huang, H., Yu, P. S. & Wang, C. An introduction to image synthesis with
generative adversarial nets. https://doi.org/10.48550/arxiv.1803.04469 (2018).
26. Johnson, M. et al. Google’s multilingual neural machine translation system:
enabling zero-shot translation. Trans. Assoc. Comput. Linguist. 5, 339–351
(2017).
27. Bilodeau, C., Jin, W., Jaakkola, T., Barzilay, R. & Jensen, K. F. Generative
models for molecular discovery: recent advances and challenges. WIREs
Comput. Mol. Sci. 12, e1608 (2022).
28. Zhavoronkov, A. et al. Deep learning enables rapid identiﬁcation of potent
DDR1 kinase inhibitors. Nat. Biotechnol. 37, 1038–1040 (2019).
29. Yoshimori, A., Kawasaki, E., Kanai, C. & Tasaka, T. Strategies for design of
molecular structures with a desired pharmacophore using deep reinforcement
learning. Chem. Pharm. Bull. 68, 227–233 (2020).
30. Yoshimori, A. et al. Design and synthesis of DDR1 inhibitors with a desired
pharmacophore using deep generative models. ChemMedChem 16, 955–958
(2021).
31. Bickerton, G. R., Paolini, G. V., Besnard, J., Muresan, S. & Hopkins, A. L.
Quantifying the chemical beauty of drugs. Nat. Chem. 4, 90–98 (2012).
32. Ertl, P. & Schuffenhauer, A. Estimation of synthetic accessibility score of drug-
like molecules based on molecular complexity and fragment contributions. J.
Cheminform. 1, 1–11 (2009).
33. Asano, S., Io, T., Kimura, T., Sakamoto, S. & Takeguchi, N. Alanine-scanning
mutagenesis of the sixth transmembrane segment of gastric H+,K+-ATPase
α-subunit. J. Biol. Chem. 276, 31265–31273 (2001).
34. Abe, K. et al. The cryo-EM structure of gastric H+,K+-ATPase with bound
BYK99, a high-afﬁnity member of K+-competitive, imidazo[1,2-a]pyridine
inhibitors. Sci. Rep. 7, 6632 (2017).
35. Kaminski, J. J., Wallmark, B., Briving, C. & Andersson, B. M. Antiulcer agents.
5. Inhibition of gastric H+/K(+)-ATPase by substituted imidazo[1,2-a]
pyridines and related analogues and its implication in modeling the high
afﬁnity potassium ion binding site of the gastric proton pump enzyme. J. Med.
Chem. 34, 533–541 (1991).
36. Keeling, D. J., Laing, S. M. & Senn-Bilﬁnger, J. SCH 28080 is a lumenally
acting, K+-site inhibitor of the gastric (H+ + K+)-ATPase. Biochem.
Pharmacol. 37, 2231–2236 (1988).
37. Maki-Yonekura, S., Hamaguchi, T., Naitow, H., Takaba, K. & Yonekura, K.
Advances in cryo-EM and ED with a cold-ﬁeld emission beam and energy
ﬁltration—reﬁnements of the CRYO ARM 300 system in RIKEN SPring-8
center—. Microscopy 70, 232–240 (2021).
38. Nakane, T. et al. Single-particle cryo-EM at atomic resolution. Nature 587,
152–156 (2020).
39. Gaulton, A. et al. ChEMBL: a large-scale bioactivity database for drug
discovery. Nucleic Acids Res. 40, D1100–D1107 (2012).
40. Yoshida, S. et al. Peptide-to-small molecule: a pharmacophore-guided small
molecule lead generation strategy from high-afﬁnity macrocyclic peptides. J.
Med. Chem. 65, 10655–10673 (2022).
41. Olivecrona, M., Blaschke, T., Engkvist, O. & Chen, H. Molecular de-novo
design through deep reinforcement learning. J. Cheminform. 9, 1–14 (2017).
42. Bemis, G. W. & Murcko, M. A. The properties of known drugs. 1. Molecular
frameworks. J. Med. Chem. 39, 2887–2893 (1996).
43. Wolber, G., Dornhofer, A. A. & Langer, T. Efﬁcient overlay of small organic
molecules using 3D pharmacophores. J. Comput. Aided Mol. Des. 20, 773–788
(2006).
44. Abe, K. & Olesen, C. Isolation of H+,K+-ATPase-enriched membrane fraction
from pig stomachs. Methods Mol. Biol. 1377, 19–27 (2016).
45. Chifﬂet, S., Torriglia, A., Chiesa, R. & Tolosa, S. A method for the
determination of inorganic phosphate in the presence of labile organic
phosphate and high concentrations of protein: application to lens ATPases.
Anal. Biochem. 168, 1–4 (1988).
46. Young, V. C. et al. Structure and function of H+/K+ pump mutants reveal Na
+/K+ pump mechanisms. Nat. Commun. 13, 5270 (2022).
47. Dukkipati, A., Park, H. H., Waghray, D., Fischer, S. & Garcia, K. C. BacMam
system for high-level expression of recombinant soluble and membrane
glycoproteins for structural studies. Protein Expr. Purif. 62, 160–170 (2008).
48. Chae, P. S. et al. Maltose–neopentyl glycol (MNG) amphiphiles for
solubilization, stabilization and crystallization of membrane proteins. Nat.
Methods 7, 1003–1008 (2010).
49. Kubala, M. H., Kovtun, O., Alexandrov, K. & Collins, B. M. Structural and
thermodynamic analysis of the GFP:GFP-nanobody complex. Protein Sci. 19,
2389–2401 (2010).
50. Chae, P. S. et al. A new class of amphiphiles bearing rigid hydrophobic groups
for solubilization and stabilization of membrane proteins. Chem. Eur. J. 18,
9485–9490 (2012).
51. Nakanishi, H. et al. Transport cycle of plasma membrane ﬂippase ATP11C by
Cryo-EM. Cell Rep. 32, 108208 (2020).
52. Mastronarde, D. N. Automated electron microscope tomography using robust
prediction of specimen movements. J. Struct. Biol. 152, 36–51 (2005).
53. Zivanov, J. et al. New tools for automated high-resolution cryo-EM structure
determination in RELION-3. Elife 7, e42166 (2018).
54. Punjani, A., Rubinstein, J. L., Fleet, D. J. & Brubaker, M. A. cryoSPARC:
algorithms for rapid unsupervised cryo-EM structure determination. Nat.
Methods 14, 290–296 (2017).
55. Punjani, A., Zhang, H. & Fleet, D. J. Non-uniform reﬁnement: adaptive
regularization improves single-particle cryo-EM reconstruction. Nat. Methods
17, 1214–1221 (2020).
56. Zivanov, J., Nakane, T. & Scheres, S. H. W. A Bayesian approach to beam-
induced motion correction in cryo-EM single-particle analysis. IUCrJ 6, 5–17
(2019).
57. Rosenthal, P. B. & Henderson, R. Optimal determination of particle
orientation, absolute hand, and contrast loss in single-particle electron
cryomicroscopy. J. Mol. Biol. 333, 721–745 (2003).
58. Emsley, P. et al. Coot: model-building tools for molecular graphics. Acta
Crystallogr. Sect. D Biol. Crystallogr. 60, 2126–2132 (2004).
59. Adams, P. D. et al. PHENIX: a comprehensive Python-based system for
macromolecular structure solution. Acta Crystallogr. Sect. D Biol. Crystallogr.
66, 213–221 (2010).
COMMUNICATIONS BIOLOGY | https://doi.org/10.1038/s42003-023-05334-8
ARTICLE
COMMUNICATIONS BIOLOGY | (2023) 6:956 | https://doi.org/10.1038/s42003-023-05334-8 | www.nature.com/commsbio
13

## Page 14 (Section: Acknowledgements)

Acknowledgements
K.A. thanks Drs. A. Oshima and K. Tanaka for their help in grid screening and image
processing, and Dr. P. Artigas for discussion. Cryo-EM experiments were performed at
EM01CT at SPring-8 with the approval of the Japan Synchrotron Radiation Research
Institute (JASRI proposal number 2021B2530). The authors thank the ACISS Academia
Support Service for the in silico experiments. This work has been funded by Grant-in-Aid
for Scientiﬁc Research (21H02426), Novartis Foundation, Daiichi Sankyo Foundation of
Life Science, JST CREST Grant Number JPMJCR22E4 (to K.A.). This work was ﬁnan-
cially supported by the Research Support Project for Life Science and Drug Discovery
[Basis for Supporting Innovative Drug Discovery and Life Science Research (BINDS)]
from AMED under Grant Number JP23ama121044 (to S.Y.) [support number 4085
(to K.A.)].
Author contributions
K.A. designed the study with S.Y. and A.Y. C.K. and A.Y. performed DQ calculation.
M.O., M.I., Y.M., S.K., N.U. and S.Y. synthesized the compounds. K.A. and C.N. per-
formed ATPase assay. K.A. expressed and puriﬁed protein. K.A. performed cryo-EM
analysis with C.C.G., C.G. and H.S. K.A. performed image processing, model building
and structural interpretations. K.A., S.Y. and A.Y. wrote the manuscript. C.C.G. and C.G.
commented on and edited the manuscript.
Competing interests
A.Y. is a CEO of Institute for Theoretical Medicine, Inc. C.K. is an employee of INTAGE
Healthcare Inc. Other authors declare no competing interests.
Additional information
Supplementary information The online version contains supplementary material
available at https://doi.org/10.1038/s42003-023-05334-8.
Correspondence and requests for materials should be addressed to Kazuhiro Abe,
Satoshi Yokoshima or Atsushi Yoshimori.
Peer review information This manuscript has been previously reviewed at another
Nature Portfolio journal. The manuscript was considered suitable for publication without
further review at Communications Biology. Primary Handling Editor: Gene Chong.
Reprints and permission information is available at http://www.nature.com/reprints
Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in
published maps and institutional afﬁliations.
Open Access This article is licensed under a Creative Commons
Attribution 4.0 International License, which permits use, sharing,
adaptation, distribution and reproduction in any medium or format, as long as you give
appropriate credit to the original author(s) and the source, provide a link to the Creative
Commons license, and indicate if changes were made. The images or other third party
material in this article are included in the article’s Creative Commons license, unless
indicated otherwise in a credit line to the material. If material is not included in the
article’s Creative Commons license and your intended use is not permitted by statutory
regulation or exceeds the permitted use, you will need to obtain permission directly from
the copyright holder. To view a copy of this license, visit http://creativecommons.org/
licenses/by/4.0/.
© The Author(s) 2023
ARTICLE
COMMUNICATIONS BIOLOGY | https://doi.org/10.1038/s42003-023-05334-8
14
COMMUNICATIONS BIOLOGY | (2023) 6:956 | https://doi.org/10.1038/s42003-023-05334-8 | www.nature.com/commsbio


---

# Deep Learning in Phosphoproteomics: Methods and Application in Cancer Drug Discovery

- **Authors:** Neha Varshney, Abhinava K Mishra
- **Issuer:** Proteomes
- **Type:** Scientific article
- **Published:** 2023-05-02
- **Language:** en
- **DOI:** 10.3390/proteomes11020016
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37218921/
- **Licence:** CC-BY

## Page 1 (Section: Introduction )

Citation: Varshney, N.; Mishra, A.K.
Deep Learning in Phosphoproteomics:
Methods and Application in Cancer
Drug Discovery. Proteomes 2023, 11,
16. https://doi.org/10.3390/
proteomes11020016
Academic Editor: Weiguo Andy Tao
Received: 13 February 2023
Revised: 24 April 2023
Accepted: 25 April 2023
Published: 2 May 2023
Copyright:
© 2023 by the authors.
Licensee MDPI, Basel, Switzerland.
This article is an open access article
distributed
under
the
terms
and
conditions of the Creative Commons
Attribution (CC BY) license (https://
creativecommons.org/licenses/by/
4.0/).
proteomes
Review
Deep Learning in Phosphoproteomics: Methods and
Application in Cancer Drug Discovery
Neha Varshney 1,2,*
and Abhinava K. Mishra 3,*
1
Division of Biological Sciences, Department of Cellular and Molecular Medicine, University of California,
San Diego, CA 93093, USA
2
Ludwig Institute for Cancer Research, La Jolla, CA 92093, USA
3
Molecular, Cellular and Developmental Biology Department, University of California,
Santa Barbara, CA 93106, USA
*
Correspondence: nevarshney@ucsd.edu (N.V.); abhinavamishra@ucsb.edu (A.K.M.)
Abstract: Protein phosphorylation is a key post-translational modiﬁcation (PTM) that is a central
regulatory mechanism of many cellular signaling pathways. Several protein kinases and phosphatases
precisely control this biochemical process. Defects in the functions of these proteins have been
implicated in many diseases, including cancer. Mass spectrometry (MS)-based analysis of biological
samples provides in-depth coverage of phosphoproteome. A large amount of MS data available in
public repositories has unveiled big data in the ﬁeld of phosphoproteomics. To address the challenges
associated with handling large data and expanding conﬁdence in phosphorylation site prediction,
the development of many computational algorithms and machine learning-based approaches have
gained momentum in recent years. Together, the emergence of experimental methods with high
resolution and sensitivity and data mining algorithms has provided robust analytical platforms for
quantitative proteomics. In this review, we compile a comprehensive collection of bioinformatic
resources used for the prediction of phosphorylation sites, and their potential therapeutic applications
in the context of cancer.
Keywords:
phosphoproteomics; machine learning; deep learning; cancer; post-translational
modiﬁcation; personalized medicine
1. Introduction
Protein phosphorylation is the most widespread post-translational modiﬁcation (PTM)
in eukaryotes and plays a cardinal role in regulating protein functions, such as modulating
their intracellular dynamics, stability, subcellular localization, and interaction with other
proteins [1,2]. Protein phosphorylation is reversibly controlled by protein kinases (PK) and
protein phosphatases (PP) [3]. Protein phosphorylation regulates many cellular processes,
including cellular metabolism, cell migration, cell division, proliferation and differentiation,
apoptosis, etc. [4–11]. Dysregulated phosphorylation has been identiﬁed as a hallmark of
many diseases, including numerous cancers, Alzheimer’s disease, and diabetes [12–14].
Therefore, understanding protein phosphorylation and its effects on cell signaling is a
major endeavor in the post-genomics era.
Recent advances in experimental approaches have immensely helped in the charac-
terization of PTMs. However, the analysis and understanding of PTMs involve several
challenges. Efﬁcient and sensitive methods for the detection of PTMs are indispensable.
Traditionally, techniques including Edman degradation, mutational analysis, isotopic la-
belling, or immunochemistry have been used for PTM such as protein phosphorylation
discovery [15–17]. Recently, mass spectrometry (MS)-based approaches have shown to be
useful in protein phosphorylation identiﬁcation [18]. MS provides a good platform for the
experimental determination of protein phosphorylation sites and high in-depth coverage,
and it provides opportunities for ML-based approaches to handle large datasets in public
Proteomes 2023, 11, 16. https://doi.org/10.3390/proteomes11020016
https://www.mdpi.com/journal/proteomes

## Page 2 (Section: Methods for Phosphorylation Site Prediction )

Proteomes 2023, 11, 16
2 of 19
repositories. PTM research has made remarkable progress over the years, especially after
the emergence of new computational techniques. Combined with experimental methods,
the application of bioinformatics tools in PTM analysis enables a more efﬁcient exploration
of the phosphorylation network, resulting in the timely analysis of datasets and providing
insights for biological research and drug discovery [19].
Deep learning (DL) in phosphoproteomics refers to the application of machine learn-
ing (ML) algorithms to analyze large amounts of data generated from phosphoproteomic
experiments. The aim of ML is to identify patterns, classify proteins, and make predictions
about protein phosphorylation. The data analysis in phosphoproteomics involves the
identiﬁcation of phosphopeptides based on MS/MS spectra. This can be performed by
database searches. The databases report phosphopeptide sequences along with assigned
phosphorylation sites. Next, to determine the conﬁdence of each possible phosphoryla-
tion site candidate in an identiﬁed peptide sequence, several computational algorithms or
ML-based approaches can be used. A global understanding of the protein phosphoryla-
tion network using these approaches can aid in our understanding of cellular signaling
pathways, disease mechanisms, disease onset prediction, drug development, and therapy
response in an efﬁcient yet comprehensive manner.
In this brief review, we survey the mainstream tools available to explore the phospho-
rylation network. Additionally, we present a comparative analysis of these computational
tools in terms of technique used, implementation, performance, functionality and limi-
tations from the perspective of a biologist. Finally, we discuss the applications of these
phosphoproteomics-based bioinformatics tools in cancer research in identifying novel
drug targets and advancing personalized medicine. Hence, this review aims to bridge the
gap and emphasize the complementarity between traditional MS-based methods to study
phosphoproteomics and the new cutting-edge deep-learning-based prediction methods.
2. Methods for Phosphorylation Site Prediction
The computational approaches provide a promising strategy for identiﬁcation and
understanding of phosphorylation sites. Several computational methods have been devel-
oped for phosphorylation site prediction over the years. These can be classiﬁed into two
main categories: algorithm-based and more advanced ML-based methods.
2.1. Algorithm-Based Computational Approaches
In the past, many studies used algorithm-based computational methods to predict
phosphorylation sites in which there are no learning algorithms used to gain information
directly from data. They can be further classiﬁed into simple consensus pattern-based
approaches (SCPs) and sequence similarity-based clustering methods (SSs). For example,
in 1988, one of the ﬁrst computational approaches to predict PTM sites was developed,
which used the primary sequence of the protein and SCP approach [20]. Other examples
of SCPs are PROSITE [21], ELM [22], and HPRD [23], which depend upon the presence
of an exact motif surrounding the phosphorylation site. However, SSs-based methods
were later designed to provide a high score to a query peptide that has a high similarity
score with known phosphorylation peptides, using the sequence similarity measures such
as the BLOSUM62 matrix. PostMod [24] and PSEA [25] are examples of this category.
These methods have been shown to be inappropriate for large-scale analyses since the
performance of these methods in predicting phosphorylation sites is poorer than more
advanced ML-based approaches.

## Page 3 (Section: Machine Learning (ML)-Based Computational Approaches )

Proteomes 2023, 11, 16
3 of 19
2.2. Machine Learning (ML)-Based Computational Approaches
Over the last decade, the integration of ML into a wide range of computational models
has improved prediction accuracy and gained a better understanding of protein function
and PTMs [26,27]. With the explosion of DL methods, ML-based approaches for phos-
phorylation site prediction have become more popular. ML is generally the ability of
machines to do actions based on prior knowledge and experience [28]. ML-based methods
can learn the underlying rules and signatures in the data by tuning and optimizing related
parameters during the model training process, resulting in better performance as compared
to SCP-based methods. A few examples of ML-based techniques for phosphorylation site
prediction are neural network (NN), hidden Markov models (HMM), Bayesian decision
theory (BDT), support vector machines, logistic regression (LR), random forest (RF), K-
nearest neighbor (KNN), and conditional random ﬁelds (CRFs) [29–31]. A few examples of
phosphorylation site prediction tools based on these techniques are NetPhos, KinasPhos,
DISPHOS, and Ptpset. Most of the databases and phosphorylation-site prediction tools
that use different algorithms and ML-based approaches are listed in Tables 1 and 2, respec-
tively. The development of these models have set the benchmark for ML- and DL-based
approaches for various PTM predictions.

## Page 4 (Section: Machine Learning (ML)-Based Computational Approaches )

Proteomes 2023, 11, 16
4 of 19
Table 1. List of protein phosphorylation databases.
Name
Technique
Organisms
Description/Functionality
Ref
Website
Kinome
Kinomer
HMMER 2.3.2
Eukaryotes
Annotated classiﬁcations for the protein kinase complements of
43 eukaryotic genomes
[32,33]
http://www.compbio.dundee.ac.
uk/kinomer/ (accessed on
24 April 2023)
KinaseNET
-
Human
Comprehensive source on human kinases
-
http://www.kinasenet.ca/ (accessed
on 24 April 2023)
Phosphatome
PTP
-
-
Integrates sequence and structure with cellular and biological
functions on protein tyrosine phosphatases
[34]
http://ptp.cshl.edu/ (accessed on 24
April 2023)
DEPOD
BLAST
Comprehensive and informative database on human
kinase-phosphatase substrate
[35]
http://depod.bioss.uni-freiburg.de/
(accessed on 24 April 2023)
Kinome-Phosphatome
Phospho.ELM
BLAST
Multiple
Database designed to store in vivo and in vitro phosphorylation
[36]
http://phospho.elm.eu.org/
(accessed on 24 April 2023)
PSP (PhosphositePlus)
-
Human, mouse, and rat
Resource that comprehensively curates information about the
structure and regulatory interactions of phosphorylation sites
[37]
https://www.phosphosite.org
(accessed on 24 April 2023)
UniProt
-
Multispecies
A central hub for the collection of functional information on
proteins
[38]
https://www.uniprot.org (accessed
on 24 April 2023)
EPSD (Eukaryotic
Phosphorylation site
Database)
-
Multiple
A data resource for the collection, curation, integration, and
annotation of p-sites in eukaryotic proteins
[39]
http://epsd.biocuckoo.cn (accessed
on 24 April 2023)
RegPhos 2.0 (regulatory
network in protein
phosphorylation)
-
Human, mouse, and rat
A comprehensive tool to view intracellular signaling networks
by integrating the information of metabolic pathways and
protein–protein interactions
[40]
http://140.138.144.141/~RegPhos/
(accessed on 24 April 2023)
Phospho3D 2.0
-
Multiple
A database for the collection of information on the residues
surrounding the p-site in space (3D zones)
[41]
http://www.phospho3d.org/
(accessed on 24 April 2023)

## Page 5 (Section: Machine Learning (ML)-Based Computational Approaches )

Proteomes 2023, 11, 16
5 of 19
Table 1. Cont.
Name
Technique
Organisms
Description/Functionality
Ref
Website
dbPSP
-
Prokaryotes
Collection of p-sites in prokaryotic phosphoproteins
[42]
http://dbpsp.biocuckoo.cn
(accessed on 24 April 2023)
LymPHOS
-
Human, mouse
A database for storage, sharing, and visualization of data related
with the human T-lymphocyte phosphoproteome
[43]
http://www.lymphos.org (accessed
on 24 April 2023)
P3DB
-
Plant species
Displays data in a relational, hierarchical manner that integrates
proteins, peptides, phosphosites, and spectra for each
phosphorylation event
[44]
http://www.p3db.org/ (accessed on
24 April 2023)
PHOSIDA
(Phosphorylation site
database)
-
Multiple
Structural and evolutionary investigation and prediction of
phosphosites
[45]
http://phosida.de/ (accessed on
24 April 2023)
HPRD (human protein
reference database)
BLAST
Human
A database of curated proteomic information including PTMs,
kinase/phosphatase motifs, and binding motifs pertaining to
human proteins
[46]
http://www.hprd.org (accessed on
24 April 2023)
VPTMdb
SVM, NB, RF
Virus
Predicts viral p-Ser
[47]
http://vptmdb.com:
8787/VPTMdb/ (accessed on
24 April 2023)
pTestis
-
Mouse
Testis phosphorylation sites from various studies were analyzed,
integrated with the iGPS prediction results, which present the
potential kinase–substrate regulatory relationships
[48]
http://ptestis.biocuckoo.org/
(accessed on 24 April 2023)
PhosphoPep
BLAST
Multiple
Database of protein phosphorylation sites for systems level
research in model organisms
[49]
http://www.unipep.org/
phosphopep/index.php (accessed on
24 April 2023)
PhosphoPOINT
PPI, BLASTP
Human
Annotates interactions among kinases, with their downstream
substrates and interacting phosphoproteins
[50]
http://kinase.bioinformatics.tw/
(accessed on 24 April 2023),
https://bioregistry.io/registry/
phosphopoint.protein (accessed on
24 April 2023)

## Page 6 (Section: Machine Learning (ML)-Based Computational Approaches )

Proteomes 2023, 11, 16
6 of 19
Table 2. A comprehensive list of computational tools used for phosphoproteomic data analysis, including phosphorylation site prediction, predicting kinases, and
phosphoproteomic data annotation. Column headings are as follows. Name: Name of the tool; Technique: the machine learning technique used; Organisms: list of
organisms the tool is applicable; Description/Functionality: important properties of the tool in terms of its functions; Reference; the paper describing that tool,
website: the address of that tool’s web implementation or source of access (if applicable). ANN: artiﬁcial neural network; PSSM: position-speciﬁc scoring matrices;
ZSL: zero-short learning; RNN: recurrent neural network; BLR: bagged logistic regression; LR: logistic regression algorithm; DNN: deep neural network; PPI:
protein–protein interaction; XGBoost: extreme gradient boosting; MLS: motif length selection (MLS); LSTM: long short-term memory.
Name
Technique
Organisms
Description/Functionality
Ref
Website
NetPhos 3.1
ANN
Multiple
Generates NN predictions for serine, threonine, and tyrosine phosphorylation
sites in eukaryotic proteins. Utilizes sequence composition features, both generic
and kinase speciﬁc predictions
[30]
https://mybiosoftware.com/tag/
netphos (accessed on 24 April 2023)
NetPhosK
ANN
Eukaryotes
Kinase-speciﬁc phosphorylation sites prediction
[51]
https://www.hsls.pitt.edu/obrc/
index.php?page=URL1117048165
(accessed on 24 April 2023)
Scansite 2.0
PSSM
Human
A tool built on experimental binding and/or substrate information from oriented
peptide library screening and phage display experiments, together with detailed
biochemical characterization to derive a weight matrix-based scoring algorithm
that predicts protein–protein interactions and sites of phosphorylation
[52]
https://scansite4.mit.edu/#home
(accessed on 24 April 2023)
PhosphoNet
PSSM
Human
An open source of putative phosphosites predicted after improvisation of kinase
substrate prediction algorithm to the primary structure of proteins
[53]
http://www.phosphonet.ca
(accessed on 24 April 2023)
Predphospho
SVM
Human
Predicts the changes in phosphorylation sites caused by amino acid variations at
intra- and interspecies levels
[54]
http://www.ngri.re.kr/proteo/
PredPhospho.htm (accessed on
24 April 2023)
NetworkKIN
ANN, PSSM
Human
Uses probabilistic protein association network (string) to model the context of
kinases and substrates, combined with consensus sequence motifs
[55]
https://networkin.info/ (accessed
on 24 April 2023)
jEcho
Weight vector
Human
Phosphorylation sites of kinases
[56]
http://www.healthinformaticslab.
org/supp/resources.php (accessed
on 24 April 2023)
PhoScan
Scoring function
Human
Predicts kinase-speciﬁc phosphorylation sites with sequence features by a
log-odds ratio approach
[57]
http://bioinfo.au.tsinghua.edu.
cn/phoscan/ (accessed on
24 April 2023)

## Page 7 (Section: Machine Learning (ML)-Based Computational Approaches )

Proteomes 2023, 11, 16
7 of 19
Table 2. Cont.
Name
Technique
Organisms
Description/Functionality
Ref
Website
Predphos
SVM
Multiple
Structural-based prediction of phosphorylation sites, hybrid approach,
which incorporates bootstrap resampling technique, SVM-based fusion
classiﬁers and majority voting strategy
[58]
No tool link
NetPhosYeast
ANN
Yeast
Prediction of protein phosphorylation sites in yeast
[59]
https://services.healthtech.dtu.dk/service.
php?NetPhosYeast-1.0 (accessed on
24 April 2023)
GPS 6.0
(group-based
prediction
system)
MLS, PSSM, GA
Mammalian
Protein phosphorylation sites and their cognate kinases (addresses false
positive rates in prediction)
[60,61]
http://gps.biocuckoo.org/ (accessed on 24
April 2023)
iGPS
GPS with PPI
Human
It is a GPS algorithm with the interaction ﬁlter, or in vivo GPS mainly for
the prediction of in vivo site-speciﬁc kinase-substrate relation (ssKSRs)
[62]
http://igps.biocuckoo.org/links.php
(accessed on 24 April 2023)
PPRED
PSSM, SVM
-
Incorporates only evolutionary information of PSSM proﬁle of the
proteins in predicting phosphorylation sites
[63]
http://www.cse.univdhaka.edu/~ashis/
ppred/index.php (accessed on
24 April 2023)
Phos3D
SVM
Human
Prediction of phosphorylation sites (p-sites) in proteins, originally
designed to investigate the advantages of including spatial information in
p-site prediction
[64]
https://phos3d.mpimp-golm.mpg.de/cgi-
bin/index.py (accessed on 24 April 2023)
DAPPLE 2
BLAST
Human
Homology-based prediction of phosphorylation sites
[65]
http://saphire.usask.ca/saphire/dapple2
(accessed on 24 April 2023)
EMBER
CNN + RNN
Multiple
Embedding-based multilabel prediction of phosphorylation events
(EMBER), a DL method that integrates kinase phylogenetic information
and motif-dissimilarity information into a multilabel classiﬁcation model
for the prediction of kinase motif phosphorylation events
[66]
https://github.com/gomezlab/EMBER
(accessed on 24 April 2023)
KinomeXplorer
NetworKIN algorithm,
a novel Bayesian
scoring scheme
Human and
major
eukaryotes
Analyze phosphorylation-dependent protein interaction networks
[67]
http://kinomexplorer.info/ (accessed on 24
April 2023)
PhosTransfer
CNN
Info not
available
Hierarchical kinase-speciﬁc phosphorylation site (KPS) prediction
[68]
https://github.com/yxu132/PhosTransfer
(accessed on 24 April 2023)

## Page 8 (Section: Machine Learning (ML)-Based Computational Approaches )

Proteomes 2023, 11, 16
8 of 19
Table 2. Cont.
Name
Technique
Organisms
Description/Functionality
Ref
Website
MusiteDeep
CNN/CapsNet
Human
Prediction and visualization for multiple PTMs and simultaneously potential
PTM cross-talks
[69]
https://www.musite.net (accessed
on 24 April 2023)
PROSPECT
CNN
E. coli
Predicts histidine phosphorylation sites from sequence information
[70]
https://bio.tools/prospect-web
(accessed on 24 April 2023)
DeepKinZero
ZSL
Human
Predicts the kinase acting on a phosphosite for kinases with no known
phosphosite information
[71]
https://github.com/Tastanlab/
DeepKinZero (accessed on
24 April 2023)
DeepPPSite
LSTM
Mammals and
Arabidopsis
thaliana
Long short-term memory (LSTM) recurrent network for predicting
phosphorylation sites
[72]
https://github.com/saeed344
/DeepPPSite (accessed on
24 April 2023)
DeepIPs
CNN + LSTM
Human
Identiﬁcation of phosphorylation sites using deep learning method
[73]
https://github.com/linDing-
group/DeepIPs (accessed on 24
April 2023)
Rice_Phospho
1.0
SVM
Rice
Predicts protein phosphorylation sites in rice
[74]
http://bioinformatics.fafu.edu.cn/
rice_phospho1.0 (accessed on 24
April 2023)
Yeast KID
-
Yeast
The ﬁrst literature-curated database for kinases that integrates a series of HTP
and LTP, genetic, physical, and biochemical experimental evidence with the goal
of establishing known kinase–substrate relationships.
[75]
http://www.moseslab.csb.
utoronto.ca/KID/ (accessed on 24
April 2023)
AutoMotif
SVM
The service uses a supervised support vector machine approach to predict
various types of phosphorylation sites in proteins
[76]
http://ams2.bioinfo.pl/ (accessed
on 24 April 2023)
PhosIDN
Multilayer DNN
Human
An integrated DNN approach for improving protein phosphorylation site
prediction by combining sequence and protein–protein interaction information
[77]
https://github.com/
ustchangyuanyang/PhosIDN
(accessed on 24 April 2023)
DeepPhos
CNN
Human
Uses densely connected CNN for kinase-speciﬁc phosphorylation site prediction
[29]
https://github.com/USTC-HIlab/
DeepPhos (accessed on
24 April 2023)
Chlamy-
EnPhosSite
CNN + LSTM
Chlamydomonas
reinhardtii
Can predict novel sites of phosphorylation within the entire C. reinhardtii
proteome
[78]
https://github.com/dukkakc/
Chlamy-EnPhosSite (accessed on
24 April 2023)

## Page 9 (Section: Machine Learning (ML)-Based Computational Approaches )

Proteomes 2023, 11, 16
9 of 19
Table 2. Cont.
Name
Technique
Organisms
Description/Functionality
Ref
Website
DeepPSP
DNN, SENet,
Bi-LSTM
?
Uses both local and global sequence information to improve
phosphorylation site prediction performance
[79]
https://github.com/DeepPSP (accessed on
24 April 2023)
Predikin 2.0
PSSM
Human
Utilizes the kinase sequence to build scoring matrices based on key residues
in the kinase catalytic domain that are known from structural analysis to
interact with the substrate phosphorylation site.
[80]
http://predikin.biosci.uq.edu.au (accessed
on 24 April 2023)
KinasePhos2.0
SVM
Human?
Predicts phosphorylation sites based on protein sequence proﬁle and
protein coupling pattern and the type of kinase that acts at each site
[81]
http://kinasephos2.mbc.nctu.edu.tw/
document.html,
https://bio.tools/kinasephos_2.0 (accessed
on 24 April 2023)
KinasePhos 3.0
SVM, XGBoost
Human and
others
Provides comprehensive annotations of kinase-speciﬁc phosphorylation
sites on multiple proteins. Shapley additive explanations (SHAP) was
integrated to increase the feature interpretability
[82]
https://awi.cuhk.edu.cn/KinasePhos/
index.html, https://github.com/tom-209/
KinasePhos-3.0-executable-ﬁle (accessed on
24 April 2023)
DISPHOS
(disorder-
enhanced
phosphorylation
predictor)
BLR
Human
Position-speciﬁc amino acid frequencies and disorder information is used to
improve the discrimination between phosphorylation and
non-phosphorylation sites
[83]
http://www.ist.temple.edu/DISPHOS
(accessed on 24 April 2023)
pkaPS
Scoring function
Human
Phosphorylation sites of PKA
[84]
http://mendel.imp.univie.ac.at/sat/pkaPS
(accessed on 24 April 2023)
Quokka
Seqeunce scoring
function + LR
Human
Predicts kinase-speciﬁc phosphorylation sites
[85]
http://quokka.erc.monash.edu/ (accessed
on 24 April 2023)
PHOSIDA
(phosphorylation
site database)
SVM
Multiple
Structural and evolutionary investigation and prediction of phosphosites
[45]
http://phosida.de/ (accessed on
24 April 2023)
VPTMdb
SVM, NB, RF
Virus
Predicts viral p-Ser
[47]
http://vptmdb.com:8787/VPTMdb/
(accessed on 24 April 2023)

## Page 10 (Section: Framework of ML-Based Approaches for Phosphorylation Site Prediction )

Proteomes 2023, 11, 16
10 of 19
3. Framework of ML-Based Approaches for Phosphorylation Site Prediction
Generally, ML-based computational approaches for phosphorylation site prediction
are developed using the following ﬁve steps: (1) dataset preparation; (2) selection of
encoding methods; (3) building prediction models; and (4) performance evaluation and
development of a web-server (Figure 1).
 
Figure 1. Workﬂow of machine learning-based computational approaches for phosphorylation site
prediction (SVM: support vector machine, RF: random forest, ANN: artiﬁcial neural network).
3.1. Dataset Preparation
The ﬁrst step for phosphorylation site prediction is dataset preparation that includes
the extraction of experimentally validated phosphorylation sites from the publicly available
databases, dbPTMs, and the literature [86]. A few of the protein phosphorylation databases
are enlisted in Table 1. An extracted dataset must include both positive and negative
datasets. The fragments or peptides that have the phosphorylated residues (S, T, Y) com-
piled from the aforementioned dbPTMs are considered a positive dataset. The S, T, Y amino
acids in the experimental peptides with no phospho-groups on them are considered as
negative datasets. Almost all studies use databases to gather positive samples, yet, selecting
the negative dataset is the most challenging step. While a particular residue that can be
phosphorylated can be validated experimentally, a particular residue that is not phosphory-
lated under any conditions is difﬁcult to prove experimentally. Therefore, databases contain
thousands of known phosphorylation sites but do not contain phosphorylation sites that are
known to be unphosphorylated. A few criteria to apply while extracting a negative dataset
include the selection of a site that should not have been reported as a phosphorylation
site in the positive dataset, the thresholding of a solvent accessible area of the protein, etc.
Following the construction of these datasets, the next step is the removal of homologous
and redundant sequences. The Cluster Database at high identity with tolerance (CD-hit)
is a popular program to detect and ﬁlter similar sequences [87]. The threshold of identity
between sequences is considered to range from 30% to 90%. These prepared datasets are
used as benchmark data, which are eventually divided into 80% training data for learning
and 20% testing set for model validation. The training data are used for feature selection
and ML model generation, which also includes a 5-fold internal cross-validation of the

## Page 11 (Section: Feature Encoding and Selection )

Proteomes 2023, 11, 16
11 of 19
trained classiﬁers’ performance. The testing dataset is used for further assessment and
validation of ML models using various statistical measures.
3.2. Feature Encoding and Selection
For feature encoding, all the proteins are partitioned into polypeptides in such a way
that the target residue is placed at the center of the peptide. Each polypeptide sequence
(both positive and negative datasets) is encoded as a numerical feature vector according to
the appropriate biological descriptors, such as amino acid composition [88], similarity score
to the known motifs [89], and evolutionary and structural properties [90]. Occasionally, to
enhance the prediction performance, all features are pooled, thus resulting in a combination
of features to generate learning models. Feature selection methods are then used to choose
the most relevant features while minimizing the redundancy in the data and further
improving the model performance by reducing its computational time. The feature selection
is performed at two levels: minimum redundancy maximum relevance (mRMR) approach
followed by symmetrical uncertainty (SU) selection method. mRMR is a widely used feature
selection method approach that ranks the features while taking into consideration their
importance to the classiﬁcation variable along with the redundancy among the features
themselves [91]. The SU attribute evaluation method weighs the merit of an attribute by
determining its uncertainty with reference to other sets of attributes [92].
3.3. Model Construction and Validation
Once the features have been extracted, data are used to train a model/classiﬁer for
PTM site prediction. At this point, different classiﬁers are trained, and based on the
performance of each classiﬁer, a suitable classiﬁer is selected. One of the most popular
ML-based methods used for predicting sites is SVM. SVMs are a set of points in the n-
dimensional space of data that deﬁne the boundaries of categories. It is a maximum margin
classiﬁer in which data are separated by a hyperplane, provided that they have the highest
margin over the data. RF is one of the other well-known ML-based algorithms used for
phospho-sites. RF is a supervised learning algorithm; as the name suggests, it builds forests
randomly whereby forests are groups of decision trees. Once several decision trees are
made, they are merged to make more stable and accurate stable predictions. The classiﬁer
is trained on a subset of assembled dataset (training dataset) after parameter optimization
and, ﬁnally, the predictor is ready to be assessed for performance and compared with other
methods. The prediction performance of the model is assessed by its accuracy (proportion
of correct positive and negative predictions), sensitivity or true-positive rate, F-score, and
Mathew’s correlation coefﬁcient (MCC). An independent test set is carried out to evaluate
the performance of the classiﬁer and further verify its practicality.
4. Use of Machine Learning-Based Approaches for Phosphoproteome Prediction
in Cancers
Quantitative phosphoproteomics-based approaches are powerful tools to investigate
the signaling pathways and cross-talk networks in cancer cells, assess disease prognosis,
and develop personalized treatments [8,9,93–95]. Integrating ML and multi-omics data
to classify cancer stages or accelerate the prognosis of the disease in the early stages is an
active area of investigation. Many in silico approaches for predicting the phosphoproteomic
proﬁles of cancer patients have gained attention in recent years. Sequence-based approaches
to predict phosphoproteomes have limited accuracy as phosphoproteomic proﬁles may vary
considerably across cancer patients [96]. Further, MS-based approaches are time-consuming
and expensive. Therefore, new computational methods to predict phosphoproteomic
proﬁles across cancer patients are now widely investigated. Several models have been
developed and used to predict phosphoproteome in cancer cells, discover biomarkers,
patient-speciﬁc drug targets, individualized prediction of drug response, and clinical
outcomes and toxicity [95,97–101] (Figure 2).

## Page 12 (Section: Machine Learning-Based Approaches for Phosphoproteome-Based Biomarker Prediction )

Proteomes 2023, 11, 16
12 of 19
 
Figure 2. Application of machine learning-based phosphoproteome prediction studies in cancer.
4.1. Machine Learning-Based Approaches for Phosphoproteome-Based Biomarker Prediction
The Cancer Genome Atlas (TCGA), the National Cancer Institute (NCI), and the Clini-
cal Proteomic Tumor Analysis Consortium (CPTAC) are valuable resources that provide a
collection of genomic, transcriptomic, proteomic, and phosphoproteomic data for a variety
of cancer types. Artiﬁcial intelligence (AI) can be used to train these datasets to create algo-
rithms that can predict patient-speciﬁc outcomes by predicting biomarkers. For example,
using the Boruta algorithm to identify mutant genes involved in the vascular invasion from
TCGA, the National Institute of Health, Medical Research, and AMC databases, a gene
signature was identiﬁed and a recurrence prediction model for recurrence for HCC patients
was established [102]. A convolutional NN algorithm was used to analyze proteomics and
histology imaging datasets generated by the Clinical Proteomic Tumor Analysis Consor-
tium (CPTAC) from clear cell renal cell carcinoma patients. This study reported a robust
correlation between diagnostic markers and predictions generated by the imaging-trained
classiﬁcation model [103]. Joint learning (JL) is a type of ML method to predict proteome
from the transcriptome. This method was developed using a training dataset by NCI-
CPTAC and TCGA, consisting of proteomic, phosphoproteomic, and transcriptomic data
from 77 breast and 105 ovarian cancer samples. In this powerful model, a gene-speciﬁc
regulatory network was trained, followed by creating a cross-tissue model by JL, the shared
regulatory networks and pathways across many cancer tissues. Such a robust model can
help facilitate biomarker discoveries for high- and low-risk patients in survival analyses
with different clinical outcomes due to the activation of different functional pathways [104].
Further, the proteome complexity across cancer types and within the patient-speciﬁc cohort
can also be effectively studied using these models, whereas the traditional approaches may
have limited scope to address these issues.
Further, to predict the drug response and design rational combination therapies, a
recent study used seven targeted anticancer drugs in 35 non-small cell lung cancer (NSCLC)
cell lines and 16 samples of pleural effusions from NSCLC and analyzed dynamic changes
in 52 phosphoproteins. They developed an orthogonal ML approach to predict drug
response and rational combination therapy. Such studies can supplement the existing
methods of using gene mutations to predict biomarkers by utilizing the proteomics data

## Page 13 (Section: Machine Learning-Based Approaches for Phosphoproteome-Based Patient-Specific Drug Targets and Responses )

Proteomes 2023, 11, 16
13 of 19
and predict treatment choices and therapy outcomes based on the dynamic proteome
complexity [98].
4.2. Machine Learning-Based Approaches for Phosphoproteome-Based Patient-Speciﬁc Drug
Targets and Responses
ML is becoming increasingly popular and valuable in enhancing our current un-
derstanding of established or new molecular targets in regulating stemness and cancer
metastasis. These studies are key to identifying novel phosphoproteome-based drug targets
for hard-to-treat cancers. In a recent in-depth global and phosphoproteomic analyses of
tumor cells, using protein structure modeling and interface prediction-guided mutagenesis,
the interaction between CD44 and CD81 in extracellular vesicles (EVs) secretion was identi-
ﬁed [100]. EVs are the drivers of breast cancer stemness and metastasis in triple-negative
breast cancer (TNBC). Hence, this study is seminal to identifying new molecular drug
targets with the help of ML approaches. Another study analyzed the phosphoproteomes of
cholangiocarcinoma cell lines and patient tumors using MS-based phosphoproteomics and
computational methods to identify patient-speciﬁc drug targets. This study identiﬁed the
inhibitors of histone deacetylase and PI3K pathway members as high-ranking therapies to
use in primary cholangiocarcinoma by the drug ranking using machine learning (DRUML)
algorithm [97]. Drug ranking using ML (DRUML) has also been successfully applied to
predict the efﬁcacy of anticancer drugs [105].
KSTAR is graph- and statistics-based algorithm that can capture patient-speciﬁc kinase
activities from phosphoproteomic data. This algorithm was applied to clinical breast cancer
phosphoproteomic data. The study reported that the predicted kinase activity proﬁles could
successfully identify misclassiﬁed HER2-positive breast cancer patients. In addition, the
algorithm can also identify the likelihood of clinically diagnosed HER2-negative patients
to respond to HER2-targeted therapy [106]. Thus, in addition to identifying novel drug
targets, ML-based studies are also actively contributing to our current understanding of
patient-speciﬁc drug responses.
Cellular immunotherapies are a form of personalized medicine that has revolutionized
cancer treatment. However, only a subset of patients responds to immunotherapy; hence,
there is vast room for improvement. In a recent study, ML-based algorithms were applied to
MS-based serum proteomics signatures to predict the response and toxicity of immunother-
apy. Datasets from advanced non-small cell lung cancer and malignant melanoma patients
were used in this study. Interestingly, the algorithm was able to effectively categorize
patients into groups with good and poor treatment outcomes independent of the biomarker
signatures [99].
To understand the disease progression and therapy outcome and to identify new drug
targets, a holistic understanding of the complex phosphoproteome in cancer is required.
This will involve a combination of mass spectrometry-based phosphoproteomics, together
with databases and bioinformatics tools to capture the actual, real-time activity of kinases.
Such tools could be valuable to establish a phosphoproteomics-based personalized medicine
platform for hard-to-treat cancers.
5. Conclusions and Future Perspective
The function of a protein is strongly affected by the post-translational chemical modi-
ﬁcations that play important functions in a myriad of cellular processes. Therefore, PTM
identiﬁcation is critical for the understanding of molecular functions and diseases. The
considerable amount of PTM data generated from the in-depth MS-based experimental
approaches could be used to support the development of downstream computational
identiﬁcation methods. DL is a highly effective computational approach to understand
large and complex datasets to predict PTMs. In recent years, several DL methods have been
developed to predict PTM sites with high efﬁciency. While these tools have shed light on
the quicker, efﬁcient, and less labor-intensive ways on the discovery of phosphorylation site
prediction, there are some common weaknesses in assessing these methods, and various

## Page 14 (Section: Machine Learning-Based Approaches for Phosphoproteome-Based Patient-Specific Drug Targets and Responses )

Proteomes 2023, 11, 16
14 of 19
factors should be considered in deciding which tool to choose. The most critical factor
relevant for the evaluation of prediction tools is the motif size and proper biological context.
Another important factor relevant for consideration in PTM predictor construction is the
quality of underlying data, including the amount and redundancy of example substrate
protein sequences and the level of authenticity. There are several DL algorithms employed;
however, each model has its own advantages and disadvantages. In many models, PTM
sites are predicted based on sequence information, physical properties, chemical properties,
and protein structure properties, but there is still room for approaches that are based on
reduced amino acid compositions [107–109].
Thousands of phosphorylation sites have been identiﬁed for different proteins by MS;
however, the kinase responsible for the phosphorylation of that amino acid in a few of the
reported datasets is missing. Therefore, there is a need to develop databases which could
bridge the gap between the number of experimentally identiﬁed phosphorylation sites and
the number of phosphorylation sites for which the modifying kinase is known. While PTM
identiﬁcation can be implemented with DL-based methods in a non-invasive, efﬁcient, and
low-cost way, there is still a caveat if these algorithms can be directly used for diseases
diagnoses. The over-arching problem is the false-positive rate, which is not ideal for its
application in healthcare studies where every misdiagnosis can pose a danger to a patient’s
health. An ideal model is characterized by high sensitivity and a very low false-positive
prediction rate. Therefore, further research is required to evaluate more state-of-the-art
frameworks so that these techniques could be applied in clinical practice more effectively.
A phosphorylation event is dynamic and cell type-speciﬁc and cannot be traced in a
heterogenous cell population, highlighting the importance of analyzing phosphorylation
events at the single-cell level for complex samples, such as tissues and organs. With the
advent of single-cell proteomics, the adaptation of phosphoproteomics proﬁling to single-
cells has revolutionized the ﬁeld in uncovering the heterogeneity in signaling networks,
complementing single-cell genomics and transcriptomics [110–112]. Therefore, we believe
that an integration of computational and biochemical approaches will form the basis for
the future development of methods that can reconstruct trans-regulatory networks for
heterogeneous cells in single-cell multi-omics data [113]. Another forth-coming area of
research in this ﬁeld is the characterization of cross-talk between different types of PTMs.
Mass spectrometry is one of the key platforms for proteomic analyses that involves
either a ‘bottom-up’ or a ‘top-down’ proteomics approach. The traditional ‘bottom-up’
approach employs the digestion of intact proteins into peptides, followed by introduction
into the mass spectrometer for fragmentation/detection. Majority of the ML-based methods
run smoothly on the bottom-up proteomics data. In the ‘top-down’ approach, the proteins
are ionized directly and the intact fragmented proteins rather than digestive peptides are
used in the analysis [114]. Many phosphoproteins have been studied using the top-down
approach [115–117]. However, one of the major challenges in top-down proteomics data
analysis is the complexity of the high-resolution top-down mass spectra that involves
centroiding, deconvolution, proteoform identiﬁcation, and quantiﬁcation [118]. A number
of algorithm- and ML-based approaches are now actively being developed to enhance
the predictions in the top-down proteomics. These methods will be extremely valuable
resources that will aid into our understanding of proteoform complexity and improve the
performance of disease diagnosis and drug target discovery.
Recently, ensembled learning-based feature selection methods were employed to
explore the nature of the phosphorylation of SARS-CoV-2 to contribute to SARS-CoV-2
drug discovery [119]. Finally, in the era of personalized medicine, ML-based approaches in
phosphoproteome studies will play an instrumental role both in understanding the disease
mechanisms and in identifying new therapy targets. ML-based approaches will be valuable
in discovering novel biomarkers, advance our current understanding of patient-speciﬁc
drug targets and drug responses, and facilitate cancer stage classiﬁcation.

## Page 15 (Section: References)

Proteomes 2023, 11, 16
15 of 19
Author Contributions: Conceptualization, N.V. and A.K.M.; writing—original draft preparation,
N.V. and A.K.M.; writing—review and editing, N.V. and A.K.M. All authors have read and agreed to
the published version of the manuscript.
Funding: This research received no external funding.
Institutional Review Board Statement: Not applicable.
Informed Consent Statement: Not applicable.
Data Availability Statement: Not applicable.
Acknowledgments: We would like to acknowledge the work of those researchers that could not be
cited in the present article due to space limitations. The study used PubMed and Google Scholar
search engines for the literature search.
Conﬂicts of Interest: The authors declare no conﬂict of interest.
References
1.
Ubersax, J.A.; Ferrell, J.E. Mechanisms of speciﬁcity in protein phosphorylation. Nat. Rev. Mol. Cell Biol. 2007, 8, 530–541.
[CrossRef] [PubMed]
2.
Deribe, Y.L.; Pawson, T.; Dikic, I. Post-translational modiﬁcations in signal integration. Nat. Struct. Mol. Biol. 2010, 17, 666–672.
[CrossRef] [PubMed]
3.
Hunter, T. Protein kinases and phosphatases: The Yin and Yang of protein phosphorylation and signaling. Cell 1995, 80, 225–236.
[CrossRef]
4.
Varshney, N.; Schaekel, A.; Singha, R.; Chakraborty, T.; van Wijlick, L.; Ernst, J.F.; Sanyal, K. A surprising role for the Sch9 protein
kinase in chromosome segregation in Candida albicans. Genetics 2015, 199, 671–674. [CrossRef] [PubMed]
5.
Varshney, N.; Sanyal, K. Aurora kinase Ipl1 facilitates bilobed distribution of clustered kinetochores to ensure error-free
chromosome segregation in Candida albicans. Mol. Microbiol. 2019, 112, 569–587. [CrossRef]
6.
Varshney, N.; Som, S.; Chatterjee, S.; Sridhar, S.; Bhattacharyya, D.; Paul, R.; Sanyal, K. Spatio-temporal regulation of nuclear
division by Aurora B kinase Ipl1 in Cryptococcus neoformans. PLoS Genet. 2019, 15, e1007959. [CrossRef]
7.
Humphrey, S.J.; James, D.E.; Mann, M. Protein phosphorylation: A major switch mechanism for metabolic regulation. Trends
Endocrinol. Metab. 2015, 26, 676–687. [CrossRef]
8.
Mishra, A.K.; Sharma, V.; Mutsuddi, M.; Mukherjee, A. Signaling cross-talk during development: Context-speciﬁc networking of
Notch, NF-κB and JNK signaling pathways in Drosophila. Cell. Signal. 2021, 82, 109937. [CrossRef]
9.
Mishra, A.K.; Sachan, N.; Mutsuddi, M.; Mukherjee, A. Kinase active Misshapen regulates Notch signaling in Drosophila
melanogaster. Exp. Cell Res. 2015, 339, 51–60. [CrossRef]
10.
Cohen, P. The origins of protein phosphorylation. Nat. Cell Biol. 2002, 4, E127–E130. [CrossRef]
11.
Cohen, P. The role of protein phosphorylation in the hormonal control of enzyme activity. Eur. J. Biochem. 1985, 151, 439–448.
[CrossRef]
12.
Meyerovitch, J.; Backer, J.M.; Kahn, C.R. Hepatic phosphotyrosine phosphatase activity and its alterations in diabetic rats. J. Clin.
Investig. 1989, 84, 976–983. [CrossRef]
13.
Hijazi, M.; Smith, R.; Rajeeve, V.; Bessant, C.; Cutillas, P.R. Reconstructing kinase network topologies from phosphoproteomics
data reveals cancer-associated rewiring. Nat. Biotechnol. 2020, 38, 493–502. [CrossRef] [PubMed]
14.
Blume-Jensen, P.; Hunter, T. Oncogenic kinase signalling. Nature 2001, 411, 355–365. [CrossRef] [PubMed]
15.
Kettenbach, A.N.; Rush, J.; Gerber, S.A. Absolute quantiﬁcation of protein and post-translational modiﬁcation abundance with
stable isotope-labeled synthetic peptides. Nat. Protoc. 2011, 6, 175–186. [CrossRef] [PubMed]
16.
Ross, F.E.; Zamborelli, T.; Herman, A.C.; Yeh, C.-H.; Tedeschi, N.I.; Luedke, E.S. Detection of acetylated lysine residues using
sequencing by edman degradation and mass spectrometry. In Techniques in Protein Chemistry; Elsevier: Amsterdam, The
Netherlands, 1996; Volume 7, pp. 201–208. ISBN 9780124735569.
17.
Fuchs, S.M.; Strahl, B.D. Antibody recognition of histone post-translational modiﬁcations: Emerging issues and future prospects.
Epigenomics 2011, 3, 247–249. [CrossRef]
18.
Witze, E.S.; Old, W.M.; Resing, K.A.; Ahn, N.G. Mapping protein post-translational modiﬁcations with mass spectrometry. Nat.
Methods 2007, 4, 798–806. [CrossRef]
19.
Paul, P.; Muthu, M.; Chilukuri, Y.; Haga, S.W.; Chun, S.; Oh, J.-W. In silico tools and phosphoproteomic software exclusives.
Processes 2019, 7, 869. [CrossRef]
20.
Nakai, K.; Kanehisa, M. Prediction of in-vivo modiﬁcation sites of proteins from their primary structures. J. Biochem. 1988, 104,
693–699. [CrossRef]
21.
Sigrist, C.J.A.; de Castro, E.; Cerutti, L.; Cuche, B.A.; Hulo, N.; Bridge, A.; Bougueleret, L.; Xenarios, I. New and continuing
developments at PROSITE. Nucleic Acids Res. 2013, 41, D344–D347. [CrossRef]

## Page 16 (Section: References)

Proteomes 2023, 11, 16
16 of 19
22.
Puntervoll, P.; Linding, R.; Gemünd, C.; Chabanis-Davidson, S.; Mattingsdal, M.; Cameron, S.; Martin, D.M.A.; Ausiello, G.;
Brannetti, B.; Costantini, A.; et al. ELM server: A new resource for investigating short functional sites in modular eukaryotic
proteins. Nucleic Acids Res. 2003, 31, 3625–3630. [CrossRef] [PubMed]
23.
Peri, S.; Navarro, J.D.; Amanchy, R.; Kristiansen, T.Z.; Jonnalagadda, C.K.; Surendranath, V.; Niranjan, V.; Muthusamy, B.; Gandhi,
T.K.B.; Gronborg, M.; et al. Development of human protein reference database as an initial platform for approaching systems
biology in humans. Genome Res. 2003, 13, 2363–2371. [CrossRef] [PubMed]
24.
Jung, I.; Matsuyama, A.; Yoshida, M.; Kim, D. PostMod: Sequence based prediction of kinase-speciﬁc phosphorylation sites with
indirect relationship. BMC Bioinform. 2010, 11 (Suppl. S1), S10. [CrossRef] [PubMed]
25.
Suo, S.-B.; Qiu, J.-D.; Shi, S.-P.; Chen, X.; Liang, R.-P. PSEA: Kinase-speciﬁc prediction and analysis of human phosphorylation
substrates. Sci. Rep. 2014, 4, 4524. [CrossRef]
26.
Avery, C.; Patterson, J.; Grear, T.; Frater, T.; Jacobs, D.J. Protein Function Analysis through Machine Learning. Biomolecules 2022,
12, 1246. [CrossRef]
27.
Auslander, N.; Gussow, A.B.; Koonin, E.V. Incorporating Machine Learning into Established Bioinformatics Frameworks. Int. J.
Mol. Sci. 2021, 22, 2903. [CrossRef]
28.
Jordan, M.I.; Mitchell, T.M. Machine learning: Trends, perspectives, and prospects. Science 2015, 349, 255–260. [CrossRef]
29.
Luo, F.; Wang, M.; Liu, Y.; Zhao, X.-M.; Li, A. DeepPhos: Prediction of protein phosphorylation sites with deep learning.
Bioinformatics 2019, 35, 2766–2773. [CrossRef]
30.
Blom, N.; Gammeltoft, S.; Brunak, S. Sequence and structure-based prediction of eukaryotic protein phosphorylation sites. J. Mol.
Biol. 1999, 294, 1351–1362. [CrossRef]
31.
Plewczy´nski, D.; Tkacz, A.; Godzik, A.; Rychlewski, L. A support vector machine approach to the identiﬁcation of phosphorylation
sites. Cell. Mol. Biol. Lett. 2005, 10, 73–89.
32.
Miranda-Saavedra, D.; Barton, G.J. Classiﬁcation and functional annotation of eukaryotic protein kinases. Proteins 2007, 68,
893–914. [CrossRef] [PubMed]
33.
Martin, D.M.A.; Miranda-Saavedra, D.; Barton, G.J. Kinomer v. 1.0: A database of systematically classiﬁed eukaryotic protein
kinases. Nucleic Acids Res. 2009, 37, D244–D250. [CrossRef] [PubMed]
34.
Andersen, J.N.; Del Vecchio, R.L.; Kannan, N.; Gergel, J.; Neuwald, A.F.; Tonks, N.K. Computational analysis of protein tyrosine
phosphatases: Practical guide to bioinformatics and data resources. Methods 2005, 35, 90–114. [CrossRef] [PubMed]
35.
Damle, N.P.; Köhn, M. The human DEPhOsphorylation Database DEPOD: 2019 update. Database 2019, 2019, baz133. [CrossRef]
36.
Dinkel, H.; Chica, C.; Via, A.; Gould, C.M.; Jensen, L.J.; Gibson, T.J.; Diella, F. Phospho.ELM: A database of phosphorylation
sites–update 2011. Nucleic Acids Res. 2011, 39, D261–D267. [CrossRef]
37.
Hornbeck, P.V.; Zhang, B.; Murray, B.; Kornhauser, J.M.; Latham, V.; Skrzypek, E. PhosphoSitePlus, 2014: Mutations, PTMs and
recalibrations. Nucleic Acids Res. 2015, 43, D512–D520. [CrossRef]
38.
Bairoch, A.; Apweiler, R.; Wu, C.H.; Barker, W.C.; Boeckmann, B.; Ferro, S.; Gasteiger, E.; Huang, H.; Lopez, R.; Magrane, M.; et al.
The universal protein resource (uniprot). Nucleic Acids Res. 2005, 33, D154–D159. [CrossRef]
39.
Lin, S.; Wang, C.; Zhou, J.; Shi, Y.; Ruan, C.; Tu, Y.; Yao, L.; Peng, D.; Xue, Y. EPSD: A well-annotated data resource of protein
phosphorylation sites in eukaryotes. Brief. Bioinform. 2021, 22, 298–307. [CrossRef]
40.
Huang, K.-Y.; Wu, H.-Y.; Chen, Y.-J.; Lu, C.-T.; Su, M.-G.; Hsieh, Y.-C.; Tsai, C.-M.; Lin, K.-I.; Huang, H.-D.; Lee, T.-Y.; et al.
RegPhos 2.0: An updated resource to explore protein kinase-substrate phosphorylation networks in mammals. Database 2014,
2014, bau034. [CrossRef]
41.
Zanzoni, A.; Carbajo, D.; Diella, F.; Gherardini, P.F.; Tramontano, A.; Helmer-Citterich, M.; Via, A. Phospho3D 2.0: An enhanced
database of three-dimensional structures of phosphorylation sites. Nucleic Acids Res. 2011, 39, D268–D271. [CrossRef]
42.
Shi, Y.; Zhang, Y.; Lin, S.; Wang, C.; Zhou, J.; Peng, D.; Xue, Y. dbPSP 2.0, an updated database of protein phosphorylation sites in
prokaryotes. Sci. Data 2020, 7, 164. [CrossRef] [PubMed]
43.
Nguyen, T.D.; Vidal-Cortes, O.; Gallardo, O.; Abian, J.; Carrascal, M. LymPHOS 2.0: An update of a phosphosite database of
primary human T cells. Database 2015, 2015, bav115. [CrossRef]
44.
Yao, Q.; Bollinger, C.; Gao, J.; Xu, D.; Thelen, J.J. P(3)DB: An Integrated Database for Plant Protein Phosphorylation. Front. Plant
Sci. 2012, 3, 206. [CrossRef] [PubMed]
45.
Gnad, F.; Ren, S.; Cox, J.; Olsen, J.V.; Macek, B.; Oroshi, M.; Mann, M. PHOSIDA (phosphorylation site database): Management,
structural and evolutionary investigation, and prediction of phosphosites. Genome Biol. 2007, 8, R250. [CrossRef]
46.
Keshava Prasad, T.S.; Goel, R.; Kandasamy, K.; Keerthikumar, S.; Kumar, S.; Mathivanan, S.; Telikicherla, D.; Raju, R.; Shafreen,
B.; Venugopal, A.; et al. Human Protein Reference Database–2009 update. Nucleic Acids Res. 2009, 37, D767–D772. [CrossRef]
[PubMed]
47.
Xiang, Y.; Zou, Q.; Zhao, L. VPTMdb: A viral posttranslational modiﬁcation database. Brief. Bioinform. 2021, 22, bbaa251.
[CrossRef] [PubMed]
48.
Qi, L.; Liu, Z.; Wang, J.; Cui, Y.; Guo, Y.; Zhou, T.; Zhou, Z.; Guo, X.; Xue, Y.; Sha, J. Systematic analysis of the phosphoproteome
and kinase-substrate networks in the mouse testis. Mol. Cell. Proteom. 2014, 13, 3626–3638. [CrossRef]
49.
Bodenmiller, B.; Campbell, D.; Gerrits, B.; Lam, H.; Jovanovic, M.; Picotti, P.; Schlapbach, R.; Aebersold, R. PhosphoPep—A
database of protein phosphorylation sites in model organisms. Nat. Biotechnol. 2008, 26, 1339–1340. [CrossRef]

## Page 17 (Section: References)

Proteomes 2023, 11, 16
17 of 19
50.
Yang, C.-Y.; Chang, C.-H.; Yu, Y.-L.; Lin, T.-C.E.; Lee, S.-A.; Yen, C.-C.; Yang, J.-M.; Lai, J.-M.; Hong, Y.-R.; Tseng, T.-L.; et al.
PhosphoPOINT: A comprehensive human kinase interactome and phospho-protein database. Bioinformatics 2008, 24, i14–i20.
[CrossRef]
51.
Blom, N.; Sicheritz-Pontén, T.; Gupta, R.; Gammeltoft, S.; Brunak, S. Prediction of post-translational glycosylation and phosphory-
lation of proteins from the amino acid sequence. Proteomics 2004, 4, 1633–1649. [CrossRef]
52.
Obenauer, J.C.; Cantley, L.C.; Yaffe, M.B. Scansite 2.0: Proteome-wide prediction of cell signaling interactions using short sequence
motifs. Nucleic Acids Res. 2003, 31, 3635–3641. [CrossRef] [PubMed]
53.
Safaei, J.; Maˇnuch, J.; Gupta, A.; Stacho, L.; Pelech, S. Prediction of 492 human protein kinase substrate speciﬁcities. Proteome Sci.
2011, 9 (Suppl. S1), S6. [CrossRef] [PubMed]
54.
Kim, J.H.; Lee, J.; Oh, B.; Kimm, K.; Koh, I. Prediction of phosphorylation sites using SVMs. Bioinformatics 2004, 20, 3179–3184.
[CrossRef]
55.
Linding, R.; Jensen, L.J.; Pasculescu, A.; Olhovsky, M.; Colwill, K.; Bork, P.; Yaffe, M.B.; Pawson, T. NetworKIN: A resource for
exploring cellular phosphorylation networks. Nucleic Acids Res. 2008, 36, D695–D699. [CrossRef] [PubMed]
56.
Zhao, M.; Zhang, Z.; Mai, G.; Luo, Y.; Zhou, F. jEcho: An Evolved weight vector to CHaracterize the protein’s posttranslational
modiﬁcation mOtifs. Interdiscip. Sci. 2015, 7, 194–199. [CrossRef]
57.
Li, T.; Li, F.; Zhang, X. Prediction of kinase-speciﬁc phosphorylation sites with sequence features by a log-odds ratio approach.
Proteins 2008, 70, 404–414. [CrossRef]
58.
Gao, Y.; Hao, W.; Gu, J.; Liu, D.; Fan, C.; Chen, Z.; Deng, L. PredPhos: An ensemble framework for structure-based prediction of
phosphorylation sites. J. Biol. Res. (Thessalon) 2016, 23, 12. [CrossRef]
59.
Ingrell, C.R.; Miller, M.L.; Jensen, O.N.; Blom, N. NetPhosYeast: Prediction of protein phosphorylation sites in yeast. Bioinformatics
2007, 23, 895–897. [CrossRef]
60.
Xue, Y.; Ren, J.; Gao, X.; Jin, C.; Wen, L.; Yao, X. GPS 2.0, a tool to predict kinase-speciﬁc phosphorylation sites in hierarchy. Mol.
Cell. Proteom. 2008, 7, 1598–1608. [CrossRef]
61.
Wang, C.; Xu, H.; Lin, S.; Deng, W.; Zhou, J.; Zhang, Y.; Shi, Y.; Peng, D.; Xue, Y. GPS 5.0: An Update on the Prediction of
Kinase-speciﬁc Phosphorylation Sites in Proteins. Genom. Proteom. Bioinform. 2020, 18, 72–80. [CrossRef]
62.
Song, C.; Ye, M.; Liu, Z.; Cheng, H.; Jiang, X.; Han, G.; Songyang, Z.; Tan, Y.; Wang, H.; Ren, J.; et al. Systematic analysis of protein
phosphorylation networks from phosphoproteomic data. Mol. Cell. Proteom. 2012, 11, 1070–1083. [CrossRef] [PubMed]
63.
Biswas, A.K.; Noman, N.; Sikder, A.R. Machine learning approach to predict protein phosphorylation sites by incorporating
evolutionary information. BMC Bioinform. 2010, 11, 273. [CrossRef] [PubMed]
64.
Durek, P.; Schudoma, C.; Weckwerth, W.; Selbig, J.; Walther, D. Detection and characterization of 3D-signature phosphorylation
site motifs and their contribution towards improved phosphorylation site prediction in proteins. BMC Bioinform. 2009, 10, 117.
[CrossRef] [PubMed]
65.
Trost, B.; Maleki, F.; Kusalik, A.; Napper, S. DAPPLE 2: A Tool for the Homology-Based Prediction of Post-Translational
Modiﬁcation Sites. J. Proteome Res. 2016, 15, 2760–2767. [CrossRef] [PubMed]
66.
Kirchoff, K.E.; Gomez, S.M. EMBER: Multi-label prediction of kinase-substrate phosphorylation events through deep learning.
Bioinformatics 2022, 38, 2119–2126. [CrossRef]
67.
Horn, H.; Schoof, E.M.; Kim, J.; Robin, X.; Miller, M.L.; Diella, F.; Palma, A.; Cesareni, G.; Jensen, L.J.; Linding, R. KinomeXplorer:
An integrated platform for kinome biology studies. Nat. Methods 2014, 11, 603–604. [CrossRef]
68.
Xu, Y.; Wilson, C.; Leier, A.; Marquez-Lago, T.T.; Whisstock, J.; Song, J. PhosTransfer: A Deep Transfer Learning Framework for
Kinase-Speciﬁc Phosphorylation Site Prediction in Hierarchy. In Advances in Knowledge Discovery and Data Mining: 24th Paciﬁc-Asia
Conference, PAKDD 2020, Singapore, 11–14 May 2020, Proceedings, Part II; Lauw, H.W., Wong, R.C.-W., Ntoulas, A., Lim, E.-P., Ng,
S.-K., Pan, S.J., Eds.; Lecture Notes in Computer Science; Springer International Publishing: Cham, Switzerland, 2020; Volume
12085, pp. 384–395. ISBN 978-3-030-47435-5.
69.
Wang, D.; Zeng, S.; Xu, C.; Qiu, W.; Liang, Y.; Joshi, T.; Xu, D. MusiteDeep: A deep-learning framework for general and
kinase-speciﬁc phosphorylation site prediction. Bioinformatics 2017, 33, 3909–3916. [CrossRef]
70.
Chen, Z.; Zhao, P.; Li, F.; Leier, A.; Marquez-Lago, T.T.; Webb, G.I.; Baggag, A.; Bensmail, H.; Song, J. PROSPECT: A web server
for predicting protein histidine phosphorylation sites. J. Bioinform. Comput. Biol. 2020, 18, 2050018. [CrossRef]
71.
Deznabi, I.; Arabaci, B.; Koyutürk, M.; Tastan, O. DeepKinZero: Zero-shot learning for predicting kinase-phosphosite associations
involving understudied kinases. Bioinformatics 2020, 36, 3652–3661. [CrossRef]
72.
Ahmed, S.; Kabir, M.; Arif, M.; Khan, Z.U.; Yu, D.-J. DeepPPSite: A deep learning-based model for analysis and prediction of
phosphorylation sites using efﬁcient sequence information. Anal. Biochem. 2021, 612, 113955. [CrossRef]
73.
Lv, H.; Dao, F.-Y.; Zulﬁqar, H.; Lin, H. DeepIPs: Comprehensive assessment and computational identiﬁcation of phosphorylation
sites of SARS-CoV-2 infection using a deep learning-based approach. Brief. Bioinform. 2021, 22, bbab244. [CrossRef]
74.
Lin, S.; Song, Q.; Tao, H.; Wang, W.; Wan, W.; Huang, J.; Xu, C.; Chebii, V.; Kitony, J.; Que, S.; et al. Rice_Phospho 1.0: A new
rice-speciﬁc SVM predictor for protein phosphorylation sites. Sci. Rep. 2015, 5, 11940. [CrossRef] [PubMed]
75.
Sharifpoor, S.; Nguyen Ba, A.N.; Youn, J.-Y.; van Dyk, D.; Friesen, H.; Douglas, A.C.; Kurat, C.F.; Chong, Y.T.; Founk, K.; Moses,
A.M.; et al. A quantitative literature-curated gold standard for kinase-substrate pairs. Genome Biol. 2011, 12, R39. [CrossRef]
[PubMed]

## Page 18 (Section: References)

Proteomes 2023, 11, 16
18 of 19
76.
Plewczynski, D.; Tkacz, A.; Wyrwicz, L.S.; Rychlewski, L.; Ginalski, K. AutoMotif Server for prediction of phosphorylation sites
in proteins using support vector machine: 2007 update. J. Mol. Model. 2008, 14, 69–76. [CrossRef] [PubMed]
77.
Yang, H.; Wang, M.; Liu, X.; Zhao, X.-M.; Li, A. PhosIDN: An integrated deep neural network for improving protein phospho-
rylation site prediction by combining sequence and protein-protein interaction information. Bioinformatics 2021, 37, 4668–4676.
[CrossRef] [PubMed]
78.
Thapa, N.; Chaudhari, M.; Iannetta, A.A.; White, C.; Roy, K.; Newman, R.H.; Hicks, L.M.; Kc, D.B. A deep learning based
approach for prediction of Chlamydomonas reinhardtii phosphorylation sites. Sci. Rep. 2021, 11, 12550. [CrossRef]
79.
Guo, L.; Wang, Y.; Xu, X.; Cheng, K.-K.; Long, Y.; Xu, J.; Li, S.; Dong, J. DeepPSP: A Global-Local Information-Based Deep Neural
Network for the Prediction of Protein Phosphorylation Sites. J. Proteome Res. 2021, 20, 346–356. [CrossRef]
80.
Saunders, N.F.W.; Brinkworth, R.I.; Huber, T.; Kemp, B.E.; Kobe, B. Predikin and PredikinDB: A computational framework for the
prediction of protein kinase peptide speciﬁcity and an associated database of phosphorylation sites. BMC Bioinform. 2008, 9, 245.
[CrossRef]
81.
Wong, Y.-H.; Lee, T.-Y.; Liang, H.-K.; Huang, C.-M.; Wang, T.-Y.; Yang, Y.-H.; Chu, C.-H.; Huang, H.-D.; Ko, M.-T.; Hwang, J.-K.
KinasePhos 2.0: A web server for identifying protein kinase-speciﬁc phosphorylation sites based on sequences and coupling
patterns. Nucleic Acids Res. 2007, 35, W588–W594. [CrossRef]
82.
Ma, R.; Li, S.; Li, W.; Yao, L.; Huang, H.-D.; Lee, T.-Y. KinasePhos 3.0: Redesign and expansion of the prediction on kinase-speciﬁc
phosphorylation sites. Genom. Proteom. Bioinform. 2022; in press. [CrossRef]
83.
Iakoucheva, L.M.; Radivojac, P.; Brown, C.J.; O’Connor, T.R.; Sikes, J.G.; Obradovic, Z.; Dunker, A.K. The importance of intrinsic
disorder for protein phosphorylation. Nucleic Acids Res. 2004, 32, 1037–1049. [CrossRef]
84.
Neuberger, G.; Schneider, G.; Eisenhaber, F. pkaPS: Prediction of protein kinase A phosphorylation sites with the simpliﬁed
kinase-substrate binding model. Biol. Direct 2007, 2, 1. [CrossRef] [PubMed]
85.
Li, F.; Li, C.; Marquez-Lago, T.T.; Leier, A.; Akutsu, T.; Purcell, A.W.; Ian Smith, A.; Lithgow, T.; Daly, R.J.; Song, J.; et al. Quokka:
A comprehensive tool for rapid and accurate prediction of kinase family-speciﬁc phosphorylation sites in the human proteome.
Bioinformatics 2018, 34, 4223–4231. [CrossRef] [PubMed]
86.
Lee, T.-Y.; Huang, H.-D.; Hung, J.-H.; Huang, H.-Y.; Yang, Y.-S.; Wang, T.-H. dbPTM: An information repository of protein
post-translational modiﬁcation. Nucleic Acids Res. 2006, 34, D622–D627. [CrossRef]
87.
Li, W.; Godzik, A. Cd-hit: A fast program for clustering and comparing large sets of protein or nucleotide sequences. Bioinformatics
2006, 22, 1658–1659. [CrossRef]
88.
Kawashima, S.; Ogata, H.; Kanehisa, M. Aaindex: Amino acid index database. Nucleic Acids Res. 1999, 27, 368–369. [CrossRef]
89.
Li, T.; Du, P.; Xu, N. Identifying human kinase-speciﬁc protein phosphorylation sites by integrating heterogeneous information
from various sources. PLoS ONE 2010, 5, e15411. [CrossRef] [PubMed]
90.
Lins, L.; Thomas, A.; Brasseur, R. Analysis of accessible surface of residues in proteins. Protein Sci. 2003, 12, 1406–1417. [CrossRef]
[PubMed]
91.
Peng, H.; Long, F.; Ding, C. Feature selection based on mutual information: Criteria of max-dependency, max-relevance, and
min-redundancy. IEEE Trans. Pattern Anal. Mach. Intell. 2005, 27, 1226–1238. [CrossRef] [PubMed]
92.
Jamal, S.; Ali, W.; Nagpal, P.; Grover, A.; Grover, S. Predicting phosphorylation sites using machine learning by integrating the
sequence, structure, and functional information of proteins. J. Transl. Med. 2021, 19, 218. [CrossRef]
93.
Scheidt, T.; Alka, O.; Gonczarowska-Jorge, H.; Gruber, W.; Rathje, F.; Dell’Aica, M.; Rurik, M.; Kohlbacher, O.; Zahedi, R.P.;
Aberger, F.; et al. Phosphoproteomics of short-term hedgehog signaling in human medulloblastoma cells. Cell Commun. Signal.
2020, 18, 99. [CrossRef]
94.
Rubbi, L.; Titz, B.; Brown, L.; Galvan, E.; Komisopoulou, E.; Chen, S.S.; Low, T.; Tahmasian, M.; Skaggs, B.; Müschen, M.; et al.
Global phosphoproteomics reveals crosstalk between Bcr-Abl and negative feedback mechanisms controlling Src signaling. Sci.
Signal. 2011, 4, ra18. [CrossRef] [PubMed]
95.
Li, H.; Guan, Y. Machine learning empowers phosphoproteome prediction in cancers. Bioinformatics 2020, 36, 859–864. [CrossRef]
[PubMed]
96.
Zhang, H.; Liu, T.; Zhang, Z.; Payne, S.H.; Zhang, B.; McDermott, J.E.; Zhou, J.-Y.; Petyuk, V.A.; Chen, L.; Ray, D.; et al. CPTAC
Investigators Integrated Proteogenomic Characterization of Human High-Grade Serous Ovarian Cancer. Cell 2016, 166, 755–765.
[CrossRef] [PubMed]
97.
Khorsandi, S.E.; Dokal, A.D.; Rajeeve, V.; Britton, D.J.; Illingworth, M.S.; Heaton, N.; Cutillas, P.R. Computational Analysis of
Cholangiocarcinoma Phosphoproteomes Identiﬁes Patient-Speciﬁc Drug Targets. Cancer Res. 2021, 81, 5765–5776. [CrossRef]
[PubMed]
98.
Coker, E.A.; Stewart, A.; Ozer, B.; Minchom, A.; Pickard, L.; Ruddle, R.; Carreira, S.; Popat, S.; O’Brien, M.; Raynaud, F.; et al.
Individualized Prediction of Drug Response and Rational Combination Therapy in NSCLC Using Artiﬁcial Intelligence-Enabled
Studies of Acute Phosphoproteomic Changes. Mol. Cancer Ther. 2022, 21, 1020–1029. [CrossRef]
99.
Park, Y.; Kim, M.J.; Choi, Y.; Kim, N.H.; Kim, L.; Hong, S.P.D.; Cho, H.-G.; Yu, E.; Chae, Y.K. Role of mass spectrometry-based
serum proteomics signatures in predicting clinical outcomes and toxicity in patients with cancer treated with immunotherapy. J.
Immunother. Cancer 2022, 10, e003566. [CrossRef]

## Page 19 (Section: References)

Proteomes 2023, 11, 16
19 of 19
100. Ramos, E.K.; Tsai, C.-F.; Jia, Y.; Cao, Y.; Manu, M.; Taftaf, R.; Hoffmann, A.D.; El-Shennawy, L.; Gritsenko, M.A.; Adorno-Cruz, V.;
et al. Machine learning-assisted elucidation of CD81-CD44 interactions in promoting cancer stemness and extracellular vesicle
integrity. eLife 2022, 11, e82669. [CrossRef]
101. Rodrigues-Ferreira, S.; Nahmias, C. Predictive biomarkers for personalized medicine in breast cancer. Cancer Lett. 2022, 545,
215828. [CrossRef]
102. Shen, J.; Qi, L.; Zou, Z.; Du, J.; Kong, W.; Zhao, L.; Wei, J.; Lin, L.; Ren, M.; Liu, B. Identiﬁcation of a novel gene signature for the
prediction of recurrence in HCC patients by machine learning of genome-wide databases. Sci. Rep. 2020, 10, 4435. [CrossRef]
103. Azuaje, F.; Kim, S.-Y.; Perez Hernandez, D.; Dittmar, G. Connecting Histopathology Imaging and Proteomics in Kidney Cancer
through Machine Learning. J. Clin. Med. 2019, 8, 1535. [CrossRef]
104. Li, H.; Siddiqui, O.; Zhang, H.; Guan, Y. Joint learning improves protein abundance prediction in cancers. BMC Biol. 2019, 17, 107.
[CrossRef] [PubMed]
105. Gerdes, H.; Casado, P.; Dokal, A.; Hijazi, M.; Akhtar, N.; Osuntola, R.; Rajeeve, V.; Fitzgibbon, J.; Travers, J.; Britton, D.; et al. Drug
ranking using machine learning systematically predicts the efﬁcacy of anti-cancer drugs. Nat. Commun. 2021, 12, 1850. [CrossRef]
[PubMed]
106. Crowl, S.; Jordan, B.T.; Ahmed, H.; Ma, C.X.; Naegle, K.M. KSTAR: An algorithm to predict patient-speciﬁc kinase activities from
phosphoproteomic data. Nat. Commun. 2022, 13, 4283. [CrossRef] [PubMed]
107. Pan, Y.; Wang, S.; Zhang, Q.; Lu, Q.; Su, D.; Zuo, Y.; Yang, L. Analysis and prediction of animal toxins by various Chou’s pseudo
components and reduced amino acid compositions. J. Theor. Biol. 2019, 462, 221–229. [CrossRef]
108. Zuo, Y.; Li, Y.; Chen, Y.; Li, G.; Yan, Z.; Yang, L. PseKRAAC: A ﬂexible web server for generating pseudo K-tuple reduced amino
acids composition. Bioinformatics 2017, 33, 122–124. [CrossRef]
109. Meng, L.; Chan, W.-S.; Huang, L.; Liu, L.; Chen, X.; Zhang, W.; Wang, F.; Cheng, K.; Sun, H.; Wong, K.-C. Mini-review: Recent
advances in post-translational modiﬁcation site prediction based on deep learning. Comput. Struct. Biotechnol. J. 2022, 20,
3522–3532. [CrossRef]
110. Schoof, E.M.; Furtwängler, B.; Üresin, N.; Rapin, N.; Savickas, S.; Gentil, C.; Lechman, E.; Keller, U.A.d.; Dick, J.E.; Porse, B.T.
Quantitative single-cell proteomics as a tool to characterize cellular hierarchies. Nat. Commun. 2021, 12, 3341. [CrossRef]
111. Lun, X.-K.; Bodenmiller, B. Proﬁling Cell Signaling Networks at Single-cell Resolution. Mol. Cell. Proteom. 2020, 19, 744–756.
[CrossRef]
112. Wei, W.; Shin, Y.S.; Xue, M.; Matsutani, T.; Masui, K.; Yang, H.; Ikegami, S.; Gu, Y.; Herrmann, K.; Johnson, D.; et al. Single-Cell
Phosphoproteomics Resolves Adaptive Signaling Dynamics and Informs Targeted Combination Therapy in Glioblastoma. Cancer
Cell 2016, 29, 563–573. [CrossRef]
113. Pérez-Mejías, G.; Velázquez-Cruz, A.; Guerra-Castellano, A.; Baños-Jaime, B.; Díaz-Quintana, A.; González-Arzola, K.; Ángel
De la Rosa, M.; Díaz-Moreno, I. Exploring protein phosphorylation by combining computational approaches and biochemical
methods. Comput. Struct. Biotechnol. J. 2020, 18, 1852–1863. [CrossRef]
114. Smith, L.M.; Kelleher, N.L. Consortium for Top Down Proteomics Proteoform: A single term describing protein complexity. Nat.
Methods 2013, 10, 186–187. [CrossRef] [PubMed]
115. Chen, J.; Shiyanov, P.; Green, K.B. Top-down mass spectrometry of intact phosphorylated β-casein: Correlation between the
precursor charge state and internal fragments. J. Mass Spectrom. 2019, 54, 527–539. [CrossRef] [PubMed]
116. Gafken, P.R.; Lampe, P.D. Methodologies for characterizing phosphoproteins by mass spectrometry. Cell Commun. Adhes. 2006, 13,
249–262. [CrossRef] [PubMed]
117. Zabrouskov, V.; Ge, Y.; Schwartz, J.; Walker, J.W. Unraveling molecular complexity of phosphorylated human cardiac troponin I
by top down electron capture dissociation/electron transfer dissociation mass spectrometry. Mol. Cell. Proteom. 2008, 7, 1838–1849.
[CrossRef] [PubMed]
118. McIlwain, S.J.; Wu, Z.; Wetzel, M.; Belongia, D.; Jin, Y.; Wenger, K.; Ong, I.M.; Ge, Y. Enhancing Top-Down Proteomics Data
Analysis by Combining Deconvolution Results through a Machine Learning Strategy. J. Am. Soc. Mass Spectrom. 2020, 31,
1104–1113. [CrossRef] [PubMed]
119. Liu, S.; Cui, C.; Chen, H.; Liu, T. Ensemble learning-based feature selection for phosphorylation site detection. Front. Genet. 2022,
13, 984068. [CrossRef] [PubMed]
Disclaimer/Publisher’s Note: The statements, opinions and data contained in all publications are solely those of the individual
author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to
people or property resulting from any ideas, methods, instructions or products referred to in the content.


---

# Development and evaluation of a java-based deep neural network method for drug response predictions

- **Authors:** Beibei Huang, Lon W R Fong, Rajan Chaudhari, Shuxing Zhang
- **Issuer:** Frontiers in artificial intelligence
- **Type:** Scientific article
- **Published:** 2023-03-23
- **Language:** en
- **DOI:** 10.3389/frai.2023.1069353
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37035534/
- **Licence:** CC-BY

## Section: Abstract

AbstractAccurate prediction of drug response is a crucial step in personalized medicine. Recently, deep learning techniques have been witnessed with significant breakthroughs in a variety of areas including biomedical research and chemogenomic applications. This motivated us to develop a novel deep learning platform to accurately and reliably predict the response of cancer cells to different drug treatments. In the present work, we describe a Java-based implementation of deep neural network method, termed JavaDL, to predict cancer responses to drugs solely based on their chemical features. To this end, we devised a novel cost function and added a regularization term which suppresses overfitting. We also adopted an early stopping strategy to further reduce overfit and improve the accuracy and robustness of our models. To evaluate our method, we compared with several popular machine learning and deep neural network programs and observed that JavaDL either outperformed those methods in model building or obtained comparable predictions. Finally, JavaDL was employed to predict drug responses of several aggressive breast cancer cell lines, and the results showed robust and accurate predictions with r2 as high as 0.81.Keywords: artificial intelligence (AI), deep learning, deep neural network, quantitative structure activity relationship (QSAR), multilayer neural network (MNN), triple-negative breast cancer (TNBC), drug response

## Section: 1. Introduction

Over the past ten years, many machine-learning methods have been developed to tackle the problem of identifying drugs that would work best for a given patient population (Murphy, 2011; Bizzego et al., 2019; Freedman, 2019; Steventon et al., 2019; Vamathevan et al., 2019; Woo, 2019). Recently a new branch of machine learning known as deep learning has been gaining significant attention (Tan et al., 2016a; Lee et al., 2019; You et al., 2019; Zeng et al., 2019; Adam et al., 2020; Baskin, 2020). In particular, the resurgence of neural networks took place around 2005 when more efficient training algorithms were developed and improvements in overfitting were made. This has led to the success of deep neural networks with many applications to biomedical research such as protein structure prediction and drug repositioning (Reddy et al., 2014; Heffernan et al., 2015; Tan et al., 2016b; Carpenter and Huang, 2017; Chaudhari et al., 2017; Smalley, 2017; Tsao et al., 2017; Evans et al., 2018; Lo et al., 2018; Robichaux et al., 2018; Segler et al., 2018; Senior et al., 2020; Humphreys et al., 2021; Jumper et al., 2021). Moreover, deep learning has been employed to diagnose diseases based on medical images (Acharya et al., 2018; Du et al., 2018; Jang et al., 2018; Gurovich et al., 2019; Indraswari et al., 2019; Jeyaraj and Nadar, 2019; Ma et al., 2019).

In the canonical configuration, a normal deep neural network (DNN) consists of an input layer where an input signal is fed, an output layer where predictions are generated, and several hidden (middle) layers which capture features during the training (Kang et al., 2018). DNN is also considered a type of representation learning, in that it allows a machine to be fed raw data and automatically discover the representations needed for detection. During the training process, the raw data in the form of certain signals are fed into the input layer and then transported from one hidden layer to another, in each one leaving a trail forming a certain increasingly abstractive pattern. For instance, in image processing the raw data are arrays of pixel values, while in QSAR modeling it may be descriptors including a variety of physical chemical properties of compounds. Such applications involve a large amount of input data, exposing the drawbacks of previous multilayer neural network (MNN) programs, which only accept limited numbers of input descriptors and have limited numbers of hidden layers and neurons in a hidden layer. Due to these limitations, networks with only a single hidden layer were largely abandoned (Winkler and Le, 2017).

One of the major issues with artificial neural networks is that the models are significantly complex, since neural networks usually have large numbers of layers containing many neurons. The number of connections in these models is astronomical, easily reaching the millions, and overfitting thus becomes very common (Gawehn et al., 2016). In general, there is a direct trade-off between overfitting and model complexity. Inadequately complex models may not be powerful enough to capture all the information necessary to solve a problem, but overly complex ones (especially with a limited amount of data) tend to run into the risk of overfitting (Gawehn et al., 2016). Besides overfitting, another challenge in drug response prediction comes from the activity cliff that is formed when a pair of structurally similar molecules display a large difference in potency (Bajorath, 2017; Watanabe et al., 2017). From the perspective of chemical structures, the activity cliff indicates a lack of assayed compounds in the surrounding space. This can also lead to poorly generalized models and overfitting. Furthermore, the distance between compounds is defined based on their relationship to neighboring compounds. Hence almost all current published prediction models are flawed to some degree due to the limitations that arise from one or more of the above problems.

In the present study, we aim to develop a novel method and build robust models that accurately predict drug response in cancer cells. To this end, we designed an approach which employs deep learning algorithms for drug activity prediction. Our software package, termed JavaDL, integrates several of the latest improved techniques, including regularization, dropout, and early stopping, to mitigate the issues caused by overfitting and activity cliffs. In order to assess its robustness, we used two very different datasets: a Caco-2 dataset for permeability prediction and a hERG dataset for cardiovascular toxicity prediction. We also evaluated the ability and robustness of JavaDL to perform big data analysis using the Merck Molecular Activity Challenge dataset from Kaggle. Finally, our software was employed to predict the drug response of cancer cells using data we recently curated and experimentally measured. The results show that JavaDL could obtain significantly improved prediction and have broad applicability in a variety of datasets as well as a high capability to handle big data problems.

## Section: 2. Methods

Activation function based on the Tanh function tanh(x) and its derivative tanh'(x).

The overall framework of JavaDL including data processing and DNN implementation.

The overall flowchart of JavaDL Algorithm.

## Section: 2. Methods › 2.1. Dataset

For model building and prediction evaluation, we compared JavaDL with several published studies using the exact same datasets. The first dataset was curated by our group and it has been used to build Caco-2 permeability prediction models with kNN and SVM (Du-Cuny et al., 2009; Smith et al., 2018). The whole dataset contains 174 compounds with 334 descriptors calculated using MOE. Another dataset contains hERG blockers with their corresponding known hERG inhibition activity (pIC50) obtained from previous publications (Du-Cuny et al., 2011). This dataset includes 639 hERG active and inactive compounds. Similarly, MOE was used to calculate the molecular descriptors which were normalized to avoid disproportional weighting for both datasets (Du-Cuny et al., 2011). In addition, to evaluate the ability of JavaDL to handle big data, we obtained a dataset for the Merck Molecular Activity Challenge on Kaggle. The original training data set contained 1,569 compounds with 4,505 descriptors, which after washing shrank to 1,983 descriptors.1 Finally, we applied JavaDL to predict the TNBC cell response to drugs. The experimental data of cancer cell response to drugs were collected from the MIPE project at the National Center for Advancing Translational Science (NCATS)2 and our own laboratory's data. We focused on triple-negative breast cancer (TNBC) due to our own research interest, but the approach can be easily applied to other cancer cell lines or even other diseases. In particular, we selected four breast cancer cell lines, HCC-1937, MDA-MB-436, MDA-MB-231, and MDA-MB-453, representing four different TNBC molecular subtypes. The dataset contains 274 compounds used in all four cell lines. Each compound is described by 205 molecular descriptors and four half maximal activity (log) concentration (LAC50) values (one for each cell line). Although internal cross validation is generally considered sufficient to justify model predictive power (Tropsha et al., 2003; Zhang et al., 2006a), many researchers have argued that external validation is crucial. In this study compounds in our datasets are divided into training and test sets via a rational approach based on the Sphere Exclusion algorithm (Golbraikh et al., 2003; Zhang et al., 2006b).

## Section: 2. Methods › 2.2. Techniques to address challenges in DNN

Activation function based on the Tanh function tanh(x) and its derivative tanh'(x).

## Section: 2. Methods › 2.2. Techniques to address challenges in DNN › 2.2.1. Activation function

For our program, we essentially adopted a backpropagation algorithm to train the deep neural network. Based on our experience and other reports (Hornik, 1991; Maggiora, 2006; Hinton, 2014; Ma et al., 2015; Angermueller et al., 2016; Gawehn et al., 2016), we included five total layers for our deep neural networks, with three hidden layers. Assuming five nodes in the input layer and one node in the output layer, three hidden layers each containing 20 hidden nodes makes the total number of variables (weight variables) 920. In contrast to frequently used activation functions in previous studies (Ma et al., 2015), on each hidden node we adopted an activation function tanh(x) =e2x-1e2x+1 (Figure 1), with which one of the advantages is to avoid bias in the gradient during training. For the loss function we chose mean squared error. In the backpropagation process we employed the stochastic gradient descent algorithm for optimization. Additionally, JavaDL has been implemented in a way to deal with data featuring different scales and complexity. For instance, to build a model from a limited dataset, the five-layer structure with each layer containing 20 neurons is sufficient. However, for large datasets such as those in the Merck Molecular Activity Challenge competition, JavaDL can grow accordingly the number of layers and neurons with corresponding increase of the connections between neighboring layers.

Activation function based on the Tanh function tanh(x) and its derivative tanh'(x).

## Section: 2. Methods › 2.2. Techniques to address challenges in DNN › 2.2.2. Regularization

To address the overfitting issue, we adopted a common regularization technique: addition of a regularization term to the cost function. It is based on the relation between the regularized overall squared-error cost function and the correlation coefficient q2. Given a training set of m examples, the overall squared-error cost function J(W, λ) is considered below:

where nl denotes the number of layers in the network. Sl represents the number of nodes on lay l, and Wijl denotes the weight of the connection between node i on lay l and node j on lay l+1. The first term is an average sum-of-squares error. For simplicity, we neglect the bias term, but it can be easily taken into account. The second term is the weight decay term, which suppresses overfitting via tuning the value of λ to decrease the magnitude of the weights. The method of minimizing the cost function by searching for the optimal value of λ is introduced in Burden and Winkler (2008). This method, called Bayesian Regularized Neural Networks, involves incorporating Bayes' theorem into the regularization scheme. It has been frequently used in current research.

We defined our own cost function by replacing the average sum-of-squares error with – q2

where y¯ is the average actual activity of the training set. The relation in equation 3 guarantees the consistency between the results from the minimization of J and the maximization of q2; therefore we consider only the minimization of cost J(W, λ) hereafter.

## Section: 2. Methods › 2.2. Techniques to address challenges in DNN › 2.2.3. Dropout and early stopping

It has been suggested to use at least two hidden layers with a minimum of 250 neurons in each layer (Ma et al., 2015). Since our DNNs have a large number of layers containing many neurons, the increasing number of connections between these neurons makes the corresponding Hessian matrix in the backpropagation process increase complexity by O(N2), where N is the layer size, and the number of variables in these models can reach into the millions easily. To improve efficiency, JavaDL adopts a process of randomly “dropping out” some neurons in the hidden layers during the training process, which involves temporarily removing the randomly selected neurons from the network, along with all their incoming and outgoing connections (Srivastava et al., 2014). This strategy reduces the complexity of JavaDL's backpropagation computation and ameliorates overfitting as well. Several other methods have also been used to implement the early stopping strategy in JavaDL. The default early stopping criterion of JavaDL is based on the evaluation of the cost function value on a test set.

## Section: 2. Methods › 2.3. Implementation of JavaDL

The overall framework of JavaDL including data processing and DNN implementation.

The overall flowchart of JavaDL Algorithm.

## Section: 2. Methods › 2.3. Implementation of JavaDL › 2.3.1. The overall framework

The overall framework of our system consists of four steps as illustrated in Figure 2. The first step is to curate compound structures and their corresponding bioactivities from literature and other online sources. In the second step we calculate the descriptors of compounds with MOE3 and CDK.4 The third step is to clean the data as described below, and in the final step the data is used as input to JavaDL to train the program and build models. We chose XML as the format for parameter input to provide extra flexibility for the use of the program: since it is verbose, self-describing and extendable, it can be easily incorporated in other applications. Our software was developed using DL4J, an open-source, distributed deep-learning library. For easy-to-access and easy-to-use, the software package is made available online along with an instruction manual (https://www.imdlab.net/JavaDL/) for download upon request.

The overall framework of JavaDL including data processing and DNN implementation.

## Section: 2. Methods › 2.3. Implementation of JavaDL › 2.3.2. Data cleaning

Online or published data are rich but often “dirty,” and thus generally need further cleaning and curation. Detection of true outliers is of particular importance; therefore, outlier separation from the main data is included in the data-washing step. The premise here is that similar structures have similar biological activity and that the multidimensional response surface to densely sampled data follows a normal distribution (Maggiora, 2006; Husby et al., 2015). Therefore, we adopted the Pauta criterion to detect abnormal activity-value points, defining a compound with activity value over three standard deviations (3σ) from the mean as an outlier. However, to be statistically significant, the number of compounds similar to the outlier in the descriptor space should be more than 10.

Currently over 5,000 molecular descriptors have been reported (Xue et al., 2004; Ballabio et al., 2009), thus requiring selection of the most relevant and independent descriptors that can represent specific properties of the chemical entities, with smaller numbers of descriptors preferred. Principal components analysis (PCA) has been frequently employed to reduce the dimension of the descriptor matrix (Chan Phooi M'ng and Mehralizadeh, 2016; Zhang et al., 2018). Our initial implementation was based on PCA: given a descriptor matrix Mm×n=(a1T,a2T,a3T⋯anT), in which n denotes the number of compounds and aiT represents the vector containing m descriptors; the algorithm is then described in the following steps:

Step 1. Calculate the mean of each column ai¯=1m∑j=1maij and substract the mean (a1~,a2~,a3~⋯an~ );

Step 2. Calculate the covariance matrix;

Step 3. Calculate the eigenvectors and eigenvalues of the covariance matrix Mcov, then order them by eigenvalues from highest to lowest;

Step 4. Select P important eigenvectors from the highest P eigenvalues to compose a feature matrix Mfeature, n×p = (v1, v2, ⋯vp);

Step 5. With the new feature matrix, we derive a new low-dimension matrix via Mfeature,n×pT×Mm×nT for model building.

However, during the process, the challenge was that the descriptor covariance is too high and P is difficult to select. To overcome this problem, we implemented a simple workaround: instead of considering the covariance of descriptors between two compounds, we considered the correlation between two descriptors. In the descriptor matrix Mm×n = (b1, b2⋯bn), bi represents the ith descriptor vector. We assume if there is a high correlation between descriptor vectors bi and bj, they are not considered orthogonal to each other, since either alone carries enough information to distinguish signals during the training process. Our final implementation with a simple algorithm to exclude the redundant descriptors is as follows:

1. For i = 1 to n

2. For j = i to n

3. If corr(bi, bj) > threshold

4. Delete column j from M

5. End if

6. End for

where corr(bi, bj) is the function calculating the value of correlation between bi and bj, and “threshold” denotes the tolerance value for the correlation coefficient. Equation 2 is used to evaluate the correlation directly. This is much more efficient and effective.

## Section: 2. Methods › 2.3. Implementation of JavaDL › 2.3.3. Deep learning implementation

Our JavaDL employs deep layer neural networks as the primary training engine. A variable selection procedure was also implemented as an option, in particular for small datasets, where for each predefined number of variables it seeks to optimize the models with the highest correlation coefficient (q2) (equation 2) for both internal training set and external test set. Figure 3 shows the flowchart of JavaDL training process, in which the backpropagation algorithm is utilized. The most time-consuming step in this algorithm is the calculation of the stochastic gradient descent (SGD) in each layer and the weight (neuron connections) adjustment to minimize the errors derived from our overall squared-error cost function J(W,λ) (equation 1) in each iteration. In other words, through the backpropagation algorithm, JavaDL knows how to reduce the error from the cost function, rather than from blindly wandering in space or being guided by a scalar quantity such as the random walk in the Metropolis algorithm.

Generally, the time complexity is determined by the number of descriptors chosen and the structure of the neural network. Let k denote the number of descriptors picked from K total descriptors, m, n the number of layers and neurons, respectively, in each layer (assume each layer contains the same number of neurons), and d the size of the mini-batch representing the minimum iteration time in the training process, the time complexity is then O(CKkmnd).

The overall flowchart of JavaDL Algorithm.

## Section: 3. Results and discussion

Method comparison with the Caco-2 dataset.

Method comparison with the hERG dataset.

Predicted vs. actual activities obtained for test sets. (A) Prediction of Caco-2 permeability using JavaDL with five descriptors: BCUT_ PEOE_3, GCUT_SLOGP_1, mr, a_base, vsa_base. (B) Prediction of hERG activity with five descriptors: GCUT_PEOE_3, reactive, SlogP_V SA1, SlogP_V SA9, and vdw_area.

Predicted vs. actual biological activities for the Merck Molecular Activity Challenge big data set in Kaggle competition. The model was built using 1,569 compounds with 4,505 descriptors. Among them 250 compounds are picked out randomly for test predictions, and the best model derived (A) q2 = 0.99, shown in the left panel, and (B) r2 = 0.65, shown in the right panel.

Predicted vs. actual activities (IC50) of drugs in TNBC, including (A) HCC-1937, (B) MDA-MB-231, (C) MDA-MB-453, and (D) MDA-MB-436. The red-circled compound 3-Methyladenine as an outlier was not accurately predicted. Further analysis shows that no compound in the training set is similar enough to 3-Methyladenine while there are always similar compounds to the accurately predicted ones (blue-circled Afatinib and UNC-0638).

From left to right is 3-Methyladenine, Afatinib and UNC-0638, respectively. 3-Methyladenine was not accurately predicted while the other two compounds obtained accurate prediction of their activity in TNBC.

## Section: 3. Results and discussion › 3.1. Comparison with other machine learning programs

Before training, we first performed data wash as described previously and then divided the data into two sets using the Sphere Exclusion (SE) algorithm (Golbraikh et al., 2003; Zhang et al., 2006b). For the Caco-2 dataset, one is for training with 80 compounds and the other is for testing with 20 compounds. It should be noted that the division process is executed each time after changing the descriptors during iterations. The same procedure was followed for the hERG dataset, with 133 compounds for training and 14 compounds for testing. Results from JavaDL are compared with those obtained by kNN, SVM, Random Forest, XGBoost, and CNN (1D) methods as shown in Tables 1, 2. Also as illustrated in Figure 4 our models show high correlation between the actual and predicted activities for the test sets. The statistical parameters used to assess models, including q2 and r2, demonstrate the comparable performance of JavaDL to other machine learning algorithms, particularly when datasets are small. For the first three ML methods list in Tables 1, 2, we directly adopted sklearn libraries, such as sklearn.neighbors.KNeighborsRegressor, sklearn.svm.SVR and sklearn.ensemble.RandomForestRegressor, for the regression tasks. The default optimized parameters were used unless otherwise stated. The architectures and parameters of CNN and our own JavaDL are described in the Supporting Information.

We also examined our JavaDL program using a large data set from the Merck Molecular Activity Challenge as described above. Since this would make the training computationally intensive, we have implemented a parallel computing function for JavaDL so that it can efficiently handle big data with a large number of compounds and high dimensional space (number of descriptors). With 250 compounds in the test set, our model achieved robust predictions with q2 = 0.99 and r2 = 0.65. These results demonstrate significant superiority to all published models released by the Merck Molecular Activity Challenge where r2 was below 0.49. Our models and predictions are shown in Figure 5.

Method comparison with the Caco-2 dataset.

Method comparison with the hERG dataset.

Predicted vs. actual activities obtained for test sets. (A) Prediction of Caco-2 permeability using JavaDL with five descriptors: BCUT_ PEOE_3, GCUT_SLOGP_1, mr, a_base, vsa_base. (B) Prediction of hERG activity with five descriptors: GCUT_PEOE_3, reactive, SlogP_V SA1, SlogP_V SA9, and vdw_area.

Predicted vs. actual biological activities for the Merck Molecular Activity Challenge big data set in Kaggle competition. The model was built using 1,569 compounds with 4,505 descriptors. Among them 250 compounds are picked out randomly for test predictions, and the best model derived (A) q2 = 0.99, shown in the left panel, and (B) r2 = 0.65, shown in the right panel.

## Section: 3. Results and discussion › 3.2. Predicting cancer response to drugs

As discussed, it is critical to predict individual cancer cell response to different drugs. Such information can provide insight into what drugs can be used to treat what type of cancer with the highest sensitivity. With TNBC screening data from NCATS and our own experiments, we performed data pre-processing, and the total number of compounds for each of the four TNBC cell lines was reduced to 186, 163, 146, and 172, respectively. In each group we randomly selected 40 compounds as the external test set, and set qthreshold2=0.60 and rthreshold2=0.55 as criteria to determine if a model is acceptable. Since the data is sufficiently large and JavaDL can handle big data efficiently, we took into account all descriptors of the compounds for model building and final predictions. The measured and predicted activities with our best models are shown in Figure 6. The curated datasets for four TNBC cell lines with training source code are available at https://www.imdlab.net/JavaDL/.

Predicted vs. actual activities (IC50) of drugs in TNBC, including (A) HCC-1937, (B) MDA-MB-231, (C) MDA-MB-453, and (D) MDA-MB-436. The red-circled compound 3-Methyladenine as an outlier was not accurately predicted. Further analysis shows that no compound in the training set is similar enough to 3-Methyladenine while there are always similar compounds to the accurately predicted ones (blue-circled Afatinib and UNC-0638).

## Section: 3. Results and discussion › 3.3. Discussion

In this study, we present a new deep-learning method for predicting the efficacy of small-molecule anti-cancer therapeutic agents. The novelty of this implementation lies in multiple aspects. The first is that prediction of drug response has been challenging due to the intrinsic complexity of cancer cells and various unknown cell survival mechanisms (Hu et al., 2016; Tan and Zhang, 2016); DNN is exactly designed to handle this type of “black-box” problems through a continuous self-learning process. Second, we have implemented a variety of strategies to address several frequent issues including data cleaning, overfitting, outliers, and program complexity. Third, we designed a new scoring activation function and cost function. Fourth, JavaDL is able to predict the response of cancer cells to drugs using only structural information from compounds, and it can be easily expanded to include cell gene profile change upon drug treatment for predictions. Finally, DNN is combined with variable selection in this parallelized implementation and we could identify specific descriptors that are critical for activities. Such information is tremendously helpful to guide actual rational drug design.

Using two very well studied datasets (hERG and Caco-2) as benchmarks, we obtained robust results demonstrating the superiority of our multiple-layer DNN techniques to several machine learning techniques such as kNN and SVM. As expected, its predictive capability is comparable to some popular methods including Random Forest, XGBoost, and CNN. Of note, such observations are not only related to modeling methods and training parameters, but also highly dependent on the datasets used. In addition, our models could effectively capture the abstract relation between the structural features of chemical compounds and their activities. Also as shown, JavaDL was successfully employed to predict the response of aggressive TNBC cell lines to different drugs, which has been a challenge in personalized cancer therapy. Moreover, this indicates that JavaDL may potentially be used as a general screening tool to predict activities of novel compounds in different cancer cells, and thus helping to lower costs of anticancer therapeutics screening. It is mostly worth to mention that, as one of the signified features of deep learning, our prediction of the Merck Molecular Activity Challenge dataset demonstrated the capacity of JavaDL to handle big data problems with a large number of points in a high dimensional space.

As mentioned, the variable selection feature in this implementation is particularly useful for rational molecular design, and identification of selected descriptors, when combined with chemical structures, can be employed to interpret the molecular structure-activity relationship and guide lead optimization in drug development. For instance, the descriptors selected in the Caco-2 permeability model are PEOE Charge BCUT, GCUT logP, molecular refractivity, number of basic atoms, and Van der Waals basic surface area. It makes sense that all of these properties, in particular logP, charges, and molecular refractivity, are highly correlated with the permeability of the compounds. While GCUT logP contributes positively to permeability, the other four have negative impact on permeability. Such relationship is demonstrated by the comparison of quinidine (Caco-2 P = −4.69) and ranitidine (Caco-2 P = −6.31) where quinidine has much higher GCUT logP while the other four properties have lower values than ranitidine. Similar observations have been obtained in the case of hERG and TNBC studies.

Some cheminformatics practitioners contend that machine learning has not fulfilled its promise in predicting biological activity (Golbraikh and Tropsha, 2002; Kovalishyn et al., 2018). Poor predictivity is a problem in most models, and there are a variety of possible reasons for this including the incorrect assignment of molecular properties, chance correlation, rough response surfaces, and overtraining (Robichaux et al., 2018; Jumper et al., 2021). With JavaDL we obtained significant improvement of prediction over other machine-learning models, with most of the prediction errors below one unit, which is usually acceptable in drug design and development. For a few compounds our prediction is not ideal. As shown in Figure 6C, the compound 3-methyladenine (structure shown in Figure 7) is identified as an outlier with the worst prediction in MDA-MB-453 cell lines. To elucidate the reason, we calculate the similarity of 3-methyladenine to other compounds in the training dataset based on their Euclidean distance. We found that the distance to the most similar compound (theobromine) is SD3−methyladenine = 1.49. Similarly, we randomly selected two compounds (afatinib and UNC-0638 shown in Figure 7) that were accurately predicted (Figure 6C) and computed their corresponding Euclidean distance to the most similar compounds. We obtained SDafatinib = 0.68 and SDUNC−0638 = 0.80, respectively. Using the Tanimoto Coefficient (TC), we observed the similar trend: for 3-methyladenine the highest TC = 0.40 (to theobromine); for afatinib and UNC-0638, TC = 0.61 (to pelitinib) and TC = 0.50 (to XL-647), respectively. This indicates that when there are similar compounds in the training set, the prediction is relatively accurate, in agreement with the general principle of QSAR that similar structures tend to have similar activities.

Our DNN-based JavaDL is not limited to drug response predictions; rather it can be very easily used for studies of large genomic and bioinformatics data to predict gene-disease association, identify biomarkers with whole genome profiling, and develop treatment algorithms based on patient response to drugs. Our promising results shown here suggest that JavaDL can be used as a general tool for the discovery and design of biologically active agents as well as for many other types of biomedical research.

From left to right is 3-Methyladenine, Afatinib and UNC-0638, respectively. 3-Methyladenine was not accurately predicted while the other two compounds obtained accurate prediction of their activity in TNBC.

## Section: 4. Availability

The program is freely available at https://www.imdlab.net/JavaDL/.

## Section: Data availability statement

The original contributions presented in the study are included in the article/Supplementary material, and further inquiries can be directed to the corresponding author.

## Section: Author contributions

SZ and BH conceived the idea and designed the algorithm. BH developed the program. SZ, BH, LF, and RC tested program and analyzed the data. All authors contributed to the article and approved the submitted version.

## Section: Acknowledgments

We thank Eric Zhang for helping build and maintain the website. Special thanks to the Deeplearning4j and CDK toolkit development teams for providing us academic licenses. We also thank the high-performance computing (HPC) resources provided by MD Anderson RIS and Texas Advanced Computing Center (TACC).

## Section: Funding Statement

This work has been partially supported by CPRIT RP170333, NIH 1R01CA225955, DOD W81XWH-20-PCRP-IDA, and MD Anderson Cancer Center Bridge Funding Program to SZ.

## Section: Conflict of interest

Author RC is currently employed by the company Eurofins Beacon Discovery. The remaining authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.

## Section: Publisher's note

All claims expressed in this article are solely those of the authors and do not necessarily represent those of their affiliated organizations, or those of the publisher, the editors and the reviewers. Any product that may be evaluated in this article, or claim that may be made by its manufacturer, is not guaranteed or endorsed by the publisher.

## Section: Supplementary material

The Supplementary Material for this article can be found online at: https://www.frontiersin.org/articles/10.3389/frai.2023.1069353/full#supplementary-material

Click here for additional data file.

## Section: Associated Data

Click here for additional data file.

## Section: Associated Data › Supplementary Materials

Click here for additional data file.

## Section: Associated Data › Data Availability Statement

The original contributions presented in the study are included in the article/Supplementary material, and further inquiries can be directed to the corresponding author.


---

# Development and Validation of an Explainable Machine Learning-Based Prediction Model for Drug-Food Interactions from Chemical Structures

- **Authors:** Quang-Hien Kha, Viet-Huan Le, Truong Nguyen Khanh Hung, Ngan Thi Kim Nguyen, Nguyen Quoc Khanh Le
- **Issuer:** Sensors (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2023-04-13
- **Language:** en
- **DOI:** 10.3390/s23083962
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37112302/
- **Licence:** CC-BY

## Section: Abstract

Possible drug–food constituent interactions (DFIs) could change the intended efficiency of particular therapeutics in medical practice. The increasing number of multiple-drug prescriptions leads to the rise of drug–drug interactions (DDIs) and DFIs. These adverse interactions lead to other implications, e.g., the decline in medicament’s effect, the withdrawals of various medications, and harmful impacts on the patients’ health. However, the importance of DFIs remains underestimated, as the number of studies on these topics is constrained. Recently, scientists have applied artificial intelligence-based models to study DFIs. However, there were still some limitations in data mining, input, and detailed annotations. This study proposed a novel prediction model to address the limitations of previous studies. In detail, we extracted 70,477 food compounds from the FooDB database and 13,580 drugs from the DrugBank database. We extracted 3780 features from each drug–food compound pair. The optimal model was eXtreme Gradient Boosting (XGBoost). We also validated the performance of our model on one external test set from a previous study which contained 1922 DFIs. Finally, we applied our model to recommend whether a drug should or should not be taken with some food compounds based on their interactions. The model can provide highly accurate and clinically relevant recommendations, especially for DFIs that may cause severe adverse events and even death. Our proposed model can contribute to developing more robust predictive models to help patients, under the supervision and consultants of physicians, avoid DFI adverse effects in combining drugs and foods for therapy.

## Section: 1. Introduction

The intended efficiency of medications or therapies can be altered due to drug–food constituent interactions (DFIs) [1]. While most DFIs cause no harm or mild effects, some may lead to adverse drug events (ADEs) [2] or severe consequences. Therefore, the awareness of DFIs is pivotal for the safe usage of oral drugs, food types, and food-originated supplements to ensure the efficacy of therapies. As the number of prescriptions containing drug–drug combinations rockets [3,4], the adverse DFIs experience a corresponding rise. The bioavailability and other parameters of medications could be reduced or increased due to the interactions with different food types or even with the physiological secretion of the body itself, e.g., the secretion of gastric acid, pancreatic digestive chemicals, and more [1]. More than 30 percent of the reported adverse drug events are related to DFIs [5]. Moreover, one of the most common causes of drug or medicament withdrawals from the market is owing to DFIs [6,7,8]. In contrast, the figure for the usage of any prescriptions rose by nearly five percent to reach 85% in 2012 [3]. This can exacerbate the probability of DFI since clinicians or patients can ensure no interactions between oral drugs and food intake.

Verapamil, terfenadine, nifedipine, cyclosporine, and more drugs were also reported with adverse events when taken with grapefruit juice [9]. It is due to the inhibiting effects of grapefruit juice on intestinal CYP3A4, a crucial isoenzyme of cytochrome P450 helping eliminate drugs [10]. Warfarin was reported to interact with various food types, in which altering the anti-coagulant effect is the most critical consideration [11,12,13]. Alcohol could cause severe adverse events, and even death, when combined with diazepam, lorazepam, acetaminophen, or methotrexate [14,15,16,17,18,19]. Foods rich in [K+], such as oranges and bananas, may cause hyperkalemia, resulting in cardiac arrest and death due to myocardial arrhythmia. Therefore, they must not be taken with renin-angiotensin system inhibitors since they elevate the blood potassium concentration by reducing aldosterone activity. In addition, tyramine-rich foods (e.g., wine, cheese, etc.) must not be combined with monoamine oxidase inhibitors (MAOIs), which are used for patients with depression. The consequence is the onset of a hypertensive crisis resulting from the growth of catecholamine biosynthesis caused by the breakdown reduction of tyramine [20].

There is a dire need to stratify which drug–food compound pairs can be taken together for the safety of patients during therapy [21]. A study in 2004 indicated that DFIs, not only among foods but also in dietary supplements, were responsible for mitigating medications’ efficacy or lasting pharmacological effects, negatively affecting patients’ health and drug labeling [6]. Four hundred sixty-two medicinal products were withdrawn from the market due to adverse drug reactions in DFIs and drug-drug interactions (DDIs) [7]. It is also evident that the elderly suffered the most from harmful DFIs [22]. Aging patients, associated with chronic comorbidities, hygiene, and changes in physiological processes, require multiple-drug therapy. One study on the senior Brazilian population [23] has depicted the correlation between disease conditions, metabolism status among aged people, and risks of adverse events resulting from DFIs. Furthermore, Mason [24] revealed that the risks of DFIs increased among infants, children, and patients who have undergone long-term therapy or those in need of particular nutritional demand (cancer, burns, diarrhea, etc.).

Various strategies have been proposed to study the adverse interactions between drugs and food constituents. Mallet et al. [25], and Chan [26] provided some measures to treat unexpected DFIs. However, the first-step clinical approach to avoiding DFIs is carefully investigating which ingesting food can cause interactions with administering oral medications and planning an appropriate combination of drugs and dietary supplements or food intake. Jensen et al. [27] proposed a MEDLINE database to explore DFIs to improve therapeutic intervention strategies. Their findings concentrated on the interactions between plant-based food constituents and drug targets. Another approach introduced by Riedmaier et al. [28] integrated with in vitro data with the knowledge of human physiology to predict food effects on drug compounds. This framework has curbed the drawbacks of other previous methods using only in vitro samples [29,30,31], or animal experiments [31,32,33]. Qin et al. deployed spectroscopy and molecular interaction to discover the inhibitory effects of apigenin and luteolin on advanced glycation end products in bovine serum albumin (BSA)-glucose and BSA-fructose models [34], in which Auto dock software (version 4.0, Scripps Institute, USA) was used to compute the minimum binding energy of the investigated proteins. However, the methods above required much information on drug targets, interacting foods, and particular effects, which usually miss input data to classify the DFIs.

The recent development of machine learning (ML) in drug discovery [35] has facilitated DDI classification tasks [5,22,36,37]. No DFI study applied advanced ML techniques to differentiate between the interaction effects of drug and food compounds, except Ryu et al. [5] and Rahman et al. [38]. In Ryu et al. [5], albeit indirectly, they employed their deep learning network trained on DDI data to discriminate the DFIs. With the presence of simplified molecular-input line-entry system (SMILES) formulas represented for constituents and public databases (e.g., DrugBank [39] and FooDB (https://foodb.ca/, accessed on 29 August 2022), Ryu et al. showed the potential of ML implementation in identifying DFIs. However, there was a need to assemble a model that could detect various DFIs straightforwardly without relying on this. Rahman et al. [38] applied a graph mining approach to forecasting DFIs. Despite the novelty, the experiment was complex to reproduce under many conditions, and the final results were unsatisfactory. Moreover, the method did not cover all drug–food constituents.

Herein, we introduced a predictive model, which utilized simple ML algorithms to classify the DFIs more conveniently, accurately, and efficiently based on their SMILES. Input data are the SMILES of drug and food compounds, which express their codified chemical structures [40]. Our model was built on an eXtreme Gradient Boosting (XGBoost) classification algorithm, with the eighteen most essential features refined through a tight, four-step feature selection method. We evaluated the robustness of our model’s prediction on one external test set. Furthermore, we used our predictor to recommend the combination of some drugs and foods in clinical practice. Clinical physicians could use the results interpreted from the model since the interactions written in readable sentences could contribute to drug prescriptions and dietary decisions.

## Section: 2. Materials and Methods

The workflow of our study, which is exhibited in Figure 1, comprised three key steps: (i) Data gathering and pre-processing, (ii) Model building and optimization, and (iii) Validations and recommendations. In the first step, we extracted the data from DrugBank [39] (version 5.1.7) and FooDB (https://foodb.ca/, accessed on 29 August 2022) (version 1.0) databases. During this step, we processed the data to reduce the number of drug and food constituents examined to 1133 and 4341, respectively. In the second step, we applied four feature selection methods to pick up eighteen optimal features among 3780. We applied five algorithms to the training set with eighteen features and then fine-tuned the parameters to find the best model. The last step evaluated the performance of our model on one external test set from the previous study [5]. Finally, we extended our study to predict some adverse DFIs of various drugs encountered in clinical practice.

## Section: 2. Materials and Methods › 2.1. Data Gathering and Pre-Processing › 2.1.1. Data Gathering

We primarily collected data from the DrugBank (version 5.1.7, 2020) [39] and FooDB (version 1.0, 2020) databases, which contained 13,580 drugs and 70,477 food constituents, respectively. We focused on DFI annotations in DrugBank and consistently selected only canonical SMILES for food and drug compounds [40].

## Section: 2. Materials and Methods › 2.1. Data Gathering and Pre-Processing › 2.1.2. Data Pre-Processing

In the FooDB database, we eliminated food compounds without SMILES (N = 70) or duplicates (N = 809). We then excluded similar foods using Tanimoto’s coefficient, which calculates the structural similarity between two constituents [5,41]. First, we used one compound as a “target” and then matched that compound to the other “query” molecules in the dataset to calculate the coefficients. This step was repeated until the last pair of compounds in the dataset. Second, we rejected which food compounds were similar in structure, meaning they had a structural similarity coefficient greater or equal to 0.75 [5,41,42]. This process resulted in the removal of 65,257 food compounds. Finally, the number of food compounds for further analysis was 4341.

For the drug database (N = 13,580), we removed compounds that do not have information on the SMILES (N = 2889) and/or do not have annotations on interactions for food compounds (N = 12,395). The final drug data set contained 1133 drug compounds with SMILES formulas and annotations of DFIs.

## Section: 2. Materials and Methods › 2.1. Data Gathering and Pre-Processing › 2.1.3. Labeling of DFIs Ground Truth

Based on annotations from DrugBank, we categorized the DFIs into three groups:Positive interactions (Class 1): (1) if two of the following conditions are met simultaneously. (a) If a drug compound in combination with a food compound, and the food compound increases the extent of absorption, increases bioavailability, increases peak concentrations, and decreases time to peak concentrations of the drug; (b) no adverse effect or toxicity for human health has been observed from DrugBank annotations. (2) If the DrugBank annotations indicate that when the drug compound is taken with the food compound, the food compound will benefit the patient (e.g., food reduces irritation, take with food to reduce nausea, food decreases the risk of gastrointestinal side effects, etc.) despite not specifying the interaction information in terms of pharmacokinetics, the pharmacodynamics of the drug. (3) If DrugBank annotations indicate “take after meals”, “take after a meal”, or “take with food” although they do not specify the information on pharmacokinetics, pharmacodynamics, or patient benefits when taking that drug with food compounds.Negative interactions (Class 0): (1) if two of the following conditions are met simultaneously. (a) If the drug is taken with food, but food reduces the extent of absorption, reduces bioavailability, decreases peak concentrations, and increases time to peak concentrations of the drug; (b) at least one adverse effect or toxicity for human health has been described from DrugBank annotations. (2) If the DrugBank annotations indicate that when the drug compound is taken with the food compound, the food compound will cause harm to the patient regardless of the interaction information in terms of pharmacokinetics and the pharmacodynamics of the drug. If DrugBank annotations contain the words “avoid”, “Take separately from meals”, “take on an empty stomach” or “take before a meal” regardless of the information on pharmacokinetics, pharmacodynamics, or benefits when taking that drug with food compounds.Non-significant interactions (Class 2): (1) if DrugBank annotations do not fall into the above two categories. (2) If DrugBank annotations state “take with or without food”, “take consistently with regard to food” regardless of pharmacokinetic or pharmacodynamic interaction information.

Drug compounds with the annotation “take at the same time every day” were not considered; however, if there were other annotations for the same drug that satisfied the conditions of the three groups mentioned above, the drug–food interactions were classified into the corresponding category. In detail, from 4341 food and 1133 drug compounds, there were 2,382,871 DFIs, including 476,642 negative DFIs, 776,146 positive DFIs, and 1,130,083 non-significant DFIs.

## Section: 2. Materials and Methods › 2.2. Model Building and Optimization › 2.2.1. Feature Extraction

We ran our experiments on Windows 10 (version 20H2) (4.60 GHz Intel i7-11800H CPU and 64 GB RAM). We used PyBioMed package [43] (PyInteraction module) and RDKit (version 1.0.3) [44] for input representation preparation of the chemical compounds. All calculations were implemented in Python 3.9.12. We extracted all drug–food pairs in SMILES to 2,382,871 number arrays with 3780 molecular operating environment (MOE) descriptors. MOE descriptors are features derived from each pair of DFIs, calculated from the low energy conformations of the composite.

slogP is the logarithm of octanol:water regional coefficient; this was calculated by Wildman and Crippen in 1999. MTPSA or “Molecule polar surface area” was calculated by estimating the polar surface area from the connection plane’s information, which was first introduced by Ertl et al. [45]. VSA was defined as the van der Waals surface area, which the polyhedral depiction of individual atoms could quantify. PEOE is the abbreviation of Partial Equalization of Orbital Electronegativities, which was introduced by Gasteiger et al. [46], and is a method used to calculate the atomic partial charges [46]. The Lorentz–Lorentz equation defines the molecular refractivity (MR) parameter or molecular refractivity:(1)MR=(n2−1n2+2)(MWd) where n is the index of refraction, MW is the molecular weight, and d is the density. MR is strongly correlated with the polarization of the respective molecule. MR can also be estimated from group-relative constants when exploratory values are absent. In total, there were seven families of descriptors.

## Section: 2. Materials and Methods › 2.2. Model Building and Optimization › 2.2.2. Feature Selection

We performed feature selection using variance threshold (VT), which removes the features with variance lower than a threshold value of 0.8. The remained features would next undergo Pearson’s correlation coefficient feature selection. If two features correlate more than 75%, we will reject one that contributes less to the outcome. All features obtained from the previous step would then be passed to the least absolute shrinkage and selection operator (LASSO) [47], with alpha set to 0.001. Afterward, we performed the RidgeCV-based recursive feature elimination with the cross-validation (RFECV) technique (five iterations of cross-validation) to filter out the best features. There were 18 optimal features; the detailed names of all features can be found in the Section 4.

## Section: 2. Materials and Methods › 2.3. Model Training

Random forest (RF), extreme gradient boosting (XGBoost), extra trees (ET), light gradient boosting machine (LGBM), and one neural-network-based classifier multilayer perceptron (MLP) were five-time cross-validated on the training set to measure the baseline performance [48]. Next, all baseline models were fine-tuned using Randomized Search Cross-Validation (CV) (five iterations) on the validation set. The best classification model was chosen based on the performance of all models on the testing set. The CV and fine-tuning results can be found in the Section 4 (Table 1, Table 2 and Table 3).

## Section: 2. Materials and Methods › 2.4. Validation and Recommendations

For the final stage, we aimed to create a model capable of yielding recommendations or warnings to assist patients and physicians in using drugs in combination with food to avoid adverse effects. The user(s) input the names of the drug and food compound into the model. Then, the model will predict whether they can be used together or not. Based on that output, the user(s) will consult a physician for the best advice. If the DFI were positive, the predicted result would be “A could be taken with food containing B”. If the DFI were non-significant, the output would be “A may be taken with food containing B”. Otherwise, the recommendation would be “A should not be taken with food containing B”.

## Section: 2. Materials and Methods › 2.5. Evaluation Metrics

Four measurement metrics [49] were taken into account to assess the performance of each algorithm in classifying the interactions:(2)Accuracy=TP+TNTP+TN+FP+FN (3)Recall=TPTP+FN (4)Precision=TPTP+FP (5)F1−score=2×Precision×RecallPrecision+Recall

TP, TN, FP, and FN represent True positive, True negative, False positive, and False negative, respectively. For each class in the multi-classification task, the Accuracy of each class is the ratio of correctly predicted instances of that class and the total number of instances. Recall is the fraction between the number of accurately predicted DFIs and all positive DFIs. Precision is calculated by the division of accurately classified DFIs and total DFIs. Recall and Precision are related; increasing the former may decline the latter, and vice versa. Therefore, the F1-score, the geometric mean of Recall and Precision, makes the result interpretations more plausible.

## Section: 3. Results › 3.1. 4341 Food Compounds and 1133 Drug Compounds from DrugBank and FooDB

Of the 4341 food compounds, 20 were inorganic, 1095 were organic, and the remaining 3226 were missing information. Among 1133 drug compounds, 22 were inorganic, 1063 were organic, and 48 were unknown. We excluded the drug–food pairs having the same mean value of 3780 features. This helps us to avoid training the models repetitively with similar interacting pairs and to increase the generalizability. This process reduced the number of samples from 2,382,903 in the benchmark dataset to 2,263,474. We then randomly split 1,133,652 (50.08%) for training, 848,803 (37.50%) for hyperparameter tuning (the validation set) and 281,019 (12.42%) for testing (the internal test set).

For the external test set, we extracted DFIs from a previous study by Ryu et al. [5]. They applied a predictive model to a validation set of 4567 DFIs. We removed 2319 duplicates of drug–food pairs, 66 drugs and 260 foods with no SMILES data in DrugBank and FooDB, respectively. Finally, the external test set consisted of 1922 instances, with 751, 378, and 793 pairs of negative, positive, and non-significant DFIs, respectively. More importantly, it contained 232 drugs not included in the training data.

## Section: 3. Results › 3.2. 18 Selected Features Can Improve the Prediction

With the threshold set to 0.8, VT eliminated 935 features from 3780 original features. For the remaining 2845 features, we normalized all training data using the standardization method from scikit-learn and performed Pearson’s correlation coefficient feature selection process. After the experiment, we picked up 1568 features correlating more to the classification outcome. Next, we fed 1568 features to LASSO with an alpha of 0.01 and filtered out 52. Finally, we performed the RidgeClassifierCV-based RFECV (cross-validation set to 5, performed on five iterations) to obtain 18 features, including MTPSA+MTPSA, MRVSA9, MRVSA8, MRVSA0, MRVSA2, VSAEstate10+VSAEstate10, EstateVSA0*LabuteASA, PEOEVSA12, PEOEVSA10, PEOEVSA5, PEOEVSA9, slogPVSA2, slogPVSA0, slogPVSA9, VSAEstate7+VSAEstate7, EstateVSA7, EstateVSA2, EstateVSA1*VSAEstate8.

We applied four ML algorithms and one neural network architecture to our training set: RF, XGBoost, ET, LGBM, and MLP. For each classifier, we implemented a five-fold CV to evaluate their performances. In Table 1, XGBoost reported the highest performance, achieving a mean accuracy of 96.75% (±0.05%). The lowest accuracy was seen on MLP (95.89% ± 0.02%), whereas LGBM, RF, and ET gave a score ranging from 95.89% to 96.71%.

## Section: 3. Results › 3.3. Performance Improvement Via Hyper-Parameter Tuning

We applied randomized search cross-validation to tune the optimal parameters for all five algorithms. Six parameters were adjusted (Table 2). Hyper-tuned parameters improved the performance of the baseline XGBoost model by 0.0004 (Table 3), gaining the highest accuracy of 96.77%. The tuned XGBoost model was afterward used to predict DFIs in the external test set (Table 4 and Figure 2).

## Section: 3. Results › 3.4. Evaluating the Performance Results of the Final Models on External Test Set

We evaluated the model’s classification performance on the internal validation set and the external test set (which was based on drugs and foods used in the study of Ryu et al. [5]). The external test set consisted of 377 drugs and 59 food compounds that comprised 1922 drug–food pairs, with 751, 378, and 793 pairs of negative, positive, and non-significant DFIs, respectively. The external test set contained 232 drugs without the annotations of interactions from our database. Our model correctly predicted 97.56% of drug–food pairs (Table 4 and Figure 2), showing the model’s predictive capacity on unseen data.

## Section: 3. Results › 3.5. Interpretation of Eighteen Optimal Features

MRVSA0 is calculated using MR and surface area contributions. MRVSA0 ranked first in the feature importance list. PEOEVSA5 and PEOEVSA9 compute the sum of one atom’s van der Waals surface areas where its partial charge is between 0.25 and 0.30. EstateVSA7 and EstateVSA2 [43] are computed using Estate indices and surface area contributions. slogPVSA2 denotes the relative approachable van der Waal’s surface area, computed for each atom with a contribution to the partition coefficient log (octanol/water) in the range of (−0.2, 0) [50]. Its negative coefficient value indicated that high hydrophobicity decreased the agonist activity.

According to the SHAP (SHapley Additive exPlanations) [51] analysis in Figure 3, the x-axis portrays the SHAP value calculated for each feature based on their contribution to the final output, while the y-axis depicts the feature names. In this study, SHAP values greater than zero (i.e., the right side of the x-axis) indicate that the model predicts non-significant DFIs, while SHAP values less than zero (i.e., the left side of the x-axis) indicate negative DFI predictions. SHAP values close to zero indicate positive DFI outputs. We can observe that the over-zero side of the x-axis is longer than the opposite one because of the larger number of non-significant DFIs compared to other groups. Each point on the chart represents one SHAP value for a prediction and feature. The red color indicates a higher value of a feature, while blue indicates a lower value of a feature.

Accordingly, the red dots of MRVSA0, EstateVSA2, MRVSA9, MRVSA8 and blue dots of PEOEVSA5, MTPSA+MTPSA, VSAEstate10+VSAEstate10 gather on the right side of the x-axis, indicating that the high values and low values of these features, respectively, direct the model in recognizing the non-significant DFIs. High PEOEVSA5, EstateVSA7, slogPVSA9, MTPSA+MTPSA, and low values of MRVSA0, MRVSA9 help detect the negative DFIs. The positive DFIs are identified by the increasing values of PEOEVSA5, EstateVSA0*LabuteASA, EstateVSA1*VSAEstate8 and the decline of PEOEVSA9, EstateVSA7, EstateVSA2, slogPVSA9, MRVSA2, VSAEstate7+VSAEstate7, slogPVSA0, PEOEVSA12.

The polarization and van der Waals surface area of the interacting molecules seem to have a critical role in determining whether a drug–food constituent combination is negative or non-significant. At the same time, they cannot assist in distinguishing a positive one. This can be observed in the rise or fall of MRVSA0 and MRVSA9. Furthermore, interacting atoms with higher “octanol:water” regional coefficient, polar surface area, and van der Waals forces tend to generate negative drug–food constituent pairs. On the other hand, molecules with high electrotopological state indices combined with increasing van der Waals surface area and orbital electronegativities may indicate a positive interaction between respective drugs and foods. These observations are drawn from the model output and, thus, are needed to be confirmed by biological experiments.

## Section: 3. Results › 3.6. The Interpretation of our Model to Clinical Physicians, Pharmacists, and Patients

We input nine commonly used drugs and seven food compounds known to cause adverse reactions to test the model’s predictive power in clinical practice. We focus on negative interactions because we believe they are more clinically significant than positive and non-significant interactions. Additionally, we have attached scientific evidence about adverse interactions explaining why the listed pairs should not be used together for reference (see Table 5).

## Section: 4. Discussions

The acknowledgment of DFIs is currently underestimated compared to the concerns for DDIs. The lack of methods to classify DFIs, drug–nutrient interactions (DNIs), and further predict novel interactions contributes to the massive manufacturing of drugs regardless of underlying harmful inter-activities towards food and dietary plans. Thus, we propose an ML model capable of predicting the directions of compound-level interactions using SMILES structures.

After applying Tanimoto’s coefficient, the number of food compounds could raise concerns about insufficient food compounds, potentially reducing the model’s predictive power for unseen patterns. However, we believe that applying the Tanimoto coefficient helps to increase generalizability, meaning that 4,341 food constituents can represent others. To test our model’s ability to predict negative DFIs, we looked at Geranyl rhamnosyl-glucoside (not included in the final food dataset) to assess whether our model could predict a negative interaction (“Avoid alcohol”) with Nitroglycerin. The model predicted that “Nitroglycerin should not be taken with Geranyl rhamnosyl-glucoside”, which was true. In the second example, the model correctly predicted that Warfarin and Dicoumarol should not be taken together, even though Dicoumarol was not included in the 4341 foods.

In this study, we used DrugBank annotations to label drug–food interactions as “positive”, “negative”, and “non-significant”. In the literature, most studies classify drug–food interactions based on pharmaceuticals–pharmacokinetics–pharmacodynamics [1,23,65]. However, no study has provided a straightforward and convenient way to apply ML. Therefore, our classification model can pave the way for further studies on the same topic.

Our proposed framework, with four stages of refinement, removes similar features and reduces collinearity to improve the model’s performance. From 3780 features, we used various feature selection methods to sort out the most significant ones for the outcome. Eventually, we selected only the five most important features, each representing different aspects of drug or food constituents (see Figure 3). XGBoost has long been used as an efficient algorithm for classification problems. Its simplicity, high stability, scalability, and ability to prevent overfitting [66] make XGBoost a robust classifier, particularly in high-dimensional datasets. Hypertuning further boosted the performance of XGBoost, demonstrating the potential of this classifier algorithm to correctly detect different types of DFIs. The experimental results also revealed that XGBoost outperformed MLP, a neural network-based model, showing that XGBoost can perform better on this type of data.

As previously mentioned, we computed interactions between drugs and food constituents from SMILES. This is similar to previous research conducted by Ryu et al. [5] and Rahman et al. [38]. However, our study differed from Ryu et al. [5] in terms of labeling the data and using a predictive model. In our study, we directly predicted drug–food interactions from the SMILES formula of drug–food constituents. In contrast, Ryu and colleagues predicted drug–food interactions based on similarity with drug–drug interactions using a Tanimoto coefficient of more than 0.75 (Table 6). However, this approach may not cover all food molecules, as not all foods are structurally similar to available drugs. Additionally, their performance on drug-food data was not mentioned, making a complete comparison impossible.

Similar to our research, Rahman et al. [38] used the SMILES of food directly as input data and based their study on the same databases. However, their training set contained only 788 drugs for analysis. Although they gathered more food constituents (16,230 foods), their selected foods did not represent the whole FooDB database compared to our work, since we used Tanimoto’s coefficient for structural similarity filtration. Moreover, our model can detect drug–food interactions better than Rahman’s approach, with precision ranging from 0.9265 to 1.0 on the external test set compared to their model’s highest precision of 0.84 (Table 6). Our model’s simplicity is also superior to their proposed method regarding reproducibility.

Knowing which drugs to combine with which food compounds is essential for managing dietary intake plans and improving treatment outcomes. Based on the model results, we aim to extend this study to provide drug–food combination recommendations. To test this, we examined seven commonly used clinical drugs and eight foods that should not be combined according to DrugBank annotations. For example, consuming alcohol during treatment with Methotrexate may lead to hepatotoxicity [16,54,55], while the use of grapefruit juice during treatment with nisoldipine may cause toxicity to patients [59]. Our model successfully recommended that Methotrexate and nifedipine should not be taken with these food compounds. However, it may take some time to improve this extension, and we hope that it will become more helpful in the future.

Despite the promising results of our model, various limitations remained and needed to be addressed. The first drawback to be considered is the shortage of databases due to invalid information, such as origins, class, and interactions towards broader classes of different compounds, of food, nutrients, and drug constituents. In the future, with broader contributions to the public food database, we believe that ML models’ ability to predict DFIs will be even more impressive. Second, since there was no standard to determine in which situation a DFI would be positive or negative, the way we labeled data in this study, based on DrugBank annotations, may be inappropriate. Third, the outputs of our model were imperfect, as there were still many incorrect recommendations, which can negatively affect clinical practice. Furthermore, we can only distinguish between positive, negative, or non-significant results, but we cannot explain how negatively the DFIs affect our health. Many aspects need to be improved before our model can become a robust assistant for medical staff. Therefore, we emphasize that the recommendations of physicians or pharmacists are of the highest importance, and the outcomes from our model are only for further consideration. Fourth, although we proved that XGBoost was superior to a neural network algorithm, we still need to consider other deep methods. In 2018, Ryu et al. successfully proposed a cutting-edge deep neural network-based model to predict DDIs [5]. Recently, Lin et al. [67,68] proposed two state-of-the-art deep neural networks to discriminate DDIs. Motivated by this work, our future focus will be on recruiting deep learning techniques [69] to classify DFIs more accurately. Finally, the efficacy and stability of our model require further assessment of different databases, institutions, and contributions from worldwide scientists to complete the prediction model in the future.

## Section: 5. Conclusions

To reduce the number of ADEs due to DFIs and DNIs, we propose a new classification model based on the XGBoost classifier and eighteen optimal features. The ability of our model to predict adverse interactions between drug-food compounds can contribute to drug discoveries and the conformity between prescribed drugs and dietary plans in clinical medicine. From a large number of drug and food constituents (13,580 and 70,477, respectively), we reduced them to only 1133 drugs and 4341 food compounds. We also identified the eighteen most important features that yielded the highest predictive performance on DFIs. Each feature represents a chemical reaction between atoms. Thus, our findings could contribute to understanding DFIs at the atomic level along with biological experiments. We believe these findings will benefit the scientific community and patients by decreasing the number of ADEs caused by DFIs and setting a new standard for DFI prediction models.


---

# Digital Health Data Quality Issues: Systematic Review

- **Authors:** Rehan Syed, Rebekah Eden, Tendai Makasi, Ignatius Chukwudi, Azumah Mamudu, Mostafa Kamalpour, Dakshi Kapugama Geeganage, Sareh Sadeghianasl, Sander J J Leemans, Kanika Goel, Robert Andrews, Moe Thandar Wynn, Arthur Ter Hofstede, Trina Myers
- **Issuer:** Journal of medical Internet research
- **Type:** Scientific article
- **Published:** 2023-03-31
- **Language:** en
- **DOI:** 10.2196/42615
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37000497/
- **Licence:** CC-BY

## Section: Abstract

BackgroundThe promise of digital health is principally dependent on the ability to electronically capture data that can be analyzed to improve decision-making. However, the ability to effectively harness data has proven elusive, largely because of the quality of the data captured. Despite the importance of data quality (DQ), an agreed-upon DQ taxonomy evades literature. When consolidated frameworks are developed, the dimensions are often fragmented, without consideration of the interrelationships among the dimensions or their resultant impact.ObjectiveThe aim of this study was to develop a consolidated digital health DQ dimension and outcome (DQ-DO) framework to provide insights into 3 research questions: What are the dimensions of digital health DQ? How are the dimensions of digital health DQ related? and What are the impacts of digital health DQ?MethodsFollowing the PRISMA (Preferred Reporting Items for Systematic Reviews and Meta-Analyses) guidelines, a developmental systematic literature review was conducted of peer-reviewed literature focusing on digital health DQ in predominately hospital settings. A total of 227 relevant articles were retrieved and inductively analyzed to identify digital health DQ dimensions and outcomes. The inductive analysis was performed through open coding, constant comparison, and card sorting with subject matter experts to identify digital health DQ dimensions and digital health DQ outcomes. Subsequently, a computer-assisted analysis was performed and verified by DQ experts to identify the interrelationships among the DQ dimensions and relationships between DQ dimensions and outcomes. The analysis resulted in the development of the DQ-DO framework.ResultsThe digital health DQ-DO framework consists of 6 dimensions of DQ, namely accessibility, accuracy, completeness, consistency, contextual validity, and currency; interrelationships among the dimensions of digital health DQ, with consistency being the most influential dimension impacting all other digital health DQ dimensions; 5 digital health DQ outcomes, namely clinical, clinician, research-related, business process, and organizational outcomes; and relationships between the digital health DQ dimensions and DQ outcomes, with the consistency and accessibility dimensions impacting all DQ outcomes.ConclusionsThe DQ-DO framework developed in this study demonstrates the complexity of digital health DQ and the necessity for reducing digital health DQ issues. The framework further provides health care executives with holistic insights into DQ issues and resultant outcomes, which can help them prioritize which DQ-related problems to tackle first.

## Section: Introduction › Background

The health care landscape is changing globally owing to substantial investments in health information systems that seek to improve health care outcomes [1]. Despite the rapid adoption of health information systems [2] and the perception of digital health as a panacea [3] for improving health care quality, the outcomes have been mixed [4,5]. As Reisman [6] noted, despite substantial investment and effort and widespread application of digital health, many of the promised benefits have yet to be realized.

The promise of digital health is principally dependent on the ability to electronically capture data that can be analyzed to improve decision-making at the local, national [6], and global levels [7]. However, the ability to harness data effectively and meaningfully has proven difficult and elusive, largely because of the quality of the data captured. Darko-Yawson and Ellingsen [8] highlighted that digital health has resulted in more bad data rather than improving the quality of data. It is widely accepted that the data from digital health are plagued by accuracy and completeness concerns [9-12]. Poor data quality (DQ) can be detrimental to continuity of care [13], patient safety [14], clinician productivity [15], and research [16].

To assess DQ, scholars have developed numerous DQ taxonomies, which evaluate the extent to which the data contained within digital health systems adhere to multiple dimensions (ie, measurable components of DQ). Weiskopf and Weng [17] identified 5 dimensions of DQ spanning completeness, correctness, concordance, plausibility, and currency. Subsequently, Weiskopf et al [18] refined the typology to consist of only 3 dimensions: completeness, correctness, and currency. Similarly, Puttkammer et al [13] focused on completeness, accuracy, and timeliness, whereas Kahn et al [19] examined conformance, completeness, and plausibility. Others identified “fitness of use” [20] and the validity of data to a specific context [21] as key DQ dimensions. Overall, there are wide-ranging definitions of DQ, with an agreed-upon taxonomy evading the literature. In this paper, upon synthesizing the literature, we define DQ as the extent to which digital health data are accessible, accurate, complete, consistent, contextually valid, and current. When consolidated frameworks are developed, the dimensions are often treated in a fragmented manner, with few attempts to understand the relationships between the dimensions and the resultant outcomes. This is substantiated by Bettencourt-Silva et al [22], who indicated that DQ is not systematically or consistently assessed.

## Section: Introduction › Research Aims and Questions

Failure of health organizations to leverage high-quality data will compromise the sustainability of an already strained health care system [23]. Therefore, we undertook a systematic literature review to answer the following research questions: (1) What are the dimensions of digital health DQ? (2) How are the dimensions of digital health DQ related? and (3) What are the impacts of digital health DQ? The aim of this research was to develop, from synthesizing the literature, a consolidated digital health DQ dimension and outcome (DQ-DO) framework, which demonstrates the DQ dimensions and their interrelationships as well as their impact on core health care outcomes. The consolidated DQ-DO framework will be beneficial to both research and practice. For researchers, our review consolidates the digital health DQ literature and provides core areas for future research to rigorously evaluate and improve digital health DQ. For practice, this study provides health care executives and strategic decision makers with insights into both the criticality of digital health DQ by exemplifying the impacts and the complexity of digital health DQ by demonstrating the interrelationships between the dimensions. Multimedia Appendix 1 [24] provides a list of common acronyms used in this study.

This paper is structured as follows: first, we provide details of the systematic literature review method; second, in line with the research questions, we present our 3 key findings—(1) DQ dimensions, (2) DQ interrelationships, and (3) DQ outcomes; and third, we compare the findings of our study with those of previous studies and discuss the implications of this work.

## Section: Methods

We followed the PRISMA (Preferred Reporting Items for Systematic Reviews and Meta-Analyses) guidelines and the guidelines proposed by Webster and Watson [25] for systematic literature reviews. Specifically, consistent with Templier and Paré [26], this systematic literature review was developmental in nature with the goal of developing a consolidated digital health DQ framework.

PRISMA (Preferred Reporting Items for Systematic Reviews and Meta-Analyses) inclusion process. EHR: electronic health record.

Analysis process. DQ: data quality.

## Section: Methods › Literature Search and Selection

To ensure the completeness of the review [25] and consistent with interdisciplinary reviews, the literature search spanned multiple fields and databases (ie, PubMed, Public Health, Cochrane, SpringerLink, EBSCOhost [MEDLINE and PsycInfo], ABI/INFORM, AISel, Emerald Insight, IEEE Xplore digital library, Scopus, and ACM Digital Library). The search was conducted in October 2021 and was not constrained by the year of publication because the concept of DQ has a long-standing academic history. The search terms were reflective of our research topic and research questions. To ensure comprehensiveness, the search terms were broadened by searching their synonyms. For example, we used search terms such as “electronic health record,” “digital health record,” “e-health,” “electronic medical record,” “EHR,” “EMR,” “data quality,” “data reduction,” “data cleaning,” “data pre-processing,” “information quality,” “data cleansing,” “data preparation,” “intelligence quality,” “data wrangling,” and “data transformation.” Keywords and search queries were reviewed by the reference librarian and subject matter experts in digital health (Multimedia Appendix 2).

The papers returned from the search were narrowed down in a 4-step process (Figure 1). In the identification step, 5177 articles were identified through multiple database searches, and from these, 3856 (74.48%) duplicates were removed, resulting in 1321 (25.42%) articles. These 1321 articles were randomly divided into 6 batches, which were assigned to separate researchers, who applied the inclusion and exclusion criteria (Textbox 1). As a result of abstract screening, 67.83% (896/1321) of articles were excluded, resulting in 425 (32.17%) articles. Following an approach to the abstract screening, the 425 articles were again randomly divided into 6 batches and assigned to 1 of the 6 researchers to read and assess the relevance of the article in line with the selection criteria. The assessment of each of the 425 articles was then verified by the research team, resulting in a final set of 227 (53.4%) relevant articles. During this screening phase (ie, abstract and full text), daily meetings were held with the research team in which any uncertainties were raised and discussed until consensus was reached by the team as to whether the article should be included or excluded from the review In line with Templier and Paré [26], as this systematic literature review was developmental in nature rather than an aggregative meta-analysis, quality appraisals were not performed on individual articles.

PRISMA (Preferred Reporting Items for Systematic Reviews and Meta-Analyses) inclusion process. EHR: electronic health record.

## Section: Methods › Literature Analysis

The relevant articles were imported to NVivo (version 12; QSR International), where the analysis was iteratively performed. To ensure reliability and consistency in coding, a coding rule book [27] was developed and progressively updated to guide the coding process. The analysis involved 6 steps (Figure 2).

In the first step of the analysis, the research team performed open coding [27], where relevant statements from each article were extracted using verbatim codes and grouped based on similarities [28]. The first round of coding resulted in 1298 open codes. Second, the open codes were segmented into 2 high-level themes: the first group contained 1044 (80.43%) open codes pertaining directly to DQ dimensions (eg, data accuracy), and the second group contained 254 (19.57%) open codes pertaining to DQ outcomes (eg, financial outcomes).

In the third step, through constant comparison [29], the 1044 raw DQ codes were combined into 29 DQ subthemes based on commonalities (eg, contextual DQ, fitness for use, granularity, relevancy, accessibility, and availability). In the fourth step, again by performing iterative and multiple rounds of constant comparison, the 254 open codes related to DQ outcomes were used to construct 22 initial DQ outcome subthemes (eg, patient safety, clinician-patient relationship, and continuity of care). The DQ outcome subthemes were further compared with each other, resulting in 5 DQ outcome dimensions (eg, clinical, business process, research-related, clinician, and organizational outcomes). For the DQ subthemes, a constant comparison was performed using the card-sorting method [30], where an expert panel of 8 DQ researchers split into 4 groups assessed the subthemes for commonalities and differences. The expert groups presented their categorization to each other until a consensus was reached. This resulted in a consolidated set of 6 DQ dimensions (accuracy, consistency, completeness, contextual validity, accessibility, and currency). Multimedia Appendix 3 [9,12,13,15,16,18,19,21,31-65] provides an example of how the open codes were reflected in the subthemes and themes.

After identifying the DQ dimensions and outcomes, the next stage of coding progressed to identifying the interrelationships (step 5) among the DQ dimensions and the relationships (step 6) between the DQ dimensions and DQ outcomes. To this end, the matrix coding query function using relevant Boolean operators (AND and NEAR) in NVivo was performed. The outcomes of the matrix queries were reviewed and verified by an expert researcher in the health domain.

Throughout the analysis, steps for providing credibility to our findings were performed. First, before commencing the analysis, the research team members who extracted the verbatim codes initially independently reviewed 3 common articles and then convened to review any variations in coding. In addition, they reconvened multiple times a week to discuss their coding and update the codebook to ensure that a consistent approach was followed. Coder corroboration was performed throughout the analysis, with 2 experienced researchers independently verifying all verbatim codes until a consensus was reached [27]. Subsequent coder corroboration was performed by 2 experienced researchers to ensure that the open codes were accurately mapped to the themes and dimensions. This served to provide internal reliability. Steps for improving external reliability were also performed [66]. Specifically, the card-sorting method provided an expert appraisal. In addition, the findings were presented to and confirmed by 3 digital health care professionals.

Analysis process. DQ: data quality.

## Section: Results

Publications by year.

Description of the data quality (DQ) dimensions.

Interrelationships between the data quality (DQ) dimensions.

The relationships between data quality (DQ) dimensions and data outcomes.

Consolidated digital health data quality dimension and outcome framework.

## Section: Results › Overview

The vast majority of relevant articles were published in journal outlets (169/227, 74.4%), followed by conference proceedings (42/227, 18.5%) and book sections (16/227, 7%). The 169 journal articles were published in 107 journals, with 12% (n=13) of the journals publishing >1 study (these journals are BMC Medical Informatics and Decision Making, eGEMS, International Journal of Medical Informatics, Applied Clinical Informatics, Journal of Medical Internet Research, Journal of the American Medical Information Association, PLOS One, BMC Emergency Medicine, Computer Methods and Programs in Biomedicine, International Journal of Population Data Science, JCO Clinical Cancer Informatics, Perspectives in Health Information Management, Studies in Health Technology and Informatics, Australian Health Review, MBC Health Services Research, BMJ Open, Decision Support Systems, Health Informatics Journal, International Journal of Information Management, JAMIA Open, JMIR Medical Informatics, Journal of Biomedical Informatics, Journal of Medical Systems, Malawi Medical Journal, Medical Care, Online Journal of Public Health Informatics, and Telemedicine and e-Health). A complete breakdown of the number of articles published in each outlet is provided in Multimedia Appendix 4.

Overall, as illustrated in Figure 3, the interest in digital health DQ has been increasing over time, with sporadic interest before 2006.

In the subsequent sections, we provide an overview of the DQ definitions, DQ dimensions, their interrelationships, and DQ outcomes to develop a consolidated digital health DQ framework.

Publications by year.

## Section: Results › DQ Definitions

Multiple definitions of DQ were discussed in the literature (Multimedia Appendix 5 [17,18,20-22,31,54,67-77]). There was no consensus on a single definition of DQ; however, an analysis of the definitions revealed two perspectives, which we labeled as the (1) context-agnostic perspective and (2) context-aware perspective. The context-agnostic perspective defines DQ based on a set of dimensions, regardless of the context within which the data are used. For instance, as Abiy et al [67] noted “documentation and contents of data within an electronic medical record (EMR) must be accurate, complete, concise, consistent and universally understood by users of the data, and must support the legal business record of the organization by maintaining the required parameters such as consistency, completeness and accuracy.” By contrast, the context-aware perspective evaluates the dimensions of DQ with recognition of the context within which the data are used. For instance, as the International Organization for Standardization and Liu et al [78] noted, DQ is “the degree to which data satisfy the requirements defined by the product-owner organization” and can be reflected through its dimensions such as completeness and accuracy.

## Section: Results › DQ Dimensions

Description of the data quality (DQ) dimensions.

Interrelationships between the data quality (DQ) dimensions.

## Section: Results › DQ Dimensions › Overview

In total, 30 subthemes were identified and grouped into 6 DQ dimensions: accuracy, consistency, completeness, contextual validity, accessibility, and currency (Table 1; Multimedia Appendix 6 [8-12,14-16,18-22,31-62,67,69,71,72,76,79-168]). Consistency (164/227, 72.2%), completeness (137/227, 60.4%), and accuracy (123/227, 54.2%) were the main DQ dimensions. Comparatively, less attention was paid to accessibility (28/227, 12.3%), currency (18/227, 7.9%), and contextual validity (26/227. 11.5%).

Description of the data quality (DQ) dimensions.

## Section: Results › DQ Dimensions › DQ Dimension: Accessibility

The accessibility dimension (28/227, 12.3%) is composed of both the accessibility (15/28, 54%) and availability (13/28, 46%) subthemes, reflecting the feasibility for users to extract data of interest [18]. Scholars regularly view the accessibility subtheme favorably, with the increased adoption of electronic health record (EHR) systems overcoming physical and chronological boundaries associated with paper records by allowing access to information from multiple locations at any time [33,80]. Top et al [33] noted that EHR made it possible for nurses to access patient data, resulting in improved decision-making. Furthermore, Rosenlund et al [81] noted that EHRs benefit health care professionals by providing increased opportunities for searching and using information. The availability subtheme is an extension of the accessibility subtheme and examines whether data exist and whether the existing data are in a format that is readily usable [34]. For instance, Dentler et al [34] noted that pathology reports, although accessible, are recorded in a nonstructured, free-text format, making it challenging to readily use the data. Although structuredness may make data more available, Yoo et al [82] highlighted that structured data entry in the form of drop-down lists and check boxes tends to reduce the narrative description of patients’ medical conditions. Although not explicitly investigating accessibility, Makeleni and Cilliers [31] also noted the challenges associated with structured data entry.

## Section: Results › DQ Dimensions › DQ Dimension: Accuracy

The accuracy dimension (123/227, 54.2%) is composed of 7 subthemes, namely correctness (42/123, 34.1%), validity (23/123, 18.7%), integrity (19/123, 15.4%), plausibility (17/123, 13.8%), accurate diagnostic data (13/123, 10.6%), conformance (7/123, 5.7%), and veracity (2/123, 1.6%). Accuracy refers to the extent to which data reveal the truth about the event being described [31] and conform to their actual value [83].

Studies often referred to accuracy as the “correctness” of data, which is the degree to which data correctly communicate the parameter being represented [32]. By contrast, other studies focused on plausibility, which is the extent to which data points are believable [35]. Although accuracy concerns were present for all forms of digital health data, some studies focused specifically on inaccuracies in diagnostic data and stated that “the accurate and precise assignment of structured [diagnostic] data within EHRs is crucial” [84] and is “key to supporting secondary clinical data” [36].

To assess accuracy, the literature regularly asserts that data must be validated against metadata constraints, system assumptions, and local knowledge [19] and conform to structural and syntactical rules. According to Kahn et al [19] and Sirgo et al [85], conformance focuses on the compliance of data with internal or external formatting and relational or computational definitions. Accurate, verified, and validated data as well as data conforming to standards contribute to the integrity of the data. Integrity requires that the data stored in health information systems are accurate and consistent, where the “improper use of [health information systems] can jeopardise the integrity of a patient’s information” [31]. An emerging subtheme of accuracy is the veracity of data, which represents uncertainty in the data owing to inconsistency, ambiguity, latency, deception, and model approximations [21]. It is particularly important in the context of the secondary use of big data, where “data veracity issues can arise from attempts to preserve privacy,...and is a function of how many sources contributed to the data” [86].

## Section: Results › DQ Dimensions › DQ Dimension: Completeness

The completeness dimension (114/227, 50.2%) is composed of 5 subthemes: missing data (66/114, 57.9%), level of completeness (25/114, 21.9%), representativeness (13/114, 11.4%), fragmentation (8/114, 7%), and breadth of documentation (2/114, 1.8%). A well-accepted definition of data completeness considers 4 perspectives: documentation (the presence of observations regarding a patient in data), breadth (the presence of all desired forms of data), density (the presence of a desired frequency of data values over time), and prediction (the presence of sufficient data to predict an outcome) [169]. Our analysis revealed that these 4 perspectives, although accepted, are rarely systematically examined in the extant literature; rather, papers tended to discuss completeness or the lack thereof as a whole.

Missing data is a prominent subtheme and represents a common problem in EHR data. For instance, Gloyd et al [87] argued that incomplete, missing, and implausible data “was by far the most common challenge encountered.” Scholars regularly identified that data fragmentation contributed to incompleteness, with a patient’s medical record deemed incomplete owing to data being required from multiple systems and EHRs [18,37,88-93]. “Data were also considered hidden within portals, outside systems, or multiple EHRs, frustrating efforts to assemble a complete clinical picture of the patient” [89]. Positive perspectives pertaining to data completeness focus on the level of completeness, with studies reporting relatively high completeness rates in health data sets [34,38,80,94,95,170]. For data to be considered complete, it needs to be captured at sufficient breadth and depth over time [12,18].

Some studies have proposed techniques for improving completeness, including developing fit-for-purpose user interfaces [68,96,97], standardizing documentation practices, [98,99], automating documentation [100], and performing quality control [99].

In some instances, the level of completeness and extent of missing data differed depending on the health status of the patient [15,16,18,20,39-43,86,90,101,170,171], which we classified into the subtheme of representativeness. It has been found that there is “a statistically significant relationship between EHR completeness and patient health status” [42], with more data recorded for patients who are sick than for patients with less-acute conditions. This strongly aligns with the subtheme of contextual validity.

## Section: Results › DQ Dimensions › DQ Dimension: Consistency

The consistency dimension (157/227, 69.2%) is composed of 10 subthemes: inconsistent data capturing (33/157, 21%), standardization (28/157, 17.8%), concordance (22/157, 14%), uniqueness (14/157, 8.9%), data variability (14/157, 8.9%), temporal variability (13/157, 8.3%), system differences (12/157, 7.6%), semantic consistency (10/157, 6.4%), structuredness (7/157, 4.5%), and representational consistency (4/157, 2.5%).

Inconsistent data capturing is a prevalent subtheme caused by the manual nature of data entry in health care settings [86], especially when data entry involve multiple times, teams, and goals [102]. Inconsistent data capturing results in data variability and temporal variability. Data variability refers to inconsistencies in the data captured within and between health information systems, whereas temporal variability reflects inconsistencies that occur over time and may be because of changes in policies or medical guidelines [20,44-46,87,103-105]. Semantic inconsistency (ie, data with logical contradictions) and representational inconsistency (ie, data variations owing to multiple formats) can also result from inconsistent data capturing [47].

Standardization in terms of terminology, diagnostic codes, and workflows [99] are proffered to minimize inconsistency in data entry, yet in practice, there is a “lack of standardized data and terminology” [9] and “even with a set standard in place not all staff accept and follow the routine” [99]. The lack of standardization is further manifested because of health information system differences across settings [106]. As a result of the differences between systems, concordance—the extent of “agreement between elements in the EHR, or between the EHR and another data source”—is hampered [107].

Furthermore, inconsistent data entry can be caused by redundancy within the system because of structured versus unstructured data [108], which we label as the subtheme “structuredness,” and duplication across systems [39,48,104,109,172,173], which we label as the subtheme “uniqueness.” Although structured data entry “facilitates information retrieval” [33] and is “in a format that enables reliable extraction” [18], the presence of unstructured fields leads to data duplication efforts, hampering uniqueness, as data are recorded in multiple places with varying degrees of granularity and level of detail.

## Section: Results › DQ Dimensions › DQ Dimension: Contextual Validity

The contextual validity dimension (26/227, 11.5%) is composed of 4 subthemes: fitness for use (11/26, 42%), contextual DQ (9/26, 35%), granularity (4/26, 15%), and relevancy (2/26, 8%). Contextual validity requires a deep understanding of the context that gives rise to data [86], including technical, organizational, behavioral, and environmental factors [174].

Contextual DQ is often described as “fitness of use” [20], for which understanding the context in which data are collected is deemed important [18,90]. Another factor that contributes to data being fit for use is the granularity of data. Adequate granularity of time stamps [49], patient information [16], and data present in EHR (eg, diagnostic code [16]) was considered important to make data fit for use. Finally, for data to be fit for use, they must be relevant. As indicated by Schneeweiss and Glynn [41], for data to be meaningful, health care databases need to contain relevant information of sufficient quality, which can help answer specific questions. The literature clearly demonstrates the need to take context into consideration when analyzing data and the need to adapt technologies to the health care context so that appropriate data are collected for reliable analysis to be performed.

## Section: Results › DQ Dimensions › DQ Dimension: Currency

The currency dimension (18/227, 7.9%) is composed of a single subtheme: timeliness. Currency, or timeliness, is defined by Afshar et al [32] and Makeleni and Cilliers [31] as the degree to which data represent reality from the required point in time. From an EHR perspective, data should be up to date, available, and reflect the profile of the patient at the time when the data are accessed [32,50]. Lee et al [35] extended this to include the recording of an event at the time when it occurs such that a value is deemed current if it is representative of the clinically relevant time of the event. Frequently mentioned causes for lack of currency of data include (1) recording of events (long) after the event actually occurred [91,99,110,111], (2) incomplete recording of patient characteristics over time [16], (3) system or interface design not matching workflow and impeding timely recording of data [99], (4) mixed-mode recording—paper and electronic [99], and (5) lack of time stamp metadata, meaning that the temporal sequence of events is not reflected in the recorded data [16].

## Section: Results › DQ Dimensions › Interrelationships Among the DQ Dimensions

As illustrated in Figure 4 and Multimedia Appendix 7 [16,34,40,42,78,80,90,91,109], interrelationships were found among the digital health DQ dimensions.

Consistency influenced all the DQ dimensions. Commonly, these relationships were expressed in terms of the presence of structured and consistent data entry, which prompts complete and accurate data to be entered into the health information system and provides more readily accessible and current data for health care professionals when treating patients. As Roukema et al [80] noted, “structured data entry applications can prompt for completeness, provide greater accuracy and better ordering for searching and retrieval, and permit validity checks for DQ monitoring, research, and especially decision support.” When data are entered inconsistently, it impedes the accuracy of the medical record and the contextual validity for secondary uses of the data [40].

Accessibility of data was found to influence the currency dimension of DQ. When data are not readily accessible, they seldom satisfy the timeliness of information for health care or research purposes [34]. Currency also influenced the accuracy of data. In a study investigating where DQ issues in EHR arise, it was found that “false negatives and false positives in the problem list sometimes arose when the problem list...[was] out-of-date, either because a resolved problem was not removed or because an active problem was not added” [90].

Furthermore, completeness influences the accuracy of data; as Makeleni and Cilliers [31] noted, “data should be complete to ensure it is accurate.” The presence of inaccurate data was regularly linked to information fragmentation [88], incomplete data entry [109], and omissions [35]. Completeness also influenced contextual validity, as it is necessary to have all the data available to complete specific tasks [78]. When it comes to the secondary use of EHR data, evaluation of “completeness becomes extrinsic, and is dependent upon whether or not there are sufficient types and quantities of data to perform a research task of interest” [42].

Accuracy and contextual validity exhibited a bidirectional relationship with each other. The literature suggests that accuracy influences contextual validity; however, data cannot simply be extracted from structured form fields, and free-text fields will also need to be consulted. For instance, Kim and Kim [112] identified “it is sometimes thought that structured data are more completely optimized for clinical research. However, this is not always the case, particularly given that extracted EMR data can still be unstable and contain serious errors.” By contrast, other studies suggest that when only a segment of information regarding a specific clinical event (ie, contextual validity) is captured, inaccuracy can ensue [16].

Interrelationships between the data quality (DQ) dimensions.

## Section: Results › Outcomes of Digital Health DQ

The analysis of the literature identified five types of digital health DQ outcomes: (1) clinical, (2) business process, (3) clinician, (4) research-related, and (5) organizational outcomes (Multimedia Appendix 8 [15,16,20,31,33,39,40,42,51,52,55,57, 58,61,63,64,84,90,105,113,166,175-178]). Using NVivo’s built-in cross-tab query coupled with subject matter expert analysis, it was identified that different DQ dimensions were related to DQ outcomes in different ways (Table 2). Currency was the only dimension that did not have a direct effect on DQ outcomes. However, as shown in Figure 5, it is plausible that currency affects DQ outcomes by impacting other DQ dimensions. In the subsequent paragraphs, we discuss each DQ dimension and its respective outcomes.

We identified that the accessibility DQ dimension influenced clinical, clinician, business process, research-related, and organizational outcomes. In terms of clinical outcomes, Roukema et al [80] indicated that EHRs substantially enhance the quality of patient care by improving the accessibility and legibility of health care data. The increased accessibility of medical records during the delivery of patient care is further proffered to benefit clinicians by reducing the data entry burden [33]. By contrast, inconsistency in the availability of data across health settings increases clinician workload; as Wiebe et al [15] noted, “given the predominantly electronic form of communication between hospitals and general practitioners in Alberta, the inconsistency in availability of documentation in one single location can delay processes for practitioners searching for important health information.” When data are accessible and available, they can improve business processes (eg, quality assurance) and research-related (eg, outcome-oriented research) outcomes and can support organizational outcomes with improved billing and financial management [179].

The literature demonstrates that data accuracy influences clinical outcomes [14,39,51] and research-related outcomes [14,113]; as Wang et al [14] described, “errors in healthcare data are numerous and impact secondary data use and potentially patient care and safety.” Downey et al [39] observed the negative impact on quality of care (ie, clinical outcomes) resulting from incorrect data and stated, “manual data entry remains a primary mechanism for acquiring data in EHRs, and if the data is incorrect then the impact to patients and patient care could be significant” [39]. Poor data accuracy also diminishes the quality of research outcomes. Precise data are beneficial in producing high-quality research outcomes. As Gibby [113] explained, “computerized clinical information systems have considerable advantages over paper recording of data, which should increase the likelihood of their use in outcomes research. Manual records are often inaccurate, biased, incomplete, and illegible.” Closely related to accuracy, contextual validity is an important DQ dimension that considers the fitness for research; as stated by Weiskopf et al [42], “[w]hen repurposed for secondary use, however, the concept of ‘fitness for use’ can be applied.”

The consistency DQ dimension was related to all DQ outcomes. It was commonly reported that inconsistency in data negatively impacts the reusability of EHR data for research purposes, hindering research-related outcomes and negatively impacting business processes and organizational outcomes. For example, Kim et al [114] acknowledged that inconsistent data labeling in EHR systems may hinder accurate research results, noting that “a system may use local terminology that allows unmanaged synonyms and abbreviations...If local data are not mapped to terminologies, performing multicentre research would require extensive labour.” Alternatively, von Lucadou et al [16] indicated the impact of inconsistency on clinical outcomes, reporting that the existence of inconsistencies in captured data “could explain the varying number of diagnoses throughout the encounter history of some subjects,” whereas Diaz-Garelli et al [84] demonstrated the negative impact that inconsistency has on clinicians in terms of increased workload.

Incomplete EMR data were found to impact clinical outcomes (eg, reduced quality of care), business process outcomes (eg, interprofessional communication), research-related outcomes (eg, research facilitation), and organizational outcomes (eg, key performance indicators related to readmissions) [15]. For example, while reviewing the charts of 3011 nonobstetric inpatients, Wiebe et al [15] found that missing discharge summary within an EHR “can present several issues for healthcare processes, including hindered communication between hospitals and general practitioners, heightened risk of readmissions, and poor usability of coded health data,” among other widespread implications. Furthermore, Liu et al [69] reported that “having incomplete data on patients’ records has posed the greatest threat to patient care.” Owing to the heterogeneous nature (with multiple data points) of EHR data, Richesson et al [20] emphasized that access to large, complete data will allow clinical investigators “to detect smaller clinical effects, identify and study rare disorders, and produce robust, generalisable results.”

The relationships between data quality (DQ) dimensions and data outcomes.

Consolidated digital health data quality dimension and outcome framework.

## Section: Discussion › Overview

The following sections describe the three main findings of this research: the (1) dimensions of DQ, (2) interrelationships among the dimensions of DQ, and (3) outcomes of DQ. As described in the Summary of Key Findings section, these 3 findings led to the development of the DQ-DO framework. Subsequently, we compared the DQ-DO framework with related works. This leads to implications for future research. The Discussion section concludes with a reflection on the limitations of this study.

## Section: Discussion › Summary of Key Findings

In summary, we unearthed 3 core findings. First, we identified 6 dimensions of DQ within the digital health domain: consistency, accessibility, completeness, accuracy, contextual validity, and currency. These dimensions were synthesized from 30 subthemes described in the literature. We found that consistency, completeness, and accuracy are the predominant dimensions of DQ. Comparatively, limited attention has been paid to the dimensions of accessibility, currency, and contextual validity. Second, we identified the interrelationships among these 6 dimensions of digital health DQ (Table 2). The literature indicates that the consistency dimension can influence all other DQ dimensions. The accessibility of data was found to influence the currency of data. Completeness impacts accuracy and contextual validity, with these dimensions serving as dependent variables and exhibiting a bidirectional relationship with each other. Third, we identified 5 types of data outcomes (Table 2; Multimedia Appendix 8): research-related, organizational, business process, clinical, and clinician outcomes. Consistency was found to be a very influential dimension, impacting all types of DQ outcomes. By contrast, contextual validity was shown to be particularly important for data reuse (eg, performance measurement and outcome-oriented research). Although currency does not directly impact any outcomes, it impacts the accuracy of data, which impacts clinical and research-related outcomes. Therefore, if currency issues are not resolved, accuracy issues would still prevail. Consistency, accessibility, and completeness were shown to be important considerations for achieving the goal of improving organizational outcomes. Through consolidating our 3 core findings, we developed a consolidated DQ-DO framework (Figure 5).

## Section: Discussion › Comparison With Literature

Our findings extend those of previous studies on digital health DQ in 3 ways. First, through our rigorous approach, we identified a comprehensive set of DQ dimensions, which both confirmed and extended the existing literature. For instance, Weiskopf and Weng [17] identified 5 DQ dimensions, namely completeness, correctness, concordance, plausibility, and currency, all of which are present within our DQ framework, although in some instances, we use slightly different terms (referring to correctness as accuracy and concordance as consistency). Extending the framework of Weiskopf and Weng [17], we view plausibility as a subtheme of accuracy and disentangle accessibility from completeness, and we also stress the importance of contextual validity per Richesson et al [20]. Others have commonly had a narrower perspective of DQ, focusing on completeness, correctness, and currency [18] or on completeness, timeliness, and accuracy [13]. In other domains of digital health, such as physician rating systems, Wang and Strong’s [180] DQ dimensions of intrinsic, contextual, representational, and accessibility have been adopted. Such approaches to assessing DQ are appropriate, although they remove a level of granularity that is necessary to understand relationships and outcomes. This is particularly necessary given the salience of consistency in our data set and the important role it plays in generating outcomes.

Second, unlike previous studies on DQ dimensions, we also demonstrate how these dimensions are all related to each other. By analyzing the interrelationships between these DQ dimensions, we can determine how a particular dimension influences another and in which direction this relationship is unfolding. This is an important implication for digital health practitioners, as although several studies have examined how to validate [38] and resolve DQ issues [16], resolving issues with a specific DQ dimension requires awareness of the interrelated DQ dimensions. For instance, to improve accuracy, one also needs to consider improving consistency and completeness.

Third, although previous studies describe how DQ can impact a particular outcome (eg, the studies by Weiskopf et al [18], Johnson et al [52], and Dantanarayana and Sahama [115]), they largely focus broadly on DQ, a specific dimension of DQ, or a specific outcome. For instance, Sung et al [181] noted that poor-quality data were a prominent barrier hindering the adoption of digital health systems. By contrast, Kohane et al [182] focused on research-related outcomes in terms of publication potential and identified that incompleteness and inconsistency can serve as core impediments. To summarize, the DQ-DO framework (Figure 5) developed through this review provides not only the dimensions and the outcomes but also the interrelationships between these dimensions and how they influence outcomes.

## Section: Discussion › Implications for Future Work › Implication 1: Equal Consideration Across DQ Dimensions

This study highlights the importance of each of the 6 DQ dimensions: consistency, accessibility, completeness, accuracy, contextual validity, and currency. These dimensions have received varying amounts of attention in the literature. Although we observe that some DQ dimensions such as accessibility, contextual validity, and currency are discussed less frequently than others, it does not mean that these dimensions are not important for assessment. This is evident in Figure 5, which shows that all DQ dimensions except for currency directly influence DQ outcomes. Although we did not identify a direct relationship between the currency of data and the 6 types of data outcomes, it is likely that the currency of data influences the accuracy of data, which subsequently influences the research-related and clinical outcomes. Future research, including consultation with a range of stakeholders, needs to further delve into understanding the underresearched DQ dimensions. For instance, both the currency and accessibility of data are less frequently discussed dimensions in the literature; however, with the advances in digital health technologies, both have become highly relevant for real-time clinical decisions [21,53].

## Section: Discussion › Implications for Future Work › Implication 2: Empirical Investigations of the Impact of the DQ Dimensions

The DQ-DO framework identified in this study has been developed through a rigorous systematic literature review process, which synthesized the literature related to digital health DQ. To extend this study, we advocate for empirical mixed methods case studies to validate the framework, including an examination of the interrelationships between DQ dimensions and DQ outcomes, based on real-life data and consultation with a variety of stakeholders. Existing approaches can be used to identify the presence of issues related to DQ dimensions within digital health system logs [38,183]. The DQ outcomes could be assessed by extracting prerecorded key performance indicators from case hospitals and be triangulated with interview data to capture patients’, clinicians’, and hospitals’ perspectives of the impacts of DQ [184]. This could then be incorporated into a longitudinal study in which data collection is performed before and after a DQ improvement intervention, which would provide efficacy to the digital health DQ intervention.

## Section: Discussion › Implications for Future Work › Implication 3: Understanding the Root Causes of DQ Challenges

Although this study provides a first step toward a more comprehensive understanding of DQ dimensions for digital health data and their influences on outcomes, it does not explore the potential causes of such DQ challenges. Without understanding the reasons behind these DQ issues, the true potential of evidence-based health care decision-making remains unfulfilled. Future research should examine the root causes of DQ challenges in health care data to prevent such challenges from occurring in the first place. A framework that may prove useful in illuminating the root causes of DQ issues is the Odigos framework, which indicates that DQ issues emanate from the social world (ie, macro and situational structures, roles, and norms), material world (eg, quality of the EHR system and technological infrastructure), and personal world (eg, characteristics and behaviors of health care professionals) [183]. These insights could then be incorporated into a data governance roadmap for digital hospitals.

## Section: Discussion › Implications for Future Work › Implication 4: Systematic Assessment and Remedy of DQ Issues

Although prevention remains better than the cure (refer to implication 3), not all DQ errors can be prevented or mitigated. It is common for many health care organizations to dedicate resources to data cleaning to obtain high-quality data in a timely manner, and this will remain necessary (although hopefully to a lesser degree). Some studies (eg, Weiskopf et al [18]) advocate evidence-based guidelines and frameworks for a detailed assessment of the quality of digital health data. However, few studies have focused on a systematic and automated method of assessing and remedying common DQ issues. Future research should also focus on evidence-based guidelines, best practices, and automated means to assess and remedy digital health data.

## Section: Discussion › Limitations

This review is scoped to studying digital health data generated within a hospital setting and not those generated within other health care settings. This is necessary because of the vast differences between acute health care settings and primary care. Future research should seek to investigate the digital health data of primary care settings to identify the DQ dimensions and outcomes relevant to these settings. In addition, this literature review has been scoped to peer-reviewed outlets, with “grey” literature excluded, which could have led to publication bias. Although this scoping may have resulted in the exclusion of some relevant articles, it was necessary to ensure the quality behind the development of the digital health DQ framework. An additional limitation that may be raised by our method is that because of the sheer number of articles returned by our search, we did not perform double coding (where 2 independent researchers analyze the same article). To mitigate this limitation, steps were taken to minimize bias by conducting coder corroboration sessions and group validation, as mentioned in the Methods section, with the objective of improving internal and external reliability [66]. To further improve internal reliability, 2 experienced researchers verified the entirety of the analysis in NVivo and to improve external reliability, card-sorting assessments were performed with DQ experts, and the findings were presented and confirmed by 3 digital health care professionals. Furthermore, empirical validation of the framework is required, both in terms of real-life data and inputs from a range of experts.

## Section: Discussion › Conclusions

The multidisciplinary systematic literature review conducted in this study resulted in the development of a consolidated digital health DQ framework comprising 6 DQ dimensions, the interrelationships among these dimensions, 6 DQ outcomes, and the relationships between these dimensions and outcomes. We identified four core implications to motivate future research: specifically, researchers should (1) pay equal consideration to all dimensions of DQ, as the dimensions can both directly and indirectly influence DQ outcomes; (2) seek to empirically assess the DQ-DO framework using a mixed methods case study design; (3) identify the root causes of the digital health DQ issues; and (4) develop interventions for mitigating DQ issues or preventing them from arising. The DQ-DO framework provides health care executives (eg, chief information officers and chief clinical informatics officers) with insights into DQ issues and which digital health-related outcomes they have an impact on, and this can help them prioritize tackling DQ-related problems.


---

# Digital Research Environment(DRE)-enabled Artificial Intelligence (AI) to facilitate early stage drug development

- **Authors:** Jeffrey S Barrett, Solmaz Eradat Oskoui, Scott Russell, Amanda Borens
- **Issuer:** Frontiers in pharmacology
- **Type:** Scientific article
- **Published:** 2023-03-24
- **Language:** en
- **DOI:** 10.3389/fphar.2023.1115356
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37033647/
- **Licence:** CC-BY

## Page 1 (Section: Digital Research Environment(DRE)-enabled Artificial Intelligence (AI) to facilitate early stage drug development)

Digital Research
Environment(DRE)-enabled
Artiﬁcial Intelligence (AI) to
facilitate early stage drug
development
Jeffrey S. Barrett*, Solmaz Eradat Oskoui, Scott Russell and
Amanda Borens
Aridhia Digital Research Environment, Glasgow, United Kingdom
Early-stage drug discovery is highly dependent upon drug target evaluation,
understanding
of
disease
progression
and
identiﬁcation
of
patient
characteristics linked to disease progression overlaid upon chemical libraries of
potential drug candidates. Artiﬁcial intelligence (AI) has become a credible
approach towards dealing with the diversity and volume of data in the modern
drug development phase. There are a growing number of services and solutions
available to pharmaceutical sponsors though most prefer to constrain their own
data to closed solutions given the intellectual property considerations. Newer
platforms offer an alternative, outsourced solution leveraging sponsors data with
other, external open-source data to anchor predictions (often proprietary
algorithms) which are reﬁned given data indexed upon the sponsor’s own
chemical libraries. Digital research environments (DREs) provide a mechanism
to ingest, curate, integrate and otherwise manage the diverse data types relevant
for drug discovery activities and also provide workspace services from which
target sharing and collaboration can occur providing yet another alternative with
sponsors being in control of the platform, data and predictive algorithms.
Regulatory engagement will be essential in the operationalizing of the various
solutions and alternatives; current treatment of drug discovery data may not be
adequate with respect to both quality and useability in the future. More
sophisticated AI/ML algorithms are likely based on current performance
metrics and diverse data types (e.g., imaging and genomic data) will certainly
be a more consistent part of the myriad of data types that fuel future AI-based
algorithms. This favors a dynamic DRE-enabled environment to support drug
discovery.
KEYWORDS
artiﬁcial intelligence, drug developement, drug discovery, data sharing, digital research
environment
OPEN ACCESS
EDITED BY
Verena Schöning,
University Hospital of Bern, Switzerland
REVIEWED BY
Felix Hammann,
University Hospital of Bern, Switzerland
Amit Khurana,
University Hospital RWTH Aachen,
Germany
Nils Weskamp,
Boehringer Ingelheim, Germany
*CORRESPONDENCE
Jeffrey S. Barrett,
Jeff.barrett@aridhia.com
SPECIALTY SECTION
This article was submitted to
Experimental Pharmacology
and Drug Discovery,
a section of the journal
Frontiers in Pharmacology
RECEIVED 03 December 2022
ACCEPTED 14 March 2023
PUBLISHED 24 March 2023
CITATION
Barrett JS, Oskoui SE, Russell S and
Borens A (2023), Digital Research
Environment(DRE)-enabled Artiﬁcial
Intelligence (AI) to facilitate early stage
drug development.
Front. Pharmacol. 14:1115356.
doi: 10.3389/fphar.2023.1115356
COPYRIGHT
© 2023 Barrett, Oskoui, Russell and
Borens. This is an open-access article
distributed under the terms of the
Creative Commons Attribution License
(CC BY). The use, distribution or
reproduction in other forums is
permitted, provided the original author(s)
and the copyright owner(s) are credited
and that the original publication in this
journal is cited, in accordance with
accepted academic practice. No use,
distribution or reproduction is permitted
which does not comply with these terms.
Frontiers in Pharmacology
frontiersin.org
01
TYPE Perspective
PUBLISHED 24 March 2023
DOI 10.3389/fphar.2023.1115356

## Page 2 (Section: Introduction)

Introduction
The drug discovery process and milestones
The discovery phase includes early aspects of drug research
designed to conﬁrm pharmacologic targets, identify investigational
drug candidates, and perform initial experiments that allow scientists
to rank and select candidates for preclinical evaluation. This ﬁrst stage
of the process takes approximately three to 6 years. Researchers hope
to identify one or more promising drug candidates for further
investigation, ultimately in humans. Investigators conduct studies
in cells, tissues, and animal models to determine whether the target
can be inﬂuenced by a drug candidate. Target validation is crucial to
help scientists identify the most promising approaches before going
into the laboratory to develop potential drug candidates, increasing
the efﬁciency and effectiveness of the R&D process.
In actuality this phase consists of two distinct segments: an
initial discovery phase, followed by a development phase. These two
phases differ signiﬁcantly from each other with respect to scope,
challenges, and approaches. Differences notwithstanding, discovery
and development must be integrated into a coherent whole for the
process to be successful. Accordingly, much thought has been
devoted
to
insuring
scientiﬁc,
logistical,
and
organizational
aspects of such integration are taken into consideration and
optimized. Figure 1 provides a schematic representation of the
modern drug discovery process focusing only on the elements
critical to target validation and candidate selection. As the
current discovery and preclinical phases of development are very
much deﬁned by the design and conduct of discrete experiments
(e.g., the initial pre-clinical pharmacological screening especially
while in vivo studies are ongoing), AI/ML approaches can help by
both reﬁning these experiments as well as test assumptions related to
their outcome. As conﬁdence in this approach improves, this could
obviate the need for some of these experiments entirely and limit the
amount of in vivo animal testing.
The entire process of drug discovery and preclinical development
is summarized for the eventual purpose of ﬁlling a new drug
application,
in
standardized
form
of
Common
Technical
Document (CTD), containing ﬁve modules (Jordan, 2014). A high-
level summary of the process would include diverse data, critical
decisions and documentation but this would be true of all drug
development phases on the surface. Artiﬁcial intelligence (AI)
approaches to inform drug development are most focused at early
and late stages of development mostly based on the nature and type of
data generated in these stages. At early stages of development, the
chemical space is generally viewed as comprising > 1,060 molecules
(Paul et al., 2021). The virtual chemical space is vast and suggests a
geographical map of molecules by illustrating the distributions of
molecules and their properties. The idea behind the illustration of
chemical space is to collect positional information about molecules
within the space to search for bioactive compounds and, thus, virtual
screening helps to select appropriate molecules for further testing.
Several chemical spaces are open access, including PubChem
(PubChem, 2023), ChemBank, DrugBank (Drug Bank, 2023),
ChEMBL (ChEMBL, 2023), and ChemDB.
AI is well-suited for these tasks because it can handle large volumes
of data with enhanced automation (Bohr and Memarzadeh, 2020). AI
involves several method domains, such as reasoning, knowledge
representation, solution search, and, among them, a fundamental
paradigm of machine learning (ML). ML uses algorithms that can
recognize patterns within a set of data that has been further classiﬁed. A
subﬁeld of the ML is deep learning (DL), which engages artiﬁcial neural
networks (ANNs). While discovery groups are eager to leverage AL/ML
to acquire meaningful insights from the enormous data they hold or
acquire, the accuracy of the AI/ML models depends on the volume and
quality of the data used as an input for training them. Inaccurate input
GRAPHICAL ABSTRACT
Frontiers in Pharmacology
frontiersin.org
02
Barrett et al.
10.3389/fphar.2023.1115356

## Page 3 (Section: Collaborative research environments: Platforms, TREs and DREs)

data can result in misleading outcomes delivered by the AI/ML models
but generally this approach is more forgiving with respect to data quality
and uncertainty relative to traditional modeling approaches. While
automation systems can cleanse data based on explicit programming
rules (e.g., imputation algorithms), it’s almost impossible for them to ﬁll
in all missing data gaps without some manual intervention or plugging
in additional data source feeds. However, machine learning can make
calculated assessments on missing data based on its reading of the
situation.
The cost of bringing new drugs from bench to bedside has become
excessively steep. In identifying these trends, AI/ML-driven in silico
platforms are alluring to the pharmaceutical and healthcare industry
due to their multidimensional, predictive capabilities, and the
associated increased efﬁciency. Traditional model-informed drug
development (MIDD) approaches have been used in drug discovery
and development over the last 2decades with the recent increase in
complexity from the usage of AI/ML-driven in silico platforms. Table 1
highlights some of the more common model types and impact on
early-phase drug development. Application opportunities for AI/ML
can be associated with all stages of drug discovery and development.
For example, drug-target validation and engagement, identiﬁcation of
prognostic biomarkers and evaluation of digitized clinical pathology
data in clinical trials, and ﬁnally high-accuracy predictions of the
pharmacokinetic, pharmacodynamic, and efﬁcacy parameters from a
limited pool of physiological and pharmacological preclinical and
clinical datasets. As each of these decision points also represents a
milestone for early phase drug development, one can also appreciate
that there are no obvious gaps in an AI-driven approach which seems
to coincide with the recent investment in these approaches (Maharao
et al., 2020; Paul et al., 2021).
AI expertise is highly desirable by a multitude of sectors now and
AI technologies are being recruited by universities and scientiﬁc
institutions. As these technologies advance and become more
sophisticated, experts are certain that they will revolutionize
academia. It has been maintained by some that areas in which
AI-enabled technologies will change the game in science and
academia are varied and driven by enhanced access to data in an
unprecedented speed and volume, peer review procedures that
enable data-driven scientiﬁc hypotheses and.
AI-enabled technologies that are paving the way for open-source
science (Lexis Nexis Report, 2020). As drug development is inherently
multidisciplinary, it will be incumbent upon the leadership in the core
disciplines of biology, chemistry, engineering, pharmacy and other life
and quantitative sciences to offer AI/ML curriculum to its student
population in order to better prepare the future workforce and ensure
that the supply of core disciplines has the requisite training to
appreciate and apply these methodologies.
Collaborative research environments:
Platforms, TREs and DREs
Data generation and FAIR
The hurdle to speeding the pace of both patient diagnosis and drug
development is that patient health data is often held and accessed by
a single group or organization (“silos,” in other words), and patient
conﬁdentiality and uncertainty around governance and provenance
makes data-sharing problematic. Adding to that aspect is the fact the
what constitutes patient level health data is not all maintained in the
same operational data store. It is quite common for patient records,
pharmacy data and genomic data to reside in different data structures
(more silos). To overcome this hurdle, researchers and organizations
are leaning into a relatively new method of health data management, by
establishing trusted research environments (TREs) (Bacchelli, 2022).
TRE is becoming a commonly used acronym among the science and
research community. In general, a TRE is a secure collaborative
research environment for digital analysis of data. TREs can only be
accessed by approved researchers. Governance processes and TRE
FIGURE 1
Schematic of typical Discovery phase activities used in the process of target identiﬁcation and early candidate selection; often referred to and
described as the “DMTA cycle” (Design-Make-Test-Analyze).
Frontiers in Pharmacology
frontiersin.org
03
Barrett et al.
10.3389/fphar.2023.1115356

## Page 4 (Section: Collaborative research environments: Platforms, TREs and DREs)

features ensure only approved researchers can access data, and no data
enters or leaves the environment without the express permission of an
approved proxy for the data owner. Because data stays put, the risk of
patient conﬁdentiality is reduced. However successful the TRE is at
reducing risk of sharing sensitive data across separate invited
collaborators, it is not inherently a means to breaking down siloes.
Essential companions to the TRE are dynamically-updated and
searchable metadata catalogs, in situ analysis tools with code
versioning, as well as data provenance, and audit trails (Graham
et al., 2022). Without these, a TRE is simply a safe place for a single
project to be completed and then archived with limited usefulness for
new projects or data consumers on other project teams. A DRE
Workspace is a Trusted Research Environment–providing a safe-
haven for clinical researchers, bioinformaticians and pharmacologists
to analyze and develop models on sensitive data with the conﬁdence
that the data and models developed are secure and protected. A DRE
builds on the concept of a TRE in that it provides remote access to data
alongside tools for analysis in a securely controlled workspace, but it
also adds essential components that allow the data and tools to be FAIR
(Findable, Accessible, Interoperable, and Reusable), version-controlled
and dynamically growing in size or quality as a result of each
collaboration, and to break down the silos often created by
aggregating and analyzing data as a single-use asset.
Vital to collaborative development is the need for individuals to
modify, change and ﬁx on their own versions of code without
disrupting other team members. When code is committed and a
submission is made, either to a research paper, as a thesis or for
approval from a regulatory body–reproducibility of outcomes is
essential. It must be possible to re-run the exact code, on the exact
data on the exact compute infrastructure and verify that the results
FIGURE 2
Diagram illustrating a typical ﬂow for development and review purposes based on the Aridhia DRE Workspace Environment.
TABLE 1 Data, model and stage-gate decision connectivity in a traditional MIDD drug discovery paradigm.
Stage-gate
decision
Typical data to inform decision
Complimentary
model(s)
Stakeholders
Target validation
Drug discovery data: in vitro screening data; chemical libraries;
in silico modeling results, etc.
QSAR, QSP models
Pharmacology, Medicinal Chemistry
Target
indication(s)
Commercial data on medical need, prevalence, etc. (e.g., claims
data; epidemiologic data)
HECON; pharmacoeconomic
models
R&D Therapeutic areas, Franchise commercial
groups
Candidate selection
Preclinical (animal in vivo) PK/PD experiments, Toxicology
(TK/outcomes) trials, in vitro biomarker data, IVIVC data,
Human PK/PD, patient RWD
PK, PK/PD, Pop-PK/PD
Pharmacology, Formulations, Toxicology/Safety
Assessment, Epidemiology, Clinical Pharmacology,
FIH dose
PBPK, Biopharmaceutic models,
QSP models
R&D Therapeutic Areas
Biomarker strategy
POC trial design
Endpoint selection
Patient enrollment
criteria
Frontiers in Pharmacology
frontiersin.org
04
Barrett et al.
10.3389/fphar.2023.1115356

## Page 5 (Section: AI/ML–Drug discovery use cases)

and outcomes are unchanged. Such transparent reproducibility is
only possible with version control software.
Outside of a workspace, Git -Scm (2023), the open-source
versioning control software, along with GitHub (2023) for
hosting has become the standard for collaborative development,
not only for code but for API standards and, signiﬁcantly for
healthcare data science, ontologies. Figure 2 illustrates a typical
ﬂow for development and review purposes for the Aridhia DRE as an
example of a DRE workspace environment. Important elements of
the workﬂow are the security access to the DRE in general, the FAIR
data services which manage the ingestion, curation and integration
aspects of the process and provide audit trails to any further data
transformation and the workspace tooling of both open-souce and
proprietary software or connectivity to other platforms that could
provide AI/ML solutions via access from the DRE.
Inside a workspace, where data is often highly sensitive, security is
of paramount importance and access to online repositories is typically
prohibited, users still require the Git-like abilities to create
repositories,
clone
them,
import
external
repositories
(with
appropriate review and security controls) and push reviewed and
approved code to repositories or other workspaces as part of the
outbound airlock process. For drug discovery purposes there are a
number of open source databases that would provide an anchor for
AI-based predictions but most commonly these data will be joined by
proprietary data from drug sponsors seeking to protect their
intellectual property. Best practice recommendations for code
development and publishing with a Trusted Research Environment
(Chalstrey, 2021) have been proposed by the Turing Institute.
The paper by the Turing Institute promotes best practice
recommendations (Chalstrey, 2021). Key to the conclusions
within the paper is the requirement to version code, data and
compute within the scope of a DRE. Outcomes must be digitally
reproducible and the paper recommends the use of Conda for
package management and Git for code, model and (where
appropriate)
data
versioning.
The
Aridhia
DRE
workspace
provides support for the use of Anaconda (https://knowledgebase.
aridhia.io/article/installing-anaconda-and-running-jupyter-
notebooks-on-the-virtual-machine/) and has now released the
integration of Gitea (https://gitea.io/en-us/). Users of a workspace
now have access to their own completely secure version control
system. This is completely locked within the scope of a Workspace,
ensuring that data and code cannot leak to other workspaces or leave
the workspace environment without going through the accepted
airlock release checks and balances. Based on discussion with data
science, modelling and governance communities, this approach
seems to hit the right balance between freedom to operate for
workspace owners and the rigorous security and information
governance requirements of data controllers.
As it pertains to drug discovery in particular, historically most
large PhRMA companies have relied on their own chemical libraries
as sources for both target validation and candidate selection. This is
limiting in the sense that this data deﬁnes therapeutic areas of
current interest where historical libraries may be thin. To augment
this deﬁcit, occasionally companies may either develop partnerships
with some organizations having more extensive libraries or acquire
them entirely [BioProcess Online Press release. “ChemRx To
Develop
Compounds
For
Signal
Pharma
Under
New
Agreement,”1998, https://www.bioprocessonline.com/doc/chemrx-
to-develop-compounds-for-signal-pharma-0001 and Astellas press
release, “Astellas Announces Acquisition of Nanna,” 2020, https://
www.astellas.com/en/news/15756] both of which are timely, costly
and may have intellectual property (IP) considerations. This
behaviour continues with a single goal in mind, to signiﬁcantly
extend capabilities to support drug discovery. More is deﬁnitely
better in the case of chemical libraries. Even though this is often
outside the realm of data sharing, the details of data acquisition,
curation and integration are essential and often not exposed to any
great extent and are likely to be time consuming and costly. It’s
likewise a setting where an internally facing DRE may have an
advantage over more traditional ETL (extract, transform, load)
procedures. In the case where collaborations are in place (e.g.,
academic and industry based with IP sharing under contractual
agreement), data sharing must be more directly dealt with and
described in detail in both data collaboration and data use
agreements (DUAs and DCAs) (Barrett, 2020). The data sharing
application of both TREs and DREs are obvious with many examples
including Yoda (Ross et al., 2018), RDCA-DAP (Larkindale et al.,
2022), ADDI (ADDI, 2021) and ICODA (Zariffa et al., 2021) to
name a few. Some focus on providing honest broker services for data
designated for public sharing (Yoda) and others emphasize a
collaborative research environment from which data sharing and
collaboration via analytic tool development (RDCA-DAP) can
actually occur.
AI/ML–Drug discovery use cases
There are many open-source projects which have been creating
collaborative tooling for drug discovery (e.g., VirtualFlow, https://
github.com/VirtualFlow/VFVS). The opportunity for different drug
discovery libraries to be used within a DRE can further aid in creating
a trustworthy, transparent, and collaborative research environment.
Scarcity of biological data for the purpose of building accurate and
robust Machine learning models in the area of drug discovery is a well-
known problem. Open source tools and projects are providing a
solution through the additional tooling and collaborative approach to
addressing this problem. Below we identify several, mostly academic
efforts to guide and support drug discovery in targeted therapeutic
areas where AI-based approaches have been integrated into drug
discovery milestones. The use cases are reviewed highlighting their
focus and track record in advancing drug discovery science. We also
provide and assessment for how these use cases could be further
optimized in a DRE environment.
Drug discovery for TB combination
therapy—TUFTS university
Until COVID-19 appeared in 2020, tuberculosis (TB) was
acknowledged as the deadliest infectious disease and still tops the
list of deadly infectious diseases (European Centre for Disease
Prevention
and
Control
Press
Release,
2022).
Its
current
therapeutic treatment is based on a cocktail of four drugs taken
for 4 months duration with signiﬁcant side effects that make it difﬁcult
for many patients to complete the regimen. TB is also becoming
increasingly resistant to standard treatments. The TUFTS research
Frontiers in Pharmacology
frontiersin.org
05
Barrett et al.
10.3389/fphar.2023.1115356

## Page 6 (Section: DeepChem and TorchDrug and other chemical library examples)

environment and platform creates accurate predictions of how
effective treatments will perform when moving from testing in a
lab to testing in mouse models which is typically the purview of drug
discovery. Promising new antibiotics aimed at TB have been
developed recently. But researchers and drug developers have been
challenged to ﬁnd ways to cheaply and effectively determine which
drugs will work best in combination (Terreni et al., 2021). It’s a
mathematically complex, expensive, and time-consuming process
using traditional procedures.
During
drug
development,
scientists
ﬁrst
test
potential
pharmaceuticals in the lab relying on in vitro experiments with
TB bacteria. Treatments that kill TB proceed to testing in lab
rodents, and those regimens that are determined effective in
rodents
proceed
eventually
to
clinical
trials
in
humans.
Combination therapy is necessary because the TB bacterium
Mycobacterium tuberculosis is highly adaptive to its site of
infection, giving rise to differences in drug response among the
bacteria in a single person. Also, individuals may be infected with a
drug-resistant strain, or their TB infection may evolve over time to
become resistant to one or more of the traditional cocktail’s
antibiotics. Using mathematical models and artiﬁcial intelligence,
the Tufts team discovered a set of rules that drug pairs need to satisfy
to be potentially good treatments (Aldridge et al., 2021).
The AI predictive algorithm DiaMOND (Larkins-Ford et al.,
2022)
is
based
on
diagonal
measurement
of
n-way
drug
interactions, a method to systemically study pairwise and high-
order drug combination interactions to identify shorter, more
efﬁcient treatment regimens for TB and diseases that require
combination
drug
therapy.
With
design
rules
established,
researchers believe this system can increase the speed at which
discovery scientists can determine which drug combinations will
most effectively treat tuberculosis. This modeling system and the
use of drug pairs (rather than combinations of three or four drugs)
cuts down signiﬁcantly on the amount of testing that needs to be done
before moving a drug pair into further study. As this system becomes
an option for drug developers, mechanisms to deal with varied data
contributors and data governance/provenance issues may necessitate
the evolution of this platform to become a multi-stakeholder DRE. At
the moment, interested stakeholders can contact the PI for interest in
supplying drug for experimental and in silico analysis with potential
combination outcomes generated in an iterative manner. External
stakeholders cannot access the environment directly and are reliant on
the research team to publish ﬁndings to generate their own summary
data for subsequent analyses.
DeepChem and TorchDrug and other
chemical library examples
Another project aiming to create collaborative open-source tools
for drug discovery as well as material science, quantum chemistry
and biology is the DeepChem project (DeepChem, 2022). The
project aims to address some of the key issues when building
machine learning models on molecules, namely, limited amount
of data, wide range of outputs to predict, large heterogeneity in input
molecular
structure
and
appropriate
learning
algorithms
to
benchmark model performance (Wu et al., 2018). The paper
“Low Data Drug Discovery with one-shot learning” points out
the central problem of small-molecule based drug discovery is to
optimize the candidate molecule by ﬁnding analogue molecules with
increased pharmaceutical activity and reduced patient risks. The
paper outlines the capacity for deep neural networks is underpinned
by their ability to learn from large amounts of biological data. The
lack of large datasets for models to learn and form accurate
predictions for novel compounds remains a challenge in drug
discovery. Using the DeepChem open-source framework for
deep-learning they demonstrate how one-shot learning can lower
the amount of data required to make meaningful predictions in drug
discovery (Altae-Tran et al., 2017). The DeepChem library was
extended into an end-to-end modelling pipeline for drug discovery
through the ATOM Modeling PipeLine [AMPL] (Minnich et al.,
2020). AMPL showed DeepChem can be used in a large scale
pipeline for Pharma drug discovery efforts.
Build on top of the PyTorch library, TorchDrug benchmarks a
variety of important tasks in drug discovery, including molecular
property prediction, pretrained molecular representations, de novo
molecular design and optimization, retrosynthsis prediction, and
biomedical
knowledge
graph
reasoning
(Zhu
et
al.,
2022).
Therapeutics Data Commons (TDC) a platform comprised of
three components, namely, 66 AI-ready datasets and 22 learning
tasks for drug discovery and development, an ecosystem of tools and
community resources and leaderboards for therapeutics machine
learning (Huang et al., 2022). In the context of relational deep
learning, ChemicalX (Rozemberczki et al., 2022) is a deep learning
library for drug-drug interactions, polypharmacy side effect, and
synergy predictions. Its deep neural network architecture can be
used to solve the drug pair scoring task. By predicting the outcome of
administering two drugs together in a biological or chemical context
(ChemicalX, 2022). In the area of genomic deep learning, a tool that
is envisioned to facilitate drug discovery is Graphein (Jamasb et al.,
2020). It is a tool for transforming raw data from widely-used
bioinformatics databases into machine learning-ready datasets. It
is a Python library for constructing graph and surface-mesh
representations of protein structures and biological interaction
networks for computational analysis. The use cases in this
example illustrate how chemical libraries can be interfaced with
AI-based tooling to answer early phase drug development questions.
The missing element in these efforts in the appropriateness of the
various “AI-ready datasets” described above to certain, speciﬁc
contexts of use across a variety of target therapeutic areas and
drug targets. Likewise, the incremental beneﬁt of augmented such
data with data from a drug sponsor is not known. Both of these
aspects could be accommodated within the conﬁnes of a sponsor-
governed and owned DRE in which the such libraries could co-exist
and in which software and tooling could be directly deployed within
a DRE workspace or run within a virtual machine that is deployed in
a DRE workspace.
DRE requirements for AI/ML data
exploitation and collaboration
Data requirements
Despite some misconceptions about the ability to simply drop an
army of messy data into a generic ﬁle repository, run some
algorithms, and receive magical insights, data requirements for
Frontiers in Pharmacology
frontiersin.org
06
Barrett et al.
10.3389/fphar.2023.1115356

## Page 7 (Section: Compute requirements)

efﬁcient, effective AI and ML models are signiﬁcant (Paullada et al.,
2021). When biotech companies outsource AI projects in the drug
discovery phase, they often ship their proprietary data off to external
vendor platforms to be transformed and standardized as needed for
aggregation with subsets from open-source data repositories. In
addition to the risk of data leakage, companies lose visibility into the
data curation work and may have a loose connection to its
provenance. This situation creates potential for unintended costs
in time, insights, and money in several ways. Different vendor teams
may be repeating the same data cleaning each time and charging
proportionately, or they may choose to leave data as it is received but
charge for the excessive compute resources needed to analyze messy
data. In some cases, messy data give insights but take longer to
process, and in other cases the messy data produce noisy and
unhelpful mathematical results.
Moreover, companies’ transformed data are not useful for future
projects with new formats or model input speciﬁcations, which also
fails to extract the full potential of the data for later phases of the
drug development process. An alternative that solves these concerns
is keeping proprietary data in a private company DRE where data
transformations and other cleaning processes may be standardized
across projects with audit trails to provide provenance and a robust
metadata catalog to increase interoperability and reusability.
Owning internal data curation standards allows federated access
to open-source repositories by maintaining the interoperability of
internal data assets. The DRE in this case reduces the multiplying
cost of sending data to outsourced vendors to be repeatedly
processed, but it also facilitates dynamic improvement of data
assets for all projects in the organization. Because the DRE
provides internal AI/ML experts and external contractors secure
access to data, tools and scalable compute resources in one audited
environment, the downstream advantage is that companies may use
their proprietary data assets in later phases of drug development
where regulatory tolerance for data and algorithms without
provenance is minimal.
Compute requirements
The DRE, as the research environment, requires access to
appropriately sized and conﬁgured pools of compute. Depending
on the tools used and environment required to run them, these can
range from dedicated machines, such as a Virtual Machine or
“Instance”
in
a
cloud
environment
to
High
Performance
Compute (HPC) clusters dedicated to running batch systems,
where discrete jobs can be run across a cluster in parallel,
allowing for distributed compute and processing. These batch
processing environments will orchestrate the execution of jobs in
accordance with developer conﬁguration, to produce optimal
results. These systems can signiﬁcantly reduce the time to
execute ML processes, however, can often be cost prohibitive. An
alternative to a dedicated HPC cluster is to take advantage of cloud
services offered by all the major cloud vendors such as AWS, Azure
and Google. Each has ML focused batch compute environments that
can be run on demand using only the compute they need.
Developers and researchers can choose the balance between
runtime and costs and the system ensures that only the compute
required is run at any point in time.
As learning algorithms need to run against as many different
training sources as possible, potentially across various geographies,
the need to federate this compute across multiple environments
becomes more pertinent. The Global Alliance For Genomic Health
has developed a standard application programming interface (API)
known as the Task Execution Service (TES). The TES provides a
standard API for nodes of a federated network to implement,
allowing for an orchestrated machine learning system to execute
jobs relevant to their tasks on remote compute nodes. This can
ensure that data remains within the geography and within the DRE
implementing the API. The results of the execution are provided to
the orchestration engine to inform the learning process.
Discussion
AI/ML techniques have been successfully applied to drug
discovery and early stage drug development but most of the
successful use cases have been generated through partnerships
and outsourced solutions (Liu et al., 2021; Terreni et al., 2021;
Schauperl and Denny, 2022). The beneﬁt of TRE or even DRE
solutions has been less appreciated as they appear to create a sense of
vulnerability from an intellectual property standpoint as data
sharing is the presumed emphasis of such solutions. Likewise,
FAIR and workspace services are appreciated for late stage drug
development but don’t always seem essential for drug discovery and
late stage development based on a presumed high overhead (effort
and cost). The reality however is that AI-based drug discovery
applications can be more easily managed and controlled in a
robust, DIY (do-it-yourself) approach which cannot only provide
an integrated solution owned and managed by the sponsor but also
offer a complementary solution to established MIDD approaches
that facilitate decision making.
Data sharing initiative are many including many consortia (e.g.,
https://www.melloddy.eu/,
https://www.pistoiaalliance.org/,
etc.)
but in fact the majority of these are focused on late-stage drug
development and the sharing of clinical trial, patient-level data and
not early-stage development or drug discovery data. Other initiatives
such as the Open Reaction Database (https://docs.open-reaction-
database.org/en/latest/index.html) are more complementary as they
seek to build an open access chemical reaction database to support
machine learning and related efforts in reaction prediction, chemical
synthesis planning, and experiment design. A consortium-based
approach to accumulating and sharing drug discovery data is
unlikely given concerns for IP as deﬁned previously.
The MIDD approach is well entrenched in the current drug
development paradigm both from innovators seeking to develop
new drugs and new drug targets as well as regulators who must judge
the suitability of evidentiary proof that proposed new treatments are
both safe and efﬁcacious. The current approach is highly dependent
on quantitative scientists with expertise in various forms of
modeling and simulation methodologies, a suite of software
solutions
that
permit
the
development,
codiﬁcation,
and
validation of discrete models that de-risk decision making and a
modern compute environment to house the software and model
libraries so that such resources can be maintained in a secure, Part
11 compliant manner and share among its practitioners. Most
importantly, the current MIDD approach relies on buy-in from
senior leaders within and organization and favorable interactions
with regulatory authorities. Likewise, as the approach evolves and
Frontiers in Pharmacology
frontiersin.org
07
Barrett et al.
10.3389/fphar.2023.1115356

## Page 8 (Section: Data availability statement)

certainly if considerations for an AI-enabled approach is put
forward, these interactions will require revisiting with additional
education and performance conﬁrmation.
The ﬁeld is constantly evolving requiring additional skillsets and
expertise as well as diverse software solutions, customized and
secure
compute
platforms
and
new
methodologies
and
approaches.
Sponsors
likewise
recognize
that investment
in
MIDD is similarly evolving and growing. As the industry
constantly
seeks
more
efﬁcient
and
cost-effective
solutions,
MIDD is not immune to this scrutiny. Much of the recent effort
to improve the efﬁciency of MIDD is based on improved access to
integrated data sources, creating libraries of model elements that can
be shared and combined as needed and improving the compute
platform to ensure that relevant tools and software solutions can
coexist on the same platform. Little has been done to alter the data or
model types that inform the commonly held critical decisions as
previously outlined.
Artiﬁcial intelligence has received much interest of late as a
complementary tool to answer speciﬁc drug development questions
and pharmaceutical sponsors have been both dedicating internal
resources and investing in external partnerships to enhance their
knowledge and expertise in this discipline (Liu et al., 2020). An
outgrowth of this interest has been the submission of some of these
efforts to regulatory authorities. As recent work suggests (Liu et al.,
2023), the number of these submissions has increased dramatically
recently allowing authorities to gain an understanding of the
diversity of applications that might support drug development
and judge the usefulness of the approach for regulatory decision
making. Some positive outcomes from this early experience includes
the generation of early thoughts on guiding principles and the
development of consortiums and shared resources. While these
are early days in the process of getting comfortable with the
approach and gaining conﬁdence in the application, it is also an
opportunity to gage future requirements for submission of such AI/
ML implementations and consider how transformative the approach
could be in a more coordinated manner. Early regulatory guidance
(Liu et al., 2020; Liu et al., 2023) suggest that regulatory authorities
are also anticipating broader utilization.
A future, but hopefully near-term effort should include the
consideration of AI/ML application as either a complimentary or
entirely self-sufﬁcient approach to support an MIDD paradigm,
particularly in support of early stage drug development. Early
adopters of the approach tend to compartmentalize the effort
into certain drug development sectors (Liu et al., 2020; Maharao
et al., 2020; Paul et al., 2021) but few have considered this as an
end-to-end solution. Moreover, the approach is still being
compared to traditional MIDD efforts, speciﬁcally around the
comparison of AI/ML prediction against speciﬁc model types
(PBPK, PK/PD, CTS, etc.) and not around the data types and
dimensions that would inform the various approaches or whether
a revamped approach considering the optimal information value
(driven by data and models) needed to guide regulatory
milestones.
While
drug
discovery
and
early
stage
drug
development may be considered an acceptable frontier for this
effort at face value given the presumed lower bar for regulatory
buy-in and acceptance, there will be continuity gains for ensuring
data traceability and audit trails as the early-stage AI deliverables
become linked to later-stage efforts and milestones. Clearly, the
path forward involves collaboration and an open mind with
respect to optimized and informative data generation coupled
with tools that can be utilized with high ﬁdelity based on
mutually agreed and objective performance criteria.
Data availability statement
The original contributions presented in the study are included in
the article/supplementary materials, further inquiries can be
directed to the corresponding author.
Author contributions
All authors (JB, SO, SR, and AB) contributed to the writing of
this manuscript; JB generated the outline and provided ﬁnal editing.
Conﬂict of interest
The authors declare that the research was conducted in the
absence of any commercial or ﬁnancial relationships that could be
construed as a potential conﬂict of interest.
Publisher’s note
All claims expressed in this article are solely those of the authors
and
do
not
necessarily
represent
those
of
their
afﬁliated
organizations, or those of the publisher, the editors and the
reviewers. Any product that may be evaluated in this article, or
claim that may be made by its manufacturer, is not guaranteed or
endorsed by the publisher.
References
ADDI (2021). Federating data access, alzheimer’s data research. Avaliable At: https://
www.alzheimersdata.org/news/federated-data-access.
Aldridge, B. B., Barros-Aguirre, D., Barry, C. E., Bates, R. H., Berthel, S. J.,
Boshoff, H. I., et al. (2021). The tuberculosis drug accelerator at year 10: What have
we learned? Nat. Med. 27, 1333–1337. doi:10.1038/s41591-021-01442-2
Altae-Tran, H., Ramsundar, B., Pappu, A. S., and Pande, V. (2017). Low data drug
discovery with one-shot learning. Washington DC: American Chemical Society, 283–293.
Bacchelli, C. (2022). The future of health data management: Enabling a trusted
research environment: Technology Networks Informatics. Avaliable At: https://
www.technologynetworks.com/informatics/articles/the-future-of-health-data-
management-enabling-a-trusted-research-environment-359592
(accessed
9
3,
2023).
Barrett, J. S. (2020). Perspective on data-sharing requirements for the necessary evolution of
drug development. J. Clin. Pharmacol. 60 (6), 688–690. doi:10.1002/jcph.1607
Bohr, A., and Memarzadeh, K. (2020). The rise of artiﬁcial intelligence in healthcare
applications. Artif. Intell. Healthc. 2020, 25–60. doi:10.1016/B978-0-12-818438-7.
00002-2
Chalstrey, E. (2021). Developing and publishing code for trusted research
environments: Best practices and ways of working. Avaliable At: https://www.turing.
ac.uk/sites/default/ﬁles/2021-11/wmml_turing_project_report_01_nov_21.pdf.
Frontiers in Pharmacology
frontiersin.org
08
Barrett et al.
10.3389/fphar.2023.1115356

## Page 9 (Section: Data availability statement)

ChEMBL (2023) chembl. Avaliable At: https://www.ebi.ac.uk/chembl/ (Accessed 9 3, 2023).
ChemicalX (2022). AstraZeneca. Available At: https://github.com/AstraZeneca/
chemicalx.
DeepChem (2022). deepchem. Avaliable At: https://deepchem.io/about.html
(Accessed 12 22, 2022).
Drug Bank (2023) Drug Bank online, Avaliable At: https://go.drugbank.com/
(Accessed 9 3, 2023).
European Centre for Disease Prevention and Control Press Release (2022).
Tuberculosis remains one of the deadliest infectious diseases worldwide, warns new
report. Avaliable At: https://www.ecdc.europa.eu/en/news-events/tuberculosis-
remains-one-deadliest-infectious-diseases-worldwide-warns-new-report.
Git-Scm (2023). git-scm. Avaliable At: https://git-scm.com/ (accessed 9 3, 2023).
GitHub (2023) GitHub. Avaliable At: https://github.com/ (accessed 9 3, 2023).
Graham, M., Milne, R., Fitzsimmons, P., and Sheehan, M. (2022). Trust and the
goldacre review: Why trusted research environments are not about trust. J. Med. Ethics
23, 108435. doi:10.1136/jme-2022-108435
Huang, K., Fu, T., Gao, W., Zhao, Y., Roohani, Y. H., Leskovec, J., et al. (2022).
Therapeutics data commons: Machine learning datasets and tasks for drug discovery
and development, Available At: https://arxiv.org/abs/2102.09548 (last accessed 12 2,
2022).
Jamasb, A. R., Viñas, R., Ma, E. J., Harris, C., Huang, K., Hall, D., et al. (2020)
Graphein - a Python library for geometric deep learning and network analysis on
protein structures and interaction networks. bioRxiv. doi:10.1101/2020.07.15.204701
Jordan, D. (2014). An overview of the Common Technical Document (CTD)
regulatory
dossier.
Med.
Writ.
23
(2),
101–105.
doi:10.1179/2047480614Z.
000000000207
Larkindale, J., Betourne, A., Borens, A., Boulanger, V., Theurer Crider, V., Gavin, P.,
et al. (2022). Innovations in therapy development for rare diseases through the rare
disease cures accelerator-data and analytics platform. Ther. Innov. Regul. Sci. 56,
768–776. doi:10.1007/s43441-022-00408-x
Larkins-Ford, J., Degefu, Y. N., Van, N., Sokolov, A., and Aldridge, B. B. (2022).
Design principles to assemble drug combinations for effective tuberculosis therapy
using interpretable pairwise drug response measurements. Cell. Rep. Med. 3 (9), 100737.
doi:10.1016/j.xcrm.2022.100737
Lexis Nexis Report (2020). AI in academia: How the need for future data scientists &
the availability of big data is transforming universities. Avaliable At: https://www.
lexisnexis.com/community/insights/professional/b/industry-insights/posts/ai-in-
academia.
Liu, Q., Huang, R., Hsieh, J., Zhu, H., Tiwari, M., Liu, G., et al. (2023). Landscape
analysis of the application of artiﬁcial intelligence and machine learning in regulatory
submissions for drug development from 2016 to 2021. Clin. Pharmacol. Ther. 771–774.
doi:10.1002/cpt.2668
Liu, Q., Zhu, H., Liu, C., Jean, D., Huang, S-M., ElZarrad, M. K., et al. (2020).
Application of machine learning in drug development and regulation: Current status
and future potential, Clin. Pharmacol. Ther. 107 (4), 726–729. doi:10.1002/cpt.
17711002/cpt.1771
Liu, Z., Roberts, R. A., Lal-Nag, M., Chen, X., Huang, R., and Tong, W. (2021). AI-
based language models powering drug discovery and development. Drug Discov. Today
26 (11), 2593–2607. doi:10.1016/j.drudis.2021.06.009
Maharao, N., Antontsev, V., Wright, M., and Varshney, J. (2020). Entering the era of
computationally driven drug development. Drug Metab. Rev. 52 (2), 283–298. doi:10.
1080/03602532.2020.1726944
Minnich, A. J., McLoughlin, K., Tse, M., Deng, J., Weber, A., Murad, N., et al. (2020).
Ampl: A data-driven modeling pipeline for drug discovery. J. Chem. Inf. Model. 60,
1955–1968. doi:10.1021/acs.jcim.9b01053
Paul, D., Sanap, G., Shenoy, S., Kalyane, D., Kalia, K., and Tekade, R. K. (2021).
Artiﬁcial intelligence in drug discovery and development. Drug Discov. Today 26 (1),
80–93. doi:10.1016/j.drudis.2020.10.010
Paullada, A., Raji, I. D., Bender, E. M., Denton, E., and Hanna, A. (2021). Data and its
(dis)contents: A survey of dataset development and use in machine learning research.
Patterns (N Y) 2 (11), 100336. doi:10.1016/j.patter.2021.100336
PubChem (2023). Pubchem. Avaliable At: https://pubchem.ncbi.nlm.nih.gov/
(Accessed 9 3, 2023).
Ross, J., Waldstreicher, J., Bamford, S., Berlin, J. A., Childers, K., Desai, N. R., et al.
(2018). Overview and experience of the YODA Project with clinical trial data sharing
after 5 years. Sci. Data 5, 180268. doi:10.1038/sdata.2018.268
Rozemberczki, B., Hoyt, C. T., Gogleva, A., Grabowski, P., Karis, K., Lamov, A., et al.
(2022). ChemicalX: A deep learning library for drug pair scoring. arXiv preprint arXiv:
2202.05240.
Schauperl, M., and Denny, R. A. (2022). AI-based protein structure prediction in drug
discovery: Impacts and challenges. J. Chem. Inf. Model. 62 (13), 3142–3156. doi:10.1021/
acs.jcim.2c00026
Terreni, M., Taccani, M., and Pregnolato, M. (2021). New antibiotics for multidrug-
resistant bacterial strains: Latest research developments and future perspectives.
Molecules 26 (9), 2671. doi:10.3390/molecules26092671
Wu, Z., Ramsundar, B., Feinberg, E. N., Gomes, J., Geniesse, C., Pappu, A. S., et al.
(2018). MoleculeNet: A benchmark for molecular machine learning. Chem. Sci. 9,
513–530. doi:10.1039/c7sc02664a
Zariffa, N., Haggstrom, J., and Rockhold, F. (2021). Open science to address COVID-
19: Sharing data to make our research investment go further. Ther. Innov. Regul. Sci. 55
(3), 558–560. doi:10.1007/s43441-020-00250-z
Zhu, Z., Shi, C., Zhang, Z., Liu, S., Xu, M., Yuan, X., et al. (2022). TorchDrug: A powerful
and ﬂexible machine learning platform for drug discovery. arXiv preprint arXiv:2202.08320.
Avaliable At: https://arxiv.org/pdf/2202.08320.pdf (last accessed 12 2, 2022).
Frontiers in Pharmacology
frontiersin.org
09
Barrett et al.
10.3389/fphar.2023.1115356


---

# DoubleSG-DTA: Deep Learning for Drug Discovery: Case Study on the Non-Small Cell Lung Cancer with EGFRT790M Mutation

- **Authors:** Yongtao Qian, Wanxing Ni, Xingxing Xianyu, Liang Tao, Qin Wang
- **Issuer:** Pharmaceutics
- **Type:** Scientific article
- **Published:** 2023-02-16
- **Language:** en
- **DOI:** 10.3390/pharmaceutics15020675
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36839996/
- **Licence:** CC-BY

## Section: Abstract

Drug–targeted therapies are promising approaches to treating tumors, and research on receptor–ligand interactions for discovering high-affinity targeted drugs has been accelerating drug development. This study presents a mechanism-driven deep learning-based computational model to learn double drug sequences, protein sequences, and drug graphs to project drug–target affinities (DTAs), which was termed the DoubleSG-DTA. We deployed lightweight graph isomorphism networks to aggregate drug graph representations and discriminate between molecular structures, and stacked multilayer squeeze-and-excitation networks to selectively enhance spatial features of drug and protein sequences. What is more, cross-multi-head attentions were constructed to further model the non-covalent molecular docking behavior. The multiple cross-validation experimental evaluations on various datasets indicated that DoubleSG-DTA consistently outperformed all previously reported works. To showcase the value of DoubleSG-DTA, we applied it to generate promising hit compounds of Non-Small Cell Lung Cancer harboring EGFRT790M mutation from natural products, which were consistent with reported laboratory studies. Afterward, we further investigated the interpretability of the graph-based “black box” model and highlighted the active structures that contributed the most. DoubleSG-DTA thus provides a powerful and interpretable framework that extrapolates for potential chemicals to modulate the systemic response to disease.

## Section: 1. Introduction

Clinically acquired resistance is an insurmountable dilemma for small-molecule kinase inhibitors to treat cancer [1]. Nevertheless, locating small-molecule ligands with high affinity and good properties for target proteins in a broad chemical space has been a primary challenge in drug research and development (R&D) [2]. To date, it cannot be overstated to describe the kinase drugs approved by The U.S. Food and Drug Administration (FDA) to overcome clinical resistance driven by protein kinase “gatekeeper” mutation as “desert oasis”. Lung cancer is the leading cause of cancer-related deaths worldwide, with non-small cell lung cancer (NSCLC) being the most common type of lung cancer. Secondary epidermal growth factor receptor (EGFR) mutations in threonine 790 (T790M) lead to acquired resistance which severely affects patient prognosis. Therefore, strategies or drugs to overcome resistance are urgent to prolong the survival of patients with NSCLC.

Laborious wet labs and high-throughput screening techniques are so time-consuming and challenging that they are unsuitable for screening candidate drugs from a broad range of compound groups in pre-drug R&D. With improvements in machine learning theory and an abundance of pharmacological data available, machine learning provides sufficient power for the development of precision medicine and artificially intelligent drug design (AIDD). Many encouraging scientific achievements have convincingly demonstrated the potential of these approaches. For instance, the knowledge graph (KG) enables to detect of the drivers of tumor resistance and adverse drug reactions in a wider multi-omics space [3,4]; reinforcement learning (RL) has been found to be particularly effective in the de novo design and multi-objective optimization of drug molecules [5,6,7]. Deep learning is a powerful data-driven algorithm in machine learning, which offers significant advantages to reveal implicit relationships between drugs, diseases, and genes that are not easily detected, owing to the powerful generalization and representation extraction capability. Some in silico methods that explore potential drug–target associations to advance drug R&D have been developed to narrow the research concentration areas toward the more workable drugs.

Some studies have viewed DTA prediction as a binary classification task, borrowing binary numbers (1/0) to label whether the two are combined [8,9,10], while some others treat it as a regression task and use floating-point numbers to indicate DTAs [11,12,13].

The random forest (RF) algorithm broke the previous methods of relying on multi-parameter scoring functions to infer DTA [14], which has proven to be convincing for extrapolating drug–target relationships in larger chemical spaces. KronRLS [15] and SimBoost [12] were regression-based machine-learning approaches that evaluated similarities between drugs and proteins to determine DTA. Various excellent deep-learning works have been presented. DeepDTA [8] and Attention-DTA [16] leveraged the convolutional neural networks (CNNs) to obtain the hidden relationships of atomic and amino acid sequences. DeepCDA incorporated the long- to short-term memory network which aims to alleviate the phenomenon of gradient disappearance and gradient explosion [17]. MATT-DTI deployed relation-aware self-attention with position embedding to reinforce relative positional associations among atoms [13]. Transformer-based works have come to the fore in various natural language processing (NLP) tasks. DMIL-PPDTA utilized the transformer encoder to enrich word embeddings of drug and protein sequences, aiming to learn hidden associations from the raw data [18]. DeepAtom [19] extrapolated node-level interaction information relevant to binding from the voxelized protein–compound complex structures. Nevertheless, these models rely on known 3D drug–target complexes, and the computational burden of complex 3D convolutional networks to extract the features of massive complexes is expensive. GraphDTA [11] and MGraphDTA [20] represented compounds as topological graphs and evaluated several types of Graph Neural Network (GNN) variants, including Graph Convolutional Network (GCN) [21], Graph Isomorphism Network (GIN) [22], and the Graph Attention Network (GAT) [23], with the aim of replacing CNN and achieving excellent performance. Additionally, DGraphDTA encoded both drugs and proteins into the graphs for inferring DTA by GNN [24]. Among those graph-based methods, they not only effectively avoid the drawbacks of few complex samples and high computational cost, but compensate for the problem of inadequate SMILES (Simplified Molecular Input Line Entry System) [25] for drug representation, and the molecule graph is closer to the natural description of compounds.

Although these methods produce excellent prediction results, they are difficult to generalize to real-world problems. Firstly, the molecular similarity principle [26] states that molecules with similar structures usually show similar biological activities and physicochemical properties; conversely, there are significant differences. Therefore, the model must discriminate between molecular structures over a wide chemical space. Moreover, modeling underlying complicated mapping patterns between compounds and proteins simply concatenate, which deviates from the non-covalent interaction between the receptor and ligand. More importantly, these approaches have limited interpretability as a result of the “black-box” property of graph neural networks. Considering that the false-positive statistics generated by the binary classification task directly impair the robustness of the model, here, predicting DTA was regarded as a regression problem. We propose a three-channel DoubleSG-DTA theoretical framework based on GINs and multiple attention mechanisms to address the aforementioned problems, which significantly outshines other regression-based SOTA methods on various benchmark datasets. Afterward, we visualize the gradient of atomic contributions in graph representations and compare them with the molecular docking poses to further extend the interpretability of the graph-based model.

This paper presents the main contributions as follows:DoubleSG-DTA combined graph isomorphism networks and the squeeze-and-excitation networks to extract multimodal representations of drugs in parallel, aiming to enhance the model to discriminate between compound structures and selectively suppress redundant information to disturb model decisions.The design of cross-multi-head attention mechanisms to model the reality-based non-covalent molecular docking behavior of drug substructures and subsequences with target proteins, respectively;Application of the DoubleSG-DTA to screen promising hit compounds of the NSCLC harboring EGFRT790M mutation from natural products, which have been consistent with reported laboratory studies.

## Section: 2. Double Sequence and Graph to Predict Drug–Target Affinity (DoubleSG-DTA)

This work developed the DoubleSG-DTA model with three-channel multimodal representations, four-channel interaction, and one-channel output for DTA prediction, which deployed multilayer GINs and multiple attention blocks, as shown in Figure 1. Primarily, we took the drug graphs and SMILES as inputs into the drug representation learning models. Multilayer GINs [22] and squeeze-and-excitation networks (SENets) [27] are jointly used as feature extractors for drugs. Additionally, the protein representation learning model captures the dominant feature of the over-redundant protein sequences that are highly dependent on stacked SENets. Moreover, to further encode the drug–target mutual interaction information, we designed cross-multi-head attention to model the reality-based non-covalent molecular docking behavior of drug substructures and subsequences with target proteins, respectively. Ultimately, we decoupled the attention coefficients into the Multilayer Perceptrons (MLPs) to predict DTA. This section presents the building blocks of our framework in order.

## Section: 2. Double Sequence and Graph to Predict Drug–Target Affinity (DoubleSG-DTA) › 2.1. Word Embedding and Graph Encoding

Initially, we utilized high-dimensional word embeddings to uniquely encode drug and protein sequences. To this aim, we built label/integer dictionaries for drug SMILES and protein FASTA sequences, which consist of 64 and 22 key-value pairs, respectively. For example, the SMILES of Propylene glycol “CC(O)CO” and the EGFRT790M [28] protein subsequence “NWCVQIA” are encoded as [2222433312233] and [14212221581] according to the SMILES dictionary {‘C’:22, ‘N’:34, ‘O’:33, ‘(’:4, ‘)’:3} and the protein dictionary {‘A’:1, ‘N’:14, ‘C’:2, ‘Q’:15, ‘I’:8, ‘V’:22, ‘W’:21}. We then map each integer vector into word embeddings De∈Rld×le and Pe∈Rlp×le by embedding layers. Where ld and lp denote the size of the SMILES and protein FASTA sequence, le represents the embedding dimensions.

We convert SMILES to their corresponding molecular graphs G=V,E and extract atom features by RDKit [29], where E and V are the sets of edges and atoms, respectively. Each atom node in a drug is represented by a multi-dimension vector of 10 molecular descriptors (atom symbol, atom number, hybridization, number of adjacent atoms, chirality, formal charge, aromaticity, number of bonded hydrogens, and explicit and implicit valence).

## Section: 2. Double Sequence and Graph to Predict Drug–Target Affinity (DoubleSG-DTA) › 2.2. Drug and Protein Sequence Representation Learning Model

The CNNs construct text features by fusing spatial correlations between features that benefit from the convolutional kernel’s local receptive field but are likewise limited by it. In computer vision, the squeeze-and-excitation (SE) block with channel attention was integrated into existing architectures, which adaptively rescales channel-wise feature weights by explicitly modeling non-mutually-exclusive relationships between channels [27]. The research has confirmed that the SENets achieved superior performance for image classification with a slight increase in computational cost [27]. Accordingly, we stacked multilayer SENets designed to selectively enhance effective statistics and suppress noise to disturb model decisions. Given U∈RH×W×C as the feature matrix of the convolution layer output, we routed it to the SE block, where U=[u1,u2,⋯,uC].

SE module makes use of squeeze, excitation, and reweighting operators. The squeeze operator intrinsically aims to transform the dimensions of the feature matrix U and obtain channel-wise statistics z∈RC by applying the global average pooling operation. (1)zc=Fsq(uc)=1H×W∑i=1H∑j=1Wuc(i,j).

The excitation module leverages two learnable FCNs with the gating mechanism to learn inter-channel non-linear interaction and filter non-dominant features. (2)s=Fex(Z,W)=σW2δ(W1z), where the δ is the Rectified Linear Unit (ReLU) activation function, and σ is the sigmoid function, and W1∈RCr×C and W2∈RC×Cr are the two learnable weight matrices. The reduction ratio was set to r = 16 to reconcile the balance between performance and complexity [27].

The reweighting representation xc was computed by applying the channel-wise multiplication operation to the channel attention weight sc and the feature map uc. (3)xc=Fsc(uc,sc)=sc×uc. where X=x1,x2,……xC, xc∈RH×W.

The word embeddings De and Pe are directly fed into the convolutional layers, then delivered to the SE block accompanied by a global max pooling operation to calculate desired feature information. Hence, the drug and protein sequence representations can be expressed as:(4)DSENet=gmpSECNNDePSENet=gmpSECNNPe.

## Section: 2. Double Sequence and Graph to Predict Drug–Target Affinity (DoubleSG-DTA) › 2.3. Drug Graph Representation Learning Model

Drug molecules are non-Euclidean chemical structures that consist of entities (atoms) and relations (bonds) with rich semantic information and complex spatial structures. This is essential for accurately discriminating between drug molecules and precisely predicting the binding affinity of different compound molecules with proteins. Nevertheless, that is beyond the reach of traditional GNNs.

Meanwhile, we take into account that drugs with similar substructures may react pharmacologically with target proteins with the same or similar protein binding pockets. Interestingly, graph isomorphism networks [22] with injectivity broadly follow a flexible message-passing scheme that enables atoms to recursively update semantic information through aggregating near and far neighboring atomic features. A sufficient number of iterations allows the GIN to be perfectly equipped with the most powerful ability to “read-out” drug graph representations and identify drug molecules.

GIN updates atom feature vectors via the MLPs, ensuring that GIN still satisfies injectivity after K-iterations of aggregation. The graph representation is obtained by summing all of the atom feature vectors in the drug. Formally, the kernel function of GINs updates atom feature vector Dvk, and the drug graph representation DGIN is:(5)Dvk=MLPk1+εk·Dvk−1+∑i∈NvDik−1DGIN=CONCATREADOUTDvk|v∈G, where Nv is a set of nodes adjacent to atom i. The READOUT function is a graph-level pooling function. We made ε a learnable parameter.

The successful construction of deep GINs is highly dependent on the ReLU activation function and batch normalization, while batch normalization can effectively alleviate the vanishing gradient and over-smoothing problems. (6)GIN(l+1)G=BNLayerGINlGDGIN=DropoutδGINnG,W where BNLayer denotes node-level batch normalization.

## Section: 2. Double Sequence and Graph to Predict Drug–Target Affinity (DoubleSG-DTA) › 2.4. Drug Molecule and Target Protein Interaction Model

Drug molecules binding to target proteins is actually an identification relationship similar to the “lock and key” model. Inspired by previous attention-based methods [13,17,30], we constructed two cross-multi-head attention modules to model non-covalent molecular docking behavior between compounds and proteins, instead of simply connecting drug and protein representations that inherently generates more intrusive information. Concretely, we observed the associations among molecules’ substructures, subsequences, and residues from multiple independent perspectives. The cross-multi-head attention blocks take the drug and protein sequences feature matrices DSENet∈Rld×lc and PSENet∈Rlp×lc of SENets, and the drug graph-level representation DGIN∈Rld×lg of the GIN as inputs, respectively.

In the following paragraphs, we construct learnable linear transition layers so that each head can fully learn from the high-dimensional features. Afterward, we combine DSENet, DGIN with PSENet by adopting the cross-multi-head attention mechanism. (7)Qs=δ(DSENetWsenet+bsenet),Qg=δ(DGINWgin+bgin)K=δ(PSENetWsenet+bsenet),V=δ(PSENetWsenet+bsenet) where Wsenet∈Rlc×la, Wgin∈Rlg×la, and bsenet, bgin are the learnable weights and bias terms, respectively. Q, K, and V represent queries, keys, and values vectors. An individual scaled dot–product attention module was expressed as mapping the Q with K-V pairs to the similarity matrix. Multi-head attention jointly concerned different representation subspaces at distinct positions by concatenating h individual attention units [31].

We obtained one of the cross-multi-head attention weight ADP1 as follows:(8)Attention(Qs,K,V)=SoftmaxQsKTlc/h·V (9)headi=Attention(QsWiQ,KWiK,VWiV)ADP1=Concat[head1,…,headh]WO where WiQ, WiK, WiV, and WO are parameter matrices for learning linear projections. Next, another cross-multi-head attention coefficient ADP2 was computed as:(10)Attention(Qg,K,V)=SoftmaxQgKTlg/h·V (11)headj=Attention(QgWjQ,KWjK,VWjV)ADP2=Concat[head1,…,headh]WO

Afterward, we decoupled the attention weight ADP to obtain drug attention weight αd and protein attention weight αp by applying row-wise sum and column-wise sum operations. We updated the drug representation αD and protein representation αP. (12)ADP=Concat[ADP1,ADP2] (13)αD=Concat[αd⊙Dsenet,αd⊙Dgin],αP=αp⊙Psenet where ⊙ is an element-wise product. The drug–target interaction weight Idp can be interpreted as modeling the significant semantic correlations between target proteins and compound features. (14)Idp=gapConcatgmpαD,gmpαP where gap is the global average pooling operation.

## Section: 2. Double Sequence and Graph to Predict Drug–Target Affinity (DoubleSG-DTA) › 2.5. Drug and Target Protein Binding Affinity Prediction

Finally, interaction information Idp was fed directly into MLPs to map the drug–target affinity score. Here, this MLPs consists of four layers, each followed by a ReLU and dropout layer, which are applied to alleviate the model from over-fitting. (15)DTA=MLP(Idp).

## Section: 3. Materials and Methods › 3.1. Benchmark Datasets

This research assessed the DoubleSG-DTA with three benchmark datasets: Davis [32], KIBA [33], and BindingDB [34] datasets. The statistics of the Davis, KIBA, and BindingDB datasets and split strategy have been listed in Table 1. (16)pKd=−log10Kd1×109

The Davis dataset was highly biased and discrete. We converted the Kd values into log space according to Equation (16) [8], and the KIBA dataset comprises KIBA scores for about 118 K protein–compound interactions, and KIBA scores were derived from different bioactivity measures, such as Ki, Kd, or IC50. The BindingDB dataset collects binding affinities for small molecule drugs and target proteins for public access.

## Section: 3. Materials and Methods › 3.2. Evaluation Metrics

To ensure consistency and a fair comparison, we applied the Concordance index (CI, ↑), Mean Square Error (MSE, ↓), and Regression toward the mean (rm2 index, ↑) as performance metrics following previous studies [8,11,13] to assess the model.

MSE: The MSE metric was commonly used to measure the difference between the ground truths and the predicted values, and minimizing the MSE was the main training objective.

CI: The CI metric was introduced to measure the probability of the concordance between the ground truths and the predicted values. CI values range between 0.50 and 1.0, with values less than 0.7 indicating less convincing model prediction, 0.71 to 0.90 indicating moderate prediction accuracy, and more than 0.9 indicating reliable predictions.

rm2: The rm2 metric was extensively adopted to evaluate the external predictive performance of regression-based models, and an acceptable model has a rm2 value greater than 0.5. (17)MSE=1N∑i=1NDTAi−Labeli2

DTAi and Labeli mean the predictive value and the ground truth, respectively. (18)CI=1Z∑δi>δjζDTAmax−DTAmin

DTAmax and DTAmin represent the predictive values of the highest affinity δi and the lowest affinity δj. ζ(x) expresses the step function [15], where ζx=1,x>0;0.5,x=0;0,x<0;, Z is a normalization constant. (19)rm2=r2×(1−r2−r02).

Generally, an acceptable model has a rm2 value greater than 0.5, where the r02 and r2 designate squared correlation coefficients of interception or not.

More importantly, the Pearson correlation coefficient was employed to measure the linear correlation between the ground truths and predicted values. The Pearson correlation coefficient can be calculated as follows. (20)PearsonDTA,Label=CovDTA,LabelσDTAσLabel, where Cov means co-variance, and σ represents the standard deviation.

## Section: 3. Materials and Methods › 3.3. Hyperparameter Settings

Experiments were conducted with an NVIDIA RTX A5000 GPU. We adopted five-fold cross-validation to evaluate the quality of previously reported works and DoubleSG-DTA model, Table 2 gives the hyperparameter settings in experiments.

## Section: 3. Materials and Methods › 3.4. Baselines

In this part, we conducted experiments applying the MSE(↓), CI(↑), and rm2(↑) to assess the DoubleSG-DTA method and previous studies on the above three benchmark datasets, including DeepDTA [8], GraphDTA [11], MATT-DTI [13], AttentionDTA [16], DeepCDA [17], and DMIL-PPDTA [18]. Besides, we also benchmarked our work against proteochemometrics methods [35], including the support vector machine (SVM), feedforward neural network (FNN), SimBoost [12], Random Forest (RF) [14], and KronRLS [15].

## Section: 4. Results and Discussion › 4.1. Comparison against Baselines in Regression Tasks

Table 3, Table 4 and Table 5 summarize the quantitative results of the DoubeSG-DTA and previously studied models on the benchmark datasets. Obviously, DoubleSG-DTA achieved significantly superior performances to other regression-based methods on various datasets.

Considering the Davis dataset, the MSE metric of the DoubleSG-DTA model was 0.219, 0.004 lower than the best DMIL-PPDTA [18] model in the sequence-based models, and the CI and rm2 metrics of our model were 0.902 and 0.725, 0.009 and 0.04 higher than FNN [20] model in the sequence-based models, respectively. When comparing with the best GraphDTA [11] model in the graph-based models, the CI value was increased by 0.009 and the MSE value was decreased by 4.37%.

Considering the KIBA dataset, the MSE and rm2 metric of the DoubleSG-DTA model were 0.138 and 0.787, 6.12% lower and 0.003 higher than the best DMIL-PPDTA [18] model in the sequence-based models, and the CI metrics of our model were 0.896, 0.007 higher than the MATT-DTI [13] model in the sequence-based models, respectively. When compared with the best GraphDTA [11] model in the graph-based models, the CI value was increased by 0.005 and the MSE value was decreased by 0.001.

Considering the BindingDB dataset, the MSE metric of the DoubleSG-DTA model was 0.533, 11.61% lower than the best AttentionDTA [16] model in the sequence-based models, and the CI and rm2 metrics were 0.862 and 0.726, which were 0.01 and 0.039 higher than it, respectively. When compared with the best GraphDTA [11] model in the graph-based models, the CI and rm2 metrics were increased by 0.005 and 0.023, respectively, and the MSE metric was decreased by 4.31%.

Figure 2 presents that the predictive values and ground truths show approximately overlapping distribution trends in the KIBA, Davis, and BindingDB datasets. In addition, using the Pearson correlation enabled us to make an unbiased assessment for DoubleSG-DTA that is optimized for MSE. In particular, our model achieved even better Pearson correlations of 0.852, 0.894, and 0.867 in the three benchmark datasets, respectively.

These results indicate that the powerful graph isomorphism networks, coupled with the lightweight squeeze-and-excitation networks enable the DoubleSG-DTA to perform exceptionally well under the support of cross-multi-head attention.

## Section: 4. Results and Discussion › 4.2. Ablation Study 1: The Effect of Graph Isomorphism Network Layers on Model Performance

Extracting drug representations highly relies on the graph computational capability of GIN. We conducted an ablation experiment to investigate the contribution of graph isomorphism network depth on prediction performance. It can be seen from Figure 3 that the DoubleSG-DTA outperforms all other settings when the count of layers of GINs L∈4,5, and the CI and rm2 metrics of the DoubleSG-DTA model tend to decrease as the number of GIN layers increases, and the MSE metric of the main objective of DoubleSG-DTA training increases sharply. GIN performs a weighted average of its own features and near and far neighboring node features to update the node’s new features, with the aim of capturing graph representations and discriminating between graph structures. However, increasing the number of layers infinitely will cause the feature vectors of nodes within the same cluster to gradually converge to similarity, which may lead to node-wise over-smoothing and impair model decision-making performance [36]. Therefore, the appropriate depth of GIN facilitates obtaining drug graph representations, while stacking a collection of GIN layers may cause over-smoothing and vanishing gradients problems.

## Section: 4. Results and Discussion › 4.3. Ablation Study 2: The Effect of Se Block on Model Performance

This work forgoes the CNNs used in previous studies [8,13,16,17] as the feature extractor but instead creates multilayer squeeze-and-excitation networks to construct textual features of drug and amino acid sequences, which was compared with a CNN-based method. As shown in Table 6, although the multilayer SE modules with channel attention were embedded into the DoubleSG-DTA model that caused the model parameters to rise and also caused higher model complexity, there was no significant increase in the training time of the model on the three benchmark datasets. Therefore, controlled experiments demonstrated that the DoubleSG-DTA model with SENet blocks (DoubleSG-DTA + SENet) achieves considerable improvements at a slightly additional computational burden than the models without it (DoubleSG-DTA + CNN). Overall, our findings suggest that SENets significantly reduce the model’s error rate, which benefits from inter-channel attention.

## Section: 4. Results and Discussion › 4.4. Ablation Study 3: Interaction Learning with Cross-Multi-Head Attention Mechanism

Ultimately, this study investigated the impact of the cross-multi-head attention mechanism modeling the reality-based molecular docking behavior of drug molecules and target proteins, and compared it against the method of concatenating both. As shown in Table 7, the MSE index of the DoubleSG-DTA model with cross-multi-head attention decreased by 9.50%, 10.39%, and 3.79% compared to the latter in the Davis, KIBA, and BindingDB datasets, respectively. Besides, the rm2 index increased by 0.012, 0.014, and 0.024. Overall, after using the cross-multi-head attention mechanism, the complete DoubleSG-DTA model led to more considerable improvements.

## Section: 5. Case Study on the NSCLC with EGFRT790M Mutation

According to the statistics of cancer data in 2021 [37], lung cancer mortality increased to around 46% of total cancer mortality, among which NSCLC accounted for approximately 85% of lung malignancies. Patients with NSCLC are normally accompanied by epidermal growth factor receptor (EGFR) mutations [38], which brings great challenges to the treatment of NSCLC. In recent years, the remarkable achievements of small-molecule EGFR tyrosine kinase inhibitors (EGFR-TKIs) in targeted therapy have brought light to NSCLC patients. First-generation EGFR-TKIs (Gefitinib and Erlotinib) and second-generation EGFR-TKI (Afatinib) significantly improved the prognosis of advanced NSCLC patients compared to platinum-based chemotherapy. Unfortunately, the majority of patients develop EGFRT790M mutation, resulting in severe resistance symptoms [39]. Inevitably, despite the high selectivity of the third-generation EGFR-TKI (Osimertinib) targeting NSCLC harboring EGFRT790M mutation, patients develop secondary resistance [40].

Natural products continue to be a precious source of templates with structural complexity and numerous pharmacophores in drug R&D, especially effective in cancer. For instance, paclitaxel [41] and vincristine [42] have been widely invested in the clinical treatment of tumors. In this section, we preferred to screen high-affinity and good properties targeted inhibitors of NSCLC with EGFRT790M mutation from natural products. We hope our results may provide clues for medical scientists to develop highly selective natural drugs.

For the above purpose, we acquired the FASTA sequence of mutant protein EGFRT790M (PDB ID:2JIT [28]) from the Protein Data Bank [43] and collected 2645 natural compounds from Selleck Chemicals https://www.selleck.cn/ (accessed on 4 January 2023), which are easily optimized for good human oral bioavailability (OB > 40%) and drug-likeness (DL > 0.18) [44,45]. Table 8 provides information on the top 10 natural products predicted by DoubleSG-DTA, which have the highest affinity to the EGFRT790M mutant protein.

Then, we carried out a comprehensive literature survey on the top 10 natural products. Based on the study [46], gossypol not only significantly increased the sensitivity to EGFR-TKIs in H1975 cells carrying EGFRL858R/T790M, but inhibited cell proliferation and induced apoptosis. The Gö6976 is derived from Staurosporine, experimental confirmation that Gö6976 (at 500 nanomolar) exhibits significant binding affinity for EGFRT790M mutants, while it shows a significantly lower affinity for wild-type EGFR [47]. The research results indicate that Shikonin has selective cytotoxic effects on gefitinib-resistant NSCLC cell lines carrying EGFRT790M mutation, while relatively safe to normal lung cells [48]. Gossypol acetic acid significantly enhances sensitized lung cancer cells carrying EGFRL858R/T790M mutation to gefitinib and overcomes EGFR-TKIs resistance [49,50]. According to the above-mentioned report, such natural products may be promising strategies to combat resistance in NSCLC harboring EGFRT790M mutation.

Docking information of the top 10 natural products with the highest affinity.

## Section: 6. Molecular Docking and Biological Interpretation

To further validate such new interactions, computational docking was performed via AutoDock [51]. As shown in Figure 4, we employed the most efficient, reliable, and successful Lamarckian genetic algorithm in Autodock to perform an adaptive global–local search for the lowest-energy ligand–receptor docked conformation, and predicted the binding free energy via an empirical binding free energy force field [52]. The ligand–receptor binding energy includes electrostatic interactions, hydrogen bonding, van der Waals forces and hydrophobic interactions, and so forth, and the structural stability is negatively correlated with the binding energy value. Furthermore, an acceptable molecular docking conformation that has a binding energy of less than −5.0208 KJ/mol. Drug molecule ligands interact stably with target proteins in the above manner, aiming to exert a variety of biological activities such as anti-inflammatory and anti-tumor activities of the drug molecules, and to stimulate the physiological and pharmacological functions of the protein. As shown in Figure 4 and Table 8, the docking indicates that the top 10 natural compounds can be stably docked to the EGFRT790M protein by generating multiple hydrogen bonds.

Graph neural networks have always been criticized because of their poor interpretability, and these models are commonly thought of as “black boxes”. In this work, inspired by Grad-AAM [20] and Grad-CAM [53], which employed the gradient-weighted class activation mapping method, the regions of graph structure that contribute most to the prediction results are visualized as heatmaps, enhancing the interpretability of deep learning-based network models processing graph data.

Since the last layer of the GINs of DoubleSG-DTA incorporates the richest high-level semantic information, the drug graph representations are visualized to produce heatmaps depicting the atoms and functional groups that contribute most prominently to predicting DTA. We denote the feature map of the last graph convolution layer as F. In order to obtain the probability map P of atomic node v for a given drug molecule, we calculate the gradient of the predicted affinity DTA of the molecule binding to the target protein at the c-th channel of the feature map F and atomic node v. The gradient Wc has been calculated as follows. (21)Wc=1|V|∑v∈V∂DTA∂Fvc.

Next, a weighted combination of the data for each channel of the feature map F was performed, followed by the ReLU activation function. (22)P=δ∑cWcFc.

Finally, the gradient weights were scaled to the range of 0 to 1 using min–max normalization to obtain a probability map P of the weighted distribution of the drug molecules, which was further rendered into a heatmap.

As shown in Figure 4, the active structures in the heatmaps overlap with molecular docking sites by more than 77.14%, and the mathematical calculation formulation is given as Equation (23). Figure 4 explains that describing the drug molecules as graphs and learning the topological pattern structures of the drug molecules with an appropriate depth of GIN can accurately discriminate between drug molecular active structures. (23)overlaprate=1N∑i=1NPdrugPprotein, where N denotes the number of drugs, Pprotein stands for the number of molecular docking sites, and Pdrug is the number of atoms and functional groups that contributes the most and is identical to the molecular docking site.

## Section: 7. Conclusions

This investigation presented an interpretable deep learning-based computational model to project the affinity of drug–target pairs for aiding in drug discovery. The experimental results indicated that the simple yet powerful graph isomorphism networks coupled with the lightweight squeeze-and-excitation networks made the DoubleSG-DTA perform exceptionally well with the support of cross-multi-head attention compared with all previously reported works. Extensive experiments have revealed that (i) the most appropriate number of graph isomorphism network layers for extracting drug graph representations and discriminating between molecular structures is 4,5, (ii) the SE block with the soft attention mechanism selectively emphasized information features by expanding the perceptual field, significantly boosting the model’s decision making, and (iii) fully modeling the interaction between compounds and proteins facilitates further performance in predicting drug–target binding affinity. Ultimately, the well-established DoubleSG-DTA was applied to screen promising high-affinity compounds of Non-Small Cell Lung Cancer with EGFRT790M mutation from natural products to provide some clues for medical scientists. In addition, drug graph representations were visualized as heatmaps, in which the active structures that contributed the most covered almost all molecular docking sites, which may provide biological interpretation and entry points for later molecular optimization. Overall, DoubleSG-DTA may be an effective in silico drug discovery tool for medical challenges and urgent public health emergencies.


---

# Electronic health record data quality assessment and tools: a systematic review

- **Authors:** Abigail E Lewis, Nicole Weiskopf, Zachary B Abrams, Randi Foraker, Albert M Lai, Philip R O Payne, Aditi Gupta
- **Issuer:** Journal of the American Medical Informatics Association : JAMIA
- **Type:** Scientific article
- **Published:** 2023-09-25
- **Language:** en
- **DOI:** 10.1093/jamia/ocad120
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37390812/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractObjectiveWe extended a 2013 literature review on electronic health record (EHR) data quality assessment approaches and tools to determine recent improvements or changes in EHR data quality assessment methodologies.Materials and MethodsWe completed a systematic review of PubMed articles from 2013 to April 2023 that discussed the quality assessment of EHR data. We screened and reviewed papers for the dimensions and methods defined in the original 2013 manuscript. We categorized papers as data quality outcomes of interest, tools, or opinion pieces. We abstracted and defined additional themes and methods though an iterative review process.ResultsWe included 103 papers in the review, of which 73 were data quality outcomes of interest papers, 22 were tools, and 8 were opinion pieces. The most common dimension of data quality assessed was completeness, followed by correctness, concordance, plausibility, and currency. We abstracted conformance and bias as 2 additional dimensions of data quality and structural agreement as an additional methodology.DiscussionThere has been an increase in EHR data quality assessment publications since the original 2013 review. Consistent dimensions of EHR data quality continue to be assessed across applications. Despite consistent patterns of assessment, there still does not exist a standard approach for assessing EHR data quality.ConclusionGuidelines are needed for EHR data quality assessment to improve the efficiency, transparency, comparability, and interoperability of data quality assessment. These guidelines must be both scalable and flexible. Automation could be helpful in generalizing this process.Keywords: clinical research informatics, data quality, electronic health records

## Section: BACKGROUND

The usage of electronic health record (EHR) derived data in biomedical research has increased in recent years, and this trend is expected to continue as such technologies improve.1 The multitude of data available in EHRs make them well-suited for high-dimensional analyses, including phenotyping as well as machine learning and artificial intelligence approaches.2 Additionally, EHR data offer potential cost and time savings as an alternative to the primary collection of medical data for research purposes.3 The coronavirus disease 2019 (COVID-19) pandemic, for example, has highlighted the importance of using EHR data to uncover and monitor patterns in disease spread and severity.4,5 In addition to the potential benefits of using EHR data for research, however, there are also challenges, including EHR data quality concerns, timely access, patient protections and confidentiality, and the ability to generalize results based on EHR data.3,4,6

Best practices for assessing EHR data quality, despite their clear importance, remain an open question. There does not currently exist a standard approach to assessing EHR data quality and quality assessments are often ad hoc for a specific project. Some work has been done previously to consolidate data quality assessment (DQA) approaches. Prior to the broad adoption and usage of EHRs, Wang and Strong presented a conceptual framework of data quality.7 Although not specific to EHRs or medicine at all, their framework is still applicable in an EHR setting. Categories of data quality included in this framework are intrinsic data quality (data are objective and accurate), contextual data quality (quality is based on the context in which data were collected; data are relevant, timely, and complete), representational data quality (data are represented consistently and interpretable), and accessible data quality (data are accessible and securely managed).7 The data consumers who helped develop this model indicated accessibility and context as some of the most important facets of data quality. Working under this mindset, DQAs as they relate to EHR data should be defined on their own accord.

A 2013 review established 5 themes of EHR data quality and 7 methods by which to assess these dimensions.8 Dimensions included completeness (the presence of data in the EHR); correctness (the truthfulness of data in the EHR); concordance (the agreement between elements within the EHR and between the EHR and other data sources); plausibility (the extent to which EHR data make sense in a larger medical context); and currency (the accuracy of the EHR data for the time at which it was recorded and how up to date the data are). At the time, concordance and plausibility seemed likely to be proxies for accuracy or correctness. Often, plausibility was defined by the correctness of a value in the EHR or the believability of a distribution of values in light of other knowledge. In some cases, plausibility implied a value is possible in the given setting without asserting the correctness of the value which may be prone to some sort of recording error. Assessment methods included a gold standard comparison between the EHR data and another data set that is considered to be true; data element agreement: agreement between elements within the EHR; element presence of necessary data fields and observations in the EHR; data source agreement: agreement between the EHR and another data source not necessarily considered to be a gold standard; distribution comparison of EHR data distributions to clinical data source distributions; validity checking of EHR data; and log review: an examination of data entry practices. Although the definition of certain methods and dimensions are similar, dimensions represented an element of data quality while methods represented the process used to assess for dimensions. Additionally, individual methods could be used to assess multiple dimensions of data quality. In this case, the dimension being assessed was determined by the rationale for the chosen method.

Additional data quality frameworks have been proposed beyond the 2013 review. Kahn et al highlight conformance, completeness, and plausibility in their proposed DQA framework, which has been utilized by groups like the National Patient-Centered Clinical Research Network (PCORnet) and the All of Us research program to streamline DQA.9–11 Wang et al12 propose a rule-based system for assessing data quality. The Observational Health Data Sciences and Informatics (OHDSI) program has developed the Automated Characterization of Health Information at Largescale Longitudinal Evidence Systems (ACHILLES), a framework and tool, for assessing data conforming to the observational medical outcomes partnership (OMOP) common data model (CDM).13 Although not considered a universal tool, this tool can be openly accessed and used to assess the quality of data conforming to the OMOP structure. The utility of ACHILLES has been demonstrated in multiple settings for creating comparable DQAs.14 The National COVID Cohort Collaborative (N3C) uses a version of the OHDSI DQA approach to assess data quality after transforming data to the OMOP CDM.15 The dimensions and methods from the 2013 review and more recent attempts to standardize DQA, although consistently utilized across health-related research applications to describe data quality, still vary substantially in the ways they are recorded and discussed, indicating a lack of community agreement and adoption of such DQA frameworks and methods.

## Section: OBJECTIVE

To address this gap in knowledge, we aim to extend the 2013 literature review8 to understand how EHR DQA has changed in recent years. We propose 2 main extensions of the 2013 review: first, to expand the literature review on EHR DQA to present day to determine how DQA practices have changed since 2013, and second, to include a broader range of literature including developed DQA tools and opinion pieces in addition to papers that focus on a data quality measure as an outcome of interest.

## Section: MATERIALS AND METHODS

As we were extending the prior literature review, we closely followed the methods outlined by Weiskopf.8 Similarly, we aimed to identify articles which discussed the quality of EHR data specifically. In order to do this, we included the same terms as Weiskopf in our PubMed Query of titles and abstracts completed in September 2021:

This PubMed query resulted in a total of 593 articles. To select articles for review, we developed the inclusion and exclusion criteria in Table 1. We developed inclusion and exclusion criteria such that they identified original work related to DQA of EHR data. These articles were then sorted in descending order by their number of citations per year since being published and reviewed in order until selecting 90 articles, a similar number to the 2013 review.8 However, one of our goals was to capture both highly relevant articles and emergent literature. We first selected at least 10 articles from both 2020 and 2021 based on a descending sorting of number of citations per year before sorting and searching through the remainder of the query. We screened the abstracts of 253 papers and based inclusion on the criteria from Table 1. From here, we read 122 papers in full to determine inclusion which resulted in inclusion of a total of 90 papers in the review (Figure 1). We repeated the PubMed query in April 2023 to extend our search window through March 2023. An additional 84 articles were identified, of which 13 were included in the final collection based on meeting inclusion criteria (Table 1, Figure 1). Two authors (AEL, AG) developed inclusion and exclusion criteria to reduce bias during the screening process. A doctoral student (AEL) completed the screening and review analysis. A second author validated the selection of included papers and review analysis (AG).

For each included paper, we determined a paper category, the data quality dimensions assessed, and the methods used to assess the data quality dimensions. Paper categories included data quality outcomes of interest, tools, and opinion pieces. Data quality outcome of interest papers included original research using DQA methods. DQA tool papers included specific methodologies for assessing data quality or a set of definitions for understanding DQA, instructions for how to use them, and demonstration of the tool on one or more example datasets. Tool papers differed from data quality outcome of interest papers in that they are designed to be used on a general data set rather than a specific data set of interest. Opinion papers represented an amalgamation of DQA suggestions from experts in the field and differ from tools in that they do not include a tangible output and have not necessarily been tested.

We abstracted the presence of data quality dimensions as defined by Weiskopf8 from each paper along with the methods used to assess the dimensions based on the definitions provided in the introduction. In addition, we collected the type of data being analyzed, vocabulary used to describe data quality dimensions, and specific evaluation methods within the larger methodological groups. We then used an iterative process to abstract and define additional dimensions and methods in all pieces and themes occurring in tools and opinion pieces as these themes may differ from those defined in 2013. In order to abstract new dimensions and methods during the first round of review, we recorded dimensions of data quality and methods that did not fit into one of Weiskopf’s definitions. Commonly occurring topics were considered to be new dimensions, methods, or themes. Themes encompassed all concepts not considered to be a method or dimension of data quality. We created the minimum number of mutually exclusive themes which included all commonly occurring concepts. We then reviewed all papers a second time for data collection on the newly defined dimensions, methods, and themes. A list of papers and the collected data can be found in the Supplementary Materials.

Inclusion and exclusion criteria

Prisma diagram.16

## Section: RESULTS

Of the 103 papers included in the review, 73 were data quality outcome of interest papers, 22 were tools, and 8 were opinion pieces (Table 2). Ninety-nine papers discussed structured data, 25 papers discussed unstructured data, and 21 discussed both. Table 3 and Figure 2 show the types of methods used to assess each dimension.

Similar to 2013, the most commonly assessed dimension of data quality was completeness which was explored in 76 (74%) papers (Table 2). In the majority of cases, element presence was used to assess completeness (Table 3). When completeness was assessed by comparison to another data set within or external to the EHR, gold standard or otherwise, comparison data sets included within EHR agreement,17–23 an alternative data source,18,24,25 billing data,22 or physician agreement.19,22,26,27 Common terms used to describe completeness included missingness, presence, availability, breadth, and accuracy.

Again, the second most commonly addressed dimension of data quality was correctness which was assessed in 53 (51%) papers (Table 2). Data element agreement was the method most often used to assess correctness and was followed closely by a gold standard comparison and data source agreement (Table 3). Comparison data sets included other EHR data from the same system,18,28–37 manual review by a physician,19,22,33,38–50 billing data,22,51,52 unstructured data, or an external data source.18,25,53–62 Many terms were used to describe correctness including accuracy, validity, specificity, sensitivity, positive predictive value, and error.

Forty-six (45%) papers assessed concordance most often using data element agreement or data source agreement (Tables 2 and 3). Similar to correctness, comparison data sets included other EHR data from the same system,17,18,25,30,31,33,46,50,53,63–69 unstructured data,34,55,70–73 manual review by a physician,38,41,42,46,48,74–76 billing data,46,68,69,77–80 or an external data source.18,25,53,54,56,57,60,80–87 Common terms used to describe concordance were consistency, agreement, sensitivity, discrepancy, and correlation.

In contrast to 2013, currency was the fourth most commonly assessed dimension of data quality and was considered in 35 (34%) papers (Table 2). Currency was most often assessed using log review while data element agreement and distribution comparison were also utilized (Table 3). Common terms used to describe currency included timeliness, frequency, and accuracy. Finally, plausibility was assessed in 29 (28%) papers and was most often assessed by distribution comparison. Common terms used to describe plausibility included validity, truthfulness, extreme values, duplication, and believability.

In addition to the 5 dimensions of data quality identified by Weiskopf, we identified conformance and bias as further dimensions of data quality and structural agreement as a method by which to conduct DQA. Eighteen (17%) papers assessed conformance, or compliance with a predefined representational structure, almost exclusively using structural agreement (Tables 2 and 3). Here, we define structural agreement as agreement with predefined formatting constraints. In a majority of cases, conformance was described as conformance, consistency, or representation and implied the use of some predefined structure, value, or format. Structural agreement most often depended on the usage of a correct data type and unit if necessary.

Eleven (11%) papers assessed bias most commonly using data element agreement (Table 2). We define bias as a dimension of data quality as missingness not at random. For example, some authors identified the pattern that sicker patients have higher levels of data completeness which implies that exclusion based on complete records will select a biased sample in terms of patient health levels.31,77,88,89 Additionally, some authors highlighted the differences in data availability from structured versus unstructured data and suggested the bias resulting from using only one of the forms of EHR data.73,77 Differential recording of patient attributes by race also constituted an example of bias.72 Although sometimes similar to the dimension of completeness in considering missing data, it can be seen from these examples that the dimension of bias further examines missing data rates in the presence of other variables.

Dimensions of data quality

Dimensions of data quality and methods of assessment

Map comparing dimensions of data quality and methods used to assess dimensions of data quality. Dimensions are listed in the boxes on the left and methods are listed in the boxes on the right. The weight of an edge indicates the frequency of that combination. This figure presents an updated version of Figure 1 from the original review.8

## Section: RESULTS › Tools

Tools included in this review were often described as frameworks or ontologies for assessing EHR data quality. Eighteen of the 19 tools were built to assess structured data, while only 2 of the tools were built to assess unstructured data. Tools most often assessed completeness (86%), plausibility (50%), and correctness (45%), though currency, concordance, and conformance were also considered.

From the iterative review process, we established 4 themes in the tool development papers. The first theme addresses the task or project dependency of DQA.12,22,25,32,84,90–92 These tools provide a mechanism to adjust aspects of the DQA based on the project or use case at hand. However, this task dependence must be balanced with the second theme, which highlights the necessity for scalable tool development.11,12,22,32,85,91–96 These authors highlight the fact that consistent and comparable DQA requires identical approaches across domains. Due to the immense range of domain applications, this comparability is challenging to achieve.

The other 2 themes provide suggestions for improving a streamlined DQA. The third theme advocates more consistent use of a CDM.11,25,69,75,84,85,91,92 A CDM could facilitate the scalability of a tool and allow for easier comparison of data quality across different domains. The fourth theme recommends the automation of DQA.11,12,25,54,75,85,92,95–97 Initial attempts to automate DQA included software packages that can be applied to various EHR datasets,85,94 applied to EHR data in a specific type of system,92 and rule lists or frameworks that can be assessed on different EHR datasets.12,17,32 Automation would support both the timeliness of DQA and the ability to use a single DQA tool across multiple domains.

## Section: RESULTS › Opinion pieces

Opinion pieces often consisted of a collection of ideas derived from expert panels or stakeholders through surveys and interviews.59,98,99 Due to the process of collecting different opinions, the opinion pieces developed the general notion that a collaborative team is necessary and helpful for developing DQA.36,99,100 These opinion pieces echoed many of the themes highlighted in the tool category. Most notably, they agreed that CDMs would be useful both for completing and comparing DQA methods.36,53,59,98,101 However, they also acknowledge the task dependency of DQA as a limiting factor for comparison of qualities between different assessments at this point in time.18,59,99,100

## Section: DISCUSSION

EHR data quality is of paramount importance as EHR data continues to be increasingly leveraged for biomedical research purposes. In order to understand trends in DQA of EHR data, we extended a 2013 literature review8 on the topic to present day. In 2013, Weiskopf established 5 dimensions of EHR data quality and 7 methods by which to assess these dimensions. Since 2013, we have found a general increase in the number of dimensions assessed per paper and the number of methods used along with the addition of 2 dimensions to the framework.

In regards to a priori specified dimensions, we found an increase in the proportion of papers that assess completeness, concordance, plausibility, and currency, and a decrease in the proportion of papers that assess correctness as they relate to EHR data since 2013. This decrease in proportion of papers assessing correctness should not be taken at face value as concordance and plausibility can sometimes be considered a subset of other dimensions.8 Similarly, there was an increase in the proportion of papers in which each method was used. However, data element agreement, element presence, and data source agreement surpassed the use of a gold standard as the most common methods in that order. The trend towards using methods other than a gold standard comparison is positive as there are noted challenges that go along with establishing a gold standard comparator.8

In addition to Weiskopf’s original 5 dimensions of data quality, we propose conformance and bias as additional and meaningful dimensions of data quality. Our definition of conformant data, or data that complies with a predefined relational structure, aligns with the definition of value conformance from Kahn et al9 and extends Weiskopf’s model of DQA to include aspects of Wang and Strong’s representational data quality.7 This represents a shift in DQA practices since the 2013 review which only identified dimensions that focused on intrinsic and contextual DQA, a shift that may be partly due to the adoption of frameworks like the one presented by Kahn et al9 and the increased adoption of CDMs both within research networks and collaborative studies.11,53 Structured data lend themselves well to intrinsic and contextual approaches as they have likely been assessed for conformance, while unstructured data in the EHR or an associated source, such as clinical registries, may still require assessment of conformance.

The second dimension we added to Weiskopf’s model of DQA was bias, or missingness not at random, which is often due to information or measurement bias.118 Generally in informatics research, there are different levels of missingness, some of which can be ignored in secondary analyses and some of which impact the outcome of the analyses.119 Bias is one mechanism for understanding whether or not missingness in EHR data is ignorable and is therefore increasingly important to consider as it has direct implications for downstream research. Recently, there have been many projects in the health informatics domain which highlight the damaging effects of biased data on research outcomes. Bias in EHR data can cause bias in the machine learning and artificial intelligence models developed using the data.120,121 These biased results may then have a negative impact on patient care when machine learning models are used in decision support tools in clinical practice.122 Patients may be assigned incorrect risk scores or be given incorrect treatment recommendations.123 This is especially problematic when biased results, in turn, perpetuate systematic inequities in healthcare systems and delivery at the individual and population levels.

Bias as a dimension of EHR data quality also provides an example of an underlying mechanism behind general data quality issues. When data quality issues do occur, they likely can be attributed to some underlying mechanism. These mechanisms range from data entry or documentation errors to larger problems within EHR storage or warehouse software to institutional level barriers to accessing care. Understanding from where a data quality error may stem can help to identify key points in the data lifecycle at which to assess and improve data quality. Such an observation also argues for the recognition of the dynamic, complex systems that influence or impact data quality in “real world” settings.

Despite the consistent patterns of DQA in the literature found by this review, researchers largely developed DQA on a project-by-project basis. The methods used to assess data quality were repeatedly implemented across many applications although assessing a consistent collection of dimensions. The repetitive patterns of DQA are not practical in terms of time and resources in our current research environment as EHR data continues to be commonly used for downstream analysis. For this reason, we recommend and highlight the emerging theme of DQA automation as discussed in many of the opinion pieces and tools. This review emphasized the movement towards automating DQA in the development of DQA tools. Examples of automation include software packages, rule lists, and frameworks.

The prospect of automating DQA also requires interrogation of the data lifecycle to determine optimal points at which to assess data quality. Although the majority of DQA in the literature occurs after extraction from the EHR, some of the proposed tools transitioned to DQA at an EHR software level.92 Based on prior work and experience using EHR data for downstream analysis, we identified the original entry point of data into an EHR, the transition to a data warehouse, or after extraction for a specific project as natural opportunities for DQA. It may be the case that certain dimensions of DQA are available at different stages in the data lifecycle. Implementation of automated DQA checks across an EHR ecosystem could help improve interoperability and further the transition to a comparable model of DQA.

In addition to automation, we should give further consideration to the balance between a scalable tool and a task specific tool. As data requirements differ between systems and projects, we will need a flexible tool in order to be able to assess data quality across many applications. One potential solution to this problem is the usage of a CDM to support interoperability and enable the development of reusable DQA tools.25,36,53,59,69,75,84,85,91,92,98,101

## Section: DISCUSSION › Limitations

There are a few limitations of this review to consider. First, the paper selection process was subjective as it was only performed by one author. For this reason, authors and other reviewers may not agree with our classifications. In addition, we were unable to review all of the initial results due to resource constraints. Our screening process could be considered a convenience sample which optimizes for recent research and highly visible research based on citation frequency. It is possible that selecting literature in order of citation frequency may identify papers cited for clinical research content rather than data quality content. However, the primary objective of all included papers was DQA, so we believe the number of citations implies a larger visibility for the DQA methods in the research community regardless of the citation purpose. A future review could take the time to review all initial search results rather than adopting our dual importance and emergence approach or could ensure that selection by citation frequency optimizes for data quality literature.

## Section: CONCLUSION

Although high quality EHR data are necessary to support patient care and secondary analyses, there do not exist standard methods for assessing EHR data quality. We extended a 2013 literature review on EHR DQA to evaluate changes and improvements in DQA approaches. There has been an increase in the number of dimensions of DQA and the methods by which to assess the dimensions of EHR data quality in recent years. However, there still does not exist a standard approach for DQA of EHR data, so future work should focus on the development of DQA tools and potential automation of such tools.

## Section: Supplementary Material

Click here for additional data file.

## Section: Contributor Information

Abigail E Lewis, Division of Computational and Data Sciences, Washington University in St. Louis, St. Louis, Missouri, USA; Institute for Informatics, Data Science and Biostatistics, Washington University in St. Louis, St. Louis, Missouri, USA.

Nicole Weiskopf, Department of Medical Informatics and Clinical Epidemiology, Oregon Health & Science University, Portland, Oregon, USA.

Zachary B Abrams, Institute for Informatics, Data Science and Biostatistics, Washington University in St. Louis, St. Louis, Missouri, USA.

Randi Foraker, Institute for Informatics, Data Science and Biostatistics, Washington University in St. Louis, St. Louis, Missouri, USA.

Albert M Lai, Institute for Informatics, Data Science and Biostatistics, Washington University in St. Louis, St. Louis, Missouri, USA.

Philip R O Payne, Institute for Informatics, Data Science and Biostatistics, Washington University in St. Louis, St. Louis, Missouri, USA.

Aditi Gupta, Institute for Informatics, Data Science and Biostatistics, Washington University in St. Louis, St. Louis, Missouri, USA.

## Section: FUNDING

This research received no specific grant from any funding agency in the public, commercial, or not-for-profit sectors.

## Section: AUTHOR CONTRIBUTIONS

AEL, PROP, and AG conceived and designed the study. AEL completed the literature review and analysis, drafted and revised the manuscript, and prepared tables and figures. AEL, NW, PROP, and AG participated in the literature review interpretation and drafted the manuscript. All authors reviewed and revised the manuscript, and approved the final version for submission.

## Section: SUPPLEMENTARY MATERIAL

Supplementary material is available at Journal of the American Medical Informatics Association online.

## Section: CONFLICT OF INTEREST STATEMENT

None declared.

## Section: DATA AVAILABILITY

The data underlying this article are available in the article and in its online supplementary material.

## Section: Associated Data

Click here for additional data file.

## Section: Associated Data › Supplementary Materials

Click here for additional data file.

## Section: Associated Data › Data Availability Statement

The data underlying this article are available in the article and in its online supplementary material.


---

# Evaluating point-prediction uncertainties in neural networks for protein-ligand binding prediction

- **Authors:** Ya Ju Fan, Jonathan E Allen, Kevin S McLoughlin, Da Shi, Brian J Bennion, Xiaohua Zhang, Felice C Lightstone
- **Issuer:** Artificial intelligence chemistry
- **Type:** Scientific article
- **Published:** 2023-06-03
- **Language:** en
- **DOI:** 10.1016/j.aichem.2023.100004
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37583465/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Neural Network (NN) models provide potential to speed up the drug discovery process and reduce its failure rates. The success of NN models requires uncertainty quantification (UQ) as drug discovery explores chemical space beyond the training data distribution. Standard NN models do not provide uncertainty information. Some methods require changing the NN architecture or training procedure, limiting the selection of NN models. Moreover, predictive uncertainty can come from different sources. It is important to have the ability to separately model different types of predictive uncertainty, as the model can take assorted actions depending on the source of uncertainty. In this paper, we examine UQ methods that estimate different sources of predictive uncertainty for NN models aiming at protein-ligand binding prediction. We use our prior knowledge on chemical compounds to design the experiments. By utilizing a visualization method we create non-overlapping and chemically diverse partitions from a collection of chemical compounds. These partitions are used as training and test set splits to explore NN model uncertainty. We demonstrate how the uncertainties estimated by the selected methods describe different sources of uncertainty under different partitions and featurization schemes and the relationship to prediction error.

## Section: Background and motivation

Traditional drug discovery examines bioactivities between drug and protein via a high throughput screening experiment [1,2]. The process is time-consuming and expensive. Deep learning (DL) models try to capture intricate nonlinear relationships between input data (such as drug compounds) and the associated output (such as protein inhibition) for large scale computational screens [3]. The models then predict the properties of new compounds that help determine a feasible set of compounds for synthesis and evaluation. Computational screens save time and effort, and provide the potential to speed up the drug discovery process and reduce its failure rates [4,5]. However, drug discovery requires exploring chemical space beyond the training data distribution. Predictions on unknown regions are prone to pathological failure. The success of adopting DL methods across a range of drug-design settings requires better communication of uncertainty [6,7]. Detecting regions of chemical space with high uncertainty could help design the experiments to expand a model’s applicability domain.

Recent studies have emphasized the importance and challenges of uncertainty quantification (UQ) in deep learning for drug discovery. Mervin et al. (2020) [8] reviewed classic and modern UQ methods and discussed their usage for drug design (e.g, including the empirical, frequentist and Bayesian approaches). The study points out that the chemoinformatic data being modeled is overall heavily biased with respect to the amount, degree of diversity and distribution of data points. There are issues surrounding data quality and assay variability [9], as well as the skewed proportion of protein-target complexes [10,11] and the imbalance between active and inactive compound-target labels [12]. Hence, most models for drug discovery are not able to provide realistic probability estimates while providing single point predictions. A common misleading phenomenon is in the classification models where the predictions for two classes, such as labels of ‘activity’ and ‘inactivity’, come from probability-like fractions. One example is the softmax function used in the last layer of a neural network model, which gives an output value between zero and one. These function values only mean to separate output classes, not to provide confidence of the prediction. Applying explicit uncertainty quantification methods could provide an alternative confidence measure to the classification probability estimates.

Uncertainty of deep learning could come from two sources: data (aleatoric) uncertainty and model (epistemic) uncertainty [13]. The data uncertainty reflects a lack of confidence due to the imprecision of molecular measurements. The aleatory concept involves unknown outcomes that can differ each time one runs an experiment under similar conditions [14]. Data collected for the drug discovery process could have experimental variabilities due to natural biological changes in the samples, measurement fidelity, instrumentation, sampling procedures, etc. The data uncertainty is irreducible to the model and is an inherent property of their distribution.

In contrast, model uncertainty measures the uncertainty in model parameters given the training data. Particularly, inadequate knowledge contributes to the model uncertainty. This is often the case for the chemoinformatic data where there is a limited number of drug compounds available with unbalanced activity classes for a complex biological process. UQ methods for deep neural networks (NN) that evaluate how changes in model parameters effect the NN predictions are aimed at capturing the model uncertainty. Bayesian neural networks (BNN) [15,16] quantify posterior uncertainty on NN model parameters (i.e. weights) and express predictions in terms of expectations with respect to this posterior distribution [17]. Other methods generate a set of point predictions and use its mean and variance to represent the optimal prediction and its corresponding uncertainty. Monte-Carlo dropout [18] passes a test sample multiple times through the NN model and generate a collection of such predictions. For each iteration, the model assigns the value zero to a fraction of randomly selected weights. Similarly, deep ensemble [19] and bootstrap [20] train multiple models and compute the mean and spread of the ensemble.

Apart from data uncertainty and model uncertainty, Malinin and Gales (2018) presented distributional uncertainty as a separate source of uncertainty [21]. Distributional uncertainty occurs when the test data is foreign to the model due to mismatch between the training and test distributions. Applicability domain (AD) estimates whether a model’s prediction for a chemical compound is applicable based on the model’s training set properties. Distance-based methods used to evaluate AD play a similar role as distributional uncertainty modeling methods [22].

Residual estimation with an I/O kernel (RIO) [23] directly estimates prediction residuals using modified Gaussian Processes (GP). GP models offer a mathematically grounded approach to reason about the predictive uncertainty [24]. RIO uses a new composite I/O kernel that makes use of both inputs and outputs of the NN, meaning that the method examines both the distance to the nearest training data and the prediction errors on the training set. It provides predictive uncertainty estimation without modifying the NN training or formulation. Hie et al., 2020 [7] demonstrated that RIO uncertainty estimation enables successful iterative learning across a broad spectrum of experimental scales for biological discovery and design.

It is important to have the ability to separately model the different types of predictive uncertainty, as the model can take assorted actions depending on the source of uncertainty [21]. In this article, we present a carefully designed experiment with publicly available drug data to gain insights into uncertainty quantification methods. We employ the calculated end-point binding free energy with MM/GBSA (the molecular mechanics generalized Born surface area) as the response values for the NN models. Note that MM/GBSA is one of a number of different methods used in computational drug discovery [25]. The simulated MM/GBSA scores are not from the experimental measurements, and hence reduce the aleatoric uncertainty, which allows the study to focus on modeling epistemic uncertainty. We select the UQ methods that examine different sources of uncertainty. Additionally, they can be directly applied to any standard NN without having to modify the model training formulation. We use the ATOM Modeling PipeLine (AMPL) [26] developed by the Accelerating Therapeutics for Opportunities in Medicine (ATOM) Consortium to provide a rigorous pipeline for training and evaluating drug discovery oriented NN models. We demonstrate how the selected UQ methods provide uncertainty estimations on point predictions of NN models. Since the goal of UQ is to detect unanticipated imprecision of model predictions, we inspect how the UQ methods reflect prediction errors.

This paper is organized as follows. First, we collect related work in Section 2. Next, we describe the selected uncertainty quantification methods and how they present different sources of uncertainty in Section 3. In Section 4, we explain the preparation of the chemical compound inputs, NN model building and the experimental design to evaluate the UQ methods. Finally, we present the experimental results in Section 5 and conclude our findings in Section 6.

## Section: Related work

There has been significant demand in quantifying prediction uncertainty for DNN models, especially for drug discovery where mistakes may be expensive. Hie et al. (2020) [7] leveraged Gaussian process-based uncertainty prediction to identify and validate experimental compounds with nanomolar affinity for diverse kinases and whole-cell growth inhibition of Mycobacterium tuberculosis. They showed that the GP uncertainty estimation enables successful iterative learning across a broad spectrum of experimental scales. Scalia et al. (2020) [27] compared scalable UQ methods, including MC-dropout, Deep Ensembles and bootstrapping, for graph convolutional neural networks (GCNN), designed for deep learning-based molecular property prediction. They introduced a set of quantitative criteria, including ranking-based methods and uncertainty calibration methods, to capture different uncertainty aspects. Wang et al. (2021) [22] combine both distance-based and Bayesian UQ approaches together for improved uncertainty quantification in QSAR (Quantitative Structure-Activity Relationship) regression modeling. The hybrid method quantitatively assesses the ranking and calibration ability of the selected UQ methods, including applicability domain (AD) methods, mean-variance estimation of the graph convolutional neural networks [27] and deep ensembles [19].

There has been notable progress made on predictive uncertainty for deep learning through the formulation of neural networks. One class of approaches stems from the combination of a Bayesian approach and neural networks [16,19,28–30]. All such methods require significant modifications to the model infrastructure and training procedure. Malinin and Gales (2018) developed Prior Networks for modeling predictive uncertainty, which explicitly models distributional uncertainty [21]. Tang and de Jong (2019) [31] developed marginalized graph kernel specifically for computing similarity between molecules. The framework employs GP regression to perform prediction on the atomization energy of molecules. Moreover, drug discovery tasks often evaluate novel molecules by entering areas in the feature space that are not previously represented in training data. Han et al. (2021) [32] measured the data distributional shift as the model reliability of graph neural networks (GNN).

In this work, we focus on measuring the point-prediction uncertainties of the standard neural network regression models with fully connected layers that require feature vectors as their input. We investigate a set of the UQ methods separately, which examine different sources of uncertainty. These methods also provide UQ estimations without requiring specific NN formulations, allowing broader applications.

## Section: Uncertainty quantification methods for neural networks

We select uncertainty quantification approaches for deep neural networks that do not limit the choice of model. Consider a neural network model with L layers. We denote Wi as the NN’s weight matrices for each layer i=1, 2,…,L. We denote yi as the observed output corresponding to input xi,i=1, 2,…,n, where n is the number of data points. Let X,y be the input and output sets and let the training dataset 𝒟=(X,y)=xi,yii=1n. The predictive probability of a NN model can be parameterized as (1) P(y|x,𝒟)=∫P(y|x,ω)︸Datap(ω|𝒟)dω︸Model.

In a Bayesian framework the predictive uncertainty of a NN model P(y∣x,𝒟) trained on a finite dataset 𝒟 will result from data (aleatoric) uncertainty and model (epistemic) uncertainty as shown in 1. The posterior distribution over responses y given a set of model parameters ω describes a model’s estimates of data uncertainty, and the posterior distribution over the parameters given data describes model uncertainty [21].

## Section: Uncertainty quantification methods for neural networks › Monte-Carlo dropout (MC-dropout)

Deep neural networks contain multiple nodes and layers that try to learn complicated relationships between the inputs and outputs. Dropout is a method used to prevent overfitting and lower generalization error for NN models [33]. Dropout means temporarily removing a node from the network along with all its incoming and outgoing connections, which we can simply set zero on the weight of the node. The choice of which nodes to drop is random. In most cases, we choose a fixed value to indicate the fraction of the nodes to drop. Gal and Ghahramani (2016) further applied the concept to generate ensembles for evaluating model uncertainty.

Let Wi be a random matrix for each layer i and set ω=Wii=1L. In Equations 1 obtaining the true posterior p(ω∣𝒟) using Bayes’ rule is intractable, and it is necessary to use either an explicit or implicit variational approximation q(ω) [34–36]. Monte-Carlo (MC) dropout utilizes the q(ω) as a distribution over matrices whose columns are randomly set to zero (called dropout). Furthermore, the integral in Equations 1 for the predictive probability is also intractable for neural networks. MC dropout employs sampling to approximate it. As shown in Equations 2 each term in the sum is approximated by Monte-Carlo integration with a single sample ω(i)~q(ω) to obtain an unbiased estimate[18].

Training a neural network with dropout is as training a collection of thinned networks with extensive weight sharing. The process does not change the dropout NN model itself. In testing we use the original model by simply cutting off the node’s weights. MC dropout estimates the predictive mean and predictive uncertainty by collecting the results of stochastic forward passes through the NN model.

## Section: Uncertainty quantification methods for neural networks › Applicability domain (AD)

The Applicability Domain (AD) assessment is based on the numerical vector representation of chemical compounds in the training set. We select two AD methods that are distance-based and suitable for novelty (or outlier) detection.

## Section: Uncertainty quantification methods for neural networks › Applicability domain (AD) › Empirical distance distribution (AD-DD)

For distance-based novelty detection we need a threshold to decide whether or not the unseen object is actually novel [37]. The empirical distance distribution of the training set molecules can help establish a threshold, using the 1-α quantile (for α=0.01, 0.05 or 0.1) of the k-nearest neighbors within the training set distance distribution [38]. We collect the mean distances from every data point to its k-nearest neighbors in the training set. We fit a normal distribution on these mean distances and obtain its total mean, μknn, and standard deviation, σknn. For a new chemical compound x, we compute its mean distance to its k-nearest neighbors in the training set d‾knn(x). The score of the applicability domain using the empirical distance distribution is the rectified Z-score of the mean k-nearest neighbor distance of the new point based on the distribution of the training set: (3) ρD(x)=max{0,d¯knn(x)−μknnσknn}.

## Section: Uncertainty quantification methods for neural networks › Applicability domain (AD) › Local density (AD-LD)

Denote the distance of a data point x to its kth -nearest neighbor in the training set NNktrain(x) as ‖x−NNktrain(x)‖. The local density is inversely related to the distance. The higher the local density is, the lower the distance is to the neighbors. The score of the applicability domain using local density [39] is: (4) ρL(x)=1k∑i=1k‖x−NNitrain(x)‖1k2∑i=1k∑j=1k‖NNitrain(x)−NNjtrain(NNitrain(x))‖.

The denominator is the average distance from the nearest neighbors NNtrain(x) to their nearest neighbors in the training set NNtrain(NNtrain(x)).

## Section: Uncertainty quantification methods for neural networks › Residual estimation with an I/O kernel (RIO)

Residual estimation with an I/O kernel (RIO) is a Gaussian processes (GP) method designed to be applied on top of any trained NN model [23]. RIO quantifies the uncertainty in the point-predictions of NN models without retraining or modifying any component of them.

Let yˆi be the point prediction of a NN model given xi. RIO models the residuals between observed outcomes y and NN predictions yˆ using GP with a composite kernel. The residuals rii=1n between observed outcomes and NN predictions on the training dataset 𝒟 is (5) ri=yi−y^i, for i=1,2, …,n.

Let r be the vector of all residuals and yˆ be the vector of all NN predictions. RIO trains a GP with a composite kernel assuming r~𝒩0,Kθ((X,yˆ),(X,yˆ))+σn2I, where 𝒩 denotes a multivariate Gaussian distribution with mean 0 and covariance matrix Kθ((X,yˆ),(X,yˆ))+σn2I, and σn2 is the noise variance of observations. The composite kernel Kθ((X,yˆ),(X,yˆ)) is an n×n covariance matrix at all pairs of training points whose elements are: (6) kθ((xi,y^i),(xj,y^j))=kθin (xi,xj)+kθout (y^i,y^j),fori,j=1,2, …,n.

This kernel design enables the evaluation on both the novelty of a data point and the prediction residual. The composite kernel is the sum of two kernels, one for the NN input data and the other for the NN output data. RIO applies the composite kernel as the covariance function of GP. The GP optimizes the hyperparameters of the covariance function, θin and θout, by maximizing the log marginal likelihood logp(r∣X,yˆ).

## Section: Experimental design

We randomly select 9000 drug compounds available from the ChEMBL database [40,41], a large, open-access bioactivity data source. The drug compounds are presented in the SMILES (simplified molecular-input line-entry system) strings, which describes the structure of the chemical compounds in the dataset. We use two featurization schemes to map the SMILES strings into model input features. We first compute the chemical descriptors using Molecular Operating Environment (MOE) software [42]. Many MOE descriptors were strongly correlated with each other due to the fact that they scaled with molecular size, as measured by the total number of atoms, denoted as a_count [43]. We replace all descriptors, d, having Pearson correlation r (d, a_count) > 0.5 with the computed d/a_count to remove the dependency. We further eliminate descriptors that are duplicated, have constant values or are linear functions of other descriptors. The final set of the MOE descriptors contain 306 features. The other featurization scheme that we also compute is the extended connectivity fingerprint (ECFP4). We use RDKit [44] to generate the ECFP4 bit vectors with length 1024.

We utilize the molecular mechanics generalized Born surface area (MM/GBSA) continuum solvent approach to rescore the binding affinities of the chemical compounds [45,46]. Note that there are other approaches used in computational drug discovery [25]. The computed MM/GBSA scores are not from experimental measurements but rather estimate binding affinity between a compound and a target protein. The target protein used for this study is the main spike protein for SARS-CoV-2. Applying them as the responses of the NN models reduces their aleatoric uncertainty. Since the aleatoric uncertainty is irreducible to the model, making it more controllable could help observing other uncertainty sources. We have also observed that the MOE descriptors are highly correlated to the MM/GBSA scores in the randomly selected 9000 drug compounds. Among the total 306 MOE features there are 22 features having correlation larger than 0.5 as shown in Table 1.

To better understand how the uncertainty quantification methods work for the protein-ligand binding prediction in the drug discovery tasks, we make use of the known correlation between the MOE descriptors and the MM/GBSA scores to design the experiments. We visualize the correlation in the dataset using the t-distributed stochastic neighbor embedding (t-SNE). We project the top 22 correlated MOE features employing ten principle components before computing the two coordinates of the t-SNE, according to the suggested usage of the method [47]. Fig.1 displays the two-dimensional t-SNE scatter plot of the dataset.

It appears that the dataset consists of five clusters. The color on the data points represents the MM/GBSA scores where a more negative value indicates stronger binding. Cluster 2, 3 and 4 marked on the plot contain data points with large negative MM/GBSA scores, while cluster 1 and 3 contain more high value MM/GBSA scores. Fig. 2 shows the distribution of the MM/GBSA scores for each cluster.

We split the dataset into training set and test set based on the clusters. The numbers of the data points in the clusters are 2132, 2455, 3252, 1154 and 7, respectively, from cluster 1 to cluster 5. We exclude cluster 5 due to its small size. We randomly select 1000 data points in each cluster as the training set, another 100 data points as the validation set and the rest as the test set. We apply the same splits to both the MOE features and the ECFP features, creating eight splittings of training, validation and test sets (from four clusters and two featurization methods). We include all of the 306 MOE features in the dataset as the 22 high correlation features discussed earlier are for visualization purposes only.

We train the Neural Network models using a data-driven modeling pipeline, AMPL, developed by our group at the ATOM Consortium [26]. The underlying models were implemented with the DeepChem package [48]. The architecture of the neural networks consists of one, two or three fully connected hidden layers. Each layer contains varying numbers of rectified linear unit (ReLU) nodes. During training and evaluation we randomly drop out 30% of nodes to avoid overfitting. To optimize the performance of neural networks, we run hyperparameter searches, varying the numbers of hidden layers, numbers of nodes per layer, and learning rates. We evaluate an average of 1500 regression models for each training set and select the best model for further analysis on quantifying the point-prediction uncertainties. We select the best model parameters based on validation set performance following standard machine learning practices. We evaluate the performance of regression models using the coefficient of determination (R2)[49] defined as R2=1−∑i=1n(yi−y^i)2∑i=1n(yi−y¯i)2 where yi is the actual MM/GBSA score for a compound i,y‾ is the average value of the actual scores and yˆi is the predicted value of yi. An R2 close to 1 implies an almost perfect case when modeled values nearly match the observed values. An R2 equal to 0 implies a baseline model, which always predicts the mean. A negative R2 indicates that a model has worse predictions than the baseline.

## Section: Experimental results › Model performance

The best regression model after hyperparameter tuning, measured by R2 scores, is kept for each cluster and each type of chemical representation (MOE or ECFP). Tables 2 and 3 collect the separated test set performances of the best model trained on each cluster. Recall that we take 1000 randomly selected data points from each cluster for model training. We use the rest of the data points as the test set in the cluster to show how each model perform on single clusters.

We found that the models trained on MOE descriptors perform better than the ones trained on ECFP. The clusters used for the training and test sets are created from the most correlated MOE descriptors. Since the clusters are not explicitly separated by their ECFP distances, there would be more similarity between the training and test sets in ECFP. It is surprising that the ECFP models do more poorly in the cross cluster prediction task.

The results also indicate that the NN models perform the best in their own clusters, except on the model trained on cluster 3 with MOE descriptors. Data points in cluster 3 cover a wider range of the MM/GBSA scores. Interestingly the model trained on cluster 3 using MOE descriptors performed the best on cluster 1 with R2 at 0.685, while performed the second best on the test set from its own cluster with R2 at 0.580. We also observed that the models trained on cluster 2 and cluster 4 do not perform well on predicting data points in other single clusters. Overall, most models have worst performance on their test set, and best performance on their training set. This aligns with what we expect when designing the splits of the data. Chemical compounds outside a cluster tend to be more different from those in the cluster. It is a challenge to the model trained on a cluster to test its performance outside the cluster. Next, we investigate how the selected UQ methods capture such challenges.

## Section: Experimental results › Uncertainty evaluation

Since we use the t-SNE plot to generate the clusters where distances in the original data space are not preserved in the 2D feature space. The clusters in the plot may be shown to appear in non-clustered data.

Values generated by the AD method using empirical distance distribution (AD-DD) measuring the dissimilarities to the training set can help realize the actual distances. Figs. 3, 5, 7 and 9 display the uncertainty estimations of the point predictions using the four uncertainty quantification methods for the models trained on cluster 1,2,3 and 4, respectively. The AD-DD uncertainty values are significantly lower in the training clusters than in the rest of the chemical compounds, especially in cluster 1,2 and 3. When using the cluster 4 as the training set, AD-DD method does not give as distinctly smaller values for the training data. It appears that chemical compounds described by MOE descriptors in cluster 4 are close to data points in cluster 2 and 3, indicating that the cluster covers a wide range of chemical compounds. Furthermore, data points represented by ECFP features in cluster 4 spread out from each other, suggesting non-clustered data.

Recall that distance-based novelty detection needs a threshold to decide whether a new compound is actually novel [37]. If we use a 95 % quantile of the k-nearest neighbor within the training set distance distribution as a threshold, the corresponding z-score is around 1.6 in a standard normal distribution. We can use the value 1.6 for AD-DD values as a threshold to identify novel test compounds. We can see that this threshold distinguishes the training cluster 1,2 and 3 from their corresponding test set clusters.

The AD method using local density (AD-LD) highlights more data points with larger values than the AD-DD method. The distinctiveness between the training and the test sets using AD-LD is less significant than AD-DD. Only the models trained on cluster 1 with MOE descriptors gives significantly lower AD-LD values on the training cluster than the rest of chemical compounds. Moreover, the models trained with ECFP features yield lower ranges of AD-LD values, which indicates that data points in ECFP features spread out and may not form definite clusters.

Models using different compound representation may have opposite uncertainty values from MC-dropout. The model uncertainties (evaluated by MC-dropout) that appear high in one compound representations may be low in other compound representations. The third rows of the figures display the UQ values from MC-dropout used to present the model uncertainties. For the models trained on cluster 1 and cluster 3, MC-dropout gives opposite degrees of uncertainties when using different compound representations. As shown in Figs. 3 and 7 the MC-dropout method gives high uncertainty values with MOE descriptors while giving low uncertainty values with ECFP features for most predictions. To investigate which uncertainty values to trust, we compare the UQ values with the prediction errors in the Figs. 4 and 8, which display the actual MM/GBSA scores versus the predicted, colored by the UQ values. The distance from a data point to the diagonal indicate its prediction error. We found that the UQ values using MC-dropout on the MOE descriptors tend to be high on the prediction values that have data points far away from the diagonal and low on the predictions that are closer to the diagonal, indicating that MC-dropout on the MOE descriptors can reflect possible prediction errors. We also know that the models trained on the ECFP features do not perform well on the predictions. We may conclude that the UQ values from MC-dropout are more reliable on the MOE descriptors than on the ECFP features possibly due to better trained models with MOE descriptors. Furthermore, MC-dropout does not necessarily give lower uncertainties in the training than in the test set. There are high MC-dropout uncertainty values in the training clusters where the other three methods tend to have low uncertainty values (Figs. 7 and 8).

RIO method gives near constant uncertainty values to the majority of the chemical compounds, especially on the models trained with ECFP features. There are only a few data points that have relative high RIO uncertainty values. In general RIO picked up part of high uncertainties similar to AD-DD when the models are trained with MOE descriptors. Exceptionally, for the model trained on cluster 4 with MOE descriptors RIO marks particularly high uncertainty values on several chemical compounds; while all other methods mark similar high uncertainty values but they are less distinct than what RIO gives as shown in Figs. 9 and 10.

## Section: Experimental results › Uncertainties v.s. prediction errors

When using NN model predictions to direct experimental design, unanticipated imprecision wastes valuable time and resources for drug discovery applications [50]. We examine whether the UQ methods are able to identify the prediction errors when using NN models for new chemical compounds. We plot the actual MM/GBSA scores versus the predicted values of the chemical compounds from the test sets. We color their uncertainty values from the four evaluation methods for the models trained on cluster 1, 2, 3 and 4 in Figs. 4, 6, 8 and 10, respectively. The diagonal line on the plots represents the values where the predicted is equal to the actual MM/GBSA score. Data points that are far away from the diagonal have large prediction errors. We examine the results for each cluster in the following.

The majority of the chemical compounds in cluster 1 have MM/GBSA scores ranging from around −15 to −35, indicating weaker binding. It is reasonable that larger prediction errors fall on the stronger binding side, ranging from −30 to −40 as shown in Fig. 4. This range is near the tail of the training set. Predicted values that fall outside the training set can be less reliable. The AD-LD, MC-dropout and RIO uncertainty values are high for those less reliable predictions for the model trained with MOE descriptors, while only the AD-DD and AD-LD values are high for ECFP. For the model trained on cluster 1 with ECFP the model uncertainty from MC-dropout appears opposite to the desired values, rendering low values on the high prediction error ranges and high values on the low prediction error ranges. For the same model the RIO method gives relatively high evaluations only to a few predicted values at the two ends of the predicting range, around −20 and −35.

Cluster 2 has strong binding free energy with the MM/GBSA scores approximately ranging from −25 to −55 as the majority. For the model trained on cluster 2 with MOE descriptors the AD-DD and AD-LD methods give relatively high values on the chemical compounds that also have large prediction errors as shown in Fig. 6. For the same model with the MOE descriptors, the model uncertainties from MC-dropout are moderately high on the lower half of the prediction values, while the RIO uncertainties are distinctly higher at the points far away from the diagonal. The four uncertainty evaluation methods do not capture any prediction errors for the model trained on cluster 2 with the ECFP features, whose training set performance was poor with R2 at 0.412. The model predicts strong binding for all data points, and has a small range of prediction values, from −32 to −44.

The chemical compounds in cluster 3 and cluster 4 cover a wider range of MM/GBSA scores than cluster 1 and cluster 2. Between the two clusters, cluster 3 contains more high value MM/GBSA scores (meaning weaker binding) while cluster 4 contains more low value MM/GBSA scores (meaning stronger binding). The models trained on cluster 3 have the best performance on the test set prediction. This also reflects on the actual versus predicted plots in Fig. 8 where most data points are along the diagonal. AD-DD, AD-LD and RIO give high values at the two ends of the predicting range for the model trained with MOE descriptors. RIO uncertainty gives distinct large uncertainty values at the lowest predicted MM/GBSA scores and only a few at the highest, reflecting the uncertainty due to the lack of low MM/GBSA scores in the training set. For the models trained on cluster 3 model uncertainties from MC-dropout are high at the lower half of the predicted range with MOE descriptors, but high at the highest predicted values with ECFP. The model trained with ECFP again does not perform well and has a narrow range of predicted values, ranging from −30 to −43. The AD-DD and AD-LD values are spread out while the RIO uncertainties are close to a constant for the model trained with ECFP.

The model trained on cluster 4 with MOE descriptors predicts high MM/GBSA scores with large errors. All four methods successfully indicate these high prediction errors. Particularly the RIO method gives distinctively high uncertainties on the predictions larger than −20 where the large errors occur. Similar to the model trained on cluster 3, the model trained with ECFP does not perform well and has a narrow range of prediction values, ranging from −30 to −43. The AD-DD and AD-LD values are spread out. The model uncertainties are high at the high predicted values. The RIO uncertainties are close to a constant for most chemical compounds except the lowest and the highest ends of the predicted values.

Although RIO gives almost all predictions a near constant uncertainty estimation, we observed that these constants reflect possible prediction errors. Fig. 11 display the box plots for the test set uncertainties and prediction errors. Fig. 11(C) and Fig. 11(B) contain the estimated mean and standard deviation of the prediction errors from the Gaussian Processes used in RIO. On the x-axis are the trained models where the first column C1 indicates the model trained on cluster 1. The corresponding data points in the box plot are from C1’s test set, composed of cluster 2,3 and 4. The UQ value that RIO estimates for a point prediction is the standard deviation of the prediction errors. RIO gives high uncertainty values to most of their test set predictions except C1 with MOE descriptors, reflecting the possibility of large test set prediction failures.

Remarkably by ordering the uncertainty values and examining the test set performance, we found that the magnitude of the uncertainties does not necessarily reflect the level of prediction errors. We sort the uncertainty values in a decreasing order in the test sets for each of the UQ methods. We compute the test set coefficient of determination (also known as the R2 score) and remove the top 5% largest uncertainty values in the test set, iteratively, until no samples are left. These computed values form the performance curves shown in Fig. 12. If the magnitude of the uncertainty values reflect the level of the prediction errors, the test set performance will increase as the top 5% largest uncertainty values are removed from the test set. The model trained on cluster 4 with MOE descriptors is the only one where all four UQ methods are able to reflect the level of prediction errors. These UQ methods evaluating other NN models barely echo the level of prediction errors.

## Section: Conclusion

In this article, we investigate selected uncertainty quantification (UQ) methods that provides estimates of different sources of predictive uncertainty for neural networks (NN) aimed at protein-ligand binding prediction. The applicability domain (AD) methods capture distributional uncertainties. MC-dropout estimates model uncertainties. RIO perceives NN behavior by estimating the NN prediction residuals. The selected methods can be directly applied to any standard NN without having to modify the model formulation or training procedure, making them more accessible to analysts.

To test how these UQ methods work on NN model predictions for the drug discovery tasks, we carry out a series of carefully designed experiments. We randomly select drug compounds in the form of SMILES strings from public available database. We rescore the binding affinities of the chemical compounds by employing the molecular mechanics generalized Born surface area (MM/GBSA) continuum solvent approach. Since the MM/GBSA scores are calculated and not from the experimental measurements, it reduces the otherwise irreducible aleatoric uncertainty in the prediction. We use two featurization schemes, the MOE descriptors and the ECFP4 bit vectors, as model features. We design the splits of the training and test set using our prior knowledge on the correlation between MOE descriptors and the MM/GBSA scores. The visualization algorithm, t-distributed stochastic neighbor embedding (t-SNE), gives four visible clusters on the subset of MOE features that are highly correlated to the MM/GBSA scores. The clusters contain different distributions of the MM/GBSA scores. We take each cluster as a training set and the rest of the chemical compounds as the corresponding test set. We apply hyperparameter search to build optimal NN models. Finally, the selected UQ methods provide uncertainty values for the point predictions made by the trained NN models.

Our experiments show that the selected UQ methods describe different sources of uncertainty for point predictions of NN models. The AD method using distance distribution (AD-DD) retain the distance scale of the original data space, which the projected 2-dimensional t-SNE space has lost. Our results show that the AD-DD method can highlight novel chemical compounds, which gives the data in the other clusters higher uncertainties. It can also identify non-clustered data in the t-SNE plot, such as the cluster 4. When using cluster 4 as the training cluster, AD-DD gives high uncertainty values to several data points in the cluster, indicating the chemical compounds are very different from each other. The AD method using local density (AD-LD) verifies the clarity of the training set clusters.

MC-dropouts points to the sensitivity of the training parameters to the final predictions. MC-dropout can give opposite levels of uncertainty estimations when using different compound representations (i.e. MOE or ECFP). Our results show that MC-dropout is more reliable with MOE descriptors than with ECFP, possibly due to the better trained models with MOE descriptors. MC-dropout can reflect possible prediction errors on some of the predictions made by the models trained with MOE descriptors on cluster 1 and cluster 3. However, MC-dropout provide high uncertainty values to the predictions in the training clusters where the other methods tend to give low values.

RIO method gives near constant uncertainty values to the majority of chemical compounds. We observed that these constants reflect possible prediction errors made by poorly performing models. When the model is not performing well, the RIO gives high near-constant uncertainty values to most predictions. Only in the case where the chemical compounds are very different from the applicable domain and at the same time the model causes large prediction errors in the test set, RIO gives high uncertainty values to the data points that are distinctly larger than the near-constant uncertainty values.

Moreover, we observed that not all UQ methods can capture high prediction errors invariably. Only for cluster 4 with MOE descriptors do all four models capture the high prediction errors. Furthermore, the magnitude of the uncertainties does not clearly reflect the level of prediction errors. Again, only the models trained on cluster 4 with MOE descriptors form increasing performance curves when the top 5% largest uncertainty values are removed iteratively. Generally, the AD methods can only detect the novelty of the chemical compounds without any knowledge from the NN model. MC-dropout reflects the prediction variance due to changes in training parameters. RIO gives extra high uncertainties to extreme predicted values. These scenario do not always come with high prediction errors.

The differences in the uncertainty estimations made by the selected UQ methods provide more insight into the behavior of NN models for protein-ligand binding prediction. We suggest to model the different types of predictive uncertainty separately. Knowing the assorted types of uncertainty in a point prediction may assist practitioners in taking an appropriate UQ aware selection strategy.
