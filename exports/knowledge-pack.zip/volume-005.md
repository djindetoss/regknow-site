# Advances in de Novo Drug Design: From Conventional to Machine Learning Methods

- **Authors:** Varnavas D Mouchlis, Antreas Afantitis, Angela Serra, Michele Fratello, Anastasios G Papadiamantis, Vassilis Aidinis, Iseult Lynch, Dario Greco, Georgia Melagraki
- **Issuer:** International journal of molecular sciences
- **Type:** Scientific article
- **Published:** 2021-02-07
- **Language:** en
- **DOI:** 10.3390/ijms22041676
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33562347/
- **Licence:** CC-BY

## Section: Abstract

De novo drug design is a computational approach that generates novel molecular structures from atomic building blocks with no a priori relationships. Conventional methods include structure-based and ligand-based design, which depend on the properties of the active site of a biological target or its known active binders, respectively. Artificial intelligence, including ma-chine learning, is an emerging field that has positively impacted the drug discovery process. Deep reinforcement learning is a subdivision of machine learning that combines artificial neural networks with reinforcement-learning architectures. This method has successfully been em-ployed to develop novel de novo drug design approaches using a variety of artificial networks including recurrent neural networks, convolutional neural networks, generative adversarial networks, and autoencoders. This review article summarizes advances in de novo drug design, from conventional growth algorithms to advanced machine-learning methodologies and high-lights hot topics for further development.

## Section: 1. Introduction

The development of a chemical entity and its testing, evaluation, and authorization to become a marketed drug is a laborious and expensive process that is prone to failure [1]. Indeed, it is estimated that just 5 in 5000 drug candidates make it through preclinical testing to human testing and just one of those tested in humans reaches the market [2]. The discovery of novel chemical entities with the desired biological activity is crucial to keep the discovery pipeline going [3]. Thus, the design of novel molecular structures for synthesis and in vitro testing is vital for the development of novel therapeutics for future patients. Advances in high-throughput screening of commercial or in-house compound libraries have significantly enhanced the discovery and development of small-molecule drug candidates [4]. Despite the progress that has been made in recent decades, it is well-known that only a small fraction of the chemical space has been sampled in the search for novel drug candidates. Therefore, medicinal and organic chemists face a great challenge in terms of selecting, designing, and synthesizing novel molecular structures suitable for entry into the drug discovery and development pipeline.

Computer-aided drug design methods (CADD) have become a powerful tool in the process of drug discovery and development [5]. These methods include structure-based design such as molecular docking and dynamics, and ligand-based design such as quantitative structure–activity relationships (QSAR) and pharmacophore modeling. In addition, the increasing number of X-ray, NMR, and electron microscopy structures of biological targets, along with state-of-the-art, fast, and inexpensive hardware, have led to the development of more accurate computational methods that accelerated the discovery of novel chemical entities. However, the complexity of signaling pathways that represent the underlying biology of human diseases, and the uncertainty related to new therapeutics, require the development of more rigorous methods to explore the vast chemical space and facilitate the identification of novel molecular structures to be synthesized [6].

De novo drug design (DNDD) refers to the design of novel chemical entities that fit a set of constraints using computational growth algorithms [7]. The word “de novo” means “from the beginning”, indicating that, with this method, one can generate novel molecular entities without a starting template [8]. The advantages of de novo drug design include the exploration of a broader chemical space, design of compounds that constitute novel intellectual property, the potential for novel and improved therapies, and the development of drug candidates in a cost- and time-efficient manner. The major challenge faced in de novo drug design is the synthetic accessibility of the generated molecular structures [9]. In this paper, advances in de novo drug design are discussed, spanning from conventional growth to machine learning approaches. Briefly, conventional de novo drug design methodologies, including structure-based and ligand-based design using evolutionary algorithms, are presented. Design constraints can include, but are not limited to, any desired property or chemical characteristic, for example: predefined solubility range, toxicity below a threshold, and specific chemical groups included in the structure. Finally, machine-learning approaches such as deep reinforcement learning and its application in the development of novel de novo drug design methods are summarized. Future directions for this important field, including integration with toxicogenomics and opportunities in vaccine development, are presented as the next frontiers for machine-learning-enabled de novo drug design.

## Section: 2. De Novo Drug Design Methodology

De novo drug design is a methodology that creates novel chemical entities based only on the information regarding a biological target (receptor) or its known active binders (ligands found to possess good binding or inhibitory activity against the receptor) [10,11,12,13,14]. The major components of de novo drug design include a description of the receptor active site or ligand pharmacophore modeling, construction of the molecules (sampling), and evaluation of the generated molecules. Two major de novo drug-design approaches are available including structure-based and ligand-based design (Figure 1). The three-dimensional structures of a receptor are generally available through X-ray crystallography, NMR, or electron microscopy [15,16]. When the structure of the receptor is unknown, homology modeling can be employed to acquire a suitable structure for de novo drug design [17]. However, the quality of a homology model depends on the quality of the template structure and sequence similarity. The Ligand-based approach is generally used when no structural data for the biological target are available, but instead one or more active binders are known [3].

## Section: 2. De Novo Drug Design Methodology › 2.1. Structure-Based De Novo Drug Design

Receptor-based de novo drug design begins with defining the active site of the receptor. Since the molecular shape, physical, and chemical properties of the active site are important for tight and specific binding of a ligand, the active site is analyzed to determine the shape constraints and the non-covalent interactions for a ligand [9]. Receptor–ligand non-covalent interactions consist of hydrogen-bonds, electrostatic, and hydrophobic interactions and are used to generate interaction sites for a ligand. These sites play a significant role in reducing the high number of generated structures, thus increasing selectivity. There are several methods used to define interaction sites for the active site of the receptor. An example is HSITE, a rule-based method which considers only hydrogen-bond donors and acceptors generating a map of hydrogen-bonding regions [18]. LUDI and PRO_LIGAND are other ruled-based methods that also consider hydrophobic interaction sites [19,20,21]. HIPPO is a ruled-based method that considers the interaction sites of covalent bonds and metal ion bonds [22]. Other methods include grid-based approaches, in which a grid of points is generated in the active site of the receptor, and interaction energies for hydrogen-bonding or hydrophobic interactions are calculated using probe atoms or fragments at each grid point [23,24,25]. Multiple-copy simultaneous search (MCSS) is a method that randomly docks functional groups in the active site to determine energetically favorable positions and orientations [26,27]. The functional groups are then minimized using a force-field, and groups are discarded if the interaction energy between them and the active site is not favorable based on a threshold value. The evaluation of the candidate structures is important in de novo drug design and it is generally performed by calculating the free binding energy of the candidate molecule with the binding site of the receptor using scoring functions. The main scoring functions used to evaluate the generated structures include force fields, empirical scoring functions, and knowledge-based scoring functions [28,29,30,31,32].

## Section: 2. De Novo Drug Design Methodology › 2.2. Ligand-Based De Novo Drug Design

When the three-dimensional structure of a biological target is absent, known active binders offer an alternative strategy for de novo drug design [3]. Such data are available in the literature from screening efforts or structure–activity relationship studies [33]. Active binders can also be found in databases such as ChEMBL, which contains bioactive molecules with drug-like properties [34]. This method is often employed to design novel candidate structures for biological targets for which obtaining a crystal structure is challenging [35]. From one or more known active binders, a ligand pharmacophore model is established and used to design novel structures. In particular, the ligand pharmacophore model can be utilized either to create a pseudo-receptor or to directly perform similarity design [21]. It is worth mentioning that the quality of the pharmacophore model plays a significant role in ligand-based de novo drug design and it depends on the structural diversity of the known binders. The possibility of different binding modes requires the assumption of a common binding mode to build the pharmacophore model. A quantitative structure–activity relationship model can be used in parallel to evaluate the quality of the pharmacophore model [36]. Examples of ligand-based de novo drug design tools include TOPAS [37], SYNOPSIS [38], and DOGS [39].

## Section: 2. De Novo Drug Design Methodology › 2.3. Sampling Methods in De Novo Drug Design

Sampling of the candidate structures can be achieved by two methods, namely atom-based and fragment-based approaches [8,9]. In atom-based sampling, an initial atom is randomly placed in the active site and used as a seed to construct the rest of the molecule. In every stage, a variety of atoms and hybridization states of each atom are explored. As a result, the chemical space covered by this method is vast and the generated structures need to be narrowed down. This is typically achieved by filtering the structures based on chemical accessibility. Atom-based sampling has the advantage of a higher exploration of the chemical space, and thus a greater number and variety of structures are generated. However, the high number of generated structures makes it difficult to identify suitable compounds for synthesis and experimental testing. LEGEND is an example of an atom-based de novo drug-design algorithm [24]. Fragment-based sampling is the preferred method in de novo drug design because the structures are generated as fragment assemblies, which narrows the chemical search space, maintains good diversity, and generates candidate compounds with chemical accessibility and optimal adsorption, distribution, metabolism, excretion and toxicity (ADMET) properties [8]. This method requires a database that contains fragments and linkers, which are obtained either virtually or experimentally [3]. A fragment is docked in the active site and is utilized as a seed to build the rest of the molecule [40,41,42]. Examples of algorithms that employ fragment-based design as a sampling method include LUDI [43], PRO_LIGAND [20], SPROUT [44], and CONCERTS [29]. It is worth mentioning that drug properties such as ADMET can be implemented in de novo drug design using secondary target constraints [9]. For example, structures with drug-like properties such as oral bioavailability can be obtained by filtering the proposed structures using Lipinski’s rule of five or other in silico predictive models [45,46,47].

## Section: 3. Evolutionary Algorithms in De Novo Drug Design

Evolutionary algorithms have been extensively used in de novo drug design [8]. These algorithms are subdivided into genetic algorithms, genetic programming, evolutionary programming, and evolutionary strategies, which are based on population optimization using mechanisms inspired by biological evolution, such as reproduction, mutation, recombination (crossover), and selection [48,49]. In the case of drug design, a population of structures or conformations is created, and each member of the population is encoded by a randomly generated chromosome. The cycle begins with the generation of a “parent” population from a randomly (stochastically) created initial population (Figure 2). Each parent undergoes a random transformation using genetic operators to generate a population of new structures, called “children”. The two principal operators used are mutation and crossover. Mutation generates new populations by introducing new information, while crossover uses this information to create new individual populations of the candidate structures. A fitness function is then employed to evaluate the binding score of each “child” structure. Based on the score, a new generation of parents is selected from the combined population of the initial “parents” and “children”. This new population of “parents” is used in the next cycle. This cycle is repeated until the termination criterion is fulfilled [50,51,52]. The main evolutionary techniques used in de novo drug design include genetic algorithms, evolutionary strategies, and evolutionary graphs [8]. Examples of de novo drug-design applications using genetic algorithms include LigBuilder [25], LEA [53], ADAPT [54], PEP [55], SYNOPSIS [38], LEA3D [56], GANDI [40] and ML GAN [57]. De novo drug-design tools utilizing evolutionary strategies are TOPAS [37], Flux(1) [58], and FLUX [59]. Finally, examples of de novo drug-design applications employing evolutionary graphs are MEGA [60] and EvoMD [61].

## Section: 4. Artificial Intelligence in De Novo Drug Design

Artificial intelligence (AI) is a scientific field that exploits the ability of machines to mimic human cognitive functions such as learning and problem solving (Figure 3) [62,63,64,65]. Machine learning (ML) is a subdivision of AI that enables machines to learn from data using statistical methods and to make predictions [66,67]. ML methods have been employed to predict outcomes related to drug discovery [68]. Deep learning (DL) is a subdivision of ML which makes the computation of multilayer neural networks feasible [69]. The increased volumes of data available, combined with continuous increasing computer power, gave rise to DL methods such as recurrent neural networks (RNN), convolutional neural networks (CNN), generative adversarial networks (GAN), and autoencoders (AE). Reinforcement learning (RL) is another subdivision of machine learning, based on rewarding desired behaviors and/or punishing undesired ones [70]. Deep reinforcement learning (DRL) is a combination of artificial neural networks with reinforcement learning architectures, and has recently been employed in de novo drug design [71,72]. Such methods are expected to revolutionize the field of drug discovery since they are remarkably successful in other fields including recognition of speech [73], formal languages [74], video representations [75], music [76], and more.

## Section: 4. Artificial Intelligence in De Novo Drug Design › Deep Reinforcement Learning (DRL) in De Novo Drug Design

Among the range of AI subdivisions, DL has been very popular in mimicking human abilities of image recognition and natural language processing [77]. In addition, DL has been employed for the development of analysis approaches in data-driven fields such as biomedicine and healthcare [78,79]. In drug discovery, DL was initially employed for the development of QSAR to predict properties such as affinity, toxicity, etc. [80,81]. Advances in drug discovery DL methods led to the development of fully connected neural networks using molecular descriptors calculated directly from molecular structures [82]. De novo drug design using DRL, which combines artificial neural networks with reinforcement learning, is a breakthrough in the field of drug discovery [72,83]. DRL approaches in de novo drug design typically consist of a generative model (generator) and a de novo drug-design agent that uses reinforcement learning (Figure 4). For the generative model, a multilayer artificial neural network is used. Depending on the type of artificial network, the input layer might consist of SMILES or graphs of molecules [84]. SMILES represents a molecule as a sequence of characters corresponding to atoms and special characters denoting connectivity [85]. The neural network is then trained using tokens of pre-existing data such as known bioactive molecules for a specific biological target. Construction of output structures is a result of iterative learning and decision-making steps [83]. At each step, the model determines the optimal token from the vocabulary based on the generated sequence of previous steps. The de novo drug design agent is part of the reinforcement framework, and it could be conceptualized as a virtual robot that interacts with molecules and modifies them to improve their properties. The actions of the agent are controlled by the artificial neural network, also called the generator.

## Section: 5. Examples of DRL in De Novo Drug Design › 5.1. Recurrent Neural Networks (RNN)

A recurrent neural network (RNN) is an artificial neural network architecture that employs cyclic connections between neurons [86,87]. These connections enable an RNN to have an inner representation of the current state, which enables it to remember information from previous steps in a sequence. Because of that, an RNN is suitable for the analysis of sequential data such as text or molecules represented as a sequence of characters like SMILES. RNN works sequentially by processing one step at a time in a series of actions. RNN can learn from SMILES strings’ patterns and the molecules produced from the de novo molecule procedure are chemistry-driven.

RNN combined with reinforcement learning was successfully employed in the de novo drug design of novel molecular entities [88,89,90]. The first step of this method includes a fine-tuned RNN that is pre-trained using existing bioactive molecules from a database such as ChEMBL. Training of an RNN is generally performed through maximum likelihood estimations of the next token in a target sequence of given tokens from the previous steps [72]. Once the RNN has been trained on target sequences such as SMILES, it is then used to generate new sequences that follow the conditional probability distributions learned from the training set [72]. In the second step, a de novo drug-design agent is generated based on a policy that maps a state to the probability of each action taken. Based on a set of actions taken from states and the received rewards, the agent policy is improved to increase the expected return. Two approaches have been used in reinforcement learning to obtain a policy: policy-based RL in which a representation of the decision policy is explicitly built and kept in memory during learning, or a value-based RL where only a value function is stored while the policy is implicit. A task that has a clear endpoint is referred to as an episodic task, which in the case of de novo drug design, is the generation of a SMILES string for a novel molecular entity.

Several examples of DRL in de novo drug design that employed RNN were reported in the literature, including a model that was trained to generate sulfur-free molecules using augmented episodic likelihood [72]. Reinforcement Learning for Structural Evolution (ReLeaSE) is an application of DRL to the problem of designing chemical libraries with the desired physicochemical and biological properties [91]. This approach uses a special type of stack-augmented RNN that was successful in inferring algorithmic patterns. This implementation considers SMILES strings as sentences composed of characters used in SMILES notation. The objective of stack-RNN is to learn the hidden rules of forming sequences of letters that correspond to legitimate SMILES strings. SMILES strings are used for both generative and predictive phases of the method and these phases are integrated into a single workflow. A fragment-based DRL approach, based on an actor-citric model, for the automatic generation of molecules with improved properties, was developed using RNN and RL [92]. This model learns how to modify molecules to improve their properties by generating novel structures that are similar to existing bioactive compounds of a given target. Thus, this approach does not attempt to search the entire chemical space to find optimal candidate molecules; instead, it optimizes an existing lead compound by adding fragments.

A multi-objective evolutionary de novo drug-design approach was developed using RNN to generate novel molecules [93]. The best molecules were selected to retrain the network using transfer learning (TL). In TL, a model is trained on a source task and then retrained on a new related task called the target task [94]. TL has been proven to be efficient in improving the accuracy of models based on narrowly defined tasks. A deep learning methodology using a long short-term memory (LSTM) RNN was successfully employed in de novo drug design [95]. The first part of this study involved training an LSTM-based RNN model to generate libraries of valid SMILES strings with high accuracy. TL was then used to fine-tune the model by generating molecules that are structurally similar to drugs with known bioactivities against a particular biological target. This method was found to be successful in the early stages of drug discovery where there is a low amount of data available. The second part of this study involved the application of the generative model to fragment-based drug discovery by growing a library of leads starting from a known active fragment [95].

An interesting study demonstrated that molecular information, such as molecular descriptors, can be incorporated into a conditional RNN generative process [96]. The generation process of this approach was conditioned with properties calculated either directly from molecular structures or QSAR, such that the encoder part was no longer needed. The conditional seed successfully steered the focus of the RNN towards a particular subset of the chemical domain, such as bioactive compounds of a biological target. A novel way of assessing the focus of a probabilistic sequence generator was also achieved using negative log-likelihood plots. An RNN trained on large sets of molecules was employed to develop a data-driven de novo drug-design approach [89]. This study demonstrated that an RNN trained on SMILES strings of molecules can both learn the grammar required to generate valid SMILES and generate molecules with similar properties to the compounds used for the training of the RNN [97]. A recent study assessed bidirectional molecule generation with RNN, comparing three bidirectional strategies (novelty, chemical biological relevance, and scaffold diversity) to the unidirectional forward RNN approach for the computer-generated molecules with SMILES string generation [98].

## Section: 5. Examples of DRL in De Novo Drug Design › 5.2. Convolutional Neural Networks (CNN)

A convolutional neural network (CNN) is a type of artificial network consisting of altering, convolution, and pooling layers, which enables them to extract features automatically [99,100,101]. CNNs were extensively employed in image processing with great success by running a small window over the input feature vector at both training and test phases as a feature detector [77]. This process allows a CNN to learn various features of the input regardless of their absolute position within the input feature vector [99]. DeepScaffold is a comprehensive solution for scaffold-based de novo drug design that utilizes CNN and 2D graphs of molecular structures [102]. This method can generate molecules based on a wide spectrum of scaffold definitions including Bemis–Murcko scaffolds, cyclic skeletons, and scaffolds with specifications of side-chain properties. An advantage of this method is its ability to generalize the chemical rules of adding atoms and bonds to a given scaffold. The compounds generated by DeepScaffold were evaluated by molecular docking to their associated biological targets, and the results suggested that this approach could be effectively applied in drug discovery. DeepGraphMolGen is a multi-objective computational strategy for generating molecules with desirable properties using a graph CNN and reinforcement learning [103]. This strategy consists of property prediction and molecular generation in which molecules were represented as 2D graphs, since they are a more natural molecular representation than SMILES strings. Finally, a new framework for de novo drug design was proposed based on a graph generation model. The graph generator was designed to be suitable for the task of molecule generation using a simple decoding scheme and a graph convolutional architecture that is less computationally expensive [104].

## Section: 5. Examples of DRL in De Novo Drug Design › 5.3. Generative Adversarial Networks (GAN)

A generative adversarial network (GAN) is a special type of neural network model where two networks are trained simultaneously, with one focused on image generation and the other centered on discrimination [105,106,107]. The generator typically captures the distribution of true examples for new data example generation. The discriminator is usually a binary classifier, discriminating the generated examples from the true examples as accurately as possible. GANs have been found to be successful in image generation tasks, including text-to-image synthesis, super-resolution, and image-to-image translation [105]. An original deep neural network (DNN) architecture called a reinforced adversarial neural computer (RANC) was utilized for de novo drug design of novel small-molecule organic structures based on a GAN and reinforcement learning [108]. RANC uses a differentiable neural computer, a category of neural network with increased generation capabilities due to the addition of an explicit memory bank mitigating common problems found in adversarial settings, as the generator. RANC was able to generate structures that match the distributions of key chemical descriptors and the lengths of SMILES strings in the training dataset [108]. Adversarial threshold neural computer (ATNC) is another de novo drug-design approach based on a GAN architecture and reinforcement learning. This approach uses a differentiable neural computer as the generator and has a new specific block, called an adversarial threshold, which acts as a filter between the agent (generator) and the environment (discriminator and objective reward factions) [109]. To generate more diverse molecules, a new objective reward function, named internal diversity, clustering (IDC) was employed [109]. LatentGAN is a novel deep-learning architecture which combines an autoencoder and a GAN for de novo drug design [110]. The utility of this method was examined using two scenarios: the first to generate random drug-like compounds and the second to generate target-biased compounds, with promising results in both cases. This method generates molecules that differ from those obtained using RNN-based generative models, indicating that these two approaches are complementary [110].

## Section: 5. Examples of DRL in De Novo Drug Design › 5.4. Autoencoders (AE) › 5.4.1. Variational Autoencoder (VAE)

A variational autoencoder (VAE) is a stochastic variational inference and learning algorithm that is extensively used to represent high-dimensional complex data via a low-dimensional latent space learned in an unsupervised manner using encoders and decoders [111]. De novo drug-design approaches using VAE include the development of a method to convert discrete representations of molecules to a multidimensional continuous representation [112]. In this study, a DNN was trained on hundreds of thousands of existing chemical structures to construct three coupled functions: an encoder, a decoder, and a predictor. The encoder converts the discrete representation of a molecule into a real-valued continuous vector, and the decoder converts these continuous vectors back into discrete molecular representations. The predictor estimates chemical properties from the latent continuous vector representation of the molecules. This model allowed efficient exploration of the chemical space through the development of optimized chemical structures. A shape-based generative approach for de novo drug design was developed using CNN to generate novel molecules from a seed compound, its three-dimensional shape, and its pharmacophoric features [113]. A VAE is used to perturb the 3D representation of a compound, followed by a system of convolutional and recurrent neural networks that generate a sequence of SMILES tokens. The generative design of novel scaffolds and functional groups performed by this method could cover unexplored regions of the chemical space that still possess lead-like properties. A conditional VAE was employed to develop a new molecular design strategy that directly produces molecules with the desired target properties [114]. This method controls multiple target properties by imposing them onto a condition vector. The authors demonstrated that it was possible to generate drug-like molecules with specific values for the five target properties (molecular weight (MW), octanol–water partition coefficient (LogP), number of hydrogen bond donors and acceptors (HBD, HBA) and topological polar surface area (TPSA)) within an error range of 10%. In addition, the authors were able to selectively control LogP without changing the other molecular properties and to increase a specific property beyond the range of the training set [114].

## Section: 5. Examples of DRL in De Novo Drug Design › 5.4. Autoencoders (AE) › 5.4.2. Sequence-to-Sequence Autoencoder (seq2seq AE)

A sequence-to-sequence autoencoder (seq2seq AE) is an artificial network architecture that maps an input sequence to a fixed-sized vector in the latent space using a gated recurrent unit (GRU) [115] or an LSTM network [116], and then maps the vector to a target sequence with another GRU or LSTM network [117]. Thus, the latent vector is an intermediate representation containing the “meaning” of the input sequence. In the case of de novo drug design, the input and output sequences are both SMILES strings [118]. A generative network complex was successful in generating new drug-like molecules based on multi-property optimization via a gradient descent in the latent space of an autoencoder [118]. In this approach, both multiple chemical properties and similarity scores were optimized to generate drug-like molecules with the desired properties. The predictions of this method were validated using independent two-dimensional predictors based on molecular fingerprints. Finally, the method was utilized to generate a large number of new BACE1 inhibitors, as well as thousands of novel alternative drug candidates for eight existing drugs currently on the market, including Ceritinib, Ribociclib, Acalabrutinib, Idelalisib, Dabrafenib, Macimorelin, Enzalutamide, and Panobinostat [118]. A seq2seq AE was also used to develop a de novo drug-design approach using SMILES strings [119]. Using this method, the extent to which translation between different chemical representations influences the latent space similarity to the SMILES strings or circular fingerprints was explored. It was found that training a seq2seq hetero-encoder based on an RNN with LSTM cells to predict different enumerated SMILES strings from the same canonical SMILES string gives the largest similarity between latent space distance and molecular similarity measured as circular fingerprints similarity [119].

## Section: 5. Examples of DRL in De Novo Drug Design › 5.4. Autoencoders (AE) › 5.4.3. Adversarial Autoencoder (AAE)

An adversarial autoencoder (AAE) is a probabilistic autoencoder that uses a GAN to perform variational inference by matching the aggregated posterior of the hidden code vector of an autoencoder with an arbitrary prior distribution [120]. An AAE that contains both a generator and a discriminator was trained on a set of molecules with anti-tumor growth activity [121]. The generated model was utilized to create molecules with the desired properties in the form of fingerprints. A close examination of the newly generated molecules showed that the newly created molecular fingerprints matched the structure of highly effective anticancer drugs. An improvement in this architecture led to the development of druGan, an AAE that incorporated additional molecular properties such as solubility and allowed the generation of molecules with different chemical structures [122]. druGan showed better performance in terms of feature extraction, ability to generate molecules, and reconstruction error compared to its predecessor AAE.

## Section: 6. Particle Swarm Optimization for De Novo Drug Design

Particle swarm optimization (PSO) is a stochastic optimization technique inspired by swarm intelligence, which aims to find an optimal point in a search space defined by an objective function. The particle swarm consists of individual agents (particles) that optimize the given problem in parallel by making use of knowledge gained during its search. Additionally, particles constantly exchange information about optimization successes, and thus influence their direction of movement in the search space. During the search, promising solutions are identified in the region that attracts most of the particles. PSO has been successfully applied in the field of drug design for optimization of the molecular properties of compounds with the desired biological properties. For example, Hartenfeller et al. developed COLIBREE, an algorithm for fragment-based molecular de novo drug design based on PSO optimization [123]. In their approach, PSO guides the process of combinatorial de novo drug design. The constructed molecules follow a fixed build-up scheme with three main elements: (1) a user-defined molecular scaffold, which is used as the starting point for the molecular design; (2) building blocks which are molecular fragments derived by pseudo-retrosynthesis from known bioactive molecules; (3) linkers that represent substructures connecting two building blocks and link the building blocks to the scaffold. The whole design process, including the selection of linkers, building blocks, and structure assembly, is controlled by PSO, where each particle of the swarm identifies new candidate compounds. These compounds are evaluated by a ligand similarity-based fitness function to measure how far the new drug is from a reference set of drugs in a topological atom-pair description space. The particles in the swarm gain knowledge during the process, which is incorporated into the choice of new building blocks and linkers until a final optimal solution is reached.

Winter et al. developed a computational methodology that integrates PSO with in silico prediction of molecular properties such as biological activity and pharmacokinetics [124]. They used a DNN to learn a compressed latent space representation of compounds from 75 million chemicals. They defined a fitness function for the identification of the best candidate drug as a combination of structure–activity-relationship knowledge (for example, fixed ranges for molecular weight, and number of hydrogen-bonds.), a set of targets that should be hit by the compound, and pharmacokinetics-related properties. The PSO is used to search the compounds’ latent space and identify the optimal candidate drug. The main advantage of this approach is that the optimization can be performed using multiple objective functions simultaneously. However, the authors pointed out that this methodology has to be used in combination with constraints to the part of the chemical space that can be modeled within a reasonable applicability domain.

## Section: 7. Evaluation Criteria

The design of new compounds is only the first step in the development of new drugs and is followed by an iterative loop of synthesis, analysis, and molecular optimization. However, not every generated compound can undergo this resource-intensive process. Therefore, it is necessary to focus the efforts on a few promising de novo generated compounds. For a compound to be relevant, it has to reach a balance between several contrasting aspects, which include the right amount of novelty: it should not be too similar to known drugs but also not too different so as to be completely unpredictable; it has to be stable and synthesizable; it should be feasible to produce; and it should score highly in the prediction of its desired properties (for example, target affinity and drug-likeness).

## Section: 7. Evaluation Criteria › 7.1. Diversity and Novelty

Generative models usually produce a population of chemical compounds on the order of hundreds or thousands of generated samples. Of course, not every compound will be unique; inevitably, some generated compounds will share characteristics to a lesser or greater degree, and some others will be more similar to the training data, or the reference database, depending on the specific method. It is especially important to test the capability of producing a wide variety of new structures when working with deep generative models, as failure may happen where the generated samples lack variety (such as mode collapse in GANs [125]) or the generated samples resemble the mean of the training distribution too much (blurry samples produced by AE-based models). To explore the similarity of a group of generated compounds against the reference set, several similarity scores have been proposed depending on the representation format of the molecules. The edit (or levenshtein) distance can be used to evaluate how different two SMILES strings are. If the molecules are represented as substructure fingerprints, such as extended-connectivity circular fingerprints (ECFP) or molecular access system (MACCS) keys, the Tanimoto and Dice distances can be used. Finally, several graph similarity measures (or graph kernels) have been proposed for evaluating the similarity of molecules represented by graphs, such as the random walk kernel or the convolutional kernel [126].

Due to the novelty of these methods, standardized approaches do not yet exist when it comes to specific workflows and validation guidelines for computer-assisted drug development, such as, for example, the Organization for Economic Cooperation and Development (OECD) rules for the validation of QSAR models [127]. Similarly, no guidelines currently exist on the acceptable ranges of evaluation metrics. This means that the selection of good evaluation thresholds for new generated drugs is subjective, experiential, and domain-specific and the decision is left to the human operator. As discussed in the next session, a current workaround would be the application of well-established ADMET and QSAR approaches, prior to synthesis and in vitro testing, for assessing the relevance of the computer-designed molecules, as also stated by Muratov et al. [128]. In any case, further work in this direction is required to identify specific criteria that computer-generated compounds must fulfill, even if these are still subject to the same in vivo and in vitro tests of a usual drug-discovery process.

## Section: 7. Evaluation Criteria › 7.2. Desired Properties

Virtually all the generative approaches rely on an evaluation mechanism that rewards some aspects of the generated compounds, such as target affinity or desired bioactivity. However, there are other “side” properties that, during the generating process, evolve in a substantially unconstrained manner. Moreover, these side properties may represent the difference between the success and failure of the development stages following the design and synthesis of a candidate drug molecule. Examples of undesired side properties include low drug-likeness scores [129] and undesired binding affinity with other complexes, which may reduce the overall efficacy or even cause adverse effects and cellular toxicity. Thus, in order to focus the synthesis efforts on the most promising generated compounds, a prioritization mechanism is often employed. The easiest approach is filtering and/or ranking of the generated molecules according to predicted drug-likeness, first introduced by Lipinski et al. [45], or ADMET properties [130], such as the solubility of the molecule, permeability of the brain–blood barrier, and affinity to transport proteins [126].

## Section: 7. Evaluation Criteria › 7.3. Synthetic Feasibility

Another concern is the actual capability of synthesizing the most promising de novo generated compounds for further evaluation and optimization [6,18,22,131,132]. Left unconstrained, generative models may propose overly complex or even impossible-to-produce compounds. The generative process can be biased by penalizing the complexity of the molecules, but at the expense of reduced efficacy [133]. Several evaluation functions have been proposed to estimate the complexity of a generated compound, like the synthetic accessibility (SA) score, which takes into account the presence of non-standard structural features, such as large rings, non-standard ring fusions, stereocomplexity, and molecule size [131], and the synthetic complexity (SC) score, which was trained using a reaction corpus based on 12 million reactions from the Reaxys database to impose a pairwise inequality constraint to ensure that reaction products are more synthetically complex than their corresponding reactants [134]. In addition to filtering the results of the learning process, the ability to generate realistic compounds can also be enforced directly at the level of the generation process. For example, the SPROUT algorithm assigns a different penalty to each fragment while assembling the compounds based on a database of fragments with known complexity [135]. The requirement of synthetic feasibility can be used as an inductive bias while training a deep generative model to only design synthetically feasible compounds. For example, MoleculeCHEF incorporates knowledge of basic reactants and a chemical reaction prediction model, and generates molecules through a series of simulated reactions [135]. Thus, each generated sample is expressed as a bag of base reactants and a “recipe” of chemically stable reactions, which are supposed to produce the target compound.

## Section: 8. Bridging Toxicogenomics and Molecular Design

Toxicogenomics is the field of study that links the safety assessment of chemicals to the underlying biological mechanisms [136,137]. One important aspect tackled by toxicogenomics is the characterization of the mechanism-of-action (MOA) of a compound, represented as the set of all molecular alterations induced by the exposure of an organism (human) to it. Elucidation of the MOA allows understanding of the chain of biological events (such as immune system activation, changes in the metabolism, and effects to the cell cycle) triggered by a specific chemical (drug) exposure, which will lead to a phenotypic endpoint (for example, toxicity). Merging the cheminformatic and toxicogenomic methods, in combination with DL techniques, would facilitate and speed up the development of novel approaches where chemicals are designed de novo to exert specific molecular alterations and phenotypic effects.

Most of the approaches proposed to date are chemocentric, but new methodologies that bridge toxicogenomics and molecular design are starting to emerge. For example, Mendez-Lucio et al. developed a DL model based on a GAN whose training was conditioned by gene expression data [138]. In a conditional generative model, target properties for each compound are incorporated into the training and generative phases, in addition to the compound chemical representation. Thus, conditional models learn a latent representation space, which is a good representation of the compounds and of the conditional variables. This makes the models useful both for reconstruction and predictive tasks. By using this kind of approach, the trained model can be used to generate new compounds with a predicted transcriptomic alteration similar to the one required in the input. This approach, compared with more traditional similarity search-based approaches, has the main advantage of not being limited to the initial pool of compounds for which the gene expression signature is measured. Indeed, generative models can also help overcome the limitation of the chemical space by generating new compounds tailored to match the query gene expression signature. However, further work is required to assess the optimal biological models in which to generate the gene expression signatures, especially in the light of the variability of drug responses in cell lines, and the well-known limitations (relative advantages and disadvantages) of utilizing cell lines versus primary cells.

## Section: 9. De Novo Drug Design for COVID-19

The coronavirus SARS-CoV-2 is responsible for the ongoing COVID-19 pandemic. The novel nature of this virus urgently requires the development of efficient drug repositioning and de novo drug-design approaches. The scientific community has been actively working in this field and some of the well-known AI-based methods for drug design have been applied to generate new compounds [139,140,141]. For example, Ton et al. developed a novel DL platform, called deep docking, that provides fast prediction of docking scores for structure-based virtual screening of billions of molecules simultaneously [142]. They displayed their application by applying the deep docking method to more than one billion compounds from the ZINC15 library and found 1000 potential ligands for the SARS-CoV-2 main protease (Mpro) protein. These candidate inhibitors are chemically diverse and have superior docking scores compared to known protease inhibitors.

Chenthamarakshan et al. have developed a new method, called CogMol, for target-specific drug design for COVID-19 using deep generative models [143]. They first trained a VAE to learn the SMILES representations of the molecules. Then, they used a pre-trained protein sequence embedding from 24 million Uniprot protein sequences to train a protein-molecule binding affinity regressor that they used to guide the generation of new molecules. Finally, CogMol is empowered with an in silico screening protocol for the generated molecules, which accounts for factors such as the toxicity prediction of a clinical endpoint and the synthetic feasibility, and performs docking calculations to estimate the binding of the generated molecules to target proteins. They used the CogMol framework to generate candidate molecules to bind three relevant targets of the SARS-CoV-2 spike protein with high affinity. From the generated drugs that passed the in vitro screening filters less than 20 compounds, for each of the three protein targets considered, match an existing SMILES in PubChem. Among them are Plasmepsin-2 and Plasmepsin-4 inhibitor, ACE-2 inhibitors, and drugs approved for skin diseases and pneumonia. Since these drugs have already been approved for specific uses, it should be faster to have them approved for the treatment of COVID-19.

A different approach was applied by Tang et al. [144], who developed an advanced deep Q-learning network with fragmented-based drug design for generating potential lead compounds targeting the SARS-CoV-2 3C-like Mpro. Their approach starts from a molecular fragment library built from a starting set of 284 molecules knowing to inhibit the SARS-CoV-2 3C-like Mpro. Next, they applied an advanced deep Q-learning network, which combines meaningful molecular fragments, for generating new candidate compounds. They generated 4922 unique valid structures. Among these, 47 were selected by their reward function (for example, how the agent “ought” to behave) and further evaluated with docking and covalent docking studies [144].

Bai et al. developed a new tool for 3D drug design of protein targets, called MolAICal [145]. This tool combines deep generative models based on Wasserstein GAN (WGAN) and virtual screening to generate new compounds starting from a library of fragments from US FDA-approved drugs. They used MolAICal to generate new drugs targeting the membrane protein glucagon receptor (GCGR) and the non-membrane protein SARS-CoV-2 Mpro. They used 21,064 fragments of FDA-approved drugs extracted from the e-Drug3D database and 1,060,000 drug-like ligands obtained from the ZINC database, and showed that MolAICal can generate various ligands with high 3D structural similarity to the crystal ligand of GCGR or SARS-CoV-2 Mpro.

## Section: 10. Building Community and Regulatory Acceptance of DL Methods for De Novo Drug Design

These COVID-19 examples demonstrate the power of DL methods for de novo drug design and are likely to further accelerate the drug discovery pipeline and the repurposing of existing drugs against alternative pathologies in the coming decade. However, since the development of DL-based de novo drug design approaches is still at an early stage, experimental validation of its effectiveness in drug discovery is crucial for the continuous improvement of these methods and to support their widespread uptake into medicinal chemistry practice and drug regulation. A recent report from the European Medicines Agency (EMA) and Heads of Medical Agencies (HMA) on regulatory challenges from big data suggested that “Algorithm code should be more transparent (feature selection, code, original data set) and available for targeted review by regulators. Outcomes of, and changes to, algorithm use (safety and efficacy) need to be subject to post-marketing surveillance mechanisms, just like it is done today to monitor drug safety after marketing authorization” [146]. A first key step is complete documentation of the DL models and the underpinning datasets, as is the case, for example, for QSAR models, which are documented using the QSAR model report format (QMRF), a harmonized template for summarizing and reporting key information on QSAR models including the results of any validation studies, structured according to the OECD QSAR validation principles. QMRFs are an essential part of the validation and acceptance of QSARs for use in regulatory decision making, and thus, similar approaches for DL models would be an essential next step. While the OECD have not yet developed specific guidance for DL models, they have published a set of values-based principles for the development of AI methods [147] and position papers on using AI to help combat COVID-19 [148], and on identifying and measuring developments in AI [149].

Sharing of tools and approaches, via an open innovation model, is another essential approach to achieving the promise of DL models for de novo drug design, as sharing the training set and workflow can help with understanding the computational workflow and gaining users’ trust. While this may not be entirely possible, due to privacy and policy constraints, a workaround could be the release of a “training subset” that would allow users to comprehend the model in question [150]. This can be achieved by constructing a boundary tree, based on selected training data, which is able to closely approximate the trained model. Traversing the datapoints in the tree can provide users with significantly better understanding of the model and increased trust during model sharing [150]. While some of the challenges for DL applications in medicine are related to patient data confidentiality and the need for certainty where patient care options and treatment regimens are being decided, many of the open innovation solutions currently being developed are likely applicable. First efforts towards the establishment of a DL model sharing architecture and marketplace have been demonstrated, to support the sharing of pretrained models across different ML libraries and run-time environments, with a focus on model reusability, rather than model development. In the future, standards or guidelines for model input/output format definition, as well as data mapping rules and model validation procedures, will be implemented [151].

## Section: 11. Concluding Remarks

Since 1960, many forms of computer-aided drug design have generated a positive impact in drug discovery. Among them, structure-based and ligand-based conventional de novo drug design using evolutionary algorithms was employed for the development of novel chemical entities. AI approaches including DRL have been successfully used in the development of novel de novo drug-design approaches. Such methods include DRL using artificial neural networks including recurrent neural networks, convolutional neural networks, generative adversarial networks, and autoencoders. These methods are also used in other computer-aided drug-design approaches and, based on the promising acquired results, are expected to revolutionize the drug discovery and development process, as well as to address some of the main challenges during the early stages of drug discovery including cost and time demands, by developing in silico approaches for de novo drug design, synthesis prediction, and bioactivity prediction. Indeed, as demonstrated herein, the utility of DL-based de novo drug design for supporting drug repurposing for COVID-19 treatment has been impressive and will likely accelerate adoption of the approaches more broadly across the medical domain. The discovery of a new drug is a complex, expensive, and time-consuming process. The traditional drug development pipeline needs 12 years and 2.7 billion USD on average. The use of CADD algorithms and tools could reduce drug development costs and time significantly with conservative estimates suggesting AI pipelines require less than 1/3 of the current time and cost [152,153]. Examples of DRL-based de novo drug design include the development of adenosine A2A receptor ligands [83], rapid identification of potent DDR1 kinase inhibitors [154], and the development of a large number of new BACE1 inhibitors, which is an enzyme involved in Alzheimer’s disease [118].

Standard de novo design methods rely on the interactions with the active site of a biological target or the pharmacophores of a known active binder, and they are limited by our partial understanding of receptor–ligand interactions. DRL-based de novo drug-design approaches were developed with the goal of overcoming the limitations of existing conventional approaches. These approaches are data-driven, flexible, versatile, and can utilize a large amount of data from the scientific literature and databases. Besides the design of novel chemical entities, synthetic accessibility is also important in de novo drug design. Conventional methods partially consider the synthetic feasibility of the generated molecules based on a set of synthetic rules that are limited in a small number of retrosynthetic organic reactions [22]. DL methods allowed the development of template-free self-corrected retrosynthetic predictors to predict retrosynthesis using transformer neural networks [155].

Although the development of DL approaches in drug discovery has just begun, there is no doubt that the benefits are tremendous. However, there is still much to be done, since recent property optimization studies are focused on easily optimizable properties, such as drug-likeness [156], and efforts to integrate detailed understanding of modes of action and toxicogenomics are only beginning. Key challenges remain in terms of building community and regulatory acceptance of deep learning models, with documentation and sharing of training datasets, development of standards for model validation and model-sharing platforms as essential steps towards achieving this.


---

# Approval of artificial intelligence and machine learning-based medical devices in the USA and Europe (2015-20): a comparative analysis

- **Authors:** Urs J Muehlematter, Paola Daniore, Kerstin N Vokinger
- **Issuer:** The Lancet. Digital health
- **Type:** Scientific article
- **Published:** 2021-01-18
- **Language:** en
- **DOI:** 10.1016/s2589-7500(20)30292-2
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33478929/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

There has been a surge of interest in artificial intelligence and machine learning (AI/ML)-based medical devices. However, it is poorly understood how and which AI/ML-based medical devices have been approved in the USA and Europe. We searched governmental and non-governmental databases to identify 222 devices approved in the USA and 240 devices in Europe. The number of approved AI/ML-based devices has increased substantially since 2015, with many being approved for use in radiology. However, few were qualified as high-risk devices. Of the 124 AI/ML-based devices commonly approved in the USA and Europe, 80 were first approved in Europe. One possible reason for approval in Europe before the USA might be the potentially relatively less rigorous evaluation of medical devices in Europe. The substantial number of approved devices highlight the need to ensure rigorous regulation of these devices. Currently, there is no specific regulatory pathway for AI/ML-based medical devices in the USA or Europe. We recommend more transparency on how devices are regulated and approved to enable and improve public trust, efficacy, safety, and quality of AI/ML-based medical devices. A comprehensive, publicly accessible database with device details for Conformité Européene (CE)-marked medical devices in Europe and US Food and Drug Administration approved devices is needed.


---

# Artificial intelligence in drug discovery: recent advances and future perspectives

- **Authors:** José Jiménez-Luna, Francesca Grisoni, Nils Weskamp, Gisbert Schneider
- **Issuer:** Expert opinion on drug discovery
- **Type:** Scientific article
- **Published:** 2021-04-02
- **Language:** en
- **DOI:** 10.1080/17460441.2021.1909567
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33779453/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Introduction: Artificial intelligence (AI) has inspired computer-aided drug discovery. The widespread adoption of machine learning, in particular deep learning, in multiple scientific disciplines, and the advances in computing hardware and software, among other factors, continue to fuel this development. Much of the initial skepticism regarding applications of AI in pharmaceutical discovery has started to vanish, consequently benefitting medicinal chemistry.Areas covered: The current status of AI in chemoinformatics is reviewed. The topics discussed herein include quantitative structure-activity/property relationship and structure-based modeling, de novo molecular design, and chemical synthesis prediction. Advantages and limitations of current deep learning applications are highlighted, together with a perspective on next-generation AI for drug discovery.Expert opinion: Deep learning-based approaches have only begun to address some fundamental problems in drug discovery. Certain methodological advances, such as message-passing models, spatial-symmetry-preserving networks, hybrid de novo design, and other innovative machine learning paradigms, will likely become commonplace and help address some of the most challenging questions. Open data sharing and model development will play a central role in the advancement of drug discovery with AI.


---

# Artificial intelligence in drug discovery: what is realistic, what are illusions? Part 2: a discussion of chemical and biological data

- **Authors:** Andreas Bender, Isidro Cortes-Ciriano
- **Issuer:** Drug discovery today
- **Type:** Scientific article
- **Published:** 2021-01-27
- **Language:** en
- **DOI:** 10.1016/j.drudis.2020.11.037
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33508423/
- **Licence:** CC-BY

## Section: Abstract

Graphical abstract

## Section: Introduction: data in image recognition, speech classification, and drug discovery

AI has transformed many fields, probably most notably those of image and speech recognition, leading to automated passport controls and ‘virtual assistants’ (with related implications also to e.g., privacy). Focusing on the technological side from here onwards, a possible starting point of more recent developments from the image recognition side could be the 2010 paper by Schmidhuber and colleagues [1] on recognizing handwritten characters. The field rose to prominence with the 2012 NIPS paper on AlexNet [2], which successfully utilized deep neural networks for image classification. This progress was dependent not only on particular choices made by the authors [such as using successive convolution and pooling layers, using Rectified Linear (ReLU) units, data augmentation and dropout layers [3]], but also the large amounts of labeled data available from the ImageNet repository [4], as well as the use of Graphical Processing Units (GPUs). When it came to speech recognition, work such as Long Short Term Memory (LSTM) by Hochreiter and colleagues [5] paved the way for recent practical implementations and applications, such as in mobile devices and virtual assistants.

As it became clear in particular in the context of ‘deep learning’, the data available for a learning task at hand are crucial, which refers to the amount of data available, as well as their distribution (and inherent biases). The amount of data available in different domains is summarized in Table 1, comprising image data, data compiled from autonomous driving (here by Tesla), and data sets that are used in the chemical, biological, and drug discovery context 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20. The amount of data available in different domains differs hugely, from only hundreds of data points with in vivo annotations (such as in case of drugs annotated with their potential to induce drug-induced liver injury, DILI) to Zettabytes (1021 bytes) available per year for the fleet of cars operated by Tesla. The latter is also similar to the amount of data generated by the world’s largest radiotelescope currently under development, the Square Kilometre Array, with telescopes located in Australia and South Africa. (Astronomy has long been leading the field when it comes to handling truly big data.) The amount of chemical and biological data available to use is comparatively small, in the context of other domains.Table 1Number of data points and/or sizes of data sets available in different domains, namely for images, self-driving cars, astronomy, and in the chemical, biological, and drug discovery domainsaTable 1DomainNumber of entriesSize of data set (bytes)RefsData sets of images, from autonomous cars and astronomyImage Net14 × 106[2]Tencent image data set20 × 106[6]Tesla (video/sensor-derived information)1–450 TB/day/user (assuming 2TB/day/user and 106 users this means ∼2 EB/day, or ∼1 ZB/year)7, 8Square Kilometre Array (world’s largest radiotelescope)∼100 TB/s (∼100 EB/year)[9]Data sets in drug discoveryEMBL: raw data across databases273 PB[10]REAL database of ‘drug-like molecules’1.2 × 109[11]ZINC database release 15 (purchasable compounds)∼750 × 106[12]ChEMBL: compounds with bioactivity annotations (Release 26)16 × 10612 GB (Oracle tablespace)[13]Marketed Drugs (DrugBank v5.1.5)13 548 entries (2626 approved small molecules, 1372 approved biologics, 131 nutraceuticals, >6363 experimental drugs)[14]DrugMatrix compound with organ-based gene expression data627[15]Drugs with DILI annotations1036[16]SIDER (drugs with adverse effect annotations)1430 drugs (139 756 drug–adverse effect pairs)[17]Open Targets Platform (as of April 2020)8 462 444 associations spanning 13 818 diseases and 27 700 targets[18]Tox21 screening dataCa 10 000 molecules tested for 72 endpoints (∼50 × 106 data points in total)[19]Registry of Toxic Effects of Chemical Substances (RTECS)Data for ‘more than 160 000 chemicals’[20]aTB, terabytes or 1012 bytes; PB, petabytes or 1015 bytes; EB, exabytes or 1018 bytes; ZB, zettabytes or 1021 bytes.

Besides the sheer amounts of data available, the ability to represent it in a computer amenable form is also vital, as is the ability to label data with relevant endpoints for data mining. A comparison between analyzing images and the domains of chemistry and biology is given in Fig. 1 for this purpose, which assumes the application of supervised algorithms in this case, where an output label for training needs to be assigned.Figure 1Illustration of the differences between image recognition and classification tasks in the chemical and biological drug discovery domains. When classifying images (and also speech), the model architecture and representation of object are more integrated than when using chemical and biological data, and labels can be assigned relatively less ambiguously. In the chemical domain, the best representation of an object is generally unknown (different aspects of a chemical are responsible for different types of effect, and some might be related to the functional group, others related to surface properties, etc.), whereas, in the biological domain, it is not clear which type of information provides information related to which endpoint. Common to the chemical and biological domains is that labels depend to a large extent on the set-up of a particular experiment, even if the same thing is measured ‘in principle’.Figure 1

In the image domain, an object is usually represented by pixels (although other representations could be used [21]), which have a spatial arrangement relative to each other. Hence, objects can be visually distinguished by a computer (in the same way as by humans) insofar as they have different pixel values and, therefore, shapes or colours. This spatial arrangement of pixels is vital for image recognition using convolutional neural networks (CNNs), because convolutional layers detect object features such as edges (or more complex ones, such as faces, humans, etc.) based on particular filters that are used in the network architecture to take relative distances of the elements within images into account. In case of images, aspects of model choice also exist (with respect to both the choice of the underlying model architecture and its hyperparameters), but what is common is the agreement to use pixels as an input for such a model, which limits the possible model space. Equally, the output label of an image-based learning task can generally be assigned based entirely on the content of an image (there is no external context that needs to be taken into account) and with certainty (during human labeling; meaning either an image contains an object or not, so there is a ground truth that can be assigned unambiguously). Exceptions to this do exist, such as an image being part of a video so that labeling depends on context, objects that are hard to spot, and annotation errors in image databases. However, generally objects can be annotated based on the information visible in the image frame; there is generally little outside information that determines its labels. For image-based classification, we have a neural network available where its structure (such as convolutional layers) follows the requirements of the description of the object (its shape), and where we are able to assign labels for training generally unambiguously and on a large scale (see Table 1 for quantitative information). Analogous considerations apply to the application of recurrent neural networks (RNNs) to speech recognition (where changes of amplitude in the time domain can be appropriately captured by the structure of the network), as well as other applications where both the temporal domain and the context of the signal need to be taken into account 22, 23.

By contrast, in the chemical and biological domain, this situation of how to represent information to the computer is rather different, as shown in Fig. 1 in the middle row (see also a previous companion article for further discussions of domain differences [24]). In the chemical domain, apart from different numbers of data points present to other domains (Table 1), there are ∼3000 25, 26 known predefined descriptors, so it is by no means clear which description captures most relevant information. Some molecular properties are defined by local features (e.g., hydrogen bonds or charges), whereas others are defined by distributions of properties across the molecular surface (e.g., lipophilicity), whereas again others depend on external context (e.g., binding to a receptor, which is spatially defined, and depends on a complex balance of enthalpic and entropic factors [27]). Hence, one can choose to represent molecules as, for example, graphs, surfaces, bioactivity profiles, or using their physicochemical properties (among others). There is no lack of representations available [25]; there is only limited understanding of which representations that are predictive of the molecular property endpoint one considers in a given situation. Generally speaking, we do not know what matters about a structure for a given effect.

Given the large amount of recent work in the area of representing molecules, the representation of a molecular structure for exchanging information about its connectivity has a fundamentally different purpose from its representation for model generation purposes. The connectivity table (be it in a graph representation or, for example, in the SMILES format of a molecule) represents which bonds are present in a molecule, between which atoms. However, given that molecules are a dynamic entity (with respect to conformations, tautomerism, etc.) that exist in 3D, this representation does not capture in all cases its properties relevant for model generation. For example, a connectivity table/SMILES will not capture aspects such as the boat/chair inversion of cyclohexane (because connectivity remains identical); neither does it represent more complex stereochemistry (such as axial chirality); it can only properly represent two-electron bonds (and not, for example, three-centre-two-electron bonds); it does not capture the directionality of, for example, hydrogen bonds (and, hence, the discrimination between intramolecular interactions, and those that are accessible to interaction partners, which is crucial for aspects such as solubility); and so on. Thus, this type of information useful for exchanging the connectivity of a molecule (but which became apparent, does not cover all aspects of structural information either) needs to be clearly distinguished from a representation useful for model generation. In case of the latter, relevant properties are represented as such in the first place (such as pharmacophoric points relevant for interaction with a receptor and, hence, where external knowledge is used for their derivation, such as discussed earlier), and in this particular representation (which needs expert input in the first place!); hence, fewer data points are required for model generation. Given that data sets available for model generation are (and will be) always small compared with the size of chemical space, the requirement for suitable representations will stay with us for some time to come; that is, learned representations will probably be (and become) more useful in more data-rich areas, whereas expert-chosen representations will probably remain more useful in more data-sparse areas. In recent years, there has been some cross-over between representations that were intended to be used for exchange of structures and those used for model generation of course. In particular, use of representations used to convey connectivity of structures has been used for model generation; and this is not necessarily a bad thing either (after all, for example, MACCS keys were originally intended for cataloguing structures, but show remarkable performance in virtual screening settings, etc.) [28]. However, the above examples of limitations should be mentally distinguished, and one needs to be aware what the primary purpose of a given representation is.

In the context of recent studies, work on the ‘Molecular Transformer’ [29] has led to numerical improvements with respect to the prediction of the reaction outcome of chemical reactions by using SMILES representations of structures. Thus, given the numerical improvements, one can conclude that the use of connectivity table-derived descriptors appears to be justified empirically, because aspects such as axial chirality (one of the limitations of a SMILES/connectivity table representation) is not the primary problem we are currently confronted with. Other developments in the area of the representation of molecules have heavily focused on ‘learned representations’(e.g., 30, 31; reviewed in 32, 33). These approaches generally assign properties to the connectivity representation of a molecule, convolute those assignments, and, hence, tailor a descriptor to the particular endpoint that the model is meant to learn. In some publications 30, 31, this type of descriptor outperforms others with respect to the prediction of properties, where the dependence on sufficiently large data sets also becomes clear 32, 33, not replacing other methods with respect to every endpoint. Although no final statement shall be made here regarding the practical utility of a particular representation, the area is currently still under heavy development; it can be summarized here that endpoints can only be modeled in a meaningful way in this way where sufficient data for a relevant endpoint are available to truly learn representations and that in many cases, compared with the size of chemical space, this is not the case currently. Also, it would be necessary for performance evaluation to be performed in a way that retrospective performance translates to prospective performance, which is simply difficult with existing data sets that are often small and biased in nature (because of the heavy presence of analogs). In this regard, graph-based descriptors are naturally favored by data sets with analog bias, which makes the estimation of true prospective performance still difficult (see part 1 [24] and http://www.drugdiscovery.net/HowToLie for a more detailed discussion of model validation aspects, and the often limited utility of proxy data for the in vivo situation).

Maybe surprisingly, even (image-)matrix-based representations of molecules 34, 35, 36 perform surprisingly well, despite being far away from any chemically meaningful representation of a molecule. It is not too far-fetched to conclude that we do not understand which molecular features really matter in many cases. Hence, it is not trivial to represent a molecule to the computer for learning in the first instance, because the representation that conveys relevant information depends on the endpoint being modeled. Second, the choice of a machine-learning (ML) model is subjective and, hence, the assumption of the underlying functional form of linking molecular features to a property: for example, are features additive or do they behave in other ways? For empirically determining such relationships from the data, in most cases only insufficient amounts of data are available, given the size of chemical space and the limited data at hand (Table 1). Finally, labels in the chemical domain are very much dependent on context: is a compound toxic in the liver? This depends on dose, and the biological system a compound is tested in; or, if in the clinic, the particular individual who takes a drug. (What is the age, sex, is there any co-medication, etc.?) Is a certain nitrogen protonated, or not? This depends on the particular protein it binds to, and its dielectricity constants in the binding site (which might also change dynamically), as well as the set-up of the assay chosen (where the number of parameters is large). Even supposedly ‘simple’ molecular properties, such molecular solubility, depend heavily on the particular way one attempts to measure them [37]), as well as the particular solid it is in (amorphous, in a particular crystalline form, etc.), without even requiring information about the involvement of any biological endpoints when labeling molecules with a property. All of those aspects are not contained in the structure itself and, for many endpoints, many ways exist to measure them. In other words, the label ‘depends’, it is not defined entirely by compound structure. Hence, we are also in principle not able to label our data unambiguously. Therefore, the description of the system, devising a model, and labeling data represent problems in the chemical domain.

Similar considerations apply to modeling biological data (bottom row of Fig. 1), and probably even on a larger scale: which biological ‘descriptor’ is relevant for a problem at hand, is it one of the various -omics type of readouts? Is it, for example, transcriptomics (gene expression) where a certain phenomenon can be observed, or do we expect post-translational modification instead (or rather inactivation of the protein because of, say, a protein–protein interaction being present)? Except in very simple cases (such as overexpression of nuclear hormone receptors in some cancers), it is not trivial to understand the relationships of different levels of biology with particular endpoints of interest. Often we cannot say, because of our lack of understanding of biology and, hence, the generation of biological data is often driven by technology push, instead of science pull.

However, this difficulty does not end with the description of the system; similar aspects apply to the labeling one might want to use: How does one define, for example, ‘disease’ based on the cause, mechanism, or on the symptom level (where the levels often disagree with each other, and where some individuals with a given genetic background display very different symptoms, or also none at all) [38]? What is a drug–drug interaction; how do we define it, for example, with respect to its relationship with the dose of the drugs given, what is the impact of genotype of the individuum (some drug–drug interactions are only observed in some individuals [39]), and how do we handle frequency versus severity of events in our description? As in the case of chemical data, labeling is ambiguous and heavily situation dependent. We might be able to assign, for example, cellular cytotoxicity given a particular assay format and parameters, but whether a compound causes, for example, liver toxicity in an organism depends on the species it is tested in (and often also the strain), route of administration, dose, assay endpoint one considers, and many other factors (age, sex, co-medication, etc.). Even then, control animals also show a certain likelihood of say liver lesions in histopathology: what does one do here? Are more frequent observations of toxicity more significant, or less frequent observations, but which are observed at higher severity? In addition, as opposed to labels in the case of images, the system is not static; for example, aspects such as ‘cell line drift’ [40] exist, where the biological system evolves over time, and which has no equivalent in the image domain.

One distinction to be made here when it comes to labels in the biological domain is the difference between ‘controlled’ and ‘uncontrolled’ variability in data, with the former being, for example, the influence of a precise assay set-up, and the latter being annotations of an image chosen by a histopathologist (where, even if standardized terminology is used, annotations are often subjective). The effect of controlled variability can, in principle, be taken into account in the model, such as in multitask models (where, despite fewer data points generated in a given set-up, endpoints can learn from each other). By contrast, uncontrolled variability leads to noisy data and, hence, models with lower performance. In practice, however, this is not a black-and-white situation, such as in the case of cell line drift [40] mentioned earlier, which is supposedly a controlled part of the assay set-up (where metadata to this effect can and should be added to the assay annotation), but in real-world situations those annotations are also often not kept under control in practice.

Biological labels are hugely conditional and multidimensional and, hence, it is not trivial to assign labels in particular in case of more complex biological endpoints. Given that ML algorithms need labeled data to learn from this represents a problem when applying AI in the drug discovery field using supervised techniques, which require labels for decision-making in the first place. (Whereas unlabeled data can be subject to, for example, clustering, such as in case of single-cell data, where ample information is available [41], without insight into the meaning of individual clusters, such techniques are generally not useful for making decisions in drug discovery projects, where a decision needs to be made based on a given model output).

Thus, we can conclude that areas of previous success of AI, such as those for image classification and speech recognition, differ from the chemical and biological data available in the drug discovery field with respect to the following: (i) the amounts of data available; (ii) ability to represent it in a suitable form to the computer; (iii) a ML algorithm that is intrinsically consistent with the data available (e.g., waveforms and RNNs, or images and CNNs have this underlying consistency, which doesn’t exist for chemical and biological data); and (iv) the possibility to assign meaningful labels (which are in the drug discovery area heavily dependent on the situation, such as dose, genotype, assay set-up, etc.). Also recent other developments, such as the success of DeepMind in winning the recent CASP protein folding competition by a large margin [67] need to be evaluated in what precisely this allows us to do in the context of drug discovery. For the area of protein folding this indeed is a very important development, given the precision and speed with which predictions of folded protein states are now possible. However, for the field of drug discovery crucial questions of in vivo efficacy and safety of any drug remain as before - we will likely be able to dock (and do structure-based design) on more targets than before to discover ligands faster; how this translates into the in vivo situation is an entirely open question, and the comments above on ‘ligand’ vs ‘drug’ discovery apply as before. For a recent comprehensive discussion of the topic also see [68]. In short, there is a difference between identifying objects on images, and also predicting a protein structure, and identifying safe and efficacious drugs. We will describe the differences in more detail in the following.

We can furthermore distinguish domains depending on whether the representation of information to the computer is relevant to the objective at hand, whether it is comprehensive (i.e., whether it contains sufficient information to classify every object in principle), whether the underlying distribution of the space to be classified can be described (either analytically or by brute force), how well we can sample from the underlying distribution, whether data are conditional (or depends on factors outside the data available themselves), and to what extent it depends on quantitative effects, so that, for example, one concentration of a compound renders a compound toxic, and another (lower) one does not. This information is summarized in Table 2, including the domains of image classification and speech recognition, the games chess and GO, as well as chemical and biological data used in drug discovery.Table 2Comparison of data and representations in the image, speech, and chemistry/biology domainsa, bTable 2DomainRepresentation relevant for objectiveRepresentation comprehensiveUnderlying distribution knownSampling of underlying distributionConditionality of dataQuantitative dependence of label on external contextImagesPixels describe object (but dependent on orientation)Yes within domain (images contain all information about visual object)NoBiased but good (large data sets available)PartialNone (labels can be assigned in binary fashion)SpeechYes (waveform captures all aspects of speech)YesNoBiased and good (large data sets available)Partial (context); local and global structureNone (words can be assigned entirely based on waveform)Chess/GOYes (locations and functions of pieces are fully defined)Yes (positions of pieces entirely describe state of system)Can be calculated in principle, because there is a large but finite set of movementsCan be exhaustively sampled (in principle)NoN/ADrug discovery: chemistryDepends on context: which features/representation of compounds is relevant is often unknownPartially (conformations, protonation states, etc. are frequently unknown)No (chemical space not known in its entirety; can only be calculated as approximation)Biased and small (100 s; up to 106–109 out of 1063[49])Partially (e.g., lipophilicity depends on protonation states, etc.)Depends on contextDrug discovery: biologyWhich aspect of biology contains information for which endpoint is frequently unknownNo (level of biological type of data generated, temporal, and spatial domain not explored)Very partial (e.g., amino acid distributions in evolution)Biased (depends heavily on experimental set-up)Yes (e.g., gene expression depends on treatment, cell type, etc.Very large (biological system is heavily influenced by system, experimental set-up)aGiven recent successes of AI in the games Chess and GO, these are included for comparison. It can be seen that chemical, and in particular biological, systems are difficult to describe, given that data can be generated on many different layers (genes, proteins, etc.); representations are not comprehensive; sampling is low; and data depend significantly on the condition of the system, while quantitative aspects abound (e.g., different concentrations of a chemical can lead to entirely different biological responses).bThe colour scheme indicates in which cases data and representations are expected to cause relatively few problems in computational models (green), an intermediate problems (yellow), or large problems (red) due to either high dimensionality, incomplete data, or incomplete definition of the problem in a given representation, or due to other reasons.

Progress in games such as GO has recently been heralded as a ‘breakthrough’ of AI [42]. Although this might well be the case in this particular domain, such games are also much simpler than a drug discovery setting, in that there is a finite set of states, rules are defined explicitly and can be calculated exhaustively (either in practice, but at least in principle). However, this is a very different set-up from the life science area: Here, in particular in the biological domain, systems generally do not follow explicitly defined rules (or at least those are generally not known, and can only be derived insufficiently from sparse data available). Rather, systems can be defined on a large number of different levels (e.g., the transcriptomics, proteomics, and metabolomics levels, but then also the epigenetic and functional interaction levels, on a time- and spatially resolved manner, taking both intracellular and intercellular signaling into account, from the cellular to the organism level). Furthermore, observations in the biological domain are highly conditional (depend on a large number of parameters) which are generally not known. In a database such as SIDe Effect Resource (SIDER) [17], one might annotate a drug with a particular side effect, and use this information to train computational models for prediction purposes. However, this effect also depends, besides the drug administered itself, on: (i) dose; (ii) genetic set-up of the recipient (such as CYP expression [43] or genetic polymorphisms [44]); (iii) factors influencing pharmacokinetic (PK) properties of the drug (e.g., food intake [45]); (iv) co-medication; (v) disease state; (vi) sex; (vii) age; or (viii) microbiome [46]; and then the side effect might only occur in a particular fraction of patients, and it might also be apparent at different levels of severity, in different forms in different organs. Ontologies used to annotate side effects might (or might not) agree with respect to term mappings and their relationships, and there might be cultural differences with respect to adverse event reporting in different populations. (Finally, it is not trivial to perform statistics based on side effect data, which suffer from profound biases [47], such as reporting bias.) As apparent from Table 2 (in addition to Table 1), data and their meaning in different areas heavily differ, and not every approach that works in one area can be directly transferred to another. We need to conclude that chemical and biological data needs to be used with significant care, and always be interpreted in its context.

The term ‘data’ is convenient in terms of thinking that ‘more data will solve our problems’ in drug discovery. However, this is not true, as described earlier, to quote Sydney Brenner, ‘Indeed, there are some who think that all that will be required is the collection of more and more data under many different experimental conditions and then the right computer program will be found to tell us what is going on in cells. […] this approach is bound to fail […]’. [48] It needs to be data than contain a signal to answer the concrete questions we ask from it, which means data supported by understanding, and solid hypotheses.

Number of data points and/or sizes of data sets available in different domains, namely for images, self-driving cars, astronomy, and in the chemical, biological, and drug discovery domainsa

Illustration of the differences between image recognition and classification tasks in the chemical and biological drug discovery domains. When classifying images (and also speech), the model architecture and representation of object are more integrated than when using chemical and biological data, and labels can be assigned relatively less ambiguously. In the chemical domain, the best representation of an object is generally unknown (different aspects of a chemical are responsible for different types of effect, and some might be related to the functional group, others related to surface properties, etc.), whereas, in the biological domain, it is not clear which type of information provides information related to which endpoint. Common to the chemical and biological domains is that labels depend to a large extent on the set-up of a particular experiment, even if the same thing is measured ‘in principle’.

Comparison of data and representations in the image, speech, and chemistry/biology domainsa, b

## Section: Why representing drug discovery information for AI is difficult: linking bioactivity to adverse events

We now illustrate, based on secondary pharmacology profiling data and linking bioactivities on the protein bases to physiological outcomes, the complexities of drawing conclusions across the chemical and biological domains. Although one might as a first approximation assume that activity against a protein target is sufficient to understand (and, hence, predict) its effect in a biological system (which indeed would be convenient for AI approaches in drug discovery) this is unfortunately not the case in practice.

We previously analyzed such relationships themselves [50] when considering the ratio of bioactivity against a target relative to unbound plasma concentration, with respect to the likelihood of a drug showing adverse events for annotations from the US Food and Drug Administration (FDA) Adverse Event Reporting System (FAERS) [51] and the database SIDER [17]. The hypothesis is that if the blood plasma concentration of a drug is above the threshold needed to act on a particular target, then one would assume to see a particular type of side effect (or, more generally, biological effect). The results of this analysis are shown in Fig. 2. Whereas bioactivity against some targets is indeed more frequently associated with particular adverse reactions than bioactivity against other targets, there is far from a 1:1 relationship between both spaces. In particular, the positive predictive value (PPV) of activity on some side effect-related targets is often low; thus, whereas activity against a protein target (at physiologically relevant concentrations) makes it more likely to observe a particular effect, activity against a target is far from a sufficient criterion for anticipating particular drug side effects.Figure 2The positive predictive values (PPV) of target–adverse event associations against the hit rate or recall (i.e., the fraction of drugs associated with the adverse event also being active at an individual protein target). Activity calls were made based on the ratio of the in vitro bioactivity and the unbound plasma concentration. Target–adverse event pairs with a high PPV tend to have a low hit rate, meaning only a small share of all drugs associated with the adverse event would be picked up by the bioactivity at the target. Alternatively, a high hit rate is associated with a low PPV, indicating a high false positive rate for that target–adverse event combination. Thus, overall, there exists no clear 1:1 relationship between on-target activity and observed adverse events after compound administration. Abbreviations: ADRA1B, α1b adrenergic receptor; ACE, angiotensin-converting enzyme; CHRM1/2/3, muscarinic acetylcholine receptor M1/2/3; PTGS1, cyclooxygenase-1; DRD2, dopamine D2 receptor; FAERS, US Food and Drug Administration Adverse Event Reporting System; HTR2A, serotonin 2a (5-HT2a) receptor; HTR2C, serotonin 2c (5-HT2c) receptor; KCNH2, hERG; SIDER, SIDe Effect Resource.Figure 2

One might argue that this analysis is rather simplistic, because many factors are not taken into account in this analysis (compound metabolism, full PK profile, such as accumulation into organs, off-target profiles, etc.), and this is indeed the case, and the point being made here: single (or even few) descriptors of a compound will not be able to anticipate the full biological complexity of drug effects, which, however, is the underlying assumption of many computational drug discovery approaches. We look at one particular compound in Box 1 to make this point clearer 52, 53, 54, 55 (this example is also repeated in [24] because of its relevance for the point we are trying to make in both contributions).Box 1Why representing drug discovery information for AI is difficult: a closer look at one compound, ketamineKetamine is used as both an (overall rather safe) anaesthetic, which has been approved since 1970, and a street drug. However, in 2000, its effect as an antidepressant, when dosed significantly lower than when used as an anaesthetic, was also published [52]; in addition, its bronchodilatory properties are well known. Although ketamine has long been thought to act via blocking the NMDA receptor, other NMDA blockers, such as memantine and lanicemine, have not been successful in clinical trials, hinting to a difference in their respective mode of action, which has yet to be fully understood. More recently, besides the NMDA receptor, the opioid system has also been implicated in the action of ketamine, given that naltrexone (which acts on the opioid system) influenced the effect of ketamine in one study [53] (whereas another study found the opposite [54]). Furthermore, a metabolite of ketamine was recently found to be active in animal models of depression [55], with human studies still outstanding. This case illustrates the difficulty of annotating drugs with clear mode of action and indications labels, which are often not known in detail, and depend on dose and metabolism (among other factors). This renders the application of AI approaches on such poorly labeled data in the drug discovery context nontrivial.Alt-text: Box 1

The positive predictive values (PPV) of target–adverse event associations against the hit rate or recall (i.e., the fraction of drugs associated with the adverse event also being active at an individual protein target). Activity calls were made based on the ratio of the in vitro bioactivity and the unbound plasma concentration. Target–adverse event pairs with a high PPV tend to have a low hit rate, meaning only a small share of all drugs associated with the adverse event would be picked up by the bioactivity at the target. Alternatively, a high hit rate is associated with a low PPV, indicating a high false positive rate for that target–adverse event combination. Thus, overall, there exists no clear 1:1 relationship between on-target activity and observed adverse events after compound administration. Abbreviations: ADRA1B, α1b adrenergic receptor; ACE, angiotensin-converting enzyme; CHRM1/2/3, muscarinic acetylcholine receptor M1/2/3; PTGS1, cyclooxygenase-1; DRD2, dopamine D2 receptor; FAERS, US Food and Drug Administration Adverse Event Reporting System; HTR2A, serotonin 2a (5-HT2a) receptor; HTR2C, serotonin 2c (5-HT2c) receptor; KCNH2, hERG; SIDER, SIDe Effect Resource.

## Section: Data and problem settings in drug discovery

Whereas drug discovery in textbooks tends to follow a logical path, such as from target validation to hit identification, lead optimization, and into the clinical phases, this linear sequence is somewhat abstract and often shows more iterative features (or heavy tailoring to the specific situation) in practice. Nonetheless, for the purpose of using data analysis methods in the drug discovery domain, we can generally distinguish two types of model: (i) those based on large(r)-scale and proxy measures, which often aim at compound selection from a large set of either physically available or virtual molecules (e.g., in virtual screening), and which tend to be more qualitative in nature (see the first and third columns of Table 3), including models for solubility, logD, or bioactivity on protein targets usually fall into this category; and (ii) models that are based on the available data usually on a smaller scale (but which are often more relevant data for in vivo endpoints), which are of more quantitative nature, and which aim for the prediction of safety- or efficacy-related endpoints (see second and last column in Table 3). More complex models, such as animal models (or also human efficacy or safety data), fall into this category.Table 3Data available at different stages of drug discovery, and different problem settingsaTable 3Data availabilityProblem settingProxy data (usually in vitro)Efficacy/safety data (usually in vivo)Proxy data (usually in vitro)Efficacy/safety data (usually in vivo)Often ‘simple’ readouts (e.g., activity on protein)Large number of data points for training modelsModels have clear labels (within limits of model system; e.g., ‘ligand is active against protein at IC50 < 10uM’, logD, logS, etc.Good for model generation: many, clearly categorized data pointsOften less good for in vivo relevanceQuantitative data (dose, exposure, etc.)More complex assays to generate data, and fuzzy labels (classes ‘depend’, on exposure, e.g., multiple mutually dependent histopathological endpoints)Less, and less clearly labeled data: difficult from machine learning angleRecording complex data in format suitable for mining is not trivial; e.g., histopathology/in vivo endpoint dataDiscovery setting: ‘find me suitable 100 s or 1000s out of 1 million’ (e.g., prioritization, screening)Qualitative predictions often sufficientAnything fulfilling (limited) set of criteria will do ‘for now’, predicting presence of somethingComputationally generative models often usefulNeed to predict for this particular data point (molecule)Large number of criteria to rule out, based on limited data… predicting absence of ‘many things’ (e.g., different modes of toxicity)Predictive models needed (more tricky than generative; e.g., data coverage limiting)Quantitative predictions required (is this compound efficacious/toxic given the dose?)aAs it has been shown before for quantity, the quality of models for decision-making has significant impact on project success. This has profound implications for the use of predictive models in the context of AI in drug discovery, where, thus, models with sufficient inherent performance have to be used, and which are trained on endpoints of relevance for the in vivo situation (which is not necessarily a given for every endpoint).

Thus, drug discovery, in the way that it is frequently implemented in industry, often deals with proxy measures (see following section for details), where large numbers of data points can be generated by relatively simple types of assay. This is beneficial for the amount of data available for training (and, hence, coverage of chemical space, for example). However, in cases where proxy measures have relatively low predictivity for the relevant in vivo endpoint, the sheer amount of data is often not sufficient to generate a practically useful model. By contrast, quantitative readouts from complex biology might be more advantageous when it comes to their human in vivo relevance, although these data are more difficult to generate and model (because of the conditionality of data, an aspect discussed earlier).

There are considerable efforts taking place that aim at in vitro to in vivo extrapolation (IVIVE), in both the efficacy (e.g., related to clearance [56]) and the safety [57] contexts. However, the problem is that there is no ‘general’ mapping of proxy endpoints to a particular efficacy or toxicity that one is interested in; for example, a particular compound class extrapolates differently from one particular activity in one assay to one particular endpoint in vivo, be it for biological reasons (e.g., target expression), or PK properties (e.g., different transport, or metabolism etc.), or various other reasons. Given the large size of chemical space, in combination with the few data available across many different endpoints, it will also not be the case in the future that this type of mapping will ever be available in a comprehensive manner. That being said, localized IVIVE approaches do exist; however, they are generally tailored to the particular problem (chemical series, assay and in vivo endpoint in particular); thus, they are not generally applicable to the ‘AI in drug discovery’ field in its generality and significant manual work is required in every case. Why is the general lack of predictivity of proxy endpoints now important when aiming to use proxy measures in the drug discovery process, both generally, and also with respect to their prediction using computational methods? It has been shown before that the predictivity of assays (endpoints) used for decision making is key; to cite from a previous study [58], ‘changes in the predictive validity of screening and disease models that many people working in drug discovery would regard as small and/or unknowable (i.e., an 0.1 absolute change in correlation coefficient between model output and clinical outcomes in man) can offset large (e.g., 10 fold, even 100 fold) changes in models’ brute-force efficiency’. This is of significant importance for the utilization of predictive models for compound selection: if one uses models with insufficient quality for predicting compound properties (be it because of insufficient performance of the model itself, or an unsuitable endpoint for the in vivo situation), then a significant speed-up of individual steps in the drug discovery process will also not lead to better project outcome. Of course, the performance of models is closely linked to the quality of the underlying data, and this is often another limiting factor of using predictive models in practice [59].

To summarize, we currently do not have data of the right types available to enable us to generate models to truly utilize AI for drug discovery. Hence, incremental changes with respect to the ability to model those proxy endpoints will also not be game-changing, simply because they do not translate to any in vivo endpoints relevant to drug safety and efficacy. In many cases, we do not understand biology sufficiently well to define what we need to measure; and the choice of proxy endpoints (be they related to physicochemical properties, PK, efficacy, or safety) are always associated with significant uncertainty how they translate to the clinic. Given this property of the underlying data available, ‘AI’ approaches will also conceptually not be able to improve upon the current situation, whatever the algorithm used. (We revisit this topic in more detail in the companion article, see Table 1 in [24] and associated discussion).

Data available at different stages of drug discovery, and different problem settingsa

## Section: Discussion of data types and their information content in drug discovery: on data and labels in drug discovery

Although aspects of drug discovery might be intellectually understandable by humans, for modeling data using algorithms either qualitative or quantitative labels (be they binary, categorical, or numerical) need to be applied to utilize any type of explorative or predictive modeling approach. In the case of objects, these can be identifiers (‘house’, ‘car’, ‘cat’) that are often assigned manually for a training data set, and which can then be used to train a model to classify future instances without labels. Also hierarchical labeling concepts (ontologies) exist, which have been increasingly applied in the biological and drug discovery fields [60], and which have provided a helpful way to organize chemical and biological information.

However, biological annotations in particular are often far from ideal for data mining for a variety of reasons (in addition to the conditionality of biological data explained earlier), some of which are illustrated here. As an example, let us revisit the concept of a ‘mode of action’ of a drug (which has already been discussed in Box 1 for ketamine), where often Anatomic Therapeutical Classification (ATC) [61] codes are used to provide a label of this type. However, ATC codes have grown historically, and the top level category of ATC is the organ level, which is not linked to any meaningful biological mode of action. Which other options exist? For example, activity on a particular target is a common choice, say by using Entrez-Gene IDs as target identifiers. However, the situation is not as simple as that; for example, which identifier should be used if a uniquely identifiable gene is not the target, but only a particular splice variant; or a particular activation state of, for example, a kinase (e.g., the phosphorylated form); or a particular allosteric binding site? In addition, this target also might be inhibited (while its concentration remains the same), or its expression might be changed (e.g., across cell types or states), or it might be marked for degradation via PROTACs, and so on. Hence, there are many different ways of interacting with a drug target, only a few of which are functionally equivalent to each other. Furthermore, different types of interaction on the same target can lead to different effects; in the simplest case, this can be the difference between an agonist and an antagonist on a protein; but receptor pharmacology is of course more subtle than that, and biased signaling or considering the pharmacodynamics of ligand–receptor interactions, and their functional consequences, leads to further complications of how to ‘label’ a particular compound with a mode of action to enable data mining [62]. Hence, even if one accepts the premise that activity against a particular target is used to annotate modes of action of a compound (which is a big ‘if’ in itself; one can also define it say on the pathway level), then which labels to use for this purpose is by no means trivial.

An example of more complex biological readouts comes from in vivo systems, in this case histopathology information. This type of information is routinely generated in animal studies, where organs are microscopically evaluated for changes that might indicate compound toxicity. In this case, assigning observations of significance to a compound depends (besides the structure itself) on exposure (the concentration of compound in the target tissue), the subjective interpretation of observations (although this can be made more objective using image recognition techniques [63]), mutual dependency of endpoints (meaning that one endpoint has a different meaning in the context of the presence or absence of another endpoint), and the subjective use of terminology. An example of the latter are 60 different terms for ‘kidney’ encountered in the recent eTox data harmonization work of animal readouts [64], and the above list is not complete; one could also include the particular study protocol used, biological variation, and so on. Furthermore, there is the difficulty of determining which effects are treatment related and which are not (because observations also exist in the control group), and how to deal with the severity of findings [54]. In this case, histopathology endpoints are rendering this type of data nontrivial to use for AI decision-making by the very complexity (conditionality) of the data present, as well as the low amount of data that is available, which is usually only in the order of hundreds (or in the low thousands) of compounds in the largest available databases, such as DrugMatrix [15] and TG-GATEs [65]. Given the large chemical space that compounds are drawn from (and resulting low coverage), in combination with the high-dimensional readout space and the differences in experimental set-up, this type of information is very difficult to fit into AI frameworks at the current stage.

Similar considerations apply even for ‘commonly used’ terms, such as ‘disease’. This is not one biologically coherent entity one can label: it can be classified, at least, because of the underlying cause, mechanistic process, or at the symptomatic level [38]. Links between those levels depend considerably on the individual; that is, identical genetic backgrounds do not necessarily manifest themselves in the same way in different individuals. Generally speaking, if one goes from the in vitro to the in vivo area, the underlying data become more complex, smaller scale, and highly dependent on the particular set-up (protocol, individual, etc.), representing problems for AI approaches.

This inability, in many cases, to label compounds in a meaningful way leads to problems when mining data, be it in predictive models or using, for example, knowledge graphs. If we cannot represent the property and problem of interest in a suitable way, and have data from different sources (with unknown confidence), this leads to uncertainty in the predicted labels in turn. If the space we could label is large (such as 1063 plausible small molecules [49]), and our rate of overpredictions is nontrivial, then this leads to a large number of false positives from our model output, making it difficult to choose the output from AI systems as directly actionable input.

Table 4 provides a brief summary of such problems in the chemical, biological mode of action, and phenotypic domains for different types of representation and label currently being used.Table 4Different types of chemical and biological information utilized in drug discovery, along with a brief description of where and why labeling data is nontrivial in each domainTable 4Data typeRepresentationDifficulty/shortcomingResulting problem in AI applicationsChemical structure1D descriptors, fragments, graphs, pharmacophores, surfaces, etc.Descriptor choice subjective (not known beforehand/trial and error), etc.No problem-inherent representationInformation not necessarily contained in chemical structure and, hence, descriptor (e.g., dose-related properties, metabolites that could contribute to both desired and undesired effects, etc.)Biological dataActivity on protein targetSingle number (e.g., IC50, Ki/Kd, etc.)Functional pharmacological effects incompletely characterizedNot all protein targets considered/data available forActivity on target not necessarily relevant at therapeutic dose (depends on compound PK), etc.Ligand–protein labels are both incomplete (not available for all combinations) and heterogeneous (stem from different types of endpoint measured)Activity for isolated protein might not be relevant in in vivo systemMode of actionTarget, pathway, functional level, etc.Can be defined on different levels, there is no intrinsic ‘mode of action’ of a compoundOften contradictory information on different levels of readoutsDepends on precise system (e.g., cell type), etc.Labels heterogenous (because concept is not properly defined itself; see also ketamine case study in Box 1 in the main text as an example),Gene expression dataUp- and downregulation of individual genes (or pathways)NoisyDepends heavily on assay set-up (cell line/system, time point, dose)Wide choice of pathway annotationsWide choice of analysis methods and parameters, etc.High-dimensional and noisy input space (∼20 000 dimensions)Relevance of gene expression changes for physiological endpoint not always clearVery parameter dependentCellular imaging readoutsImages themselves, or explicitly defined featuresDependent on parameters (cell line/system, time point, dose)Difficult to interpret biologicallyCan be difficult to identify signal (especially in hypothesis-free screening setups), etc.Not trivial to infer biological meaning (and select relevant features)Predictive value for many practical purposes still needs to be establishedVery high dimensional (especially when derived in hypothesis-free set-ups)Physiological dataPK dataConcentration over time per tissue typeDifficult to generate (especially for tissues that are difficult to access, e.g., brain, lungs)Interpersonal variabilityTracking metabolites not trivial, etc.Generally too few PK data available (almost none for tissues)Makes it difficult to predict exposure-dependent effects (which however are crucially related to both in vivo efficacy and toxicity)Animal endpointse.g., clinical parameters, histopathologyBiological variationLack of consistent terminology and use of ontologiesDifficult to establish treatment-related effectsFrequency and severity difficult to compareEndpoints relevant only in contextTime and dose dependence of observations, etc.In vivo readouts difficult to label (see difficulties on the left), also generally only available on a smaller scaleGenerally too few data to expect algorithms to infer relationships between drug treatment and in vivo endpoint observationsClinical endpointsOrgan-based endpoints (eg DILI); adverse events such as in MedDRA, disease annotations such as from ICD-10, etc.Endpoint definitions are partially overlapping and cannot be assigned clearly (e.g., DILI depends on dose etc.)Adverse events depend on reporting (with associated biases)Disease annotations depend on generally subjective evaluation by medical professionalsComplete genetic background usually not known/considered (leads to incomplete knowledge about system), etc.In vivo endpoints are heavily conditional, biased, and can be assigned in different ways (leading to lack of consistency among data sets)Generally too few data to expect algorithms to infer relationships between drug treatment and in vivo endpoint observationsaIt can be seen that little of the information in the field can easily be assigned labels, be it from the chemical or biological domain, with resulting difficulties to using such data for applying AI approaches in drug discovery.

Different types of chemical and biological information utilized in drug discovery, along with a brief description of where and why labeling data is nontrivial in each domain

## Section: So where are we now, and what is the way forward for Artificial Intelligence in drug discovery when it comes to data?

The earlier discussion was a brief illustration of why it is currently not trivial to apply AI methods in the drug discovery context, which is, to a good extent, because of difficulties in generating and labeling relevant chemical, biological, and physiological data for questions related to efficacy and safety. Currently, we frequently ‘model where the data is’ (in the way of looking for the car keys where the light is, but not where we expect to find them); and real breakthroughs in the field are still scarce. Just having ‘data’ does not help (it might, to an extent, in other areas, but much less so when it comes to drug discovery): they need to be the right data, and be available in the right format and be used for the right purpose, for AI in drug discovery to bring a real change to the area.

That being said, it has been recognized that drug discovery data need to be organized much better than they have been traditionally [66], with the general trend that we are better able to do data look-up, cataloguing (where possible), and nearest neighbor searches in many cases already, all of which is useful. Still, to go to the next level, we need to go beyond the limitations posed by current data, and decide which data we need to answer a question related to in vivo safety and efficacy according to the information they contain for the question at hand.

Fig. 3 shows that the scientific question, or hypothesis, is at the start of any model: we have the hypothesis that, for example, the overexpression of a given gene is related to a particular disease. This allows us to generate data in a targeted manner (in this case, using gene expression detection methods), which we need to represent in a suitable way (to keep the signal in the data), and finally analyze the data with an appropriate method (which ideally is aware of the underlying distributions of data one expects in a particular area).Figure 3Illustration of a scientific question, or hypothesis, at the basis of data generation. The hypothesis leads to the generation of relevant data for a given question, which are represented in a signal-preserving manner; and which are then analyzed using a method that is able to handle the signal in the data. A method cannot save an unsuitable representation, which cannot remedy irrelevant data, for an ill thought-through question. This principle needs to be at the basis of data generation for making true use of ‘artificial intelligence’ in drug discovery.Figure 3

However, this is unfortunately not the case with data that are currently often used for drug discovery. To the contrary, data are frequently being generated in a hypothesis-free manner, followed by subsequent ‘fishing exercises’, and using constant parameters: a given cell line that is sufficiently easy to handle in a lab, and compounds are tested at a constant dose (e.g., 10 μM) and an often arbitrarily chosen time point (e.g., 12 or 24 h). This indeed makes it easier to mine data, but the relevance of data generated with such parameters for any in vivo situation is unclear.

Furthermore, data are frequently generated via techniques that are becoming available (see example of genome sequencing in the first part of this publication [24]), and which are hence expected to lead to major new insights: without asking the question whether these are the right data to generate, for a given purpose. to be able to truly use chemical and biological data for decision-making in drug discovery, we need to move beyond data that are generated by the ‘push’ of technology, toward a ‘pull’ of scientific need. Likewise, data that are generated in a hypothesis-free manner will remain difficult to analyze and to identify a signal in; thus, we need to identify better what to measure in the first place (and this might well be an iterative cycle of, for example, pilot studies to identify relevant parameters, and eventual large-scale data generation of what has been established to contain a signal from such explorative initial studies). To return to the quote of Sydney Brenner earlier, ‘Indeed, there are some who think that all that will be required is the collection of more and more data under many different experimental conditions and then the right computer program will be found to tell us what is going on in cells. […] this approach is bound to fail […]’ [48].

Illustration of a scientific question, or hypothesis, at the basis of data generation. The hypothesis leads to the generation of relevant data for a given question, which are represented in a signal-preserving manner; and which are then analyzed using a method that is able to handle the signal in the data. A method cannot save an unsuitable representation, which cannot remedy irrelevant data, for an ill thought-through question. This principle needs to be at the basis of data generation for making true use of ‘artificial intelligence’ in drug discovery.

## Section: Concluding remarks

The data available in the drug discovery field are fundamentally different in nature from those in other domains where AI has achieved great advances recently, such as image and speed recognition domains. Partly this relates to difficulties in defining the relevance of particular endpoints (and achieving meaningful labels for ML models to success); and partially this relates to a lack of current understanding of in particular biological systems (as well as other reasons outlined in this article). In many cases, it is difficult to label life science data (because of biological variation, dependency of labels on precise assay set-up, mutual dependence of labels on context, and inconsistent naming schemes, among others) which is a severe problem when applying AI methods in the drug discovery field. To truly advance the field, and to go from applications in ligand discovery to those in drug discovery (beyond developing chemical probes, which of course can be useful for target validation by themselves for example), we need to understand which data to generate for which purpose, and this involves understanding biology better in the first place. Only when we are then able to measure and capture relevant biological endpoints in vivo we will be able to advance the field significantly further, and to apply the computational algorithms currently available to us fruitfully in the drug discovery area, with respect to compound efficacy and safety in the clinic.

## Section: Conflict of interest

AB is a shareholder of Healx Ltd. and Pharmenable Ltd.


---

# Artificial intelligence in early drug discovery enabling precision medicine

- **Authors:** Fabio Boniolo, Emilio Dorigatti, Alexander J Ohnmacht, Dieter Saur, Benjamin Schubert, Michael P Menden
- **Issuer:** Expert opinion on drug discovery
- **Type:** Scientific article
- **Published:** 2021-06-02
- **Language:** en
- **DOI:** 10.1080/17460441.2021.1918096
- **Source:** https://pubmed.ncbi.nlm.nih.gov/34075855/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Introduction: Precision medicine is the concept of treating diseases based on environmental factors, lifestyles, and molecular profiles of patients. This approach has been found to increase success rates of clinical trials and accelerate drug approvals. However, current precision medicine applications in early drug discovery use only a handful of molecular biomarkers to make decisions, whilst clinics gear up to capture the full molecular landscape of patients in the near future. This deep multi-omics characterization demands new analysis strategies to identify appropriate treatment regimens, which we envision will be pioneered by artificial intelligence.Areas covered: In this review, the authors discuss the current state of drug discovery in precision medicine and present our vision of how artificial intelligence will impact biomarker discovery and drug design.Expert opinion: Precision medicine is expected to revolutionize modern medicine; however, its traditional form is focusing on a few biomarkers, thus not equipped to leverage the full power of molecular landscapes. For learning how the development of drugs can be tailored to the heterogeneity of patients across their molecular profiles, artificial intelligence algorithms are the next frontier in precision medicine and will enable a fully personalized approach in drug design, and thus ultimately impacting clinical practice.


---

# Artificial Intelligence in Surveillance, Diagnosis, Drug Discovery and Vaccine Development against COVID-19

- **Authors:** Gunjan Arora, Jayadev Joshi, Rahul Shubhra Mandal, Nitisha Shrivastava, Richa Virmani, Tavpritesh Sethi
- **Issuer:** Pathogens (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2021-08-18
- **Language:** en
- **DOI:** 10.3390/pathogens10081048
- **Source:** https://pubmed.ncbi.nlm.nih.gov/34451513/
- **Licence:** CC-BY

## Section: Abstract

AbstractAs of August 6th, 2021, the World Health Organization has notified 200.8 million laboratory-confirmed infections and 4.26 million deaths from COVID-19, making it the worst pandemic since the 1918 flu. The main challenges in mitigating COVID-19 are effective vaccination, treatment, and agile containment strategies. In this review, we focus on the potential of Artificial Intelligence (AI) in COVID-19 surveillance, diagnosis, outcome prediction, drug discovery and vaccine development. With the help of big data, AI tries to mimic the cognitive capabilities of a human brain, such as problem-solving and learning abilities. Machine Learning (ML), a subset of AI, holds special promise for solving problems based on experiences gained from the curated data. Advances in AI methods have created an unprecedented opportunity for building agile surveillance systems using the deluge of real-time data generated within a short span of time. During the COVID-19 pandemic, many reports have discussed the utility of AI approaches in prioritization, delivery, surveillance, and supply chain of drugs, vaccines, and non-pharmaceutical interventions. This review will discuss the clinical utility of AI-based models and will also discuss limitations and challenges faced by AI systems, such as model generalizability, explainability, and trust as pillars for real-life deployment in healthcare.Keywords: COVID-19, machine learning, artificial intelligence, drug discovery, SARS-CoV-2, pandemic, diagnosis, prediction, surveillance, vaccine

## Section: 1. Introduction

COVID-19, caused by severe acute respiratory syndrome coronavirus 2 (SARS-CoV-2), is the worst pandemic since the 1918 Spanish Flu. Within weeks of the first outbreak in December 2019 in the Wuhan city of China, the disease took epidemic proportions in China and other countries. On January 30th, 2020, COVID-19 was declared as a Public Health Emergency of International Concern, and subsequently, on March 11th, 2020, COVID-19 was declared a pandemic by the World Health Organization (WHO). The COVID-19 pandemic has resulted in a total of 200.8 million cases worldwide, with a reported 4.26 million deaths as of August 6th, 2021 [1]. Owing to its high transmissibility and death rate amongst elderly and immunocompromised individuals, the disease has become the latest foe to humankind. In terms of the total number of infections and mortality, the USA, India and Brazil are the most severely hit by COVID-19 [1]. Despite mass vaccination all over the world, COVID-19 still poses a threat to human lives and livelihood [2]. India’s recent COVID-19 crisis suggests that the pandemic is far from over, and new strategies are required for the surveillance, diagnosis and identification of therapeutic solutions against COVID-19. In this review, we will focus on the role of Artificial intelligence (AI) and machine learning (ML) tools in managing the COVID-19 pandemic.

The application of Artificial Intelligence in handling COVID-19 pandemic. The life cycle of SARS-CoV-2 and COVID-19 disease etiology is shown on the left panel. On the right, examples of different applications of Artificial Intelligence (AI) are shown. AI-related tools can be useful in the accurate diagnosis of COVID-19 disease, finding new drugs, and analysis of data from clinical trials.

## Section: 1. Introduction › 1.1. Pathophysiology of COVID-19

SARS-CoV-2, which was first transmitted from animal-to-humans, is primarily spread by the droplet route but is also suspected to have airborne, contact, fomite, fecal-oral, bloodborne, and mother-to-child transmissions [3,4,5,6]. It is important to note that both symptomatic and asymptomatic subjects can transmit the SARS-CoV-2 virus through secretions such as saliva or respiratory droplets while talking, coughing, or sneezing [7,8,9,10,11]. When the respiratory droplets containing SARS-CoV-2 virus come in contact with a susceptible person’s mouth, nose, or eyes, it can result in COVID-19 infection. Transmission can also occur indirectly when a healthy individual comes in contact with a contaminated object or surface (fomite transmission) [12,13,14,15]. The SARS-CoV-2 infection mainly causes mild to severe respiratory disease that may lead to death in some cases, though many people infected with the virus do not develop any symptoms (asymptomatic) [16]. Symptoms such as fever, dry cough, and tiredness mark the beginning of the SARS-CoV-2 infection. The infection can also result in a variety of other symptoms, including loss of smell or taste, chest pain, sore throat, difficulty in breathing, chills, muscle aches, headache, vomiting, nausea, diarrhea, and a loss of appetite. The average incubation period for COVID-19 in patients ranges from 2 to 14 days [17,18,19]. Once in contact, the SARS-CoV-2 virus infects the lining of nasal, laryngeal, and lung mucosal membranes, thus producing a large number of virus particles that, in turn, activate the immune system and leads to the production of cytokines [20,21,22,23].

One of the most common COVID-19 manifestations is severe pneumonia, which may cause shortness of breath [20,24]. COVID-19 infection can be divided into three main phases [25,26,27]: the initial phase where SARS-CoV-2 replicates and symptoms are generally mild; this is followed by a phase where respiratory symptoms continue, and infection stimulates the adaptive immune system, which if remaining uncontrolled, leads to a third phase causing hyper-inflammation and death [25]. SARS-CoV-2 can also directly bind to other cells expressing ACE2 (angiotensin-converting enzyme 2), such as renal tubular cells and testicular cells, causing damage to the kidney and testicular tissue of the patients [28,29,30]. However, the evidence of COVID-19 affecting reproductive organs remains contentious and needs to be validated. COVID-19 also affects the digestive system, which leads to loss of appetite, diarrhea, vomiting, and abdominal pain [25,31,32]. The disease could also affect the liver leading to elevated levels of aspartate transaminase and alanine transaminase [33,34,35]. In the early stage of infection, antivirals (e.g., remdesivir, lopinavir) can provide some benefit in limiting the virus spread, while immunomodulatory therapies such as anti-interleukin (IL)-6 or corticosteroids may be helpful in the more advanced stages [36,37,38,39]. To date, there are no infallible druggable targets established to treat COVID-19 associated pathologies [40]. Efforts have been made to develop new drugs that target the SARS-CoV-2 virus and host surface receptor binding, regulating endocytosis machinery; viral replication, multiplication, and assembly; or targets that regulate host-associated innate immunity [41,42,43,44,45,46,47].

## Section: 1. Introduction › 1.2. Advancement of Computational Methods to Combat COVID-19 Pandemic

In the last two decades, evolvement in computational approaches and modeling led to a paradigm shift in research methodologies related to infectious diseases [48,49,50,51,52,53,54]. Advancements in AI algorithms have helped to analyze a great volume of data and make meaningful predictions, conclusions, and automation [55]. AI is described as an effort to mimic the cognitive functions of a normal brain, such as problem solving and learning with the help of data [56]. The wide spectrum of AI in healthcare includes rule-based systems, classical ML and deep learning (DL). ML is a branch of AI that solves problems based on experiences gained from the curated data, usually referred to as training data, and makes predictions or decisions without any explicit instruction by the user [57]. Based on the input data, ML can be divided into two categories- supervised and unsupervised ML. The supervised ML model is constructed based on labeled data, known as training data, and this model is used to make predictions on new data. Conversely, in unsupervised ML, the supplied data are unlabeled and categorized without any previous knowledge [57]. Apart from the classical ML algorithms such as support vector machines, random forest classifiers, k-means and hierarchical clustering etc., recently, artificial neural networks (ANN) have become quite popular. ANNs are ML algorithms that mimic biological neural networks based on the mathematical structure to solve complex data-oriented problems [58]. Deep learning comprises advanced ANN-based ML algorithms in which multiple layers of processing units are used to deduce higher-level features from the data [59]. Most of the supervised ML algorithms can work with small datasets that are organized and labeled, whereas deep-learning programs can work with raw, unstructured data and require much larger volumes [60,61]. AI is being utilized in healthcare and biomedical research with a variety of tasks such as basic research, medicine, patient and disease management, image analysis and medical devices [62]. For example, IBM’s Watson for Oncology tool has convincingly predicted drugs for the treatment of cancer patients. Similarly, Microsoft’s Hanover Project proposes a personalized cancer treatment option based on AI [57,63]. Predicting drug toxicity using ML techniques has also gained popularity over the years [64]. After the onset of the COVID-19 pandemic, several efforts have been made to apply AI techniques on data such as CT scans, X-ray images, and cough sounds to follow infection [65,66,67]. Several studies have utilized omics data to find repurposed drug candidates for COVID-19 treatment [68,69]. In addition to this, data from social media, mobile phones and news articles have been utilized to track potential hotspots and community infections [70]. Usage of these big datasets requires a careful balance between public health and protecting data privacy [71].

In this review, we will discuss how AI has been utilized during this pandemic to address key issues such as surveillance, detection, rapid diagnosis, drug discovery, and vaccine development (Figure 1). Furthermore, we will discuss several examples of ML and other AI applications that have been used previously in fighting complex diseases such as cancer and tuberculosis and can be applied in the case of COVID-19.

The application of Artificial Intelligence in handling COVID-19 pandemic. The life cycle of SARS-CoV-2 and COVID-19 disease etiology is shown on the left panel. On the right, examples of different applications of Artificial Intelligence (AI) are shown. AI-related tools can be useful in the accurate diagnosis of COVID-19 disease, finding new drugs, and analysis of data from clinical trials.

## Section: 2. Application of AI in Surveillance of COVID-19

AI-based surveillance models can play a major role in predicting global infectious disease threats [72,73]. An integrated modeling approach that combines different types of individual data models such as travel data, mobile phone location tracking, epidemiological and behavioral pattern data is key to build a successful surveillance system [74]. This modeling approach requires an understanding of the target population at an individual level and, most importantly, during mass gatherings to restrict the spread of infection [75]. This type of integrated model-based platform could help identifying threats from infectious diseases of international concern as well as in anticipatory surveillance. Such integrated approaches also encourage mathematical modeling that can estimate the spread of infectious diseases with mass gatherings; simulate the effect of public health interventions aimed at the local and global level [76]. For example, a study predicted the infectious disease vulnerability index (IDVI) through an integrated modeling approach during the onset of coronavirus infection in Wuhan, China [77,78,79]. Multiple indicators such as travel information, country’s socio-economic condition, politics and health management facilities, and economic metrics are used to calculate IDVI scores [77,78,79,80]. IDVI scores range from 0 to 1, and a lower score signifies potential epidemic threats. Further, travel history along with common signs and symptoms through mobile phone-based online surveys can be used to build an AI-based model to predict risk factors [81].

Different methods, such as multi-layered perceptron (MLP) and adaptive network-based fuzzy inference system (ANFIS), have been demonstrated to predict COVID-19 outbreak [82,83], whereas DL and other ML algorithms were favorable towards predicting COVID-19 spread in the future [84] (Figure 2). Alongside, mobile data-based surveillance, social networking data and associated public sentiment analysis are essential tools for the better management of the COVID-19 pandemic [85]. Contact tracing plays a major role in minimizing the spread of infection during any epidemic or pandemic. Mobile phone-based data are a great source to track individual activity, but it has to be wisely used as individual data privacy and security are always a concern. Different programs based on mobile applications, such as WeChat, have been developed, which utilizes smartphone-based GPS and social media data to perform contact tracing and risk assessment [86]. While such contact tracing may result in high false positives, a novel method has been proposed which uses data from six different smartphone sensors for contact tracing. This method outperforms other methods and identifies ~95% fewer false positives, reaching up to ~87% accuracy [87]. In Table S1, we have summarized some of the AI/ML models uses and their application in the surveillance of COVID-19.

In addition to contact tracing and predicting disease outbreaks, AI is also used in understanding COVID-19 risk assessment and public perception [88]. Combining data from different sources such as social media, demographic, mobility, and COVID-19 related epidemiological data, Ye et al. developed an AI-based program, α-Satellite. The development of α-Satellite required initial work on different tools that gather COVID-19 associated information from different sources in real-time and developed an attributed heterogeneous information network (AHIN) to use this data in a thorough manner. The key advantage of AHIN is that it can learn in a situation where data availability is restricted. Further, α-Satellite framework uses conditional generative adversarial net (cGAN) to create synthetic data and improve the AHIN. Finally, the α-Satellite uses a novel heterogeneous graph auto-encoder (GAE) to combine data from the close-by geographical areas and find the risk of any location. This program could be useful in assessing the risk at a community level in a hierarchical manner (geographical location such as state or country) [89]. The above applications of these powerful techniques suggest that the implementation of AI and ML models may provide a better prediction and management of pandemics in real-time [73,90,91].

The role of AI tools in the COVID-19 pandemic. (A) The illustration depicts applications of ML and other AI tools in curated datasets from different paradigms to address the challenges associated with the COVID-19 pandemic. (B) An overview of existing AI techniques.

## Section: 3. Role of AI in the Screening of COVID-19 Infected Patients and Diagnosis

The sudden increase in COVID-19 cases is imparting high pressure on healthcare services worldwide [92,93]. Precise diagnosis of COVID-19 infected patients is fundamental in the process of providing proper treatment and avoiding the overburdening of the healthcare system. Large-scale testing during a pandemic has been a challenge due to huge costs and a shortage of resources. Even the widely used RT–PCR test for the detection of COVID-19 positive (+) or COVID-19 negative (-) patient samples are not free from false-negative reports in low viral load conditions coupled with mild or no symptoms. Therefore, additional assistance from different AI-based modalities can be highly beneficial for accurate screening and diagnosis of COVID-19 and many other diseases [94,95] (Figure 1). A large number of symptom-based screening tools using decision rules can be thought of as one of the most common applications of AI. Further, we discuss some of the more advanced forms of AI, including ML and DL.

## Section: 3. Role of AI in the Screening of COVID-19 Infected Patients and Diagnosis › 3.1. Imaging-Based Diagnostics

The various imaging techniques such as chest X-rays (CXR) and Computerized Tomography (CT) images are shown to be suitable in identifying COVID-19 (+) patients. However, the visual analysis of these images by a radiologist is subjective and therefore also prone to error. Researchers have shown that computer vision-based models can be accurate in analyzing these images [65,66,67]. Recently, an AI-based model has been developed which compared the performance between CT-based and CXR-based datasets [96]. Another study by Wang et al. showed that a convolutional neural network (CNN)-based model can be useful to identify COVID-19 infection in patients through CXR images [97]. A mathematical construct, CNN adaptively learns spatial hierarchies of data such as images [98]. The application of CNN-based deep learning methods in radiological image analysis for COVID-19 patients is discussed in great detail in a recent review [99]. A unified slice thickness is one of the limitations of the CT images, and generative adversarial networks-based AI models can overcome this challenge [100]. In another study, combining clinical and radiological imaging data with AI algorithms is shown to be more effective in identifying COVID-19 (+) patients than a senior thoracic radiologist [101]. An AI-based predictive diagnostic model was built based on chest CT findings with clinical symptoms, exposure history and laboratory testing data. This model identified COVID-19 infection with ~84.3% sensitivity and AUC (Area under the ROC Curve) of 0.92 [101]. Interestingly, researchers came up with a new set of descriptors based on the shape and texture of chest x-ray images in combination with a support vector machine (SVM) to differentiate COVID-19 from bacterial and viral pneumonia. This SVM-based model achieved ~89% accuracy and sensitivity while significantly lowering the computational cost as observed in DL-based methods [102]. In addition, Belfiore et al. projected the role of Thoracic VCAR (GE Healthcare, Milan, Italy), an AI-based software in COVID-19 diagnosis. The software is capable of doing automated lung segmentation and quantitative measurements to help in the assessment and follow-up of lung diseases [103,104]. Overall, these examples suggest that ML and other AI-based approaches can be useful in the objective assessment of imaging data obtained from COVID-19 patients.

## Section: 3. Role of AI in the Screening of COVID-19 Infected Patients and Diagnosis › 3.2. Blood Analysis Tests

Routine blood exams provide various blood cell and other biochemical parameters that can be used for differential diagnosis. Generally, routine blood exams data in numerical form such as Whole Blood Cells count, blood sugar level, Hemoglobin, etc., can be used as a feature set to build classification and regression models. Combining blood tests with advanced AI-based methods can significantly improve the sensitivity and accuracy of diagnosis [105,106,107]. In the recent past, several studies have been published which show the applicability of these techniques in predicting common diseases [107,108]. Alsheref et al. assessed various ML algorithms to detect blood diseases. In this study, the author assessed the predictability of commonly used supervised algorithms to detect blood diseases, and they achieved ~98% accuracy to predict the occurrence of blood disease with LogitBoost algorithms [108]. Park et al. built three models, LightGBM and extreme gradient boosting (XGBoost) ML models and a DNN (deep neural network) based model on 5145 cases and 326686 laboratory tests [109]. The authors proposed that among the three models, the ensemble model showed 81% F1-score and ~92% prediction accuracy against the most common diseases [109]. Not only does this blood analysis detect the disease, but it can also tell about the severity of a disease. In another such example, Karahan et al. has proposed an ML model to detect disease severity in Chronic venous insufficiency (CVI), which is a progressive inflammatory disease. In this work, the author concluded that variation in fibrinogen and albumin levels can predict clinical class with ~75% sensitivity and disease severity with ~90% sensitivity in patients with CVI [110]. A data mining and a statistical analysis-based study was conducted by Zeng et al. on data from 3090 COVID-19 patients. These data were derived from a total of 15 studies showing variability in neutrophils and lymphocyte count. The ratio of the blood cells can be utilized to monitor the severity and progression of the disease [111]. Despite the ethical and commercial boundaries across the globe, researchers are trying hard to make such useful data available in the public domain. Aljame et al. have utilized open source data provided by Albert Einstein Hospital in Brazil. The ensemble model was built upon 5644 data samples to attain an outstanding performance with very high accuracy (~99.88%) and sensitivity (~98.72%) [112]. In one such study, two ML classification models were built based on hemato-chemical values from routine blood exams. This study was conducted on 279 patients with COVID-19 symptoms, and 177 were diagnosed as positive, while 102 as negative. ML models were able to predict positive and negative samples with high sensitivity (~95%) and accuracy (~86%). This study demonstrated the applicability and clinical usefulness of combining blood examinations with ML as an alternative to routine genomics-based approaches such as RT-PCR [113]. In another independent study, the researchers used random forest (RF), ANN, and a simple statistical test to diagnose SARS-CoV-2 in patients using full blood cell count data without knowing the symptoms or history of the patients. These techniques were able to diagnose SARS-CoV-2 among patients with a high accuracy range (AUC = 94–95%) from the community (AUC = 80–86%) [114]. Ko et al. have shown that these models can detect the risk of mortality and can be transformed into user-friendly and accessible open-source applications. The beatcovid web application can be utilized by any healthcare system for the management of COVID-19. The application can predict mortality with very high accuracy (~92%), specificity (~91%), and sensitivity (~100%) [115]. Despite the several successful trials and encouraging results, more effort is required to build a more generalized model based on robust datasets.

## Section: 3. Role of AI in the Screening of COVID-19 Infected Patients and Diagnosis › 3.3. Analysis of Text and Voice Data

In recent times, natural language processing (NLP) aims to develop computational algorithms to interpret human languages [116,117] (Figure 2). NLP and text mining have been adopted in medical research to extract and analyze data from various sources such as patient symptom records, sentiment data from social networking sites, and news articles to predict a medical condition or a disease outbreak. During the COVID-19 pandemic, efforts have been made to adopt such techniques to fight COVID-19 transmissibility.

A recent study has used textual clinical reports to predict the occurrence of COVID-19 in patients. In this work, featured engineering algorithms, such as Bag of Words (BOW), report length, and Term Frequency/Inverse Document Frequency (TF/IDF), were applied to look for the best feature in the textual dataset. Selected features were used to train traditional and ensemble ML classifiers. The results suggested an outstanding accuracy of ~96.2% in detecting COVID-19 positive cases [118]. An AI-powered application, named AI4COVID-19, proposed that it is capable of diagnosing patients based on a sound recording of cough. This application communicates with the cloud and transfers the voice recording, and within seconds receives predictions based on the cloud-based AI engine [119].

## Section: 4. Application of AI in Predicting COVID-19 Outcome

While the accurate detection of SARS-CoV-2 in patients is the critical step towards treatment, a fast and early clinical assessment of the disease severity is also crucial to support decision making and logistical planning in healthcare systems [120,121,122]. Patients’ characteristics such as age, varied clinical symptoms, and comorbidities can help in categorizing the infection severity, need for hospitalization and predict the disease outcome [122,123]. Such prognosis-based prediction models for a given disease support the physician’s decision-making and assist in the screening of high-risk patients.

The mortality of COVID-19 patients can be potentially reduced by an early intervention, which is only possible by an accurate and early prediction of disease progression. XGBoost classifier, a high-performance ML algorithm, is used to identify three potential biomarkers; lymphocytes, Lactate dehydrogenase (LDH), and high-sensitivity C-reactive protein (hs-CRP). The XGBoost algorithm has great interpretability potential due to its recursive tree-based decision system and is shown to be ~90% accurate in predicting patient mortality approximately 2 weeks in advance [124]. Similarly, in another study, SARS-CoV-2 induced pneumonia was predicted based on seven laboratory parameters (prothrombin activity, urea, white blood cell, interleukin-2 receptor, indirect bilirubin, myoglobin, and fibrinogen degradation products) [125]. These parameters were identified by applying the least absolute shrinkage and selection operator (LASSO) logistic regression model based on features selected by the mRMR algorithm. This study showed that these multiple feature-based models can produce ~98% sensitivity and ~91% specificity in predicting SARS-CoV-2 pneumonia prognosis [125]. AI modalities can also help in predicting the personalized risk of adverse events or COVID-19 disease trajectory [126,127]. Further, different datasets such as patient health, travel history, geographical location, and demographic data were combined to build an AdaBoost Random Forest model. This model predicted the possible outcome of a COVID-19 patient with ~94% accuracy [128]. A study on a cohort of 13,690 patients has shown that the ML model can be applied effectively on a combined feature set. In this study, the patients’ clinical, demographic, and comorbidities data were analyzed to predict COVID-19 outcome, which helps the physician in decision-making [129]. Another example describes the better predictability of ventilation requirements for COVID-19 patients. This prediction uses ML models over physiological scoring based on modified early warning systems (MEWS). This model successfully predicted the need for a mechanical ventilator for a COVID-19 patient during hospitalization and helps in management of COVID-19 and improved patient care [130]. Another mortality prediction model for COVID-19 patients was built using the XGBoost algorithm based on clinical and demographic data. A combination of three main features, namely the type of patient encounter, minimum oxygen saturation, and age, showed high accuracy (AUC score of 0.91). This model can be easily implemented due to these three highly accessible clinical features pertaining to COVID-19 disease [131].

In Table S2, we have presented GitHub repository links from peer-reviewed literature that can be directly implemented in practice for COVID-19 diagnosis or disease outcome prediction to accelerate COVID-19 identification in patients, deciding proper treatment regime and possibly minimizing mortality.

## Section: 5. Application of AI in Drug Discovery

Antiviral agents and immunomodulators are the two major classes of compounds tested against COVID-19 [132,133]. Several repurposed drugs such as remdesivir, ivermectin, lopinavir, ritonavir, and other antiviral drugs emerged as somewhat effective treatment strategies for COVID-19 in the preliminary clinical studies [134]. So far, only a few drug candidates have looked promising as potential COVID-19 treatments [135]. AI algorithms enable the design of sophisticated and advanced drug development pipelines that can reduce the time and cost of the lengthy drug discovery process [136,137,138,139]. AI-based techniques are shown to be useful in the identification of repurposable drug candidates [69,140,141,142]. By applying various supervised ML and DL algorithms on experimental data, these techniques are proven to be more effective in identifying new antiviral drugs [143] (Figure 2). In a recent publication, Zeng et al. proposed that the AOPEDF (arbitrary-order proximity embedded deep forest approach) algorithm can predict novel drug-target interactions [144]. Based on a DL-based drug–target interaction model, Beck et al. predicted drugs that can target SARS-CoV-2-related proteins and are commercially available [145]. Pham et al. proposed DeepCE, a deep learning algorithm to repurpose drug compounds. The author demonstrated the application of DeepCE to predict potential leads for COVID-19 treatment [146]. In another study, an ML model was built to predict new indications for existing drugs and herbal compounds based on 1330 positive drug-disease associations though it was not directed against COVID-19 [147]. Overall, there is an enthusiasm for AI-based methods in finding repurposed drugs against SARS-CoV-2 [142,148,149]. Compounds with a potential likelihood of being a drug candidate demand sophisticated infrastructure and bioassay for the assessment of their toxicity, efficacy and response, interaction with other biomolecules, bioavailability, and metabolism [150,151]. The assessment of these pharmacokinetic properties of a drug candidate is considered a primary cause of failure of a drug during clinical trials [152]. For the SARS-CoV-2 drug discovery, an insight from the past studies that have combined cheminformatics and ML algorithms could be very useful [153]. ML learning algorithms are applied in the screening of millions of compounds against a druggable target in a very fast manner [154,155]. Using a similar method, Zhang et al. proposed a deep learning-based pipeline that is useful to screen peptides and small molecules against SARS-CoV-2 viral proteins [156]. The study used a densely fully connected neural network (DFCNN), which extracts more features from the data and allows faster virtual drug screening. To train DFCNN, the authors used the PDBBIND database, which renders structural information of proteins and macromolecular complexes [156]. In a recent study, Xu et al. used inhibitors of COVID-19 3CLpro and SARS 3CLpro proteins to build an ML-based model to predict novel inhibitors. Their training data set includes 66 active and 66 inactive compounds [157]. They employed six different ML classifiers (RF, SVM, LR, NB, DT, KNN) in their study. Based on probability (based on area under the ROC curve or AUC), the authors used Logistic Regression to screen the library. Using ML algorithms, Kabra et al. predicted antiviral peptides, which bind to SARS-CoV-2 protease [158]. ML algorithms used in the study allowed authors to work with SARS-CoV-2 virus sequences from different countries in a quick manner [158]. AI strategies developed here will not only be path breaking for COVID-19 drug discovery but also pave the way to develop new drugs against other infectious maladies [159,160,161,162]. We have tabulated the primary example of AI-based models used in COVID-19 drug discovery in Table S3.

In addition to this, ML-based methods can be effectively used in biomarker identification and drug sensitivity prediction that can improve clinical success rates [163,164]. With so many therapies emerging for COVID-19, AI-based tools can help in clinical trials andnovel treatments that are safe and effective (Figure 1). These algorithms can also be used to analyze the data from failed or suspended drug trials for COVID-19. Analysis of this observational evidence can be further used to assess uncertainty and generate causal inference to improve the design of future studies [55]. One way to improve the speed of clinical trials for drugs against COVID-19 is to avoid the traditional multi-phase route and design dynamic ML-based adaptive trials that start with a small group and continue into a trial-collection loop in which the collected data are used to determine pivot or continuation [30,165,166].

The above examples show several applications of ML and other AI techniques in drug target detection and assessing the impact of the mutation on existing targets, which can be utilized in the case of SARS-CoV-2 and associated pathologies (Figure 1).

## Section: 6. Application of AI in Vaccine Development and Delivery

One of the best possible strategies to combat COVID-19 is to develop a vaccine. Several virus components are used to develop an effective vaccine, namely the whole virus, the Spike (S) protein, Nucleocapsid (N) protein, and Membrane (M) protein [167,168,169,170]. Some of the vaccine candidates that got EUA approval during the COVID-19 pandemic, e.g., Comirnaty (Pfizer/BioNtech), mRNA-1273 (Moderna), Covishield (Oxford-AstraZeneca) and JNJ-78436735/Ad26.COV2.S (Johnson and Johnson), have been developed exploiting these viral components [171,172,173,174,175,176,177]. Though these vaccines are authorized by the the United States Food and Drug Administration (FDA), these possible interventions still have safety concerns and are less likely to give complete protection [178]. More so, side effects such as allergic reactions have been reported on the administration of these vaccines [179,180,181]. The challenges in manufacturing, storage, logistics, and issues related to the safety and efficacy of different vaccine candidates can be overcome by AI algorithms. As for any vaccine-induced immune response, the first step after COVID-19 vaccine administration is the presentation of antigenic peptides by major histocompatibility complex (MHC) class II molecules (or called Human Leukocyte Antigens) present on the surface of antigen-presenting cells. These exogenous peptides displayed by MHC class II molecules bind to the T-cell receptor of CD4+ T cells. Similarly, MHC class I molecules bind to CD8+ T-cells and activate the cytotoxic lymphocytes. Together, MHC-I and MHC-II molecules induce antigen-specific responses, which are central to vaccine-induced immunity. One of the most direct applications of ML and other AI-based strategies in vaccine development is to identify the presence of antigenic peptides presented by MHC-II. As an example, ML was used to develop programs such as MARIA (major histocompatibility complex analysis with recurrent integrated architecture) and MoDec that predicts antigen presentation [182,183,184]. Various AI-related tools have been used to analyze SARS-CoV-2 viral peptide presentation on MHC molecules from patients to understand natural immunity. Such an understanding may directly or indirectly help discover COVID-19 specific immune response and assist in designing an effective vaccine [185,186,187]. Ong et al. have used Vaxign-ML-based reverse vaccinology tools to predict targets that can be used to develop a safe and effective COVID-19 vaccine [169,188].

On the other hand, AI tools can help the local governments to assess public perception of COVID-19 vaccines and help in spreading vaccine awareness to the public. The main role of AI is basically to analyze all previous data and predict where the disease may progress in the future. This will not only help in analyzing but also understanding and suggesting paradigms for the development of future vaccines based on the number of cases studied, including confirmed, recovered, and patients who succumbed to the disease. The key advantages of AI are speed and accuracy with which it identifies these cases and its utility in screening for diagnosis and drug/vaccine development. Arshadi et al. developed Corona-DB-AI, a collection of compounds, peptides, and epitopes related to COVID-19 therapeutics. This dataset can be used for training models in order to extract COVID-19 treatment [189]. More recently, a study conducted at MIT’s computer science and AI lab has enlightened the use of AI in predicting its efficacy based on racial and minority populations [190,191]. The study has used two ML-based programs OptiMax and EvalMax, which work in tandem. OptimAX helps in the identification of the relevant peptide and designing peptide vaccine. EvalMax works with genetic structures of various racial ethnicities and finds which HLA (Human Leukocyte Antigen) haplotype frequencies work with specific peptides. The results with Optivax suggested that Spike protein of SARS-CoV-2 alone may not be effective in providing complete immunity to all the racial ethnicities. The study suggests that the addition of some peptides can enhance the immune response [190]. AI modalities are also used in effective vaccine design and assessing the safety of these vaccines [192,193,194].

## Section: 7. Application of AI in Predicting Possible Viral Mutational Landscape

High infectivity combined with a high mutation rate has made COVID-19 very challenging and deadly; thus, new SARS-CoV-2 infections are increasing unprecedentedly. [195]. Recent research based on AI has provided significant insight in predicting these mutational landscapes [196]. Hie et al. have developed an NLP-based algorithm that can predict mutations that have the potential to escape from the immune system and preserve the pathogenic capability of a virus strain. Using this model, authors are able to predict structural escape patterns of various viruses, including SARS-CoV-2 [197]. In a similar work, Salama et al. have presented a proof of concept by applying neural network and rough set technique on the genetic mutation prediction of Newcastle Disease Virus. The proposed technique verifies a correlation between the mutation of nucleotides and successfully predicts the nucleotides in the next generation [198]. Malone et al. used an AI-based algorithm to develop a broad-spectrum vaccine against COVID-19 that can provide maximum coverage for various COVID-19 strains. In this study, authors have evaluated around 3400 SARS-CoV-2 sequences that are used in the model for predicting epitope hotspots [199]. An recurrent neural network (RNN)-based Long Short-term Memory (LSTM) model has also shown very promising results in predicting the future rate of mutation in a person’s body after COVID-19 infection. Haimed et al. proposed a viral reverse engineering approach in which they try to find pattern similarity in viral protein and genomic sequences, and further mutational changes were extracted based on the phylogenetic tree to capture the evolutionary behavior [200]. Finally, a possible viral evolutional instance was predicted based on these two observations combined with the LSTM model [200]. The availability of several vaccines worldwide has created confidence among the community to tackle this challenge. However, the emergence of new and deadly strains, such as the B.1.617.2 (delta) variant, puts the healthcare system under pressure and uncertainty about the future efficacy of the available vaccines. Not only the prevention but the treatment of COVID-19 is also affected by new variants; hence, these methods have emerged as a key in tracking, predicting, and forecasting the mutational landscapes to manage COVID-19 disease [201,202].

## Section: 8. Challenges and Limitations Associated with AI

AI is poised to play an increasingly important role in all areas of healthcare. However, the real-world scaling of such solutions poses many challenges and limitations. Validation, generalization, explainability, interpretability, risk mitigation, fairness, and inclusiveness are some of the key challenges in making AI-based decisions in medical and public health settings [203]. Generalization refers to the ability of AI-based algorithms to perform efficiently in different settings. Several concerns need to be addressed as the use of ML and other AI tools are increasing day to day in critical decision making [204]. In AI, generalizability usually attributes to the ability of an ML algorithm to be effective across a range of inputs and applications [205]. The narrow context models always have risks that they can fail at the broad level when applied with different datasets [206]. However, generalizability cannot be summarized by a universally agreed definition [207]. Owing to the participation of AI in different applications, it is critical to create and govern these techniques in a credible and fair manner. In clinical and health care setups, the absence of transparency within the models, the privacy of the patient data, and the safety and liability-related issues are major challenges in terms of ethical and regulatory aspects of AI [208]. AI governance deals with issues such as bias and lack of transparency by engaging different stakeholders. The prime focus of ethical governance should be on handling ethical issues involved in clinical operations such as fairness, transparency, and privacy [209,210]. Explainability and interpretability are two important factors that need governance to monitor and enhance AI algorithmic fairness, transparency, and accountability [210]. In addition to this, ethical auditing can examine the inputs and outputs of AI algorithms and models for bias and potential risks [211]. One of the drawbacks of AI-based models is that their real utility remains largely untested. For example, in the case of COVID-19 research, AI-based models are theoretical [212,213]. For instance, although minimum oxygen saturation was identified as an important mortality predictor, it needs to be modeled alongside the supplemental oxygen delivered, a piece of data that may be missing in many models.

However, most of these challenges are being proactively addressed by the AI researcher community. In the clinical settings, COVID-19 has triggered the need to go digital, improve data literacy and explore assistive algorithms. Grassroot-level applications of AI in addressing public health and the supply chain are also helping in connected care [214]. In the near future, some of the AI tools may be employed in the decision making in medical supplies, humanitarian aids, population risk assessment, and at a certain level, clinical care and treatment [126,214,215].

## Section: 9. Discussion and Conclusions

The world is going through another wave of COVID-19 infections. Worldwide, daily rates of new infections have jumped significantly since March 2020, with deaths rising—this horrid emergency is again putting strain on the heavily-burdened healthcare system throughout the world. To control the pandemic and related stress on healthcare, scientists are testing the applicability of AI strategies [71,216,217,218,219,220,221,222,223,224,225].

The computational approaches have proven very effective in basic research, diagnosis, and treatment to fight against infectious diseases [54,226,227,228,229,230,231,232,233]. AI-based approaches have emerged as a useful tool/method in surveillance, diagnostic and discovery of new therapeutics [139,187,224,234] (Figure 2). Combining a vast variety of data such as blood exams, clinical images, and recording of cough sound with advanced ML techniques provides a quick and reliable alternative for diagnosis and assessment of the disease severity. COVID-19 patients show symptoms such as fever, fatigue, muscle ache, cough and respiratory issues. Since clinicians cannot identify patients who succumb to the disease early on, the AI/ML tools are shown to be effective and helpful in making clinical decisions. From evaluating the safety and efficacy of therapeutics, to help with imaging data analysis or contact tracing, AI has provided novel solutions in the fight against COVID-19. For example, AI is helping overcome barriers between repurposed drugs, clinical testing of therapeutic strategies, and drug authorization [165,166,235,236]. The application of AI strategies in COVID-19 also faces certain challenges. To fully utilize these strategies, it is important to address issues related to data privacy, concerns on data collection and handling practices, and governmental oversight. Even in the pre-pandemic 2019, many experts believed that AI has the potential to revolutionize healthcare, and while the risk of algorithmic bias and data privacy concerns are very real, there is little question that AI has proven its utility in the fight against COVID-19.

## Section: Acknowledgments

The authors would like to thank Andaleeb Sajid for the critical reading of the manuscript.

## Section: Supplementary Materials

The following are available online at https://www.mdpi.com/article/10.3390/pathogens10081048/s1, Table S1: AI application in Surveillance of COVID-19, Table S2: Ready-to-use AI-based models available in GitHub for diagnosing COVID-19 and predicting disease outcome, Table S3: The application of AI-based models used in COVID-19 drug discovery.

Click here for additional data file.

## Section: Author Contributions

Conceptualization, G.A. and J.J.; Literature Curation, G.A., J.J., R.S.M., N.S. and T.S.; Writing—Original Draft Preparation, G.A., J.J., R.S.M., N.S. and R.V.; Writing—Review and Editing, G.A., J.J., R.S.M., N.S., T.S. and R.V.; Visualization, J.J. and R.S.M.; Project Administration, G.A. and T.S. All authors have read and agreed to the published version of the manuscript.

## Section: Funding

This work was not funded by any external grant.

## Section: Institutional Review Board Statement

Not applicable.

## Section: Informed Consent Statement

Not applicable.

## Section: Data Availability Statement

No new data were created or analyzed in this study. Data sharing is not applicable to this article.

## Section: Conflicts of Interest

The authors declare no conflict of interest.

## Section: Associated Data

Click here for additional data file.

## Section: Associated Data › Supplementary Materials

Click here for additional data file.

## Section: Associated Data › Data Availability Statement

No new data were created or analyzed in this study. Data sharing is not applicable to this article.


---

# Combining generative artificial intelligence and on-chip synthesis for de novo drug design

- **Authors:** Francesca Grisoni, Berend J H Huisman, Alexander L Button, Michael Moret, Kenneth Atz, Daniel Merk, Gisbert Schneider
- **Issuer:** Science advances
- **Type:** Scientific article
- **Published:** 2021-06-11
- **Language:** en
- **DOI:** 10.1126/sciadv.abg3338
- **Source:** https://pubmed.ncbi.nlm.nih.gov/34117066/
- **Licence:** CC-BY-NC

## Section: Abstract

Generative deep learning and miniaturized bench-top synthesis were combined to automate the design of novel LXR agonists.

## Section: INTRODUCTION

Rapid iteration of the molecular design-make-test-analyze (DMTA) cycle has the potential for making “better decisions faster” (1, 2), with numerous applications in drug discovery and related fields (3, 4). Recent advances in chemical reaction monitoring and optimization, computing hardware, and algorithms have boosted the automation of several parts of the drug discovery process, such as robotic synthesis (5–8), computational molecular design (9–11), and synthesis planning (12–15). Standardized experimental procedures with robotic assistance increase the reproducibility of results, reduce errors, and decrease the consumption of materials, thereby contributing to “green chemistry” (16). Furthermore, reasoning with machine intelligence supports the discovery of novel drug-like molecules by freeing the molecular design and optimization process from personal biases (1). Pioneering studies combined microfluidics platforms with machine intelligence for synthesis planning (7, 17) as well as automated hit finding and hit-to-lead optimization in combinatorial libraries (8, 18). Computer-assisted molecular design is a critical element of this automation process. Molecular structure generation is often performed in a “rule-based” manner, i.e., by using algorithms for molecule assembly from predefined virtual reactions and reactants (19). Generative deep learning models extend the capabilities of rule-based de novo molecule generators by sampling new molecules from a latent chemical space representation (20–23), without the need for human-crafted molecule construction rules. Recently, the prospective applicability of “rule-free” generative deep learning for de novo molecular design has been demonstrated in combination with batch synthesis (9, 10, 24–26).

This study aims to pioneer the integration of generative molecular design with automated synthesis. Here, a recently published generative deep learning model (27) was adapted to generate compounds that are at the same time (i) bioactive on a selected macromolecular target and (ii) synthesizable on a bench-top microfluidic synthesis platform (16, 28). We challenged this automated DMTA pipeline to design liver X receptor (LXR) agonists from scratch, with minimal human interference. LXRs have emerged as promising drug targets because of their regulatory role in lipid metabolism and inflammation, thereby causing increased reverse cholesterol transport and reduction of atherosclerosis (29–32). With 28 molecules successfully synthesized and 12 fully validated for LXR activation in vitro, this present study pioneers the integration of generative artificial intelligence and automated synthesis by designing and experimentally testing the highest number of molecules reported thus far. The proposed modular framework has the potential to accelerate the DMTA cycle, thereby addressing one of the main bottlenecks of the preclinical drug discovery process (33).

## Section: RESULTS AND DISCUSSION

(A) A generative deep learning model (27) based on a long-short term memory network (34) was used to generate putative liver X receptor α agonists. The two-step network training procedure first trained the model on 656,070 compounds predicted as compatible with the microfluidics system and then fine-tuned this pretrained model with 40 known LXRα agonists. (B) The de novo generated molecules were filtered on the basis of their predicted synthesis route, using a set of 17 reactions specified in the SMARTS notation (“virtual reaction filter”). Molecular building blocks for synthesis were automatically retrieved from a commercial supplier catalog. (C) A total of 41 de novo designs were retained for synthesis on a microfluidics platform, which contained two syringes for the handling of reagents R1 and R2, a Cetoni Qmix element equipped with a Dean Flow microfluidic reactor chip, and a Rheodyne MRA splitter for automated sample transfer to an HPLC-MS system.

(A) Number of de novo designs retained by the virtual reaction filter depending on the pretraining (mean and SD over three replicates and 3000 sampled SMILES strings each). Compared to previous studies using bioactive molecules from ChEMBL (dashed lines) (9, 27, 38), this pretraining strategy (solid line) led to a larger number of compounds retained by the virtual reaction tool (P < 0.001, Kruskal-Wallis test), with up to 255 ± 97 more designs retained in each fine-tuning epoch. The epochs chosen for sampling are highlighted (epochs 15 to 20, gray rectangle). (B) Relative scaffold diversity (i.e., unique scaffolds/total number of scaffolds) of the de novo designs before and after applying the virtual reaction filter. No statistically significant difference in scaffold diversity was observed (Wilcoxon test, α = 0.05). (C) Analysis of 67 de novo designs retained for potential synthesis: 14 compounds were patented LXR modulators annotated in SureChEMBL or Reaxys (22%); 15 compounds existed in PubChem, of which 10 compounds are annotated as commercially available (15% of the total); 4 (6%) compounds lack vendor information; and 2 compounds (3%) were known LXR modulators annotated in ChEMBL27 [median inhibitory concentration (IC50)/EC50 ≤ 2 μM]. Thirty-seven compounds (55%) were not found in either PubChem, ChEMBL27, SciFinder, SureChEMBL, or Reaxys databases.

(A) Compounds 1 to 25 were synthesized in flow, and compounds 26 to 28 were purchased. (B) LXRα and LXRβ activation by compounds 1 to 28, as determined by the hybrid Gal4 reporter gene assays on the crude reaction products (test concentration ~10 μM, n = 2 with two technical replicates each). The numbers and color intensity indicate the fold activation of LXRα and LXRβ by each compound.

Potency was determined in cellular Gal4-based hybrid reporter gene assays. EC50 values and fold activation are reported as mean ± SE (n = 3). n.d., not determined.

(A) Selected de novo designs (1, 5, 13, and 15; Table 1), with atomic scaffolds highlighted with a thicker line, in comparison with the most similar fine-tuning compound (29, ChEMBL-ID: 379225, LXRα: EC50 = 0.4 μM, LXRβ: EC50 = 0.18 μM). The corresponding fragment similarity (Morgan molecular fingerprints and Tanimoto index) is indicated in percentage values. Compounds 1, 13, and 15 have novel atomic scaffolds compared to the known LXR modulators annotated in the ChEMBL27 database. Compound 5 has a similar agonistic effect on LXRα to compound 29, and it is five times more selective for the α subtype. (B) Automated ligand docking of compounds 5 (de novo design, blue) and 29 (fine-tuning compound, light gray) to the binding pockets of LXRα [PDB ID: 3IPS (63), left] and LXRβ [PDB ID: 1PQC (64), right]. GOLD (65) docking software was used. The solvent-accessible surface of the binding pockets is colored according to the computed electrostatic potential; red: negatively charged and blue: positively charged.

## Section: RESULTS AND DISCUSSION › Modular DMTA platform

The automated molecular design pipeline was composed of three modules (Fig. 1):

1) Module 1: A generative deep learning model (27) based on a recurrent neural network with long-short term memory (LSTM) cells (34). LSTM models were used for the design of new molecules represented as simplified molecular input line entry systems (SMILES) (35) strings (20, 21, 36). This LSTM-based “chemical language model” served as the de novo structure generator (Fig. 1A).

2) Module 2: A virtual reaction filter that captured 17 one-step reactions that were compatible with the microfluidics system (module 3). These reactions were encoded as SMILES arbitrary target specification (SMARTS) strings (37) (table S1). This filtering module selected those generated molecules that were synthetically compatible within the microfluidics platform (Fig. 1B).

3) Module 3: A microfluidics platform designed to minimize the amount of manual labor needed to optimize reaction conditions and synthesize focused compound libraries via one-step reactions. This compact bench-top system combined the automated retrieval of required reagents with the optimization of reaction conditions, online reaction product monitoring by high-performance liquid chromatography–mass spectrometry (HPLC-MS), and the collection of the reaction mixtures (Fig. 1C).

(A) A generative deep learning model (27) based on a long-short term memory network (34) was used to generate putative liver X receptor α agonists. The two-step network training procedure first trained the model on 656,070 compounds predicted as compatible with the microfluidics system and then fine-tuned this pretrained model with 40 known LXRα agonists. (B) The de novo generated molecules were filtered on the basis of their predicted synthesis route, using a set of 17 reactions specified in the SMARTS notation (“virtual reaction filter”). Molecular building blocks for synthesis were automatically retrieved from a commercial supplier catalog. (C) A total of 41 de novo designs were retained for synthesis on a microfluidics platform, which contained two syringes for the handling of reagents R1 and R2, a Cetoni Qmix element equipped with a Dean Flow microfluidic reactor chip, and a Rheodyne MRA splitter for automated sample transfer to an HPLC-MS system.

## Section: RESULTS AND DISCUSSION › De novo molecular design with artificial intelligence

The deep learning model (Fig. 1A) was pretrained on the SMILES strings of 656,070 commercially available molecules from four compound vendors (for details, see Materials and Methods), which were predicted by the virtual reaction system to be suitable for the on-chip synthesis within our microfluidics platform. This pretraining step enabled the model to capture the syntax of the SMILES strings. After pretraining, 83 ± 2% of the generated SMILES strings were unique and chemically valid (average of three repetitions, 3000 SMILES strings sampled at each repetition) and corresponded to novel molecules that were not included in the pretraining set. Compared to model pretraining performed in previous studies using bioactive molecules from the ChEMBL database (9, 27, 38), the approach used here resulted in a significantly higher proportion of de novo molecules that were considered synthesizable in flow (P < 0.001, Kruskal-Wallis test; Fig. 2A). This result highlights the capability of the deep learning model to implicitly learn the desired molecular features (here, compound synthesizability as defined by the virtual reaction filter), without the need for explicit, rule-based design constraints.

After pretraining, the model was fine-tuned with the SMILES strings of 40 LXRα agonists [median effective concentration (EC50) < 0.5 μM; tables S2 and S3] that were not included in the pretraining set. This fine-tuning step allowed us to focus the model on features that are shared by a chosen set of compounds (20, 39); therefore, it was used to bias the generation of new SMILES strings toward the chemical space of known LXRα agonists. Both the number of fine-tuning epochs for molecule design and the sampling temperature for SMILES string generation were automatically determined to optimize three parameters simultaneously (fig. S1), namely, the (i) predicted LXR activity (40), (ii) scaffold diversity (41), and (iii) pharmacophore similarity to the fine-tuning compounds (42). From the fine-tuned model (epochs 15 to 20), 3000 SMILES strings were sampled per epoch. Only those generated molecules that were not included in the pretraining and fine-tuning sets were retained, resulting in a total of 3626 de novo designs.

The retrosynthetic route of each generated molecule was predicted using the chosen set of 17 virtual reaction schemes (Fig. 1B). The compounds that could be decomposed into suitable reactants were kept (1911 designs). Notably, with a relative scaffold diversity equal to 23% both before and after reaction filtering, this filtering step did not markedly alter the scaffold diversity (41) of the designs. In general, no statistically significant decrease in the relative scaffold diversity due to the application of the virtual reaction filter was observed (α = 0.05, Wilcoxon test; Fig. 2B), rendering this method suitable for the design of reaction-focused compound libraries. Whenever the predicted reaction product was compatible with the microfluidics system (i.e., potentially synthesizable following 1 of the 17 selected reaction schemes), the predicted reactants were automatically retrieved from the Sigma-Aldrich catalog extracted from PubChem (43) (27 February 2019). For 67 designs, all of the required reactants were available.

A novelty check of the remaining 67 molecules was performed in PubChem (43), ChEMBL27 (44), SciFinder (45), SureChEMBL (46), and Reaxys compound databases (47). Of the 67 designs, 17 molecular structures corresponded to patented or otherwise known LXR agonists, with EC50 values ranging from 0.2 to 2 μM (Fig. 2C). This result indicated that the deep learning model correctly captured the relevant molecular features for LXR binding and activation. For the remaining 51 de novo designs (table S4), no information on bioactivity for LXR was available. Of this compound set, 37 molecules were novel, 10 compounds were commercially available, and 4 were described in the PubChem database but were unavailable for purchase (Fig. 2C). Overall, 41 compounds were selected for synthesis and 3 were purchased, while the remaining compounds were discarded because of unavailability or the high price of the respective building blocks.

(A) Number of de novo designs retained by the virtual reaction filter depending on the pretraining (mean and SD over three replicates and 3000 sampled SMILES strings each). Compared to previous studies using bioactive molecules from ChEMBL (dashed lines) (9, 27, 38), this pretraining strategy (solid line) led to a larger number of compounds retained by the virtual reaction tool (P < 0.001, Kruskal-Wallis test), with up to 255 ± 97 more designs retained in each fine-tuning epoch. The epochs chosen for sampling are highlighted (epochs 15 to 20, gray rectangle). (B) Relative scaffold diversity (i.e., unique scaffolds/total number of scaffolds) of the de novo designs before and after applying the virtual reaction filter. No statistically significant difference in scaffold diversity was observed (Wilcoxon test, α = 0.05). (C) Analysis of 67 de novo designs retained for potential synthesis: 14 compounds were patented LXR modulators annotated in SureChEMBL or Reaxys (22%); 15 compounds existed in PubChem, of which 10 compounds are annotated as commercially available (15% of the total); 4 (6%) compounds lack vendor information; and 2 compounds (3%) were known LXR modulators annotated in ChEMBL27 [median inhibitory concentration (IC50)/EC50 ≤ 2 μM]. Thirty-seven compounds (55%) were not found in either PubChem, ChEMBL27, SciFinder, SureChEMBL, or Reaxys databases.

## Section: RESULTS AND DISCUSSION › Microfluidics-assisted synthesis “on-chip” and first-pass screening

The 41 selected de novo molecules were synthesized in flow using the computationally suggested reactions. Of these compounds, 21 were predicted to be synthesizable by sulfonamide formation, 19 by amide bond formation, and compound 21 by ester bond formation (table S5). These predictions were in agreement with the distribution of the pretraining set, in which these three reactions were the most frequently predicted ones (98% of the molecules; table S6). On the basis of the respective HPLC-MS mass peaks, a total of 25 compounds were successfully synthesized on the microfluidics platform (1 to 25; Fig. 3A and fig. S2 to S26), corresponding to a 61% success rate. Compounds 26 to 28 were purchased.

Compounds 1 to 28 were subjected to preliminary testing for LXRα and LXRβ activation in hybrid Gal4 reporter gene assays with human embryonic kidney (HEK) 293T cells (48). This assay relies on chimeric transcription factors composed of the respective human nuclear receptor ligand-binding domain and the DNA-binding domain of the yeast protein Gal4. Gal4-responsive firefly luciferase served as the reporter gene, and a constitutively expressed Renilla luciferase was used for normalization and to monitor the toxicity of the test compounds. As a cellular test system, this assay also captured the cell penetration and cytotoxicity of the test compounds. Crude reaction mixtures (49, 50) of all 28 test compounds were analyzed at a single concentration for LXRα and LXRβ activation, with two independent biological duplicates (Fig. 2B). The test compound concentration was roughly adjusted to 10 μM based on the HPLC traces of the samples.

Reaction mixtures of compounds 1 to 17 displayed ≥3-fold LXR activation in this preliminary screening, potentially corresponding to up to 68% actives among the 25 synthesized molecules. “Fold activation” refers to the fold LXR-induced reporter activity compared to untreated [dimethyl sulfoxide (DMSO)] cells. The reference LXR agonist T0901317 (51) achieved 81 ± 3–fold activation of LXRα and 129 ± 7–fold activation of LXRβ in this assay (at 1 μM). Compounds 6 (52-fold LXRα activation) and 15 (60-fold LXRβ activation) exhibited the strongest response in the primary screening. All compounds showing more than twofold LXR activation had a hexafluoro-2-phenyl-isopropanoyl moiety, suggesting particular relevance of this molecular feature for the observed bioactivity. This feature was also present in 12 of the fine-tuning compounds (29%), with an additional 4 (10%) and 8 (20%) fine-tuning compounds having a hexafluoro-2-aryl-isopropanoyl moiety and an aryl-trifluoromethyl motif, respectively. All compounds showing more than 10-fold LXRα activation in the preliminary screening were selected for full characterization of the dose-response curve. Compound 7 was excluded because of its cytotoxicity. Compound 1 (twofold LXRα activation) was included in the follow-up study because of its novel atomic scaffold (41), which is not present in any molecule annotated for LXRs in ChEMBL27 or in a repository for nuclear receptor bioactivity (52).

(A) Compounds 1 to 25 were synthesized in flow, and compounds 26 to 28 were purchased. (B) LXRα and LXRβ activation by compounds 1 to 28, as determined by the hybrid Gal4 reporter gene assays on the crude reaction products (test concentration ~10 μM, n = 2 with two technical replicates each). The numbers and color intensity indicate the fold activation of LXRα and LXRβ by each compound.

## Section: RESULTS AND DISCUSSION › Bioactivity determination

The selected 14 compounds were prepared in-batch (scheme S1), purified, and fully characterized on LXRα and LXRβ (Table 1). Of these compounds, only compounds 2 and 3 were not confirmed to be active in the follow-up screening, suggesting that some other components in the crude reaction product mixture had activated LXRs in the primary screening. This finding indicates that the hexafluoro-2-phenyl-isopropanoyl moiety is not sufficient for LXR activation, despite its ubiquity among the de novo designs. The potencies of the remaining 12 LXR modulators were in the range of EC50 = 0.18 to 4.5 μM for LXRα and EC50 = 0.34 to 4.0 μM for LXRβ. In agreement with the primary screening data, compound 6 displayed the highest potency on LXRα, with an EC50 of 0.183 ± 0.006 μM and a 32-fold maximum activation. Compound 15 was confirmed as the most potent LXRβ agonist, with an EC50 of 0.34 ± 0.02 μM and 38-fold maximum receptor activation.

The bioactive hits had varying levels of fragment similarity to the fine-tuning compounds (25 ± 13% on average), in terms of their Tanimoto similarity on Morgan molecular fingerprints (53). Seven designs showed a fragment similarity <65% to all fine-tuning compounds (table S6). Compound 29 (Fig. 4A) was the nearest fine-tuning neighbor to several bioactive designs, with fragment similarity values ranging from 55 to 75%. Among those designs, bioactive compounds 1, 13, and 15 had novel atomic scaffolds (“Murcko scaffolds”) (41) compared to the LXRα and LXRβ agonists, with EC50 ≤ 50 μM annotated in the ChEMBL27 database (Fig. 4A). Furthermore, the scaffolds of compounds 1 and 13 were not present in any of the 15,247 molecules annotated in the Nuclear Receptor Activity (NURA) dataset (52). Compound 15, the most potent LXRβ agonist, had the lowest fragment similarity to the two closest fine-tuning molecules (table S6). These results corroborate the capacity of the computational pipeline to explore narrow regions of the chemical space defined by the known LXR agonists while, at the same time, providing hitherto unexplored molecular cores for further compound optimization.

All the confirmed active compounds had a preference for LXRα over the LXRβ subtype (Table 1). This observation reflects the desired effect of fine-tuning the artificial intelligence model with LXRα modulators. Compounds 17 and 5 showed the highest LXRα selectivity, with five to six times greater activity than on LXRβ (Table 1). Compound 17 activated LXRα less potently than its closest structural relative among the fine-tuning compounds (EC50 < 0.1 μM; table S6). Compound 5 (LXRα, EC50 = 0.26 ± 0.01 μM; LXRβ, EC50 = 1.30 ± 0.03 μM) constituted only a minor structural modification of fine-tuning compound 29, which had an EC50 of 0.4 μM on LXRα (54, 55) and an EC50 of 0.18 μM on LXRβ (54). While compounds 5 and 29 were comparable in their agonistic effects on LXRα, compound 5 was more than seven times less potent than 29 on the β subtype. As suggested by automated ligand-receptor docking, the preference for LXRα could be ascribed to the different positioning of compounds 5 and 29 in the LXRβ binding pocket (Fig. 4B). While compounds 5 and 29 are predicted to adopt similar binding poses within the LXRα pocket [root mean square deviation (RMSD), <1.8 Å], compound 29 was predicted to engage in an additional CH3-π interaction in the binding pocket of LXRβ. This hypothesis potentially explains the greater affinity of compound 29 for LXRβ as compared to that of compound 5.

Potency was determined in cellular Gal4-based hybrid reporter gene assays. EC50 values and fold activation are reported as mean ± SE (n = 3). n.d., not determined.

(A) Selected de novo designs (1, 5, 13, and 15; Table 1), with atomic scaffolds highlighted with a thicker line, in comparison with the most similar fine-tuning compound (29, ChEMBL-ID: 379225, LXRα: EC50 = 0.4 μM, LXRβ: EC50 = 0.18 μM). The corresponding fragment similarity (Morgan molecular fingerprints and Tanimoto index) is indicated in percentage values. Compounds 1, 13, and 15 have novel atomic scaffolds compared to the known LXR modulators annotated in the ChEMBL27 database. Compound 5 has a similar agonistic effect on LXRα to compound 29, and it is five times more selective for the α subtype. (B) Automated ligand docking of compounds 5 (de novo design, blue) and 29 (fine-tuning compound, light gray) to the binding pockets of LXRα [PDB ID: 3IPS (63), left] and LXRβ [PDB ID: 1PQC (64), right]. GOLD (65) docking software was used. The solvent-accessible surface of the binding pockets is colored according to the computed electrostatic potential; red: negatively charged and blue: positively charged.

## Section: RESULTS AND DISCUSSION › Study significance and outlook

With 61% of the computational designs successfully synthesized and 12 novel LXR agonists with low-micromolar to sub-micromolar activity identified, the integrated de novo design platform shows promise for automating the DMTA cycle in drug discovery. By tailoring the model optimization to the available experimental pipeline, the benefits of rule-free de novo design, virtual reaction specification, and automated synthesis were combined. The results further validate the ability of generative molecular design approaches to capture desired molecular properties such as chemical synthesizability and on-target bioactivity, as well as their potential to support automation. The proposed DMTA framework offers the promise of fast iterations through the molecular design cycle and data-driven compound optimization. By relying on generative deep learning, the pipeline could be operated with minimal human interference, only requiring human input for the curation of the pretraining and fine-tuning compounds, and not using any human-crafted rules for molecule construction. Owing to its modular character, the approach can be tailored to other de novo design applications by replacing the computational molecule generator, reactions used for filtering, or synthesis technology. For the purpose of this proof-of-concept study, we successfully obtained molecules that were synthesizable within the microfluidics platform and had desired activity on LXR. These results indicate the usefulness of the pipeline for compound optimization and structure-activity relationship studies. Within the constraints of the two optimization goals (i.e., synthesizability and bioactivity on LXR), limited exploration of the chemical space was achieved. While conserving the overall structural similarity of the compounds in the fine-tuning set, novel structural features were introduced and new molecular scaffolds were identified. The three novel bioactive scaffolds (EC50 values ranging from 0.24 to 4.5 μM) highlight the capability of the computational pipeline to explore narrow regions of the relevant chemical space while, at the same time, providing access to unexplored molecular scaffolds.

The integrated de novo design platform can be further expanded by explicitly including the structural diversity of the molecular designs in the multiparameter optimization process. To achieve a broader exploration of the chemical space, several strategies can be adopted, for example, choosing different optimization criteria for the generative deep learning model or including other artificial intelligence models (15, 56) in the definition of compatible organic reactions. The proposed approach demonstrates the possibility to achieve closed-loop benchtop platforms for compound design and iterative optimization driven by artificial intelligence. Future work will be concerned with extending the microfluidic system to enable multistep synthesis, exploring automated batch synthesis as an alternative, as well as establishing active learning (57, 58) for improved process efficiency.

## Section: MATERIALS AND METHODS › Computational › Virtual reaction filter

A total of 17 decomposition reactions written in the SMARTS language (in the form “product >> reactant”) were adapted from a recent study (59) to capture feasible synthetic routes for the microfluidics-assisted platform (see table S1). The program code of the virtual reaction filter can be accessed at the following URL: https://github.com/ETHmodlab/ai-on-a-chip.

## Section: MATERIALS AND METHODS › Computational › Training data

The pretraining library was obtained from a dataset of 3,383,942 commercially available synthetic compounds, assembled from four providers: Asinex (http://asinex.com/libraries-html/—Elite, Fragments, Gold, and Platinum collections), ChemBridge screening compound collection (http://chembridge.com), Enamine advanced and HTS collections (http://enamine.net), and Specs screening compounds (https://specs.net). The library was filtered using the respective reaction SMARTS. Only compounds that could be successfully decomposed into their corresponding reactants (656,689 molecules) were retained for model pretraining. Fine-tuning was performed on a set of 40 LXRα agonists (table S2), manually curated from ChEMBL26 (44) (target ID = CHEMBL2808), with cell-based activity data demonstrating LXRα agonism with EC50 < 500 nM.

## Section: MATERIALS AND METHODS › Computational › Molecule preprocessing

The molecular structures were standardized with the Molecular Operating Environment (MOE) “wash” procedure (MOE v.2018.01, default settings) before computing molecular descriptors and performing target prediction. As in our previous study (27), before LSTM training, molecular structures were encoded as canonical SMILES (60) strings using the RDKit package (v.2018.03, www.rdkit.org); stereochemical information was removed and only SMILES strings with a length of up to 80 SMILES characters were retained (656,070 and 40 molecules for pretraining and fine-tuning, respectively). The preprocessed training set data can be accessed at the following URL: https://github.com/ETHmodlab/ai-on-a-chip.

## Section: MATERIALS AND METHODS › Computational › Target prediction and molecular descriptors

Target prediction was performed with the in-house software SPiDER (40), using MOE2D and Chemically Advanced Template Search 2 (CATS2) descriptors (42) as input. Only predictions with P < 0.05 were considered. CATS2 descriptors were calculated using in-house software (settings: CorrelationDistance = 10, Scaling = Types, Distance = Euclidean). MOE2D descriptors were calculated with the “QSAR descriptors” node of MOE 2018.01 in a KNIME 3.7.0 environment (61) (charge calculation = MMFF94*).

## Section: MATERIALS AND METHODS › Computational › Model architecture and settings

The chemical language model was implemented in Python (v. 3.6.5) using Keras (https://keras.io/, v2.2.0) with the TensorFlow GPU backend (www.tensorflow.org, v1.9.0) as a recurrent neural network with LSTM cells (34), as previously published (27). The neural network used consisted of four layers, for a total of 5,820,515 parameters: (i) BatchNormalization layer, (ii) LSTM layer with 1024 units, (iii) LSTM layer with 256 units, and (iv) BatchNormalization layer. The model was trained with SMILES strings encoded as one-hot vectors. SMILES randomization and 10-fold augmentation, as recently published (27), were used. We used the categorical cross-entropy loss and the Adam optimizer (62). The model was pretrained for 10 epochs with a learning rate equal to 0.001. We selected the pretraining epoch (epoch 2) as the one maximizing the number of designs that could be decomposed into compatible reactants (building blocks) available from the Sigma-Aldrich catalog. The selected model was fine-tuned for 40 epochs (learning rate = 0.002). The model code can be accessed at the following URL: https://github.com/ETHmodlab/virtual_libraries.

## Section: MATERIALS AND METHODS › Computational › Temperature and sampling epoch choice

Sampling temperature and fine-tuning epochs were automatically determined to optimize three parameters simultaneously: (i) predicted LXR activity by SPiDER (40), (ii) scaffold diversity (41), and (iii) distance to the fine-tuning compounds [as encoded by CATS2 (42) descriptors with Euclidean distance]. We tested three sampling temperatures (T = 0.2, T = 0.7, and T = 1.2; fig. S1) and fine-tuning epochs 1 to 40 (fig. S3). Sampling temperature T = 0.70 and fine-tuning epochs in the range of 15 to 20 were chosen to generate the final designs, as they resulted in the best compromise between scaffold diversity, number of compounds predicted as LXR modulators (P < 0.05), and CATS2 similarity between the fine-tuning set and de novo design.

## Section: MATERIALS AND METHODS › Computational › Novelty and scaffold analysis

The 67 de novo designs retained after reaction-based filtering were checked for their structural novelty on PubChem (43), ChEMBL27 (44), SciFinder (version 2019; Chemical Abstracts Service) (45), SureChEMBL (46), and Reaxys (47) (accessed 4 April 2019). Atomic scaffolds (41) were computed using RDKit in KNIME (v. 3.6.2).

## Section: MATERIALS AND METHODS › Computational › Similarity analysis

ChEMBL27 compounds that were structurally similar to the bioactive hits [as determined by the Tanimoto similarity on RDKit Morgan (53) fingerprints with radius equal to 2 and 1024 bits; table S7] were retrieved using the ChEMBL web resource client “similarity filter” function (https://github.com/chembl/chembl_webresource_client, beta version, 6 November 2020, Python 3.7.7). The same strategy was used to report the two most similar fine-tuning compounds for each bioactive hit (table S6).

## Section: MATERIALS AND METHODS › Computational › Automated ligand docking

The crystal structures of LXRα [Protein Data Bank (PDB) ID: 3IPS (63)] and LXRβ [PDB ID: 1PQC (64)] were retrieved from the PDB (https://www.rcsb.org/) and prepared with MOE v.2019.0102 (QuickPrep module: “Preserve Sequence and Neutralize”; “Use Protonate 3D for Protonation” = True; “Allow ASN/GLN/HIS ‘Flips’ in Protonate 3D” = True; “Delete Water Molecules Farther than 4.5 Å from Ligand or Receptor” = True; Tether Receptor: Strength = 10, Buffer = 0.25; Fix: “Atoms Farther than 8 Å from Ligands”, hydrogens close to ligands not fixed; Refine: “to RMS Gradient of 0.1 kcal/mol/Å”; “Retain QuickPrep Minimization Restraints” = True). Compounds 5 and 29 were docked with GOLD (65) within MOE v.2019.0102 (Efficiency = default, Score Efficiency = 100; Early Termination = [number:3, RMS = 1.5], PLP scoring, Rigid Receptor, 30 poses per compound), and poses were refined with MOE GBVI/WSA dG (10 refinement poses). Redocking of the crystalized ligand led to RMSD values of 0.8037 and 0.3775 Å for 3IPS and 1PQC, respectively.

## Section: MATERIALS AND METHODS › Synthesis › Chemicals

All chemicals and solvents were reagent grade and used without further purification unless specified otherwise. The building block chemicals were purchased from Sigma-Aldrich (St. Louis, USA; www.sigmaaldrich.com), Apollo Scientific (Cheshire, UK; www.apolloscientific.co.uk), Alfa Aesar (Kandel, Germany; www.alfa.com), Fluorochem (Derbyshire, United Kingdom; www.fluorochem.co.uk), Acros Organics (Geel, Belgium; www.acros.com), Enamine (Riga, Latvia; www.enamine.net), Maybridge (Waltham, MA, USA; www.fishersci.com), ABCR (Karlsruhe, Germany; www.abcr.de), and ChemDiv (San Diego, CA, USA; www.chemdiv.com). Compounds 26 and 27 were purchased from Enamine (www.enamine.net; compounds Z45510435 and Z45410017, respectively; purity = 90%); 28 was purchased from ChemDiv (www.chemdiv.com; compound 8012-4386, purity = 90%).

## Section: MATERIALS AND METHODS › Microfluidics platform › Instruments

Automated synthesis was performed on a Cetoni flow chemistry system (Cetoni GmbH, Korbussen, DE) using two gas-tight borosilicate glass syringes (SGE gas tight 2.5 ml, luer lock, Trajan Scientific), a reaction chip (Chip Type Dean Flow A, 16 × 12.5 mm, DFM-A1, 5 μl), and an 800-μl reaction coil of polytetrafluoroethylene tubing. The flow through the system was directed by three-way solenoid valves (100T3/S116, Bio-Chem Valve Inc., Chrom Tech, Apple Valley, MN, USA). The analysis block consisted of a Rheodyne MRA splitter (MRA100-000, Kinesis, Vernon Hills, IL, USA) coupled with an Advion Expression CMS (Advion, Ithaca, NY, USA) for in-line mass analysis. This equipment used L-216OU pumps from a VWR LaChrom ULTRA HPLC system (Radnor, PA, USA). An analytical HPLC system (Shimadzu, Kyoto, Japan) equipped with an analytical C18 reverse phase column (Macherey-Nagel, Nucleodur C18 HTec; 5 μm, 150 × 3 mm) was used for follow-up sample analysis. Mass signals were recorded using a Shimadzu LCMS-2020 system (Kyoto, Japan). The automated synthesis system was controlled using the QmixElements software supplied by Cetoni on an Aspire X3990 PC (i3 Intel Core 2120 CPU, 8GB, 1066 MHz DDR3 RAM, Windows 7 OS).

## Section: MATERIALS AND METHODS › Microfluidics platform › Protocol

The building blocks were loaded into two 96-well plates and sealed using adhesive slit seal sheets. User input was requested for the type of reaction, the number of reactions to be performed, the desired on-chip residence time, choice of reaction chip, and desired temperatures. Upon reaching the desired reaction conditions, aspiration of the reagent solutions was initiated. Using the Move-To-Container functions, the 360° rotAXYS arm moved to the location of the first building block and the dose-volume function was used to aspirate the dead volume between the syringe and the well plate. This volume was discarded, and the syringe was aspirated with a plug of dissolved building block consisting of 0.75 ml diluted with 0.25 ml of clean solvent. Before moving to the second building block container, the 360° rotAXYS arm moved to a clean solvent container using the “Move-To-Container” function to clean the needle. The same aspiration procedure was used for the second syringe. The volume contained in the syringes was then injected into the reaction chip using the dose-volume function at a flow rate calculated from the desired residence time. Once the syringes were empty, they were refilled with 2.5 ml of clean solvent using the dose-volume function and solvent was injected until the remaining part of the reaction plug had passed the reaction coil with the correct residence time. Once the reaction plug had passed the analysis unit and reached the end of the tubing, the Move-To-Container function was used to move the second rotAXYS arm to an empty container, where it was allowed to remain until the reaction plug was collected. The arm then moved back to the waste container position using the Move-XY function. HPLC-MS was used as an online monitoring tool. A stream splitting device coupled the ambient-pressure reactor system in an isolated fashion to the high-pressure side required by HPLC-MS.

## Section: MATERIALS AND METHODS › Automated synthesis › General amide bond synthesis procedure (compounds 1 to 15 and 22)

Solutions (0.2 M) of the respective acid chloride building block in tetrahydrofuran (THF) and the amine building block in acetonitrile/N,N′-dimethylformamide (MeCN/DMF) (9:1 v/v) were prepared, and 1 ml of each solution was loaded into individual wells of a 96-well plate. For automated synthesis, 0.75 ml of each building block solution was used per reaction and diluted with the running solvent (MeCN/THF; 50:50, v/v) to a total volume of 1.0 ml. The residence time was set to 15 min, and the temperature was set to 55°C. After mixing both solutions in the reaction chip, the reaction mixture was pumped through the coil and 2 ml per sample was collected in another 96-well plate.

## Section: MATERIALS AND METHODS › Automated synthesis › General ester bond synthesis procedure (compound 21)

Solutions (0.2 M) of the respective acid chloride building block in THF and the alcohol building block in MeCN/DMF (9:1, v/v) were prepared, and 1 ml of each solution was transferred into individual wells in a 96-well plate. The residence time was set to 5 min, and the temperature was set to 55°C. A 0.75-ml portion of each solution was aspirated into the syringe pumps and diluted to 1-ml total volume with the running solvent (MeCN/THF, 50:50, v/v). After mixing both solutions in the reaction chip, the reaction mixture was pumped through the coil and 2 ml was collected in a 96-well plate.

## Section: MATERIALS AND METHODS › Automated synthesis › General sulfonamide synthesis procedure (compounds 16 to 20 and 23 to 25)

Solutions (0.2 M) of the sulfonyl chloride building block in THF and the amine building block with one equivalent of triethylamine in MeCN/THF (50:50 v/v) were prepared, and 1 ml of each solution was loaded into individual wells of a 96-well plate. For automated synthesis, 0.75 ml of each building block solution was used per reaction and diluted with the running solvent (MeCN/THF, 50:50, v/v) to a total volume of 1.0 ml. The residence time was set to 10 min, and the temperature was set to 55°C. After mixing both solutions in the reaction chip, the reaction mixture was pumped through the coil and 2 ml per sample was collected in another 96-well plate.

## Section: MATERIALS AND METHODS › Batch synthesis

Fourteen compounds were synthesized in-batch for dose-response characterization (compounds 1 to 3, 5 to 6, 8 to 15, and 17). All compounds had a purity greater than 97% according to the HPLC-UV (ultraviolet) analysis (λ = 254 nm, λ = 290 nm). For details of the batch synthesis and analytical characterization, see the Supplementary Materials (figs. 29 and 30).

## Section: MATERIALS AND METHODS › Biological characterization

The Gal4-fusion receptor plasmid [pFA-CMV-hLXRα-LBD (48) and pFA-CMV-hLXRβ-LBD (48)] coding for the hinge region and ligand-binding domain of the canonical isoform of the respective nuclear receptor have been reported previously. pFR-Luc (Stratagene) was used as the reporter plasmid along with pRL-SV40 (Promega) for normalization of the transfection efficiency and cell growth. HEK293T cells were grown in high-glucose Dulbecco’s modified Eagle’s medium, supplemented with 10% fetal calf serum, sodium pyruvate (1 mM), penicillin (100 U ml−1), and streptomycin (100 μg ml−1) at 37°C and 5% CO2. HEK293T cells were seeded 1 day before transfection in 96-well plates (3.0 × 104 cells per well). Before transfection, the medium was changed to Opti-MEM without supplements. Transient transfection was carried out using Lipofectamine LTX reagent (Invitrogen) according to the manufacturer’s protocol, with pFR-Luc (Stratagene), pRL-SV40 (Promega), and the respective pFA-CMV-hLXR-LBD plasmid. Five hours after transfection, the medium was changed to Opti-MEM supplemented with penicillin (100 U ml−1), streptomycin (100 μg ml−1), 0.1% DMSO, and the respective test compounds or 0.1% DMSO alone as an untreated control. During primary screening, the concentration of each sample was roughly adjusted to 10 μM. Each sample was duplicated and tested in two biological repeats. For dose-response characterization of the purified compounds, each concentration was duplicated, and each experiment was repeated independently at least three times. Following overnight (12 to 14 hours) incubation with the test compounds, the cells were assayed for luciferase activity using the Dual-Glo luciferase assay system (Promega) according to the manufacturer’s protocol. Luminescence was measured using a Tecan Spark luminometer (Tecan Deutschland GmbH, Germany). Normalization of the transfection efficiency and cell growth was performed by dividing the firefly luciferase data by Renilla luciferase data and multiplying the value by 1000, resulting in relative light units (RLUs). Fold activation was obtained by dividing the mean RLU of the test compounds at a respective concentration by the mean RLU of the untreated control. T0901317 served as a reference agonist for assay validation and monitoring assay performance.

## Section: Acknowledgments

We thank S. Haller, B. Winkler, D. Gautschi, P. Schneider, and J. A. Hiss for their technical support. Funding: This work was financially supported by the Swiss National Science Foundation (grant no. 205321_182176 to G.S.) and by the RETHINK initiative at ETH Zurich. Author contributions: G.S. conceived the study, with contributions from F.G. and D.M.; F.G. designed the computational workflow and analysis, with contributions from A.L.B., M.M., and D.M.; B.J.H.H. curated the pretraining molecules; D.M. curated the fine-tuning molecules; M.M. trained the LSTM model and generated the designs; F.G. optimized the LSTM settings and performed post hoc analysis and docking; A.L.B. performed the retrosynthetic analysis; B.J.H.H. developed the microfluidic synthesis platform and performed the synthesis in flow; D.M. designed the in vitro screening procedure and performed the in vitro characterization; K.A. performed the batch synthesis and purification. F.G. drafted the manuscript, with contributions from D.M., B.J.H.H., M.M., and G.S. All authors contributed to manuscript revision. Competing interests: G.S. declares a potential financial conflict of interest as a cofounder of inSili.com LLC, Zurich, and in his role as a consultant to the pharmaceutical industry. The other authors declare that they have no competing interests. Data and materials availability: All data needed to evaluate the conclusions in the paper are present in the paper and/or the Supplementary Materials. Additional data related to this paper may be requested from the authors.

## Section: SUPPLEMENTARY MATERIALS

Supplementary material for this article is available at http://advances.sciencemag.org/cgi/content/full/7/24/eabg3338/DC1

## Section: Associated Data

Supplementary material for this article is available at http://advances.sciencemag.org/cgi/content/full/7/24/eabg3338/DC1

## Section: Associated Data › Supplementary Materials

Supplementary material for this article is available at http://advances.sciencemag.org/cgi/content/full/7/24/eabg3338/DC1


---

# Comprehensive Survey of Recent Drug Discovery Using Deep Learning

- **Authors:** Jintae Kim, Sera Park, Dongbo Min, Wankyu Kim
- **Issuer:** International journal of molecular sciences
- **Type:** Scientific article
- **Published:** 2021-09-15
- **Language:** en
- **DOI:** 10.3390/ijms22189983
- **Source:** https://pubmed.ncbi.nlm.nih.gov/34576146/
- **Licence:** CC-BY

## Section: Abstract

Drug discovery based on artificial intelligence has been in the spotlight recently as it significantly reduces the time and cost required for developing novel drugs. With the advancement of deep learning (DL) technology and the growth of drug-related data, numerous deep-learning-based methodologies are emerging at all steps of drug development processes. In particular, pharmaceutical chemists have faced significant issues with regard to selecting and designing potential drugs for a target of interest to enter preclinical testing. The two major challenges are prediction of interactions between drugs and druggable targets and generation of novel molecular structures suitable for a target of interest. Therefore, we reviewed recent deep-learning applications in drug–target interaction (DTI) prediction and de novo drug design. In addition, we introduce a comprehensive summary of a variety of drug and protein representations, DL models, and commonly used benchmark datasets or tools for model training and testing. Finally, we present the remaining challenges for the promising future of DL-based DTI prediction and de novo drug design.

## Section: 1. Introduction

The primary goal of drug discovery is to develop safe and effective medicines for human diseases. All the drug development processes—from target identification to step-by-step clinical trials—require significant amount of time and cost. As costs increase gradually with every step, it is essential to ensure that appropriate drug candidates are selected for the next phase at each milestone. In particular, the “hit-to-lead” process is a pivotal step in identifying promising lead compounds from hits and determining their potential as therapeutics. One of the reasons why clinical trials face side effects and lack in vivo efficacy is that single or multiple drugs often interact with multiple targets based on the concept of polypharmacology [1]. Ideally, full-scale in vivo tests for each disease model should be able to address this problem; however, that will require astronomical time and effort. Computer-aided drug discovery or design methods have played a major role in this hit-to-lead process by reducing the burden of consumptive validation experiments since the 1980s in modern pharmaceutical research and development (R & D) [2,3,4]. However, even this in silico approach has not prevented the decline in pharmaceutical industry R & D productivity since the mid-1990s.

Recently, much effort was invested in drug discovery through artificial intelligence (AI), which has enabled significant and cost-effective development strategies in academia and pharmaceutical industries. The vast amounts of chemical and biological data accumulated over decades, along with technological automation through the availability of high-performance processors such as graphics processing unit computing, paved the way for AI in drug development [4,5,6]. Not only state-of-the-art AI technologies are adopted in the drug development process, but also diverse pipelines or frameworks for AI-driven drug development are being built [7,8,9]. Utilizing deep neural networks provides the advantage of understanding the very complex contexts of biological space. This is because nonlinear models can be constructed in hidden layers to extract complex patterns from multi-level representations. It also minimizes the work of manually preprocessing unformatted raw data and selecting all kinds of features. Consequently, advances made in the development of deep learning (DL)-based methods have led to successful outcomes for prediction of drug–target interactions (DTIs) and generation of novel molecules with desired properties [4,10,11]. However, since datasets for drug development exhibit types and distributions that are different from those used in traditional AI data, such as images and texts, further attempts are still required to analyze data from a different angle and apply the latest DL techniques.

In this review, we introduce essential data representations and DL models for DTI prediction and de novo drug design. In addition, we investigate recent advances and benchmark datasets in DL-based methods in the following sections: The “Data Representation” section introduces several data representations of the inputs that were used in DL-based drug discovery. The “Deep Learning Models” section explains DL methods for drug discovery via comparison of the strengths and weaknesses of models. In the two sections, “Deep Learning Methods for Drug–Target Interaction Prediction” and “Deep Learning Methods for De Novo Drug Design,” we classify and describe the models for each of the DTI predictive models and de novo drug design models based on their utility. The “Benchmarking Datasets and Tools” section demonstrates the commonly used benchmark dataset and publicly available benchmarking tools. Finally, we discuss the advantages and limitations of the current methods as well as the remaining important challenges and future perspective for DL-based drug discovery in the “Limitation and Future Work” section.

In the “Deep Learning Methods for Drug–Target Interaction Prediction” section, the description of the following studies was minimized: (1) studies that predict compound properties not considering protein targets such as blood–brain barrier permeability, solubility, lipophilicity, and chemical-based adverse effect [10,11]; (2) target prediction studies that determine targets for the existing drugs, such as reverse docking simulation [12]; (3) studies that only use knowledge-based documents from which information is extracted by text mining techniques [13]; (4) studies that focus on only optimizing binding between the drug and target using molecular dynamics simulation [14,15,16].

## Section: 2. Data Representation

The input data for DL-based drug discovery are molecules; drugs and protein targets are small molecules or macromolecules. To characterize these molecules, several types of molecular representations (often referred to as descriptors or features) have been used in many machine learning (ML) methods—from simple sequences of molecular entities to manually predefined molecular features [17,18] (Figure 1). However, because it is directly related to the knowledge of learning models, data representation has a significant impact on pre-training to improve performance of predictive models. There has been a surge of interest in research on representation of molecules, and these efforts can contribute to capturing unknown features of compounds and targets [19,20]. Learning expressive representation from molecular structures is one of the challenges of these studies [21]. Besides, many recent DL models tend to use three-dimensional (3D) representations based on protein–ligand complexes, including molecular graphs, atom-pair fingerprints, and voxels. The various molecular representations utilized in deep neural networks as drug representations and target representations are described separately in this section.

## Section: 2. Data Representation › 2.1. Drug Representations › 2.1.1. SMILES

The most commonly used drug representation is a simplified molecular-input line-entry system (SMILES) string, which is a line notation that encodes structural, geometric, and topological properties of a molecule. The SMILES is simple and easy to obtain; therefore, it enables fast training. A number of molecular deep-learning models use the SMILES as the molecular representation [22,23,24,25]. As it is a sequence-based feature, a SMILES string can be directly used as a “sentence” to learn the representations. Sequence models using the SMILES can be successfully applied to predict chemical reactions. For example, many studies have shown promising results for synthetic prediction by directly converting to the predicted reactants in the SMILES format through seq-2-seq approaches to illustrate the reactions of compounds [26,27,28]. Furthermore, most molecules can be randomly generated with more than one SMILES string by starting in different atoms and changing the atomic orders, and this randomized SMILES model exhibits much better performance [29,30].

## Section: 2. Data Representation › 2.1. Drug Representations › 2.1.2. Fingerprint

Another chemical structure-implemented feature is molecular FP, which is a bit string encoding structural or pharmacological feature of a ligand. Many types of molecular FPs have been proposed for similarity comparisons for virtual screening (VS), including ligand-based similarity searching and quantitative structure-–activity relationship (QSAR) analysis. A number of deep-learning-based DTI prediction models also used FPs as input features [24,31,32,33,34]. We discuss three types of widely used molecular FPs: key-based FPs, hashed FPs, and pharmacophore FPs.

Key-based FPs include molecular ACCess system (MACCS) and PubChem FP. The MACCS keys are composed of predefined 166 substructures. PubChem FP [35] has 881 bits and each bit tests the presence of element count, type of ring, atom pairing, and nearest neighbors, etc. These structural keys are designed for substructure retrieval. Therefore, although it is possible to quickly and accurately find substructures, there is a limit to classifying various characteristics.

Hashed FPs, such as Daylight FP, Morgan FP, extended-connectivity FP (ECFP), and functional-class FP (FCFP), are also used in the similarity analysis of compounds. Unlike key-based FPs, hashed FPs do not require predefined substructures and are instead created by a hash function to convert all possible fragments to numeric values. ECFP, a circular FP based on the Morgan algorithm [36], is often used in a wide range of applications, including DL models for the DTI prediction. This is because several DL methods using ECFP exhibited robustness in bioactivity prediction [8,37].

Pharmacophore FPs have pharmacophoric features such as aromatic, hydrophobic, charged, and hydrogen bond donor/acceptor. The pharmacophore FPs consider the overlapping of energy-minimized conformations of a set of known ligands and the extraction of recurrent pharmacophoric properties [38]. Many studies have used these pharmacophoric features to assess similarities between binding sites [39].

Finally, recent studies have attempted to add 3D structures to FPs to accurately predict binding affinity [8,40,41]. Gao et al. [33] reassessed the predictive power of 2D and 3D FPs and concluded that 2D FPs are still competitive in prediction of toxicity, physicochemical properties, and ligand-based binding affinity; however, 3D structure-based models outperformed 2D-based counterparts in the protein–ligand binding prediction. In other words, 2D FPs are still competitive; therefore, considering the structural properties at the 2D and 3D levels together will yield better results.

## Section: 2. Data Representation › 2.1. Drug Representations › 2.1.3. Learned Representations

“word2vec” is a very popular method in natural language processing for word embedding [42]. With word2vec, the meaning of the word is learned and reflected in the coordinates; therefore, an ML model can better characterize the words. The embedding method, which usually adds “(2)vec” to the end, is inspired by “word2vec” and treats a molecule or protein as a sentence or word of a natural language and converts it into a real vector. ProtVec [43] and Mol2vec [44] are representative representations, and there are other methods such as SPvec [40] and SMILES2vec [41]. When converted to the 2vec type, specific information such as atom (or amino acid) type or bonding relationship of the original data cannot be known without restoration. Therefore, it is not suitable for a de novo design and is mainly used for property prediction. It is also known that the 2vec type has better prediction accuracy than the SMILES or FP [32].

There are other learned representation methods that employ DL. Recently, many studies used deep representation learning to encode molecules. The most common learned representation method is AutoEncoder (AE) [45]. The AE extracts the potential characteristics that make the input data distinguishable and compress them into vectors of desired length, called as latent vectors. Currently, the transformer model is preferred over the AE [46]. However, to train representation learning, a large amount of data is required; however, a publicly available pre-trained transformer or AE model can also be used without making your own DL model [46]. X-Mol [46] or MolGNet [47] are well-known frameworks designed for this purpose. By fine-tuning these frameworks according to the purpose, they can be used in a variety of ways—from property prediction, DDI, DTI, de novo design, to molecule optimization.

Additionally, Denis et al. applied wave transform for efficient representation of sparse voxel data [48], and Ziyao et al. proposed HamNet [49] considering molecular conformation in their study.

## Section: 2. Data Representation › 2.1. Drug Representations › 2.1.4. Voxel

A voxel is a combination of “volume” and “pixel,” which is a data representation that extends a 2D image into three dimensions. In the 3D space, a value is assigned to the geographic location where the atom exists, and the rest is filled with zeros. The value can be 1 to indicate the presence of only an atom, and it may be an encoded value corresponding to the type of atom or a quantum chemical property such as hydropathy or electric charge [50]. In addition, as mentioned in Section 2.2, a voxel is used as the expression of the target protein and has the advantage that it can express only the pocket that reacts with the ligand instead of the entire protein [51]. Because the voxel has specific 3D information, it is a very suitable expression for binding prediction.

Resolution is important when using voxel. For example, if the size of a voxel is 20 × 20 × 20, the number of features in the input data is 8k, so the size is large; however, most of the data are filled with zeros. If the resolution is lowered to reduce the size, the accuracy will decrease, and if the resolution is increased, the data size and training speed will increase significantly. There are also 3D mesh [52] or point cloud [53] for geometric 3D representation; however, the voxel is most widely used in the DTI field.

## Section: 2. Data Representation › 2.1. Drug Representations › 2.1.5. Molecular Graph

A molecular graph is a mapping of atoms constituting a molecule to nodes and chemical bonds to edges. In molecular graphs, nodes are sometimes represented using symbols in the periodic table to indicate atom types, or using some kinds of functional groups or fragments [20]. The edge attributes can describe bond strength or bond resonances between two atoms, which is important training data that is expressed as the adjacent matrix in the graph convolution neural network model [11]. With the development of graph neural networks, recent DL-based works have adopted molecular graphs as drug or target representations for both DTI prediction models and novel molecular design models. Notably, molecular graphs can represent not only 2D structures but also 3D structures with the spatial information including atomic coordinates, bond angles, and chirality. However, since the arrangement of atoms in a three-dimensional space changes constantly, the space in a molecular graph is almost infinite. Some successful results using 3D graph representation were obtained for the DTI prediction by avoiding inefficient computations [54]; however, the 3D structure data of the protein–ligand complex is insufficient. Thus, the model can memorize the features of the training data extensively [55]. If you need a further explanation of molecular graphs, we recommend referring to Ref. [20], which provides a good review of molecular representations.

## Section: 2. Data Representation › 2.2. Target Representations › 2.2.1. Sequence-Based Feature

The simple and primary feature of targets is a protein sequence composed of a linear composition of amino acid residues, which is easy to obtain and serves as the input of the recurrent neural network (RNN). Amino acid sequences including protein primary structures have been frequently used as a target representation in the predictive models. Information on protein primary structures can also generate a variety of target properties, such as monopeptide/dipeptide/tripeptide composition (also called protein sequence composition description; PSC), sequence motif, and functional domain. Lin Zhu et al. [56] listed the types of protein features derived from the amino acid composition: amino acid composition, sequence order, etc. Some studies [34,57] considered a position specific scoring matrix (PSSM) as the target feature. The PSSM is derived from an ordered set of sequences that are presumed to be functionally related and serves as an important feature that is widely used in the prediction of DNA or RNA binding sites (e.g., PSI-BLAST [58]) [34].

## Section: 2. Data Representation › 2.2. Target Representations › 2.2.2. Structure-Based Feature

For known protein structures, as previously described in the drug presentation part, molecular descriptors such as atom-pair map, voxel, and molecular graph were often used for the target representation to determine structurally matching ligands or to design new ligands for the protein [17,40,59,60]. However, there are not many known protein structures. Genetically encoded amino acid sequences determine the remarkable diversity of the molecular functions performed by finely tuned 3D structures (i.e., tertiary structure) through protein folding. Accurately predicting the folding structure of proteins in a real biological system is important in biomedicine and pharmacology. Scientists directly analyzed the stereoscopic structure of proteins using methods such as X-ray crystallography, nuclear magnetic resonance spectroscopy, or cryo-electron microscopy to decipher the structures of more than 170,000 protein species; however, it took a very long time to analyze a single protein. For this reason, the tertiary structure of proteins has been determined using computational methods. Since there are many variables in protein folding, this challenge has not been addressed over fifty years in computational biology [61]. Recently, DeepMind developed AlphaFold and succeeded in accurately predicting the 3D structure of proteins from amino acid sequences [62]. As these prediction results are open to the public, it is expected that all scientists will be able to gain new insights and spur their discovery in drug development.

## Section: 2. Data Representation › 2.2. Target Representations › 2.2.3. Relationship-Based Feature

The key questions for druggable targets are how to extract important features of the drug-binding site and how to predict potential space. Many DL models have simply applied amino-sequence-based features; however, some studies have focused on a variety of aspects of target proteins. Some groups [59,63,64] utilize not only sequences but also pathway membership information such as gene ontology (GO) terms [60] and MSigDB pathways [65]. A number of studies [59,63,66,67,68] employed a protein–protein interaction (PPI) network, which is generated into network-based features by node2vec or AE. Other studies showed the transcriptome data, such as connectivity map (CMAP) [69] and Library of integrated network-based cellular signatures (LINCS)-L1000 database [70], can be utilized as target features for the DTI prediction models [63,71]. The transcriptional profile is an integrated result of many genetic processes; thus, the characteristic changes in the transcriptional profiles can denote the underlying mechanisms of diseases of interest [72].

## Section: 3. Deep Learning Models

Basic DL models can be classified according to their purpose, loss function, learning method, and structure. When DL was initially applied for drug development, there were studies using only a single model; however, recently, there are very few cases where only a basic model is used. In most cases, two or more of the basic models introduced below are combined. There are many different types of DL models, but only very basic ones have been described in this section. We describe the strengths and weaknesses of each model and introduce the characteristics of the models from the point of view of drug discovery.

## Section: 3. Deep Learning Models › 3.1. Multi-Layer Perceptron

Multi-layer perceptron (MLP) is the most common neural network structure and is also called the fully connected layer, linear layer, etc. MLP’s strengths lie in classification and regression. Usually, it is trained by finding the optimal parameters that can minimize the error between the predicted value and the correct answer for the input. Since it is a standard model that has been studied extensively, various techniques have been established and almost all DL frameworks basically provide it; therefore, it is easy to apply, and stable performance can be expected. Because of its wide versatility, various data such as FP, transcriptome [71], bioassay [73], and molecular properties can be used along with the compound structure. Chen et al. used the MLP with four hidden layers for the DTI prediction, FP was used for compound, and various information such as PseAAC, PsePSSM, NMBroto, and structure feature were combined with the target protein information [57].

## Section: 3. Deep Learning Models › 3.2. Convolutional Neural Network

Convolutional neural networks (CNN) extract local features by calculating several adjacent features through the same computational filter. By stacking the CNNs in several layers, global features including local features can be extracted. The CNN is generally used when all the input data are single-modal-like image recognition. The convolution filter is the same regardless of the amount of the input data. Even if the amount of the input data is large, the number of calculations increases; however, the number of parameters of the DL model does not increase much. Therefore, it is efficient for training. It is also relatively robust against noise from the input data. Because the CNN is well suited to atomistic geometry [74], it is often used in combination with the voxel or image-type data. DEEPScreen [19] used a 2D image of the molecule, and RoseNet [15], AK-score [75], and DeepDrug3D [51] predicted the DTI by converting the protein and ligand into a voxel. Although it is not optimized for sequential expression methods such as SMILES or amino acids, the CNNs are sometimes used instead of the RNNs [76]. Both DeepConv-DTI [31] and transformer-CNN [77] used the CNNs for sequential input data to build QSAR models.

## Section: 3. Deep Learning Models › 3.3. Graph Neural Network

Most of the data used in ML is expressed in the form of a vector that matches the Euclidean space. In the case of single-vector-type data or sequential data, models such as MLP, RNN, or transformer can be used; however, it is not appropriate to apply these models to data expressed in relational graphs such as social networks. A graph neural network is a model designed to learn graph-type data in a DL method [78]. There are various graph types of data in drug discovery—compound structure, DTI relationship, PPI, patient–disease relationship, etc. There are several types of graph neural networks (GNN); however, the graph convolution network (GCN) [79,80] adopting the CNN method and the graph attention network(GAT) applying the attention mechanism are representative [47].

GNNs are widely used in many ways; however, they stand out primarily in three applications. The first is to predict the properties of compounds using representation learning. Yang et al. claimed that the GNN method that they employed has better property prediction performance than the existing methods [21]. According to this trend, recently, the GNN is widely applied for property prediction [81]. The second is to learn relationship information between different domains such as heterogeneous and bipartite [82,83]. For example, it is possible to learn the relationship between patients and diseases, and between genes and drugs, making it possible to utilize comprehensive meta data [83]. Lastly, in the field of de novo design, compounds are generated or optimized by the GNN [84].

## Section: 3. Deep Learning Models › 3.4. Recurrent Neural Network

If sequential data are put into the recurrent neural network (RNN) one by one in order, it is influenced by the previous input value to derive the next output value. When the RNN was first introduced, AI performance in the natural language field, which was difficult to achieve previously, was greatly improved, and it became one of the famous models of DL. In addition, it can be used to embed structural information as a kind of representation learning by extracting the weight of the hidden layer and treating it as a feature with sequence information. However, the naive RNN has a simple structure, and there are performance limitations for application in various situations. The most important problem is the vanishing gradient problem, which exhibits poor performance for long-length data such as large proteins and large compounds because the length of the input sequence exponentially reduces the impact of items far from the currently entered item [85]. Moreover, since the same operation is executed repeatedly as the length of the input sequence, the length of the sequence increases the training time. Even when the items in sequential data have complex intrinsic relationships, their characteristics are not well learned.

Long short-term memory (LSTM) was invented in the 1990s and began to be widely used in the late 2000s [86]. LSTM was introduced to address the fast-vanishing problem of naive RNNs. The LSTM can be used with good performance even on longer sequential data compared to the RNN. Since its introduction, various modifications of the LSTM have been proposed [87], and recently, gated recurrent units (GRU) with a simpler internal structure [88] has also been widely used. It can simply be used for the de novo drug design, which randomly generates short-length compounds, and can generate an appropriate candidate drug by inputting a target protein sequence [89]. The LSTM and GRU have exhibited significant improvements over the RNN and are widely used to replace the RNN in drug discovery [31,90,91]; however, the vanishing problem still persists, which makes it difficult to use very long sequence data.

## Section: 3. Deep Learning Models › 3.5. Attention-Based Model

The self-attention technique is a method that was first proposed by the transformer model to introduce machine translation in the field of natural language processing. Self-attention is a technique that calculates the association between the elements included in a sequence and extracts features for each element based on the calculated result. Unlike the RNN, which uses a single hidden state in which all time step values are implied, the attention technique handles past data in parallel; therefore, the correlation with distant tokens can be used without reduction. Furthermore, bidirectional encoder representations from transformers (BERT), introduced by Devlin et al. [92] in 2018, has dramatically improved natural language presentation using DL and has been actively introduced in drug discovery.

In DTI, the transformer model was naturally absorbed into the traditional QSAR modeling using the RNN. Karpov et al. [77] used a model applying CNN to a transformer with SMILES as an input to predict drug activity. Shin et al. [23] proposed a molecular transformer DTI (MT-DTI) model that predicts drug-target binding affinity by embedding the protein sequence using the CNN and embedding the molecule structure using the BERT. Lennox et al. [93] also proposed a model with a concept similar to MT-DTI; however, it used BERT for both protein and chemical structures and was based on GCN. Lennox et al. evaluated that their model performed better in predicting binding affinity than MT-DTI.

## Section: 3. Deep Learning Models › 3.6. Generative Adversarial Network

Generative adversarial network (GAN), first published in 2014 [94], is the most representative generative model in the field of DL. The GAN is only used in the de novo drug design and not in the DTI. Two DL modules, generator and discriminator, are included in pairs, and these two modules are trained adversarially with each other, and finally, the generator produces fake results that cannot be distinguished from the real ones by a discriminator. Although the GAN is used as a very powerful method for some data types such as image data, it has difficulty in generating large molecules compared to other generative models. In addition, the technical difficulty for training is somewhat higher than that of other models, and it involves problems such as mode collapse.

The GAN, combined with reinforcement learning (RL), is considered a very successful model for novel molecules generation. There are various GAN architecture applications used in drug discovery [95], however, we introduce only two very simple models. Objective-reinforced generative adversarial networks (ORGAN) [90], introduced by Guimaraes et al., and molecular GAN (MolGAN) [91], introduced by Cao and Kipf, are frequently cited successful models. Since ORGAN uses SMILES data as input, sequence GAN (seqGAN) [96] is used as the basic framework and RL is added. ORGAN showed good performance in drug likeliness and synthesizability except solubility compared to the naive RNN. The MolGAN is a similar concept to the ORGAN, but it applied the GCN based on molecular graph representation and showed better performance than the ORGAN and the naive RNN.

## Section: 3. Deep Learning Models › 3.7. Autoencoder

AE is a DL structure for basic unsupervised learning that consists of an encoder that compresses data and a decoder that reconstructs the data to their original shape. In this symmetric process, the dominant characteristic that distinguishes the data from each other is automatically extracted. A set of abstracted points compressed by the encoder, called a latent space, can be used in other models as new features. At the training stage, the encoder and decoder are trained simultaneously; however, after the training stage, only the encoder is separated and used for data embedding, dimension reduction, and visualization, or only the decoder is separated and used as a generation model. Because dimension reduction is possible without the need for data labels, it is good to use in combination with other DL models [97].

The points in the latent space created by the AE are very sparsely distributed; however, there is no continuous meaning between the points. Variational autoencoder (VAE) limits the latent space to a Gaussian-shaped stochastic fence. This increases the density of the latent space and makes the data continuous and smooth. Gómez-Bombarelli et al. showed that continuous search from one compound to another is possible in a smooth chemical latent space constructed using the SMILES [98]. AE is excellent in data compression and is used for the DTI, whereas VAE has lower compression performance than AE and is used for the de novo drug design due to the continuous and limited latent space characteristics described above.

Adversarial AE (AAE) [99] is a DL model that adds the GAN structure to the VAE, whose purpose is feature compression and generation. The VAE can compress the properties of compounds well; however, it exhibits inadequate performance to generate valid results. Conversely, the GAN can produce valid compounds and produce plausible results but can be biased with a single mode and have low diversity scores. Insilico Medicine first published the AAE [100,101] for the identification and generation of new compounds in 2016 [101], followed by an improved model named druGAN [102] in 2017. The AAE is a method that can show good performance in the generation of new compounds while compressing the data to the latent space. Polykovskiy et al. generated new compounds by changing the lipophilicity (logP) and synthetic accessibility of the input compound by adding the function to control the condition to AAE [103].

## Section: 4. Deep Learning Methods for Drug–Target Interaction Prediction

DTI prediction using DL techniques incorporates both the chemical space of the compound and the genome space of the target protein into a pharmacological space, which is called as a chemogenomic (or proteochemometric, PCM) approach. This approach would ideally solve the DTI problem by building a chemogenomic matrix between the whole compounds and their biological proteins. Advances in the high-throughput screening (HTS) technology have enabled hundreds of thousands of compounds to be tested on biological targets in a very short time; however, it is practically impossible to obtain a complete chemogenomic matrix for a vast chemical space of 1060.

As DL models predicting DTIs continue to apply state-of-the-art algorithms, combine multiple algorithms, and gradually shorten development periods, DL-based DTI prediction models have become so diverse that it is difficult to divide groups into appropriate categories [104]. Previous review papers have categorized the DTI prediction models into various groups [104,105,106,107]; however, none of these reviews have established a clearly distinguished classification scheme for DL methods. Another review categorized ML-based DTI prediction methods into docking simulation methods, ligand-based methods, GO-based methods and so on; however, this also did not provide detailed classification of the DL methods [108]. Therefore, we summarized the recent works using deep neural networks as prediction models for the DTIs. We describe the works by grouping them into three branches according to their input features: (1) ligand-based approach, (2) structure-based approach, (3) relationship-based approach (Figure 2). Appendix A Table A1, Table A2 and Table A3 summarize the studies involving each approach.

## Section: 4. Deep Learning Methods for Drug–Target Interaction Prediction › 4.1. Ligand-Based Approach

The ligand-based approach is based on the hypothesis that a candidate ligand will be similar to the known ligands of the target proteins. It predicts the DTI via the ligand information of the target of interest. This approach includes similarity search methods that follow the assumption that structurally similar compounds usually have similar biological activities [6,109,110]. For decades, these VS methods have either prioritized compounds in large compound libraries through tremendous computing tasks or solved problems using manual formulas. The DL technology can shorten these cumbersome steps and manual tasks, and the difference between in silico prediction and empirical investigation is gradually narrowed through deep neural network models (Appendix A Table A1). Researchers have developed deep-learning-based VS for exploring compounds with desired characteristics, which has led to the revival of new drug designs, which will be detailed in the “De Novo Drug Designs” section.

With the development of benchmark packages such as MoleculeNet [111] and DeepChem [112], researchers can easily apply deep neural networks for analyzing ligands and predicting ligand-related properties, including bioactivities and physicochemical properties. Therefore, a number of ligand-based DL methods have adopted simple neural networks such as MLP and CNN [12,21,27,113]. In particular, ADMET studies tended to focus more on the representation power of the molecular descriptors than the model itself [27,34,35,114]. Hirohara et al. applied the SMILES string to a CNN model and detected motifs with important structures for protein-binding sites or unknown functional groups from learned features [25]. Wenzel et al. investigated multi-task deep neural networks using atom pairs and pharmacophoric donor–acceptor pairs as descriptors for predicting microsomal metabolic liability [115]. Gao et al. employed several ML algorithms, including random forest, single-task deep neural network, and multi-task deep neural network models, in order to conduct comparisons of six types of 2D FPs in the protein–ligand binding affinity prediction [33]. Matsuzaka and Uesawa developed a CNN model that predicts agonists for constitutive androstane receptors by training 2D images of 3D chemical structures [109]. They optimized the best performance in snapshots at different angles or coordinates of a 3D ball-and-stick model, and as a result, the approach outperformed the predictions of typical 3D chemical structures.

Several studies applied state-of-art techniques such as graph convolution network and graph attention network for bioactivity or physicochemical property prediction. Since the introduction of the GCN was introduced, GCN models in drug-related applications constructed graph representations of a molecule that included information about the chemical substructures by summing up all the features of all the adjacent atoms [116]. Many studies have applied the GCNs as 3D descriptors instead of SMILES strings and evaluated that these learned descriptors outperformed in the prediction tasks and are more interpretable than the existing descriptors [23,24,86]. Chemi-net utilized the GCN models for molecular representation and compared performances between single-task and multi-task deep neural networks on their internal QSAR datasets [81]. Yang et al. proposed an advanced model, the directed message passing neural network (D-MPNN), by adopting a directed message-passing paradigm. They extensively compared their models on 19 public and 16 internal datasets and found that the D-MPNN models performed better or exhibited similar performance in most of the datasets [21]. They underperformed compared to traditional 3D descriptors in two datasets and were not robust when the dataset was small or extremely imbalanced. Then, another study group also practically used this D-MPNN model and successfully predicted an antibiotic, called halicin, which showed bactericidal efficacy in mice animal models [22]. This became the first case that led to antibiotic discovery by exploring a large-scale chemical space with DL methods that cannot be afforded by the current experimental approaches.

Another promising recent approach is the applications of attention-based graph neural networks [79]. Because the edge features can vary the graph representations for a molecule, the edge weights can be jointly learned with the node features. Thus, Shang et al. proposed an edge attention-based multi-relational GCN [11]. They built a dictionary of attention weights for each edge (i.e., individual bonds in the molecule), and as this dictionary is shared across the entire molecule, the model becomes robust to various input sizes. Consequently, the model can efficiently learn pre-aligned features from inherent properties of the molecular graph, and they evaluated that the performance of this model is better than that of the random forest model in Tox21 and HIV benchmark datasets. Withnall et al. [21] introduced a further augmentation with an attention mechanism to the MPNN model, called attention message passing neural network (AMPNN), which takes the weighted summation in the message passing stage [117]. They also extended the D-MPNN model (the reference by Yang et al. mentioned in the previous paragraph [21]) by attention mechanism in the same way as the AMPNN and called it the edge memory neural network (EMNN). This model outperformed other models on the standardized missing data from the maximum unbiased validation (MUV) benchmark set, although it is computationally more consumptive than other models.

## Section: 4. Deep Learning Methods for Drug–Target Interaction Prediction › 4.2. Structure-Based Approach

Contrary to the ligand-based VS, structure-based VS uses both protein targets and their ligand information. Typical molecular docking simulation methods aimed at estimating geometrically feasible binding of ligands and proteins of a known tertiary structure [110]. While many ML methods for the DTI prediction utilize a variety of structural descriptors of ligands and targets as input features, several reviews separated these ML methods from typical structure-based approaches in methodology classification and classified them as feature-based methods [2,117,118]. However, we believe that the recent studies incorporating DL of feature-based methods utilize the same method because the training is essentially performed with structural features [17,40,59,119,120]. Appendix A Table A2 shows the recent applications of structure-based DL methods for the DTI prediction.

One of the most commonly used DTI prediction methods in recent years is the use of 1D descriptors for drug and target [26,33,37,42,121]. As described in the previous representation section, drug and target can be expressed as sequences of atoms and amino acid residues, respectively, and the sequence-based descriptors have been preferred because DL models can be applied immediately without any tricky preprocessing of input features. DeepDTA proposed by Öztürk [24] applied only sequence information of the SMILES string and amino acid sequences to a CNN model and outperformed moderate ML methods such as KronRLS [122] and SimBoosts [123] on the Davis kinase binding affinity dataset [113] and KIBA dataset [114]. Wen et al. chose the common and simple features, such as ECFPs and protein sequence composition descriptors, and trained the features by a semi-supervised learning through deep belief-network [37]. This study suggested that in a problem where a very sparse set of total DTI pairs is used for the training, even a small dataset can be predicted more accurately by unsupervised pre-training. Another work called DeepConv-DTI constructed a deep convolution neural network model using only a type of RDKit Morgan FP and protein sequences [31]. They additionally captured local residue patterns of target protein sequences from the pooled convolution results, which can give high values to important protein regions such as actual binding sites.

A keystone of the structure-based regression model is the score function that ranks the binding potential of the protein–ligand 3D complexes and parametrizes the training data to predict the binding affinity values or binding pocket sites of the target proteins. AtomNet incorporated the 3D structural features of the protein–ligand complexes to the CNNs [124]. Their understanding is that the interactions between the chemical groups in the protein–ligand complexes are predominantly constrained in a local space; therefore, the CNN architecture is appropriate to learn local effects such as hydrogen bonding and π-bond stacking. They vectorized fixed-size 3D grids (i.e., voxel) over the protein–ligand complexes, and then each grid cell represents the structural features in that location. Since then, many researchers have investigated deep CNN models using voxels for binding affinity prediction or binding pocket site prediction [17,40,59,60,120], and these models have shown improved performance compared to the popular docking methods such as AutoDock Vina [125] or Smina [126]. This is because the CNN models are relatively resistant to noise in the input data and can be trained even when the input size is large.

Similar to the trends in the ligand-based methods, many DTI studies based on the structure-based methods using the GCNs have been published [8,127,128]. Feng et al. adopted both the ECFPs and GCNs as ligand features [8]. Compared to previous models such as KronRLS [122] and SimBoost [123], their models showed better performance on the Davis [113], Metz [129], and KIBA [114] benchmark datasets. However, they acknowledged that their GCN model could not beat their ECFP model because of difficulties in applying the GCN due to time and resource constraints. Another DTI prediction study by Torng et al. built an unsupervised graph-AE to learn the fixed-size representations of the protein-binding pockets [118]. Then, they used the initialized protein-pocket GCN in the pre-trained GCN model, while the ligand GCN model was trained using the automatically extracted features. They concluded that this model effectively captured the protein–ligand binding interactions without relying on the target–ligand complexes.

Attention-based DTI prediction methods have emerged because the attention mechanism-implemented models have key advantages that make the model interpretable [25,128,130]. Gao et al. used encoded vectors using the LSTM recurrent neural networks for the protein sequences and the GCN for ligand structures [119]. In particular, they focused on explaining the ability of their approach to provide biological insights to interpret the DTI predictions. To this end, two-way attention mechanisms were used to compute the interaction of the drug–target pairs (DTPs) interact, enabling scalable interpretability to incorporate high-level information from the target proteins, such as GO terms. The Molecule transformer DTI (MT-DTI) method was proposed by Shin et al. using the self-attention mechanism for drug representations [23]. The pre-trained parameters from the publicly available 97 million compounds (PubChem) were transferred to the MT-DTI model, and it was fine-tuned and evaluated using two Davis [113] and KIBA [114] benchmark datasets. However, they did not apply the attention mechanism to represent the protein targets because the target sequence length was long, which takes a considerable amount of time to calculate, and there is not enough target information to pre-train. On the other hand, AttentionDTA presented by Zhao et al. combines an attention mechanism for the CNN models to determine the weight relationships between the compound and protein sequences [120]. They demonstrated that the affinity prediction tasks by the MLP model performed well on these attention-based drug and protein representations.

## Section: 4. Deep Learning Methods for Drug–Target Interaction Prediction › 4.3. Relationship-Based Approach

According to polypharmacology, most compounds have more effects not only on their primary targets, but also on other targets. These effects depend on the dose of the drug and the related biological networks. Therefore, in silico proteochemometric modeling turned out to be useful, particularly when profiling selectivity or promiscuity of the ligands for proteins [121]. Moreover, multi-task learning neural networks are well suited for learning aspects of these different types of data simultaneously [131]. There are many applications of DL models that utilize relational information for multiple perspectives such as DTI-related heterogeneous networks and drug-induced gene-expression profiles. A network-based approach uses heterogeneous networks that integrate more than two types of nodes (drugs, target proteins/genes, diseases, or side effects) and various types of edges (similarities between drugs, similarities between proteins, drug–drug interactions (DDIs), PPIs, drug-disease association, protein-disease association, etc.) [132,133].

The key point of this approach is the use of local similarity between the nodes in the networks. For example, when a similarity network with drugs as nodes and drug–drug similarity values as the weights of the edges is considered, the DTIs can be predicted by utilizing their relationships and topological properties. It is based on the “guilt-by-association” theory that interacting entities are more likely to share functionalities [13]. Various ML methods that incorporate heterogeneous networks have been used as the prediction frameworks, e.g., support vector machine [134,135], regularized least square model (RLS) [127,128,136], and random walk with the restart algorithm [122,137].

With growing interest in the use of DL technologies, network-based DTI prediction studies using DL have been shown to improve the existing association prediction methods for measuring the topological similarities of bipartite (drug and target networks) and tripartite linked networks (drug, target, and disease networks) [15,69,73,74,104]. Zong et al. exploited the tripartite networks through the application of the DeepWalk method [130] to obtain the local latent information and compute topology-based similarities, and they demonstrated the potential of this method as a drug repurposing solution [13].

Some network-based DTI prediction studies used relationship-based features that were extracted by training the AE. A DTI-CNN prediction model devised by Zhao et al., used low-dimensional but rich depth features in a heterogeneous network trained by the stacked AE algorithm [68]. Moreover, in vivo experimental validation on atherosclerosis found that tetramethylpyrazine could attenuate atherosclerosis by inhibiting signal transductions in platelets. Other two studies [59,97] also applied the AE to capture the global structure information of the similarity measures. A study by Wang et al. applied a deep AE and introduced positive pointwise mutual information to compute the topological similarity matrix of drug and target [59]. Meanwhile, another study by Peng et al. utilized a denoising AE to select network-based features and reduce the dimensions of representations [97]. The denoising AE adds noise to high-dimensional, noisy, and incomplete input data and enables the encoder to learn more robustly by making the self-encoder learn to denoise.

However, these approaches have a limitation in that it is difficult to predict new drugs or targets, which is well known as the “cold start” problem of the recommendation systems [138]. These models are strongly influenced by the size and shape of the network; thus, if the network is not sufficiently comprehensive, they do not capture the properties of all the drugs or targets that may not appear in the network [13,139].

The other approach is using transcriptome data for DTI predictions, which measures the biological effect of drug action in in vitro experimental conditions. After the first release of the CMAP [69], a large-scale drug-induced transcriptome dataset, there have been many studies that succeeded in the identification of the drug repositioning candidates for a variety of diseases or the elucidation of the drug mode of action [140,141,142,143]. A number of studies have also employed the gene-expression profiles as the chemogenomic features for predicting DTIs. These studies are based on the assumption that drugs with similar expression profiles affect common targets [144,145].

Recent studies incorporated the updated version of CMAP, LINCS-L1000 database [70] into the DL DTI models [67,77,146]. Xie et al. built a binary classification model using a deep neural network based on the LINCS drug perturbation and gene knockout results [71]. On the other hand, Lee and Kim used the expression signature genes as the input drug and target features. They trained the rich information considering three distinct aspects of protein function, which included pathway-level memberships and PPI extracted using node2vec [63]. DTIGCCN by Saho and Zhang used a GCN model to extract the features of drug and target, respectively, from the LINCS data and CNN model to extract the latent features to predict DTPs [147]. In this hybrid model, they found that the Gaussian kernel function was helpful in building high-quality graphs; thus, their model showed better performance on classification tasks. The relationship-based DL methods described above are provided in Appendix A Table A3.

## Section: 5. Deep Learning Methods for De Novo Drug Design

In general, when classifying the de novo drug designs, studies are classified based on the DL models [87]. However, in the case of actual implementation, it may be an appropriate classification; however, it may not be enough to understand the purpose of the model. In reflection of the recent trend changes, purpose, and usability, drug design using DL has been newly classified (Figure 3).

## Section: 5. Deep Learning Methods for De Novo Drug Design › 5.1. Chemical Latent Space

The manifold hypothesis states that there exists a low-dimensional subspace that explains specific data well within the original data space [148]. The latent space is mapped with a relatively low-dimensional vector space. The latent space created through manifold learning expresses the potential characteristics of the input data well. A representative model that performs manifold learning is the AE. Dimension reduction methods based on mathematical algorithms such as principal component analysis (PCA), t-distributed stochastic neighbor embedding (t-SNE), and singular value decomposition (SVD) have similar functions; however, they have limitations in determining complex manifolds compared to the ML methods.

Converting to a latent vector as an input feature has several advantages. First, the dimension of input data is reduced. Reducing the dimension reduces the risk of overfitting the module and makes learning easier with less data. Second, it becomes possible to search or optimize molecules in the latent space [149,150,151,152]. Since similar compounds or proteins are more densely expressed in a well-trained latent space [153,154], it is also possible to compare properties or calculate compounds according to compound structures [98]. A model named GENTRL proposed by Zhavoronkov et al. [7] generated compounds reflecting the latest trends that are indirectly extracted from patent dates using self-organizing map (SOM) from the chemical latent space. Instead of learning the encoder separately, if it is connected to a DL model and learned simultaneously during the training process, a latent space is produced that is more suitable for the purpose.

However, since the latent space is also data-dependent, it is produced differently each time, and it may be constructed differently or in an incomprehensible form unlike human intention. Recently, pre-trained encoders such as X-MOL [46] are provided as independent modules. By using transfer learning, described in Section 7.2, the performance can be improved by fine-tuning the latent space trained for a universal situation according to an appropriate purpose.

## Section: 5. Deep Learning Methods for De Novo Drug Design › 5.2. Condition Control of Compounds

There are two methods for studying new drug candidates in the de novo drug design using DL. The first method is generating as many arbitrary compounds as possible and filtering them through several steps according to the purpose and finally determining a small number of candidate drugs [7]. The second method is forcing conditions or properties to meet the purpose of the generation [45]. It cannot be said that either one is better; however, many random generation methods were used in the relatively early days, and recently there are many studies on controlling the condition. Condition-controllable models are useful when creating new drugs or optimizing the existing drugs because the condition control model can modify properties such as binding affinity, logP, molecular weight, side effects, and toxicity while maintaining the main structural characteristics of the molecule.

There are various locations and methods of applying the condition (Figure 4). Lim et al. [45] manipulated the properties of the compound to be produced using conditions in the VAE (Figure 5). This simple model is trained by adding molecular properties (MW, logP, HBD, HBA, topological polar surface area (TPSA)) to both the encoder and decoder of the VAE. When creating a new compound, the researcher only needs to add the desired property to the latent vector that determines the structure of the compound. The difference between the input value and the output value is approximately 10%. Lim et al. conducted an interesting experiment to observe the change in the condition. The first was to create a set of compounds with similar properties but different structures by putting the properties of aspirin in a random latent vector. Second, several compounds similar to aspirin were generated by adding the properties of aspirin to a latent vector near aspirin. Finally, similar to the second experiment, the properties of Tamiflu were added to the latent vector near Tamiflu; however, the structural change was observed while changing the logP to various values. Kang et al. [155] made a model almost similar to Lim et al.’s model [45]. However, while Lim et al.’s model can use only compounds with known properties, Kang et al.’s semi-supervised VAE (SSVAE) can use more compounds for training by inputting the predicted results from the property predictor. Hong et al. [156] suggested different structures in their two previous studies. They used the AAE model instead of the VAE and connected the property predictor from the latent vector to refine the latent space, and then they put the compound properties (logP, SAS, and TPSA) together with the latent vector in the decoder in the training process.

## Section: 5. Deep Learning Methods for De Novo Drug Design › 5.3. Generation at Once or Sequentially

Basic generative models such as the AE or GAN form a compound from a corresponding input vector by a decoder or generator at once. In the case of the RNN using the SMILES, the word with the highest probability of matching the grammar is generated one by one from the start token until the end token appears, and finally, a large compound is completed. The one-time generation method is a method to create a new compound directly in the latent space, whereas the sequential method can start from nothing or a specific substructure and gradually complete the compound. The one-time method is simple and can provide more diverse results. Since the sequential method is generated while maintaining the active site or core scaffold with core characteristics, it can improve the binding score or properties; therefore, it can be used for fine lead optimization. Grisoni et al. [157] generated novel compounds using the SMILES and RNNs and Bongini et al. [158] using the GNNs. Lim et al. [84] created a graph-based sequential generative model from a specific scaffold rather than an atom, which has a property (MW, TPSA, logP) control function.

## Section: 5. Deep Learning Methods for De Novo Drug Design › 5.4. Fragment-Based Generation

A typical structure-based molecular representation, such as the SMILES or graph, consists of atoms and their junctions. However, compounds have more similar properties at the scaffold level than at the atomic level. The advantage of the fragment-based DL models is that when generating relatively large molecules, they output a product that is likely to exist in the natural state. For example, in the case of an atom-based model, the produced compound may include a ring consisting of 10 carbons, or a very long linear compound consisting of carbons, which are rare in nature. However, first, if the scaffold is used as a reference instead of the atom, it can be trained and created while maintaining the main substructure of the compound [84,146]. Second, it is easy to interpret and give feedback on the results based on the experts’ existing knowledge [159]. For example, beta-lactam has a characteristic scaffold (Figure 6) [160] so when developing a new antibiotic, various types of drugs can be created while maintaining the scaffold. Jin et al. [161] used molecular graphs to generate compounds from fragments (they called them motifs), and Arús-Pous et al. [146] used the SMILES to model adding fragments (they called them decorators) from a core scaffold.

Fragment-based generation has a limitation in that it becomes difficult to find a new molecular entity because only compounds similar to the existing scaffold structure are generated. In addition, there are very few types of atoms and bonds that are used in molecules, whereas the scaffolds have many types if not restricted by certain criteria.

## Section: 5. Deep Learning Methods for De Novo Drug Design › 5.5. Genetic Algorithm

Genetic algorithm is a method inspired by biogenetics, which has been traditionally used before DL [162], and it is mainly used to address optimization problems. The algorithm generates a random set of data called the initial generation and combines them to create a new generation. It repeats the process of intersecting some data with the highest score to create the next generation to obtain the most optimal result. If each data can be expressed in the form of a gene, and if there is a titration function that can be evaluated as a continuous value, it can be introduced relatively easily and produces a sufficiently acceptable result, although not perfect. De novo drug design using a genetic algorithm has been studied until recently [163,164], and the genetic algorithm method combined with DL [165] has been proposed in recent years.

## Section: 6. Evaluation Method › 6.1. Benchmarking Datasets and Tools

Over the decades, large amounts of repositories on the bioactivity, structure, and protein targets of small molecules have been accumulated in public databases such as PubChem [163], ChEMBL [164], and BindingDB [166]. These big datasets enable us to build predictive models for drug–target relationships via computational methods. To compare the performance of the models by evaluating their reproducibility for the prediction results, several datasets have been used. Appendix A Table A4 shows the list of benchmark datasets. These datasets consist of known active data and inactive compounds. In many datasets, an inactive compound is presumed to be inactive unless it is identified as active in an experimental biological assay, also referred to as “decoys” [167]. There are several benchmarking databases that provide refined decoy compounds [166,168]. They rationally selected inactive compounds to avoid false negatives because the false negative (i.e., active compounds are considered as inactive in the decoy sets) can underestimate the performance of the prediction methods. DUD-E [166], a gold standard dataset used for the evaluation of the VS methods, selected decoys based on the concept that the decoy compounds must be structurally different from the known ligands to reduce the false negative, whereas it must be similar to the known ligands with respect to physicochemical properties to reduce bias.

Chen et al. argued that the hidden bias in the widely used dataset (DUD-E database) may lead to misleading performance of the CNN models during the structure-based VS [169]. There were two remaining biases [170]. One is the limitation of exploring the decoy restricted in the chemical space of reference compounds including active compounds (i.e., analogous bias). The other is the limitation of artificially good enrichment in evaluation because the physicochemical properties of the active compounds and decoy compounds (i.e., artificial enrichment bias) can be clearly distinguished. To overcome these limitations, the MUV datasets [168] and the demanding evaluation kits for objective in silico screening (DEKOIS) [171] were proposed. Until recently, fine-tuned benchmarking datasets have been consistently presented. Xia et al. proposed the unbiased ligand set (ULS) and unbiased decoy set (UDS) [172] for the G protein-coupled receptors. Another group used an asymmetric validation embedding procedure to design a novel dataset called LIT-PCBA dataset [173] for some PubChem bioassays.

Candidate drugs created using the de novo drug design cannot be measured for efficacy unless they are actually synthesized. The de novo drug design using DL has developed significantly in recent years [19], and designing a good generative model rather than generating an effective drug is a major evaluation criterion in the de novo drug design research field. MOlecular SEtS (MOSES) [174] and GuacaMol [175] are the most popular benchmarking tools. These two tools score and compare the performance of new DL models based on the base models. Both the tools use post-processing databases based on ZINC or ChEMBL, and include general representations such as FP, SMILES, and molecular graphs. The features and issues of both the tools for benchmarking in the de novo drug design are described in detail by Grant et al. [176] in their review paper.

## Section: 6. Evaluation Method › 6.2. Evaluation Metrics for DTI Prediction

The DTI prediction can be grouped into two types: (1) DTP prediction by a classification model that assigns a positive or negative (i.e., active or inactive) label to the DTP and (2) drug–target affinity (DTA) prediction by a regression model that estimates the binding affinity value between the drug and target. Because the evaluation metrics are different for each type, this section describes the performance metrics for each type of model.

## Section: 6. Evaluation Method › 6.2. Evaluation Metrics for DTI Prediction › 6.2.1. Classification Metrics

The DTP prediction studies have adopted several common evaluation indicators including accuracy, precision, recall (also known as sensitivity), and specificity. These metrics are calculated from the confusion matrix. The most straightforward metric for classifier performance is accuracy. However, the accuracy metric does not work well in problems with skewness or class imbalance. For example, a prediction with a target that only affects less than 1% of all drugs is very easy to achieve 99% accuracy by obtaining the correct negatives even when few correct positives are predicted. For this reason, precision and recall are often quantified by many DL studies, which measure that the correctly predicted DTI with activity in practice is classified as positive repeatedly. Precision and recall can be measured simultaneously using two scores: F-score and precision–recall area under curve (AUPR). F-score (also called F measure) is a balance between precision and recall. For example, an F1 score is the weighted average value of precision and recall. The PR-AUC can show the tradeoff between precision and recall and reduce the impact of false positives. There are other useful metrics when the classes are imbalanced. Balanced accuracy applies the average of the sensitivity and specificity [177]. Matthews correlation coefficient (MCC) measures the correlation of the true classes with the predicted labels. Chicco and Jurman [178] showed that MCC is more informative in evaluating binary classifications than accuracy and F1 score.

Another commonly used evaluation indicator for DL methods is the area under the curve (AUC). The AUC means the area underneath a receiver–operator characteristic (ROC) curve that compares the performance of classifiers by distinguishing the two types of errors: false positives or negatives. The ROC curve is the plot of true positive rate (TPR, or sensitivity) against false positive rate (FPR, or 1-specificity), and the best classifier that will achieve perfection is the top-left of the plot (FPR = 0, and TPR = 1). The AUC value in the DTI prediction indicates how well the positive DTIs are ranked in the prediction. The AUC is sensitive to the imbalanced DTI dataset, which are prone to a large number of false positives (i.e., few positive DTIs relative to negative DTIs) [179].

## Section: 6. Evaluation Method › 6.2. Evaluation Metrics for DTI Prediction › 6.2.2. Regression Evaluation Metrics

Binding affinity scores such as IC50 and pKd predicted by DTA prediction models can be assessed by several evaluation indicators: mean square error (MSE), root mean square error (RMSE), Pearson’s correlation coefficient (R), and squared correlation coefficient (R2). These metrics have been implicated to determine the quality of predictive QSAR models. The MSE is defined as the average squared difference between the predicted and ground-truth binding affinity scores. The RMSE, as its name suggests, is the squared RMSE. R2 measures how well the predicted values match the real values (i.e., goodness of fit). Some studies [23,120] applied the modified R2 (rm2) to the test set prediction, which was introduced by Roy and Roy [180].

Other metrics such as concordance index (CI or C-index) and Spearman’s correlation coefficient (ρ) quantify the quality of rankings by comparing the order of the predictions and the order of the ground truths. A frequently used ranking metric in the DTA prediction is the CI [25,130,181]. When predicting the binding affinity values of two random DTPs, the CI measures whether those values were predicted in the same order as their actual values. The other metric, Spearman’s correlation coefficient, measures the strength and direction of the association between two ranked variables. Several studies utilized Spearman’s correlation coefficient with other metrics [17,59,60,182].

## Section: 6. Evaluation Method › 6.3. Evaluation Metrics for De Novo Drug Design › 6.3.1. Generation Metrics

The generation index is meaningful in evaluating the performance of the DL generator model through the set of generated molecules rather than evaluating the generated compounds as drugs. This does not mean that models with better generative metrics make better drugs. The four generation indices are commonly used in the de novo drug design studies, and in the case of the SMILES data, an open library such as RDkit [119], GuacaMol [175], or MOSES [174] can be used to quickly measure the generation index (Figure 7).

Validity index evaluates whether a generated compound can exist or not. For example, in the case of the SMILES expression method, if the grammar is not learned sufficiently, the valid molecules are not generated, or the parentheses do not match. Validity is the ratio of compounds that grammatically exist among all the compounds, and the closer to 1, the better the model. A higher validity may indicate a better model; however, from an industrial point of view of new drug development, low validity is not necessarily a problem. Even a model with low validity can increase the absolute number of valid compounds by securing a large population. This is because the additional cost of generating more compounds and filtering valid compounds in the VS stage is relatively low compared to the time and cost in other stages. Rather, if the novelty and uniqueness performance is lowered to increase the validity, it may not be suitable for the creation of new drug candidates.

Uniqueness is a number that determines whether the generator creates a new compound without duplication. Compared to other types of data such as images and sounds, a compound is a very discrete type of data. For this reason, even if a small change or noise is added to the input condition, the generated compound does not reflect the change, and the same compound may be created repeatedly. Uniqueness is evaluated by the number of generated products and the ratio of unique compounds with duplicates removed. If the uniqueness is 1, it means that all the generated compounds are different without duplicates.

While uniqueness measures the absence of overlap within the generated compound set, novelty measures the non-overlapping property by comparing the generated set with the existing dataset. That is, it evaluates whether the generator has created a new compound that does not exist in the training dataset. It is evaluated by the ratio of the subset with the training dataset compared to the generated compound. The closer the novelty is to 1, the more completely new compounds are created, and although it is used as an important indicator in the field of de novo drug design, it is not important if the existing compounds are also allowed. (1)ValidityN=# of valid compounds in N# of compounds in N, (2)UniquenessN=# of unique compounds in N# of compounds in N, (3)NoveltyN, T=# of intersection between N and Tc# of compounds in N.N = generated compounds set, T = Training dataset, Tc = Complement set of T Diversity or dissimilarity (or distance) is an indicator to determine how dissimilar and diverse the produced compounds are when only a few scaffolds or a small number of atoms are changed. Chemotype diversity can be measured as a value between 0 and 1 using scaled Shannon entropy. Similarity can also be measured using the distance between compounds the expressed in the FP or SMILES. As shown in Equations (4)–(6), the average distance within a set can be calculated using the Tanimoto coefficient [183]. (4)Tanimoto x, y=x· yTx· xT+y· yT−x· yT, (5)Soergel x, y=1−Tanimoto x, y, (6)Distance N=2Nu2 ∑i=1Nu−1∑j=i+1NuSoergel xiu,xju.

Controllability is mainly used in the de novo models with the condition control functions [155,156]. It indicates how precisely the property value of the output compound is distributed for the input condition. Unlike other metrics, it is not expressed as a specific value, but is usually visualized using a histogram to evaluate the distribution compared to the target value. The smaller the variance, the better the performance.

## Section: 6. Evaluation Method › 6.3. Evaluation Metrics for De Novo Drug Design › 6.3.2. Pharmacological Indicators

The pharmacological index measures whether the produced compounds have pharmacological effects, through a hypothetical method. Quantitative estimate of drug-likeness (QED), a representative pharmacological index, was introduced by Bickerton et al. [184], and it measures how similar the chemical properties of eight types of drugs are to those of the existing drug groups [185]: molecular weight (MW), lipophilicity (logP), number of hydrogen bond donors (HBD), number of hydrogen bond acceptors (HBA), polar surface area (PSA), number of rotatable bonds (ROTB), number of aromatic rings (AROM), and count of alerts for undesirable substructures. QED was inspired by Lipinski’s rule and was standardized more quantitatively by including the insight. QED is widely used in the de novo drug design; however, usually, researchers evaluate only some of its metrics. Typically, the distributions of the MW and logP are often compared, and HBD and HBA are sometimes used. In particular, the MW and logP are often used to evaluate the control performance of a controllable de novo model [45] and can be considered to produce good performance when the variance is small.

Moreover, synthetic accessibility is measured to enhance the validity of real medicines from a practical industrial perspective. When building a model, synthetic accessibility can be optimized, or it can be filtered by removing compounds that are difficult to synthesize after being randomly generated. Currently, research is underway not only to measure composition difficulty through DL but also to propose suitable synthesis order. If this can be integrated, optimal drugs can be created from the early stages of new drug design considering molecular synthesis.

## Section: 7. Limitation and Future Work › 7.1. Current Challenges › 7.1.1. Data Scarcity and Imbalance

The lack of labeled data is a major limitation to the use of DL-based drug discovery [186]. Data volumes resulting from drug discovery studies are small-scale because it requires expensive experiments and a long time to generate DTI data. For example, the most frequently used benchmark dataset for the DTI prediction is the Yamanishi_2008 dataset [187]. The dataset not only presents data on less than 1000 drugs, but also contains very limited DTI information with an average sparse rate of 3.6% [67].

Besides, the labeled data in drug discovery are extremely imbalanced. Since the HTS technique itself does not presuppose a high frequency of active responses, the HTS data consist of significantly fewer active responses than inactive responses. Consequently, there are often only a few validated drugs available for positive DTIs. In the PubChem Bioassay dataset, an active to inactive ratio of 1:40.92 (a hit rate of 2.385% of the total labeled activity values) indicates that most of the test results are inactive [188].

## Section: 7. Limitation and Future Work › 7.1. Current Challenges › 7.1.2. Absence of Standard Benchmark

In reality, the total number of drugs and proteins tested during the experiment is limited, making it imprecise to guarantee how a specific drug or target protein can work under the same experimental conditions. This problem is prominent in public databases that have accumulated data from the experimental results of numerous researchers around the world. However, big pharmaceutical companies can collect a large amount of data points by analyzing of constant conditions and well-characterized quality [133]. One research group built a model using the company’s private data and the public ChEMBL [189] data and found that the predictive quality of the company model was higher than that of the public data model [115]. This demonstrates that the experimental conditions in the standardized datasets can affect the DNN prediction quality. Therefore, the necessity of data standardization and curation prior to building a predictive model are indispensable. Many public databases, including PubChem [190], ChEMBL, and ExCAPE-DB [191], aimed to standardize and integrate multiple-sourced datasets to facilitate computational drug discovery. However, many DTI prediction models use only a small benchmarking dataset and use the train data and test data from the same source. This shows that many DTI models do not properly validate their generalization performance, demonstrating their inability to predict new DTIs in practical drug development.

## Section: 7. Limitation and Future Work › 7.2. Promising Method › 7.2.1. Transfer Learning

As mentioned in the previous section, one of the biggest problems in drug discovery using AI is the lack of data. When targeting a specific disease or newly discovered target, the amount of data is so small that it is difficult to train. Moreover, it is difficult to easily apply augmentation to all the data. In such a situation, transfer learning is an excellent alternative [186,192]. Transfer learning, as part of lifelong learning, is inspired by how quickly humans acquire new knowledge from other similar experiences in the past. Transfer learning can improve many problems of insufficient data by fine-tuning a pre-trained model with a large dataset in another or a general field to an actual small-scale dataset [181]. Bonggun et al. [23] imported a molecule representation model learned from the PubChem database and applied it to their DTI model to improve performance. Panagiotis et al. reported that the transfer learning method exhibited improved performance in CHEMBL25 or DRD2 in the de novo study using conditional RNN [182].

Multi-task learning is also frequently used in drug discovery [186]. If transfer learning is to take the weights of a well-initialized DL model using a large dataset and use it for the target model, multi-task learning trains multiple tasks with many common parts at the same time (Figure 8). With multi-task learning, intrinsic features that are difficult to train with small datasets can be trained using different tasks. Steven et al. showed that using multi-task learning increased the AUC compared to the conventional random forest method or logistic regression method. When using multi-task learning, some datasets exhibited slightly decreased AUC, but for most datasets, AUC increased significantly. In particular, it is noteworthy that the performance of the datasets with a relatively smaller amount of data improved significantly. Using a pre-trained model improves the performance [47]; however, it has the advantage of significantly reducing the training time and computing power from an industrial and practical point of view. Therefore, we recommend using transfer learning for representation learning.

## Section: 7. Limitation and Future Work › 7.2. Promising Method › 7.2.2. Data Augmentation

There is a method of supplementing the data by incorporating small modifications in the existing data or changing the expression rule, which is called data augmentation. Data augmentation reduces model overfitting and improves the general performance. For data such as the voxel, a common image data augmentation method called geometric transformations can be applied [193]. Alternatively, there is a data augmentation method that adds a small amount of noise that does not affect the performance of the data. Isidro et al. [194] improved the predictive performance of the model by adding Gaussian noise to bioactivities and compound descriptors.

Another popular data augmentation method in drug discovery is randomized SMILES [146,182]. One compound can be written in various SMILES according to the starting point and direction. In the early stage of drug discovery using DL, a canonical SMILES was used for consistent expression; however, in the field of de novo drug design, randomized SMILES is used in a more general way [195]. Josep et al. [182] revealed that the quality of the generative model was better when using randomized SMILES than when using canonical SMILES. Randomized SMILES is mainly used for the de novo drug design [146]; however, Esben [30] showed that randomized SMILES trained more reliably and performed better than the canonical form even when predicting IC50. Unlike de novo, where the number of possible representations of a molecule is important, DTI requires information on the relationship between the ligand and target; therefore, it is not widely used.

## Section: 7. Limitation and Future Work › 7.2. Promising Method › 7.2.3. Uncertainty and Interpretation

DL is a very powerful tool. It gives us hope that problems that were difficult to address using the classical ML methods can be solved with good performance if high-quality data are supplied abundantly. However, problems arose as the field of application of DL was expanded to a specialized area rather than an easy task. Since the parameters in the model are fixed and the operation process can be known, it is not actually a black box; however, it is treated as a black box because it is difficult for a human to interpret the process of deriving the result [196]. The non-transparency of this interpretation makes it difficult to accurately understand the reasoning process or an obstacle to decision-making. In particular, in areas such as drug discovery or disease diagnosis, where a wrong decision is costly and time consuming, sufficient evidence is needed to accept the result. Therefore, there is a growing need for explainable AI. An explainable AI review paper in the field of drug discovery by Jiménez-Luna et al. describes this well [197].

Although ‘explainable’ is defined in many ways, we will describe only two of the most commonly used concepts [198]. The first is ‘uncertainty estimation’. Uncertainty can be thought of as the opposite of reliability of AI. In the case of the classification model, the weight for each class is output in the last layer, and the class with the highest value is selected using a function such as softmax. However, sometimes, the model outputs completely different results even with very small changes in the weight of the data or hidden layer. From this point of view, uncertainty can be interpreted as a measure of robustness against noise in the training process or model parameters when a certain result is output. Uncertainty leads researchers to make safer and more efficient decisions by estimating risks that will occur during drug development [199]. The second is ‘interpretation’. Interpretation is often used interchangeably with ‘transparency’ depending on the paper [3,198]. Xuhong et al. [64] redefined ‘interpretability’ as follows in their paper: “The model interpretability is the ability (of the model) to explain or to present in understandable terms to a human.” The initial concept of an interpretable DL model was to create class activation maps [200] from the convolution layer of the CNN to visualize the reason for prediction by matching the input result. In the recent drug discovery field, attention-based explainable models dominate. The increased use of attention-based models such as the transformer is also because the performance is better than the other methods at sequential data; however, the reason can be inferred indirectly from attention. Gao et al. [119] created an attention matrix from the results of embedded protein (LSTM) and molecule (GCN). The attention matrix visualized contributing weights of atoms in molecule and residues that affect the DTI, thereby helping researchers to understand the process in a transparent manner and gain new insights. As a solubility prediction method, but not that of DTI, Karpov et al. [77] used a transformer-CNN model from the SMILES data, and Liu et al. [201] used the GCN from a molecule graph to predict the positive or negative contribution of the atoms to solubility. Chen et al. created a model to interpret the atoms contributing to the interaction in the prediction of the DDI [80].

The advantage of interpretability is that it gives the researchers confidence in the results. When the reason for drawing a conclusion is consistent with prior knowledge, the expert can accept the decision with high confidence [3]. It can also provide new inductive inspiration to experts [198]. Finally, it can provide another channel to discover problems when the performance of the DL models is poor.


---

# Construction and Drug Evaluation Based on Convolutional Neural Network System Optimized by Grey Correlation Analysis

- **Authors:** Hui Teng
- **Issuer:** Computational intelligence and neuroscience
- **Type:** Scientific article
- **Published:** 2021-09-15
- **Language:** en
- **DOI:** 10.1155/2021/2794588
- **Source:** https://pubmed.ncbi.nlm.nih.gov/34567098/
- **Licence:** CC-BY

## Section: Abstract

Incidence rate of mental illness is increasing year by year with the development of city. The amount of modern medical data is huge and complex. In many cases, it is difficult to realize the rational allocation of resources, which puts forward an urgent demand for the artificial intelligence of modern medicine and brings great pressure to the development of the medical industry. The purpose of this study is to develop and construct a grey correlation analysis and related drug evaluation system of mental diseases based on deep convolution neural network. The establishment of the system can effectively improve the automation and intelligence of modern psychiatric treatment process. In this article, the grey correlation analysis of patient data is carried out, and then, the optimized deep convolution neural network is constructed. Combined with the medical knowledge base, the analysis of disease results is realized, and on this basis, the efficacy of related drugs in the treatment of mental diseases is evaluated. The results show that the advantage of the deep convolution neural network system is to effectively improve the induction rate. What's more, compared with other algorithms, this algorithm has higher accuracy and efficiency. It improves the comprehensiveness and informatization of disease screening methods, improves the accuracy of screening, reduces the consumption of doctors' human resources, and provides a theoretical basis for the digitization of the medical industry in the future.

## Section: 1. Introduction

In recent years, with the development of science and technology, many breakthroughs have been made in the field of deep learning. Convolutional neural network (CNN) reported many research results that are very eye-catching [1–3]. The advantage of deep convolution neural network is not only that it can imitate the human visual system and extract image features layer by layer, which can improve the recognition rate, but also the stability and good translation invariance of these features, which can improve the accuracy of analysis and processing [4, 5]. Based on the above advantages, deep convolution neural network is widely used in many industries, including but not limited to face, image, and speech recognition [6–8].

Grey relational analysis (GRA) is a common analysis method, which is mostly used to count the influence of multiple factors on the results [9, 10]. In many cases, there are many factors affecting the process of the results, and we need to analyze which index is more relevant or the correlation ranking of these factors, and we can get the response results through the grey correlation analysis.

In recent years, with the development of society, people's demand for spiritual life is increasing, the incidence of mental illness is also increasing year by year, and the incidence is mostly concentrated in big cities [11–13]. Modern medicine has a huge amount of complex data; in many cases, it is difficult to achieve a reasonable allocation of resources, which puts forward an urgent demand for the artificial intelligence of modern medicine and also brings great pressure to the development of the medical industry [14–16]. Compared with other kinds of diseases, the medical data of mental diseases may have more complex data records, which consumes a lot of medical human resources. However, the scope of computer identification data is limited and can only be applied to structured data. Therefore, we need to process the massive data of mental diseases to construct an evaluation system that is widely used in the analysis of mental illness.

In recent years, deep learning is a very important aspect in the field of machine learning, especially in the medical and other industries [17, 18]. Machine learning relies on the process of computer recognition data, which is limited to a certain extent, and requires manpower and material resources to develop specific evaluation indicators for each mental disease [19, 20]. These indicators are special and constantly change with the types of diseases, which is not conducive to the unified processing of intelligent data [21–23]. Deep learning can integrate data and represent specific indicators of data by combining higher level features that claim to be abstract [24, 25]. Because of its good feature extraction ability and system construction method, it can be applied to many different areas of mental illness [26–28].

There is a huge space for in-depth learning and development in the medical industry, especially in the assessment of mental illness. Therefore, the purpose of this study is to develop and construct a grey relational analysis of mental illness and evaluation system of related drugs based on deep convolution neural network. The establishment of this system can effectively improve the automation and intelligence of modern psychiatric treatment process. In this article, the grey correlation analysis of the patient data was carried out and then construction of the optimized depth convolution neural network was done, combined with the medical knowledge base, to achieve the analysis of the results of the disease, and on this basis, to evaluate the effect of the relevant drugs for the treatment of mental diseases. The advantage of the construction of deep convolution neural network system in this study is that it effectively improves the induction, classification, and analysis efficiency of modern mental diseases using the algorithm, makes the disease screening means more comprehensive and informative, improves the screening accuracy, and reduces the consumption of doctors' human resources, which provides a theoretical basis for the future digitization of the medical industry.

## Section: 2. Grey Correlation Analysis of Mental Illness Cases › 2.1. Construction of Grey Correlation Analysis System

Grey relational analysis (GRA) is a commonly used analysis method, which is mostly used to count the influence of multiple factors on the results. The basic process is to determine the composition of reference data column and comparison data column, which reflects the degree of correlation between data. When using grey correlation analysis to solve the problems of comprehensive evaluation, it is necessary to calculate and analyze the subsequence and the parent sequence, which are changing with the events according to certain rules and on the basis of establishing the parent sequence, so as to get the degree of correlation between the two and draw a conclusion. The specific flow chart is shown in Figure 1 [29].

First of all, we need to be clear about the two basic sequences. The first is the sequence of specific behavior characteristics of the reaction process system, which is called reference sequence here. The other is the sequence that has a certain impact on the system behavior, which we call comparative sequence. The formula is as follows:

References sequence:(1)Yk|k=1,2,…,n.

Comparison sequence:(2)Xik|k=1,2,…,n, i=1,2,…,m.

After defining these two sequences, we need to do some dimensionless processing on the data. The reason is that different dimensions in the system will have a certain degree of influence on the data in each factor column, which will interfere with our correct experimental results, so it is very necessary to carry out dimensionless data processing. We can do dimensionless processing by the following two methods.

First, initial value processing:(3)xik=xikxi1, k=1,2,…,n; i=0,1,2,…,m.

The second is the average processing:(4)xik=xikxi, k=1,2,…,n; i=0,1,2,…,m.

In the above two formulas (3) and (4), k represents the time, and i represents an eigenvalue in the comparison sequence.

After processing the data, we will calculate the correlation coefficient.(5)ζik=miniminkyk−xik+ρmaximaxkyk−xikyk−xik+ρmaximaxkyk−xik.

Note that(6)△ik=yk−xik.

Then(7)ζik=minimink△ik+ρmaximaxk△ik△ik+ρmaximaxk△ik.

Among them,(8)ρϵ0,∞.

In these formulas, ρ is the resolution coefficient. When its value is smaller, the resolution of analysis will be larger. Generally, the value range is (0, 1). In general, we think that when ρ < 0.5463, the resolution of this case is the best, so it is usually ρ=0.5.

Next, we need to calculate the correlation coefficient. Because the correlation coefficient is the correlation degree value of the comparison sequence and the reference sequence at each time (that is, each point in the curve), it has more than one number, and the information is too scattered to facilitate the overall comparison. In order to make a better overall comparison, we need to integrate each point in the curve into a numerical value, that is, to calculate the average value, and reflect the correlation between the comparison sequence and the reference sequence on the basis of the average value [30]. The formula is as follows:(9)ri=1n∑k=1nζik, k=1,2,…,n.

Then, we compare the two values. If r1 < r2, the reference sequence y is more similar to the comparison sequence x2.

## Section: 2. Grey Correlation Analysis of Mental Illness Cases › 2.2. Analysis of Mental Illness Cases

The system includes medical document preprocessing module, which is used to clean up illegal characters in medical text big data, unify Chinese character encoding, and generate word table for word vector training. The word vector training module is used to read preprocessed medical texts. By training a deep convolutional neural network, the primary word vector is generated by optimizing the probability of the language model. The distributed semantic characteristics of medical information extraction module take the primary keyword as the starting point of the vector, using deep convolution neural networks, mapping the original data to hidden layer feature space, and finally, we use the full connection layer to map distributed features to a sample label space. Thus, the distributed semantic features in the medical field are generated for the risk assessment of mental diseases and the evaluation of drug efficacy.

We need to deal with the massive data of mental illness and build an evaluation system, which is widely applicable to the analysis of mental illness. The premise of this system is to process the existing data of mental illness according to the corresponding indicators. This study conducted a grey correlation analysis on the incidence rate of mental illness to explore the influencing factors of mental illness. Mental diseases are usually divided into schizophrenia, psychosexual disorders, and personality disorders. We analyzed the incidence rate of some mental disorders reported in a recent 5 years. We used the reported incidence rate as a reference sequence (A0) in the past years, taking schizophrenia, A1, A2, and A3 as the comparison sequence. We adopted the initial steps to carry out the dimensionless processing through the basic steps of grey correlation analysis and then calculated the correlation coefficients based on the normalized values after the treatment was processed [31]. The results are shown in Figure 2.

From Figure 2, we can analyze that the incidence rate of A2 mental illness in the past five years is relatively high in the three cases, which may be attributed to the changes in social and cultural development in recent years as the development of science and technology.

Next, we also analyzed the correlation between mental illness and patients' age, gender, height, weight, occupation, and income, as shown in the figure. It can be seen from Figure 3 that the incidence of mental illness has the highest correlation with the income of patients and the lowest correlation with gender.

There are many methods of factor analysis, such as regression analysis, including linear regression, multifactor regression, single factor regression, stepwise regression, nonstepwise regression, and so on. The above methods generally require a large amount of data, typical distribution, and large amount of calculation. Grey correlation analysis is based on the development trend of the process and the spatial distribution of related samples, in order to explain the correlation between the two. As shown in Figure 4, it is the error surface diagram after three repetitions of grey correlation analysis data calculation, and the error range is within the allowable value (a < 1).

The essence of factor analysis method is to analyze the geometry of the curve, judge whether the development trend is close or relevant from the correlation of geometry, and judge the specific value of correlation through the proximity of geometry, which can accurately reflect the dynamic development process between samples.

## Section: 3. Construction of Convolution Neural Network System Optimized by Grey Correlation Analysis

In the field of deep learning, the first mock exam is the convolution neural network (CNN), which has been a major factor in the development of AI in recent years [32]. The advantage of this model is that it is necessary to extract features automatically and reduce the dimension of the feature based on convolution and pool operation.

As a special kind of neural network algorithm, the neurons in each layer of convolutional neural network have three dimensions, including width, height, and depth [33]. Convolution is based on a two-dimensional model, which has two numerical indicators of width and height, while depth refers to the dimension of active data volume in convolution network. The main flow of convolution neural network algorithm is shown in Figure 5. The data are transformed and analyzed through three dimensions and finally output to specific vector data through the output layer.

Convolutional neural network is mainly composed of input layer, convolution layer, relu layer, pooling layer, and fully connected layer. The deep learning algorithm for mental illness analysis and drug evaluation flow chart is shown in Figure 6.

Convolution layer is the core layer of convolution neural network, and most of the computation in the network is generated by convolution layer. Note the number of calculations not the number of parameters. The parameters of convolution layer are composed of a group of learning filters. The space for each filter is small (width and height), but the depth is the same as the input data. The formula for calculating the output size of any given convolution layer is as follows:(10)O=W−K+2PS+1,where k is the filter size, P is the fill value, S is the step size, and W is the dimension of the input text matrix.

The actual output formula of the whole network is(11)Op=FnF1XW1.

The output of the current layer is expressed as(12)X1=f1W1WX1−1+b1.

The activation function F1 is the correction linear unit, which is relu activation function(13)f1=maxW1TX1,0.

When dealing with some complex input problems, such as image processing, each neuron cannot perfectly link with the previous neuron. In this case, we need to transform the connection part of each neuron into a specific area in the part of the previous input data. This area is called the receiving domain, and the actual size of the receiving domain is a super parameter. In the depth direction, the size of the connection is always equal to the depth of the input.

In addition, the existence of receptive field also explains the specific structure of convolution layer in deep convolution neural network, in which each neuron has a certain connection with the input data sample, and how each neuron arranges with the corresponding input data needs to be clarified in this part. In general, there are three super parameters to control the output volume, including depth, step size, and zero fill. It can be calculated by inputting relevant data, including receptive field size (F), step size (S), number of filters (K), and number of zero padding (P) of neurons in convolution layer(14)W2=W1−F+2PS+1,H2=H1−F+2PS+1.

Generally speaking, when the step size S = 1, the value of zero padding is P = (F − 1)/2, which can ensure that the input and output data bodies have the same space size.

In the convolution layer, the number of parameters is generally regulated by the weight, and even in the same convolution layer, the weight of each receptive field may be different, which will lead to a huge amount of data in such a complex situation.

Usually, a pooling layer is periodically inserted between successive convolution layers. Its function is to gradually reduce the spatial size of the data body. In this way, the number of parameters in the network can be reduced, the cost of computing resources can be reduced, and the over fitting can be effectively controlled.

The corresponding formula in the convergence layer is as follows:(15)W2=W1−FS+1,H2=H1−FS+1.

There are two main differences between this method and the previous convolution size calculation. Firstly, there is no additional supplement in the pooling process; Secondly, the depth of pool remains unchanged.

The deep convolution neural network mainly uses the back propagation of the error function and uses the random gradient descent method to optimize and adjust the convolution parameters and deviations until the network converges or stops when the maximum number of iterations is reached. In this process of back propagation, it is usually necessary to compare different data samples with corresponding labels and then calculate the square error cost function to identify multiple categories of c categories and N training samples. The final output error function of the network is calculated by the following formula:(16)EN=12∑n=1N∑k=1ctkn−ykn2.

BP algorithm is used to calculate the error function(17)δ1=Wl+1Tδl+1f′u′,of which(18)u′=Wlxl+1+bl.

Using grey correlation analysis to optimize convolution neural network algorithm is an improved method, which can give full play to the advantages of convolution neural network algorithm. The improved main flow chart is shown in Figure 7.

## Section: 4. Analysis of Experimental Results and Drug Evaluation

In the above experimental analysis, we set the structure and related parameters of the deep convolution network. The structure of deep convolution network is composed of two convolution layers and two subsampling layers, which are connected alternately; The number of characteristic graphs of the lower sampling layer is consistent with that of the corresponding convolution layer. We analyze and compare the accuracy rates of traditional CNN, preprocessed CNN, and improved CNN algorithm system based on GRA and test the error recognition rates of the three algorithms after iterating once, and the results are shown in Figure 8.

With the development of science and technology, many deep learning models are considered to be used in the research of medical industry and related drugs. Among them, deep convolution network with its unique advantages has gained a lot of attention, its unique advantage is that it is good at classifying massive and complex data streams into smaller and smaller information. This characteristic is the key reason why deep convolution neural network can produce the best results in dealing with many complex problems, including image classification and speech recognition. Then, the depth convolution neural network model can recognize nose, ears, and eyes by combining edges. Finally, the model can learn face recognition and other fields by combining these parts.

The prediction of drug-drug interaction (DDI) is a very challenging problem for pharmacology and clinical application. Drug-drug interaction refers to the connection and chemical interaction between two or more drugs under certain conditions, which may lead to unexpected side effects in the treatment process. In recent years, many reports also show the importance of the study of drug interactions. If we can predict DDI in advance, we can do this and provide the theoretical basis of neural network algorithm calculation for the drug treatment of mental diseases in the future.

There are several methods for DDI prediction. The first is molecular characterization, which mainly focuses on the feature learning of drug molecules. These methods are based on the same assumption that drug molecules with similar embedding representation will show similar DDI. If molecules A and B have similar molecular structures and so do their learning eigenvectors. If molecule A interacts with molecule C, it can be inferred that molecule B and molecule C have similar DDI. There are many methods to learn drug molecular features, such as one-dimensional smile sequence similar to text coding, such as traditional methods based on molecular descriptors or molecular fingerprint ECFP or methods based on 3D coordinate axis position information.

Another commonly used DDI prediction method is based on network embedding. By constructing various biological networks related to drugs, drugs are regarded as nodes in the network, and the relationship between potential edges, namely, DDI, is predicted by learning the embedded representation of nodes. There are many ways to establish the mapping relation network, such as matrix decomposition or constructing the objective relation into a matrix to solve. For example, random walk, choose a fixed path to walk in the graph to obtain more node features. The goal of these methods is to predict the label edge between drugs, but they only focus on a single DDI relationship and do not consider other links related to drugs.

The system preprocesses the electronic health documents of mental illness patients and builds a language model to transform the text into word vector. The distributed semantic features of clinical documents were extracted by deep convolutional neural network, and the long-term semantic correlation features were obtained by combining with deep grid long-term and short-term memory neural network, which could be used for the subsequent evaluation and analysis of the efficacy of related drugs in patients with mental illness.

In this study, we use the convolution neural network algorithm system optimized by grey correlation analysis to analyze the related drugs 1–4 for depression, which is an important treatment of mental illness. We can comprehensively judge the drug effect by comparing its six different clinical treatment indicators. The results are shown in Figure 9. It can be seen from the analysis of the results in Figure 9 that among the four drugs used for the treatment of depression, the scores generated by each clinical index are different, and the final comprehensive evaluation score can better reflect the effect of the drug in the clinical treatment process. From the results of this analysis, it can be seen that the comprehensive evaluation score of drug 1 is the best, followed by drug 3, followed by drug 4, and finally drug 2 has the lowest comprehensive evaluation score. Based on the above results, it can provide data theoretical guidance for the follow-up treatment of depression. This evaluation system provides more possibilities for improving the relevant medical means or drug combination.

## Section: 5. Conclusion

In this study, a mental disease grey correlation analysis system and related drug evaluation system based on deep convolutional neural network were developed and constructed, which innovatively applied deep convolutional neural network to the analysis of mental diseases and the evaluation of related drugs, providing great convenience for the diagnosis and treatment of mental diseases. The establishment of this system can effectively improve the automation and intelligence of modern mental illness treatment process. In this article, the grey correlation analysis of the patient data was carried out, and then the construction of the optimized depth convolution neural network was done, combined with the medical knowledge base, to achieve the analysis of the results of the disease, and on this basis, to evaluate the effect of the relevant drugs for the treatment of mental diseases. The advantage of the construction of deep convolution neural network system in this study is that it effectively improves the induction, classification, and analysis efficiency of modern mental diseases by using the algorithm, makes the disease screening means more comprehensive and informative, improves the screening accuracy, and reduces the consumption of doctors' human resources, which provides a theoretical basis for the future digitization of the medical industry.


---

# Deep Learning Driven Drug Discovery: Tackling Severe Acute Respiratory Syndrome Coronavirus 2

- **Authors:** Yang Zhang, Taoyu Ye, Hui Xi, Mario Juhas, Junyi Li
- **Issuer:** Frontiers in microbiology
- **Type:** Scientific article
- **Published:** 2021-10-28
- **Language:** en
- **DOI:** 10.3389/fmicb.2021.739684
- **Source:** https://pubmed.ncbi.nlm.nih.gov/34777286/
- **Licence:** CC-BY

## Page 1 (Section: Deep Learning Driven Drug Discovery: Tackling Severe Acute Respiratory Syndrome Coronavirus 2)

MINI REVIEW
published: 28 October 2021
doi: 10.3389/fmicb.2021.739684
Edited by:
Mohammad-Hossein Sarrafzadeh,
University of Tehran, Iran
Reviewed by:
Hashem Asgharnejad,
Polytechnique Montréal, Canada
Tanmay Majumdar,
National Institute of Immunology (NII),
India
*Correspondence:
Yang Zhang
zhangyang07@hit.edu.cn
Junyi Li
lijunyi@hit.edu.cn
Specialty section:
This article was submitted to
Systems Microbiology,
a section of the journal
Frontiers in Microbiology
Received: 11 July 2021
Accepted: 30 September 2021
Published: 28 October 2021
Citation:
Zhang Y, Ye T, Xi H, Juhas M and
Li J (2021) Deep Learning Driven Drug
Discovery: Tackling Severe Acute
Respiratory Syndrome Coronavirus 2.
Front. Microbiol. 12:739684.
doi: 10.3389/fmicb.2021.739684
Deep Learning Driven Drug
Discovery: Tackling Severe Acute
Respiratory Syndrome Coronavirus 2
Yang Zhang1*, Taoyu Ye1, Hui Xi1, Mario Juhas2 and Junyi Li3*
1 College of Science, Harbin Institute of Technology (Shenzhen), Shenzhen, China, 2 Medical and Molecular Microbiology
Unit, Department of Medicine, Faculty of Science and Medicine, University of Fribourg, Fribourg, Switzerland, 3 School
of Computer Science and Technology, Harbin Institute of Technology (Shenzhen), Shenzhen, China
Deep learning signiﬁcantly accelerates the drug discovery process, and contributes
to global efforts to stop the spread of infectious diseases. Besides enhancing the
efﬁciency of screening of antimicrobial compounds against a broad spectrum of
pathogens, deep learning has also the potential to efﬁciently and reliably identify drug
candidates against Severe Acute Respiratory Syndrome Coronavirus 2 (SARS-CoV-
2). Consequently, deep learning has been successfully used for the identiﬁcation of
a number of potential drugs against SARS-CoV-2, including Atazanavir, Remdesivir,
Kaletra, Enalaprilat, Venetoclax, Posaconazole, Daclatasvir, Ombitasvir, Toremifene,
Niclosamide, Dexamethasone, Indomethacin, Pralatrexate, Azithromycin, Palmatine,
and Sauchinone. This mini-review discusses recent advances and future perspectives
of deep learning-based SARS-CoV-2 drug discovery.
Keywords: deep learning, database, drug discovery, antibiotics, antimalarial drug, drug repurposing, SARS-CoV-2
INTRODUCTION
Deep learning is a branch of machine learning. It is an algorithm that abstracts data by using
multiple processing layers composed of complex structures or multiple non-linear transformations.
Compared with the shallow machine learning methods, deep learning algorithm is a process of
automatic feature engineering. Deep learning frameworks, such as convolutional neural network
and recursive neural network, have been applied in the ﬁelds of bioinformatics and biomedicine
and achieved excellent results (Lipinski et al., 2019). Deep learning methods have good applications
in microbiology including metagenomic data analysis, microbial-related drug discovery, disease
microbial association and so on (Duch et al., 2007). When analyzing microbial related data, it shows
high prediction accuracy in practice. Because deep learning algorithms are good at obtaining very
complex underlying patterns in data, they are especially suitable for large and high-dimensional
data sets. Moreover, it is easy to update the model with the new data. The hidden layer of the
network obviously reduces the demand for Feature Engineering and is conducive to the completion
of prediction tasks. The schematic diagram of the deep learning in drug discovery is shown in
Figure 1.
Deep learning has revolutionized most areas of science and technology, including drug
discovery. Traditional drug discovery methods are not time and cost eﬃcient and therefore often
unable to keep pace with the rapidly emerging and re-emerging pathogenic microorganisms.
More recent drug discovery methods include Naive Bayesian, Support Vector Machines and
Neural Networks (Bender et al., 2007; Stephenson et al., 2019). These alternative drug discovery
Frontiers in Microbiology | www.frontiersin.org
1
October 2021 | Volume 12 | Article 739684

## Page 2 (Section: Deep Learning Driven Drug Discovery: Tackling Severe Acute Respiratory Syndrome Coronavirus 2)

Zhang et al.
AI in Fighting Against SARS-CoV-2
FIGURE 1 | The schematic diagram of deep learning in drug discovery. Biochemical data from drug candidates and protein targets can be used for drug discovery.
Chemical sequences (simpliﬁed molecular-input line-entry system (SMILES) strings) and amino acid (AA) sequences, structure of chemical compounds and protein
targets can be used as the features to fed into the deep learning models. Different deep learning models can be employed to analyze the data by integrating Drug
Target Interaction (DTI) prediction, knowledge graph or structure based computational methods. Figure is made in part with BioRender.
methods usually use bigger data sets generated from high
throughput screenings and allow more accurate prediction of
bioactivities and molecular properties of the targets (Stephenson
et al., 2019). Compared to these alternative machine learning
methods used for drug discovery, deep learning is characterized
by the ﬂexibility of the architecture of Neural Networks (Chen
et al., 2018). Given the cost and time required for traditional
drug discovery, deep learning has the potential to signiﬁcantly
accelerate the drug discovery process. By using information
on the biological, chemical, and topological properties of
compounds and their putative targets from the large-scale
libraries, deep learning can be employed to identify the most
promising drugs against speciﬁc diseases (Neves et al., 2020;
Stokes et al., 2020). Various deep learning methods have been
developed over the last few years, but their application in drug
discovery has still not reached its full potential. One of the
main hurdles for researchers planning to build their own deep
learning model for drug identiﬁcation is the amount of resources
and time required to collect large amounts of data. A number
of computational screen open databases have been made to
prioritize drug candidates, recently. A representative set of open
access datasets which can be used to train deep learning models
for speciﬁc research projects is shown in Table 1.
The
outbreak
of
severe
acute
respiratory
syndrome
coronavirus
2
(SARS-CoV-2)
causing
coronavirus
disease
(COVID-19) has been declared a global pandemic. By September
2021, more than 220 million people have been infected with
SARS-CoV-2 and more than 4.5 million of those infected have
died. In addition, several SARS-CoV-2 variants with mutations
that increase their potential to contribute to the severity of the
pandemic have emerged and are spreading around the globe
(Zhang Y. et al., 2020).
Besides
non-structural
proteins,
SARS-CoV-2
genome
encodes four structural proteins: envelope (E), membrane (M),
nucleocapsid (N), and spike (S) (Zhang Y. et al., 2020). S protein
mediates entry of SARS-CoV-2 into the host cells by binding
and fusing with the host’s cellular receptor, the angiotensin-
converting enzyme 2 (ACE2). Mutations in S protein, particularly
in its receptor binding domain (RBD) were shown to play a role
in the increased transmissibility and infectivity of the emerging
SARS-CoV-2 variants (Zahradnik et al., 2021).
Although several SARS-CoV-2 vaccines have been developed
over the last few months, there are not many eﬃcient
and reliable drugs available for the treatment of SARS-CoV-
2 infections. This is caused partially by the fact that the
traditional drug discovery process may be time-consuming
and costly to keep pace with the rapid spread of SARS-CoV-
2 and its variants with increased transmissibility and other
enhanced features.
Deep
learning
has
been
previously
applied
for
the
identiﬁcation of a number of antiviral compounds, including
antiviral peptides (Timmons and Hewage, 2021) and small
drug-like compounds with the potential to inhibit HIV-1
(Andrianov et al., 2021).
Frontiers in Microbiology | www.frontiersin.org
2
October 2021 | Volume 12 | Article 739684

## Page 3 (Section: Antimicrobial Drugs Identified by Deep Learning)

Zhang et al.
AI in Fighting Against SARS-CoV-2
The
computational
approaches
employing
deep
learning will aid also faster discovery of novel and active
potential
inhibition
agents
against
SARS-CoV-2
and
its
emerging variants.
High-throughput technologies have generated an increasing
amount of data in chemoinformatics. As a result, it is believed
that the application of the recent deep learning advances into
the drug discovery process will lead to novel, more reliable and
eﬃcient therapeutics against SARS-CoV-2.
ANTIMICROBIAL DRUGS IDENTIFIED BY
DEEP LEARNING
Deep learning can reduce time and costs of the drug discovery
process, particularly in its early stages. Consequently, deep
learning-based approaches have been successfully used to
identify novel antimicrobial compounds against a wide variety
of pathogenic microorganisms, including bacteria, protozoan
parasites and viruses.
Training of the deep learning model to identify molecules
active against antibiotic-resistant bacteria led to the discovery
of Halicin and eight additional potential antibiotics from the
ZINC database (Table 1; Stokes et al., 2020). Interestingly,
these compounds identiﬁed by deep learning are all structurally
divergent from conventional antibiotics (Stokes et al., 2020).
Subsequent tests revealed strong antibacterial activity of Halicin
against a number of antibiotic-resistant bacteria, including
Carbapenemase-producing
Enterobacterales,
Mycobacterium
tuberculosis, Acinetobacter baumannii, and Clostridioides diﬃcile
(Stokes et al., 2020).
In
parasite
research,
deep
learning
has
been
applied
to predict new antimalarial drug candidates. Neves et al.
(2020) employed deep learning to obtain binary, continuous
Quantitative Structure-Activity Relationships (QSAR) models
using datasets extracted from ChEMBL database (Table 1).
QSAR mathematical models can predict the relationship
between the structure of a molecule and biological activity or
physicochemical property. This study led to the discovery of
two new families of the potential next generation antimalarial
drugs with activity against Plasmodium causing malaria at
nanomolar concentrations and low cytotoxicity in mammalian
cells (Neves et al., 2020).
Deep learning has been also applied for the identiﬁcation
of a number of antiviral compounds. Timmons and Hewage
developed a novel method called ENNAVIA, which employs deep
learning and chemoinformatics, to identify peptides with low
toxicity and excellent biological activity. The peptides identiﬁed
in this study represent promising candidates for antiviral drugs
(Timmons and Hewage, 2021). Furthermore, deep learning in
combination with molecular modeling has been applied for
the identiﬁcation of three small drug-like compounds from
millions of molecules in the ZINC15 database (Andrianov et al.,
2021). Based on machine learning, molecular docking, molecular
dynamics and quantum chemical calculations, the compounds
identiﬁed in this study are promising HIV-1 drugs with the
potential to block CD4-binding site of the viral envelope protein,
TABLE 1 | Representative biochemical datasets used in deep learning studies.
Dataset
Description
URL
References
ZINC
ZINC database
contains over 230
million compounds.
http://zinc.docking.org/
Bai et al.,
2020; Choi
et al., 2020;
Stokes et al.,
2020; Ton
et al., 2020
ChEMBL
ChEMBL (version 27)
chemical database
contains over 1.9
million speciﬁc
compounds.
https://www.ebi.ac.uk/
chembl/
Stokes et al.,
2020
Drug target
commons
(DTC)
DTC crowdsourcing
database contains
204,901 annotated
bioactivity data points
among 4,276
compounds and 1,007
speciﬁc protein targets.
https:
//drugtargetcommons.
ﬁmm.ﬁ/
Beck et al.,
2020
BindingDB
BindingDB database of
measured binding
afﬁnities contains
2,061,017 binding data
for 8,160 protein
targets and 907,259
small molecules.
http://www.bindingdb.
org/bind/index.jsp
Beck et al.,
2020
DrugBank
DrugBank
pharmaceutical
database contains
detailed molecular
information about
drugs, their
mechanisms,
interactions and
targets.
https://go.drugbank.
com/releases/latest
Choi et al.,
2020; Zeng
et al., 2020
PDBbind
PDBbind database
provides binding data
of 21,382 biomolecular
complexes, including
protein-ligand (17,679),
nucleic acid-ligand
(136), protein-nucleic
acid (973), and
protein-protein
complexes (2,594).
http:
//www.pdbbind.org.cn
Bai et al.,
2020
thus inhibiting HIV-1 entry (Andrianov et al., 2021). Li et al. have
developed a dual-channel deep neural network for identifying
variable-length antiviral peptides (DeepAVP) which could block
entry of the virus into the host cell (Li et al., 2020). Deep learning
has been also used for the prediction of plant-exclusive virus-
derived small interfering RNAs (PVsiRNAPred) (He et al., 2019).
DEEP LEARNING IN TACKLING SEVERE
ACUTE RESPIRATORY SYNDROME
CORONAVIRUS 2
Reliable and eﬃcient computing methods employing deep
learning are urgently needed for the discovery of drugs against
SARS-CoV-2 and its emerging variants.
Frontiers in Microbiology | www.frontiersin.org
3
October 2021 | Volume 12 | Article 739684

## Page 4 (Section: Antimicrobial Drugs Identified by Deep Learning)

Zhang et al.
AI in Fighting Against SARS-CoV-2
Drug repurposing is considered to be among the fastest and
most promising methods for identiﬁcation of eﬀective SARS-
CoV-2 treatments. A good example of the drug repurposing
involving deep learning is a recent work by Zhang Y. et al.
(2020). This study employed a deep learning-based drug-target
interaction model called Molecule Transformer-Drug Target
Interaction (MT-DTI) utilizing chemical sequences [simpliﬁed
molecular-input line-entry system (SMILES) strings] and amino
acid (AA) sequences as the input (Figure 1). MT-DTI model
was trained with a combined and curated chemical-protein pairs
from BindingDB and Drug Target Commons (DTC) databases
(Table 1). This study led to identiﬁcation of several commercially
available antiviral drugs with the potential to interact also
with the SARS-CoV-2 proteins (Beck et al., 2020). Subsequent
experiments showed that several of the antiviral agents identiﬁed
by MT-DTI model could be potentially used to treat SARS-CoV-
2 (Beck et al., 2020). These include Atazanavir (Kd 94.94 nM),
Remdesivir (Kd 113.13 nM), and Kaletra (Lopinavir/Ritonavir)
(Table 2). Atazanavir, showing an inhibitory potency against
SARS-CoV-2 3-C like proteinase is an antiviral drug used for
the treatment of the human immunodeﬁciency virus (HIV)
infections. Remdesivir has been previously predicted to act
against SARS-CoV-2. Furthermore, Lopinavir and Ritonavir
were shown to target viral proteinases (Beck et al., 2020). The
BindingDB is a public database containing measured binding
aﬃnities for three types of coronaviruses, SARS-CoV-2, SARS-
CoV and MERS-CoV.1
MT-DTI model was also used to select compounds from 1,400
approved drugs in DrugBank and ZINC databases (Table 1) with
strong aﬃnity to the host cell targets crucial for viral infection
(Zahradnik et al., 2021). This approach led to identiﬁcation of
drugs candidates with a strong binding aﬃnity (Kd < 100 nM)
against ACE2 receptor and transmembrane protease serine 2
(TMPRSS2) (Zahradnik et al., 2021). Drug candidates identiﬁed
in this study include an ACE2 inhibitor Enalaprilat (Kd 1.46 nM)
and several drugs with predicted strong aﬃnity for TMPRSS2,
namely Venetoclax (Kd 6.12 nM), Posaconazole (Kd 17.11
nM), Daclatasvir (Kd 6.65 nM), and Ombitasvir (Kd 5.91 nM)
(Table 2). Strong aﬃnity of Enalaprilat for ACE2 suggests that it
might prevent the entry of SARS-CoV-2 to human cells. Notably,
two of the drug candidates identiﬁed, namely Daclatasvir and
Ombitasvir, are known Hepatitis C virus (HCV) inhibitors, thus
suggesting that they may act against both HCV and SARS-CoV-
2 (Zahradnik et al., 2021). The DrugBank has collected data for
65 drugs against 385 drug targets, which is web accessible at
https://go.drugbank.com/covid-19.
Zeng et al. used deep learning-based knowledge graph to select
promising SARS−CoV−2 drug candidates (Zeng et al., 2020).
Knowledge graph in this study encompasses 15 million edges
across 39 types of relationships connecting expression patterns,
genes, pathways, drugs and diseases and incorporates data from
over 20 million PubMed articles and the DrugBank database
(Table 1). Deep learning employed to learn the representation
of nodes and relationships in this knowledge graph led
to identiﬁcation of 41 promising drug candidates, including
1https://www.bindingdb.org/bind/Covid19.jsp
Toremifene, Niclosamide, Dexamethasone and Indomethacin
(Table 2; Beck et al., 2020). Toremifene is a selective estrogen
receptor modulator, which has shown antiviral activity against
a number of viruses, including SARS-CoV-2. Dexamethasone is
an anti-inﬂammatory agent with the potential to treat SARS-
CoV-2 infections (Beck et al., 2020). Niclosamide, a drug used
to treat tapeworm and an anti-inﬂammatory drug Indomethacin
were also shown to have antiviral activity in vitro. The 41
promising drug candidates identiﬁed in this study (including
Toremifene, Niclosamide, Dexamethasone and Indomethacin)
were also validated by gene expression and proteomics of cells
infected with SARS-CoV-2 (Beck et al., 2020).
A hybrid deep learning and molecular simulation-based
screening procedure was used to select drug candidates targeting
RNA-dependent RNA polymerase (RdRp) from 1906 approved
drugs, recently (Choi et al., 2020). Commercially available drug
candidates, Pralatrexate and Azithromycin, (Table 2) identiﬁed
in this study were conﬁrmed to inhibit SARS-CoV-2 replication
in vitro (Choi et al., 2020). While Pralatrexate was shown to act
after entry of the virus into the cells, Azithromycin was active at
both the entry and post-entry of SARS-CoV-2 into the host cells
(Choi et al., 2020).
Bai et al. developed MolAICal software tool combining deep
learning model and classical algorithm for identiﬁcation of drugs
interacting with 3D pocket of protein targets (Bai et al., 2020).
Deep learning model of MolAICal software was trained using
approved drug fragments in PDBbind database and drug-like
molecules in the ZINC database (Table 1). Drug design functions
of MolAICal software were demonstrated using the membrane
protein glucagon receptor (GCGR) and SARS−CoV−2 main
protease (Mpro) (Zeng et al., 2020).
Ton et al. (2020) developed a Deep Docking (DD) deep
learning platform which uses QSAR models for screening of
potential drug candidates in the ZINC database (Table 1). This
approach led to the identiﬁcation of 1,000 potential ligands for
SARS−CoV−2 Mpro (Ton et al., 2020).
Deep
learning
and
molecular
docking
methods
were
developed for screening of natural compounds against SARS-
CoV-2 Mpro in the ChEMBL database (Table 1; Bai et al., 2020).
ChEMBL database is an open large-scale chemical database
of bioactive molecules, containing 8,200 potential anti-SARS-
CoV-2 drug candidates. This study led to the identiﬁcation of
two natural compounds with potential as therapeutics against
SARS-CoV-2, namely Palmatine (Kd 1096.4 nM) and Sauchinone
(Table 2) (Kd 389.05 nM). Palmatine and Sauchinone are an
alkaloid and a lignan, respectively, with previously shown
pharmacological properties. Furthermore, both Palmatine and
Sauchinone form a stable complex with SARS-CoV-2 Mpro and
have been predicted to inhibit SARS-CoV-2 (Bai et al., 2020).
Deep learning combined with multiple sequence alignment
drug-likeness screening, molecular docking, chemical space
mapping and molecular dynamics simulation was also used
to identify drug candidates by screening 1528 anti-HIV-
1 compounds against 3-chymotrypsin-like cysteine protease
(3CLpro) of SARS-CoV-2 (Nand et al., 2020).
Given the lack of therapeutics against SARS-CoV-2, deep
learning
approaches
combined
with
other
computational
Frontiers in Microbiology | www.frontiersin.org
4
October 2021 | Volume 12 | Article 739684

## Page 5 (Section: Antimicrobial Drugs Identified by Deep Learning)

Zhang et al.
AI in Fighting Against SARS-CoV-2
TABLE 2 | Drug candidates against SARS-CoV-2.
Drug
Molecular
formula
Structural
formula
SMILES
Target
References
Atazanavir
C38H52N6O7
COC(N[C@@H](C(C)(C)C)C(NN
(C[C@H](O)[C@H](CC1 = CC =
CC = C1)NC([C@H](C(C)(C)C)NC
(OC) = O) = O)CC(C = C2) = CC =
C2C3 = NC = CC = C3) = O) = O
3C-like
proteinase
Beck et al.,
2020
Remdesivir
C27H35N6O8P
CP = O.COC1 = CC = CC = C1.O
= C(OCC(CC)CC)[C@H](C)NC.NC2
= NC = NN3C2 = CC = C3[C@@]4
(C#N)[C@H](C)[C@H](C)[C@@H]
(C[O])O4.[OH].[OH]
3C-like
proteinase
Beck et al.,
2020
Kaletra
(Lopinavir/Ritonavir)
C74H96N10O10S2
(C37H48N4O5/C37
H48N6O5S2)
CC1 = CC = CC(C) = C1OCC(N
[C@@H](CC2 = CC = CC = C2)
[C@@H](O)C[C@H](CC3 = CC
= CC = C3)NC([C@H](C(C)C)
N4C(NCCC4) = O) = O) = O
Helicase
Beck et al.,
2020
CC(C)C1 = NC(CN(C)C(N[C@@H]
(C(C)C)C(N[C@@H](CC2 = CC
= CC = C2)C[C@H](O)[C@H](CC3
= CC = CC = C3)NC(OCC4 = CN
= CS4) = O) = O) = O) = CS1
Enalaprilat
C18H24N2O5
OC([C@H]1N(C([C@H](C)N
[C@H](C(O) = O)CCC2 = CC
= CC = C2) = O)CCC1) = O
ACE2
Choi et al.,
2020
Venetoclax
C45H50ClN7O7S
ClC1 = CC = C(C2 = C(CN3CC
N(C4 = CC = C(C(NS(C5 = CC =
C(NCC6CCOCC6)C([N + ]([O-
]) = O) = C5)(= O) = O) = O)C(OC
7 = CC(C = CN8) = C8N = C7) =
C4)CC3)CCC(C)(C)C2)C = C1
TMPRSS2
ACE2
Choi et al.,
2020
Posaconazole
C37H42F2N8O4
FC1 = CC(F) = CC = C1[C@@]2
(CN3N = CN = C3)C[C@H](COC
4 = CC = C(N5CCN(C6 = CC = C(N
7C = NN([C@@H](CC)[C@@H](O)
C)C7 = O)C = C6)CC5)C = C4)CO2
TMPRSS2
ACE2
Choi et al.,
2020
Daclatasvir
C40H50N8O6
COC(N[C@@H](C(C)C)C(N1[C@H]
(C2 = NC = C(C3 = CC = C(C4 = C
C = C(C5 = CN = C([C@H]6N(C([C@
@H](NC(OC) = O)C(C)C) = O)CCC6)N
5)C = C4)C = C3)N2)CCC1) = O) = O
TMPRSS2
ACE2
Choi et al.,
2020
Ombitasvir
C50H67N7O8
CC(C)(C)C(C = C1) = CC = C1N([C@
H](C2 = CC = C(NC([C@@H]3CCCN
3C([C@H](C(C)C)NC(OC) = O) = O)
= O)C = C2)CC4)[C@@H]4C5 = CC
= C(NC([C@H]6N(C([C@@H](NC(O
C) = O)C(C)C) = O)CCC6) = O)C = C5
TMPRSS2
ACE2
Choi et al.,
2020
Toremifene
C26H28ClNO
CN(C)CCOC1 = CC = C(/C(C2
= CC = CC = C2) = C(C3 = C
C = CC = C3)/CCCl)C = C1
–
Zeng et al.,
2020
(Continued)
Frontiers in Microbiology | www.frontiersin.org
5
October 2021 | Volume 12 | Article 739684

## Page 6 (Section: Discussion)

Zhang et al.
AI in Fighting Against SARS-CoV-2
TABLE 2 | (Continued)
Drug
Molecular formula
Structural
formula
SMILES
Target
References
Niclosamide
C13H8Cl2N2O4
ClC1 = CC = C(O)C(C(NC2
= CC = C([N + ]([O-]) = O)C
= C2Cl) = O) = C1
–
Zeng et al.,
2020
Dexamethasone
C22H29FO5
O = C1C = C[C@@]2(C)C(CC[C@]
([C@@](C[C@@H](C)[C@]3(O)C(C
O) = O)([H])[C@]3(C)C[C@@H]4O)
([H])[C@@]24F) = C1
–
Zeng et al.,
2020
Indomethacin
C19H16ClNO4
COC1 = CC = C(N(C(C2 = CC
= C(Cl)C = C2) = O)C(C) = C3
CC(O) = O)C3 = C1
–
Zeng et al.,
2020
Pralatrexate
C23H23N7O5
NC1 = C2C(N = CC(CC(C3 =
CC = C(C(N[C@H](C(O) = O)
CCC(O) = O) = O)C = C3)
CC#C) = N2) = NC(N) = N1
RdRp
Zhang H. et al.,
2020
Azithromycin
C38H72N2O12
CN([C@H](C)[C@@H](O)C(C)(O)[C
@@H](CC)O1)C[C@H](C)C[C@@]
(O[C@H]2[C@H](O)[C@@H](N(C)C)
C[C@@H](C)O2)(O)C[C@@H](C)[C
@H](O[C@H]3O[C@@H](C)[C@H](O
)[C@](C)(OC)C3)[C@@H](C)C1 = O
RdRp
Zhang H. et al.,
2020
Palmatine
C21H22NO4+
COC1 = C(OC)C(C = [N + ]
(CCC2 = C3C = C(OC)C(OC)
= C2)C3 = C4) = C4C = C1
Mpro enzyme
of SARS-CoV-2
Joshi et al.,
2020
Sauchinone
C20H20O6
O = C1C = C2[C@]3(OCO2)[C@
@]4([H])[C@@]1([H])C[C@@H](C)
[C@H](C)[C@@]4([H])C5 = CC
(OCO6) = C6C = C5O3
Mpro enzyme
of SARS-CoV-2
Joshi et al.,
2020
Table shows molecular and structural formulas, simpliﬁed molecular-input line-entry system (SMILES) strings and corresponding targets of the potential drugs against
SARS−CoV−2.
methods will play an important role in the identiﬁcation
of
potential
drugs
targeting
SARS-CoV-2.
Compounds
selected by deep learning will subsequently undergo standard
clinical evaluation.
DISCUSSION
Deep learning has a number of advantages compared to more
conventional methods, including its ability to learn complex
features independently. Although deep learning has played an
important role in the identiﬁcation of novel drugs against
a wide range of pathogens, including SARS-CoV-2, many
challenges still remain.
The connection between the data fed into the deep learning
model and the delivered output is inscrutable, which hidden
inside is a so-called black box. Deep neural network due to its
black-box nature therefore often lacks interpretability. Therefore,
the interpretability of the future neural networks on the output
results will be a key factor in understanding the logic of machine.
This will aid analysis of the chemical compounds identiﬁed by
deep learning and better design of the drug discovery studies.
Furthermore,
the
input
data
aﬀects
the
prediction
performance of the deep learning model. Consequently, a large,
Frontiers in Microbiology | www.frontiersin.org
6
October 2021 | Volume 12 | Article 739684

## Page 7 (Section: Author Contributions)

Zhang et al.
AI in Fighting Against SARS-CoV-2
standardized and reliable biochemical dataset is necessary to
achieve better learning of the deep learning model. Development
of a large open dataset in the future will enable potential
standardization of the deep learning-based drug discovery.
Antibody-based therapy represents an interesting SARS-CoV-
2 treatment option. Deep learning models have been developed
for the discovery and design of therapeutic antibodies (Mason
et al., 2021; Saka et al., 2021). Thus, drug repositioning and
screening from computational libraries containing a massively
diverse antibody sequences could be used to engineer anti-viral
SARS-CoV-2 treatment.
Furthermore, most recent studies describe methodologies
separately and test them individually. Application of deep
learning to combine chemoinformatics with other types of
data, such as imaging, cellular and molecular biology data for
integrative analysis would be an important direction for future
research. To this end, it might be necessary to identify the best
neural network architecture for handling those vast troves of data.
We believe that integrative and systematic analysis will be
important for future deep learning-based drug discovery that
involves complicated large biological, chemical and clinical
datasets. Using such large datasets to streamline and accelerate
drug discovery, deep learning will be crucial not only for
the identiﬁcation of drug candidates against SARS-CoV-2
but also against a broad spectrum of other emerging and
reemerging pathogens.
AUTHOR CONTRIBUTIONS
All
authors
contribute
to
the
writing
and
reviewing
the manuscript.
FUNDING
This work was supported by the Natural Science Foundation of
Shenzhen City (Project No. JCYJ20180306172131515) and the
Shenzhen Science and Technology Program the university stable
support program (20200821222112001).
REFERENCES
Andrianov, A. M., Nikolaev, G. I., Shuldov, N. A., Bosko, I. P., Anischenko,
A. I., and Tuzikov, A. V. (2021). Application of deep learning and molecular
modeling to identify small drug-like compounds as potential HIV-1 entry
inhibitors. J. Biomol. Struct. Dyn. 15, 1–19. doi: 10.1080/07391102.2021.
1905559
Bai, Q., Tan, S., Xu, T., Liu, H., Huang, J., and Yao, X. (2020). MolAICal:
a soft tool for 3D drug design of protein targets by artiﬁcial intelligence
and classical algorithm. Brief Bioinform. 11:bbaa161. doi: 10.1093/bib/bb
aa161
Beck, B. R., Shin, B., Choi, Y., Park, S., and Kang, K. (2020). Predicting
commercially
available
antiviral
drugs
that
may
act
on
the
novel
coronavirus (SARS-CoV-2) through a drug-target interaction deep learning
model.
Comput.
Struct.
Biotec.
18,
784–790.
doi:
10.1016/j.csbj.2020.
03.025
Bender, A., Scheiber, J., Glick, M., Davies, J. W., Azzaoui, K., Hamon, J., et al.
(2007). Analysis of pharmacology data and the prediction of adverse drug
reactions and oﬀ-target eﬀects from chemical structure. ChemMedChem 2,
861–873. doi: 10.1002/cmdc.200700026
Chen, H., Engkvist, O., Wang, Y., Olivecrona, M., and Blaschke, T. (2018). The
rise of deep learning in drug discovery. Drug Discov. Today 23, 1241–1250.
doi: 10.1016/j.drudis.2018.01.039
Choi, Y., Shin, B., Kang, K., Park, S., and Beck, B. R. (2020). Target-centered
drug repurposing predictions of Human Angiotensin-Converting Enzyme 2
(ACE2) and Transmembrane Protease Serine Subtype 2 (TMPRSS2) interacting
approved drugs for Coronavirus disease 2019 (COVID-19) treatment through
a drug-target interaction deep learning model. Viruses 12:1325. doi: 10.3390/
v12111325
Duch, W., Swaminathan, K., and Meller, M. (2007). Artiﬁcial intelligence
approaches for rational drug design and discovery. Curr. Pharm. Des. 13,
1497–1508. doi: 10.2174/138161207780765954
He, B., Huang, J., and Chen, H. (2019). PVsiRNAPred: Prediction of plant
exclusive virus-derived small interfering RNAs by deep convolutional neural
network. J. Bioinform. Comput. Biol. 17:1950039. doi: 10.1142/S02197200195
00392
Joshi, T., Joshi, T., Pundir, H., Sharma, P., Mathpal, S., and Chandra,
S. (2020). Predictive modeling by deep learning, virtual screening and
molecular dynamics study of natural compounds against SARS-CoV-2 main
protease. J. Biomol. Struct. Dyn. 5, 1–19. doi: 10.1080/07391102.2020.18
02341
Li, J., Pu, Y., Tang, J., Zou, Q., and Guo, F. (2020). DeepAVP: A dual-
channel deep neural network for identifying variable-length antiviral peptides.
IEEE J. Biomed. Health Inform. 24, 3012–3019. doi: 10.1109/JBHI.2020.2
977091
Lipinski, C. F., Maltarollo, V. G., Oliveira, P. R., daSilva, A. B. F., and Honorio,
K. M. (2019). Advances and Perspectives in applying deep learning for
drug design and discovery. Front. Robot. 6:108. doi: 10.3389/frobt.2019.0
0108
Mason, D. M., Friedensohn, S., Weber, C. R., Jordi, C., Wagner, B., Meng, S., et al.
(2021). Optimization of therapeutic antibodies by predicting antigen speciﬁcity
from antibody sequence via deep learning. Nat. Biomed. Eng. 5, 600–612. doi:
10.1038/s41551-021-00699-9
Nand, M., Maiti, P., Joshi, T., and Chandra, S. (2020). A Ramakrishnan
Virtual
screening
of
anti-HIV1
compounds
against
SARS-CoV-2:
machine learning modeling, chemoinformatics and molecular dynamics
simulation based analysis. Sci. Rep. 10:20397. doi: 10.1038/s41598-020-7
7524-x
Neves, B. J., Braga, R. C., Alves, V. M., Lima, M. N. N., Cassiano, G. C.,
Muratov, E., et al. (2020). Deep Learning-driven research for drug discovery:
Tackling Malaria. PLoS Comput. Biol. 16:e1007025. doi: 10.1371/journal.pcbi.10
07025
Saka, K., Kakuzaki, T., Metsugi, S., Kashiwagi, D., Yoshida, K., Wada, M., et al.
(2021). Antibody design using LSTM based deep generative model from phage
display library for aﬃnity maturation. Sci. Rep. 11:5852. doi: 10.1038/s41598-
021-85274-7
Stephenson, N., Shane, E., Chase, J., Rowland, J., Ries, D., Justice, N.,
et al. (2019). Survey of machine learning techniques in drug discovery.
Curr.
Drug
Metab.
20,
185–193.
doi:
10.2174/138920021966618082
0112457
Stokes,
J.
M.,
Yang,
K.,
Swanson,
K.,
Jin,
W.
G.,
Cubillos-Ruiz,
A.,
Donghia,
N.
M.,
et
al.
(2020).
A
deep
learning
approach
to
antibiotic
discovery.
Cell
180,
688–702.
doi:
10.1016/j.cell.2020
.01.021
Timmons, P. B., and Hewage, C. M. (2021). ENNAVIA is a novel method which
employs neural networks for antiviral and anti-coronavirus activity prediction
for therapeutic peptides. Brief Bioinform. 2021:bbab258. doi: 10.1093/bib/
bbab258
Ton, A. T., Gentile, F., Hsing, M., Ban, F., and Cherkasov, A. (2020). Rapid
identiﬁcation of potential inhibitors of SARS−CoV−2 main protease by deep
docking of 1.3 billion compounds. Mol. Inform. 8:e2000028. doi: 10.1002/minf.
202000028
Frontiers in Microbiology | www.frontiersin.org
7
October 2021 | Volume 12 | Article 739684

## Page 8 (Section: Author Contributions)

Zhang et al.
AI in Fighting Against SARS-CoV-2
Zahradnik, J., Marciano, S., Shemesh, M., Zoler, E., Harari, D., Chiaravalli, J., et al.
(2021). SARS-CoV-2 variant prediction and antiviral drug design are enabled
by RBD in vitro evolution. Nat. Microbiol. 6, 1188–1198. doi: 10.1038/s41564-
021-00954-4
Zeng, X., Song, X., Ma, T., Pan, X., Zhou, Y., Hou, Y., et al. (2020).
Repurpose open data to discover therapeutics for COVID-19 using deep
learning. J. Proteome. Res. 19, 4624–4636. doi: 10.1021/acs.jproteome.0
c00316
Zhang, H., Yang, Y., Li, J., Wang, M., Saravanan, K. M., Wei, J., et al.
(2020).
A
novel
virtual
screening
procedure
identiﬁes
Pralatrexate
as
inhibitor
of
SARS-CoV-2
RdRp
and
it
reduces
viral
replication
in
vitro.
PLoS
Comput.
Biol.
16:e1008489.
doi:
10.1371/journal.pcbi.1
008489
Zhang, Y., Xi, H., and Juhas, M. (2020). Biosensing detection of the SARS-
CoV-2 D614G mutation. Trends Genet. 37, 299–302. doi: 10.1016/j.tig.2020.1
2.004
Conﬂict of Interest: The authors declare that the research was conducted in the
absence of any commercial or ﬁnancial relationships that could be construed as a
potential conﬂict of interest.
Publisher’s Note: All claims expressed in this article are solely those of the authors
and do not necessarily represent those of their aﬃliated organizations, or those of
the publisher, the editors and the reviewers. Any product that may be evaluated in
this article, or claim that may be made by its manufacturer, is not guaranteed or
endorsed by the publisher.
Copyright © 2021 Zhang, Ye, Xi, Juhas and Li. This is an open-access article
distributed under the terms of the Creative Commons Attribution License (CC BY).
The use, distribution or reproduction in other forums is permitted, provided the
original author(s) and the copyright owner(s) are credited and that the original
publication in this journal is cited, in accordance with accepted academic practice. No
use, distribution or reproduction is permitted which does not comply with these terms.
Frontiers in Microbiology | www.frontiersin.org
8
October 2021 | Volume 12 | Article 739684


---

# Development and validation of a weakly supervised deep learning framework to predict the status of molecular pathways and key mutations in colorectal cancer from routine histology images: a retrospective study

- **Authors:** Mohsin Bilal, Shan E Ahmed Raza, Ayesha Azam, Simon Graham, Mohammad Ilyas, Ian A Cree, David Snead, Fayyaz Minhas, Nasir M Rajpoot
- **Issuer:** The Lancet. Digital health
- **Type:** Scientific article
- **Published:** 2021-10-19
- **Language:** en
- **DOI:** 10.1016/s2589-7500(21)00180-1
- **Source:** https://pubmed.ncbi.nlm.nih.gov/34686474/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

SummaryBackgroundDetermining the status of molecular pathways and key mutations in colorectal cancer is crucial for optimal therapeutic decision making. We therefore aimed to develop a novel deep learning pipeline to predict the status of key molecular pathways and mutations from whole-slide images of haematoxylin and eosin-stained colorectal cancer slides as an alternative to current tests.MethodsIn this retrospective study, we used 502 diagnostic slides of primary colorectal tumours from 499 patients in The Cancer Genome Atlas colon and rectal cancer (TCGA-CRC-DX) cohort and developed a weakly supervised deep learning framework involving three separate convolutional neural network models. Whole-slide images were divided into equally sized tiles and model 1 (ResNet18) extracted tumour tiles from non-tumour tiles. These tumour tiles were inputted into model 2 (adapted ResNet34), trained by iterative draw and rank sampling to calculate a prediction score for each tile that represented the likelihood of a tile belonging to the molecular labels of high mutation density (vs low mutation density), microsatellite instability (vs microsatellite stability), chromosomal instability (vs genomic stability), CpG island methylator phenotype (CIMP)-high (vs CIMP-low), BRAFmut (vs BRAFWT), TP53mut (vs TP53WT), and KRASWT (vs KRASmut). These scores were used to identify the top-ranked titles from each slide, and model 3 (HoVer-Net) segmented and classified the different types of cell nuclei in these tiles. We calculated the area under the convex hull of the receiver operating characteristic curve (AUROC) as a model performance measure and compared our results with those of previously published methods.FindingsOur iterative draw and rank sampling method yielded mean AUROCs for the prediction of hypermutation (0·81 [SD 0·03] vs 0·71), microsatellite instability (0·86 [0·04] vs 0·74), chromosomal instability (0·83 [0·02] vs 0·73), BRAFmut (0·79 [0·01] vs 0·66), and TP53mut (0·73 [0·02] vs 0·64) in the TCGA-CRC-DX cohort that were higher than those from previously published methods, and an AUROC for KRASmut that was similar to previously reported methods (0·60 [SD 0·04] vs 0·60). Mean AUROC for predicting CIMP-high status was 0·79 (SD 0·05). We found high proportions of tumour-infiltrating lymphocytes and necrotic tumour cells to be associated with microsatellite instability, and high proportions of tumour-infiltrating lymphocytes and a low proportion of necrotic tumour cells to be associated with hypermutation.InterpretationAfter large-scale validation, our proposed algorithm for predicting clinically important mutations and molecular pathways, such as microsatellite instability, in colorectal cancer could be used to stratify patients for targeted therapies with potentially lower costs and quicker turnaround times than sequencing-based or immunohistochemistry-based approaches.FundingThe UK Medical Research Council.

## Section: Introduction

Differing molecular pathways of colorectal cancer carcinogenesis can help to explain diversity in disease progression and tumour growth among patients.1 Chromosomal instability is associated with lower rates of overall and progression-free survival in colorectal cancer,2 whereas tumours with microsatellite instability or hypermutation are more likely to respond to immunotherapy.3, 4, 5, 6 Further classifications consider different subgroups of CpG island methylator phenotypes (CIMPs) and microsatellite instability1, 6, 7 based on responses to adjuvant therapy and survival. Increasing numbers of studies have subtyped colorectal cancer on the basis of shared and distinct molecular characteristics and pathways1, 8 and determined the association of these pathways with patient prognosis, overall survival, and response to specific treatments—particularly targeted therapy and immunotherapy.3, 9, 10

Research in context Evidence before this study We queried Google Scholar without language restrictions and with the search terms “(Predicting OR assessing) and (((msi OR dMMR) status) OR (tumor mutation burden OR TMB)) in (colorectal cancer) AND (Machine OR Deep) Learning OR (Artificial Intelligence OR AI)”, and analysed the top 50 scientific articles published between Jan 1, 2018, and Dec 20, 2020, to examine evidence before undertaking this study. Studies have shown that deep learning can predict the presence of microsatellite instability and genetic driver mutations directly from whole-slide images of haematoxylin and eosin-stained slides of colorectal cancer and other cancer types. However, previous methods using a standard deep learning model and equal weighting of all tiles for these predictions performed only modestly, especially in The Cancer Genome Atlas colon and rectal cancer (TCGA-CRC-DX) multicentre cohort. In addition, existing models have not assessed the cellular composition of histological regions that contribute to the final prediction. Added value of this study Considering tissue heterogeneity, we hypothesised that all image tiles containing tissue contents in a whole-slide image are not equally predictive of the status of molecular pathways and key mutations. Therefore, in this retrospective study, we proposed a new, weakly supervised deep learning algorithm for whole-slide image classification based on non-annotated images and using only slide-level labels to predict the status of colorectal cancer pathways and mutations. We also cross-validated the microsatellite instability prediction in a completely unseen cohort. The histological contents of strongly predictive tiles were systematically analysed in a data-driven manner. Our iterative draw and rank sampling method outperformed previously published methods in the prediction of hypermutation, microsatellite instability, chromosomal instability, and BRAF and TP53 mutation status in the TCGA-CRC-DX cohort. Implications of all the available evidence After large-scale validation in multicentre cohorts, our prediction algorithm could be used to stratify patients for targeted therapies, with potentially lower costs and quicker turnaround times than with current approaches. Indeed, the prediction of slide labels and their spatial mapping to the tissue microenvironment has the potential to improve diagnostic practice and personalised treatment for several different types of cancer. Automated analysis of the cellular composition of predictive histological features could improve our understanding of the downstream impact of these features and lead to new insights into representative and discriminative morphological features corresponding to molecular pathways and mutations for cancer.

However, standard genetic (eg, PCR) and immunohistochemistry testing might incur time delays and additional costs,3, 4 and molecular testing assays (eg, diagnostic biopsies) often require tissue, the availability of which can be limited.11 As such, visual examination of haematoxylin and eosin-stained tissue slides remains the gold standard for diagnosis of colorectal cancer. With the uptake and validation of digital pathology for routine diagnosis,12 multi-gigapixel whole-slide images can be generated and interrogated to yield information beyond a simple diagnosis.

In histopathology, deep learning-based algorithms have been shown to predict clinically relevant molecular phenotypes,13 microsatellite instability,4, 14, 15 consensus molecular subtypes,4, 16 and outcomes17 in colorectal cancer. Indeed, Kather and colleagues4 developed a standard deep learning model using equal weighting of all tiles to stratify microsatellite instable and microsatellite stable colorectal cancer and achieved an area under the convex hull of the receiver operating characteristic curve (AUROC) of 0·77 (95% CI 0·62–0·87) on a test split of The Cancer Genome Atlas colon and rectal cancer (TCGA-CRC-DX) cohort. Kather and colleagues18 then extended this previously proposed computational pipeline4 to detect clinically actionable genetic alterations from haematoxylin and eosin-stained slides of multiple solid tumours. Echle and colleagues11 evaluated the use of deep learning models for the detection of microsatellite instability and mismatch repair deficiency on haematoxylin and eosin-stained slides from colorectal tumours, which showed a strong performance in intra-cohort validation in three large international training sets and the TCGA-CRC-DX cohort (n=426). The performance of these models in intra-cohort and inter-cohort validation11 in the TCGA-CRC-DX cohort matched, but did not improve upon, the state-of-the-art performance of the previous microsatellite instability prediction method developed by Kather and colleagues.4

The labelling of a digitised whole-slide image as positive or negative for a specific genetic mutation or molecular pathway without detailed annotations at the cellular and regional levels would be considered weakly supervised learning in the language of machine learning. Weakly supervised learning of slide-level labels for whole-slide images and the detection of clinically actionable genetic alterations from the analysis of haematoxylin and eosin-stained whole-slide images have been shown to be possible with deep learning.4, 11, 18 However, two fundamental questions remain unanswered. First, can deep learning be used to predict the status of molecular pathways and relevant genetic mutations from images of haematoxylin and eosin-stained sections of colorectal cancer tumours with a high degree of accuracy? And, second, can these predictions be mapped onto known or novel histological features?

Several weakly supervised learning methods for computational pathology have been proposed to maximise the use of available slide-level labels.19, 20, 21 For instance, Campanella and colleagues22 proposed a deep learning system based on multiple instance learning to discriminate between tumour and non-tumour whole-slide images using high-level image labels only. However, the multiple instance learning method22 required tens of thousands of whole-slide images to effectively train the model. Although the authors chose only a few representative top-ranked tiles from each slide, their method compared all tiles in the slide in each training epoch, which might be computationally expensive and requires a large amount of training data. Another weakly supervised method to classify whole-slide images proposed by Wang and colleagues23 requires pixel-level coarse annotations, which are labour-intensive and often unavailable, in addition to high-level image labels. Both these methods used an additional machine learning model to aggregate tile scores into a slide score.

We aimed to develop a novel, weakly supervised, deep learning pipeline that could effectively predict the status of slide labels, and, in particular, key molecular pathways and specific mutations, from haematoxylin and eosin-stained images of colorectal tumours, using only slide-level labels (and not cell-level or regional-level annotations) for algorithm training.

## Section: Methods

IDaRS prediction pipeline and histopathological feature discovery of colorectal cancer pathways

(A) Tissue segmentation and tile extraction were performed to obtain informative tiles. Model 1 (ResNet18) was trained to separate tumour from non-tumour tiles. These tiles served as input to iterative draw and rank sampling (an adaptation of ResNet34; model 2), which was trained on tumour tiles for label prediction. (B) A concept diagram of iterative draw and rank sampling illustrating the training strategy for the fast labelling of whole-slide images. The deep learning model was trained iteratively for classification with a random draw (di) of the same number of tiles from each whole-slide image and the k top-ranked tiles of the same slide drawn in the previous iteration. (C) The trained iterative draw and rank sampling model gave a prediction score to each tile in the whole-slide image, which were used to obtain a slide score and identify the top-ranked tiles from each slide. (D) Model 3 (HoVer-Net) inference was used to segment and classify different types of nuclei in top-ranked representative tiles in a cellular composition analysis of colorectal cancer pathways. Histological patterns of the molecular characteristics of colorectal cancers are shown as a spider plot based on the feature importance of different cellular composition profiles modelled via a support vector machine. H&E=haematoxylin and eosin. IDaRS=iterative draw and rank sampling. NEP1=neoplastic epithelial type 1. NEP2=neoplastic epithelial type 2.

## Section: Methods › Study design

In this retrospective study, we developed a novel, weakly supervised, deep learning framework involving three separate convolutional neural network models (figure 1). Because tumour tissue blocks taken during tumour sampling are large and almost always contain non-tumour tissue, it is necessary to first identify the tumour areas. A fine-tuned convolutional neural network (ResNet18; model 1)24 was used as the tumour detection model (figure 1A) to identify tumour tiles in a given slide. These tumour tiles served as input to iterative draw and rank sampling (an adaptation of ResNet34; model 2), which learned the discriminative features of slide labels, molecular pathways, and mutations (ie, hypermutation, microsatellite instability, chromosomal instability, CIMP, BRAF, TP53, and KRAS status) to calculate a digital score of the corresponding molecular status for each tile of the whole-slide image and the whole-slide image's most predictive visual fields (figure 1B, C). The final convolutional neural network (HoVer-Net;25 model 3; figure 1D) used the top-ranked tiles (as predicted by iterative draw and rank sampling) to segment and classify different types of cell nuclei in each tile to analyse cellular composition. Then, the predicted digital scores of each pathway were investigated for their association with the status of colorectal cancer molecular pathways and key mutations. Both training and inference were used for the first two networks, whereas, for the third, only inferences were made by use of HoVer-Net, a state-of-the-art nuclear segmentation and classification model pre-trained on the publicly available PanNuke dataset.26Figure 1IDaRS prediction pipeline and histopathological feature discovery of colorectal cancer pathways(A) Tissue segmentation and tile extraction were performed to obtain informative tiles. Model 1 (ResNet18) was trained to separate tumour from non-tumour tiles. These tiles served as input to iterative draw and rank sampling (an adaptation of ResNet34; model 2), which was trained on tumour tiles for label prediction. (B) A concept diagram of iterative draw and rank sampling illustrating the training strategy for the fast labelling of whole-slide images. The deep learning model was trained iteratively for classification with a random draw (di) of the same number of tiles from each whole-slide image and the k top-ranked tiles of the same slide drawn in the previous iteration. (C) The trained iterative draw and rank sampling model gave a prediction score to each tile in the whole-slide image, which were used to obtain a slide score and identify the top-ranked tiles from each slide. (D) Model 3 (HoVer-Net) inference was used to segment and classify different types of nuclei in top-ranked representative tiles in a cellular composition analysis of colorectal cancer pathways. Histological patterns of the molecular characteristics of colorectal cancers are shown as a spider plot based on the feature importance of different cellular composition profiles modelled via a support vector machine. H&E=haematoxylin and eosin. IDaRS=iterative draw and rank sampling. NEP1=neoplastic epithelial type 1. NEP2=neoplastic epithelial type 2.

IDaRS prediction pipeline and histopathological feature discovery of colorectal cancer pathways

(A) Tissue segmentation and tile extraction were performed to obtain informative tiles. Model 1 (ResNet18) was trained to separate tumour from non-tumour tiles. These tiles served as input to iterative draw and rank sampling (an adaptation of ResNet34; model 2), which was trained on tumour tiles for label prediction. (B) A concept diagram of iterative draw and rank sampling illustrating the training strategy for the fast labelling of whole-slide images. The deep learning model was trained iteratively for classification with a random draw (di) of the same number of tiles from each whole-slide image and the k top-ranked tiles of the same slide drawn in the previous iteration. (C) The trained iterative draw and rank sampling model gave a prediction score to each tile in the whole-slide image, which were used to obtain a slide score and identify the top-ranked tiles from each slide. (D) Model 3 (HoVer-Net) inference was used to segment and classify different types of nuclei in top-ranked representative tiles in a cellular composition analysis of colorectal cancer pathways. Histological patterns of the molecular characteristics of colorectal cancers are shown as a spider plot based on the feature importance of different cellular composition profiles modelled via a support vector machine. H&E=haematoxylin and eosin. IDaRS=iterative draw and rank sampling. NEP1=neoplastic epithelial type 1. NEP2=neoplastic epithelial type 2.

## Section: Methods › Data collection and preparation

We used 502 diagnostic slides of primary colorectal tumours (contributed by 36 different centres in the USA) from 499 patients in the TCGA-CRC-DX cohort, which has been used in previous studies (appendix 1 pp 2–3).4, 11, 18 For external validation of the microsatellite status results, our iterative draw and rank sampling model was trained on the TCGA-CRC-DX cohort and tested on the Pathology Artificial Intelligence Platform (PAIP) challenge cohort, which contains 47 slides (12 microsatellite instable and 35 microsatellite stable) from three different centres in South Korea. The microsatellite status of each tumour was determined by PCR assays. The TCGA-CRC-DX dataset was deidentified and publicly available, and participant consent had previously been obtained by The Cancer Genome Atlas consortium. For the PAIP cohort, all necessary participant consent had been obtained and all study patients had been previously deidentified by Seoul National University Hospital (Seoul National University Hospital IRB number H-1808-035-964). Institutional permissions were received to use the PAIP dataset and no further ethics approval was required.

The iterative draw and rank sampling deep neural network model was trained for binary classification. The ground truth labels of the TCGA-CRC-DX cohort for hypermutation (high mutation density vs low mutation density), microsatellite instability (highly microsatellite instable vs microsatellite stable), chromosomal instability (chromosomal instability vs genomic stability), and CIMP (high [CIMP-high] vs low [CIMP-low] frequencies of DNA hypermethylation) were obtained from, and defined by, Liu and colleagues.1 For prediction of BRAF, TP53, and KRAS mutation, the binary classifications were either mutant or wild-type and were obtained from Kather and colleagues.18 All slides were pre-processed for tissue segmentation by use of Otsu thresholding.27 Then, the segmented tissue region in each whole-slide image was divided into equally sized tiles (256 μm by 256 μm). Further details about ground truth labels and data pre-processing are provided in appendix 1 (pp 2–3).

## Section: Methods › Deep learning framework

A deep neural network (ResNet18; model 1) was trained on a balanced dataset of tumour and non-tumour tiles, comprising 35 436 tiles from seven arbitrarily selected slides from the TCGA-CRC-DX cohort combined with two publicly available datasets (from Kather and colleagues4 and Shaban and colleagues28), to extract tumour tiles from the TCGA-CRC-DX cohort slides (appendix 1 p 3). 24 843 (70·1%) of the tiles were used for training, 5380 (15·2%) were used for validation, and the remaining 5213 (14·7%) comprised an unseen test set, which contained 2493 (47·8%) non-tumour tiles and 2720 (52·2%) tumour tiles and was used to test model performance. We calculated accuracy and an F1 score to report the performance of the tumour segmentation model on the unseen test set.

The second neural network model was a fine-tuned version of ResNet34,24 pre-trained on ImageNet for the prediction of slide labels (ie, the status of molecular pathways and genetic mutations). Training was by Monte Carlo iterative draw and rank sampling and was done for 30 iterations, with a batch size of 256. Trained model 2 then calculated a prediction score for each tile in the whole-slide image, which can be considered the likelihood of a tile belonging to the positive class in our binary classification setting. These scores were used to identify the ten top-ranked tiles from each slide and to obtain a slide score by aggregating the scores of all tiles in a whole-slide image and reporting the average probability-based aggregation. Further details about training and aggregation are provided in appendix 1 (pp 3–4).

We used a final convolutional neural network (HoVer-Net;25 model 3) to segment and classify the different types of cell nuclei in the ten top-ranked tiles (as predicted by iterative draw and rank sampling) into five categories: neoplastic epithelial cells, non-neoplastic epithelial cells, inflammatory cells, mesenchymal cells, and necrotic cells. This step mimics the visual analysis of an expert pathologist who analyses nuclear composition in the tissue microenvironment subjectively under a microscope in a high-power field. The cell segmentation and classification results of HoVer-Net were visually examined by expert pathologists (AA and DS) for all cell types. We used the counts of individual cell types in each tile in a feature importance analysis to investigate potential associations between the cellular composition profile of top-ranked tiles for a given whole-slide image and molecular slide labels for hypermutation (high mutation density vs low mutation density), microsatellite instability (highly microsatellite instable vs microsatellite stable), chromosomal instability (chromosomal instability vs genomic stability), and CIMP (CIMP-high vs CIMP-low; appendix 1 pp 7–10). We calculated a tumour-infiltrating lymphocyte abundance score: the abundance of tumour-infiltrating lymphocytes in the vicinity of the tumour regions.

## Section: Methods › Statistical analysis

We used four-fold cross-validation in our prediction experiments to measure the mean iterative draw and rank sampling performance of the entire cohort. We used two folds for training, one fold as a validation set for keeping the best performing model, and one fold was kept aside as an unseen test set to measure model performance in a blinded way (appendix 1 p 5). We used the AUROC as a performance measure of the model predictions, and report the means and SDs of the AUROC values.

We compared our results with those of a state-of-the-art, automated microsatellite instability prediction model from a previous publication4 that used the same training-to-test dataset split in the TCGA-CRC-DX cohort. We also compared our algorithm's performance in a multi-fold cross-validation setting for microsatellite instability11 and other pathways and mutations (BRAF, TP53, and KRAS).18 Considering varying ratios of class imbalance (unequal samples in positive and negative classes) in the data, we also used average precision to calculate the area under the precision-recall curve (AUPRC). Both the AUROC and AUPRC were averaged for multiple runs and multiple folds of the experiments.

For internal validation of our microsatellite instability prediction results, we matched the split of the TCGA-CRC-DX cohort to that used by Kather and colleagues.4 For external validation, our iterative draw and rank sampling model was trained on the TCGA-CRC-DX cohort and tested on the PAIP challenge cohort, which contained 47 slides from three different centres. Tumour tiles (n=58 097) were obtained from the PAIP cohort by use of the expert pathologist annotations of the tumour region provided in the PAIP challenge dataset.

Because of the importance of clinical stage in routine histopathology and colorectal cancer pathways and mutations, we also divided the entire TCGA-CRC-DX cohort by TNM stage (stage I, stage II, stage III, and stage IV) and computed the AUROC for each group separately.

We overlaid local prediction heatmaps on top of whole-slide images to further analyse the relationship of our molecular labels (hypermutation, microsatellite instability, chromosomal instability, and CIMP) with the spatial features of the tumour microenvironment. In our correlation analysis, we analysed the correlation between the iterative draw and rank sampling-based digital scores for hypermutation, microsatellite instability, chromosomal instability, CIMP, BRAF, and TP53 status for each slide of the TCGA-CRC-DX test set used previously by Kather and colleagues,4 obtained by applying separately trained models on the same training set. Feature importance in the cellular composition analysis is shown as the mean value for each pathway, and presented as box and whisker plots. Statistical significance (p values) for the difference between tumour-infiltrating lymphocyte abundance scores was assessed via paired t tests. Correlation coefficients (r) and p values for the correlation analysis were obtained by use of Pearson correlation. More details about our visualisation and correlation analyses can be found in appendix 1 (pp 10–11). We used scipy.stats library (version 1.5.2) in Python to calculate statistics. The p value cutoff of less than 0·05 was used for defining statistical significance and an r value cutoff of 0·7 or –0·7 defined a strong correlation.

## Section: Methods › Role of the funding source

The funder of the study had no role in study design, data collection, data analysis, data interpretation, or writing of the report.

## Section: Results

Model 1 achieved an accuracy and F1 score of 99% for the test tiles. This model was then used to identify tumour tiles (a total of 448 595 tiles) in the entire TCGA-CRC-DX cohort (appendix 1 p 3).

For the prediction of hypermutation status, 67 slides labelled high mutation density and 363 labelled low mutation density were considered for binary classification, with our iterative draw and rank sampling method yielding a mean cross-validation AUROC of 0·81 (SD 0·03), compared with a previously published AUROC of 0·71 (table; figure 2).18 Among 62 slides labelled positive for high microsatellite instability and 366 labelled microsatellite instability low or microsatellite stable, our iterative draw and rank sampling method outperformed the method used by Echle and colleagues,11 with a mean cross-validated AUROC of 0·86 (SD 0·04) versus 0·74 (95% CI 0·66–0·80). Among 313 slides labelled as positive for chromosomal instability and 117 labelled as positive for genomic stability, our method outperformed the previously published method, with a mean AUROC of 0·83 (SD 0·02) versus 0·73.18 Among 55 slides labelled CIMP-high and 184 labelled CIMP-low, our mean AUROC was 0·79 (SD 0·05). Our iterative draw and rank sampling method also outperformed previously published methods for the prediction of BRAF mutation status (0·79 [SD 0·01] vs 0·66) and TP53 mutation status (0·73 [0·02] vs 0·64), and showed similar performance to previously published methods for predicting KRAS mutation status (0·60 [0·04] vs 0·60).18TablePerformance of the iterative draw and rank sampling method for prediction of hypermutation, microsatellite instability, chromosomal instability, and mutation status from haematoxylin and eosin-stained slides of colorectal cancerSamples (n)Published AUROC (95% CI)IDaRS AUROC (SD)IDaRS AUPRC (SD)TotalPositiveNegativeFour-fold cross-validation in the TCGA-CRC-DX cohortHigh vs low mutation density430673630·71180·81 (0·03)0·57 (0·09)Microsatellite instability vs stability428623660·74 (0·66–0·80)110·86 (0·04)0·62 (0·10)Chromosomal instability vs genomic stability4303131170·73180·83 (0·02)0·92 (0·01)CIMP-high vs CIMP-low23955184..0·79 (0·05)0·51 (0·05)BRAFmutvs BRAFWT502594430·66180·79 (0·01)0·33 (0·05)TP53mutvs TP53WT5022942080·64180·73 (0·02)0·78 (0·04)KRASmutvs KRASWT5022082940·60180·60 (0·04)0·53 (0·04)Train-test splits of TCGA-CRC-DX from Kather and colleagues4High vs low mutation density35966293..0·88 (0·02)0·66 (0·06)Microsatellite instability vs stability359622970·774 (0·62–0·87)0·90 (0·01)0·72 (0·02)Chromosomal instability vs genomic stability359257102..0·85 (0·02)0·92 (0·02)CIMP-high vs CIMP-low20351152..0·84 (0·01)0·61 (0·02)Validation of prediction on TCGA-CRC-DX and PAIP datasetsMicrosatellite instability vs stability (internal)359622970·774 (0·62–0·87)0·900·72Microsatellite instability vs stability (external)471235..0·980·95Labels considered positive were high mutation density, microsatellite instability, chromosomal instability, CIMP-high, and mutant (BRAFmut, TP53mut, and KRASmut). Labels considered negative were low mutation density, microsatellite stability, genomic stability, CIMP-low, and wild-type (BRAFWT, TP53WT, and KRASWT). Alongside our analysis, we list published results from previous studies11, 18 of three-fold cross-validation mean AUROCs and a train-to-test split4 AUROC in the TCGA-CRC-DX cohort. AUPRC=area under the precision-recall curve. AUROC=area under the convex hull of the receiver operating characteristic curve. CIMP=CpG island methylator phenotype. IDaRS=iterative draw and rank sampling. PAIP=Pathology Artificial Intelligence Platform. TCGA-CRC-DX=The Cancer Genome Atlas colon and rectal cancer.Figure 2Iterative draw and rank sampling-based prediction of colorectal cancer pathways in the TCGA-CRC-DX cohortAUROC plots of four-fold cross-validation for prediction of hypermutation (A), microsatellite instability (B), chromosomal instability (C), CpG island methylator phenotype (D), BRAF mutation status (E), and TP53 mutation status (F). The true positive rate represents sensitivity and the false positive rate represents 1–specificity. The blue shaded areas represent the SD. AUROC=area under the convex hull of the receiver operating characteristic curve. TCGA-CRC-DX=The Cancer Genome Atlas colon and rectal cancer.

As Kather and colleagues4 used a subset of the current version of the TCGA-CRC-DX cohort, which contained 62 slides with microsatellite instability and 297 with microsatellite stability, we used the same patient cohort and split the dataset into training and testing groups to compare our prediction of microsatellite instability with that by Kather and colleagues.4 Our iterative draw and rank sampling method outperformed the method used by Kather and colleagues,4 with a mean AUROC of 0·90 (SD 0·01) versus 0·77 (95% CI 0·62–0·87).

The highest AUPRC was obtained for predicting chromosomal instability, with relatively high values for predicting microsatellite instability, TP53 status, hypermutation, and CIMP (table). Generally, the higher the AUROC and the more balanced the dataset, the higher the AUPRC.

A breakdown of slide numbers from the TCGA-CRC-DX cohort by molecular label and cancer stage can be found in appendix 1 (p 2), as can AUROC plots by molecular label and stage (p 6). Among the individual stage groups, hypermutation, chromosomal instability, and BRAF mutation status were predicted with the highest AUROC in patients with stage IV cancer, whereas microsatellite instability was predicted with the highest AUROC in patients with stage I or II disease (appendix 1 pp 6–7). Our method was better at differentiating between CIMP-high and CIMP-low groups in patients with stage I, II, or III cancer than in patients with stage IV cancer (appendix 1 pp 6–7). We did not find any difference in accuracy for predicting TP53 status by cancer stage (appendix 1 pp 6–7).

Model 3 (HoVer-Net) segmented and classified the cell nuclei in each top-ranked tile into five categories (appendix 1 pp 7–8). Non-neoplastic epithelial cells identified by model 3 differed from those identified by the model as neoplastic epithelial cells, but all of these were categorised as tumour cells by the experts (as only tumour tiles were used). Therefore, neoplastic epithelial cells identified by HoVer-Net are called neoplastic epithelial type 1 (NEP1) cells, and non-neoplastic epithelial cells identified by the model are called neoplastic epithelial type 2 (NEP2) cells.

A relatively high proportion of inflammatory and necrotic cells and a relatively low proportion of NEP1, NEP2, and mesenchymal cells were associated with microsatellite instability (figure 3). A relatively high proportion of inflammatory and NEP1 cells and a relatively low proportion of NEP2, mesenchymal, and necrotic cells were associated with hypermutation (figure 3). A relatively high proportion of inflammatory, necrotic, and NEP1 cells and a relatively low proportion of mesenchymal and NEP2 cells were associated with CIMP-high status (figure 3). A relatively high proportion of NEP2, mesenchymal, and NEP1 cells and a relatively low proportion of necrotic and inflammatory cells were associated with chromosomal instability (figure 3). Our feature importance analysis of cellular composition profiles by molecular label, in addition to our analysis of tumour-infiltrating lymphocyte abundance score by molecular label, can be found in appendix 1 (pp 8–10). Figure 3 suggests infiltration by inflammatory cells as a key discriminating histological feature in microsatellite instable and hypermutated tumors. Paired t tests found tumour-infiltrating lymphocyte abundance scores to be significantly associated with the microsatellite instability pathway (p=0·0024) and hypermutation (p=0·024), but not with the CIMP (p=0·090) and the chromosomal instability (p=0·16) pathways. This finding suggests that high proportions of tumour-infiltrating lymphocytes are strongly associated with microsatellite instable and hypermutated tumours.Figure 3Spider chart of differential cellular compositions as histological features of colorectal cancer pathwaysNormalised weights between –1 and 1 show the size of significance of the corresponding histological feature. CIMP-high=CpG island methylator phenotype of high frequencies of DNA hypermethylation. NEP1=neoplastic epithelial type 1. NEP2=neoplastic epithelial type 2.

As can be observed in our tile prediction heatmaps, similar tissue regions appear to be predictive of either a positive or negative status of the four colorectal cancer molecular labels or pathways (appendix 1 pp 10–11). However, tiles associated with the ground truth label differed in number between heatmaps (appendix 1 pp 10–11).

Iterative draw and rank sampling-based digital scores for microsatellite instability and hypermutation showed a strong positive correlation, and the scores for microsatellite instability and CIMP showed a moderate positive correlation, wherein the microsatellite stability score showed the highest positive correlation with the CIMP-low score (appendix 1 pp 11–12). The digital scores of microsatellite instability and CIMP showed strong negative correlations with chromosomal instability (appendix 1 pp 11–12). Microsatellite instability had the strongest negative correlation with genomic stability, CIMP-low had the strongest negative correlation with chromosomal instability, and chromosomal instability had the strongest positive correlation with TP53 mutation status (appendix 1 pp 11–12). Microsatellite instability and CIMP scores were positively correlated with BRAF mutation (appendix 1 pp 11–12).

Performance of the iterative draw and rank sampling method for prediction of hypermutation, microsatellite instability, chromosomal instability, and mutation status from haematoxylin and eosin-stained slides of colorectal cancer

Iterative draw and rank sampling-based prediction of colorectal cancer pathways in the TCGA-CRC-DX cohort

AUROC plots of four-fold cross-validation for prediction of hypermutation (A), microsatellite instability (B), chromosomal instability (C), CpG island methylator phenotype (D), BRAF mutation status (E), and TP53 mutation status (F). The true positive rate represents sensitivity and the false positive rate represents 1–specificity. The blue shaded areas represent the SD. AUROC=area under the convex hull of the receiver operating characteristic curve. TCGA-CRC-DX=The Cancer Genome Atlas colon and rectal cancer.

Spider chart of differential cellular compositions as histological features of colorectal cancer pathways

Normalised weights between –1 and 1 show the size of significance of the corresponding histological feature. CIMP-high=CpG island methylator phenotype of high frequencies of DNA hypermethylation. NEP1=neoplastic epithelial type 1. NEP2=neoplastic epithelial type 2.

## Section: Discussion

In this retrospective study, we developed and validated a deep learning pipeline using the TCGA-CRC-DX cohort with similar experimental setups to those reported in previously published studies.4, 11, 18 We showed that using a novel training strategy in a standard deep learning model can improve the prediction of key molecular characteristics and mutations in colorectal cancer tumours. Hypermutation, microsatellite instability, chromosomal instability, BRAF mutation status, and TP53 mutation status were predictable from digitised images of routine haematoxylin and eosin-stained slides with a higher accuracy than previously published state-of-the-art computational algorithms. We also optimised our tumour segmentation algorithm, which ensured that non-tumour colon mucosa was not included in the analysis.

We evaluated iterative draw and rank sampling for prediction of KRAS mutation status and BRAF mutation status, both of which could potentially be used for patient stratification for anti-epidermal growth factor receptor therapy. The US Food and Drug Administration have approved the use of immunotherapy for patients with colorectal cancers with high microsatellite instability, and so iterative draw and rank sampling could be used for patient selection using routine diagnostic histology slides. In the UK, the National Institute for Health and Care Excellence have also approved the use of encorafenib plus cetuximab for patients with previously treated, metastatic colorectal cancer positive for BRAF Val600Glu mutations. We hope that our algorithms might prove to be useful alternative tests for key mutations and pathways for patient stratification, potentially reducing turnaround time and saving resources.

Our analysis of stage-wise prediction accuracy (AUROC) indicated that the prediction of hypermutation, molecular pathways (microsatellite instability, chromosomal instability, and CIMP), and key mutations (BRAF and TP53) might vary by cancer stage. For example, the accuracy of microsatellite instability prediction decreased slightly from stage I cancers to stage IV cancers. This finding indicates that tumour stage might affect deep learning-based discrimination of predictive features. Because we interrogated sections of primary tumours only, features of early-stage cancers with microsatellite instability could differ subtly from those of advanced cancers with microsatellite instability, perhaps due to the increased heterogeneity of advanced tumours. Similarly, hypermutation, chromosomal instability, and BRAF mutation status were predicted with the highest AUROC in patients with stage IV cancer. Exploring the predictive value of deep learning features of early-stage cancers might allow for more aggressive and targeted treatment to prevent disease progression.

Key challenges for prediction of microsatellite instability are the trade-off between sensitivity and specificity for clinical gold-standard testing (immunohistochemistry) and inconsistencies among different assays. Further improvements in the AUROC for microsatellite instability prediction and comparison with other molecular and genetic labels are possible if the specificity and sensitivity of the corresponding test used for acquiring the slide-level ground truth labels are improved and known beforehand, and the size of the dataset is increased. The ground truth microsatellite instability labels used in this study were based on molecular data in the TCGA-CRC-DX cohort and PCR assays in the PAIP cohort. The sensitivity (94%) and specificity (88%)29 of gold-standard, immunohistochemistry-based testing should represent a minimum performance threshold that needs to be achieved by digital methods such as iterative draw and rank sampling for scoring microsatellite instability. Further large-scale validation of iterative draw and rank sampling on multiple international cohorts is necessary before it can be considered for clinical use.

We did a cellular composition analysis to mine differential histological features for each of the colorectal cancer pathways, leveraging the ability of iterative draw and rank sampling to produce and overlay a prediction confidence heatmap on the original whole-slide images. Confidence heatmaps have shown that the tiles of both positive and negative labels with varying confidence are often predicted in an image, which could be linked to the difficulty of predicting microsatellite instability, especially when the immunogenic response of microsatellite stability is similar to the histomorphology of microsatellite instability.30 It could also indicate that a more sophisticated aggregation method than a simple average or majority voting might be needed to correctly classify some molecular characteristics.

Knowledge regarding stratification of colorectal cancer into multiple molecular pathways, and the morphological correlates and clinical significance of these pathways, is still evolving, and most findings so far are inconclusive. Gao and colleagues31 found that microsatellite instability was associated with low inflammatory cell infiltration, but not with tumour necrosis, in colorectal cancers; however, others9, 32 found that tumour-infiltrating lymphocytes and an absence of tumour necrosis were strong predictors of microsatellite instability in colorectal cancers. In a study by Saller and colleagues,30 findings compatible with an immunogenic response were observed in the colorectal tumours of three patients, but different assays gave inconsistent interpretations of their microsatellite instability status. This contradiction can be attributed to the absence of an objective and systematic data-driven approach for analysis of the entire tissue slide for multicentre cohorts. In the existing literature, histological correlates of molecular characteristics (eg, microsatellite instability) are often examined only subjectively.6, 7, 9, 31, 32, 33, 34 We believe that our iterative draw and rank sampling-based analysis is a first step towards an objective, quantitative, and reproducible approach for analysing colorectal cancer pathways from routine histology slides and studying their corresponding histological correlates in a systematic and data-driven manner.

A relatively high proportion of NEP2, mesenchymal, and NEP1 cells and a relatively low proportion of necrotic and inflammatory cells were associated with chromosomal instability. This finding could explain the potential association of chromosomal instability with less favourable outcomes.2, 9 The strong association of CIMP-high with a high proportion of inflammatory cells and a low proportion of mesenchymal cells found in our cellular composition analysis might suggest the molecular characteristics of an active immune response, as reported previously.7 A relatively high proportion of inflammatory and necrotic cells and a relatively low proportion of NEP1, NEP2, and mesenchymal cells were associated with microsatellite instability. This finding could explain the favourable response of tumours with microsatellite instability to immunotherapy.35, 36 Our differential cellular composition analysis suggests that the infiltration scores of lymphocytes and necrosis within the tumour can serve as digital biomarkers for further stratification and the analysis of each pathway and its clinical impact. Our findings of a strong correlation between microsatellite instability and hypermutation,1, 3, 37 a moderate correlation between microsatellite instability and CIMP,6, 7 and a high infiltrate of inflammatory cells in microsatellite instable tumours9, 32, 34 are in line with existing literature. The cellular composition profiles of microsatellite instability, hypermutation, chromosomal instability, and CIMP groups potentially add new knowledge to the literature regarding the associations between molecular labels and cell types, requiring large validation and further exploration with subsequent studies.

Our iterative draw and rank sampling algorithm uses Monte Carlo sampling to iteratively select training data from each whole-slide image, leading to a slightly different trained model for each run. Therefore, we ran each experiment three times with the same data splits and report averaged measures. The number of randomly drawn tiles, top-ranked tiles, and maximum training iterations used in the iterative draw and rank sampling training algorithm might not have been optimal (appendix 1 p 6). These values might need to be adjusted for a given problem. Data imbalance—having a different number of positive and negative samples in a binary classification dataset—is another common issue with medical datasets, which can affect classification performance. We therefore reported the AUPRC results in addition to the AUROC results. External validation was done on 47 whole-slide images from the PAIP dataset obtained from three different centres, which is a relatively small dataset. A pre-trained HoVer-Net model—a state-of-the-art alogorithm—was used for nuclei segmentation and classification, which was followed by a review by expert pathologists (AA and DS). However, nuclear segmentation and classification from haematoxylin and eosin-stained images is known to be a challenging task; therefore, our classification of neoplastic and stromal cells for the TCGA-CRC-DX cohort might have been imperfect, affecting our interpretation of the importance of these cell types. Although the TCGA-CRC-DX cohort is a multicentre dataset and PAIP is an external cohort, further large-scale validation of these findings is required before implementation into diagnostic practice and patient management.

## Section: Data sharing

All images and the associated pathway and mutation status information for the TCGA-CRC-DX cohort (separated for colon adenocarcinoma and rectal adenocarcinoma) used in this study are publicly available at https://portal.gdc.cancer.gov/ and cBioPortal (https://www.cbioportal.org/). The TCGA-CRC-DX manifest file can be used to download all images for the TCGA-CRC-DX cohort and can be found in appendix 2. The ground truth labels of the TCGA-CRC-DX cohort for hypermutation, microsatellite instability, chromosomal instability, and CIMP were obtained from Liu and colleagues.1 A link to the spreadsheet containing the corresponding clinical and molecular data, including cancer stages, subtypes, and mutation and pathway status, can also be found in appendix 2. The scores generated by our algorithm are provided in appendix 2. Source code can be made available, subject to intellectual property constraints, by contacting the first (mohsin.bilal@warwick.ac.uk) or last (N.M.Rajpoot@warwick.ac.uk) authors. Deidentified pathology images and annotations from the PAIP cohort, which were used with institutional permissions in this study, can be obtained via appropriate data access requests at http://www.wisepaip.org/paip.

## Section: Declaration of interests

MI reports grants from Roche, outside the submitted work. DS reports personal fees from Royal Philips, outside the submitted work. NMR reports research funding from GlaxoSmithKline and is also part of the PathLAKE consortium, which is partly funded by Royal Philips. All other authors declare no competing interests.


---

# Discovery of novel selective PI3Kγ inhibitors through combining machine learning-based virtual screening with multiple protein structures and bio-evaluation

- **Authors:** Jingyu Zhu, Kan Li, Lei Xu, Yanfei Cai, Yun Chen, Xinling Zhao, Huazhong Li, Gang Huang, Jian Jin
- **Issuer:** Journal of advanced research
- **Type:** Scientific article
- **Published:** 2021-04-20
- **Language:** en
- **DOI:** 10.1016/j.jare.2021.04.007
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35127160/
- **Licence:** CC-BY

## Section: Abstract

Graphical abstractKeywords: PI3Kγ, Selective inhibitor, Hematologic malignancies, Virtual screening, Molecular dynamics simulation, JN-KI3Abbreviations: PI3K, Phosphoinositide 3-kinase; RTK, receptor tyrosine kinases; GPCR, G protein-coupled receptors; CADD, computer-aided drug design; VS, virtual screening; MD, molecular dynamics; PDB, protein data bank; RMSD, root-mean-squared-deviation; SP, standard precision; XP, extra precision; DS3.5, discovery studio 3.5; NBC, naive Bayesian classifier; ROC, receiver operations characteristic; AUC, area under receiver operations characteristic curve; REOS, rapid elimination of swill; Badapple, bioactivity data associative promiscuity pattern learning engine; SMILES, simplified molecular input line entry specification; ADMET, absorption, distribution, metabolism, excretion, and toxicity; DMEM, Dulbecco’s Modified Eagle Medium; IMDM, Iscove’s Modified Dulbecco’s Medium; FBS, fetal bovine serum; SD, standard deviation; AKT, protein kinase B; PAGE, polyacrylamide gel electrophoresis; RMSF, root-mean-squared-fluctuation; MM/GBSA, molecular mechanics/generalized born surface area; PAINS, pan-assay interference compounds; PSA, primary screening assays; CDRA, confirmatory dose–response assays; PARP, poly ADP-ribose polymerase; H-bond, hydrogen bond; Ionic, ionic interactions; Water Bridge, hydrogen bonds through water molecular bridge

## Section: Introduction

The extensive research conducted over the past decades has implicated the role of various cell signaling events in numerous malignant, inflammatory, autoimmune, and cardiovascular diseases, out of which the phosphoinositide 3-kinase (PI3K) signaling is one of the most relevant pathways because of its various vital functions, such as cell survival, proliferation, differentiation, and motility [1]. PI3Ks belong to a family of lipid kinases which catalyze the phosphorylation of the inositol ring of phosphoinositide and then transduce the signals as secondary messengers [2]. PI3Ks are divided into three different classes (I, II, and III) based on their primary structures and the preference of substrates [3]. Comparing to the other two classes, class I PI3Ks have been extensively and exhaustively studied. Class I PI3Ks are consist of two different subclasses, class IA and class IB, according to their signaling pathways and regulating proteins [4]. There are three PI3K isoforms, PI3Kα, PI3Kβ, and PI3Kδ, belonging to class IA, and PI3Kγ is the only member of class IB. Class IA are activated by receptor tyrosine kinases (RTKs) and other tyrosine kinase coupled receptors [5], [6], [7], while class IB accepts the signaling from G protein-coupled receptors (GPCRs) through the interaction between PI3Kγ regulatory subunit and the β-subunits of GPCRs [8], [9], [10]. A large amount of research has proved that the Class I PI3Ks play multiple crucial roles in a wide variety of cellular processes [11], [12], [13], and that makes PI3K as a promising drug target for the treatment of cancers, inflammations, and immune disorders [3], [4], [5], [6], [7]. Nowadays, four PI3K inhibitors have been pushed into the market, namely, Idelalisib in 2014 (PI3Kδ inhibitor) [14], [15], Copanlisib in 2017 (pan-PI3K inhibitor) [16], Duvelisib in 2018 (PI3Kδ/γ duel inhibitor) [17] and Alpelisib in 2019 (PI3Kα inhibitor) [18], [19]. These achievements greatly stimulated the development of novel PI3K inhibitors, especially PI3K selective inhibitors.

Among the four isoforms, PI3Kγ has been attracted more and more attention for its restricted expression in the hematopoietic systems, especially in leukocytes [20]. Thus, PI3Kγ is considered as a valuable target to treat not only advanced solid tumors, leukemia and lymphoma, but also inflammatory and autoimmune diseases [21], [22], [23]. However, the high structural and sequential homology of these four PI3K isoforms is a huge hinder to acquire specific PI3Kγ inhibitor [24]. Some selective PI3Kγ inhibitors have been discovered with experimental methods and almost all of those were identified through screening against a broad panel of diverse kinases for each chemical scaffold [22], [25], [26]. It is known that these traditional experimental approaches are expensive and time-consuming [27]. Besides, it is reported that in the ATP-binding pocket of PI3Kγ, the side chains of the residues distinguished from other isoforms are always rotated away from the pocket [24]. The conventional methods are difficult to reveal these structural features at a molecular level. Therefore, computer-aided drug design (CADD) is an appropriate selection to aid in the discovery or design of PI3Kγ inhibitors with a high degree of selectivity [28], [29], [30]. Thus, in this present study, a combined approach integrated bioactive evaluation and computer simulation was conducted to discover novel PI3Kγ inhibitors. The whole workflow was given in Fig. 1. First, a machine learning-virtual screening (VS) model based on molecular docking with multi-PI3Kγ conformations was built to screen the ChemDiv database, and some top-ranked inhibitors were purchased and submitted to bioassays. As a result, some potential PI3Kγ selective inhibitors were identified. Particularly, JN-KI3 exhibits a high degree of PI3Kγ-selective inhibition and specific anti-proliferative activity against hematologic malignancies. In the end, a systematic computational analysis utilizing molecular docking and molecular dynamic (MD) simulations was performed to study the selective-PI3Kγ inhibition mechanism of JN-KI3.

The workflow of this study.

## Section: Material and methods › Construction of VS model › Preparation of PI3Kγ complexes

The workflow of the VS protocol is illustrated in Fig. 1. A total of 87 crystallographic structures of PI3Kγ-inhibitor complexes were gathered and retrieved from the RCSB protein data bank (PDB, Table S1 in the supplementary information) [31]. All PI3Kγ protein structures were prepared with Protein Preparation Wizard module of Schrödinger 9.0 to remove crystallographic waters, add hydrogen atoms, assign partial charges with the OPLS-2005 force fields [32], assign the protonated state. The missing side chains and loops were added using Prime module, and last, all protein structures were minimized until the root-mean-squared-deviation (RMSD) reached a maximum value of 0.3 Å, and other parameters were set as default. Then the residues within 10 Å of each co-crystallized ligand were reserved and structurally aligned with STAMP algorithm in VMD [33]. Afterward, the phylogenetic tree module in VMD was employed to calculate the phylogenetic tree based on the RMSD values and the result was illustrated in Fig. S1, all of them were divided into 10 categories and the complex with the highest resolution within each category were chosen and finally 10 representative complexes were selected to further docking simulation. Firstly, the “docking power” of these chosen complexes was evaluated with following steps: the co-crystallized ligands were redocked into the active binding pocket by Glide/SP (standard precision) and Glide/XP (extra precision) molecular docking methods, and then the RMSD between the docking results and the original conformations of inhibitors were calculated. Generally speaking, RMSD ≤ 2.0 Å represents the criterion of successful docking prediction [34].

## Section: Material and methods › Construction of VS model › Inhibitor/non-inhibitor validation set

In order to evaluate the “screening power” of the 10 complexes with the docking module, which represents the ability to distinguish the known PI3Kγ inhibitors from non-inhibitors, 800 PI3Kγ inhibitors, as an “inhibitor set”, with definite biological activity (IC50 < 10 μM) were extracted from BindingDB database [35] using Find Diverse Molecules module of Discovery Studio 3.5 (DS3.5) software. Besides, 16,000 compounds were randomly selected from ChemDiv compound library with the Find Diverse Molecules in DS 3.5 to construct a “decoy set”, the ratio between inhibitors and decoys was 1:20. Both “inhibitor set” and “decoy set” were minimized under OPLS-2005 force field [2] using the LigPrep module of Schrödinger 9.0 with the default parameters set.

## Section: Material and methods › Construction of VS model › Validation of molecular docking

10 prepared PI3Kγ complex were then submitted to perform molecular docking. the Receptor Grid Generation module of Schrödinger 9.0 was employed to generate a bounding box of size 10 Å × 10 Å × 10 Å within each PI3Kγ structure, and the center of each box was defined through the co-crystallized ligand in the ATP binding site. And all prepared compounds in the validation set were then docked into the ATP binding site of these PI3Kγ structures, and all docking poses were scored by the SP and XP scoring modes. The best binding pose of each compound was saved for the following analysis, and Student’s t-test was used to measure the difference in the distribution of docking scores between inhibitor and non-inhibitors.

## Section: Material and methods › Construction of VS model › Integrated docking with multiple PI3Kγ proteins

Consequently, a machine learning approach, naive Bayesian classification (NBC), based on these 10 PI3Kγ structures was employed to evaluate the screening accuracy. The docking scores calculated by the Glide docking module were used as the independent variable (X), and 1/0 (1 for PI3Kγ inhibitor and 0 for non-inhibitor) was used as the response variable (Y). Then, the predicting classifiers for VS model were generated following the Create Bayesian Model protocol in DS 3.5, and the ligand enrichment was determined through the area under ROC (receiver operating characteristic curve) value (AUC). The AUC represents the relationship between the true positive rate (active inhibitors) and the false positive rate (decoys), and a high AUC value indicates that the developed model contains a strong power to discriminate the positive inhibitors from the negative non-inhibitors [36].

## Section: Material and methods › Construction of VS model › Multi-conformational virtual screening in a sequential manner

Firstly, about 2,000,000 compounds from ChemDiv database were docking into the binding site of 10 PI3Kγ structures with the preferred docking precision, respectively, and 10,000 top-ranked compounds were retained. And then, the best Bayesian classifier was then utilized to re-score these 10,000 compounds, and 2,000 compounds with top Bayesian scores were reserved. Afterward, these compounds were assessed the drug-likeness by Filter by Lipinski and Veber Rules module in DS3.5 [37] and the rapid elimination of swill (REOS) rules in Canvas [38], and 200 compounds were selected. Besides, to maintain structure diversity of screening compounds, the 200 compounds were structurally clustered through the Find Similar Molecules by Fingerprints module in DS3.5, the compounds with similarity coefficients higher than 0.8 were clustered into the same group. And then, 100 compounds with various scaffolds were chosen. The 2D-interactions patterns between these 100 compounds and PI3Kγ following illustrated by the Ligand Interactions module of Schrödinger. And the compounds interacting with the “hot residues” within the ATP binding pocket, which were identified by our previous work [39], [40], were kept. Finally, the top 49 compounds with required interactions were selected as pro-hits for the following biological evaluations.

## Section: Material and methods › Promiscuity and ADMET assessment

The promiscuity of JN-KI3 was investigated by two online programs, Badapple [41] (bioactivity data associative promiscuity pattern learning engine, http://pasilla.health.unm.edu/tomcat/badapple/badapple) and Hit Dexter 2.0 [42] (https://acm.zbh.uni-hamburg.de/hitdexter/). For both tools, the SMILES (simplified molecular input line entry specification) format of JN-KI3 was entered into the input box and the results would be generated automatically. In addition, the ADMET (absorption, distribution, metabolism, excretion, and toxicity) properties were predicted using QikProp module of Schrödinger. This module was carried out in normal mode and predicted principal descriptors and physicochemical properties of JK-KI3.

## Section: Material and methods › Bio-assay evaluation › PI3K kinases activity in cell-free assays

The PI3K inhibitory activities of these pro-hits were all determined by ADP-Glo assay (Promega) [39]. For the initial screening, the compositions and optimized concentrations of the assay were listed as below: PI3Kγ 0.625 μg/mL, PIP2:PS 50 μg/mL, compounds 10 μM, ATP 25 μM, IPI-145 and LY294002 [43] were used as positive controls. For the JN-KI3 kinases activity assays, the compositions and optimized concentrations were listed as follows: PI3Kα 0.625 μg/mL, PI3Kβ 0.625 μg/mL, PI3Kδ 0.625 μg/mL, PI3Kγ 0.625 μg/mL, ATP 25 μM, PIP2:PS 50 μg/mL, PI-103 and LY294002 were used as positive controls. JN-KI3 and all positive compounds were serially diluted into required concentrations. In all cases, except for the control wells and background wells, the solution of PI3K enzymes was incubated with testing compounds in 384 plate for 45 min. 2.5 μL ATP/substrate mixture was added into the wells to initiate kinase reactions and incubated at room temperature for 1 h. Then, the reactions were stopped by addition of 5 μL ADP-Glo reagent and incubation for 120 min at room temperature. Before reading the luminescence signals of each well, 10 μL kinase detection buffer was added and incubated for 30 min at room temperature.

## Section: Material and methods › Bio-assay evaluation › Cell lines and cell culture

The human cancer lines, MDA-MB-231, Patu8988, HepG2, A2780, LOVO, H1299, A549, HCT-8, SW480, 3AO, and MGC-803 were saved by the lab of Dr. Jian Jin, Jiangnan University. MCF-7 was purchased from the American Type Culture Collection (ATCC). Human malignant blood tumor cells, HL-60, U266, OPM2, OCI-My5, RPMI-8226, NCI-H929, Jurkat, LP-1, CCRF-CEM, K562, and U937, were provided by Dr. Xinliang Mao, Soochow University. MDA-MB-231, Patu8988, HepG2, A2780, LOVO, H1299, A549, HCT-8, SW480, 3AO, MGC-803, and MCF-7 were cultured in Dulbecco’s Modified Eagle Medium (DMEM, Gibco); U266, RPMI-8226, OPM2, OCI-My5, NCI-H929 and LP-1 were cultured in Iscove’s Modified Dulbecco’s Medium (IMDM. Gibco). The rest of cell lines were cultured in RPMI-1640 medium (Gibco). All mediums were supplemented with 10% fetal bovine serum (FBS, Gibco), 100 μg/mL penicillin and streptomycin, and all cells were maintained in a cell incubator with 5% CO2 at 37℃.

## Section: Material and methods › Bio-assay evaluation › Cell proliferation assay

All cells were incubated in 96-well culture plates with 100 μL medium in each well. The concentration of solid cells (MDA-MB-231, MCF-7, Patu8988, HepG2, A2780, 3AO, LOVO, HCT-8, SW480, A549, H1299, and MGC-803) was 3,000/well and the concentration of suspension cells (HL-60, U266, OPM2, OCI-My5, RPMI-8226, NCI-H929, Jurkat, LP-1, CCRF-CEM, K562, and U937) was 7,500/well. Cells were then treated with 5 μL compounds and positive inhibitors, IPI-145 and LY294002, diluted in the required concentration for 72 h. The viability of the cancer cells was evaluated by Thiazolyl Blue (MTT) assay. 10 μL of 5 mg/mL MTT was added to each well and the plate was incubated at 37℃ for 4 h. Then, 100 μL MTT buffer was added to each well. After incubating the plate overnight, the absorbance of each well was measured at 550 nm by a microplate reader. All data were normalized to control groups (5 μL DMSO) and converted into the percent of living cells. All results were represented as the mean and standard deviation (SD) of the three independent measurements.

## Section: Material and methods › Bio-assay evaluation › Western Blot assay

K562 and RPMI-8226 cells were cultured in 6-well plates with 1 × 106 cells per well and then treated with various concentrations of JN-KI3: 0, 2.5, 5, 10, and 20 μM. After 24 h, the cells of each well were collected and washed by PBS 3 times. The sedimentary cells were then incubated in an ice bath with 80 μL RIPA lysis buffer (Beyotime) for 20 min and then centrifuged at 12,000 rpm for 20 min. The supernatant was collected and its total concentration of protein was quantified using the BCA protein assay kit (Biosharp). Loading buffer (5 ×) was added to all protein samples prepared for Western Blot assays and boiled at 100℃ for 5 min.

The inhibitory situation of PI3K/AKT (Protein kinase B) signaling pathway was then determined by Western Blot assays. The SDS-polyacrylamide gel electrophoresis (PAGE) was used to separate the proteins. All protein samples and Protein Marker (Proteintech) were loaded onto an acrylamide gel and ran for 30 min at 80 V within the staking gel and for 1 h at 100 V with the separating gel. Then, the protein was electro-transferred onto an NC membrane at 100 V for 1 h. After that, the membrane was blocked in 5% skim milk diluted in TBST (1 ×) for 2 h and then the membrane was incubated with relevant primary antibody overnight at 4℃: Phospho-AKT (Thr308) (1 : 1000, cat# 13038 T; Cell Signaling Technology), Phospho-AKT (Ser473) (1: 1000, cat# 4060 T; Cell Signaling Technology), AKT (pan) (1: 1000, cat# 4691 T; Cell Signaling Technology), caspase-3 (1: 1000, cat# sc-56053; Santa Cruz Biotechnology), PARP (1: 1000, cat# 9542S; Cell Signaling Technology). GAPDH (1: 5000, cat#60004–1-Ig; Santa Cruz Biotechnology), After 10-min washing in TBST (1 ×) for 3 times, the membrane was incubated with relevant secondary antibody at room temperature on a shaker for 1 h. And the membrane was washed for 4 times in TBST again before being imaged.

## Section: Material and methods › Bio-assay evaluation › Flow cytometry assay

After being treated with JN-KI3 for 24 h, K562 and RPMI-8226 were stained with Annexin V-FITC/PI detection kit (Beyotime) and the apoptosis of the cells were detected using a flow cytometer (FACSCalibur, BD) following the instructions.

## Section: Material and methods › Theoretical studies on the PI3Kγ selective inhibition mechanism of JN-KI3

Docking studies. The crystallographic structures with high resolutions of PI3Kα (PDB ID: 6PYS) [44], PI3Kβ (PDB ID: 2Y3A) [45], PI3Kδ (PDB ID: 6PYR) [44] and PI3Kγ (PDB ID: 4ANV) [46] were stretched from the RCSB PDB. All structures were prepared in the Protein Preparation Wizard module of Schrödinger 9.0. The 3D-structures of Cpd5, Cpd36, Cpd38, and JN-KI3 were generated by maestro and minimized in the LigPrep module. Then, a bounding box was generated on the ATP binding site of each complex with the center of crystallized ligand by using the Receptor Grid Generation module. Cpd5, Cpd36, and Cpd38 were docked into PI3Kγ, while JN-KI3 was docked into the binding site of each complex, all docking programs were performed using Glide SP method.

MD simulations. Four PI3Ks/JN-KI3 complexes with the best conformations generated by molecular docking were used as initial structures to perform MD simulations by Desmond [47]. Each complex system was immersed in a solvent model with TIP3P water molecules and the boundary of the infiltration volume was extended to 10 Å in each direction. Then, each system was neutralized with Na+/Cl- counter ions and minimized under the OPLS-2005 force field [2]. Afterward, four complexes were submitted to MD simulations following the default NPT and NVT ensemble protocols in Desmond program, a 200-ns MD simulation at the pressure of 1 atm maintained by Martyn-Tobias-Klein pressure bath [48] and at the temperature of 300 K maintained by Nose- Hoover Chain thermostat [49] was performed for each system. The Smooth Particle Mesh Ewald method [50] was used to analyze the electrostatic interaction forces between the complexes. And the RMSDs of the PI3Ks protein backbones and the RMSF (root-mean-squared-fluctuation) value of each atom in JN-KI3 were calculated.

MM/GBSA free energy calculation. The binding free energy (ΔGBind) for each system was calculated by using Prime MM/GBSA (Molecular Mechanics/Generalized Born Surface Area) module employing an equation:

Where Gcomplex, Gprotein and Gligand are the prime energies of the optimized complex, free receptor and free ligand, respectively [51].

## Section: Results and discussion

The docking power, screening power, and crucial interactions of ten PI3Kγ crystal structures.

(A-J) Distributions of the docking scores of the inhibitor (red)/noninhibitor (green) for each PI3Kγ protein with the best discrimination power; (K) the ROC curve of the naive Bayesian classifier based on every single docking score; (L) the ROC curve of the naive Bayesian classifier based on the combined docking scores.

(A) The cell-free PI3Kγ inhibitory activities of 49 hits and two positive inhibitors, IPI-145 and LY294002; (B) the anti-proliferation effects towards multiple tumor cells of 49 hits and two positive inhibitors, IPI-145 and LY294002; (C) the anti-proliferation effects towards multiple tumor cells of JN-KI3 and IPI-145; (D) the anti-proliferation effects towards multiple malignant tumor cells of JN-KI3 with the gradient of concentrations.

The 2D-structures and the cell-free inhibitory activity values (IC50) of JN-KI3 and the positive reference compounds JN-PK1, PI-103, and LY294002.

The pScore and inDrug values from Badapple data base, and the predicted ADMET properties of JK-KI3.

JN-KI3 inhibited PI3K/AKT signaling pathway and induced apoptosis of (A) K562 and (B) RPMI-8226 cell lines at different concentrations from 0 to 20 μM after 24 h incubation. JN-KI3 inhibited PI3K/AKT signaling pathway and induced apoptosis of (C) K562 and (D) RPMI-8226 cell lines at different times from 0 to 24 h for 20 μM concentration. JN-KI3 induced apoptosis of hematologic malignancies illustrating by flow cytometry. Apoptosis of (E) K562 and (F) RPMI-8226 cell lines treated with different concentrations of JN-KI3 (from 0 μM to 10 μM) for 24 h.

The docking scores and predicted binding free energies of JN-KI3/PI3Ks, and the inhibitory activities against PI3Ks of JN-KI3.

2D interaction patterns and protein–ligand occupancy histogram of (A) PI3Kα/JN-KI3; (B) PI3Kβ/JN-KI3; (C) PI3Kδ/JN-KI3; (D) PI3Kγ/JN-KI3 complexes.

(A) the 2D-structure labeled with atomic numbers; (B) the ligand RMSF value of JN-KI3; (C) the 3D-interaction diagrams between JN-KI3 and PI3Kγ before MD simulation (H-bond colored in green); (D) the 3D-interaction diagrams between JN-KI3 and PI3Kγ after MD simulation (H-bond colored in green).

## Section: Results and discussion › Performance of the VS model

Accumulative studies have shown that multi-conformational virtual screening, which could mimic the induced-fit effect of the protein, in a sequential or parallel manner could be the most appropriate to balance efficiency and precision of VS than the conventional VS, which usually uses single one protein with “rigid” structure to guarantee the optimum efficiency of VS. Therefore, 87 PI3Kγ crystallographic structures from PDB were collected and then divided into 10 conformational types after the clustering analysis. The complex with the highest resolution in each class was chosen and finally 10 representative complexes were selected, namely, 2A5U (Resolution: 2.70 Å) [22], 2V4L (2.50 Å) [52], 3DBS (2.80 Å) [53], 3ML8 (2.70 Å) [54], 3R7Q (2.50 Å) [55], 4FJY (2.90 Å) [56], 4FLH (2.60 Å) [57], 4PS7 (2.69 Å) [58], 4WWO (2.30 Å) [59] and 5G2N (2.68 Å) [60] (PDB ID). In order to estimate the precision and stability of these docking model systems, the “docking power” and “screening power” were evaluated, respectively. The “docking power”, which is a vital criterion of the reliability of molecular docking, presents the accuracy of poses prediction. For each PI3Kγ complex, the crystallized ligand was re-docked into the binding site and the RMSD between the docking pose and its original conformation was calculated. The results were tabulated in Table 1, the RMSD of ten PI3Kγ complexes were all<2.0 Å, which means that all of them contain remarkable predicting power through both Glide/SP or Glide/XP molecular docking methods.

On the other hand, the “screening power” was investigated, which exhibits an ability of the docking methods to distinguish the active PI3Kγ inhibitors from non-inhibitors. Herein, 800 PI3Kγ inhibitors with definite bio-activity and 16,000 non-inhibitors were chosen to make up a validation set. All compounds in the dataset were all docked into ten PI3Kγ proteins with SP and XP modes, respectively. The distributions of two docking scores of each protein were illustrated, and the T-test was carried out to evaluate the discrimination capacity of each protein with P-value. As shown in Table 1, both SP and XP could accurately distinguish the inhibitors from non-inhibitors for ten PI3Kγ proteins (P-value < 0.05), but overall, the performance of SP shows better than XP in each system, except 4WWO (Fig. 2). Take 2A5U as an example, the P-value of SP mode is 1.612 × 10-158, which is much<9.675 × 10-128, the P-value of XP. Some studies have demonstrated that even though XP is the extra precision mode of the Glide module and considered to be more accurate, the performance of SP is not always worse than it. Therefore, in our studied PI3Kγ systems, except 4WWO, SP mode with superior “screening power” would be adopted.

Next, the data matrix consisting of the docking scores from the above validation protocols was utilized to build the NBC model. The capability to distinguish between inhibitors and non-inhibitors for the NBC model was measured through the AUC value. Firstly, ten NBC models were constructed based on a single docking score for each complex, as summarized in Fig. 2K. The NBC model of 3DBS_SP (both inhibitors and non-inhibitors were docked into protein following Glide/SP protocol) shows the best predicting power and the AUC value is 0.814. The AUC value of each system is 0.768 (2A5U_SP), 0.766 (2V4L_SP), 0.775 (3ML8_SP), 0.803 (3R7Q_SP), 0.789 (4FJY_SP), 0.811 (4FLH_SP), 0.799 (4PS7_SP), 0.729 (4WWO_XP) and 0.807 (5G2N_SP), respectively (Fig. 2K). Generally, the AUC value > 0.7 indicates that the model contains a satisfactory prediction power, thus a novel NBC model based on the combined docking scores of the ten PI3Kγ proteins was built up, as shown in Fig. 2L, the AUC value of this model is as high as 0.906, showing an excellent prediction for PI3Kγ inhibitors.

The docking power, screening power, and crucial interactions of ten PI3Kγ crystal structures.

(A-J) Distributions of the docking scores of the inhibitor (red)/noninhibitor (green) for each PI3Kγ protein with the best discrimination power; (K) the ROC curve of the naive Bayesian classifier based on every single docking score; (L) the ROC curve of the naive Bayesian classifier based on the combined docking scores.

## Section: Results and discussion › JN-KI3 selectively inhibit PI3Kγ

The 49 pro-hits identified from VS were numbered as Cpd1 to Cpd49. The cell-free PI3Kγ inhibitory activities of these hits were firstly validated by ADP-Glo assay. The reported inhibitors, IPI-145 and LY294002, were tested as positive controls. The PI3Kγ-inhibitory activity of each hit was primitively validated at the concentration of 10 μM and the results were shown in Fig. 3A. At first glance, the marketed drug, IPI-145, showed the strongest inhibitory activity but it is encouraging that there are four hits with the inhibitory percent exceeding 50%, namely, Cpd5, JN-KI3 (Cpd14), Cpd36 and Cpd38. Among these four compounds, JN-KI3 has the most satisfying activity with almost 60% inhibitory percent to PI3Kγ, the 2D structure of JN-KI3 is illustrated in Table 2. The molecular docking results between these four compounds and PI3Kγ show that these compounds all form hydrogen bonds (H-bond) with Val882 of PI3Kγ (Fig. S2), Val882 have been identified as a core residue, which could form characteristic H-bond in almost all of the PI3Kγ/inhibitors complexes. Therefore, these four compounds all cause varying degrees of PI3Kγ inhibition. The alignment of the four compounds in the binding pocket shows JN-KI3 could form stronger hydrophobic interaction with PI3Kγ because of its chlorine phenyl group (Fig. S2A). The modeling results also reveal that JN-KI3 contains a novel scaffold different from the classical propeller-shaped core structure, like IPI-549. Then, the selective inhibition of JN-KI3 on other PI3K isoforms was evaluated and the potent pan-PI3K inhibitor, PI-103, was used as the positive control, the results summarized in Table 2. The IC50 value of JN-KI3 against PI3Kγ is 3,873 nM, whose inhibitory potency is near to LY294002. Though JN-KI3 shows lower bio-activity on PI3Ks than PI-103, encouragingly, it exhibits a significant specificity to PI3Kγ, as shown in Table 2, the IC50 values of JN-KI3 against other three isoforms are all>20,000 nM. Comparing to JN-PK1, which is an effective hit identified from our previous traditional VS work, JN-KI3 appeared not only a more significant PI3Kγ inhibitory activity, but also a higher selectivity against PI3Kγ. This result strongly proves that the VS integrated a machine learning based on multi-conformational PI3Kγ could effectively discover novel selective PI3Kγ inhibitors.

(A) The cell-free PI3Kγ inhibitory activities of 49 hits and two positive inhibitors, IPI-145 and LY294002; (B) the anti-proliferation effects towards multiple tumor cells of 49 hits and two positive inhibitors, IPI-145 and LY294002; (C) the anti-proliferation effects towards multiple tumor cells of JN-KI3 and IPI-145; (D) the anti-proliferation effects towards multiple malignant tumor cells of JN-KI3 with the gradient of concentrations.

The 2D-structures and the cell-free inhibitory activity values (IC50) of JN-KI3 and the positive reference compounds JN-PK1, PI-103, and LY294002.

## Section: Results and discussion › The promiscuity and ADMET assessments for JN-KI3

Pan-assay interference compounds (PAINS) analysis was used to investigate how far JN-KI3 could be flagged as a PAINS compound. PAINS refer to a series of promiscuous compounds specifically binding to different macromolecular targets and leading to misleading false-positive results in experimental assays. Therein, two available promiscuous predicting algorithms, Hit Dexter 2.0 and Badapple, were utilized to examine whether JN-KI3 could be categorized as PAINS. The detailed promiscuity analysis result of JN-KI3 using Hit Dexter 2.0 is available on the website (https://nerdd.zbh.uni-hamburg.de/hitdexter/result/c1ac770f-753e-455b-8c66-a5ed2337dbfd). JN-KI3 is predicted as non-promiscuous by the PSA (primary screening assays) classifier with a probability of 0.90 and the CDRA (confirmatory dose–response assays) classifier with a probability of 1.00 at moderate confidence. Besides, JN-KI3 shows the low promiscuous probability values even at high confidence, 0.26 for PSA, and 0.17 for CDRA (Fig. S3). It demonstrates that JN-KI3 would be a specific compound rather than a promiscuous one. Promiscuity screening data of Badapple are listed in Table 3. Scaf1, the indolyl group of JN-KI3, is found to have a pScore value higher than 300, accompanied with a “True” result inDrug database. The other scaffold, Scaf2, 1-phenyl-indole, presented a moderate pScore value with a “True” result inDrug database. These results suggest both promiscuity and drug-likeness probability of JN-KI3. However, no pScore was generated for Scaf3 and Scaf4, and the inDrug values are both “False”, indicating the absence of the scaffolds in the drug database.

Besides, in silico ADMET of JN-KI3 were calculated to predict the pharmacochemical properties. Table 3 shows that almost all properties are within the acceptable range. For instance, all the logP values are within the optimal range, the human oral absorption (PHOA) of JN-KI3 is close to the highest recommended values,100%. All these predictions indicate that JN-KI3 exhibits optimum drug-like properties.

The pScore and inDrug values from Badapple data base, and the predicted ADMET properties of JK-KI3.

## Section: Results and discussion › JN-KI3 selectively anti-proliferate against hematologic cancer cells

At the same time, the anti-proliferative activity of each hit towards different human cancer cells was evaluated, including breast cancer cells (MDA-MB-231, MCF-7), pancreatic cancer cell (Patu8988), liver cancer cell (HepG2), ovarian cancer cells (A2780, 3AO), colon cancer cells (LOVO, HCT-8, SW480), lung cancer cells (A549, H1299), gastric cancer cell (MGC-803), and hematologic malignancies cells (HL-60, U266, OPM2, PRMI-8226, NCI-H929, Jurkat, LP-1, CCRF-CEM, K562, U937). IPI-145 and LY294002 were still used as positive controls. The anti-proliferative activity of each hit was shown as the livability of the cells. Fig. 3B shows that there are three hits considerably inhibiting the proliferation of some cancer cell lines. To be specific, Cpd5 could suppress the proliferation of acute promyelocytic leukemia (HL-60), Cpd13 could inhibit chronic myelogenous leukemia (K562). It is a pity that the results from the cellular experiments are not in good agreement with those of above cell-free assays, such as Cpd36 and Cpd38, which show little anti-tumor effect. But luckily, JN-KI3 show potently suppressed proliferation in some cell lines and more interestingly, JN-KI3 seems to prefer to inhibit the proliferation of hematologic cancer cell lines, such as K562 and multiple myeloma cell lines (RPMI-8226 and U937), and the inhibition effect is even stronger than IPI-145 (Fig. 3C). As discussed above, PI3Kγ is mainly distributed and expressed in the hematopoietic systems, that may lead to the specific inhibition against hematologic cancer cell lines. To test this hypothesis, more hematologic tumor cell lines were treated with JN-KI3, including four human leukemia cells (HL-60, Jurkat, CCRF-CEM, K562), four multiple myeloma cells (OPM2, OCI-My5, LP-1, RPMI-8226) and one lymphoma cells (U937). As shown in Fig. 3D, the proliferation of all cells was decreased in a concentration-dependent manner, especially K562, which show significant sensitivity to JN-KI3 at a low concentration.

## Section: Results and discussion › JN-KI3 induce apoptosis of hematologic cancer cells with selective inhibition on PI3K/AKT signaling pathway

As it has been widely reported that PI3Kγ/AKT signaling pathway play central roles in regulating the survival and proliferative activities in hematologic malignancies. To investigate the inhibition of JN-KI3 to PI3K at the cellular level, immunoblotting assays were performed with the two sensitive cell lines, K562, and RPMI-8226 (8226). AKT is a node protein downstream of the PI3K signaling pathway. The inhibition of PI3Kγ kinase activity can suppress the phosphorylation of AKT at Thr308 and Ser473 sites. Thus, the inhibitory activity against PI3K of JN-KI3 at a cellular level was verified using AKT phosphorylation as a readout. As shown in Fig. 4A & B, after treating with the increasing concentration of JN-KI3 for 24 h, AKT phosphorylation at Thr308 and Ser473 sites in K562 and 8226 cell lines were both markedly decreased, and the inhibition was caused even at a concentration as low as 2.5 μM, while the expression of total AKT (t-AKT) was not affected. In addition, both K562 and 8226 cell lines were treated with 20 μM JN-KI3 for the indicated time periods. As shown in Fig. 4C & D, the phosphorylation level of AKT at both sites was significantly inhibited with the prolongation of the time of JN-KI3 action. Similarly, t-AKT was not markedly affected. All the above results indicated that JN-KI3 would effectively inhibit PI3K/AKT signaling with a concentration- and time-dependent manners in hematologic cancer cells.

Those above results suggested that JN-KI3 could specifically inhibit PI3Kγ both at the cell-free and the cellular level, and it selectively suppressed hematologic cancer cells. To further demonstrate whether JN-KI3 could induce the apoptosis of hematologic cells with the inhibition of PI3Kγ, K562 and 8226 were treated with JN-KI3 with increased duration or concentrations, and the relative levels of two apoptosis biomarkers, PARP (poly ADP-ribose polymerase) and caspase-3 were detected and the results were illustrated in Fig. 4. Caspase-3 belongs to the caspase family of cysteine proteases, which are the key mediators of cell apoptosis. Caspase-3 cleaves the death substrate PARP to a specific 89 kDa form observed during apoptosis. Fig. 4A & B show that after incubating with the increasing concentrations of JN-KI3, the cleavage levels of PARP and caspase-3 in K562 and 8226 cell lines were obviously increased and showing in the dependent manner of concentration. Then, a time-course study was conducted, and both K562 and 8226 treated with 20 μM JN-KI3 activated the PARP and caspase-3 following increased incubation time (Fig. 4C & D). The results demonstrated that the cleavage level of Caspase-3 and PARP in both cell lines significantly increased after a short time (6 h) of incubation with JN-KI3.

To further observe the induction of apoptosis by JN-KI3, Annexin V-FITC/PI double staining was performed to K562 and 8226 treated with increasing concentrations of JN-KI3 for 24 h, and then flow cytometry was utilized to observe the apoptotic cancer cells. As shown in Fig. 4E, JN-KI3 could induce the apoptosis of K562 at considerably low concentration, there was 41.2%, 47.5% and 65.7% of K562 cells occurring apoptosis after treating with 2.5, 5 and 10 μM JN-KI3 for 24 h, respectively. Comparing to K562, 8226 presented moderate cellular apoptosis, about 20.43% of 8226 cells occurred definite apoptosis at a JN-KI3 concentration up to 10 μM (Fig. 4F). These results are good agreement with those in cell proliferation bioassay. To sum up, JN-KI3 could induce apoptosis of hematologic cancer cells in association with its potent PI3Kγ inhibition.

JN-KI3 inhibited PI3K/AKT signaling pathway and induced apoptosis of (A) K562 and (B) RPMI-8226 cell lines at different concentrations from 0 to 20 μM after 24 h incubation. JN-KI3 inhibited PI3K/AKT signaling pathway and induced apoptosis of (C) K562 and (D) RPMI-8226 cell lines at different times from 0 to 24 h for 20 μM concentration. JN-KI3 induced apoptosis of hematologic malignancies illustrating by flow cytometry. Apoptosis of (E) K562 and (F) RPMI-8226 cell lines treated with different concentrations of JN-KI3 (from 0 μM to 10 μM) for 24 h.

## Section: Results and discussion › Theoretical studies on the PI3Kγ selective inhibition mechanism of JN-KI3

In order to reveal the mechanism of selective inhibition of PI3Kγ by JN-KI3 at a molecular level, a computational strategy integrating molecular docking, MD simulation and free energy calculations was employed. JN-KI3 was firstly docked into the ATP-binding pocket of four PI3K isoforms and the docking scores were listed in Table 4. It is delighted to find that the docking scores are consistent with the experimental inhibitory activities. The docking score of PI3Kγ/JN-KI3 is −7.841 kcal/mol, which is higher than those of PI3Kα/JN-KI3 (-6.730 kcal/mol), PI3Kβ/JN-KI3 (-6.640 kcal/mol) and PI3Kδ/JN-KI3 (-6.018 kcal/mol). It roughly demonstrated that JN-KI3 has a stronger binding affinity to PI3Kγ than the other three PI3K isoforms.

To further estimate the dynamic behavior of PI3Ks after binding to JN-KI3, the MD simulations were implemented and the docking poses from molecular docking studies (Fig. S4) were served as initial structures. The backbone RMSD values of four complexes were illustrated in Fig. S5, which indicated each system reached equilibrium in a short time after the simulations began. When the systems were stable, MM/GBSA method was utilized to calculate the binding free energy of each system. All results are listed in Table 4. The binding free energies of PI3Kα/JN-KI3, PI3Kβ/JN-KI3, PI3Kδ/JN-KI3, and PI3Kγ/JN-KI3 are −42.832, −36.875, −49.441 and −64.981 kcal/mol, respectively. The predicted binding free energy of PI3Kγ/JN-KI3 is greatly lower than the other three systems, which suggest that JN-KI3 binds to PI3Kγ most tightly and it agrees with the above experimental and docking results.

To further uncover the interaction modes between JN-KI3 and PI3Ks in a dynamic process, the dominant interactions, including H-bond, hydrophobic, ionic interactions (Ionic) and hydrogen bonds through water molecular bridge (Water Bridge), between key residues of each PI3K isoform and JN-KI3 were elucidated. As shown in Fig. 5, the carbonyl group of JN-KI3 formed an H-bond with Val residue in all four PI3K isoforms, namely, Val851α, Val848β, Val828δ, and Val882γ. After a sequence comparison and structural alignment, it suggested that these Val residues were conserved and located at the similar position at the hinge region within the ATP-binding pocket in all four isoforms. The hinge region is one of the four well-depicted regions in the ATP-binding pocket playing a significant role in determining the binding affinities between PI3Ks and small molecular inhibitors. As for PI3Kα/JN-KI3, there were hydrophobic interactions between Trp780/Ile800/Ile932 and JN-KI3 (Fig. 5A). As for PI3Kβ/JN-KI3, Glu852 and Asp856 formed Water Bridge interactions with the free hydroxyl group and the secondary amino group of JN-KI3, respectively. Moreover, Ile930 formed a hydrophobic interaction with JN-KI3 (Fig. 5B). As for PI3Kδ/JN-KI3, Trp760 formed a Pi-Pi interaction with the indole ring of JN-KI3, which almost dominated the nonpolar contribution in PI3Kδ. In addition, there was a Water Bridge between Asp832 and JN-KI3 (Fig. 5C). As for PI3Kγ/JN-KI3, except for Val882, Thr887 formed an H-bond with the free hydroxyl group of JN-KI3, and Thr886 formed another H-bond with the free amino group of JN-KI3. As far as we know, these characteristic H-bonds are less common compared to most of the reported PI3K inhibitors. Besides, there were two strong hydrophobic interactions between Met953/Ile963 and JN-KI3 (Fig. 5D). Thus, the extra H-bonds and the stronger hydrophobic interactions between JN-KI3 and PI3Kγ were deemed as the critical reason for the PI3Kγ selective inhibition of JN-KI3.

Finally, the RMSF value of each atom of JN-KI3 was calculated, the atoms forming potent interactions with PI3Ks would be imped to fluctuate and thus show extremely low values. As a whole, JN-KI3 exhibited less fluctuate in PI3Kγ system (Fig. 6B), and it indicated JN-KI3 preferred to bind to PI3Kγ. Specifically, the carbonyl group (atom index: 11 and 12), the indole ring (atom index: 1–9), P-methylphenyl at 9 position (atom index: 14–20) were all bind to PI3Ks with almost same interacted effect (green colored in Fig. 6A). Comparing the binding poses before and after the MD simulation, these groups show little fluctuation in the PI3Kγ binding region (Fig. S6). The H-bond was always maintained between Val882 and the carbonyl group, while Met953 and Ile963 still form strong hydrophobic interactions with JN-KI3 (Fig. 6C & D). Therefore, this motif of JN-KI3 is vital for the satisfactory binding affinity to PI3Kγ. However, the motif colored in red of JN-KI3 presented weak interactions with class IA PI3K isoforms, especially the chlorine phenyl (atom index: 26–32 and 34). Interestingly, the RMSF values of these atoms in PI3Kγ/JN-KI3 were far lower than the values in other systems. On the other hand, the H-bond between JN-KI3 and Ala885 lost after MD simulation (Fig. 6C), the motif including chlorine phenyl (atom index: 21–34) had significant ligand torsions (Fig. S6C), that made the motif prefer to bias Thr886 and Thr887, and lastly formed two strong H-bonds with these two residues (Fig. 6D). Thus, all these results are supposed to be responsible for the PI3Kγ selective inhibition of JN-KI3.

The docking scores and predicted binding free energies of JN-KI3/PI3Ks, and the inhibitory activities against PI3Ks of JN-KI3.

2D interaction patterns and protein–ligand occupancy histogram of (A) PI3Kα/JN-KI3; (B) PI3Kβ/JN-KI3; (C) PI3Kδ/JN-KI3; (D) PI3Kγ/JN-KI3 complexes.

(A) the 2D-structure labeled with atomic numbers; (B) the ligand RMSF value of JN-KI3; (C) the 3D-interaction diagrams between JN-KI3 and PI3Kγ before MD simulation (H-bond colored in green); (D) the 3D-interaction diagrams between JN-KI3 and PI3Kγ after MD simulation (H-bond colored in green).

## Section: Conclusion

In the present study, a machine learning-based VS with multiple protein structures was developed to screen against a large chemical library. This integrated VS model exhibits more precision prediction through mimicking the induced-fit effect of drug target than conventional VS, and the sequential manner during this protocol could be more appropriate to balance the efficiency and precision of VS. The developed NBC model integrating ten PI3Kγ proteins showed a satisfactory prediction power against PI3Kγ inhibitors with the AUC value as high as 0.906, indicating that the VS with multiple PI3Kγ structures would get much better performance and higher enrichment rate than that based on any single PI3Kγ structure. After the evaluation of drug-likeness with the Lipinski and Veber rules and REOS, 49 VS-hits interacting with the “hot residues” within the ATP binding pocket of PI3Kγ were screened out, and then, all compounds were submitted to a series of bio-assay studies. Firstly, the PI3Kγ inhibitory activities of these hits were preliminarily validated by the cell-free assay, and four (4 in 49) compounds show over 50% inhibitory percent at a concentration of 10 μM. Among them, JN-KI3 exhibits the most potent selective PI3Kγ inhibitory bioactivity, the IC50 against PI3Kγ is 3,873 nM. And, even more crucially, JN-KI3 shows a significant specificity to PI3Kγ, while there is no inhibitory effect on Class IA PI3Ks even at concentrations higher than 20,000 nM. It suggests that the novel integrated VS strongly manifests the robustness to find new PI3Kγ inhibitors. Meanwhile, the in silico PAINS and ADMET assessments indicated that JN-KI3 contains appropriate drug-like properties. Subsequently, dozens of common human cancer cell lines were treated with JN-KI3, respectively, and it is interesting that JN-KI3 prefers to inhibit the proliferation of hematologic cancer cell lines, the inhibition effect on some hematologic cancer cells is even stronger than IPI-145, which is consistent with the main distribution and expression of PI3Kγ in the hematopoietic systems. Therefore, PI3Kγ would be a suitable therapeutic target for hematologic cancers. Immunoblotting analysis revealed that JN-KI3 would effectively inhibit PI3K/AKT signaling with concentration- and time-dependent manners in hematologic cancer cells even at a low concentration. The further studies at the cellular models show that JN-KI3 could significantly induce apoptosis of hematologic cancer cells. The potent selective inhibition on PI3Kγ of JN-KI3 resulted in the significant cleavage of two apoptosis biomarkers, PARP and caspase-3, and finally led to distinct apoptosis of the cell lines with dose- and time-dependent manners. Lastly, the selective inhibition mechanism of JN-KI3 against PI3Kγ was uncovered by a theoretical study combining molecular docking, MD simulation, and free energy calculations. The results reveal that JN-KI3 contains the highest binding free energy against PI3Kγ than Class IA isoforms, which is in good agreement with the experimental bioactivities. In addition, some key residues influencing γ isoform-selective inhibition of JN-KI3 were highlighted, such as Val882, Thr886, Thr887, Met953, and Ile963, these key interactions are less common compared to most of the reported PI3Kγ inhibitors, indicating that JN-KI3 has novel structural characteristics as a selective PI3Kγ inhibitor. On the other hand, some structural features of JN-KI3 critical to the γ-isoform preferred binding affinity were outstood, the chlorine phenyl of JN-KI3 formed stronger interactions with PI3Kγ than Class IA isoforms, which makes a favorable contribution for specific inhibition on PI3Kγ. All results could provide some significant guidance for the further rational design of JN-KI3.

## Section: Author Contributions

ZJ, LH, HG, JJ developed the study concept and design. LK performed the modeling studies and the bio-assay evaluation. ZJ, LK, ZX carried out the data analysis. XL provided software. ZJ, LK, CY drafted the manuscript, CY, LH, HG, JJ approved the manuscript.

## Section: Declaration of Competing Interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

## Section: Acknowledgments

The study was supported by the National Natural Science Foundation of China (No. 21807049, 81803430, and 81830052), the Fundamental Research Funds for the Central Universities (JUSRP51703A), the Postgraduate Research & Practice Innovation Program of Jiangsu Province (KYCX19_1888), the Top-notch Academic Programs Project of Jiangsu Higher Education Institutions (PPZY2015B146), the Construction Project of Shanghai Key Laboratory of Molecular Imaging (18DZ2260400), and the Shanghai Municipal Education Commission (Class II Plateau Disciplinary Construction Program of Medical Technology of SUMHS, 2018-2020).

## Section: Contributor Information

Jingyu Zhu, Email: jingyuzhu@jiangnan.edu.cn.

Gang Huang, Email: huanggang@sumhs.edu.cn.

Jian Jin, Email: jianjin@jiangnan.edu.cn.

## Section: Supplementary material

The following are the Supplementary data to this article:


---

# Enhancing preclinical drug discovery with artificial intelligence

- **Authors:** R S K Vijayan, Jan Kihlberg, Jason B Cross, Vasanthanathan Poongavanam
- **Issuer:** Drug discovery today
- **Type:** Scientific article
- **Published:** 2021-11-25
- **Language:** en
- **DOI:** 10.1016/j.drudis.2021.11.023
- **Source:** https://pubmed.ncbi.nlm.nih.gov/34838731/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Artificial intelligence (AI) is becoming an integral part of drug discovery. It has the potential to deliver across the drug discovery and development value chain, starting from target identification and reaching through clinical development. In this review, we provide an overview of current AI technologies and a glimpse of how AI is reimagining preclinical drug discovery by highlighting examples where AI has made a real impact. Considering the excitement and hyperbole surrounding AI in drug discovery, we aim to present a realistic view by discussing both opportunities and challenges in adopting AI in drug discovery.


---

# Evaluating the Accuracy of Breast Cancer and Molecular Subtype Diagnosis by Ultrasound Image Deep Learning Model

- **Authors:** Xianyu Zhang, Hui Li, Chaoyun Wang, Wen Cheng, Yuntao Zhu, Dapeng Li, Hui Jing, Shu Li, Jiahui Hou, Jiaying Li, Yingpu Li, Yashuang Zhao, Hongwei Mo, Da Pang
- **Issuer:** Frontiers in oncology
- **Type:** Scientific article
- **Published:** 2021-03-05
- **Language:** en
- **DOI:** 10.3389/fonc.2021.623506
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33747937/
- **Licence:** CC-BY

## Section: Abstract

Background: Breast ultrasound is the first choice for breast tumor diagnosis in China, but the Breast Imaging Reporting and Data System (BI-RADS) categorization routinely used in the clinic often leads to unnecessary biopsy. Radiologists have no ability to predict molecular subtypes with important pathological information that can guide clinical treatment.Materials and Methods: This retrospective study collected breast ultrasound images from two hospitals and formed training, test and external test sets after strict selection, which included 2,822, 707, and 210 ultrasound images, respectively. An optimized deep learning model (DLM) was constructed with the training set, and the performance was verified in both the test set and the external test set. Diagnostic results were compared with the BI-RADS categorization determined by radiologists. We divided breast cancer into different molecular subtypes according to hormone receptor (HR) and human epidermal growth factor receptor 2 (HER2) expression. The ability to predict molecular subtypes using the DLM was confirmed in the test set.Results: In the test set, with pathological results as the gold standard, the accuracy, sensitivity and specificity were 85.6, 98.7, and 63.1%, respectively, according to the BI-RADS categorization. The same set achieved an accuracy, sensitivity, and specificity of 89.7, 91.3, and 86.9%, respectively, when using the DLM. For the test set, the area under the curve (AUC) was 0.96. For the external test set, the AUC was 0.90. The diagnostic accuracy was 92.86% with the DLM in BI-RADS 4a patients. Approximately 70.76% of the cases were judged as benign tumors. Unnecessary biopsy was theoretically reduced by 67.86%. However, the false negative rate was 10.4%. A good prediction effect was shown for the molecular subtypes of breast cancer with the DLM. The AUC were 0.864, 0.811, and 0.837 for the triple-negative subtype, HER2 (+) subtype and HR (+) subtype predictions, respectively.Conclusion: This study showed that the DLM was highly accurate in recognizing breast tumors from ultrasound images. Thus, the DLM can greatly reduce the incidence of unnecessary biopsy, especially for patients with BI-RADS 4a. In addition, the predictive ability of this model for molecular subtypes was satisfactory,which has specific clinical application value.

## Section: Introduction

Breast cancer is the most common malignant tumor in women in China (1, 2). Breast ultrasound is more suitable for tumor discovery in Asian women considering the higher breast density (3, 4) and the younger age at diagnosis (5, 6). Patients with Breast Imaging Reporting and Data System (BI-RADS) 4a or higher findings are usually recommended to undergo core needle biopsy or surgery. BI-RADS has a wide range of possibilities to predict the presence of malignancies, but its false positive findings lead to unnecessary biopsies in a large number of individuals without breast cancer (7).

The combination of deep learning (8) and large datasets has shown good performance in the diagnosis of many diseases, including cancer (9–12). The deep learning model (DLM) takes the original image pixels and corresponding category labels in medical image data as inputs and does not require manual design features required by traditional methods but automatically learns features related to category classification (13).

Based on receptor status, breast cancers are divided into five subtypes (14). If the molecular subtype is identified before surgery, we can determine whether the patient is suitable for neoadjuvant treatment and which scheme should be more efficient. However, currently, we cannot obtain subtype information through traditional ultrasound examinations.

In addition to the differentiation of benign and malignant breast tumors from ultrasound images, previous studies have focused on the correlation between imaging features and molecular subtypes. Breast cancers with the triple-negative subtype were more likely to be associated with circumscribed margins and were less associated with calcifications (15–18). Human epidermal growth factor receptor 2 (HER2) (+) breast cancers usually show enhanced posterior acoustics on ultrasound images (15, 17). Tumors with posterior shadowing are often found in hormone receptor (HR) (+) HER2 (–) breast cancers (16, 19, 20). In addition, echogenic halos were frequently present in the HR (+) HER2 (–) subtype (17, 20). Due to the various imaging features of different subtypes, there is potential to predict molecular subtypes with DLM by analyzing only the ultrasound images.

In this study, we constructed a DLM based on ultrasound images. We obtained a higher accuracy for breast tumor diagnosis with the DLM than with radiologists. We obtained a good prediction for tumor molecular subtypes, which may provide more choices for therapy.

## Section: Materials and Methods

This study was approved by the Institutional Review Board of Harbin Medical University Cancer Hospital. Because of its retrospective nature, the study was exempt from obtaining informed consent from patients.

Cohort selection flowchart and the composition of the training, test and external test sets. The black rectangles represent the process of data selection. The orange rectangles represent the composition of datasets for the diagnosis of breast tumors. The blue rectangles represent the composition of datasets used to predict the molecular classification of breast cancer. n, the number of images; N, the number of patients; M, malignant; B, benign; HER2, human epidermal growth factor receptor 2; HR, hormone receptor.

Some samples of breast ultrasound images from the datasets. In the first column, the samples were divided according to the diagnosis results of the tumor, which were benign and malignant; in the second column, the samples were classified according to molecular subtypes, which were divided into images of HR (+) subtype, HER2 (+) subtype, and triple-negative subtype. HR, hormone receptor; HER2, human epidermal growth factor receptor 2.

Structural diagram of the transfer learning model for breast cancer ultrasound images. CNN-1 represents the classification model trained on the ImageNet dataset, which is divided into 1,000 categories of natural images. CNN-2 is the benign and malignant tumor diagnostic model obtained by model transfer and retraining on the basis of the CNN-1 model, and CNN-3 is the classification model of tumor molecular subtypes obtained by model transfer and retraining on the basis of the CNN-2 model. CNN, convolution neural network.

## Section: Materials and Methods › Datasets

We obtained original ultrasound images for the training and testing datasets from the breast image database of Harbin Medical University Cancer Hospital (a total of 17,226 images from 2,542 patients). All patients underwent surgical treatment with definitive pathological results. The cohort selection flowchart is shown in Figure 1. Patients in the external test set were enrolled from The First Affiliated Hospital of Harbin Medical University and were selected with the same criteria as those for the training and test sets. Exclusion criteria for the datasets are described in the Supplementary Material.

We selected ultrasound images of breast cancer patients with corresponding pathological results. We excluded tumors with incomplete immunohistochemistry results and then separated the tumors into molecular subtypes. Data on estrogen receptor (ER) and progesterone receptor (PR) expression were collected. Patients with positivity for either or both receptors were defined as being HR positive. According to the expression of two indicators, HR and HER2, we regrouped patients into three molecular subtypes: HER2 (+) subtype, HR (+) subtype and triple-negative subtype. HER2 (+) subtype = HR (+) HER2 (+) or HR (–) HER2 (+); HR (+) subtype = HR (+) HER2 (–); triple-negative subtype = HR (–) HER2 (–).

In Figure 2, we listed some samples of breast ultrasound images from the datasets, which were presented by classification of benign and malignant tumors and molecular subtypes.

The training and test sets were formed by a random sampling method at a ratio of 4:1. The compositions of these sets are shown in Figure 1. It is noteworthy that within the training set, we redivided it into a new training set and a validation set for model tuning and training at a ratio of 4:1. The optimal model obtained was tested with the test set and the external test set.

Cohort selection flowchart and the composition of the training, test and external test sets. The black rectangles represent the process of data selection. The orange rectangles represent the composition of datasets for the diagnosis of breast tumors. The blue rectangles represent the composition of datasets used to predict the molecular classification of breast cancer. n, the number of images; N, the number of patients; M, malignant; B, benign; HER2, human epidermal growth factor receptor 2; HR, hormone receptor.

Some samples of breast ultrasound images from the datasets. In the first column, the samples were divided according to the diagnosis results of the tumor, which were benign and malignant; in the second column, the samples were classified according to molecular subtypes, which were divided into images of HR (+) subtype, HER2 (+) subtype, and triple-negative subtype. HR, hormone receptor; HER2, human epidermal growth factor receptor 2.

## Section: Materials and Methods › Development of the DLM

All images in the datasets were 8-bit and 3-channel images, so they could be used as training set and test set images to fine-tune the deep convolutional neural network (DCNN) directly. Supplementary Figure 1 shows the whole process of breast ultrasound image analysis.

To obtain a better deep learning effect, the necessary image preprocessing algorithm was used to improve the image quality. In the image preprocessing of the Supplementary Material, we specifically described how to carry out preprocessing of breast ultrasound images.

Considering the amount of data compared with the depth of deep learning, we used data enhancement to enhance the diversity and generalization of the data. We used data enhancement in the Keras model, which could enhance the real-time data with the help of a central processing unit (CPU) during training. Due to the particularity of the ultrasound image data, we used four kinds of random operations to enhance the data: vertical rotation, horizontal rotation, center rotation, and scale reduction.

Because the data had enough high-quality samples after preprocessing and expansion, we used the deep learning Keras framework to transfer and fine-tune the Xception network, making it a network that could extract features for breast ultrasound images (21). The Xception convolution neural network (CNN) has trained more than 1.2 million images from the ImageNet large-scale vision recognition challenge (ILSVRC) knowledge base.

The structure of the Xception model mainly consisted of a convolutional layer and a fully connected classification layer. Figure 3 shows the structure diagram of our model training, which mainly adopted the transfer learning method to train the model. CNN-1 represented the training model on the ImageNet dataset and outputted 1,000 classification results. The CNN-2 model was obtained through transfer learning of the CNN-1 model and used for the classification of benign and malignant breast tumors by ultrasound images. The specific model training method was to freeze the convolutional layer parameters of CNN-2 and then train the fully connected layer of the CNN-2 model. After the training was stable, we defrosted the convolutional layer for retraining to achieve the best effect. CNN-3 was a classification model of molecular subtypes, which was acquired from the transfer learning of the CNN-2 model. Two specific training parameters are shown in the Supplementary Material.

Structural diagram of the transfer learning model for breast cancer ultrasound images. CNN-1 represents the classification model trained on the ImageNet dataset, which is divided into 1,000 categories of natural images. CNN-2 is the benign and malignant tumor diagnostic model obtained by model transfer and retraining on the basis of the CNN-1 model, and CNN-3 is the classification model of tumor molecular subtypes obtained by model transfer and retraining on the basis of the CNN-2 model. CNN, convolution neural network.

## Section: Materials and Methods › Statistical Analysis

Evaluation of the DLM was performed with R version 3.5.1. For binary classification in discriminating breast cancer patients from controls, a classification matrix (caret version 6.0–80) and the receiver operating characteristic (ROC) curve (pROC version 1.13.0) were generated to visualize the diagnostic ability of the DLM. For the triple classification of the three molecular subtypes, a classification matrix and the ROC curve using a one-vs-all approach (multiROC version 1.1.1) were generated. The area under the curve (AUC), accuracy, sensitivity, and specificity were calculated to compare the predictive performance between the DLM and BI-RADS classification systems in the test and external test sets. P < 0.05 was considered to indicate a statistically significant difference. Moreover, the calculation of sample size is shown in the Supplementary Material.

## Section: Results

Confusion matrices of the test set and external test set.

Identification performance of BI-RADS and the DLM on the test set and external test set.

Identification performance of the DLM on the test set (A) and external test set (B). The blue dot on the left ROC curve indicates the performance of BI-RADS. DLM, deep learning model; ROC, receiver operating characteristic; BI-RADS, Breast Imaging Reporting and Data System; AUC, area under the curve.

Diagnostic results of the DLM for breast tumors with different BI-RADS categorizations compared with the definitive pathological results. (A) The width of the extended branches corresponds to the size of the data; 70.76% represents the percentage of BI-RADS 4a patients diagnosed as benign by the DLM; 29.24% represents the percentage of BI-RADS 4a patients diagnosed as malignant by the DLM. (B) The numbers in this graph represent the number of images; 92.86% represents the diagnostic accuracy of BI-RADS 4a patients with the DLM; 67.86% represents the reduction rate of unnecessary biopsy in BI-RADS 4a patients with the DLM; 10.4% represents the false negative rate of BI-RADS 4a patients with the DLM. Negative means the diagnosis of the DLM is benign. Positive means the diagnosis of the DLM is malignant. DLM, deep learning model; BI-RADS, Breast Imaging Reporting and Data System.

Performance of the DLM in identifying different molecular subtypes with triple classification on the test set. HER2 (+) subtype = HR (+) HER2 (+) or HR (–) HER2 (+); HR (+) subtype = HR (+) HER2 (–); triple-negative subtype = HR (–) HER2 (–). DLM, deep learning model; HER2, human epidermal growth factor receptor 2; HR, hormone receptor.

## Section: Results › Cohort Composition

We divided the ultrasound images collected from Harbin Medical University Cancer Hospital into two sets (Figure 1). The training set was composed of 2,822 images, including 1,786 images from 1,217 patients with malignant tumors and 1,036 images from 603 patients with benign tumors. The test set was composed of 707 images, including 447 images from 392 patients with malignant tumors and 260 images from 228 patients with benign tumors. After applying the same exclusion criteria, external test set images were collected from The First Affiliated Hospital of Harbin Medical University, including 93 images from 38 patients with malignant tumors and 117 images from 45 patients with benign tumors.

Two datasets were used for molecular subtype prediction (Figure 1). The training set consisted of 212 images from 149 HER2 (+) subtype patients, 588 images from 417 HR (+) subtype patients and 186 images from 118 triple-negative subtype patients. The test set comprised 54 images from 47 HER2 (+) subtype patients, 148 images from 135 HR (+) subtype patients and 47 images from 40 triple-negative subtype patients.

## Section: Results › Performance in Diagnosis

The DLM was more accurate (0.897, 95% CI: 0.872–0.918) than ultrasound doctors (0.856, 95% CI: 0.828–0.881) (P = 0.024) (Tables 1, 2). The doctors used the malignant probability and BI-RADS system to determine positive ultrasound findings. For sensitivities, 91.3 and 98.7% (P < 0.001) were achieved for the DLM and BI-RADS systems, respectively. However, the specificity of the DLM (86.9%) was significantly higher than that of BI-RADS (63.1%) (P < 0.001). This result indicates that the DLM may reduce the unnecessary biopsy of false positive findings with the BI-RADS system. For the test set, the AUC was 0.96. For the external test set, the AUC was 0.90 (Figure 4). These results suggest that the DLM has good performance in breast cancer diagnosis.

Confusion matrices of the test set and external test set.

Identification performance of BI-RADS and the DLM on the test set and external test set.

Identification performance of the DLM on the test set (A) and external test set (B). The blue dot on the left ROC curve indicates the performance of BI-RADS. DLM, deep learning model; ROC, receiver operating characteristic; BI-RADS, Breast Imaging Reporting and Data System; AUC, area under the curve.

## Section: Results › Reducing Unnecessary Biopsy

Each ultrasound image had corresponding BI-RADS, DLM, and pathological results. The proportion of all patients with BI-RADS 4a judged as benign (70.76%) by the DLM was greater than that judged as malignant (29.24%) (Figure 5A). This result indicated that 70.76% of BI-RADS 4a patients did not need surgery when diagnosed using the DLM. The diagnostic accuracy for BI-RADS 4a patients reached 92.86%, and unnecessary biopsy was reduced by 67.86%, with a false negative rate of 10.4% for the DLM (Figure 5B). These findings suggest that the DLM can greatly reduce the incidence of unnecessary biopsy, especially for BI-RADS 4a patients with a low false negative rate.

Diagnostic results of the DLM for breast tumors with different BI-RADS categorizations compared with the definitive pathological results. (A) The width of the extended branches corresponds to the size of the data; 70.76% represents the percentage of BI-RADS 4a patients diagnosed as benign by the DLM; 29.24% represents the percentage of BI-RADS 4a patients diagnosed as malignant by the DLM. (B) The numbers in this graph represent the number of images; 92.86% represents the diagnostic accuracy of BI-RADS 4a patients with the DLM; 67.86% represents the reduction rate of unnecessary biopsy in BI-RADS 4a patients with the DLM; 10.4% represents the false negative rate of BI-RADS 4a patients with the DLM. Negative means the diagnosis of the DLM is benign. Positive means the diagnosis of the DLM is malignant. DLM, deep learning model; BI-RADS, Breast Imaging Reporting and Data System.

## Section: Results › Molecular Subtype Prediction

The DLM can be used not only in the diagnosis of breast cancer but also in the prediction of molecular subtypes. From the results of the triple classification, the triple-negative subtype reached the highest AUC of 0.864. The AUC of the HER2 (+) subtype was 0.811, and the AUC of the HR (+) subtype was 0.837 (Figure 6). Accuracy of the HR (+) subtype (85.14%) was significantly higher than that of the HER2 (+) subtype (50%) and triple-negative subtype (53.19%) (Supplementary Table 1).

Performance of the DLM in identifying different molecular subtypes with triple classification on the test set. HER2 (+) subtype = HR (+) HER2 (+) or HR (–) HER2 (+); HR (+) subtype = HR (+) HER2 (–); triple-negative subtype = HR (–) HER2 (–). DLM, deep learning model; HER2, human epidermal growth factor receptor 2; HR, hormone receptor.

## Section: Discussion

We successfully established a DLM for breast cancer diagnosis and molecular subtype prediction based on ultrasound images. The accuracy of the DLM in the diagnosis of breast cancer was higher than that of BI-RADS, and the DLM performed well in both the test set and external test set. The DLM can apparently reduce unnecessary biopsy for patients with BI-RADS 4a. In the predictive results of the DLM for the molecular subtypes of breast cancer, we could see that its performance for various subtypes was ideal, and there were no significant disparities among them.

In many studies of cancer diagnosis, the accuracy of DLMs is higher than that of radiologists. Li et al. successfully developed a DCNN model for the diagnosis of thyroid cancer with ultrasound images. The accuracy was 89.8% with the DCNN model vs. 78.8% with radiologists (22). To classify invasive adenocarcinomas from preinvasive lesions, Wang et al. (23) developed a CNN model. The accuracy of the model (84%) was higher than that of three radiologists (radiologist 1: 80.2%; radiologist 2: 80.7%; and radiologist 3: 81.7%). He et al. used a CNN to predict the local recurrence of giant cell bone tumors. The accuracy of the CNN model was 75.0%, while the accuracy of radiologists was 64.3% (24). Our study had similar results. The DLM was more accurate (0.897, 95% CI: 0.872–0.918) than radiologists (0.856, 95% CI: 0.828–0.881) (P = 0.024). In summary, the DLM performed well and has the potential to provide better diagnostic results than radiologists.

At present, there are few studies on the diagnosis of breast cancer with DLMs based on ultrasound images. In recent studies, researchers used different DLMs to diagnose breast tumors on ultrasound images, and the one that performed best was selected after comparison. The purpose of these studies was to develop only a DLM for the classification of malignant and benign masses (25–29). In our study, we sought to develop a DLM not only for classifying masses but also for reducing unnecessary biopsy. Unnecessary biopsy was theoretically reduced by 67.86% with the DLM in BI-RADS 4a patients. Zhu et al. (30) developed a DLM based on breast MRIs that showed some predictive value for molecular subtypes. However, these researchers only considered the distinction between the luminal A subtype and all other subtypes. Unlike their model, our model can differentiate each molecular subtype and guide individualized treatment. To the best of our knowledge, this is the first study to apply a DLM to the prediction of molecular subtypes using ultrasound images.

The DLM is better than traditional methods in identifying benign and malignant breast tumors. It performs well with high AUC values and other indicators and reduces the burden of radiologists (31). DLMs do not require time-consuming tumor boundary labeling, which is a necessary step for traditional methods. In addition, the DLM can make better use of the hidden information around the tumor, which is ignored by traditional methods.

Currently, most studies use statistical analysis to obtain low-dimensional features of breast ultrasound images for molecular classification. These low-dimensional features are easily affected by the number and quality of the samples collected, making it difficult to mine and quantify the relationships between images and subtypes (32). However, deep learning methods can extract abstract features. All extracted features are high-dimensional features related to molecular classification. Although difficult to visualize, molecular classification is important and can greatly improve recognition accuracy.

There are limitations in our study. First, the training set data came from one hospital, and we did not summarize the basic information on patients and tumors. Second, regardless of the training, test or external test sets, the sample size was small. Thus, these results need to be validated with a larger cohort to determine the value of our model in clinical practice. Third, because the study was retrospective, all patients underwent surgical treatment. However, there are many women who have a BI-RADS categorization with certain malignant potential who choose observation instead of surgical treatment. This factor may be one of the reasons why our study did not achieve a better result.

## Section: Conclusion

We demonstrated that our DLM can recognize breast tumors and predict molecular subtypes with high accuracy based solely on ultrasound images, which may make DLM an effective alternative to clinical biopsy. It is necessary to cooperate with other institutions to expand the dataset to better confirm our model and make it an important decision-making tool with great potential in clinical application.

## Section: Data Availability Statement

The original contributions presented in the study are included in the article/Supplementary Material, further inquiries can be directed to the corresponding author/s.

## Section: Ethics Statement

This study was approved by the Institutional Review Board of Harbin Medical University Cancer Hospital. Because of its retrospective nature, the written informed consent of patients was exempted.

## Section: Author Contributions

XZ, YaZ, HM, and DP conceived and designed the study. WC, HJ, SL, and JH collected the clinical and imaging data. HL, JL, and YL performed image preprocessing. XZ, CW, YuZ, DL, YaZ, HM, and DP performed the data interpretation and the statistical analysis. All authors approved the final manuscript.

## Section: Conflict of Interest

The authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.


---

# Evaluation Framework for Successful Artificial Intelligence-Enabled Clinical Decision Support Systems: Mixed Methods Study

- **Authors:** Mengting Ji, Georgi Z Genchev, Hengye Huang, Ting Xu, Hui Lu, Guangjun Yu
- **Issuer:** Journal of medical Internet research
- **Type:** Scientific article
- **Published:** 2021-06-02
- **Language:** en
- **DOI:** 10.2196/25929
- **Source:** https://pubmed.ncbi.nlm.nih.gov/34076581/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackgroundClinical decision support systems are designed to utilize medical data, knowledge, and analysis engines and to generate patient-specific assessments or recommendations to health professionals in order to assist decision making. Artificial intelligence–enabled clinical decision support systems aid the decision-making process through an intelligent component. Well-defined evaluation methods are essential to ensure the seamless integration and contribution of these systems to clinical practice.ObjectiveThe purpose of this study was to develop and validate a measurement instrument and test the interrelationships of evaluation variables for an artificial intelligence–enabled clinical decision support system evaluation framework.MethodsAn artificial intelligence–enabled clinical decision support system evaluation framework consisting of 6 variables was developed. A Delphi process was conducted to develop the measurement instrument items. Cognitive interviews and pretesting were performed to refine the questions. Web-based survey response data were analyzed to remove irrelevant questions from the measurement instrument, to test dimensional structure, and to assess reliability and validity. The interrelationships of relevant variables were tested and verified using path analysis, and a 28-item measurement instrument was developed. Measurement instrument survey responses were collected from 156 respondents.ResultsThe Cronbach α of the measurement instrument was 0.963, and its content validity was 0.943. Values of average variance extracted ranged from 0.582 to 0.756, and values of the heterotrait-monotrait ratio ranged from 0.376 to 0.896. The final model had a good fit (χ262=36.984; P=.08; comparative fit index 0.991; goodness-of-fit index 0.957; root mean square error of approximation 0.052; standardized root mean square residual 0.028). Variables in the final model accounted for 89% of the variance in the user acceptance dimension.ConclusionsUser acceptance is the central dimension of artificial intelligence–enabled clinical decision support system success. Acceptance was directly influenced by perceived ease of use, information quality, service quality, and perceived benefit. Acceptance was also indirectly influenced by system quality and information quality through perceived ease of use. User acceptance and perceived benefit were interrelated.Keywords: artificial intelligence, AI, clinical decision support systems, evaluation framework

## Section: Introduction › Clinical Decision Support Systems

Clinical decision support systems are computer-based enterprise systems designed to utilize massive data, medical knowledge, and analysis engines as well as to generate patient-specific assessments or recommendations to health professionals in order to assist clinical decision making through human–computer interaction [1,2]. These systems provide services ranging from simple reminders to complex risk prediction [3] and support health care providers in diagnosis, treatment decisions, and population health management. Clinical decision support systems assist one or more levels of decision making: alerting, interpreting, critiquing, assisting, diagnosing, and managing [4]. Diagnostic support systems are a subset of clinical decision support systems that are specifically designed to support clinician in diagnosing patients [5]. Artificial intelligence (AI)–enabled clinical decision support systems combine the knowledge reasoning techniques of AI and the functional models of clinical decision support systems [6].

## Section: Introduction › AI-Enabled Clinical Decision Support Systems: Characteristics, Usage, and Benefits

AI-enabled clinical decision support systems include an intelligent component [6], and in comparison to traditional clinical decision support systems, represent a paradigm shift. They are designed to aid clinicians by converting raw medical-related data, documents, and expert practice into a set of sophisticated algorithms, applying techniques such as machine learning, knowledge graphs, natural language processing, and computer vision so that users find suitable solutions to their medical problems and make clinical decisions [7]. AI-enabled clinical decision support systems have the potential to improve clinicians’ performance, quality of health care, and patient safety [8].

Diagnostics are a primary use case of AI-enabled clinical decision support systems, and these systems have been applied in the field of rare disease diagnosis [9], sepsis detection or prediction [10], fracture detection [11], and cancer detection or diagnosis [12,13]. In addition, current AI-enabled clinical decision support systems are also used in medication therapy [14,15] and health care management [16,17].

The greatest benefits of AI-enabled clinical decision support systems reside in their ability to learn from real-world use and experience (ie, training) and their capabilities for improving their performance (ie, adaptation) [18]. By using techniques such as knowledge graphs and natural language processing, AI can deal with large amounts of text classification, information retrieval, and information extraction from the corpora that is provided by hospital electronic health records. Based on structured data, AI can support more comprehensive and more personalized decision-making suggestions for clinicians through techniques such as machine learning. Another benefit is that the functionality and utility from combining clinical decision support systems with AI techniques surpass those of traditional clinical decision support systems, and the system improves and supports the decision-making process by providing intelligent behavioral patterns, with the ability to learn new clinical knowledge [7].

## Section: Introduction › Need for AI-Enabled Clinical Decision Support System Evaluation

A comprehensive evaluation framework with common elements and interoperability is necessary to serve as a reference for AI-enabled clinical decision support system design and evaluation, with focuses on cross-disciplinary communication and collaboration, and there is a pressing need to develop robust methodologies and empirically based tools for such evaluation. The factors driving this need are the uncertain added value of AI-enabled clinical decision support system implementation, lack of attention, and the possible benefits of comprehensive evaluation implementations.

First, the added value of AI-enabled clinical decision support system implementations in a clinical setting is not firmly established, though evidence exists that such implementations offer potential benefit to patients, clinicians, and health care in general [19]. Introducing this type of system in clinical settings is not without risk [8]. Similar to any other newly introduced technology, AI-enabled clinical decision support systems may disrupt clinical service, threaten patient safety [20], and cause more negative than positive impacts [19]. As a result, there are concerns that AI-enabled clinical decision support system implementation can introduce new errors and have unintended consequences [21]. Additionally, the effect of these systems on clinical, social, and economic outcomes is still controversial which highlights the need to evaluate recognized value parameters [22]. Second, attention to evaluation of clinical decision support systems, in general, and AI-enabled clinical decision support systems, in particular, remains weak [23], which has resulted in a paucity of data on safety, effectiveness, cost benefits, and impacts of AI-enabled clinical decision support systems on patients and health systems [24,25]. Finally, the evaluation of AI-enabled clinical decision support systems is a learning and knowledge-gaining process, and it also helps to identify the gaps to be filled [26]. Findings of comprehensive evaluations could be used to help improve implementations [27].

## Section: Introduction › AI-Enabled Clinical Decision Support System Evaluation Methodologies

The approach to AI-enabled clinical decision support system evaluation is influenced by a sociotechnical regime, which informs and guides the development of the robust and focused evaluation method of this study. It has increasingly been acknowledged that evaluations of such systems are based on a sociological understanding of the complex practices in which the information technologies are to function [28]. A careful balance between social and technical value is required in order to ensure that unwanted consequences do not pose a threat to patients [26] and clinical practices.

A well-defined success measure, based on users’ perspectives, that specifies aspects of AI-enabled clinical decision support systems that determine their success [29] is critical for a robust performance and usefulness evaluation framework. Due to the user-centric nature of information system development and evaluation [30,31], evaluation of AI-enabled clinical decision support system success aims to recognize factors relevant to user acceptance and utility, thus analysis of articulated users’ opinions is necessary [32]. Clinicians are the direct users of AI-enabled clinical decision support systems; the adoption of the product depends on the individual physicians who decide to use it [5]. In many scenarios, clinicians make decisions for patients, and clinicians are responsible for the medical decisions they make. Predicting and managing users’ attitudes toward AI-enabled clinical decision support systems lead to an in-depth understanding of these systems via situated practice [33] and help developers and medical managers maximize user acceptance. Lack of a well-defined success measure is likely to lead to inappropriate evaluation that does not reflect the clinical impact of AI-enabled clinical decision support systems and may hamper technology advancement[19].

A comprehensive evaluation methodology involves a multidisciplinary process and diverse stakeholder involvement, which, when applied to AI-enabled clinical decision support system evaluation, refers to a mixed methodology not only based on tenets in medicine and information technology but also social and cognitive psychology [30]. Using both qualitative and quantitative methods within a single research project has been shown to provide a richer understanding of a given topic than using solely either a qualitative or quantitative approach, facilitate better and more accurate inferences, and provide an integrated perspective [34]. A similar benefit would likely apply when employing mixed methods in designing an AI-enabled clinical decision support system evaluation scheme.

AI-enabled clinical decision support system interface with a diverse set of clinical and nonclinical users and stakeholders whose inputs are integral to the evaluation process. Health care enterprises are multiprofessional organizations that often include dual hierarchical structures involving clinical practitioners and managers [35], and in such settings, AI-enabled clinical decision support systems are not only tools for clinical practitioners who interact directly with the system (eg, physicians, nurses, pharmacists) but also for nonclinical workers (eg, medical administrators). Additionally, there is still an important group of invisible stakeholders, namely patients, who can be affected by these systems use even without direct interaction. The relationships of such diverse groups of stakeholders can prove to be complex, with competing interests and values; therefore, the views, beliefs, and assumptions of stakeholders must be exposed and considered within the AI-enabled clinical decision support system evaluation process [33,36].

## Section: Introduction › Objective

We aimed to address the gap in evaluation knowledge and methodologies by identifying which variables influence AI-enabled clinical decision support system success and using these variables to develop a parsimonious evaluation framework. Specifically, we (1) proposed an evaluation framework with 6 variables and hypotheses about interrelationships between the 6 variables based on the literature review, (2) developed and validated an instrument using the 6 variables for assessing the success of diagnostic AI-enabled clinical decision support systems, and (3) tested the hypotheses using path analysis with latent variables in a structural equation model.

## Section: Methods

Evaluation model hypotheses.

## Section: Methods › Ethics Approval

This study was approved by the Ethics Review Committee, Children’s Hospital of Shanghai/Shanghai Children’s Hospital, Shanghai Jiao Tong University (file number 2020R050-E01).

## Section: Methods › Overview

Our study combined qualitative and quantitative methodologies to validate a proposed evaluation framework, which consisted of a model with hypotheses and containing 6 variables.. A Chinese-language measurement instrument was developed with the goal to measure and quantify the 6 variables, following established instrument development paradigm. A literature review and a Delphi process were conducted to develop the measurement instrument items, cognitive interviews, pretest, and web-based survey. Exploratory factor analysis was used to construct the constituent questions of the measurement instrument, reliability and validity tests were performed, and the interrelations of the variables were tested and verified.

## Section: Methods › Theory

Evaluation methodologies are informed by a rich corpus of theory, which provides a robust foundation for designing an AI-enabled clinical decision support system evaluation framework. In this study and in previous review work [37], three classic theories were used, namely, the DeLone and McLean Model of Information Systems Success [38], the Information Systems Continuance Model [39,40], and the Information Value Chain Theory [29].

An updated model of information systems success that captures multidimensionality and interdependency was proposed by DeLone and McLean in 2003 [38]; the model is a basic and flexible framework of information system evaluation that can adapt to the complexity of the clinical environment [41-44]. In considering the importance of user acceptance and retention to an information system’s success, the information systems continuance model describes the path from expectation confirmation to the formation of users’ intention to continuance [39]. The information value chain theory underlines decision improvement as the main purpose of technology and provides a mechanism to separate process outcomes from clinical outcomes [45].

## Section: Methods › Evaluation Framework Model Variable and Measurement Instrument Item Selection › Literature Search

A set of evaluation model variables and a candidate set of medical AI and clinical decision support system evaluation items were collected through a literature review [35]. A broad search strategy was employed, using multiple databases including Cochrane, MEDLINE, EMBASE, Web of Science, PubMed, CINAHL, PsycINFO, and INSPEC. Studies published from January 2009 to May 2020 were utilized to inform the clinical decision support system evaluation items selection and studies published January 2009 to April 2020 for the AI evaluation items discovery. A candidate set of 6 model variables (Multimedia Appendix 1) and a candidate set of 45 evaluation items were identified.

## Section: Methods › Evaluation Framework Model Variable and Measurement Instrument Item Selection › Delphi Process

The candidate set of evaluation items was examined and finalized using a Delphi process. Delphi is a structured group communication process, designed to obtain a consensus of opinion from a group of experts [46].

Snowball sampling was used to identify a group of experts. Expert selection criteria were (1) clinical practitioners who worked in a medical specialty at least 10 years, preferably had a PhD (minimum postgraduate qualification), had a professional title at the advanced level or above, had an appointment or affiliation with a professional organization, and had more than 1 year of practical experience (with respect to AI-enabled clinical decision support systems); (2) hospital chief information officers who worked in an information system specialty at least 10 years, had a postgraduate qualification, had a midlevel professional title or above, and had an appointment or affiliation with a professional information system organization; or (3) information technology engineers working in medical information system enterprises who worked in AI or clinical decision support systems at least 5 years, had a postgraduate qualification, and had a midlevel position title or above.

In addition to these selection criteria, a measure of degree of expert authority was introduced to add or remove experts from each round of the Delphi process. The degree of expert authority Cr was defined Cr = (Ca + Cs) / 2, using 2 self-evaluated scores—Ca is their familiarity with the problem, and Cs is their knowledge base to judge the program. Cs and Ca ranged between 1 and 5, with a higher value indicating more reliable judgment and more familiarity with the problem. If the self-rated degree of expert authority was >3, the expert was retained, otherwise the expert was removed from group. As a result, a total of 11 experts were selected from diverse areas of expertise and professional focus: clinical practitioners, hospital chief information officers, and information technology engineers working in medical information system enterprises.

The experts were invited to participate in the modified Delphi process via email. Those who accepted were sent an email with a link to the round 1 consultation. Experts were required to provide a relevance score for each item in the candidate set using a 4-point Likert scale (1=not relevant, 2=relevant but requires major revision, 3=relevant but requires minor revision, 4=very relevant and requires no revision). Experts were given 2 weeks to complete each round. A reminder was sent 2 days before the deadline to those who had not completed the survey. The 2-round Delphi process was carried out from May to July 2020.

The content validity was assessed in the last round of the Delphi process. Item-content validity was calculated as the percentage of expert ratings ≥3; if item-content validity was ≥0.8 (ie, expert endorsement), the item was retained. The mean item-content validity, representing the content validity of the measurement instrument of all retained items from the last round was computed. At the end of this step, the set of evaluation items for the measurement instrument were finalized. The final set consisted of 29 evaluation items.

## Section: Methods › Evaluation Framework Model Variable and Measurement Instrument Item Selection › Measurement Instrument Refinement

The measurement instrument consisted of the set of evaluation items measured by a web-based survey. A draft set of survey questions was refined by employing cognitive interviews and a pretest. Interviewees (n=5) who were postgraduates majoring in health informatics or end-users of AI-enabled clinical decision support systems (ie, clinicians) were asked to verbalize the mental process entailed in providing answers. The pretest included 20 end-users. The interviews and pretest were conducted in July 2020 and aimed to assess the extent to which the survey questions reflected the domain of interest and that answers produced valid measurements. Responses used a Likert scale from 1 (strongly disagree) to 7 (strongly agree). The wording of the questions was subsequently modified based on the feedback from the respondents. The web-based survey was initiated in July and was closed in September 2020.

## Section: Methods › Study Population

The evaluation entities chosen in this study were AI-enabled clinical decision support systems designed to support the risk assessment of venous thromboembolism among inpatients: AI-enabled clinical decision support systems that automatically capture electronic medical records based on natural language processing supporting assessment based on individual risk of thrombosis (eg, Caprini scale or Wells scoring), with monitoring of users and reminders sent to users to provide additional data were targeted.

## Section: Methods › Survey Participants and Sample Size

Users of target AI-enabled clinical decision support systems who had at least 1 month of user experience were included. The convenience sample participants were based in 3 hospitals in Shanghai that implemented venous thromboembolism risk assessment AI-enabled clinical decision support systems in clinical settings. We appointed an investigator at each hospital site who was responsible for stating the objective of the study, for identifying target respondents, and for monitoring the length of time it took the participants to complete the survey. This was a voluntary survey. The investigators transmitted the electronic questionnaire link to the respondents through the WeChat communication app.

To ensure usability for exploratory factor analysis [47] and to obtain parameter estimates with standard errors small enough to be of practical use in structural equation modeling [48,49], the required sample size was calculated using to participant-to-item ratio (ranging from 5:1 to 10:1), yielding n=150. A response rate ≥70% was targeted to support external validity [50].

## Section: Methods › Quality Control Measures

Quality control measures were implemented to ensure logical consistency, with completeness checks before the questionnaire was submitted by the responders. Before submitting, respondents could review or change their answers. In order to avoid duplicates caused by repeat submissions, respondents accessed the survey via a WeChat account. Submitted questionnaires meeting the following criteria were deleted: (1) filling time <100 seconds, or (2) the answer of following 2 questions were contradictory: “How often do you use the AI-enabled clinical decision support systems?” versus “You use the AI-enabled clinical decision support systems frequently.” Finally, we asked the point-of-contact individuals in each hospital to send online notifications to survey respondents at least 3 times at regular intervals in order to improve the response rate.

## Section: Methods › Statistical Analysis

Evaluation model hypotheses.

## Section: Methods › Statistical Analysis › Overview

Statistical analyses were performed (SPSS Amos, version 21, IBM Corp) to (1) identify items of measurement instrument that were not related to AI-enabled clinical decision support system success for deletion, (2) explore the latent constructs of the measurement instrument, and (3) evaluate reliability and validity of the measurement instrument.

## Section: Methods › Statistical Analysis › Measurement Instrument Item Reduction

Critical ratio and significance were calculated using independent t tests between high- (upper 27%) and low- (lower 27%) score groups. Item-scale correlation was calculated using Pearson correlation. Corrected item-to-total correlations and the effect on Cronbach α if an item was deleted were calculated using reliability analysis. Item-scale correlation and corrected item-to-total correlations were indications of the degree to which each item was correlated with the total score. Criteria for potential elimination were (1) nonsignificant critical ratio (P>.05), (2) item-scale correlation <0.40, (3) corrected item-to-total correlation <0.40, (4) an increased α if the item was deleted [51,52], that is, if α increased with an item removed, we considered removal of the item from the measurement instrument [49].

## Section: Methods › Statistical Analysis › Latent Construct of Measurement Instrument

Construct of the measurement tool was tested using exploratory factor analysis. Principal component analysis was applied for factor extraction, and the Promax with Kaiser normalization rotation strategy was used to redefine the factors to improve their interpretability. The cutoff strategy was based on verify if the data set was suitable for exploratory factor analysis—the Bartlett test of sphericity should be statistically significant (P<.05) and a Kaiser-Meyer-Olkin value ≥.60 is considered mediocre [49], a value ≥.90 is marvelous [53]. Only factors with an eigenvalue ≥0.50 were retained.

## Section: Methods › Statistical Analysis › Reliability and Validity of Measurement Instrument

Cronbach α coefficients were calculated to assess internal consistencies of the scale and each subscale; values >.80 are preferred [49,50]. Convergent validity and discriminant validity were tested using maximum likelihood estimation confirmatory factor analysis in structural equation modeling. Average variance extracted was used as an indicator of convergent validity, and values >.50 were considered acceptable. The heterotrait-monotrait ratio of correlations was used to test discriminant validity. A heterotrait-monotrait ratio value <0.90 provided sufficient evidence of the discriminant validity of constructs [54].

## Section: Methods › Statistical Analysis › Path Analysis

Interrelationships between variables selected for the evaluation framework were hypothesized in a model (Figure 1). The model was tested using path analysis with latent variables in structural equation modeling. We used the following indicators to assess competence of the model fit: chi-square (significant if P>.05), ratio of chi-square to degrees of freedom <2.00), comparative fit index >0.95, goodness-of-fit index >0.95, root mean square error of approximation <0.06, and standardized root mean square residual ≤0.08 [52,55].

Evaluation model hypotheses.

## Section: Results

Accepted items in the Delphi process.

Principal component analysis results.

Internal consistency, convergent validity, and discriminant validity of constructs.

Final evaluation model (comparative fit index 0.991; goodness-of-fit index 0.957; root mean square error of approximation 0.052; standardized root mean square residual 0.028).

Parameter estimation for path coefficients.

Squared multiple correlations.

## Section: Results › Measurement Instrument

Accepted items in the Delphi process.

## Section: Results › Measurement Instrument › Delphi Process and Evaluation Item Selection

Of the 11 experts invited to participate (Multimedia Appendix 2), all accepted in round 1 (100% response rate) and 10 accepted in round 2 (91% response rate). Most respondents in round 2 (9/10, 90%) identified themselves as expert or very expert (Cr≥4.0) with respect to AI-enabled clinical decision support systems. Consensus was reached in round 2: 29 items obtained at least 80% endorsement (Table 1).

Accepted items in the Delphi process.

## Section: Results › Measurement Instrument › Measurement Instrument Formatting

Based on the feedback from the cognitive interviews and pretesting, we made modifications to the wording of 4 items and added explanations to 2 items in order to make them easier to understand. This self-administered measurement instrument with 29 items was used to collected survey data.

## Section: Results › Results of Survey

Principal component analysis results.

Internal consistency, convergent validity, and discriminant validity of constructs.

## Section: Results › Results of Survey › Characteristics of Survey Respondents

Survey responses were collected from a total of 201 respondents (Multimedia Appendix 3) from 3 hospitals in Shanghai, China, of which 156 responses (77.6%) were valid. No data were missing. The ratio of participants to items was 5.4 to 1.

## Section: Results › Results of Survey › Reduction of Items for the Measurement Instrument

One item—usage behavior—was deleted based on item-scale correlation, corrected item-to-total correlation, and effect on Cronbach-α-if-the-item-was-deleted criteria (Table 1).

## Section: Results › Results of Survey › Latent Construct of the Measurement Instrument

Exploratory factor analysis was deemed to be appropriate (Kaiser-Meyer-Olkin .923; χ3782=3859.495; and significant Bartlett test of sphericity, P<.001). Eight components, which explained 80.6% of the variance, were extracted (Table 2; Multimedia Appendix 4; Multimedia Appendix 5). For interpretability, we classified decision change, process change and outcome change as one factor—Perceived benefit—thereby, the constructs of measurement instrument reflected the 6 variables in the hypothesis model.

Principal component analysis results.

## Section: Results › Results of Survey › Reliability and Validity of Measurement Instrument

The 28-item scale appeared to be internally consistent (Cronbach α=.963). The Cronbach α for the 6 subscales ranged from .760 to .949. Content validity of the overall scale was 0.943. Values of average variance extracted ranged from .582 to .756 and met the >.50 restrictive criterion, which indicated acceptable convergent validity. The values of heterotrait-monotrait ratio ranged from 0.376 to 0.896 and met the <0.90 restrictive criterion, which indicated acceptable discriminant validity of constructs (Table 3, Multimedia Appendix 6).

Internal consistency, convergent validity, and discriminant validity of constructs.

## Section: Results › Model Validation

Final evaluation model (comparative fit index 0.991; goodness-of-fit index 0.957; root mean square error of approximation 0.052; standardized root mean square residual 0.028).

Parameter estimation for path coefficients.

Squared multiple correlations.

## Section: Results › Model Validation › Hypothesized Model Modification

The chi-square of the hypothesized model was significant (χ302=126.962, P<.001; ratio of chi-square over degrees of freedom 4.232). Model fit indices (comparative fit index 0.921; goodness-of-fit index 0.874; root mean square error of approximation 0.144; standardized root mean square residual 0.131) suggested the hypothesized model needed to be modified in order to have a better fitting model: 2 paths, predicting Acceptance from Information quality and Service quality, were added, and one path, predicting Perceived ease of use from Service quality, was moved, which significantly improved the model and lowered the chi-square values. This meant that in addition to the relationship between Perceived ease of use and Information quality or Acceptance, there was also a direct relationship between Information quality and Acceptance.

## Section: Results › Model Validation › Revised Model Fit and Pathway Coefficients

The chi-square of the revised model was not significant (χ262=36.984, P=.08; ratio of chi-square over degrees of freedom 1.422). Model fit indices (comparative fit index 0.991; goodness-of-fit index 0.957; root mean square error of approximation 0.052; standardized root mean square residual 0.028) indicated a good-fitting model (Figure 2). All of the path coefficients between measured variables and factors in the final model were significant (2-tailed, P<.05). Better System quality (P<.001) and better Information quality (P<.001) significantly increased Perceived ease of use. Better Information quality (P=.04), better Service quality (P<.001), and Perceived ease of use (P<.001) significantly increased Acceptance. Acceptance and Perceived benefit were interrelated (Figure 2, Table 4). Variables in the final model accounted for 89% of the variance in Acceptance (Table 5). Parameter estimation of error in measurement, standardized total effects, direct effects, and indirect effects are shown in Multimedia Appendix 7-10.

Final evaluation model (comparative fit index 0.991; goodness-of-fit index 0.957; root mean square error of approximation 0.052; standardized root mean square residual 0.028).

Parameter estimation for path coefficients.

Squared multiple correlations.

## Section: Discussion › Main Findings

User acceptance was established as central to AI-enabled clinical decision support system success in the evaluation framework. A 28-item measurement instrument was evaluated, yielding an instrument that quantifies 6 variables: System quality, Information quality, Service quality, Perceived ease of use, User acceptance, and Perceived benefit.

## Section: Discussion › User Acceptance is the Central Dimension

User acceptance is the traditional focus of evaluation in determining the success of an information system [15,17,32]. User acceptance is a synthesized concept—we used expectation confirmation, user satisfaction, and intention of use as secondary indicators. The item system usage was removed; DeLone and McLean [38] suggested that “intention to use,” that is, intention of use in our study, may be a worthwhile alternative measure in some contexts. Our work demonstrated that the use or nonuse of AI-enabled clinical decision support systems is not a universal success criterion. Therefore, the item was removed from the measurement instrument. The nature of health care settings, wherein diverse perspectives, power asymmetry, and politically led changes co-exist, supports this approach [26]. The use of an AI-enabled clinical decision support system tends to be mandatory, thus it is difficult to interpret users’ evaluations with respect to system usage. Our model demonstrated that User Acceptance of AI-enabled clinical decision support systems was directly determined by Perceived ease of use, Information quality, Service quality, and Perceived benefit.

## Section: Discussion › Perceived Ease of Use

In this study, perceived ease of use encompassed human–computer interaction (eg, user interface, data entry, information display, legibility, response time), ease of learning, and workflow integration [17,56,57]. Perceived ease of use was a mediation variable between System quality, Information quality, and Acceptance. System quality did not directly affect user Acceptance, but indirectly exerted influence through Perceived ease of use, principally because clinicians’ intuitive feelings of ease of use are fixed on external, tangible, and accessible features. Engineering-oriented performance characteristics of an AI-enabled clinical decision support system and necessary supporting functionalities are not their main concerns.

## Section: Discussion › Information Quality

Information quality refers to reliable and valid suggestions, provided by an AI-enabled clinical decision support systems, and directly and indirectly affected user Acceptance. Suggestions without reliability or validity not only reflects low diagnostic performance of AI-enabled clinical decision support systems but also may excessively interrupt daily work [36,58], negatively affecting ease of use and further lowering user acceptance.

## Section: Discussion › Service Quality

Service quality required by clinicians emphasizes knowledge updating for timeliness and system improvement [9,56].

## Section: Discussion › Perceived Benefit

Perceived benefit and user Acceptance were interrelated; and clinicians are always concerned with the usefulness of AI-enabled clinical decision support system adoption for themselves, groups, and patients [19]. AI-enabled clinical decision support system products with anticipated benefits are more likely to be accepted by clinicians. As demonstrated in our study, Perceived benefit was not the conclusive criterion of AI-enabled clinical decision support system success even if it could be measured with precision [59]. There will be a comparison between assumptions and expectations of personal preference with perceived benefit [36]. When clinicians are not willing to accept a new AI-enabled clinical decision support systems, the system will face adoption difficulties in clinical practice even if the system is considered to be a benefit to quality of care and patients’ outcomes in general.

## Section: Discussion › Recommendations of Benefit Measures for AI-Enabled Clinical Decision Support Systems › Decision Changes

We recommend using Decision change as an outcome measure rather than appropriate decisions. Decision change for AI-enabled clinical decision support system usage underlines decision inconsistency between system and human. These decision-making suggestions might correct users’ clinical orders, particularly for those who have insufficient practical experience [21]. Consequently, measuring user decision change (eg, tests cancel, order optimization) is more straightforward than measuring appropriate decisions.

## Section: Discussion › Recommendations of Benefit Measures for AI-Enabled Clinical Decision Support Systems › Process Changes

Process change, which is similar to perceived usefulness [39], mainly covers individual, group, or organization levels of performance improvement. This study used knowledge, skills, confidence [17,25,60-62], and work efficiency [17,61] as indicators of individual performance and used quality of health care and documentation [57,62-66] as indicators of group or organization performance.

## Section: Discussion › Recommendations of Benefit Measures for AI-Enabled Clinical Decision Support Systems › Outcome Changes

Outcome measures tended to be complicated indicators of AI-enabled clinical decision support system success, which often failed to be objective in clinical settings [15,58]. Beneficial patient outcomes from AI-enabled clinical decision support system implementations are the concern of all stakeholders. But there remains a paucity of high-quality evidence for outcome measures [19]. Consequently, although both subjective and objective measures of AI-enabled clinical decision support system success should compensate for the shortcomings of each other, our work showed that it is valuable to evaluate clinicians’ attitude toward perceived benefit for patients that can be obtained from specific AI-enabled clinical decision support system implementation under the health care contexts when objective measures are difficult to qualify.

## Section: Discussion › Limitations

This study is an innovative attempt and pilot examination of an evaluation framework in relation to AI-enabled clinical decision support system success. This evaluation framework is widely applicable, with a broad scope in clinically common and multidisciplinary interoperable scenarios. In order to test the validity of the variables and the hypotheses about their relationships, an empirical methodology was needed. Specifically, the items of the measurement instrument were developed targeting diagnostic AI-enabled clinical decision support systems, and AI-enabled clinical decision support systems designed to support the risk assessment of the venous thromboembolism among inpatients was the focus. Thus, one potential limitation may arise due to this narrow focus. A future expanded evaluation framework would require validation among diverse populations and encompassing AI-enabled clinical decision support systems with diverse functions.

## Section: Discussion › Implications and Conclusion

This study offers unique insight into AI-enabled clinical decision support system evaluation from a user-centric perspective, and the evaluation framework can support stakeholders to understand user acceptance of AI-enabled clinical decision support system products with various functionalities. Given the commonality and interoperability of this evaluation framework, it is widely applicable in different implementations, that is, this framework can be used to evaluate success of various AI-enabled clinical decision support systems.

From a theoretical point of view, this framework can be an evaluation approach to help in describing and understanding AI-enabled clinical decision support system success with a user acceptance–centric evaluation process. There are also practical implications in terms of how this evaluation framework is applied in clinical settings. The 28-item diagnostic AI-enabled clinical decision support system success measurement instrument, divided into 6 model variables, showed good psychometric qualities. The measurement instrument can be a useful resource for health care organizations or academic institutions designing and conducting evaluation projects on specific AI-enabled clinical decision support systems. At the same time, if the measurement instrument is to be used for AI-enabled clinical decision support system products with different functionalities in a specific scenario, item modifications, cross-cultural adaptation, and tests of reliability and validity testing (in accordance with scale development guidelines [52]) is needed.

## Section: Acknowledgments

This work was supported by the Doctoral Innovation Fund in Shanghai Jiao Tong University School of Medicine 2019 [BXJ201906]; the Shanghai Municipal Education Commission-Gaoyuan Nursing Grant Support [Hlgy1906dxk]; and the Shanghai Municipal Commission of Health and Family Planning (Grant No. 2018ZHYL0223).


---

# Exploring the Underlying Mechanism of Shenyankangfu Tablet in the Treatment of Glomerulonephritis Through Network Pharmacology, Machine Learning, Molecular Docking, and Experimental Validation

- **Authors:** Meiling Jin, Wenwen Ren, Weiguang Zhang, Linchang Liu, Zhiwei Yin, Diangeng Li
- **Issuer:** Drug design, development and therapy
- **Type:** Scientific article
- **Published:** 2021-11-09
- **Language:** en
- **DOI:** 10.2147/dddt.s333209
- **Source:** https://pubmed.ncbi.nlm.nih.gov/34785888/
- **Licence:** CC-BY-NC

## Section: Abstract

This study aimed to explore the underlying mechanisms of Shenyankangfu tablet (SYKFT) in the treatment of glomerulonephritis (GN) based on network pharmacology, machine learning, molecular docking, and experimental validation. The active ingredients and potential targets of SYKFT were obtained through the Traditional Chinese Medicine Systems Pharmacology Database and Analysis Platform, the targets of GN were obtained through GeneCards, etc. Perl and Cytoscape were used to construct an herb-active ingredient-target network. Then, the clusterProfiler package of R was used for Gene Ontology (GO) and Kyoto Encyclopedia of Genes and Genomes (KEGG) pathway analysis. We also used the STRING platform and Cytoscape to construct a protein-protein interaction (PPI) network, as well as the SwissTargetPrediction server to predict the target protein of the core active ingredient based on machine-learning model. Molecular-docking analysis was further performed using AutoDock Vina and Pymol. Finally, we verified the effect of SYKFT on GN in vivo. A total of 154 active ingredients and 255 targets in SYKFT were screened, and 135 targets were identified to be related to GN. GO enrichment analysis indicated that biological processes were primarily associated with oxidative stress and cell proliferation. KEGG pathway analysis showed that these targets were involved mostly in infection-related and GN-related pathways. PPI network analysis identified 13 core targets of SYKFT. Results of machine-learning model suggested that STAT3 and AKT1 may be the key target. Results of molecular docking suggested that the main active components of SYKFT can be combined with various target proteins. In vivo experiments confirmed that SYKFT may alleviate renal pathological injury by regulating core genes, thereby reducing urinary protein. This study demonstrated for the first time the multicomponent, multitarget, and multipathway characteristics of SYKFT for GN treatment.
