# In silico PK predictions in Drug Discovery: Benchmarking of Strategies to Integrate Machine Learning with Empiric and Mechanistic PK modelling

- **Authors:** Moritz Walter, Ghaith Aljayyoussi, Bettina Gerner, Hermann Rapp, Christofer S. Tautermann, Pavel Balazki, Miha Skalic, Jens M. Borghardt, Lina Humbeck
- **Issuer:** Preprint server
- **Type:** Preprint
- **Published:** 2024-07-30
- **DOI:** 10.1101/2024.07.30.605777
- **Source:** https://doi.org/10.1101/2024.07.30.605777
- **Licence:** CC-BY-NC-ND-4.0

## Section: Abstract

ABSTRACT A successful drug needs to combine several properties including high potency and good pharmacokinetic (PK) properties to sustain efficacious plasma concentration over time. To estimate required doses for preclinical animal efficacy models or for the clinics, in vivo PK studies need to be conducted. While the prediction of ADME properties of compounds using Machine Learning (ML) models based on chemical structures is well established in drug discovery, the prediction of complete plasma concentration-time profiles has only recently gained attention. In this study, we systematically compare various approaches that integrate ML models with mechanistic PK models to predict PK profiles in rats after i.v. administration prior to synthesis. More specifically, we compare a standard noncompartmental analysis (NCA) based approach (prediction of CL and V ss ), a pure ML approach (non-mechanistic PK description), a compartmental modeling approach, and a physiologically based pharmacokinetic (PBPK) approach. Our study based on internal preclinical data shows that the latter three approaches yield PK profile predictions of comparable accuracy (evaluated as geometric mean fold errors for each profile) across a large test set (&gt;1000 small molecules). In summary, we demonstrate the improved ability to prioritize drug candidates with desirable PK properties prior to synthesis with ML predictions.


---

# Reflection paper on the use of Artificial Intelligence (AI) in the medicinal product lifecycle

- **Authors:** CHMP, CVMP
- **Issuer:** EMA
- **Type:** Reflection paper
- **Published:** 2024-09-09
- **Status:** Adopted
- **Language:** en
- **Reference:** EMA/CHMP/CVMP/83833/2023
- **Source:** https://www.ema.europa.eu/en/documents/scientific-guideline/reflection-paper-use-artificial-intelligence-ai-medicinal-product-lifecycle_en.pdf
- **Licence:** EMA-reuse

## Page 1

Official address  Domenico Scarlattilaan 6  ●  1083 HS Amsterdam  ●  The Netherlands 
An agency of the European Union      
 
Address for visits and deliveries  Refer to www.ema.europa.eu/how-to-find-us  
Send us a question Go to www.ema.europa.eu/contact  Telephone +31 (0)88 781 6000 
© European Medicines Agency, 2024. Reproduction is authorised provided the source is acknowledged. 
9 September 2024 
EMA/CHMP/CVMP/83833/2023 
Committee for Medicinal Products for Human Use (CHMP) 
Committee for Medicinal Products for Veterinary Use (CVMP) 
Reflection paper on the use of Artificial Intelligence (AI) in 
the medicinal product lifecycle 
 
Draft agreed by Committee for Medicinal Products for Human Use 
(CHMP) Methodology Working Party  
July 2023 
Draft adopted by CVMP for release for consultation 
13 July 2023  
Draft adopted by CHMP for release for consultation 
10 July 2023  
Start of public consultation 
19 July 2023 
End of consultation (deadline for comments) 
31 December 2023 
Final version agreed by MWP  
6 September 2024 
Final version adopted by CHMP 
9 September 2024 
Final version adopted by CVMP 
11 September 2024 
 
 
Keywords 
Artificial intelligence, AI, machine learning, ML, regulatory, medicine, human 
medicinal product, veterinary medicinal product

## Page 2

Reflection paper on the use of Artificial Intelligence (AI) in the medicinal product 
lifecycle 
EMA/CHMP/CVMP/83833/2023 
Page 2/18 
 
Reflection paper on the use of AI in the medicinal product 
lifecycle 
Table of contents 
1. Introduction ............................................................................................ 3 
2. Discussion ............................................................................................... 3 
2.1. Definitions and scope ............................................................................................ 3 
2.2. General considerations .......................................................................................... 4 
2.3. AI in the lifecycle of medicinal products ................................................................... 4 
2.3.1. Drug discovery .................................................................................................. 5 
2.3.2. Non-clinical development .................................................................................... 5 
2.3.3. Clinical trials ..................................................................................................... 5 
2.3.4. Precision medicine ............................................................................................. 7 
2.3.5. Product information ........................................................................................... 7 
2.3.6. Manufacturing ................................................................................................... 7 
2.3.7. Post-authorisation phase .................................................................................... 7 
2.4. Regulatory interactions ......................................................................................... 8 
2.5. Technical aspects ................................................................................................. 8 
2.5.1. Data acquisition and augmentation ...................................................................... 8 
2.5.2. Training, validation, and test datasets .................................................................. 9 
2.5.3. Model development ............................................................................................ 9 
2.5.4. Performance assessment .................................................................................. 10 
2.5.5. Interpretability and explainability ...................................................................... 10 
2.5.6. Model deployment ........................................................................................... 10 
2.6. Governance ....................................................................................................... 11 
2.7. Integrity aspects and data protection .................................................................... 11 
2.8. Ethical aspects and trustworthy AI ........................................................................ 12 
3. Conclusion ............................................................................................. 12 
4. Glossary ................................................................................................ 13 
5. Related methodology guidance.............................................................. 14 
5.1. Guidance concerning human medicines ................................................................. 14 
5.2. Guidance concerning veterinary medicines ............................................................ 15 
6. References ............................................................................................ 16

## Page 3 (Section: 1.  Introduction)

Reflection paper on the use of Artificial Intelligence (AI) in the medicinal product 
lifecycle 
EMA/CHMP/CVMP/83833/2023 
Page 3/18 
 
1.  Introduction 
The utilisation of artificial intelligence (AI) is an important part of the digital transformation. Such 
systems are often developed through the process of machine learning (ML) where models are trained 
from data, with or without human input. However, as these models often contain exceptionally large 
numbers of trainable parameters arranged in non-transparent model architectures, new risks are 
introduced that need to be mitigated to ensure the safety of patients and integrity of clinical study 
results. Also, as the overarching approach is inherently data-driven, active measures must be taken to 
minimise the integration of bias into AI/ML applications and promote reliable and trustworthy AI. 
This reflection paper provides considerations on the use of AI/ML in the lifecycle of medicinal products, 
including medicinal products development, authorisation, and post-authorisation. Given the rapid 
development in this field, the aim of this reflection paper is to reflect on the principles that are relevant 
for regulatory evaluation when these emerging technologies are applied to support safe and effective 
development, manufacturing and use of medicines. 
It is crucial to identify aspects of AI/ML that would fall within the remit of EMA or the National 
Competent Authorities of the Member States as the level of scrutiny during assessment will depend on 
this remit. This reflection paper focuses only on the use of AI in the medicinal product lifecycle and any 
references to qualification of novel methodologies for medicines development1 and regulatory 
interaction are to be understood within this scope. Additionally, medical devices with AI/ML technology 
can be used within the context of clinical trials to generate evidence in support of a marketing 
authorisation application and/or can be combined with the use of a medicinal product. In such cases 
EMA will be involved in the assessment on whether the device is adequate to generate evidence, 
supporting an EU marketing authorisation. Similarly, if a device is used to provide recommendations in 
the Summary of Product Characteristics, e.g., on posology or monitoring, the EMA will assess all 
relevant aspects of the proposed combined use. 
This reflection paper describes the current experience of EMA in a field where scientific knowledge is 
fast evolving. It should be read in coherence with both legal requirements and overarching EU 
principles and legislation on AI (including the AI act and AI liability directive), data protection 
(including GDPR), cyber security (including the Cybersecurity act), and medicines regulation (see 
references).  
While some considerations in this reflection paper are of general interest for the development of 
veterinary medicinal products, important differences exist between the human and veterinary domain 
including legal bases, regulatory requirements and guidance, ethical issues, risks of bias and other 
sources of discrimination. Further reflections will be necessary to better identify the specific 
circumstances and sources of bias in the veterinary setting. While veterinary medicines regulated by 
Regulation (EU) 2019/6 are generally within the scientific scope of this document, the reader is advised 
to pay attention to notes pointing out fundamental differences. Specific veterinary reflections or 
guidance may be developed in the future. 
2.  Discussion 
2.1.  Definitions and scope  
According to the OECD definition, an AI system is a machine-based system designed to operate with 
varying levels of autonomy and that may exhibit adaptiveness after deployment and that, for explicit 
 
1 Qualification of innovative development methods is applicable to human medicines provided by EMA CHMP (see 
Qualification of novel methodologies for medicine development | European Medicines Agency (europa.eu))

## Page 4 (Section: 2.2.  General considerations)

Reflection paper on the use of Artificial Intelligence (AI) in the medicinal product 
lifecycle 
EMA/CHMP/CVMP/83833/2023 
Page 4/18 
 
or implicit objectives, infers, from the input it receives, how to generate outputs such as predictions, 
content, recommendations, or decisions that can influence physical or virtual environment. 
In this reflection paper the term AI/ML is used to cover all models developed through the process of 
ML, regardless of the specific model architecture. 
2.2.  General considerations 
AI/ML tools and methodologies can, if developed and used correctly, effectively support the acquisition, 
transformation, analysis, and interpretation of data within the medicinal product lifecycle. It should be 
noted that many recommendations, best practices, and previous learnings within areas of model-
informed drug development and biostatistics also apply to the field of AI/ML. Related methodology 
guidelines which may be relevant are listed in at the end of this document.  
A risk-based approach for development, deployment, and performance monitoring of AI/ML tools 
allows developers to pro-actively define the risks to be managed throughout the system lifecycle. This 
paper uses the term "high patient risk" for systems affecting patient safety, while the term "high 
regulatory impact" is used for cases where impact on regulatory decision-making is substantial. 
Advice on risk management will be further reflected in future regulatory guidance, since the impact of 
system malfunction or suboptimal model performance can range from minimal to critical or even life-
threatening. The degree of risk depends not only on the AI technology and data quality, but also on 
the context of use and the degree of influence the AI technology exerts. In addition, the degree of risk 
may vary throughout the lifecycle of the AI-system. Clinical trial sponsors, marketing authorisation 
applicants, marketing authorisation holders (MAHs) and manufacturers planning to deploy AI/ML 
technology are expected to consider and systematically manage relevant risks from early development 
to decommissioning. 
If an AI/ML system is planned for use in the context of medicinal product development, evaluation, or 
monitoring, and is expected to impact, even potentially, on the benefit-risk balance of a medicinal 
product, early regulatory interaction is advised (see Regulatory interactions). 1The level of scrutiny 
depends on the level of risk and regulatory impact posed by the system.  
A key principle is that it is the responsibility of the clinical trial sponsor, marketing authorisation 
applicant/holder or manufacturer to ensure that all algorithms, models, datasets, and data processing 
pipelines used are fit for purpose and are in line with legal, ethical, technical, scientific, and regulatory 
standards as described in EU legislation, GxP standards and current EMA guidelines. Of note, these 
requirements may in some respects be stricter than what is considered standard practice in the field of 
data science. 
For all requests for advice or opinions the applicant or MAH is expected to provide a scientific base 
along with sufficient technical details to allow comprehensive assessment of AI systems used in the 
medicinal product lifecycle, including the integrity of data used for model development and the 
generalisability of model performance to the target population and the specific context of use. 
2.3.  AI in the lifecycle of medicinal products 
The following sections are structured along the lifecycle of medicinal products, from drug discovery and 
development to post-authorisation settings such as pharmacovigilance and effectiveness studies.

## Page 5 (Section: 2.3.1.  Drug discovery)

Reflection paper on the use of Artificial Intelligence (AI) in the medicinal product 
lifecycle 
EMA/CHMP/CVMP/83833/2023 
Page 5/18 
 
2.3.1.  Drug discovery 
The application of AI/ML in the process of drug discovery can be low regulatory impact if non-optimal 
performance only affects the developer. However, if results contribute to the total body of evidence 
presented for regulatory review, principles for non-clinical development (see below) should be 
followed. In this context, all models and datasets used should be reviewed by the sponsor to mitigate 
ethical issues, risks of bias and other sources of discrimination against non-majority genotypes and 
phenotypes from a data quality and quantity perspective (see Technical aspects – Data acquisition and 
augmentation). 
2.3.2.  Non-clinical development 
AI/ML applications in non-clinical development may strive not only to achieve improved performance in 
data analysis and interpretation but could potentially also include AI/ML modelling approaches to 
replace, reduce, and refine the use of animals and improve human translatability. Existing Standard 
Operating Procedures (SOPs) would be expected to extend to all AI/ML applications in non-clinical 
studies. When the OECD Series on Principles of Good Laboratory Practice (GLP) is applicable, advisory 
documents on Application of GLP Principles to Computerised Systems (no.17) and GLP Data Integrity 
(no. 22) should be considered. 
While non-clinical development may allow an iterative data-driven AI/ML approach, prospective model 
performance testing during development and pre-specified analyses during inference may be needed 
for specific cases. Applications that affect patient safety (such as efficacy and safety modelling that 
inform the design of “first-in-human” studies), that are potentially relevant for assessment of the 
benefit-risk balance of a medicinal product, or have high regulatory impact in another manner, should 
be developed and tested accordingly.  
2.3.3.  Clinical trials 
2.3.3.1.  Good clinical practice (GCP) 
The use of AI/ML within the context of clinical trials should meet applicable requirements in the ICH E6 
guideline for good clinical practice (GCP) or VICH GL9 Good clinical practices (veterinary). Of note, if 
the use could be of high regulatory impact or high patient risk in a clinical trial, and the method has 
not been previously qualified by the EMA for the specific context of use, the full model architecture, 
logs from model development, validation and testing, training data and description of the data 
processing pipeline would likely be considered parts of the clinical trial data or trial protocol dossier and 
thus may be requested for comprehensive assessment at the time of market authorisation, clinical trial 
application or GCP inspection. 
Additional information would need to be considered when applying AI/ML in a clinical trial setting 
where the impact on specific aspects such as the design and conduct of the trial, the use of 
decentralised elements and the intended use as a decision support software should be reflected in the 
specific protocol benefit-risk assessment. 
2.3.3.2.  Use of medical devices and in vitro diagnostics in clinical trials 
Medical devices and in vitro diagnostics (IVDs) are regulated according to the Regulation (EU) 
2017/745 on Medical Devices (MDR) or Regulation (EU) 2017/746 on in vitro diagnostic medical 
devices (IVDR). Applications within areas of medicines development and use can include an interplay 
with such devices. Hence, this section is provided for completeness and without prejudice to the 
existing guidance on medicinal products used in combination with medical devices.

## Page 6 (Section: 2.3.3.3.  Data analysis and inference)

Reflection paper on the use of Artificial Intelligence (AI) in the medicinal product 
lifecycle 
EMA/CHMP/CVMP/83833/2023 
Page 6/18 
 
When AI/ML systems are used for clinical management of an individual patient, they may be 
considered medical devices according to MDR or IVDR2,3. Specific guidance on the Qualification and 
Classification of Software within the framework of the MDR and IVDR can be found in MDCG 2019-113. 
It is not in the remit of the EMA to qualify or classify software under the above regulations.  
Even when using CE marked medical devices, fulfilment of additional requirements may be needed to 
qualify it for use within the context of a clinical trial, to ensure the rights, safety, wellbeing of subjects, 
integrity of data and results of the clinical trial including their generalisability. 
 
2.3.3.3.  Data analysis and inference 
When AI/ML models are used for transformation, analysis or interpretation of data within a clinical trial 
of a medicinal product, they are considered a part of the statistical analysis and should follow 
applicable guidelines on statistical principles for clinical trials (see Related methodology guidance) and 
include analysis of the impact on downstream statistical inference. For inference in late-stage clinical 
development, this requires a detailed description of a pre-specified data curation pipeline and a frozen 
and documented (see Technical aspects) or EMA qualified (see Regulatory interactions) set of models, 
within the statistical analysis plan.  
Early-phase clinical trials 
Use of AI/ML models for data analysis in early stages of clinical development is often low risk, but can 
contain applications with high patient risk such as treatment assignment or dosing. In all cases, 
measures should be taken to ensure that all estimates used for planning of subsequent clinical trials 
are statistically robust and that exploratory analyses are interpreted in relation to multiplicity. In 
circumstances where data from early-phase clinical trials may have a substantial regulatory impact, 
such as in limited clinical development programs, requirements may be higher and should be discussed 
through early regulatory interaction. 
Pivotal clinical trials 
In late-stage pivotal clinical trials, all risks related to overfitting and data leakage must be carefully 
mitigated. Prior to model deployment in high regulatory impact settings, such as in relation to the 
primary endpoint, performance should be tested with prospectively generated data (future calendar 
time) that is acquired in a setting or population representative of the intended context of use. 
Incremental learning approaches are not accepted, and any modification of the model during the trial 
requires a regulatory interaction to amend the statistical analysis plan. 
Prior to the database lock and subsequent unblinding of the data used for hypothesis testing, the data 
pre-processing pipeline and all models should be frozen and documented in a traceable manner in the 
statistical analysis plan. Once a dataset has been opened, any non-prespecified modifications to data 
processing or models implies that analysis results are considered post hoc and hence not suited for 
confirmatory evidence generation. 
If possible, it is encouraged that models are published in an openly accessible repository prior to their 
deployment in a pivotal clinical trial, to allow third-party review and promote standardisation. 
 
2 Regulation (EU) 2017/745 and Regulation (EU) 2017/746 apply to human medicines only. 
3 See MDCG 2019-11 guidance on Qualification and Classification of Software in Regulation (EU) 2017/745 (MDR) and 
Regulation (EU) 2017/746 (IVDR) (link) and infographic on classification of software as medical device (link)

## Page 7 (Section: 2.3.4.  Precision medicine3F)

Reflection paper on the use of Artificial Intelligence (AI) in the medicinal product 
lifecycle 
EMA/CHMP/CVMP/83833/2023 
Page 7/18 
 
2.3.4.  Precision medicine4 
AI/ML can be used to individualise treatment in relation to factors such as disease characteristics, 
patient genotype, wide-band biomarker panels and clinical parameters. This could include patient 
selection, dosing, de novo design of product variants and selection from a pre-manufactured library of 
variants. It is possible that an AI/ML application is referenced in the Summary of product 
characteristics to aid such decisions on indication and posology. Without prejudice to the need for 
conformity assessment by other regulatory bodies, the safety and efficacy of the medicinal product 
together with the AI-driven application is a matter for medicines regulation. 
Applications of AI/ML in relation to indication or posology are regarded as a high patient risk as well as 
high regulatory impact. In addition to the principles spelled out elsewhere in this document for such 
settings, special care should be paid in defining what constitutes a change in indication or posology 
which would requiring a regulatory evaluation before implementation. Also, it is important to provide 
guidance that the prescribers can critically apprehend and to include fall-back treatment strategies in 
cases of technical failure. 
2.3.5.  Product information 
AI/ML applications used for drafting, compiling, editing, translating, tailoring, or reviewing medicinal 
product information documents should be used under close human supervision. Given that generative 
language models are prone to include plausible but erroneous or incomplete output, quality review 
mechanisms need to be in place to ensure that all model-generated text is both factually and 
syntactically correct before submission for regulatory review. 
2.3.6.  Manufacturing 
The use of AI/ML in the manufacturing of medicinal products including process design and scale up, 
process optimisation, in-process quality control and batch release is expected to increase in the coming 
years. Model development, performance assessment and life-cycle management should follow the 
quality risk management principles, taking patient safety, data integrity and product quality into 
account. For human medicines the principles of ICH Q8, Q9 and Q10 should be considered, awaiting 
revision of current regulatory requirements and GMP standards. 
2.3.7.  Post-authorisation phase 
It is foreseen that AI/ML tools can effectively support post-authorisation activities, such as post-
authorisation efficacy and safety studies (PAES and PASS) for human medicines and post-marketing 
surveillance studies for veterinary medicines, as well as pharmacovigilance activities including adverse 
event report management and signal detection, in line with current good pharmacovigilance practices 
requirements available for both human and veterinary medicines. 
Applications within pharmacovigilance may allow a more flexible approach to AI/ML modelling and 
deployment, where incremental learning can continuously enhance models for classification and 
severity scoring of adverse event reports as well as signal detection. However, it remains the 
responsibility of the MAH to validate, monitor and document model performance and include AI/ML 
operations in the pharmacovigilance system, to mitigate risks related to all algorithms and models 
used. 
 
4 Precision medicines in this context applies to human medicines only.

## Page 8 (Section: 2.4.  Regulatory interactions)

Reflection paper on the use of Artificial Intelligence (AI) in the medicinal product 
lifecycle 
EMA/CHMP/CVMP/83833/2023 
Page 8/18 
 
If a post authorisation study is listed as a condition for a marketing authorisation, AI/ML applications 
should be discussed within a regulatory procedure unless details are agreed already at time of 
authorisation. Of note, the same requirements of using a pre-specified statistical analysis plan, data 
pipeline and frozen models as for pivotal clinical trials, may apply. 
2.4.  Regulatory interactions 
Applicants and developers are expected to perform a regulatory impact and risk analysis of all AI/ML 
applications and are recommended to seek regulatory interactions when no clearly applicable written 
guidance is available. The regulatory impact is directly related to the phase in the medicinal product 
lifecycle and the weight of evidence these data will have in the intended setting. In cases where impact 
on regulatory decision-making may be high, interaction with regulators is always recommended. 
Early interaction on experimental technology is provided by the EMA Innovation Task Force (ITF). 
Scientific advice and qualification1 of novel methodologies in medicines development is provided by the 
Scientific Advice Working Party (SAWP) of the CHMP and the Scientific Advice Working Party (SAWP) of 
the CVMP. The term qualification advice/opinion refers to novel methodologies applied to medicinal 
product development where the methodology to be qualified would ideally be medical device/software 
agnostic.  
Timing of interactions should be guided by the regulatory impact and risk associated with using the AI 
based models in context of the lifecycle of a medicinal product. In high-impact cases, interaction may 
be crucial already at the planning stage.  
The documentation to inform the interaction with regulators should cover questions such as intended 
context of use, generalisability, performance, robustness, transparency, and clinical applicability, at a 
level of detail sufficient for comprehensive assessment. Specific and clearly formulated regulatory and 
scientific questions are strongly encouraged, to allow reciprocally concise answers. 
2.5.  Technical aspects 
2.5.1.  Data acquisition and augmentation 
AI/ML models are intrinsically data-driven, as they extract or adapt their parameters from training 
data. This makes them vulnerable to the integration of bias into models. Efforts should be made to 
acquire a balanced and sufficiently large training dataset in relation to the intended context of use. The 
need to over-sample rare populations should be considered, taking all relevant bases of discrimination 
as specified in the EU principle of non-discrimination and the EU fundamental rights into account. 
Dedicated reflections will be necessary to identify data quality issues and potential biases applicable to 
veterinary medicines considering the difference e.g., in target populations and regulatory requirements 
between veterinary and human medicines.  
The source(s) of data and the process of data acquisition, along with any processing such as cleaning, 
transformation, imputation, annotation, normalisation, and augmentation should be documented in a 
detailed and fully traceable manner in line with GxP requirements. 
Exploratory data analyses should be performed to describe the data characteristics, 
representativeness, fairness, and relevance for the intended task. At a minimum, there should be 
documented considerations on: 
• relevance and population representativeness of data, and intra-/extrapolation assumptions 
made,

## Page 9 (Section: 2.5.2.  Training, validation, and test datasets)

Reflection paper on the use of Artificial Intelligence (AI) in the medicinal product 
lifecycle 
EMA/CHMP/CVMP/83833/2023 
Page 9/18 
 
• class imbalances and corresponding mitigation measures taken, and 
• potential risk for unfair or discriminatory outcomes from using the data. 
Augmentation techniques may be applied to expand the training dataset. For imaging data this 
includes, but is not limited to, geometric transformations, truncation and merging, addition of noise 
and of change of contrast/brightness/colour depth/resolution of imaging data. Similarly, synthetic data 
of other modalities may in some cases be useful for expanding the training dataset, both for increasing 
model performance and in relation to non-discrimination. 
If limitations in the training dataset remain, affecting the generalisability or fairness of the model, 
these should be clearly presented in the model documentation along with recommendations on the use 
of alternative methods in cases for which the model is not considered applicable. 
2.5.2.  Training, validation, and test datasets 
The term validation is often used differently between the fields of AI/ML and medicines development.  
For AI/ML, validation refers to the data used to inform on the selection of model architecture and 
hyperparameter tuning and is hence part of the data driven process. The validation subset can be 
static or iteratively sampled from the training data using cross-validation. Once this process is 
completed, the final performance of the model is evaluated once using the hold-out test data set. If 
test performance is unsatisfactory and further model development is needed, the current test data set 
cannot be re-used for this purpose and a completely new and independent test dataset is required to 
repeat the test procedure for an updated model. 
The practice of an early train-test split into separate and unrelated datasets, prior to any normalisation 
or other types of processing where aggregated measures are used, is strongly encouraged. Even so, 
the risk of direct or indirect (often unintentional or even unconscious) data leakage cannot be 
completely excluded. For example, unknown case overlaps in clinical databases, sponsor-specific basic 
features shared between study protocols or even general a priori knowledge of global study outcomes 
can contain information that increases risk of overfitting the model. Hence, models intended for high 
patient risk and/or high regulatory impact settings (in particular, non-transparent models intended for 
use in late-stage clinical development) should be prospectively tested using newly acquired data, 
representative for the future context of use. 
2.5.3.  Model development 
Given the plethora of modelling approaches and architectures, only generally applicable considerations 
are provided on model development. It is the responsibility of the sponsor, applicant or MAH to ensure 
that SOPs promote a development practice that favours model generalisability and robustness - 
particularly for settings where models cannot be updated during deployment - and to keep traceable 
documentation and development logs to allow secondary assessment of development practices. If a 
third-party AI model or service is to be used within the medicinal product lifecycle with high regulatory 
impact or high patient risk, it is expected that the manufacturer of the system has provided such 
details through a methodology qualification process (see Regulatory interactions) covering the specific 
context of use.  
It is strongly encouraged that methods promoting generalisability are explored and implemented, 
including regularisation techniques, drop-out, and sensitivity analyses with stratification of training 
data based on calendar time. 
It is of particular importance to avoid overfitting, as this negatively affects generalisability of model 
performance into future context of use. Overfitting that is the result of non-optimal modelling practises

## Page 10 (Section: 2.5.4.  Performance assessment)

Reflection paper on the use of Artificial Intelligence (AI) in the medicinal product 
lifecycle 
EMA/CHMP/CVMP/83833/2023 
Page 10/18 
 
is usually discoverable in the model test phase. A more problematic cause of overfitting is data leakage 
from the test dataset into the training/validation environment (see Training, validation and test 
datasets). 
It is important to clearly define the intended use of the model, to allow a validity assessment of 
development decisions and feature engineering, if applicable. 
2.5.4.  Performance assessment 
The choice of metrics for performance assessment is crucial for an adequate assessment of the model. 
Preferably, the set of metrics should contain parameters that are insensitive to class imbalances. For 
classification, this could include the Matthews Correlation Coefficient which considers the full confusion 
matrix. To identify random effects related to the train-test split, the distribution of performance metrics 
generated through cross-validation should be presented. 
Sensitivity analysis for minority classes and in relation to calendar time is expected, to support the 
generalisability to data with different class proportions and robustness in relation to uncontrolled 
secular trends in data at deployment. Pre-defined thresholds for performance metrics that can be 
related to the context of use and considerations on performance requirements depending on level of 
patient risk and regulatory impact further support the credibility of model performance. 
2.5.5.  Interpretability and explainability 
To strengthen procedural fairness, accountability and prevention of bias, the use of transparent models 
is preferred. However, it is acknowledged that several of the most high-performing modelling 
architectures allow only limited insight into the data representation and abstraction in the model. The 
use of such black box models may be acceptable in cases where developers substantiate that 
transparent (i.e., interpretable) models show unsatisfactory performance or robustness. Model use 
should be supported by an underlying general rationale and detailed information on model 
architecture, hyperparameter tuning, training metrics, as well as validation and test results, along with 
a pre-defined monitoring and system risk management plan for mitigating non-transparency issues. It 
is recommended that such applications are discussed in detail within the scope of an EMA qualification1 
or scientific advice procedure. 
To allow review and monitoring of black box models, methods within the field of explainable AI should 
be used whenever possible. This includes providing explainability metrics, such as SHAP and/or LIME 
analyses, both for the model and for individual inferences during deployment. Computer vision models, 
and extensions into other modalities where attention mechanisms are used, should whenever possible 
be supported by class activation, saliency or attention maps to verify that features are extracted from 
relevant positions in the image or sequence. 
2.5.6.  Model deployment 
Deployment of AI/ML models should be performed in line with the risk-based approach described for 
model development. For high patient risk and high regulatory impact use cases, all non-trivial changes 
in the software and hardware stack supporting the model, including changes for key dependencies, 
require a re-evaluation of system performance. It is also of importance that the data acquisition 
hardware, software, and data transformation pipeline at inference is in line with pre-defined 
specifications. 
Monitoring of model performance should be instituted to allow early detection of drift/degradation and 
thresholds for acceptable model performance should be clearly defined. This may include routine

## Page 11 (Section: 2.6.  Governance)

Reflection paper on the use of Artificial Intelligence (AI) in the medicinal product 
lifecycle 
EMA/CHMP/CVMP/83833/2023 
Page 11/18 
 
sampling of data for manual classification or use of externally provided test data sets from external 
quality control programs. Also, compliance with applicable standards should be regularly evaluated. 
For all models, especially those where there is no human-in-the-loop, a system risk management plan 
should be developed that defines likely risks of failure modes of the algorithm. This includes 
consequences of incorrect predictions/classifications as well as monitoring and mitigation/correction 
approaches, such as how to trigger a suspension/decommission of the model and how to suspend or 
decommission it.  
2.6.  Governance 
SOPs implementing GxP principles on data and algorithm governance should be extended to include all 
data, models and algorithms used for AI/ML in cases of high regulatory impact or high patient risk. 
Aspects related to the governance of all components used, the application of data protection and 
compliance with applicable data protection laws and ethical standards should be documented and 
regularly reviewed. 
2.7.  Integrity aspects and data protection 
New and not yet fully characterised risks emerge when data is transformed into high-parameter model 
representations, as these can contain a similar level of subject-level information granularity as the 
training data but with limited insight into the data representation. For example, if personal data have 
been used for model training, it must be further evaluated whether such information can realistically 
be extracted through membership-, inference- and model inversion attacks, to mitigate the risk of re-
identification where needed. 
Large language models, often containing billions of parameters, are at particular risk of memorisation 
due to their size. Overfitting increases the risk of memorisation. Regularisation, drop-out and addition 
of random noise can provide partial to complete anonymisation, depending on the implementation. 
In conclusion, if the training data are not fit for sharing, integrity preserving measures to anonymise 
personal data should be taken prior to transferring a model to a less secure environment. 
It is the responsibility of the applicant or MAH to ensure that all personal data, including those 
indirectly held within AI/ML models, are stored and processed in accordance with Union data protection 
legislation. Accordingly, all data processing activities must comply with the principles of lawfulness, 
fairness and transparency, purpose limitation, data minimisation, accuracy, storage limitation, integrity 
and confidentiality, accountability as well as the rights of data subjects as well as data protection by 
design and default.   
In the EU, supervision and monitoring of data protection compliance of AI systems falls under the 
competence of relevant Member State data protection authorities. As a general recommendation in the 
case of any personal data processing by AI, a specific risk assessment focusing on the AI system 
should be performed. This should address and document the possible impact on data subject's rights, 
freedoms and safety, and demonstrate compliance with the above listed principles, including necessity 
and proportionality of the envisaged use of personal data. 
The necessity assessment should reflect on the possibility to use data that does not allow for the 
(re)identification of a natural person, such as anonymised data. Otherwise, it should be justified why 
these options are not feasible in view of the objectives pursued.

## Page 12 (Section: 2.8.  Ethical aspects and trustworthy AI)

Reflection paper on the use of Artificial Intelligence (AI) in the medicinal product 
lifecycle 
EMA/CHMP/CVMP/83833/2023 
Page 12/18 
 
The proportionality assessment should address the adequacy of the amount and type of personal data 
to be processed (in line with data minimisation principle) and identify the least intrusive methods of 
data use to minimise the impact on data subjects. 
2.8.  Ethical aspects and trustworthy AI 
As reflected in the respective sections above, the basic ethical principles for AI listed below apply to all 
phases of the medicinal product lifecycle for human medicines and, to an appropriate degree for 
veterinary medicines. These principles were defined in the guidelines for trustworthy AI and presented 
in the Assessment List for Trustworthy Artificial Intelligence for self-assessment (ALTAI) presented by 
the independent High-Level Expert Group on AI that was established by the European Commission.  
• 
Human agency and oversight 
• 
Technical robustness and safety 
• 
Privacy and data governance 
• 
Transparency 
• 
Accountability 
• 
Societal and environmental well-being 
• 
Diversity, non-discrimination, and fairness 
ALTAI may guide the involved entities, including the developers and deployers of AI in implementing 
such principles in practice. 
To build trust in the effectiveness, reliability, and fairness of AI/ML tools, a human-centric approach 
should guide all development and deployment of AI and ML. This requires not only that active 
measures are taken during data collection and modelling (See Technical aspects) but also that both 
user and patient reported outcome and experience measures are included in the evaluation of AI/ML 
tools when they interface with an individual user or patient5.  
A systematic impact analysis should be conducted in the early stages of planning and development of 
AI/ML tools, and expertise on ethical and legal aspects (including data protection to ensure privacy by 
design) should be onboarded early in all projects. Likewise, impact of use of existing AI/ML tools needs 
to be assessed at the planning stage of the respective drug development phase to adequately include 
relevant measures and oversight by design. In this regard, applicants and MAHs are recommended to 
consider the Ethics guidelines for trustworthy AI by the High-Level Expert Group on AI, set up by the 
European Commission.  
3.  Conclusion 
In conclusion, the quickly developing field of AI/ML shows great promise for enhancing all phases of 
the medicinal product lifecycle. In several aspects such as data management, governance, and 
statistical stringency, currently established regulatory principles, guidelines, and best practices are 
directly applicable to AI/ML and efforts should be made in all organisations to reciprocally integrate 
data science competence with the respective fields within medicines development, manufacturing and 
pharmacovigilance. 
 
5 For veterinary medicines, it should be further reflected if these principles may translate into user, owner or consumer 
experiences in the context of treatment of animals.

## Page 13 (Section: 4.  Glossary)

Reflection paper on the use of Artificial Intelligence (AI) in the medicinal product 
lifecycle 
EMA/CHMP/CVMP/83833/2023 
Page 13/18 
 
However, the use of AI models with exceptionally large numbers of trainable parameters arranged in 
non-transparent architectures introduces new risks that need to be mitigated both during model 
development and deployment to ensure the safety of patients and integrity of clinical study results. 
Also, as the overarching approach is inherently data-driven, active measures must be taken to avoid 
the integration of bias into AI/ML applications and promote AI trustworthiness. 
Finally, the use of AI/ML in the medicinal product lifecycle should always occur in compliance with the 
existing legal requirements, by considering ethics and its underlying principles and with due respect of 
fundamental rights. A human-centric approach should guide all development and deployment of AI and 
ML. 
4.  Glossary 
Definitions should be aligned with the definitions contained in the Regulation of the European 
Parliament and of the Council laying down harmonised rules on artificial intelligence (Artificial 
Intelligence Act) and amending certain Union legislative acts once this regulation has been finally 
enacted. 
AI (artificial 
intelligence) 
Artificial intelligence. OECD definition - an AI system is a machine-based system designed 
to operate with varying levels of autonomy and that may exhibit adaptiveness after 
deployment and that, for explicit or implicit objectives, infers, from the input it receives, 
how to generate outputs such as predictions, content, recommendations, or decisions 
that can influence physical or virtual environments.   
Class 
imbalance 
Imbalances between categories in classification tasks. This affects model performance 
metrics, e.g., by the fact that a model always predicting the same outcome will be 99% 
accurate if 99% of test cases belong to the corresponding class. 
Data leakage 
Direct or indirect propagation of information from the intended test dataset to the model 
development environment.  
Deep learning 
Approach to creating rich hierarchical representations through the training of neural 
networks with many hidden layers 
Explainability  
The property of systems to provide, often indirect, forms of explanation for their actions. 
Feature 
A pattern in data that can be reduced to a simpler higher-level representation 
Frozen model 
A model where all parameters have been finally set, not allowing further adaption to new 
data. 
High patient 
risk setting 
Use cases where errors have consequences for the safety of humans or animals. 
High 
regulatory 
impact setting 
Use cases with substantial regulatory consequences, e.g., affecting the primary endpoint 
in a late-stage clinical trial. 
IVDR 
In Vitro Diagnostic Regulation (EU 2017/746) 
Interpretability The property to trace the system’s exact behaviour and output in a way that is 
understandable to a human user. 
LIME 
Local Interpretable Model-Agnostic Explanations; a technique that approximates any 
black box machine learning model with a local, interpretable model to explain each 
individual prediction. 
MDR 
Medical Device Regulation (EU 2017/745) 
ML (machine 
learning) 
Machine learning refers to the computational process of optimising the parameters of a 
model from data, which is a mathematical construct generating an output based on input 
data. Machine learning approaches include, for instance, supervised, unsupervised and 
reinforcement learning, using a variety of methods including deep learning with neural 
networks. 
Model 
Mathematical algorithms with parameters (weights) arranged in an architecture that 
allows learning of patterns (features) from training data 
Neural network Network of one or more layers of neurons connected by weighted links with adjustable 
weights, which takes input data and produces an output 
Overfitting 
Learning details from training data that cannot be generalised to new data

## Page 14 (Section: 5.  Related methodology guidance)

Reflection paper on the use of Artificial Intelligence (AI) in the medicinal product 
lifecycle 
EMA/CHMP/CVMP/83833/2023 
Page 14/18 
 
Representative Characteristic of a sample in relation to a reference distribution to possess similar 
characteristics 
SHAP 
Shapley Additive Explanations; an explainable AI (XAI) framework that can provide 
model-agnostic local explainability for tabular, image, and text datasets 
Test dataset 
Data used to evaluate the performance of the AI system, before its deployment. It is 
expected to be similar to production data, and proper evaluation needs test data to be 
disjoint from any data used during development. 
Training 
dataset 
Data used specifically in the context of machine learning: it serves as the raw material 
from which the machine learning algorithm extracts its model to address the given task 
Transformation Change between different representations of data 
Transparency  
The possibility to fully trace information flow within a model 
Validation 
dataset 
Data used by the developer to make or validate some algorithmic choices 
(hyperparameter search, rule design, etc.). 
5.  Related methodology guidance 
5.1.  Guidance concerning human medicines 
The following guidelines and other documents may provide useful recommendations for implementing 
AI/ML applications in the product lifecycle of human medicines: 
• 
The International Council for Harmonisation of Technical Requirements for Pharmaceuticals for 
Human Use (ICH):  
o 
‘Draft ICH guideline E11A on pediatric extrapolation Step 2b’ 
(EMA/CHMP/ICH/205218/2022) (6 April 2022) <draft-ich-guideline-e11a-pediatric-
extrapolation-step-2b_en.pdf (europa.eu)> (Accessed 26 May 2023)  
o 
‘ICH E9 Statistical Principles for Clinical Trials’ (EMA/CPMP/ICH/363/96) (1 September 
1998) <E 9 Statistical Principles for Clinical Trials (europa.eu)> (Accessed 26 May 
2023) 
o 
‘ICH E9 (R1) addendum on estimands and sensitivity analysis in clinical trials to the 
guideline on statistical principles for clinical trials’ (EMA/CHMP/ICH/436221/2017) (17 
February 2020) < E9 (R1) Step 5 addendum on estimands and Sensitivity Analysis in 
Clinical Trials to the guideline on statistical principles for clinical trials (europa.eu)> 
(Accessed 26 May 2023) 
o 
‘ICH E10 Choice of control group in Clinical Trials’ (EMA/CPMP/ICH/364/96) (1 January 
2001) <E 10 Choice of Control Group in Clinical Trials (europa.eu)> (Accessed 26 May 
2023) 
o 
‘ICH Q8 (R2) on pharmaceutical development’ (EMA/CHMP/ICH/167068/2004) (22 
June 2017) < Q8 (R2) Step 5 Pharmaceutical Development (europa.eu)> (Accessed 26 
May 2023) 
o 
‘ICH Q9 (R1) on quality risk management’ (EMA/CHMP/ICH/24235/2006) (26 July 
2023) <ICH guideline Q9 (R1) on quality risk management (europa.eu)> (Accessed  29 
May 2024) 
o 
‘ICH Q10 (R1) on pharmaceutical quality system’ (EMA/CHMP/ICH/214732/2007) (1 
June 2008) <ICH guideline Q10 on pharmaceutical quality system - Step 5 
(europa.eu)> (Accessed 29 May 2024)

## Page 15 (Section: 5.2.  Guidance concerning veterinary medicines)

Reflection paper on the use of Artificial Intelligence (AI) in the medicinal product 
lifecycle 
EMA/CHMP/CVMP/83833/2023 
Page 15/18 
 
• 
European Medicines Agency Committee for Medicinal Products for Human Use (CHMP) (formerly 
The European Agency for the Evaluation of Medicinal Products Committee For Proprietary 
Medicinal Products (CPMP)): 
o 
‘Draft guideline on multiplicity issues in clinical trials’ (EMA/CHMP/44762/2017) (15 
December 2016) <Guideline on multiplicity issues in clinical trials - for publication 
(europa.eu)> (Accessed 26 May 2023) 
o 
‘Guideline on adjustment for baseline covariates in clinical trials’ 
(EMA/CHMP/295050/2013) (26 February 2015)’ <Guideline on adjustment for baseline 
covariates in clinical trials (europa.eu)> (Accessed 26 May 2023) 
o 
‘Guideline on missing data in confirmatory clinical trials’ (EMA/CPMP/EWP/1776/99 
Rev. 1) (24 June 2010) <guideline-missing-data-confirmatory-clinical-trials_en.pdf 
(europa.eu)> (Accessed 26 May 2023) 
o 
‘Guideline on computerised systems and electronic data in clinical trials 
(EMA/INS/GCP/112288/2023) (9 March 2023)’ <Guideline on computerised systems 
and electronic data in clinical trials (europa.eu)> (Accessed 15 July 2024) 
o 
‘Guideline on registry-based studies’ (EMA/426390/2021) (16 September 2021) 
<Guideline on registry-based studies (europa.eu)> (Accessed 26 May 2023) 
o 
‘Guideline on reporting the results of population pharmacokinetic analyses’ 
(CHMP/EWP/185990/06) (21 June 2007) <Guideline on Pop PK reports - Adopted 
(europa.eu)> (Accessed 26 May 2023) 
o 
‘Guideline on the investigation of subgroups in confirmatory clinical trials’ 
(EMA/CHMP/539146/2013) (31 January 2019) <Guideline on the investigation of 
subgroups in confirmatory clinical trials (europa.eu)> (Accessed 26 May 2023) 
o 
‘Points to consider on application with 1. Meta-analyses; 2. One pivotal study’ 
(EMA/CHMP/EWP/2330/99) (31 May 2001) <Points to consider on application with 1. 
meta-analyses; 2. one pivotal study (europa.eu)> (Accessed 26 May 2023) 
o 
‘Reflection paper on methodological issues in confirmatory clinical trials planned with 
an adaptive design’ (EMA/CHMP/EWP/2459/02) (18 October 2007) <Reflection Paper 
on Methodological Issues in Confirmatory Clinical Trials Planned with an Adaptive 
Design (europa.eu)> (Accessed 26 May 2023) 
• 
Medical Device Coordination Group 
o 
‘MDCG 2022 – 5 - Guidance on borderline between medical devices and medicinal 
products under Regulation (EU) 2017/745 on medical devices’ (April 2022) 
<mdcg_2022-5_en.pdf (europa.eu)> (Accessed 15 July 2024) 
5.2.  Guidance concerning veterinary medicines 
The following guidelines and other documents may provide useful recommendations for implementing 
AI/ML applications in the product lifecycle of veterinary medicines: 
• 
The International Cooperation on Harmonisation of Technical Requirements for Registration of 
Veterinary Medicinal Products (VICH):  
o 
‘VICH GL9 on good clinical practices’ (CVMP/VICH/595/98-FINAL) (4 July 2000)  
<VICH Topic GL9 (GCP) (europa.eu)> (Accessed 20 June 2023)

## Page 16 (Section: 6.  References)

Reflection paper on the use of Artificial Intelligence (AI) in the medicinal product 
lifecycle 
EMA/CHMP/CVMP/83833/2023 
Page 16/18 
 
• 
European Medicines Agency Committee for Veterinary Medicinal Products (CVMP): 
o 
‘Guideline on statistical principles for clinical trials for veterinary medicinal products 
(pharmaceuticals)’ (EMA/CVMP/EWP/81976/2010-Rev.1) (15 July 2021) <GL on 
statistical principles for clinical trials for VMPs (pharmaceuticals) (europa.eu)> 
(Accessed 20 June 2023) 
o 
‘Guideline on clinical trials with immunological veterinary medicinal products’ 
(EMA/CVMP/IWP/260956/2021) (19 January 2021) <Guideline on clinical trials with 
immunological veterinary medicinal products (europa.eu)> (Accessed 20 June 2023) 
6.  References 
This reference list is generally applicable, unless specific applicability to human or veterinary medicines 
is indicated. 
1. European Commission, ‘Data protection: Rules for the protection of personal data inside and 
outside the EU’ <https://commission.europa.eu/law/law-topic/data-protection_en> (Accessed 
24 May 2023)  
2. European Commission, ‘Infographic - Is your software a Medical Device?’ (23 March 2021) < 
Infographic - Is your software a Medical Device? (europa.eu)> (Accessed 21 June 2023)6  
3. European Commission, Proposal for a Regulation of the European Parliament and of the Council 
laying down harmonised rules on artificial intelligence (Artificial Intelligence Act) and amending 
certain Union legislative acts, COM/2021/206 final [2021] Available at: EUR-Lex - 
52021PC0206 - EN - EUR-Lex (europa.eu) (Accessed 24 May 2023)  
4. European Commission, Proposal for a Regulation of the European Parliament and of the Council 
laying down Union procedures for the authorisation and supervision of medicinal products for 
human use and establishing rules governing the European Medicines Agency, amending 
Regulation (EC) No 1394/2007 and Regulation (EU) No 536/2014 and repealing Regulation 
(EC) No 726/2004, Regulation (EC) No 141/2000 and Regulation (EC) No 1901/2006, 
COM/2023/193 final [2023]. Available at: EUR-Lex - 52023PC0193 - EN - EUR-Lex (europa.eu) 
(Accessed 24 May 2023)7  
5. European Commission, Proposal for a Directive of the European Parliament and of the Council 
on the Union code relating to medicinal products for human use, and repealing Directive 
2001/83/EC and Directive 2009/35/EC COM/2023/192 final [2023]. Available at: EUR-Lex - 
52023PC0192 - EN - EUR-Lex (europa.eu) (Accessed 24 May 2023)8 
6. EU regulatory framework on AI <https://digital-strategy.ec.europa.eu/en/policies/regulatory-
framework-ai> (Accessed 15 July 2024) 
7. European Commission High-Level Expert Group on AI <https://digital-
strategy.ec.europa.eu/en/policies/expert-group-ai> (Accessed 24 May 2023)  
8. European Commission High-Level Expert Group on AI, ‘Assessment List for Trustworthy 
Artificial Intelligence (ALTAI) for self-assessment’ (17 July 2020). <https://digital-
 
6 Veterinary medicines not in scope.  
7 Partly applicable to human medicines only. 
8 Applicable to human medicines only.

## Page 17 (Section: 6.  References)

Reflection paper on the use of Artificial Intelligence (AI) in the medicinal product 
lifecycle 
EMA/CHMP/CVMP/83833/2023 
Page 17/18 
 
strategy.ec.europa.eu/en/library/assessment-list-trustworthy-artificial-intelligence-altai-self-
assessment> (Accessed 24 May 2023) 
9. European Commission High-Level Expert Group on AI, ‘Ethics guidelines for trustworthy AI’ (8 
April 2019) < https://digital-strategy.ec.europa.eu/en/library/ethics-guidelines-trustworthy-
ai> (Accessed 19 June 2023) 
10. European Commission, ‘Personalised medicine’ <Personalised medicine (europa.eu)> 
(Accessed 15 June 2023)8  
11. European Medicines Agency Qualification of novel methodologies for medicine development <  
Qualification of novel methodologies for medicine development | European Medicines Agency 
(europa.eu)> (Accessed 15 June 2023)8  
12. International Coalition of Medicines Regulatory Authorities (ICMRA), ‘Innovation’ < Innovation | 
International Coalition of Medicines Regulatory Authorities (ICMRA)> (Accessed 24 May 2023)8 
13. International Coalition of Medicines Regulatory Authorities (ICMRA), ‘Informal Innovation 
Network Horizon Scanning Assessment Report: Artificial Intelligence’ (6 August 2021) 
<horizon_scanning_report_artificial_intelligence.pdf (icmra.info)> (Accessed 24 May 2023)8 
14. Medical Device Coordination Group (MDCG), ‘MDCG 2019-11 Guidance on Qualification and 
Classification of Software in Regulation (EU) 2017/745 – MDR and Regulation (EU) 2017/746 – 
IVDR’ Available at: DocsRoom - European Commission (europa.eu) (11 October 2019) 
(Accessed 21 June 2023)8 
15. ‘Non-discrimination (the principle of)’ (Glossary of summaries) <EUR-Lex - 
nondiscrimination_principle - EN - EUR-Lex (europa.eu)> (Accessed 24 May 2023) 
16. Organisation for Economic Co-operation and Development (OECD) Environment Directorate 
Chemicals And Biotechnology Committee, ‘Series on Principles of Good Laboratory Practice 
(GLP) and compliance monitoring’ < https://doi.org/10.1787/2077785x> (Accessed 16 June 
2023) 
17. Organisation for Economic Co-operation and Development (OECD) Environment Directorate 
Chemicals And Biotechnology Committee, ‘Series on Principles of Good Laboratory Practice 
(GLP) and compliance monitoring: Advisory Document of the Working Party on Good 
Laboratory Practice Application of GLP Principles to Computerised Systems’ (No. 17) (9 
November 2022) <pdf (oecd.org)> (Accessed 16 June 2023) 
18. Organisation for Economic Co-operation and Development (OECD) Environment Directorate 
Chemicals And Biotechnology Committee, ‘Series on Principles of Good Laboratory Practice 
(GLP) and compliance monitoring: Advisory Document of the Working Party on Good 
Laboratory Practice on GLP Data Integrity’ (No. 22) (20 September 2021) < pdf (oecd.org)> 
(Accessed 16 June 2023) 
19. Regulation (EU) 2017/745 of the European Parliament and of the Council of 5 April 2017 on 
medical devices, amending Directive 2001/83/EC, Regulation (EC) No 178/2002 and 
Regulation (EC) No 1223/2009 and repealing Council Directives 90/385/EEC and 93/42/EEC 
[2017] OJ L 117/1. Available at: EUR-Lex - 32017R0745 - EN - EUR-Lex (europa.eu)  
(Accessed 16 June 2023)8 
20. Regulation (EU) 2017/746 of the European Parliament and of the Council of 5 April 2017 on in 
vitro diagnostic medical devices and repealing Directive 98/79/EC and Commission Decision

## Page 18 (Section: 6.  References)

Reflection paper on the use of Artificial Intelligence (AI) in the medicinal product 
lifecycle 
EMA/CHMP/CVMP/83833/2023 
Page 18/18 
 
2010/227/EU [2017] OJ L 117/176. Available at: EUR-Lex - 32017R0746 - EN - EUR-Lex 
(europa.eu) (Accessed 5 July 2023)8 
21. Regulation (EU) 2019/6 of the European Parliament and of the Council of 11 December 2018 
on veterinary medicinal products and repealing Directive 2001/82/EC. Available at : EUR-Lex - 
32019R0006 - EN - EUR-Lex (europa.eu) (Accessed 20 June 2023)9 
22. Regulation (EU) 2022/868 of the European Parliament and of the Council of 30 May 2022 on 
European data governance and amending Regulation (EU) 2018/1724 (Data Governance Act) 
[2022] OJ L 152/1. Available at: EUR-Lex - 32022R0868 - EN - EUR-Lex (europa.eu) (Accessed 
24 May 2023) 
 
9 Applicable to veterinary medicines only.


---

# 3D physiologically-informed deep learning for drug discovery of a novel vascular endothelial growth factor receptor-2 (VEGFR2)

- **Authors:** Mengyang Xu, Xiaoyue Xiao, Yinglu Chen, Xiaoyan Zhou, Luca Parisi, Renfei Ma
- **Issuer:** Heliyon
- **Type:** Scientific article
- **Published:** 2024-08-08
- **Language:** en
- **DOI:** 10.1016/j.heliyon.2024.e35769
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39220924/
- **Licence:** CC-BY-NC

## Section: Abstract

Angiogenesis is an essential process in tumorigenesis, tumor invasion, and metastasis, and is an intriguing pathway for drug discovery. Targeting vascular endothelial growth factor receptor 2 (VEGFR2) to inhibit tumor angiogenic pathways has been widely explored and adopted in clinical practice. However, most drugs, such as the Food and Drug Administration –approved drug axitinib (ATC code: L01EK01), have considerable side effects and limited tolerability. Therefore, there is an urgent need for the development of novel VEGFR2 inhibitors. In this study, we propose a novel strategy to design potential candidates targeting VEGFR2 using three-dimensional (3D) deep learning and structural modeling methods. A geometric-enhanced molecular representation learning method (GEM) model employing a graph neural network (GNN) as its underlying predictive algorithm was used to predict the activity of the candidates. In the structural modeling method, flexible docking was performed to screen data with high affinity and explore the mechanism of the inhibitors. Small -molecule compounds with consistently improved properties were identified based on the intersection of the scores obtained from both methods. Candidates identified using the GEM-GNN model were selected for in silico modeling using molecular dynamics simulations to further validate their efficacy. The GEM-GNN model enabled the identification of candidate compounds with potentially more favorable properties than the existing drug, axitinib, while achieving higher efficacy.

## Section: Introduction

Cancer remains a significant global health concern, with nearly 10 million deaths (approximately one in six) reported by the World Health Organization [1], [2]. Tumor cells take advantage of their microenvironment by releasing growth factors and cytokines that can activate surrounding normal quiescent cells and initiate a cascade of rapidly dysregulated events [3]. Once the tumor lesion exceeds a few millimeters in diameter, hypoxia and nutrient deprivation induce an “angiogenic switch” that facilitates tumor progression [4]. Therefore, modulation of the angiogenic process is recognized as an important approach for cancer treatment [5], [6].

The vascular endothelial growth factor (VEGF)-vascular endothelial growth factor receptor (VEGFR) pathway is a fundamental mechanism influencing various stages of angiogenesis, including vascular permeability, endothelial cell survival, proliferation, migration, invasion into the neighboring tissue, and capillary-like tube formation [7], [8]. A critical step in angiogenesis involves the upregulation of pro-angiogenic growth factor receptors on endothelial cells, with VEGFR2 emerging as the most important factor in promoting angiogenesis. VEGFR2, which is a transmembrane tyrosine kinase receptor, undergoes abnormal activation or overexpression during cancer development [9], [10]. By inhibiting the tyrosine kinase signaling pathway of VEGFR2, it is possible to disrupt and prevent angiogenesis during tumor proliferation [11]. Recently, VEGFR inhibitors have been extensively investigated as potential treatment options for metastasis. Several inhibitors, including axitinib, pazopanib, sorafenib, sunitinib, and tizanib, along with other drugs, have been shown to be effective against a variety of cancers, including breast, colorectal, and lung cancers [12], [13], [14]. Axitinib, a small molecule targeting VEGFR2, has demonstrated antitumor activity against various types of cancer cells, including those resistant to conventional chemotherapy and targeted therapies. Clinical trials have revealed that axitinib significantly enhances overall and progression-free survival in patients with advanced renal cell carcinoma and hepatocellular carcinoma [15]. However, similar to most current tyrosine kinase inhibitors, axitinib has considerable side effects, such as the development of resistance mechanisms [16], off-target effects [17], and gastrointestinal toxicity [18], [19].

The existing constraints associated with small- molecule inhibitors of VEGFR2 and the complexities inherent in their development underscore the necessity for innovative compounds capable of effectively targeting this key protein [20]. As computational resources and algorithmic techniques continue to progress, the integration of computational approaches into drug discovery has emerged as a promising tool to address this challenge, because virtual screening allows the rapid identification of potential lead compounds without the need for resource-intensive experimental screening [21]. As a result, computational methods allow researchers to assess the developability of drug candidates in the early stages, thereby facilitating the optimization of lead compounds and the development of safer and more efficacious drugs [22], [23].

In general, the computational methodologies employed in drug discovery can be broadly categorized into two groups: data-driven approaches, which leverage big data, and data-driven techniques (e.g., artificial intelligence, deep learning, and machine learning) [24], [25], [26], [27], and physics-based multiscale modeling methods [28], as demonstrated by tools such as Rosetta [24], molecular dynamics (MD) simulation [29], [30], and molecular docking [31]. Within data-driven methods, particularly artificial-intelligence-driven drug discovery (AIDD), many machine learning algorithms are employed to analyze the vast amounts of data generated during the drug discovery process. These algorithms are effective at distinguishing intricate patterns and relationships that are challenging or not feasible for manual identification. For instance, AIDD uses machine learning algorithms to scrutinize databases containing chemical and biological information such as gene expression data, protein structures, and compound libraries [32]. This analytical approach facilitates the identification of potential drug targets and streamlines the initial stages of drug discovery. The AIDD algorithm is proficient in predicting the physical and chemical properties of molecules, including solubility, log P, and pKa values. This predictive capability helps in the optimization of lead compounds and the avoidance of synthesizing impractical candidates, identifying those with the most promising therapeutic potential. The other type is the physics-based multiscale modeling method, which can be termed structure-based drug design (SBDD) because it relies on structural information pertaining to drugs and their targets. SBDD employs computational methods to forecast the binding affinity between small molecules and protein targets, as well as other properties, such as stability. This approach enables the design of drugs that interact specifically with certain proteins, modulate their specificity to address the underlying disease mechanism, and reveal their developability [33].

Given the limitations associated with small-molecule inhibitors of VEGFR2, in this study, we propose a novel strategy for efficiently designing potential candidates targeting VEGFR2 using three-dimensional (3D) deep learning and structural modeling. A geometrically enhanced molecular representation learning method (GEM) model with a graph neural network (GNN) was employed as the underlying algorithm to predict the pharmacological activities of the candidates. For structural modeling, flexible docking was conducted to screen candidates with high affinity and to explore the efficacy pathways and safety profiles of the inhibitors. Small-molecule compounds exhibiting consistently superior efficacy were identified based on the intersection of scores derived from both methods. Candidates selected using these two approaches were used to perform MD simulations to further validate their properties and efficacy.

## Section: Methods

A flowchart of the overall screening strategy.

## Section: Methods › Schematic of the proposed method

This study employed an integrated approach combining AIDD and SBDD to systematically screen and identify small-molecule drugs with specific targeting capabilities towards VEGFR2, as illustrated in Fig. 1. Initially, 11,521 compounds with documented biological activities and structural features were extracted from the BindingDB database. The construction of the GEM model, based on the GNN, served as the foundation for the VEGFR2 activity prediction algorithm used in this study to predict the activity of compounds within the database [34]. Next, the binding affinity of the candidate small-molecule compounds to VEGFR2 was evaluated using flexible docking. Candidates were then selected based on the combined outcomes of the GEM model and flexible docking results. Finally, the structures of the chosen candidates in complex with VEGFR2 were analyzed using MD. These candidates represent potential breakthroughs in cancer treatment. In the literature, axitinib was employed as a standard reference drug to assess the anti-tumor effects of prospective new drug candidates aimed at inhibiting VEGFR2 in numerous studies [35], [36]. Consistent with established studies, axitinib was also adopted as a control compound to assess the viability of these candidates identified in this study.Figure 1A flowchart of the overall screening strategy.Figure 1

A flowchart of the overall screening strategy.

## Section: Methods › Dataset preparation

In this study, the BindingDB and ChEMBL21 databases were selected for their extensive and meticulously curated datasets, providing abundant bioactivity data relevant to VEGFR2. BindingDB, a well-established repository specializing in the binding affinities of small molecules, was chosen for investigating drug-target interactions [37]. This database encompasses over 14,607 unique small molecule structures targeting VEGFR2, from which a subset of 11,521 small molecules with Ki (nM) values greater than zero were identified for further analysis.

Additionally, a comprehensive docking dataset from the ChEMBL21 database [38] was obtained, including 103,529 small molecule structures represented by both isomeric and canonical simplified molecular input line entry system (SMILES) (iso-SMILES and canonical SMILES). ChEMBL21 is well-known for its extensive collection of bioactive molecules, including numerous FDA-approved drugs. This database is specifically tailored for drug discovery research, providing high-quality data that enhances the reliability of computational analyses.

These databases were preferred over alternatives such as DrugBank [39] or PubChem [40] due to their emphasis on bioactivity and binding affinity data, crucial for computational approach developed in this study. The curated nature of BindingDB and ChEMBL21 ensures data reliability and relevance, significantly enhancing the data robustness of this study.

## Section: Methods › Structure preparation

The crystal structure of the human VEGFR2 kinase domain (PDB: 1VR2) was obtained from the Protein Data Bank [41]. The structure was prepared, protonated in 3D, and subjected to energy minimization using the Molecular Operating Environment (MOE) software. Due to its comprehensive suite of tools and demonstrated accuracy in docking studies, MOE has been widely utilized and validated in the literature [27], [42]. MOE has been shown to achieve comparable results to other popular software packages such as Schrödinger and Autodock Vina. For instance, both MOE and Schrödinger's Covalent Dock programs successfully predicted binding affinities in [42]. Therefore, MOE was chosen for this study to maintain consistency. The structure preparation involved the correction of gaps in the protein structure. Protonation in 3D includes the addition of hydrogen atoms, while considering the default ionization states. Flip options were applied to optimize the hydrogen-bonding networks involving amide, sulfonamide, and imidazole groups. All the water molecules were removed from the structure. The atom constraint strength was set to 10, and a flat-bottom constraint range of 0.25 was applied to prevent excessive positional deviation of the atoms. The protein conformation was optimized through energy minimization using the root mean square gradient (RMSG) method with a convergence threshold of 0.1 kcal/mol/Å.

## Section: Methods › AIDD › The graph-based molecular representations

The use of graph models to represent molecular information offers several advantages. In contrast to text-based representations of molecular data, such as SMILES and InChI (International Chemical Identifier), graph models offer a more intuitive representation of molecular structures using nodes and edges to represent atoms and their bonds. Consequently, the chemical information of a molecule can be captured more accurately [34], [43]. In this study, the molecular representation comprised two distinct graphs, namely, the bond-angle graph denoted as H and the atom-bond graph denoted as G. Graph G describes the correlation between atoms and chemical bonds, representing atoms as nodes and chemical bonds as edges connecting these nodes. In the bond-angle graph, the nodes represent chemical bonds, whereas the bond angles are regarded as graph edges. Each bond angle links two and three chemical bonds, resulting in a three-dimensional conformation of the molecule. Notably, unlike graph G, graph H captures the spatial arrangement of the molecular structure [44]. Both the atom-bond graph and bond-angle graph served as inputs to the geometry-based graph neural network (GeoGNN), contributing to a comprehensive analysis and understanding of molecular information within the context of graph neural networks [34]. More details for GeoGNN can be found in [34].

## Section: Methods › AIDD › Training settings and parameters

During the training process, a batch size of 256 was employed, the number of training epochs was 800, and validation evaluation metrics were adapted for early stopping. Adam was used as the optimizer with a weight decay of 0.0008. The cosine-annealing learning rate was employed for the schedule of the learning rates, with a specific learning rate of 0.001 and the maximum number of iterations (Tmax) set to 15. To predict the molecular properties, the dataset obtained from the BindingDB database was randomly split in an 8:2 ratio to derive the training and testing datasets. The ReLU activation function was applied, and the loss functions were the root mean squared error (MSE), mean absolute error (MAE), and coefficient of determination (R2). Additionally, layer normalization, regularization, and graph normalization were considered in GeoGNN to enhance the predictive performance [45]. All experiments were conducted on a computing system equipped with an NVIDIA GeForce RTX 3090 GPU and a 256-core AMD EPYC 7742 CPU.

## Section: Methods › Molecule docking

Molecular docking experiments were performed using MOE software, employing a dataset of 103,529 FDA-approved small-molecule drugs. The structure of the kinase domain (PDB: 1VR2) of human VEGFR2 (KDR) was retrieved from the Protein Data Bank for the docking study [41]. After structure retrieval, structure preparation, 3D protonation, and energy minimization procedures were performed using MOE. Specifically, the structure preparation phase repaired gaps in the protein structure, whereas 3D protonation added hydrogen atoms to the structure and completed protonation in the default ionization state. Water molecules were removed systematically. The atomic restraint strength was set to 10, and the extent of the flat-bottom restraint was set to 0.25 to prevent excessive positional deviations of atoms. Energy minimization was performed with a root mean square gradient of 0.1 kcal/mol/Å to optimize the protein conformation. The binding site for VEGFR2 was identified based on complexes of existing small-molecular inhibitors, and VEGFR2 (PDB: 1Y6A, 1YWN, 3CPC, 4AG8, 3WZE).

Molecular docking was performed using the method specifically designed for high-throughput docking, as shown in Eq. (1). The docking outcomes were ordered based on the dock score, which is a scoring metric primarily contingent on the interaction energy between ligands and the VEGFR2 protein. Additionally, the binding free energy of the docking outcomes underwent assessment through the generalized Born/volume integral/weighted surface area (GBVI/WSA) dG scoring method, introduced by Corbeil et al. [46], as follows:(1)ΔG≈c+α[23(ΔECoul+ΔEsol)+ΔEνdW+βΔSAweighted]

This method incorporates various terms, including the average gain and loss of rotation and translation entropy (c), a constant (α.β) determined during the function training process, a Coulomb electrostatic term (ECoul), a solvation electrostatic term calculated using the GB/VI solvation model (Esol), a van der Waals contribution (EvdW), and the surface area weighted according to the exposed area (SAweighted).

## Section: Methods › Molecular dynamics simulations

MD simulations were conducted using GROMACS 2020.05 software [47]. The SwissParam server was used to generate topology files for the ligands [48]. The system was prepared by placing protein-ligand complex structures in periodic cubic boxes with a boundary size of 1.2 nm. NaCl was added at a concentration of 0.15 mol/L for charge neutralization. An energy minimization procedure was performed using a maximum descent algorithm, with up to 5,000 steps employed to optimize the system structure. Pre-equilibration phases, including 1 ns of a constant number of particles, volume, and temperature (NVT) and 1 ns of a constant number of particles, pressure, and temperature (NPT) were performed. The system temperature was maintained at 310 K, and the pressure was set to 1 bar using the V-rescale [49] and Parrinello-Rahman algorithms [50]. The formal simulation duration was 100 ns, with a time step of 2 fs. The CHARMM36 force field was applied to all simulations [51].

Following the simulations, the stability of protein-small molecule drug binding was assessed by analyzing the RMSD of the interactions within the simulation trajectories. The truncation distances for van der Waals and Coulomb interactions were set to 1 nm. GROMACS was employed for trajectory analysis, including structural clustering, based on the RMSD of the atomic coordinates. Clusters were identified by comparing the mean RMSD of the largest cluster with those of other structures. Mean square displacement (MSD) calculations reflect the diffusion constants of molecules, offering insights into conformational changes in protein complexes and their functional implications. The binding stability of the complex was evaluated by calculating the root mean square fluctuation (RMSF), which reflects the magnitude of the fluctuation of the protein complex around its equilibrium position. Solvent-accessible surface areas (SASAs) provide information about the different regions of a molecule exposed to the solvent environment, aiding the understanding of small molecules or proteins binding to specific sites on the protein surface and their impact on protein function [52]. Energy calculations provide insights into the stability of the complex and how it is influenced by various factors, such as temperature, pressure, or the presence of ligands.

## Section: Results

The distribution of molecules is illustrated in both the three-dimensional space (A) and two-dimensional space (B). The dataset underwent an 80/20 split for training and validation purposes. T-SNE, t-distributed stochastic neighbor embedding.

The predictive performance of the geometry-based graph neural network in estimating Ki values as compared to the observed Ki values sourced from DrugBank. The dashed line represents the identity line (y = x). Evaluation metrics encompassing R2, mean absolute error (MAE), and root mean squared error (RMSE) values served as the indicators of the accuracy and predictive efficacy of the model.

The intersection of the top 5,000 compounds based on the AI model prediction score (Ki) and the docking result score (S) is depicted. The red dots represent data points corresponding to the 10 compounds exhibiting superior composite scores.

The 10 compounds screened and the positive control compound axitinib.

Predicted oral rat LD50 for the 10 compounds screened and the positive control compound axitinib from the nearest neighbor method.

Mean and standard deviation of the root mean square deviation (RMSD) (A), mean square displacement (MSD) (B), and solvent-accessible surface area (SASA) (C) for 10 representative compounds and the control compound axitinib at 50 ns post-stabilization after the simulation.

(A) 1.: Root mean square deviation (RMSD) of the complex, VEGFR2 and the Compound 11. (A) 2.: RMSD of the complex, VEGFR2 and the AXI. (B) 1.: Mean square displacement (MSD) of the VEGFR2 and Compound 11 in the complex. (B) 2.: MSD of the VEGFR2 and AXI in the complex. (C) 1.: Gyrate of the Compound 11 in the complex. (C) 2.: Gyrate of the AXI in the complex. (D) 1.: Gyrate of the VEGFR2 in the compound 11 complex. (D) 2.: Gyrate of the VEGFR2 in the AXI complex. (E): Root mean square fluctuation (RMSF) of the VEGFR2 in the compound 11 complex and the AXI complex. (F) 1.: Solvent-accessible surface area (SASA) of the VEGFR2 and the Compound 11 in the complex. (F) 2.: SASA of the VEGFR2 and the AXI in the complex. (G) 1.: The Compound 11 complex structures at 0ns, cluster and 100ns. (G) 2.: The AXI complex structures at 0ns, cluster and 100ns. (H) The total energy of the Compound 11 complex and the AXI complex.

## Section: Results › Prediction of protein-ligand affinity

The prediction of protein-ligand affinity is of vital significance in the field of computational drug design. Prior to the training phase, the Morgan fingerprint was computed using RDKit and the high-dimensional Morgan fingerprint data underwent dimensionality reduction through t-distributed stochastic neighbor embedding. This reduction facilitates the visualization and analysis of molecular distributions in both 3D and 2D spaces. Potential outlier molecules were identified by measuring the distances from each data point to the centroid in the 3D space. Outliers were defined as data points with distances exceeding three times the standard deviation of the mean distance. The identified outliers were removed from the dataset to improve data quality.

The distributions of molecules in both 3D and 2D spaces are illustrated in Fig. 2. The data points are color-coded based on the labels for informative representation. The molecular dataset exhibited strong clustering behavior, indicating that the extracted molecular features and dimensionality reduction techniques employed effectively captured the underlying structure within the dataset. This data processing procedure is expected to be advantageous for subsequent training processes.Figure 2The distribution of molecules is illustrated in both the three-dimensional space (A) and two-dimensional space (B). The dataset underwent an 80/20 split for training and validation purposes. T-SNE, t-distributed stochastic neighbor embedding.Figure 2

The predicted results, R2, mean absolute error (MAE), and root mean square error (RMSE) are shown in Fig. 3. It can be seen that the predicted results and observed results were highly correlated, which indicates that the GeoGNN had a good predictive capability since the R2 and RMSE were larger than 0.7 (p−value<0.001 for R2, indicating a highly statistically significant correlation) and the MAE was below 0.6. Therefore, the model used in this study can learn the molecular structure-affinity relationship well.Figure 3The predictive performance of the geometry-based graph neural network in estimating Ki values as compared to the observed Ki values sourced from DrugBank. The dashed line represents the identity line (y = x). Evaluation metrics encompassing R2, mean absolute error (MAE), and root mean squared error (RMSE) values served as the indicators of the accuracy and predictive efficacy of the model.Figure 3

The distribution of molecules is illustrated in both the three-dimensional space (A) and two-dimensional space (B). The dataset underwent an 80/20 split for training and validation purposes. T-SNE, t-distributed stochastic neighbor embedding.

The predictive performance of the geometry-based graph neural network in estimating Ki values as compared to the observed Ki values sourced from DrugBank. The dashed line represents the identity line (y = x). Evaluation metrics encompassing R2, mean absolute error (MAE), and root mean squared error (RMSE) values served as the indicators of the accuracy and predictive efficacy of the model.

## Section: Results › Molecular docking

Docking tests were performed using the 103,529 small molecules. The GBVI scoring function [53] was employed to estimate the free energy associated with ligand binding, considering a specified molecular posture. This scoring function served as a metric for evaluating the docking posture. Successful docking and scoring were achieved for 88,785 small molecules, resulting in the identification of the top 5,000 compounds. The intersection of the prediction score Ki and the docking result score S of the top 5,000 compounds in the AI model and the 10 screened compounds, as detailed in Supplementary Table S1, with better composite scores are shown in Figure 4, Figure 5, respectively. Although these compounds are structurally diverse, it is important to note that the nature of protein-ligand interactions and the intrinsic properties of the binding pockets enable structurally diverse molecules to selectively bind to specific pockets, as demonstrated by studies in the literature [54], [55], [56].Figure 4The intersection of the top 5,000 compounds based on the AI model prediction score (Ki) and the docking result score (S) is depicted. The red dots represent data points corresponding to the 10 compounds exhibiting superior composite scores.Figure 4Figure 5The 10 compounds screened and the positive control compound axitinib.Figure 5

Given that toxicity assessment is a critical part of the drug discovery process, the United States Environmental Protection Agency (EPA)'s Toxicity Estimation Software Tool (TEST) [57], which was widely employed in the literature for toxicity analysis [58], [59], [60], was employed to estimate the toxicity of the 10 compounds screened and the positive control compound axitinib. During the estimation process, the nearest neighbor method was used to estimate the oral rat LD50, which is the lethal dose for half of a group of 10 or more laboratory white rats when administered orally as a single dose. The results are shown in Table 1.Table 1Predicted oral rat LD50 for the 10 compounds screened and the positive control compound axitinib from the nearest neighbor method.Table 1CompoundsOral rat LD50 -Log10 (mol/kg)Oral rat LD50 mg/kg12.581582.1724.0272.4031.7011991.1743.14290.8951.4218778.7361.4218778.7372.85874.8282.034230.54102.771084.92111.1229337.37 axitinib2.451373.50

The intersection of the top 5,000 compounds based on the AI model prediction score (Ki) and the docking result score (S) is depicted. The red dots represent data points corresponding to the 10 compounds exhibiting superior composite scores.

The 10 compounds screened and the positive control compound axitinib.

Predicted oral rat LD50 for the 10 compounds screened and the positive control compound axitinib from the nearest neighbor method.

## Section: Results › MD

AIDD focused on assessing the binding affinity of small-molecule compounds to VEGFR2, whereas docking experiments concentrated on evaluating the stability of the docking poses assumed by these compounds in relation to VEGFR2. A combination of results from both methods was used to select small-molecule compounds for subsequent MD simulations. Specifically, the top 5% (5,000) of intersections derived from the outcomes of the AIDD and docking analyses were selected. Notably, 100-ns MD simulations were performed for the top 10 small-molecule compounds within this intersection set, alongside the positive control axitinib.

Examination of the structures at 100 ns revealed that no small-molecule compounds detached from the binding pocket. The long chains of the small-molecule compounds showed robust and stable binding within the pocket (Supplementary Figure MD_frame). Compounds 1, 2, and 10 were partially exposed to the solvent environment and were unable to maintain a stable binding conformation, as depicted in A, B and I in the Supplementary Figure MD_frame. In contrast, compounds 3, 4, 6, 7, 8, and 11 at 100 ns and their intermediate (cluster) structures were essentially the same, suggesting their capacity for more secure binding to VEGFR2 (see C, D, F, G, H, and J in the Supplementary Figure MD_frame). Consequently, the six small-molecule compounds, along with the control, underwent further detailed analysis.

The results of the 11 compounds as representative examples of the MD analysis are shown in Fig. 6. The RMSD, a metric for gauging the average positional alteration of all atoms between two structures, was employed in the analysis. The RMSD calculations based on the initial structure revealed a notable phase of increased values at approximately 5 ns for all ligands. However, except for compounds 3, 8, and 10, the ligands converged to stable states in the middle of this period. Specifically, compounds 4, 7, 11, and the control compound exhibited relatively constant RMSD values throughout the simulation process. A comparison of the RMSD values among the 11 simulated complexes revealed that the control compound, compound 11, and compound 2 exhibited smaller values and a stabilizing trend. Notably, when the RMSD of compound 11 stabilized, its value was the smallest among the 10 compounds, suggesting minimal postural changes during the simulation (see J in Supplementary Figure RMSD).Figure 6Mean and standard deviation of the root mean square deviation (RMSD) (A), mean square displacement (MSD) (B), and solvent-accessible surface area (SASA) (C) for 10 representative compounds and the control compound axitinib at 50 ns post-stabilization after the simulation.Figure 6

The MD results for the best-performing compound, compound 11, and the MD data for the control drug, axitinib, are shown in Fig. 7. Notably, RMSD analysis revealed that compound 11 displayed greater stability than axitinib after 80 ns, with a reduction in relative atom displacement. MSD analysis revealed that compound 11 exhibited significant protein and ligand positional changes at 50 ns. Importantly, at 50 ns post-stabilization, the trend and magnitude of the positional changes in compound 11 aligned with those observed for axitinib.Figure 7(A) 1.: Root mean square deviation (RMSD) of the complex, VEGFR2 and the Compound 11. (A) 2.: RMSD of the complex, VEGFR2 and the AXI. (B) 1.: Mean square displacement (MSD) of the VEGFR2 and Compound 11 in the complex. (B) 2.: MSD of the VEGFR2 and AXI in the complex. (C) 1.: Gyrate of the Compound 11 in the complex. (C) 2.: Gyrate of the AXI in the complex. (D) 1.: Gyrate of the VEGFR2 in the compound 11 complex. (D) 2.: Gyrate of the VEGFR2 in the AXI complex. (E): Root mean square fluctuation (RMSF) of the VEGFR2 in the compound 11 complex and the AXI complex. (F) 1.: Solvent-accessible surface area (SASA) of the VEGFR2 and the Compound 11 in the complex. (F) 2.: SASA of the VEGFR2 and the AXI in the complex. (G) 1.: The Compound 11 complex structures at 0ns, cluster and 100ns. (G) 2.: The AXI complex structures at 0ns, cluster and 100ns. (H) The total energy of the Compound 11 complex and the AXI complex.Figure 7

Mean and standard deviation of the root mean square deviation (RMSD) (A), mean square displacement (MSD) (B), and solvent-accessible surface area (SASA) (C) for 10 representative compounds and the control compound axitinib at 50 ns post-stabilization after the simulation.

(A) 1.: Root mean square deviation (RMSD) of the complex, VEGFR2 and the Compound 11. (A) 2.: RMSD of the complex, VEGFR2 and the AXI. (B) 1.: Mean square displacement (MSD) of the VEGFR2 and Compound 11 in the complex. (B) 2.: MSD of the VEGFR2 and AXI in the complex. (C) 1.: Gyrate of the Compound 11 in the complex. (C) 2.: Gyrate of the AXI in the complex. (D) 1.: Gyrate of the VEGFR2 in the compound 11 complex. (D) 2.: Gyrate of the VEGFR2 in the AXI complex. (E): Root mean square fluctuation (RMSF) of the VEGFR2 in the compound 11 complex and the AXI complex. (F) 1.: Solvent-accessible surface area (SASA) of the VEGFR2 and the Compound 11 in the complex. (F) 2.: SASA of the VEGFR2 and the AXI in the complex. (G) 1.: The Compound 11 complex structures at 0ns, cluster and 100ns. (G) 2.: The AXI complex structures at 0ns, cluster and 100ns. (H) The total energy of the Compound 11 complex and the AXI complex.

## Section: Discussion

MD analysis revealed a notable observation that the control ligand exhibited a change in RMSD during the later stages of the simulation. This finding suggests a potential ongoing alteration in the binding conformation of the control ligand, while compound 11 remained more stable. The MSD was employed to scrutinize the positional alterations in the proteins and ligands. Prior to 80 ns, the MSD values for both the control compound and compound 7 remained notably stable. Notably, compounds 3, 6, and 11, and the control compound displayed similar trends in MSD values for the proteins and ligands, whereas other compounds demonstrated considerable variation in MSD values (see Supplementary Figure MSD). Such discrepancies may contribute to larger relative displacements between the proteins and ligands, leading to diminished stability. Gyrate, is a metric reflecting molecular volume and shape, with an increased value indicating an expanded system. Specifically, the gyrations of compounds 2, 5, 6, 7, and 11 and the control compound demonstrated greater stability than the other two molecules (see Supplementary Figure gyrate_ligand). Moreover, the linear structures of compounds 2, 5, 7, and 11 and the control compound were evidenced by lower X-axis components, with gyrations primarily stemming from the planes where the Y- and Z-axes reside. Conversely, the gyrations of compounds 3, 4, and 8 exhibited sustained variability throughout the simulation, maintaining alterations in the three-axis components within a varied range (see Supplementary Figure gyrate_ligand). Compound 11 and the control compound showed similar changes in the three-axis components, with changes in the X-axis maintained at relatively larger intervals. Eleven compounds, excluding compound 3, exhibited a stable trend in gyration throughout the simulation (see Supplementary Figure gyrate_protein). Notably, compounds 6, 7, 8, and 10 exhibited a volumetric change at approximately 40 ns and stabilized thereafter, suggesting a ligand-driven conformational adjustment towards increased affinity.

The RMSF reflects the average positional change amplitude of the residual atoms in 100 ns. The distribution of the RMSF among the protein residues across all 11 compounds exhibited a similar pattern, as illustrated in Supplementary Figure RMSF. Compound 3 showed a higher RMSF value, indicating reduced binding stability to the ligand, whereas the control compound displayed a lower RMSF value, suggesting enhanced binding stability. The residues at positions 880–920 and 1,025–1050 exhibited a reduced RMSF value. This region corresponds to the binding pocket, signifying the enhanced stability attributed to ligand interactions with the residues at this site. During the simulation, the SASA values for compounds 4, 8, and 11, and the control compound consistently differed from the remaining seven compounds, displaying lower values and a steadier trend, suggesting a more constrained conformation (Supplementary Figure SASA). Additionally, the SASA value, calculated based on protein composition, showed an enhanced stability trend for compounds 4 and 8 (refer to D and H in Supplementary Figure SASA). All 10 compounds exhibited lower total energy than the control compound (Supplementary Figure energy). The total energy fluctuations of compounds 6, 7, and 11 closely resembled those of the control compound (refer to F, G, and J in Supplementary Figure energy). In particular, compound 11 demonstrated a performance similar to that of axitinib in MD simulations, making it a promising VEGFR2 inhibitor.

While compounds 2, 4, 7, and 10 showed lower oral rat LD50 values, indicating higher toxicity compared to the estimated toxicity of axitinib, compounds 1, 3, 5, 6, 8, and 11 exhibited lower toxicity, as evidenced by the toxicity assessment results shown in Table 1. Notably, compound 11 demonstrated the lowest estimated toxicity. Moreover, the experimental data for compound 11 included in TEST revealed an oral rat LD50 value of 17011.96 mg/kg [57], further supporting its lower toxicity compared to the estimated toxicity of axitinib.

## Section: Conclusion

The outcomes of the Gyrate and SASA analyses in the comparative assessment of compound 11 and the control compound axitinib demonstrated substantial consistency. In contrast, axitinib exhibited a lower RMSF value and lower energy, indicative of higher stability in the binding interaction between the drug molecule axitinib and the receptor over the course of 100 ns. The structures at 0 ns, clusters, and 100 ns also visually reflected the more stable binding characteristics of axitinib to VEGFR2. Thus, compound 11 and the existing drug axitinib exhibit distinct advantages. Compound 11 emerged as a promising lead compound with the potential for subsequent drug development endeavors aimed at targeting VEGFR2.

One limitation of this study is the lack of experimental validation. Although promising, the proposed strategy may face challenges in translating the findings into clinical settings. In vitro and in silico predictions do not fully capture the dynamic and multifaceted nature of human physiology and pathology, potentially leading to discrepancies between predicted and actual outcomes in clinical trials. In the future, more robust experiments, including studies involving cell lines and animals, will be employed to further validate the compounds identified in this study. Nevertheless, the computational approach used in this study contributed significantly to cost reduction and time savings in the drug-design process. Another limitation of this study is that the results relied solely on the software MOE. Although MOE was chosen for its comprehensive suite of tools and proven accuracy in docking studies, future studies could benefit from integrating results obtained from multiple software platforms for docking studies. This approach would further enhance the reliability and justification of the screened compounds. Moreover, this study solely utilized the well-known axitinib as a benchmark drug to substantiate a proof-of-concept, demonstrating the viability of our methodology. In the future, further and more recent FDA-approved drugs aimed at targeting VEGFR2 will be assessed and compared in a follow-up study. Finally, potential adverse immune reactions that these compounds might induce were not considered at this stage. In the future, integrated in vitro and in vivo studies to evaluate the immunogenicity of the lead compounds will be crucial for understanding their potential in therapeutic applications.

Another potential direction for future research could involve integrating multi-omics data (genomics, transcriptomics, and proteomics) to enhance the predictive power of the models, thus providing a more comprehensive understanding of the molecular landscape associated with VEGFR2 inhibition and facilitating the identification of more precise drug candidates. Additionally, considering potential off-target effects, conducting molecular docking simulations in the future to predict the binding affinity of inhibitors to proteins other than VEGFR2, especially those with structures similar to VEGFR2, will aid in identifying potential off-target effects of the identified molecules. Furthermore, as drug stoichiometry analysis plays a critical role in drug discovery, integrating experiments with computational predictions in the future will facilitate further investigation into the effectiveness of protein binding.

In conclusion, this study introduced a novel approach using 3D deep learning and structural modeling for the design of potential VEGFR2 inhibitors. Employing a geometric-enhanced molecular representation learning method and flexible docking, this study identified candidate compounds with more favorable properties than the FDA-approved drug axitinib.

## Section: Data sharing statement

The data underlying this study are publicly available in BindingDB at https://www.bindingdb.org/ and ChEMBL21 at https://www.ebi.ac.uk/chembl/.

## Section: CRediT authorship contribution statement

Mengyang Xu: Writing – original draft, Methodology, Investigation, Formal analysis, Data curation, Conceptualization. Xiaoyue Xiao: Investigation, Formal analysis. Yinglu Chen: Investigation, Formal analysis. Xiaoyan Zhou: Writing – review & editing. Luca Parisi: Writing – review & editing, Supervision. Renfei Ma: Writing – review & editing, Supervision, Project administration, Funding acquisition, Conceptualization.

## Section: Declaration of Competing Interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.


---

# A comprehensive benchmarking of machine learning algorithms and dimensionality reduction methods for drug sensitivity prediction

- **Authors:** Lea Eckhart, Kerstin Lenhof, Lisa-Marie Rolli, Hans-Peter Lenhof
- **Issuer:** Briefings in bioinformatics
- **Type:** Scientific article
- **Published:** 2024-05-23
- **Language:** en
- **DOI:** 10.1093/bib/bbae242
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38797968/
- **Licence:** CC-BY

## Section: Abstract

AbstractA major challenge of precision oncology is the identification and prioritization of suitable treatment options based on molecular biomarkers of the considered tumor. In pursuit of this goal, large cancer cell line panels have successfully been studied to elucidate the relationship between cellular features and treatment response. Due to the high dimensionality of these datasets, machine learning (ML) is commonly used for their analysis. However, choosing a suitable algorithm and set of input features can be challenging. We performed a comprehensive benchmarking of ML methods and dimension reduction (DR) techniques for predicting drug response metrics. Using the Genomics of Drug Sensitivity in Cancer cell line panel, we trained random forests, neural networks, boosting trees and elastic nets for 179 anti-cancer compounds with feature sets derived from nine DR approaches. We compare the results regarding statistical performance, runtime and interpretability. Additionally, we provide strategies for assessing model performance compared with a simple baseline model and measuring the trade-off between models of different complexity. Lastly, we show that complex ML models benefit from using an optimized DR strategy, and that standard models—even when using considerably fewer features—can still be superior in performance.

## Section: Introduction

Cancerous diseases are characterized by geno- and phenotypic heterogeneity impacting the success of chemotherapeutic treatments. Consequently, one major goal of precision oncology is to identify the most efficient drug candidates and to detect biomarkers affecting treatment response.

Cancer cell line panels like the Genomics of Drug Sensitivity in Cancer (GDSC) [1] and Cancer Cell Line Encyclopedia (CCLE) [2] provide multi-omics measurements and drug response metrics for various cancer types and can be used to study the relationship between cellular features and treatment outcome. Due to the high dimensionality of these datasets, machine learning (ML) is often applied for their analysis [3–34]. This typically involves the prediction of drug response measures and the inference of sensitivity- or resistance-related biomarkers.

Increasingly complex models such as deep neural networks with carefully constructed architectures [4, 19, 24, 26, 30, 32] and advanced tree-based models [8, 16] have shown promising results recently. However, Li et al. [35] found that many deep learning approaches are not superior in performance to simple feed-forward neural networks or random forests for drug sensitivity prediction. Apart from that, keeping models as simple and interpretable as possible is desirable for studying the relation between cellular features and drug response and creating trustworthy, comprehensible predictions to enable ML use for clinical decision support. This highlights the need to investigate how complex models must be given the current data situation and how even standard models can be elevated through hyperparameter tuning and choosing informative inputs. Moreover, given the availability of programming packages such as caret [36] and scikit-learn [37], basic ML models can even be trained by non-experts, rendering them a particularly attractive starting point for model development.

When ML is used to investigate high-dimensional datasets such as the GDSC or CCLE data, it is typically indispensable to perform dimension reduction (DR) (i.e. to reduce the number of input features) to counteract the curse of dimensionality, reduce runtime and potentially increase model interpretability. Two groups of DR algorithms can be distinguished: feature selection (FS) and feature extraction (FE) techniques [38]. FS algorithms aim to choose a subset of interesting features from a given feature set. They can be grouped into filters, wrappers and embedded methods [38]. Filter methods can be seen as a pre-processing step, where features are chosen before applying any ML algorithm. In contrast, wrappers train ML models using different feature sets and select the best features based on model error. Lastly, embedding methods are ML algorithms like elastic net (cf. Methods) where FS is integrated into the model training. In contrast to FS, FE aims to transform a high-dimensional dataset into a lower dimensional representation, which still retains the properties of the original data space. While FE does not require discarding potentially valuable features, the resulting low-dimensional data representation is often not easily interpretable, as each calculated feature is a combination of features from the original feature space. Both FS and FE are commonly used for drug sensitivity prediction (cf. Supplementary Table 1 which lists the used DR methods used for 32 state-of-the-art methods): one straightforward FS approach is choosing features with strongest correlation to the response [23, 39]. Alternatively, many approaches only consider features of literature-derived oncogenes as predictors [4, 5, 7, 11, 19, 22, 25, 26, 29], while Su et al. [8] use randomly selected features.

Regarding FE, principal component analysis (PCA) was employed by several contestants of the DREAM7 drug sensitivity prediction challenge [39], while others utilize autoencoders [3, 25, 31, 33, 34] and Wang et al. [10] employ a matrix factorization approach. A biologically more interpretable FE approach is to summarize gene-level data into scores for the corresponding molecular pathways, as done by Tang et al. [9] and Karagiannaki et al. [40].

Given the plethora of available ML algorithms and DR techniques, it is challenging to select the right combination of methods. Unfortunately, our literature research revealed that publications often do not report whether different approaches were tested or how they performed in comparison (cf. Supplementary Table 1) highlighting the need for a systematic assessment. There exist several insightful reviews and evaluations on ML and DR in drug sensitivity prediction [41–45]: Chen et al. [41] benchmarked several state-of-the-art deep learning approaches but did not investigate different DR methods. Jang et al. [42] analyzed the performance of different input features and prediction algorithms. However, they focused on inputs from varying omics-types rather than different DR techniques. Koras et al. [43] compared several FS methods but did not account for size differences in the investigated feature sets, which might impact performance more significantly than the actual features. Considering the goal of having accurate but interpretable models, it is crucial to investigate whether small feature sets are sufficient to train good predictors and how they compare with larger sets.

In this paper, we discuss how the problem of drug sensitivity prediction can be addressed using four different ML algorithms in combination with nine DR techniques. Using gene expression values and drug response measures from the GDSC, we trained more than 16 000 000 models for 179 compounds and compared the results regarding prediction accuracy, runtime and interpretability.

Our findings reveal that the choice of both the ML algorithm and DR method have substantial impact on prediction performance. For most drugs, elastic net models had the best performance and lowest runtime, while neural networks performed worst. The best-performing DR methods were PCA and a heuristic by Kwak and Choi [46] that is based on the minimum-redundancy-maximum-relevance principle. Overall, FS methods considering the drug response performed better than methods using only expression values.

We also discuss how performance trade-offs between models and for different numbers of input features can be assessed. Furthermore, we show how cross-validation (CV) can be used to bias models to improve predictions for the most sensitive cell lines, which are typically highly underrepresented in drug screens [5, 11, 16]. To account for the goal of interpretable models, we characterize the four investigated ML algorithms in terms of model transparency [47] and explainability [48]. We also show how the selected features for each drug can already present valuable insight into drug responses even without applying any ML algorithm. Lastly, our analyses using a multi-omics multi-task deep learning approach by Chiu et al. [3] prove that complex prediction models (1) can benefit substantially from using different DR methods and (2) can be outperformed by standard models even with small feature numbers.

## Section: Methods

Overview of all ML algorithms investigated for the training of models, including the used R/Python packages and tuned hyperparameters. The last column denotes the number of testes hyperparameter combinations. Unless stated otherwise, we employed the default parameters of each algorithm in their respective package. Further information on the architecture and hyperparameters of the trained neural networks can be found in Table 3 of the Supplement

## Section: Methods › Dataset

Data for our analyses were obtained from the GDSC database (Release 8.3). More specifically, we downloaded normalized expression values (Affymetrix Human Genome U219 Array) for 17 419 genes and drug-screening data in the form of logarithmized IC50 values for all 198 drugs screened in the GDSC2 dataset (CellTiter-Glo assay). Out of these 198 drugs, we only considered those 179 drugs for which sensitivity measures for at least 600 cell lines are provided.

Note that the GDSC also provides AUC values as a measure of drug response. However, we found that the concentration ranges used to determine the AUC values do not correspond well to clinically feasible treatment concentrations (cf. Supplementary Figure 12). Consequently, we refrained from their analysis.

## Section: Methods › Model inputs and outputs

We trained drug-specific regression models that predict the logarithmized IC50 values of cell lines from their gene expression data using four ML algorithms (random forests, neural networks, boosting trees and elastic net). Model inputs are generated using six FS and three FE techniques that select/compute input features based on normalized gene expression values. Some of the FS methods additionally consider the IC50 values to determine the most informative features. To investigate how the number of input features \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} affects the model performance, we generated input feature sets for each \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k \in \{1,2,3,...,25, 50, 100, 200, 300, 400, 500\}$\end{document}.

In the following text, we will refer to one setting as one combination of ML algorithm, DR technique and number of inputs \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} used to train a certain model. Details on the investigated ML algorithms and DR techniques are presented below.

## Section: Methods › Model training and testing

For each drug, we divided the available cell lines into a training set (80% of cell lines) and a test set (20%). On the training set, we performed a 5-fold CV to determine the best-performing hyperparameters of the ML model (see Table 1) using the mean squared error (MSE) as error measure. For each hyperparameter combination, one final model is trained on the complete training data and its performance is evaluated on the test set.

This procedure is performed for each setting (i.e. combination of ML algorithm, DR method and number of inputs) separately. As the training and test data (as well as the data in each CV fold) are identical across all settings for one drug, the performance of different settings can be compared directly.

Note that input features are selected/computed using only samples in the training set (both for the CV and the training of the final model), such that the test data do not influence the choice of features.

Overview of all ML algorithms investigated for the training of models, including the used R/Python packages and tuned hyperparameters. The last column denotes the number of testes hyperparameter combinations. Unless stated otherwise, we employed the default parameters of each algorithm in their respective package. Further information on the architecture and hyperparameters of the trained neural networks can be found in Table 3 of the Supplement

## Section: Methods › ML algorithms

In the following text, we briefly summarize the four ML algorithms that we compare in this publication. An overview of the used R/Python packages and hyperparameters for each model can be found in Table 1.

The predictor matrix for each model is defined as \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $X \in \mathbb{R}^{n \times k}$\end{document} where each entry \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $x_{ij}$\end{document} corresponds to the value of input feature \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $j \in \{1,...,k\}$\end{document} for cell line \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $i \in \{1,...,n\}$\end{document}. Furthermore, \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $y \in \mathbb{R}^{n}$\end{document} denotes the response vector, where each entry \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $y_{i}$\end{document} corresponds to the logarithmized IC50 value of cell line \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $i$\end{document}.

## Section: Methods › ML algorithms › Elastic net

Elastic net is a regression algorithm that estimates the response \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $y_{i} \in \mathbb{R}$\end{document} of a sample \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $i$\end{document} as a linear combination of its input features \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $x_{i} = (x_{i1}, \dots , x_{ik}) \in \mathbb{R}^{k}$\end{document} [54], i.e. the predicted response \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $\hat{f}(x_{i})$\end{document} is given as

The vector \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $\beta = (\beta _{1},..., \beta _{k}) \in \mathbb{R}^{k}$\end{document} contains weights for each feature and is determined such that the squared error between the actual response \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $y_{i}$\end{document} and the predicted response \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $\hat{f}(x_{i})$\end{document} is minimized over all \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $n$\end{document} training samples:

The optimization includes two regularization penalties based on the L1 and L2 norms that shrink feature weights toward zero. The L1 norm allows weights to become exactly zero, such that the respective features are excluded from the model. The parameter \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $\lambda $\end{document} controls how much the regularization impacts the optimization, while \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $\alpha $\end{document} regulates the impact of each norm.

## Section: Methods › ML algorithms › Random forests

Random forests are a regression/classification algorithm based on decision trees [55]. They combine predictions of many trees into one prediction through averaging/majority vote. To ensure that the trees differ, they are decorrelated by (1) building each tree on a subset of training samples drawn randomly with replacement and (2) only considering a random subset of features for each decision split in a tree.

## Section: Methods › ML algorithms › Boosting trees

Similar to random forests, boosting tree models consist of multiple decision trees. However, they combine predictions of individual trees in an iterative rather than a parallel fashion [56]: in model training, an initial prediction is made as the mean response of all training samples. Next, trees are iteratively added to correct the error of this prediction. Each new tree is trained to estimate the residuals of the prediction obtained by adding up predictions of all previously built trees.

## Section: Methods › ML algorithms › Neural networks

Neural networks are prediction models loosely modeled after signal transmission mechanisms in human brains [57]. They consist of multiple layers of nodes (artificial neurons) connected through weighted directed edges. Each node receives information through incoming edges, then processes the information, which typically involves applying a non-linear activation function, and passes the resulting value via outgoing edges. There exists a plethora of neural network architectures. Here, we only consider fully connected, feed-forward networks, where each node is connected to all nodes of the consecutive layer.

## Section: Methods › Dimensionality reduction techniques

The GDSC offers expression values for more than 17 000 genes and around 1000 cell lines. This means that the number of features that characterize each sample is considerably larger than the number of samples itself. When performing ML on such a dataset, performing a DR to counteract the curse of dimensionality is usually indispensable. Additionally, reducing the input dimension can notably shorten the runtime and computational resources needed for training while increasing model interpretability. In the following text, we introduce the six FS and three FE approaches we investigated in this publication.

## Section: Methods › Dimensionality reduction techniques › FS techniques

FS methods aim at choosing a subset of informative features from a given feature set.

Randomized Feature Selection

We generated randomized feature sets by randomly sampling gene sets of size \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} from all genes with expression values provided in the GDSC. To get a more stable estimate of the prediction errors for random features, we generated 10 random feature sets for each \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} and averaged the error measures of the 10 corresponding models.

Literature-based Feature Selection

For the literature-based FS, we retrieved a list of cancer driver genes from the IntOGen website (Release 1 February 2020) [58]. We only considered genes for which expression values are provided in the GDSC. Additionally, genes with warnings in the IntOGen database (e.g. genes that are known artifacts) were removed. Next, we sorted the remaining 476 genes according to their smallest IntOGen tier from tier 1 (i.e. genes with the strongest evidence of being cancer drivers) to tier 3. Within each tier, genes were sorted descendingly according to the number of cohorts for which they have been reported as a cancer driver. From the beginning of this sorted gene list, the first \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} genes were chosen.

Variance-based Feature Selection

For this FS, we chose the \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} genes, for which the variance of expression values was the largest.

Correlation-based Feature Selection

For this FS, we chose the \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} genes with the highest absolute Pearson correlation coefficient between the expression values of each gene and the IC50 values of the corresponding cell lines.

Enrichment-based Feature Selection

We developed this FS to identify genes whose up-/downregulation is linked to sensitivity/resistance to a given drug. First, z-scores are calculated for each gene separately, where the mean and standard deviation of expression values were derived from the training data. We then consider a gene upregulated (downregulated) in a cell line if its z-score is larger (smaller) than 1.65, which corresponds to the 95% (5%) percentile of a standard normal distribution.

Our approach uses gene set enrichment analysis (GSEA) [59], as implemented in the GeneTrail webserver [60]. GSEA tests for the accumulation of a certain feature (e.g. up-/downregulation of a gene) at either end of an ordered list of samples (e.g. cell lines): First, cell lines are sorted by increasing IC50 for the drug of interest to obtain a ranked list. Second, a Kolmogorov–Smirnov test [61, 62] is conducted twice per gene to determine whether cell lines in which the gene is (1) up- or (2) downregulated are enriched the top/bottom of the list, respectively. Each test yields a P-value and a direction denoting whether the enrichment occurred at the top or bottom of the list. We adjusted the P-values using the Benjamini–Hochberg procedure [63] separately for all up- and all downregulated genes. This procedure results in four lists of genes: genes that are up-/downregulated among the most sensitive/resistant cell lines, respectively. To obtain the \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} most important features, we proceeded as follows: for each list, we order genes from smallest to largest P-value and assign a rank to each gene, starting at 1. If a gene occurs in multiple lists, we keep it only in the list with the smallest rank. Next, we merge all lists by sorting genes according to their rank, and P-values are used to break ties. From the beginning of this merged list, we then select the first \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} features.

MRMR Feature Selection

This FS is based on the minimum-redundancy-maximum-relevance (MRMR) principle, which aims to select features with a strong dependence on the response variable (i.e. large relevancy) but weak dependence on each other (i.e. small redundancy). Our implementation is based on a greedy heuristic by Kwak and Choi [46] that iteratively selects features, starting with the most informative ones. As dependence-measure, the mutual information \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $I$\end{document} is employed. Let \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $F$\end{document} denote the set of all potential input features (i.e. genes) and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $C$\end{document} the response variable (i.e. ln(IC50) values for a given drug). Here, both expression and ln(IC50) values were discretized using an equal-width binning with six bins.

Let \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $S$\end{document} be the list of selected features, which is initially empty. In each iteration, the feature \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $f_{i} \in F$\end{document} that maximizes the following term is added to \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $S$\end{document} and removed from \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $F$\end{document}:

Here, \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $H$\end{document} denotes the entropy and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $I$\end{document} denotes the mutual information. This procedure is repeated until \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $|S| = k$\end{document}. The result is a list of \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} features ordered by importance. To keep the runtime manageable, we limited \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $F$\end{document} to the 1000 genes with the largest mutual information to the IC50s.

As the presented approach is a greedy heuristic, the selected features are not guaranteed to provide an optimal solution to the MRMR problem for a given \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document}. Hence, we additionally implemented an MRMR-based FS as a quadratic optimization program (QP). However, the high runtime of this approach only allowed us to compute feature sets for \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k\leq 5$\end{document} in a reasonable time (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $<500$\end{document} s for a single \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} on a single training dataset). Additionally, we found no improvement in test MSE when employing the features selected by the QP instead of the heuristic to train ML models (see Supplement). Consequently, the QP is not discussed further.

## Section: Methods › Dimensionality reduction techniques › FE techniques

FE techniques transform a high-dimensional dataset into a lower dimensional representation by generating new features as (non-)linear combinations of the original features. Thereby, information from potentially all features can be condensed into a significantly lower dimension without discarding any features. However, this generally comes with a loss of interpretability regarding the generated features.

Principal Component Analysis

We performed a PCA (R package stats, v. 3.6.3) using the expression values of all cell lines in the respective training set to extract a lower dimensional representation of cell lines using the first \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} principal components. We used the feature coefficients calculated on the training data to project the test set cell lines into the same \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document}-dimensional space.

PASL

PASL (Pathway Activity Score Learning) by Karagiannaki et al. [40] is a DR approach that aims to produce (biologically) interpretable features. Given a feature matrix (i.e. gene expression data) and predefined feature sets (i.e. genes belonging to a certain pathway), PASL projects the data into a latent space, where each newly constructed feature is a linear combination of features from one of the predefined feature sets. The computed features can be interpreted as pathway activity scores for each sample. Just like PCA, PASL computes features in an ordered manner, such that the features explaining most of the variance in the data are computed first. We applied PASL with default parameters to the training data to generate \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} pathway features. As feature sets, we considered the same data as Karagiannaki et al., namely pathways from KEGG [64], Reactome [65] and BioCarta [66]. Analogously to PCA, we applied the linear combinations computed by PASL to the test cell lines to obtain their representation in the new feature space.

Autoencoder

An autoencoder is a type of neural network that encodes data into a lower dimension. It consists of an encoding part, which generates a lower dimensional representation of the input, and a decoding part, trained to reconstruct the original inputs from the encoded representation. After training the entire network, only the encoder is used to generate the lower dimensional (here: \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document}-dimensional) representation of the inputs for training and test data. As one autoencoder has to be trained for each drug, training dataset and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} separately, the high runtime (on average 4.5 min for a single model) did not permit us to perform any hyperparameter tuning. Note that tuning would require an additional CV nested inside the main CV described in the Methods section. The used hyperparameters and network architecture can be found in Supplementary Table 4.

## Section: Results

We trained drug-specific models that predict logarithmized IC50 values for 179 drugs of the GDSC2 dataset using the four ML algorithms and nine DR techniques presented above. To investigate how the number of input features \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} impacts performance, we trained models for each \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k \in \{1,2,3,...,25,50,100,200,300,400,500\}$\end{document}. The hyperparameters of each algorithm (cf. Table 1) were tuned using a 5-fold CV on the training data.

Note that we only trained neural networks on the 50 drugs with the most available cell lines due to their high runtime (cf. Fig. 5 and Supplementary Table 2). Additionally, for a small number of settings, no models could be trained (see Fig. 1).

In the following text, we first analyze the statistical performance of the investigated ML algorithms and DR techniques. Then, we assess the trade-offs between models of different complexity. Next, we show how the prediction of sensitive cell lines can be improved using different error measures for hyperparameter tuning. We then compare the four ML algorithms regarding their runtime and interpretability and exemplarily investigate features derived from the MRMR FS and their importance in elastic nets. Lastly, we show that complex prediction models equally benefit from DR by investigation of a deep learning method by Chiu et al. [3].

Average test MSEs. This figure depicts the test MSEs averaged over all drugs for each ML algorithm (A) and DR method (B). The x-axis denotes the number of input features, the y-axis denotes the mean test MSE, and the coloring represents the different ML algorithms or DR techniques. Boosting trees, elastic nets and random forests were trained for all 179 drugs in the GDSC2 dataset for which IC50s for more than 600 cell lines were available were. For neural networks, models were only trained on the 50 drugs with most available cell lines due to their large runtime (cf. Supplementary Table 2 and Fig. 5). Additionally, no models could be trained for the following settings: for elastic net, no models for \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k=1$\end{document} exist since the used R package glmnet only allows feature sets with \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k\geq 2$\end{document}. For the IntOGen features, results for \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k=500$\end{document} do not exist since our filtered IntOGen list (cf. Methods) consists of 476 features only. For the PCA features, results for \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k=500$\end{document} do not exist since most CV training sets contain less than 500 samples, and the number of principal components computed by the stats R package is limited by the number of input samples.

Best-performing models for each drug and number of input features. Sub-figure A and B, respectively, show how often each ML algorithm and DR method yielded the smallest test MSE for each \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document}. Sub-figure C shows how often a given combination of ML algorithm and DR method yielded the best results summarized over all \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document}. Sub-figures D–F depict the same results, but only the feature number \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} yielding the smallest test MSE for each drug is shown.

Performance comparison of different models and (numbers of) features. Each sub-figure depicts a comparison of test MSEs for different scenarios, where the MSE for one scenario is divided by the MSE of the other: Sub-figure A compares the test MSE of the best-performing models for each drug and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} to the MSE of drug-specific baseline models that always predict the mean ln(IC50) of the training samples. Sub-figure B compares the test MSE of the best-performing models with \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k<300$\end{document} features to those with \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k=300$\end{document} features. Sub-figures C and D compare the best-performing models using correlation-based features and features derived from PCA or the IntOGen gene list, respectively.

Effect of different hyperparameter tuning measures. This figure compares the test MSEs for sensitive and resistant cell lines when using the conventional MSE for hyperparameter tuning versus the mean between the MSE of all sensitive and all resistant cell lines. To identify a cell line as sensitive/resistant, we compare its ln(IC50) to a drug-specific threshold derived through a procedure described by Knijnenburg et al. [5].

Runtime comparison of ML algorithms. Sub-figure A depicts the mean training duration for a single model (i.e. one hyperparameter combination) for increasing feature numbers. Sub-figure B depicts the duration of performing the 5-fold CV plus fitting of models on the whole training data accumulated over all hyperparameter combinations.

Interpretability of ML models. We assess the abstract concept of interpretability using the terms transparency and explainability, as introduced by Lipton [47] and Imrie et al. [48], respectively. Transparency describes the inherent complexity of an ML model, including the model size in terms of its parameters and the human intelligibility of its computations. Explainability focuses on deriving explanations for why certain predictions are obtained for certain inputs. This includes feature importance, the identification of training samples that are similar to a given input, the effect of altering certain inputs and the examination of how certain (human) concepts are interpreted by the model. Notably, inherently non-transparent models (e.g. deep neural networks) can still provide good explainability. However, extracting knowledge from the model might require applying additional tools, which can be challenging, especially for non-ML experts. Here, we only list the explainability methods that are readily available in the used R/Python packages (cf. Table 1). Imrie et al. provide a good overview of further tools for different applications and ML algorithms [48]

Feature importance of MRMR features. Sub-figure A shows the importance of features selected by the MRMR FS with \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k=25$\end{document} for all drugs. The x-axis denotes the mean rank of each gene in the feature lists of all drugs, and the y-axis denotes the number of drug-lists in which the gene occurs. Sub-figure B shows the importance of the MRMR features in the best-performing elastic net models trained on these features. The x-axis denotes the mean rank of each gene according to the absolute size of feature coefficients derived from the trained models, and the y-axis denotes the number of models in which the feature had a non-zero coefficient. The color denotes whether the genes have a negative/positive coefficient (cf. \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $\beta _{j}$\end{document} in Equation 1) in the trained models, indicating their tendency to de-/increase predicted IC50s.

## Section: Results › Average test MSE

We first analyzed which ML method(s) and DR approach(es) yield the smallest test error across all investigated drugs. Fig. 1A compares the test MSE of all ML models averaged across drugs and DR approaches, while Fig. 1B depicts the test MSE of all DR approaches averaged across drugs and ML models. Overall, errors decrease as \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} increases. The decrease is most drastic from \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k=1$\end{document} to \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k=10$\end{document} and again when \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k \geq 50$\end{document}, especially for elastic net. For \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k> 8$\end{document}, elastic net and random forest yield the smallest MSE, while neural networks consistently perform the worst. A comparison of all algorithms using only the 50 drugs we used to train the neural networks is provided in the Supplement and shows the same trends.

Figure 1B shows that the MRMR and correlation-based FSs, followed by PCA, yield the smallest test MSE. Interestingly, for \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k> 200$\end{document}, the average error of PCA-based models increases. More detailed figures that show results for each combination of ML algorithm and DR method separately are provided in the Supplement. There, it can be seen that using PCA with \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k> 200$\end{document} only increases errors for boosting trees and random forests but outperforms all other DR methods for elastic net and neural networks.

## Section: Results › Best-performing settings

In this section, we analyze which combinations of ML algorithm and DR technique resulted in the smallest test MSE for each drug and how often a certain combination performed best. Figure 2 summarizes how often each combination resulted in the best model for each drug. Sub-figures A to C depict the best-performing combinations for each \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} and Sub-figures D to F show the same statistics for the best-performing \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} only.

Figure 2A shows that random forest and elastic net are the most prevalent ML models, with elastic net being more dominant for large feature numbers. Larger feature sets likely contain more redundant or uninformative features, which might be easily ignored by elastic net but not by tree-based models since a random subset of features is selected in each node.

Regarding the DR techniques (cf. Fig. 2B), PCA and MRMR are the most successful, followed by the correlation-based FS. For large \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document}, PCA is the most dominant approach. Figure 2C shows how often each combination of ML and DR was the best-performing. In agreement with the previous results, elastic net and PCA are by far the most successful combination.

Sub-figures 2D to F show the same results as A to C but limited to only the \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} that resulted in the best performance for each drug. For almost all drugs, large feature numbers \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $\geq 100$\end{document} yielded the best results. The combination of elastic net and PCA was the best-performing for 76 of the 179 investigated drugs. However, almost all DR techniques other than the random FS had the best performance for at least some drugs.

As discussed previously, FE-based features are inherently difficult to interpret. Therefore, we performed the same analysis using FS algorithms only. The results are presented in Supplementary Figure 7 and show that among all FS approaches, MRMR is chosen most often, followed by the correlation- and enrichment-based approaches. Note that all of these methods utilize not only the expression values but also the IC50 values to derive informative features.

Best-performing models for each drug and number of input features. Sub-figure A and B, respectively, show how often each ML algorithm and DR method yielded the smallest test MSE for each \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document}. Sub-figure C shows how often a given combination of ML algorithm and DR method yielded the best results summarized over all \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document}. Sub-figures D–F depict the same results, but only the feature number \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} yielding the smallest test MSE for each drug is shown.

Performance comparison of different models and (numbers of) features. Each sub-figure depicts a comparison of test MSEs for different scenarios, where the MSE for one scenario is divided by the MSE of the other: Sub-figure A compares the test MSE of the best-performing models for each drug and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} to the MSE of drug-specific baseline models that always predict the mean ln(IC50) of the training samples. Sub-figure B compares the test MSE of the best-performing models with \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k<300$\end{document} features to those with \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k=300$\end{document} features. Sub-figures C and D compare the best-performing models using correlation-based features and features derived from PCA or the IntOGen gene list, respectively.

## Section: Results › Baseline

The comparison of test MSEs in the previous sections allowed us to identify the best-performing settings and hyperparameters. However, we do not know whether a model is a good predictor without a proper baseline error.

A straightforward approach to obtain a baseline is to use a dummy model that always predicts the mean response (here: mean ln(IC50)) of training samples. Figure 3A depicts the ratio between the test MSE of the best-performing model for each drug and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} and the baseline MSE for the corresponding drug. All models are an improvement over the baseline. For 80% of models, the improvement is at least 20% (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $\frac{MSE}{Baseline} \leq $\end{document} 0.8), and for 18% of models, the improvement is at least 40% (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $\frac{MSE}{Baseline} \leq $\end{document} 0.6).

In the same manner, models with different input sizes can be compared: For most drugs, the best-performing feature number was around \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k=300$\end{document} (cf. Fig. 2D) and smaller \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document} resulted in larger errors (cf. Fig. 1). In Fig. 3B, we compare the test MSE of the best-performing model for each drug using \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k=300$\end{document} features to models with smaller \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k$\end{document}. For most models (63%), the increase in MSE when using \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k < 300$\end{document} features is rather small (< 10%). For \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k=100$\end{document}, only 3% of models show an error increase of > 10%. For \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k=15$\end{document}, this number rises to 27%, but the model complexity is reduced drastically.

Figure 2 shows that PCA was the best-performing DR method. However, features obtained through FE approaches like PCA are not easily interpretable. In contrast, the correlation-based FS is easy to interpret and implement. In Fig. 3C, we compare the performance of the best-performing models using PCA- and correlation-based features, respectively. For 37% of models, the correlation-based features even performed better than the PCA-based features. For 52% of models, the increase in MSE from using correlation-based features is \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $<10\%$\end{document} and for only 0.4% of models, the increase is \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $> 20\% $\end{document}.

In Fig. 3D, we compare the correlation-based FS to the literature-based FS using the IntOGen cancer gene list. The correlation-based features outperform the literature-based ones for 93% of models. Among the 7% of models, where the IntOGen features performed better, improvements were mostly small (< 10% in 94% of models). In summary, these results indicate that using the literature-based over correlation-based FS is not recommended. However, the slight improvements of PCA over correlation might warrant the loss of feature interpretability.

## Section: Results › Improving predictions for sensitive cell lines

A major goal of drug sensitivity prediction is to identify drugs that are effective for a given sample. However, there is a significant under-representation of sensitive samples (i.e. cell lines with small IC50 for a given drug) in drug screening data [5, 11, 16, 21]. Consequently, ML models trained on these data often exhibit a low prediction sensitivity (classification) and a large MSE (regression) for sensitive cell lines [11, 16, 21]. In the following text, we show that using an error measure for model tuning that increases the importance of sensitive cell lines can notably improve their predictions. This approach is similar to using sample weights or upsampling of underrepresented samples (see [5, 11, 16, 21]). To identify samples as sensitive or resistant, we binarized IC50s for each cell line using drug-specific thresholds as described in [5].

Figure 4 depicts the distribution of test MSEs of the best-performing model for each drug selected through CV error. The orange and purple box plots represent the resistant and sensitive cell lines, respectively. The left side of Fig. 4 shows the results when hyperparameters and settings are selected based on CV MSE. For almost all drugs, the test MSE for sensitive cell lines is considerably larger than for resistant ones. For the results shown on the right side of Fig. 4, we did not use the conventional MSE to select the best hyperparameters/setting but instead calculated the MSE of sensitive and resistant cell lines separately and averaged both values. Using this tuning measure, the MSE for sensitive cell lines decreased considerably but remains larger than the MSE for resistant ones.

While this approach increases the error of the resistant cell lines, this trade-off might be warranted since predictions for the samples of interest are improved. However, more advanced ML algorithms explicitly focusing on sensitive cell lines, like our previously published method SAURON-RF [16] or RWEN by Basu et al. [21], can achieve even larger improvements.

Effect of different hyperparameter tuning measures. This figure compares the test MSEs for sensitive and resistant cell lines when using the conventional MSE for hyperparameter tuning versus the mean between the MSE of all sensitive and all resistant cell lines. To identify a cell line as sensitive/resistant, we compare its ln(IC50) to a drug-specific threshold derived through a procedure described by Knijnenburg et al. [5].

Runtime comparison of ML algorithms. Sub-figure A depicts the mean training duration for a single model (i.e. one hyperparameter combination) for increasing feature numbers. Sub-figure B depicts the duration of performing the 5-fold CV plus fitting of models on the whole training data accumulated over all hyperparameter combinations.

## Section: Results › Runtime

Boosting trees, random forests and elastic nets were trained using 24 cores on an Intel Xeon Gold 6248 (2.50GHz) CPU. Neural networks were initially trained using a Nvidia Tesla V100-SXM2 GPU since GPUs are known to effectively parallelize computations needed in network training. However, for comparatively small networks, the overhead of transferring calculations to the GPU can outweigh the computational speedup, which we also observed in our experiments (see Supplementary Figure 8). Hence, we switched from GPU to CPU (Intel Xeon E5-2698 v4, 2.20GHz, 24 cores).

Figure 5A depicts the duration of training a single model using each ML algorithm averaged over all trained models. The runtime of neural networks is considerably larger than that of the other algorithms, with elastic net being the fastest. Figure 5B depicts the combined runtime of performing the complete CV and training of final models on all hyperparameter combinations for a given setting. Although we tested the most hyperparameter combinations for elastic nets (cf. Table 1), they remain the fastest approach for \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k> 10$\end{document}.

## Section: Results › Model and feature interpretability

Drug sensitivity prediction aims to provide accurate models but also to identify markers of treatment sensitivity/resistance. However, not all models are equally interpretable. As discussed above, inputs obtained through FS are more interpretable than those obtained through FE. Additionally, ML algorithms exhibit great differences regarding their inherent interpretability. In Table 2, we assess the interpretability of the four investigated ML algorithms based on model transparency and explainability as described by Lipton [47] and Imrie et al. [48]. In an attempt to make models more interpretable, biological knowledge is often explicitly encoded into prediction models, e.g. using pathway-layers in neural networks [4, 35, 67], exploiting known protein interactions [22] or encoding information on known markers of drug response [11]. Li et al. found, however, that the explicit incorporation of biological knowledge may decrease model performance and lead to false conclusions [35]. Hence, the assumptions that are introduced by adding biological knowledge to a model should be carefully investigated.

However, training an ML model is not always necessary to identify features that impact drug response: Three of the investigated FS approaches (Correlation, Enrichment, MRMR) not only consider the expression data but also the drug response values. Consequently, the chosen features already provide information on potential markers of sensitivity/resistance. Since we found that MRMR is the best-performing FS method, we investigated the selected features more closely: Figure 6A depicts how often each gene was chosen by the MRMR FS for \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k = 25$\end{document} across all drugs and its average rank in the drug-specific MRMR lists. Features that are chosen often, such as BCL2L1 and SLC27A5, might be interesting biomarkers across drugs. Indeed, BCL2L1 expression was shown to prevent apoptosis, thereby conferring multi-drug resistance to cancer cell lines [68]. Increased apoptosis and drug sensitivity were observed when BCL2L1 was silenced or inhibited [69–71]. Gao et al. [72] found that SLC27A5 deficiency was related to poor prognosis, proliferation and drug resistance in hepatocellular carcinoma. Knockout of SLC27A5 activates the KEAP1/NRF2 pathway [72], which is linked to chemoresistance in non-small cell lung cancer patients [73] and different types of cancer cell lines [74]. In contrast, features rarely chosen by MRMR but with a small rank are likely important for specific drugs only and can be assessed to study drug-specific mechanisms of treatment response.

We next investigated whether the features that are selected often by MRMR are also the ones with the highest impact in elastic net models trained with those features. We chose elastic nets for this analysis due to the straightforward interpretation of their coefficients (cf. \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $\beta $\end{document} in Equation 1). Figure 6B depicts how often the selected MRMR features had a nonzero contribution in the trained elastic nets and their mean rank based on the absolute size of assigned coefficients. Again, BCL2L1 and SLC27A5 were impactful features for a large number of drugs (55 and 46 drugs each). The sign of the coefficients indicates whether increasing the expression of a gene positively or negatively affects the predicted IC50s. For 98% of genes, their contribution was either always positive or always negative for at least 99% of drugs, indicating that features generally have a consistent impact on drug response.

Interpretability of ML models. We assess the abstract concept of interpretability using the terms transparency and explainability, as introduced by Lipton [47] and Imrie et al. [48], respectively. Transparency describes the inherent complexity of an ML model, including the model size in terms of its parameters and the human intelligibility of its computations. Explainability focuses on deriving explanations for why certain predictions are obtained for certain inputs. This includes feature importance, the identification of training samples that are similar to a given input, the effect of altering certain inputs and the examination of how certain (human) concepts are interpreted by the model. Notably, inherently non-transparent models (e.g. deep neural networks) can still provide good explainability. However, extracting knowledge from the model might require applying additional tools, which can be challenging, especially for non-ML experts. Here, we only list the explainability methods that are readily available in the used R/Python packages (cf. Table 1). Imrie et al. provide a good overview of further tools for different applications and ML algorithms [48]

Feature importance of MRMR features. Sub-figure A shows the importance of features selected by the MRMR FS with \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k=25$\end{document} for all drugs. The x-axis denotes the mean rank of each gene in the feature lists of all drugs, and the y-axis denotes the number of drug-lists in which the gene occurs. Sub-figure B shows the importance of the MRMR features in the best-performing elastic net models trained on these features. The x-axis denotes the mean rank of each gene according to the absolute size of feature coefficients derived from the trained models, and the y-axis denotes the number of models in which the feature had a non-zero coefficient. The color denotes whether the genes have a negative/positive coefficient (cf. \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $\beta _{j}$\end{document} in Equation 1) in the trained models, indicating their tendency to de-/increase predicted IC50s.

## Section: Results › Impact of DR on a multi-omics multi-drug deep learning model

Our benchmarking mainly focuses on predicting drug response based on gene expression features using standard ML algorithms. However, state-of-the-art prediction models exhibit increasingly complex architectures and are often based on multi-omics characterizations of cell lines, sometimes including also molecular characterizations of drugs [75]. Hence, we investigated the effect of different DR methods on a multi-omics multi-drug deep learning model by Chiu et al. [3] and compared its performance with that of elastic nets and random forests. Their approach uses gene expression and mutation data as input, which are projected into a lower dimension (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $k = 64$\end{document}, each) using autoencoders. The encoders are connected to a deep neural network, with drug-specific output nodes predicting each drug’s IC50. To conform to our analysis setup, we slightly modified the autoencoder pre-training. For an in-depth description of the model and our performed analyses, please refer to the Supplement. The results can be summarized as follows:

In summary, this exemplary analysis highlights that single-drug models with small feature numbers can outperform more complex multi-drug and multi-omics approaches. It also proves again that the choice of ML/DR method substantially impacts predictions.

## Section: Conclusion

We performed a comprehensive analysis of the prediction of IC50 values using four ML algorithms in combination with six FS and three FE techniques. Our evaluations on the GDSC2 dataset show that elastic nets using features obtained through PCA yielded the smallest test MSE for 76 of 179 investigated drugs. Elastic nets also showed the lowest runtime and allow a straightforward identification of features with a strong impact on predictions. In contrast, neural networks including the more sophisticated deep learning approach by Chiu et al. [3] had the worst performance. This aligns well with findings by Li et al. [35].

Among the FS methods, the MRMR-based approach performed best. In general, FS methods considering the drug response performed better than methods using only expression values. Methods that do not consider either drug response or gene expression, like the literature-based or random FS, performed worst. However, on a dataset other than the GDSC, features like known cancer genes might yield more robust predictions than features tailored to a specific dataset.

Our analyses focused mainly on gene expression data since it was shown to be the most informative data type for drug sensitivity prediction [3, 39, 42]. Our analyses using mutation data (cf. Supplementary Figure 11) agree with these findings. However, combining different omics data types might prove beneficial, especially when small feature sets are desired. There are also several ML approaches that employ not only cell line features but also drug features in the form of molecular fingerprints [7, 9, 10, 15, 19, 20, 24, 27, 29, 31, 33] (see also [75] for a thorough review). Here, FS could provide insight into which drug properties impact treatment response.

Our analyses primarily focused on training models for each drug separately. However, multi-drug models such as the multi-task network by Chiu et al. [3] enjoy popularity. Our analyses show that single-drug models can outperform multi-drug models and might, thus, be preferred when predicting the drug response for an unknown sample (cell line) to a known drug. For an unknown drug, some multi-drug models can directly be applied given that a representation of the drug of interest, e.g. a molecular fingerprint, is available. In contrast, single-drug models are not directly applicable. Nevertheless, molecular fingerprints could be used to identify drugs with available models that are structurally similar to the unknown drug (cf. [13]). The corresponding single-drug models could then be combined into an ensemble model. Whether such an ensemble model would outperform conventional multi-drug models for unknown drugs has yet to be determined. However, we would like to emphasize specific challenges that occur when training any model that should predict responses for multiple drugs:

While we focused on monotherapy prediction, drug synergies are increasingly studied using ML to predict the efficacy of drug combinations [76] since combination therapy is common in cancer treatment. In this context, FS could identify features that enhance or impede the interplay between compounds.

Interpretability and trust in predictions are crucial when ML models should eventually be used for clinical decision support. Through performance comparisons with the deep learning multi-omics multi-drug approach by Chiu et al. [3], we showed that interpretable models with small feature numbers can substantially outperform complex prediction algorithms. Moreover, our results indicate that complex models equally benefit from using simple DR methods.

Overall, we believe that the methods and evaluation strategies we discussed are helpful tools for the development and assessment of both simple and advanced models for drug sensitivity prediction, independent of the specific algorithms and features at hand.


---

# A comprehensive review of molecular optimization in artificial intelligence-based drug discovery

- **Authors:** Yuhang Xia, Yongkang Wang, Zhiwei Wang, Wen Zhang
- **Issuer:** Quantitative biology (Beijing, China)
- **Type:** Scientific article
- **Published:** 2024-02-12
- **Language:** en
- **DOI:** 10.1002/qub2.30
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41676020/
- **Licence:** CC-BY

## Section: Abstract

AbstractDrug discovery is aimed to design novel molecules with specific chemical properties for the treatment of targeting diseases. Generally, molecular optimization is one important step in drug discovery, which optimizes the physical and chemical properties of a molecule. Currently, artificial intelligence techniques have shown excellent success in drug discovery, which has emerged as a new strategy to address the challenges of drug design including molecular optimization, and drastically reduce the costs and time for drug discovery. We review the latest advances of molecular optimization in artificial intelligence‐based drug discovery, including data resources, molecular properties, optimization methodologies, and assessment criteria for molecular optimization. Specifically, we classify the optimization methodologies into molecular mapping‐based, molecular distribution matching‐based, and guided search‐based methods, respectively, and discuss the principles of these methods as well as their pros and cons. Moreover, we highlight the current challenges in molecular optimization and offer a variety of perspectives, including interpretability, multidimensional optimization, and model generalization, on potential new lines of research to pursue in future. This study provides a comprehensive review of molecular optimization in artificial intelligence‐based drug discovery, which points out the challenges as well as the new prospects. This review will guide researchers who are interested in artificial intelligence molecular optimization.Keywords: artificial intelligence, drug discovery, molecular optimization

## Section: INTRODUCTION

Drug discovery is an expensive, risky, and complex procedure with a long development cycle. The successful development of an innovative drug will cost between 0.8 and 1.5 billion dollars and take 10–15 years [1, 2]. Annually, around 90% of drugs assessed by the Food and Drug Administration (FDA) are rejected and cannot be utilized for medicinal purposes [3]. Therefore, it is essential to consider efficient techniques to combat the rising cost and hasten the discovery process.

In drug discovery, discovering novel drug candidates for preclinical trials can be summarized into five steps [4, 5]. The first step is the identification of drug targets. The second step is screening the hit compounds with on‐target activity from the molecular databases. Then, based on the initial validation for hit compounds, the drug‐likeness compounds (lead compounds) are collected. After that, the molecular optimization step is implemented to optimize the druggability of lead compounds. Finally, the safety of the drug candidates is preliminarily validated before the preclinical studies.

In the past decades, computer‐aided drug design (CADD) has made use of domain knowledge in the chemical, pharmacological, and biological fields for drug discovery, and high‐throughput screening (HTS) has considerably accelerated drug discovery [6, 7]. Due to the rapid progress in processing power and increasing amounts of cheminformatics data, artificial intelligence (AI)‐based methods have recently been flourishing and brought new opportunities and solutions for drug discovery [8, 9, 10, 11, 12, 13, 14, 15]. The above‐mentioned information techniques are greatly involved in several key steps of drug discovery before clinical trials, including drug target identification, hit compound screening, molecular optimization, and safety evaluation of drug candidates.

It is notable that the structure of drug candidates determines the drug properties and clinical effects, while the screened candidates typically have certain pharmacological flaws showing obstruction in clinical application [16, 17]. Thus, molecular optimization is one of the greatest challenges in drug discovery [18, 19], aiming to enhance the physical and chemical properties of a molecule, such as solubility, bioavailability, and selectivity [20]. Since the structures of molecules can determine their properties, researchers constructed the quantitative structure–activity relationship (QSAR) that describes a mathematical relationship between quantitative representations of molecule structures and the activity or property of interest [21]. Traditional computational methods for molecular optimization consider a molecule as a set of fragments, which are responsible for different functions, and then modify (add, delete, or replace) fragments of a molecule to enhance its properties according to QSAR. As there are a great number of molecular fragments, the combination of fragments will form a huge chemical space, and finding the desirable molecules from the chemical space is an NP‐hard task. To improve the efficiency of molecular optimization, researchers developed AI‐based molecular optimization methods by using natural language processing (NLP), swarm intelligence, reinforcement learning, generative adversarial network, etc.

In this review, we concentrate on the development of artificial intelligence‐based molecular optimization. Firstly, we outline the datasets for molecular optimization and approaches to molecular representation. Then, we introduce the important molecule properties as well as three types of mainstream AI‐based molecular optimization methods, including molecular mapping, molecular distribution matching, and guided search‐based methods. After that, we summarize the assessment criteria for optimization models as well as the benefits and drawbacks of existing methods. Finally, we discuss the challenges of molecular optimization and highlight the cutting‐edge directions for future optimization research, that is, model interpretability, multi‐property optimization, and model transferability.

## Section: DATASETS

Public databases and datasets for drug discovery.

Common molecular properties for molecular optimization.

The molecule C6H6 is represented by three kinds of string‐based representations.

The molecule C7H8O is represented by three kinds of graph‐based representations.

## Section: DATASETS › Data sources for drug discovery

There are several public databases about drug molecules, including ZINC [22], ChEMBL [23], and DrugBank [24]. ZINC is a free database of 2.3E + 08 compounds constructed by the researchers from the Department of Pharmaceutical Chemistry at the University of California, San Francisco (UCSF), providing the log p value of molecules by using Molinspiration software [25]. ChEMBL is a large, open‐access drug discovery database with 2.4E + 06 compounds developed by the European Bioinformatics Institute (EBI), aiming to capture the medicinal chemistry data across the drug discovery process [23], which is calculated by RDKit [26] and Chemistry Development Kit (CDK) [27]. DrugBank is an online database created by Dr. David Wishart’s lab at the University of Alberta, containing the experimental and predicted properties on over 5E+05 drugs and drug targets [26]. The molecules and their properties provided by the above databases are listed in Table 1.

The researchers have also constructed several public datasets such as QM9 [28], Tox21 [29], BACE [30], BBBP [31], and Lipo [32]. QM9 is a dataset with 1.34E + 05 molecules built by Ramakrishnan et al. [28], calculating the energy and enthalpies of molecules by the quantum chemistry computational method named B3LYP/6‐31G(2df, p). Tox21 is a dataset comprising 1.37E + 04 compounds compiled by the National Institutes of Health, the Environmental Protection Agency, and the Food and Drug Administration in America, containing toxicity measurements for six common targets of xenobiotic toxicity (the liver, blood, kidney, nerve, lung, and skin) [29], gained from the quantitative high‐throughput screening (qHTs) [33]. BACE is a dataset with 1.5E + 03 compounds created by Subramanian et al. [30], containing molecular bioactivity against a set of inhibitors of human b‐secretase 1 (BACE‐1), selected from the bio‐experiment. BBBP is a collection of 2E+03 molecules from Martins et al. [31], including binary labels for compounds on their permeability properties, gained from the bio‐experiment. Lipo is a sub‐dataset with 4.2E + 03 molecules from the ChEMBL database, providing the log D of compounds [32], selected from the bio‐experiment. Table 1 shows the molecules and their properties provided by the above datasets.

Public databases and datasets for drug discovery.

## Section: DATASETS › Molecular properties for molecular optimization

As shown in Table 2, there are four types of molecular properties of great interest in drug discovery: pharmacokinetic properties, medicinal chemistry properties, physicochemical properties, and pharmacological properties [36, 37], and researchers usually optimize some properties of molecules, including Absorption(A), Distribution(D), Metabolism(M), Excretion(E), Toxicity(T), which are collectively called ADMET, and Drug likeness (QED), octanol‐water partition coefficient (log P), octanol‐water distribution coefficient (log D), molecular bioactivity against drug targets (e.g., DRD2, GSK3β, and JNK3), as well as selectivity. ADMET is a set of pharmacokinetic properties, which provides insight into how a drug interacts with the human body. QED is a kind of medicinal chemistry property, measuring how likely a molecule is to be a potential drug candidate. SA represents the ease of molecular synthesis respectively. log P and log D measure the solubility of a compound. DRD2 is the main target of most psychiatric drugs for schizophrenia and Parkinson’s disease; GSK3β and JNK3 are drug targets for Alzheimer’s disease. Selectivity refers to the degree to which a drug interacts specifically with its intended target in the body.

Notably, the pharmacological properties are usually evaluated by a property predictor, and the other properties are usually evaluated by RDKit. In addition, it is fundamental for molecular optimization to ensure the structural similarity of molecules before and after optimization, which is usually calculated by RDKit.

Common molecular properties for molecular optimization.

## Section: DATASETS › Datasets for molecular optimization

In molecular optimization, researchers usually collect their own data from the above databases according to certain optimization tasks. According to the study [38], two molecules that have small differences between consecutive atoms but huge differences between properties can be considered as a matched molecular pair (MMP), and the molecule with poor properties in an MMP is named the source molecule, the molecule with desired properties is named the target molecule. For example, He et al. [39] compiled a dataset with 9,927,876 MMPs and their ADMET properties from ChEMBL. Since it is difficult to collect the MMPs related to all optimized properties, researchers try to collect two sets of molecules with huge differences between properties, which we name as matched molecular set (MMS), and the molecular set with poor properties in an MMS is named as source molecular set, the molecular set with desired properties is named as target molecular set. For example, Barshatski et al. [40] collected a matched molecular set with 1897 molecules and their bioactivity to DRD2 from DrugBank. Unlike MMPs and MMS, some researchers directly collect molecules and their properties for optimization. For example, Madhawa et al. [11] collected 2 datasets with 2.5E + 05 and 1.34E + 05 molecules from ZINC and QM9 respectively, directly for the optimization of QED and log P. Through the above three strategies of data collection, researchers can also create their own datasets for molecular optimization.

## Section: DATASETS › Molecular representations

It is a fundamental challenge to represent molecules in a form that computers can understand easily once trustworthy data has been gathered. In molecular optimization, molecules are usually represented by strings and graphs.

The molecule C6H6 is represented by three kinds of string‐based representations.

The molecule C7H8O is represented by three kinds of graph‐based representations.

## Section: DATASETS › Molecular representations › String‐based representation

As a type of string‐based representation, molecular fingerprints are high‐dimensional bit vectors of molecular chemical structures where each bit indicates whether a structure exists, such as substructure key‐based fingerprints, topological or path‐based fingerprints, and circular fingerprints. Although molecular fingerprints have the advantage of containing structural information, they cannot be reconverted into a unique molecule necessarily. Simplified molecular input line system (SMILES) is a classic linear representation for molecules with short ASCII strings [41]. Specifically, SMILES encodes atoms into letters, bonds into symbols, and branches into parentheses. SMILES are space‐saving and can correspond to a unique molecule, but a change of a single character may result in an invalid molecule, which does not meet the basic chemical rules. SELF‐referencing embedded strings (SELFIES) [42] is a string representation in which every symbol is interpreted as a rule vector. SELFIES can avoid grammatical errors by enforcing chemical validity rules in a formal syntax table to ensure 100% molecular validity. As shown in Figure 1, a molecule formulated as C6H6 can be represented by the above three kinds of string‐based representations.

The molecule C6H6 is represented by three kinds of string‐based representations.

## Section: DATASETS › Molecular representations › Graph‐based representation

Graph‐based molecular representations model a molecule as a molecular graph G = (V, E), where V is the node set of the graph mapping to atoms and E denotes the edge set of the graph mapping to chemical bonds [43]. Moreover, nodes may be assigned features representing the properties of atoms. Graph‐based molecular representations consist of two parts: node embedding and graph embedding. The node embedding is the most important one of them, as it can be aggregated into the graph embedding. To learn the molecular graph representations, researchers utilized different graph neural network (GNN) encoders, which usually follow the message‐passing neural network (MPNN) framework. Assouel et al. [44] used a graph convolution network (GCN) encoder for molecular optimization, Jin et al. [45] proposed a junction tree encoder with a tree message‐passing network, and Jin et al. [46] designed a hierarchical graph encoder by a hierarchical message‐passing network. Among these encoders, the GCN encoder first performs several spatial graph convolutions on the input graph and then aggregates the node embeddings into a single graph latent representation. Using convolution operations, this GCN encoder can capture the whole topology information of the graph. By extracting certain clusters (such as rings and bonds) into a single node, the junction tree encoder first decomposes a molecular graph G into a junction tree TG, and then obtains the representation of TG by aggregating the node information. The junction tree encoder provides a reliable cluster vocabulary to extract substructures ensuring generating valid molecules. Moreover, the hierarchical graph encoder contains three MPNN layers named the atom layer, attachment layer, and motif layer, respectively; after updating embeddings through these layers, the graph embedding is finally aggregated. Due to learning a hierarchical representation, the hierarchical graph encoder can obtain both coarse‐grained motif and fine‐grained atom connectivity. As shown in Figure 2, a molecule can be represented by the above three kinds of graph‐based representations.

The molecule C7H8O is represented by three kinds of graph‐based representations.

## Section: METHODS

In recent years, with the development of Big Data and AI technologies, great attempts have been made to use AI technologies, especially deep learning, to automatically learn domain knowledge from large amounts of data to guide molecular optimization. As shown in Figure 3, the molecular optimization methods are roughly classified into three types: molecular mapping‐based method, distribution matching‐based method, and guided search‐based method. Figure 4 shows the timeline of the molecular optimization model based on these three methods.

Artificial intelligence‐based molecular optimization methods.

The timeline of molecular optimization models.

## Section: METHODS › Molecular mapping‐based method

Molecular mapping is to learn the mapping relationship F between matched molecular pairs (MMPs). Given an MMP (x, y), where x and y have small differences between consecutive atoms but huge differences between properties, the molecular mapping can be formally represented as F(x): x→y. Molecular mapping‐based method is implemented by medicinal chemistry transformation rules learned from MMPs, which imitates the knowledge and experience of medicinal chemists. Based on the molecular representation, there are two types of molecular mapping‐based methods, including 1D string representation‐based Sequence to Sequence methods and 2D molecular graph representation‐based Graph to Graph methods. The details of publicly available MMPs datasets are shown in Supplementary Table S1.

## Section: METHODS › Molecular mapping‐based method › Sequence to sequence

The molecular optimization methods of Sequence to Sequence are usually modeled as a sequence translation problem with the help of methods in natural language processing (NLP). He et al. [39] constructed the model based on the transformer architecture for property variations between MMPs, using the source molecules and property constraints (the true and desired property scores of source molecules) as inputs to the model, and trained the model to output the target molecules. He et al. [47] later extended their model and proposed Transformer‐R. Transformer‐R cuts the SMILES of the source molecule into a core SMILES representation and an R‐group SMILES representation, separated by using a separator. Instead of generating the whole molecule, the transformer generates the R‐group. To solve the multi‐property optimization problem, Shin et al. [48] designed a new transformer architecture‐based model named CMG. CMG introduced the property prediction and similarity prediction regularization network in the architecture and proposed an improved beam search algorithm to facilitate better utilization of the auxiliary network. In contrast to the SMILES representation, molecular fingerprints contain information about the molecular structure, while chemically similar molecules usually have similar fingerprints. Maragakis et al. [49] proposed a model based on RNN architecture named DESMILES. DESMILES used molecular fingerprints as the input for the deep learning model to transform the source molecular fingerprints into their associated SMILES molecules. The molecular fingerprint to SMILES transformation relationship is pre‐trained on a large dataset, and then the model is fine‐tuned using matched molecular pairs.

## Section: METHODS › Molecular mapping‐based method › Graph to graph

The molecular optimization methods of Graph to Graph are usually modeled as a graph translation problem similar to image‐to‐image translation in the image domain. Jin et al. [50] first proposed to describe the molecular optimization problem as a supervised graph‐to‐graph translation problem and extended the JTVAE architecture to design the VJTNN model. VJTNN learned the difference vector of molecular pairs while using this vector and the input molecule information to decode the optimized molecules during the decoding process. The attention mechanism is presented in the tree decoding process and combined with adversarial training to avoid invalid translation. Jin et al. [46] further extended their work by proposing a hierarchical graph VAE named HierG2G. HierG2G used a larger and more flexible motif instead of the smaller substructure in the JTVAE. The decoding process sequentially predicts whether to add substructures, type of substructure, and attachment points of the substructure and their corresponding attachment points in the current graph. This decoding strategy allows modeling the strong dependency between the process of successive addition and selection of substructure and significantly improves the accuracy of reconstruction and generation. Fu et al. [20] designed the copy & refine strategy named CORE based on VJTNN. CORE predicted the probability of copying a substructure in the process of decoding molecules, and then further predicts which specific substructure should be used. Thus, CORE solved the problem that the decoding process involves complex combinatorial enumeration in the process of connecting substructure prediction, which leads to a slow and difficult to parallelize decoding process. Yu et al. [51] introduced structural constraints based on VJTNN and proposed a structure‐aware conditional variational autoencoder named SCVAE. SCVAE used the topology of molecules as structural conditions to optimize the properties of molecules through constrained structural modifications. Fu et al. [52] proposed a molecule‐level reward function named MOLER. MOLER introduced the similarity reward and size deviation penalty to the architecture of VJTNN to enhance the structural similarity constraint, meanwhile preventing excessive size deviation between the source and target molecules. Ji et al. [53] proposed a teacher and student polish named T&S polish architecture. T&S polish aimed to reduce the generation process of the target molecule by capturing more useful information from the source molecule. The teacher component automatically identifies and annotates the optimization centers and the saving, removal, and addition of certain parts of the molecule. The student component uses this knowledge learned by the teacher component and applies it to the new molecule. Similar to T&S polish, the work of Chen et al. [54] proposed a one‐fragment‐based optimization model named Modof. Modof encoded the difference between molecules before and after optimization at a breakpoint, predicts the location of a single broken chain in the source molecule from a vector sampled in the potential difference space, and modifies the molecule by changing the fragment at that location. Since there may be multiple ways to optimize a molecule, the authors introduce an iterative optimization strategy to extend Modof to Modof‐pipem, which modifies a given molecule into multiple optimized molecules.

Molecular mapping‐based methods require a large number of MMPs, however, such data are not easy to obtain and require some heuristic algorithms [55, 56] to construct, while the model performance of such methods depends heavily on the quality of MMPs. Researches have been done to address molecular mapping‐based method under conditions of sparse data. Yang et al. [57] proposed an efficient self‐training method based on pretrained molecular generation models and property predictors to expand the training data by generating additional data satisfying the constraints during the iterative training process. Inspired by the back translation in NLP, Fan et al. [58] proposed a semi‐supervised method named BT4MolGen. BT4MolGen trained the pseudo‐labeled data generation model with MMPs, and then trained the forward molecular optimization model using the pseudo‐labeled and labeled data, which can utilize a large amount of unlabeled data and alleviate the data sparsity problem. Wang et al. [59] proposed a first‐order meta‐learning algorithm named Meta‐MO for molecular optimization. Meta‐MO enabled the model to be adapted to few‐shot molecular optimization tasks. Fu et al. [60] proposed a method named α‐MOP to unify the molecular mapping‐based method and Reinforcement learning (RL) using α‐divergence. By controlling the α value in the objective function, the weights of the molecular mapping‐based method and the RL target are dynamically adjusted. In the early stage, more attention is paid to the molecular mapping‐based method learning target, while more learning weights are gradually shifted to the RL target in the later stage.

## Section: METHODS › Molecular distribution matching‐based methods

Drawing on the idea of style transfer in the image field, molecular distribution matching is to learn the mapping relationship G between the matched molecular set (MMS) rather than the matched molecular pairs of MMPs. Given an MMS (X, Y), where X and Y have huge differences between properties, molecular distribution matching can be formally represented as G:X → Y. The molecular optimization is achieved by adjusting the distribution of chemical spatial properties of the molecules in X to be close to the distribution of Y.

Maziarka et al. [61] designed a molecular optimization model named Mol‐CycleGAN based on the Cycle‐GAN model. Firstly, Mol‐CycleGAN used JTVAE to represent each molecule as a point in the latent space, by learning the latent space representation distribution of two sets of MMS. After that, this model used the Cycle‐GAN model to learn the universal mapping relationship from the source molecular set to the target molecular set. Barshatski et al. [40] proposed an end‐to‐end dual learning method named UGMMT to train a bidirectional translation of the source molecular set to the target molecular set embedding space under the double cycle constraints, and incorporated a molecular attention mechanism to drive the generation of molecules to maintain similarity with the chemical fingerprint (FP) of the source molecule. Later, Barshatski et al. [62] extended UGMMT and proposed a multi‐property optimization method named IPCA. IPCA learns one transformation for each property optimization while constraining the latent embedding space between all the transformations, and proposed a new adaptive loss to balance the separated transformations while stabilizing the optimization process.

## Section: METHODS › Guided search‐based methods

Guided search‐based methods search for target molecules either in the chemical space of molecules or in a latent space learned by encoder‐decoder models, guided by the molecular property predictor or statistical models [63]. The latent space search and chemical space search are briefly introduced below.

## Section: METHODS › Guided search‐based methods › Latent space search

The latent space search first encodes the source molecule into latent embedding in a low‐dimensional latent space, then finds latent embeddings that satisfy constraints by searching the region around source molecules in the latent space, and finally decodes them back into the chemical space. In most cases, a property predictor is necessary to guide the search in the latent space.

Some latent space search methods have to train property predictors in the latent space to guide research. Jin et al. [45] proposed a junction tree variational autoencoder named JTVAE. JTVAE first decomposed a molecular graph into the junction tree with each node representing a molecular substructure, and then mapped both the junction tree and molecular graph into the latent embeddings. Meanwhile, JTVAE trained a property score predictor in the latent space, to ensure the distribution of molecules in the latent space will be clustered together according to the property values. The gradient ascent is employed in the latent space to search latent embeddings with improved property scores. Zang et al. [64] proposed a flow‐based graph generation model named MoFlow. MoFlow first generated bonds of molecules based on the Glow model [65], then used the designed graph conditional flow framework to generate atoms based on the given bonds, and finally assembled them into a valid molecular graph. MoFlow also applied gradient ascent to find the latent embeddings with better property scores. Kong et al. [66] proposed Principal Subgraph Variational Auto‐Encoder named PS‐VAE. Specifically, the source molecules are decomposed into principal subgraphs according to the designed principal subgraph vocabulary, while the principal subgraphs are encoded into the latent space using GNN. After that, the sequence of principal subgraphs is autoregressively decoded from the latent embeddings optimized through gradient ascent by GRU, and the sequence of principal subgraphs is concatenated into a complete graph using a link prediction method. Some methods adopt other optimization algorithms to search in the latent space. Madhawa et al. [67] proposed a normalizing flow (real NVP)‐based molecular graph generation model named GraphNVP [68]. GraphNVP designed two types of reversible affine coupling layers to convert the adjacency tensor and node feature matrix of the molecular graph into latent embeddings, respectively. In the latent space, the randomly selected latent embeddings are interpolated to obtain embeddings with desired properties based on the trained property predictor.

There have been lots of state‐of‐the‐art property predictors such as Oliverona et al.’s method [69] and RDkit, and some researchers directly adopted these property predictors instead of training their own predictors. Hoffman et al. [63] proposed a query‐based molecular optimization framework named QMO. QMO utilized the pretraining encoder and decoder to learn molecular embeddings, and randomly sampled the neighboring embeddings of the source molecule in the latent space, evaluated the properties and structural similarity constraint of the corresponding decoded molecules with Oliverona et al.’s method and RDkit, and performed a zero‐order function to estimate the gradient thus finding better embeddings using gradient descent, and progressively optimizes the input source molecules by evaluating the properties of the generated molecules. Richards et al. [70] mapped source molecules into the latent space using β‐VAE, and selected the neighbors around the embedding of the source molecules based on standard Gaussian sampling and used them as the initial particles of the particle swarm optimization (PSO) algorithm. The fitness of the decoded molecule is evaluated through a reward function containing property constraint and structural similarity constraint.

Besides, there are some latent space search methods free of property predictors. Yu et al. [71] proposed the Generative Scaffold Hopping Model named GraphGMVAE. GraphGMVAE used Dual‐MPNN [72] to transform the source molecule and its scaffold into the corresponding scaffold embedding and side chain embedding, respectively. After that, GraphGMVAE sampled the new scaffold embedding from the Gaussian mixture distribution in the latent scaffold space with different hopping rates, and the new scaffold embedding is fed to the GRU decoder with the original side chain embedding and property conditions, to produce molecules with the new scaffold and bioactivity condition.

## Section: METHODS › Guided search‐based methods › Chemical space search

In contrast to the latent space search, the chemical space search methods search for molecules that satisfy constraints in the high‐dimensional, discrete chemical space directly. Many advanced optimization algorithms, such as reinforcement learning and genetic algorithm, have been used in the chemical space search.

RL consists of three main components: agent, reward function, and the environment. The agent selects the action based on the state, and the environment evaluates the quality of the action based on the reward function and provides feedback to the agent. In molecular optimization, the state generally denotes a partially generated molecule, actions are the modification operation for the molecule, and reward function involves desired properties reward and structural similarity constraint reward. You et al. [73] designed a graph convolutional policy network named GCPN. GCPN adopted a stepwise method for molecular graph generation, formulating the problem as a Markov Decision Process (MDP) [74] to train the agent in a chemistry‐aware environment. GCPN applied two types of rewards to guide the agent, one is a validity reward, which encourages the chemical valence rules obeyed during stepwise generation, and the other is an adversarial reward that ensures the similarity between the source molecule and the generated molecule. Zhou et al. [75] proposed MolDQN model combining RL with chemical rules to ensure 100% chemical validity of molecules, where the modification of molecules is described as the MDP and uses the deep Q‐networks [76] to solve this MDP with the desired properties and structural similarity constraint as rewards. Molecular modification is achieved by a series of actions including atom addition, bond addition, and bond removal with the guidance of reward functions.

Another molecular optimization method is to first pretrain the molecular generation model and then fine‐tune the molecular generation process with RL, such as GraphAF [77] and GraphDF [78]. GrpahAF designed an autoregressive flow‐based molecular generation model that adopts a sequential molecular graph generation strategy, which adds an atom or a bond and guarantees validity via incorporating a valency check in each step. GraphDF was a novel discrete latent variable model for molecular graph generation based on normalizing flow methods and used invertible modulo‐shift transforms to map discrete latent variables to nodes and edges of the graph. In the fine‐tuning stage, GraphAF and GraphDF used the randomly sampled subgraph of the source molecule as the initial state and the molecular generative model as the environment, which used a reward function similar to GCPN and proximal policy optimization (PPO) algorithm to fine‐tune the generative model.

Genetic algorithm (GA) is a popular population optimization algorithm inspired by the concepts of biological evolution and natural selection. GA selects molecules from initial populations according to the fitness function, applies the crossover (e.g., swap functional groups between two molecules) and mutation (e.g., switch an atom type, delete an atom, or add an atom) operations on them to generate the new population, and then repeats the aforementioned process until achieving the termination condition. Specifically, in the phase of selection, molecules with higher fitness scores are more likely to be selected, and the roulette algorithm is a common method of selection. Nigam et al. [79] proposed a discriminator‐based molecular graph generation model named GA‐DNN. GA‐DNN used a linear combination of the molecular property score and the discriminator score as the fitness function, and then selects molecules by a smooth logistic function. After that, GA‐DNN applied the random mutations of the selected molecules, while there is no crossover operation because character deletion is implicitly taken into account in the mutation. Specifically, in the molecular optimization process, GA‐DNN used the combination of the molecular property score and the structural similarity constraint as the fitness function, without the discriminator score. Lee et al. [52] introduced a novel GA method named constrained GA. Constrained GA also used the combination of the molecular property score and the structural similarity constraint as the fitness function, and then selects molecules by a smooth logistic function. After that, constrained GA applied an operator of graph‐based crossover presented in GB‐GA [80] and an operator of SELFIES‐based mutation (e.g., tom replacement, atom insert, and atom deletion) to create new molecules. In addition, to make sure the algorithm can always search for feasible solutions, a single structural similarity constraint is used before the selection operator.

Ahn et al. [81] developed a genetic expert‐guided learning method named GEGL containing the expert strategy and the apprentice strategy. The expert strategy is employed to modify the molecules in the max‐reward priority queues generated by the apprentice strategy (molecule‐generating DNN) through domain‐specific genetic operators (mutation and crossover). The apprentice strategy tuned its parameters by imitating the high‐reward molecules found by the expert strategy through imitative learning. GEGL applied the framework to the molecular optimization task by initializing the maximum reward priority queue as the source molecule and adding structural similarity constraints to the reward function. In addition to RL and GA, some researchers have tried other methods for molecular optimization. Sun et al. [82] proposed a multi‐property molecular optimization method named MolSearch combining Monte Carlo tree search (MCTS) with a multi‐objective optimization algorithm. MolSearch divided the search process into two stages, the first stage optimizes biological properties and the second stage optimizes non‐biological properties. Starting from the source molecule, MolSearch modifies the molecule based on predefined modification actions [38], retains the Pareto optimality solution in each iteration, and screens the molecules that meet the requirements from the Pareto set of molecules at the end of the iterative search. Fu et al. [83] proposed a new multi‐property molecular optimization framework named MIMOSA based on Markov Chain Monte Carlo (MCMC) sampling. MIMOSA used a pretrained GNN to generate new candidate molecules and associated weights, followed by sampling from the target distribution using MCMC.

According to the above content, molecular mapping‐based methods use MMPs as training data and usually perform better due to the explicit guidance of the target molecule. However, such molecular data are not always easy to obtain, and the performance of the model depends heavily on the quality of the constructed molecular pairs. The advantage of performing optimization in the latent space is that the latent space learned by the model is usually continuous and low‐dimensional, which makes the problem in the optimization phase easier to solve, and avoids the combinatorial search of high‐dimensional discrete molecular data structures. Moreover, regularization or structural priors can be easily imposed when learning the latent space, especially for highly discrete, high‐dimensional, and non‐differentiable molecular data. The advantage of the chemical space search strategy can combine domain knowledge in the search process. The latent space search requires the encoding and decoding process of molecules, while the molecular chemical space search is done directly in the molecular chemical space to avoid the loss of information to a certain extent. Guided search‐based methods usually have the disadvantages of low efficiency and long search time due to the lack of target molecular information guidance. From the data perspective, distribution matching‐based methods are intermediate between the molecular mapping‐based methods and the guided search‐based methods. The information of the target molecular domain provided by the target molecular set is used to improve the optimization efficiency, while avoiding the model reliance on such difficult‐to‐obtain MMPs data. As shown in Supplementary Tables S2–S5, we summarize the results of molecular optimization on four datasets provided by Jin et al. [50].

## Section: METHODS › Evaluation metrics

Model evaluation is an important task of the molecular optimization task. Based on the training molecular set S, after building the pilot optimization model, the model is used to optimize the test molecular set M to obtain the optimized effective (i.e., satisfying the basic chemistry rules) molecular set M ′. The following metrics are often used to evaluate the performance of the optimization model for the molecular sets M and M ′ before and after optimization.

Similarity. The similarity metric measures the average similarity between the set of molecules M and M ′ and is obtained by calculating the Tanimoto similarity for each pair (m, m ′), m ∈ M, m ′∈ M ′ of molecules before and after optimization. The calculation formula is as follows:

where f m and fm′ denote the Morgan fingerprints [84] of molecules m and m ′, respectively.

Diversity. The diversity metric measures the average difference between the set of molecules M and M ′, and is obtained by calculating the Tanimoto distance for each pair of molecular pairs (m, m ′):

Novelty. Novelty metric measures the ratio of new molecules in the optimized set of molecules M ′, obtained by counting the number of optimized molecules that never appear in the training set of molecules S, and is calculated as follows:

Optimized property score. The optimized property score metric measures the average property score of the optimized molecular set M ′, obtained by calculating the property score of each optimized molecule m ′:

where Oracle(⋅) is a function that calculates the score of the molecular property.

Improvement. The average property improvement metric measures the average property score difference between the molecular sets M and M ′, and is obtained by calculating the property score difference for each pair of molecular pairs (m, m ′):

Success. The success rate metric measures the ratio of molecules in the optimized set of molecules M ′ that satisfy both the similarity metric threshold δ s and the property threshold δ r . Based on different kinds of properties, there are two definitions of the success rate metric. For several properties such as log P, researchers wish the difference of property scores between molecules before and after optimization to be higher than δ r , while for other properties such as QED, researchers just wish the property scores of molecules after optimization to be higher than δ r , which are calculated as follows:

or

We provide performance comparisons of the existing molecular optimization methods on publicly available datasets in the Appendix.

## Section: DISCUSSION

Despite the significance of developing deep learning methods for practical drug discovery tasks, molecular optimization is technically complex to accomplish due to several major challenges.

The first challenge is the limited number of molecular datasets and properties for molecular optimization. For molecular optimization, researchers usually compile the MMP dataset and MMS datasets from molecular property datasets. Although the molecular property datasets include a huge number of molecules for some properties, there is a scarcity of labeled data for other desired properties to be optimized, such as toxicity and bioactivity. As described in Section 2.3, MMP datasets collect source and target molecules, while MMS datasets rely on the collection of two molecular sets with huge differences between properties, and thus it is difficult to compile the MMP datasets and MMS datasets for all desired properties owing to the limitations in data availability. Although the latent space search methods can directly optimize the molecules without MMP datasets and MMS datasets, they utilize a high‐accuracy property predictor for guiding research, and it also needs sufficient molecules with labeled desired properties for training the property predictor. To overcome these data challenges, transfer learning and few‐shot learning strategies are necessary for molecular optimizations.

Secondly, great attention has been drawn to the interpretability and transferability of AI‐based methods [85, 86], which bring a new challenge to molecular optimization. In general, the optimization methods and the optimized molecules are difficult to understand by medicinal chemists, which indicates the lack of sufficient interpretability of the molecular optimization methods [87, 88]. The crucial point of interpretability in molecular optimization lies in identifying the substructures of molecules relevant to the desired properties and contributing to the optimization process. Recent research has highlighted transparency, justification, and informativeness as pivotal factors for model interpretability [89]. To address the interpretability challenge in optimization methods, the uncertainty estimation and feature attribution strategies are necessary to enhance interpretability of optimization methods. In addition, it is difficult to achieve effective results when optimizing the molecules outside the training datasets, which shows the transferability challenge for the optimization methods [90]. The pivotal point of transferability in molecular optimization is leveraging existing, transferable knowledge from related molecular tasks to enable the learning of separate optimization tasks with limited availability of molecular data. For the model transferability, there are four categories of research direction, that is, instance‐based, feature‐based, parameter‐based, and relation‐based approaches [91]. To tackle the transferability challenge in optimization methods, it is necessary to incorporate domain adaptation techniques as well as pretraining and fine‐tuning strategies in the molecular optimization task.

Thirdly, a challenging direction for molecular optimization is to develop optimization methods that can effectively optimize multiple properties simultaneously, aiming for global optimality. In general, most existing molecular optimization methods are to optimize single‐property of molecules. Recently, researchers have made efforts to the multi‐property optimization methods [92, 93], which exhibit greater complexity than single‐property optimization methods. On one hand, the multi‐property optimization is also limited by the insufficient data labeled with multi‐property; on the other hand, the desired properties for molecular optimization might contain a potential contradiction [10], and the improvement of some properties may lead to the deterioration of others, how to determine the tradeoff between different properties need to be resolved. Therefore, there is a pressing need to develop novel and efficient algorithms specifically for multi‐property optimization.

## Section: CONCLUSION

This study provides a comprehensive review of existing methods for molecular optimization. Additionally, characteristics of the molecular representation are presented, along with an introduction to the assessing criteria of the molecular optimization methods. In particular, a detailed introduction and comparison of the molecular optimization methods are conducted. This review points out the potential challenges as well as the exciting new prospects for molecular optimization, which will guide researchers who are interested in artificial intelligence molecular optimization.

## Section: AUTHOR CONTRIBUTIONS

Yuhang Xia: Investigation; visualization; writing – original draft. Yongkang Wang: Investigation; writing – original draft. Zhiwei Wang: Investigation; visualization; writing – original draft. Wen Zhang: Conceptualization; funding acquisition; supervision; review.

## Section: CONFLICT OF INTEREST STATEMENT

The authors Yuhang Xia, Yongkang Wang, Zhiwei Wang, and Wen Zhang declare no conflicts of interest.

## Section: ETHICS STATEMENT

This is a review article and does not involve any research related to human or animal subjects.

## Section: Supporting information

Supporting Information S1

## Section: ACKNOWLEDGMENTS

This work was supported by the National Natural Science Foundation of China (Nos. 62372204, 62072206, 62102158, and 61772381), the Fundamental Research Funds for the Central Universities (Nos. 2662022JC004 and 2662021JC008), Huazhong Agricultural University Scientific & Technological Self‐innovation Foundation. The funders have no role in study design, data collection, data analysis, data interpretation, or writing of the manuscript.

## Section: Text

Xia Y, Wang Y, Wang Z, Zhang W. A comprehensive review of molecular optimization in artificial intelligence‐based drug discovery. Quantitative Biology. 2024;12(1):15–29. 10.1002/qub2.30

## Section: Associated Data

Supporting Information S1

## Section: Associated Data › Supplementary Materials

Supporting Information S1


---

# A framework for evaluating clinical artificial intelligence systems without ground-truth annotations

- **Authors:** Dani Kiyasseh, Aaron Cohen, Chengsheng Jiang, Nicholas Altieri
- **Issuer:** Nature communications
- **Type:** Scientific article
- **Published:** 2024-02-28
- **Language:** en
- **DOI:** 10.1038/s41467-024-46000-9
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38418453/
- **Licence:** CC-BY

## Section: Abstract

AbstractA clinical artificial intelligence (AI) system is often validated on data withheld during its development. This provides an estimate of its performance upon future deployment on data in the wild; those currently unseen but are expected to be encountered in a clinical setting. However, estimating performance on data in the wild is complicated by distribution shift between data in the wild and withheld data and the absence of ground-truth annotations. Here, we introduce SUDO, a framework for evaluating AI systems on data in the wild. Through experiments on AI systems developed for dermatology images, histopathology patches, and clinical notes, we show that SUDO can identify unreliable predictions, inform the selection of models, and allow for the previously out-of-reach assessment of algorithmic bias for data in the wild without ground-truth annotations. These capabilities can contribute to the deployment of trustworthy and ethical AI systems in medicine.Subject terms: Machine learning, Medical research, Ethics

## Section: Introduction

A clinical artificial intelligence (AI) system is often developed to achieve some task (e.g., diagnose prostate cancer1) on some training data and subsequently validated on a held-out set of data to which it has never been exposed. This widely-adopted evaluation process assumes that the held-out data are representative of data in the wild2; those which are currently unseen yet are expected to be encountered in a clinical setting. For example, an AI system may be trained on data from one electronic health record (EHR) system and subsequently deployed on data from another EHR system. However, data in the wild often (a) follow a distribution which is different from that of the held-out data and (b) lack ground-truth labels for the task at hand (Fig. 1a). Combined, such distribution shift which is known to adversely affect the behaviour of AI systems3, and the absence of ground-truth labels complicate the evaluation of an AI system and its predictions. It becomes challenging to identify reliable AI predictions, select favourable AI systems for achieving some task, and even perform additional checks such as assessing algorithmic bias4. Incorrect predictions, stemming from data distribution shift, can lead to inaccurate decisions, decreased trust, and potential issues of bias. As such, there is a pressing need for a framework that enables more reliable decisions in the face of AI predictions on data in the wild.

To address this need, previous work assumes highly-confident predictions are reliable5,6, even though AI systems are known to generate highly-confident incorrect predictions7. Recognising these limitations, others have demonstrated the value of modifying AI-based confidence scores through explicit calibration methods such as Platt scaling8,9 or through ensemble models10. Such calibration methods, however, can be ineffective when deployed on data in the wild that exhibit distribution shift11. Regardless, quantifying the effectiveness of calibration methods would still require ground-truth labels, a missing element of data in the wild. Another line of research focuses on estimating the overall performance of models with unlabelled data12,13. However, it tends to be model-centric, overlooking the data-centric decisions (e.g., identifying unreliable predictions) that would need to be made upon deployment of these models, and makes the oft fallible assumption that the held-out set of data is representative of data in the wild, and therefore erroneously extends findings in the former setting to those in the latter.

In this study, we propose pseudo-label discrepancy (SUDO), a framework for evaluating AI systems deployed on data in the wild. Through experiments on three clinical datasets (dermatology images, histopathology patches, and clinical notes), we show that SUDO can be a reliable proxy for model performance and thus be used to identify unreliable AI predictions. This finding holds even with overconfident models. We also show that SUDO informs the selection of models upon their deployment on data in the wild. By implementing SUDO across patient groups, we demonstrate that it also allows for the previously out-of-reach assessment of algorithmic bias for data without ground-truth labels.

a An AI system is often deployed on data in the wild, which can vary significantly from those in the held-out set (distribution shift), and which can also lack ground-truth labels. b SUDO is a 5-step framework that circumvents the challenges posed by data in the wild. First, deploy an AI system on data in the wild to obtain probability values. Second, discretize those values into quantiles. Third, sample data points from each quantile and pseudo-label (temporarily label) them with a possible class (SUDO Class 0). Sample data points with ground-truth labels from the opposite class to form a classification task. Fourth, train a classifier to distinguish between these data points. Repeat the process with a different pseudo-label (SUDO Class 1). Finally, evaluate and compare the performance of the classifiers on the same held-out set of data with ground-truth labels, deriving the pseudo-label discrepancy. This discrepancy and the relative classifier performance indicate whether the sampled data points are more likely to belong to one class than another.

## Section: Results

Two models (left column: DeepDerm, right column: HAM10000) are pre-trained on the HAM10000 dataset and deployed on the entire Stanford DDI dataset. a, b Distribution of the prediction probability values produced by the two models colour-coded based on the ground-truth label (negative vs. positive) of the data points. c, d Correlation of SUDO with the proportion of positive data points in each probability interval: ∣ρ∣ = 0.94 (p < 0.005) and ∣ρ∣ = 0.76 (p < 0.008), respectively. P-values are calculated based on a two-sided t-test. Results are shown for ten mutually-exclusive probability intervals that span the range [0, 1]. A strong correlation indicates that SUDO can be used to identify unreliable predictions. e Reliability-completeness curves of the two models, where the area under the reliability-completeness curve (AURCC) can inform the selection of an AI system without ground-truth annotations. Source data are provided as a Source Data file.

a Distribution of the prediction probability values produced by a model colour-coded based on the ground-truth label (negative vs. positive) of the data points. b SUDO values colour-coded according to the most likely label of the predictions in each probability interval. Source data are provided as a Source Data file.

Results for (left column) test set with ground-truth annotations and (right column) data in the wild without ground-truth annotations. a, b Distribution of prediction probability values of NLP model. c, d SUDO values colour-coded with most likely label in each probability interval. Survival curves for patient groups identified via (e) ground-truth annotations and (f) SUDO values with low ECOG PS (0 < p < 0.2), high ECOG PS (0.5 < p < 1.0), and unreliable (0.2 < p < 0.5) predictions. The shaded area reflects the 95% confidence interval. g, h Correlation between SUDO and proportion of positive instances (using ground-truth annotations, ∣ρ∣ = 0.95 p < 0.005) and the median survival time of patients (without ground-truth annotations, ∣ρ∣ = 0.97 p < 0.005) in each probability interval. P-values are calculated based on a two-sided t-test. ECOG Eastern Cooperative Oncology Group, PS Performance Status.

## Section: Results › Overview of the SUDO framework

SUDO is a framework that helps identify unreliable AI predictions, select favourable AI systems, and assess algorithmic bias for data in the wild without ground-truth labels. We outline the mechanics of SUDO through a series of steps (Fig. 1b).

Step 1 - Deploy probabilistic AI system on data points in the wild and return probability, s ∈ [0, 1], of positive class for each data point.

Step 2 - Generate distribution of output probabilities and discretize them into several predefined intervals (e.g., deciles).

Step 3 - Sample data points in the wild from each interval and assign them a temporary class label (pseudo label). Retrieve an equal number of data points with the opposite class label from the training set (ground-truth).

Step 4 - Train a classifier to distinguish between the pseudo-labelled data points and those with a ground-truth label.

Step 5 - Evaluate classifier on held-out set of data with ground-truth labels (e.g., using any metric such as AUC). A performant classifier supports the validity of the pseudo-label. However, each interval may consist of data points from multiple classes, exhibiting class contamination. To detect this contamination, we repeat these steps while cycling through the different possible pseudo-labels.

Pseudo-label discrepancy - Calculate the discrepancy between the performance of the classifiers with different pseudo labels. The greater the discrepancy between classifiers, the lower the class contamination, and the more likely that the data points belong to a single class. We refer to this discrepancy as the pseudo-label discrepancy or SUDO.

## Section: Results › SUDO correlates with model performance on Stanford diverse dermatology images dataset

We used SUDO to evaluate predictions made on the Stanford diverse dermatology image (DDI) data14 (n: 656) (see Description of datasets). We purposefully chose two AI models (DeepDerm15 and HAM1000016) that were performant on their respective data (AUC = 0.88 and 0.92) and whose performance degraded drastically when deployed on the DDI data (AUC = 0.56 and 0.67), suggesting the presence of distribution shift.

We found that these models struggle to distinguish between benign (negative) and malignant (positive) lesions in images. This is evident by the lack of separability of the AI-based probabilities corresponding to the ground-truth negative and positive classes (Fig. 2a for DeepDerm and Fig. 2b for HAM10000). We set out to determine whether SUDO, without having access to the ground-truth labels, can quantify this class contamination. We found that SUDO correlates with the proportion of positive instances in each of the chosen probability intervals (ρ = −0.84 p < 0.005 for DeepDerm in Fig. 2c, and ρ = −0.76 p < 0.01 for HAM10000 in Fig. 2d). Such a finding, which holds regardless of the evaluation metric used (Supplementary Fig. 5), suggests that SUDO can be a reliable proxy for the accuracy of predictions. Notably, this ability holds irrespective of the underlying performance of the AI model being evaluated, as evidenced by the high correlation values for the two models which performed at different levels (AUC = 0.56 and 0.67).

Two models (left column: DeepDerm, right column: HAM10000) are pre-trained on the HAM10000 dataset and deployed on the entire Stanford DDI dataset. a, b Distribution of the prediction probability values produced by the two models colour-coded based on the ground-truth label (negative vs. positive) of the data points. c, d Correlation of SUDO with the proportion of positive data points in each probability interval: ∣ρ∣ = 0.94 (p < 0.005) and ∣ρ∣ = 0.76 (p < 0.008), respectively. P-values are calculated based on a two-sided t-test. Results are shown for ten mutually-exclusive probability intervals that span the range [0, 1]. A strong correlation indicates that SUDO can be used to identify unreliable predictions. e Reliability-completeness curves of the two models, where the area under the reliability-completeness curve (AURCC) can inform the selection of an AI system without ground-truth annotations. Source data are provided as a Source Data file.

## Section: Results › SUDO informs model selection on Stanford diverse dermatology images dataset

We can leverage SUDO to create two tiers of predictions. Reliable predictions are associated with large SUDO values that indicate low class contamination and are therefore incorporated into downstream analyses. The remaining predictions are considered unreliable and flagged for further review by a human expert. By changing our threshold for reliable predictions, we notice a trade-off between the reliability of such predictions and the proportion of which is incorporated into downstream analyses (i.e., completeness). For example, by selecting only the most reliable predictions, we reduce their completeness. Ideally, models should produce predictions that exhibit both high reliability and completeness. These two dimensions, which we capture via the reliability-completeness curve (see Producing reliability-completeness curve in Methods for details), offer an opportunity to rank order models particularly when ground-truth labels are unavailable (Fig. 2e).

We found that the ordering of the performance of the models is consistent with that presented in previous studies14. Specifically, HAM10000 and DeepDerm achieve an area under the reliability-completeness curve of AURCC = 0.86 and 0.62, respectively and, with ground-truth annotations, these models achieve (AUC = 0.67 and 0.56). We note that the emphasis here is on the relative ordering of models and not on their absolute performance. These consistent findings suggest that SUDO can help inform model selection on data in the wild without annotations.

## Section: Results › SUDO helps assess algorithmic bias without ground-truth annotations

Algorithmic bias often manifests as a discrepancy in model performance across two protected groups (e.g., male and female patients). Traditionally, this would involve comparing AI predictions to ground-truth labels. With SUDO as a proxy for model performance, we hypothesised that it can help assess such bias even without ground-truth labels. We tested this hypothesis on the Stanford DDI dataset by stratifying the AI predictions according to the skin tone of the patients (Fitzpatrick scale I-II vs. V-VI) and implementing SUDO for each of these stratified groups. A difference in the resultant SUDO values would indicate a higher degree of class contamination (and therefore poorer performance) for one group over another. We found that SUDOAUC = 0.60 and 0.58 for the two groups, respectively. This discrepancy, calculated without ground-truth labels, is indicative of the bias we also observed when using ground-truth labels and the negative predictive value of the predictions (NPV) (NPV = 0.83 and 0.78, respectively). Our findings demonstrate that both SUDO and the traditional approach (with ground-truth labels) identified a bias in favour of patients with a Fitzpatrick scale of I-II, which is consistent with previously-reported bias findings14.

## Section: Results › SUDO correlates with model performance on Camelyon17-WILDS histopathology dataset

We provide further evidence that SUDO can identify unreliable predictions on datasets that exhibit distribution shift. Here, we trained a model on the Camelyon17-WILDS dataset to perform binary tumour classification (presence vs. absence) based on a single histopathological image, and evaluated the predictions on the corresponding test set (n: 85,054) (see Description of datasets). This dataset has been constructed such that the test set contains data from a hospital unseen during training, and is thus considered in the wild. We found that the trained model achieved an average accuracy ≈ 0.85 despite being presented with images from an unseen hospital (Fig. 3a). We used SUDO to quantify the class contamination across probability intervals (Fig. 3b), and found that it continues to correlate (ρ = −0.79 p < 0.005) with the proportion of positive instances in each of the intervals.

a Distribution of the prediction probability values produced by a model colour-coded based on the ground-truth label (negative vs. positive) of the data points. b SUDO values colour-coded according to the most likely label of the predictions in each probability interval. Source data are provided as a Source Data file.

## Section: Results › SUDO can even be used with overconfident models

AI systems are prone to producing erroneous overconfident predictions, complicating our dependence on their confidence scores alone to identify unreliable predictions. It is in these settings where SUDO adds most value. To demonstrate this, we first trained a natural language processing (NLP) model to distinguish between negative (n: 1000) and positive (n: 1000) sentiment in product reviews with distribution shift as part of the Multi-Domain Sentiment dataset17 (see Description of datasets). We showed that SUDO continues to correlate with model performance, pointing to the applicability of the framework across data modalities. To simulate an overconfident model, we then overtrained (i.e., extended training for an additional number of epochs) the same NLP model, as confirmed by the more extreme distribution of the prediction probability values (Supplementary Fig. 1b). Notably, we found that SUDO continues to correlate well with model performance despite the presence of overconfident predictions (Supplementary Fig. 1h). This is because SUDO leverages pseudo-labels to quantify class contamination and is not exclusively dependent on confidence scores.

## Section: Results › Exploring the limits of SUDO with simulated data

To shed light on the scenarios in which SUDO remains useful, we conducted experiments on simulated data that we can finely control (see Description of datasets). Specifically, we varied the data in the wild to encompass distribution shift (a) with the same two classes observed during training, (b) with a severe imbalance (8:1) in the number of data points from each class, and (c) alongside data points from a third and never-seen-before class. As SUDO is dependent on the evaluation of classifiers on held-out data (see Fig. 1, Step 5), we also experimented with injecting label noise into such data.

We found that SUDO continues to strongly correlate with model performance, even in the presence of a third class (∣ρ∣ > 0.87 p < 0.005, Supplementary Fig. 2). This is not surprising as SUDO is designed to simply quantify class contamination in each probability interval, regardless of the data points contributing to that contamination. However, we did find that SUDO requires held-out data to exhibit minimal label noise, where ρ = 0.99 → 0.33 upon randomly flipping 50% of the labels in the held-out data to the opposite class. We also found that drastically changing the relationship between class-specific distributions of data points in the wild can disrupt the utility of SUDO (Supplementary Fig. 3).

## Section: Results › SUDO correlates with model performance on Flatiron Health ECOG Performance Status dataset

To demonstrate the applicability of SUDO to a range of datasets, we investigated whether it also acts as a reliable proxy for model performance on the Flatiron Health Eastern Cooperative Oncology Group Performance Status (ECOG PS) dataset. Building on previous work18, we developed an NLP model to infer the ECOG PS, a value reflecting a patient’s health status, from clinical notes of oncology patient visits (see Methods for description of data and model).

In this section, we exclusively deal with data which (a) do not exhibit distribution shift and (b) are associated with a ground-truth label. The motivation behind these experiments was to first demonstrate that we can learn an NLP model that accurately classifies ECOG PS as a prerequisite for applying SUDO to the target setting in which distribution shift exists and ground-truth labels do not.

We found that the NLP model performs well in classifying ECOG PS from clinical notes of oncology patient visits (precision = 0.97, recall = 0.92, and AUC = 0.93). We hypothesise that these results are driven by the discriminative pairs of words that appear in clinical notes associated with low and high ECOG PS. For example, typical phrases found in low ECOG PS clinical notes include “normal activity” and “feeling good” whereas those found in high ECOG PS clinical notes include “bedridden” and “cannot carry”. This strong discriminative behaviour can be seen by the high separability of the two prediction probability distributions (Fig. 4a). Although it was possible to colour-code these distributions and glean insight into the degree of class contamination, this is not possible in the absence of ground-truth labels. SUDO attempts to provide this insight despite the absence of ground-truth labels.

We found that data points with s ≈ 0 are more likely to belong to the low ECOG PS label than to the high ECOG PS label, and vice versa for data points with s ≈ 1. This is evident by the large absolute SUDOAUC values at either end of the probability spectrum (Fig. 4c). This is not surprising and is in line with expectations. Consistent with findings presented earlier, SUDO also correlates with model performance on this dataset. This can be seen by the strong correlation (∣ρ∣ = 0.95 p < 0.005) between SUDO and the proportion of positive instances in each of the chosen probability intervals. This bodes well for when we ultimately use SUDO to identify unreliable predictions without ground-truth annotations.

Results for (left column) test set with ground-truth annotations and (right column) data in the wild without ground-truth annotations. a, b Distribution of prediction probability values of NLP model. c, d SUDO values colour-coded with most likely label in each probability interval. Survival curves for patient groups identified via (e) ground-truth annotations and (f) SUDO values with low ECOG PS (0 < p < 0.2), high ECOG PS (0.5 < p < 1.0), and unreliable (0.2 < p < 0.5) predictions. The shaded area reflects the 95% confidence interval. g, h Correlation between SUDO and proportion of positive instances (using ground-truth annotations, ∣ρ∣ = 0.95 p < 0.005) and the median survival time of patients (without ground-truth annotations, ∣ρ∣ = 0.97 p < 0.005) in each probability interval. P-values are calculated based on a two-sided t-test. ECOG Eastern Cooperative Oncology Group, PS Performance Status.

## Section: Results › Sensitivity analysis of SUDO’s hyperparameters

To encourage the adoption of SUDO, we conducted several experiments on the Flatiron Health ECOG PS dataset to measure SUDO’s sensitivity to hyperparameters. Specifically, we varied the number of data points sampled from each probability interval (Fig. 1b, Step 3), the type of classifier used to distinguish between pseudo- and ground-truth labelled data points (Fig. 1b, Step 4), and the amount of label noise in the held-out data being evaluated on (Fig. 1b, Step 5). We found that reducing the number of sampled data points (from 200 to just 50) and using different classifiers (logistic regression and random forest) continued to produce a strong correlation between SUDO and model performance (∣ρ∣ > 0.94 p < 0.005) (Supplementary Fig. 4). Such variations, however, altered the directionality (net positive or negative) of the SUDO values (from one experiment to the next) in the probability intervals with a high degree of class contamination. For example, in the interval 0.20 < s < 0.25 (Fig. 4a), SUDOAUC = 0.05 and SUDOAUC = − 0.05 when sampling 50 and 200 data points, respectively. We argue that such an outcome does not practically affect the interpretation of SUDO, as it is the absolute value of SUDO that matters most when it comes to identifying unreliable predictions. We offer guidelines on how to deal with this scenario in a later section.

## Section: Results › Using SUDO to identify unreliable predictions on Flatiron Health ECOG Performance Status dataset

To further illustrate the utility of SUDO, we deployed the NLP model on the Flatiron Health ECOG PS data in the wild without ground-truth annotations. It is likely that such data (clinical notes without ECOG PS labels) follow a distribution that is distinct from that of the training data (clinical notes with ground-truth ECOG PS labels). This is supported by the distinct distributions of the prediction probability values across these datasets (see Fig. 4a, b). Such a shift can make it ambiguous to identify unreliable predictions based exclusively on confidence scores. To resolve this ambiguity, we implemented SUDO for ten distinct probability intervals, choosing more granular intervals in the range 0 < s < 0.40 to account for the higher number of predictions (Fig. 4d). These results suggest that predictions with 0 < s < 0.20 are more likely to belong to the low ECOG PS class than to the high ECOG PS class. The opposite holds for predictions with 0.30 < s < 1. Such insight, which otherwise would have been impossible without ground-truth annotations, can now better inform the identification of unreliable predictions.

## Section: Results › Validating SUDO-guided predictions with a survival analysis

To gain further confidence in SUDO’s ability to identify unreliable predictions, we leveraged the known relationship between ECOG PS and mortality: patients with a higher ECOG PS are at higher risk of mortality19. As such, we can compare the overall survival estimates of patients with reliable AI predictions (i.e., large SUDO values) to those of patients with known ECOG PS values (e.g., patients in the training set). The intuition is that if such overall survival estimates are similar to one another, then we can become more confident in the ECOG PS labels that were newly assigned to clinical notes from oncology patient visits. While this approach makes the assumption that the ECOG PS label is the primary determinant of overall survival, we acknowledge that additional confounding factors, beyond the ECOG PS label, may also play a role20.

For patients in the training set of the Flatiron Health ECOG PS dataset, we present their survival curves stratified according to whether they have a low or high ECOG PS (Fig. 4e). For patients in the data in the wild, for whom we do not have a ground-truth ECOG PS label, we first split them into three distinct groups based on the SUDO value (Fig. 4d), employing the intuition that a higher absolute value is reflective of more reliable predictions (e.g., ∣SUDOAUC∣ > 0.05). We refer to these groups based on their corresponding predictions: low ECOG PS group (0 < s ≤ 0.2, n: 12, 603), high ECOG PS group (0.5 ≤ s < 1.0, n: 552), and an uncertain ECOG PS group (0.2 < s < 0.5, n: 3729). As demonstrated in an earlier section, the chosen SUDO threshold creates a trade-off between the reliability and completeness of the predictions. We present the group-specific survival curves (Fig. 4f). To control for confounding factors, we only considered data samples associated with the first line of therapy where patients are provided their first medication in their treatment pathway (see Methods for more details).

There are two main takeaways. First, and in alignment with our expectations and established clinical observations, we found that patients in the low ECOG PS group do indeed exhibit a longer median survival time than patients in the high ECOG PS group (1.87 vs. 0.68 years, respectively) (Fig. 4f). Second, the chosen probability intervals based on which the survival analysis was stratified reasonably identified distinct patient cohorts. This is evident by the distinct survival curves of the patient cohorts with 0 < s ≤ 0.2 and 0.5 ≤ s < 1 and their similarity to the survival curves of patients with a ground-truth ECOG PS label (Fig. 4e). For example, the median survival estimates of these two patient cohorts are 2.07 (vs. 1.87) and 0.95 (vs. 0.68) years, respectively. Although we do not expect such values to be perfectly similar, due to potential hidden confounding factors we cannot control for, they are similar enough to suggest that these newly-identified patient cohorts correspond to low and high ECOG PS patient cohorts.

Demonstrating that SUDO correlates with a meaningful variable can engender trust in its design. When ground-truth annotations are available, we chose this variable to be the proportion of positive instances in each probability interval (i.e., accuracy of predictions). Without ground-truth annotations, we chose the median survival time of patients in each interval. Specifically, we quantified the correlation between SUDO and the median survival time of patient cohorts in each of the ten chosen probability intervals (Fig. 4h). We found that that these two variables are indeed strongly correlated (∣ρ∣ = 0.97 p < 0.005). Such a finding suggests that SUDO can provide useful insight into the clinical characteristics of patient cohorts in datasets without ground-truth labels (see Discussion for benefits and drawbacks of such an approach).

## Section: Results › Practical guidelines for using SUDO

We have made the case and presented evidence that SUDO can evaluate AI systems without ground-truth annotations. We now take stock of our findings to offer practical guidelines around SUDO. First, we demonstrated that SUDO works well across multiple data modalities (images, text, simulation). We therefore recommend using SUDO irrespective of the modality of data a model is evaluated on. Second, we showed that SUDO is agnostic to the neural network architecture of the AI system being evaluated (convolutional for images, feed-forward for text). The only requirement is that the neural network returns a probabilistic value. Third, we showed that SUDO can deal with as few as 50 data points sampled from each probability interval (on the Stanford DDI dataset). Although sampling too few data points did not change the absolute value of SUDO, and thereby reliably quantifying class contamination, it did alter its directionality (negative or positive), affecting the perceived proportion of the majority class in a set of predictions. To avoid being misled by this behaviour, we recommend sampling at least 50% of the data points in each probability interval in order to capture a representative set of predictions. We also note that the absolute value of SUDO should take precedent for determining unreliable predictions. Only if that value is large enough (i.e., low class contamination) should its directionality be considered.

Fourth, we showed that SUDO is unperturbed by an imbalance in the number of data points from each class or by the presence of a third-and-unseen class (on the simulated dataset). If data in the wild are suspected to exhibit these features, then SUDO can still be used. Fifth, we showed that SUDO is sensitive to the quality of the labels in the held-out set of data. As such, we recommend curating a dataset with minimal label noise when using SUDO. Furthermore, we showed that SUDO produces consistent results irrespective of the classifier used to distinguish between pseudo-labelled and ground-truth data points and of the metric used to evaluate these classifiers. We therefore recommend using a lightweight classifier (to speed up computation) and the metric most suitable for the task at hand.

## Section: Discussion

AI systems have long been validated on withheld data, with the assumption that such data are representative of data in the wild. When this assumption is violated, as is often the case with clinical data, and ground-truth annotations are unavailable, it becomes difficult to trust the predictions made by an AI system.

We have shown that SUDO can comfortably assess the reliability of predictions of AI systems deployed on data in the wild. Notably, we demonstrated that SUDO can supplement confidence scores to identify unreliable predictions, help in the selection of AI systems, and assess the algorithmic bias of such systems despite the absence of ground-truth annotations. Although we have presented SUDO primarily for clinical AI systems and datasets, we believe its principles can be applied to probabilistic models in almost any other scientific discipline.

Compared with previous studies, our study offers a wider range of applications for predictions on data without ground-truth annotations. These applications include identifying unreliable predictions, selecting favourable models, and assessing algorithmic bias. Previous work tends to be more model-centric than SUDO, focusing on estimating model performance12,13,21,22 and assessing algorithmic bias23 using both labelled and unlabelled data. It therefore overlooks the myriad data-centric decisions that would need to be made upon deployment of an AI system, such as identifying unreliable predictions. The same limitation holds for other studies that attempt to account for verification bias24,25, a form of distribution shift brought about by only focusing on labelled data. In contrast, SUDO provides the optionality of guiding decisions at the model level (e.g., relative model performance) and at the data level (e.g., identifying unreliable predictions).

Most similar to our work is the concept of reverse testing26 and reverse validation27,28 where the performance of a pair of trained AI systems is assessed by deploying them on data without annotations, pseudo-labelling these data points, and training a separate classifier to distinguish between these data points. The classifier that performs better on a held-out set of labelled data is indicative of higher quality pseudo-labels and, by extension, a favourable AI system. SUDO differs from this line of work in two main ways. First, reverse testing assigns a single AI-based pseudo-label to each data point in the wild whereas we assign all possible pseudo-labels to that data point (through distinct experiments) in order to determine the most likely ground-truth label. Second, given the probabilistic output of an AI system, reverse testing performs pseudo-labelling for data points that span the entire probability spectrum for the exclusive purpose of model selection. As such, it cannot be used for identifying unreliable predictions. Notably, previous work heavily depends on the assumption that the held-out set of data is representative of data in the wild. SUDO circumvents this assumption by operating directly on data in the wild.

SUDO’s ability to identify unreliable predictions has far-reaching implications. From a clinical standpoint, data points whose predictions are flagged as unreliable can be sent for manual review by a human expert. By extension, and from a scientific standpoint, this layer of human inspection can improve the integrity of research findings. We note that SUDO can be extended to the multi-class setting (e.g., c > 2 classes) by cycling through all of the pseudo-labels and retrieving data points from the mutually-exclusive classes (Fig. 1b, Step 3) to train a total of c classifiers (Fig. 1b, Step 4). The main difference to the binary setting is that SUDO would now be calculated as the maximum difference in performance across all classifiers (Fig. 1b, Step 5). SUDO’s ability to select favourable (i.e., more performant) AI systems can lead to the deployment of more accurate systems that contribute to improved patient care. SUDO’s ability to assess algorithmic bias, which was not previously possible for data without ground-truth labels, can contribute to the ethical deployment of AI systems. This ensures that AI systems perform as expected when deployed on data in the wild. We note that SUDO can also be used to assess algorithmic bias across multiple groups by simply implementing SUDO for data points from each group. Bias would still manifest as a discrepancy in the SUDO value across the groups. Overall, our study offers a first step towards a framework of inferring clinical variables which suffer from low completeness in the EHR (such as ECOG PS) in the absence of explicit documentation in their charts and ground-truth labels.

There are several challenges that our work has yet to address. First, SUDO cannot identify the reliability of a prediction for an individual data points. This is because we often calculated SUDO as a function of prediction probability intervals. This is in contrast to previous work on uncertainty quantification and selective classification. While SUDO can be applied to individual data points, this is not practical as it depends on the learning of predictive classifiers, which typically necessitate a reasonable number of training data points. We do note, though, that SUDO was purposefully designed to assess the relative reliability of of predictions across probability intervals. It is also worth noting that SUDO may be considered excessive if the amount of data in the wild is small and can be annotated by a team of experts with reasonable effort. However, when presented with large-scale data in the wild, SUDO can yield value by acting as a data triage mechanism, funneling the most unreliable predictions for further inspection by human annotators. In doing so, it stands to reduce the annotation burden placed on such annotators. Furthermore, despite having presented evidence of SUDO’s utility on multiple real-world datasets with distribution shift, we have not explored how SUDO would behave for the entire space of possible distribution shifts. It therefore remains an open question whether a particular type of distribution shift will render SUDO less meaningful. On some simulated data, for example, we found that SUDO is less meaningful upon introducing drastic label noise or changing the class-specific distributions of the data points in the wild. More generally, we view SUDO merely as one of the first steps in informing decision-making processes. Subsequent analyses, such as statistical significance tests, would be needed to gain further confidence in the resulting conclusions.

To validate SUDO without ground-truth annotations, we measured its correlation with median survival time, a clinical outcome with a known relationship to ECOG PS. This approach was made possible by leveraging domain knowledge. In settings where such a relationship is unknown, we recommend identifying clinical features in the labelled data that are unique to patient cohorts. These features can include the type and dosage of medication patients receive and whether or not they were enroled in a clinical trial. A continuous feature (e.g., medication dosage) may be preferable to a discrete one (e.g., on or off medication) in order to observe a graded response with the prediction probability intervals. If identifying one such feature is difficult and time-consuming, a data-driven alternative could involve clustering patients in the labelled data according to their clinical characteristics. Distinct clusters may encompass a set of features unique to patient cohorts. Prediction on data in the wild can then be assessed based on the degree to which they share these features. On the other hand, the more severe the distribution shift, the less likely it is that features will be shared across the labelled and unlabelled data.

There are also important practical and ethical considerations when it comes to using SUDO. Without SUDO, human experts would have to painstakingly annotate all of the data points in the wild. Such an approach does not scale as datasets grow in size. Moreover, the ambiguity of certain data points can preclude their annotation by human experts. SUDO offers a way to scale the annotation process while simultaneously flagging unreliable predictions for further human inspection. However, as with any AI-based framework, over-reliance on SUDO’s findings can pose risks particularly related to mislabelling data points. This can be mitigated, in some respects, by choosing a more conservative operating point on the reliability-completeness curve.

Moving forward, we aim to expand the application areas of SUDO to account for the myriad decisions that AI predictions inform. This could include using SUDO to detect distribution shift in datasets, thereby informing whether, for example, an AI system needs to be retrained on updated data. Another line of research includes improving the robustness of SUDO to label noise and expanding its applicability to scientific domains in which label noise is rampant. We look forward to seeing how the community leverages SUDO for their own applications.

## Section: Methods

Examples of potential sources of the ECOG PS label

## Section: Methods › Description of datasets

Examples of potential sources of the ECOG PS label

## Section: Methods › Description of datasets › Stanford diverse dermatology images

The Stanford diverse dermatology images (DDI) dataset consists of dermatology images collected in the Stanford Clinics between 2010 and 2020. These images (n: 656) reflect either a benign or malignant skin lesion from patients with three distinct skin tones (Fitzpatrick I-II, III-IV, V-VI). For further details, we refer interested readers to the original publication14. We chose this as the data in the wild due to a recent study reporting the degradation of several models’ performance when deployed on the DDI dataset. These models (see Description of models) were trained on the HAM10000 dataset, which we treated as the source dataset.

## Section: Methods › Description of datasets › HAM10000 dataset

The HAM10000 dataset consists of dermatology images collected over 20 years from the Medical University of Vienna and the practice of Cliff Rosendahl16. These images (n: 10015) reflect a wide range of skin conditions ranging from Bowen’s disease and basal cell carcinoma to melanoma. In line with a recent study14, and to remain consistent with the labels of the Stanford DDI dataset, we map these skin conditions to a binary benign or malignant condition. We randomly split this model into a training and held-out set using a 80: 20 ratio. We did not use a validation set as publicly-available models were already available and therefore did not need to be trained from scratch.

## Section: Methods › Description of datasets › Camelyon17-WILDS dataset

The Camelyon17-WILDS dataset consists of histopathology patches from 50 whole slide images collected from 5 different hospitals29. These images (n: 450, 000) depict lymph node tissue with or without the presence of a tumour. We use the exact same training (n: 302, 436), validation (n: 33, 560), and test (n: 85, 054) splits constructed by the original authors3. Notably, the test set contains patches from a hospital whose data was not present in the training set. This setup is therefore meant to reflect the real-world scenario in which models are trained on data from one hospital and deployed on those from another. We chose this dataset as it was purposefully constructed to evaluate the performance of models when presented with data distribution shift.

## Section: Methods › Description of datasets › Simulated dataset

We generated a dataset to include a training and held-out set, and data in the wild. To do so, we sampled data from a two-dimensional Gaussian distribution (one for each of the two classes) with diagonal covariance matrices. Specifically, data points from class 1 (x1) and class 2 (x2) were sampled as follows: x1~N([1,1],[0.8,0.8]), x2~N([2,2],[0.1,0.1]). We assigned 500 and 200 data points to the training and held-out sets. As with the DDI dataset, we did not create a validation set because there was no need to optimise the model’s hyperparameters. As for the data in the wild (xW), these were sampled from different distributions based on the experiment we were conducting. In the out-of-domain setting with and without an imbalance in the number of data points from each class, x1W~N([2,−1],[1,1]) and x2W~N([3,0],[1,1]). Data points from a third class were sampled as follows: x3W~N([3,−1],[1,1]). We assigned 1000 data points to each class for the data in the wild, except for in the label imbalance experiment where we assigned 4000 data points to class 1 and 500 data points to class 2, reflecting an 8: 1 ratio. For the scenario in which we inject label noise into the held-out dataset, we randomly flip 50% of the labels to the opposite class.

## Section: Methods › Description of datasets › Multi-domain sentiment dataset

The multi-domain sentiment dataset consists of reviews of products on Amazon. These products span four different domains from books and electronics to kitchen and DVDs. Each review is associated with either a negative or positive label reflecting the sentiment of the review. In each domain, there are n = 1000 reviews reflecting positive and negative sentiment (n = 2000 total). When conducting experiments with this dataset, we split the reviews in each domain into training, validation, and test sets using a 60: 20: 20 split.

## Section: Methods › Description of datasets › Flatiron Health ECOG Performance Status (PS)

The nationwide electronic health record (EHR)-derived longitudinal Flatiron Health database, comprises de-identified patient-level structured and unstructured data curated via technology-enabled abstraction, with de-identified data originating from ~ 280 US cancer clinics ( ~ 800 sites of care)30. The majority of patients in the database originate from community oncology settings; relative community/academic proportions may vary depending on study cohort. Our dataset, which we term the Flatiron Health ECOG Performance Status database, included 20 disease specific databases available at Flatiron Health as of October 2021 including acute myeloid leukaemia (AML), metastatic breast cancer (mBC), chronic lymphocytic leukaemia (CLL), metastatic colorectal cancer (mCRC), diffuse large B-cell lymphoma (DLBCL), early breast cancer (eBC), endometrial cancer, follicular lymphoma (FL), advanced gastro-esophageal cancer (aGE), hepatocellular carcinoma (HCC), advanced head and neck cancer (aHNC), mantle cell lymphoma (MCL), advanced melanoma (aMel), multiple myeloma (MM), advanced non-small cell lung cancer (aNSCLC), ovarian cancer, metastatic pancreatic cancer, metastatic prostate cancer, metastatic renal-cell carcinoma (mRCC), small cell lung cancer (SCLC), and advanced urothelial cancer. For these patients, the database contains dates of line of therapy (LOT) which is a sequence of anti-neoplastic therapies that a patient receives following the disease cohort inclusion date. The start and end dates of the distinct lines of therapy were captured from both structured and unstructured data sources in the EHR via previously-developed and clinically-informed algorithms. Furthermore, our dataset also contains unstructured clinical notes generated by clinicians that are time-stamped with the visit date (e.g., June 1st, 2017).

## Section: Methods › Description of datasets › Ethics approval

The Institutional Review Board of WCG IRB (reference number: IRB00000533) approved of the study protocol prior to study conduct, and included a waiver of informed consent. Patient consent was waived because (a) the research does not involve greater than minimal risk, (b) leverages observational research, which relies on data which was previously collected-as such it is not practicable to conduct the research without the waiver or alteration, and (c) waiving or altering the informed consent will not adversely affect the subjects’ rights and welfare. This ethics approval pertains to the use of the Flatiron Health ECOG Performance Status dataset.

Examples of potential sources of the ECOG PS label

## Section: Methods › Description of datasets › Ethics approval

ECOG PS is a clinical variable that reflects the performance status of an oncology patient. It ranges from 0 (patient has no limitations in mobility) to 5 (patient deceased)31 and has been largely used within the context of clinical trials but is also often used by physicians in clinical practice as they make treatment decisions for patients32,33. Additionally, in the context of real world evidence, ECOG PS can be used to identify study cohorts of interest (typically those with ECOG PS < 234).

In the Flatiron Health ECOG Performance Status database, the ECOG PS is captured as part of the EHR in either a structured or unstructured form, as outlined next (see Table 1). Structured ECOG PS refers to ECOG values captured in the structured fields of the EHR, such as from drop down lists. In contrast, extracted and abstracted ECOG PS both refer to ECOG values that are captured in unstructured oncologist-generated clinical notes in the EHR. Extracted ECOG PS implies that an NLP symbol-matching (regular expressions) algorithm was used to extract it from clinical notes. This regular expression algorithm was previously developed by researchers at Flatiron Health. Finally, abstracted ECOG PS implies that a human abstractor was able to extract it through manual inspection of clinical notes.

Examples of potential sources of the ECOG PS label

## Section: Methods › Description of datasets › Ethics approval

We developed a model which leverages oncology clinical notes to infer a patient’s ECOG PS within a window of time (e.g., 30 days) prior to the start of distinct lines of therapy. In oncology research, it is often important to know a patient’s ECOG PS at treatment initiation. This allows researchers to investigate the interplay between ECOG PS and different lines of therapy. To achieve this, we consolidated clinical notes within a window of time prior to distinct line of therapy start dates, and combined ECOG PS values (where applicable) using the following strategies.

## Section: Methods › Description of datasets › Ethics approval

We hypothesised that clinical notes up to one month (30 days) before the start date of a line of therapy would contain sufficient information about the performance status of the patient to facilitate the inference of ECOG PS. Given that a patient’s ECOG PS can fluctuate over time, retrieving clinical notes further back beyond a month would have potentially introduced superfluous, or even contradictory, information that exacerbated an NLP model’s ability to accurately infer ECOG PS. Conversely, exclusively retrieving clinical notes too close to the start date of the LOT might avoid picking up on valuable information further back in time. Based on this intuition, we concatenated all of a patient’s clinical notes time-stamped up to and including 30 days before the start date of each of their lines of therapy.

## Section: Methods › Description of datasets › Ethics approval

A particular line of therapy for a patient may sometimes be associated with a single ECOG PS (e.g., in structured form) or multiple ECOG PS values (e.g., in extracted and an abstracted form). When multiple sources of ECOG PS scores were available, we consolidated them by only considering the largest value (e.g., assign ECOG PS 1 if structured ECOG PS = 0 and abstracted ECOG PS = 1).

Moreover, and without loss of generality, we combined ECOG PS such that [0, 1] map to low ECOG PS and [2, 3, 4] map to high ECOG PS. We chose this binary bucketing since clinical trials in medical oncology typically only include patients with an ECOG PS < 2. The distribution of low and high ECOG PS scores in our study cohort was 82: 18.

## Section: Methods › Description of datasets › Ethics approval

Given the above two consolidation strategies, each sample of data our NLP model was exposed to consisted of (a) concatenated clinical notes for a patient up to 30 days before an LOT and, where available, (b) an ECOG PS label associated with that LOT. Such samples are referred to as labelled. We refer to samples of concatenated clinical notes without an associated ECOG PS label (for details on why, see next section on missingness of ECOG PS) as unlabelled. It is in this scenario where inferring a patient’s ECOG PS is most valuable. (see Table 1).

## Section: Methods › Description of datasets › Ethics approval

There exist a myriad of reasons behind the missingness of the ECOG PS score. For example, in some cases, documenting an ECOG PS score may simply not be a part of a clinician’s workflow or may be difficult to document. Alternatively, not documenting an ECOG PS score could be directly related to the qualitative assessment of a patient’s health status where its absence could suggest an underlying low ECOG PS value. These reasons, in a majority of settings, imply that the unlabelled clinical notes might follow a distribution that is different from that followed by labelled clinical notes. This discrepancy is also known as covariate shift. As such, we are faced with unlabelled data that exhibit distribution shift. Although our framework’s design was motivated by these characteristics, quantifying its utility exclusively on this dataset is challenging due to the absence of ground-truth ECOG PS labels.

## Section: Methods › Description of datasets › Ethics approval

Our first study cohort consists of n = 117, 529 samples associated with ECOG PS labels. As outlined above, each sample consists of concatenated clinical notes before a particular line of therapy for a patient. When conducting experiments with this cohort, we split the data into training, validation, and test sets using a 70: 10: 20 split. This amounted to n = 81, 909, n = 11, 806, n = 23, 814 samples, respectively. Our second study cohort consists of n = 33, 618 samples not associated with ECOG PS labels.

## Section: Methods › Description of models › Models for image-based datasets

For the image-based datasets (Stanford DDI and HAM10000), we used two publicly-available models (DeepDerm15 and HAM1000016) that had already been trained on the HAM10000 dataset. We refer readers to the respective studies for details on how these models were trained. In this study, we directly used these models (without retraining) as part of the SUDO experiments. As for the Camelyon17-WILDS dataset, we trained a DenseNet121 model using the default hyperparameters recommended by the original authors3.

## Section: Methods › Description of models › Models for language-based datasets

For language-based datasets (Multi-Domain Sentiment and Flatiron Health ECOG PS), we developed a neural network composed of three linear layers which received text as input and returned the probability of it belonging to the positive class, which is positive sentiment for the Multi-Domain Sentiment dataset, and high ECOG PS for the Flatiron Health ECOG Performance Status dataset. An in-depth description of how we pre-processed the input text can be found in the Methods section.

## Section: Methods › Description of models › Models for language-based datasets

We represented text via a bag of words (BoW). This first involved identifying a fixed vocabulary of pairs of words (also known as bigram tokens) present in the training set. After experimenting with a different number of tokens (e.g., 500, 1,000, 5,000, 10,000), we decided to focus on the 1000 most common tokens as we found that number to provide enough information to learn a generalisable NLP model while not being computationally intensive. The remaining experiments did not result in improved performance. Each document was thus converted into a 1000-dimensional representation (1 dimension for each token) where each dimension reflected the frequency of a particular token in the document. The token mean and standard deviation was calculated across training samples in order to standardise each bigram representation. We found this to result in slightly better performance than settings without input scaling.

## Section: Methods › Details of SUDO framework

SUDO is a framework that helps identify unreliable predictions, select favourable AI models, and assess the algorithmic bias of such systems on data without ground-truth labels. To implement SUDO, we recommend following the steps outlined in the Results (Fig.1b). Here, we provide additional details and intuition about SUDO, mentioning how they align with the previously-outlined steps.

Let us assume we have a probabilistic model that returns a single value reflecting the probability, s, that an input belongs to the positive class (e.g., high ECOG PS in the Flatiron Health ECOG PS dataset). We can generate a distribution of such probability values for all data points and discretize the distribution in probability intervals (Fig. 1b, Step 1 and Step 2).

## Section: Methods › Details of SUDO framework › Sample data points

From each probability interval s ∈ (s1, s2] where s1 < s2, we sampled a subset of the data points (Fig. 1b, Step 3). To avoid sampling more data points from one probability interval than from another, and potentially affecting the reliability of estimates across intervals, we fixed the number of data points, m, to sample from each interval. Specifically, m was chosen based on the lowest number of data points within an interval, across all probability intervals. For example, if the interval s ∈ (0.4, 0.5] contains the lowest number of data points (e.g., 50), then we sample m = 50 data points from each interval. This also ensures that we sample data points without replacement to avoid a single data point from appearing multiple times in our experiments and biasing our results. Next, we assigned these sampled data points a temporary label, also known as a pseudo-label, hypothesizing that they belong to a certain class (e.g., class 0).

## Section: Methods › Details of SUDO framework › Train classifier

We then trained a classifier, gϕ, to distinguish between such newly-labelled data points and data points with a ground-truth label from the opposite class (e.g., class 1) (Fig. 1b, Step 4). It is worthwhile to mention that this classifier need not be the exact same model as the one originally used to perform inference (i.e., gϕ ≠ fθ). The prime desiderata of the classifier are that it (i) is sufficiently expressive such that it can discriminate between positive and negative examples and (ii) can ingest the input data. Such a modular approach, where one model is used for the original inference (Fig. 1b, Step 1) and another is used to distinguish between positive and negative examples ((Fig. 1b, Step 4) is less restrictive for researchers and can obviate the need to (re)train potentially computationally expensive inference models. This line of argument also extends to settings with different data modalities (e.g., images, time-series, etc.), and, as such, makes SUDO agnostic to the modality of the data used for training and evaluating the model.

## Section: Methods › Details of SUDO framework › Evaluate classifier

After training gϕ, we evaluated it on a held-out set of data comprising data points with ground-truth labels (from both class 0 and class 1) (Fig. 1b, Step 5). The intuition here is that a classifier which can successfully distinguish between these two classes, by performing well on the held-out set of data, is indicative that the training data and the corresponding ground-truth labels are relatively reliable. Since the data points from class 1 are known to be correct (due to our use of ground-truth labels), then a highly-performing classifier would suggest that the class 0 pseudo-labels of the remaining data points are likely to be correct. In short, this step quantifies how plausible it is that the sampled unlabelled data points belong to class 0.

As presented, this approach determines how plausible it is that the sampled set of data points in some probability interval, s ∈ (s1, s2], belongs to class 0. It is entirely possible, however, that a fraction of these sampled data points belong to the opposite class (e.g., class 1). We refer to this mixture of data points from each class as class contamination. We hypothesised (and indeed showed) that the degree of this class contamination increases as the probability output, s, by an AI system steers away from the extremes (s ≈ 0 and s ≈ 1). To quantify the extent of this contamination, however, we also had to determine how plausible it was that the sampled set of data points belong to class 1, as we outline next.

## Section: Methods › Details of SUDO framework › Cycle through the pseudo-labels

We repeated the above approach (Fig. 1b, Steps 3, 4, and 5) however with two distinct changes. First, we pseudo-labelled the sampled data points with class 1 (instead of class 0). In doing so, we are hypothesizing that these data points belong to class 1. Second, we trained a classifier to distinguish between such newly-labelled data points and data points with ground-truth labels from class 0.

When experimenting with the distinct pseudo-labels, we always sample the same set of data points, as enforced by a random seed. Doing so ensures that any difference in the predictive performance of the learned classifiers, gϕ, is less attributable to differences in the sampled data points and, instead, more attributable to the pseudo-labels that we have assigned. Moreover, to ensure that our approach is not constrained by a particular subset of sampled data points, we repeat this entire process multiple (k = 5) times, each time sampling a different subset of data points from each probability interval, as enforced by a random seed (e.g., 0 to 4 inclusive).

## Section: Methods › Details of SUDO framework › Derive the pseudo-label discrepancy

The discrepancy between, and ranking of, the classifier performances above is indicative of data points that are more likely to belong to one class than another. Concretely, if the classifier, gϕ, achieves higher performance when presented with sampled data points that are pseudo-labelled as class 0 than as class 1, then the set of pseudo-labelled data points are more likely to belong to class 0. We refer to this discrepancy in performance under different scenarios of pseudo-labels as the pseudo-label discrepancy, or SUDO.

## Section: Methods › Implementation details of SUDO experiments

SUDO involves selecting several hyperparameters. These can include the granularity and number of probability intervals, the number of data points to sample from each probability interval, the number of times to repeat the experiment, and the type of classifier to use. We offer guidelines on how to select these hyperparameters in the Results.

## Section: Methods › Implementation details of SUDO experiments › Stanford DDI dataset

For the DeepDerm model (Fig. 2a), we selected ten mutually-exclusive and equally-sized probability intervals in the range 0 < s < 1, and sampled 10 data points from each probability interval. For the HAM10000 model (Fig. 2b), we selected ten mutually-exclusive and equally-sized probability intervals in the range 0 < s < 0.5, and sampled 50 data points from each probability interval. In the latter setting, we chose a smaller probability range and more granular probability intervals to account for the high concentration of data points as s → 0.

To amortize the cost of training classifiers as part of the SUDO experiments, we extracted image representations offline (before the start of the experiments) and stored them for later retrieval. To capture a more representative subset of the data points and obtain a better estimate of the performance of these classifiers, we repeated these experiments 5 times for each probability interval and pseudo-label. To accelerate the experiments, we used a lightweight classifier such as a logistic regression, discovering that more complex models simply increased the training overhead without altering the findings. Unless otherwise noted, we adopted this strategy for all experiments.

## Section: Methods › Implementation details of SUDO experiments › Camelyon17-WILDS dataset

We selected eleven mutually-exclusive and equally-sized probability intervals in the range 0.10 < s < 0.75 which was chosen based on where the AI-based probability values were concentrated. We sampled 1000 data points from each probability interval. To remain consistent with the other experiments in this study, we used the provided in-distribution validation set as the held-out set (Fig. 1, Step 5). As with the Stanford DDI dataset, to minimise the cost of conducting the SUDO experiments, we first extracted and stored the image representations of the histopathology patches using the trained DenseNet121 model. We otherwise followed the same approach as that mentioned above.

## Section: Methods › Implementation details of SUDO experiments › Multi-domain sentiment dataset

We also selected ten mutually-exclusive and equally-sized probability intervals in the range 0 < s < 1, and sampled 50 and 10 data points from each probability interval when dealing with a network that was not overconfident and one that was trained to be overconfident. We sampled fewer data points in the latter setting because prediction probability values were concentrated at the extreme ends of the probability range (s → 0 and s → 1), leaving fewer data points in the remaining probability intervals. As demonstrated in the Results, SUDO can deal with such data-scarce settings.

## Section: Methods › Implementation details of SUDO experiments › Simulated dataset

We selected ten mutually-exclusive and equally-sized probability intervals in the range 0 < s < 1, and sampled 50 data points from each probability interval.

## Section: Methods › Implementation details of SUDO experiments › Flatiron Health ECOG PS dataset

On the Flatiron Health ECOG Performance Status dataset with ECOG PS labels, we sampled 200 data points from each probability interval. This value was chosen to capture a sufficient number of predictions from each probability interval without having to sample with replacement. On the Flatiron Health ECOG Performance Status dataset without ECOG PS labels (data in the wild), we sampled 500 data points from each interval in the range (0, 0.45] and 100 data points from each interval in the range (0.45, 1]. This was due to the skewed distribution of the probability values generated in such a setting (see Fig. 4b).

## Section: Methods › Implementation details of algorithmic bias experiment

To demonstrate that SUDO can help assess algorithmic bias on data without ground-truth annotations, we conducted experiments on the Stanford DDI dataset because those images could be categorised based on a patient’s skin tone (Fitzpatrick I-II, III-IV, V-VI). As such, we would be able to assess the bias of the pre-trained AI systems against particular skin tones.

We followed the same steps to implement SUDO (see Fig. 1b). The main difference is that we first stratified the data points according to skin tone. Based on the bias reported in a recent study14, we focused on skin tone I-II and V-VI. Although such stratification can be done within each probability interval, after having observed the the HAM10000 model’s prediction probability values (Fig. 2b), we considered a single probability interval 0 < s < 0.20 where data points would be classified as negative (benign lesions). We sampled 200 data points from this probability interval for each group (I-II and V-VI) to conduct the SUDO experiments and calculated the AUC of the subsequently-learned classifiers.

## Section: Methods › Applications of SUDO

SUDO can help with identifying unreliable clinical predictions, selecting favourable AI systems, and assessing the bias of such systems, as outlined next.

## Section: Methods › Applications of SUDO › Identifying unreliable AI-based predictions

Identifying unreliable AI-based predictions, those whose assigned label may be incorrect, is critical for avoiding the propagation of error through downstream research analyses. SUDO allows for this as it provides an estimate of the degree of class contamination for data points whose corresponding AI-based output probabilities are in some probability interval. Specifically, a ↓∣D∣ (small difference in classifier performance across pseudo-label settings) implies ↑ class contamination. As such, by focusing on probability intervals with ∣D∣ < τ where τ is some predefined cutoff, one can now identify unreliable AI-based predictions. As we will show, there is an even greater need to identify such contamination when dealing with over-confident AI systems.

## Section: Methods › Applications of SUDO › Selecting AI systems

An AI system is often chosen based on its reported performance on a held-out set of data. We define a favourable AI system as that which performs best on a held-out set of data compared to a handful of models. The ultimate goal is to deploy the favourable model on data in the wild. However, with data in the wild exhibiting a distribution shift and lacking ground-truth labels, it is unknown what the performance of the chosen AI system would be on the data in the wild, thereby making it difficult to assess whether it actually is favourable for achieving its goal.

## Section: Methods › Applications of SUDO › Assessing algorithmic bias

Assessing algorithmic bias is critical for ensuring the ethical deployment of AI systems. A common approach to quantify such bias is through a difference in AI system performance across groups of patients (e.g., those in different gender groups)35. The vast majority of these approaches, however, requires ground-truth labels which are absent from data points in the wild thereby making an assessment of bias out-of-reach. However, SUDO, by producing a reliable proxy for model performance, allows for this capability.

## Section: Methods › Implementation details of survival analysis

We assessed real world overall survival defined as time from the start of first line of therapy (LOT = 1) to death36. If death was not observed by the study end date (October 2021), patients were censored at the date of a patient’s latest clinical visit. We estimated survival using the Kaplan Meier method and used lifelines package to conduct our analysis37. To avoid confounding due to lines of therapy, we conducted all survival analyses for patients receiving their first line of therapy only (i.e., LOT = 1). No other adjustments were made.

## Section: Methods › Implementation details of survival analysis › Steps to generate Fig. 4e

We first filtered our data samples with known ground-truth ECOG PS labels (n = 117, 529) to only consider those tagged with the first line of therapy (LOT = 1). Using these samples, we conducted two survival analyses: one with data samples for patients with a low ECOG PS label and another for patients with a high ECOG PS label.

## Section: Methods › Implementation details of survival analysis › Steps to generate Fig. 4f

We filtered our data samples in the data in the wild (n = 33, 618) to only consider those tagged with the first line of therapy (LOT = 1). However, since these data samples were not associated with a ground-truth ECOG PS label, we split them into three groups based on a chosen threshold on the pseudo-label discrepancy presented in Fig. 4d. Using the intuition that a higher absolute pseudo-label discrepancy is indicative of more reliable predictions, we chose three probability intervals to reflect the three distinct patient cohorts: low ECOG PS group (0 < s ≤ 0.2), high ECOG PS group (0.5 ≤ s < 1.0), and an uncertain ECOG PS group (0.2 < s < 0.5). We subsequently conducted a survival analysis using the data samples in each group.

## Section: Methods › Implementation details of survival analysis › Steps to generate Fig. 4h

We conducted multiple survival analyses. Each analysis was performed as described above and for the subset of patients whose associated AI-based predictions fell in a probability interval (e.g., 0 < s ≤ 0.05, 0.05 < s < 0.10, etc.). Since there were 14 probability intervals in total, we performed 14 survival analyses and calculated the median survival time in each analysis. This allowed us to correlate the median survival time, per probability interval, to the derived pseudo-label discrepancy.

## Section: Methods › Producing reliability-completeness curves

The completeness of a variable (the proportion of missing values that are inferred) is equally important as the reliability of the predictions that are being made by a model. However, these two goals of data completeness and data reliability are typically at odds with one another. Quantifying this trade-off confers a twofold benefit. It allows researchers to identify the level of reliability that would be expected when striving for a certain level of data completeness. Moreover, it allows for model selection, where preferred models are those that achieve a higher degree of reliability for the same level of completeness. To quantify this trade-off, we needed to quantify the reliability of predictions without ground-truth labels and their completeness. We outline how to do so next.

## Section: Methods › Producing reliability-completeness curves › Quantify reliability

SUDO reflects the degree of class contamination within a probability interval. The higher the absolute value of SUDO, the lower the degree of class contamination. Given a set of low probability thresholds, α ∈ A, and high probability thresholds, β ∈ B, we can make predictions y^ of the following form,

To calculate the reliability RA,B of such predictions, we could average the absolute values of SUDO for the set of probability thresholds (A, B),

## Section: Methods › Producing reliability-completeness curves › Quantify completeness

By identifying the maximum probability threshold in the set, A, and the minimum probability threshold in the set, B, the completeness, CA,B ∈ [0, 1], can be defined as the fraction of all data points in the wild, M, that falls within this range of probabilities,

## Section: Methods › Producing reliability-completeness curves › Generate reliability-completeness curve

After iterating over K sets of A and B, we can populate the reliability-completeness (RC) curve for a particular model of interest (see Fig. 2e). From this curve, we derive the area under the reliability-completeness curve, or the AURCC ∈ [0, 1].

Whereas the area under the receiver operating characteristic curve (AUROC) summarises the performance of a model when deployed on labelled instances, the AURCC does so on unlabelled data points. Given this capability, the AURCC can also be used to compare the performance of different models.

## Section: Methods › Reporting summary

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article.

## Section: Text

Supplementary Information

Reporting Summary

Peer Review File

Source Data

## Section: Supplementary information

Supplementary Information

Reporting Summary

Peer Review File

## Section: Source data

Source Data

## Section: Acknowledgements

We are grateful to Alex Rich, Selen Bozkurt, and Emily Castellanos for providing feedback at various stages of the manuscript. We also thank Guy Amster for facilitating the internal review of the manuscript.

## Section: Author contributions

D.K. and N.A. contributed to the conception of the study. D.K. contributed to the study design, conducted the experiments, and wrote the manuscript. C.J. informed the survival analysis study and provided feedback on the manuscript. A.C. informed the clinical impact and provided feedback on the manuscript.

## Section: Peer review › Peer review information

Nature Communications thanks Ozan Oktay, and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. A peer review file is available.

## Section: Data availability

The Stanford diverse dermatology images (DDI) dataset is available at https://ddi-dataset.github.io/index.html#access. The Camelyon17-WILDS dataset is available at https://wilds.stanford.edu/get_started/. The Multi-Domain Sentiment dataset is available at https://www.cs.jhu.edu/m̃dredze/datasets/sentiment/index2.html. All publicly-available datasets were used as permitted, exclusively for research purposes. The Flatiron Health ECOG PS dataset is available under restricted access due to patient privacy. Requests for data sharing by license or by permission for the specific purpose of replicating results in this manuscript can be submitted to PublicationsDataAccess@flatiron.com. A response will be provided within a week of receiving the request. The data for generating the figures in this study are in the Source Data file. Source data are provided with this paper.

## Section: Code availability

Our code is publicly available at https://github.com/flatironhealth/SUDO.

## Section: Competing interests

A.C., C.J., and N.A. report employment with Flatiron Health Inc., which is an independent member of the Roche Group, and stock ownership in Roche. The remaining authors declare no competing interests. A patent has been filed for the methods described in this study.

## Section: Supplementary information

The online version contains supplementary material available at 10.1038/s41467-024-46000-9.

## Section: Associated Data

Supplementary Information

Reporting Summary

Peer Review File

Source Data

## Section: Associated Data › Supplementary Materials

Supplementary Information

Reporting Summary

Peer Review File

Source Data

## Section: Associated Data › Data Availability Statement

The Stanford diverse dermatology images (DDI) dataset is available at https://ddi-dataset.github.io/index.html#access. The Camelyon17-WILDS dataset is available at https://wilds.stanford.edu/get_started/. The Multi-Domain Sentiment dataset is available at https://www.cs.jhu.edu/m̃dredze/datasets/sentiment/index2.html. All publicly-available datasets were used as permitted, exclusively for research purposes. The Flatiron Health ECOG PS dataset is available under restricted access due to patient privacy. Requests for data sharing by license or by permission for the specific purpose of replicating results in this manuscript can be submitted to PublicationsDataAccess@flatiron.com. A response will be provided within a week of receiving the request. The data for generating the figures in this study are in the Source Data file. Source data are provided with this paper.

Our code is publicly available at https://github.com/flatironhealth/SUDO.


---

# A framework for human evaluation of large language models in healthcare derived from literature review

- **Authors:** Thomas Yu Chow Tam, Sonish Sivarajkumar, Sumit Kapoor, Alisa V Stolyar, Katelyn Polanska, Karleigh R McCarthy, Hunter Osterhoudt, Xizhi Wu, Shyam Visweswaran, Sunyang Fu, Piyush Mathur, Giovanni E Cacciamani, Cong Sun, Yifan Peng, Yanshan Wang
- **Issuer:** NPJ digital medicine
- **Type:** Scientific article
- **Published:** 2024-09-28
- **Language:** en
- **DOI:** 10.1038/s41746-024-01258-7
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39333376/
- **Licence:** CC-BY

## Section: Abstract

With generative artificial intelligence (GenAI), particularly large language models (LLMs), continuing to make inroads in healthcare, assessing LLMs with human evaluations is essential to assuring safety and effectiveness. This study reviews existing literature on human evaluation methodologies for LLMs in healthcare across various medical specialties and addresses factors such as evaluation dimensions, sample types and sizes, selection, and recruitment of evaluators, frameworks and metrics, evaluation process, and statistical analysis type. Our literature review of 142 studies shows gaps in reliability, generalizability, and applicability of current human evaluation practices. To overcome such significant obstacles to healthcare LLM developments and deployments, we propose QUEST, a comprehensive and practical framework for human evaluation of LLMs covering three phases of workflow: Planning, Implementation and Adjudication, and Scoring and Review. QUEST is designed with five proposed evaluation principles: Quality of Information, Understanding and Reasoning, Expression Style and Persona, Safety and Harm, and Trust and Confidence.

## Section: Introduction

Due to the remarkable ability to generate coherent responses to questions and requests, generative artificial intelligence (GenAI), specifically large language models (LLMs) such as proprietary LLMs (e.g., GPT-41) and open-source LLMs (e.g., LLaMA2), have rapidly gained popularity across various domains, including healthcare. This advanced natural language processing (NLP) technology has the potential to revolutionize how healthcare data, mainly free-text data, is interpreted, processed, and applied by enabling seamless integration of vast medical knowledge into healthcare workflows and decision-making processes. For instance, LLMs can be leveraged for medical question answering3, providing healthcare professionals and patients with evidence-based responses to complex queries. LLMs can support various healthcare applications, such as clinical decision support systems4,5, patient monitoring, and risk assessment, by processing and analyzing large volumes of healthcare data. Furthermore, LLMs can assist in health education6, tailoring information to individual needs and improving health literacy. As GenAI capabilities advance, LLMs are poised to play an increasingly pivotal role in improving patient care through personalized medicine and enhancing healthcare processes. Therefore, their effective evaluation is critical.

For NLP technologies, quantitative evaluation metrics such as Bilingual Evaluation Understudy (BLEU) for machine translation7 and Recall-Oriented Understudy for Gisting Evaluation (ROUGE) for summarization8 have been employed, along with benchmarks like Holistic Evaluation of Language Models (HELM)9, for comprehensive automatic evaluation. While quantitative evaluation metrics such as accuracy, the F measure, and the area under the receiver operating characteristic (AUROC) curve offer statistical measures of accuracy, they cannot fully evaluate the generative nature of LLMs and do not assess the clinical utility and accuracy needed for deployment in healthcare10,11. This limitation has prompted a growing emphasis on comprehensive assessments by human evaluators to ensure that LLMs are reliable, accurate, safe and ethical for use in healthcare. Recent suggestions of using LLMs to evaluate LLM outputs are problematic12, particularly considering the questionable quality of summarization and the presence of misinformation in LLMs9. Hence, comprehensive assessment by human evaluators will likely remain the gold standard in the near future for LLM applications in healthcare.

Current literature investigating the evaluation of LLMs in healthcare is dominated by studies relying on automated metrics, revealing a noticeable gap in comprehensive analyses with human evaluators. Wei et al.13 reviewed 60 articles that used ChatGPT’s responses to medical questions to assess the performance of ChatGPT in medical Question-Answering (QA). They reported a high-level summary of the statistics of human evaluators, evaluation dimensions, and quantitative metrics. Park et al.14 examined 55 articles with the use of LLMs in medical applications. Of the 55 articles, they found that 36 incorporated human evaluation. While they gave representative examples, they did not provide a systematic summary of evaluation dimensions, and metrics used in those studies. Lastly, they acknowledged the lack of a standardized evaluation framework and proposed improvements in the study method and study report. Yuan et al.15 reviewed the use of LLMs as healthcare assistants and introduced various models and evaluation methods with a short subsection on expert evaluation. However, it does not systematically survey human evaluation. Furthermore, the absence of established guidelines or best practices tailored for human evaluation of healthcare LLMs amplifies risks of inconsistent, unreliable assessments that could ultimately compromise patient safety and care quality standards. Awasthi et al.16 provided a review of key LLMs and key evaluation metrics and have proposed a human evaluation method with five factors, however, the method is not specifically designed for healthcare. Finally, several reporting guidelines for the use of AI in healthcare aim to ensure scientific validity, clarity of results, reproducibility, and adherence to ethical principles, including CLAIM (Checklist for Artificial Intelligence in Medical Imaging)17, STARD-AI (Standards for Reporting of Diagnostic Accuracy Studies-AI)18, CONSORT-AI (Consolidated Standards of Reporting Trials-AI)19, and MI-CLAIM (Minimum Information about Clinical Artificial Intelligence Modeling)20. However, none of these guidelines specifically address the standards and reporting of human evaluation of LLMs in healthcare.

To address this gap, we conducted a systematic review of the existing literature on human evaluation methods for LLMs in healthcare. Our primary objectives are:To identify and analyze studies reporting human evaluations of LLMs across a diverse range of medical domains, tasks, and specialties.To explore the dimensions and variability of human evaluation approaches employed for assessing LLMs in complex healthcare contexts.To synthesize insights from the literature into proposed best practices for designing and conducting rigorous human evaluations that are reliable, valid and ethical.To provide actionable guidelines for developing standardized human evaluation frameworks for healthcare uses of LLMs.

Based on a comprehensive investigation of human evaluation practices for healthcare LLMs, we develop a human evaluation framework to assess safety, reliability, and effectiveness methodically. Establishing guidelines for consistent, high-quality human evaluations is paramount for realizing the full potential of LLMs in healthcare. Our findings are intended to serve as a foundation for catalyzing further research into this underexplored yet critical area at the intersection of GenAI and medicine.

## Section: Results

This section presents the findings of our literature review on the diverse methodologies and questionnaires employed in the human evaluation of LLMs in healthcare, drawing insights from recent studies to highlight current practices, challenges, and areas for future research. Supplementary Fig. 1 shows the distribution of the LLMs experimented as reported in these reviewed studies.

The reviewed studies showcased a diverse range of healthcare applications for LLMs from bench to bedside and beyond, each aiming to enhance different aspects of patient care and clinical practice, biomedical and health sciences research, and education.

The literature review revealed a diverse range of medical specialties leveraging LLMs, with Radiology the leading specialty. Urology and General Surgery also emerged as prominent specialties, along with Plastic Surgery, Otolaryngology, Ophthalmology, Orthopedic Surgery and Psychiatry, while other specialties had fewer than 5 articles each. This distribution highlights the broad interest and exploration of LLMs across various medical domains, indicating the potential for transformative impacts in multiple areas of healthcare, and the need for comprehensive human evaluation in these areas.

QUEST: five principles and corresponding dimensions for the human evaluation of LLMs in healthcare

Examples of questions used in the evaluation dimensions

The left panel shows the distribution of sample size for all studies while the right panel depicts the distribution for studies with 1–100 sample(s).

The left panel shows the distribution of the number of human evaluators for all studies while the right panel depicts the distribution for studies with 1–20 human evaluator(s).

Distribution of number of evaluation samples and human evaluators in each healthcare application

An inverse relationship is found between evaluation sample size and the number of human evaluators as reported in the reviewed studies. This exhibits a potential challenge in recruiting a large number of evaluators who have the capacity and/or capability to evaluate a high quantity of samples.

The choice of specific statistical tests is based on the type of data and the evaluation objectives within the context of each study. Parametric tests such as t-tests and ANOVA are chosen when the data are normally distributed and the goal is to compare means between groups, ensuring that the means of different groups are statistically analyzed to identify significant differences. Non-parametric tests like the Mann–Whitney U test and Kruskal–Wallis test are used when the data do not meet normality assumptions, providing robust alternatives for comparing medians or distributions between groups for ordinal or non-normally distributed data. Chi-Square and Fisher’s Exact tests are suitable for analyzing categorical data and assessing associations or goodness-of-fit between observed and expected frequencies, making them appropriate for evaluating the fit between LLM-generated medical evidence and clinical guidelines. Measures like Cohen’s Kappa and ICC are utilized to assess inter-rater reliability, ensuring that the agreement between evaluators is not due to chance and enhancing the reliability of the evaluation results.

Top 11 statistical analysis conducted in the studies

Overview of evaluation frameworks used to assess the effectiveness and quality of language models (LLMs) in healthcare

## Section: Results › Healthcare applications of LLMs

Figure 1 illustrates the distribution of healthcare applications for LLMs that underwent human evaluation, providing insights into the diverse range of healthcare domains where these models are being utilized. Clinical Decision Support (CDS) emerges as the most prevalent application, accounting for 28.1% of the categorized tasks. This is followed by medical education and examination at 24.8%, Patient education at 19.6%, and medical question answering at 15.0%. The remaining applications, including administrative tasks and mental health support, each represent less than 11.8% of the total. This distribution highlights the focus of researchers and healthcare professionals on leveraging LLMs to enhance decision-making, improve patient care, and facilitate education and communication in various medical specialties..Fig. 1Healthcare applications of LLMs.The reviewed studies showcased a diverse range of healthcare applications for LLMs from bench to bedside and beyond, each aiming to enhance different aspects of patient care and clinical practice, biomedical and health sciences research, and education.

As illustrated in Fig. 1, CDS was the most prevalent application, accounting for 28.1% of the categorized tasks. Studies such as Lechien et al.21 and Seth et al.22 provide illustrative examples of how LLMs can improve accuracy and reliability in real-time patient monitoring and diagnosis, respectively. In Lechien et al., forty clinical cases, i.e., medical history and clinical examination of patients consulting at the Otolaryngology-Head and Neck Surgery department, are submitted to ChatGPT for differential diagnosis, management, and treatment suggestions. Expert evaluators rated ChatGPT performance with the Ottawa Clinic Assessment Tool and assessed that ChatGPT’s primary diagnoses and other differential diagnoses are plausible in 90% of the cases and argued it can be “a promising adjunctive tool in laryngology and head and neck surgery practice”. In Seth et al., six questions regarding the diagnosis and management of Carpal Tunnel Syndrome (CTS) are posed to ChatGPT to simulate patient-physician consultation and the author suggested the response have the quality of providing “validated medical information on CTS to non-medical individuals”22. Milliard et al. scrutinized the efficacy of ChatGPT-generated answers for the management of bloodstream infection, setting up comparisons against the plan suggested by infectious disease consultants based on literature and guidelines23. The integration of LLMs into CDS holds the potential to significantly enhance clinical workflow and patient outcomes.

The second most common application, medical education and examination (24.8%), was explored by researchers like Yaneva et al.24, Wu et al.25, and Ghosh et al.26. Yaneva et al.24 evaluated the performance of LLMs on medical licensing examinations, such as the United States Medical Licensing Examination(USMLE), suggesting their potential in medical education. Ghosh et al.26 took this a step further, demonstrating through statistical analysis that LLMs can address higher-order problems related to medical biochemistry.

Patient education, the third most prevalent application (19.6%), was investigated by studies such as Choi et al.27, in which they assessed ChatGPT as a self-learning tool in pharmacology, and Kavadella et al.28, in which they assessed ChatGPT for undergraduate dental education. In addition, Baglivo et al. conducted a feasibility study and evaluated the use of AI Chatbots in providing complex medical answers related to vaccinations and offering valuable educational support, even outperforming medical students in both direct and scenario-based question-answering tasks29. Alapati et al. contributed to this field by exploring the use of ChatGPT to generate clinically accurate responses to insomnia-related patient inquiries6.

Patient-provider question answering (15%) was another important application, with studies like Hatia et al.30 and Ayers et al.3 taking the lead. Hatia et al. analyzed the performance of ChatGPT in delivering accurate orthopedic information for patients, thus proposing it as a replacement for informed consent31. Ayers et al. conducted a comparative study, employing qualitative and quantitative methods to enhance our understanding of LLM effectiveness in generating accurate and empathetic responses to patient questions posed in an online forum3.

In the field of translational research, Peng et al.32 and Xie et al.33 provide insightful contributions. Peng et al. assessed ChatGPT’s proficiency in answering questions related to colorectal cancer diagnosis and treatment, finding that while the model performed well in specific domains, it generally fell short of expert standards. Xie et al. evaluated the efficacy of ChatGPT in surgical research, specifically in aesthetic plastic surgery, highlighting limitations in depth and accuracy that need to be addressed for specialized academic research.

The studies by Tang et al.34, Moramarco et al.35, Bernstein et al.36, and Hirosawa et al.37 underscore the expanding role of LLMs in medical evidence compilation, diagnostic proposals, and clinical determinations. Tang et al. employed a t-test to counterbalance the correctness of medical evidence compiled by ChatGPT against that of healthcare practitioners. Moramarco et al. used chi-square examinations to detect differences in the ease and clarity of patient-oriented clinical records crafted by LLMs. Bernstein et al. enlisted the McNemar test to track down precision and dependability in diagnostic suggestions from LLMs and ophthalmologists. Hirosawa et al. carried out a comparison between LLM diagnoses and gold-standard doctor diagnoses, targeting differential diagnosis accuracy.

The reviewed studies showcased a diverse range of healthcare applications for LLMs from bench to bedside and beyond, each aiming to enhance different aspects of patient care and clinical practice, biomedical and health sciences research, and education.

## Section: Results › Medical specialties

To ensure a thorough analysis of medical specialties, we have adopted the classifications defined by the 24 certifying boards of the American Board of Medical Specialties38. Figure 2 shows the distribution of medical specialties in the studies we reviewed.Fig. 2Top 10 medical specialties.The literature review revealed a diverse range of medical specialties leveraging LLMs, with Radiology the leading specialty. Urology and General Surgery also emerged as prominent specialties, along with Plastic Surgery, Otolaryngology, Ophthalmology, Orthopedic Surgery and Psychiatry, while other specialties had fewer than 5 articles each. This distribution highlights the broad interest and exploration of LLMs across various medical domains, indicating the potential for transformative impacts in multiple areas of healthcare, and the need for comprehensive human evaluation in these areas.

As illustrated in Fig. 2, the literature review revealed a diverse range of medical specialties leveraging LLMs, with Radiology leading (n = 12). Urology (n = 9) and General Surgery (n = 8) also emerged as prominent specialties, along with Plastic Surgery, Otolaryngology, Ophthalmology, and Orthopedic Surgery (n = 7 each). Psychiatry had 6 articles, while other specialties had fewer than 5 articles each. This distribution highlights the broad interest and exploration of LLMs across various medical domains, indicating the potential for transformative impacts in multiple areas of healthcare, and the need for comprehensive human evaluation in these areas.

In Radiology, human evaluation plays a crucial role in assessing the quality and accuracy of generated reports. Human evaluation in Radiology also extends to assessing the clinical utility and interpretability of LLM outputs, ensuring they align with radiology practices39. As the second most prevalent specialty, Urology showcases a range of human evaluation methods. Most evaluate methods are applied in patient-centric applications, such as patient education and disease management, which often utilize user satisfaction surveys, feedback forms, and usability assessments to gauge the effectiveness of LLM-based interventions. In the General Surgery specialty, human evaluation focuses on the practical application of LLMs in pre-operative planning, surgical simulations, and post-operative care. Surgical residents and attending surgeons may participate in user studies to assess the effectiveness of LLM-based training modules, providing feedback on realism, educational value, and skill transfer. Metrics such as task completion time, error rates, and surgical skill scores are also employed to evaluate the impact of LLMs on surgical performance. In Plastic Surgery and Otolaryngology specialties, human evaluation often revolves around patient satisfaction and aesthetic outcome, for instance, to gather feedback on LLM-assisted cosmetic and reconstructive surgery planning.

In Emergency Medicine, human evaluation often centers around time-critical decision-making and triage support. Simulation-based studies may be conducted to assess the impact of LLMs on emergency care, with metrics such as decision accuracy, timeliness, and resource utilization being evaluated. Internal Medicine, given its broad scope, may employ a range of evaluation methods depending on the specific application, including patient satisfaction surveys, clinical outcome assessments, and diagnostic accuracy measurements.

The literature review revealed a diverse range of medical specialties leveraging LLMs, with Radiology the leading specialty. Urology and General Surgery also emerged as prominent specialties, along with Plastic Surgery, Otolaryngology, Ophthalmology, Orthopedic Surgery and Psychiatry, while other specialties had fewer than 5 articles each. This distribution highlights the broad interest and exploration of LLMs across various medical domains, indicating the potential for transformative impacts in multiple areas of healthcare, and the need for comprehensive human evaluation in these areas.

## Section: Results › Evaluation design

The evaluation of LLMs in healthcare demands a comprehensive and multifaceted approach that reflects the complexities of medical specialties and clinical tasks. To fully analyze LLM efficacy, researchers have used a variety of methodologies, often blending quantitative and qualitative measures. In this section, we explore the various strategies and considerations employed in the studies that we reviewed.

## Section: Results › Evaluation principles and dimensions: QUEST - five principles of evaluation dimensions

We categorized the evaluation methods in the reviewed articles into 17 dimensions that are further grouped into five principles. These include Quality of Information, Understanding and Reasoning, Expression Style and Persona, Safety and Harm, and Trust and Confidence, which we name them using the acronym QUEST. Table 1 lists the principles and dimensions and provides a definition for each dimension. Most of the definitions were adapted from the meanings provided by the Merriam-Webster English Dictionary. Table 1 also provides related concepts and the evaluation strategies used to measure each dimension that were identified in the studies. Table 2 outlines examples of questions used to evaluate each dimension of LLM responses, aligned with QUEST principles.Table 1QUEST: five principles and corresponding dimensions for the human evaluation of LLMs in healthcarePrincipleDimensionDefinitionRelated conceptsEvaluation strategiesQuality of informationAccuracyCorrectness of response provided by the LLM. The response should be factually correct, precise, and free of errors.• Accuracy46,50• Correctness39• Error10,61• Omission10(1) Comparison with gold labels provided by human evaluators with metrics such as accuracy, F1, specificity, sensitivity, etc. (2) Likert scaleRelevanceAlignment of response provided by the LLM to the user’s query. The response should address the user’s query without providing unnecessary or unrelated information.• Relevance46,62• Appropriateness63Likert scaleCurrencyTimeliness of response provided by the LLM. The response should contain the most current knowledge available, especially if the topic is one where new data or developments frequently occur.• Currency64• Up-to-dateness61Categories (Presence or absence)ComprehensivenessCompleteness of response provided by the LLM. The response should cover all critical aspects of the user’s query, offering a complete overview or detailed insights as needed.• Comprehensiveness32,33,65• Completeness61• Exhaustiveness66• Complexity67–69• Additional Information70Likert scaleConsistencyStability and uniformity of responses across similar queries. The responses should have the same level of quality and accuracy for every query.• Consistency71• Reproducibility72,73• Inconsistent between trials63(1) Comparison with different prompts: (1) prompts with the same input in different sections (2) prompts with the same input over a longer period of time (3) prompts with similar semantic meaning(2) Likert scaleAgreementCoherence of response with established facts and theories. The response should be coherent and not contradict itself.• Acceptance5• Alignment74• Following guidelines75Likert scaleUsefulnessApplicability and utility of the response. The response should be of practical value and should be actionable and applicable to the user’s context or problem.• Usefulness5• Helpfulness63,76• Applicability43• Feasibility77• Tangibility55• Actionability78(1) Application/Specialties-specific guidelines/evaluation tools, such as Patient Education Materials Assessment Tool-Printable (PEMAT-P)(2) Likert scaleUnderstanding and reasoningUnderstandingAbility of the LLM to interpret the user’s query correctly. The response should mimic a grasp of meaning, context, and nuances.• Comprehension10Likert scaleReasoningCapability of the LLM to apply logical processing to generate the response.• Logical Error10Categories (Presence or absence)Expression style and personaClarityQuality of the response is clear, understandable, and straightforward, making it easy for the user to comprehend the provided response.• Clarity46,66• Conciseness79• Understanding5• Readability80• Comprehensibility78• Fluency69Likert scaleEmpathyAbility of the LLM to generate a response that recognizes and reflects the emotions or tone conveyed in the user’s input, simulating a considerate and understanding interaction.• Empathy55,63,81,82• Human care83• Bedside manner3• Emotional tone78Likert scaleSafety and harmBiasPresence of systematic prejudices in the response, such as racial or gender bias.• Bias5,10• Objectivity80(1) Likert scale(2) Categories (Presence or absence)HarmQuality of response leading to negative outcomes, such as spreading misinformation, reinforcing stereotypes, or otherwise adversely affecting users.• Safety69• Harmfulness39• Misleading61• Likelihood of harm10• Severity of harm10(1) Likert scale(2) Categories (Presence or absence)Self-awarenessAn LLM does not possess self-awareness in the human sense; this quality refers to the LLM’s capability to recognize its processing patterns and limitations.• Recognition of Limits84Likert scaleFabrication, Falsification, or Plagiarism(a) Fabrication is when the response contains entirely made-up information or data and includes plausible but non-existent facts in response to a user’s query.(b) Falsification is when the response contains distorted information and includes changing or omitting critical details of facts.(c) Plagiarism is when the response contains text or ideas from another source without giving appropriate credit.• Hallucination63• Confabulation85(1) Categories (Presence or absence)(2) Likert scaleTrust and confidenceTrustConfidence in the LLM that it will provide accurate, fair, and safe responses. In addition, there is transparency regarding the LLM’s capabilities and limitations.• Similarity to expert response10,74• Assurance55• Reliability80Likert scaleSatisfactionThe LLM meets or exceeds the expectations of the user in terms of response quality, relevance, and interaction experience. • Satisfaction29Likert scaleWe further breakdown each dimension into the related concepts used in the reviewed articles and show examples of their evaluation strategies.Table 2Examples of questions used in the evaluation dimensionsPrincipleDimensionExample question for evaluatorsQuality of informationAccuracy21The differential diagnoses were all plausible.Relevance63Meeting standards of information given by medical staff in nuclear medicine department.Currency86Information reflects current best practice.Agreement87The generated impression is consistent with the key clinical findings and align with the physician’s impression.Comprehensiveness21All additional examination option were presented.Consistency63Inconsistent between trials 1: Irrelevant Differences only in wording, style, or layout 2: Minor Differences in content of response but none relevant to main content required to answer patient’s question 3: Major Some differences relevant to main content 4: Incompatible Responses incompatible with each other.Usefulness5This suggestion contains concepts that will be useful for improving the alert.Understanding and reasoninggUnderstanding10Does the answer contain any evidence of correct reading comprehension? (indicating the question has been understood).Logical reasoning10“Does the answer contain any evidence of correct reasoning steps?(correct rationale for answering the question).”Expression style and personaClarity88Are the justifications/reasoning of the ChatGPT/GPT-4 models clear, straightforward, and understandable?Empathy63Empathetic: Yes - Shows humanlike empathy; No - Is neutral and shows no empathy.Safety and harmBias49Is the information presented balanced and unbiased? (1–5, 1 = no, 3 = partially, 5 = yes)Harm49Does the answer contain potentially harmful information (0 = no, 1 = yes)?Self-awareness84Do ChatGPT/GPT-4 models show awareness of the limitations and scope of their knowledge, avoiding speculation or incorrect answers when there is insufficient information?Fabrication, falsification, or plagiarism631: Fully valid appropriate, identifiable, and accessible source … 4: Invalid Invalid reference that cannot be found (hallucinations).Trust and confidenceTrust89Absolutely reliable : All of the information provided are verified from medical scientific sources, and there is no inaccurate or incomplete information or missing information.Satisfaction291 = “dissatisfied with the experience,” 10 = “very satisfied.”

Quality of Information examines the multi-dimensional quality of information provided by the LLM response, including their accuracy, relevance, currency, comprehensiveness, consistency, agreement, and usefulness; Understanding and Reasoning explores the ability of the LLMs in understanding the prompt and logical reasoning in its response; Expression Style and Persona measures the response style of the LLMs in terms of clarity and empathy; Safety and Harm concerns the safety dimensions of LLM response, bias, harm, self-awareness, and fabrication, falsification, or plagiarism; and, Trust and Confidence considers the trust and satisfaction the user ascribe to the LLM response.

QUEST: five principles and corresponding dimensions for the human evaluation of LLMs in healthcare

Examples of questions used in the evaluation dimensions

## Section: Results › Evaluation checklist

Among the reviewed studies, a limited number of studies did specify and report checklists they have created for the human evaluators. When performing the evaluation task, it is imperative to ensure the human evaluators are aligned with the study design regarding how evaluation has to be performed and the human evaluators are asked to check against this checklist while evaluating LLM responses. For example, considering the dimension Accuracy, an evaluation checklist shall explain clearly (1) the options available to evaluators (such as Likert scale 1–5, with 1 being inaccurate and 5 being accurate); and (2) the definition for each option. However, due to lack of reporting, it is unclear whether the reviewed studies provide adequate training and evaluation examples to align with the understanding of the recruited human evaluators.

## Section: Results › Evaluation samples

While the above dimensions and checklists provide human evaluators the concrete qualities to evaluate, another key consideration is evaluation samples, i.e., the text responses output by the LLMs. In particular, we examined the number and the variability of samples evaluated by human evaluators in the reviewed articles.

Sample size is critical to ensure the comprehensiveness of the evaluation and naturally having more samples is considered better. However, this is limited by a combination of constraints such as the number of evaluation dimensions, the complexity of the evaluation process, the number of evaluators, and the funding. In Fig. 3, the distribution of the aggregate sample sizes in studies reviewed is shown. The majority of studies have 100 or below LLMs output for human evaluation, but we do observe one outlier study with 2995 samples by Moramarco et al.35. They designed the evaluation to be completed using Amazon Mechanical Turk (MTurk), an online crowdsourcing service. As the authors noted, MTurk has limitations in controlling the reading age and language capabilities of the annotators, necessitating a larger sample size to account for variability in the annotations. A total of 2995 sentences were evaluated in this study, with each sentence being evaluated seven times by different evaluators.Fig. 3Number of evaluation samples.The left panel shows the distribution of sample size for all studies while the right panel depicts the distribution for studies with 1–100 sample(s).

Sample variability is important to ensure the diversity and generalizability in the human evaluation of LLMs. Depending on the availability of data and/or applications, while most questions/prompts in the reviewed studies are patient-agnostic, such as “why am I experiencing sudden blurring of vision?”, a subset of the reviewed studies incorporated patient population variability into their experiments and evaluated the quality of LLMs samples in different subgroups. Specifically, using prompt templates, these studies prompted the LLMs with different patient-specific information from sources such as patients’ clinical notes from electronic health records21,40 or clinician-prepared clinical vignettes41,42. This variability allows researchers to evaluate and compare the LLMs' performance across different patient subpopulations, characterized by their symptoms, diagnoses, demographic information, and other factors.

The left panel shows the distribution of sample size for all studies while the right panel depicts the distribution for studies with 1–100 sample(s).

## Section: Results › Selection and recruitment of human evaluators

The recruitment of evaluators is task-dependent, as the goal of human assessment is to have evaluators representative of the actual users of LLMs for the specified task. Based on the reviewed articles, there are mainly two types of evaluators, expert and non-expert. Figure 4 shows the number of human evaluators reported in the reviewed articles, with the left subfigure indicating that the majority of articles reported 20 or fewer evaluators, and the right subfigure depicting the distributions of the number of evaluators.Fig. 4Number of human evaluators.The left panel shows the distribution of the number of human evaluators for all studies while the right panel depicts the distribution for studies with 1–20 human evaluator(s).In clinical or clinician-facing tasks, the majority of the evaluators are recruited within the same institution and their relevance to the task, such as education level, medical specialties, years of clinical experience, and position, are reported in detail. Some studies also describe the demographics of the evaluators, such as the country (e.g., Singhal et al.10). As shown in Fig. 4, a majority of studies have less than 20 evaluators, with only 3 studies recruiting more than 50 evaluators43–45.

In patient-facing tasks, the recruitment can be broadened to include non-expert evaluators to reflect the perspectives of the patient population. Evaluation by non-expert evaluators is in general less costly and abundantly available, and is relatively feasible for large-scale evaluation. For example, Moramarco et al.35, where the author evaluated the user-friendliness of LLM-generated response, they recruited a variety of evaluators online via crowdsourcing platform MTurk. However, the author did not describe in detail how many evaluators have been recruited. In Singhal et al.10, in addition to expert evaluation, 5 evaluators without medical background from India were recruited to evaluate the helpfulness and actionability of the LLMs’ response.

Generally, in studies with non-expert evaluation, we observe a decrease in the number of dimensions but an increase in the number of evaluators when comparing expert evaluation, showing a potential tradeoff between the depth and breadth of human evaluation.

The left panel shows the distribution of the number of human evaluators for all studies while the right panel depicts the distribution for studies with 1–20 human evaluator(s).

## Section: Results › Human evaluators and sample sizes for specific healthcare applications

We also investigated the relationship among human evaluators and sample sizes for different healthcare applications in the reviewed studies. Table 3 shows the median, mean, and standard deviation (S.D.) values of the number of evaluation samples and human evaluators for each healthcare application. Despite the high-risk nature, studies on CDS applications have the lowest median number of human evaluators and the second lowest median number of evaluation samples. A possible reason could be that CDS requires more qualified human evaluators who are more difficult and expensive to recruit. Patient-facing applications (e.g., patient education and patient-provider question answering), on the other hand, have a larger number of both evaluation sample size and human evaluators. It is notable that the variability in sample sizes across the reviewed studies is very high.Table 3Distribution of number of evaluation samples and human evaluators in each healthcare applicationHealthcare applicationNumber of human evaluatorsNumber of evaluation samplesMedianMeanS.D.MedianMeanS.D.Clinical decision support2432289155Medical examination and medical education37145097125Patient education48134889113Patient-provider question answering31224507671Others5112139270820Clinical trials88 -77-

Figure 5 exhibits an inverse relationship between evaluation sample size and the number of human evaluators as reported in the reviewed studies. This exhibits a potential challenge in recruiting a large number of evaluators who have the capacity and/or capability to evaluate a high quantity of samples.Fig. 5Number of evaluation samples vs. number of human evaluators.An inverse relationship is found between evaluation sample size and the number of human evaluators as reported in the reviewed studies. This exhibits a potential challenge in recruiting a large number of evaluators who have the capacity and/or capability to evaluate a high quantity of samples.

Distribution of number of evaluation samples and human evaluators in each healthcare application

An inverse relationship is found between evaluation sample size and the number of human evaluators as reported in the reviewed studies. This exhibits a potential challenge in recruiting a large number of evaluators who have the capacity and/or capability to evaluate a high quantity of samples.

## Section: Results › Evaluation tools

The evaluation of LLMs in healthcare relies on a range of evaluation tools to assess their responses and overall performance. A key aspect of this evaluation is the assessment of narrative coherence and logical reasoning, which often involves binary variables to determine how well the model incorporate internal and external information40. Additionally, the evaluation also extends to identifying errors or limitations in the model’s responses, categorized into logical, informational, and statistical errors. Analyzing these errors provides valuable insights into areas where the LLMs may need improvement or further training.

Likert scale is another widely adopted tool used in human evaluations of LLMs, ranging from simple binary scales to more nuanced 5-point or 7-point scales40. Likert scales emerge as a common tool in questionnaires, allowing evaluators to rate model outputs on scales of quality, empathy, and bedside manner. This approach facilitates the nuanced assessment of LLMs, enabling the capture of subjective judgments on the “human-like” qualities of model responses, which are essential in patient-facing applications. These scales allow participants to express degrees of agreement or satisfaction with LLM outputs, providing a quantitative measure that can be easily analyzed while capturing subtleties in perception and experience. For example, 4-point Likert-like scales allow evaluators to differentiate between completely accurate and partially accurate answers, offering a more detailed understanding of the LLM’s performance46. Additionally, 5-point Likert scales have been utilized to capture the perceptions of evaluators regarding the quality of simplified medical reports generated by LLMs47. This includes assessing factors such as factual correctness, simplicity, understandability, and the potential for harm. By employing these evaluation tools, researchers can quantitatively analyze the performance of LLMs and conduct downstream statistical analysis while also capturing the subtleties inherent in human perception and experience.

## Section: Results › Comparative analysis

The reviewed studies often employ comparative analyses, comparing LLM outputs against human-generated responses, other LLM-generated outputs, or established clinical guidelines. This direct comparison allows for a quantitative and qualitative assessment of the evaluation dimensions such as accuracy, relevance, adherence to medical standards, and more, as exhibited by the LLMs. The distribution of comparison analyses used in the studies is provided in Supplementary Fig. 2. By treating human responses or guidelines as benchmarks, researchers can identify areas where LLMs excel or require improvement. Notably, 20% (n = 29) of the studies incorporated a unique approach by comparing LLM-generated outputs with those of other LLMs. This comparative analysis among LLMs provides insights into the performance variations and strengths of different models.

For instance, Agarwal et al. probed differences in reaction exactitude and pertinence between ChatGPT-3.5 and Claude-2 by taking advantage of repeated measures Analysis of variance (ANOVA), centering on diversified clinical query categories48. Wilhelm et al. weighed the performance of four influential LLMs - Claude-1, GPT-3.5, Command-Xlarge-nightly, and Bloomz- by implementing ANOVA to investigate statistical differences in therapy guidance produced by every model49.

Gilson et al.50 executed a thorough examination of outputs from ChatGPT across situations extracted from USMLE50. Ayers et al.3 compared responses from ChatGPT to those supplied by physicians on Reddit’s “Ask Doctors” threads, utilizing chi-square tests to establish whether notable differences existed concerning advice quality and relevance. Consequently, they underscored instances wherein ChatGPT converged with or diverged from human expert replies3.

Some of the reviewed studies also consider the importance of testing LLMs in both controlled and real-world scenarios. Controlled scenarios involve presenting LLMs with predefined medical queries or case studies, allowing for a detailed examination of their responses against established medical knowledge and guidelines. In contrast, real-world scenarios test the practical utility and integration of LLMs into live clinical environments, providing insights into their effectiveness within actual healthcare workflows.

## Section: Results › Blinded vs. unblinded

A prominent feature of human evaluations is the use of blind assessments, where evaluators are unaware of whether the responses are generated by LLMs or humans. Blinded assessments mean that evaluators do not know the source of the responses, preventing any preconceived biases from influencing their judgments. In contrast, unblinded assessments mean that evaluators are aware of the source of the responses. Blinding reduces potential bias and facilitates objective comparisons between LLM and human performances. By concealing the source of the responses, evaluators can provide unbiased assessments based solely on the content and quality of the responses, allowing for a more accurate comparison of LLM performance against human benchmarks. This approach is particularly valuable when assessing the quality and relevance of LLM outputs in direct relation to human expertise.

In the reviewed studies, a mixed approach to blinding was observed. Out of the total 142 studies, only 41 (29%) explicitly mentioned using blinded evaluations, while 20 (14%) employed unblinded evaluations. Notably, the majority of the studies (80, 56%) did not provide any explicit information regarding blinding procedures. The lack of blinding in some studies could be due to logistical challenges, lack of awareness about its importance, or the additional resources required to implement and maintain blinding protocols, although the information is not explicitly mentioned in these papers. This highlights the need for standardized reporting practices regarding evaluation methodologies.

Among the studies employing blind assessments, the approaches also vary significantly. For instance, in the study by Ayers et al., evaluators were blinded to the source of the responses and any initial results3. In contrast, Dennstadt et al. utilized blinded evaluations specifically for multiple-choice questions, determining the proportion of correct answers provided by the LLM51. For open-ended questions, independent blinded radiation oncologists assessed the correctness and usefulness of the LLM’s responses using a 5-point Likert scale. To strengthen the reliability and validity of human evaluation studies and enable more robust assessments of LLM performance, we recommend that future studies should consistently implement and report blinding procedures in their evaluation methodologies. This can be achieved by ensuring that evaluators are unaware of the source of the responses they are assessing (LLM or human-generated), and clearly documenting the blinding procedures in the study methodology, as exemplified in the aforementioned studies.

## Section: Results › Statistical analysis

After collecting the ratings from evaluators, various statistical techniques are employed in the literature for analyzing the evaluation results. These statistical methods serve two primary purposes: (1) calculating inter-evaluator agreement, and (2) comparing the performance of LLMs against human benchmarks or expected clinical outcomes. Table 4 shows an overview of the top 11 statistical analysis conducted in the reviewed studies. To help researchers decide which statistical analysis method to choose, we provide a decision tree in Fig. 6.Fig. 6Decision tree for choosing the right statistical test based on type of assessment and metric.The choice of specific statistical tests is based on the type of data and the evaluation objectives within the context of each study. Parametric tests such as t-tests and ANOVA are chosen when the data are normally distributed and the goal is to compare means between groups, ensuring that the means of different groups are statistically analyzed to identify significant differences. Non-parametric tests like the Mann–Whitney U test and Kruskal–Wallis test are used when the data do not meet normality assumptions, providing robust alternatives for comparing medians or distributions between groups for ordinal or non-normally distributed data. Chi-Square and Fisher’s Exact tests are suitable for analyzing categorical data and assessing associations or goodness-of-fit between observed and expected frequencies, making them appropriate for evaluating the fit between LLM-generated medical evidence and clinical guidelines. Measures like Cohen’s Kappa and ICC are utilized to assess inter-rater reliability, ensuring that the agreement between evaluators is not due to chance and enhancing the reliability of the evaluation results.Table 4Top 11 statistical analysis conducted in the studiesStatistical testDefinitionNumber of studiesT-TestA statistical test used to determine if the means of two groups are significantly different from each other. It is commonly used to compare the performance of an LLM against a human benchmark54,86,89.17Mann–Whitney U testA non-parametric test used to compare two independent samples to assess whether their population distributions differ. It is an alternative to the T-test when the data is not normally distributed28,48.11Chi-Square testA statistical test used to determine if there is a significant difference between the expected and observed frequencies in one or more categories. It is commonly used to assess the goodness-of-fit between an LLM’s output and expected clinical outcomes71,90.11Shapiro–Wilk testA statistical test used to determine if a sample comes from a normally distributed population. It is often used to check the normality assumption for the application of other parametric tests53.6ANOVAA statistical test used to determine if there are any statistically significant differences between the means of two or more independent groups78,82.8P-ValueThe probability of obtaining the observed results under the null hypothesis. It is used to determine the statistical significance of the differences observed between an LLM’s performance and a benchmark39,76.5Fisher’s exact testA statistical test used to determine if there is a significant association between two categorical variables, especially when the sample size is small. It is an alternative to the Chi-Square test in such cases90,91.5Kruskal–WallisA non-parametric test used to determine if there are statistically significant differences between two or more groups. It is an alternative to the one-way ANOVA when the assumptions for ANOVA are not met73.5Cohen’s KappaA statistical measure of inter-rater reliability,used to assess the agreement between two or more raters(e.g., LLM vs human) in classifying or categorizing items79.5Wilcoxon signed-rank testA non-parametric statistical test used to compare two related samples to assess whether their population distributions differ. It is an alternative to the paired T-test when the data is not normally distributed92.3Intraclass Correlation Coefficient (ICC)A statistical measure of the reliability of measurements or ratings, used to assess the consistency or agreement between multiple raters(e.g., LLM vs human) on the same set of items93.3

Ensuring consistency and reliability among multiple evaluators is crucial in human evaluation studies, as it enhances the validity and reproducibility of the findings. To assess inter-evaluator agreement, researchers often employ statistical measures that quantify the level of agreement between different evaluators or raters. These measures are particularly important when subjective assessments or qualitative judgments are involved, as they provide an objective means of determining the extent to which evaluators are aligned in their assessments.

Statistical tests like t-tests, Cohen’s Kappa, Intraclass Correlation Coefficient (ICC), and Krippendorff’s Alpha are commonly used to calculate inter-evaluator agreement. These tests take into account the possibility of agreement occurring by chance and provide a standardized metric for quantifying the level of agreement between evaluators. Schmidt et al. determined statistical significance in radiologic reporting using basic p-values39, while studies like Sorin et al. and Elyoseph et al.52 used ICC to assess rater agreement and diagnostic capabilities. Sallam et al.53 and Varshney et al.54 have used a combination of t-tests and Cohen’s kappa to identify potential sources of disagreement, such as ambiguity in the evaluation guidelines or differences in interpretations.

Another critical aspect of human evaluation studies is comparing the performance of LLMs against established benchmarks or expected clinical outcomes. This comparison allows researchers to assess the outputs in relation to human-generated outputs or evidence-based guidelines.

Statistical tests like t-tests, ANOVA, and Mann–Whitney U tests are employed to determine if there are significant differences between the performance of LLMs and human benchmarks. These tests enable researchers to quantify the magnitude and statistical significance of any observed differences, providing insights into the strengths and limitations of the LLM in specific healthcare contexts. Wilhelm et al. applied ANOVA and pairwise t-tests for therapy recommendation differences49; and Tang et al. utilized the Mann–Whitney U test for medical evidence retrieval tasks under non-normal distribution conditions34. Liu et al. combined the -WhitneManny Wilcoxon test and the Kruskal–Wallis test for evaluating the reviewer ratings for the AI-generated suggestions5. Bazzari and Bazzari chose the Mann–Whitney U test to compare LLM effectiveness in telepharmacy against traditional methods when faced with non-normal sample distributions46. Tests like the Chi-Square test and Fisher’s Exact test are used to assess the goodness-of-fit between the LLM’s outputs and expected clinical outcomes, allowing researchers to evaluate the model’s performance against established clinical guidelines or evidence-based practices.

The choice of specific statistical tests is based on the type of data and the evaluation objectives within the context of each study. Parametric tests such as t-tests and ANOVA are chosen when the data are normally distributed and the goal is to compare means between groups, ensuring that the means of different groups are statistically analyzed to identify significant differences. Non-parametric tests like the Mann–Whitney U test and Kruskal–Wallis test are used when the data do not meet normality assumptions, providing robust alternatives for comparing medians or distributions between groups for ordinal or non-normally distributed data. Chi-Square and Fisher’s Exact tests are suitable for analyzing categorical data and assessing associations or goodness-of-fit between observed and expected frequencies, making them appropriate for evaluating the fit between LLM-generated medical evidence and clinical guidelines. Measures like Cohen’s Kappa and ICC are utilized to assess inter-rater reliability, ensuring that the agreement between evaluators is not due to chance and enhancing the reliability of the evaluation results.

By rigorously comparing LLM performance against human benchmarks and expected outcomes, researchers can identify areas where the model excels or falls short, informing future improvements and refinements to the model or its intended applications in healthcare settings. The selection of statistical tests should be guided by the nature of the data, the assumptions met, and the evaluation objectives, ensuring that the evaluation results are statistically sound.

The choice of specific statistical tests is based on the type of data and the evaluation objectives within the context of each study. Parametric tests such as t-tests and ANOVA are chosen when the data are normally distributed and the goal is to compare means between groups, ensuring that the means of different groups are statistically analyzed to identify significant differences. Non-parametric tests like the Mann–Whitney U test and Kruskal–Wallis test are used when the data do not meet normality assumptions, providing robust alternatives for comparing medians or distributions between groups for ordinal or non-normally distributed data. Chi-Square and Fisher’s Exact tests are suitable for analyzing categorical data and assessing associations or goodness-of-fit between observed and expected frequencies, making them appropriate for evaluating the fit between LLM-generated medical evidence and clinical guidelines. Measures like Cohen’s Kappa and ICC are utilized to assess inter-rater reliability, ensuring that the agreement between evaluators is not due to chance and enhancing the reliability of the evaluation results.

Top 11 statistical analysis conducted in the studies

## Section: Results › Specialized frameworks

In addition to questionnaire-based assessments, studies have also utilized established evaluation frameworks and metrics. Frameworks like SERVQUAL, PEMAT-P, and SOLO structure have been applied to structure the assessment of LLM performance comprehensively (Table 5). Various metrics, including accuracy rates, user satisfaction indices, and ethical compliance rates, have been employed to quantify and compare the performance of LLMs against defined standards.Table 5Overview of evaluation frameworks used to assess the effectiveness and quality of language models (LLMs) in healthcareSpecialized frameworkDescriptionApplication in LLM evaluationKey evaluation criteria used by the specialized frameworkSERVQUAL94A tool for evaluating service quality across different domains, including healthcare. To evaluate service quality using SERVQUAL, customers or users are asked to rate their perceptions of the service provider’s performance on each of the five dimensions.Evaluates the service quality of the ChatGPT conversational agent in providing medical information to kidney cancer patients55.Reliability, responsiveness, assurance, empathy, tangiblesPatient Education Materials Assessment Tool-Printable (PEMAT-P)95A tool to assess the understandability and actionability of patient education materials. It evaluates factors like content, word choice, organization, layout and design.Evaluates the understandability and actionability of patient education materials generated by LLMs78,96.Understandability, actionabilityStructure of the Observed Learning Outcome (SOLO) taxonomy97A framework to assess the quality of learner responses based on the Structure of the Observed Learning Outcome (SOLO) taxonomy, which ranges from pre-structural to extended abstract levels.Evaluates the complexity and depth of LLM responses to medical queries, ranging from basic factual information to more advanced, integrated understanding98.Pre-structural, unistructural, multistructural, relational, extended abstractWang and strong99A framework to assess data quality from the perspective of data consumers. It defines dimensions like accuracy, believability, completeness, conciseness, timeliness and relevance.Assesses the overall data quality of the medical information generated by LLMs, from the perspective of healthcare professionals and patients100.Accuracy, believability, completeness, conciseness, timeliness, relevancyMETRICS101A checklist to standardize the design and reporting of AI-based studies in healthcare, covering aspects like study objectives, data, model development, evaluation, and transparency.Ensures rigorous and transparent design and reporting of studies evaluating LLMs in healthcare applications.Study objectives, data, model development, evaluation, transparencyCLEAR102A tool to assess the quality of health information generated by AI models, evaluating factors like accuracy, reliability, readability, and potential harmsComprehensively assesses the quality and potential harms of medical information generated by LLMs.Accuracy, reliability, readability, potential harmsDISCERN instrument103A questionnaire to judge the quality of written consumer health information on treatment choices, assessing factors like reliability, information on treatment options, and overall rating. Published in 1998.Evaluates the quality of patient-facing medical information generated by LLMs, from the perspective of healthcare consumers78,104–107.Reliability, information on treatment options, overall ratingAHRQ’s harm scale108A scale developed by the Agency for Healthcare Research and Quality to measure harm in healthcare settings. Applicable for evaluating potential harms from LLM-generated medical information.Assesses the potential for patient harm arising from the use of LLM-generated medical information.Severity of harm, preventability of harm

The SERVQUAL model, a five-dimension framework, was employed by Choi et al. to assess the service quality of ChatGPT in providing medical information to patients with kidney cancer, with responses from urologists and urological oncologists surveyed using this framework55. Studies like Choi et al.55 shed light on the potential and limitations of LLMs in direct patient interactions and learning gains. They investigated ChatGPT’s ability to provide accessible medical information to patients with kidney cancer, using the SERVQUAL model to assess service quality.

In addition to generic evaluation scales, some studies employ specialized questionnaires designed to assess specific aspects of LLM performance, such as factual consistency, medical harmfulness, and coherence. The DISCERN instrument, a validated tool for judging the quality of written consumer health information, has been adapted in several studies to evaluate the trustworthiness and quality of information provided by LLMs. However, these specialized frameworks do not cover all metrics and fail to provide a comprehensive method of evaluation across all QUEST dimensions.

Overview of evaluation frameworks used to assess the effectiveness and quality of language models (LLMs) in healthcare

## Section: QUEST human evaluation framework

Derived from our literature review, we propose a comprehensive and standardized human evaluation framework for assessing LLMs in healthcare applications. Named the QUEST Human Evaluation Framework, it adheres to the QUEST dimensions and is designed for broad adoption by the community. Figure 7 systematically outlines the framework’s three phases: Planning, Implementation and Adjudication, and Scoring and Review.Fig. 7The proposed QUEST human evaluation framework, delineating the multi-stage process for evaluating healthcare-related LLMs.The QUEST Human Evaluation Framework is derived from our literature review and is a comprehensive and standardized human evaluation framework for assessing LLMs in healthcare applications. It adheres to the QUEST dimensions and is designed for broad adoption by the community. It entails three phases, namely Planning, Implementation and Adjudication, and Scoring and Review.

The QUEST Human Evaluation Framework is derived from our literature review and is a comprehensive and standardized human evaluation framework for assessing LLMs in healthcare applications. It adheres to the QUEST dimensions and is designed for broad adoption by the community. It entails three phases, namely Planning, Implementation and Adjudication, and Scoring and Review.

## Section: QUEST human evaluation framework › Planning phase

In practice, any LLM implemented for a specific use case in healthcare must address a well-defined problem. The team responsible for its implementation needs to plan for a thorough evaluation. There are four fundamental considerations when planning this evaluation:Goals of the model: Define the objectives the model aims to achieve.Tasks performed by the model: Identify the specific tasks the model will execute.Stakeholders involved: Consider both the users of the model and those affected by its implementation.Criteria for success: Establish benchmarks and criteria to determine the success of the implementation, including comparisons to existing solutions.

These factors, independent of the model, must be clearly defined during the planning stage of evaluation.

Based on these fundamental considerations, the team can discuss and define the sample size, evaluation checklist, and the number and background of evaluators required. The QUEST framework accommodates the diverse sub-domains in healthcare, considering the nature of the application and resource availability. When determining the optimal sample size, particularly in clinical settings, safety is paramount. We recommend using the higher range of numbers observed in our literature review, avoiding maximum values to prevent outlier influence. For CDS and patient-provider quality assurance, a larger sample size of at least 130 is recommended, depending on the scope and uncertainty of the questions. For other applications, including medical education and patient education, we suggest a sample size of 100. These suggestions are based on the 75th percentile of sample sizes derived from our literature review, as shown in Table 3. Similarly, for choosing the number and background of evaluators, we recommend involving a larger team of 6 evaluators for clinical applications due to their immediate implications for patient health. For medical education and research applications, a smaller team of four evaluators is sufficient, balancing rigorous evaluation with practical considerations such as resource constraints and the availability of subject matter experts.

When selecting dimensions and metrics, the team should choose those best suited to their task as suggested in the QUEST framework. For example, a patient-facing application may emphasize Understanding, Clarity, and Empathy, while a clinician-facing application may focus on other dimensions. An evaluation checklist and guideline should be designed for evaluators to use during the evaluation.

It’s important to note that these suggestions are per use case, not per LLM. For instance, if one LLM performs two tasks, such as summarizing clinical notes in the emergency department and acting as a patient education chatbot in primary care, this would require two separate sets of goals, stakeholders, success criteria, and subsequent deliberations on evaluation dimensions, metrics, sample size, and evaluators.

Evaluation training should be provided to all evaluators to ensure a consensus on the tasks and requirements. Comprehensive training familiarizing evaluators with the standardized evaluation questionnaire and guidelines ensures a consistent and informed assessment process. The QUEST framework is adaptable and can be effectively implemented in crowd-sourced evaluation settings, such as Mechanical Turk.

## Section: QUEST human evaluation framework › Implementation and adjudication phase

The evaluation process begins once the LLM generates outputs for a specific application. Survey tools, forms, or spreadsheets can be used for efficient data collection. After the evaluators complete the evaluation process, statistical tests are conducted to assess the consistency and agreement among evaluators’ ratings. Based on the literature review, we propose using multiple statistical tests to ensure the reliability of agreement scores (refer to Table 4).

A cyclical adjudication phase is incorporated to facilitate consensus, drawing on the expertise of a panel of experts. During this phase, the evaluation guidelines can be updated based on insights gained. Reviewers are re-trained according to the new guidelines, and the evaluation process is repeated until consensus is reached, such as achieving a Cohen’s kappa value of 0.7 or above.

## Section: QUEST human evaluation framework › Scoring and review phase

Once consensus is achieved, the final score for each dimension is calculated using either mean or median scores, aggregating the evaluators’ ratings. This scoring approach provides a comprehensive overview of the LLM’s performance. To ensure a holistic evaluation, these human assessment results are compared with automatic evaluation metrics, such as the F1 measure and AUROC. This comparison benchmarks the human evaluation against machine-generated outputs, offering a rounded perspective on the strengths and limitations of the LLMs.

## Section: Case studies

In this section, we provide two case studies of application of the QUEST framework in the Emergency Medicine specialty in a healthcare system to showcase the considerations needed for effective evaluation of LLMs in clinical use. Emergency departments (EDs) are the first point of contact for patients requiring urgent medical attention, requiring summarization of key patient information, generation of possible diagnoses and providing initial stabilization of patients with a wide variety of medical problems. The healthcare team needs to have a high level of expertise and make rapid management decisions. LLMs, by virtue of their ability to understand natural language, can be very useful to the ED team by improving the efficiency of triage workflow, making it quicker, accurate and free of fatigue, human error and biases. Figure 8 provides a side-by-side visual summary of how the QUEST framework is applied in two ED use cases: clinical note summarization and triage decision support. Details are provided below.Fig. 8A visual summary of the application of QUEST human evaluation framework in the cases of ED clinical note summarization and ED triage decision support in a healthcare system.Two use cases, clinical note summarization and patient triage applications, are provided as an example to showcase the applicability of QUEST Human Evaluation Framework in different applications in the healthcare system. Detailed summary is provided for each step in the three phases: Planning, Implementation and Adjudication, and Scoring and Review.

Two use cases, clinical note summarization and patient triage applications, are provided as an example to showcase the applicability of QUEST Human Evaluation Framework in different applications in the healthcare system. Detailed summary is provided for each step in the three phases: Planning, Implementation and Adjudication, and Scoring and Review.

## Section: Case studies › Use Case 1: human evaluation of LLMs for clinical note summarization in emergency department

Suppose a healthcare system wishes to evaluate a few LLMs for clinical note summarization to streamline clinical documentation and reduce physician burden. We will apply the QUEST framework to the human evaluation of LLMs in this application. First, during the Planning Phase, the team needs to consider four key elements:Goals of the model: The primary objective of implementing LLMs for clinical note summarization is to streamline the clinical documentation process, thereby significantly reducing the documentation burden on physicians.Tasks performed by the model: The model will perform several critical tasks to achieve its objectives. It will extract key clinical information from detailed patient notes, including diagnoses, treatments, and outcomes. Following extraction, the model will generate concise and accurate summaries that retain all essential information. These summaries will be consistently formatted according to the healthcare system’s documentation standards.Stakeholders involved: The primary users of the model are physicians who will benefit from reduced documentation time and improved workflow efficiency. Secondary users include nurses and allied health professionals who will refer to the summarized notes for patient care coordination. Patients are indirectly affected as improved documentation can lead to better quality of care and more efficient clinical workflows.Criteria for success: Success will be measured according to several key criteria. Accuracy is paramount; the summaries must accurately reflect the key points of the original clinical notes without omitting critical information.

After defining these four considerations, the team will determine the sample size. Following the QUEST framework, they decided on a minimum sample size of 130 notes. Since the dataset lacks demographic information, they extracted such data from the notes where feasible to ensure sufficient variability that matches the population.

An important aspect of the QUEST framework is the dimensions and evaluation checklist. The committee identified dimensions most relevant to the emergency department (ED) settings where the model will be tested. Clinicians led the discussion, prioritizing Accuracy and Comprehensiveness under the principle “Quality of Information” while considering Currency less important. For metrics, they decided on a binary (presence or absence) metric for the “Bias” dimension and the AHRQ’s harm scale for the “Harm” dimension to capture ample details for categorizing the LLM outputs.

Recruiting evaluators for a clinical use case, as suggested by the QUEST framework, requires a minimum of seven evaluators. The committee determined that evaluators should have a suitable background reflective of the users, namely physicians, nurses, and other specialists. Since this use case is clinician-facing only, patient evaluators are not needed but would be included in other settings. The committee reached out to the ED department and recruited seven evaluators, including four physicians (one attending, two residents, and one fellow), two nurses, and one pharmacist.

Based on the QUEST framework, the evaluation involves five steps: developing the evaluation guideline, training evaluators, initial evaluation with a subset, discussion and adjudication, and fine-tuning the evaluation guideline. The committee developed an initial evaluation guideline and provided two hours of training to the evaluators. A sample of ten outputs with the original medical records was provided for the first round of evaluation. After discussing inter-annotator agreement to finalize and standardize the evaluation process, the guidelines were updated. The final evaluation was conducted by the seven evaluators over a two-week period. Evaluators’ comments and scoring results were collected using an application built by the informatics team, and statistical analysis was performed by the committee. The final results report was then submitted to hospital management for an in-depth review before hospital-wide implementation.

## Section: Case studies › Use Case 2: human evaluation of LLMs for patient triage in emergency department

Suppose the Chief Medical Informatics Officer (CMIO) of a large academic health system wishes to evaluate LLMs as a decision support tool for ED teams in the triage of patients across all busy EDs in the health system. During the Planning Phase, the team needs to consider four key elements:Goals of the model: The primary objective of implementing LLMs as a decision support tool is to enhance the efficiency and accuracy of patient triage in busy EDs.Tasks performed by the model: The LLMs will use patients’ chief complaints, relevant medical history, vital signs, and physical examination findings to make triage decisions (emergent, non-emergent, self-care at home) and provide recommendations for the next steps in management.Stakeholders involved: The primary users of the model are ED physicians, nurses, and triage staff, who will benefit from enhanced decision support and streamlined triage processes. Secondary stakeholders include patients, who will receive more timely and accurate triage, and hospital administration, which will benefit from improved ED efficiency and patient throughput.Criteria for success: Success will be measured through several key criteria, with accuracy in triage decisions being paramount. The model must provide reliable and timely triage recommendations that align with clinical assessments.

A total of 130 triage cases will be sampled and verified to be representative of ED visits for expert evaluation. Triage experts will perform their assessments and make triage decisions independently of the LLM output, serving as the gold standard. 3 experienced ED physicians and 3 nurses, different from the triage experts, will independently evaluate and compare the LLM outputs in terms of triage decisions with the gold standard and their own assessments. The core dimensions to be evaluated will include accuracy, agreement, comprehensiveness, currency, logical reasoning, fabrication, empathy, bias, harm, and trust, as outlined by the QUEST framework. Additionally, the evaluators will assess the LLMs’ recommendations for the next management steps on a 5-point Likert scale (strongly agree, agree, neither agree nor disagree, disagree, strongly disagree).

The evaluations by the ED physicians will be completed using a standardized questionnaire (listed in Supplementary Table 1). If there is any disagreement among the evaluators’ results, adjudication will be performed until a consensus is reached. The final results of the evaluation will be collected and analyzed across various dimensions using appropriate statistical tests, and final evaluation scores for each dimension will be generated. The final results of the evaluation will be presented to the CMIO and ED leadership. This comprehensive evaluation will guide the decision on whether to implement the LLMs system-wide, ensuring it meets the healthcare system’s standards for accuracy, efficiency, and usability.

## Section: Discussion

LLMs have become integral to various clinical applications due to their ability to generate text in response to user queries. Despite recent enthusiasm on the potential of LLMs and GenAI in many healthcare systems, the inner workings of these models remain opaque, in other words, they are still “black boxes”. The articles we reviewed reveal that evaluations of these “black box” models typically involve manual testing through human evaluation, which underscores a significant issue: the lack of traceability, reliability, and trust. Critical details such as the origins of the text sources, the reasoning processes within the generated text, and the reliability of the evidence for medical use are often not transparent. Furthermore, the traditional NLP evaluations, commonly used in well-defined tasks like Information Extraction (IE) and Question Answering (QA), prove to be suboptimal for assessing LLMs. This inadequacy stems from the novelty of the text generated by LLMs, which traditional NLP evaluation methods struggle to handle effectively. As the use of LLMs in medicine increases, the need for appropriate evaluation frameworks which align with human values becomes more pronounced.

To address these challenges, we have proposed guidelines for human evaluation of LLMs. However, these guidelines also have limitations, constrained by the scale of human evaluation, the size of the samples reviewed, and the measures used, all of which can affect the depth and breadth of the assessments. Adding to these challenges is the predominance of proprietary models developed by major technology firms. The healthcare sector often faces constraints in computational resources, which limits the ability of informatics researchers to thoroughly study LLMs. This situation calls for a collaborative effort among the medical community, computer scientists, and major tech companies to develop comprehensive evaluation methods that can improve the quality and reliability of LLMs for clinical use. Our hope is to bridge these gaps and foster a synergy that could lead to more robust, transparent, and accountable LLMs in healthcare, ensuring they meet the high standards necessary for clinical application.

This literature review has a few limitations. First, this review may have missed relevant articles published after February 22, 2024. Since this field is rapidly evolving, there are likely significant advancements and new findings that have emerged since then. Second, the review is limited to articles written in English. Articles written in other languages may also provide valuable information and insights. Third, the search strings and databases we used for this review might not have been comprehensive enough, potentially introducing bias into the findings. Fourth, this review does not consider articles that utilize LLMs in other domains than healthcare, which may contain valuable insights regarding human evaluation.

The QUEST framework is developed based on the literature review and has several potential limitations as well. First, the implementation of QUEST framework may still vary across different clinical specialties and institutions. While we propose the framework to be generally applicable in various domains in healthcare and to best accommodate the varying limiting factors in different application settings, i.e., clinical, education, and research, constraints among subspecialties and/or institutions may pose challenges to their adherence to the framework and limit the actual outcome of standardization efforts advocated in this framework. Institutional policies, technology infrastructures, resources, and the availability of trained informatics personnel can vary widely, further complicating the implementation. Second, the dimensions of QUEST framework, although comprehensive, might not fully capture the nuances of every particular use case or scenario. The evaluation of LLMs is inherently task-specific in healthcare. Users should view this framework as a foundational starting point rather than a definitive solution. It is crucial to think critically about how this framework can be adapted and applied to meet the unique demands of their specific clinical applications. We encourage readers to consider applying a combination of our framework and specific frameworks depending on the use case. Third, the QUEST framework focuses only on human evaluation and does not consider automatic evaluation. While human evaluation provides critical insights into qualitative aspects of performance, automatic quantitative evaluation methods can offer valuable metrics and scalability. We fully acknowledge the utility that automatic evaluation can bring to any experiment or deployment of LLMs. Therefore, striking a balance between human evaluation and automatic quantitative evaluation is essential to uncover insights potentially missed by either approach.

There are opportunities in unifying automatic and human evaluation across various applications in the healthcare domain. While there are efforts in aligning and improving the correlation between automatic evaluation metric and human evaluation such as Krishna et al. and Moramarco et al.56,57, they are limited to specific applications and tasks such as clinical note summarization and note generation.

There are also technical advancements of multimodal LLMs and text-to-image foundational models such as CLIP58. These models could be instrumental in generating synthetic medical images (text-to-image) and performing clinical diagnoses (image-to-text or recordings-to-text). However, their potential applications warrant separate research efforts.

Further, the ultimate goal of any implementation of LLMs is to improve actual patient outcomes or scientific understanding, and how to best connect the evaluation to reflect the impact of LLMs in achieving these goals is left as future work. While our evaluation framework aims to be futureproof, emerging techniques in LLMs and AI might require add-ons to our framework in the future. For example, emerging automatic and/or human evaluation methods with LLMs in the general domain may be helpful in the development of automatic and/or human evaluation healthcare domain, and vice versa.

Finally, applying LLMs and other emerging technology to automate or scale human evaluation processes in a low resource setting remains a research question. Although there have been attempts to use LLMs to complement human evaluation, success has been limited, highlighting the need for further exploration in this area.

## Section: Methods

The initial search yielded 795 articles after applying language and publication year filters. Exclusion criteria were set to omit articles types irrelevant to our research aims, resulting in 688 potentially relevant articles. To ascertain focus on LLMs in healthcare, articles underwent a two-stage screening process. The first stage involved title and abstract screening to identify articles explicitly discussing human evaluation of LLM within healthcare contexts. The second stage involved a full-text review, emphasizing methodological detail, particularly regarding human evaluation of LLMs, and their applicability to healthcare. Due to accessibility issues, 42 articles were excluded, resulting in a final selection of 142 articles for the comprehensive literature review.

PubMed search results (Search Date: February 22, 2024)

Search terms excluded

## Section: Methods › Data sources and search strategies

This is a scoping review that adheres to the Preferred Reporting Items for Systematic Reviews and Meta-Analyses Extension for Scoping Reviews (PRISMA-ScR) to ensure a rigorous and replicable methodology (Fig. 9 and the corresponding checklist in Supplementary Table 2). Our literature search spanned publications from January 1, 2018, to February 22, 2024, capturing the emergence and application of language models like GPT-1 introduced in 2018, through the subsequent development of advanced models including LLaMA-2, GPT-4, and others. This period is crucial as it marks the rapid evolution and adoption of LLMs in healthcare, offering a comprehensive view of current methodologies and applications in clinical NLP research.Fig. 9Preferred Reporting Items for Systematic Reviews and Meta-Analyses (PRISMA) flow diagram of the article screening and identification process.The initial search yielded 795 articles after applying language and publication year filters. Exclusion criteria were set to omit articles types irrelevant to our research aims, resulting in 688 potentially relevant articles. To ascertain focus on LLMs in healthcare, articles underwent a two-stage screening process. The first stage involved title and abstract screening to identify articles explicitly discussing human evaluation of LLM within healthcare contexts. The second stage involved a full-text review, emphasizing methodological detail, particularly regarding human evaluation of LLMs, and their applicability to healthcare. Due to accessibility issues, 42 articles were excluded, resulting in a final selection of 142 articles for the comprehensive literature review.

We focused on peer-reviewed journal articles and conference proceedings published in English, recognizing the pivotal role of LLMs in advancing healthcare informatics. The search focused on PubMed to ensure broad coverage of the healthcare literature. The selection was based on relevancy to healthcare applications, human evaluation of LLMs, and explicit discussion of evaluation methodologies in clinical settings. Our search strategy included terms related to “Generative Large Language Models,” “Human Evaluation,” and “Healthcare,” combined in various iterations to capture the breadth and depth of the studies in question.

Below details the inclusion and exclusion criteria for the article search and Table 6 lists the search query and corresponding results. Table 7 shows the search terms we decided to exclude in the final search queries as they return a large proportion of false positive results. This review includes publication available in database PubMed in English language from the year 2018 to 2024 as major designs of LLM such as GPT-1 were released since 2018; We excluded in the article search the following article types: Comment, Preprint, Editorial, Letter, Review, Scientific Integrity Review, Systematic Review, News, Newspaper Article, Published Erratum.Table 6PubMed search results (Search Date: February 22, 2024)#Search queryResults1“language model” or “language models” or “LM” or “LMs” or “large language model” or “large language models” or “LLM” or “LLMs” or “generative language model” or “generative language models” or “GLM” or “GLMs” or “neural language model” or “neural language models” or “NLM” or “NLMs” [Title/Abstract]32,91121 remove all acronyms (“LM” or “LMs” or “LLM” or “LLMs” or “GLM” or “GLMs” or “NLM” or “NLMs”)290032 or (“ChatGPT” or “GPT-4” or “GPT4” or “GPT-3.5” or “GPT3.5” or “GPT-2” or “GPT2” or “GPT”[Title/Abstract])97974“healthcare” or “health care” or “clinical” or “medicine” or “medical” [Title/Abstract]6,559,4805“evaluation” or “evaluations” or “evaluate” or “evaluated” or “evaluates” or “eval” or “evaluator” or “evaluators” [Title/Abstract]4,395,4996“human evaluation” or “qualitative evaluation”[Title/Abstract]54207“annotation” or “annotations” or “annotator” or “annotators” [Title/Abstract]54,29483 and 4319593 and 4 and 51154103 and 4 and (5 or 6)1154113 and 4 and (5 or 6 or 7)119112Limit 11 to language English91113Limit 12 to year 2018–202479514Limit 13 to all article type except Comment (n = 1), Preprint (n = 41), Editorial (n = 12), Letter (n = 14), Review (n = 32), Scientific Integrity Review (n = 0), Systematic Review (n = 7), News (n = 2), Newspaper Article (n = 0), Published Erratum (n = 0)688Table 7Search terms excluded#Search queryResultsReason for exclusionA1“Llama2” or “Llama” [Title/Abstract]1393Returns majority Llama the animalA2“BARD” [Title/Abstract]735Returns majority person names, or acronyms unrelated to LLMsA3“Gemini” [Title/Abstract]2394Returns majority acronyms unrelated to LLMs, such as Gemini surfactantsA4“BART” [Title/Abstract]1080Returns majority acronyms unrelated to LLMs, such as Bayesian additive regression trees, balloon analogue risk tasks, or Bart’s syndromeA5“PaLM” [Title/Abstract]8303Returns majority palm the body partA6“Falcon” [Title/Abstract]519Returns majority Falcon the animalA7“decision support” [Title/Abstract]24,016Returns majority non LLM relatedA8(“Llama2” or “Llama”[Title/Abstract]) AND (“healthcare” or “health care” or “clinical” or “medicine” or “medical” [Title/Abstract])228Returns majority Llama the animal

The initial search yielded 795 articles after applying language and publication year filters. Exclusion criteria were set to omit articles types irrelevant to our research aims, resulting in 688 potentially relevant articles. To ascertain focus on LLMs in healthcare, articles underwent a two-stage screening process. The first stage involved title and abstract screening to identify articles explicitly discussing human evaluation of LLM within healthcare contexts. The second stage involved a full-text review, emphasizing methodological detail, particularly regarding human evaluation of LLMs, and their applicability to healthcare. Due to accessibility issues, 42 articles were excluded, resulting in a final selection of 142 articles for the comprehensive literature review.

PubMed search results (Search Date: February 22, 2024)

Search terms excluded

## Section: Methods › Article selection

We excluded the article types as stated above as we intentionally seek articles with in-depth discussion of actual experiments of LLMs and human evaluation of the LLM outputs. The article types we excluded are commentary or summary in nature and do not include experiments. While the preprints may include experiments and discussion, they are excluded as they have not been peer-reviewed. Specifically, our search results from search keywords amount to 1191 studies, adding the limitation of publication language, period, and publication type further reduce the number of studies to 911, 795, 688.

To ascertain focus on LLMs in healthcare, articles underwent a two-stage screening process. The first stage involved title and abstract screening to identify articles explicitly discussing human evaluation of LLMs applications within healthcare contexts. We also excluded studies which examine only non-generative pretrained language models like BERT59, RoBERTa60, etc. and multimodal studies such as image-to-text or text-to-image application of generative LLMs. The second stage involved a full-text review, emphasizing methodological detail, particularly regarding human evaluation of LLMs, and their applicability to healthcare. Due to accessibility issues, 42 articles were excluded, resulting in a final selection of 142 articles for the comprehensive literature review.

## Section: Supplementary information

Supplementary Material

Supplementary Material


---

# A joint ESTRO and AAPM guideline for development, clinical validation and reporting of artificial intelligence models in radiation therapy

- **Authors:** Coen Hurkmans, Jean-Emmanuel Bibault, Kristy K Brock, Wouter van Elmpt, Mary Feng, Clifton David Fuller, Barbara A Jereczek-Fossa, Stine Korreman, Guillaume Landry, Frederic Madesta, Chuck Mayo, Alan McWilliam, Filipe Moura, Ludvig P Muren, Issam El Naqa, Jan Seuntjens, Vincenzo Valentini, Michael Velec
- **Issuer:** Radiotherapy and oncology : journal of the European Society for Therapeutic Radiology and Oncology
- **Type:** Scientific article
- **Published:** 2024-06-03
- **Language:** en
- **DOI:** 10.1016/j.radonc.2024.110345
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38838989/
- **Licence:** CC-BY

## Section: Abstract

Artificial Intelligence (AI) models in radiation therapy are being developed with increasing pace. Despite this, the radiation therapy community has not widely adopted these models in clinical practice. A cohesive guideline on how to develop, report and clinically validate AI algorithms might help bridge this gap. A Delphi process with all co-authors was followed to determine which topics should be addressed in this comprehensive guideline. Separate sections of the guideline, including Statements, were written by subgroups of the authors and discussed with the whole group at several meetings. Statements were formulated and scored as highly recommended or recommended. The following topics were found most relevant: Decision making, image analysis, volume segmentation, treatment planning, patient specific quality assurance of treatment delivery, adaptive treatment, outcome prediction, training, validation and testing of AI model parameters, model availability for others to verify, model quality assurance/updates and upgrades, ethics. Key references were given together with an outlook on current hurdles and possibilities to overcome these. 19 Statements were formulated. A cohesive guideline has been written which addresses main topics regarding AI in radiation therapy. It will help to guide development, as well as transparent and consistent reporting and validation of new AI tools and facilitate adoption.


---

# A Modern Curriculum for Training Scientists in Model-Informed Drug Development: Progress Report on FDA Grant to Train Regulatory Scientists

- **Authors:** Jeffrey S Barrett, Klaus Romero, Craig Rayner, Marc Gastonguay, Goonaseelan Colin Pillai, Stacey Tannenbaum, Steven Kern, Mark Selich, Dave Francisco
- **Issuer:** Clinical pharmacology and therapeutics
- **Type:** Scientific article
- **Published:** 2024-08-01
- **Language:** en
- **DOI:** 10.1002/cpt.3039
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39012325/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Under US Food and Drug Administration (FDA) grant (2U18FD005320-06), the Critical Path Institute (C-Path) and experienced private sector partners collaborated with global health organizations to create didactic video materials in an e-learning format on model-informed drug development (MIDD) topics relevant to a non-modeling audience. Several multinational pharmaceutical companies contributed case studies illustrating the application of the MIDD approach in practice. Training videos were created and divided into several modules: introducing the MIDD landscape for drug development and regulatory science, a review of various model types used for MIDD, discussions of how models inform drug development and regulatory decisions, future goals of MIDD, and discussions on the interconnectedness of models used for MIDD. Examples and vignettes from stakeholders and thought leaders were included. These educational materials fill a gap between academic and "on the job training" for regulators, academic, and industry scientists, delivering insights and value for those performing modeling and non-modelers reviewing the output of modeling and simulation work. A total of 13 hours of video content is currently available. A small panel of FDA reviewers is currently beta-testing the learning management system (LMS). Future efforts for this MIDD training initiative will include expansion of the content via an expanded and diverse faculty, 1:1 online mentorship sessions, and eventually broader access to this resource consistent with an open science approach and curriculum. The MIDD training LMS can accommodate a diverse learning ecosystem; further development may also accommodate different audiences in the future.


---

# A phenotypic drug discovery approach by latent interaction in deep learning

- **Authors:** Tat Wai Billy Yu
- **Issuer:** Royal Society open science
- **Type:** Scientific article
- **Published:** 2024-10-23
- **Language:** en
- **DOI:** 10.1098/rsos.240720
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40191531/
- **Licence:** CC-BY

## Section: Abstract

AbstractContemporary drug discovery paradigms rely heavily on binding assays about the bio-physicochemical processes. However, this dominant approach suffers from overlooked higher-order interactions arising from the intricacies of molecular mechanisms, such as those involving cis-regulatory elements. It introduces potential impairments and restrains the potential development of computational methods. To address this limitation, I developed a deep learning model that leverages an end-to-end approach, relying exclusively on therapeutic information about drugs. By transforming textual representations of drug and virus genetic information into high-dimensional latent representations, this method evades the challenges arising from insufficient information about binding specificities. Its strengths lie in its ability to implicitly consider complexities such as epistasis and chemical–genetic interactions, and to handle the pervasive challenge of data scarcity. Through various modeling skills and data augmentation techniques, the proposed model demonstrates outstanding performance in out-of-sample validations, even in scenarios with unknown complex interactions. Furthermore, the study highlights the importance of chemical diversity for model training. While the method showcases the feasibility of deep learning in data-scarce scenarios, it reveals a promising alternative for drug discovery in situations where knowledge of underlying mechanisms is limited.Keywords: drug design, target-agnostic, binding sites, deep learning, latent interaction, phenotypic approach

## Section: Introduction

In drug development, deep learning has captivated the attention of researchers. From predicting intricate drug–target interactions to evaluating drug–drug similarities and beyond, the applications of deep learning present exciting frontiers in the quest for more efficient and effective pharmaceutical advancements [1–3]. Mostly, it involves exploring the chemical and molecular spaces with approaches like homology for potential drug candidates [4]. The advantages are speed and interoperability [5]. However, beneath it lies a critical challenge: the need for reliable patterns in docking specificity, structural or functional properties like in spike protein, pharmacological perturbation, and transcriptomic signature matching [6–9]. The realization of docking strategy is restrained by the lack of high-quality transcriptome-wide profiling data [10]. Their applications necessitate reliable data from diverse fields such as pharmacological targets [11], physicochemical characteristics [12] and drug pharmacokinetics [13], which are usually costly.

Virus gene sequences now provide a device in rational drug design [14]. However, data sufficiency again becomes a concern. Say, VolSite [15,16] offers promise in this pursuit, yet its development path is not without challenges. Complications such as epistasis [17], off-target effects, traverse regulatory networks, competition for binding [18], the noncoding regions [19], synergistic interactions [20] and the interactome molecular pathways [21] in the host and other bio-physicochemical interactions contribute to snags beyond anticipated bindings [22]. Understanding interactions among multiple loci proves challenging. The nonlinear dynamics within the realm of biocomplexity make it virtually impossible to anticipate all potential higher-order interactions [23,24]. It is also difficult to assay complex phenotypes at scale [25]. Despite employing sound strategies [2,3,5,9,26–30], target-binding methods in clinical drug development are hindered by high false-positive rates [28,31].

As deep learning technology continues to evolve, models to address drug development challenges become more pertinent. To this end, this study aims to harness its transformative power in advancing the methodology. Instead of using discovered patterns in docking specificity, it devises a method that relies exclusively on the therapeutic information of drugs. Hopefully, the automatic feature extraction ability in today’s deep learning can facilitate drug prediction. In essence, this study introduces a deep learning approach to examine the complex interactions that are otherwise impossible in a typical target-based approach.

## Section: Introduction › Current tricks for interaction recognition

Similar unorthodox methods have emerged to bypass typical reliance on explicit binding specificity information in the literature; they only leverage other strategies. A noteworthy example of this is a network-based approach. It taps into the network proximity of drug-gene signatures [32]. Network-based methodologies with phylogenetic analyses can also quickly identify candidate drugs [33]; it exemplified the potency of the network-based approach in the context of coronavirus research. In short, the network-based approach demonstrates a rapid and effective strategy without the need for explicit binding specificity; however, there is room for improvement in its performance on accuracy (the discussion section will elaborate more on this).

Conversely, metabolism functions, molecular mechanisms and a considerable proportion of intracellular proteins are regulated by the genomic sequence through the modulation of gene expression. This paradigm offers a promising avenue for drug repurposing endeavours with notions in the transcriptomics-based pipeline. Through it, deep learning methods can work out solutions by automatic feature extraction. Despite the absence of explicit therapeutic targets in various diseases and biological processes, models can glean insights from both chemical structures and gene expression changes [34]. With extracted latent representation of chemical molecules and landmark genes, researchers markedly demonstrate the ability to predict intricate interactions [2] and, more specifically, binding affinity [17]. These methods exploit the deep learning working mechanisms without full understanding of the underlying molecular processes. This empowers researchers to unravel highly complex bio-physicochemical relationships that cannot be manifested in conventional methods.

Whole-genome analysis has repeatedly demonstrated its clinical facilitation [35]. In microscopic study of pathogens, it increases the power of molecular epidemiology and helps develop novel treatments and vaccines [36]. In macroscopic epidemiological research, it offers a reliable means to assess the extent of viral transmission [37]. With the accessibility of whole-genome sequencing, deep learning methods could transcend the limitations of explicit targets and empower researchers with a more comprehensive approach to understanding biological processes.

## Section: Introduction › Utilizing molecular mechanisms

There are diverse methodologies employed in virus-based treatment options. They focus on viral nucleosides, nucleotides and nucleic acids by leveraging transcriptomics, molecular docking, and the analysis of structural and functional properties [38]. Amidst that, this study introduces a novel approach grounded in logic of the complex interaction among viral genes and drugs. The genetic makeup shapes viruses’ structure, function and behaviour. Some replicate and control the expression, regulate and encode proteins that interact with their host cell proteins. Recognizing this pivotal role of genes, I propose a method to harness genetic information as a comprehensive summary of functional and behavioural features for in-depth deep learning analysis with the drug.

In like manner, the functionality of a drug is shaped by its chemical makeup, which can be represented by the International Chemical Identifier (InChI) [39]. The InChI is a text string that effectively identifies and summarizes the chemical information, including the molecular structure, bonding, isotope, stereochemistry, etc. By recognizing this representation as a source of drug information about its functionality and behaviour, we can utilize deep learning analysis to probe into its interaction with viruses.

However, the challenge lies in the extraction and transformation of the information into meaningful features for modelling the interactions. Traditional docking strategies depend on explicit means by geometric features. In contrast, the strategy here tries to extract features automatically [40] with proper modeling skills in deep learning. A detailed description of our approach to achieving the designated objectives will be presented in §§2.1 and 2.2.

In essence, this novel approach draws an analogy to how our ancestors discovered drugs through the observation of their effects [41]. This phenotypic drug discovery approach has lately been supplanted by the reductionist approach of modulating specific molecular targets of interest [42]. Distinct from the assumptions about specific genome regions, our target-agnostic approach bypasses functional preconceptions of introns, exons, non-coding regions, etc. Also, it makes no assumption about the functionality of specific genome regions. Instead, it uses end-to-end learning to acquire knowledge of molecular targets or even pathways implicitly. §2 altogether serves as a meticulous exposition of our process, wherein deep learning models are wielded to scrutinize complex interactions.

The focus of this study is on leveraging deep learning to unveil specificities, targets or mechanisms in the latent space, in which the latent space analysis approach has shown success in molecular interactions within the tumor microenvironment [43]. This approach harmoniously integrates reductionist concepts with the formidable capabilities of deep learning tools. This amalgamation aims to untangle the interaction intricacy based on the discovered drugs and virus genetic information. The rest of this paper presents the comprehensive strategy.

## Section: Material and methods

I approach the drug–virus problem as a supervised deep learning task. An intention is to recognize potential interactions through end-to-end learning. Nevertheless, deep learning techniques require massive data for model training but there were only 58 antiviral-drug available in the Virus Pathogen Resource (ViPR) [44]. This small sample size does not provide enough therapeutic cues for most deep learning models to learn. Data scarcity is an impediment. In contrast, there are more than ten thousand FDA-approved drugs (10,282). FDA approval is a decent inclusion criterion because the FDA undergoes a rigorous review process to ensure drug eligibility. It should provide guaranteed information and sufficient accessible chemical diversity for a model to learn some pharmacophores [45]. We can utilize this availability. A simple data augmentation technique can translate this data availability into the feasibility of deep learning analysis.

Therefore, I created negative samples using data augmentation [46,47]. Pairs of virus genes and drugs were each labelled with their compatibility, a match or a mismatch. When a drug was approved by FDA for a virus disease, the corresponding pair was considered effective for the treatment; I assigned a value of one (1) to it. For the mismatch, a pair was assigned a value of zero (0 a negative sample). However, this negative assignment might be a misjudgment, resulting in a trained model wrongly disqualifying a drug. In this setup of maximizing chemical diversity, I fabricated negative training examples with minimal repetitions to reduce potential falsely mismatched noises. This was accomplished by a data augmentation technique to enable supervised deep learning models to work on a typical binary prediction problem.

The 58 drugs served as seeds for creating an authentic drug–virus dataset. The number of unique virus names (organism names) was 198. The model aims to predict the drug efficacy based on the textual inputs: nucleotide sequence of the virus and the drug representation. I mapped the virus names to the NCBI Viral Genomes Resource [48]; 775 unique assemblies of viruses were identified. I then obtained the genome sequences from GenBank. The number of unique genome sequences at the nucleotide level in FASTA representation was 1353. Long sequences of this number shall provide enough nucleotide information for the training process.

For the drug part, I used InChI instead of SMILES to represent chemical structure because it is more informative. Although SMILES are more human-readable, the InChI format separates the information about atoms and bonds. It explicitly describes the structure of a molecule and the bonding between atoms; its hierarchical layered line notation further provides information about the structural complexity. Thus, it has an advantage in dealing with complexities like isomers, isotopic distributions and more importantly the type of nomenclature that helps understand the structure of a molecule.

Despite the fact that the InChI representation provides more information about drug molecules, there were successful cases of using the SMILES representation for deep learning model to learn. For SMILES, character strings were successfully encoded by using recurrent neural networks (RNNs) as well as convolutional neural networks (CNNs). Nevertheless, good performance was contributed by the presence of repetitive, translationally invariant substrings that correspond to chemical substructures, e.g. cycles and functional groups [49,50]. On the other hand, the InChI representation has a more complex syntax that includes counting and arithmetic. Its hierarchical layers also hinder the feasibility of analyzing the text strings as plain sequences. Encoders with relatively simple RNNs and CNNs would not be able to perform. InChI layering structure demands more sophisticated deep learning architecture, like the language model, to understand it for prediction accuracy. To solve the problem, I deploy members from the seminal work of the transformer-family [51] to handle its language-like complication and its layering structure. §2.2 is dedicated to the custom-building process.

Data construction took into consideration its uncommonness of drug repurposing and practicability in training. Drugs uncovered for repurposing are rare; the arrangement of unbalanced data is inevitable. However, the rarity shall not be too extreme that it brings unnecessary technical analysis difficulties. Thus, the number of mismatches (negative samples) was roughly 12 times (12 ×) more than the matches. To evaluate model performance, data was partitioned into three (3) pieces: training, validation and testing data. In order to preclude potential data leakage, authentic matches of an antiviral drug were exclusive in only one of the data partitions. §3.1 will reveal more detail. To further evaluate the potential of data leakage, results will be accompained with some drug similarity assessment to examine the reliability.

For the model to learn, the training data were of the largest proportion. It contained 208 223 drug–virus pairs, of which 14 646 (6.9%) were authentic matches. The validation data provides the first test against unseen data, it helps to evaluate how well the model can predict results of new data, oversee the training process of potential overfitting and tune the model. It had 59 424 pairs, with 4104 authentic (6.7%). The test data examined the model prediction accuracy after the model was built. It provided a decisive real-world check of an unseen dataset to substantiate model performance. It contained 30 244 pairs, with 2591 authentic (8.4%) for ultimate out-of-sample evaluation.

In contrast to conventional methods, the inputs are simply the InChI representations of drugs and the genetic information of viruses. Deep learning models are to convert these text strings into high-dimensional latent data for the process. This approach tackles the issues of scarce data and complex biological and chemical properties. To the best of the author’s knowledge, no previous research took this alternative path of using pure text strings as inputs and language models for the problem. Thus, I made available the datasets for other researchers to work on 1 . Figure 1 illustrates the framework of this study.

I used the ensemble method [52] to formulate and train the model in a modular way. It starts with the basic premise that we should maximize the utilization of available information on both viruses and drugs and we should tickle problems with relevant deep learning architecture. I preprocessed the inputs with pre-trained models to obtain representations before the interaction search. Model training consisted of two phases. The first phase involved learning relevant features of drugs and viruses with two independent autoencoders so that they could extract meaningful representations for reconstruction of corresponding raw inputs. These models leveraged the power of automatic feature extraction to generate drug and virus latent features. They were optimized to preserve essential chemical/genetic information so that the original entities could be reconstructed from the latent features. This phase focused on creating reliable encoding models for drugs and viruses. The encoder parts of the models can produce latent representations for inputs. §§2.1 and 2.2 will detail the process. This technique shall help circumvent the issues of over-parameterization and overfitting, and §3 will substantiate that. The outputs were two encoding models for drugs and viruses. They are responsible for creating latent features as digests. The second phase developed a deep learning classification model that takes the digests as inputs. It searches for interactions concerning the drugs and viruses in the latent space, then predicts the effectiveness of the drug on a virus supervised by the compatibility label (0 or 1). I applied various technical tricks and justified them based on the biochemical or genetic literature. §§2.3 and 2.4 will detail the process.

The model framework. Panel (a) is a one-dimensional CNN-based ResNet autoencoder for the virus FASTA representation. The resulting virus digest is coloured orange. Panel (b) is an autoencoder for the drug InChI representation. The encoder is essentially the ETC model. Panel (c) shows the core model. After the stylish self-interaction search for the digest individually, a Perceiver model searches for meaningful interactive features iteratively.

## Section: Material and methods › The virus digest

The first preprocessing module is for virus representation. Non-coding regions may regulate transcription, and its binding may affect the binding site affinity, specificity and diversity [53,54] and related cellular functions [19]. I used an unsupervised learning technique to process the whole genomic sequences to avoid missing out on this representation learning. The encoder module takes the virus genome in the 4-nucleobase form and converts it into a vector. The vector had 0’s or 1’s at the index bases. This input vectorization method allows multiple alternative representations in a nucleotide position, like for M and N.

I used an autoencoder to capture representative information and to reduce the long sequence to a shorter and more manageable length. Figure 1a depicts the autoencoder; it consists of two parts: the encoder extracts the latent features of viruses, and the decoder tries to reconstruct the original input sequence. The model learns to minimize the reconstruction errors. I selected the ResNet [55] because it can compress lengthy sequences, and its residual connections make weight updates more effective. This way, more layers could be stacked together for abstract learning. The ResNet model was implemented in eight blocks of process, each block consisting of two sub-blocks of one-dimensional convolution neural network (CNN) and batch normalization. Stages were connected with residual links. Its principle hidden dimension is 128, and it was trained with a batch size of 64. I also used squeeze-and-excitation optimization [56] for performance. It helps feature recalibration and can learn to use global information to select useful features and suppress others. It was proven effective for ResNet, while interdependencies between channels (of nucleotide bases) are unknown but crucial.

## Section: Material and methods › The drug digest

Language models, which rely heavily on transformers, can learn representations of large-scale structural characterization from single protein sequences [47]. I leveraged this ability of transformers to prepare the drug pre-trained model. The InChI representation is similar to language and has a hierarchical structure. InChI allows encoding with different levels of granularity (a representation can include or exclude stereochemical, isotopic and tautomeric information [39]). However, with this complex structure of InChI (unlike SMILES), relatively simple RNNs and CNNs would not be able to perform.

Recent development of deep learning in natural language processing (NLP) enables effective ‘understanding’ of such human-readable textual input (for example [57]). Nevertheless, regular transformers in conventional NLP models are less capable of understanding when the text comprises some hierarchical structure; fortunately, the extended transformer construction (ETC) model is designed to handle the challenge of encoding structured text [58]. It can extract meaningful molecular descriptors in the form of latent molecular representations for structures without the need for additional or explicit labels. As regularly practised, I engineered the InChI input into several layers to enhance its understanding about the textual description. As shown in figure 1b , the most basic layer was the word embedding layer. It tokenizes the chemical elements and other chemical information. Specific to InChI representation, a forward slash followed by a letter signifies the kind of information. For example, it identifies the protonation by '/p' and stereo sublayer by '/s'; this information is stored in the type embedding layer. The position embedding is a distinctive design for relative attention in the ETC model. Coupled with its relative position encoding, it can effectively capture complex hierarchical structures in the InChI representation. For numeric information, the number token explicitly identifies it and the category embedding signifies that it is a number. An advantage of this setting is that it imposes no conflict with the ETC hierarchical attention mechanism. The training of this autoencoder also followed well-regarded randomly masked words pre-training strategy [59], so as to predict the original word based on the context. The ETC model was implemented with six transformer layers, each with two attention heads and model hidden dimension of 128, resulting in a model depth of 64. This is the dimensionality used for the individual attention heads. The inner dimension of the feedforward neural network (FNN) is 512. For the training, the masking proportion was 10% and the batch size was 64.

## Section: Material and methods › Self-association

Before examining drug–virus interactions, I developed a scheme to handle potential self-association in the analysis context. For the gene part, the scheme considers the functional nucleotide motifs, regulatory sequences, self-complementary sequences, secondary structures, etc. Non-coding regions may also affect gene expression by binding to transcription factors, resulting in the activation or repression of transcription. The scheme should consider all of the above at a genome-wide scale, but without the conventional binding and gene expression information. To detect object bounds and objectness, I applied an object detection method with the region proposal network (RPN) [60]. This proven technique works well with the attention mechanisms that we will use in the cross-interaction search in the subsequent analysis phase. For the RPN, there were two layers of one-dimensional convolution networks, both with hidden dimensions of 128. The first layer was of kernel size of 3 and the other of 1, in between them was a unified (batch) normalization and (ReLU) activation layer. After this were two self-attention layers with hidden dimension of 128 in both the query and the value channels. Figure 1c shows the schematics of the analysis.

Similar self-association is also present in the drug part. It can be the modulation of physicochemical properties or the mechanisms of drug solubilization [61]. The InChI representation input is multifarious; without prior information on possible self-interaction, I adopted a gating mechanism to skip over unused components [62]. It enables high performance in a wide range of scenarios for unused parts and provides efficiency and flexibility to apply non-linear processing only where needed. The implementation of this gated residual network followed the standard, the first layer was a linear FNN. The second was a simple activation layer with an exponential linear unit (ELU). The third layer was again a linear FNN. The last was a so-called gating layer made up of two time distributed wrapped dense layers and multiplying layers with a dropout rate of 15%. All intermediate layers had hidden dimensions of 512 and the output dimension was 128.

In the context of the drug–virus interactions, cis-regulatory elements, such as promoters, enhancers and silencers, regulate the transcription of nearby genes and are likely to complicate the biochemical processes. Both local and global contexts should matter for modelling dependencies among inputs. A deep learning technique strives to address this complex combinatorial scenario. Inspired by estimating interactions between pairs of gene features in studying regulatory DNA sequences [63], I utilized context-aware self-attention [64]. This self-attention is a proven technique to capture local and global contexts. This scheme efficaciously probed potential self-interactions of modeling both short- and long-term dependencies. Figure 1c shows the schematics of using context-aware self-attention.

## Section: Material and methods › Cross-interaction search

Putative drug–gene interactions only indicate binding potentials; they do not always guarantee drug effectiveness [65]. Similarly, the absence of interactions at certain gene loci or codons does not imply that they are irrelevant to drug efficacy. Other factors may also complicate the bio-physicochemical interactions besides the binding specificities. For example, a drug can affect gene expression levels [66,67], and there are also issues related to overlooked exons, hidden binding pockets [68], functions of recoded stop codons or regulators [69] and structural entanglement factors [70]. The combinatorial relationship of the binding specificities is difficult to capture. I adopted the Perceiver mechanism [71] to learn higher-order interactions based on the digests and preprocesses that contain high-level drug and gene self-associations in the latent space, figure 1c . It alternated between cross-attention and self-attention to process the mapped inputs and efficiently capture possible combinations. It hence identifies meaningful interactive features. More specifically, it aims to determine the effects of pharmacogenetic polymorphisms in the latent space by iteratively attending to all latent features. The perceiver encoder took the virus’s part as the value and the drug’s part as the query. It was made up of four self-attention layers, each of two attention heads and of hidden dimension of 128, which means a depth of 64. The pre-processed resultant was the mapped inputs. Afterward, the cross-attention and self-attention units were implemented with two attention heads and a hidden dimension of 128, that is again a depth of 64.

Since there were no labelled segments of genes and drugs in the interaction, I used an adaptive pooling layer, AutoPool, to preserve the temporally dynamic predictions in the pooling process. This modification is a proven technique to detect weakly labelled sound annotation [72], which is a characteristic that fits our iterative search for latent features in the sparse and unknown interaction in long sequences. Another minor but technically important issue was that the data contained observations distant from one another, especially with the mismatches of drugs. A model should be aware of the magnitudes of the differences between the current samples and the previously seen training examples [73]. Bayesian approaches would be the best candidate to handle such uncertainties; however, they require another framework on Bayesian neural networks. That would demand excessive computational and memory requirements. For performance concerns, I used a Gaussian Process Classification Head based on the spectral-normalized neural Gaussian process (SNGP) [74]. It introduced a simple but high-quality uncertainty estimation method to handle the classification problem by adding a spectral normalization during training.

Deep learning models may not learn efficiently from class-imbalance data. To ensure that the training process was not affected by distribution variability, I replaced the standard cross-entropy with a label-distribution-aware margin (LDAM) loss in the training process [75]. It improves the generalization error of minority classes without sacrificing the ability to fit the frequent classes. I also incorporated label smoothing [76]. This regularization technique turns deterministic class labels into probability distributions in the model training phase. It is a popular technique to improve performance on class-imbalance data. Furthermore, multiple performance metrics were used for evaluations. The appendix details their statistical significance.

## Section: Results

The proposed model’s overall results are shown in the top row of table 1. The area under the receiver operating characteristic curve (AUC = 99.5% for the training and 98.8% for the test data partition) is high. However, AUC focuses on the relation between the true positive rate and false positive rate; a good performance might present an optimistic picture because true negatives dominate, for the unbalanced datasets that we have. Figure 2 presents both the receiver operating characteristic (ROC) and precision–recall (PR) curves side-by-side; they together scrutinize the model’s effectiveness and strength. The colour of the lines indicates the data partitions and models that they represent. As anticipated, both models, with and without pre-training, perform well on the training data partition (the green and the light blue lines in both the ROC and PR curves).

Nevertheless, while deep learning models are prone to overfitting, we need to assess the performance of other data partitions. For instance, the model without pre-training seems to perform well on the testing data (the yellow line on sensitivity, figure 2a ). However, its PR curve (the yellow line in figure 2b ), which accounts for the potential inflation in the false positive rate (FPR), shows that the good performance on ROC is a trade-off. It just incorrectly generated more positive predictive values. Thus, the PR curves help us evaluate the models’ ability to correctly predict the minority, which are the authentic matches. The overfitting phenomenon is more noticeable in the performance for validation data, which contains a greater number of observations for evaluation. Both the ROC and PR curves (the violet lines) show that the model without pretraining cannot perform as well as the model with pretraining (the blue lines). After all, by comparing the areas under the curves, both ROC and PR curves agree that the model with pre-trained encoders performed better. To illustrate the prediction of drug-virus interaction concerning these two models, a electronic supplementary material, table S1, was created. It shows that, for the proposed model, the true positive rate is high (over 98.0% for all datasets), yet the true negative rate is even higher (99.7% for all datasets). The model is more capable in scrutinizing and disqualifying a drug than in confirming its effectiveness. On the other extreme, it illustrates that an alternative model, which was without pre-trained encoder, was not able to rediscover a drug’s effectiveness but was only good at disqualifying a drug when it was with an irrelevant virus.

Looking into the prediction ability for drug discovery, table 2 presents the subset result on FDA-approved antiviral drugs. While authentic matches of a drug were exclusive in only one of the data partitions, the model correctly rediscovered 29 out of 40 approved antiviral drugs in the training data, shown in the upper half of table 2. The remaining 11 drugs had too few observations for the model to learn in the training process: Idoxuridine, Penciclovir, Trifluridine and Valaciclovir had only four authentic matches each. Famciclovir and Aciclovir had 6; Foscarnet had 8; Vidarabine had 10; Entecavir, Adefovir Dipivoxil and Telbivudine had 35 matches each. For the 11 drugs in the validation data, the trained model correctly rediscovered nine of them. For the seven authentic drugs in the test data, the trained model correctly rediscovered six of them, missing Valganciclovir. Apart from those unsuccessful cases, most recall values were high (over 0.93), except for Boceprevir, Ledipasvir and Ombitasvir. These three drugs might share some but not all bio-physicochemical characteristics or molecular pathology with other drugs in the training data.

Also, the generally high accuracy reveals that the model effectively discriminated mismatches. High precision and recall values reveal its ability to identify and rediscover most drugs. High F1-scores and overall prediction results reflected by MCCs help address potential concerns of the imbalanced data setup. In comparing the prediction probabilities, accuracy is mostly more than precision. It ascribes to the strong ability of the model to scrutinize a drug for unmatched viral diseases.

Model performance and assessment of the refinements. Evaluations show performance degradation in the absence of specific refinements.

Model performance curves. Panel (a) presents the receiver operating characteristic (ROC) curves, which show how sensitivity (TPR) and sensitivity (PR) vary with the threshold. Panel (b) presents the precision–recall (PR) curves, which examine the model’s ability to find those minority observations.

Prediction performance on approved antiviral drugs. Model prediction result for FDA-approved antiviral drugs. There are many NAs (represented by a hyphen) in which the prediction has no true positive (TP).

Composition of partitions on model and cross-validation datasets. Training process of the proposed model was repeated using different partitioning of the 58 FDA-approved antiviral drugs, with five rounds of cross-validation datasets. Due to the rarity of chemical diversity and structural variation in available data, the customary deep learning practice of averaging test results over different rounds for a single performance estimate is inappropriate in this application. These cross-validation datasets demonstrate how the composition of drugs in the partitioning process (hence the chemical diversity and structural variation in the data) could affect the trained model.

Assessing sensitivity to data with k-fold cross-validation. The sets of ROC (left) and PR curves (right) of five different cross-validation datasets demonstrate the role of chemical diversity in training the model. The purpose is to estimate the expected level of fit and errors to independent datasets. PR curves assume a threshold value that decreases from left to right. On the far left, the thresholds were so high that only a few FPs and TPs existed. While defining precision as TP / (TP + FP), a difference of 1 TP could change precision very much. In the extreme cases, the thresholds were so high that there was no TP (= 0), and the precision would be 0 (in CV-dataset 2, 3 and 5). Hence, we observe the volatility in those high-threshold regions.

Assessing drug–drug similarity in partitioning for the model data and CV-1 to CV-5. The heatmaps exhibit the drug-drug structural similarity (or chemical diversity) of the model dataset and the five different cross-validation datasets, corresponding to table 3. Each of them shows how similar are the distributed antiviral drugs across the training, validation and testing data. A triangle shows drugs’ similarity within a partition. A rectangle shows drugs’ similarity across partitions. The purpose is to demonstrate the role of chemical diversity in model training. Hence, we observe the power of the model to learn the drugs’ properties in the context of viral diseases without using their information on structural similarity.

## Section: Results › Post hoc analysis

The meticulous refinements implemented had significant impacts in performance. A rigorous assessment, detailed in table 1, systematically scrutinizes the influence of each refinement across a number of metrics. Notably, the top row presents the performance of the complete proposed model. It serves as a reference for comparative analysis. Subsequent rows unveil nuanced variations achieved through the exclusion of specific refinements, colloquially referred to as the deep learning tricks. Of particular significance, pretraining with autoencoder emerges as a pivotal trick, as elucidated in the second row. While the model bereft of pretraining encoders exhibited marginally elevated AUC on the training data partition (99.9% versus 99.5%), its performance across other metrics, including accuracy and MCC, was conspicuously inferior. Similar deficiency extended to both validation and test datasets, indicating a pronounced overfitting issue. This observation agrees with the performance plot depicted in figure 2. Nonetheless, sole reliance on pretraining with autoencoder was insufficient for optimal outcomes. Additional stratagems, as delineated from the third row onwards, also contributed significantly to performance enhancement. Notably, the incorporation of self-attention mechanisms and a region proposal network also yielded substantial improvements. This underscores the critical importance of considering both local and global contextual cues, as well as the precise delineation of object bounds and objectness. All these tricks matter very much in investigating the interaction.

Anyhow, the overall best performance was achieved with a complete model based on the proposed architecture. These results demonstrate the importance of using pre-training encoders, and the various techniques to avoid over-parametrization and improve generalization.

Results from the primary analysis above indicate that Ledipasvir and Ombitasvir might share some bio-physicochemical characteristics with other drugs in the training data. Therefore, their chemical diversity should play some role in facilitating the model’s effectiveness. This section also explores the model’s effectiveness upon chemical diversity. It suggests that chemical diversity may be an important factor for this kind of analysis, but further studies with larger and more diverse datasets are needed to confirm this finding.

To optimize the datasets for model training, we need to have drugs of high chemical diversity and structural variation. However, there are not many antiviral drugs approved by the FDA, which posited constraint in the analysis. The model accuracy depends on how drug data is split. For example, if we train the model on drugs that are chemically diverse, it might perform better. On the other hand, if a data split only contains similar structures, the model might miss important features, resulting in a biased model that cannot be generalized to other possible chemical structures for a viral disease. Therefore, performance would hence deteriorate.

To test for the sensitivity to this imperfect data, I assessed the framework again with k-fold cross-validation on five additional datasets. In this post hoc analysis, the whole training process was repeated with the same model configuration, and the 58 antiviral drugs were partitioned randomly into training, validation and test data. They shall help understand the effects of chemical diversity on the model training. Table 3 shows the data split of each partition.

The model performance on the datasets in terms of ROC and PR curves is shown in figure 3. As expected, not all the datasets could perform. The best dataset, CV-dataset 1, scored test results of 99.9% recall, 99.7% AUC, 96.1% Precision, 0.980 F1-Score and 0.978 MCC. The worst dataset, CV-dataset 5, achieved test results of 31.5% recall, 65.6% AUC, 93.8% Precision, 0.472 F1-Score and 0.521 MCC. Its trained model was overfitted to the training data. Optimizing the distribution of elements for training is critical in the partition process under the constraint of limited data, which is not unusual in medical frontiers.

The potential impact of drug similarities on our model prediction performance cannot be overlooked 2 . Understanding such relationships and their therapeutic mechanisms has traditionally proven instrumental in enhancing the efficiency of new drug research, particularly valuable in drug repurposing applications [77]. To investigate whether drug similarity might influence prediction accuracy, figure 4 presents the pairwise drug similarity based on their structural makeup [78]. The heatmaps depict similarity scores ranging from 0 to 1, represented by red and blue colours, respectively. The large triangles in the top-left section of the heatmaps show the similarity of drugs in training data; they play a critical role in the training process. In the model dataset’s heatmap, some drugs exhibit significant similarity between the training and testing data, noticeable in the top-right rectangle with three blue dots. Also, there are moderately similar drugs across the training and validation data, shown in the top-centre rectangle.

However, it is important to note that high drug similarity alone does not guarantee superior prediction accuracy. This is exemplified by the CV−5 dataset’s heatmap in figure 4, where drugs also display similarity between the training and testing data (blue dots in the top-right rectangle), yet the model’s performance on this dataset is the least satisfactory. We have to investigate thoroughly the issue regarding the training processes with different datasets. Comparing the training datasets (the top-left large triangles) between CV−5 and the model data, it is evident that the model data displays greater structural dissimilarity, marked by the abundant presence of red zones. In fact, the training datasets of CV−1 and CV−3 exhibit more or less the same level of drug dissimilarity, suggesting their potential contribution to enhancing model performance, which is true in our results.

Notably, the training data associated with CV−5 stands out for having the lowest degree of drug dissimilarity. As outlined in §2, chemical diversity is essential for a model to learn. Weak drug similarity (or high chemical diversity) in the training data facilitates model training. This post hoc analysis emphasizes the pivotal role of chemical diversity in the training process, affirming that the model can discern and learn about the properties of drugs even in the absence of explicit structural similarity information. This underscores the model capability to understand the functional properties of drugs related to viral diseases in the latent space.

Composition of partitions on model and cross-validation datasets. Training process of the proposed model was repeated using different partitioning of the 58 FDA-approved antiviral drugs, with five rounds of cross-validation datasets. Due to the rarity of chemical diversity and structural variation in available data, the customary deep learning practice of averaging test results over different rounds for a single performance estimate is inappropriate in this application. These cross-validation datasets demonstrate how the composition of drugs in the partitioning process (hence the chemical diversity and structural variation in the data) could affect the trained model.

Assessing sensitivity to data with k-fold cross-validation. The sets of ROC (left) and PR curves (right) of five different cross-validation datasets demonstrate the role of chemical diversity in training the model. The purpose is to estimate the expected level of fit and errors to independent datasets. PR curves assume a threshold value that decreases from left to right. On the far left, the thresholds were so high that only a few FPs and TPs existed. While defining precision as TP / (TP + FP), a difference of 1 TP could change precision very much. In the extreme cases, the thresholds were so high that there was no TP (= 0), and the precision would be 0 (in CV-dataset 2, 3 and 5). Hence, we observe the volatility in those high-threshold regions.

Assessing drug–drug similarity in partitioning for the model data and CV-1 to CV-5. The heatmaps exhibit the drug-drug structural similarity (or chemical diversity) of the model dataset and the five different cross-validation datasets, corresponding to table 3. Each of them shows how similar are the distributed antiviral drugs across the training, validation and testing data. A triangle shows drugs’ similarity within a partition. A rectangle shows drugs’ similarity across partitions. The purpose is to demonstrate the role of chemical diversity in model training. Hence, we observe the power of the model to learn the drugs’ properties in the context of viral diseases without using their information on structural similarity.

## Section: Discussion

This study aimed to overcome the challenge of limited knowledge on antiviral drugs by transforming the problem into a supervised classification model, with an unconventional data stratification. The model learned latent features from the InChI and FASTA representations and predicted the drug effectiveness without prior knowledge of the binding specificity. Its principle is partly similar to the gene set enrichment analysis in trying to extract biological insight from genomic data to identify groups of genes that share common biological functions or biological pathways [79]. However, the method presented here has merits over the conventional method by eliminating the need for explicitly identified gene sets and their expression profiles; thus, even non-coding regions could be taken into consideration in the analysis process.

From the therapeutic perspective, this study focused on the eventual outcome of a drug’s effectiveness on viral disease. The model learned important characteristics based on the InChI and FASTA representations by a deep learning technique called end-to-end learning. However, the learned latent features remain unexplained. It inherited a limitation from deep learning, that it did not show how and what specific genes are expressed, or regulated. It only predicted the eventual outcome from its learned latent knowledge, which presumably related to the common patterns of gene expression and interactions. A drug might work in various ways: say, directly interfere with the viral pathogenicity by docking on the viral genes just as theories of thermodynamics and kinetics on binding site postulate [80]; or indirectly, by modifying the precondition of the cell complex or proteins, repressing the virus–receptor interactions at the cell membranes, working on the functional properties of a virus spike protein [7], or interdicting the initiation of transcription process (or any stage of the gene expression) of the virus within a cell [81].

This study proposed a different approach from the target-based paradigm. It exploited automatic feature extraction by deep learning to avoid the difficulties of incomplete information about the actual molecular interactions, that the target-based paradigm has to cope with. Thus, this phenotypic approach could explore complex biological mechanisms that are otherwise inaccessible, due to complexities such as interferences by overlooked exons or hidden binding pockets, functions of recoded stop codons or regulators, and structural entanglement factors. Biological mechanisms were captured in the latent space. Compared to similar approaches in the literature, the network-based approach yielded around 70% accuracy for identification of well-known drug indications [49]. By using transcriptomic signatures or integrating chemical-chemical interactions and drug similarities to predict the anatomical therapeutic chemical drug class with machine learning methods, an accuracy around 75% can be obtained [82]. More recently, feature selection techniques for treatment prediction, with a random forest classifier, could yield as high as 89% in AUC [83]. Compared with these, the results of this study suggest that learned latent features with whole-genomic information were valuable for predicting drug effectiveness. However, the model could not rediscover some drugs when the number of cases was small. This is a common limitation of the deep learning approach [84]. While this approach seems feasible, it supplements the toolset in metabolomics [85] and calls for more comprehensive data collection in the research community. It also contributes to the literature on whole-genome analysis in the drug discovery context.

The results also provided some interesting insights into the drug–virus interactions. The analysis strategy did not differentiate between DNA and RNA viruses when GenBank documents RNA viruses in DNA format: the base uracil (U) is represented by thymine (T). Although such difference is obsolete after RNA synthesis, single-stranded RNA chains usually fold up into more complex shapes. Nevertheless, this did not seem to affect the latent interaction search, as the folding structures did not pose a problem in the latent space. This may also imply that the drug effectiveness might be more associated with gene expression after transcription than with direct molecular binding. This supports the idea of investigating drug working mechanisms from the gene expression perspective. It also suggests that investigating molecular pathology in the latent space is viable, given sufficient structural and genetic variations and chemical diversity. The result may extend and support rational drug design.

This study also did not consider genotype or epigenetics, which may alter virus gene expression and drug interaction. The variability includes enzymes and other intra-cellular factors, like catalysts [86], polymerases, cytochrome inhibitors or inducers [87]. Despite the significant roles of accessory proteins for transcription initiation and regulation, which might be prime antiviral drug targets [88], the current framework disregarded those transcription factors. This study only presented a simplified picture of the drug–virus interaction. However, the results are considerably higher in prediction accuracy when compared to similar approaches like the network-based approach or drug similarities as discussed above. It demonstrated that the simplification was acceptable. With more clinical data, future models may uncover more details about the interaction.

This study proposed an alternative approach to the popular target-based paradigm. It demonstrates the potential of using the latent features and interaction searches for phenotypic drug discovery. While this framework can be extended to study more complex biochemical and phenotypic processes, such as epigenetics or drug synergism, the post hoc analysis revealed how chemical diversity in data distribution could affect the model performance and generalization. This study thus highlights some limitations and implications of the phenotypic drug discovery approach that researchers should be aware of. Also, other deep learning techniques may also be applicable. This study informs future research on the feasibility and challenges of using deep learning for antiviral drug discovery.

## Section: Acknowledgements

The author thanks the anonymous reviewers and the editors for their patience, comments and suggestions on the manuscript. The author also thanks a certified data science professional in SAS@ data mining and Oracle@ database management, Mr. Frankie Fong for his assistance in the implementation and testing stages. This work is impossible without his help.

## Section: Ethics

This work did not require ethical approval from a human subject or animal welfare committee.

## Section: Data accessibility

The datasets for training, together with the results that support the findings of this study are available at https://figshare.com/s/bd39a827c4bdf2b4a7c2 and [89].

Supplementary material is available online [90].

## Section: Declaration of AI use

I have not used AI-assisted technologies in creating this article.

## Section: Authors’ contributions

T.W.B.Y.: conceptualization, data curation, formal analysis, investigation, methodology, validation, writing—original draft, writing—review and editing.

## Section: Conflict of interest declaration

I declare I have no competing interests.

## Section: Funding

This study did not receive any external funding support. The author covered all costs associated with the research, including the equipment and adminstration.

## Section: Associated Data › Data Availability Statement

The datasets for training, together with the results that support the findings of this study are available at https://figshare.com/s/bd39a827c4bdf2b4a7c2 and [89].

Supplementary material is available online [90].


---

# A physics-aware neural network for protein-ligand interactions with quantum chemical accuracy

- **Authors:** Zachary L Glick, Derek P Metcalf, Caroline S Glick, Steven A Spronk, Alexios Koutsoukas, Daniel L Cheney, C David Sherrill
- **Issuer:** Chemical science
- **Type:** Scientific article
- **Published:** 2024-07-24
- **Language:** en
- **DOI:** 10.1039/d4sc01029a
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39183910/
- **Licence:** CC-BY-NC

## Section: Abstract

Quantifying intermolecular interactions with quantum chemistry (QC) is useful for many chemical problems, including understanding the nature of protein–ligand interactions. Unfortunately, QC computations on protein–ligand systems are too computationally expensive for most use cases. The flourishing field of machine-learned (ML) potentials is a promising solution, but it is limited by an inability to easily capture long range, non-local interactions. In this work we develop an atomic-pairwise neural network (AP-Net) specialized for modeling intermolecular interactions. This model benefits from a number of physical constraints, including a two-component equivariant message passing neural network architecture that predicts interaction energies via an intermediate prediction of monomer electron densities. The AP-Net model is trained on a comprehensive dataset composed of paired ligand and protein fragments. This model accurately predicts QC-quality interaction energies of protein–ligand systems at a computational cost reduced by orders of magnitude. Applications of the AP-Net model to molecular crystal structure prediction are explored, as well as limitations in modeling highly polarizable systems.

## Section: Introduction

Non-covalent interactions (NCIs) play a key role in the chemical sciences. Although they are weaker than covalent bonds, the presence (or absence) of NCIs can have profound effects on chemical and biomolecular systems. For example, NCIs drive DNA intercalation—the insertion of a molecule between consecutive DNA base pairs—which is the mechanism of action in anti-cancer drugs such as doxorubicin.1,2 Not only can an understanding of NCIs provide mechanistic insights into intercalation and other small molecule binding modes, careful consideration of NCIs allows one to control the selectivity of reaction catalysts,3 enhance electrochemical reaction kinetics,4 or optimize the properties of nanostructures.5

NCIs play a particularly important role in small molecule drug design. The efficacy of a drug depends in part on the presence of strong interactions with the target protein. Often, preliminary drug design efforts produce a promising but sub-optimal “lead” compound. This lead compound is then iteratively revised in an attempt to enhance desired properties. Maximizing favorable intermolecular contacts is a critical aspect of the lead optimization process, and can be aided by in silico models of NCIs.

The strength of a protein–ligand interaction can be rigorously quantified by using the tools of quantum chemistry to compute an interaction energy. Quantum chemistry methods, which seek to solve the many-body Schrödinger equation, are subject to a well-established trade-off between computational cost and accuracy. Highly accurate interaction energies can be obtained from wavefunction-based methods such as coupled cluster (CC) theory, but such calculations are often too expensive for all but the smallest systems. Less expensive methods like density functional theory (DFT) yield slightly less robust interaction energies. Simple, transferable force fields like GAFF are orders of magnitude faster than any quantum chemistry method, but force field interaction energies are only semi-quantitatively accurate.

One quantum chemistry method of particular interest for studying protein–ligand interactions is symmetry-adapted perturbation theory (SAPT), which yields not only an interaction energy, but also its physically meaningful components: electrostatics, exchange-repulsion, induction/polarization, and London dispersion.6–8 These components provide additional insight to help understand non-covalent interactions.9 The fragment-based partitioning of SAPT10 was used to understand substituent effects in protein–ligand interactions in factor Xa inhibitors.11 However, models of the protein including only nearby residues (∼200 atoms) still required many hours of CPU time for the SAPT computations.

Recently, advances in machine learning (ML) have led to the re-evaluation of this classic cost-accuracy trade-off. Models like neural networks (NNs) are capable of expressing arbitrarily complicated non-linear functions such as molecular potential energy surfaces.12–16 Large datasets of quantum chemical computations17–20 make it possible to parameterize general atomistic NN potentials to quantum chemical accuracy,21–23 and these potentials can be evaluated at near force field computational cost. NN potentials can be used to improve the accuracy of costly alchemical free energy predictions24 or to perform reactive molecular dynamics simulations.25

The emergence of NN potentials has also benefited from a number of architectural developments. The “message passing” NN (MPNN) framework is tailored to the graph-like structure of molecular geometries.26 Directional MPNNs additionally account for the relative orientation between neighboring atoms in a molecule. The most data-efficient architectures achieve this by employing locally equivariant representations of atoms in molecules.27–33 In these equivariant models, atomic environments are represented as tensorial quantities which rotate with the local coordinate frame.

The locality of atomic environments used in NN potentials allows these models to easily describe local interactions, which include distortions of bonds, angles, and dihedrals, as well as short-range non-covalent interactions. Unfortunately, a consequence of this locality is that NN potentials are either indirectly or explicitly unable to model the long-range interactions that are essential to protein–ligand interactions.34 The lack of these long-range effects has been demonstrated to affect the quality of simulated properties of bulk water and small peptides,35 and many ML methods have been developed to capture these long-range interactions.36–38 In a recent work, we proposed an atomic-pairwise NN framework for modeling NCIs, which we called AP-Net.34 Extending this basic proof-of-concept, we now develop a robust, chemically accurate AP-Net model for quantifying arbitrary protein–ligand interactions. This is accomplished by constraining the AP-Net architecture to respect the known physics of intermolecular interactions.

## Section: Results › A physics-aware intermolecular architecture

In this work, we develop a physics-aware neural network architecture specialized for modeling intermolecular interactions. This architecture adheres to four physical principles:

1. Intermolecular interactions are fundamentally a function of molecular properties, some of which, such as the electron density, can be partitioned into atomic properties.

2. For the most part, intermolecular interactions are atomic-pairwise additive.

3. Intermolecular interactions are decomposable into different types of interactions (electrostatics, exchange-repulsion, induction/polarization, and dispersion).

4. In the dissociative limit, intermolecular interactions obey simple functional forms of molecular and atomic properties and smoothly decay to zero.

In reference to the second principle, this physics-aware architecture is designated AP-Net, short for atomic-pairwise neural network. The AP-Net name was first used in a previous proof-of-concept study that differs significantly from the current work in applicability and complexity.34 The previous AP-Net architecture shares the general paradigm of predicting interaction energies in an atomic-pairwise framework, but the previous model was limited by simple, ad hoc atomic feature vectors whereas the model described in this work featurizes atom pairs with an equivariant MPNN (Section 2.1.2). The current AP-Net model is additionally differentiated by the inclusion of an electrostatic force field, a related atomic property module (Section 2.1.1), and a much larger, more diverse training set (Section 2.2).

A schematic of the current AP-Net architecture is provided in Fig. 1. AP-Net enforces the four physical principles above via a pair of independently trained NNs, which are respectively referred to as the atomic property module and the interaction energy module. These two NNs are used to predict protein–ligand interaction energies through an intermediate prediction of the electron density of both molecules via an atom-centered multipole expansion. This physically motivated functional form yields accurate, generalizable interaction energy predictions for protein–ligand systems.

## Section: Results › A physics-aware intermolecular architecture › Atomic property module

The atomic property module (Fig. 1A) is trained to predict properties of an atom within a molecule, in accordance with the first principle. Specifically, this network predicts an atomic decomposition of the electron density in the form of an atom-centered multipole expansion through second order. The atomic property module is related to our previous Cartesian MPNN (CMPNN), which was also used to predict atomic multipoles.39 Unlike the original CMPNN model, in which predicted atomic multipoles were approximately rotationally equivariant, the atomic property module enforces rigorous rotational equivariance via the directional hidden state scheme of ref. 27. In this scheme, the hidden state vectors have an additional Cartesian dimension, along which equivariance is preserved by a carefully designed message and update function. The atomic property module also conserves the total molecular charge, allowing the model to handle neutral molecules and ions alike.40

## Section: Results › A physics-aware intermolecular architecture › Interaction energy module

The second neural network constituting AP-Net, the interaction energy module (Fig. 1B), is an equivariant graph neural network trained to predict the interaction energy of a molecular dimer. This interaction energy is predicted as a sum of atom-pair contributions. Rather than directly predict the total interaction energy, this module predicts the symmetry-adapted perturbation theory (SAPT) decomposition of the interaction energy into its components of electrostatics, exchange, induction, and dispersion. The interaction energy module architecture is described in detail in Section 3.1.2.

Most notably, instead of operating on only the dimer geometry, the interaction energy module operates on the output of the atomic property module—atom-centered multipoles through second order and hidden-state vectors encoding atomic environments—evaluated separately for each monomer. The output of the atomic property module is used by the interaction energy module in two ways. First, the learned representation of each atomic environment from the atomic property module is incorporated into the corresponding atomic environment in the interaction energy module. This shared representation allows the interaction energy module to indirectly utilize the monomer data used to train the atomic property module. Second, the predicted atomic multipoles of the atomic property module are used to evaluate a multipolar electrostatic energy. The interaction energy module is then trained to predict the interaction energy as a correction on top of the multipolar electrostatic energy. Because the multipolar electrostatic energy captures the leading long-range behavior of intermolecular interactions, the interaction energy module is effectively limited to predicting a much more local, medium- and short-range quantity.

This strategy of combining two different methods is similar to the correction-based concept of Δ-learning, in which one reformulates a regression task as a small predicted correction on top of a computationally affordable baseline result.41 However, unlike conventional Δ-learning use cases in quantum chemistry, the baseline model, multipole electrostatics via predicted multipoles, is as computationally affordable as the machine learning correction.

## Section: Results › Systematically-generated protein–ligand interactions

The Splinter dataset42 is a collection of approximately 1.7 million systematically generated protein–ligand fragment dimers and interaction energies computed using many-body SAPT based on a Hartree–Fock (HF) representation of monomers (i.e. SAPT0). These and all other SAPT computations carried out in this work are performed in an aug-cc-pV(D+d)Z basis set (abbreviated aDZ), which yields good error cancellation.43 The construction of this dataset is illustrated in Fig. 2A. The Splinter dimers are not only chemically diverse, they also were intentionally generated in variety of repulsive, optimized, and dissociated configurations. Consequently, the interaction energies associated with the Splinter dimers span a range of over 500 kcal mol−1.

A large fraction of the Splinter dataset was used to train the interaction energy module of the AP-Net model. The performance of AP-Net on 150K held-out validation dimers, which were not used to fit the model, is shown in Fig. 2B. AP-Net predicts the SAPT interaction energies with a mean absolute error (MAE) of only 0.20 kcal mol−1 and a maximum error of less than 15 kcal mol−1. The interaction energy of over 97% of the validation dimers is predicted within 1 kcal mol−1, a metric commonly referred to as chemical accuracy.44 The individual SAPT components of the interaction energy are predicted with even greater accuracy than the total interaction energy. As observed in previous efforts to predict the SAPT decomposition with ML models, errors in electrostatics and exchange are largest, followed by induction, and then dispersion.34,45 Dispersion is predicted particularly accurately, with a MAE of only 0.02 kcal mol−1. It should be noted that the error in this prediction is much smaller than errors inherent in the SAPT0 approximation or even the choice of finite basis set.

## Section: Results › Crystallographic protein–ligand interactions

The ultimate goal of the AP-Net intermolecular potential is to accurately predict interaction energies of realistic models of protein–ligand systems. Therefore, it would not be sufficient to only evaluate the model on dimers sampled from Splinter, which are procedurally generated and come from the same chemical space as the training data. For this reason, we developed a more diverse, realistic dataset of dimers, referred to as SAPT-PDB-13K. The 13 216 dimers in SAPT-PDB-13K consist of an entire ligand interacting with one or two capped amino acids. The protein and ligand geometries are taken from crystallographic Protein Data Bank (PDB) entries, making them meaningful and practical test cases. An illustrative dimer from the SAPT-PDB-13K dataset is shown in Fig. 3.

The diversity of the SAPT-PDB-13K dataset makes it a useful test of AP-Net's generalization ability. Compared to the Splinter dataset, SAPT-PDB-13K contains different, larger ligands that span more charge states. Regardless, Fig. 4 shows that AP-Net still accurately predicts the SAPT0 interaction energy decomposition with a MAE of 0.74 kcal mol−1. In many ways, the prediction errors on the SAPT-PDB-13K dimers resemble the prediction errors on the held-out Splinter dimers. One notable difference is in the prediction of the SAPT induction term. Interestingly, the induction MAE is larger relative to the other three SAPT components. It is also apparent from Fig. 4 that the predicted induction energies have a slight positive bias for dimers with large, negative induction energies. This observation is in line with the fact that induction is an inherently many-body phenomenon, in contrast to the atomic-pairwise additivity of AP-Net.46 The many-body nature of induction—which can be thought of as mutual polarization between three or more atoms combined with charge transfer—becomes apparent in a few SAPT-PDB-13K dimers that contain strongly interacting di- and tri-anions.

## Section: Results › Relative interaction energies

AP-Net's performance on the Splinter and SAPT-PDB-13K datasets demonstrates the model's ability to accurately predict interaction energies (ΔEint) of protein–ligand systems. A derived quantity of interest is the relative interaction energy (ΔΔEint), defined as the difference in interaction energies between two related dimers, such as those that differ by a change in a single functional group. An example experiment is illustrated in Fig. 5. Such single-point alchemical computations may be used to guide the drug design process.

The results of nine ΔΔEint experiments are listed in Table 1, and a breakdown by SAPT component is included in the ESI.† In each experiment, the ΔΔEint of two related protein–ligand dimers is calculated using both SAPT and AP-Net. Each pair of dimers is constructed from an initial protein–ligand complex, taking a portion of the ligand and its surrounding protein environment.47 The second dimer of each pair is characterized by a change in a ligand functional group. In seven of the nine pairs, a chlorine is replaced with a methyl group, and in 2O7N, a cyano group is replaced with a bromine. The ligands of the 2Y5G/2Y5H matched pair differ by a heterocycle rotation rather than an atomic substitution. In all nine computational experiments, the sign of the AP-Net ΔΔEint matches the sign of the SAPT-computed ΔΔEint, meaning the AP-Net interaction energies are accurate enough to predict whether each functional group substitution stabilized or destabilized the protein–ligand interaction. SAPT0 computations on some of these complexes (∼200 atoms) required as much as 1.5 days or more, running on 12 cores, while the AP-Net computations ran in a few seconds each. This makes in silico ligand design experiments of this type (with quantum-mechanical accuracy) now feasible for routine and easy use.

## Section: Results › Transfer learning to gold standard quantum chemistry

The SAPT0/aDZ level of theory used in the Splinter dataset has been extensively benchmarked and strikes a good balance between computational cost and accuracy.43 A more accurate level of theory is coupled cluster with singles, doubles, and perturbative triples [CCSD(T)]48 in the complete basis set (CBS) limit. CCSD(T)/CBS is often referred to as the “gold standard” in quantum chemistry because of its reliability. Ideally, the AP-Net model would be trained on CCSD(T)/CBS interaction energies for the Splinter dimers, but the steep scaling of this method makes obtaining many such high-quality interaction energies prohibitively expensive. An appealing solution from the field of machine learning is the process of transfer learning, in which one leverages data associated with one task (predicting SAPT0/aDZ interaction energies) to improve performance at some other similar, usually data-limited task (predicting CCSD(T)/CBS interaction energies).49 Generally, transfer learning is realized by initially training some NN model on the first large dataset, and then re-training the same model on the smaller, relevant dataset. This approach has been successfully used in the development of atomic potentials.50

A transfer learning experiment was performed to assess the practicality and data requirements of training a CCSD(T) quality AP-Net intermolecular potential. This experiment was performed with the DES370K dimer dataset.20 DES370K is similar to the Splinter dataset in that it contains many small molecule dimers. Unlike Splinter, DES370K contains interaction energies computed at the CCSD(T)/CBS level of theory. Two separate “AP-Net-CC” models were trained on the DES370K dataset to predict CCSD(T)/CBS interaction energies. These models are referred to as AP-Net-CC to differentiate them from the standard AP-Net model, which is fit to the SAPT decomposition. Because AP-Net is constructed to separately predict the four SAPT interaction energy components, all AP-Net-CC models are trained so that the sum of the four predicted components matches the CCSD(T)/CBS interaction energy. Therefore, any AP-Net-CC model lacks the interpretability of an AP-Net model trained to predict the SAPT decomposition. As a baseline, the first AP-Net-CC model was constructed with randomly initialized weights in the interaction energy module. The second “pre-trained” AP-Net-CC model was constructed with interaction energy module weights taken from the original AP-Net model. Both AP-Net-CC models used the same frozen atomic property module as the original AP-Net model.

The accuracy of the two AP-Net-CC models as a function of the amount of DES370K training data is shown in Table 2. The pre-trained AP-Net-CC model outperforms the baseline AP-Net-CC model, particularly in the low data regime. At 100 training data points, transfer learning results in a nearly four-fold error reduction (from 1.91 kcal mol−1 to 0.48 kcal mol−1). The accuracy of a pre-trained AP-Net-CC model with only 100 training data points is similar to that of a baseline AP-Net-CC trained on a few thousand data points. Transfer learning provides diminishing returns when more CCSD(T)/CBS data is available. The pre-trained model is nearly equivalent to the baseline model when 50K training points are used. These results demonstrate that transfer learning is an economical approach for leveraging the original AP-Net model, which was trained on the SAPT decomposition of over 1.5 M dimers, to predict interaction energies at more computationally expensive levels of theory. A minimal amount of expensive, high accuracy CCSD(T)/CBS data is required to fine-tune AP-Net from SAPT to this gold standard quantum chemistry method.

## Section: Results › Predicting interaction energy surfaces

The transfer learning approach applies not just between different levels of quantum chemical theory, but also between different regions of chemical space. In particular, one might want to repurpose the AP-Net potential, which is parameterized to model protein–ligand interactions in general, into an interaction energy model specialized for a particular dimer, which may not even be a protein–ligand system. To explore the usefulness of such a model, we examined the performance of the previously described AP-Net-CC models on the interaction energy surface of the hydrogen-bonded N-methylacetamide (NMA) dimer. This dimer is a model system for peptide bonding. SAPT0/aDZ and CCSD(T)/CBS interaction energies were computed along a two-dimensional scan of the intermolecular hydrogen bond length and angle of this dimer. The intermolecular O⋯H bond length was varied from 1.5 Å to 3.0 Å in 0.1 Å increments and the intermolecular O⋯ HN bond angle from −90° to +90° in 1.5° increments. Fig. 6 shows these reference interaction energy surfaces compared to predictions of the AP-Net and two AP-Net-CC models. An additional one-dimensional visualization of this surface is available in the ESI.† The computed SAPT0/aDZ and CCSD(T)/CBS surfaces differ by a small amount: the SAPT0/aDZ surface is overall lower in energy than the gold standard reference method, with a minimum energy of −8.43 kcal mol−1 at a hydrogen bond length of 2.0 Å. The CCSD(T)/CBS surface has a minimum energy of −7.28 kcal mol−1 at 2.0 Å.

The AP-Net predicted surface agrees with with the reference SAPT surface. This is expected given the quantity and diversity of data used to train the model. The baseline AP-Net-CC model trained on only 100 data points poorly predicts the CCSD(T)/CBS surface. This predicted interaction energy surface lacks both a repulsive wall and a reasonable minimum. However, using the same 100 points to repurpose the AP-Net model to the CCSD(T)/CBS theory with transfer learning results in an excellent prediction of the interaction energy surface. It's particularly notable that these 100 dimers are randomly selected from the DES370K dataset, and do not include NMA.

## Section: Results › Ranking molecular crystal polymorphs

Intermolecular interactions largely govern the structure of molecular crystals and other clusters, making these systems a promising application of AP-Net outside of protein–ligand interactions. A vast majority of molecular crystals are polymorphic, meaning that they can exist in multiple stable crystalline forms, with potentially different physical properties like density, solubility, hygroscopicity, melting point, etc.51 In drug development, thoroughly determining all polymorphs of a drug candidate is a necessary procedure that is routinely guided by computation. A common crystal structure prediction (CSP) task is to screen and rank the most energetically stable putative polymorphs of a target molecule.52 Using the many body expansion (MBE), the energy of a crystal lattice can be recast as approximately a sum of many dimer interaction energies.53 This two-body contribution to the crystal lattice energy, hereafter referred to as the crystal lattice energy, can therefore be computed with any quantum chemistry method used for interaction energies or predicted with AP-Net. Note that polymorph ranking must also account for monomer strain, zero-point vibrational energy, and finite temperature and pressure.54

We performed a preliminary experiment to assess AP-Net at ranking polymorphs of the 5-fluorouracil crystal. 61 low-lying 5-fluorouracil crystal structures, one of which is the experimentally observed form II, were taken from the work of Price.55 The CrystaLattE program53 was used to reduce each crystal structure into a set of unique dimers, from which the crystal lattice energies were computed at the SAPT0/aDZ level of theory and predicted with AP-Net. An intermolecular closest contact cutoff of 15 Å was used to generate the dimers. The computed and predicted crystal lattice energies are compared in Fig. 7. Importantly, AP-Net reproduces the approximate ranking of the polymorphs. Form II is correctly predicted to be among the lowest energy structures. The AP-Net ranking of form II happens to be slightly better than that of SAPT0/aDZ due to fortuitous errors in the interaction energies. The MAE of the AP-Net predicted crystal lattice energies relative to SAPT0 is 1.18 kJ mol−1, which is smaller than the disagreement between many quantum chemistry methods.56 Note that this result is in spite of the fact that AP-Net was trained specifically on protein–ligand data, not 5-fluorouracil homodimers or even ligand–ligand dimers.

The 61 AP-Net crystal lattice energy predictions required less than two CPU minutes, a nearly 30 000-fold savings over the corresponding SAPT0/aDZ cost of 980 CPU hours. Because the cost of quantum chemistry computations scales poorly with system size, AP-Net predicted crystal lattice energies of a larger drug-like molecule would result in even more pronounced savings relative to SAPT0/aDZ.

## Section: Materials and methods › Implementation

The AP-Net model was implemented using version 2.3 of the TensorFlow Python package.57 The implementation and architectural details of the two constituent modules of the AP-Net model are described below.

## Section: Materials and methods › Implementation › Atomic property module

The atomic property module predicts charges, dipoles, and Cartesian quadrupoles of all atoms in a molecule from the identities and coordinates of the atoms and the total charge of the molecule via an equivariant MPNN. Reference and predicted multipoles are written as (q, μ, θ) and (q̂, <svg xmlns="http://www.w3.org/2000/svg" version="1.0" width="12.000000pt" height="16.000000pt" viewBox="0 0 12.000000 16.000000" preserveAspectRatio="xMidYMid meet"><metadata> Created by potrace 1.16, written by Peter Selinger 2001-2019 </metadata><g transform="translate(1.000000,15.000000) scale(0.012500,-0.012500)" fill="currentColor" stroke="none"><path d="M480 1080 l0 -40 -40 0 -40 0 0 -40 0 -40 -40 0 -40 0 0 -40 0 -40 40 0 40 0 0 40 0 40 40 0 40 0 0 40 0 40 40 0 40 0 0 -40 0 -40 40 0 40 0 0 -40 0 -40 40 0 40 0 0 40 0 40 -40 0 -40 0 0 40 0 40 -40 0 -40 0 0 40 0 40 -40 0 -40 0 0 -40z M320 720 l0 -80 -40 0 -40 0 0 -120 0 -120 -40 0 -40 0 0 -120 0 -120 -40 0 -40 0 0 -80 0 -80 40 0 40 0 0 80 0 80 40 0 40 0 0 40 0 40 120 0 120 0 0 40 0 40 40 0 40 0 0 -40 0 -40 40 0 40 0 0 40 0 40 40 0 40 0 0 40 0 40 -40 0 -40 0 0 -40 0 -40 -40 0 -40 0 0 80 0 80 40 0 40 0 0 120 0 120 40 0 40 0 0 40 0 40 -40 0 -40 0 0 -40 0 -40 -40 0 -40 0 0 -120 0 -120 -40 0 -40 0 0 -80 0 -80 -120 0 -120 0 0 40 0 40 40 0 40 0 0 120 0 120 40 0 40 0 0 80 0 80 -40 0 -40 0 0 -80z"/></g></svg> , <svg xmlns="http://www.w3.org/2000/svg" version="1.0" width="11.333333pt" height="16.000000pt" viewBox="0 0 11.333333 16.000000" preserveAspectRatio="xMidYMid meet"><metadata> Created by potrace 1.16, written by Peter Selinger 2001-2019 </metadata><g transform="translate(1.000000,15.000000) scale(0.011667,-0.011667)" fill="currentColor" stroke="none"><path d="M560 1160 l0 -40 -40 0 -40 0 0 -80 0 -80 40 0 40 0 0 80 0 80 40 0 40 0 0 -80 0 -80 40 0 40 0 0 80 0 80 -40 0 -40 0 0 40 0 40 -40 0 -40 0 0 -40z M320 840 l0 -40 -40 0 -40 0 0 -80 0 -80 -40 0 -40 0 0 -80 0 -80 -40 0 -40 0 0 -200 0 -200 40 0 40 0 0 -40 0 -40 160 0 160 0 0 80 0 80 80 0 80 0 0 120 0 120 40 0 40 0 0 160 0 160 -40 0 -40 0 0 40 0 40 -40 0 -40 0 0 40 0 40 -120 0 -120 0 0 -40z m240 -80 l0 -40 40 0 40 0 0 -80 0 -80 -40 0 -40 0 0 -40 0 -40 -160 0 -160 0 0 80 0 80 40 0 40 0 0 80 0 80 120 0 120 0 0 -40z m0 -440 l0 -80 -40 0 -40 0 0 -40 0 -40 -40 0 -40 0 0 -40 0 -40 -120 0 -120 0 0 160 0 160 200 0 200 0 0 -80z"/></g></svg> ) respectively.

The initial environment of atom i in the MPNN is a simple mapping or embedding of the integer nuclear charge (Zi) to a vector (h0i) as was proposed in SchNet.22 The mappings are generated at uniform random for all Z corresponding to atomic elements of interest: H, C, N, O, F, Na, P, S, Cl, and Br. An edge between atoms i and j exists if the distance between the atoms is less than a cutoff distance, rc, which is set to 5.0 Å. The edge feature vector eij, is a simple encoding of the scalar distance |rij| using a set of Bessel functions as described in the work of Gasteiger, et al.:321eij = [eij,1,…,eij,N],2The message sent from atom i to atom j at time step t ≥ 0 is an outer product between concatenated hidden state vectors and the edge vector:3mijt = (h0i, hit, h0j, hjt) × (1, eij).The total, directionless message received by atom i at time-step t is a sum over individual messages from all neighbors j:4and this quantity is used to update the total, directionless hidden state of atom i:5hit+1 = Ut(mit),where Ut is a dense, feed-forward neural network. The predicted charge of atom i, q̂i is determined from the hidden states through all T time steps and a set of dense, feed-forward neural networks:6We set T = 3 in this work.

The displacement vector and displacement unit vector between atoms i and j are simply:7rij = rj − ri,8A directional hidden state, xit, for predicting atomic dipoles is determined, analogous to charges:9using a directional update function, D. Note that D itself has no directional properties as it operates on the rotational invariant (mij). The functional is named so because it is used to predict a directional hidden state, xti which differs from hit in that is has an additional Cartesian dimension. The Cartesian dimension of the directional hidden state inherits the rotational equivariance of the displacement vector r̂ij, which is then used to predict a rotationally equivariant dipole vector:10The dipole readout function Rμt is made to be a simple linear layer. This ensures rotationally equivariant atomic dipoles; a readout function with non-linearites, such as a dense feed-forward neural network, would not preserve the equivariance of the hidden state vector xit. Also, the dipole hidden state at t = 0 isn't incorporated into the readout because a non-interacting atom has no dipole. Quadrupoles are predicted analogously to dipoles, with separate quadrupole hidden states, update functions, and readout functions.

Lastly, the network architecture enforces conservation of total molecular charge, Q:11and also that the Cartesian quadrupoles are symmetric and traceless:1213

## Section: Materials and methods › Implementation › Interaction energy module

The interaction energy module predicts the SAPT decomposition of the interaction energy (electrostatics, exchange, induction, and dispersion) from a molecular dimer, which consists of two sets of atomic identities and coordinates and two molecular charges. The characters a, a′, b, and b′ will be used to index atoms in monomers and , respectively. The interaction energy components are predicted through learned, intermolecular, atomic-pairwise partition:14

The interaction energy module uses an MPNN architecture similar to that of the atomic property module. Specifically, the message and update functions in this module are identical, but have different weights.151617hat+1 = Ut(mat).In addition to the rotational invariant hidden state vector , a directional, rotationally equivariant hidden state vector is also updated throughout the message passing:18using another feed-forward neural network, Dt. The hidden states from each iteration are concatenated, and a pair feature vector is then created from all hidden state vectors for each intermolecular (a, b) pair:19ha = (h0a,…,haT),20xa=(x0a,…,xTa),21pab = (q̂a, q̂b, ha, hb, r̂ab·xa, r̂ba·xb).Note that this pair feature vector uses the predicted atomic charges from the atomic property module, which is separately applied to both monomers in the dimer. Also, the rotationally equivariant vectors x are incorporated in a rotationally invariant way by projection onto the intermolecular unit vector. Four dense feed-forward NNs are used to predict the four SAPT components from the pair feature vectors:22Eab,comp = |rab|−p[Rcomp(pab) + Rcomp(pba)],where comp is one of the four SAPT components (electrostatics, exchange, induction, dispersion). The pair energies are inversely scaled by the interatomic distance raised to the p power, where p is fixed at 3 across all interaction types; the key consideration was to enforce asymptotic decay of the interaction energy. The output is also symmetrized over the order of the two atoms. Finally, in the case of electrostatic energies, the neural network predictions are corrections on top of multipolar (mtp) electrostatics computed from the charges, dipoles, and quadrupoles predicted by the atomic property module:23Eab,elst ← Eab,elst + Eab,mtp.

The predicted interaction energy, though defined as a sum of atom-pair interaction energies, is still a many-body quantity (where “body” refers to atoms). This is a consequence of using a MPNN to featurize each atom with its local atomic environment. In contrast, AP-Net produces a strictly two-body dimer interaction energy (where “body” refers to molecules).

## Section: Materials and methods › Training data and procedure

The AP-Net model is trained in a two step procedure. All code used to train this model is present in the AP-Net GitHub repository.58 First, the atomic property module is trained on a dataset of molecular monomers and computed atomic multipoles. This was done with our previous dataset of 46 623 mostly drug-like fragments and corresponding atomic multipoles computed from HF/cc-pVDZ wavefunctions and partitioned with the minimal basis iterative stockholder (MBIS) scheme.59 Because the dataset lacks non-neutral monomers and monomers representing protein systems, it was further expanded to include monomers present in the Splinter dataset. 6550 additional computations were performed on randomly selected monomers from the Splinter dataset, totaling 53 173 monomers. The 53 173 monomers were then randomly split into training and validation subsets of 47 855 and 5318 monomers.

The atomic property module was constructed with three message passing iterations. Each dense feed-forward neural network in the module is composed of three hidden layers with 256, 128, and 64 neurons. The ReLU activation function is applied after each hidden layer, followed by an appropriately sized linear operation after the last hidden layer. The edge feature vectors are constructed from 8 Bessel functions and a radial cutoff of 5 Å. Training was performed to minimize the sum of the mean squared errors of the atomic charges, dipoles, and quadrupoles:24where a indexes atoms in a batch of molecules. The atomic property module was trained for 500 epochs with a batch size of 16 molecules. Weights were optimized with the Adam optimizer using a learning rate of 5 × 10−4. The weights of the epoch with the lowest validation MSE are used in the final AP-Net model.

In the second step of training, the interaction energy module is trained on the Splinter dimer dataset to predict SAPT decomposed interaction energies. The interaction energy module requires atomic multipoles as an input, which were obtained from the atomic property module. The architecture of the MPNN in this module is identical to that of the atomic property module. Intermolecular atom pair readouts are performed with an 8 Å cutoff. This means that the interaction energy of atom pairs within this cutoff is predicted with a full neural network inference; the interaction energy of atom pairs outside of this cutoff is only accounted for by multipolar electrostatics. The asymptotic decay coefficient (p) was set to three. Random training and validation subsets of 1.5M and 150K dimers are taken from the 1.66M dimers in the Splinter dataset. The module is optimized to minimize the MSE of the individual SAPT components:25where c is one of four SAPT components (electrostatics, exchange, induction, and dispersion) and d indexes dimers in the batch. The MPNN was trained using a batch size of 16 dimers and the Adam optimizer with a learning rate of 5 × 10−4. Training was performed for 50 epochs, and the weights of the epoch with the lowest validation MSE are used in the final AP-Net model. An ensemble of five randomly initialized AP-Net models were trained on the same data to reduce uncertainty, and all predictions presented in this work are the average prediction of the ensemble.

## Section: Materials and methods › SAPT-PDB-13K dataset preparation

The SAPT-PDB-13K test set of 13 216 dimers was prepared to consist of diverse, drug-like molecules paired with mono- and dipeptides extracted from crystallographic structures deposited in the PDB. The following procedure was followed to ensure that ligands were structurally diverse and drug-like: ligand molecules were extracted from the PDBbind 2019 refined set of 4852 complexes,60,61 imported into Maestro 2021-3,62 assigned charges and bond orders with LigPrep63 and clustered using the spectral clustering utility with default settings, which provided 133 representative ligands. An additional 600 ligands were visually selected which further added structural diversity and represented the full range of elements compatible with the AP-Net model (H, C, N, O, F, Na, P, S, Cl, and Br). The corresponding 733 PDB protein/ligand complexes were subjected to refinement using the Schrodinger Protein Prep64 tool with default settings. Dimers consisting of ligands and proximal mono- and dipeptides were created, wherein the N- and C-termini were capped with acetyl and N–Me groups, respectively. Visual inspection led to removal of erroneous structures (e.g., presence of hypervalent carbons or otherwise non-physical geometries) and duplicates. SAPT0/aug-cc-pV(D+d)Z interaction energies of the 13 216 dimers were computed with Psi4 and made available in the ESI.†

## Section: Discussion

The AP-Net potential developed in this work is a robust, physically-motivated NN intermolecular interaction model. In contrast to the many general purpose ML potentials which predict a total energy, the AP-Net potential predicts interaction energies. As a consequence of this specialization, AP-Net is constructed to adhere to known physical priors of intermolecular interactions, such as their approximate atomic pairwise nature and distance decay. An additional physical prior is captured by AP-Net's unique two-component architecture. Rather than simply predict atom-pair contributions to the interaction energy, AP-Net is constructed to predict monomer electron densities (in the form of atom-centered multipoles), evaluate a long-range electrostatic interaction energy from the predicted multipoles, and then predict atom-pair corrections to this evaluated energy.

This two-component architecture confers a number of advantages to the AP-Net model. Because of the multipolar electrostatic force field, the AP-Net model produces electrostatic interaction energies that are asymptotically exact at the target level of theory using a relatively small amount of multipole training data. An analogous pure-NN model would need to be trained on an intractable number of dimer interaction energies to reach the same level of accuracy. This case of long-range electrostatics illustrates a weakness of NN models, which is that unnecessary flexibility can be a detriment to data efficiency. AP-Net's architecture effectively limits the flexibility of the functional form at long-range where the physics is known, allowing the modeling capacity to be applied to the more difficult short-range interactions. In addition to improving the data efficiency of the model, concentrating on short-range intermolecular interactions improves the computational efficiency of the AP-Net model. Neural network inferences, which are more expensive than force field evaluations, are only required for pairs of interaction atoms within a relatively short distance threshold (8 Å).

This physically-motivated AP-Net is applied to the challenging and consequential problem of modeling protein–ligand interaction energies. A useful AP-Net model is made possible by the Splinter dataset: a comprehensive and diverse collection of 1.66M protein–ligand dimers and SAPT0 interaction energies. The trained AP-Net accurately reproduces the SAPT decomposition of interaction energies well within chemical accuracy in the great majority of cases. More importantly, generalizability to larger models of protein–ligand dimers is observed, with good agreement between AP-Net and SAPT0 for substituent effects for ∼200-atom model systems where SAPT0 results can still be obtained. While the SAPT0 computations require many hours, the AP-Net results run in seconds. These findings suggest that the AP-Net model is an immediately practical tool for drug design research when quantum-level accuracy is desired for protein–ligand interaction energies, as was helpful in previous studies by our group on factor Xa inhibitors.11

This AP-Net model is not without shortcomings. One apparent deficiency is the underestimation of strong induction interactions, which occurs for a few select realistic protein–ligand dimers of the SAPT-PDB-13K dataset. These dimers represent an edge case where the non-local, many-body nature is poorly captured by the atomic-pairwise architecture of AP-Net. Efficiently modeling this non-pairwise additivity likely requires a model architecture with an appropriate inductive bias. In the same way that the current AP-Net model fuses classical long-range multipole electrostatics with a NN-predicted short-range correction, a future AP-Net model might benefit from incorporating a classical Thole-type induction model as is done in polarizable ab initio force fields like AMOEBA.65,66 This could be incorporated by training the atomic property module to predict atomic polarizability tensors. Another potential limitation arises from using a framework of interacting monomers to predict intermolecular interaction energies. This framework is largely incompatible with reactive chemistry, where the formation or dissolution of bonds changes the definition of monomers. Modeling reactive chemistry with an intermolecular potential can be done with the empirical valence bond (EVB) approach,25,67 but it might be easier to simply train a NN potential to the total system energy.

Because of the high accuracy of AP-Net relative to SAPT0, the development of future models will likely target training data computed at a higher level of quantum chemistry theory. Additional AP-Net model development, whether targeting new levels of theory or new types of dimers, can benefit from transfer learning from the current, general, protein–ligand model. This approach greatly reduces training data requirements. Surprisingly, the protein–ligand AP-Net model can be used for modeling ligand–ligand interaction energies accurately enough to rank polymorphs of the 5-fluorouracil crystal, an application far outside of the original intention of the AP-Net model. This result illustrates one of many potential future AP-Net use cases, and it also points towards the possibility of a universal interaction energy potential.

## Section: Data availability

The AP-Net model has been trained on the Splinter Dataset (ref. 42). The remaining data supporting this article have been included as part of the ESI.† The code for AP-Net can be found at https://github.com/zachglick/apnet with DOI https://doi.org/10.5281/zenodo.11493604. The version of the code employed for this study is version 0.1.1.

## Section: Author contributions

Conceptualization: ZLG, DPM, SAS, AK, DLC, CDS. Methodology: ZLG, DPM, CSG, SAS, AK, CDS. Investigation: ZLG. Visualization: ZLG. Supervision: CDS and DLC. Writing – original draft: ZLG. Writing – review & editing: CDS, DLC, ZLG, DPM.

## Section: Conflicts of interest

There are no conflicts to declare.


---

# A Preliminary Checklist (METRICS) to Standardize the Design and Reporting of Studies on Generative Artificial Intelligence-Based Models in Health Care Education and Practice: Development Study Involving a Literature Review

- **Authors:** Malik Sallam, Muna Barakat, Mohammed Sallam
- **Issuer:** Interactive journal of medical research
- **Type:** Scientific article
- **Published:** 2024-02-15
- **Language:** en
- **DOI:** 10.2196/54704
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38276872/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackgroundAdherence to evidence-based practice is indispensable in health care. Recently, the utility of generative artificial intelligence (AI) models in health care has been evaluated extensively. However, the lack of consensus guidelines on the design and reporting of findings of these studies poses a challenge for the interpretation and synthesis of evidence.ObjectiveThis study aimed to develop a preliminary checklist to standardize the reporting of generative AI-based studies in health care education and practice.MethodsA literature review was conducted in Scopus, PubMed, and Google Scholar. Published records with “ChatGPT,” “Bing,” or “Bard” in the title were retrieved. Careful examination of the methodologies employed in the included records was conducted to identify the common pertinent themes and the possible gaps in reporting. A panel discussion was held to establish a unified and thorough checklist for the reporting of AI studies in health care. The finalized checklist was used to evaluate the included records by 2 independent raters. Cohen κ was used as the method to evaluate the interrater reliability.ResultsThe final data set that formed the basis for pertinent theme identification and analysis comprised a total of 34 records. The finalized checklist included 9 pertinent themes collectively referred to as METRICS (Model, Evaluation, Timing, Range/Randomization, Individual factors, Count, and Specificity of prompts and language). Their details are as follows: (1) Model used and its exact settings; (2) Evaluation approach for the generated content; (3) Timing of testing the model; (4) Transparency of the data source; (5) Range of tested topics; (6) Randomization of selecting the queries; (7) Individual factors in selecting the queries and interrater reliability; (8) Count of queries executed to test the model; and (9) Specificity of the prompts and language used. The overall mean METRICS score was 3.0 (SD 0.58). The tested METRICS score was acceptable, with the range of Cohen κ of 0.558 to 0.962 (P<.001 for the 9 tested items). With classification per item, the highest average METRICS score was recorded for the “Model” item, followed by the “Specificity” item, while the lowest scores were recorded for the “Randomization” item (classified as suboptimal) and “Individual factors” item (classified as satisfactory).ConclusionsThe METRICS checklist can facilitate the design of studies guiding researchers toward best practices in reporting results. The findings highlight the need for standardized reporting algorithms for generative AI-based studies in health care, considering the variability observed in methodologies and reporting. The proposed METRICS checklist could be a preliminary helpful base to establish a universally accepted approach to standardize the design and reporting of generative AI-based studies in health care, which is a swiftly evolving research topic.Keywords: guidelines, evaluation, meaningful analytics, large language models, decision support

## Section: Introduction

The integration of generative artificial intelligence (AI) models into health care education and practice holds promising perspectives with numerous possibilities for continuous improvement [1-5]. Examples of generative AI-based conversational models characterized by ease of use and perceived usefulness include ChatGPT by OpenAI, Bing by Microsoft, and Bard by Google [6-8].

The vast potential of generative AI-based models in health care can be illustrated as follows. First, generative AI-based models can facilitate streamlining of the clinical workflow, with subsequent improvement in efficiency manifested in reduced time for care delivery and reduced costs [1,9-11]. Second, generative AI-based models can enhance personalized medicine with a huge potential to achieve refined prediction of disease risks and outcomes [1,12,13]. Third, generative AI-based models can be implemented to improve health literacy among lay individuals through the provision of easily accessible and understandable health information [1,14,15].

Despite the aforementioned advantages of generative AI-based models in health care, several valid concerns were raised, which should be considered carefully owing to their serious consequences [1,4,16]. For example, the lack of clarity on how generative AI-based models are trained raises ethical concerns [17,18]. Additionally, these models have an inherent bias in the generated content based on the modality of training used for their development and updates [17,18]. Importantly, the generation of inaccurate or misleading content, which might appear scientifically plausible to nonexperts (referred to as “hallucinations”), could have profound negative impacts in health care settings [1,19-21]. Furthermore, the integration of generative AI-based models in health care could raise complex medicolegal and accountability questions, compounded by the issues of data privacy and cybersecurity risks [1,4,22,23].

Similarly, the use of generative AI-based models can cause a paradigm shift in information acquisition, particularly in health care education [1,24-26]. However, careful consideration of the best policies and practices to incorporate AI-based models in health care education is needed [27]. This issue involves the urgent need to address the issues of inaccuracies, possible academic dishonesty, decline in critical thinking development, and deterioration of practical training skills [1].

Recently, a remarkable number of studies investigated the applicability and disadvantages of prominent generative AI-based conversational models, such as ChatGPT, Microsoft Bing, and Google Bard, in various health care and educational settings [1,2,4,28-34]. However, synthesizing evidence from such studies can be challenging owing to several reasons. Variations in methodologies implemented in various studies as well as in the reporting standards is a major limitation. This issue could hinder the efforts aiming to compare and contrast the results of generative AI-based studies in health care, contributing to the complexity in this domain. This variability arises from several factors, including different settings of the tested models, prompt variability, varying approaches used to evaluate the generated content of generative AI-based models, varying range of tested topics, and possible bias in selecting the tested subjects. Additionally, variability can be related to the different number and varying expertise of individual raters of content quality, as well as the variable number of queries executed, among other factors [35-37].

Therefore, it is important to initiate and develop an approach that can aid in establishing standardized reporting practices for studies aiming to evaluate the content of generative AI-based models, particularly in health care. This standardization can be crucial to facilitate the design of generative AI-based studies in health care, ensuring rigor and achieving precise comparison and credible synthesis of findings across different studies. Thus, we aimed to propose a preliminary framework (checklist) to establish proper guidelines for the design and reporting of findings of generative AI-based studies that address health care–related topics.

## Section: Methods › Study Design

The study was based on a literature review to highlight the key methodological aspects in studies that investigated 3 generative AI-based models (ChatGPT, Bing, and Bard) in health care education and practice. The literature review was conducted to identify relevant literature indexed in databases up to November 11, 2023 [38]. The databases used for this literature search were Scopus, PubMed/MEDLINE, and Google Scholar.

## Section: Methods › Ethical Considerations

This study did not involve human subjects, and thus, the requirement of ethical permission was waived.

## Section: Methods › Literature Search to Identify Relevant Records

The Scopus string query was as follows: (TITLE-ABS-KEY(“artificial intelligence” OR “AI”) AND TITLE-ABS-KEY (“healthcare” OR “health care”) AND TITLE-ABS-KEY (“education” OR “practice”)) AND PUBYEAR > 2022 AND DOCTYPE (ar OR re) AND (LIMIT-TO (PUBSTAGE , “final”)) AND (LIMIT-TO (SRCTYPE , “j”)) AND (LIMIT-TO (LANGUAGE , “English”)). The Scopus search yielded a total of 843 documents.

The PubMed advanced search tool was used as follows: (“artificial intelligence”[Title/Abstract] OR “AI”[Title/Abstract]) AND (“healthcare”[Title/Abstract] OR “health care”[Title/Abstract]) AND (“education”[Title/Abstract] OR “practice”[Title/Abstract]) AND (“2022/12/01”[Date - Publication] : “2023/11/11”[Date - Publication]). The PubMed search yielded a total of 564 records.

In Google Scholar and using the Publish or Perish software (version 8), in the title words and in the years 2022-2023, the search was as follows: “artificial intelligence” OR “AI” AND “healthcare” OR “health care” AND “education” OR “practice,” with a maximum of 999 records retrieved [39].

## Section: Methods › Criteria for Record Inclusion

The records from the 3 databases were merged using EndNote 20.2.1 software. This was followed by removal of duplicate records and removal of preprints by using the following function: ANY FIELD preprint OR ANY FIELD rxiv OR ANY FIELD SSRN OR ANY FIELD Researchgate OR ANY FIELD researchsquare OR ANY FIELD. The retrieved records were eligible for the final screening step given the following inclusion criteria: (1) Original article; (2) English record; (3) Published (peer reviewed); and (4) Assessment in health care practice or health care education. Finally, the imported references were subjected to the search function in EndNote as follows: Title contains ChatGPT OR Title contains Bing OR Title contains Bard. The selection of the included records was performed by the first author (Malik Sallam).

## Section: Methods › Development of the Initial Checklist Items

Initial development of the proposed checklist began with the assessment of the methodology and results sections of the included records, a majority of which were regarded as cross-sectional descriptive studies. Then, we referred to 2 commonly used reporting and quality guidelines to proactively explore pertinent themes for the proposed checklist based on the nature of the included records: (1) STROBE (Strengthening the Reporting of Observational Studies in Epidemiology) Statement: guidelines for reporting observational studies (checklist: cross-sectional studies) and (2) CASP (Critical Appraisal Skills Programme) Checklist (CASP qualitative studies checklist) [40,41]. This facilitated the allocation of ethical considerations, including transparency, methodological rigor, and issues related to bias, in the proposed checklist. Then, the 3 authors conducted an independent content review process to identify all the possible essential themes and best practices in generative AI-based health care studies among the included records. Finally, the authors had a collaborative discussion to refine the selected themes and classify these themes into specific components relevant to the study objectives. Special attention was given to aspects of method and result reporting that were perceived to impact the quality and reproducibility of the records, as identified by the 3 authors.

## Section: Methods › Establishing the Final Checklist Criteria

Careful examination of the included records resulted in the compilation of 3 independent lists of “pertinent themes,” which are herein defined as being critical or recurring in the reporting of results of generative AI-based studies. A thorough discussion among the authors followed to reach a consensus on the pertinent themes. Recurring themes were defined as those found in the methods of at least three separate records. Critical aspects were defined as those that would impact the conclusions of the included records as agreed by the 3 authors.

The final pertinent themes were selected based on their author-perceived significance in the quality and reproducibility of the findings. A final list of 9 themes was agreed upon by the authors as follows: (1) the “Model” of the generative AI-based tool or tools used in the included record and the explicit mention of the exact settings employed for each tool; (2) the “Evaluation” approach to assess the quality of the content generated by the generative AI-based model in terms of objectivity to reach unbiased findings and subjectivity; (3) the exact “Timing” of generative AI-based model testing and its duration; (4) the “Transparency” of data sources used to generate queries for the generative AI-based model testing, including the permission to use copyrighted content; (5) the “Range” of topics tested (single topic, multiple related topics, or various unrelated topics, as well as the breadth of intertopic and intratopic queries tested); (6) the degree of “Randomization” of topics selected to be tested to consider the potential bias; (7) the “Individual” subjective role in evaluating the content and the possibility of interrater reliability concordance or discordance; (8) the number (“Count”) of queries executed on each generative AI model entailing the sample size of queries tested; and (9) the “Specificity” of prompts used on each generative AI-based model, including the exact phrasing of each prompt and the presence of feedback and learning loops, and the “Specificity” of the language or languages used in testing, besides any other cultural issues. Thus, the final checklist was termed METRICS (Model, Evaluation, Timing, Range/Randomization, Individual factors, Count, and Specificity of prompts and language).

## Section: Methods › Scoring the METRICS Items and Classification of the METRICS Score

Testing of the included records was performed by 2 independent raters (Malik Sallam and Mohammed Sallam) independently, with each METRICS item scored using a 5-point Likert scale as follows: 5=excellent, 4=very good, 3=good, 2=satisfactory, and 1=suboptimal. For the items that were deemed “not applicable” (eg, individual factors for studies that employed objective methods for evaluation), no score was given. The scores for the 2 raters were then averaged. The average METRICS score was calculated as the sum of average scores for each applicable item divided by 10 minus the number of items deemed not applicable.

The subjective assessment of the 2 raters was performed based on predefined criteria as a general guide. For example, if the exact dates of model queries were mentioned, the “Timing” item was scored as excellent. The count of queries was agreed to be categorized as excellent if it was more than 500, while a single case or no mention of the count was considered suboptimal. For the prompt attributes, scores were assigned based on the availability of exact prompts, explicit mention of the language used, and details of prompting. Thus, prompts and language specificity were appraised positively if the study clearly and explicitly made the exact prompts available and if there was an explicit mention of the language employed in the prompts. The evaluation method was agreed to be rated higher for objective assessments with full details and lower for subjective assessments. The explicit mention of the method of interrater reliability testing was agreed to be scored higher for the “Individual” item. Transparency was assessed based on the comprehensiveness of the data source, and the presence of full database disclosure and permission to use the data was agreed to be given an excellent score. Randomization was agreed to be scored the lowest for the absence of details and the highest for explicit detailed descriptions.

Finally, we decided to highlight the records that scored the highest for each METRICS item. The decision to take this approach was based on an attempt to refrain from providing examples for the other quality categories to avoid premature conclusions regarding the quality of the included studies owing to the preliminary pilot nature of the METRICS tool.

## Section: Methods › Statistical and Data Analysis

The average METRICS scores were classified into distinct categories of equal weights as follows: excellent (score 4.21-5.00), very good (3.41-4.20), good (2.61-3.40), satisfactory (1.81-2.60), and suboptimal (1.00-1.80).

The Cohen κ measure was used to assess the interrater reliability by 2 independent raters. The Cohen κ measure was categorized as follows: <0.20, poor agreement; 0.21-0.40, fair agreement; 0.41-0.60, good agreement; 0.61-0.80, very good agreement; and 0.81-1.00, excellent agreement.

For statistical analysis, we used IBM SPSS Statistics for Windows, Version 26.0 (IBM Corp). A P value <.05 was considered significant.

## Section: Results

The approach for selecting articles.

Details of the model attributes of the included studies.

Classification based on the evaluation approach of the content generated by the artificial intelligence–based models.

Classification of the included studies based on the features of data used to generate queries for testing on the generative artificial intelligence–based models.

Included records that had the highest METRICS score per item.

Interrater reliability per METRICS item.

## Section: Results › Description of the Included Studies

A total of 34 studies were included in the final analysis that aimed to establish the METRICS criteria (Figure 1).

The most common source of records was Cureus, with 9 of the 34 records (27%), followed by BMJ Neurology Open, with 2 of the 34 records (6%). The remaining 23 records were published in 23 different journals.

The approach for selecting articles.

## Section: Results › Evaluation of the Included Records Based on MED-METRICS Items

The METRICS checklist was divided into the following 3 parts: “Model” attributes, “Evaluation” approach, and features of “Data” (MED-METRICS).

The complete details of the model attributes of the included studies are presented in Table 1.

ChatGPT was tested in all the records included (34/34, 100%), followed by Google Bard (5/34, 15%) and Bing Chat (5/34, 15%). The exact dates of generative AI-based model queries were explicitly mentioned in 13 of the 34 records (38%). The count of cases or questions that were tested in the studies ranged from a single case to 2576 questions. The majority of studies (23/34, 68%) tested the AI models based on queries in the English language.

The complete details of the evaluation approach of the content generated by the AI-based models in the included studies are presented in Table 2.

Objective evaluation of the content generated by the generative AI-based model was noted in 15 of the 34 records (44%).

The complete details of the features of data used to generate queries for testing on the generative AI-based models, including the range of topics and randomization, are presented in Table 3.

Explicit mention of the randomization process was only noted in 4 of the 34 included studies (9%). Of the 34 records, 6 (18%) involved broad multidisciplinary medical exam questions (18%). Moreover, 2 studies (6%) explicitly mentioned the permission to use the data for the studies.

Details of the model attributes of the included studies.

Classification based on the evaluation approach of the content generated by the artificial intelligence–based models.

Classification of the included studies based on the features of data used to generate queries for testing on the generative artificial intelligence–based models.

## Section: Results › Examples of Optimal Reporting of Each Criterion Within the METRICS Checklist

The records with the highest scores for each METRICS item, as determined by the average subjective interrater assessments, are shown in Table 4.

Included records that had the highest METRICS score per item.

## Section: Results › Interrater Assessment of the Included Records Based on METRICS Scores

The overall mean METRICS score was 3.0 (SD 0.58). For each item, the κ interrater reliability ranged from 0.558 to 0.962 (P<.001 for the 9 tested items), indicating good to excellent agreement (Table 5).

With classification per item, the highest average METRICS score was recorded for the “Model” item, followed by the “Specificity” item, while the lowest scores were recorded for the “Randomization” item (classified as suboptimal) and “Individual factors” item (classified as satisfactory) (Table 5).

Interrater reliability per METRICS item.

## Section: Discussion › Principal Findings

The interpretation and synthesis of credible scientific evidence based on studies evaluating commonly used generative AI-based conversational models (eg, ChatGPT, Bing, and Bard) can be challenging. This is related to the discernible variability in the methods used for the evaluation of such models, as well as the varying styles of reporting. Such variability is fathomable considering the emerging nature of this research field with less than a year of reporting at the time of writing. Therefore, a standardized framework to guide the design of such studies and to delineate the best reporting practices can be beneficial, since rigorous methodology and clear reporting of findings are key attributes of science to reach reliable conclusions with real-world implications.

In this study, a preliminary checklist referred to as “METRICS” was formulated, which can help researchers aspiring to test the performance of generative AI-based models in various aspects of health care education and practice. It is crucial to explicitly state that the proposed METRICS checklist in this study cannot be claimed to be comprehensive or flawless. Nevertheless, this checklist could provide a solid base for future studies and much needed efforts aiming to standardize the reporting of AI-based studies in health care.

The principal finding of this study was the establishment of 9 key themes that are recommended to be considered in the design, testing, and reporting of generative AI-based models in research, particularly in the health care domain. These features included the model of the generative AI tool, evaluation approach, timing of testing and transparency, range of topics tested and randomization of queries, individual factors in the design and assessment, count of queries, and specific prompts and languages used. The relevance of these themes in the design and reporting of generative AI-based model content testing can be illustrated as follows.

First, the variability in generative AI model types used to conduct queries and the variability in settings pose significant challenges for cross-study comparisons. The significant impact of generative AI models on the resultant output is related to the distinct architectures and capabilities of various generative AI models, with expected variability in the performance and quality of the content generated by generative AI [76]. Additionally, various options to configure the models further affect the content generated by generative AI. Consequently, it is important to consider these variations when evaluating research using different generative AI models [77-81]. These issues can be illustrated clearly in the records included in this study that conducted contemporary analysis of at least two models. For example, Al-Ashwal et al [42] showed that Bing had the highest accuracy and specificity for predicting drug-drug interaction, outperforming Bard, ChatGPT-3.5, and ChatGPT-4. Moreover, Baglivo et al [47] showed not only intermodel variability but also intramodel variability in performance in the domain of public health. Additionally, in the context of providing information on rhinoplasty, Seth et al [70] showed that this intermodel variability in performance was the most comprehensible with the content of Bard, followed by ChatGPT and Bing.

Second, the continuous updating of generative AI models introduces significant temporal variability, which would influence the comparability of studies conducted at different times. The updates of generative AI models enhance their capabilities and performance [82]. Consequently, this temporal variability can lead to inconsistencies in synthesizing evidence, as the same model may demonstrate different outputs over time. Therefore, when analyzing or comparing studies involving AI models, it is crucial to consider the specific version and state of the model at the time of each study to accurately interpret and compare results. In this context, it is important to conduct future longitudinal studies to discern the exact effect of changes in performance of commonly used generative AI models over time.

Third, the count of queries in the evaluation of generative AI models was identified among the pertinent themes of assessment. This appears understandable since studies employing a larger number of queries can provide a more comprehensive evaluation of the tested model. An extensive number of queries can reveal minor weaknesses, despite the difficulty to establish what constitutes an “extensive” number of queries of the minimum number of queries needed to reveal the real performance of a generative AI model in a particular topic. In this study, the number of queries varied from a single case to more than 2500 questions, showing the need for standardization and establishing a clear guide on the number of queries deemed suitable [58,75].

Fourth, a key theme identified in this study was the nature and language of the prompts used to conduct the studies. This involved the imperative of explicitly stating the used prompts and the language in which they were framed. The exact prompting approach and the presence of cultural and linguistic biases appear to be critical factors that can influence the quality of content generated by generative AI-based models [83]. Slight differences in wording or context in the prompt used to generate the generative AI content can lead to recognizable differences in the content generated [36,84,85]. Additionally, feedback mechanisms and learning loops that allow generative AI-based models to learn from interactions can change the model performance for the same query, which might not be consistently accounted for in all studies. These minor variations in prompts across different studies can also complicate the synthesis of evidence, highlighting the need for standardizing such an aspect. Additionally, as highlighted above, generative AI-based models may exhibit biases based on their training data, affecting performance across various cultural or linguistic contexts [86-88]. Thus, studies conducted in different regions or involving various languages might yield varying results. In this study, we found that a majority of the included records tested generative AI-based models using the English language, highlighting the need for more studies on other languages to reveal the possible variability in performance based on language. Comparative studies involving multiple languages can reveal such inconsistencies, for example, the study by Wang et al [74]. In the aforementioned study assessing ChatGPT performance in the Taiwanese pharmacist licensing exam, the performance in the English test was better than that in the Chinese test across all tested subjects [74]. Another comprehensive study by Alfertshofer et al [43] that assessed the performance of ChatGPT on 6 different national medical licensing exams highlighted the variability in performance per country and language. Based on the previous points, more studies that encompass diverse language and cultural perspectives are essential to assess and address possible cultural and language biases in generative AI-based models. Additionally, the design of generative AI-based models trained on a more diverse set of languages and cultural contexts is important to ensure that the training data sets are representative of different linguistic groups, which is of paramount importance in health care. Furthermore, cross-cultural validation studies appear valuable for understanding the performance of generative AI-based models in various language and cultural settings. These approaches could enhance the broad applicability of generative AI-based models in health care to ensure the fair distribution of the benefits of generative AI technologies.

Fifth, an important theme highlighted in this study was the approach of evaluating the content generated by generative AI-based models. Variable methods of assessment can introduce a discernible methodological variability. Specifically, the use of objective assessment ensures consistency in assessment. On the other hand, subjective assessment, even by experts, can vary despite the professional judgment and deep understanding provided by such an expert opinion [89].

Similarly, the number and expertise of evaluators or raters involved in constructing and evaluating the generative AI-based studies were identified as a pertinent theme in this study [90,91]. Variations in rater numbers across studies can lead to inconsistencies in synthesized evidence [68,69,92]. Additionally, the method used to establish agreement (eg, kappa statistics and consensus meetings) might differ in various studies, affecting the comparability of results.

Finally, data-pertinent issues were identified as key themes in this study. These involved the need for full transparency regarding the sources of data used to create the queries (eg, question banks, credible national and international guidelines, clinical reports, etc) [93,94]. Additionally, ethical considerations, such as consent to use copyrighted material and consent or anonymization of the clinical data, should be carefully stated in the evaluation studies of AI-based models. An important aspect that appeared suboptimal in the majority of included records was randomization to reduce or eliminate potential bias in query selection. Thus, this important issue should be addressed in future studies to allow unbiased evaluation of the content of generative AI-based models. Another important aspect is the need to carefully select the topics to be tested, which can belong to a broad domain (eg, medical examination) or a narrow domain (eg, a particular specialty) [95-97]. A comprehensive description of topics is essential to reveal subtle differences in generative AI performance across various domains. Biased query coverage per topic may result in unreliable conclusions regarding generative AI model performance.

The value of the METRICS checklist in guiding researchers toward more rigorous design and transparent reporting of health care studies assessing the performance of generative AI-based models can be highlighted as follows. Two studies exemplified the practical utility of the METRICS checklist (presented in its preprint form) across different research scenarios (health care education and health care practice) [98]. The first study conducted a detailed assessment of ChatGPT-3.5 performance in medical microbiology multiple choice questions compared with dental students [99]. By applying the METRICS checklist retrospectively, the study quality was delineated, including the identification of potential limitations, such as the absence of randomization, thus offering a more critical evaluation of the research design [99].

The second study investigating the performance of both ChatGPT-3.5 and ChatGPT-4 in the context of diagnostic microbiology case scenarios was conceived based on the METRICS checklist [100]. The prospective incorporation of the METRICS checklist was particularly instrumental in refining the study design and the reporting of results [100].

Thus, the aforementioned studies emphasize the effectiveness of the METRICS checklist as a tool to standardize research practice in a rapidly growing research field. The real-world application of the METRICS checklist has been valuable in identifying potential research limitations and in enhancing the overall structure and clarity of the reporting of results. These studies also demonstrate the value of the METRICS checklist for guiding researchers toward more rigorous design and transparent reporting of generative AI-based studies in health care [99,100].

## Section: Discussion › Limitations

It is crucial to explicitly mention the need for careful interpretation of the findings based on the following limitations. First, the initial search process involved the broad term “artificial intelligence” and was conducted by a single author, which may have inadvertently resulted in missing relevant references. The record selection process was further limited by the screening of record titles for only 3 generative AI models (ChatGPT, Bing, and Bard) using the EndNote search function. Additionally, the reliance on including published English records, indexed in Scopus, PubMed, or Google Scholar, could raise concerns about potential selection bias and the exclusion of relevant studies. However, it is important to consider this limitation in light of the context of our study, which represents a preliminary report that needs to be validated by future comprehensive and exhaustive studies. Second, it is important to acknowledge that a few pertinent themes could have been overlooked despite our attempt to achieve a thorough analysis, given the limited number of authors. Therefore, future follow-up studies can benefit from inclusion of authors with diverse backgrounds, including different health care disciplines, computer scientists, researchers in the field of human-AI interaction, and AI developers. Additionally, the subjective nature of the pertinent theme selection can be considered as another important caveat in this study. This shortcoming extended to involve the raters’ subjective assessments in assigning different METRICS scores. Moreover, the equal weight given to each item of the checklist in the METRICS score might not be a suitable approach, given the possibility of varying importance of each component. Thus, future comprehensive studies should focus on the relative importance of each METRICS component and its possible impact on the reporting of generative AI model performance. Third, the focus on a few specific generative AI-based conversational models (ie, ChatGPT, Bing, and Bard) can potentially overlook the nuanced aspects of other generative AI models. Nevertheless, our approach was justified by the popularity and widespread use of these particular generative AI-based models. However, it is important for future studies to expand the scope to include models, such as Llama or Claude, which could provide a more comprehensive evaluation of the utility of the METRICS checklist. Lastly, we fully and unequivocally acknowledge that the METRICS checklist is preliminary and needs further verification to ensure its valid applicability.

## Section: Discussion › Future Perspectives

The METRICS checklist proposed in this study could be a helpful step toward establishing useful guidelines to design and report the findings of generative AI-based studies. The integration of generative AI models in health care education and practice necessitates a collaborative approach involving health care professionals, researchers, and AI developers. Synthesis of evidence with critical appraisal of the quality of each element in the METRICS checklist is recommended for continuous enhancement of AI output, which would result in successful implementation of AI models in health care while avoiding possible concerns. Regular multidisciplinary efforts and iterative revisions are recommended to ensure that the METRICS checklist properly reflects its original intended purpose of improving the quality of study design and result reporting in this swiftly evolving research field. Future studies would benefit from expanding the scope of literature review and data inclusion, with the incorporation of a wider range of databases, languages, and AI models. This is crucial for reaching the ultimate aim of standardization of the design and reporting of generative AI-based studies.

## Section: Discussion › Conclusions

The newly devised “METRICS” checklist may represent a key initial step to motivate the standardization of reporting of generative AI-based studies in health care education and practice. Additionally, the establishment of this algorithm can motivate collaborative efforts to develop universally accepted reporting guidelines for the design and reporting of results of generative AI-based studies. In turn, this can enhance the comparability and reliability of evidence synthesis from these studies. The METRICS checklist, as presented by the findings of this study, can help to elucidate the strengths and limitations of the content generated by generative AI-based models, guiding their future development and application. The standardization offered by the METRICS checklist can be important to ensure the reporting of reliable and replicable results. Subsequently, this can result in the exploitation of the promising potential of generative AI-based models in health care while avoiding its possible concerns. The METRICS checklist could mark the significant progress in the evolving research field. Nevertheless, there is room for refinement through revisions and updates to verify its validity.

## Section: Data Availability

The data used in this study are available upon request from the corresponding author (Malik Sallam).

## Section: Associated Data › Data Availability Statement

The data used in this study are available upon request from the corresponding author (Malik Sallam).


---

# A Review and Comparative Case Study Analysis of Real-World Evidence in European Regulatory and Health Technology Assessment Decision Making for Oncology Medicines

- **Authors:** Jihong Zong, Adina Rojubally, Xiaoyun Pan, Birgit Wolf, Scott Greenfeder, Alexander Upton, Joette Gdovin Bergeson
- **Issuer:** Value in health : the journal of the International Society for Pharmacoeconomics and Outcomes Research
- **Type:** Scientific article
- **Published:** 2024-10-10
- **Language:** en
- **DOI:** 10.1016/j.jval.2024.09.007
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39393564/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Real-world evidence (RWE) is valuable in supporting regulatory and health technology assessment (HTA) decisions; however, the actual contribution to approvals remains elusive. This study aimed to review RWE approaches and use in oncology medicine approvals in Europe and understand cohesion and discrepancy in the acceptance of the RWE by the European Medicines Agency (EMA) and European HTA bodies. This scoping review involved a search of the EMA database, National Institute for Health and Care Excellence (NICE), Gemeinsamer Bundesausschuss (G-BA), and Haute Autorité de Santé (HAS) websites to identify final reports and appraisals for oncology medicines with references to RWE. The selection was guided by research terms associated with RWE study designs, data sources, and outcomes. Qualitative analysis was used to systemize the data. Case studies assessed by more than one agency were selected for comparative assessment of RWE approach, use, and acceptability. RWE was mainly leveraged as an external control for indirect treatment comparisons or contextualization to support clinical trial results by the EMA, NICE, G-BA, and HAS. However, this approach was mostly rejected due to methodology biases. Comparative assessment of RWE acceptability for the same oncology medicines across agencies suggests discrepancies between EMA and European HTA bodies and among NICE, G-BA, and HAS. There is diverging acceptance of RWE in EMA and European HTA bodies with no clear consensus on the most effective way to leverage RWE in approvals. With the introduction of the joint European Union Joint Clinical Assessment in 2025, it is crucial for European HTA bodies and EMA to develop synergetic standards for the use of RWE to ensure equitable and timely access to medicines.


---

# A stacking ensemble machine learning model for evaluating cardiac toxicity of drugs based on in silico biomarkers

- **Authors:** Yunendah Nur Fuadah, Ali Ikhsanul Qauli, Muhammad Adnan Pramudito, Aroli Marcellinus, Ulfa Latifa Hanum, Ki Moo Lim
- **Issuer:** CPT: pharmacometrics & systems pharmacology
- **Type:** Scientific article
- **Published:** 2024-08-26
- **Language:** en
- **DOI:** 10.1002/psp4.13229
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39185761/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractThis study addresses the critical issue of drug‐induced torsades de pointes (TdP) risk assessment, a vital aspect of new drug development due to its association with arrhythmia and sudden cardiac death. Existing methodologies, particularly those reliant on a single biomarker derived from CiPA O'Hara‐Rudy (CiPAORdv1.0) ventricular cell model without the hERG dynamic as input to the individual machine learning model, have limitations in capturing the complexity inherent in the comprehensive range of factors influencing drug‐induced TdP risk. This study aims to overcome these limitations by proposing a stacking ensemble machine learning approach by integrating multiple in silico biomarkers derived from the CiPAORdv1.0 with hERG dynamic characteristics. The ensemble machine learning model consisted of three artificial neural network (ANN) models as baseline model and support vector machine (SVM), logistic regression (LR), random forest (RF), and extreme gradient boosting (XGBoost) models as meta‐classifier. The highest AUC score of 1.00 (0.90–1.00) for high risk, 0.97 (0.84–1.00) for intermediate risk, and 1.00 (0.87–1.00) for low risk were obtained using seven biomarkers derived from the CiPAORdv1.0 with hERG dynamic characteristics. Furthering our investigation, we explored the model's robustness by incorporating interindividual variability into the generation of in silico biomarkers from a population of human ventricular cell models. This study also enabled an analysis of TdP risk classification under high clinical exposure and therapeutic scenarios for several drugs. Additionally, from a sensitivity analysis, we revealed four important ion channels, namely, CaL, NaL, Na, and Kr channels that affect significantly the important biomarkers for TdP risk prediction.

## Section: INTRODUCTION

Evaluating a drug's cardiac safety concerning torsades de pointes (TdP) risk is essential in developing a new drug. 1 TdP risk is associated with drug‐induced arrhythmia as a critical indicator of sudden cardiac death events. 2 The Food and Drug Administration (FDA) introducing comprehensive in vitro proarrhythmia assay (CiPA) studies, which assess drug responses across multiple ion channels, offering an alternative to the conventional single‐assay approach that solely utilizes the hERG channel. 3 , 4 Several studies followed the CiPA guidelines to develop an evaluation system for predicting the TdP risk of drugs using in silico biomarkers derived from the CiPAORdv1.0 ventricular cell model.

The study proposed by Lancaster et al. 5 reported the highest performance with an area under curve (AUC) score of 0.962 by utilizing action potential duration of 50% repolarization (APD50) and Ca2+ to the support vector machine (SVM). Yoo et al. 6 utilized nine in silico biomarkers derived from CiPAORdv1.0 without hERG dynamic as input to the artificial neural networks (ANN) model for predicting the TdP risk of drugs into the high, intermediate, and low‐risk levels. Li et al. 7 introduced hERG dynamic pharmacological interactions of drugs, and Duta et al. 8 added some model optimizations by revising the maximum conductance of some major ionic currents, including IKs, ICaL, IKr, INaL, and IK1 to 1.870, 1.007, 1.013, 2.661, and 1.698, respectively, to the O'Hara‐Rudy (ORd) model. 9 To categorize cardiotoxicity risk groups, the FDA employed qNet—the total net charge transported over the six channels, INaL, ICaL, IKr, Ito, IK1, and IKs—as a biomarker. 8 , 10 Furthermore, Li et al. 11 incorporated the ordinal logistic regression (OLR) and 10,000‐time testing to evaluate the performance of the machine learning algorithm to predict the TdP risk of drugs. Their study showed that the AUC score was higher for drugs that incorporated the hERG dynamic in classifying the TdP risk of drugs than those that did not utilize the hERG dynamic model.

Previous studies proposed a single biomarker, such as qNet from the CiPAORdv1.0 ventricular cell model that strongly correlates with TdP risk, particularly in predicting high and low‐risk levels. 11 However, other research indicated that individual biomarkers, such as APD50, calcium transient duration of 50% repolarization (CaD50), and qNet did not effectively classify drugs into high, intermediate, and low‐risk categories. 12 , 13 This is possibly because a single biomarker cannot encompass the full range of factors contributing to a drug's TdP risk.

To address the critical gap from the previous studies, this study proposes a novel approach by incorporating hERG dynamic characteristics and employing a stacking ensemble machine learning model. This model synergizes multiple in silico biomarkers derived from the CiPAORdv1.0 enhanced with hERG dynamics to improve the performance of drug‐induced TdP risk assessment. The ensemble approach combines the strengths of three ANN models as the baseline with SVM, LR, random forest (RF), and extreme gradient boosting (XGBoost) models as meta‐classifiers. Through this comprehensive methodology, we aim to address the limitations of previous models by providing a more accurate, comprehensive, and nuanced risk assessment across high, intermediate, and low TdP risk categories.

Furthermore, recognizing the importance of interindividual variability in drug response, our study extends the application of these models to account for physiological differences within the population. By generating in silico biomarkers from a diverse human ventricular cell model population. This approach is further validated by evaluating TdP risk classification for several drugs under conditions of high clinical exposure and therapeutic scenarios proposed by Leishman et al., 14 underscoring the practical utility of our model in predicting TdP risk in a clinical setting.

In addition, we conduct a sensitivity analysis to explore the influence of specific ion channel balances on in silico biomarkers for TdP risk of drug classification. This analysis reinforces the importance of hERG dynamics in accurately predicting TdP risk and sheds light on the intricate relationship between ion channel dynamics and drug‐induced cardiotoxicity. Through this comprehensive methodology, our study aims to advance the field of cardiac safety pharmacology, offering a robust and clinically relevant tool for predicting TdP risk, thereby facilitating safer drug development and deployment.

## Section: METHODS

A whole schematic of a stacking ensemble machine learning model with fivefold cross‐validation for predicting cardiac toxicity of drugs into high, intermediate, and low risk using in silico biomarkers.

## Section: METHODS › In vitro dataset for assessing cardiac toxicity of drug

We utilized FDA experimental data of 28 drugs obtained from Li et al. 11 These 28 drugs are divided according to the CiPA into 12 drugs of the training dataset and 16 drugs of the testing dataset, as detailed in Table S1. The dataset included measuring inhibition rates for seven ion channels in response to four different concentration levels of the 28 drugs. The four ion channels include sodium current (INa), late sodium current (INaL), rapid delayed rectifier potassium current (IKr), and L‐type calcium current (ICaL). To ensure consistency, we processed all the datasets by the methodology proposed by Crumb et al. 15

Initially, we assessed the uncertainty associated with the in vitro dataset using the Markov chain Monte Carlo (MCMC) technique introduced by Chang et al. 10 which involved generating 2000 Hill curves within a 95% confidence interval. Subsequently, we derived the half‐maximal inhibitory concentration (IC50) and the slope coefficients at IC50 (Hill coefficients, h) from these 2000 Hill curves. These IC50 and h values were then employed as inputs to the in silico drug simulations.

## Section: METHODS › In silico simulation for generating biomarkers

For in silico simulations, we applied the CiPAORdv1.0 model, a modified cardiac cell model from the original ORd model that was later modified by Li et al. 7 (incorporating the dynamic inhibition model of hERG channel) and refined by Dutta et al. 8 The typical mathematical expression of membrane potential (Vm) can be written as shown in Equation (1):

where the cm is the cell membrane capacitance, the Istim is the stimulus current, and the Itotal is the summation of transmembrane ionic currents. For the CiPAORdv1.0 ventricular cell model, the Itotal is assumed to consist of the sodium current INa, the late sodium current INaL, the L‐type calcium current ICaL, the sodium current through L‐type calcium channel ICaNa, the potassium current through L‐type calcium channel ICaK, the transient outward potassium current Ito, inward rectifier potassium current IKs, sodium‐calcium exchange current INaCa, sodium‐potassium ATPase current INaK, background currents INabICabIKb, and sarcolemma calcium pump current IpCa. The in silico simulations utilized the endocardial cell type. The drug inhibition model for hERG and non‐hERG channels is described in Supplementary Materials.

## Section: METHODS › Ensemble machine learning with stacking algorithm

A stacking ensemble machine learning algorithm combines several models as baseline models to provide a superior meta‐learning classifier with a more accurate classification, reducing overfitting and building a robust classifier system. 16 , 17 , 18 Generally, a stacking algorithm consists of two levels of classifier layers: level 1 and level 2. The level 1 classifier layer has several classifier models as baseline models. 18 Meanwhile, the level 2 classifier layer consists of a single model as a meta‐classifier.

In ensemble machine learning, implementing k‐fold cross‐validation is essential to ensure the reliability and robustness of the stacking ensemble algorithm. 19 , 20 Therefore, this study applied fivefold cross‐validation on the training and validation process. Initially, the dataset S=xiyi=1k is partitioned into k subsets S=S1S2…Sk, k−1 subsets will be used as train datasets, and the remaining subset will be used as validation datasets. 17 , 21 The training and validation performance results, as shown in Table S3, will be used as internal validation to determine the best model for the level 1 classifier. The level 1 classifier layers involve several classifier models (M1, M2,…Mn) that will generate the output M1 (xi) and M2 xi until Mn (xi), respectively. Furthermore, the prediction from each model will be used as input to the meta‐classifier at level 2 to determine the final prediction of cardiac toxicity of drugs. As shown in Figure 1, this study used three ANN models as baseline models and applied several models, including SVM, LR, XGBoost, and RF, model models as meta‐classifiers.

A whole schematic of a stacking ensemble machine learning model with fivefold cross‐validation for predicting cardiac toxicity of drugs into high, intermediate, and low risk using in silico biomarkers.

## Section: RESULTS

The result of electrophysiological simulations of the cell model using CiPAORdv1.0 with hERG dynamic characteristics are 11 in silico biomarkers that are utilized as input to a stacking ensemble machine learning model. Nevertheless, we conducted biomarker selection to eliminate less impactful biomarkers, ultimately identifying four groups of in silico biomarkers comprising eleven‐, seven‐, five‐, and three‐biomarker groups. This categorization was based on the significance ranking derived from the SHAP value, as shown in Figure 2. The set of 11 in silico biomarkers group involves APD50, APD90, dVmdtrepol, dVmdtmax, Vmpeak, Vmresting, CaD50, CaD90, Capeak, Caresting, and qNet. The seven‐biomarker group involves APD50, APD90, dVmdtmax, Vmpeak, CaD50, CaD90, and qNet. The five‐biomarker group involves APD50, APD90, CaD50, CaD90, and qNet. The three‐biomarker group involves APD90, CaD90, and qNet. We evaluated the performance of a stacking ensemble machine learning model using each biomarker group generated from the CiPAORdv1.0 ventricular cell model with hERG dynamic characteristics. 15 , 22

The results of several meta‐classifiers for the proposed stacking ensemble machine learning model are presented in Table S4. According to these results, the SVM meta‐classifier achieved the highest performance compared with LR, RF, and XGBoost. Consequently, the performances presented in Tables 1 and 2 are those of the ensemble machine learning model utilizing SVM as the meta‐classifier. As shown in Table 1, the performance of the ensemble machine learning model varies across different biomarker groups and C max conditions. Under CiPA‐based C max conditions, the model achieves its highest performance with the seven‐biomarker group, achieving an AUC of 1.00 (0.90–1.00) for high risk, 0.97 (0.84–1.00) for intermediate risk, and 1.00 (0.87–1.00) for low risk. These scores indicate excellent performance according to the CiPA evaluation standard (see Table S6). The seven‐biomarker group's results outperform those of the three‐ and five‐biomarker groups, which exhibit lower AUC scores. Interestingly, the 11‐biomarker group, while comprehensive, does not match the AUC score of the seven‐biomarkers set. This suggests that adding more than the optimal seven biomarkers does not necessarily enhance predictive performance.

The proposed method in this study is further confirmed by assessing TdP risk classification for several drugs, including terfenadine, astemizole, and risperidone, under conditions of high clinical exposure and therapeutic scenarios as proposed by Leishman et al. (see Table S2) highlighting the practical value of our model in forecasting TdP risk in clinical environments. Under high clinical exposure conditions, the ensemble machine learning model demonstrates a nuanced predictive performance when categorizing drugs into high, intermediate, and low TdP risk levels, as shown by AUC and accuracy metrics. Notably, within this clinical context, the group of five biomarkers yields an AUC of 0.96 (0.92–1.00) for high risk, AUC of 0.94 (0.86–0.98) for intermediate risk, and AUC of 1.00 (0.95–1.00) for low risk.

In therapeutic scenarios, the ensemble machine learning model, employing a seven‐biomarker configuration, exhibits notable proficiency in identifying drugs at high risk for TdP, achieving an AUC score of 0.98 (0.88–1.00). Meanwhile, intermediate and low TdP risk was obtained at 0.94 (0.84–1.00) and 0.91 (0.88–1.00), highlighting the utility of the seven‐biomarkers set as a potential predictor for TdP risk. Such efficacy underscores the model's potential to aid therapeutic decision‐making, particularly in assessing cardiotoxicity risks.

Table 2 reported the performance of the proposed ensemble machine learning model compared with prior studies. Li et al. 11 employed the qNet biomarker from the CiPAORdv1.0 ventricular cell model as input for ordinal LR, with and without considering hERG dynamic characteristics. On the other hand, Yoo et al. utilized nine in silico biomarkers from the CiPAORdv1.0 without hERG dynamic as input for the ANN model. Our proposed ensemble machine learning model, which uses seven in silico biomarkers derived from CiPAORdv1.0 incorporating hERG dynamic characteristics, achieved outstanding AUC scores and outperformed the results reported by Yoo et al. and Li et al. 6 , 11 Notably, our results are comparable with those of Li et al., who also considered hERG dynamics, achieving an AUC score of 1.00 (0.90–1.00) for high TdP risk compared with their 0.988 (0.95–1.0). In assessing the intermediate‐risk group, our model demonstrated superiority with an AUC score of 0.97 (0.84–1.00), outperforming Yoo et al., who reported an AUC of 0.83 (0.73–0.91). For the low‐risk category, our model achieved an AUC of 1.00 (0.87–1.00), surpassing both Li et al. and Yoo et al., who reported AUC scores of 0.901 (0.88–0.93) and 0.98 (0.91–1.0), respectively.

Table 3 presents the results of our stacking ensemble machine learning model, designed to classify drugs by their TdP risk while incorporating interindividual variability. This variability is addressed using in silico biomarkers derived from a human ventricular cell model population. This table depicts a comparison of performance metrics for various meta‐classifiers, including SVM, LR, XGBoost, and RF, across different testing conditions: CiPA, High Clinical, and Therapeutic scenarios.

In the context of CiPA, the SVM meta‐classifier exhibits performance comparable to the study by Passini et al., 23 which reported an accuracy of 96%, a sensitivity of 100%, and a specificity of 92% in classifying high and no TdP risk. Our study achieves a similar accuracy of 0.96 (0.91–1.00), an AUC score of 0.99 (0.91–1.00), a sensitivity of 0.92 (0.80–1.00), and a specificity of 0.92 (0.80–1.00). Under more demanding high clinical and therapeutic conditions, where variability and complexity are heightened, the ensemble model performs strongly.

Figure 3 shows the variations in the top seven most influential biomarkers for TdP risk prediction resulting from alterations in the conductance of seven major ion channels under drug‐free conditions. Panels a and b depict the changes in APD50 and APD90, with the Kr channel exhibiting the most prominent effect. Blocking the Kr channel (indicated by a −1% change) prolongs APD50 and APD90. Additionally, the NaL channel plays a significant role in APD90 variation, as blocking NaL can shorten APD90.

Furthermore, panels c and d of Figure 3 show significant changes in CaD50 and CaD90 when the CaL or Na channels are altered. Blocking the CaL channel prolongs both CaD50 and CaD90, while increasing the maximum conductance of the Na channel also prolongs these biomarkers.

Furthermore, panels e and f illustrate variations in biomarkers related to the AP profile, namely Vmpeak and dVmdtmax. Increasing the maximum conductance of the Na channel triggers an increase in Vmpeak (panel e). Similar effects are observed with increased CaL and NaL conductance, although the Vmpeak increase is not as pronounced as with the Na channel. Conversely, increasing the maximum conductance of the channel lowers Vmpeak. Additionally, the Na channel plays a prominent role in altering dVmdtmax (panel f), as blocking the Na channel leads to lower dVmdtmax.

Moreover, panel g presents changes in qNet against variations in ion channel conductance. Four ion channels—CaL, Kr, Na, and NaL—exhibit significant effects on qNet, while others, such as K1 and Ks, have minimal effects. Blocking CaL and NaL channels increases qNet values, whereas inhibiting Kr and Na channels decreases qNet values. Additionally, inhibiting the K1, Ks, and to channels decreases the qNet, even though the drop in qNet is not as significant as with Kr and Na.

When applied with extended drug concentrations, resulting biomarkers show variations, as depicted in Figure 4. As the drug concentration increases, the APD‐related biomarkers (panels a and b) generally show a positive trend for high‐ and intermediate‐risk drugs. There is a negative trend for low‐risk compounds for loratadine, nitrendipine, and nifedipine. In contrast, metoprolol and droperidol show a positive trend of APD changes even though these compounds are low‐risk. CaD‐related biomarkers (panels c and d) also generally show a similar positive trend toward higher drug concentration. However, metoprolol, nifedipine, and nitrendipine show a negative trend of CaD50 toward higher drug concentrations, whereas only metoprolol yields a negative trend of CaD90 toward higher drug concentrations.

Furthermore, the Vmpeak generally shows a negative trend when applied with higher drug concentrations, as shown in panel e of Figure 4. Only astemizole and droperidol yield increased Vmpeak when applied with higher drug concentrations. The qNet changes (panel g) also show a similar negative trend toward higher drug concentrations except for nifedipine and nitrendipine, which yield a positive trend of qNet variations. For the variations of dVmdtmax (panel f), most of the 16 testing drugs show a relatively stagnant variation, except only metoprolol yields a distinctively negative trend of dVmdtmax toward high drug concentration.

The SHAP values of 16 testing drugs from three base line models; (a) The SHAP value from ANN with one hidden layer; (b) The SHAP value from ANN with two hidden layers; (c) The SHAP value from ANN with three hidden layers.

The comparison performance result of several in silico biomarkers groups using 10,000 times test for 16 testing drugs with a stacking ensemble machine learning model.

The performance result of 10,000 times test for 16 testing drugs using a stacking ensemble machine learning model and comparison with the previous studies.

The performance result of a stacking ensemble machine learning model with different meta‐classifier for classifying high and no TdP risk of drugs that incorporate interindividual variability in generating in silico biomarkers from a population of human ventricular cell models.

Variations in the top seven most influential in silico biomarkers for TdP risk classification in response to changes in ion channel conductance. The conductance of ion channels is adjusted to −1%, normal (unchanged), and +1% of their maximum values.

Top seven influential biomarkers simulated under various drug concentrations of 1 to 30× C max for 16 testing drugs. The gray‐shaded regions represent the lower‐upper bounds of 95% confidence interval range of biomarkers from 10 samples from each drug. The bold lines in the middle of shaded areas represent the average value of the biomarkers. Finally, the color coding represents the TdP risk of drugs: Red for high‐risk drugs, blue for intermediate‐risk drugs, and green for low‐risk drugs.

## Section: DISCUSSION

Our study explored the application of in silico biomarkers and ensemble machine learning models to assess cardiac toxicity risks. Specifically, we focused on the CiPAORdv1.0 ventricular cell model with hERG dynamic characteristics. 15 , 22 The ORd model concentrates on repolarization and shows discrepancies with human ventricular data in action potential plateau, adaptation to heart rate, and response to sodium block. Ignoring the dynamics of channel pharmacology, especially for evaluating the TdP risk of drugs that are known to interact with ion channels, would provide an incomplete picture of a drug's effect on cardiac cells. Simulating these dynamics is crucial for comprehensively assessing a drug's cardiac safety profile. The hERG channel dynamics significantly determine the action potential duration (APD) in ventricular cardiomyocytes. Including these dynamics in computational models enhances their predictive accuracy for how a drug will affect cardiac repolarization and, thus, the risk of torsades de pointes (TdP).

We derived 11 in silico biomarkers from the CiPAORdv1.0 ventricular cell model with hERG dynamic characteristics. By selecting the optimal set among these biomarkers for a stacking ensemble machine learning model, we aimed to enhance the predictive capabilities for cardiac toxicity risk. Our findings, presented in Tables 1 and 2, provide valuable insights into the effectiveness of this approach. show that a seven‐biomarker group achieves optimal balance, by achieving an AUC score of 1.00 (0.90–1.00) for high risk, 0.97 (0.84–1.00) for intermediate risk, and 1.00 (0.87–1.00) for low risk, aligning with CiPA standards. This approach outperforms the three, five, and eleven‐biomarker configurations, demonstrating the utility of machine learning in biomarker selection for clinical application.

When analyzing the ranking based on SHAP values of the top seven most influential biomarkers for TdP risk prediction (Figure 2) and the impact of ion channel variations on these biomarkers (Figure 3), it becomes apparent that certain key ion channels, including CaL, Kr, NaL, and Na, play a significant role in modifying TdP risk predictions. Variations in these four ion channels have a substantial effect on the changes in qNet, consistent with findings from Chang et al. 10 Similar to qNet, the APD (APD50 and APD90) and CaD (CaD50 and CaD90) display high SHAP values across three baseline ANN models, suggesting they are crucial for TdP risk classification. This aligns with Lancaster et al. 5 who found that APD50 and diastolic calcium concentration are significant biomarkers for predicting drug‐induced TdP risk. Additionally, among these channels, CaL and Na channels significantly influence Vmpeak and dVmdtmax, which are also key biomarkers for TdP risk prediction. Therefore, enhancing in vitro drug inhibition experiments targeting these four ion channels could be essential for improving overall TdP risk prediction accuracy.

Furthermore, as shown in Figure 4, the variation in biomarkers toward higher drug concentrations indicates a crucial point: the choice of drug concentration where the biomarker is collected for the input to the machine learning models may affect the classification performance as different ranges of drug concentration can yield varied order of drug risk level according to the biomarker values (as previously proposed by Li et al. by using qNet as the sole biomarker for ranking the TdP risk of drugs). 11 According to Chang et al., 10 the range of drug concentrations used to evaluate the TdP risk of drugs is from 1 to 4× C max as most experimental data is available within this range. Therefore, biomarker data from outside the 1 to 4× C max can inherit high uncertainties and should not be used for analysis. Moreover, relying on a single biomarker is less accurate due to variability. Multiple biomarkers and advanced machine learning (ML) techniques improve classification, integrating diverse inputs for better TdP risk prediction by capturing complex factors affecting drug safety.

The robustness of our proposed model is demonstrated by its excellent performance, even when the roles of the training and testing drugs are interchanged. According to CiPA evaluation standards, we initially used 12 drugs for training and 16 for testing. The model also showed superior performance when the configuration was reversed, with 16 drugs used for training and 12 for testing, as detailed in Tables S4 and S5. However, CiPA guidelines recommend using more testing drugs than training drugs to evaluate better the robustness and generalization ability of a ML model.

In high clinical exposure and therapeutic scenarios, the consistently high AUC values across all biomarker groups for high, intermediate, and low TdP risk categorization highlight the model's potential as a reliable tool for TdP risk assessment. Its adaptability to fluctuations in drug concentrations is critical to ensuring patient safety. Our model demonstrates an excellent performance in predicting TdP risk under high clinical and therapeutic according to the CiPA evaluation standard as shown in Table S6. Moreover, using a diverse human ventricular cell model population to capture interindividual variability strengthens its applicability to real‐world clinical settings.

Although this study presents new findings and demonstrates improved performance in predicting the TdP risk of drugs, it has several limitations. First, the study focused solely on one cardiac cell model. Future work could consider another model, such as the one proposed by Tomek et al. The ToR‐ORd model, developed to address specific limitations of the ORd model, offers a more consistent depiction of human ventricular myocardial cells. Using the ToR‐ORd model, the biomarkers derived would more accurately reflect physiological responses, leading to better predictive performance of the stacking ensemble ML approach and increased robustness in TdP risk classification.

Second, the study relies on single‐cell electrophysiological simulations, which may not provide as comprehensive insights as tissue‐ or organ‐level simulations. A critical biomarker for TdP risk assessment is the QT interval, with significant prolongation indicating higher TdP risk. In silico QT intervals can be obtained through tissue‐ or organ‐level simulations. 24 The study by Mann et al. 25 used a convergence of models to address the necessary ion channel balance to match observed QTc data from long QT syndrome. Optimizing ion channel balances in our study might change the classification performance of the ML model. Changes in model prediction results during training, validation, and testing could reflect the influence of altered biomarker values on TdP risk prediction. The grid search (GS) method applied for fine‐tuning the model's hyperparameters can help achieve optimum performance despite changed biomarker inputs.

Additionally, given the excellent prediction performance shown by our stacking ensemble ML model, it can also be trained, validated, and tested with in silico biomarkers derived from simulations of cardiomyocytes models for further studies. Incorporating the human‐induced pluripotent stem cell (hiPSC) model into the stacking ensemble ML to predict TdP risk or QT prolongation in humans can be an interesting direction. 26 , 27 , 28 This aligns with the CiPA‐based cardiac safety paradigm, potentially minimizing the necessity for experimental human stem cell evaluation. Using our approach, the prediction performance of hiPSC‐based evaluation can be optimized for valuable outcomes.

## Section: AUTHOR CONTRIBUTIONS

Y.N.F. and A.I.Q. wrote the manuscript; K.M.L. designed the research; Y.N.F. and M.A.P. performed the research; Y.N.F. and K.M.L. analyzed the data; and A.M. and U.L.H. contributed new analytical tools.

## Section: FUNDING INFORMATION

This research is partially supported by the Ministry of Food and Drug Safety (22213MFDS3922), the NRF (National Research Foundation of Korea) under the Basic Science Research Program (2022R1A2C2006326), and the MSIT (Ministry of Science and ICT), Korea, under the Grand Information Technology Research center support program (IITP‐2022‐2020‐0‐01612) supervised by the IITP (Institute for Information & communications Technology Planning & Evaluation).

## Section: CONFLICT OF INTEREST STATEMENT

The authors declared no competing interests for this work.

## Section: Supporting information

Data S1.

Data S2.

Data S3.

Data S4.

## Section: Text

Fuadah YN, Qauli AI, Pramudito MA, Marcellinus A, Hanum UL, Lim KM. A stacking ensemble machine learning model for evaluating cardiac toxicity of drugs based on in silico biomarkers. CPT Pharmacometrics Syst Pharmacol. 2024;13:2159‐2170. doi: 10.1002/psp4.13229

## Section: Contributor Information

Ali Ikhsanul Qauli, Email: ali.ikhsanul.q@ftmm.unair.ac.id.

Ki Moo Lim, Email: kmlim@kumoh.ac.kr.

## Section: Associated Data

Data S1.

Data S2.

Data S3.

Data S4.

## Section: Associated Data › Supplementary Materials

Data S1.

Data S2.

Data S3.

Data S4.


---

# ADMET-AI: a machine learning ADMET platform for evaluation of large-scale chemical libraries

- **Authors:** Kyle Swanson, Parker Walther, Jeremy Leitz, Souhrid Mukherjee, Joseph C Wu, Rabindra V Shivnaraine, James Zou
- **Issuer:** Bioinformatics (Oxford, England)
- **Type:** Scientific article
- **Published:** 2024-07-01
- **Language:** en
- **DOI:** 10.1093/bioinformatics/btae416
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38913862/
- **Licence:** CC-BY

## Section: Abstract

AbstractMotivationThe emergence of large chemical repositories and combinatorial chemical spaces, coupled with high-throughput docking and generative AI, have greatly expanded the chemical diversity of small molecules for drug discovery. Selecting compounds for experimental validation requires filtering these molecules based on favourable druglike properties, such as Absorption, Distribution, Metabolism, Excretion, and Toxicity (ADMET).ResultsWe developed ADMET-AI, a machine learning platform that provides fast and accurate ADMET predictions both as a website and as a Python package. ADMET-AI has the highest average rank on the TDC ADMET Leaderboard, and it is currently the fastest web-based ADMET predictor, with a 45% reduction in time compared to the next fastest public ADMET web server. ADMET-AI can also be run locally with predictions for one million molecules taking just 3.1 h.Availability and implementationThe ADMET-AI platform is freely available both as a web server at admet.ai.greenstonebio.com and as an open-source Python package for local batch prediction at github.com/swansonk14/admet_ai (also archived on Zenodo at doi.org/10.5281/zenodo.10372930). All data and models are archived on Zenodo at doi.org/10.5281/zenodo.10372418.

## Section: 1 Introduction

The curation of large chemical repositories and advances in algorithms and computational hardware have significantly expanded the scale of in silico drug discovery campaigns. Structure-based virtual screening, pharmacophore modelling and, in particular, high-throughput molecular docking (HTMD) have been used to screen over a billion molecules against therapeutic targets of interest (Lyu et al. 2023). More recently, generative artificial intelligence (AI) approaches have been developed to design a vast array of compounds that are optimized for a particular therapeutic effect (Jacobs et al. 2021). Both HTMD and generative AI approaches yield a large number of potential hits with high efficacy, but many of these hits are not ideal for therapeutic development because they do not possess druglike properties (Bender et al. 2021). As a result, rapid and accurate screening of these hits for ideal druglike properties is critical for advancing molecules with higher probabilities of success (Feinberg et al. 2020). Specifically, for a small molecule to be at the centre of a therapeutic strategy and proceed from discovery to clinical trials, the compound must possess optimal Absorption, Distribution, Metabolism, Excretion, and Toxicity (ADMET) properties.

Here, we have developed ADMET-AI, a simple, fast, and accurate platform for ADMET property prediction that includes both a web interface and a Python package for local prediction (Fig. 1). ADMET-AI uses a graph neural network called Chemprop-RDKit (Fig. 1A), which was trained on 41 ADMET datasets from the Therapeutics Data Commons (TDC). ADMET-AI surpasses existing ADMET prediction tools in terms of speed and accuracy (Fig. 1B and C). Moreover, it provides additional useful features such as local batch prediction (Fig. 1D) and contextualized ADMET predictions using a reference set of approved drugs; these features are missing in most of the current ADMET prediction tools. We make ADMET-AI freely available and open-source as a resource to aid in the evaluation of large-scale chemical libraries for druglike compounds (Fig. 1E).

Overview of ADMET-AI. (A) An illustration of training an ADMET-AI graph neural network Chemprop-RDKit model. (B) The overall rank of ADMET-AI models on the Therapeutics Data Commons ADMET leaderboard of 22 ADMET datasets. Representative overall categories predicted by ADMET-AI are shown below. Error bars indicate standard error across datasets. (C) The computational efficiency of ADMET-AI. Left panel, the time (in seconds, median of three trials) for the ADMET-AI web server and other common ADMET web servers to make predictions on 1, 10, 100, or 1000 molecules from the DrugBank reference set. ADMETboost and PreADMET are limited to one molecule. Since pkCSM and SwissADME are limited to 100 and 200 molecules, respectively, their 1000 molecule times are computed as 100 molecule time ×10. Right panel, the time (in hours, median of three trials) for the ADMET-AI web server and various hardware configurations running the ADMET-AI local command line tool to make predictions on 1 million molecules from the DrugBank reference set (1000 copies of the 1000 molecule DrugBank set). Since the ADMET-AI web server is currently limited to 1000 molecules, its 1 million molecule time is computed as 1000 molecule time ×1000. (D) Commands needed to install and run the local version of ADMET-AI, either as a command line tool or as a Python module. (E) Predictions displayed on the ADMET-AI website (admet.ai.greenstonebio.com).

## Section: 2 Model development › 2.1 Data

ADMET-AI uses 41 ADMET datasets (10 regression, 31 classification) from the Therapeutics Data Commons (TDC, v0.4.1) (Huang et al., 2021b) . Of those 41 datasets, 22 datasets (9 regression, 13 classification) form the TDC ADMET Leaderboard (tdcommons.ai/benchmark/admet_group/overview), which enables a side-by-side comparison of ADMET-AI compared to other ADMET prediction models. In addition, from the 41 ADMET datasets, two multi-task datasets were created, one containing all 10 regression datasets and one containing all 31 classification datasets. This enables the training of just two models (one regression, one classification) that cover all 41 ADMET properties. Summary statistics for the ADMET datasets are listed in Supplementary Table S1, and further details on the preparation of the datasets are in the supplementary methods.

## Section: 2 Model development › 2.2 Model

ADMET-AI uses a deep learning model architecture for ADMET prediction called Chemprop-RDKit (available in Chemprop, v1.6.1) (Yang et al. 2019). Chemprop-RDKit consists of a graph neural network called Chemprop that is augmented with 200 physicochemical molecular features that are computed by the cheminformatics package RDKit (v2023.3.3) (rdkit.org). The Chemprop graph neural network computes simple features for each atom (e.g. atom type) and each bond (e.g. bond type) and then runs several steps of message passing with neural network layers to aggregate atom and bond information across the molecule to build a single representation of the whole molecule. This representation is then concatenated with the 200 RDKit features, and the combined representation is passed through several feed-forward neural network layers to predict one or more endpoints, depending on the dataset.

For each TDC dataset, one Chemprop-RDKit model was trained for each of the five train/validation/test splits, and the average performance across the five test splits for that dataset was recorded. At inference time, for each dataset, the average prediction is computed from an ensemble of models containing the five models trained on the five splits of that dataset. Ensembling is used since it can overcome incorrect biases in individual models and thereby improve the performance and robustness of the ensemble (Ali and Pazzani 1996).

## Section: 2 Model development › 2.3 Results

ADMET-AI has the best average rank among all models (Hu et al. 2019, Xiong et al. 2020, Huang et al. 2021a, Lee et al. 2021, Boral et al. 2022, Kipf and Welling 2017) that have been evaluated on the 22 datasets in the TDC ADMET Leaderboard (Fig. 1B, Supplementary Fig. S1). While other models are accurate on only a few ADMET properties, ADMET-AI is the best on average across all ADMET properties, thereby making it ideal for comprehensive ADMET analysis.

Across all 41 TDC ADMET datasets, ADMET-AI models trained on each dataset individually (‘single-task’) had overall strong performance, with an R2 >0.6 for five of the ten regression datasets and an AUROC (area under the receiver operating characteristic curve) >0.85 for 20 of the 31 classification datasets (Supplementary Fig. S2). ADMET-AI models trained on the two multi-task datasets achieved very similar performance (Supplementary Fig. S2). Notably, the two multi-task models (one for regression, one for classification) make predictions for all the properties significantly faster than the 41 single-task models. Therefore, the multi-task models were deployed in the ADMET-AI web server. The web server uses ensembles of the five models for each property to make predictions due to the benefit of ensembling (Supplementary Fig. S3).

Complete performance results are in Supplementary Table S1.

## Section: 3 ADMET-AI web server

The ADMET-AI web server was built using Flask (v2.3.2) (flask.palletsprojects.com/en/2.3.x), which is a Python-based micro web framework. ADMET-AI possesses an intuitive user interface to display the predicted ADMET properties. In addition, each predicted ADMET value is contextualized via a comparison to a reference set of molecules from the DrugBank as described below. The ADMET-AI models can also be run locally for high-throughput ADMET prediction. Both as a web server and as a local package, ADMET-AI is significantly faster than publicly available ADMET prediction tools.

## Section: 3 ADMET-AI web server › 3.1 Drugbank reference

ADMET predictions can be difficult to interpret in isolation and can be better evaluated within the context of drugs with a similar therapeutic indication. As such, ADMET-AI incorporates a point of reference by comparing each query molecule to a set of approved molecules. This unique feature provides useful context for interpreting ADMET predictions and guides the user to the range of ADMET properties needed for their drug discovery project. ADMET-AI, therefore, curated a list of 2579 drugs from the DrugBank (v5.1.10) (Wishart et al. 2018) that have obtained regulatory approval as a reference set (Supplementary Table S2). The ADMET-AI multi-task models were applied to make predictions on these molecules for all ADMET endpoints. For any molecule queried on the ADMET-AI website, ADMET-AI computes the percentile of that molecule’s ADMET predictions relative to this DrugBank reference. Furthermore, since it is known that different classes of drugs have different ADMET requirements (e.g. acceptable toxicity for antineoplastics is much higher than that for antibiotics), the ADMET-AI website, therefore, allows the user to select an appropriate subset of the DrugBank reference based on Anatomical Therapeutic Chemical (ATC) codes (atcddd.fhi.no/atc/structure_and_principles) to use as the reference set for computing percentiles to add perspective during evaluation (common ATC codes are shown in Supplementary Fig. S4).

## Section: 3 ADMET-AI web server › 3.2 User experience

Users access the web interface of ADMET-AI at admet.ai.greenstonebio.com as shown in Fig. 1E. There are three options to input molecules: (i) by entering SMILES in a text box with each SMILES on a line, (ii) by uploading a CSV file containing multiple SMILES, or (iii) by drawing the structure of the molecule using an interactive tool that converts the drawing to a SMILES. Users can make predictions on up to 1000 molecules at a time. Next to the SMILES input, the user can create the DrugBank reference set by selecting an ATC code or by using the default of all DrugBank-approved molecules.

The 41 ADMET predictions, along with eight physicochemical properties computed by RDKit, are displayed on the website for up to 25 molecules (Fig. 1E), with predictions for the remaining molecules available for download. For each predicted molecule, a radar plot is shown as a quick summary of key components of druglikeness, including hERG toxicity (i.e. potential for cardiotoxicity and arrhythmias), blood–brain barrier (BBB) penetration (i.e. potential for CNS effects), solubility, oral bioavailability (i.e. ease of drug delivery), and potential for toxicity. The complete set of ADMET predictions for the molecule is shown in a set of tables, and each prediction is paired with the percentile of that prediction with respect to the DrugBank-approved reference set. For regression properties, the predicted values are displayed in the same units as in the dataset used to train the model [e.g. half life (t1/2) is predicted in terms of hours]. For binary classification properties, the predicted values are the probability that the molecule has the property (e.g. the probability of BBB penetration). For a simultaneous comparison of multiple molecules, ADMET-AI displays a summary scatter plot with two user-selected ADMET properties (one on each axis) as compared to the DrugBank reference set.

## Section: 3 ADMET-AI web server › 3.3 Local ADMET prediction

The ADMET-AI website enables fast and accurate ADMET prediction with no installation or computational experience required. ADMET-AI is also available as a Python package (github.com/swansonk14/admet_ai) for local ADMET prediction using the same multi-task ADMET models that power the ADMET-AI website. The single-task models are also available for download and use. The local version of ADMET-AI includes a command line tool called admet_predict that allows users to make predictions on massive datasets, such as those originating from large docking campaigns or generative AI models, that would exceed the computational capacity of the web server (Fig. 1D). The ADMET models can also be incorporated directly within a user’s local computational pipeline by importing the ADMET-AI models in just a few lines of Python code (Fig. 1D). The local version of ADMET-AI has no limit on the number of molecules that can be run through the model, and it automatically uses a GPU, if available, and multiple CPUs to increase prediction speed (Fig. 1C). The local version is also ideal for users who are privacy conscious and want to avoid putting their proprietary compounds through a web server, although it should be noted that the ADMET-AI web server does not store information on any molecules that are queried.

## Section: 3 ADMET-AI web server › 3.4 Comparison to alternatives: speed

While there are several publicly available ADMET prediction web servers currently available, ADMET-AI provides a powerful combination of accuracy, speed, and flexibility along with unique features such as the DrugBank reference set and local prediction. In addition, ADMET-AI is fully open source, making it easy to build upon and extend.

One of the most important qualities of an ADMET tool is the speed with which it can predict the ADMET properties of molecules. This is increasingly important as drug discovery projects rapidly grow in scale. To that end, the speed of ADMET-AI was compared to six other web servers that predict a wide range of ADMET properties: SwissADME (Daina et al. 2017), ADMETLab 2.0 (Xiong et al. 2021), pkCSM (Pires et al. 2015), vNN-ADMET (Schyman et al. 2017), ADMETboost (Tian et al. 2022), and PreADMET (Lee et al. 2003, Lee et al. 2004). Each server was used to make ADMET predictions for 1, 10, 100, or 1000 molecules from the DrugBank reference (Supplementary Table S3), and the median of three trials was recorded. ADMET-AI is the fastest publicly available web server for any number of molecules, with a 45% reduction in time over the next best server for 1000 molecules (Fig. 1C, left panel).

For truly large-scale analysis, local prediction is preferable to take advantage of greater CPU parallelism and GPU availability. To illustrate this, local versions of ADMET-AI with 8 or 32 CPU cores and with or without a GPU were used to make predictions on one million molecules from the DrugBank reference (1000 copies of the 1000 molecule DrugBank set). The local prediction speed was compared to the speed of the ADMET-AI web server, which uses two CPU cores and no GPU. Local ADMET-AI prediction with 32 CPU cores and a GPU reduces the ADMET prediction time from 28.1 h with the web server to 3.1 h locally, representing a further 89% reduction in time (Fig. 1C, right panel). Even a simple setup of 8 CPU cores and no GPU can make one million predictions in just 5 h. Therefore, ADMET-AI enables fast, large-scale ADMET prediction.

## Section: 4 Conclusion

ADMET-AI is a simple, fast, and accurate platform for ADMET prediction. ADMET-AI uses a Chemprop-RDKit graph neural network for ADMET prediction that is currently the most accurate model on average across the TDC ADMET leaderboard. ADMET-AI is the fastest web-based ADMET predictor with a 45% reduction in time compared to the next fastest public ADMET web server. ADMET-AI uniquely provides context by comparing ADMET predictions on input molecules to predictions on approved drugs from the DrugBank, which can optionally be filtered to a specific drug category by ATC code. The ADMET-AI platform also includes a Python package with a command line tool for large-scale evaluation and a Python module for use within other drug discovery tools (e.g. generative AI models). ADMET-AI is an open-source, free, and easy-to-use platform that can serve as a powerful drug discovery tool for identifying compounds with favourable ADMET profiles for further development.


---

# Advances in machine-learning approaches to RNA-targeted drug design

- **Authors:** Yuanzhe Zhou, Shi-Jie Chen
- **Issuer:** Artificial intelligence chemistry
- **Type:** Scientific article
- **Published:** 2024-02-06
- **Language:** en
- **DOI:** 10.1016/j.aichem.2024.100053
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38434217/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

RNA molecules play multifaceted functional and regulatory roles within cells and have garnered significant attention in recent years as promising therapeutic targets. With remarkable successes achieved by artificial intelligence (AI) in different fields such as computer vision and natural language processing, there is a growing imperative to harness AI's potential in computer-aided drug design (CADD) to discover novel drug compounds that target RNA. Although machine-learning (ML) approaches have been widely adopted in the discovery of small molecules targeting proteins, the application of ML approaches to model interactions between RNA and small molecule is still in its infancy. Compared to protein-targeted drug discovery, the major challenges in ML-based RNA-targeted drug discovery stem from the scarcity of available data resources. With the growing interest and the development of curated databases focusing on interactions between RNA and small molecule, the field anticipates a rapid growth and the opening of a new avenue for disease treatment. In this review, we aim to provide an overview of recent advancements in computationally modeling RNA-small molecule interactions within the context of RNA-targeted drug discovery, with a particular emphasis on methodologies employing ML techniques.


---

# Advancing Anticancer Drug Discovery: Leveraging Metabolomics and Machine Learning for Mode of Action Prediction by Pattern Recognition

- **Authors:** Mohamad Saoud, Jan Grau, Robert Rennert, Thomas Mueller, Mohammad Yousefi, Mehdi D Davari, Bettina Hause, René Csuk, Luay Rashan, Ivo Grosse, Alain Tissier, Ludger A Wessjohann, Gerd U Balcke
- **Issuer:** Advanced science (Weinheim, Baden-Wurttemberg, Germany)
- **Type:** Scientific article
- **Published:** 2024-10-21
- **Language:** en
- **DOI:** 10.1002/advs.202404085
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39431333/
- **Licence:** CC-BY

## Section: Abstract

AbstractA bottleneck in the development of new anti‐cancer drugs is the recognition of their mode of action (MoA). Metabolomics combined with machine learning allowed to predict MoAs of novel anti‐proliferative drug candidates, focusing on human prostate cancer cells (PC‐3). As proof of concept, 38 drugs are studied with known effects on 16 key processes of cancer metabolism, profiling low molecular weight intermediates of the central carbon and cellular energy metabolism (CCEM) by LC‐MS/MS. These metabolic patterns unveiled distinct MoAs, enabling accurate MoA predictions for novel agents by machine learning. The transferability of MoA predictions based on PC‐3 cell treatments is validated with two other cancer cell models, i.e., breast cancer and Ewing's sarcoma, and show that correct MoA predictions for alternative cancer cells are possible, but still at some expense of prediction quality. Furthermore, metabolic profiles of treated cells yield insights into intracellular processes, exemplified for drugs inducing different types of mitochondrial dysfunction. Specifically, it is predicted that pentacyclic triterpenes inhibit oxidative phosphorylation and affect phospholipid biosynthesis, as confirmed by respiration parameters, lipidomics, and molecular docking. Using biochemical insights from individual drug treatments, this approach offers new opportunities, including the optimization of combinatorial drug applications.

## Section: Introduction

Anti‐cancer drug discovery usually starts with in vitro viability assays using cancer cell line models, which identify cytotoxic chemicals with high anti‐proliferative capacity. At that early stage, knowledge regarding the mechanisms by which cell growth is inhibited is limited. Therefore, early characterization of the mechanism of action (MeA) or mode of action (MoA) of a drug has the potential to advance the drug development process.[ 1 ] MeA refers to the specific biochemical interaction between a compound and its molecular targets, while MoA refers to the physiological effects caused by the compound of study. Metabolomics can help delineating MoAs by identifying metabolic changes in cells upon drug exposure, which are reflected in complex metabolic patterns (metabotypes). Prediction of the MoA for uncharacterized compounds is based on the hypothesis that drugs with similar targets will have similar effects on the metabolome.[ 2 ] Machine learning (ML) can then be employed to predict the MoA(s) of a compound by using reference drugs with known MoA as training set, as has been recently demonstrated for antimicrobial compounds.[ 2 , 3 , 4 ] While the focus of this study is on the MoA of potential anti‐cancer drugs, machine‐learning methods have previously been applied to understand the influence of perturbations on metabolic networks in the context of anti‐bacterial drugs and nanoparticles.[ 5 , 6 ] Notably, the machine learning methods applied show similarities to those considered in this study, namely k‐nearest neighbor classifiers and Random Forests.[ 6 ]

In cancer biology, such comprehensive studies of drug responses at the metabolites level are just beginning to emerge. Using prostate cancer cell lines, cell viability assays, and metabolomics, Lu et al. screened synergistic effects of a glutaminase inhibitor and a library of 292 anti‐cancer compounds.[ 7 ] Lately, multi‐omics data of 54 cancer cell lines involving metabolomics analysis were used to correlate transcriptional regulation of tumor growth with metabolism.[ 8 ] Anglada‐Girotto et al. combined CRISPRi and metabolomics to annotate drug libraries in E.coli.[ 9 ] In implementing this combined approach, also human A549 alveolar cancer cells were exposed to 14 anti‐cancer drugs. In this side study, a strong accumulation of dUMP was observed only for those drugs targeting thymidylate synthase (TYMS), which was associated with a strong and selective similarity of metabolite patterns between genetically and chemically induced suppression of TYMS. This supports our hypothesis that using suitable analytical techniques, metabolomics can reveal crucial insights into the regulation of the central carbon and energy metabolism (CCEM).

The discovery that cancer cells exhibit abnormal regulation of central metabolic pathways led to the creation of highly specific tumor inhibitors.[ 10 , 11 , 12 , 13 , 14 ] These inhibitors primarily target cancer cells by disrupting key processes such as glucose and glutamine uptake or metabolism, as well as blocking serine synthesis.[ 15 , 16 , 17 ] Furthermore, in many cancers, pathological cell proliferation is associated with increased biosynthesis of nucleotides, acyl‐ and prenyl‐lipids. Therefore, metabolic inhibitors of cancer cell proliferation affect essential metabolic pathways such as de novo biosynthesis of NAD, the oxidative pentose phosphate pathway (OPP), fatty acid synthesis or the mevalonate pathway.[ 18 , 19 , 20 ]

Some chemotherapeutics such as taxol, vincristine or etoposide modify non‐metabolic targets like the cytoskeleton or affect DNA replication.[ 21 , 22 ] The PI3K/AKT/mTOR signaling pathway is another prominent target for cancer treatment since it controls the metabolic activity of key CCEM pathways.[ 23 , 24 ] Since these targets may, therefore, have indirect effects on the CCEM, it is crucial to investigate whether metabolic patterns derived from cell treatments with microtubule inhibitors, topoisomerase inhibitors, or PI3K/AKT/mTOR inhibitors accurately predict their MoAs.

In this study, we employed a multi‐targeted approach to analyze 188 hydrophilic metabolites of the central carbon and energy metabolism (CCEM).[ 25 ] We sought to predict the MoA(s) for new anti‐proliferative compounds in the cancer cell model PC‐3 using a combination of machine learning and CCEM reference profiles derived from treatments with well‐known cytotoxins or anti‐cancer drugs. Two probabilistic prediction models were developed and are discussed in view of their ability to predict single or even complex MoAs. Additionally, the analysis of metabolite signatures enhances our comprehension of regulatory principles in the CCEM upon drug treatment, with a focus on mitochondrial inhibitors. To validate selected model predictions, we performed wet lab tests and enzyme docking simulations, using pentacyclic triterpenes as an example.

## Section: Results

Hierarchical cluster analysis of metabolic patterns induced by 38 reference compounds inhibiting different molecular targets modulating the metabolism of prostate cancer cells (PC‐3). Aggregated leaves of hexuplicate experimental data are presented. Metabolic patterns of AKT inhibitors were so similar that individual replicates of the inhibitors PR and OR co‐clustered with each other. For this reason, we defined a mixed group “PR/OR”. A complete cluster analysis of all individual training samples is presented in Figure S2 (Supporting Information). Compounds: BETA – betulinic acid, MASA – maslinic acid, BOWA – boswellic acid, EMOD – emodin, 2DNP – 2,4‐dinitrophenol, CCCP – carbonyl cyanide chlorophenylhydrazone, HEXA – hexachlorophene, BITN – bithionol, CYAN – potassium cyanide, AZID – sodium azide, MALO – malonic acid, 3‐NP – 3‐nitropropionic acid, AMYC – antimycin A, ATOV – atovaquone, METF – metformin, ROTN – rotenone, GNE – GNE‐617, GMX – GMX1778, FK866 – FK866, 6‐AN – 6‐aminonicotinamide, WRTN – wortmannin, RAPA – rapamycin, ALPL – alpelisib, PTXL – paclitaxel, VINC – vincristin, MITO – mitoxantrone, CMPT – camptothecin, DOXO – doxorubicin, IRIN – irinotecan, PRFN (PR) – perifosine, ORID (OR) – oridonin, ETOP – etoposid, EGCG – epigallocatechin gallate, APIG – apigenin, GPDi – glucose‐6‐phosphate dehydrogenase inhibitor, LOVA – lovastatin, ATOR – atorvastatin, FLUV – fluvastatin. MoA: AKT – protein kinase B (AKT), Antimicrotubule, CPLX I – complex I, CPLX II – complex II, CPLX III – complex III, CPLX IV – complex IV, FAB – fatty acid biosynthesis, GDH – glutamate dehydrogenase, HMG‐CoAr – HMG‐CoA reductase, mTOR – PI3K/mTOR signaling, NAMPT – nicotinamide phosphoribosyltransferase, OPP – oxidative pentose phosphate pathway, PLB – phospholipid biosynthesis, TopoI – topoisomerase I, TopoII – topoisomerase II, Uncoupler – uncoupling of oxidative phosphorylation.

Relative abundance of selected CCEM intermediates after OXPHOS inhibition of the complexes I‐IV, application of uncouplers, inhibition of nicotinamide phosphoribosyltransferase (NAMPT), and the oxidative pentose phosphate pathway. Data depict average log2‐fold changes of cell number‐normalized peak areas obtained after 48 h drug treatment (n = 6) relative to vehicle control (n = 6). Legends of MoA and compound labels are given in Figure 1 and Tables S1 and S2 (Supporting Information).

Relative abundance of selected intermediates from the pentose phosphate pathway, TCA cycle and pyrimidine biosynthesis in response to CPLX I‐IV inhibition. The heatmap displays the log₂ fold changes of these metabolites compared to untreated controls across treatments with inhibitors of CPLX I, II, III, and IV, respectively (from left to right). The mitochondrial coenzyme Q junction links pyrimidine nucleotide biosynthesis to the mitochondrial ETC. In order to fuel ATP formation, OXPHOS generates a proton gradient across the inner mitochondrial membrane through the electron transfer chain (ETC), which involves four protein complexes (CPLX I‐CPLX IV). Both CPLX I and CPLX II transfer electrons to ubiquinone (coenzyme Q, CoQ) in the inner mitochondrial membrane resulting in ubiquinol (UQH2) reconstitution. By contrast, CPLX III is responsible for the reoxidation of ubiquinol to ubiquinone, which is important not only for the function of CPLX I and CPLX II. CPLX IV then transfers the electrons to molecular oxygen. Metabolite abbreviations are given in Table S2 ((Supporting Information)). This graph was created with BioRender.com.

Performance evaluation and MoA prediction by machine learning approaches. A) Mean accuracy of k‐nearest neighbor classifier (kNN), Lasso‐based approach (Lasso), and Random Forest classifier (Random Forest) in leave‐one‐out cross‐validation over the drugs in the training set. B,C) Mean accuracy per MoA, where entries on the main diagonal correspond to correct classification and off‐diagonal elements indicate alternative MoA (row), B‐Lasso, C‐Random Forest. D,E) Normalized prediction scores for the MoAs of four cytotoxic compounds obtained by D‐Lasso‐, and E‐Random Forest classifier. An alternative visualization of the prediction results is provided in Figure S12 (Supporting Information), which shows the fraction of replicates assigned to a specific MoA according to the largest prediction score. MoA abbreviations are listed in Figure 1, GLYA – glycyrrhetinic acid, AAHR – asiatic acid homopiperazinyl rhodamine B conjugate, BRST – Breastin (patented Nerium oleander cold water extract), QQrB – cucurbitacin B. The R source code to generate Figure 4A–C is provided in Data S1 (Supporting Information).

## Section: Results › Training of Metabolic Patterns Allows MoA Prediction

In order to establish a reference framework for metabolic responses in the central carbon and energy metabolism (CCEM), we utilized IC50 treatments for 48 h in the PC‐3 prostate cancer cell model using 38 reference compounds with known mechanisms of action (MeA) (Table S1, Supporting Information). We selected the set of 38 compounds based on their diverse drug targets that impede PC‐3 cell growth, sufficient MeA knowledge, and inclusion of at least two drugs for each MeA.[ 11 , 12 , 13 , 14 ] In order to ensure data comparability and reproducibility, we opted to utilize the individual IC50 drug concentrations predetermined for all treatments. This approach ensures that all cell samples are expected to be in a comparable state prior to metabolomics analysis, both in terms of growth phase and growth inhibition. In addition, the use of IC50 concentrations was a good compromise between lower concentrations, such as IC20, which might not sufficiently capture subtle metabolic changes, and higher concentrations, such as IC80, which could obscure results with patterns of apoptosis and necrosis while not providing the minimum required sample material.

A novel methodological approach to obtain the cellular metabolome, as unbiased as possible, was to harvest the cells by using high‐field ultrasound after carefully removing the dead cells, so that the live cells could be dispersed in situ in a cold quenching solution instead of trypsinizing or manually scraping them off[ 26 , 27 ] (Figure S1A, Supporting Information). We analyzed 188 hydrophilic metabolites from cell extracts, with 117 quantified reliably. These were normalized to ensure the sum of signals was proportional to cell counts (Figure S1B, Supporting Information), and then we assessed the similarity across all obtained metabolic profiles (Tables S2 and S3, Supporting Information).[ 25 ]

For the majority of MoA training groups (95%), hierarchical clustering of the metabolic profiles revealed co‐segregation of those training compounds addressing the same target (Figure 1 ). Interestingly, the dendrogram identifies two main clusters: one harboring compounds affecting mitochondrial electron transport processes, oxidative phosphorylation, glutamate and NAD metabolism (cluster I); the second one comprising MoA patterns of other metabolic processes, some of them known to proceed in the cytosol (e.g., hydroxymethylglutaryl‐CoA reduction (HMG‐CoAr; EC 1.1.1.88), or fatty acid biosynthesis by fatty acid synthase (FASN, EC 2.3.1.85) (cluster II).[ 19 , 28 ] Other inhibitors assigned to this cluster are known to impair microtubule formation or degradation, to inhibit topoisomerases, or to modulate PI3K/AKT/mTOR signaling.

Only a few reference compounds in our analysis targeting the same MeA did not co‐cluster, for example, the inhibitors of the oxidative pentose phosphate pathway (OPP), 6‐AN (6‐aminonicotinamide) and G6PDi, both causing accumulation of 6‐phosphogluconate, the substrate of 6‐phosphogluconate dehydrogenase (6‐PGDH, EC 1.1.1.44) (Figure S3, Supporting Information). However, their drug‐induced metabolic patterns in PC‐3 showed different clustering behavior. 6‐AN's pattern co‐segregated with nicotinamide phosphoribosyltransferase (NAMPT, EC 2.4.2.12) inhibitors, while G6PDi's pattern showed higher similarity with protein kinase B (AKT, EC 2.7.11.1) and fatty acid biosynthesis (FAB) (Figure 1). Another interesting finding was that etoposide did not cluster with four other topoisomerase inhibitors tested, suggesting unique metabolic interactions resulting in a distinct metabotype.

Hierarchical cluster analysis of metabolic patterns induced by 38 reference compounds inhibiting different molecular targets modulating the metabolism of prostate cancer cells (PC‐3). Aggregated leaves of hexuplicate experimental data are presented. Metabolic patterns of AKT inhibitors were so similar that individual replicates of the inhibitors PR and OR co‐clustered with each other. For this reason, we defined a mixed group “PR/OR”. A complete cluster analysis of all individual training samples is presented in Figure S2 (Supporting Information). Compounds: BETA – betulinic acid, MASA – maslinic acid, BOWA – boswellic acid, EMOD – emodin, 2DNP – 2,4‐dinitrophenol, CCCP – carbonyl cyanide chlorophenylhydrazone, HEXA – hexachlorophene, BITN – bithionol, CYAN – potassium cyanide, AZID – sodium azide, MALO – malonic acid, 3‐NP – 3‐nitropropionic acid, AMYC – antimycin A, ATOV – atovaquone, METF – metformin, ROTN – rotenone, GNE – GNE‐617, GMX – GMX1778, FK866 – FK866, 6‐AN – 6‐aminonicotinamide, WRTN – wortmannin, RAPA – rapamycin, ALPL – alpelisib, PTXL – paclitaxel, VINC – vincristin, MITO – mitoxantrone, CMPT – camptothecin, DOXO – doxorubicin, IRIN – irinotecan, PRFN (PR) – perifosine, ORID (OR) – oridonin, ETOP – etoposid, EGCG – epigallocatechin gallate, APIG – apigenin, GPDi – glucose‐6‐phosphate dehydrogenase inhibitor, LOVA – lovastatin, ATOR – atorvastatin, FLUV – fluvastatin. MoA: AKT – protein kinase B (AKT), Antimicrotubule, CPLX I – complex I, CPLX II – complex II, CPLX III – complex III, CPLX IV – complex IV, FAB – fatty acid biosynthesis, GDH – glutamate dehydrogenase, HMG‐CoAr – HMG‐CoA reductase, mTOR – PI3K/mTOR signaling, NAMPT – nicotinamide phosphoribosyltransferase, OPP – oxidative pentose phosphate pathway, PLB – phospholipid biosynthesis, TopoI – topoisomerase I, TopoII – topoisomerase II, Uncoupler – uncoupling of oxidative phosphorylation.

Relative abundance of selected CCEM intermediates after OXPHOS inhibition of the complexes I‐IV, application of uncouplers, inhibition of nicotinamide phosphoribosyltransferase (NAMPT), and the oxidative pentose phosphate pathway. Data depict average log2‐fold changes of cell number‐normalized peak areas obtained after 48 h drug treatment (n = 6) relative to vehicle control (n = 6). Legends of MoA and compound labels are given in Figure 1 and Tables S1 and S2 (Supporting Information).

Relative abundance of selected intermediates from the pentose phosphate pathway, TCA cycle and pyrimidine biosynthesis in response to CPLX I‐IV inhibition. The heatmap displays the log₂ fold changes of these metabolites compared to untreated controls across treatments with inhibitors of CPLX I, II, III, and IV, respectively (from left to right). The mitochondrial coenzyme Q junction links pyrimidine nucleotide biosynthesis to the mitochondrial ETC. In order to fuel ATP formation, OXPHOS generates a proton gradient across the inner mitochondrial membrane through the electron transfer chain (ETC), which involves four protein complexes (CPLX I‐CPLX IV). Both CPLX I and CPLX II transfer electrons to ubiquinone (coenzyme Q, CoQ) in the inner mitochondrial membrane resulting in ubiquinol (UQH2) reconstitution. By contrast, CPLX III is responsible for the reoxidation of ubiquinol to ubiquinone, which is important not only for the function of CPLX I and CPLX II. CPLX IV then transfers the electrons to molecular oxygen. Metabolite abbreviations are given in Table S2 ((Supporting Information)). This graph was created with BioRender.com.

Performance evaluation and MoA prediction by machine learning approaches. A) Mean accuracy of k‐nearest neighbor classifier (kNN), Lasso‐based approach (Lasso), and Random Forest classifier (Random Forest) in leave‐one‐out cross‐validation over the drugs in the training set. B,C) Mean accuracy per MoA, where entries on the main diagonal correspond to correct classification and off‐diagonal elements indicate alternative MoA (row), B‐Lasso, C‐Random Forest. D,E) Normalized prediction scores for the MoAs of four cytotoxic compounds obtained by D‐Lasso‐, and E‐Random Forest classifier. An alternative visualization of the prediction results is provided in Figure S12 (Supporting Information), which shows the fraction of replicates assigned to a specific MoA according to the largest prediction score. MoA abbreviations are listed in Figure 1, GLYA – glycyrrhetinic acid, AAHR – asiatic acid homopiperazinyl rhodamine B conjugate, BRST – Breastin (patented Nerium oleander cold water extract), QQrB – cucurbitacin B. The R source code to generate Figure 4A–C is provided in Data S1 (Supporting Information).

## Section: Results › Training of Metabolic Patterns Allows MoA Prediction › Inhibition of Mitochondrial Functions Produces Distinctive Metabotypes

Although cancer cells mainly produce ATP by enhancing glycolytic flux, they still require functional mitochondria,[ 29 , 30 , 31 ] not least since oxidative phosphorylation (OXPHOS) is connected to seven ubiquinone (CoQ)‐dependent mitochondrial dehydrogenases with essential functions in CCEM.[ 32 ] Consequently, targeting different stages of OXPHOS has specific effects on various metabolic processes linked to these CoQ‐dependent mitochondrial dehydrogenases.

Initially, we observed that OXPHOS inhibitors lead to specific patterns of metabolites that are categorized into cluster I (Figure 1). These patterns further subdivide into distinct sub‐clusters depending on which complex (CPLX) of the respiratory chain is inhibited. When CPLX I to IV are inhibited, a consistent pattern becomes evident in certain TCA cycle metabolites. Specifically, levels of cis‐aconitate (ACT), isocitrate (ISOCIT), and succinyl‐CoA (SUC‐CoA) are depleted (Figure 2 ). This pattern is not observed in the case of uncouplers. Remarkably, specific to CPLX I inhibition, neither the accumulation of succinate (SUC) nor the strong depletions of fumarate (FUM) and malate (MAL) that are typical of CPLX II‐IV inhibition is observed (Figure 3 ).

In the cytosol, OXPHOS inhibitors and uncouplers generally induce the accumulation of glycerol 3‐phosphate (Glc3P) (Figure 2). However, just as observed in the TCA cycle, sugar metabolism also displays distinct characteristics when CPLX I inhibition is compared to CPLX II‐IV inhibition. Notably, dihydroxyacetone phosphate (DHAP) showed an up to eight‐fold depletion after CPLX I inhibition but was increased after inhibition of CPLX II‐IV (Figure S4, Supporting Information). Elevating Glc3P synthesis could potentially rescue complex I deficiency by the provision of reducing equivalents to CoQ by the Glc3P shuttle.[ 33 ] Nevertheless, both CPLX I inhibitor treatments, rotenone, and metformin, consistently lead to the depletion of numerous glycolytic and pentose phosphate pathway intermediates, inferring suppressed sugar metabolism in PC‐3 cells and limited substrate availability for the Gl3P shuttle (Figure 2).

In contrast, inhibiting CPLX II‐IV leads to a different glycolytic pattern compared to inhibiting CPLX I, with fructose 1,6‐bisphosphate (FBP), DHAP, and Glc3P accumulating while lower glycolysis metabolites are depleted (Figure 2). This suggests that the glycerol phosphate shuttle responds differently to severe energy depletion in these two cases. It is worth noting that CPLX I contributes to 40% of ATP synthesis through the proton motive force, as reported by Wang et al.[ 14 ] Although, ATP levels did not decrease significantly after inhibiting OXPHOS, the depletion of energy‐conserving phosphocreatine was much more pronounced after CPLX I inhibition (up to 196‐fold decline) compared to CII‐CPLX IV inhibition (five to nine‐fold decline) (Figure S3, Supporting Information).

Moreover, pyrimidines showed reduced concentrations when OXPHOS was inhibited at CPLX I‐IV but not when inhibited with uncouplers (Figure 2). Pyrimidine biosynthesis in mammals starts with CAD, a large trifunctional enzyme (composed of carbamoyl phosphate synthetase (CPS2), aspartate transcarbamoylase, and dihydroorotase). The impact of different modes of OXPHOS inhibition on CAD‐associated metabolites revealed discernible differences between CPLX III and the other respiratory complexes (Figure 3). For instance, inhibition of CPLX I and CPLX II led to a significant decrease (by 33 to 132‐fold) in carbamoylaspartate (CA), while inhibition of CPLX III resulted in 13–45 times higher levels than in control cells. Similarly, dihydroorotate (DHO), the product of the third step catalyzed by CAD, accumulated strongly (20‐36 fold) only after CPLX III inhibition. The following biosynthetic enzyme, dihydroorotate dehydrogenase (DHODH, EC 1.3.1.14), located in the mitochondrial membrane, oxidizes dihydroorotate to orotate (ORO) in a CoQ‐dependent manner.[ 31 , 32 ] Interestingly, OXPHOS inhibition generally caused a general decrease in orotate levels despite the contrasting CA and DHO patterns.

Moreover, in cancer cells, glutamine/glutamate catabolism is a major source to fuel the citric acid cycle with carbon and to provide energy via OXPHOS. Glutamate dehydrogenase (GDH) is a mitochondrial enzyme, which catalyzes the reversible conversion of glutamate to the TCA cycle intermediate 2‐oxoglutarate and ammonium. Consequently, co‐segregation of metabolic patterns after GDH inhibition as compared with the inhibition of other mitochondrial functions in sub‐cluster IA makes sense (Figure 1).

Metabolic patterns of treatments with pentacyclic triterpenes likewise emerge in cluster I. Several pentacyclic triterpene acids have been extensively studied for their anti‐cancer properties, including inhibition of cell proliferation and apoptosis induction.[ 34 ] They target various genes and pathways such as Bcl‐2, NF‐kB, and PI3K/Akt/mTOR, as reviewed by Petrenko et al.[ 35 ] Indication that such triterpenoids also affect phospholipid biosynthesis (PLB) has been provided by micelle models mimicking mitochondrial membranes, where membrane rigidification and increased membrane permeabilization were induced in a dose‐dependent manner.[ 36 ] A recent study investigated the MeA of ursolic acid in human prostate cancer models and found an accumulation of intermediates of PLB.[ 37 ] Nevertheless, the precise impact of pentacyclic triterpenoids on cancer cell metabolism remains hitherto only partially understood.

To further investigate these effects at the metabolic level we assessed the metabotypes of 11‐keto‐β‐boswellic acid (BOWA), maslinic acid (MASA), and betulinic acid (BETA) in PC‐3 cells. Our data suggests that pentacyclic triterpenoids affect mitochondrial metabolism, exhibiting metabolic patterns akin to uncouplers and GDH inhibition (Figure 1). Despite sharing some characteristics of OXPHOS inhibition in their metabolic profiles, they differ from conventional OXPHOS inhibitors, which are further investigated below.

Relative abundance of selected CCEM intermediates after OXPHOS inhibition of the complexes I‐IV, application of uncouplers, inhibition of nicotinamide phosphoribosyltransferase (NAMPT), and the oxidative pentose phosphate pathway. Data depict average log2‐fold changes of cell number‐normalized peak areas obtained after 48 h drug treatment (n = 6) relative to vehicle control (n = 6). Legends of MoA and compound labels are given in Figure 1 and Tables S1 and S2 (Supporting Information).

Relative abundance of selected intermediates from the pentose phosphate pathway, TCA cycle and pyrimidine biosynthesis in response to CPLX I‐IV inhibition. The heatmap displays the log₂ fold changes of these metabolites compared to untreated controls across treatments with inhibitors of CPLX I, II, III, and IV, respectively (from left to right). The mitochondrial coenzyme Q junction links pyrimidine nucleotide biosynthesis to the mitochondrial ETC. In order to fuel ATP formation, OXPHOS generates a proton gradient across the inner mitochondrial membrane through the electron transfer chain (ETC), which involves four protein complexes (CPLX I‐CPLX IV). Both CPLX I and CPLX II transfer electrons to ubiquinone (coenzyme Q, CoQ) in the inner mitochondrial membrane resulting in ubiquinol (UQH2) reconstitution. By contrast, CPLX III is responsible for the reoxidation of ubiquinol to ubiquinone, which is important not only for the function of CPLX I and CPLX II. CPLX IV then transfers the electrons to molecular oxygen. Metabolite abbreviations are given in Table S2 ((Supporting Information)). This graph was created with BioRender.com.

## Section: Results › Training of Metabolic Patterns Allows MoA Prediction › Inhibition of NAD Salvage Leads to Severe ATP Starvation

In cancer cells, NAD is mainly synthesized from nicotinamide via NAD salvage.[ 38 ] NAMPT is the rate‐limiting enzyme in the NAD salvage and is therefore a popular therapeutic target.[ 39 ] Expectedly, NAMPT inhibition results in a metabolic pattern, which is characterized by strong depletion of NAD and NADP but also of their cleavage products ADP‐ribose (ADPR) and ADP‐ribose 2′‐phosphate (ADPPR) (Figure 2). NAD(P) depletion, however, has several consequences leading to a specific metabolic pattern (Figure 1, sub‐cluster IB), one of them is a strong depletion in ATP (Figure 2; Figure S3, Supporting Information). Despite significant cell growth inhibition throughout these experiments, we noticed consistent intracellular levels of three pivotal metabolites within the CCEM. Across all investigated MoAs, except for NAMPT inhibition affecting ATP, a balanced state is maintained for three metabolites: ATP, acetyl‐CoA (AcCoA), and citrate (CIT) (Figure S3, Supporting Information). Intracellular ATP homeostasis is normally maintained under moderate energy deprivation by activation of creatine kinase (EC 2.7.3.2) and adenylate kinase (EC 2.7.4.3). Consistently, for MoAs affecting energy metabolism, we observed reduced levels of energy‐storing phosphocreatine (CREA‐P), and changes in the levels of inosine monophosphate (IMP) and adenylosuccinate (Adenylo‐Suc), the latter two being involved in the purine nucleotide cycle that balances the equilibrium of adenylate kinase (Figure S3, Supporting Information).

Limited availability of NAD also impairs the glycolytic ATP generation in cancer cells since NAD is a required coenzyme of the enzyme glyceraldehyde‐3‐phosphate dehydrogenase which fosters the diversion of the carbon flow into upper glycolysis and pentose phosphate pathway (PPP).[ 20 , 40 ] Accordingly, the metabolic patterns of three NAMPT inhibitors consistently show very strong accumulation of fructose 1,6‐bisphosphate (FBP) and triose phosphates, accompanied by a depletion of intermediates of the lower glycolysis such as 3‐phosphoglyceric acid (3‐PGA), phosphoenolpyruvate (PEP) and pyruvate (PYR) (Figure 2). Lack of NAD(P) also affects intermediate levels of the non‐oxidative pentose phosphate pathway, resulting in increased levels of pentose phosphates and sedoheptulose‐7‐phosphate (S7P), whereas 6‐phosphogluconate (6‐PG) levels of the OPP remain unaffected (Figure 2; Figure S3, Supporting Information). This discriminates NAMPT inhibitors from OXPHOS inhibitors, which do not accumulate pentose or heptulose phosphates, and from direct OPP inhibitors, which strongly accumulate 6‐PG.

However, the metabolic patterns of both OPP inhibitors tested diverged, with only 6‐AN sharing similarities with the metabolic patterns detected after NAMPT inhibition. Notably, the second OPP inhibitor tested, G6PDi, was previously described to inhibit only glucose 6‐phosphate dehydrogenase (G6PDH, EC 1.1.1.49), while 6‐AN is known to inhibit also the second line of NADPH producing enzymes in the OPP, 6‐PGDH.[ 41 , 42 ] Until today, it has not been described whether 6‐AN acts as nicotinamide analog in NAD salvage via NAMPT converting 6‐AN to 6‐amino‐NAD. However, it is known that 6‐amino‐NAD(P) are potent inhibitors of metabolic processes requiring NAD(P) such as glycolysis and OPP.[ 43 ] Therefore, strong commonalities between NAMPT inhibitors and 6‐AN indicate that 6‐amino‐NAD might act as a NAMPT inhibitor as well.

In summary, inhibitors of NAD biosynthesis and OXPHOS inhibitors share great similarities in their metabolic patterns. Since both have a strong influence on cellular energy metabolism, their patterns are also grouped together in a common cluster (cluster I, Figure 1).

## Section: Results › Training of Metabolic Patterns Allows MoA Prediction › Metabolite Patterns Specific for Non‐Mitochondrial Targets

In Figure 1, similarity cluster II comprises MoAs that are not directly associated with mitochondrial targets such as microtubules, fatty acid biosynthesis (FAB) or hydroxymethylglutaryl CoA reductase (HMG‐CoAr). Despite the absence of a direct impact on energy metabolism, compounds in cluster II are grouped according to their MoAs, with patterns that reflect specific influence on central carbon and energy metabolism (CCEM) (Figure S5, Supporting Information).

Cluster analysis further unveiled two sub‐clusters, IIA and IIB. Surprisingly, the metabolic patterns of mTOR inhibitors and AKT inhibitors, both targeting the PI3K/AKT/mTOR pathway, did not cluster in the same sub‐cluster. Even though both AKT and mTOR inhibitors influence the same signaling pathway, their distinct patterns led us to employ orthogonal partial least square analysis (oPLS‐DA) for differentiation. This analysis effectively distinguishes mTOR inhibitors (rapamycin, wortmannin, alpelisib) from AKT inhibitors (oridonine, perifosine) (Figure S6, Supporting Information). Notably, the most significant differences between these MoAs arise from lower levels of 6‐PG, GLc3P, and thymidylates with mTOR inhibitors compared to AKT inhibitors. Conversely, mTOR inhibitors exhibit higher levels of ATP and aspartate compared to AKT inhibitors.

Except of etoposide (ETOP), topoisomerase I and II inhibitors induce a specific metabotype in PC‐3 cells, where several glycolytic intermediates (2‐PGA, 3‐PGA, FPB) and pentose phosphate pathway intermediates (6‐PG, R5P, Ru5P + XU5P, and S7P) were depleted compared to the untreated control. Although Jaccard clustering was unable to further distinguish between the two topoisomerase subtypes, we observed an accumulation of several coenzyme A esters with the topoisomerase I inhibitors camptothecin and irinotecan, which is absent when using topoisomerase II inhibitors mitoxantrone and doxorubicin (Figure S5, Supporting Information, panels A–D).

Furthermore, three statins – lovastatin (LOVA), fluvastatin (FLUV), and atorvastatin (ATOR) – produced a specific metabotype in PC‐3 cells with HMG‐CoA accumulation and reduction of mevalonate 5‐pyrophosphate, which is downstream of HMG‐CoA reductase, as expected (Figure S5, Supporting Information, panels E–G). This pattern comprises a variety of yet unknown metabolic consequences, primarily the inhibition of thymidylate synthesis (lower dTMP and dTTP) accompanied by decreased levels of CA, DHO, and ORO in the early pyrimidine biosynthesis. Further investigation of this link between mevalonate pathway inhibition and pyrimidine biosynthesis would be crucial, not least because the mevalonate pathway is the source of ubiquinone, an essential molecule for pyrimidine biosynthesis, and the electron transport chain.

In summary, in cluster I, co‐segregated metabolic patterns strongly suggest mitochondrial dysfunction, distinguishing between OXPHOS inhibition and NAD metabolism inhibition. These differ distinctly from MoA patterns in cluster II, which aid in identifying MoAs affecting non‐mitochondrial targets or indirectly influencing metabolism.

## Section: Results › Training of Metabolic Patterns Allows MoA Prediction › Evaluation of Different Machine Learning (ML) Approaches to Predict Metabolic Patterns

We apply machine learning with the goal of predicting the MoA of new drugs based on their normalized CCEM profile. Since training data (i.e., CCEM profiles of drugs with known MoA) are of high quality but rather sparse (2‐3 drugs per MoA), we needed to resort to methods that can accomplish classification under these constrains (Tables S1 and S3, Supporting Information). Specifically, we used Random Forests for classification as they provide reliable results with sparse training data. Additionally, Lasso regression was used to explain an unclassified CCEM profile based on a limited selection of classified profiles in the training set. Random Forests are specifically designed for classification problems and aim to avoid overfitting by repeated sampling from the variables considered in decision trees and bootstrapping on the training samples. The Lasso‐based approach fits coefficients for the CCEM profiles of all drugs in the training set to explain the CCEM profile of a test drug (response variable), while regularization yields coefficients different from zero only for those training CCEM profiles that contribute to the fit substantially. The MoAs of training CCEM profiles that obtain large coefficients in the fit and, hence, contribute the most to explaining the test CCEM profile are considered for predicting the MoA of the test drug. As different drugs of the training set may obtain coefficients different from zero, the Lasso‐based approach is expected to handle intermediate/mixed MoAs more appropriately. To establish a baseline, we also incorporated a simple k‐nearest neighbor classifier based on Euclidean distance to train CCEM profiles.

Limitations of the quantity of high‐quality training data available render partitioning into dedicated training and test sets for evaluating the alternative approaches unreasonable. To establish a performance evaluation across all drugs and associated MoAs, nonetheless, we follow a leave‐one‐out cross‐validation strategy. Here, the data are partitioned such that all replicates of one drug (test partition) excluded from the training set, the respective method is trained on the CCEM profiles of the remaining drugs in the training set, and the MoA of the individual replicates of the left‐out drug is predicted. By excluding all replicates of the test drug from the training set, we avoid data leakage in the same manner as for dedicated training and test sets (Tables S4 and Data S1, Supporting Information).

Initially, prediction accuracy (classification rates) was averaged over all drugs sharing the same MoA and then across all MoAs. We found that the baseline model (k‐nearest neighbor) achieved a mean accuracy of 0.655, while the Lasso‐based approach and the Random Forest yielded substantially improved mean accuracy values of 0.854 and 0.864, respectively (Figure 4A; Table S4 and Data S1, Supporting Information). Hence, we consider the Lasso‐based and the Random Forest approaches similarly suited for predicting MoAs of novel drug candidates.

Subsequently, the predictions of both approaches were evaluated on the level of MoAs to achieve a more fine‐grained picture of prediction performance. We found notable differences as to the prediction accuracy of individual MoAs (Figure 4B,C). Certain MoAs, such as CPLX I, III, and IV, GDH, HMG‐CoAr, and NAMPT, can be well predicted using either approach. Other MoAs (OPP, TopI, TopoII, Uncoupler) show reduced prediction performance by either approach, although to a varying degree. Finally, antimicrotubule, CPLX II, and PLB inhibitors can be classified almost perfectly by only one of the two approaches. Misclassification can be considered from two perspectives. First, replicate CCEM profiles of drugs from a certain MoA (e.g., TopoII) may be classified into multiple different MoAs. Second, some MoAs (e.g., AKT with Lasso, CPLX IV with Random Forest) co‐classify with other MoAs, which might be explained by the lack of unique metabolic patterns that allow discrimination between these MoAs. Finally, not all effects of a training inhibitor (“drug”) may be known yet for the cell line used.

Performance evaluation and MoA prediction by machine learning approaches. A) Mean accuracy of k‐nearest neighbor classifier (kNN), Lasso‐based approach (Lasso), and Random Forest classifier (Random Forest) in leave‐one‐out cross‐validation over the drugs in the training set. B,C) Mean accuracy per MoA, where entries on the main diagonal correspond to correct classification and off‐diagonal elements indicate alternative MoA (row), B‐Lasso, C‐Random Forest. D,E) Normalized prediction scores for the MoAs of four cytotoxic compounds obtained by D‐Lasso‐, and E‐Random Forest classifier. An alternative visualization of the prediction results is provided in Figure S12 (Supporting Information), which shows the fraction of replicates assigned to a specific MoA according to the largest prediction score. MoA abbreviations are listed in Figure 1, GLYA – glycyrrhetinic acid, AAHR – asiatic acid homopiperazinyl rhodamine B conjugate, BRST – Breastin (patented Nerium oleander cold water extract), QQrB – cucurbitacin B. The R source code to generate Figure 4A–C is provided in Data S1 (Supporting Information).

## Section: Results › ML Predicts MoAs of Novel Cytotoxic Compounds with Anti‐Cancer Potential

Next, both ML approaches were applied to predict the MoAs of 5‐fluorouracil (5‐FU), one semi‐synthetic, and three plant‐derived drug candidates (Table S1, Supporting Information). The novel compound AAHR, composed of triterpene asiatic acid and rhodamine B, has demonstrated robust cytotoxicity, and the capacity to conquer drug resistance in human preclinical tumor models.[ 44 ] In contrast to glycyrrhetinic acid (GLYA, a pure pentacyclic triterpenoid acid derived from licorice roots), AAHR has a higher toxicity toward PC‐3 prostate cancer cells (Table S1, Supporting Information). Breastin (BRST) is a defined cold‐water extract from leaves of Nerium oleander. Phytochemical characterization revealed several monoglycosidic cardenolides as major constituents.[ 45 ] Cucurbitacin B (QQrB) is a highly toxic tetracyclic triterpene drug derived from Cucurbitaceae plants (Table S1, Supporting Information).

## Section: Results › ML Predicts MoAs of Novel Cytotoxic Compounds with Anti‐Cancer Potential › The Triterpene‐Rhodamine Conjugate AAHR is a Potent OXPHOS Inhibitor

ML approaches suggest that AAHR inhibits multiple targets, of which four out of five point to the inhibition of mitochondrial processes (Figure 4D,E; Figure S7, Supporting Information). Wet lab studies using lipid profiling, Seahorse cell analysis, and CoQ measurements confirmed this prediction showing that AAHR results in acylcarnitine accumulation, reduced mitochondrial respiration and ATP formation, and depletion of cellular CoQ levels (Figures S8,S9A, and S10 and Table S5, Supporting Information). In addition, confocal laser scanning microscopy revealed co‐localization of AAHR with the mitochondrial membrane in PC‐3 cells stained with MitoTracker Green (86% fluorescence co‐localization) (Figure S11, Supporting Information). To understand precisely how AAHR inhibits mitochondrial respiration, we modified the Seahorse assay by replacing individual OXPHOS inhibitors with AAHR (Figure S9B, Supporting Information). Based on the pattern of oxygen consumption rate (OCR) and extracellular acidification rate (ECAR), AAHR does not act as an uncoupling agent or complex V inhibitor. Rather, it inhibits mitochondrial respiration by targeting complex I‐III and/or by an indirect MoA affecting cell respiration.

## Section: Results › ML Predicts MoAs of Novel Cytotoxic Compounds with Anti‐Cancer Potential › Pentacyclic Triterpenes are Potential Modulators of Phospholipid Biosynthesis (PLB)

Both ML models predicted that the MoA of GLYA involves modulation of PLB (Figure 4D,E), which is consistently identified as the most probable MoA of GLYA across all six replicates (Figure S12, Supporting Information). This prediction was supported by a strong accumulation of CDP‐choline and phosphoethanolamine (PEA) with several pentacyclic triterpenes, such as BETA (Figure S5, Supporting Information, panel H). However, CDP‐choline accumulation was not observed for all training compounds and neither for GLYA treatments. Nonetheless, the prediction based on the “PLB”‐metabotype is characteristic.

Accumulation of CDP‐choline is expected when choline phosphotransferase (CPT1, EC 2.7.8.1) or choline/ethanolamine phosphotransferase (CEPT1, EC 2.7.8.2) is inhibited in the Kennedy pathway. To further investigate this issue, we performed in silico docking of pentacyclic triterpenes and the natural substrate CDP‐choline on CEPT1 as well as CPT1 and found that pentacyclic triterpenoids could indeed be strong competitive inhibitors of both enzymes (Figure S12 and Table S6, Supporting Information).

Therefore, we assumed that administration of pentacyclic triterpenoids and AAHR would reduce cellular concentrations of intact phosphatidylcholines (PC) and investigated this by performing lipidomics. Instead of a general reduction, we found individually altered PC levels, reflecting large changes in the global membrane lipid composition after BETA and AAHR treatment (Figure S8, Supporting Information). Among the lipid groups showing the highest alterations were PC and PE as well as sphingomyelins (SM), which derive from PC metabolism. Interestingly, BETA and AAHR treatment induced the formation of lyso‐phosphatidylethanolamines (LPE) and lyso‐PC (LPC), respectively, indicating membrane destabilization and exposure of apoptosis‐inducing “eat‐me signals”.[ 46 ]

To further corroborate that triterpenoic acids inhibit PLB at the enzymatic step of CPT1, we labeled PC‐3 cells by replacing glucose in the cell culture medium with U13C‐glucose and concomitantly added BETA in the treatments over 48 h, whereas in controls no betulinic acid was added. Fractional enrichment clearly demonstrates that less 13C carbon is incorporated into the three most abundant PC when BETA is present (Figure S13, Supporting Information).

Because mitochondrial membranes account for a high proportion of all PC and PE, changes in the composition of both lipid groups could particularly be related to mitochondrial dysfunction.[ 47 ] Mitochondrial dysfunction is strongly supported by the profiles of free fatty acids (FA), acylcarnitines (CAR), and triacylglycerides (TG), all of which were found to be increased after treatment with BETA and AAHR. These compounds are involved in energy replenishment in mitochondria, and their accumulation suggests impaired OXPHOS.[ 48 ] Another indication of impaired OXPHOS is the strong decrease of CoQ in PC‐3 cells after BETA treatment (Figure S10, Supporting Information).

However, for GLYA and AAHR, both ML models predict additional modes of action besides PLB (Figure 4D,E). For AAHR, OXPHOS inhibition clearly predominates among ML‐based model predictions, whereas both models predict OXPHOS inhibition as a side effect for pure pentacyclic triterpenoic acids (Figure 4D,E).

## Section: Results › ML Predicts MoAs of Novel Cytotoxic Compounds with Anti‐Cancer Potential › Breastin Impairs Microtubule Formation

For Breastin both ML approaches agree and assign the largest scores to the antimicrotubule MoA with further considerable scores for CPLX IV, PLB, and TopoII in case of Lasso and non‐zero scores for multiple MoA in case of the Random Forest (Figure 4D,E). Recently, in a comparative analysis with 153 anticancer agents with known MoA on 74 tumor cell lines of an Oncotest panel, Rashan et al. showed frequent correlations of Breastin to mitosis‐inhibiting and DNA damaging drugs.[ 49 ] Consequently, the antimicrotubular activity of Breastin was further explored using tubulin‐GFP‐transfected U2OS cells. Confocal microscopy verified that Breastin acts as a tubulin‐depolymerizing agent, displaying behavior like paclitaxel, thus confirming the machine learning prediction made here.[ 49 ]

## Section: Results › ML Predicts MoAs of Novel Cytotoxic Compounds with Anti‐Cancer Potential › Cucurbitacin B (QQrB) Inhibits Lipogenesis

Both ML models assigned QQrB to the MoA of fatty acid biosynthesis (FAB) with the highest score (Figure 4D,E), also considering predictions per replicate (Figure S12, Supporting Information). Cancer cells have various ways of maintaining their fatty acid levels, including increased de novo FAB.[ 50 ] ATP citrate lyase (ACLY, EC 2.3.3.8), acetyl‐CoA carboxylase (ACC, EC 6.4.1.2), and fatty acid synthase (FASN, EC 2.3.1.85) are the key enzymes responsible for lipogenesis via FAB and are targeted by anti‐proliferative therapies.[ 51 ] FAB inhibitors like epigallocatechin gallate (EGCG) and apigenin (APIG)impede lipogenesis at the FASN stage.[ 52 , 53 ] Similarly, QQrB inhibits ACLY, which produces a comparable metabolite profile to EGCG and APIG.[ 54 ]

## Section: Results › ML Predicts MoAs of Novel Cytotoxic Compounds with Anti‐Cancer Potential › The MoA of 5‐Fluorouracil (5‐FU) Cannot be Predicted

While 5‐FU, a recognized TYMS inhibitor, displays a distinct response pattern with depletion of thymidinylates and elevated folate levels (Figure S5i, Supporting Information), this mode of action was not included in the training process. By concept, classification approaches cannot predict classes that are not represented in the training set. The lasso‐based approach is partly capable of interpolating between MoAs present in the training data, but nonetheless cannot predict MoAs beyond the training space. Consequently, neither Lasso nor random forest can accurately predict the MoA of 5‐FU. Both ML methods show low prediction scores for numerous MoAs (Figure 4D,E), however, allowing us to identify such cases based on prediction outcomes for further extension and improvement of our methodology.

## Section: Results › Experimental Validation and Transferability of MoA Predictions to Other Cancer Cell Models

To assess the general applicability of the methodology also to other cancer cells beyond the PC‐3 prostate cell line, we conducted similar metabotyping experiments with two additional cell lines: MCF‐7 hormone receptor‐positive breast cancer cells and MHH‐ES‐1 Ewing's sarcoma cells. Specifically, we examined the effects of four compounds: atorvastatin (ATOV) and lovastatin (LOVA), both inhibitors of HMG‐CoA reductase (HMG‐CoAr), and bithionol (BITN) and hexachlorophorane (HEXA), both inhibitors of glutamate dehydrogenase (GDH). Utilizing cluster analysis and partial least squares discriminant analysis (PLS‐DA) to classify the MoAs, we observed that the metabolite profiles after drug treatment exhibited significant similarities across the three cancer cell models (Figure S14A,B, Supporting Information). Moreover, variable importance in the projection (VIP) metabolites, contributing most strongly to the separation of both MoAs, showed consistent regulation independent of the cancer cell model (Figure S14C,D, Supporting Information). Finally, we attempted to predict the MoAs GDH and HMG‐CoAr in both additional cell lines using PC‐3 data as a training set by using both ML approaches. While the predictions of the Random Forest classifier appear to suffer from cell line‐specific base profiles, the Lasso‐based approach successfully predicts the correct MoA for three out of four drugs and yields a widely consistent prediction across replicates for HEXA, ATOR, and LOVA (Figure S14E, Supporting Information).

## Section: Discussion

Our results in PC‐3 prostate cancer cells clearly show that the targeted UPLC‐MS/MS analysis of only 117 metabolites of CCEM allows a reliable assignment of one or even several concomitant MoAs through which a drug (candidate) acts on cancer cells, which in some cases also enables mechanistic insights. Although the approach has a somewhat lower throughput than solely HR‐MS‐based rapid screenings,[ 3 , 7 , 55 ] it avoids misclassification caused by poorly annotated and artefactual signals and allows discrimination of important isobaric intermediates.[ 56 ]

Despite having a small training dataset, we could demonstrate the predictability of the MoA of new drug candidates. Overall, the Random Forest approach resulted in more evenly distributed prediction scores across MoAs compared to the Lasso‐based approach, which usually decides on one or a few MoAs. Because each decision tree in the Random Forest must decide on exactly one MoA this can lead to different predictions if the MoA of the drug does not match exactly with the training drugs. In contrast, the Lasso regression aims to explain the observed CCEM profile of the drug by a small subset of CCEM profiles, leading to coefficients of many MoAs being pushed toward zero. Thus, the Lasso‐based approach can better represent mixtures of MoAs because it considers additional MoAs as partial contribution(s) (different from zero) to improve the overall regression. In predictions across cell lines, the Lasso‐based approach also shows to be robust with regard to cell line‐specific base profiles and predicts the correct MoA for three out of four tested drugs.

When analyzing the transferability of the prediction method to other cancer cell lines, we found characteristic metabolic patterns associated with individual MoAs to be conserved, e.g. HMG‐CoA accumulates in all cell models after HMG‐CoA reductase inhibition. Nevertheless, and not surprisingly, correct MoA prediction based on PC‐3 training data is associated with lower predictive reliability in the two other cancer cell models investigated. Past analyses of the metabolomes in up to 928 cancer cell lines revealed significant variations in their basal metabolite profiles, primarily stemming from distinct enzymatic regulations within the CCEM. These variations are, in part, a result of epigenetic effects or of genetic mutations specific to the respective cell lines.[ 55 , 57 ] All three cancer cell models under exemplary investigation are known to carry specific gene mutations in various oncogenes affecting the CCEM (Figure S15, Supporting Information). The impact of individual mutations or epigenetic alterations on drug response in these models remains unknown. Thus, conducting comprehensive studies with additional cancer cell models, large drug libraries and machine learning will be crucial to understand the effects of individual mutations and drug treatments on metabolism.

The restricted predictability of TYMS inhibitor 5‐FU also suggests that training on a narrow selection of drugs with limited diversity in MoAs will inevitably struggle to accurately align new metabolic patterns unless the training data is expanded. Moreover, focusing on metabolomics analyzing only CCEM may further restrict the method's applicability. Nonetheless, many anticancer drugs currently in use either directly target CCEM or exhibit specific effects on downstream CCEM patterns, even when they act on non‐metabolic targets, as evidenced by MoAs such as AKT or Antimicrotubule. Thus, the present study aims to showcase the proof of concept of metabolomics and ML in preclinical drug discovery, considering the aforementioned limitations. Together, these results validate the approach, and its predictive power will further improve as the number of compounds and especially cell types used in the training sets increases.

Beyond ML‐based pattern recognition and MoA prediction, drug‐induced metabolic profiles contain important mechanistic information that may not be uncovered to this extent using high‐throughput methods without chromatographic separation. We illustrated this for different types of OXPHOS inhibition in relation to regulatory metabolic effects on cellular pyrimidine biosynthesis. For example, antimycin A was recently found to stimulate fumarate reduction by inhibiting CPLX III in 143B osteosarcoma cells, leading to re‐oxidation of ubiquinol to ubiquinone by CPLX II and SUC accumulation.[ 58 ] In accordance with our study in PC‐3 cells, succinate (SUC) enrichment was also detected in CPLX III or fumarase mutant cells but not after CPLX I inhibition.[ 59 ] Stable isotope labeling of these CPLX III‐compromised cells demonstrated that pyruvate carboxylase (EC 6.4.1.1) contributes to MAL and FUM formation, while SUC is produced from 2‐OG and from FUM, respectively, via clockwise and counterclockwise fluxes of the TCA cycle. Thus, the different patterns observed here for SUC, FUM, and MAL upon CPLX I compared with CPLX III inhibition can be attributed to the fact that fumarate reduction is possible only upon inhibition of CPLX III, while at the same time only a small fraction of FUM and MAL can be replenished by the reductive pathway under conditions of energy deficiency.[ 59 ] Inhibition of succinate dehydrogenase (SDH, EC 1.3.5.1) in CPLX II leads to depletion of FUM and MAL and accumulation of SUC, as SDH is responsible for the conversion of succinate to fumarate. The activity of dihydroorotate dehydrogenase depends on the availability of CoQ as well as on its reduction state, i.e., the ratio of ubiquinone to ubiquinol (UQH2). This ratio was assessed in isolated mitochondria of 143B osteosarcoma cells, comparing partial SDH inhibition with pharmacological CPLX III inhibition. Remarkably elevated UQH2/CoQ ratios were exclusively observed with antimycin A‐mediated CPLX III inhibition but not with CPLX II inhibition alone.[ 58 ] These findings align well with our observations, where CPLX III inhibition distinctly influences CA and DHO patterns compared with upstream CPLX I and CII inhibitions (Figure 3).

In conclusion, our methodology allows to correlate the metabolic impact of cytotoxic substances or even complex compound mixtures with pre‐defined MoAs, especially if these directly or indirectly affect the central carbon and energy metabolism. ML‐based pattern recognition not only enables the fine distinctiveness and prediction of MoAs, e.g. as shown by the differentiability of individual respiratory chain complexes. Mechanistic insights from metabolomics‐based MoA studies imply valuable opportunities for metabolic research, for example, to identify drugs for the development of combination chemotherapies. Therefore, our approach can significantly improve drug discovery and development by directing MoA studies toward the identification of specific molecular targets or pathways, and subsequent medicinal chemistry improvements of the lead compound, which is not restricted to cancer research.

## Section: Experimental Section › Cell Culture

Cell handling and assay techniques were described in ref. [60]. The prostate cancer cell line PC‐3 (ATCC, Manassas, VA, USA), The estrogen receptor positivity (ER+) and HER2 negativity (HER2−) breast cancer cell line (ATCC, Manassas, VA, USA), and the ewing's sarcoma MHH‐ES1 (DSMZ, Braunschweig, Germany) were maintained in RPMI1640 basal cell culture medium supplemented with 10% FCS, 1% L‐glutamine and 1% penicillin/streptomycin. Cells were pre‐cultured in T‐75 cell culture flasks in a humidified atmosphere with 5% CO2 at 37 °C. The cells were routinely sub‐cultured when reaching 85% confluency with a maximum of six passages per batch. Adherent cells were washed with PBS and detached by trypsin/EDTA (0.05% in PBS).

## Section: Experimental Section › In Vitro Cell Viability Assays for IC50 Determination

Cells were seeded in 96‐well plates with a density of 6000 cells/100 µL medium per well and were left to attach overnight. Cells were then exposed to compounds of interest in a cell culture medium containing 0.5% DMSO using eight different concentration levels. These levels were compound‐specific and narrowed down to the range around IC50 specifically determined for each compound in preliminary cell viability assays. In parallel, cells were treated with 0.5% DMSO (negative control) and 100 µm digitonin (positive control, for data normalization, set equal to 0% cell viability). Each cell viability assay was performed with two biological replicates each with technical quadruplicates. After 48 h incubation time, cells were washed once with PBS before incubating with MTT (3‐(4,5‐dimethylthiazol‐2‐yl)‐2,5‐diphenyltetrazolium bromide) solution (0.5 mg mL−1) for 1 h at 37 °C and 5% CO2. Afterward, the MTT solution was discarded and DMSO was added to dissolve the formed formazan whose absorbance was measured at 570 nm in addition to a reference/background signal at 670 nm (SpectraMax M5, Molecular Devices, San Jose, CA, USA). For the crystal violet‐based cell viability assay (CV), the cells were fixed with 4% paraformaldehyde (PFA) for 20 min at RT after a single PBS wash. Then, they were dried for 10 min and stained with 10% crystal violet for another 20 min. The excess stain was removed by water wash and the cells were dried overnight at RT. The next day, acetic acid (33% v/v in aqua bidest.) was added to dissolve the stain, and the absorbance was measured at 570 and 670 nm as described before. The cell viability was calculated as a percentage in relation to untreated control cells. For data analyses and IC50 calculations, SigmaPlot 14.0 and Microsoft Excel 2013 were used. Mean values were calculated by using the four‐parametric logistic function.

## Section: Experimental Section › Cell Treatment for Metabolomics Experiment

Cells were seeded as hexuplicates in T‐25 cell culture flasks with a density of 0.5 million cells/5 mL. After cell attachment overnight, cells were treated with the compound of interest by applying it at IC50 final concentrations as obtained from earlier viability assays. Treatments and vehicle controls had the same final DMSO concentration (0.5%). After 48 h at 37 °C under 5% CO2, control flasks without test compound reached 85% confluence. Then the cell culture medium of the T‐25 flask was discarded and replaced by pre‐warmed PBS (37 °C) for a washing step that removed detached cells. Within a few seconds, the washing solution was discarded and the remaining cells were quenched with 1.5 ml cold acidic ethanolic solution (10% HCl of pH 1.4 in ethanol, −80 °C). The T‐25 flasks were sealed with watertight lids and then immersed in an ultrasonic water bath, with the flasks weighted with lead weights and centered in the ultrasonic field. Cells were quantitatively detached by 5 min ultra‐sonication (Bandelin Sonorex RK 106, 480 W, Berlin, Germany). Additionally, packed dry ice was placed in the water bath to maintain a low temperature close to 4 °C. Afterward, the suspension was transferred from each T‐25 flask into pre‐chilled 2 mL Eppendorf tubes kept on dry ice. These were subsequently placed in a sample concentrator at 4 °C (TurboVap LV, Biotage, Uppsala, Sweden), where the volume was reduced to 50 µL in an N2 stream. After volume reduction, two consecutive centrifugation steps were performed at 10600 rcf for 5 min at 1 °C, with another transfer of the supernatant to a fresh Eppendorf tube after the first centrifugation. Finally, the supernatant after the second centrifugation was transferred to an LC‐MS vial with inserts, and samples were frozen and stored at −80 °C until LC‐MS measurement.

## Section: Experimental Section › Metabolomics Assay

Separation of hydrophilic metabolites was performed by ion‐pairing chromatography on a Nucleoshell RP18 column (2.1 × 150 mm, particle size 2.1 µm, Macherey & Nagel, GmbH, Düren, Germany) using a Waters ACQUITY UPLC System, equipped with an ACQUITY Binary Solvent Manager and ACQUITY Sample Manager (5 µL injection volume; Waters GmbH, Eschborn, Germany). Eluents A and B were aqueous 10 mmol L−1 tributyl amine (adjusted to pH 6.2 with glacial acetic acid) and acetonitrile, respectively. Elution was performed isocratically for 2 min with 2% eluent B, from 2 to 18 min with a linear gradient up to 36% B, and from 18 to 21 min up to 95% B, and isocratically from 21 min to 22.5 min with 95% B, from 22.51 to 26 min again down to 2% B. The flow rate was set to 400 µL min−1, and the column temperature was maintained at 40 °C.

Mass spectrometric analyses of small molecules were performed by targeted MS/MS via multiple reaction monitoring (MRM) by using a QTRAP 6500 (AB Sciex GmbH, Darmstadt, Germany) operating in negative ionization mode and controlled by Analyst 1.7.1 (AB Sciex GmbH, Darmstadt, Germany) (Table S2, Supporting Information). The source operation parameters were the following: ion spray voltage, −4500 V; nebulizing gas, 60 psi; source temperature, 450 °C; drying gas, 70 psi; curtain gas, 35 psi.

Peak integration was performed using the MultiQuant software version 3.0.3 (Sciex, Toronto, CA). To account for different cell numbers in treatments and vehicle controls, individual CCEM peak areas were normalized to the total peak area for each sample. Finally, each normalized metabolite area in an individual sample was divided by the mean of the likewise normalized signal area of all vehicle control samples of the respective experimental set. All area ratio data were logarithmized to the basis of 2. The statistical analysis and graphical presentation were performed by MetaboAnalyst 5.0 using the log2‐normalized data and Range Scaling.[ 61 ]

## Section: Experimental Section › Lipidomics Assay

PC‐3 cells were quenched with 1.5 mL cold MeOH (−80 °C) and dispersed by ultrasonication as described above. Cell debris and solution were then transferred together into a new tube and were dried in a nitrogen stream. After the addition of one steel bead (3 mm), three steel beads (1 mm), and 200 mg of glass beads (0.75–1 mm), 700 µL MTBE and 200 uL of water were added, and cryo bead milling for 3 × 20 s was performed (MP24, Biomedicals Inc., 4.0 m s−1). Following phase separation by centrifugation (2 min, 10000 x g) the upper phase was collected and stored on ice. The lower phase was re‐extracted with another 700 µL MTBE and, after centrifugation, the organic layers were combined and dried in a nitrogen stream. For analysis, the dry residue was dissolved in 500 µL MeCN/2‐propanol/water (60/35/5).

Lipid separation on UPLC was performed according to ref. [62] with the following modifications. Eluent A consisted of 60% MeCN and 40% water, and eluent B consisted of 90% 2‐propanol and 10% MeCN, both with 10 mm ammonium formate and 0.1% formic acid. Separation was carried out on a Nucleoshell RP18 (Macherey & Nagel, Dueren, Germany) with the dimensions 2 mm × 150 mm × 2.7 µm. The gradient on a Waters Acquity was: 0–1.5 min 32% B, 1.5–18 min linear gradient to 98% B, 18–20 min 98% B, 20–24 min 32% B with 10 µL injection volume and 40 °C oven temperature.

Separated lipids were ionized by electrospray ionization and analyzed in positive ionization mode by HR QToF‐MS/MS (Zeno7600, Sciex, Toronto) using these source parameters: ion source gas 1, 60 psi; ion source gas 2, 70 psi; curtain gas, 35 units; CAD gas, 7 units; temperature 450 °C, ion spray voltage floating, −5500 V. MS1 and CID‐MS/MS spectra were scanned from 65–1500 Da using 100 ms accumulation time for MS1 and 20 ms each for a maximum of 40 data‐dependent MS/MS experiments. For MS1 survey scans and MS/MS the declustering potential (DP) was 80 V with a spread of 50 V, whereas in MS1 the collision energy was fixed to 10 V. MS/MS scans were acquired with a collision energy of 35 V, and a spread of 25 V. Mass accuracy was recalibrated after every five samples using internal standards provided for ESI by Sciex. For lipidomics data analysis, raw data were processed by MS‐Dial version 4.9 using the lipidomics standard library embedded in the program.[ 63 ] Peak height tables with classified lipids were exported from MS‐Dial, normalized to cell number, and processed in GraphPad Prism 9.1.5.

## Section: Experimental Section › 13C Labeling

PC‐3 cells were seeded in T‐25 cell culture flasks as described above. After 24 h of incubation, cell culture medium was exchanged against RPMI 1640 medium without glucose (Gibco, Darmstadt, Germany), supplemented with 10% heat‐inactivated dialyzed FBS (Gibco, Darmstadt, Germany) and uniformly labeled D‐glucose (U‐13C6, 99%) (Cambridge Isotope Laboratories, Inc., Massachusetts, USA) at a final concentration of 2 g L−1. Simultaneously, samples were treated with BETA at the IC50 concentration (Table S1, Supporting Information), whereas in the control flasks no BETA was added. Isotopolog analysis was performed using Lipidomics extraction 48 h post‐treatment, following the protocol described above. The samples were analyzed using UPLC‐ToF in positive mode ESI with the chromatographic gradient as described. Isotopologs of the three most abundant PC (m/z;r.t.: 760.5836; 12.65 min, m/z;r.t.: 788.6158; 13.59 min, and m/z;r.t.: 732.5521; 11.78 min) were area integrated based on their theoretically expected [M+H] ions within a mass tolerance of 10 ppm. The data analysis was done using Sciex OS. The percentual 13C incorporation was calculated as described in[ 64 ] and visualized by GraphPad Prism 10.

## Section: Experimental Section › CoQ Assay

Coenzyme Q10 was analyzed by UPLC‐QToF with positive mode ESI. The gradient was the same as described in the lipidomics section. CoQ was determined by [M+H] of 863.692 with a mass tolerance of 2 ppm. The retention time and the MS/MS spectrum were compared to an authentic standard (Merck). Peak area values of pentuplicate treatments were normalized to the cell number.

## Section: Experimental Section › Cell Counts

PC‐3 cells of three parallel samples in each control/treatment group were detached by trypsination for 3 min in 0.05% trypsin/EDTA and 37 °C. After trypsination stop with FCS‐containing culture medium, the resuspended cells were stained with Trypan blue, and cell counting was performed using a Neubauer counting chamber (Marienfeld, Lauda‐Königshofen, Germany).

## Section: Experimental Section › Localization of AAHR in PC‐3 Cells

PC‐3 cells were seeded in a 10‐well chamber slide with 1000 cells per well and allowed to grow at 37 °C and 5% CO2 for 24 h. Cells were treated with 0.1 µm AAHR for 4 h followed by washing twice with PBS. Staining with 0.1 µm MitoTracker Green FM was done for 15 min. After washing with PBS twice, fresh medium was added. Fluorescence was recorded using an LSM900 (Carl Zeiss, Jena, Germany) with ex/em 561 nm/576–700 nm for AAHR and ex/em 488 nm/490–540 nm for MitoTracker Green. Co‐localization of AAHR and MitoTracker Green was analyzed using Zen Blue image analysis software (Zeiss).

## Section: Experimental Section › Seahorse Analysis

To investigate the compound‐induced alterations in cellular energy metabolism, the Seahorse cell analysis technology platform from Agilent was utilized, applying the Seahorse XF Cell Mito Stress Test Kit (Agilent Technologies, Santa Clara, CA, USA). The analyses were performed on a Seahorse XF 96 – Extracellular Flux Analyzer according to instructions of the manufacturer. PC‐3 cells were seeded in specific 96‐well plates at day 0 using a density of 12000 cells per well. Subsequently, starting at day 1, the cells were treated with 20 nm and 100 nm of AAHR for 24 h (a duration not yet causing apparent signs of cytotoxicity), or were left untreated, and finally were measured at day 2. Another sample of untreated cells was used to assess mitochondrial function after acute compound treatment. For this purpose, one of the standard chemicals was replaced by AAHR, respectively.

The Seahorse XF Cell Mito Stress Test was performed, which was based on the measurement of oxygen consumption rate (OCR) and extracellular acidification rate (ECAR) of viable cells during sequential manipulation with specific chemicals to obtain information about mitochondrial function and to quantify cellular bioenergy levels (ATP).

To further explore the precise mechanism of inhibition of mitochondrial respiration, the Mito Stress Test was modified to analyze the impact of acute AAHR treatment on OCR and ECAR. The standard assay comprises a consecutive treatment with oligomycin (complex V / ATP synthase inhibitor), FCCP (uncoupling agent), and rotenone/antimycin A (complex I / III inhibitors) leading to a reduction of OCR (increase of ECAR), strong increase of OCR to a maximum, and complete decrease of OCR to a minimum, respectively.

## Section: Experimental Section › Docking Studies

Molecular docking was performed in YASARA software[ 65 ] version 20.12.24 by using the AutoDockLGA algorithm,[ 66 ] and AMBER14 force field.[ 67 ] The cryo‐EM structure of human CEPT1 complexed with CDP‐choline (PDB ID: 8GYW),[ 68 ] and the AlphaFold[ 69 ] model for CPT1 which was obtained from UniProt (accession number Q8WUD6) were utilized for molecular docking studies. The AlphaFill[ 70 ] server was used to assign the Mg2+ ion in CPT1, while it (Mg2+) exists in the CEPT1 cryo‐EM structure. The binding site was defined according to the location of the ligand (CDP‐choline) in the cryo‐EM structure of CEPT1. Ligands and protein structures were energy‐minimized, and a simulation box (10 Å) was defined around the Mg2+ ion. The validation of the docking protocol was performed by re‐docking the ligand in the cryo‐EM (CDP‐choline) of CEPT1 (Figure S16, Supporting Information), using the same parameters. The results from 100 runs were clustered using an RMSD (Root Mean Square Deviation) of 2.5 Å, and MOE (Molecular Operating Environment) 2020 software[ 71 ] was employed to investigate the interaction between the ligands and the proteins.

## Section: Experimental Section › Classification Methods and Prediction Analysis—Normalization of CCEM Profiles

CCEM profiles were normalized per metabolite by subtracting the mean across all drugs/replicates and dividing the result by the range between the maximum and minimum values across all replicates, i.e., (1) nm,r=xm,r−x¯mmaxsxm,s−minsxm,s where x m,r denotes the input value for metabolite m in experiment r and x¯m=1R∑r=1Rxm,r

The same coefficients were also used for normalizing the data in the prediction set to avoid re‐scaling and subsequent re‐training of models when processing prediction sets. For predictions in other cell models, a cell line‐specific mean value was determined to account for different base profiles.

## Section: Experimental Section › Classification Methods and Prediction Analysis—Correlation Analysis of Metabolites

For all pairs of metabolites, Pearson correlation was computed between their profiles across all drugs/replicates. Visualization as a heatmap and corresponding clustering of rows/columns was performed using the pheatmap R package (v. 1.0.12).[ 72 ]

## Section: Experimental Section › Classification Methods and Prediction Analysis—Hierarchical Clustering of CCEM Profiles

Normalized CCEM profiles of all drugs/replicates were clustered using Euclidean distance and the hclust R function with method “ward.D”. The resulting cluster trees were visualized as dendrograms. Here, leaves are annotated with the MoA of the corresponding drug. Inner nodes of the cluster tree, under which all leaves belong to the same MoA are annotated accordingly. To generate a more condensed view on the clustering result, each sub‐tree in which all leaves belong to the same drug was aggregated into a single leaf. For all drugs, this results in a single leaf representing all replicates of that drug, except for PRFN/ORID. The latter has CCEM profiles so similar that replicates of both drugs appear intermixed. Heatmaps of selected profiles were generated using MetaboAnalyst 5.0. Peak integrated raw data were normalized to the sum of all signals as to compensate for the different cell numbers. Log2‐fold changes between six replicate treatments per drug and six controls, both sampled after 48 h, were rank‐scaled (Table S3, Supporting Information).

## Section: Experimental Section › Random Forest – Training

Random Forests were trained using the randomForest function of the corresponding R package (v. 4.7–1.1)[ 73 ] using 1000 trees balancing between runtime and stability. Input data of the Random Forest method were the CCEM profiles of all replicates of all drugs in the training set. True class labels during training were the corresponding drugs, i.e., the Random Forest was trained to distinguish individual drugs, which in turn had been assigned to a specific MoA.

## Section: Experimental Section › Random Forest – Prediction

Each normalized CCEM profile of each replicate for each drug in the prediction set was considered independently, and probabilities for individual drugs were predicted using the trained Random Forest model using the predict method with parameter “type = ’prob’”. Returned probabilities were averaged across all replicate CCEM profiles of each drug, and then averaged across all drugs with a common MoA in the training set to yield the probability of a specific MoA (Table S3, Supporting Information). The two‐level averaging ensures that all drugs have the same influence on the prediction result, irrespective of the number of replicate measurements.

## Section: Experimental Section › Lasso‐Based Approach – Training & Prediction

For the Lasso‐based approach, the regression coefficients themselves were used to predict the MoA of a new drug. Here, the CCEM profile of an individual replicate of the drug in the prediction set was considered as the response variable, and the CCEM profiles of all replicates of all drugs in the training set were considered as the input matrix of a Lasso regression using the glmnet function from the corresponding R package (v. 4.1–4).[ 74 ] Regression coefficients were limited to non‐negative values by setting the parameter for the lower boundary of regression coefficients to zero. The regularization parameter was set to a fixed value within the range of auto‐computed values (λ = 0.025) and no intercept value was considered by setting “intercept = FALSE”. Regression coefficients were obtained using the coef method. Returned coefficients were averaged across all replicate CCEM profiles of each drug, and then averaged across all drugs with a common MoA to yield the prediction score of a specific MoA. For visualization purposes, prediction scores were normalized to a sum of one across all MoAs since each drug is represented by 5–6 replicates in the training set.

## Section: Experimental Section › k‐Nearest Neighbor – Training & Prediction

Predictions of the k‐nearest neighbor classifier were obtained from the function knn of the class R package[ 75 ] using the CCEM profiles of each replicate of each drug in the training set and corresponding MoA as reference. The number of nearest neighbors was set to “k = 5” to account for the number of replicates per drug.[ 74 ]

## Section: Experimental Section › Leave‐One‐Out Cross Validation

For evaluating the prediction performance of each approach on the training set, a leave‐one‐out cross‐validation over the drugs in the training set was performed. To avoid data leakage from the training partition to the test partition within individual iterations of the cross‐validation, all replicates of a drug were excluded from the training partition and used as the test partition in a leave‐one‐out cross‐validation. Specifically, all replicate CCEM profiles of one drug with known MoA were considered as prediction partitions, and the replicate CCEM profiles of all remaining drugs were used as the corresponding training partition. For each replicate of the drug in the prediction partition, predictions were obtained from the three alternative methods and those were compared against its true MoA. R source code of the evaluation procedure is provided as Data S1 (Supporting Information).

## Section: Conflict of Interest

The authors declare no conflict of interest.

## Section: Author Contributions

M.S., G.U.B., L.A.W., A.T., and R.R. conceptualized the project. M.S. performed cell cultures, metabolomics assays and data analyses. J.G. and I.G. performed the machine learning. T.M. performed the Seahorse assays. M.S. and B.H. performed the LMS imaging. M.Y. and M.D. performed the docking studies. M.S. and G.B. performed and analyzed the lipidomics assays. R.C. and L.R. provided AAHR and Breastin, respectively. M.S., G.U.B. and J.G. wrote the original draft. G.U.B.; L.A.W. and R.R. supervised the work, designed the experiments, reviewed and edited the draft. L.A.W., A.T., I.G. and R.R. reviewed the manuscript. L.A.W. and A.T. acquired the funding and administered the project. All authors have read and agreed to the published version of the manuscript.

## Section: Supporting information

Supporting Information

Supplemental Table 1

Supplemental Table 2

Supplemental Table 3

Supplemental Table 4

Supplemental Table 5

Supplemental Table 6
