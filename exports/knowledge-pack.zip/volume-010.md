# Evaluating molecular representations in machine learning models for drug response prediction and interpretability

- **Authors:** Delora Baptista, João Correia, Bruno Pereira, Miguel Rocha
- **Issuer:** Journal of integrative bioinformatics
- **Type:** Scientific article
- **Published:** 2022-08-26
- **Language:** en
- **DOI:** 10.1515/jib-2022-0006
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36017668/
- **Licence:** CC-BY

## Section: Abstract

AbstractMachine learning (ML) is increasingly being used to guide drug discovery processes. When applying ML approaches to chemical datasets, molecular descriptors and fingerprints are typically used to represent compounds as numerical vectors. However, in recent years, end-to-end deep learning (DL) methods that can learn feature representations directly from line notations or molecular graphs have been proposed as alternatives to using precomputed features. This study set out to investigate which compound representation methods are the most suitable for drug sensitivity prediction in cancer cell lines. Twelve different representations were benchmarked on 5 compound screening datasets, using DeepMol, a new chemoinformatics package developed by our research group, to perform these analyses. The results of this study show that the predictive performance of end-to-end DL models is comparable to, and at times surpasses, that of models trained on molecular fingerprints, even when less training data is available. This study also found that combining several compound representation methods into an ensemble can improve performance. Finally, we show that a post hoc feature attribution method can boost the explainability of the DL models.Keywords: cancer, deep learning, drug sensitivity, learned representations, molecular fingerprints

## Section: Introduction

ML has been widely used in the pharmaceutical industry for rational drug discovery. Quantitative structure-activity relationship (QSAR) models, for example, typically use ML algorithms to learn the relationship between the structures or properties of compounds and their biological activity. ML can help guide the discovery process by identifying the most promising drug candidates before experimental work is carried out. The development of predictive models of drug response in cancer is a particularly important application of ML in this field [1, 2].

The first step in an ML workflow for drug discovery is usually the calculation of molecular descriptors or fingerprints (Figure 1). Molecular descriptors are the experimental or theoretical physicochemical properties of a compound. Molecular fingerprints encode molecules as bit or count vectors. The information that is encoded depends on the type of fingerprint. Substructure key-based fingerprints set the bits of the bit vector to one or zero depending on the presence or absence in the compound of certain substructures or features from a list of predefined structural keys [3]. Path-based fingerprints enumerate the different linear paths between atoms in a molecule to determine which types of fragments are present. Circular fingerprints describe the surrounding environment of each atom in the molecule up to a predefined radius [3].

The use of end-to-end DL approaches (Figure 2) that can learn relevant features directly from raw input data may eliminate the need for precomputed descriptors and fingerprints. Graph neural networks (GNNs) can learn directly from molecular graphs [4, 5]. Certain types of DL algorithms, such as recurrent neural networks (RNNs) and 1D convolutional neural networks (CNNs), are able to learn from line notations like Simplified Molecular-Input Line-Entry System (SMILES) strings, and DL-based natural language processing methods can be applied to line notations to create continuous embeddings of molecules [6].

Several recently published benchmarking studies have analyzed whether learned representations of compounds can outperform molecular descriptors and fingerprints. The authors of one such study compared different representation methods across several drug target prediction tasks and reached the conclusion that end-to-end DL methods tended to perform worse than DL models trained using precomputed chemical features [7]. Another study benchmarked a variety of molecular descriptor-based ML models and GNN models on several molecular property prediction datasets, and also concluded that descriptor-based models usually outperformed the GNN models [8]. A different research group found that GNNs performed better than fully-connected neural networks (FCNNs) trained with molecular fingerprints on most of the benchmarking tasks considered in the study [9]. Another recent study evaluated the performance of several molecular fingerprints and DL-based representations on drug combination sensitivity and synergy prediction tasks using a large drug combination dataset. The authors found that several DL-based representations outperformed traditional fingerprints, but they also noted that the differences in performance between traditional and learned representations were small [10]. A large-scale benchmarking study using MoleculeNet datasets concluded that learned representations perform worse when training data is scarce or very imbalanced [11], and several other studies have also observed that traditional fingerprints tend to outperform learned representations in low data scenarios [12, 13]. Therefore, the most suitable representation for a given prediction problem probably depends on the type of problem itself, as well as other factors such as dataset size, making it essential to evaluate this for each specific application.

In this study, a variety of molecular representation methods and DL algorithms were benchmarked to determine which representations are the most suitable for predicting drug sensitivity in cancer cell lines. A new Python package, developed in-house, was used to perform this analysis. All of the datasets and scripts used in this study are available online at https://github.com/BioSystemsUM/DeepMol/tree/pacbb21/pacbb21_paper.

Traditional representations of compounds for machine learning tasks.

Learned representations of compounds. (A) Representations can be learned directly from SMILES strings using DL architectures such as RNNs or 1D CNNs. (B) Natural language processing-inspired methods can be used to generate continuous embeddings of molecules. (C) GNNs can be used to learn representations directly from molecular graphs.

## Section: Methods

Details on the datasets used in this study.

General data preprocessing and machine learning steps followed in this work.

## Section: Methods › Datasets

A selection of DL models were benchmarked on several human cancer cell line drug screening datasets (Table 1). Single-cell line datasets were used so that it would be possible to study the effect of different compound representations without having to take cell line features into account.

The NCI 1 and NCI 109 human tumor cell line growth inhibition datasets were used to develop binary classification models. These datasets were chosen because they have been widely used in the literature to validate graph classification algorithms. In this study, balanced versions of these datasets [14] were used (available from https://github.com/shiruipan/graph_datasets). In each dataset, the output variable indicates whether a given compound is active or inactive in a specific cell line.

To develop and evaluate regression models, two single-cell line cytotoxicity datasets (PC-3 and CCRF-CEM) from a recent drug sensitivity prediction study [15] were used. The authors of this study obtained the original datasets from ChEMBL [16], performed some filtering and data cleaning steps, and transformed the original half maximal inhibitory concentration (IC50) values into −log(IC50) values (pIC50). These pIC50 values were used as the output variable for the regression models.

The previously mentioned datasets are all relatively small, each comprised of less than 5000 compounds. However, these smaller datasets were preferred because it was assumed that they would more closely reflect the behavior of the compound representation methods when used in drug sensitivity prediction models trained on publicly available anti-cancer screening datasets, which usually have data for even fewer compounds. Indeed, the original version of the popular Genomics of Drug Sensitivity in Cancer (GDSC) resource [17], for example, provides access to a dataset (GDSC1) containing screening data for only 367 compounds, while the Cancer Therapeutics Response Portal (CTRPv2)v2 [18] dataset has data for only 481 compounds.

Nevertheless, a larger dataset derived from the National Cancer Institute 60 Human Cancer Cell Line Screen (NCI-60) dataset was also used for benchmarking. A single cell line, A549/ATCC, was selected from this dataset. After removing low quality experiments, compounds without sensitivity data, and compounds that could not be mapped to SMILES strings using the files provided by the Developmental Therapeutics Program (DTP), the final dataset contained 20,730 compounds. Sensitivity was measured as −log(GI50 (half maximal growth inhibition concentration)) in this dataset.

Prior to modeling, all SMILES strings were preprocessed using the ChEMBL Structure Pipeline [19].

Details on the datasets used in this study.

## Section: Methods › Models › Pre-computed features

Six different types of molecular fingerprints were evaluated in this work: extended connectivity fingerprint (ECFP) (ECFP4 and ECFP6), Molecular ACCess System (MACCS) keys, atom pair fingerprints (AtomPair), RDKit fingerprints (RDKitFP) and RDKit layered fingerprints (LayeredFP). ECFP fingerprints [20] are a popular circular fingerprint based on the Morgan algorithm [21]. ECFP4 fingerprints use a radius of 2 to define the circular neighborhood surrounding each atom, while ECFP6 fingerprints use a radius of 3. MACCS is a type of substructure key-based fingerprint which uses 166 predefined keys [22]. The AtomPair fingerprint is a topological fingerprint based on determining the shortest distance between all pairs of atoms within a molecule [23]. The RDKitFP is another topological fingerprint that was developed by the RDKit [24] project. The algorithm finds all subgraphs in a molecule containing a number of bonds within a predefined range, hashes the subgraphs, and then uses these hashes to generate a bit vector of fixed length. The LayeredFP [24] uses the same algorithm as the RDKitFP to identify subgraphs, but different bits are set in the final fingerprint based on different “layers” (different atom and bond type definitions).

Compound structures were encoded as bit vectors using each fingerprinting algorithm and the resulting fingerprints were used as inputs to FCNNs. With the exception of MACCS fingerprints, which have a fixed length, the size of all fingerprints was limited to 1024 bits.

## Section: Methods › Models › Mol2vec embeddings

Mol2vec is an unsupervised method that generates continuous vectors representing molecules using the Word2vec word embedding algorithm [6]. Each molecule is considered a “sentence” and molecular substructures (calculated using the Morgan algorithm) are considered “words”. In this work, a pre-trained Mol2vec model was used to generate 300-dimensional embeddings for the molecules in each dataset, which were fed into FCNNs.

## Section: Methods › Models › TextCNN

TextCNN is a 1D CNN that was originally developed for sentence classification [25]. A modified version of this algorithm (implemented in DeepChem [26]), which uses tokenized and one-hot encoded SMILES strings as inputs instead of words, was used in this study. It applies several 1D convolutional filters, followed by a max-over-time pooling operation, which summarizes each filter using its maximum value. These learned features are then fed into fully-connected layers to predict the output.

## Section: Methods › Models › Graph neural networks

The structure of a chemical compound can be represented as a molecular graph, where nodes are atoms and edges represent bonds. Conventional neural network architectures, such as FCNNs or CNNs, are unable to learn directly from this type of data.

GNNs generalize deep neural networks to graph-structured data. Inputs to a GNN are usually node features (e.g. atom type) and adjacency matrices encoding the structure of the graph, and sometimes can also include edge features as well. The node and edge features are used to initialize the graph. In general, GNNs apply learnable functions to update the node-level representations, progressively incorporating information about the neighborhood of a node into its representation. After several rounds of updates, a pooling operation can be used to obtain a graph-level (molecular-level) representation. The graph-level representations can then be fed into fully-connected layers to predict a given output.

In this work, four different GNN algorithms were benchmarked: neural fingerprints (GraphConv) [4], graph convolutional network (GCN) [27], graph attention network (GAT) [28] and the AttentiveFP algorithm [5].

## Section: Methods › Model training and evaluation

The modeling workflow that was followed in this study is shown in Figure 3.

Each dataset was split into a training set (70%) and a test set (30%). All models were trained and evaluated using the same splits for each dataset.

All models were trained for 100 epochs with a batch size of 256 samples, and used the Adam [29] optimization algorithm. Cross-entropy loss was used as the loss function for all classification models, while the mean squared error was used for regression models. Other model-specific hyperparameters were tuned using a 5-fold cross-validated randomized search, in which 30 different hyperparameter combinations were tested. These included the number of hidden layers and hidden units and the use of regularization methods, such as L2 weight regularization and dropout [30], among others. The best model that was found for each algorithm was then refit on the entire training set and evaluated on the held-out test set. Additional details on the models (including the full search space and the best hyperparameters found for each type of model) are available online at https://github.com/BioSystemsUM/DeepMol/blob/pacbb21/pacbb21_paper/supplementary_material.pdf.

General data preprocessing and machine learning steps followed in this work.

## Section: Methods › Model ensembling

Besides evaluating individual models, simple voting ensembles were also built to determine if combining predictions from multiple models could further improve performance. For classification tasks, majority voting ensembles were built, where the final prediction is the label predicted by the majority of the individual classifiers. For regression tasks, the ensembles simply averaged the individual predictions to obtain the final prediction. The hyperparameter values that were used for each individual model were the optimal values that had been previously tuned using randomized search.

## Section: Methods › Feature importance

Feature importance was determined using the Deep SHapley Additive exPlanations (SHAP) method implemented in the SHAP Python package (version 0.39.0) [31]. Deep SHAP approximates SHAP values for DL models by using a modified version of the DeepLIFT [32] algorithm.

## Section: Methods › DeepMol

All preprocessing, featurization and modeling steps were implemented using DeepMol, a newly developed chemoinformatics package from our host group. It is a python-based machine and deep learning framework for drug discovery, offering a variety of functionalities that enable a smoother approach to many drug discovery and chemoinformatics problems. This framework uses Tensorflow [33], Keras [34], Scikit-learn [35] and DeepChem [26] to either build custom ML and DL models or make use of pre-built models. It also uses the RDKit [24] framework to perform operations on molecular data.

Regarding compound standardization, it allows users to use the ChEMBL Structure Pipeline [19] or apply custom standardization steps using RDKit [24] standardization methods. Some of these steps include standardization of some non-standard valence states, molecule sanitization, charge neutralization, stereochemistry removal, the removal of smaller fragments, kekulization, among others.

The package also offers several featurization methods including molecular fingerprints, molecular embeddings and graph-based featurizers.

In summary, the package offers a complete workflow to perform machine and deep learning tasks for molecules represented as SMILES strings. It has modules that perform standard tasks, such as loading and standardizing data, computing molecular features, performing feature selection and data splitting. It also provides methods to deal with unbalanced datasets and to do unsupervised exploration of the data. This way, DeepMol provides a common platform to treat the data and build, train, optimize and evaluate ML and DL models using different ML frameworks.

## Section: Results and discussion

Performance (ROC-AUC) of different deep learning models on the NCI 1 and NCI 109 classification tasks. Higher scores mean better performance.

Performance (RMSE) of different deep learning models on the PC-3, CCRF-CEM and NCI-60 A549 regression tasks. Lower scores mean better performance.

Ensemble results for classification tasks.

Ensemble results for regression tasks.

Global feature importance for the ECFP4 model trained on the NCI 1 dataset. Only the 20 most important features are shown, and features are ordered according to their importance. Each point represents a sample in the test set, and the color of the points represents the value of a particular feature for that sample.

Global feature importance for the AtomPair model trained on the CCRF-CEM dataset. Only the 20 most important features are shown, and features are ordered according to their importance. Each point represents a sample in the test set, and the color of the points represents the value of a particular feature for that sample.

SHAP explanation of the prediction made by the ECFP4 model for sample 537 from the NCI 1 test set, represented as a waterfall plot. Features are ordered by their impact on the model output. Only the top 20 features that contribute the most to the prediction are shown.

Molecular fragments corresponding to the ten ECFP4 bits that contribute the most towards the prediction for sample 537 from the NCI 1 test set.

## Section: Results and discussion › Individual models

In this section, we report and discuss the performance of 12 DL algorithms benchmarked on 5 drug response datasets of variable size and with different output variables. Figure 4 reports the results for classification tasks, with model performance quantified using the area under the receiver operating characteristic curve (ROC-AUC). For regression problems, model performance scores are reported in Figure 5, using the root mean squared error (RMSE) values. The full results tables and plots for additional scoring metrics are available from https://github.com/BioSystemsUM/DeepMol/tree/pacbb21/pacbb21_paper/results.

ECFP4 fingerprints outperformed other fingerprints and end-to-end DL models on the NCI 1 classification task, having achieved a ROC-AUC score of 0.83. The LayeredFP model achieved a very similar ROC-AUC score (also 0.83, when rounded), while the best end-to-end DL model (TextCNN) reached a score of 0.81. On the NCI 109 dataset, the GCN algorithm ranked first in terms of performance, but other methods such as LayeredFP, TextCNN and GraphConv were not far behind (Figure 4). With the exception of the LayeredFP model, fingerprint-based methods generally performed worse than most of the end-to-end DL models on this dataset.

On the PC-3 dataset, the TextCNN model achieved the lowest RMSE (0.61), followed by the LayeredFP model and the GraphConv model, both with an RMSE of 0.65 (Figure 5). Other GNNs did not perform as well as GraphConv, having been surpassed by most of the fingerprint-based models. In the CCRF-CEM regression task, several fingerprint-based models (AtomPair, RDKitFP and MACCS) outperformed the best end-to-end DL model, which was once again the TextCNN model (RMSE = 0.76) (Figure 5). On the larger A549 dataset (Figure 5), TextCNN was the best model (RMSE = 0.79), followed by AtomPair and GCN which both reached an RMSE value of 0.81. The increase in dataset size did not benefit all of the end-to-end DL models, however.

In general, performance scores were usually similar between many of the models. This finding is in agreement with the MoleculeNet benchmarking study, which was also unable to find clear differences between models when benchmarking on smaller datasets (less than 3000 compounds) [11]. The best type of compound representation method seems to depend on the dataset itself, even when the prediction tasks are similar. Other factors, such as the particular data split that was used or the limited number of hyperparameter combinations that were explored using randomized search, could also have influenced the results. Surprisingly, results were consistently worse when using Mol2vec embeddings, which were generated using a model that had been pre-trained on a dataset with over 19 million molecules [6]. The Mol2vec models performed poorly on the training sets as well, indicating that these models were underfitting. Although the original Mol2vec study does not mention the need for scaling the embeddings before using them as inputs to ML models, some of the values in the embeddings are outside the ideal range (between 0 and 1) for DL models. Scaling the embeddings prior to learning might be necessary to improve learning. In addition, dataset-specific fine-tuning of the embedding model might also improve the performance of FCNNs trained on these embeddings.

End-to-end DL models performed as well as, and at times even surpassed, models trained on pre-computed features. TextCNN models, in particular, ranked highly across all datasets.

GNNs also performed relatively well on some of the prediction tasks. This is contrary to what would be expected given the limited number of compounds and the fact that these models were not pre-trained on larger chemical datasets beforehand. However, more complex GNNs with attention mechanisms (GAT and AttentiveFP) did not always perform as well as other end-to-end methods on the datasets that were used in this study, indicating that applying self-attention to the molecular graph nodes does not seem to be particularly advantageous in this case.

Regarding molecular fingerprints, LayeredFP consistently performed well across all datasets, and models trained using atom pair fingerprints also performed relatively well, both outperforming the more popular ECFP fingerprints in 4 out of 5 datasets. LayeredFPs are able to encode information about larger subsets of the molecular graphs than ECFPs, capturing more information on the global structure of the molecules. AtomPair fingerprints also encode more global features since all pairs of atoms are taken into account. The results suggest that global molecular features might be important for the prediction of drug sensitivity. Therefore, these less well-known fingerprints might be interesting alternatives to some of the more commonly used options, at least for drug response prediction tasks.

Despite the use of regularization methods, most models still had a tendency to overfit. In the future, an early stopping mechanism similar to the Keras EarlyStopping callback could be implemented for all models to try to mitigate this.

Performance (ROC-AUC) of different deep learning models on the NCI 1 and NCI 109 classification tasks. Higher scores mean better performance.

Performance (RMSE) of different deep learning models on the PC-3, CCRF-CEM and NCI-60 A549 regression tasks. Lower scores mean better performance.

## Section: Results and discussion › Ensemble models versus individual models

For each prediction task, the best individual models were also compared to two different ensembles: an 11-model ensemble comprising all models except Mol2Vec models, and an ensemble comprising only the 5 best individual models for a specific task. Results for the classification tasks and the regression tasks are provided in Tables 2 and 3, respectively.

Using the 11-model ensembles improved performance scores across all prediction tasks relative to the best individual models for nearly all of the scoring metrics considered. The 5-model ensembles also outperformed single models on all tasks, and performed better than the larger ensembles on the regression tasks, having achieved lower RMSE scores. The improvement in performance, when using ensembles instead of single models, is likely due to the fact that different representations capture different molecular features. Therefore, combining several drug representations is a strategy that should be considered when developing drug response prediction models in the future.

Ensemble results for classification tasks.

Ensemble results for regression tasks.

## Section: Results and discussion › Feature importance

SHAP values were used to determine which features were the most important for the test set predictions. The top 20 most important features (calculated for the test sets) for the best individual models for the NCI 1 classification task (ECFP4 model) and the CCRF-CEM regression task (AtomPair model) are shown in Figures 6 and 7, respectively. Features with greater absolute SHAP values will be the most important, and global feature importance can be determined by averaging the absolute SHAP values across all samples in the dataset. Through the use of color, these plots also show how the value of a given feature impacts the model prediction.

For NCI 1, the SHAP values can be used to determine which fingerprint bits generally lead the model to predict whether the cell line will be sensitive to a given compound or not when the bits are set to 1. For example, ECFP4 bits 724, 947, 453, 353, 324, 832, 434, 695, 856, 302, and 272 have a positive effect on the model output, indicating that the presence of these fragments in a compound is associated with drug sensitivity. Likewise, in the CCRF-CEM task, fingerprint bits that have higher SHAP values are compound fragments that, when present, contribute to increase the pIC50 values. This indicates that the sensitivity of the CCRF-CEM cell to treatment is greater when these substructures are present in the screened compounds.

SHAP values can also be analyzed at the sample level, allowing to explain how specific features affect a single prediction. Figure 8 shows how each feature contributes to increase or decrease the model prediction from a base value of 0.46 for sample 537 from the NCI 1 test set, which had been correctly predicted as “sensitive” (class label = 1) by the ECFP4 model. Fingerprint bits that are set to 1 and move the predicted value towards 1, are features present in the compound that explain the sensitivity of the cell line used in the NCI 1 assay towards this compound.

Figure 9 depicts the top ten ECFP4 bits and the corresponding substructures that most influenced the model prediction for sample 537. The compound in question is (7-Acetamido-1,2,10-trimethoxy-9-oxo-6,7-dihydro-5H-benzo[a]heptalen-3-yl) ethyl carbonate, a colchicine analog. Colchicine and its analogs bind to tubulin [36]. The top 10 most important ECFP4 bits identified for sample 537 correspond to substructures that have been identified as essential for the bioactivity of colchicine binding site inhibitors [36, 37]. Bit 900 corresponds to the trimethoxyphenyl ring that is essential for interaction with the binding site [36]. Bits 576 and 706 also represent parts of the trimethoxyphenyl moiety, and are centered on atoms that are part of the methoxy groups where drug-protein interactions are more likely to occur [36]. Bits 813, 724 and 334 are centered on atoms belonging to the phenyl ring that is part of the trimethoxyphenyl group as well, which has been shown to be essential for maintaining the geometry of the molecule required at the binding site [36]. Bit 907 is centered on a keto group where an important drug-tubulin interaction can occur in the form of a hydrogen bond [36, 37], and bit 947 is centered on a carbon atom that is linked to a methoxy group, which also might potentially be involved in drug-protein interactions [36]. Bit 302 is more difficult to interpret, but it appears to be representing part of the central 7-membered ring. These results indicate that the DL model was capable of learning which molecular features are the most relevant for predicting drug response in this particular case.

It would also be possible to determine which AtomPair fingerprint bits are most predictive of drug sensitivity for specific samples in the CCRF-CEM test set using the calculated SHAP values. However, due to the use of a hashed version of AtomPair fingerprints with a fixed length, obtaining more information on the specific fragments that are associated with each fingerprint bit is not possible, making these fingerprints more difficult to interpret than ECFP4 fingerprints.

SHAP values were only calculated for the NCI 1 and CCRF-CEM tasks because we were unable to apply SHAP directly to TextCNN (best type of model for the PC-3 and A549/ATCC datasets) and GCN (best model on the NCI 109 task). More explanation methods, including graph-specific methods such as GNNExplainer [38], should be explored the future.

Although SHAP helped to identify important features and explain how individual features affect the output of some of the DL models developed in this study, it is still difficult to explain how the interactions between multiple drug features influence drug response. The use of alternative ML methods that produce human-readable models, such as Decision Trees or other rule induction algorithms, or relational learning algorithms (e.g. inductive logic programming), may be preferable when a greater degree of interpretability is required.

Global feature importance for the ECFP4 model trained on the NCI 1 dataset. Only the 20 most important features are shown, and features are ordered according to their importance. Each point represents a sample in the test set, and the color of the points represents the value of a particular feature for that sample.

Global feature importance for the AtomPair model trained on the CCRF-CEM dataset. Only the 20 most important features are shown, and features are ordered according to their importance. Each point represents a sample in the test set, and the color of the points represents the value of a particular feature for that sample.

SHAP explanation of the prediction made by the ECFP4 model for sample 537 from the NCI 1 test set, represented as a waterfall plot. Features are ordered by their impact on the model output. Only the top 20 features that contribute the most to the prediction are shown.

Molecular fragments corresponding to the ten ECFP4 bits that contribute the most towards the prediction for sample 537 from the NCI 1 test set.

## Section: Conclusions

Most compound representation benchmarking studies are focused on molecular property prediction or drug-target interaction prediction tasks. The aim of this study was to determine which types of representations perform best for the specific problem of drug sensitivity prediction in cancer cell lines. Both traditional molecular fingerprints and DL-based representation learning methods were compared. Our findings show that most compound representations perform similarly. Nevertheless, this comparison of methods allowed the identification of representation strategies that consistently performed well across different drug response datasets. Some end-to-end DL models were capable of performing as well as or even better than traditional fingerprint-based models even on smaller datasets. Additionally, less well-known molecular fingerprints may be interesting alternatives to some of the more popular types of molecular fingerprints. The effect of combining multiple compound representation methods into ensembles of models was also evaluated in this study. The results of this analysis show that this strategy led to improved predictive performance. Finally, this study has also shown that SHAP can be used to increase the interpretability of fingerprint-based DL models. These findings can help guide the development of new DL-based drug response prediction models trained on screening data from other screening projects.

The chemoinformatics software package that was used to carry out these analyses is under constant development and it is currently at a pre-release version. New models and features will be added in the future.


---

# Evaluating the Microsatellite Instability of Colorectal Cancer Based on Multimodal Deep Learning Integrating Histopathological and Molecular Data

- **Authors:** Wenjing Qiu, Jiasheng Yang, Bing Wang, Min Yang, Geng Tian, Peizhen Wang, Jialiang Yang
- **Issuer:** Frontiers in oncology
- **Type:** Scientific article
- **Published:** 2022-07-05
- **Language:** en
- **DOI:** 10.3389/fonc.2022.925079
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35865460/
- **Licence:** CC-BY

## Section: Abstract

AbstractMicrosatellite instability (MSI), an important biomarker for immunotherapy and the diagnosis of Lynch syndrome, refers to the change of microsatellite (MS) sequence length caused by insertion or deletion during DNA replication. However, traditional wet-lab experiment-based MSI detection is time-consuming and relies on experimental conditions. In addition, a comprehensive study on the associations between MSI status and various molecules like mRNA and miRNA has not been performed. In this study, we first studied the association between MSI status and several molecules including mRNA, miRNA, lncRNA, DNA methylation, and copy number variation (CNV) using colorectal cancer data from The Cancer Genome Atlas (TCGA). Then, we developed a novel deep learning framework to predict MSI status based solely on hematoxylin and eosin (H&E) staining images, and combined the H&E image with the above-mentioned molecules by multimodal compact bilinear pooling. Our results showed that there were significant differences in mRNA, miRNA, and lncRNA between the high microsatellite instability (MSI-H) patient group and the low microsatellite instability or microsatellite stability (MSI-L/MSS) patient group. By using the H&E image alone, one can predict MSI status with an acceptable prediction area under the curve (AUC) of 0.809 in 5-fold cross-validation. The fusion models integrating H&E image with a single type of molecule have higher prediction accuracies than that using H&E image alone, with the highest AUC of 0.952 achieved when combining H&E image with DNA methylation data. However, prediction accuracy will decrease when combining H&E image with all types of molecular data. In conclusion, combining H&E image with deep learning can predict the MSI status of colorectal cancer, the accuracy of which can further be improved by integrating appropriate molecular data. This study may have clinical significance in practice.Keywords: microsatellite instability, H&E images, multi-omics data, multimodal deep learning, compact bilinear pooling

## Section: 1 Introduction

Colorectal cancer (CRC) is a common digestive tract malignancy. CRC is the third largest cancer in the world, and the second leading cause of cancer-related death; the incidence rate and mortality rate of CRC were third and fifth, respectively, among all cancers in China, with more than 250,000 new patients and 140,000 deaths annually (1–3). Sporadic colorectal cancer (SCRC) accounts for about 85%, and hereditary nonpolyposis colorectal cancer (HNPCC) accounts for about 10%–15% of all CRC patients (4). SCRC is mainly affected by environment, diet, living habits, and chronic inflammation, which leads to the mutations of the “administrator gene” and “guard gene”; the mutations disrupt the mechanisms for inhibiting cell growth, promoting cell death, and maintaining cell stability. Among them, microsatellite instability (MSI) is involved in the occurrence of SCRC, with an incidence of 12%–15% (5). The value of MSI in the diagnosis, treatment response, and prognosis of CRC has attracted global attention (6–8).

MSI refers to the change in the length of normal microsatellites caused by the deletion or insertion of repeated bases compared with normal tissue cells (9). In 2001, Fukushima and Takenoshita (10) found that MSI significantly increased the random mutation rate of genes, especially the mutation of tumor-related genes, which is an important mechanism of tumorigenesis.

There is some evidence to support the use of pre-diagnostic MSI in clinical decision-making. First, MSI detection is recommended for the diagnosis of Lynch syndrome. Lynch syndrome is the most common hereditary colon cancer syndrome, which is associated with germline mutations in the MMR gene (MLH1, MSH2, MSH6, or PMS2) (11). MSI status helps to identify families with the syndrome. Second, MSI is one of the key factors affecting the prognosis of CRC, especially in early cases (12, 13). In general, patients with stage II CRC with high MSI (MSI-H)/MMR deficiency (d MMR) have a better prognosis than patients with microsatellite stability (MSS) and low MSI (MSI-L)/MMR (p MMR) (13). Third, MSI status can be used to evaluate therapeutic response, including fluoropyrimidine-based chemotherapy (14) and immunotherapy (15). Fluoropyrimidine (5-FU or capecitabine) is the pillar of the CRC chemotherapy strategy. It plays an important role not only in neoadjuvant therapy but also in prognosis treatment (16, 17). However, patients with MSI-H status are usually resistant to 5-FU-based chemotherapy (18). Immunotherapy is an emerging and promising treatment for CRC because MSI-H tumors have a large number of mutant neoantigens, which makes them sensitive to immune checkpoint inhibitors (19). Therefore, MSI status is crucial for selecting CRC treatment and evaluating the response to treatment (20).

In recent years, the deep learning method has become a newly developing method, which has shown excellent performance in the fields of computer vision (21, 22), speech recognition (23), and bioinformatics (24–27). Deep learning technology has the characteristics of end-to-end training, and can also represent abstract concepts or patterns level by level through deep neural networks (28). At the same time, researchers use the technology of transfer learning to transfer the network model pre-trained by Image Net to the classification task of pathological image segmentation by fine-tuning the classifier layer of convolutional neural network. In the 2016 CAMELYON breast cancer lymph node metastasis challenge, 25 of the 32 algorithms submitted by the contestants used convolution neural networks (CNNs) (29) including VGG-16 (30), GoogLeNet (31), and other well-known models such as (32). Xu et al. used pre-trained AlexNet to extract the features of brain tumor pathological image blocks and achieved 97.5% classification accuracy on the small-sample MICCAI 2014 brain tumor digital pathology challenge dataset. Yang et al. proposed a multimodal deep learning method to predict the recurrence and metastasis risk of Her2-positive breast cancer by integrating pathological image with clinical information (33). Ye et al. developed a deep convolution network to evaluate prognosis of cervical cancer (34). Ke et al. (35) used the knowledge distillation model of multistage CNN to classify MSI-H and MSS, and obtained an AUC = 0.802; Kather et al. (36) used ResNet18 to predict the histopathological sections of CRC, and the AUC obtained by MSI was 0.84.

With the increasing availability of high-throughput genomic and transcriptional data, there are several molecular biomarkers in The Cancer Genome Atlas (TCGA), including somatic mutation, copy number variation, gene expression, microRNA expression, and DNA methylation, which were used to track cancer (37–39) and predict cancer recurrence and metastasis (40). Hayes identified relevant microRNA and mRNA features that predict high-risk and low-risk patients with glioblastoma (GBM). Sun et al. integrated gene expression profile, CNA spectrum, and clinical data to predict the prognosis of breast cancer, achieving a good performance of AUC = 0.843.

Based on the feasibility of cancer prediction and multimodal fusion from the pathological image level, our goal was to compare these unimodal data and combinations to predict the MSI ability of CRC in a unified context and to explore whether multimodal data fusion can significantly improve prediction accuracy compared with single-mode data.

## Section: 2 Materials and Methods

The properties of the dataset.

The network architecture of ResNet34.

## Section: 2 Materials and Methods › 2.1 Data Description

We overlapped the H&E images data and omics data to obtain 353 sample sizes, of which 63 were labeled MSI-Hs, which were marked as 1; 290 cases were labeled MSSs, which were labeled as 0.

Pathological image. We used the method of Kather et al. to publish the CRC with hematoxylin and eosin stabilized (CRC-HE) dataset, including 100,000 pieces of 224 × 224 pixel H&E-stained pathological images that were divided into blocks; each pixel in the block corresponds to 0.5 μm × 0.5 μm organization. To eliminate the color difference of slices from different data sources in the process of production and scanning, all H&E images have been dyed and standardized according to the method of Macenko et al. (41).

Multi-omics data. Multi-omics data of CRC were downloaded from the TCGA database, including messenger RNA (mRNA), microRNA expression (miRNA), long non-coding RNA (lncRNA), DNA methylation (Met), and gene copy number variation (CNV). Their forms include Counts and FPKM. The difference between FPKM and Counts is that Counts is the original expression quantity that is not processed in the data background, although FPKM and Counts are data processing methods. In the analysis of this paper, the difference analysis part adopts the form of Counts, and the modeling analysis part adopts the form of FPKM. Table 1 shows the characteristic dimensions of each omics data.

The properties of the dataset.

## Section: 2 Materials and Methods › 2.2 Feature Extraction

The network architecture of ResNet34.

## Section: 2 Materials and Methods › 2.2 Feature Extraction › 2.2.1 H&E Image Feature Representation Based on ResNet34

CNN is the latest algorithm for image recognition and classification because of its stable learning performance (42). CNN includes an input layer, a middle hidden layer, and an output layer. The middle-hidden layer is composed of multiple convolution layers, pooling layers, and full connection layers. CNN can be optimized through error backpropagation and gradient descent algorithm. However, after reaching a certain depth, increasing the number of layers of CNN cannot further improve the classification performance. Due to the vanishing gradient problem, the network convergence speed is slow and the classification accuracy is negative. ResNet is used to solve this problem. The difference between residual network and ordinary network is that jump connection is introduced, which can help the information of the previous residual block enter the next block stream unimpeded, improve the information flow, and avoid the problem of vanishing gradient and the degradation caused by the great depth of the network.

ResNet is a large-scale CNN constructed from residual blocks. We used ResNet34 ( Figure 1 ) to extract H&E image features. The architecture of ResNet34 is divided into four stages. Every Resnet architecture performed the initial convolution and max-pooling using 7 x 7 and 3 x 3 kernel sizes, respectively. The residual structure of BTNK1 can reduce the dimension, and the dimension is reduced by a 1 x 1 convolution kernel on the shortcut branch. It is worth noting that in Stage 2, Stage 3, and Stage 4, it is executed with stride 2; therefore, the size of the input will be halved in height and width, but the channel width will be doubled. When the image advances from one stage to another, the channel width will be doubled and the input size will be reduced by half. Finally, the network has an average pool layer, followed by a full connection layer containing 1,000 neurons.

The network architecture of ResNet34.

## Section: 2 Materials and Methods › 2.2 Feature Extraction › 2.2.2 Feature Extraction of Multi-Omics Data

A common problem with high-throughput sequencing datasets is the so-called “Curse of dimensionality” (40). Variable selection is very important for interpretation and prediction, especially for high-dimensional datasets. In this work, we used the characteristic importance attribute of Random forest (Gini-index) (43) to deal with high-dimensional variables in omics data. Features with Gini-index greater than or equal to 0.005 were the most important features. Then, the multimodal data are simply spliced from the important features obtained from the single group data. Then, select according to the feature importance of random forest, and the feature with a Gini-index greater than 0.005 is regarded as the most important feature.

## Section: 2 Materials and Methods › 2.3 Feature Fusion

The most common fusion methods are concatenation, element-wise product, and element-wise sum. These simple operations are not as effective as the outer product, and complex relationships can be established between the two modes. However, the complexity of outer product calculation is too high. The n-dimensional vector calculated the outer product to obtain the n 2-dimensional vector. In this work, our fusion method was the multimodal compact bilinear (MCB) model. MCB maps the result of the outer product to low-dimensional space without explicit calculation of the outer product.

## Section: 2 Materials and Methods › 2.4 Screening of Differentially Expressed Genes

The R package “Deseq2” was used to identify differentially expressed genes (DEGs) in mRNA, miRNA, and lncRNA gene expression profiles. Genes with an adjusted p-value < 0.1 and a log2foldchange (LFC) > 0 were classified as upregulated genes, whereas those with an adjusted p-value < 0.1 and an LFC < 0 were classified as downregulated genes. Taking |log2 (foldchange)| ≥ 1 and the corrected p-value < 0.05 as the threshold, the genes with significant differences were selected. The R-Pack “heat map” shows significantly different genes. The R-Pack “cluster analyzer” is used for Gene Ontology (GO) enrichment analysis and calculation. R-Pack ggplot2 is used to generate enrichment pathways in significantly different genes.

## Section: 2 Materials and Methods › 2.5 Evaluation Metrics

Fivefold cross validation (5-f cv) is used to evaluate the accuracy of the algorithm.5-k cv: Divide the dataset into five equally, and take turns using four of them as training data and one as test data. The performance of the classification algorithm is estimated by averaging 5 test sets. For binary classification, the area under the subject operating characteristic curve (AUC), Accuracy (Acc), Precision, Recall, and F1_score are used to evaluate the performance of the model.

## Section: 3 Results

Experimental flowchart. (A) Only H&E images data. (B) H&E images combined with multi-omics data.

Differential analysis of mRNA, miRNA, and lncRNA. (A) Heat map of the top 40 differentially expressed genes of mRNA. (B) Heat map of the top 40 differentially expressed genes of miRNA and (C) lncRNA. (D) GO analysis, including BP, CC, and MF. (E) KEGG enrichment analysis.

Performance of H&E images and images combined with omics data. (A) The AUC score of image and image combined with omics data. (B) Performance of each mode in Accuracy, Precision, Recall, and F1_score index. HE_omi: H&E image features combined with multi-omics features.

## Section: 3 Results › 3.1 The Overall Framework of This Study

In this work, we studied the data in two parts. In the first part, the differences of mRNA, miRNA, and lncRNA were analyzed. In the second part, in the modeling analysis, we conducted two experiments ( Figure 2 ). First, only the H&E image data were used to build the model and predict the classification ( Figure 2A ). Second, the H&E image was combined with omics for prediction and classification ( Figure 2B ), including H&E image combined with single omics data and H&E images combined with multi-omics data.

Experimental flowchart. (A) Only H&E images data. (B) H&E images combined with multi-omics data.

## Section: 3 Results › 3.2 mRNA, lncRNA, and miRNAs Differ Significantly Between MSI-H and MSI-L/MSS Groups

We comprehensively analyzed the differential expression of mRNA, lncRNA, and miRNA between MSI-L/MSI-H and MSS groups. In the lncRNA group, we obtained 1,130 upregulated expressions and 631 downregulated expressions. A total of 172 upregulated expressions and 125 downregulated expressions were obtained in miRNA. In the mRNA group, 5,210 upregulated genes and 5,466 downregulated genes were obtained. After strictly restricting the adjusted p-value, we obtained 663 significantly differentially expressed lncRNAs, 61 significantly differentially expressed miRNAs, and 1,898 significantly different mRNA genes (see Supplementary Tables 1–3 ). As shown in Figures 3A–C , we used the first 40 significant difference expressions to draw the heat map.

GO analysis was used to annotate the function of DEGs between MSI-H and MSI-L/MSS. In the biological process (BP) category, genes with significant differences were mainly enriched in organic acid, organic anion, and carboxylic acid transport. For cell component (CC) categories, genes with significant differences were mainly clustered in the apical part of the cell. In the binding molecular function (MF), significantly different genes were mainly involved in signaling receptor activator activity and receptor–ligand activity ( Figure 3D ). Further KEGG enrichment analysis was carried out to explore the potential pathological pathway of cancer. As shown in Figure 3E , the first two significant enrichment pathways were neuroactive ligand–receptor interaction and cytokine receptor interaction. Our significantly different genes were involved in these pathways, which may also contribute to the diagnosis of cancer. For example, the MUC6 gene is one of the mucin genes that make up the gastric mucosa, and its expression is downregulated in precancerous lesions and gastric cancer tissues (44). Dpcr1 DPCR1(Mucl3MUCL3) is a protein-coding gene. MUCL3 may regulate NF kappa B signaling and play a role in cell growth.

Differential analysis of mRNA, miRNA, and lncRNA. (A) Heat map of the top 40 differentially expressed genes of mRNA. (B) Heat map of the top 40 differentially expressed genes of miRNA and (C) lncRNA. (D) GO analysis, including BP, CC, and MF. (E) KEGG enrichment analysis.

## Section: 3 Results › 3.3 H&E Images Combined With DNA Methylation Performed Best in Predicting MSI of Colorectal Cancer

We evaluated the performance of images combined with omics data in predicting the MSI of CRC. 5-f cv was used to train ResNet34. As shown in Figure 4A , the prediction result of H&E images combined with DNA methylation (ROC = 0.952) was higher than that of H&E images, H&E images combined with multi-omics, and image combined with other omics data. In addition to H&E images combined with methylation, H&E images combined with other omics was lower than the prediction result of image in precision index. In Acc, Recall, and F1_ score index, the prediction results of image combined with omics were higher than those of image ( Figure 4B ).

Performance of H&E images and images combined with omics data. (A) The AUC score of image and image combined with omics data. (B) Performance of each mode in Accuracy, Precision, Recall, and F1_score index. HE_omi: H&E image features combined with multi-omics features.

## Section: 4 Discussion

As we all know, MSI is widely considered as an indicator of prediction and prognosis. It has been well studied in several types of human cancers. In CRC, about 15% to 20% of CRC cases are found to be associated with MSI-H. Therefore, MSI states that detection is particularly important for CRC and is recommended by current clinical guidelines (6, 45). With the continuous development of computer deep learning technology, computer-aided diagnosis and prognosis prediction based on H&E staining images has attracted more and more attention because of its advantages of high speed, low cost, and no trauma. Multimodal fusion is a typical interdisciplinary field and has gradually become a research hotspot. In many studies, some results have been achieved (46–48). In conclusion, the accuracy of the image-based prognosis prediction model needs to be further improved.

In this study, we systematically analyzed the differences in mRNA, lncRNA, and miRNA omics data between MSI-H and MSI-L/MSS groups, and compared the classification performance of image and image data combined with omics data to predict the MSI of CRC. In this experiment, by comparing the results of ROC, we found that H&E image combined with Met had the best performance in predicting the MSI of CRC. The result of H&E image combined with all omics data was lower than that of image combined with single omics data and higher than that of H&E images.

Our study has some limitations. First, the selected omics data were the cancer sample construction and evaluation model, not the adjacent data. Only the differences between MSI-L/MSS and MSI-H in cancer samples were studied. Second, we do not have independent datasets for validation, because we cannot find other databases to provide the required data except for the TCGA database. Finally, our multi-omics feature was just simple splicing of different single omics. It is best to test the effects of interactions between omics because the genes of each omics are not completely independent. Therefore, in our follow-up study, we will try to include para-cancerous samples, including independent test samples, and add interactive items and new classification models to improve the prediction accuracy.

## Section: 5 Conclusion

To sum up, we integrated molecular biological information and images to classify and predict the MSI of CRC. This is the first study to compare the ability of different modes in predicting the MSI of CRC under the same conditions, including the same dataset, the same preprocessing scheme, and the same classification algorithm. There were significant differences in mRNA, lncRNA, and miRNA omics data between MSI-H and MSI-L/MSS groups. By comparing the results of ROC, we found that H&E images combined with Met had the best performance in predicting the MSI of CRC. The result of image combined with all omics data was lower than that of image combined with single omics data and higher than that of H&E images.

## Section: Data Availability Statement

Publicly available datasets were analyzed in this study. These data can be found here: https://www.cancer.gov/about-nci/organization/ccg/research/structural-genomics/.

## Section: Author Contributions

JLY and PW designed the study. WQ, JSY, BW, MY, and GT performed the study, analyzed the data, and interpreted data. WQ and JLY wrote the manuscript. JSY, BW, MY, GT, and PW reviewed the manuscript. All authors contributed to the article and approved the submitted version.

## Section: Funding

This research was funded by the National Natural Science Foundation of China (numbers 51574004 and 62172004), the Natural Science Foundation of the Higher Education Institutions of Anhui Province, China (KJ2019A0085), the Academic Foundation for Top Talents of the Higher Education Institutions of Anhui Province (gxbjZD2016041), and the Educational Commission of Anhui Province (KJ2019ZD05).

## Section: Conflict of Interest

Authors WQ, JLY, GT, and MY were employed by Geneis Beijing Co., Ltd., Beijing.

The remaining authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.

## Section: Publisher’s Note

All claims expressed in this article are solely those of the authors and do not necessarily represent those of their affiliated organizations, or those of the publisher, the editors and the reviewers. Any product that may be evaluated in this article, or claim that may be made by its manufacturer, is not guaranteed or endorsed by the publisher.

## Section: Supplementary Material

The Supplementary Material for this article can be found online at: https://www.frontiersin.org/articles/10.3389/fonc.2022.925079/full#supplementary-material

Click here for additional data file.

Click here for additional data file.

Click here for additional data file.

## Section: Associated Data

Click here for additional data file.

Click here for additional data file.

Click here for additional data file.

## Section: Associated Data › Supplementary Materials

Click here for additional data file.

Click here for additional data file.

Click here for additional data file.

## Section: Associated Data › Data Availability Statement

Publicly available datasets were analyzed in this study. These data can be found here: https://www.cancer.gov/about-nci/organization/ccg/research/structural-genomics/.


---

# Evaluating the performance of machine-learning regression models for pharmacokinetic drug-drug interactions

- **Authors:** Jaidip Gill, Marie Moullet, Anton Martinsson, Filip Miljković, Beth Williamson, Rosalinda H Arends, Venkatesh Pilla Reddy
- **Issuer:** CPT: pharmacometrics & systems pharmacology
- **Type:** Scientific article
- **Published:** 2022-11-17
- **Language:** en
- **DOI:** 10.1002/psp4.12884
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36382697/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractCombination therapy or concomitant drug administration can be associated with pharmacokinetic drug–drug interactions, increasing the risk of adverse drug events and reduced drug efficacy. Thus far, machine‐learning models have been developed that can classify drug–drug interactions. However, to enable quantification of the pharmacokinetic effects of a drug–drug interaction, regression‐based machine learning should be explored. Therefore, this study investigated the use of regression‐based machine learning to predict changes in drug exposure caused by pharmacokinetic drug–drug interactions. Fold changes in exposure relative to substrate drug monotherapy were collected from 120 clinical drug–drug interaction studies extracted from the Washington Drug Interaction Database and SimCYP compound library files. Drug characteristics (features) were collected such as structure, physicochemical properties, in vitro pharmacokinetic properties, cytochrome P450 metabolic activity, and population characteristics. Three different regression‐based supervised machine‐learning models were then applied to the prediction task: random forest, elastic net, and support vector regressor. Model performance was evaluated using fivefold cross‐validation. Strongest performance was observed with support vector regression, with 78% of predictions within twofold of the observed exposure changes. The results show that changes in drug exposure can be predicted with reasonable accuracy using regression‐based machine‐learning models trained on data available early in drug discovery. This has potential applications in enabling earlier drug–drug interaction risk assessment for new drug candidates.

## Section: Text

Study Highlights WHAT IS THE CURRENT KNOWLEDGE ON THE TOPIC? Machine learning has been used to classify drug–drug interactions by type (pharmacokinetic or pharmacodynamic) and by severity using chemical structure feature sets or knowledge graphs rich in biomedical data. WHAT QUESTION DID THIS STUDY ADDRESS? The utility of machine‐learning regression models to predict the area under the curve ratio of a drug administered alone versus the drug administered with another “perpetrator” drug. In addition, the utility of features available early in the drug‐discovery process (e.g., cytochrome P450 [CYP450] activity data) was investigated. WHAT DOES THIS STUDY ADD TO OUR KNOWLEDGE? Regression modeling using a support vector regressor is effective, with the majority (78%) of points predicted correctly within twofold of actual area under the curve ratios. In addition, CYP450 activity and fraction metabolized data are effective as features even when used as a lone feature set, likely due to their mechanistic relation to drug–drug interactions. HOW MIGHT THIS CHANGE DRUG DISCOVERY, DEVELOPMENT, AND/OR THERAPEUTICS? This study demonstrates the potential for regression machine‐learning modeling to be used in early drug–drug interaction risk assessment using features available early in drug discovery.

## Section: INTRODUCTION

The use of polypharmacy, where patients are prescribed multiple drugs at the same time, is increasing, with 32% of elderly adults affected in Europe. 1 Polypharmacy comes with the risk of drug–drug interactions (DDIs). DDIs can result in under‐ or overexposure to the drugs administered, which can reduce efficacy or increase adverse drug events (ADEs). In DDI studies, the drug that exerts an effect on another drug is known as the “perpetrator,” whereas the affected drug is known as the “substrate.” Pharmacokinetic (PK) DDIs are a subset of DDIs where changes in drug activity are the result of changes in the absorption, distribution, metabolism, and excretion (ADME) characteristics of the drugs involved. This usually occurs through a change in the activity of transporters or metabolic enzymes that are involved in the ADME of both the perpetrator and the substrate. 2 The cytochrome P450 (CYP) enzyme family metabolizes ~45% of marketed drugs. 3 The fraction of a drug metabolized by a specific CYP is known as the fraction metabolized (f m). 2 CYP‐mediated PK DDIs can potentially occur as a result of two conditions. First, the perpetrator drug must inhibit or induce a CYP. Second, the f m by that CYP for a coadministered substrate drug must be >25%. 4 These DDIs have the potential to be clinically significant, with 7%–44% of ADEs caused by DDIs. 5 Inhibition of CYPs can lead to reduced substrate metabolism, resulting in increased exposure, whereas induction would result in the opposite effect. 4 Physiologically based PK (PBPK) software, such as SimCYP, 6 can model and predict DDIs. However, these models require the collection of in vitro and clinical in vivo data to build models for each drug and take time to validate. Therefore, the application of machine learning (ML) has been explored to predict DDI risk for drugs sharing ADME features with established drugs without needing to build individual PBPK models.

Machine learning algorithms consist of a set of predictor variables (features) to make predictions for the dependent variable (label). A prevalent approach for applying ML in DDI prediction has been to compute similarity metrics between features of a drug to predict their interaction because drugs sharing similar features are more likely to share interaction targets and therefore affect each other's pathways. 7 An early approach was a heterogenous network‐assisted inference framework to predict DDIs. 7 This involved generating a heterogenous set of similarity features between drug A and drug B describing chemical, genomic (based on target proteins), phenotypic (based on ADEs), and therapeutic similarities to build a binary classifier for whether a DDI will occur between the two drugs. The use of similarity measures was further developed by making predictions based on the structural similarity between a drug A and the drugs that interact with the proteins, enzymes, and transporters in the interaction network of drug B. 8 However, due to the binary nature of these classifiers, the predictions were limited in their descriptive granularity. The multitask classifier “DeepDDI” method helped to address this by classifying 86 types of interaction using structural similarity profiles. This enabled the prediction of possible mechanisms behind the predicted DDIs, enhancing model interpretability. 9 These predictions were made using features derived only from structural information.

Another approach to predicting DDIs uses features from knowledge graphs, which describe entities (e.g., drug properties) and the relationships between them. This has the benefit of being able to use all the information relating to the PK and pharmacodynamics (PD) of a drug, such as drugs, pathways, structures, and diseases. The complex embedding method 10 was used to generate features from a knowledge graph for high classification accuracy. 11 An alternative embedding technique improved the area under the precision‐recall curve (AUCPR) score from 0.88 to 0.97 and also enabled prediction of the adverse effect from a DDI even when the adverse effect was rare. 12 A different approach also demonstrated that integrating structural information together with knowledge graphs rather than using structure or knowledge graphs alone improves performance. 13

The performance of these more recent classifiers shows highly accurate classification scores. However, the approaches using knowledge graphs is limited to late‐stage DDI risk assessment and cannot be applied in early discovery because to build these algorithms, large amounts of biomedical data to inform the knowledge graphs are required and need to include features such as affected pathways, target proteins, and adverse effects. Although structure‐based models do not rely on PK data that only become available after in vitro assays are performed, not incorporating these data may limit the performance in predicting PK DDIs. Furthermore, models thus far have focused on classification tasks, whether binary or multitask. However, the development of regression‐based models for PK DDI prediction would be expected to enable a more precise estimate of the extent of the PK changes in the substrate drug, which would enable better‐informed decisions regarding the risk associated with the PK DDI that could warrant dose reduction or discontinuation of this drug candidate.

To explore a more quantitative predictive approach, regression‐based ML models for PK DDI prediction were investigated based on the use of early PK data, such as the CYP activity profile and f m for a given drug. The performance of the model using different feature sets was also assessed as well as whether the regression outputs could be converted to correct DDI classes based on US Food and Drug Administration (FDA) guidelines 14 by evaluating the classification performance of the model.

## Section: MATERIALS AND METHODS

Hyperparameter values used for optimization of regression models

Thresholds for classification of predictions using log10 AUC ratio values

## Section: MATERIALS AND METHODS › Data collection › DDI data

Clinical DDI data were collected from the Washington Drug Interaction Database 15 and SimCYP compound files. 6 Studies were included based on the following criteria: drugs involved must be available in SimCYP (Version 20), 6 dosing regimen should begin with steady‐state dosing of the perpetrator drug before a single substrate dose (to simulate clinical coadministration of the drugs), and the interaction must be mediated via time‐dependent inhibition (because the CYP activity profiles used as features are time dependent). In total, data from 120 studies were collected. The format of the PK data used in the analyses was the observed area under the plasma drug concentration‐time curve (AUC) ratio, defined as the ratio of the AUC of the substrate drug administered in monotherapy overthe AUC of the substrate drug with the perpetrator drug. Remaining data were used directly as features or used to generate other features using in silico models. Study design details were used to specify the simulation conditions used in each SimCYP simulation. CYP activity‐time profiles and f m were generated from these simulations. A total of 201 timepoints of CYP activity for each CYP in a study simulation were extracted and used as features to represent the CYP activity‐time profile. The f m data were collected for each CYP with and without the perpetrator drug for each DDI. System‐specific features are described in more detail elsewhere (Table S1).

## Section: MATERIALS AND METHODS › Data collection › Drug‐specific data

For each DDI, drug‐specific data were also collected. This included physicochemical properties and in vitro ADME data, collected from SimCYP compound files. Simplified molecular‐input line‐entry system 16 representations of drug chemical structures were used as an input for in silico models to derive drug‐specific data additional to the SimCYP features. Chemical descriptors composed of AstraZeneca's internal OESelma descriptors, which are 84 molecular descriptors of additional physicochemical properties, 17 and extended connectivity fingerprints of diameter 4 (ECFP4), 18 a set of topological circular fingerprints to describe molecular structures. PK descriptors were features derived from AstraZeneca's internal ML models for predicting human PK 19 and in vitro ADME parameters. 20 , 21 Drug‐specific features are described in more detail in Table S2.

## Section: MATERIALS AND METHODS › Data collection › Feature engineering

All models (random forest, elastic net, and support vector regression [SVR]) were implemented in Python using the Scikit‐learn library. 22 To enable compatibility between the feature data and the Scikit‐learn package, categorical features were encoded into binary format using one‐hot encoding. To control for different scales between features, values were converted from its original scale into standard deviation units as follows: z=x−μσ where z is the new feature value, x is the original feature value, μ is the mean value for the feature, and σ is the standard deviation of the feature. To remove redundant features, feature selection was implemented by regenerating the models using the most important features via the “Select from model” function in Scikit‐learn. This method of feature selection was not included for the SVR implementation due to software incompatibility. Therefore, to ensure differences in performance between SVR and other models were not due to feature selection, additional random forest and elastic net models were built for comparison without feature selection.

## Section: MATERIALS AND METHODS › Data collection › Logarithmic transformations of AUCs

AUC ratios showed a strong positive skew because induction observations ranged between 0 and 1, whereas inhibition observations had a range of 1 to ~30. To normalize the AUC distribution and make it more uniform (reducing the potential for prediction bias toward the ratios < 1), a log10 transformation was applied.

## Section: MATERIALS AND METHODS › ML modeling

Collected data were used to train regression‐based ML models. Model performance was evaluated using the nested fivefold cross‐validation. This involved splitting the full dataset (120 samples) into 96 training (80%) and 24 test (20%) samples five times with no overlap in each step/fold. For each such trial, additional (nested) fivefold cross‐validation was performed on the training data to optimize hyperparameters. Then, an optimized model was applied to estimate the test set performance. Performance values of five independent test sets were then averaged to provide final model accuracy. The candidate hyperparameter values are detailed in Table 1. All random states were set to zero. For each model, collected data for each DDI were used as features, whereas observed log10 AUC ratio data were used as labels. Deep‐learning techniques were not implemented due to the small sample size and to maintain model interpretability. Random forests are an ensemble of decision trees, where the output prediction for a given input is the average of the predictions of all the decision trees. 23 Elastic net regression uses linear regression with regularization using a combination of the lasso and ridge penalties. 24 SVR uses subsets of the training data (support vectors), rather than all of the data, to determine the regression line to enable increased generalizabiltiy. 25 A negative control regressor model was also implemented to model random prediction by predicting the mean of the training label data. The ML models were expected to significantly outperform the negative control regressor model to be considered predictive. Feature importance was determined using Shaply Additive Explanations (SHAP) values. 26

Hyperparameter values used for optimization of regression models

## Section: MATERIALS AND METHODS › Classification criteria

A potential use case of the log10 AUC ratio predictions is to classify interactions according to established FDA DDI guidelines, 14 which are described in Table 2 (to two significant figures). These reference thresholds were therefore used to convert the regression output into categorical labels.

Thresholds for classification of predictions using log10 AUC ratio values

## Section: MATERIALS AND METHODS › Statistical analysis › Regression performance

Regression performance was evaluated using the coefficient of determination (R 2), root mean square error (RMSE), and the twofold error score. All regression performance metrics were reported as the mean of the result (to two significant figures) after fivefold cross‐validation for each model along with the 95% confidence intervals.

R 2 describes the proportion of variation of the dependent variable (predicted log10 AUC ratio) that can be explained by the independent variable (observed log10 AUC ratio). It is defined as R2=1−∑i=1nyi−y^i2∑i=1nyi−y¯i2 where n is the sample size and for the i‐th sample, y is the observed value, y^ is the predicted value, and y¯ is the mean observed value. To investigate whether the non‐normally distributed predictions and observations were statistically significantly different, the Wilcoxon signed‐rank test was used.

Root mean square error describes the magnitude of error for predictions, meaning lower scores are better, and is defined as RMSE=∑i=1nyi−y^i2n A twofold error margin was used as the range for acceptable predictions. The metric score was defined as the proportion of predicted log10 AUC ratios within twofold of the observed log10 AUC ratios. This wider margin was chosen because it is the industry standard for AUC prediction of drugs with a wide therapeutic window, 27 making it appropriate for this proof‐of‐concept analysis.

## Section: MATERIALS AND METHODS › Statistical analysis › Classification performance

Classification performance was evaluated using macro F1 scores, reported as the mean (to two significant figures) across after fivefold cross‐validation ±95% confidence limits. Macro scores were used to provide equal weighting to each class because the prediction of each class had equal importance in this model. Macro F1 scores were calculated using the precision and recall metrics. The macro precision describes the proportion of positive predictions that were true positives per fold, defined as Macro Precision=∑i=1lTPiTPi+FPil where TPi is the number of true positives for class i, FPi is the number of false positives, and l is the number of classes. Recall describes the proportion of actual positives that were correctly predicted (sensitivity), defined as Macro Recall=∑i=1lTPiTPi+FNil where FNi is the number of false negatives for a given class. Because there is a trade‐off between precision and recall performance, 28 F1 score (harmonic mean of precision and recall for each fold) was used to evaluate the overall performance of the model. The macro F1 score is defined as MacroF1Score=2Macro Precision*Macro RecallMacro Precision+Macro Recall

## Section: RESULTS

Frequency histogram of the distribution of collected log10 area under the curve (AUC) ratios. Observed log10 AUC ratios were extracted from 120 clinical drug–drug interaction studies. Of the interactions, 73 were inhibition, 41 were induction, and six were noninteractions. The ratios were not uniformly distributed (Kolmogorov–Smirnov test; p < 0.005).

Regression performance of different machine‐learning models on the drug–drug interaction (DDI) dataset. Fivefold cross‐validation results (n = 5) are provided for different machine‐learning models applied to the DDI dataset. Random forest (dotted), elastic net (grid), and support vector machine regressor (striped) were tested, and the mean predictor was a negative control for predictive capability, which always predicted the mean observed log10 area under the curve (AUC) ratio of the training fold. (a) “<Two‐fold error score” reflects the proportion of predicted log10 AUC ratios that were within twofold of their corresponding observed log10 AUC ratios. (b) R 2 represents the coefficient of determination. (c) RMSE represents the root mean square error (lower is better). Data are represented as the mean metric of five test folds, and the gray lines topping each bar indicate the 95% confidence intervals.

Classification performance of machine‐learning regressor outputs after conversion to categorical labels. Predicted log10 area under the curve (AUC) ratios from different machine‐learning models were used to classify interactions according to US Food and Drug Administration guidelines. The possible classes were weak, moderate, and strong inhibition (light, medium, or dark blue) or induction (light, medium, or dark orange). (a) The mean performance of the model across the different classes and folds was also compared (dotted). Data are presented as the mean macro F1 score (harmonic mean of precision and recall) across the five folds (n = 5 for each model), along with lines indicating the 95% confidence intervals. Classification matrices of (b) elastic net, (c) random forest regressor, and (d) support vector regressor outputs are shown. Numbers correspond to the percentage of interactions of a given observed class that were predicted by the model to be a certain class. The red diagonal box indicates the ideal cases where predicted classes matched the observed class, whereas the red arrows indicate cases where observed classes were predicted to be a different class more often than the correct class.

Regression analysis of observed and support vector regressor predicted log10 area under the curve (AUC) ratios. (a) Predicted log10 AUC ratios after fivefold cross‐validation of a support vector regressor were plotted against the observed log10 AUC ratios of the corresponding drug–drug interaction studies. The dashed diagonal line indicates the perfect prediction line where predictions equal observations. The two gray lines on either side indicate the twofold error margins. Predictive performance was generally good (coefficient of determination = 0.73, root mean square error = 0.30, proportion of predictions less than twofold error = 0.78). (b) A plot is shown of the resulting residuals against the observed log10 AUC ratios.

Regression performance of support vector regressor using different feature sets. (a) Support vector regressor model performance is shown using either chemical; in vitro absorption, distribution, metabolism, and excretion; or CYP and f m/FM feature sets. Regression performance was compared using fivefold cross‐validation on the drug–drug interaction dataset. The performance metrics used were the RMSE (gray), R 2 (coefficient of determination; light blue), and twofold error (proportion of predicted log10 AUC ratios within twofold of the observed value; dark blue). Metric scores were reported as the mean score of the five folds along with lines indicating 95% confidence intervals. (b) SHAP values of the 20 most important features in the support vector regressor model are shown. CYP and FM indicate the cytochrome P450 enzyme activity‐time profiles and the fraction of substrate drug metabolized by each CYP enzyme with and without the perpetrator drug. AUC, area under the curve; C max, maximum concentration; CYP2C9, cytochrome P450 2C9; CYP3A4, cytochrome P450 3A4; CYP3A5, cytochrome P450 3A5; ECFP4, extended connectivity fingerprint with diameter 4; EM, extensive metabolizer; Exp, expected activity (simulation output); f m, fraction metabolized; fUmic, fraction unbound in microsomes IC50, half maximal inhibitory concentration; I.V., intravenous administration; Perp, perpetrator; PK, pharmacokinetic; PM, poor metabolizer; PO, oral administration; Pop, population type; RMSE, root mean square error; SHAP, Shaply Additive Explanations; Sub, substrate, T, timepoint

## Section: RESULTS › Observed log10 AUC ratios were unevenly distributed

Distributions of observed data in a training dataset can be a source of bias in a ML model, where less‐represented data ranges show higher prediction error. 29 Therefore, the distribution of the label data in the dataset was investigated to identify potential poorly represented data ranges in the DDI dataset used to train this model. Figure 1 shows a histogram of the log10 AUC ratios of the collected DDI studies (n = 120). The distribution of log10 AUC ratios were determined to be significantly different from a uniform distribution using the Kolmogorov–Smirnov test (p < 0.005). There were a greater number of samples showing inhibition (16 weak, 38 moderate, 19 strong) compared with induction (9 weak, 22 moderate, 10 strong), whereas noninteraction samples were the least common (6). This uneven distribution of log10 AUC ratios in the dataset may have been a source of bias in the ML model.

Frequency histogram of the distribution of collected log10 area under the curve (AUC) ratios. Observed log10 AUC ratios were extracted from 120 clinical drug–drug interaction studies. Of the interactions, 73 were inhibition, 41 were induction, and six were noninteractions. The ratios were not uniformly distributed (Kolmogorov–Smirnov test; p < 0.005).

## Section: RESULTS › SVR showed the strongest regression performance

The regression performance of each model was compared to determine which ML model was most appropriate for the DDI dataset. Each model was subject to fivefold cross‐validation, and a mean predictor model was used as a negative control for predictive performance. Figure 2 shows that random forest, elastic net, and SVR all had significantly lower RMSE and higher R 2 and twofold error scores compared with the control model. Figure 2a shows that the random forest regressor achieved the lowest/weakest twofold error score (0.69), whereas SVR showed the highest (0.78). Figure 2b shows that the elastic net regressor demonstrated the lowest R 2 (0.67), whereas SVR showed the highest (0.73). Figure 2c shows that the highest RMSE score was achieved by the elastic net (0.33), whereas SVR achieved the lowest/best (0.30). SVR also outperformed the elastic net and random forest models built without feature selection (Figure S1). However, the differences between the ML models were small and statistically insignificant, indicating that SVR only marginally outperformed the elastic net and random forest methods. However, all ML models significantly outperformed the mean predictor control.

Regression performance of different machine‐learning models on the drug–drug interaction (DDI) dataset. Fivefold cross‐validation results (n = 5) are provided for different machine‐learning models applied to the DDI dataset. Random forest (dotted), elastic net (grid), and support vector machine regressor (striped) were tested, and the mean predictor was a negative control for predictive capability, which always predicted the mean observed log10 area under the curve (AUC) ratio of the training fold. (a) “<Two‐fold error score” reflects the proportion of predicted log10 AUC ratios that were within twofold of their corresponding observed log10 AUC ratios. (b) R 2 represents the coefficient of determination. (c) RMSE represents the root mean square error (lower is better). Data are represented as the mean metric of five test folds, and the gray lines topping each bar indicate the 95% confidence intervals.

## Section: RESULTS › SVR showed the strongest classification performance after conversion to categorical labels

Classification performance was evaluated to determine whether the regression outputs would be correctly classified according to FDA guidelines. 14 Predicted log10 AUC ratios from the regression models were assigned to a class of DDI, and these classes were compared with the actual class (assigned based on the same thresholds) to determine the F1 score as the measure of performance. Figure 3a shows that all models showed significantly stronger mean performance than the control model. The elastic net showed the lowest macro F1 score of the noncontrol models (0.31), whereas the SVR showed the highest macro F1 score (0.40). However, intermodel performance differences were small and considered insignificant.

Across models, inhibition was generally better predicted than induction with average F1 scores of 0.42 versus 0.33, respectively. The prediction of moderate drug interactions (considering both inhibition and induction, average 0.54) were improved compared with strong (0.32) or weak (0.27) drug interactions. These two trends are concordant with the significantly higher F1 score for moderate inhibition compared with the average of all the classes in each model (0.66 vs. 0.32). In addition, there was no prediction of noninteractions, and therefore there was an F1 score of zero for noninteractions in every model. Figure 3b–d also shows that moderate drug interactions, especially moderate inhibition, had the most true positives and false positives. The random forest model showed the greatest tendency to overpredict the strength of weak interactions and correctly classified strong induction less often than the SVR. However, it correctly classified moderate induction more often than the SVR model. The raw classification matrix values are shown in Figure S2. Overall, SVR showed a stronger classification performance compared with the other two methods/models, with moderate inhibition being the most accurately predicted class across the three methods/models.

Classification performance of machine‐learning regressor outputs after conversion to categorical labels. Predicted log10 area under the curve (AUC) ratios from different machine‐learning models were used to classify interactions according to US Food and Drug Administration guidelines. The possible classes were weak, moderate, and strong inhibition (light, medium, or dark blue) or induction (light, medium, or dark orange). (a) The mean performance of the model across the different classes and folds was also compared (dotted). Data are presented as the mean macro F1 score (harmonic mean of precision and recall) across the five folds (n = 5 for each model), along with lines indicating the 95% confidence intervals. Classification matrices of (b) elastic net, (c) random forest regressor, and (d) support vector regressor outputs are shown. Numbers correspond to the percentage of interactions of a given observed class that were predicted by the model to be a certain class. The red diagonal box indicates the ideal cases where predicted classes matched the observed class, whereas the red arrows indicate cases where observed classes were predicted to be a different class more often than the correct class.

## Section: RESULTS › Strong correlation between predicted and observed log10 AUC ratios

Next, the performance of the regressor was investigated visually. Linear regression supported a strong correlation between the observed and predicted log10 AUC ratios (R 2 = 0.73; Figure 4a). The result of the Wilcoxon signed‐rank test indicated that the distributions of predictions and observations were not statistically significantly different (p = 0.51). The model predicted log10 AUC ratios between −1.5 and 1 effectively, but ratios >1 were poorly predicted because the predictions were outside the twofold error margin. Figure 4b shows the plot of residuals against observed log10 AUC ratios. There is a bias in the prediction in that both induction and inhibition effects are underpredicted.

Regression analysis of observed and support vector regressor predicted log10 area under the curve (AUC) ratios. (a) Predicted log10 AUC ratios after fivefold cross‐validation of a support vector regressor were plotted against the observed log10 AUC ratios of the corresponding drug–drug interaction studies. The dashed diagonal line indicates the perfect prediction line where predictions equal observations. The two gray lines on either side indicate the twofold error margins. Predictive performance was generally good (coefficient of determination = 0.73, root mean square error = 0.30, proportion of predictions less than twofold error = 0.78). (b) A plot is shown of the resulting residuals against the observed log10 AUC ratios.

## Section: RESULTS › CYP450 and f m data enabled the highest model performance

Because the SVR model overall performed the best (Figure 4), we assessed which features were most influential for driving the AUC ratio prediction. Subsets of the original features were grouped by the type of information the feature represented. The chemical features represented ECFP4 fingerprints and OESelma descriptors. The in vitro ADME features represented the non‐CYP descriptors of ADME derived from early in vitro assays, and the other feature set contained the CYP and f m descriptors. Each of the four feature sets was evaluated using fivefold cross‐validation with the SVR model. Individual feature importance was then evaluated using SHAP methodology, measured by the average impact on model output. Figure 5a shows that the RMSE scores were not significantly different across the different models. However, twofold error scores were significantly lower for the chemical (0.63) and in vitro ADME (0.66) models compared with the full model (0.78). In addition, the chemical model showed a significantly reduced R 2 (0.60) compared with the full model (0.73). Only the CYP and f m model showed no significant difference compared with the full model. Figure 5b shows the 20 features with the highest impact on model outputs using SHAP methodology. Notably, eight of these most important features were related to CYP and f m data (these were CYP activity at different timepoints and CYP3A5 f m with the perpetrator). In summary, the feature importance investigation demonstrated that CYP and f m data were the most influential for the predictive performance of the model.

Regression performance of support vector regressor using different feature sets. (a) Support vector regressor model performance is shown using either chemical; in vitro absorption, distribution, metabolism, and excretion; or CYP and f m/FM feature sets. Regression performance was compared using fivefold cross‐validation on the drug–drug interaction dataset. The performance metrics used were the RMSE (gray), R 2 (coefficient of determination; light blue), and twofold error (proportion of predicted log10 AUC ratios within twofold of the observed value; dark blue). Metric scores were reported as the mean score of the five folds along with lines indicating 95% confidence intervals. (b) SHAP values of the 20 most important features in the support vector regressor model are shown. CYP and FM indicate the cytochrome P450 enzyme activity‐time profiles and the fraction of substrate drug metabolized by each CYP enzyme with and without the perpetrator drug. AUC, area under the curve; C max, maximum concentration; CYP2C9, cytochrome P450 2C9; CYP3A4, cytochrome P450 3A4; CYP3A5, cytochrome P450 3A5; ECFP4, extended connectivity fingerprint with diameter 4; EM, extensive metabolizer; Exp, expected activity (simulation output); f m, fraction metabolized; fUmic, fraction unbound in microsomes IC50, half maximal inhibitory concentration; I.V., intravenous administration; Perp, perpetrator; PK, pharmacokinetic; PM, poor metabolizer; PO, oral administration; Pop, population type; RMSE, root mean square error; SHAP, Shaply Additive Explanations; Sub, substrate, T, timepoint

## Section: DISCUSSION

This study focused on predicting CYP‐mediated DDIs as a first step to predicting PK DDIs because CYPs mediate a significant proportion of PK DDIs. 4 This analysis described whether changes in drug exposure (specifically changes in CYP and f m data) attributed to PK DDIs can be predicted based on drug features. The findings of this study highlight that clinically significant exposure changes attributed to drug induction or inhibition can be predicted early in drug discovery using a regression‐based ML model. The ML models demonstrated high R 2, low RMSE, and a high proportion of predictions within twofold of the observed AUC ratios for DDIs of log10 AUC ratio <1 (all but the strongest cases of inhibition). The SVR model performed marginally better than the other approaches. Furthermore, predictive performance was retained using just CYP and f m data for PK DDIs mediated via time‐dependent inhibition or induction. This was demonstrated by the insignificant decrease when using CYP and f m features only compared with the full feature set for the R 2 (0.06 decrease), RMSE (0.03 increase), and twofold error (0.05 decrease). Therefore, the development of a model using this refined feature set may be prioritized because it is simpler and has reduced data collection requirements without the significant loss of performance associated with the other feature sets. However, the use of chemical and in vitro feature set models may also have utility when available data are limited because RMSE scores did not differ significantly between any of the feature subset models.

Of the 20 most important features in the model, eight described CYP activity at timepoints soon after administration (generally between 24 and 72 h after the first dose of the perpetrator, although the exact times represented by each timepoint depend on the specific conditions used for the SimCYP simulation). This indicates that CYP activity may not need to be measured for the entire duration of administration of a perpetrator to predict the effect on AUC, providing the possibility to explore using more limited time ranges for prediction to reduce data collection requirements. Two of the features also described the predicted maximum concentration and AUC of the substrate—this demonstrates the utility of using outputs of other ML models in feature generation.

The model's underprediction of stronger cases of inhibition could be linked to the absence of other features describing mechanisms driving stronger inhibition. An important mechanism not considered in this model is transporter‐mediated DDIs. For example, the hepatic uptake transporter Organic anion‐transporting polypeptide 1B1 and 1B3 has been found to mediate more than half of the observed strong clinical DDIs highlighted by the FDA. 30 In addition, drugs can inhibit transporters expressed on the basolateral surface of proximal tubular epithelial cells. 31 Because these transporters enable the hepatic and renal clearance of other drugs, their inhibition can lead to an increased AUC of substrate drugs. 32 Similarly, the underprediction of induction could be explained by unmodeled transporter effects. Some perpetrator drugs included in this dataset, such as rifampicin and carbamazepine, induce the gene expression of P‐glycoprotein (P‐gp), which leads to a decreased AUC for P‐gp substrates. 33 , 34 P‐gp is particularly relevant because 75% of CYP3A4/5 substrates are also substrates of P‐gp. 35 CYP3A4/5 metabolized the majority of interactions in the dataset used in this study and is the most common enzyme through which DDIs are mediated, 30 , 35 meaning P‐gp is likely involved in many DDIs in this study. Regardless, the model predicted the majority (~80%) of log10 AUC ratios below 1 within twofold, indicating that the current model is capable of effective predictions for cases that are not strong inhibition.

Imbalance in the distribution of samples may have led to poorer performance in some data ranges. F1 scores for the inhibitory and/or moderate DDIs were higher than induction and strong/weak DDIs, and there was no prediction of noninteractions. There were more inhibition DDIs than induction, more moderate than strong/weak, and noninteractions were the least common. Therefore, F1 scores for each class appear to be dependent on the sample size for each class. Previous work has shown that regression and classification ML model predictions are biased toward predicting values that are in the ranges most represented in the training data. 29 This may have contributed to the bias toward moderate predictions and the consequent underprediction of strong inhibition and induction. Therefore, the use of techniques that correct for class imbalance biases, such as synthetic minority oversampling technique, 36 may lead to improved performance in these other data ranges for both classification and regression. The use of deep‐learning algorithms could also enable improved regression performance using the set of features discussed in this study because deep learning improves DDI prediction. 9 , 37

There were limitations to this study. Although the potential for overfitting (and thus reduced generalizability) caused by the small sample size to feature ratio is controlled by the use of the nested cross‐validation, 38 the model needs to be tested on a dataset from a different source to confirm generalizability. Generalizability to clinical applications of DDI risk assessment may be limited by the feature space of the training DDI dataset. For example, ML models showed poor performance when making DDI predictions using chemical structures that the models were not trained on. 39

Future work could explore the application of PK DDI modeling in other stages of drug development. This study demonstrated the predictive power based on just CYP and f m features, and collecting these data for new drug candidates currently requires information from in vitro assays. Recent ML models can predict whether a drug will be metabolized by CYP3A4 using chemical features, 40 and deep learning has been used to classify which CYPs a drug may inhibit. 41 If this concept is developed to predict continuous values for f m and CYP activity‐time profiles, the necessary CYP and f m inputs for this model could be collected from in silico models rather than in vitro assays. This would enable the model to be used by project teams at the point of design. Conversely, ML modeling could also be used for regression‐based DDI modeling of already established drugs where clinical ADE data are already available because ADE data improve DDI prediction. 7 Also, the AUC label data used to train the model has uncertainty estimates from the SimCYP software used to generate it. The traditional ML architectures implemented in this study do not account for such uncertainties in the labels. However, future developments of this model could account for these by describing the label data as a probability distribution rather than as a single value. An example of this is the probabilistic random forest model, which accounts for uncertainty in feature or label data and outperformed the traditional random forest 30% of the time when used with noisy label data. 42

In conclusion, this study has shown that regression‐based ML can be used to predict changes in substrate AUC due to PK DDIs caused by time‐dependent inhibition/induction using features available early in the drug‐discovery process. Predictive algorithms as described here can inform early DDI risk for drug candidates.

## Section: AUTHOR CONTRIBUTIONS

J.G., M.M., R.A., and V.P.R. wrote the manuscript. A.M., B.W., F.M., J.G., M.M., and V.P.R. designed the research. J.G. and V.P.R. performed the research and analyzed the data.

## Section: FUNDING INFORMATION

No funding was received for this work.

## Section: CONFLICT OF INTEREST

Venkatesh Pilla Reddy, Marie Moullet, Anton Martinsson, and Filip Miljković are full‐time employees of and hold shares of AstraZeneca. Beth Williamson and Rosalinda H. Arends were employees of AstraZeneca at the time this research work was carried out.

## Section: Supporting information

Appendix S1

Click here for additional data file.

Appendix S2

Click here for additional data file.


---

# Evaluation of Docking Machine Learning and Molecular Dynamics Methodologies for DNA-Ligand Systems

- **Authors:** Tiago Alves de Oliveira, Lucas Rolim Medaglia, Eduardo Habib Bechelane Maia, Letícia Cristina Assis, Paulo Batista de Carvalho, Alisson Marques da Silva, Alex Gutterres Taranto
- **Issuer:** Pharmaceuticals (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2022-01-22
- **Language:** en
- **DOI:** 10.3390/ph15020132
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35215245/
- **Licence:** CC-BY

## Section: Abstract

DNA is a molecular target for the treatment of several diseases, including cancer, but there are few docking methodologies exploring the interactions between nucleic acids with DNA intercalating agents. Different docking methodologies, such as AutoDock Vina, DOCK 6, and Consensus, implemented into Molecular Architect (MolAr), were evaluated for their ability to analyze those interactions, considering visual inspection, redocking, and ROC curve. Ligands were refined by Parametric Method 7 (PM7), and ligands and decoys were docked into the minor DNA groove (PDB code: 1VZK). As a result, the area under the ROC curve (AUC-ROC) was 0.98, 0.88, and 0.99 for AutoDock Vina, DOCK 6, and Consensus methodologies, respectively. In addition, we proposed a machine learning model to determine the experimental ∆Tm value, which found a 0.84 R2 score. Finally, the selected ligands mono imidazole lexitropsin (42), netropsin (45), and N,N′-(1H-pyrrole-2,5-diyldi-4,1-phenylene)dibenzenecarboximidamide (51) were submitted to Molecular Dynamic Simulations (MD) through NAMD software to evaluate their equilibrium binding pose into the groove. In conclusion, the use of MolAr improves the docking results obtained with other methodologies, is a suitable methodology to use in the DNA system and was proven to be a valuable tool to estimate the ∆Tm experimental values of DNA intercalating agents.

## Section: 1. Introduction

Drugs interacting with DNA are among the most effective anticancer agents [1], but their low selectivity makes them highly toxic, a major drawback that calls for new studies and strategies to develop drugs selective towards DNA in cancerous cells [2].

One of the strategies for the development of new drugs is to identify small molecules through a systematic analysis of large groups of compounds with drug-like properties. An experimental approach commonly used is the high throughput screening (HTS), an automated process using robots for a systematic search. It is a costly technique due to the number of compounds to be acquired, the cost of purchase and operation of sophisticated robots [3], and experimental considerations such as stability and solubility of the compounds.

An alternative to HTS is the virtual high-throughput screening (vHTS or VS), an in silico method to test large groups of compounds, including databases available online containing millions of molecules. This technique also allows the design and virtual testing of theoretical compounds prior to synthesis or acquisition, reducing the cost and time required to find compounds with a high potential for further development [3,4]. VS methods use molecular docking to study the interaction between small molecules and their receptors [5], a method that has been evaluated for protein-ligand systems, and more recently have been used to model DNA-ligand complexes [6,7,8]. However, most docking programs use algorithms that are not suitable for modeling DNA due to its high charge density [1], prompting the need for a more adequate in silico model for nucleic acids.

Several studies have been done trying to develop a molecular docking software appropriate for DNA modeling. Ricci and Netz [9] developed a method to predict the binding mode of small molecules to DNA using AutoDock 4.0 [10], which used distinct DNA receptors in the most common conformations related to the most common binding poses to suppress the importance of the receptor’s flexibility in the algorithm.

Srivastava et al. [11] described a systematic computational analysis of 57 DNA ligands through four docking protocols, with the following root-mean-square deviation (RMSD) for the best ligands: GOLD [12] (1.24 Å), Glide [13] (1.23 Å), CDOCKER [14] (1.44 Å), and AutoDock [10] (1.57 Å). GOLD and GLIDE, with similar values, were shown to have a better performance and being the most suitable for modeling nucleic acid-ligand complexes. Molecular dynamics simulations showed that the DNA duplex skeleton underwent minor deviations in the complex, supporting docking protocols even though the receptor is kept rigid. However, the area under the ROC curve (AUC) of these methodologies was not evaluated. ROC curve is an important metric to check the capacity of methodology to distinguish false positive results. Fong and Wong [15] evaluated four scoring functions (AutoDock [10], ASP@GOLD [16], ChemScore@GOLD [17], and GoldScore@GOLD [12]) for DNA-ligand complexes, and the scoring functions reproduced the experimental crystallographic structure complexes. It is noteworthy that these previous studies improved their results by combining more than one scoring function.

Good RMSD results were obtained in previous studies, but the ranking capacity of these docking methods was not evaluated. Our study used Molecular Architecture (MolAr) [18] software to predict DNA-ligand poses. MolAr is a docking workflow that allows an integrated and automated virtual screening (VS) process, from protein preparation (homology modeling and protonation state) to virtual screening with different methods. MolAr is open access and free of charge (available at http://www.drugdiscovery.com.br, accessed on 20 May 2020), allowing users to perform all the docking steps in a unique interface with a simple and intuitive operation. It uses AutoDock Vina [19], DOCK 6 [20], and Consensus Virtual Screening (CVS) docking protocols. AutoDock Vina uses a hybrid scoring function that combines knowledge-based and empiric scoring function features. DOCK 6 offers physics-based energy score functions based on force fields and score functions (GRID and AMBER scores). CVS is a ranking normalized combination of the results of AutoDock Vina and DOCK 6, reducing the chance of false positive results [18]. Our results were evaluated for DNA-ligand model systems [11] through visual inspection of the RMSD and ROC curves. In addition, docking binding energy and descriptor values of ligands were used as a predictor to calculate the ∆Tm experimental values of 11 DNA ligands previously reported. Dynamic molecular simulations were also used to clarify their intermolecular interactions with DNA.

## Section: 2. Results

A visual inspection was performed on the 1VZK structure to identify the principal forces for molecular recognition. Figure 1 shows the 3D structure of the target 1VZK and a 2D diagram with its crystallographic ligand (D1B). The ligand is complexed into the minor groove of DNA (Figure 1a) through hydrogen bonds between amidinic moieties and the carbonyl oxygen of nitrogenous bases. Hydrophobic interactions can also be observed between the benzimidazole and aromatic and with nitrogenous bases (Figure 1b).

In general, redocking is the first evaluation method to be used in the docking process. This process shows (i) the correct elaboration of grid box parameters; (ii) the capacity of the docking method of reproducing the crystallographic binding pose; (iii) the acquisition of binding energies that can be used to rank the compounds. Usually, the redocking is evaluated by the RMSD value between the crystallographic binding pose and redocking results. The RMSD value between 1VZK and D1B ligand was 0.65 Å by AutoDock Vina, while the threshold value is 2.0 Å [20]. This result was better than previous docking methodologies, GOLD, GLIDE, CDOCKER, and AUTODOCK, which had values ranging from 1.23 Å to 1.57 Å [11].

## Section: 2. Results › 2.1. Molecular Docking

The docking performance was evaluated by calculating the AUC-ROC, EF values, and BedROC. AUC-ROC has been used to check if the docking method can distinguish false positives from true positives [21]. The AUC-ROC values for our test compounds were 0.98, 0.88, and 0.99 for AutoDock Vina, DOCK 6 (Amber Score), and CVS, respectively. Moreover, the enrichment factor (EF) value [22] reflects the ability of the docking calculations to find true positives throughout the background database compared to random selection. Thus, it indicates how good the set formed by the top x% ranked compounds is compared to a set of equal size selected randomly from the entire collection of compounds. EFs values are calculated utilizing a percentage of the data set. For example, EF5% represents the value obtained when 5% of the database was screened. The EF value is defined by:(1)EF %=actives %compounds %×total compoundstotal actives

Previous reports show CVS having the best EF values, compared to DOCK 6 and AutoDock Vina, which can be explained by the use of AutoDock Vina output as the input for DOCK 6. Consequently, AUC-ROC had values corroborated by the EF values; in other words, the EF validates AUC-ROC results, especially with the performance at EF 1%, showing the CVS method could distinguish 100% of molecules [18].

The BedROC [23] value was calculated to confirm these AUC-ROC and EF results. BedROC uses exponential weighting to give early rankings more weight than the latest rankings of active compounds. The BedROC values were 0.60, 0.52, and 0.83 for AutoDock Vina, DOCK 6 (Amber Score), and CVS, respectively. As in AUC-ROC and EF the values of CVS are better than AutoDock Vina and DOCK6 (Amber Score).

Finally, Machine Learning was used to develop a model to predict ∆Tm experimental values. ΔTm represents the change in the melting temperature of DNA upon drug binding, being directly correlated with the binding energy, and is a valuable tool to evaluate the docking results. Six algorithms of linear regression were implemented as follows: (i) Gradient Boosting Regressor [24]; (ii) Random Forest Regressor [25]; (iii) Linear Regressor [26]; (iv) Voting Regressor [27] between algorithms (i), (ii) and (iii), (v) Lasso [28] and (vi) Elastic Net [29]. The results are summarized in Table 1, with Mean Squared Error (MSE) and R2 score information. The Gradient Boosting Regressor shows the best result, with an R2 score of 0.84, and the worst is the Random Forest Regressor with an R2 score of 0.33.

## Section: 2. Results › 2.2. Molecular Dynamics

The five best CVS results and the original ligand were chosen for simulation and presented in Figure 2, where the conformation changes of each of these ligands during the MD simulation were analyzed.

The average energy for the total system, in Kcal/mol was −55,067.1, −55,473.3, −55,507.2, −55,137.1, −54,524.8, and −54,988.1 to ligands 51, 42, 45, 15, 43, and 44, respectively. The total energy graph shown in Figure 3 demonstrates an example of how the energy has a minimal variation. All energy graphs (available in the Supplementary Material, Figure S3) remained in equilibrium throughout the entire MD simulation.

The simulations were carried out in 50 ns to observe if there were significant conformational changes during the trajectory, with the results summarized in Figure 4. As can be observed, the ligands 42, 45, and 51 have the best results with an RMSD variation below 1Å. The original ligand and ligands 43 and 44 showed a major variation of approximately 2, 5, and 4 Å, respectively.

The intermolecular interactions of structures in equilibrium can be observed in Figure 5. As can be observed, the ligands 45 (5a), 51 (5b), 42 (5c), 15 (5d) were able to form hydrogen bonds and van der Waals interactions; whereas the ligands 44 (5e) and 43 (5f) carried out van der Waals interactions with nucleic acids.

Finally, to improve the analysis of RMSD values fluctuation, the heat map was plotted with the best ligands using VMD software. Figure 6 shows the heat map for ligands 45, 51, 45, and 15, Figure 6a–d, respectively. In general, the DNA structure is kept rigid during the MD trajectory with low variation. However, the highest fluctuation can be observed for all ligands reaching values ranging from 1.2 to 8.27.

## Section: 3. Discussion › 3.1. The Best Docking Methodologies to Study the DNA System

In this study, we use AUC-ROC, EF, and BedROC to evaluate the best docking methodology for DNA intercalating agents, comparing AutoDock Vina, DOCK6, and CVS. AutoDock Vina is an important tool to find the correct pose of ligand into the binding site [19]; however, the ranking among the ligands has not been carried out properly. In addition, the score function of AutoDock Vina does not consider the charges. On the other hand, the score function of DOCK 6 [20], Amber score, includes the AM1-BCC charges of the system. Consequently, the AM1-BCC charges have been determined for a start pose obtained from AutoDock Vina output, improving the accuracy of charge calculations.

AUC-ROC was used to check if the docking method can distinguish false positives from true positives. AUC values close to 1 suggest good discrimination between false and true positives, whereas values closer to 0.5 show a random process, and values higher than 0.7 represent a good distinguishing power [21].

EF indicates how good the set formed by the top x% ranked compounds is when compared to a set of equal size selected randomly from the entire collection of compounds. EF corroborates AUC-ROC [18], yielding even better results with CVS methodology. BedROC calculated values were 0.60, 0.52, and 0.83 for AutoDock Vina, DOCK 6 (Amber Score), and CVS, respectively, confirming that CVS is the best methodology.

The model of linear regression summarized in Table 1 shows the results of the implementation of six linear regressors. The Gradient Boosting Regressor shows the best result, with an R2 score of 0.84, and the worst is the Random Forest Regressor with an R2 score of 0.33. Gradient Boosting Regressor (GBR) is a generalization of boosting to arbitrary differentiable loss functions. GBR is an accurate and effective off-the-shelf procedure that can be used for both regression and classification problems in a variety of areas. Our GBR’s result is better than Srivastava’s studies [11], which used docking information from GOLD, GLIDE, CDOCKER, AUTODOCK 4, Average Information Content level 2, and chemical hardness. Thus, our Machine Learning model was able to estimate ∆Tm value with more accuracy than previous reports.

## Section: 3. Discussion › 3.2. Molecular Dynamics Simulations

MD simulations were performed to obtain information about the ligands’ interaction and stability into the DNA groove. According to the results of total energy, ligand 51 obtained the lower energy; whereas ligand 44 obtained the highest energy value. Figure 3 demonstrates the lower variation of the system in simulation.

Figure 4 shows the RMSD results of MS simulations. Ligands 15, 42, 45, and 51 showed a RMSD average variation below 1 Å. Both ligands 42 and 45 achieved the equilibrium state in the beginning of the process (Figure 4a,c). Noteworthy that ligand 51 (Figure 4b) showed a RMSD average value of 0.5 Å, indicating an absence of conformational changes for this inhibitor, suggesting a better molecular recognition between DNA and ligand in the DNA groove. In addition, 15 showed an RMSD average variation of 1 Å and stabilized in the DNA groove after 20 ns of simulation, as shown in Figure 4d. Visual inspection of the MD simulation path of 15 showed a decrease in the intermolecular interaction forces until 20 ns, followed by complete filling of the binding site during the rest of the process. 43 and 44 showed RMSD values higher than 2 Å, and it was observed that the 2-thienyl-1H-benzimidazole portion of 43 was more exposed to the solvent, resulting in a higher degree of freedom and consequent adoption of various conformations. 43 presented an RMSD value of 5.0 Å (Figure 4f), but reached equilibrium after 20 ns. 44 behaved similarly to 43, reaching equilibrium at 35 ns (Figure 4e). 44 had the quinolinium group outside the major DNA groove, obtaining an RMSD value of 3.5 Å.

Summarizing, all ligands achieved equilibrium within 50 ns of simulation, characterizing molecular recognition. Although compounds ligand 43 and ligand 44 presented good docking results at 15 and 28 nanoseconds of dynamic simulation, respectively, the structures presented conformational changes, resulting from parts of the ligands leaving the DNA groove suggesting hydrogen bonding with the solvent.

MD results corroborate the molecular docking results, with compounds 42, 45, and 51 interacting and accommodating themselves better in the smaller groove of DNA, presenting themselves as promising compounds for further studies as anticancer drugs. Compounds 43 and 44 can be considered weak DNA intercalators because, despite good docking results, they had a higher variation of RMSD values during MD.

The molecular interactions are depicted on Figure 5. 45, 51, 42, and 15 have hydrogen bonding acceptors and donors and were recognized by DNA through hydrogen bonds and van der Waals interactions (Figure 5a–d). For instance, Figure 4a shows the intermolecular interactions between compound 45 with DNA. This compound carried out hydrogen bonding with CytA:7, ThyA:9, AdeB:22 and hydrophobic interactions with ThyA:8, AdeA:10, and ThyB:20. Compound 51 (Figure 5b) was better recognized by the DNA minor groove by performing a higher number of intermolecular interactions, such as hydrogen bonding with AdeA:10, GuaA:11, and ThyB:20; and van der Waals interactions with ThyA:8, ThyA:9, AdeA:12, GuaB:17, CytB:19, and AdeB:22. Compound 42 (Figure 5c) is able to perform hydrogen bonding with CytA:6, CytA:7, ThyA:9, and AdeB:22; and hydrophobic interactions with ThyA:8, AdeA:10, CytB:19, and ThyB:20. It is noteworthy that the guanidinium groups of the 15 performed hydrogen bonds with CytA:6, CytA:7, CytB:18, AdeB:22, GuaB:23, beyond several hydrophobic interactions, such as GuaA:11, ThyB:20, and ThyB:21 (Figure 5d). These interactions with these nitrogenous bases are essential components for intercalation within the minor DNA groove, which indicates that this inhibitor remained well accommodated in the DNA during the dynamic’s simulation.

In contrast, both compounds 44 and 43 were not able to perform hydrogen bonding with DNA. 44 (Figure 5e) carried out hydrophobic interactions, for instance, with ThyA:9, AdeA:10, GuaA:11, AdeA:12, GuaA:13, GuaB:17, CytB:18, CytB:19, ThyB:20 and ThyB:21. Similarly, 43 performed hydrophobic interactions with ThyA:9, AdeA:10, GuaA:11, AdeA:12, GuaB:17, CytB:18, CytB:19 and ThyB:20, as shown in Figure 4f. These missing hydrogen bonding interactions can explain the higher RMSD fluctuations value during MD simulations, once this interaction has an important hole in the molecular recognition and stabilization of the ligand within the DNA groove. These findings highlight the structure-activity relationship of guanidinium groups in the development of antineoplastic compounds.

Through the analysis of RMSD plots using heat map graphs (Figure 6) it is possible to confirm the results generated by RMSD and interactions maps. 51 presented the smallest RMSD variation (max of 2.22 Å), best RMSD graphics and total energy. 42, 45, and 15 demonstrated RMSD variation of 2.52 Å, 3.31 Å, and 8.27 Å, respectively.

## Section: 4. Materials and Methods › 4.1. Molecular Docking

The three-dimensional structures of 57 ligands were constructed using Marvin Sketch [30] and 150 decoys were generated by the DUD-E platform [31]. The DNA molecular target was obtained from the Protein Data Bank (PDB-1VZK). These ligands and targets were described in a previous report [11] and are available in the Supplementary Material, Figure S1 [31]. The ligands were refined by Run_Mopac [32] software using Parametric Method 7 (PM7) [33] and Eigenvector Following routine [34].

The target was prepared by Chimera [35] by:removing water molecules and magnesium ions;adjusting the protonation state at pH 7.4;assigning charges using AMBERff14SB and AM1-BBC;minimizing the structure using 100 steps for steepest descent and 10 steps for conjugate gradient, each step measuring 0.02 Å.

Finally, all compounds were docked against the 1VZK molecular target at the minor groove position using a grid box with 20 × 20 × 26 Å and atomic coordinates centered to 14.44 Å, 20.57 Å, and 8.64 Å, for x, y, and z, respectively. In order to evaluate the best docking methods for DNA docking, three virtual screening simulations using MolAr were performed through AutoDock Vina, DOCK 6 (Amber Score), and CSV. All methodologies were double-checked by redocking, measurement of the area under the Receiver Characteristic Operator (ROC) curve (AUC-ROC), Enrichment Factor (EF), and Boltzmann-Enhanced Discrimination (BedROC). The redocking process consisted of removing the crystallographic ligand, with subsequent docking of the ligands into the same binding site.

In addition, we developed a machine learning model with the docking binding energy results and molecular descriptors of the molecules hereby tested to calculate the ∆Tm experimental values. The data frame was elaborated using the 57 compounds described previously, from which only 11 had their ∆Tm values calculated [11]. The descriptors were obtained using the Mordred library [36], a molecular descriptor calculator. Afterward, six Linear Regression algorithms were performed with the following descriptors: Molecular Weight, cLogP, cLogS, Total Surface Area, Relative Polar Surface Area, Polar Surface Area, AutoDock Vina with major groove, AutoDock Vina with minor groove, Ehomo, Ehomo−1, Elumo, Ehomo+1, DOCK 6 with Amber Score, Consensus with Grid and Amber Score, Structural Information Content level 1, Bond Information Content level 1, and chemical hardness [η=(Elumo−Ehomo)/2)].

## Section: 4. Materials and Methods › 4.2. Molecular Dynamics

The five best-docked ligands (according to MolAr Consensus with Amber score) were chosen for MD simulations among the crystallographic reference ligands (PDB-ID 1VZK) to characterize the molecular recognition between ligands and DNA. The ligands (PDB-IDs 1VZK, 1LEY, 1ZPH, 1ZPI, 261D, and 2GYX) are shown in the Supplementary Material, Figure S2. All ligands and the energy values for all configurations are presented in the Supplementary Material, respectively, in Figure S1 and Table S1.

The ligand-DNA complexes were inserted into a 74.15 × 52.33 × 55.58 Å simulation box and solvated with TIP3P model water molecules [37]. Sodium chloride ions were added to neutralize the system charge. Each system was energetically minimized with 5000 cycles using the Conjugate Gradient algorithm [38]. The nucleic acid atoms had position restraints with an exponent of energy function of 2 and scaling of 1.0 applied to them during the first 4000 cycles and no restraints during the last 1000 cycles. After the energy minimization, the systems were heated to 310 K during a 30 ps equilibration conducted under an isothermal-isochoric ensemble (NVT), followed by a 500 ps simulation under an isothermal-isobaric ensemble (NPT) using the Langevin piston method [39] to maintain the total pressure to an average of 1 bar. The final production had a total of 50 ns. Water stretching and bending motions were constrained by the SETTLE algorithm [40]. Electrostatic interactions were treated via the Particle-Mesh Ewald method [41,42] with a 12 Å cutoff radius. All simulations were performed using the CHARMM36 [41,43,44] force field implemented into NAMD software [33], version 2.13. Analysis was performed using VMD, version 1.9.3 [45].

## Section: 5. Conclusions

Even though DOCK 6 and AutoDock Vina showed different results, the overall result was improved when they were combined and subjected to the MolAr CVS approach. AUC-ROC, BedROC, and EF values showed the combination was able to generate more reliable results and a better prediction of the ligand conformation. MD is a critical methodology to confirm the interactions between ligands and nucleic acids, showing that MolAr CVS virtual screening can rank ligands in the DNA intercalating compounds. It is noteworthy that CVS has a low computational cost when compared with MD simulations.

In this study, two different approaches were carried out to predict the activity of compounds capable of binding to the minor groove of DNA. The first approach, structure-based drug design, was carried out to rank compounds for their ability to dock with the 1VZK molecular target at the minor groove position using docking and MD simulations. The second approach, ligand-based drug design through Machine Learning methods, ranked the six selected structures based on their binding energy. These methods were able to properly describe the intermolecular interactions between intercalating agents and DNA and build a machine learning model able to predict the ∆Tm experimental values. The application of docking machine learning and molecular dynamics methodologies suggests compounds 51, 42, and 45 as leads for the development of improved anticancer compounds.


---

# Evaluation of the Clinical, Technical, and Financial Aspects of Cost-Effectiveness Analysis of Artificial Intelligence in Medicine: Scoping Review and Framework of Analysis

- **Authors:** Jesus Gomez Rossi, Ben Feldberg, Joachim Krois, Falk Schwendicke
- **Issuer:** JMIR medical informatics
- **Type:** Scientific article
- **Published:** 2022-08-12
- **Language:** en
- **DOI:** 10.2196/33703
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35969458/
- **Licence:** CC-BY

## Section: Abstract

Cost-effectiveness analysis of artificial intelligence (AI) in medicine demands consideration of clinical, technical, and economic aspects to generate impactful research of a novel and highly versatile technology. We aimed to systematically scope existing literature on the cost-effectiveness of AI and to extract and summarize clinical, technical, and economic dimensions required for a comprehensive assessment. A scoping literature review was conducted to map medical, technical, and economic aspects considered in studies on the cost-effectiveness of medical AI. Based on these, a framework for health policy analysis was developed. Among 4820 eligible studies, 13 met the inclusion criteria for our review. Internal medicine and emergency medicine were the clinical disciplines most frequently analyzed. Most of the studies included were from the United States (5/13, 39%), assessed solutions requiring market access (9/13, 69%), and proposed optimization of direct resources as the most frequent value proposition (7/13, 53%). On the other hand, technical aspects were not uniformly disclosed in the studies we analyzed. A minority of articles explicitly stated the payment mechanism assumed (5/13, 38%), while it remained unspecified in the majority (8/13, 62%) of studies. Current studies on the cost-effectiveness of AI do not allow to determine if the investigated AI solutions are clinically, technically, and economically viable. Further research and improved reporting on these dimensions seem relevant to recommend and assess potential use cases for this technology.


---

# Explainable medical imaging AI needs human-centered design: guidelines and evidence from a systematic review

- **Authors:** Haomin Chen, Catalina Gomez, Chien-Ming Huang, Mathias Unberath
- **Issuer:** NPJ digital medicine
- **Type:** Scientific article
- **Published:** 2022-10-19
- **Language:** en
- **DOI:** 10.1038/s41746-022-00699-2
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36261476/
- **Licence:** CC-BY

## Page 1 (Section: Explainable medical imaging AI needs human-centered design: guidelines and evidence from a systematic review)

REVIEW ARTICLE
OPEN
Explainable medical imaging AI needs human-centered design:
guidelines and evidence from a systematic review
Haomin Chen
1,2, Catalina Gomez1,2, Chien-Ming Huang
1 and Mathias Unberath
1✉
Transparency in Machine Learning (ML), often also referred to as interpretability or explainability, attempts to reveal the working
mechanisms of complex models. From a human-centered design perspective, transparency is not a property of the ML model but
an affordance, i.e., a relationship between algorithm and users. Thus, prototyping and user evaluations are critical to attaining
solutions that afford transparency. Following human-centered design principles in highly specialized and high stakes domains, such
as medical image analysis, is challenging due to the limited access to end users and the knowledge imbalance between those users
and ML designers. To investigate the state of transparent ML in medical image analysis, we conducted a systematic review of the
literature from 2012 to 2021 in PubMed, EMBASE, and Compendex databases. We identiﬁed 2508 records and 68 articles met the
inclusion criteria. Current techniques in transparent ML are dominated by computational feasibility and barely consider end users,
e.g. clinical stakeholders. Despite the different roles and knowledge of ML developers and end users, no study reported formative
user research to inform the design and development of transparent ML models. Only a few studies validated transparency claims
through empirical user evaluations. These shortcomings put contemporary research on transparent ML at risk of being
incomprehensible to users, and thus, clinically irrelevant. To alleviate these shortcomings in forthcoming research, we introduce the
INTRPRT guideline, a design directive for transparent ML systems in medical image analysis. The INTRPRT guideline suggests human-
centered design principles, recommending formative user research as the ﬁrst step to understand user needs and domain
requirements. Following these guidelines increases the likelihood that the algorithms afford transparency and enable stakeholders
to capitalize on the beneﬁts of transparent ML.
npj Digital Medicine (2022) 5:156 ; https://doi.org/10.1038/s41746-022-00699-2
INTRODUCTION
There have been considerable research thrusts to develop
Machine Learning (ML) models in the healthcare domain that
assist clinical stakeholders1. However, translating these ML models
from the bench to the bedside to support clinical stakeholders
during routine care brings substantial challenges, among other
reasons, because of the high stakes involved in most decisions
that impact human lives. When stakeholders interact with ML
tools to reach decisions, they may be persuaded to follow ML’s
recommendations that may be incorrect or promote unintended
biases against vulnerable populations, all of which can have
dreadful consequences2. These circumstances motivate the need
for trustworthy ML systems in healthcare and have sparked efforts
to specify the different requirements that ML algorithms should
fulﬁll. Most of these recent efforts focus on achieving a certain on-
task performance requirement but neglect that for assisted
decision making not ML system performance alone, but human-
ML team performance is the most pertinent to patient outcome.
How to achieve adequate human-machine teaming performance,
however, is debated. While some argue that rigorous algorithmic
validation, e.g., similar to the evaluation of drugs, tests, or devices,
demonstrates safe and reliable operation and may thus be
sufﬁcient for successful human-machine teaming3,4, others reason
that transparency in an ML model, e.g., by revealing its working
mechanisms and presenting a proper interface, is necessary to
invoke user trust and achieve the desired human-machine
teaming performance5–7. The growing interest and convergence
of recent works on the importance and need of transparency have
stressed that not addressing the opacity of ML techniques might
hinder their adoption of in healthcare, limiting the potential
positive impacts5,8–12. The inability to make the decision making
process transparent might affect the misuse and disuse of ML
models in the clinical domain, as the utility of the model might be
limited if it does not reveal the reasoning process, limitations, and
biases9. We believe that this dichotomy is artiﬁcial in that, ﬁrst,
rigorous validation and transparency are not mutually exclusive,
and second, both approaches augment an ML model with
additional information in hopes to justify (in other words, make
transparent) the recommendation’s validity which is hypothesized
to achieve certain human-factors engineering goals such as
understandability, reliability, trust and etc. However, as we will
highlight
in
detail
through
a
systematic
review,
current
approaches that aim at advancing human factors goals of ML
systems rely on developers’ intuition rather than considering
whether these mechanisms affect users’ experience with the
system and their ability to act on ML model’s outputs.
Designing ML algorithms that are transparent is fundamentally
different from merely designing ML algorithms. The desire for
transparency adds a layer of complexity that is not necessarily
computational. Rather, it involves human factors, namely the users
to whom the ML algorithm should be transparent. As a
consequence, transparency of an algorithm is not a property of
the algorithm but a relationship between the transparent ML
algorithm and the user processing the information. Such relation-
ship can be understood as an affordance, a concept that is
commonly employed when designing effective Human-Computer
Interactions (HCIs)13, and we argue that transparency in ML
1Department of Computer Science, Johns Hopkins University, Baltimore, MD, USA. 2These authors contributed equally: Haomin Chen, Catalina Gomez. ✉email: unberath@jhu.edu
www.nature.com/npjdigitalmed
Published in partnership with Seoul National University Bundang Hospital
1234567890():,;

## Page 2 (Section: Explainable medical imaging AI needs human-centered design: guidelines and evidence from a systematic review)

algorithms
should
be
viewed
as
such.
There
are
several
consequences from this deﬁnition:
●
Developing transparent ML algorithms is not purely computa-
tional.
●
Speciﬁc design choices on the mechanisms to achieve
explanations or interpretations may be suitable for one user
group, but not for another.
●
Creating transparent ML systems without prior groundwork to
establish that it indeed affords transparency may result in
misspent effort.
Given the user- and context-dependent nature of transparency,
it is essential to understand the target audience and to validate
design choices through iterative empirical user studies to ensure
that design choices of transparent models are grounded in a deep
understanding of the target users and their context. In addition, to
maintain a user-centered approach to design from the early
stages, rapid prototyping with users provides feedback on the
current, low- to high-ﬁdelity embodiment of the system that is
going to be built eventually. Involving users early by exposing
them to low-ﬁdelity prototypes that mimic ﬁnal system behavior
allows designers to explore multiple alternatives before commit-
ting to one pre-determined approach that may not be under-
standable nor of interest to end users.
However, following a human-centered design approach to build
transparent ML systems for highly specialized and high stakes
domains, such as healthcare, is challenging. The barriers are
diverse and include: (1) the high knowledge mismatch between
ML developers and the varied stakeholders in medicine, including
providers, administrators, or patients; (2) availability restrictions or
ethical concerns that limit accessibility of potential target users for
iterated empirical tests in simulated setups for formative research
or validation;
(3) challenges
inherent
to clinical
problems,
including the complex nature of medical data (e.g., unstructured
or high dimensional) and decision making tasks from multiple
data sources; and last but not least, (4) the lack of ML designers’
training in design thinking and human factors engineering.
Starting from the considerations around designing and validat-
ing transparent ML for healthcare presented above, we investigate
the current state of transparent ML in medical image analysis, a
trailblazing application area for ML in healthcare due to the
abundance and structure of data. Through a systematic review
based on these aspects, we ﬁrst identify major shortcomings in
the design and validation processes of developing transparent ML
models. These deﬁciencies include the absence of formative user
research, the lack of empirical user studies, and in general, the
omission of considering ML transparency as contingent on the
targeted users and contexts. Together, these shortcomings of
contemporary practices in transparent ML development put the
resulting solutions at substantial risk of being unintelligible to the
target users, and consequently, irrelevant.
This paper aims to encourage model designers to actively
consider and work closely with the end users during the design,
construction, and validation of ML models for medical imaging
problems. Acknowledging the barriers to widespread adoption of
human-centered design techniques to develop transparent ML in
healthcare and grounded in our systematic review of the
literature, we further propose the INTRPRT guideline to help model
designers for developing transparent ML for medical image
analysis step by step. Figure 1 summarizes our guideline within
a human-centered design process. The guideline aims at high-
lighting the need to ground and justify design choices in a solid
understanding of the users and their context when adding
transparency or other human factors-based goals to ML systems
for medical image analysis. By raising awareness of the user- and
context-dependent nature of transparency, designers should
consider a trade-off between efforts to (1) better ground their
approaches on user needs and domain requirements and (2)
commit to technological development and validation of possibly
transparent systems. In this way, the guideline may increase the
likelihood for algorithms that advance to the technological
development stage to afford transparency, because they are well
grounded and justiﬁed in user and context understanding. This
may mitigate misspent efforts in developing complex systems
without prior formative user research, and help designers make
accurate claims about transparency and other human factors
engineering goals when building and validating the model. To the
best of our knowledge, we provide the ﬁrst guidelines for models
that afford transparency and involve end users in the design
process for medical image analysis.
Fig. 1
Schematic representation of the INTRPRT guideline within the main stages of a human-centered design process. The blue boxes
demonstrate the process from understanding end users and their context to the validation of the developed system, which ultimately might
result in large scale deployment. The guidelines are summarized below and are located within the design phases based on the aspects
pertinent to each one and the corresponding themes of each guideline are listed on the left. Opportunities for iterative design are illustrated
with the dashed arrows.
H. Chen et al.
2
npj Digital Medicine (2022) 156 
Published in partnership with Seoul National University Bundang Hospital
1234567890():,;

## Page 3 (Section: An overview of current trends in transparent machine learning development)

AN OVERVIEW OF CURRENT TRENDS IN TRANSPARENT
MACHINE LEARNING DEVELOPMENT
Compared to developing generic ML algorithms, designing and
validating transparent ML algorithms in medical imaging tasks
requires consideration of human factors and clinical context. We
group these additional considerations into six themes according
to the initial review, iteratively deﬁned prior to data extraction and
abbreviated to INTRPRT; the themes are incorporation (IN),
interpretability (IN), target (T), reporting (R), prior (PR), and task
(T). Incorporation refers to the communication and cooperation
between designers and end users before and during the
construction of the transparent model. Formative user research
is one possible strategy that can help designers to understand end
users’
needs
and
background
knowledge14,15,
but
other
approaches exist16. Interpretability considers the technicalities of
algorithmic realization of a transparent ML system. Figure 2
provides illustrative examples of some of these techniques. Target
determines the end users of the transparent ML algorithms.
Reporting summarizes all aspects pertaining to the validation of
transparent algorithms. This includes task performance evaluation
as well as the assessment of technical correctness and human
factors of the proposed transparency technique (e.g., intelligibility
of the model output, trust, or reliability). Prior refers to previously
published, otherwise public, or empirically established sources of
information about target users and their context. This prior
evidence can be used to conceptualize and justify design choices
around achieving transparency. Finally, task speciﬁes the con-
sidered medical image analysis task, such as prediction, segmen-
tation, or super resolution, and thus determines the clinical
requirements on performance. We emphasize that these themes
should not be considered in isolation because they interact with
and are relevant to each other. For example, technical feasibility of
innovative transparency mechanisms based on the desired task
may inﬂuence both, the priors that will be considered during
development as well as the incorporation of target users to
identify and validate alternatives.
Having identiﬁed and reﬁned the themes iteratively after an
initial review, we structured the systematic review according to
the six themes. We identify and summarize dominant trends
among the 68 included studies aiming to design transparent ML
for medical image analysis. In the incorporation theme, cross-
disciplinary study teams may constitute a ﬁrst step towards
incorporating target users during ML design, however, only 33 of
the included articles were authored by multidisciplinary clinician-
engineering teams. More importantly, no paper introduced
formative user research to understand user needs and contextual
considerations before model construction, which is reﬂected in
the lack of justifying the prior theme. Around half of the selected
articles (n = 28) chose clinical priors and guidelines as an
inspiration for transparent systems. In the target theme, we found
that only 30 of the included articles speciﬁed end users, and all of
these papers were aimed at clinical care providers, a stark
imbalance considering the variety of stakeholders. In the task
theme, prediction tasks were by far the most common application
for transparent ML algorithm design (57/68). In the Interpretability
theme,
methods
relying
on
clinical
guidelines
resulted
in
algorithms that adopted multiple sub-steps of a clinical guideline
to build the model and generate outcomes, while methods that
were based on computer vision techniques for transparency most
commonly relied on post-hoc explanations. In the Reporting
theme, the methods used for assessing transparency varied with
the problem formulation and transparency design, and included
human perception, qualitative visualizations, quantitative metrics,
and empirical user studies; we note that an evaluation with end
users was highly uncommon (only 3 of the 68 included studies).
However, no paper considered the six themes comprehensively.
More importantly, there is no evidence that any papers considered
the dependency and interaction between different themes. The
reviewed literature further supports that one guideline consider-
ing all themes and the interaction between them is highly desired
in the medical image analysis community to construct transparent
ML models following human-centered design practices.
INTRPRT GUIDELINE
We distilled a set of guidelines for designing transparent ML
models according to the interaction and relevancy among the six
themes, which is proposed here as INTRPRT guideline. The INTRPRT
guideline provides suggestions for designing and validating
transparent ML systems in healthcare in hopes to increase the
likelihood that the resulting algorithms indeed afford transpar-
ency for the designated end users. The guidelines also address the
challenges of following a human-centered design approach in the
healthcare domain, propose potential solutions, and apply to
different kinds of transparency ML algorithms. To further illustrate
Fig. 2
Illustrative examples of different techniques used in transparent ML systems for classiﬁcation and segmentation tasks from the
systematic review. Within each task, a non-interpretable model generates the task outcome from the input image (top). The use of clinical
knowledge or computer vision information as priors attempts to add transparency in the outcome generation process (bottom). Images
retrieved from the ORIGA127 and BraTS2020 datasets128.
H. Chen et al.
3
Published in partnership with Seoul National University Bundang Hospital
npj Digital Medicine (2022) 156

## Page 4 (Section: Guideline 1: specify the clinical scenario, constraints, requirements, and end users)

the INTRPRT guideline, we introduce a case study (see Supple-
mentary information A).
Guideline 1: specify the clinical scenario, constraints,
requirements, and end users
The ﬁrst step to designing any ML algorithm for healthcare is to
well deﬁne the clinical scenario, the constraints the solution will
have to abide by, and all hard or soft requirements the algorithm
needs to meet for the clinical task to be addressed adequately (cf.
Fig. 3). For ML algorithms that do not attempt to be transparent, it
is essential but sufﬁcient to assess whether the envisioned ML
algorithm design will satisfy the clinical constraints and require-
ments, e.g., an acceptable classiﬁcation accuracy in allowable
processing time. In addition, when designing transparent ML
algorithms it is equally critical to determine and characterize the
end users. It is of particular importance to investigate end user
characteristics speciﬁcally in the clinical context of the chosen
task. This is because, depending on the task, stakeholders have
varied interest, prior knowledge, responsibilities, and require-
ments17. Deep understanding of the role target users play in the
chosen clinical task and their unique needs is critical in
determining how to achieve transparency (Guideline 2).
Guideline 2: justify the choice of transparency and determine
the level of evidence
There exists a wide gap in domain expertise and contextualization
between target users and ML model designers in most use cases
in healthcare. Furthermore, there are multiple “transparency”
techniques
and
choices,
such
as
the
transparent
working
mechanism or user-centered interactions in practice. Simply
selecting a “transparency” technique, without incorporating and
consulting target users puts the resulting ML models at risk of not
achieving the desired transparency. The human-centered design
approach addresses this challenge through iterative empirical
studies that over time guide the development and reﬁnement of
the technical approach such that, upon completion, the design
choices are well justiﬁed by empirical target user feedback. This
approach may not always be feasible in healthcare due to
accessibility and availability barriers of target users. To address this
limitation while still enabling technological progress in transpar-
ent ML, we introduce four distinct levels of evidence. These levels
allow designers to classify the level of conﬁdence one may have
that the speciﬁc design choices will indeed result in a model that
affords transparency.
The levels of evidence are based on increasingly thorough
approaches to understand the chosen end users in context of the
envisioned task:
●
Level 0: No evidence. No dedicated investigations about the
end users are performed to develop transparent ML systems.
●
Level
1:
One-way
evidence.
Formative
user
research
techniques, such as surveys and diary studies, are only
performed once without further feedback from end users
about the ﬁndings extracted from the research phase,
resulting in one-way evidence. Such user research suffers
risks of potential bias in concluding about justiﬁcation of
transparency because there is no opportunity for dialog, i.e.,
designers may ask irrelevant questions or target users may
provide non-insightful, potentially biased responses.
●
Level 2: Public evidence. Public evidence refers to information
about target user knowledge, preference, or behavior that is
public domain and vetted in a sensible way. Public evidence
includes clinical best practice guidelines, Delphi consensus
reports, peer-reviewed empirical studies of closely related
approaches in large cohorts, or well documented socio-
behavioral phenomena.
●
Level 3: Iteratively developed evidence. Iteratively developed
evidence is transparency evidence that is iteratively reﬁned
through user feedback where designers and end users
communicate with each other throughout method develop-
ment. The purpose of iteratively validating and reﬁning the
current transparency mechanism is to identify any potential
bias in the assumptions that motivate the transparency
technique
while
ensuring
that
it
is
understandable
to
end users.
Being actively cognizant of the level of evidence that supports
the
development
enables
trading
off
development
efforts
between ML method development vs. gathering richer evidence
in support of the intended developments.
Guideline 3: clarify how the model follows the justiﬁcation of
transparency
This guideline is designed to ensure that the transparency
technique used in the ML model is indeed consistent with the
assumptions made during its justiﬁcation. While complying with
this guideline is trivial if the model is developed in a human-
centered design approach (Level 3: Iteratively developed evi-
dence), in all other cases designers should be explicit about the
intellectual proximity of the developed technical approach to the
motivating
evidence.
To
this
end,
after
specifying
which
components of the ML model require transparency for users to
capitalize on the intended beneﬁts, it is desirable for the method
to be as simple as possible so that it can be easily derived from
and linked to the justiﬁcation of transparency. Once conﬁrmed
that the
envisioned model
is indeed
consistent
with
the
justiﬁcation, computational development of the model, including
training, reﬁnement, and validation, begins.
Guideline 4: determine how to communicate with end users
In addition to content (Guidelines 1, 2, and 3), seemingly
peripheral factors on the presentation of information may play a
Fig. 3
Relationships of components in ML systems. a Shows the relationship between the clinical scenario and requirements in non-
transparent ML systems, where the system may not be human-facing, and as such, meeting quantitative performance requirements is
sufﬁcient. b Shows the relationship between the clinical scenario, requirements, and end users in transparent ML systems, as they arise in a
human-centered system that seeks to enable users to accomplish a certain task.
H. Chen et al.
4
npj Digital Medicine (2022) 156 
Published in partnership with Seoul National University Bundang Hospital

## Page 5 (Section: Guideline 5: report task performance of the ML systems)

disproportionate role in the perception of transparency. It is well
known that factors like format (e.g., text, images, plots)18, channel
(e.g. graphical interface)19, and interactivity (e.g. whether users
can provide feedback or reﬁne model outputs) can drastically
affect users’ experience and performance20–22, and therefore,
must be aligned with the goal of transparent system develop-
ment. Clearly, the selection of presentation mode should be
incorporated early and supported by some degree of evidence,
that emerges naturally when following human-centered design
principles
but
requires
justiﬁcation
if
not
(as
posited
for
transparency in Guideline 2). Ultimately, users’ experience with
the systems plays an important role in their willingness to adopt it
in a real setup21,23.
Guideline 5: report task performance of the ML systems
Similar to ordinary ML models, the transparent system must be
evaluated quantitatively using appropriate metrics that well reﬂect
the desired performance. In addition, the data used to evaluate
the algorithm and its relevance regarding the clinical target task
must be speciﬁed. Metrics and evaluation protocols should be
selected to well determine the model’s abilities in regard to the
clinical requirements speciﬁed per Guideline 1. Reporting task
performance of the algorithm in standalone deployment is
important as a baseline for empirical studies in which users may
interact and collaborate with the system to complete a task, and
team performance (human + ML system) metrics can be
measured. Such comparisons are relevant to the goal of improving
team performance when integrating intelligent systems to assist
humans in complex tasks23,24.
Guideline 6: assess correctness and human factors of system
transparency
In addition to task performance, transparent ML systems must be
evaluated with respect to their transparency claims. This validation
is generally necessary even for Level 3 (iteratively developed
evidence)
justiﬁed
transparency
mechanisms,
because
user
studies
in
the
design
phase
commonly
rely
on
mock-up
prototypes of the envisioned system, and therefore, may have
different modes of failure than the ﬁnal ML system. Within this
guideline, we distinguish two types of evaluation: (1) Validating
the correctness of the transparency technique, which objectively
assesses whether the information supplied to achieve transpar-
ency is in agreement with the justiﬁcation. Achieving correctness
is particularly important for systems that rely on post-hoc
explanations, since explanations may rely on a second model
that is distinct from the ML algorithm generating recommenda-
tions. (2) Validating the effectiveness of transparency in a human-
centered approach, to demonstrate that the transparent ML
system applied to relevant data samples and in cooperation with
target users achieves the desired goals. This empirical evaluation
determines the efﬁcacy of human factors engineering. The
dimensions that are often considered include users’ trust18,
reliance, satisfaction22, mental model formation25, and system
acceptance. Reporting of these user studies should include details
of the experimental design, participant sample, and techniques to
analyze the results.
Transparency of ML algorithms for medical image analysis is
commonly motivated by the desire of automating complex tasks
while retaining a clear interface for human interaction, e.g., to
improve
trust,
avoid
over-reliance,
or
increase
acceptance.
However, achieving these design goals through transparency
requires the development of transparent ML algorithms that are
intelligible by the envisioned end users. In design thinking,
aligning technological developments with user needs is accom-
plished through user involvement in the design process and
iterative user testing, which is largely infeasible in healthcare due
to varied barriers to end user involvement. We propose a design
and evaluation framework where ML designers actively consider
end
users’
needs,
knowledge,
and
requirements,
allowing
designers to classify the reliability of their understanding of end
user needs using four levels of evidence. Explicitly thinking about
the conﬁdence one may have in the assumptions about end users
that drive transparent ML system development may mitigate the
risks of developing solutions that are unintelligible to the target
users, and therefore, neither achieve the desired human factors
engineering goals nor beneﬁt clinical practice. Similarly, quantify-
ing
the
level
of
evidence
currently
available
to
motivate
transparency claims then allows developers to trade-off resources
between technical ML developments and additional formative
research of their target users to ensure that the resulting systems
are ﬁt to meet the requirements of the clinical task but foremost
the target users.
RESULTS AND DISCUSSION
We discuss the INTRPRT guideline in the context of the key
observations from different themes of our systematic review to
identify opportunities to improve the design of transparent ML
systems for medical image analysis. Each discussion point focuses
on one or more themes that we introduced before. Furthermore,
the second last subsection presents successful examples of ML
systems designed with clinical end users and the last subsection
also includes the comparison of our guideline and systematic
review with existing literature.
Importance of formative user research and empirical user
testing
Both formative user research (theme incorporation and prior) and
empirical user testing (theme reporting) are critical to ensure that
solutions meet user needs (theme target). On the one hand,
formative user research helps designers navigate and understand
end users’ domain practice and needs. On the other hand,
empirical user testing assesses whether the designed algorithm
indeed achieves the human factors engineering goals, such as
affording transparency, promoting trust, or avoiding over-reliance.
Additionally, early user involvement in the design process using
prototypes of increasing ﬁdelity provides opportunities to review
and iterate over design choices. From our systematic review of the
literature presented in the “Detailed Analysis of Findings during
Systematic Review” section, we ﬁnd that although most con-
temporary studies on transparent ML formulate human factor
engineering goals, no study reported formative user research or
empirical testing to inform and validate design choices. We must
conclude that contemporary research efforts in medical image
analysis have disproportionately prioritized the technological
development of algorithmic solutions that alter or augment the
predictions of complex ML systems with the implicit—though
unfortunately often explicit—assumption that those changes
would achieve transparency. However, because of the substantial
knowledge imbalance between ML engineers and target users
among other reasons detailed above, it is unlikely that, without
formative user research or empirical tests, those systems truly
afford transparency or achieve the promised human factors
engineering
goals.
While
demonstrating
the
computational
feasibility of advanced transparency techniques is certainly of
interest, grounding the need for these techniques in solid
understanding of the target users should be the ﬁrst step for
most, if not all, such developments.
General assessment of transparency
In addition to user involvement or formative research during the
design phase (theme incorporation and prior), upon completion of
ML development, system transparency needs to be empirically
validated (theme reporting). During the literature review, we
H. Chen et al.
5
Published in partnership with Seoul National University Bundang Hospital
npj Digital Medicine (2022) 156

## Page 6 (Section: Transparent machine learning systems for diverse stakeholders)

observed that hardly any study reported quantitative empirical
user evaluations as part of ﬁnal method validation, and many of
the included articles limited analysis of transparency goals to
qualitative analysis by presenting a limited number of illustrative
examples, e.g., pixel-attribution visualizations. While such analysis
may suggest ﬁdelity of the transparency design to the cause of the
prediction in those few select samples, its utility beyond is unclear.
In cases where no empirical user evaluation is conducted, neither
during conceptualization nor during development, claims around
system transparency or human factors are at high risk of being
optimistic and should be avoided.
Transparent machine learning systems for diverse
stakeholders
The purpose of adding transparency to an ML model varies across
end users and their context, which we covered in the target
theme. The current literature on transparent ML for medical image
analysis focuses heavily on care providers. In fact, all of the
included articles that explicitly specify end users targeted
clinicians, such as radiologists, pathologists, and physicians.
However, clear opportunities for transparent ML systems exist
for other clinical stakeholders, such as other care team members
including nurses or techs, healthcare administrators, insurance
providers, or patients. Designing transparent ML systems for these
stakeholder groups will likely require different approaches, both
technological as well in regards to human factors engineering,
because these target users are likely to exhibit distinct needs,
requirements, prior knowledge, and expectations. In light of
recent articles that question the utility of transparency in high
stakes clinical decision making tasks3,26, driving transparent ML
development
using
a
“human
factors
ﬁrst”
mindset
while
expanding target user considerations to more diverse stakeholder
groups may increase the likelihood of transparent ML having an
impact on some aspects of the healthcare system.
Transparency for tasks with and without human baseline
Clearly specifying and formulating the medical task that the ML
system solves is fundamental to determine the assistance that it
can provide to clinical practice. Along with the disproportionate
consideration of clinicians as end users goes a disproportionate
focus on clinical tasks that are routinely performed in current
clinical practice (n = 60/68) by those target users. One motivation
for investigating transparency in such tasks is the existence of
clear and systematic clinical workﬂows and guidelines, e.g., the
Breast Imaging Reporting and Data System (BI-RADS) system for
mammography, the AO/OTA Tile grading of pelvic fractures, or
other easily intelligible covariates associated with outcomes. The
availability of such human-deﬁned baselines that are already used
for clinical decision making provides immediate Level 2 evidence
of transparency for ML systems attempting their replication. In
addition, it facilitates data collection and annotation, because
intermediate outputs that may be required to build such system
are known a priori. Conversely, justifying speciﬁc attempts at
achieving transparency is much more complicated for tasks that
do not readily have human-based baselines or clinical best
practice guidelines. Some such tasks may already be performed in
clinical practice, such as segmentation or super-resolution, the
interpretation of which may be ambiguous and result in high
variability among observers27. Other tasks may be beyond the
current human understanding of the underlying mechanisms that
enable ML-based prediction, e.g., ethnicity prediction from chest
X-ray28 or various tasks in digital pathology29,30. In these scenarios,
while it may be possible to derive some justiﬁcation from the
literature, e.g., how target users generally approach tasks of the
kind, achieving even Level 2 justiﬁcation is difﬁcult if not
impossible. Empirically validating the envisioned mechanisms for
transparency with respect to their ability to afford transparency
and achieve the human factors engineering goals is thus
paramount when attempting to beneﬁt such tasks.
Successful examples of machine learning systems designed
with clinical end users
Early identiﬁcation and direct communication with end users, as it
is emphasized in the target and incorporation themes, allows ML
designers to bridge the knowledge gap and design for users in
highly specialized contexts. By following human-centered design
and HCI practices, previous works have illustrated ways to
incorporate end users in the design process of ML systems for
clinical applications. For instance, target users were consulted in
the design of an ML tool in an image retrieval system for medical
decision making14, enabling the team to design a system that
preserves human agency to guide the search process. Through an
iterative
design
process,
functional
prototypes
of
different
reﬁnement techniques based on documented user needs were
implemented and further validated in a user study. To enable
users to explore and understand an Artiﬁcial Intelligence (AI)
enabled analysis tool for Chest X-ray (CXR) images, a user-centered
iterative design assessed the utility of potential explanatory
information in the AI system15. Users’ needs during their
introduction
to
an
AI-based
assistance
system
for
digital
pathology were identiﬁed through open-ended interviews and a
qualitative laboratory study31. Iterative co-design processes were
followed to identify clinicians’ perceptions of ML tools for real
clinical workﬂows, e.g., antidepressant treatment decisions16 and
phenotype diagnosis in the intensive care unit32. Determining the
efﬁcacy of envisioned ML systems or ML-enabled interaction
paradigms in empirical user studies before committing resources
to their fully-ﬂedged implementation has become common
practice in human-centered AI, e.g.,21,33,34, with many studies
considering tasks that are related to medical image analysis15,35.
Increasing the acceptance of empirical formative user research as
an integral component of human-centered
ML design for
healthcare tasks, including medical image analysis, will be critical
in ensuring that the assumptions on which human-centered
systems are built hold in the real world.
Increasing demand for guidelines to build machine learning
systems
Motivated by advances in AI technologies and the wide range of
applications in which it can be used to assist humans, there are
ongoing efforts to guide the design and evaluation of AI-infused
systems that people can interact with (theme target). Generally
applicable design guidelines were compiled and iteratively reﬁned
by HCI experts to design and evaluate human-AI interactions36.
Although these guidelines are relevant and suitable for a wide
range of common AI-enabled systems, more nuanced guidelines
are desirable for domains where study participants cannot be
recruited nor interviewed in abundance. Similarly, previous
attempts to guide the design of effective transparency mechan-
isms acknowledge that real stakeholders involved should be
considered and understood17,32,37. Starting from the identiﬁcation
of diverse design goals according to users’ needs and their level of
expertise on AI technology, and a categorization of evaluation
measures for Explainable Artiﬁcial Intelligence (XAI) systems38,
addressed the multidisciplinary efforts needed to build such
systems. A set of guidelines, summarized in a uniﬁed framework,
suggests iterative design and evaluation loops to account for both
algorithmic and human factors of XAI systems. However, similar to
ref. 36, these guidelines are intended for generic applications, e.g.,
loan and insurance rate prediction39 and personalized advertise-
ments40, and do not consider additional challenges, barriers, and
limitations when developing algorithms for domains that exhibit
users with very speciﬁc needs and in highly speciﬁc contexts, such
as healthcare. Other considerations to build interpretable AI
H. Chen et al.
6
npj Digital Medicine (2022) 156 
Published in partnership with Seoul National University Bundang Hospital

## Page 7 (Section: Transparent machine learning systems for diverse stakeholders)

systems have been identiﬁed from a multidisciplinary perspec-
tive12. For instance, the approach presented in ref. 41 summarized
four guidelines that included the application domain, technical
implementation, and human-centered requirements in terms of
the capabilities of human understanding. A requirements list
formulated as a “fact sheet” was introduced in ref.
42 to
characterize and assess explainable systems along ﬁve key
dimensions: functional, operational, usability, safety and valida-
tion. While the ﬁve dimensions allow to systematically compare
and contrast explainability approaches theoretically and practi-
cally, the properties that were included failed to consider where
and how to formulate the justiﬁcation of transparency. Formative
user research and validation of the justiﬁcation of transparency are
especially essential in healthcare, where a huge knowledge
imbalance exists between ML designers and end users of AI
systems.
Considering potential uses of AI in clinical setups, there have
been efforts to deﬁne guidelines for the development and
reporting of medical ML systems. For instance, guidelines for
clinical trials that involve AI were proposed in ref. 43, including
items such as the description of intended users, how the AI
intervention was integrated, how the AI outputs contributed to
decision-making, among others. While specifying these items is
also relevant for creating transparent systems, these guidelines do
not include requirements in dimensions unique to the transpar-
ency of an algorithm, such as its justiﬁcation and validation.
Guidelines for the initial clinical use of AI systems were formulated
in ref. 44, highlighting the importance to assess the actual impact
of an algorithm on its users’ decisions at an early stage. This
recommendation of an early and formative evaluation is aligned
with our guideline with respect to formative user research during
the initial stages to support design choices for transparency.
Concerned with the reproducibility and reliability of medical ML
studies, a set of practical guidelines as a checklist or questions has
been collected for authors and reviews to assess the methodo-
logical
soundness
of
contributions45,
to
promote
standard
reporting practices46, and for clinicians to assess algorithm
readiness for routine care47. Besides the general reporting items
regarding the problem deﬁnition, data, model, and validation,
these checklists consider the deﬁnition of the target user and the
availability of interpretability information and support for related
claims; however, these are questions to be solved once the
transparency technique has been incorporated and might lack an
appropriate justiﬁcation and not achieve the intended goals. By
considering the reason to demand explainability in advance,
which is determined by the application domain and target users
of the AI system, model designers can determine the importance
and usefulness of the properties offered by certain explainability
techniques. To choose among available explainability techniques,
a framework with recommendations regarding mostly technical
aspects for researchers was proposed in ref. 8.
With the trend that ML is more popular in clinical decision
making tasks due to its performance, recent surveys and
systematic reviews have aimed to summarize existing literature
to create transparent ML in healthcare. However, these surveys
failed to consider all the themes proposed in this paper and each
aspect
of
transparent
ML
is
reviewed
in
isolation.
More
importantly,
current
reviews
mainly
focus
on
the
existing
transparency techniques and evaluation, ignoring how and where
justiﬁcation of transparency emerges. For example, a survey
categorized research works related to the interpretability of ML in
general, and then applied the same categories to interpretability
in the medical ﬁeld48. In addition to providing an overall
perspective of the different interpretable algorithms that are
available in the medical ﬁeld, the survey identiﬁed the recurring
assumption of having interpretable models without human
subject tests, questioning the utility within medical practices
and whether ML designs consider actual medical needs. More
speciﬁcally, there have been surveys focused uniquely on
transparent techniques for medical imaging. The interpretability
methods to explain deep learning models were categorized in
detail based on technical similarities, along with the progress
made on the corresponding evaluation approaches in ref.
9.
Another overview of deep learning-based XAI in medical image
analysis is presented in ref. 49, considering a variety of techniques
that were adapted or developed to generate visual, textual, and
example-based explanations in the medical domain. Some of the
observed trends and remarks in this survey match our perspective
and recommendations in the design of transparent methods for
medical imaging, including the lack of evaluation as a standard
practice, the user-dependent nature of explanations, and the
importance of active collaboration with experts to include domain
information. Instead of proposing a general perspective in a broad
range of healthcare problems, some reviews focus on speciﬁc
topics of medical image analysis. Transparent ML for human
experts in cancer diagnosis with AI is reviewed in ref. 10 with a
focus on 2 aspects: ML model characteristics that are important in
cancer prediction and treatment; and the application of ML in
cancer cases. These two aspects are similar to our proposed theme
“Interpretability” and “task”, but we summarize the two themes in
the general medical image analysis area instead of limiting to
cancer studies, include more on recent studies (starting from
2012), and focus on more recent ML techniques such as
Convolution Neural Networks (CNNs). Likewise, transparent ML
in cancer detection is also reviewed in ref. 50 and structured
following the same aspects of generic transparent ML techniques,
such as Local vs. Global and Ad-Hoc vs. Post-Hoc. distinctions
The guidelines and systematic review of the state of the ﬁeld
presented here aim at emphasizing the need for formative user
research and empirical user studies to ﬁrmly establish the validity
of assumptions on which human factors engineering goals
(including transparency) are based; a natural ﬁrst step in human-
centered AI or HCI, but not yet in medical image analysis. As
methods for the human-centered development of transparent ML
for medical image analysis mature, the guidelines presented here
may require reﬁnements to better reﬂect the challenges faced
then. At the time of writing, supported by the ﬁndings of the
systematic review, we believe that the lack of explicit formative
research is the largest barrier to capitalizing on the beneﬁts of
transparent ML in medical image analysis.
To conclude, transparency is an affordance of transparent ML
systems, i.e., a relationship between models and end users.
Therefore, especially in contexts where there exists a high
knowledge gap between ML developers and the envisioned end
users, developing transparent ML algorithms without explicitly
considering and involving end users may result in products that
are unintelligible in the envisioned context and irrelevant in
practice. Efforts to build ML systems that afford transparency in
the
healthcare
context
should
go
beyond
computational
advances, which—based on the ﬁndings of our systematic
review—is not common practice in the context of transparent
ML for medical image analysis. While many of the approaches
claimed transparency or derivative accomplishments in human
factors engineering, they did so even without deﬁning target
users, engaging in formative user research, or reporting rigorous
validation. Consequently, for most of the recently proposed
algorithms, it remains unclear whether they truly afford transpar-
ency or advance human factors engineering goals. We acknowl-
edge that building systems that afford transparency by involving
end users in the design process is challenging for medical image
analysis and related healthcare tasks. In this context, we propose
the INTRPRT guideline that emphasize the importance of user and
context understanding for transparent ML design, but provide
alternatives to empirical studies for formative user research. By
following these guidelines, ML designers must actively consider
their end users throughout the entire design process. We hope
H. Chen et al.
7
Published in partnership with Seoul National University Bundang Hospital
npj Digital Medicine (2022) 156

## Page 8 (Section: Methods)

that these design directives will catalyze forthcoming efforts to
build transparent ML systems for healthcare that demonstrably
achieve the desired human factors engineering goals.
METHODS
Search strategy and selection criteria
The aim of the systematic review is to survey the current state of
transparent ML methods for medical image analysis. Because ML
transparency as major research thrust has emerged following the
omnipresence of highly complex ML models, such as deep CNNs,
we limited our analysis to records that appeared after January
2012, which pre-dates the onset of the ongoing surge of interest
in learning-based image processing51.
We conducted a systematic literature review in accordance with
the Preferred Reporting Items for Systematic reviews and Meta-
Analyses (PRISMA) method52. We searched PubMed, EMBASE, and
Compendex databases to ﬁnd articles pertinent to transparent ML
(including but not limited to explainable and interpretable ML) for
medical imaging by screening titles, abstracts, and keywords of all
available records from January 2012 through July 2021. Details of
the search terms and strategy can be found in Supplementary
information B.
Study selection
Following the removal of duplicates (1731 remained), studies were
ﬁrst pre-screened using the title and abstract. Studies that did not
describe transparent methods nor medical imaging problems
were immediately excluded (217 remained). We then proceeded
to full-text review, where each study was examined to determine
whether the study presented and evaluated a transparent ML
technique for medical image analysis. Failure to comply with the
described inclusion/exclusion criteria resulted in the study’s
removal from further consideration. Detailed statistics and a
complete description of the pre-screening and full-text review can
be found in Supplementary information C and Fig. 4. 68 articles
were included for information extraction.
Data extraction strategy
For the 68 selected articles that met the inclusion criteria, two
authors (H.C. and C.G.) performed detailed data extraction to
summarize important information related to the six themes
described in INTRPRT Guideline Section. A data extraction
template was developed by all authors and is summarized in
Supplementary information D. Every one of the 68 articles was
analyzed and coded by both authors independently and one
author (H.C.) merged the individual reports into a ﬁnal consensus
document. Despite our efforts to broadly cover all relevant search
terms regarding transparent ML in medical imaging, we acknowl-
edge that the list may not be exhaustive. There are vast numbers
of articles that have imbued transparency in their methodology,
but transparency (or contemporary synonyms thereof, such as
explainability or interpretability) is not explicitly mentioned in the
title, abstract, or keywords of these articles, and often not even in
the body of the text53. This fact makes intractable to identify all
articles about transparent ML methods. Finally, the review is
limited
to
published
manuscripts,
long
articles
and
novel
approaches. Publication bias may have resulted in the exclusion
of works relevant to this review.
DETAILED ANALYSIS OF FINDINGS DURING SYSTEMATIC
REVIEW
The
data
extraction
template
for
studies
included
in
the
systematic review was structured using the six themes of the
INTRPRT guideline, the adequacy of which was conﬁrmed during
data extraction. Therefore, we summarize our ﬁndings for each
theme and provide details of the extraction results for each article
in Tables 2&3 in Supplementary information D.
IN: incorporation
A common trend among included studies (n = 33) was that the
presented methods were developed by multidisciplinary clinician-
engineering teams, as was evidenced by the incorporation of
clinical specialists, such as physicians, radiologists, or pathologists,
in the study team and on the author lists. In light of the current
bias towards clinicians as end users of transparent ML algorithms,
this observation suggests that designers may have communicated
with a limited subset of the intended end users. However, no
formative user research is explicitly described or introduced in
these articles to systematically understand the end users before
implementing the model. Further, we found that incorporating
clinical experts did not have a considerable impact on whether
clinical priors or standard or care guidelines (i.e., Level 2 evidence)
were used to build the ML system (39%/44% articles with/without
the incorporation of end users use clinical priors). Regarding the
technical approach to provide transparency, the incorporation of
medical experts motivated designers to incorporate prior knowl-
edge directly into the model structure and/or inference for
medical imaging (73%/64% articles with/without the incorpora-
tion of end users do not need a second model to generate
transparency).
IN: interpretability
Transparency of ML systems was achieved through various
techniques, including attention mechanisms (n = 15), use of
human-understandable features (n = 11), a combination of deep
neural networks and transparent traditional ML methods (n = 7),
visualization approaches (n = 5), clustering methods (n = 4),
uncertainty estimation/conﬁdence calibration (n = 3), relation
analysis between outputs and hand-crafted features (n = 3), and
other custom techniques (n = 20).
The use of an attention mechanism was the most common
technique
for
adding
transparency.
Attention
mechanisms
Fig. 4
PRISMA diagram for transparent ML in medical imaging.
The ﬂow diagram shows the number of records identiﬁed, of studies
excluded and the reasons for exclusion, and of studies included in
our systematic review.
H. Chen et al.
8
npj Digital Medicine (2022) 156 
Published in partnership with Seoul National University Bundang Hospital

## Page 9 (Section: T: targets)

enabled the generation of pixel-attribution methods54 to visualize
pixel-level importance for a speciﬁc class of interest55–69. In
segmentation tasks, where clinically relevant abnormalities and
organs are usually of small sizes, features from different resolution
levels were aggregated to compute attention and generate more
accurate outcomes, as demonstrated in multiple applications, e.g.,
multi-class segmentation in fetal Magnetic Resonance Imagings
(MRIs)58 and multiple sclerosis segmentation in MRIs61. Clinical
prior knowledge was also inserted into the attention mechanism
to make the whole system more transparent. For instance,65 split
brain MRIs into 96 clinically important regions and used a genetic
algorithm to calculate the importance of each region to evaluate
Alzheimer’s Disease (AD).
Human-understandable features, e.g., hand-crafted low-dimen-
sional features or clinical variables (age, gender, etc.) were
frequently used to establish transparent systems. There existed
two main ways to use human-understandable features in medical
imaging: (1) Extracting hand-crafted features, e.g., morphological
and radiomic features, from predicted segmentation masks
generated by a non-transparent model70–79 followed by analysis
of those hand-crafted features using a separate classiﬁcation
module; (2) Directly predicting human-understandable features
together with the main classiﬁcation and detection task80–84. In
these approaches, all tasks usually shared the same network
architecture and parameter weights.
Instead
of
explicitly
extracting
or
predicting
human-
understandable features, other articles further analyzed deep
encoded features with human-understandable techniques by
following clinical knowledge. Techniques such as decision trees
were constructed based on clinical taxonomy for hierarchical
learning76,85–90. Rule-based algorithms91 and regression meth-
ods92 were used to promote transparency of the prediction93
created a Graphical Convolution Network (GCN) based on clinical
knowledge to model the correlations among colposcopic images
captured around ﬁve key time slots during a visual examination.
We also identiﬁed various other methods to create transparent
systems. These methods can be categorized as visualization-
based, feature-based, region importance-based, and architecture
modiﬁcation-based methods. Each approach is discussed in
detail below.
Visualization-based methods provide easy-to-understand illus-
trations by overlaying the original images with additional visual
layouts generated from transparency techniques. There existed
two main visualization-based methods: (1) Visualizing pixel-
attribution maps: These maps may be generated using gradient-
based importance analysis94,95, pixel-level predicted probability96,
or a combination of different levels of feature maps97,98. (2) Latent
feature evolution: Encoded features were evolved according to
the gradient ascent direction so that the decoded image (e.g.,
generated with an auto-encoder technique99) gradually change
from one class to another100,101.
Feature-based methods directly analyze encoded features in an
attempt to make the models transparent. Various feature-based
transparency method were proposed for transparent learn-
ing102–104 ﬁrst encoded images to deep features and then
clustered samples based on these deep features for prediction
or image grouping tasks. Feature importance was also well-
studied to identify features that are most relevant for a speciﬁc
class by feature perturbation105,106 and gradients107,108 identiﬁed
and removed features with less importance for ﬁnal prediction
through feature ranking.
As an alternative to measure feature contribution, input region
importance was also analyzed to reveal sub-region relevance to
each
prediction
class.
Image
occlusion
with
blank
sub-
regions109–111 and healthy-looking sub-regions112 was used to
ﬁnd the most informative and relevant sub-regions for classiﬁca-
tion and detection tasks.
Other approaches modiﬁed the network architecture according
to relevant clinical knowledge to make the whole system
transparent58 pruned the architecture according to the degree
of scale invariance at each layer in the network113 created ten
branches with shared weights for ten ultrasound images to mimic
the clinical workﬂow of liver ﬁbrosis stage prediction114 aggre-
gated information from all three views of mammograms and used
traditional methods to detect nipple and muscle direction, which
was followed by a grid alignment according to the nipple and
muscle direction for left and right breasts115 proposed to learn
representations of the underlying anatomy with a convolutional
auto-encoder by mapping the predicted and ground truth
segmentation maps to a low dimensional representation to
regularize the training objective of the segmentation network.
Some other methods used the training image distribution to
achieve transparency in classiﬁcation116 used similar-looking
images (nearest training images in feature space) to classify
testing images with majority votes. Causal inference with plug-in
clinical prior knowledge also introduced transparency directly to
automatic systems117–119. Conﬁdence calibration and uncertainty
estimation methods were also used to generate additional
conﬁdence information for end users120–122.
T: targets
A striking observation was that none of the selected articles aimed
at building transparent systems for users other than care
providers. Less than half of the articles explicitly speciﬁed
clinicians as the intended end users of the system (n = 30). From
the remaining 38 articles, 17 articles implied that the envisioned
end users would be clinicians, while the remaining 21 did not
specify the envisioned target users. Articles that were more
explicit about their end users were more likely to rely on clinical
prior knowledge (Level 2 evidence) in model design. In total, 47%
of articles that speciﬁed or implied clinicians as end users
implemented clinical prior knowledge in the transparent systems
while only 18% of articles without end user information use
clinical prior knowledge.
R: reporting
Evaluating different properties of a transparent algorithm besides
task-related metrics, especially its performance in regards to
achieving the desired human factors engineering goals, comple-
ments the assessment of the ML model’s intended purpose. We
identiﬁed that the quality of the transparency component is
currently being evaluated through four main approaches. The ﬁrst
one involves metrics based on human perception, such as the
mean opinion score introduced in ref. 115 to capture two expert
participants’ rating of the model’s outcome quality and similarity
to the ground truth on a 5-point scale. Using two study
participants, pathologists’ feedback was also requested in ref. 107
to assess their agreement with patch-based visualizations that
display features relevant for normal and abnormal tissue. The level
of agreement was not formally quantiﬁed, but reported as a
qualitative description. Similarly, one study participant was
involved in a qualitative assessment of explanations quality in
ref. 83,108. These evaluations are different from empirical user
studies as they are limited to a few individuals and were mostly
used to subjectively conﬁrm the correctness of the transparent
component.
The second approach attempted to quantify the quality of
explanations for a speciﬁc purpose (functionally-grounded evalua-
tion123). For instance, some articles evaluated the localization ability
of post-hoc explanations by deﬁning an auxiliary task, such as
detection57,88 or segmentation62,85,98,112 of anatomical structures
related to the main task. They then contrasted relevant regions
identiﬁed by the model with ground truth annotations. These
quantitative measures (dice score, precision, recall) allowed for
H. Chen et al.
9
Published in partnership with Seoul National University Bundang Hospital
npj Digital Medicine (2022) 156

## Page 10 (Section: PR: priors)

further comparisons with traditional explanations methods. Simi-
larly116, deﬁned a multi-task learning framework for image classiﬁca-
tion and retrieval, evaluating retrieval precision and providing a
conﬁdence score based on the retrieved neighbors as an attempt to
check the learned embedding space. Capturing relevant features
consistent with human intuition was proposed in ref.
106 by
measuring the fraction of reference features recovered, which were
deﬁned according to a guideline. Overall, the evaluation of
explanations through auxiliary tasks required additional manual
efforts to get the necessary ground truth annotations.
Properties of the explanation itself were also quantiﬁed as their
usefulness to identify risky and safe predictions at a voxel-level for
the main task by thresholding on their predictive uncertainty
values122. Other properties of explanations, such as their correct-
ness (accuracy of rules), completeness (fraction of the training set
covered) and compactness (size in bytes) were measured in ref. 87.
A measure related to completeness was deﬁned in ref. 88 and
aimed to capture the proportion of training images represented
by the learned visual concepts, in addition to two other metrics:
the inter- and intra-class diversity and the faithfulness of
explanations computed by perturbing relevant patches and
measuring the drop in classiﬁcation conﬁdence. Other articles
followed a similar approach to validate relevant pixels or features
identiﬁed with a transparent method; for example, in ref. 64 a
deletion curve was constructed by plotting the dice score vs. the
percentage of pixels removed and ref. 55 deﬁned a recall rate
when
the
model
proposes
certain
number
of
informative
channels95 proposed to evaluate the consistency of visualization
results and the outputs of a CNN by computing the L1 error
between predicted class scores and explanation pixel-attribution
maps. In summary, while the methods grouped in this theme are
capable of evaluating how well a method aligns with it’s intended
mechanism of transparency, they fall short of capturing any
human factors-related aspects of transparency design.
The third, and most common approach, involved a qualitative
validation of the transparent systems (n = 40) by showing pixel-
attribution visualizations overlaid with the input image or rankings
of feature relevance, along with narrative observations on how these
visualizations may relate to the main task. These qualitative
narratives might include comparisons with other visualization
techniques in terms of the highlighted regions or the granularity/
level of details. Furthermore, following a retrospective analysis, the
consistency between the identiﬁed relevant areas/features and prior
clinical knowledge in a speciﬁc task was a common discussion item
in 37% of all the articles (n = 25); refer to articles65,86,89,110,117 for
examples. While grounding of feature visualizations in the relevant
clinical task is a commendable effort, the methods to generate the
overlaid information have been criticized in regards to their ﬁdelity
and speciﬁcity53,124. Further, as was the case for methods that
evaluate the ﬁdelity of transparency information, these methods do
not inherently account for human factors.
Lastly, transparent systems can be directly evaluated through
user studies on the target population, in which the end users
interact with the developed ML system to complete a task based
on a speciﬁc context. In ref. 96, the evaluation was centered on the
utility of example-based and feature-based explanations for
radiologists (8 study participants) to understand the AI decision
process. Users’ understanding was evaluated as the accuracy to
predict the AI’s diagnosis for a target image and a binary
judgment on whether they certify the AI for similar images (and
justify using multiple-choice options). Users’ agreement with the
AI’s predictions was measured as well. The empirical evidence
suggested that explanations enabled radiologists to develop
appropriate trust by making an accurate prediction and judgment
of the AI’s recommendations. Even though radiologists could
complete the task by themselves, a comparison with the team
performance was not included, nor the performance of the AI
model in standalone operation. An alternative evaluation of
example-based explanation usefulness was performed in ref. 121,
in which pathologists (14 study participants) determined the
acceptability of a decision support tool by rating adjectives related
to their perceived objectivity, details, reliability, and quality of the
system. Compared to a CNN without explanations, the subjective
ratings were more positive towards the explainable systems.
However, neither the team (expert + AI) nor expert baseline
performance was evaluated. The beneﬁt of involving a dermatol-
ogist to complete an image grouping task was demonstrated in
ref.
102, in which domain knowledge was used to constrain
updates of the algorithm’s training, resulting in a better grouping
performance than a fully automated method. The user evaluation
only measured the task performance. These studies that explicitly
involve target users to identify whether the envisioned human
factors engineering goals were met stand out from the large body
of work that did not consider empirical user tests. It is, however,
noteworthy that even these exemplary studies are based on very
small sample sizes that may not be sufﬁciently representative of
the target users. Careful planning of the study design (including
hypothesis
statement,
experimental
design
and
procedure,
participants, and measures) that allows to properly evaluate
whether the system achieves the intended goals by adding
transparency
to
the
ML
system
is
fundamental,
especially
considering the resources needed and challenges involved in
conducting user testing in the healthcare domain.
Even though there were articles that assessed human factors-
related properties of the transparency mechanism, a striking
majority of articles did not report metrics beyond performance in
the main task (n = 49) or did not discuss the transparency
component at all (n = 9). Task performance was evaluated in the
majority of the articles, 91% (n = 62), and most of them contrasted
the performance
of the transparent systems
with a non-
transparent baseline (n = 41). Of those, 36 works (88%) reported
improved performance and 5 (12%) comparable results.
PR: priors
We differentiate two types of priors that can be used as a source of
inspiration to devise transparent ML techniques: (1) Priors based on
documented knowledge, and especially clinical guidelines consider-
ing the unvaried end user speciﬁcation identiﬁed above; and (2)
Priors based on computer vision concepts. Most (93%) articles that
incorporated clinical knowledge priors (n = 28) directly implemen-
ted these priors into the model structure and/or inference, while
only 68% articles with computer vision priors (n = 40) provided
transparency by the model itself and/or the inference procedure.
A direct way to include clinical knowledge priors was through
the prediction, extraction, or use of human-understandable
features. Morphological features, e.g., texture, shape and edge
features were frequently considered and used to support the
transparency of ML systems70,72,73,75,76,81,83,93. Biomarkers for
speciﬁc problems, e.g., end-diastolic volume (EDV) in cardiac
MRI78,79
and
mean
diameter,
consistency,
and
margin
of
pulmonary nodules80 were commonly computed to establish
transparency. For problems with a well-established image report-
ing and diagnosis systems, routinely-used clinical features, e.g.,
Liver Imaging Reporting and Data System (LI-RADS) features for
Hepatocellular carcinoma (HCC) classiﬁcation84 or BI-RADS for
breast mass82 suggested that the ML systems may be intuitively
interpretable to experts that are already familiar with these
guidelines. Human-understandable features relevant to the task
domain were extracted from pathology images, e.g., area and
tissue structure features70. Radiomic features were also computed
to establish the transparency of ML systems75,125.
Besides human-understandable features, clinical knowledge can
be used to guide the incorporation of transparency within a
model.
Some
articles
(n = 11)
mimicked
or
started
from
clinical
guidelines
and
workﬂows
to
construct
the
ML
H. Chen et al.
10
npj Digital Medicine (2022) 156 
Published in partnership with Seoul National University Bundang Hospital

## Page 11 (Section: T: task)

systems65,74,81,82,106,113–115,118,119,74,113,114 followed the clinical work-
ﬂow to encode multiple sources of images and fused the encoded
information for the ﬁnal prediction. Other works followed the
speciﬁc clinical guidelines of the problems to create transparent
systems65 split brain MRIs into 96 clinical meaningful regions as
would be done in established clinical workﬂows and analyze all the
regions separately. Some other clinical knowledge priors were also
presented85,86,90,126 established a hierarchical label structure accord-
ing to clinical taxonomy for image classiﬁcation71 leveraged the
transparency
from
the
correlation
between
the
changes
of
polarization characteristics and the pathological development of
cervical precancerous lesions. Clinical knowledge from human
experts was used to reﬁne an image grouping algorithm through
an interactive mechanism in which experts iteratively provided
inputs to the model102.
Priors that were derived from computer vision concepts rather
than the clinical workﬂow were usually not speciﬁc or limited to a
single application. The justiﬁcation of transparency with computer
vision priors was more general than that with clinical knowledge
priors. Image visualization-based techniques to achieve transpar-
ency were most commonly considered in image classiﬁcation
problems. Common ways of retrieving relevance information
were: Visual relevancy through attention55–64,66–68; region occlu-
sion by blank areas109,111 or healthy-looking regions112; and other
techniques such as supervision of activated image regions by
clinically relevant areas88,89,92,94,95,97,98, and image similarity96.
Feature-based computer vision transparency priors focused on the
impact of feature evolution or perturbation on the decoded
output. Encoded features were evolved according to the gradient
ascent direction to create the evolution of the decoded image
from one class to the other87,100,101. Some articles directly
analyzed the feature sensitivity to the ﬁnal prediction by feature
perturbation101,105,110 and importance analysis77,107,108, feature
distribution104,105
or
image
distribution
based
on
encoded
features103,116. Conﬁdence calibration and uncertainty estimation
also increased the transparency of the ML systems120–122.
Even though we attempted to identify the type of prior
evidence used to justify the development of a speciﬁc algorithm
in each ML system, none of the included articles formally
described the process to formulate such priors to achieve
transparency in the proposed system. While the use of clinical
guidelines and routine workﬂows may provide Level 2 evidence in
support of the method affording transparency if the end users are
matched with those priors, relying solely on computer vision
techniques may not provide the same level of justiﬁcation. This is
because computer vision algorithms are often developed as an
analysis tool for ML developers to verify model correctness, but
are not primarily designed nor evaluated for use in end user-
centered interfaces. The lack of justiﬁcation and formal processes
to inform design choices at the early stages of model develop-
ment results in substantial risk of creating transparent systems
that rely on inaccurate, unintelligible, or irrelevant insights for end
users. Being explicit about the assumptions and evidence
available in support of the envisioned transparent ML system is
paramount to build fewer but better-justiﬁed transparent ML
systems that are more likely to live up to expectations in ﬁnal user
testing, the resources for which are heavily constrained.
T: task
Various types of medical image analysis tasks were explored in the
included articles. Most of the articles (n = 57) proposed transparent
ML algorithms for classiﬁcation and detection problems, such as
image classiﬁcation and abnormality detection. Three-dimensional
(3D) radiology images (n = 24) and pathological images (n = 15)
were the most popular modalities involved in the development of
transparent algorithms. The complex nature of both 3D imaging in
radiology and pathological images makes image analysis tasks more
time consuming than 2D image analysis that is more prevalent in
other specialities, such as dermatology, which motivates transpar-
ency as an alternative to complete human image analysis to save
time while retaining trustworthiness. In detail, classiﬁcation pro-
blems in 3D radiological images and pathological images included
abnormality
detection
in
computed
tomography
(CT)
scans56,59,66,73,75,90,95,106,
MRIs58,60,65,77–79,83,84,98,100,105,110,112,117,
pathology
images55,57–59,62,69–71,77,104,107–109,116,121
and
positron
emission tomography (PET) images63. Mammography dominated
the 2D radiology image applications76,81,82,87,92,94,114,119,125, mainly
focusing on breast cancer classiﬁcation and mass detection. For
other 2D radiology image applications96,118, aimed at pneumonia
and pneumothorax prediction from chest X-rays and113 created a
transparent model for liver ﬁbrosis stage prediction in liver
ultrasound images. Classiﬁcation and detection tasks were explored
in other clinical specialities, including melanoma85 and skin lesion
grade prediction58,86,87 in dermatology, glaucoma detection from
fundus images68,74,97 and retinopathy diagnosis111 in ophthalmol-
ogy,
and
polyp
classiﬁcation
from
colonoscopy
images
in
gastroenterology88,120.
Segmentation
was
another
major
application
ﬁeld
(n = 9).
Research about transparency mainly focused on segmentation
problems
for
brain
and
cardiac
MRIs61,64,67,72,89,103,115.
Other
segmentation problems included mass segmentation in mammo-
grams76, cardiac segmentation in ultrasound115, liver tumor seg-
mentation in hepatic CT images, and skin lesion segmentation in
dermatological images58. There also existed other applications, e.g.,
image grouping in dermatological images102 and image enhance-
ment (super resolution task) in brain MRIs122 and cardiac MRIs115.
Most of the application tasks were routinely performed by
human experts in current clinical practice (n = 60). A much smaller
sample of articles (n = 4) aimed to build transparent systems for
much more difﬁcult tasks where no human baseline exists, e.g.,
5-class molecular phenotype classiﬁcation from Whole Slide Images
(WSIs)70,88, 5-class polyp classiﬁcation from colonoscopy images120,
cardiac resynchronization therapy response prediction from cardiac
MRIs83, and super resolution of brain MRIs122. The remaining articles
(n = 4) did not include explicit information on whether human
baselines and established criteria exist for the envisioned applica-
tion, e.g., magniﬁcation level and nuclei area prediction in breast
cancer histology images58, age estimation in brain MRIs60, AD status
in Diffusion Tensor Images (DTIs), and risk of sudden cardiac death
prediction in cardiac MRIs79. As previously mentioned, tasks that are
routinely performed in clinical evidence may have robust human
baselines and clinical guidelines to guide transparent ML develop-
ment. Applications that are beyond the current possibilities,
however, require a more nuanced and human-centered approach
that should involve the target end users as early as possible to
verify that the assumptions that drive transparency are valid.
DATA AVAILABILITY
Figure 2 contains images from the ORIGA127 and BraTS2020 datasets128. The ORIGA
dataset is a public dataset at Kaggle website (https://www.kaggle.com/datasets/
sshikamaru/glaucoma-detection/metadata). The BraTS2020 dataset is also a public
dataset at Kaggle website (https://www.kaggle.com/datasets/awsaf49/brats2020-
training-data). The authors declare that all the data included in this study are
available within the paper and its Supplementary Information ﬁles. Please contact
author HC to request the data.
Received: 15 April 2022; Accepted: 29 September 2022;
REFERENCES
1. Topol, E. J. High-performance medicine: the convergence of human and artiﬁcial
intelligence. Nat. Med. 25, 44–56 (2019).
H. Chen et al.
11
Published in partnership with Seoul National University Bundang Hospital
npj Digital Medicine (2022) 156

## Page 12 (Section: T: task)

2. Obermeyer, Z., Powers, B., Vogeli, C. & Mullainathan, S. Dissecting racial bias in
an algorithm used to manage the health of populations. Science 366, 447–453
(2019).
3. Ghassemi, M., Oakden-Rayner, L. & Beam, A. L. The false hope of current
approaches to explainable artiﬁcial intelligence in health care. Lancet Digital
Health 3, e745–e750 (2021).
4. McCoy, L. G., Brenna, C. T., Chen, S. S., Vold, K. & Das, S. Believing in black boxes:
Machine learning for healthcare does not need explainability to be evidence-
based. J. Clin. Epidemiol. 142, 252–257 (2022).
5. Vellido, A. The importance of interpretability and visualization in machine
learning for applications in medicine and health care. Neural Comput. Appl. 32,
18069–18083 (2020).
6. Char, D. S., Abràmoff, M. D. & Feudtner, C. Identifying ethical considerations
for machine learning healthcare applications. Am. J. Bioethics 20, 7–17
(2020).
7. Holzinger, A., Langs, G., Denk, H., Zatloukal, K. & Müller, H. Causability and
explainability of artiﬁcial intelligence in medicine. Wiley Interdiscip. Rev.: Data
Mining Knowl. Discov. 9, e1312 (2019).
8. Markus, A. F., Kors, J. A. & Rijnbeek, P. R. The role of explainability in creating
trustworthy artiﬁcial intelligence for health care: a comprehensive survey of the
terminology, design choices, and evaluation strategies. J. Biomed. Inf. 113,
103655 (2021).
9. Salahuddin, Z., Woodruff, H. C., Chatterjee, A. & Lambin, P. Transparency of deep
neural networks for medical image analysis: A review of interpretability meth-
ods. Comput. Biology Med. 140, 105111 (2022).
10. Banegas-Luna, A. J. et al. Towards the interpretability of machine learning
predictions for medical applications targeting personalised therapies: A cancer
case survey. Int. J. Mol. Sci. 22, 4394 (2021).
11. Ploug, T. & Holm, S. The four dimensions of contestable ai diagnostics-a patient-
centric approach to explainable ai. Artif. Intell. Med. 107, 101901 (2020).
12. Amann, J., Blasimme, A., Vayena, E., Frey, D. & Madai, V. I. Explainability for
artiﬁcial intelligence in healthcare: a multidisciplinary perspective. BMC Med. Inf.
Dec. Making 20, 1–9 (2020).
13. Norman, D. A. Affordance, conventions, and design. Interactions 6, 38–43 (1999).
14. Cai, C. J. et al. Human-centered tools for coping with imperfect algorithms
during medical decision-making. In Proceedings of the 2019 CHI Conference on
Human Factors in Computing Systems, 1–14 (2019).
15. Xie, Y., Chen, M., Kao, D., Gao, G. & Chen, X. Chexplain: Enabling physicians to
explore and understand data-driven, AI-enabled medical imaging analysis. In
Proceedings of the 2020 CHI Conference on Human Factors in Computing Systems,
1–13 (2020).
16. Jacobs, M. et al. Designing AI for trust and collaboration in time-constrained
medical decisions: A sociotechnical lens. In Proceedings of the 2021 CHI Con-
ference on Human Factors in Computing Systems, 1–14 (2021).
17. Suresh, H., Gomez, S. R., Nam, K. K. & Satyanarayan, A. Beyond expertise and
roles: A framework to characterize the stakeholders of interpretable machine
learning and their needs. In Proceedings of the 2021 CHI Conference on Human
Factors in Computing Systems, 1–16 (2021).
18. Lai, V. & Tan, C. On human predictions with explanations and predictions of
machine learning models: A case study on deception detection. In Proceed-
ings of the conference on fairness, accountability, and transparency, 29–38
(2019).
19. Eiband, M. et al. Bringing transparency design into practice. In 23rd international
conference on intelligent user interfaces, 211–223 (2018).
20. Wang, X. & Yin, M. Are explanations helpful? a comparative study of the effects
of explanations in AI-assisted decision-making. In 26th International Conference
on Intelligent User Interfaces, 318–328 (2021).
21. Cheng, H.-F. et al. Explaining decision-making algorithms through ui: Strategies
to help non-expert stakeholders. In Proceedings of the 2019 chi conference on
human factors in computing systems, 1–12 (2019).
22. Smith-Renner, A. et al. No explainability without accountability: An empirical
study of explanations and feedback in interactive ml. In Proceedings of the 2020
CHI Conference on Human Factors in Computing Systems, 1–13 (2020).
23. Bansal, G. et al. Does the whole exceed its parts? the effect of ai explanations on
complementary team performance. In Proceedings of the 2021 CHI Conference on
Human Factors in Computing Systems, 1–16 (2021).
24. Bansal, G. et al. Beyond accuracy: The role of mental models in human-AI team
performance. Proceedings of the AAAI Conference on Human Computation and
Crowdsourcing 7, 2–11 (2019).
25. Nourani, M. et al. Anchoring bias affects mental model formation and user
reliance in explainable ai systems. In 26th International Conference on Intelligent
User Interfaces, 340–350 (2021).
26. McCoy, L. G., Brenna, C. T., Chen, S., Vold, K. & Das, S. Believing in black boxes:
Machine learning for healthcare does not need explainability to be evidence-
based. J. Clin. Epidemiol 142, 252–257 (2021).
27. Deeley, M. et al. Segmentation editing improves efﬁciency while reducing inter-
expert variation and maintaining accuracy for normal brain tissues in the pre-
sence of space-occupying lesions. Phys. Med. Biol. 58, 4071 (2013).
28. Banerjee, I. et al. Reading race: Ai recognises patient’s racial identity in medical
images. preprint at https://arxiv.org/abs/2107.10356 (2021).
29. Liu, T. A. et al. Gene expression proﬁle prediction in uveal melanoma using deep
learning: A pilot study for the development of an alternative survival prediction
tool. Ophthalmol. Retina 4, 1213–1215 (2020).
30. Lu, M. Y. et al. Deep learning-based computational pathology predicts origins
for cancers of unknown primary. preprint at https://arxiv.org/abs/2006.13932
(2020).
31. Cai, C. J., Winter, S., Steiner, D., Wilcox, L. & Terry, M. "hello AI": Uncovering the
onboarding needs of medical practitioners for human-ai collaborative decision-
making. Proce. ACM Human-Comput. Interaction 3, 1–24 (2019).
32. Wang, D., Yang, Q., Abdul, A. & Lim, B. Y. Designing theory-driven user-centric
explainable AI. In Proceedings of the 2019 CHI conference on human factors in
computing systems, 1–15 (2019).
33. Nourani, M., King, J. & Ragan, E. The role of domain expertise in user trust and
the impact of ﬁrst impressions with intelligent systems. In Proceedings of the
AAAI Conference on Human Computation and Crowdsourcing, vol. 8, 112–121
(2020).
34. Buçinca, Z., Malaya, M. B. & Gajos, K. Z. To trust or to think: Cognitive forcing
functions can reduce overreliance on ai in ai-assisted decision-making. Pro-
ceedings of the ACM on Human-Computer Interaction 5, 1–21 (2021).
35. Gaube, S. et al. Do as ai say: susceptibility in deployment of clinical decision-aids.
NPJ Digital Medicine 4, 1–8 (2021).
36. Amershi, S. et al. Guidelines for human-AI interaction. In Proceedings of the 2019
chi conference on human factors in computing systems, 1–13 (2019).
37. Liao, Q. V., Gruen, D. & Miller, S. Questioning the AI: informing design practices
for explainable ai user experiences. In Proceedings of the 2020 CHI Conference on
Human Factors in Computing Systems, 1–15 (2020).
38. Mohseni, S., Zarei, N. & Ragan, E. D. A multidisciplinary survey and framework for
design and evaluation of explainable AI systems. ACM Trans. Interactive Intell.
Syst. 11, 1–45 (2021).
39. Chen, J., Kallus, N., Mao, X., Svacha, G. & Udell, M. Fairness under unawareness:
Assessing disparity when protected class is unobserved. In Proceedings of the
conference on fairness, accountability, and transparency, 339–348 (2019).
40. Datta, A., Tschantz, M. C. & Datta, A. Automated experiments on ad privacy
settings: A tale of opacity, choice, and discrimination. preprint at https://
arxiv.org/abs/1408.6491 (2014).
41. Leslie, D. Understanding artiﬁcial intelligence ethics and safety: A guide for the
responsible design and implementation of ai systems in the public sector.
Available at SSRN 3403301 (2019).
42. Sokol, K. & Flach, P. Explainability fact sheets: a framework for systematic
assessment of explainable approaches. In Proceedings of the 2020 Conference on
Fairness, Accountability, and Transparency, 56–67 (2020).
43. Liu, X., Rivera, S. C., Moher, D., Calvert, M. J. & Denniston, A. K. Reporting
guidelines for clinical trial reports forinterventions involving artiﬁcial intelli-
gence: the consort-AI extension. BMJ 370, m3164, https://doi.org/10.1136/
bmj.m3164 (2020).
44. DECIDE-AI Steering Group. DECIDE-AI: new reporting guidelines to bridge the
development-to-implementation gap in clinical artiﬁcial intelligence. Nat. Med.
27, 186–187 (2021).
45. Cabitza, F. & Campagner, A. The need to separate the wheat from the chaff in
medical informatics: Introducing a comprehensive checklist for the (self)-
assessment of medical ai studies (2021).
46. Hernandez-Boussard, T., Bozkurt, S., Ioannidis, J. P. & Shah, N. H. Minimar
(minimum information for medical ai reporting): developing reporting stan-
dards for artiﬁcial intelligence in health care. J. Am. Med. Inf. Assoc. 27,
2011–2015 (2020).
47. Scott, I., Carter, S. & Coiera, E. Clinician checklist for assessing suitability of
machine learning applications in healthcare. BMJ Health & Care Informatics 28
(2021).
48. Tjoa, E. & Guan, C. A survey on explainable artiﬁcial intelligence (xai): Toward
medical xai. IEEE Trans. Neural Netw. Learn. Syst. 32, 4793–4813 (2020).
49. van der Velden, B. H., Kuijf, H. J., Gilhuijs, K. G. & Viergever, M. A. Explainable
artiﬁcial intelligence (xai) in deep learning-based medical image analysis. Med.
Image Anal 79, 102470 (2022).
50. Gulum, M. A., Trombley, C. M. & Kantardzic, M. A review of explainable deep
learning cancer detection models in medical imaging. Appl. Sci. 11, 4573 (2021).
51. Krizhevsky, A., Sutskever, I. & Hinton, G. E. Imagenet classiﬁcation with deep
convolutional neural networks. Commun. ACM 60, 84–90 (2017).
52. Moher, D., Liberati, A., Tetzlaff, J., Altman, D. G. & Group, P. Preferred reporting
items for systematic reviews and meta-analyses: the prisma statement. PLoS
Med. 6, e1000097 (2009).
H. Chen et al.
12
npj Digital Medicine (2022) 156 
Published in partnership with Seoul National University Bundang Hospital

## Page 13 (Section: T: task)

53. Rudin, C. Stop explaining black box machine learning models for high stakes
decisions and use interpretable models instead. Nat. Mach. Intell. 1, 206–215
(2019).
54. Molnar, C. Interpretable machine learning (Lulu. com, 2020).
55. Abdel Magid, S. et al. Channel Embedding for Informative Protein Identiﬁcation
from Highly Multiplexed Images. 23rd International Conference on Medical Image
Computing and Computer-Assisted Intervention, MICCAI 2020, October 4, 2020 -
October 8, 2020 12265 LNCS, 3–13 (2020).
56. Afshar, P. et al. MIXCAPS: A capsule network-based mixture of experts for lung
nodule malignancy prediction. Pattern Recognition 116, https://doi.org/10.1016/
j.patcog.2021.107942NS (2021).
57. Fan, M., Chakraborti, T., Chang, E. I. C., Xu, Y. & Rittscher, J. Microscopic Fine-
Grained Instance Classiﬁcation Through Deep Attention. 23rd International
Conference on Medical Image Computing and Computer-Assisted Intervention,
MICCAI 2020, October 4, 2020 - October 8, 2020 12265 LNCS, 490–499 (2020).
58. Graziani, M., Lompech, T., Muller, H., Depeursinge, A. & Andrearczyk, V. Inter-
pretable CNN Pruning for Preserving Scale-Covariant Features in Medical Ima-
ging. 3rd International Workshop on Interpretability of Machine Intelligence in
Medical Image Computing, iMIMIC 2020, the 2nd International Workshop on
Medical Image Learning with Less Labels and Imperfect Data, MIL3ID 2020, and the
5th International Workshop o 12446 LNCS, 23–32 (2020).
59. An, F., Li, X. & Ma, X. Medical Image Classiﬁcation Algorithm Based on Visual
Attention Mechanism-MCNN. Oxidative Medicine and Cellular Longevity 2021,
https://www.embase.com/search/results?subaction=viewrecord&id=
L2011217895&from=exporthttps://doi.org/10.1155/2021/6280690 (2021).
60. He, S. et al. Multi-channel attention-fusion neural network for brain age esti-
mation: Accuracy, generality, and interpretation with 16,705 healthy MRIs across
lifespan.
Med.
Image
Anal.
72,
https://www.embase.com/search/results?
subaction=viewrecord&id=L2012117928&from=exporthttps://doi.org/10.1016/
j.media.2021.102091 (2021).
61. Hou, B., Kang, G., Xu, X. & Hu, C. Cross Attention Densely Connected Networks
for Multiple Sclerosis Lesion Segmentation. 2019 IEEE International Conference
on Bioinformatics and Biomedicine, BIBM 2019, November 18, 2019 - November 21,
2019 2356–2361, https://doi.org/10.1109/BIBM47256.2019.8983149NS (2019).
62. Huang, Y. & Chung, A. C. S. Evidence localization for pathology images using
weakly supervised learning. 22nd International Conference on Medical Image
Computing and Computer-Assisted Intervention, MICCAI 2019, October 13, 2019 -
October 17, 2019 11764 LNCS, 613–621 (2019).
63. Morvan, L. et al. Learned Deep Radiomics for Survival Analysis with Attention.
3rd International Workshop on Predictive Intelligence in Medicine, PRIME 2020, held
in conjunction with the Medical Image Computing and Computer Assisted Inter-
vention, MICCAI 2020, October 8, 2020 - October 8, 2020 12329 LNCS, 35–45
(2020).
64. Saleem, H., Shahid, A. R. & Raza, B. Visual interpretability in 3D brain tumor
segmentation network. Comput. Biology Med. 133, https://www.embase.com/
search/results?subaction=viewrecord&id=L2011734982&
from=exporthttps://doi.org/10.1016/j.compbiomed.2021.104410 (2021).
65. Shahamat, H. & Saniee Abadeh, M. Brain MRI analysis using a deep learning
based evolutionary approach. Neural Netw. 126, 218–234 (2020).
66. Singla, S. et al. Subject2Vec: generative-discriminative approach from a set of
image patches to a vector. Med. Image Comput. Comput. Assist Interv. 11070,
502–510 (2018).
67. Sun, J., Darbehani, F., Zaidi, M. & Wang, B. SAUNet: Shape Attentive U-Net for
Interpretable Medical Image Segmentation. 23rd International Conference on
Medical Image Computing and Computer-Assisted Intervention, MICCAI 2020,
October 4, 2020 - October 8, 2020 12264 LNCS, 797–806 (2020).
68. Xu, X. et al. Automatic glaucoma detection based on transfer induced attention
network. Biomed. Eng. Online 20, 39 (2021).
69. Yang, H., Kim, J.-Y., Kim, H. & Adhikari, S. P. Guided soft attention network for
classiﬁcation of breast cancer histopathology images. IEEE Trans. Med. Imaging
39, 1306–1315 (2020).
70. Diao, J. A. et al. Human-interpretable image features derived from densely
mapped cancer pathology slides predict diverse molecular phenotypes.
Nat.
Commun.
12,
https://www.embase.com/search/results?subaction=
viewrecord&id=L2010776995&from=exporthttps://doi.org/10.1038/s41467-
021-21896-9 (2021).
71. Dong, Y. et al. A Polarization-imaging-based machine learning framework for
quantitative pathological diagnosis of cervical precancerous lesions. IEEE
Trans. Med. Imaging. https://www.embase.com/search/results?subaction=viewr
ecord&id=L635538309&from=exporthttps://doi.org/10.1109/TMI.2021.3
097200 (2021).
72. Giannini, V., Rosati, S., Regge, D. & Balestra, G. Texture features and artiﬁcial
neural networks: A way to improve the speciﬁcity of a CAD system for multi-
parametric MR prostate cancer. 14th Mediterranean Conference on Medical and
Biological Engineering and Computing, MEDICON 2016, March 31, 2016 - April 2,
2016 57, 296–301 (2016).
73. Loveymi, S., Dezfoulian, M. H. & Mansoorizadeh, M. Generate structured radi-
ology report from CT images using image annotation techniques: preliminary
results with liver CT. J. Dig. Imaging 33, 375–390 (2020).
74. MacCormick, I. J. C. et al. Accurate, fast, data efﬁcient and interpretable glau-
coma diagnosis with automated spatial analysis of the whole cup to disc proﬁle.
PLoS
ONE
14,
https://www.embase.com/search/results?subaction=viewre
cord&id=L625837308&from=exporthttps://doi.org/10.1371/journal.pone.
0209409 (2019).
75. Kunapuli, G. et al. A decision-support tool for renal mass classiﬁcation. J. Digit.
Imaging 31, 929–939 (2018).
76. Shen, T., Wang, J., Gou, C. & Wang, F.-Y. Hierarchical fused model with deep
learning and type-2 fuzzy learning for breast cancer diagnosis. IEEE Trans. Fuzzy
Syst. 28, 3204–3218 (2020).
77. Li, J., Shi, H. & Hwang, K.-S. An explainable ensemble feedforward method with
Gaussian convolutional ﬁlter. Knowl.-Based Syst. 225, https://doi.org/10.1016/
j.knosys.2021.107103NS (2021).
78. Puyol-Anton, E. et al. Assessing the impact of blood pressure on cardiac function
using interpretable biomarkers and variational autoencoders. 10th International
Workshop on Statistical Atlases and Computational Models of the Heart, STACOM
2019, held in conjunction with the 22nd International Conference on Medical
Image Computing and Computer Assisted Intervention, MICCAI 2019, October 13,
2019 12009 LNCS, 22–30 (2020).
79. Wongvibulsin, S., Wu, K. C. & Zeger, S. L. Improving clinical translation of
machine learning approaches through clinician-tailored visual displays of black
box algorithms: development and validation. JMIR Med. Inform. 8, e15791
(2020).
80. Lin, Y., Wei, L., Han, S. X., Aberle, D. R. & Hsu, W. EDICNet: An end-to-end
detection and interpretable malignancy classiﬁcation network for pulmonary
nodules in computed tomography. Medical Imaging 2020: Computer-Aided
Diagnosis, February 16, 2020 - February 19, 2020 11314, The Society of
Photo–Optical Instrumentation Engin. https://doi.org/10.1117/12.2551220NS
(2020).
81. Kim, S. T., Lee, H., Kim, H. G. & Ro, Y. M. ICADx: Interpretable computer aided
diagnosis of breast masses. Medical Imaging 2018: Computer-Aided Diagnosis,
February 12, 2018 - February 15, 2018 10575, DECTRIS Ltd.; The Society of
Photo–Optical Instrum. https://doi.org/10.1117/12.2293570NS (2018).
82. Kim, S. T., Lee, J.-H., Lee, H. & Ro, Y. M. Visually interpretable deep network for
diagnosis of breast masses on mammograms. Phys. Med. Biology 63, 235025
(2018).
83. Puyol-Antón, E. et al. Interpretable deep models for cardiac resynchronisation
therapy response prediction. Med. Image Comput. Comput. Assist Interv 2020,
284–293 (2020).
84. Wang, C. J. et al. Deep learning for liver tumor diagnosis part II: convolutional
neural network interpretation using radiologic imaging features. Eur. Radiol. 29,
3348–3357 (2019).
85. Codella, N. C. F. et al. Collaborative human-AI (CHAI): Evidence-based inter-
pretable melanoma classiﬁcation in dermoscopic images. 1st International
Workshop on Machine Learning in Clinical Neuroimaging, MLCN 2018, 1st Inter-
national Workshop on Deep Learning Fails, DLF 2018, and 1st International
Workshop on Interpretability of Machine Intelligence in Medical Image Computing,
iMIMIC 11038 LNCS, 97–105 (2018).
86. Barata, C., Celebi, M. E. & Marques, J. S. Explainable skin lesion diagnosis
using
taxonomies.
Pattern
Recognition
110,
https://doi.org/10.1016/
j.patcog.2020.107413NS (2021).
87. Silva, W., Fernandes, K., Cardoso, M. J. & Cardoso, J. S. Towards complementary
explanations using deep neural networks. 1st International Workshop on
Machine Learning in Clinical Neuroimaging, MLCN 2018, 1st International Work-
shop on Deep Learning Fails, DLF 2018, and 1st International Workshop on
Interpretability of Machine Intelligence in Medical Image Computing, iMIMIC
11038 LNCS, 133–140 (2018).
88. Khaleel, M., Tavanapong, W., Wong, J., Oh, J. & De Groen, P. Hierarchical visual
concept interpretation for medical image classiﬁcation. 34th IEEE International
Symposium on Computer-Based Medical Systems, CBMS 2021, June 7, 2021 - June
9, 2021 2021-June, 25–30 (2021).
89. Pereira, S. et al. Enhancing interpretability of automatically extracted machine
learning features: application to a RBM-Random Forest system on brain lesion
segmentation. Med. Image Anal. 44, 228–244 (2018).
90. Yan, K. et al. Holistic and comprehensive annotation of clinically signiﬁcant
ﬁndings on diverse CT images: Learning from radiology reports and label
ontology. 32nd IEEE/CVF Conference on Computer Vision and Pattern Recognition,
CVPR 2019, June 16, 2019 - June 20, 2019 2019-June, 8515–8524, https://doi.org/
10.1109/CVPR.2019.00872NS (2019).
H. Chen et al.
13
Published in partnership with Seoul National University Bundang Hospital
npj Digital Medicine (2022) 156

## Page 14 (Section: Acknowledgements)

91. Chen, H., Miao, S., Xu, D., Hager, G. D. & Harrison, A. P. Deep hiearchical multi-
label classiﬁcation applied to chest x-ray abnormality taxonomies. Med. Image
Anal. 66, 101811 (2020).
92. Verma, A., Shukla, P. & Verma, S. An interpretable SVM based model for cancer
prediction in mammograms. 1st International Conference on Communication,
Networks and Computing, CNC 2018, March 22, 2018 - March 24, 2018 839,
443–451 (2019).
93. Li, Y. et al. Computer-aided cervical cancer diagnosis using time-lapsed colpo-
scopic images. IEEE Trans. Med. Imaging 39, 3403–3415 (2020).
94. Wang, K. et al. A dual-mode deep transfer learning (D2TL) system for breast
cancer detection using contrast enhanced digital mammograms. IISE Trans.
Healthcare Syst. Eng. 9, 357–370 (2019).
95. Zhao, G., Zhou, B., Wang, K., Jiang, R. & Xu, M. Respond-CAM: Analyzing deep
models for 3D imaging data by visualizations. 21st International Conference on
Medical Image Computing and Computer Assisted Intervention, MICCAI 2018,
September 16, 2018 - September 20, 2018 11070 LNCS, 485–492 (2018).
96. Folke, T., Yang, S. C.-H., Anderson, S. & Shafto, P. Explainable AI for medical
imaging: Explaining pneumothorax diagnoses with Bayesian teaching. Artiﬁcial
Intelligence and Machine Learning for Multi-Domain Operations Applications III
2021, April 12, 2021 - April 16, 2021 11746, The Society of Photo–Optical
Instrumentation Engin. https://doi.org/10.1117/12.2585967NS (2021).
97. Liao, W. et al. Clinical interpretable deep learning model for glaucoma diagnosis.
IEEE J. Biomed. Health Inf. 24, 1405–1412 (2020).
98. Shinde, S., Chougule, T., Saini, J. & Ingalhalikar, M. HR-CAM: Precise localization
of pathology using multi-level learning in CNNS. 22nd International Conference
on Medical Image Computing and Computer-Assisted Intervention, MICCAI 2019,
October 13, 2019 - October 17, 2019 11767 LNCS, 298–306 (2019).
99. Ballard, D. H. Modular learning in neural networks. AAAI 647, 279–284 (1987).
100. Bifﬁ, C. et al. Learning interpretable anatomical features through deep gen-
erative models: Application to cardiac remodeling. 21st International Conference
on Medical Image Computing and Computer Assisted Intervention, MICCAI 2018,
September 16, 2018 - September 20, 2018 11071 LNCS, 464–471 (2018).
101. Couteaux, V., Nempont, O., Pizaine, G. & Bloch, I. Towards interpretability of
segmentation networks by analyzing deepDreams. 2nd International Workshop
on Interpretability of Machine Intelligence in Medical Image Computing, iMIMIC
2019, and the 9th International Workshop on Multimodal Learning for Clinical
Decision Support, ML-CDS 2019, held in conjunction with the 22nd Interna 11797
LNCS, 56–63 (2019).
102. Guo, X. et al. Intelligent medical image grouping through interactive learning.
Int. J. Data Sci. Anal. 2, 95–105 (2016).
103. Janik, A., Dodd, J., Ifrim, G., Sankaran, K. & Curran, K. Interpretability of a deep
learning model in the application of cardiac MRI segmentation with an ACDC
challenge dataset. Medical Imaging 2021: Image Processing, February 15, 2021 -
February 19, 2021 11596, The Society of Photo–Optical Instrumentation Engin.
https://doi.org/10.1117/12.2582227NS (2021).
104. Sari, C. T. & Gunduz-Demir, C. Unsupervised feature extraction via deep learning
for histopathological classiﬁcation of colon tissue images. IEEE Trans. Med.
Imaging 38, 1139–1149 (2019).
105. Venugopalan, J., Tong, L., Hassanzadeh, H. R. & Wang, M. D. Multimodal deep
learning models for early detection of Alzheimer’s disease stage. Sci. Rep. 11,
3254 (2021).
106. Zhu, P. & Ogino, M. Guideline-based additive explanation for computer-aided
diagnosis of lung nodules. 2nd International Workshop on Interpretability of
Machine Intelligence in Medical Image Computing, iMIMIC 2019, and the 9th
International Workshop on Multimodal Learning for Clinical Decision Support, ML-
CDS 2019, held in conjunction with the 22nd Interna 11797 LNCS, 39–47 (2019).
107. Pirovano, A., Heuberger, H., Berlemont, S., Ladjal, S. & Bloch, I. Improving
interpretability for computer-aided diagnosis tools on whole slide imaging with
multiple instance learning and gradient-based explanations. 3rd International
Workshop on Interpretability of Machine Intelligence in Medical Image Computing,
iMIMIC 2020, the 2nd International Workshop on Medical Image Learning with Less
Labels and Imperfect Data, MIL3ID 2020, and the 5th International Workshop o
12446 LNCS, 43–53 (2020).
108. Hao, J., Kosaraju, S. C., Tsaku, N. Z., Song, D. H. & Kang, M. PAGE-Net: inter-
pretable and integrative deep learning for survival analysis using histopatho-
logical images and genomic data. Paciﬁc Symposium on Biocomputing. Paciﬁc
Symposium on Biocomputing 25, 355–366 (2020).
109. de Sousa, I. P., Vellasco, M. M. B. R. & da Silva, E. C. Approximate explanations for
classiﬁcation of histopathology patches. Workshops of the 20th Joint European
Conference on Machine Learning and Knowledge Discovery in Databases, ECML
PKDD, September 14, 2020 - September 18, 2020 1323, 517–526 (2020).
110. Li, X., Dvornek, N. C., Zhuang, J., Ventola, P. & Duncan, J. S. Brain biomarker
interpretation in ASD using deep learning and fMRI. 21st International Con-
ference on Medical Image Computing and Computer Assisted Intervention, MICCAI
2018, September 16, 2018 - September 20, 2018 11072 LNCS, 206–214 (2018).
111. Quellec, G. et al. ExplAIn: Explanatory artiﬁcial intelligence for diabetic retino-
pathy diagnosis. Med. Image Anal. 72, https://www.embase.com/search/results?
subaction=viewrecord&id=L2012995582&from=exporthttps://doi.org/10.1016/
j.media.2021.102118 (2021).
112. Uzunova, H., Ehrhardt, J., Kepp, T. & Handels, H. Interpretable explanations of
black box classiﬁers applied on medical images by meaningful perturbations
using variational autoencoders. Medical Imaging 2019: Image Processing, Feb-
ruary 19, 2019 - February 21, 2019 10949, The Society of Photo–Optical Instru-
mentation Engin. https://doi.org/10.1117/12.2511964NS (2019).
113. Liu, J. et al. Ultrasound liver ﬁbrosis diagnosis using multi-indicator guided deep
neural networks. 10th International Workshop on Machine Learning in Medical
Imaging, MLMI 2019 held in conjunction with the 22nd International Conference
on Medical Image Computing and Computer-Assisted Intervention, MICCAI 2019,
October 13, 2019 - October 13, 2019 11861 LNCS, 230–237 (2019).
114. Liu, Y. et al. Act like a radiologist: towards reliable multi-view correspondence
reasoning for mammogram mass detection. IEEE Trans. Pattern Anal. Mach. Intell.
https://doi.org/10.1109/TPAMI.2021.3085783NS (2021).
115. Oktay, O. et al. Anatomically constrained neural networks (ACNNs): application
to cardiac image enhancement and segmentation. IEEE Trans. Med. Imaging 37,
384–395 (2018).
116. Peng, T., Boxberg, M., Weichert, W., Navab, N. & Marr, C. Multi-task learning of a
deep K-nearest neighbour network for histopathological image classiﬁcation
and retrieval. 22nd International Conference on Medical Image Computing and
Computer-Assisted Intervention, MICCAI 2019, October 13, 2019 - October 17, 2019
11764 LNCS, 676–684 (2019).
117. Liu, Y., Li, Z., Ge, Q., Lin, N. & Xiong, M. Deep Feature Selection and Causal
Analysis of Alzheimer’s Disease. Front. Neurosci. 13, https://www.embase.com/
search/results?subaction=viewrecord&id=L629992085&
from=exporthttps://doi.org/10.3389/fnins.2019.01198 (2019).
118. Ren, H. et al. Interpretable pneumonia detection by combining deep learning
and explainable models with multisource data. IEEE Access 9, 95872–95883
(2021).
119. Velikova, M., Lucas, P. J. F., Samulski, M. & Karssemeijer, N. On the interplay of
machine learning and background knowledge in image interpretation by
Bayesian networks. Artif. Intell. Med. 57, 73–86 (2013).
120. Carneiro, G., Zorron Cheng Tao Pu, L., Singh, R. & Burt, A. Deep learning
uncertainty and conﬁdence calibration for the ﬁve-class polyp classiﬁcation
from colonoscopy. Med. Image Anal. 62, https://www.embase.com/search/
results?subaction=viewrecord&id=L2005189093&from=exporthttps://doi.org/
10.1016/j.media.2020.101653 (2020).
121. Sabol, P. et al. Explainable classiﬁer for improving the accountability in decision-
making for colorectal cancer diagnosis from histopathological images. J.
Biomed.
Inf.
109,
https://www.embase.com/search/results?subaction=
viewrecord&id=L2007460563&from=exporthttps://doi.org/10.1016/j.jbi.2020.
103523 (2020).
122. Tanno, R. et al. Uncertainty modelling in deep learning for safer neuroimage
enhancement: Demonstration in diffusion MRI. NeuroImage 225, https://
www.embase.com/search/results?subaction=viewrecord&id=L2008373754&
from=exporthttps://doi.org/10.1016/j.neuroimage.2020.117366 (2021).
123. Doshi-Velez, F. & Kim, B. Towards a rigorous science of interpretable machine
learning. preprint athttps://arxiv.org/abs/1702.08608 (2017).
124. Adebayo, J. et al. Sanity checks for saliency maps. In Bengio, S. et al. (eds.)
Advances
in
Neural
Information
Processing
Systems,
vol.
31,
https://
proceedings.neurips.cc/paper/2018/ﬁle/294a8ed24b1ad22ec2e7efea049b8737-
Paper.pdf (Curran Associates, Inc., 2018).
125. Yeche, H., Harrison, J. & Berthier, T. UBS: A dimension-agnostic metric for con-
cept vector interpretability applied to radiomics. 2nd International Workshop on
Interpretability of Machine Intelligence in Medical Image Computing, iMIMIC 2019,
and the 9th International Workshop on Multimodal Learning for Clinical Decision
Support, ML-CDS 2019, held in conjunction with the 22nd Interna 11797 LNCS,
12–20 (2019).
126. Chen, H., Miao, S., Xu, D., Hager, G. D. & Harrison, A. P. Deep hierarchical multi-
label classiﬁcation of chest x-ray images. In International Conference on Medical
Imaging with Deep Learning, 109–120 (PMLR, 2019).
127. Zhang, Z. et al. Origa-light: An online retinal fundus image database for glau-
coma analysis and research. In 2010 Annual International Conference of the IEEE
Engineering in Medicine and Biology, 3065–3068 (IEEE, 2010).
128. Menze, B. H. et al. The multimodal brain tumor image segmentation benchmark
(brats). IEEE Trans. Med. Imaging 34, 1993–2024 (2014).
ACKNOWLEDGEMENTS
We acknowledge all authors for the contribution. No funding is included.
H. Chen et al.
14
npj Digital Medicine (2022) 156 
Published in partnership with Seoul National University Bundang Hospital

## Page 15 (Section: Author contributions)

AUTHOR CONTRIBUTIONS
All authors contributed to the conception and design of the study. H.C. and C.G.
contributed to the literature search and data extraction. H.C. and C.G. contributed to
data analysis and interpretation. All authors contributed to writing the manuscript,
and all authors approved the manuscript. All authors guaranteed the integrity of the
work. H.C. and C.G. contributed equally in this work and are co-ﬁrst authors.
COMPETING INTERESTS
The authors declare no competing interests.
ADDITIONAL INFORMATION
Supplementary information The online version contains supplementary material
available at https://doi.org/10.1038/s41746-022-00699-2.
Correspondence and requests for materials should be addressed to Mathias
Unberath.
Reprints and permission information is available at http://www.nature.com/
reprints
Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims
in published maps and institutional afﬁliations.
Open Access This article is licensed under a Creative Commons
Attribution 4.0 International License, which permits use, sharing,
adaptation, distribution and reproduction in any medium or format, as long as you give
appropriate credit to the original author(s) and the source, provide a link to the Creative
Commons license, and indicate if changes were made. The images or other third party
material in this article are included in the article’s Creative Commons license, unless
indicated otherwise in a credit line to the material. If material is not included in the
article’s Creative Commons license and your intended use is not permitted by statutory
regulation or exceeds the permitted use, you will need to obtain permission directly
from
the
copyright
holder.
To
view
a
copy
of
this
license,
visit
http://
creativecommons.org/licenses/by/4.0/.
© The Author(s) 2022
H. Chen et al.
15
Published in partnership with Seoul National University Bundang Hospital
npj Digital Medicine (2022) 156


---

# Fast Healthcare Interoperability Resources (FHIR) for Interoperability in Health Research: Systematic Review

- **Authors:** Carina Nina Vorisek, Moritz Lehne, Sophie Anne Ines Klopfenstein, Paula Josephine Mayer, Alexander Bartschke, Thomas Haese, Sylvia Thun
- **Issuer:** JMIR medical informatics
- **Type:** Scientific article
- **Published:** 2022-07-19
- **Language:** en
- **DOI:** 10.2196/35724
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35852842/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackgroundThe standard Fast Healthcare Interoperability Resources (FHIR) is widely used in health information technology. However, its use as a standard for health research is still less prevalent. To use existing data sources more efficiently for health research, data interoperability becomes increasingly important. FHIR provides solutions by offering resource domains such as “Public Health & Research” and “Evidence-Based Medicine” while using already established web technologies. Therefore, FHIR could help standardize data across different data sources and improve interoperability in health research.ObjectiveThe aim of our study was to provide a systematic review of existing literature and determine the current state of FHIR implementations in health research and possible future directions.MethodsWe searched the PubMed/MEDLINE, Embase, Web of Science, IEEE Xplore, and Cochrane Library databases for studies published from 2011 to 2022. Studies investigating the use of FHIR in health research were included. Articles published before 2011, abstracts, reviews, editorials, and expert opinions were excluded. We followed the PRISMA (Preferred Reporting Items for Systematic Reviews and Meta-Analyses) guidelines and registered this study with PROSPERO (CRD42021235393). Data synthesis was done in tables and figures.ResultsWe identified a total of 998 studies, of which 49 studies were eligible for inclusion. Of the 49 studies, most (73%, n=36) covered the domain of clinical research, whereas the remaining studies focused on public health or epidemiology (6%, n=3) or did not specify their research domain (20%, n=10). Studies used FHIR for data capture (29%, n=14), standardization of data (41%, n=20), analysis (12%, n=6), recruitment (14%, n=7), and consent management (4%, n=2). Most (55%, 27/49) of the studies had a generic approach, and 55% (12/22) of the studies focusing on specific medical specialties (infectious disease, genomics, oncology, environmental health, imaging, and pulmonary hypertension) reported their solutions to be conferrable to other use cases. Most (63%, 31/49) of the studies reported using additional data models or terminologies: Systematized Nomenclature of Medicine Clinical Terms (29%, n=14), Logical Observation Identifiers Names and Codes (37%, n=18), International Classification of Diseases 10th Revision (18%, n=9), Observational Medical Outcomes Partnership common data model (12%, n=6), and others (43%, n=21). Only 4 (8%) studies used a FHIR resource from the domain “Public Health & Research.” Limitations using FHIR included the possible change in the content of FHIR resources, safety, legal matters, and the need for a FHIR server.ConclusionsOur review found that FHIR can be implemented in health research, and the areas of application are broad and generalizable in most use cases. The implementation of international terminologies was common, and other standards such as the Observational Medical Outcomes Partnership common data model could be used as a complement to FHIR. Limitations such as the change of FHIR content, lack of FHIR implementation, safety, and legal matters need to be addressed in future releases to expand the use of FHIR and, therefore, interoperability in health research.Keywords: Fast Healthcare Interoperability Resources, FHIR, interoperability, health research, health care, health information technology, research, clinical research, public health, epidemiology

## Section: Introduction

Within the current COVID-19 pandemic, there was a broad realization of the currently limited data collection processes and how powerful the exchange of scientific data could be if interoperability between health care and research was provided [1]. Although there was a large amount of data in the health care ecosystem, there was lack of data that adheres to Findable, Accessible, Interoperable, and Reusable [2] principles for users to find, use, analyze, and share data on COVID-19. This applies specifically to academic health research where the lack of interoperability between health care and research often inhibits the use of existing data sources for research. Commonly, the data collections of health research are stored in decentralized, autonomous data infrastructures which requires integration into common frameworks to enable centralized search and access.

However, processing national and cross-national scientific data across different institutions and software systems requires international standards and terminologies: the Observational Health Data Sciences and Informatics (OHDSI) Observational Medical Outcomes Partnership (OMOP) common data model (CDM) is used in observational research, whereas the Clinical Data Interchange Standards Consortium (CDISC) Operational Data Standard (ODM) is used specifically for the exchange of data within clinical trials [3]. CDISC is providing standards such as standardized raw data sets (Study Data Tabulation Model; SDTM), also considered a CDM, as well as standardized analysis data sets models. Further established standards are the terminologies Systematized Nomenclature of Medicine Clinical Terms (SNOMED CT) and Logical Observation Identifiers, Names, and Codes (LOINC). SNOMED CT is the most comprehensive clinical health care terminology worldwide providing more than 350,000 concepts, whereas LOINC is a standard for laboratory tests and clinical observations. One of the latest emerging standards for the exchange of health data is the standard Fast Healthcare Interoperability Resources (FHIR).

FHIR is a standard used in health information technology introduced in 2011 by the Standard Developing Organization Health Level Seven International (HL7). FHIR is based on previous HL7 standards (HL7 versions 2 and 3 and Clinical Document Architecture) and combines their advantages with established modern web technologies such as a Representational State Transfer (REST) architecture; application programming interface (API), XML, and JSON formats; and authorization tools (Open Authorization). In FHIR, all exchangeable content is defined by distinct basic building blocks—referred to as resources—which define the content and structure of information and can refer to each other using reference mechanisms [4].

The base FHIR specification serves as a foundation providing basic resources, frameworks, APIs, and a platform in which different solutions can be implemented [5]. To cover information not included in the basic resources, FHIR provides a built-in extension mechanism and can be adapted for specific use cases while ensuring interoperability. Additional rules and constraints within resources can be defined in profiles. Therefore, FHIR covers various domains of health care with its resources and can be used for different purposes and in various contexts and workflows.

With regard to health research, there is still a lack of use of international standards when exchanging data between health care and research institutions. However, there have been recent regulative and legislative changes promoting standards and interoperability in health care [6-8]. In addition, there are initiatives of HL7 promoting FHIR’s use in health research, such as the Vulcan HL7 FHIR Accelerator aiming to connect clinical research and health care, the MedMorph project aiming to advance public health by using standards such as FHIR, and the collaboration of HL7 and OHDSI on a single common data model [9-11]. As many research platforms and modern data management systems, such as the Extensible Neuroimaging Archive Toolkit open-source imaging informatics platform, use extensible REST APIs [12,13], FHIR may be the new standard to fill the interoperability gap in health research with its REST architecture. Existing reviews on FHIR investigate the general use of FHIR in digital health [14] or its use in electronic health records [15]. However, to the best of our knowledge, the use of FHIR in health research has not been systematically investigated. Therefore, the aim of our study was to provide a systematic review of existing literature to determine the current state of use cases, implementation, goals, and limitations of FHIR in health research.

## Section: Methods › Protocol, Registration, and Ethical Considerations

This systematic review was conducted in accordance with the (PRISMA) Preferred Reporting Items for Systematic Reviews and Meta-Analyses guidelines [16]. The review was registered with the International Prospective Register of Systematic Reviews (PROSPERO; CRD42021235393) [17]. As data originated from published studies, ethical approval for this study was not requested.

## Section: Methods › Inclusion and Exclusion Criteria

We included studies investigating the use of FHIR in health research. We did not focus on particular patient populations, interventions, control groups, or outcomes, except the use of FHIR in health research. Details on inclusion and exclusion criteria are presented in Textbox 1.

## Section: Methods › Information Sources and Search Strategy

A comprehensive literature search was performed through the PubMed/MEDLINE, Embase, Web of Science, IEEE Xplore, and Cochrane Library databases. In addition, citation tracking and reference list checking were performed. The goal of the search strategy was to retrieve all relevant studies related to our research question published between 2011 and 2022. Search terms were therefore relatively broad to make sure that all potentially relevant studies were identified. Search terms used for the database searches were “FHIR” and “Fast Healthcare Interoperability Resources.” Information on the detailed search strategy for each database is provided as an appendix to this review (Multimedia Appendix 1). The search was conducted on February 26, 2022.

## Section: Methods › Study Selection and Data Collection Process

Study selection included 2 screening levels: (1) screening of titles and abstracts of all studies identified in the literature search and (2) full-text review of studies that had not been excluded in the first step. Review at the first stage of screening was performed independently by 2 authors (ML and SAIK) using the Rayyan web app [18]. Remaining disagreements were resolved by a third author (CNV). Further full-text screening at the second stage and data extraction were performed by 6 authors (CNV, ML, SAIK, PJM, AB, and TH), and disagreements of at least two authors at this stage were resolved by the last author (ST).

## Section: Methods › Data Extraction and Analysis

Data synthesis was conducted in tables and figures. For categorical variables, simple and relative frequencies and proportions were used. To identify the networks of coauthors, we also performed a network analysis that investigated, for all authors of the included studies, whether they were coauthors in a study. Results were visualized in a network graph. We did not assess bias in studies due to the lack of quantitative tools applicable to technical papers on standards. All analyses were done with R statistical software (version 4.0.5; R Foundation for Statistical Computing) [19] and the tidyverse packages [20]. All data and analyses scripts are provided in a GitHub repository [21].

## Section: Results

PRISMA (Preferred Reporting Items for Systematic Reviews and Meta-Analyses) flow diagram for identifying articles eligible for inclusion. FHIR: Fast Healthcare Interoperability Resources.

Number of publications per year (all: all FHIR publications identified in the databases with the search terms “FHIR” OR “Fast Healthcare Interoperability Resources”; included: studies included in this review). FHIR: Fast Healthcare Interoperability Resources.

Network of coauthorships. Each point represents an author. Point size and color indicate the number of publications of this author (between 1 and 6). Lines indicate that authors have coauthored at least one paper together. Line thickness represents the number of coauthorships.

Number of studies according to research domain.

Numbers of studies according to area of FHIR application, medical specialty, and international standard.

Characteristics of studies.

## Section: Results › Study Selection and Extraction

A total of 998 articles were identified through the database searches (344 from MEDLINE, 359 from Embase, 201 from Web of Science, 84 from IEEE Xplore, and 10 from Cochrane Library). No additional records were identified through citation tracking and reference list checking. We excluded 477 duplicates and 422 articles that did not meet the inclusion criteria or met the exclusion criteria. Among the 99 full-text articles assessed for eligibility, an additional 50 studies were excluded. Finally, 49 [1,12,22-68] articles met the inclusion criteria and were included in the systematic review (Figure 1). Details on the exclusion reasons for the full-text evaluation can be found in Multimedia Appendix 2, and the exclusion reasons for the abstract evaluation can be found in the GitHub repository [21].

PRISMA (Preferred Reporting Items for Systematic Reviews and Meta-Analyses) flow diagram for identifying articles eligible for inclusion. FHIR: Fast Healthcare Interoperability Resources.

## Section: Results › Characteristics of Included Studies

Publication dates ranged from 2016 to 2022 with the median in 2020. Of the 49 included studies, 73% (n=36) were published between 2020 and 2022. The increase of publications from 2020 onward is visualized in Figure 2, showing the temporal trend of all FHIR publications identified in the databases with the search terms “FHIR” OR “Fast Healthcare Interoperability Resources” and the number of publications included into the analysis per year.

The results of the network analysis of coauthorships are shown in Figure 3. Of a total of 256 authors, most (85%, n=217) appeared only once in the included studies, and no author occurred more than 6 times within the included studies. Most coauthorship networks were restricted to individual studies, with occasional connections between networks (ie, authors having published studies with different groups of coauthors).

Of the 49 studies, the majority were conducted in Germany (47%, n=23) [12,26,28-31,34,35,40-42,45-47,52,53,56-58,60,62, 63,69], the United States (27%, n=13) [22,25,36,44,48-50,61, 64-66,68,70], and Australia (6%, n=3) [1,43,67]. The remaining studies were performed in Austria (2%, n=1) [32], Canada (2%, n=1) [24], France (2%, n=1) [51], Greece (2%, n=1) [59], Japan (2%, n=1) [27], Pakistan (2%, n=1) [38], Spain (2%, n=1) [55], Switzerland (2%, n=1) [39], Taiwan (2%, n=1) [23], and the United Kingdom (2%, n=1) [37].

Number of publications per year (all: all FHIR publications identified in the databases with the search terms “FHIR” OR “Fast Healthcare Interoperability Resources”; included: studies included in this review). FHIR: Fast Healthcare Interoperability Resources.

Network of coauthorships. Each point represents an author. Point size and color indicate the number of publications of this author (between 1 and 6). Lines indicate that authors have coauthored at least one paper together. Line thickness represents the number of coauthorships.

## Section: Results › Research Domain and Area of FHIR Application

Of the 49 studies, most (73%, n=36) studies covered the research domain of clinical research, of which 10 (20%) studies were clinical trials [22,29-31,36,39,43,56,65,66]; 3 (6%) studies focused on solutions in public health and epidemiology [38,40,64], and the remaining studies did not specify their research domain (20%, n=10; Figure 4) [24,32,41,42,45-47, 50,63,69]. The included studies used FHIR for the standardization of data (41%, n=20) [23,26,30,34,41,45-48, 51-53,57-60,63,66,67,70], data capture (29%, n=14) [1,12,22,24,27,35-37,43,44,55,61,64,65], recruitment (14%, n=7) [28,29,31,32,49,56,62], analysis (12%, n=6) [25,38,42,50,68,69], and consent management (4%, n=2; Table 1) [39,40]. Details on the included studies are presented in Table 2.

Number of studies according to research domain.

Numbers of studies according to area of FHIR application, medical specialty, and international standard.

Characteristics of studies.

## Section: Results › Study Objectives

In terms of medical specialty, most (55%, 27/49) of the studies [24,27-32,34,36-42,44,46,48,49,53,56,60-63,67,70] were using a generic approach—implementable in any kind of specialty (Table 2). Of the remaining studies, 16% (8/49) use cases focused on infectious disease [1,22,23,26,45,47,50,59], whereas 12% (6/49) focused on oncology [25,55,57,58,65,66] and 8% (4/49) on genomics [43,52,68,69]. Further medical specialties were environmental health (2%, 1/49) [64], genomic cancer medicine (2%, 1/49) [51], neuroimaging research (2%, 1/49) [12], and pulmonary hypertension (2%, 1/49) [35]. Despite studies implementing FHIR in specific use cases, 55% (12/22) of the studies [1,12,22,23,25,35,43,50,52,58,64,69] reported generic solutions conferrable to other use cases. Details on study objectives with regards to FHIR use can be found in Table 2 and Multimedia Appendix 3.

## Section: Results › International Standards

Among the 49 studies, 37% (n=18) did not report on or use additional standards or terminologies [12,22-24,27,28,30-32, 38,39,48,50,55,57,64,66,69]. SNOMED CT [1,25,26,35,37,43, 45-47,51,55,56,65,70] and LOINC [25,26,35,37,42-45, 47,49,51,55,56,58,61,65,68,70] were reported to be used by 29% (n=14) and 37% (n=18) of the studies, respectively; 18% (n=9) of the studies used International Classification of Diseases 10th Revision [25,26,35,37,49,51,58,65,68] and 12% (n=6) used OMOP CDM [26,29,35,47,52,60]; and 43% (n=21) of the studies used additional standards which were categorized under “Other” (Table 1) [26,34-37,40,42,43,45-47,49,51,56,58-60, 62,63,67,70]. The implemented FHIR resources by each study are listed in Table 2; 5 (10%) studies did not precisely list their FHIR resources used [36,38,56,64,69]. Information on the FHIR version used was provided by 45% (n=22) of the studies [22,23,25,26,28,30,32,35,40,42,48,49,57,59,60,66,68,70], which can be found in Multimedia Appendix 4.

## Section: Results › Limitations of FHIR Use

With regard to the limitations of FHIR use, Bild et al [28], Lackerbauer et al [32], and Metke-Jimenez et al [43] reported the possible content changes of new versions of FHIR resources. Generalizability was a concern in the studies of Khalique et al [38] and Zong et al [65]. The need for a FHIR server [69] and the requirement for a protocol for deidentification [1] were additional limitations. Reinecke et al [29] had not tested the exchange of data between locations and therefore could not provide information in terms of use and results of their prototype. Wagholikar et al [36] implemented a limited subset of FHIR resources in their platform and therefore the filtering of FHIR resources using complex query formats was not supported. In terms of electronic consents, safety and legal matters were major concerns [39]. Zong et al [68], investigating the discovery of genotype-phenotype associations, reported the lack of information on differences in genetic data as well as extra mapping efforts since the data were from multiple sources. In addition, there was a lack of resources preventing the demonstration of use in the study. Generalizability was also a concern in this study in terms of exploring the FHIR framework within other variants and noncancer phenotypes in future work.

## Section: Discussion › Principal Findings

This systematic review summarizes the current state of use cases implementing FHIR in health research. As FHIR was developed in 2011, we included studies from 2011 to 2022 and found that half of studies were published between 2020 and 2022, displaying an increased use of FHIR in the past years. Interestingly, the first publication of our included studies emerged in 2016, indicating a 5-year latency between the publication of the FHIR standard and the publication of studies addressing its use in health research. Germany and the United States were the countries with the highest number of publications, which might be due to recent regulatory measurements and initiatives: in the United States, the 21st Century Cures Act requires the use of FHIR for health data; and in Germany, the medical informatics initiative aiming to close the gap between research and health care used FHIR in their already established use cases. Our network analysis showed that authorships were dispersed relatively equally across studies, not dominated by individual research groups or authors.

Most studies aimed to primarily standardize their data for health research and reported using additional international standards and terminologies. Within studies using FHIR for data capture, the FHIR resource “Questionnaire” was often used. Further areas of FHIR use were analysis, recruitment, and consent management. The literature shows that fast and efficient patient screening for clinical trial recruitment support systems is important, and there is a current lack of standards and interoperability of in these systems, as well as with regard to eligibility criteria [72].

The majority of studies followed a more generic approach rather than implementing FHIR for a specific use case. The studies establishing use cases focused on infectious diseases, specifically COVID-19, as well as genomics, oncology, and imaging—which are all specialties more advanced in terms of digitalization. Among these use cases, only a small number of studies reported limited generalizability of their results.

Though provided by FHIR specifically for research, resources out of the domains “Public Health & Research” and “Evidence-Based Medicine” were used in only 4 studies. A recently published study investigated the feasibility of the FHIR resource “ResearchStudy” in a metadata registry for COVID-19 research and found that there was a need for the use of extensions on more than 20% of the data items [41]. However, the resources “ResearchStudy” and “ResearchSubject” are currently under revision and will likely be tailored more to researchers’ needs when released with FHIR version R5 in 2022 [73].

Our analysis found that FHIR was used as a complement to other standards. Studies reporting on terminologies mostly used SNOMED CT and LOINC, both terminologies supported by FHIR within its value sets. There were 6 studies that used FHIR in addition to OMOP CDM, a standard widely used in observational research. Using OMOP CDM, a recommended way of transforming and transferring data from existing databases—Extract-Transform-Load tools are used for each source separately. To connect multiple heterogeneous databases, FHIR can be used as an intermediate format for local data extraction [35]. Reinecke et al [29] also extended the OMOP CDM with FHIR to exchange electronic health record data to connect the CDM to several health care systems. However, there were also limitations as Leroux et al [67] mapped CDISC SDTM and FHIR and found that CDISC SDTM’s use of controlled terminology is inhibiting semantic interoperability solutions; FHIR uses semantic standards accepted in health care that are usually precoordinated (eg, SNOMED CT and LOINC), whereas CDISC SDTM uses only controlled terminology in postcoordination. Therefore, there would be the need for sponsors to translate terminologies used within systems. Leroux et al [67] proposed the new FHIR resources “ClinicalStudyPlan” and “ClinicalStudyData”—equivalent to ODM “Study” and “ClinicalData” elements—which could overcome the semantic incompatibility. However, mappings with data transformation may lead to information loss and errors; therefore, developing ODM toward FHIR would be preferable, and the draft of ODM version 2.0 already includes better support for FHIR [74,75]. In addition, HL7 and CDISC have jointly released a mapping implementation guide to help transform FHIR content into CDISC Clinical Data Acquisition Standards Harmonization Implementation Guide or SDTM Implementation Guide data sets. [76,77].

With regard to limitations using FHIR, there were certain drawbacks reported by the included studies such as the possible change in the content of different versions of FHIR resources, safety, legal matters, and the need for a FHIR server. Not all studies tested the use of FHIR in practice and, therefore, could not provide results on the actual FHIR implementation.

## Section: Discussion › Limitations

One limitation of our study is the lack of quality evaluation due to missing established tools for evaluating technical papers on standardization in health care. For technical evaluations, structured information on additional standards, software, and FHIR version was missing in several studies. Therefore, our analysis on additional used standards might be biased as half of the studies did not report on using other international standards or terminologies. In addition, there were studies that did not list their FHIR resources clearly or at all. We aimed to guarantee an optimal systematic review process targeting academic peer-reviewed literature that is available in English; however, limitations remained as we may have missed relevant studies that were not published in the target language. Furthermore, we assumed that the published literature provides a surplus on successful FHIR initiatives because, in general, unsuccessful initiatives tend to stay unpublished [78]. Thus, our review may suffer from publication bias. In addition, this study investigated studies with a clear focus on FHIR in health research. However, there might be research projects using FHIR without FHIR being the central message or included in title and abstract.

## Section: Discussion › Conclusions

To the best of our knowledge, this is the first systematic review investigating the use of FHIR in health research. It was shown that FHIR has been successfully implemented in clinical, public health, and epidemiological research at the stages of recruitment and consent management, data capture, and standardization as well as analysis of patient data. The implementation of international terminologies such as SNOMED CT and LOINC is common and, together with the REST API, stands out in comparison with other health research standards. Other standards such as OMOP CDM were used as a complement to FHIR in some studies, and a future aim could be the development of an infrastructure for the seamless integration and communication of health information across different standards. This approach is reinforced by the current development of collaborations of different Standards Developing Organizations such as OHDSI and FHIR and the improved support of FHIR in combination with CDISC. Resources of the domain “Public Health & Research” and “Evidence-Based Medicine” were rarely used and could further elevate interoperability in health research, specifically after their modifications in FHIR version R5. However, this approach will need to address current limitations but could, if successfully implemented, elevate digitalized health research.

## Section: Acknowledgments

This work was done as part of the National Research Data Infrastructure for Personal Health Data Consortium [79]. We gratefully acknowledge the financial support of the Deutsche Forschungsgemeinschaft (German Research Foundation; NFDI 13/1).


---

# How Compounding Pharmacies Fill Critical Gaps in Pediatric Drug Development Processes: Suggested Regulatory Changes to Meet Future Challenges

- **Authors:** Robert B MacArthur, Lisa D Ashworth, Keming Zhan, Richard H Parrish
- **Issuer:** Children (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2022-12-01
- **Language:** en
- **DOI:** 10.3390/children9121885
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36553327/
- **Licence:** CC-BY

## Page 1 (Section: Introduction and Statement of the Problem )

Citation: MacArthur, R.B.; Ashworth,
L.D.; Zhan, K.; Parrish, R.H., II. How
Compounding Pharmacies Fill
Critical Gaps in Pediatric Drug
Development Processes: Suggested
Regulatory Changes to Meet Future
Challenges. Children 2022, 9, 1885.
https://doi.org/10.3390/
children9121885
Academic Editor: Hassan Almoazen
Received: 25 October 2022
Accepted: 29 November 2022
Published: 1 December 2022
Publisher’s Note: MDPI stays neutral
with regard to jurisdictional claims in
published maps and institutional afﬁl-
iations.
Copyright:
© 2022 by the authors.
Licensee MDPI, Basel, Switzerland.
This article is an open access article
distributed
under
the
terms
and
conditions of the Creative Commons
Attribution (CC BY) license (https://
creativecommons.org/licenses/by/
4.0/).
children
Opinion
How Compounding Pharmacies Fill Critical Gaps in Pediatric
Drug Development Processes: Suggested Regulatory Changes
to Meet Future Challenges
Robert B. MacArthur 1,*, Lisa D. Ashworth 2, Keming Zhan 3 and Richard H. Parrish II 4,*
1
Department of Pharmacy Services, Rockefeller University Hospital, New York, NY 10065, USA
2
Department of Pharmacy Services, Children’s Health System of Texas, Dallas, TX 75235, USA
3
Department of Biostatistics, Columbia University, New York, NY 10027, USA
4
Department of Biomedical Sciences, Mercer University School of Medicine, Columbus, GA 31902, USA
*
Correspondence: rmacarthur@rockefeller.edu (R.B.M.); parrish_rh@mercer.edu (R.H.P.II);
Tel.: +1-(201)-694-2383 (R.B.M.); +1-(706)-223-5185 (R.H.P.II)
Abstract: Drugs administered to children in the United States fall into two broad categories: (1) those
that have followed the US Food and Drug Administration (US-FDA) pediatric drug approval process
and are marketed as ﬁnished dosage forms with pediatric labeling; and (2) all others, many of which
are used “off-label”. The use of most drug products in pediatrics is still off label, often requiring special
preparation, packaging, and, in some cases, compounding into preparations. The latter category
includes compounded preparations that incorporate either a US-FDA approved ﬁnished dosage
form (e.g., a sterile solution, sterile powder, nonsterile capsules, oral solution, crushed tablets, etc.),
or rely on bulk active pharmaceutical ingredients (APIs). Compounded preparations are prepared
for individual patients in 503A pharmacies, or on a larger scale and not just for speciﬁc patients, in
licensed 503B establishments. Critical gaps in the current drug approval process for ﬁnished dosage
forms have created a proverbial “Gordian knot” that needs to be untangled thoughtfully to facilitate
increased production and approval of vitally needed medications for pediatric patients. This opinion
will describe current regulatory processes pertaining to pediatrics-only drug approval in the United
States. Additionally, discussed are steps required for a product to acquire pediatric labeling. Gaps
in regulatory approval pathways for both manufactured and compounded pediatric drugs will be
identiﬁed, especially those that complicate and slow development and availability to patients. Finally,
suggestions for regulatory modiﬁcations that may enhance pediatric product development strategies
for both manufacturers and compounders are suggested.
Keywords: compounding; drug; drug approval; drug shortages; FDAMA; manufactured material;
regulation; pediatric; 503A; 503B
1. Introduction and Statement of the Problem
Great progress has been made in the past 25 years to increase the number of US Food
and Drug Administration (US-FDA) approved drugs developed speciﬁcally for children.
Much of this is attributable to regulatory mandates and incentives enacted via the Pediatric
Rule in 1994, the Food and Drug Administration Modernization Act (FDAMA) of 1997, the
Best Pharmaceuticals for Children Act of 2002 (BPCA), the Pediatric Research Equity Act of
2003 (PREA) [1,2] and the Rare Pediatric Disease Priority Review Voucher Program of 2012
(PRV) [3]. These regulations and acts have increased investment in pediatric drug research
and development and have led to both many important pediatric labeling changes for
existing products as well as newly approved pediatric drug products. However, signiﬁcant
gaps still exist. Indeed, the vast majority of approved drug products are not designed or
developed for pediatric and infant populations [4]. These ﬁnished dosage forms often need
to be transformed into compounded preparations at 503A pharmacies (hospitals, home
Children 2022, 9, 1885. https://doi.org/10.3390/children9121885
https://www.mdpi.com/journal/children

## Page 2 (Section: US-FDA Drug Approval Pathway )

Children 2022, 9, 1885
2 of 13
care agencies, retail, specialty medication, investigational, and infusion centers) and 503B
outsourcing facilities.
Pediatric compounding performed in these establishments maintains a critical role in
ﬁlling these gaps. These pharmacies and outsourcing facilities tailor medicine that can be
administered to a child (newborns, infants, children, and adolescents), and thereby foster
improved patient compliance and safe use [5–8].
The main objective of this paper is to compare these two pathways to identify regu-
latory ambiguities and challenges, and to propose regulatory improvements to facilitate
further development of manufactured products and compounded preparations designed
for children.
2. US-FDA Drug Approval Pathway
This section describes the US-FDA drug approval process in general terms. More
detailed reviews of the overall drug approval process for New Drug Applications (NDA),
Biologics License Applications (BLAs), Abbreviated New Drug Applications (ANDAs), and
505(b)(2) applications are available from other sources [7,9–11]. (A subset of this pathway
encompasses orphan drug development which will not be included in this review [12].)
2.1. Phases for US-FDA Approval
US-FDA approves a new drug and its labeling for public use only after careful review
of data from preclinical studies in animals and human clinical trials which permit an
assessment of the risks and beneﬁts of the drug product [13]. US-FDA’s direct involvement
begins near the time the drug sponsor submits the results from preclinical testing in
an investigational new drug (IND) application. The IND also contains a description of
the drug’s chemical, physical, and biochemical properties and factors inﬂuencing the
pharmacokinetics (PK) and pharmacodynamics of the drug. Additionally, included are
plans for human clinical trials, and information about the proposed manufacturing or
compounding process. For pediatric products a Pediatric Study Plan needs to be submitted
by the end of Phase 2. Human trials can start 30 days after initial submission of the IND
unless US-FDA issues a Clinical Hold response.
With an active IND in place, drugs then undergo a multistage process of human
clinical testing. The ﬁrst clinical trials, Phase 1 trials, are designed to assess drug safety,
drug absorption, distribution, metabolism, and excretion (ADME), and evaluate different
dosing levels. Typically, these studies are performed in a small number of healthy adult
volunteers, although under specialized circumstances pediatric patient populations may be
enrolled [14]. Phase 2 trials gather initial data about potential drug beneﬁts, (e.g., efﬁcacy)
along with continued collection of safety data in a larger number of individuals who have
the condition or disease the dosage form is intended to treat. These trials may continue to
evaluate a range of doses to determine the optimal dose with respect to both efﬁcacy and
safety, suitable for study in Phase 3.
Phase 3 trials are typically randomized controlled trials that compare the safety and
efﬁcacy of the drug with a placebo or another drug product approved for the proposed
indication. These trials may also study different populations and different dosages of the
drug; in some cases, the drug may be studied in combination with other approved drugs
to see if the combination improves outcomes. Phase 3 studies vary in size, depending on
the number of patient available for study, and the magnitude of the effect of interest; some
phase 3 studies are small, while others recruit thousands of research participants. Phase 3
trials are intended to provide the primary clinical evidence of the safety and effectiveness
of the drug [15].
If clinical trial results are positive and the drug demonstrates suitable safety and
efﬁcacy, the sponsor may ﬁle a new drug application (NDA) proposing that US-FDA
approve a new drug product for marketing in the United States. The NDA is much more
extensive than the IND, and it includes the results of all toxicology and clinical studies.
Additionally, in the NDA Chemistry, Manufacturing, and Controls section (e.g., CMC),

## Page 3 (Section: US-FDA Drug Approval Pathway )

Children 2022, 9, 1885
3 of 13
updated information is included about the active ingredient and drug product (ﬁnal dosage
form) physiochemical properties, which are now much better understood than at the time
of IND ﬁling, with detailed descriptions of drug product manufacturing, processing, and
packaging. In addition, since many investigational study protocols require some type
of compounding for oral or sterile drug delivery, storage and applicable compounding
instructions are included. Other NDA sections include identiﬁcation of the investigators
conducting the research and proposed labeling.
If US-FDA approves the drug product, further safety monitoring (phase 4 of the
process) continues as sponsors are required to submit regular safety updates to US-FDA,
summarizing the adverse event reports and complaints received. Additionally, if US-FDA
requires additional post-marketing studies as a condition of approval, sponsors must
oversee that work to completion, according to the timeline provided by US-FDA. On
average, for innovative drug products, the time from IND ﬁling to drug approval, is
9.1 years (range 5 to 20 years) with an average cost of USD $1.3 billion [10,16]. For pediatric
drug products, in addition to the highly regulated, time, and resource intensive IND and
NDA requirements noted above, US-FDA has issued a number of pediatric-speciﬁc drug
development guidance documents (Table 1) that must be taken into consideration. Sponsors
must carefully review and apply this guidance where indicated to their IND and NDA
programs, to prevent delays in the US-FDA review process, due to noncompliance with
guidance document requirements. (https://www.fda.gov/science-research/science-and-
research-special-topics/pediatrics. Accessed on 29 November 2022).
Table 1. US-FDA Pediatric Guidance Documents, 2022.
•E11 Clinical Investigation of Medicinal Products in the Pediatric Population
•How to Comply with the Pediatric Research Equity Act
•Nonclinical Safety Evaluation of Pediatric Drug Products
•Over-the-Counter Pediatric Oral Liquid Drug Products Containing Acetaminophen
•Pediatric Gastroesophageal Reﬂux Disease: Developing Drugs for Treatment Guidance for Industry
•Pediatric Rare Diseases—A Collaborative Approach for Drug Development Using Gaucher Disease as a Model; Draft Guidance
for Industry
•Clariﬁcation of Orphan Designation of Drugs and Biologics for Pediatric Subpopulations of Common Diseases: Guidance
for Industry
•E11(R1) Addendum: Clinical Investigation of Medicinal Products in the Pediatric Population
•Atopic Dermatitis: Timing of Pediatric Studies During Development of Systemic Drugs
•Pediatric HIV Infection: Drug Development for Treatment
•Pediatric Information Incorporated Into Human Prescription Drug and Biological Products Labeling Good Review Practice
•Rare Pediatric Disease Priority Review Vouchers: Draft Guidance for Industry
•Drugs for Treatment of Partial Onset Seizures: Full Extrapolation of Efﬁcacy from Adults to Pediatric Patients 2 Years of Age and
Older Guidance for Industry
•Cancer Clinical Trial Eligibility Criteria: Minimum Age Considerations for Inclusion of Pediatric Patients
•Pediatric Study Plans: Content of and Process for Submitting Initial Pediatric Study Plans and Amended Initial Pediatric
Study Plans
•S11 Nonclinical Safety Testing In Support of Development of Pediatric Pharmaceuticals: International Council for Harmonization;
Draft Guidance for Industry
•FDARA Implementation Guidance for Pediatric Studies of Molecularly Targeted Oncology Drugs: Amendments to Sec. 505B of
the FD&C Act: Guidance for Industry
•Development of Anti-Infective Drug Products for the Pediatric Population: Guidance for Industry
•E11A Pediatric Extrapolation
•General Clinical Pharmacology Considerations for Pediatric Studies of Drugs, Including Biological Products
•Ethical Considerations for Clinical Investigations of Medical Products Involving Children: Draft Guidance for Industry, Sponsors,
and IRBs
The lack of pediatric drug development efforts by the pharmaceutical industry was
recognized by legislators and regulators going back to at least the 1970s [17]. Over the
course of 40 years, a series of incentive programs tailored for the pharmaceutical and
venture capital industries were put into place. These incentives began with the Pediatric

## Page 4 (Section: US-FDA Drug Approval Pathway )

Children 2022, 9, 1885
4 of 13
Labeling Rule, and thereafter advanced and expanded via The Pediatric Rule, BPCA, PREA,
and PRV (Table 2).
Table 2. Policies promoting evidence-based pediatric drug research and approvals for patented
medications [1,17–19].
Policy
Description
Pediatric Rule (1994)
- Permitted additions to pediatric labeling based upon extrapolation of efﬁcacy in adult populations
together with additional pediatric PK, pharmacodynamic, and safety studies.
- Requires that disease and drug response in adults is known to be similar in children.
- Compliance is voluntary.
Pediatric Rule in The Food
and Drug Administration
Modernization Act (1997)
(not currently in effect)
- Required sponsors of a new drug to submit, prior to approval, safety and effectiveness
information in relevant pediatric population(s) for the claimed indications. However, submission of
the pediatric data could be deferred if certain criteria applied.
- US-FDA developed a list of drugs where additional of pediatric information would be beneﬁcial.
- Sponsors received a Written Request (WR) for pediatric studies along with a required time
to completion.
- Sponsors that completed the WR requirement received an additional 6 months of
marketing exclusivity.
Best Pharmaceuticals for
Children Act (2002)
- Provides a ﬁnancial incentive to companies to voluntarily conduct pediatric studies.
- Incentive extends market exclusivity for 6 months after patents expire for pediatrics.
- The exclusivity is granted for an active pharmaceutical ingredient and applies to all US-FDA
approved drug products containing the ingredient.
- US-FDA requests may apply to both approved and unapproved indications.
- BPCA is evaluated for renewal every 5 years.
Pediatric Research Equity
Act (PREA) (2003)
- Requires sponsors to perform studies involving children to assess the safety and effectiveness of a
drug or biologic product for the claimed indications.
- Requires studies only for the indication(s) under review in adults.
- Applies to applications and supplements for a new active ingredient, new indication, new dosage
form, new dosing regimen, and new route(s) of administration.
- US-FDA may issue a waiver or deferral for some or all studies involving children. Orphan
indications are exempt.
- Results guide labeling.
- Applies to drugs and biologics.
Rare Pediatric Disease
Priority Review Voucher
Program (2012)
- Permits US-FDA to issue priority review vouchers to sponsors who receive approval for a product
to treat rare diseases in children.
- Voucher can be sold and then redeemed to receive a 6-month priority review of a subsequent
marketing application for a different product, including products intended only for adult use
(e.g., larger patient populations).
Federal Food, Drug, and
Cosmetic Act 5059b0(2)
- Other post-approval market exclusivities available after patents expire
•
5-year exclusivity for new chemical entities;
•
3-year exclusivity for new clinical investigations;
•
7-year exclusivity for orphan drugs; and
•
5-year exclusivity extension under Generic Antibiotic Incentives New (GAIN).
Collectively, these programs have been quite successful by many measures. For
example, the additional six months of marketing exclusivity granted under BPCA has
been applied to 280 US-FDA approved drugs. Under the PRV, drugs for rare pediatric
diseases move more quickly through all phases of clinical testing and are more likely
to be ﬁrst-in-class, when compared against drugs for adult rare diseases [18,19]. No-
tably, all these incentive programs require drug products to advance via the drug ap-
proval pathways as described above, with long development times and considerable
ﬁnancial investment.

## Page 5 (Section: Role of BCPA for Drugs without Active Patents )

Children 2022, 9, 1885
5 of 13
2.1.1. Role of BCPA for Drugs without Active Patents
BPCA provides funding to National Institute for Child Health and Human Devel-
opment (NICHD) to fund clinical trials that investigate off-patent approved drugs for
pediatric use, with an objective to update product labeling with pediatric-speciﬁc safety
and sometimes efﬁcacy information [20].
2.1.2. Use of Supplemental New Drug Applications
In pediatrics, large clinical trials studying new chemical entities (NCEs) under an
initial IND for a pediatric indication are uncommon. Pediatric labeling is more commonly
acquired via the supplementary NDA (sNDA) application process for products that are
already US-FDA approved. In this case, rather than large clinical trials, studies required by
an sNDA may be limited to single-dose PK bridging (adult to pediatric), and collection of
safety data in pediatric populations. Use of bridging studies is limited to circumstances
where the pharmacology in adults and children is known and expected to be similar.
An Agency response to an sNDA can include, in some cases, a Complete Response
Letter (CRL). As an example of a CRL, in the case of the drug palonosetron, the FDA
issued a CRL to the sponsor’s Pediatric Study Plan (PSP) requesting that compounding
instructions be added to product labeling (NDA 021372 and NDA 022233), which illustrates
how speciﬁc the formulation issues can be incorporated in product labeling [21]:
“ . . . a pharmacy compounded palonosetron extemporaneous liquid preparation for
oral administration must be developed for chemotherapy -induced nausea and vomiting
(CINV-MEC) prevention therapy in pediatric patients. The compounded palonosetron
formulation must utilize appropriate oral ingredients (e.g., sweeteners, suspending agents,
and diluents). You must also provide the following information for the compounded
formulation: active ingredients, diluents, and suspending and sweetening agents; detailed
step-by-step compounding instructions; packaging and storage requirements; and for-
mulation stability information. You must provide instructions to pharmacists and health
care providers for accurately measuring the volume of IV solution or oral formulation
for compounding. Compounding must be performed at 3 or more pharmacies to demon-
strate adequacy of the compounding method. Analytical data and statistical results on the
compounding method must be provided to the Agency for review [22].”
While there is a pediatric indication for palonosetron, it appears the sponsor did not
include any extemporaneous preparation instructions in the approved labeling for either
the IV or capsule dose forms [23]. In addition, in 2014, a palonosetron combination product
was approved and marketed in oral form as Akynzeo® (e.g., netupitant with palonosetron
oral capsules). The initial US-FDA approval in 2014 included no pediatric dosing or liquid
formulation and package instructions still do not contain compounding information. Based
upon the list of capsule ingredients, it could be a real challenge to compound a stable oral
liquid [24] for pediatric use. There are 11 patents assigned to the product [24]. Combined,
these factors complicate compounding of palonosetron for pediatric use.
3. Drug Compounding Pathway
Throughout its history, compounding has been considered a critical part of the practice
of pharmacy. This section focuses on current regulations and practice as shaped by the
Drug Quality and Security Act (DQSA). More detailed historical and legal reviews are
available elsewhere [25–28].
Drug Quality and Security Act of 2013
Title I of the Drug Quality and Security Act (DQSA), called the Compounding Quality
Act (CQA), organized state and federal oversight of compounding pharmacies into two
categories, as 503A pharmacies and 503B outsourcing facilities. 503A pharmacies are more
traditional pharmacies that compound preparations in response to an individual prescrip-
tion and are state licensed. By compounding in an individualized per-patient manner,
limiting the amount of compounding performed in advance of prescription receipt, and

## Page 6 (Section: Reasons for Needed Regulatory Change )

Children 2022, 9, 1885
6 of 13
limiting the volume of prescriptions dispensed across state lines, these pharmacies are
exempt from certain provisions of the Food, Drug, and Cosmetic Act. Those provisions
include exemptions from the new drug approval requirement (as described above), label-
ing with adequate directions for use, and current good manufacturing practice (CGMP)
requirements. Note the latter two provisions are also part of the new drug approval pro-
cess. Oversight of 503A pharmacies rests primarily with the state government(s) that have
licensed the pharmacy, although US-FDA has issued a guidance that addresses US-FDA
inspections of 503A pharmacies [29].
503B outsourcing facilities were created by the CQA and are permitted to compound
preparations in bulk without the requirement of the receipt of an individual prescription.
They may compound sterile and nonsterile individual prescriptions from bulk substances
and also, unlike 503A pharmacies, may distribute compounded drugs to healthcare facilities
and practitioners without ﬁrst receiving a patient-speciﬁc prescription [30]. Per the DQSA
503B outsourcing facilities are not required to license as a pharmacy, but they must pay an
annual user fee to US-FDA, comply with CGMP requirements, undergo US-FDA inspections
according to a risk-based schedule, report patient reported adverse events to US-FDA,
and provide US-FDA with certain information about the preparations they compound.
Oversight of 503B outsourcing facilities is performed primarily by US-FDA [27,30].
It is important to note the deﬁnition of compounding here to fully understand how
the process can beneﬁt individual patient populations, including children. The deﬁnition
of compounding according to the United States Pharmacopeia (USP) is the preparation,
mixing, assembling, altering, packaging, and labeling of a drug, drug-delivery device,
or device in accordance with a licensed practitioner’s prescription, medication order, or
initiative based on the practitioner/patient/pharmacist/compounder relationship in the
course of professional practice (USP <795>) [31].
Drug compounding includes the following:
•
Preparation of drug dosage forms for both human and animal patients;
•
Preparation of drugs or devices in anticipation of prescription drug orders based on
routine, regularly observed prescribing patterns;
•
Reconstitution or manipulation of commercial products that may require the addition
of one or more ingredients that is not in the package instructions. [US-FDA does
not consider reconstitution or manipulation according to the package instructions
compounding; and
•
Preparing a medication in accordance with the package insert instructions is com-
pounding under the USP deﬁnition, while it is not under US-FDA’s deﬁnition [32].
4. Reasons for Needed Regulatory Change
Despite good progress made in getting new pediatric products approved by US-FDA,
503A pharmacies and 503B outsourcing facilities still must compound on a large scale
to ﬁll the unmet medical needs of children. While the magnitude of compounding for
children is unknown, at least 6 billion prescriptions were dispensed in the United States
in 2021, and roughly one-quarter were for oral dosage forms. Of these, anywhere from
1–3% of these prescriptions were for compounded sterile and nonsterile preparations.
Approximately one-quarter of compounded prescriptions were dispensed to patients aged
0–19 years [33]. Therefore, a reasonable estimate of the total number of compounded
oral prescriptions dispensed for children annually is between 3.7 million and 11 million
prescriptions. One indication of the increasing interest in pediatric drug compounding is
the spike in publications on the topic since the enactment of the DQSA (Figure 1). Despite
policies which may facilitate conduct of pediatric randomized clinical trials (RCTs), the
publishing gap in high-impact general medical journals between adult and children RCTs
is widening. While the DQSA opened up the opportunity to perform non-patient speciﬁc
compounding of preparations without prior FDA approval, the high regulatory barrier
to acquiring US-FDA approval for a new pediatric dosage form hinders research and
development efforts.

## Page 7 (Section: Challenges for Meeting These Requirements )

Children 2022, 9, 1885
7 of 13
 
Figure 1. Number of Publications in PUBMED on the topic of pediatric drug compounding, 1991–2021.
Most of the newly US-FDA approved pediatric dosage forms are not suitable for the
very young (including neonates) and most are not labeled for use in children < 6 years of
age, an indicator of a shortcoming of current regulations. On the other hand, compounded
dosage forms have been shown to enhance patient compliance to medication regimens and
are widely and safely used now [8]. Many of these dosage forms can be made by 503As.
5. Challenges for Meeting These Requirements
Despite successes, there are recognized gaps in the US-FDA pediatric drug develop-
ment initiatives. Regarding Priority Voucher Review programs (PRV), the Government
Accounting Ofﬁce found few studies that examined the PRV programs, and those that did
found the programs had little or no effect on drug development overall [34–36]. PRV has
maintained a steady annual number and rate, and seems to facilitate advancement from
Phase I to Phase II clinical trials for rare pediatric-speciﬁc diseases, compared to that for
rare adult diseases. A similar trend, however, was not found in later stages of development.
Analysis suggests that other policies are needed to expand the pipeline for rare pediatric
diseases, particularly by stimulating the entry of new therapies developed speciﬁcally for
children. Similarly, the PRV program was not associated with a change in the rate of new
pediatric drugs starting or completing clinical testing.
Concerns have been raised that delays and a high level of noncompliance with US-
FDA post marketing study requests [1]. It would appear that, given the above, resources
could simply be placed into supporting compounding, rather than the ongoing efforts
to suppress compounding and to replace compounded preparations with much more
expensive approved drug products that likely are no more safe or effective.
The cost of drug development ranges from USD $92 million to $1.3 billion [36]. Further,
related to cost, the largest global pharmaceutical companies have most of the approved
drug products that have received pediatric exclusivity not small startup companies or not
for proﬁt companies [37].
Other more effective ﬁnished dosage forms that have been developed speciﬁcally
for children and other special patient groups (e.g., minitabs, buccal ﬁlms, immediately
dispersable tabs, delayed release minitabs) can be prepared at 503B outsourcing facilities
or 503A pharmacies with proper equipment and methods in place. More effective in this
case means dose delivery by mouth is more reliable and caregiver administration is easier.
Compounded pediatric preparation formulations can be developed at 503As and Bs that can
meet high quality production standards in accordance with USP chapters <795> and <797>.
503A pharmacies are able to compound preparations of complex solutions and suspensions
(sterile and non-sterile), lollipops, troches, and buccal preparations. Compounded dosage
forms have also been shown to enhance patient compliance or adherence to medication
regimens [8].

## Page 8 (Section: Challenges for Meeting These Requirements )

Children 2022, 9, 1885
8 of 13
Regarding post-marketing study requirements often put into place by US-FDA to
prompt pharma companies to eventually complete pediatric research commitments, justiﬁ-
able concerns have been raised about delays and noncompliance with these study requests.
For example, overall, 64 percent of new drug and biologic indications deemed relevant
to pediatric patients lacked pediatric prescribing information at ﬁve years after US-FDA
approval [1].
The costs to consumers for the BPCA, PREA, and PRV have been exceptionally high,
in the 100′s of millions of dollars per approved drug product. Similarly, the standard
level of patent protection (note many 505b2 products have patent protections as well as
505b2 exclusivity) commonly in place for 505b2 approvals (i.e., sNDA) adds another time
and cost barrier to development. When the target pediatric population is smaller, it is more
difﬁcult to justify the cost of patent and product development. One suggested alternative
is that policymakers should consider direct funding of such studies rather than shifting
much higher product costs to pediatric patients [18]. Some industry executives have held
that the slow rate of US-FDA approvals of pediatric drug products, due to the high barriers
required for approval, create a setting where many drug products used in pediatrics will
never be US-FDA approved. Fortunately for pediatric patients, preparations can be made
available via the compounding route.
There are at least six drug oral products known to the authors with formulation
and compounding information contained in the package insert, including oseltamivir
(Tamiﬂu®) capsules, rifampin (Rifadin®) capsules, secubitril and valsartan (Entresto®)
tablets, valacyclovir (Valtrex®) tablets, and valsartan (Diovan®) tablets. US-FDA could
encourage other sponsors to include these instructions in the package insert to facilitate
proper preparation of alternate oral dosage forms for children and adults that cannot
swallow solid oral doses.
In our view, US-FDA is restraining 503B-registered facilities from addressing pediatric
dosage forms. Inclusion of APIs on the US-FDA Drug Shortage List is one requirement
before an approved drug can be compounded. This is a major constraint on 503Bs that
prevents them from developing dosage forms for pediatric use. Table 3 illustrates several
recent examples of approvals via the NDA pathway with associated patents and post-
marketing commitments from the sponsor. None of these products were NCEs. Similarly,
and more recently, US-FDA Summary Review documents include comments that some
newly approved dosage forms provide alternatives to the use of compounded dosage
forms (even if not approved for pediatric use). That is, one reason for approval was to
replace, with approved products, those that are otherwise compounded [38,39]. Finally,
while no cost per dose comparisons are readily available, GMP manufactured approved
drug products could be expected to cost more per dose than a compounded preparation.
Table 3. Examples of Patents and Post Marketing Commitments for Recent US-FDA Approved
Pediatric Dosage Forms via the NDA Pathway https://www.accessdata.fda.gov/scripts/cder/ob/
index.cfm. Accessed on 29 November 2022.
Trade and Generic Name
Dosage Form
No. of Patents *
Latest Patent Date
Post Marketing Commitment
(Required under PREA)
(https://www.accessdata.fda.gov/scripts/
cder/pmc/index.cfm)
Carospir®
(spironolactone)
Suspension
5
28 October 2036
PMR 3256-1: Conduct a single-dose PK
study in pediatric patients 0 to <17 years
of age with edematous conditions.
PMR 3256-2: Conduct a multiple- dose
PK, pharmacodynamics, and safety study
in pediatric patients 0 to <17 years of age
with edematous conditions.

## Page 9 (Section: Suggestions for Regulatory Change )

Children 2022, 9, 1885
9 of 13
Table 3. Cont.
Trade and Generic Name
Dosage Form
No. of Patents *
Latest Patent Date
Post Marketing Commitment
(Required under PREA)
(https://www.accessdata.fda.gov/scripts/
cder/pmc/index.cfm)
Kapspargo Sprinkle®
(metoprolol succinate)
Capsule,
ER ˆ
2
9 July 2035
PMR 3638-1: Conduct a randomized,
dose-ranging, double-blind,
placebo-controlled, parallel group,
multi-center clinical study with an
open-label 52-week safety extension to
evaluate efﬁcacy, safety, tolerability and
pharmacokinetics of metoprolol succinate
extended release (ER) oral dosage form in
hypertensive pediatric subjects from birth
to less than 6 years of age
Qbrelis®
(lisinopril solution)
Solution
8
6 November 2035
PMR 3099-1: An efﬁcacy, safety and
dose-ﬁnding study of Qbrelis in
hypertensive pediatric patients two years
to less than six years of age
Katerzia®
(amlodipine benzoate)
Suspension
5
11 April 2039
PMR 3640-1: Conduct non-clinical toxicity
studies in juvenile rats to evaluate
developmental toxicity to include
assessment of the effects of amlodipine
benzoate suspension on reproductive and
learning development to support dosing
in humans down to birth.
PMR 3640-2: Conduct a dose-ranging,
safety, tolerability, and efﬁcacy study with
amlodipine benzoate oral suspension in
hypertensive pediatric patients age birth
to less than 6 years of age.
Norliqva®
(amlodipine besylate)
Solution
1
24 February 2041
PMR 4239-1: Conduct a dose-ranging
juvenile toxicology and toxicokinetic
study to support the deﬁnitive toxicology
study, and conduct a toxicity study in
juvenile rats to evaluate developmental
toxicity, including potential effects on
reproductive development and learning.
PMR 4239-2: Conduct an open-label,
randomized, single oral dose,
two-treatment, two-period, two-sequence
crossover bioequivalence and
bioavailability study of amlodipine
(ethanol-containing) oral solution versus
amlodipine (ethanol-free) oral solution in
healthy adults under fasting conditions.
PMR 4239-3: Conduct a dose-ranging,
safety, tolerability, and efﬁcacy study of
amlodipine besylate oral solution for the
treatment of hypertension in pediatric
patients, birth to <6 years of age.
* As reported in the US-FDA Orange Book, October 2022; ˆ Extended Release.
6. Suggestions for Regulatory Change
To begin addressing these gaps in approval pathways, the following suggestions
are offered to facilitate and improve the availability of both manufactured products and
compounded preparations.

## Page 10 (Section: Conclusions )

Children 2022, 9, 1885
10 of 13
A.
US-FDA could consider allocating additional resources into properly designed
surveillance tools that can begin to measure the depth (number of prescriptions)
and breadth (number of different dosage forms dispensed) of compounded prepa-
rations to better understand the extent to which pediatric patients rely on them.
This surveillance system will generate data that can be used to better understand
the compounding industry and guide responsive policy. US-FDA’s Compounding
Incidents Program that reviews MedWatch adverse event entries for compounded
drugs is a ﬁrst step towards better compounding surveillance in general [40].
B.
US-FDA could consider either (a) the creation of a pharmacy compounding grant
program for 503A pharmacies and 503B outsourcing facilities in addition to the
current grants directed to academic institutions that are involved in compounding
practice or (b) foster partnerships between pediatric academic medical centers and
registered 503A pharmacies and 503B outsourcing facilities to test and validate
evidence-based formulations designed speciﬁcally for children.
C.
A simpliﬁed, safe, and reliable pathway for the authorization of compounded prepa-
rations for children, and other special populations, could be developed in conjunc-
tion with USP. This can include well deﬁned active ingredient (API) and excipient
speciﬁcations, along with methods of preparation and ﬁnished dosage form tests. Ad-
ditionally, this pathway can include PK studies (bioequivalence studies, population
PK and modeling, among others) to bridge pediatric ﬁndings to adult populations,
as is currently allowed for many sNDAs.
D.
US-FDA could consider facilitating compounded pediatric preparations by not in-
cluding frequently compounded APIs on the Bulk Substances Used in Compounding
list [27]. The Bulks List should be used to incentivize safe compounding practice.
E.
US-FDA could encourage the inclusion of alternate dosage form compounding
instructions into the labeling of products that are commonly used in pediatrics. The
palonosetron CRL, provided previously, is an example. This is especially important
when an approved dosage form cannot be used in children, yet the active ingredient is
commonly used in pediatrics, and the stability of compounded preparations limited.
F.
ANDA ﬁlers (e.g., generic drug companies) could be permitted to augment labeling
with compounding instructions. This would simply require additional in vitro sta-
bility studies of compounded formulations, for example a crushed tablet in a well
characterized pharmaceutical vehicle. These studies are relatively simple for the
generic manufacturers to perform and could add additional value and labeled uses
for their speciﬁc product. US-FDA could facilitate dissemination of alternate dosage
form stability into the product’s labeling when it becomes known, especially when a
product is unstable in aqueous or non-aqueous vehicles.
7. Conclusions
Numerous examples exist which illustrate the progress made in pediatric dosage form
development. Despite this progress, regulatory challenges continue to stiﬂe development of
both US-FDA-approved products and scientiﬁcally derived compounded preparations. No-
tably, the majority of approved products used in pediatrics are used off-label and, in many
cases, require compounding prior to dispensing. Speciﬁc examples include neuropsychi-
atric drugs, where development of new molecular entities (NME) for pediatric indications
is often an afterthought to the pharmaceutical industry [41]. As another example, while
dasatinib bioequivalence studies were conducted in adults using 50 mg dispersable tablets
and a 10 mg/mL suspension, the innovator company marketed only solid oral tablets rather
than a liquid formulation suitable for pediatric use. Furthermore, the product labeling
advises against crushing the tablets even though the ofﬁcial labeling for dasatinib includes
an indication for children aged 1 year and older [42]. Similarly, even recently marketed
pediatric dosage forms (e.g., oral liquids, suspensions, capsules, sprinkles, and others)
may not be appropriate for all pediatric patients due to formulation with inappropriate
excipients and are not labeled for all age groups or pediatric populations [43].

## Page 11 (Section: Conclusions )

Children 2022, 9, 1885
11 of 13
In the absence of state regulations or professional or USP educational processes,
US-FDA should expand existing surveillance systems to better understand pediatric com-
pounded preparation needs and use. Further, the agency should resource and incen-
tivize registered compounding pharmacies and outsourcing facilities to develop stable,
reproducible, and validated preparations, perhaps in partnership with pediatric academic
research centers. Finally, a pathway to authorize compounded preparations should be
designed, with incentives for 503A, 503B and ANDA ﬁlers, that would foster the use of
bulk substances as well as permit labeling changes to promote safe compounding practices
for pediatric dosage forms.
Author Contributions: Conceptualization, R.B.M. and R.H.P.II; writing—original draft preparation,
R.B.M.; writing—review and editing, R.B.M., L.D.A., K.Z. and R.H.P.II. All authors have read and
agreed to the published version of the manuscript.
Funding: Supported in part by grant # UL1 TR001866 from the National Center for Advancing
Translational Sciences (NCATS), National Institutes of Health (NIH) Clinical and Translational
Science Award (CTSA) program (RBM).
Conﬂicts of Interest: RHP II is co-chair of the USP Expert Panel on Compounded Drug Preparation
Information Exchange.
Abbreviation
ADME
Absorption, distribution, metabolism, and excretion
ANDA
Abbreviated new drug application
API
Active pharmaceutical ingredient
BLA
Biologics license application
BPCA
Best Pharmaceuticals for Children Act of 2002
CGMP
Current Good Manufacturing Practice
CINV-MEC
Chemotherapy-induced nausea and vomiting
CRL
Complete response letter
DQSA
Drug Quality and Security Act of 2013
FDAMA
Food and Drug Administration Modernization Act of 1998
IND
Investigational new drug
NCE
New chemical entity
NDA
New drug application
NICHD
National Institute for Child Health and Human Development
NME
New molecular entity
PK
Pharmacokinetic
PREA
Pediatric Research Equity Act of 2003
PRV
Rare Pediatric Disease Priority Review Voucher Program of 2012
PSP
Pediatric study plan
RCT
Randomized clinical trial
sNDA
Supplementary NDA
US-FDA
United States Food and Drug Administration
References
1.
Carmack, M.; Hwang, T.; Bourgeois, F.T. Pediatric Drug Policies Supporting Safe and Effective Use of Therapeutics in Children: A
Systematic Analysis. Health Aff. 2020, 39, 1799–1805. [CrossRef] [PubMed]
2.
Bucci-Rechtweg, C. Enhancing the Pediatric Drug Development Framework to Deliver Better Pediatric Therapies Tomorrow. Clin.
Ther. 2017, 39, 1920–1932. [CrossRef] [PubMed]
3.
Hwang, T.; Bourgeois, F.; Franklin, J.; Kesselheim, A. Impact of the Priority Review Voucher Program on Drug Development for
Rare Pediatric Diseases. Health Aff. 2019, 38, 313–319. [CrossRef] [PubMed]
4.
Gleeson, J.P.; Fein, K.C.; Whitehead, K.A. Oral Delivery of Peptide Therapeutics in Infants: Challenges and Opportunities. Adv.
Drug Deliv. Rev. 2021, 173, 112–124. [CrossRef] [PubMed]
5.
Heitman, T.; Day, A.J.; Bassani, A.S. Pediatric Compounding Pharmacy: Taking on the Responsibility of Providing Quality
Customized Prescriptions. Children 2019, 6, 66. [CrossRef] [PubMed]

## Page 12 (Section: Conclusions )

Children 2022, 9, 1885
12 of 13
6.
Nahata, M.C.; Allen, L.V. Extemporaneous Drug Formulations. Clin. Ther. 2008, 30, 2112–2119. [CrossRef] [PubMed]
7.
Mattison, D.R.; Parker, R.M.; Jackson, L.M. (Eds.) The Clinical Utility of Compounded Bioidentical Hormone Therapy; National
Academies Press: Washington, DC, USA, 2020. [CrossRef]
8.
Carvalho, M.; Almeida, I. The Role of Pharmaceutical Compounding in Promoting Medication Adherence. Pharmaceuticals 2022,
15, 1091. [CrossRef] [PubMed]
9.
Witten, C.; Batra, A.; Durfor, C.N.; Hilbert, S.L.; Kaplan, D.S.; Fink, D.; Lavoie, D.; Maher, E.; McFarland, R. Overview of FDA
Regulatory Process. In Principles of Regenerative Medicine; Atala, A., Lanza, R., Mikos, T., Nerem, R., Eds.; Elsevier: Amsterdam,
The Netherlands, 2019; Chapter 77; pp. 1345–1365. [CrossRef]
10.
Brown, D.G.; Wobst, H.J.; Kapoor, A.; Kenna, L.A.; Southall, N. Clinical Development Times for Innovative Drugs. Nat. Rev. Drug
Discov. 2021, 21, 793–794. [CrossRef] [PubMed]
11.
Ofﬁce of the Inspector General. Compounded Drugs under Medicare Part B: Payment and Oversight. Available online:
https://oig.hhs.gov/oei/reports/oei-03-13-00270.pdf (accessed on 2 October 2022).
12.
United States Food and Drug Administration. Orphan Drug Act—Relevant Excerpts. Available online: https://www.fda.
gov/industry/designating-orphan-product-drugs-and-biological-products/orphan-drug-act-relevant-excerpts (accessed on 19
October 2022).
13.
United States Food and Drug Administration.
Development and Approval Process|Drugs.
Available online:
https:
//www.fda.gov/drugs/development-approval-process-drugs#:~{}:text=A%20team%20of%20CDER%20physicians,drug%20
is%20approved%20for%20sale (accessed on 17 November 2022).
14.
United States Food and Drug Administration. Guidance for Industry E11 Clinical Investigation of Medicinal Products in the
Pediatric Population. Available online: https://www.fda.gov/media/71355/download (accessed on 2 October 2022).
15.
United States Food and Drug Administration. FDA Drug Approval Process. Available online: https://www.fda.gov/media/82
381/download (accessed on 2 October 2022).
16.
Wouters, O.J.; McKee, M.; Luyten, J. Estimated Research and Development Investment Needed to Bring a New Medicine to
Market, 2009–2018. JAMA 2020, 323, 844. [CrossRef] [PubMed]
17.
Bourgeois, F.T.; Kesselheim, A.S. Promoting Pediatric Drug Research and Labeling—Outcomes of Legislation. N. Eng. J. Med.
2019, 381, 875–881. [CrossRef] [PubMed]
18.
Sinha, M.S.; Najafzadeh, M.; Rajasingh, E.K.; Love, J.; Kesselheim, A.S. Labeling Changes and Costs for Clinical Trials Performed
under the US Food and Drug Administration Pediatric Exclusivity Extension, 2007 to 2012. JAMA Intern. Med. 2018, 178, 1458.
[CrossRef] [PubMed]
19.
Zisowsky, J.; Krause, A.; Dingemanse, J. Drug Development for Pediatric Populations: Regulatory Aspects. Pharmaceutics 2010, 2,
364–388. [CrossRef] [PubMed]
20.
National Institute for Child Health and Human Development. BPCA Funded Clinical Trials. Available online: https://www.
nichd.nih.gov/sites/default/ﬁles/inline-ﬁles/BPCA-funded-clinical-trials.pdf (accessed on 19 October 2022).
21.
United States Food and Drug Administration. Pediatric Study Plans: Content of and Process for Submitting Initial Pediatric
Study Plans and Amended Initial Pediatric Study Plans Guidance for Industry. Available online: https://www.fda.gov/media/
86340/download (accessed on 2 October 2022).
22.
Letter from Julie Beitz to Craig Lehmann, re: NDAs 021372 and 022233. August 2010; p. 7. Available online: http://www.fda.
gov/downloads/Drugs/DevelopmentApprovalProcess/DevelopmentResources/UCM396087.pdf (accessed on 19 October 2022).
23.
Boccia, R.; Grunberg, S.; Franco-Gonzales, E.; Rubenstein, E.; Voisin, D. Efﬁcacy of oral palonosetron compared to intra-
venous palonosetron for the prevention of chemotherapy-induced nausea and vomiting associated with moderately emetogenic
chemotherapy: A phase 3 trial. Support Care Cancer 2013, 21, 1453–1460. [CrossRef] [PubMed]
24.
Akynzeo® Prescribing Information. Available online: https://www.akynzeo.com/assets/pdf/Akynzeo-USPI.pdf (accessed on
19 October 2022).
25.
Watson, C.J.; Whitledge, J.D.; Siani, A.M.; Burns, M.M. Pharmaceutical Compounding: A History, Regulatory Overview, and
Systematic Review of Compounding Errors. J. Med. Tox. 2021, 17, 197–217. [CrossRef] [PubMed]
26.
United States Food and Drug Administration. Center for Drug Evaluation and Research. Compounded Drug Products That Are
Essentially Copies of a Commercially Available Drug Product under Section 503A of the Federal Food, Drug, and Cosmetic Act:
Guidance for Industry. January 2018. Available online: https://www.fda.gov/regulatory-information/search-fda-guidance-
documents/compounded-drug-products-are-essentially-copies-commercially-available-drug-product-under-section (accessed
on 15 September 2022).
27.
United States Food and Drug Administration. Center for Drug Evaluation and Research. Bulk Drug Substances Used in
Compounding under Section 503B of the FD&C Act. Available online: https://www.fda.gov/drugs/human-drug-compounding/
bulk-drug-substances-used-compounding-under-section-503b-fdc-act (accessed on 15 September 2022).
28.
Kim, S.H. The Drug Quality and Security Act of 2013: Compounding Consistently. J. Health Care Law Policy 2017, 19, 5.
29.
United States Food and Drug Administration. Center for Drug Evaluation and Research. Pharmacy Compounding of Human
Drug Products under Section 503A of the Federal Food, Drug, and Cosmetic Act Guidance. Bethesda, MD, USA, June 2016.
Available online: https://www.fda.gov/media/94393/download (accessed on 2 October 2022).
30.
United States Food and Drug Administration, Centers for Drug Evaluation and Research. Outsourcing Facility Information.
Available online: https://www.fda.gov/media/107569/download (accessed on 20 October 2022).

## Page 13 (Section: Conclusions )

Children 2022, 9, 1885
13 of 13
31.
United States Pharmacopeial Convention. USP Compounding Compendium. 2019. Available online: https://www.usp.org/
products/usp-compounding-compendium (accessed on 12 October 2022).
32.
American Society of Health-System Pharmacists. ASHP Compounding Frequently Asked Questions. Available online: https:
//www.ashp.org/-/media/assets/advocacy-issues/docs/compounding-guidances-frequently-asked-questions.pdf (accessed
on 15 September 2022).
33.
McPherson, T.; Fontane, P.; Iyengar, R.; Henderson, R. Utilization and Costs of Compounded Medications for Commercially
Insured Patients, 2012–2013. J. Manag. Care Spec. Pharm. 2016, 22, 172–181. [CrossRef] [PubMed]
34.
Karesh, A. Pediatric Drug Development: Regulatory Expectations. Available online: https://www.fda.gov/ﬁles/drugs/
published/Pediatric-Drug-Development--Regulatory-Expectations (accessed on 2 October 2022).
35.
Government Accounting Ofﬁce. Drug Development: FDA’s Priority Review Voucher Program. Available online: https://www.
gao.gov/assets/gao-20-251.pdf (accessed on 2 October 2022).
36.
Morgan, S.; Grootendorst, P.; Lexchin, J.; Cunningham, C.; Greyson, D. The Cost of Drug Development: A Systematic Review.
Health Policy N. Y. 2011, 100, 4–17. [CrossRef]
37.
Drug Watch. Pharmaceutical Companies with the Most “Pediatric Exclusivity” Drugs. Available online: https://www.
drugpatentwatch.com/trends/pediatric-exclusivity.php (accessed on 2 October 2022).
38.
United States Food and Drug Administration, Center for Drug Evaluation and Research. Division of Cardiovascular and Renal
Products, Application Number 211340Orig1s000, KATERZIA (Amlodipine Benzoate) Oral Suspension 1 mg/mL. Available online:
https://www.accessdata.fda.gov/drugsatfda_docs/nda/2019/211340Orig1s000OtherR.pdf (accessed on 17 November 2022).
39.
United States Food and Drug Administration, Center for Drug Evaluation and Research. Application Number 022571Orig1s000,
Cuvposa 1 mg/5 mL. Available online: https://www.accessdata.fda.gov/drugsatfda_docs/nda/2010/022571Orig1s000SumR.
pdf (accessed on 17 November 2022).
40.
Janusziewicz, A.N.; Glueck, S.N.; Park, S.Y.; Nguyen, D.N.; Rimmel, S.C.; Cascio, L.A.; Doh, G.Y.; Martin-Yeboah, G.F. A
pharmacist-driven Food and Drug Administration incident surveillance and response program for compounded drugs. Am. J.
Health Syst. Pharm. 2021, 78, 1438–1443. [CrossRef] [PubMed]
41.
Grabb, M.C.; Gobburu, J.V.S. Challenges in Developing Drugs for Pediatric CNS Disorders: A Focus on Psychopharmacology.
Prog. Neurobiol. 2017, 152, 38–57. [CrossRef] [PubMed]
42.
Bristol Myers Squibb. Srycel® (Dasatinib Tablets for Oral Use) Package Insert. Available online: https://packageinserts.bms.
com/pi/pi_sprycel.pdf (accessed on 2 October 2022).
43.
Parrish, R.H., II; Ashworth, L.D.; Löbenberg, R.; Benavides, S.; Cies, J.J.; MacArthur, R.B. Compounded Nonsterile Preparations
and FDA-Approved Commercially Available Liquid Products for Children: A North American Update. Pharmaceutics 2022,
14, 1032. [CrossRef] [PubMed]


---

# Identifying Drug Targets of Oral Squamous Cell Carcinoma through a Systems Biology Method and Genome-Wide Microarray Data for Drug Discovery by Deep Learning and Drug Design Specifications

- **Authors:** Yi-Chung Lin, Bor-Sen Chen
- **Issuer:** International journal of molecular sciences
- **Type:** Scientific article
- **Published:** 2022-09-08
- **Language:** en
- **DOI:** 10.3390/ijms231810409
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36142321/
- **Licence:** CC-BY

## Page 1 (Section: Introduction )

Citation: Lin, Y.-C.; Chen, B.-S.
Identifying Drug Targets of Oral
Squamous Cell Carcinoma through a
Systems Biology Method and
Genome-Wide Microarray Data for
Drug Discovery by Deep Learning
and Drug Design Speciﬁcations. Int.
J. Mol. Sci. 2022, 23, 10409. https://
doi.org/10.3390/ijms231810409
Academic Editor: Alexander Shtil
Received: 9 August 2022
Accepted: 7 September 2022
Published: 8 September 2022
Publisher’s Note: MDPI stays neutral
with regard to jurisdictional claims in
published maps and institutional afﬁl-
iations.
Copyright:
© 2022 by the authors.
Licensee MDPI, Basel, Switzerland.
This article is an open access article
distributed
under
the
terms
and
conditions of the Creative Commons
Attribution (CC BY) license (https://
creativecommons.org/licenses/by/
4.0/).
 
International Journal of 
Molecular Sciences
Article
Identifying Drug Targets of Oral Squamous Cell Carcinoma
through a Systems Biology Method and Genome-Wide
Microarray Data for Drug Discovery by Deep Learning and
Drug Design Speciﬁcations
Yi-Chung Lin and Bor-Sen Chen *
Laboratory of Automatic Control, Signaling Processing and Systems Biology, Department of
Electrical Engineering, National Tsing Hua University, Hsinchu 30013, Taiwan
* Correspondence: bschen@ee.nthu.edu.tw
Abstract: In this study, we provide a systems biology method to investigate the carcinogenic mech-
anism of oral squamous cell carcinoma (OSCC) in order to identify some important biomarkers as
drug targets. Further, a systematic drug discovery method with a deep neural network (DNN)-based
drug–target interaction (DTI) model and drug design speciﬁcations is proposed to design a potential
multiple-molecule drug for the medical treatment of OSCC before clinical trials. First, we use big
database mining to construct the candidate genome-wide genetic and epigenetic network (GWGEN)
including a protein–protein interaction network (PPIN) and a gene regulatory network (GRN) for
OSCC and non-OSCC. In the next step, real GWGENs are identiﬁed for OSCC and non-OSCC by
system identiﬁcation and system order detection methods based on the OSCC and non-OSCC mi-
croarray data, respectively. Then, the principal network projection (PNP) method was used to extract
core GWGENs of OSCC and non-OSCC from real GWGENs of OSCC and non-OSCC, respectively.
Afterward, core signaling pathways were constructed through the annotation of KEGG pathways, and
then the carcinogenic mechanism of OSCC was investigated by comparing the core signal pathways
and their downstream abnormal cellular functions of OSCC and non-OSCC. Consequently, HES1,
TCF, NF-κB and SP1 are identiﬁed as signiﬁcant biomarkers of OSCC. In order to discover multiple
molecular drugs for these signiﬁcant biomarkers (drug targets) of the carcinogenic mechanism of
OSCC, we trained a DNN-based drug–target interaction (DTI) model by DTI databases to predict
candidate drugs for these signiﬁcant biomarkers. Finally, drug design speciﬁcations such as adequate
drug regulation ability, low toxicity and high sensitivity are employed to ﬁlter out the appropriate
molecular drugs metformin, geﬁtinib and gallic-acid to combine as a potential multiple-molecule
drug for the therapeutic treatment of OSCC.
Keywords: oral squamous cell carcinoma (OSCC); deep neural network-based drug–target interaction
(DNN-based DTI) model; genome-wide genetic and epigenetic network (GWGEN); signiﬁcant
biomarkers; drug design speciﬁcations
1. Introduction
In recent years, oral cancer has been the eighth most common malignancy of the head
and neck, with more than 145,500 deaths worldwide each year [1,2], and oral squamous
cell carcinoma (OSCC) accounts for approximate 90% of all cancers in the oral cavity [3].
Despite many advancements in cancer treatment, the 5-year survival rate for OSCC patients
is 50% [4], which has remained unchanged over the past decade. In recent years, various
environmental factors, such as smoking and chewing betel nut, are the main causes of
OSCC [5]. However, not everyone exposed to these triggers will develop oral cancer. Many
studies have shown that the occurrence of oral cancer is the result of oncogene activation
or tumor suppressor gene inactivation. Therefore, a better understanding of the regulatory
Int. J. Mol. Sci. 2022, 23, 10409. https://doi.org/10.3390/ijms231810409
https://www.mdpi.com/journal/ijms

## Page 2 (Section: Introduction )

Int. J. Mol. Sci. 2022, 23, 10409
2 of 29
networks between molecular interactions and signaling pathways is crucial for identifying
new prognostic markers or therapeutic targets for OSCC.
Chronic inﬂammation can promote tumor formation. The long-term chronic inﬂam-
matory stimulation of periodontal tissue can form an inﬂammatory microenvironment
that is conducive to the development of OSCC [6]. Inﬂammation activates NF-κB through
intracellular signaling pathways, induces the cytokines tumor necrosis factor-α (TNF-α)
expression of cytokines and can form an inﬂammatory microenvironment that promotes
tumor growth and progression [7]. Long-term inﬂammatory damage induces cell renewal
and the repair of defective tissues. During the repair process, carcinogens or macrophages
can cause cell DNA damage, cell proliferation and differentiation. Disruption occurs, creat-
ing conditions for the formation and metastasis of OSCC [8]. NF-κB can also upregulate
vascular endothelial growth factor (VEGF) and cyclooxygenase-2 (COX-2) expression [9,10],
inducing tumor angiogenesis involved in the invasion and metastasis of OSCC.
In this study, based on big data mining, the system identiﬁcation method and genome-
wide microarray data of patients of OSCC, a systems biology method is proposed to help
us analyze macroscopically systematic relationships among proteins, genes and microenvi-
ronments in cancer. As shown in Figure 1, the systems biology method including system
identiﬁcation, system order detection and principle network projection (PNP) [11,12] has
been widely used to construct core signal pathways to investigate the pathogenesis of
diseases such as cancer [13] and virus infection [14] in recent years. Therefore, based on
genome-wide microarray data of OSCC and non-OSCC, a systems biology method is used
to ﬁnd the carcinogenic mechanism of OSCC by comparing core signal pathways and their
downstream abnormal cellular functions of OSCC and non-OSCC in this study. First, a
systems biology method was employed to identify real GWGENs of OSCC and non-OSCC
by prune false positives from the candidate GWGEN by their microarray data. Then, with
the PNP approach, the core GWGENs of OSCC and non-OSCC were extracted from their
real GWGENs, respectively. By the annotation of KEGG pathways, we could obtain core
signal pathways of OSCC and non-OSCC from their corresponding core GWGENs. Then,
we can investigate the carcinogenic mechanism of OSCC by comparing the discrepancy
between core signal pathways and their downstream cellular disfunctions in the non-OSCC
and OSCC. According to the investigated carcinogenic mechanism and cellular disfunctions
in the core signaling pathways of OSCC, HES1, TCF, NF-κB and SP1 were identiﬁed as
the signiﬁcant carcinogenic biomarkers contributing to unnormal cellular functions such
as inﬂammatory-dependent cell apoptosis, angiogenesis, tumor metastasis and tumor
invasion, which were considered as drug targets for the systematic drug discovery design
of OSCC.
The development process of a new drug is an arduous task because of the highly
expensive cost and time-consuming investment. Moreover, it is estimated that it takes about
12–15 years and more than USD one billion to develop a new drug [15]. Pharmaceutical
companies need to spend a large amount of time and effort on executing experiments to
understand the properties and the possible bindings of the drug and selected targets. In
addition, the efﬁcacy and potency of the drug as well as the adverse inﬂuences on body
should be considered. Therefore, researchers conduct a number of animal and clinical trials
to check the safety and stability [16]. These complicated procedures vastly increase the risk
of failure in designing drugs. Most failures are due to the poor clinical outcomes, and the
results are usually lower than expected [17]. On the contrary, drug repurposing (also known
as drug repositioning) has been employed to identify new therapeutic uses of approved
or investigational drugs as a feasible and advantageous strategy [18]. Recently, deep
learning schemes have been widely applied for some phenomenon predictions of molecular
biological systems [19–21]. For these reasons, we developed systematic drug discovery
and design strategies based on a DNN-based DTI model to predict candidate molecular
drugs for biomarkers (drug targets) of OSCC. Then, these candidate molecular drugs of
each drug target were sieved by drug design speciﬁcations of drug–target interaction
(docking), adequate drug regulation ability, low toxicity and high sensitivity to select

## Page 3 (Section: Introduction )

Int. J. Mol. Sci. 2022, 23, 10409
3 of 29
adequate molecular drugs for biomarkers, which are combined as a multiple-molecular
drug of OSCC, from the perspective of system engineering. As seen in the ﬂowchart of
the systematic drug design procedure in a DNN-based DTI model was trained by DTI
databases in advance. Then, the well-trained DNN-based DTI model could predict a set
of candidate molecular drugs for each biomarker (drug target). Eventually, with the help
of the above drug design speciﬁcations, we chose and combined metformin, geﬁtinib and
gallic-acid among the set of candidate molecular drugs as the multiple-molecule drug to
target the biomarkers HES1, TCF, NF-κB and SP1 for OSCC. Taken together, we expect
that the proposed systematic medicine discovery and design procedure can provide an
efﬁcient way to design a multiple-molecule drug as a new therapy for OSCC treatment
before clinical trials.
Figure 1. Flowchart of the systems biology method and the outline of the systematic drug discovery
design. The candidate GWGEN consists of a gene regulation network (GRN) and protein–protein
interaction network (PPIN), where the candidate GRN was constructed through integrating gene
regulation databases, and candidate PPI was constructed via protein–protein interaction databases.
The candidate GWGEN was identiﬁed to obtain real GWGEN by OSCC microarray data from
GSE30784 and GSE17913 through system identiﬁcation and system order detection, and core GWGEN
was extracted from real GWGEN by the PNP method. The core signaling pathways of non-OSCC and
OSCC are obtained by core GWGENs of non-OSCC and OSCC via the denotation of KEGG pathways,

## Page 4 (Section: Results )

Int. J. Mol. Sci. 2022, 23, 10409
4 of 29
respectively. The carcinogenic biomarkers were identiﬁed by comparing the core signaling pathways
and their down streaming abnormal cellular functions of non-OSCC and OSCC. The DNN-based DTI
model can be employed to predict candidate molecular drugs for these carcinogenic biomarkers, and
drug design speciﬁcations are used to select a multiple-molecule drug for OSCC.
2. Results
2.1. Overview of the Systems Biology Method and the Systematic Drug Discovery and Design
of OSCC
In order to obtain insight into the carcinogenic mechanism to identify signiﬁcant
carcinogenic biomarkers as drug targets of OSCC, we search for potential molecular drugs
to target these signiﬁcant biomarkers by a deep neural network (DNN)-based DTI model
and drug design speciﬁcations from the viewpoint of system engineering. The ﬁrst step
is to construct a candidate GWGEN of non-OSCC and OSCC by big data mining from
the databases DIP [22], IntAct [23], BioGRID [24], MINT [25] HTRIdb [26], ITFP [27],
TRANSFAC [28], CircuitDB [29], TargetScanHuman [30] and starBase 2.0 [31]. Then, the
system identiﬁcation method in Equations (1)–(24) by the microarray data of non-OSCC
and OSCC and the system order detection method in Equations (25)–(32) are employed
to construct real GWGENs of non-OSCC and OSCC in Figure 2 by pruning off the false
positives from candidate GWGEN, respectively. Since, at most, 6000 molecules in real
GWGENs can be annotated by the Kyoto Encyclopedia of Genes and Genomes (KEGG)
pathways, the principal network projection method (PNP) in Equations (33)–(40) is used
for extracting the core GWGENs in Figure 3, i.e., the core GWGEN network of non-OSCC
and the core GWGEN network of OSCC are at the maximum with 6000 signiﬁcant nodes.
The core GWGENs extracted by the PNP method from the real GWGENs can also simplify
the investigation of the carcinogenic mechanism of OSCC. The numbers of proteins, TFs,
Receptors, LncRNAs and miRNAs of core GWGENs are also indicated. The core signaling
pathways of non-OSCC and OSCC are constructed by projecting the corresponding core
GWGENs to KEGG signiﬁcant pathways in Figure 4. By comparing the core signaling
pathways and the downstream abnormal cellular functions between non-OSCC and OSCC
in Figure 4, we could investigate the carcinogenic mechanism of OSCC, from which the
signiﬁcant biomarkers were identiﬁed as drug targets for the therapeutic treatment of
OSCC. Furthermore, the deep neural network of the drug–target interaction (DTI) model is
trained in Figure 5 to predict candidate molecular drugs, which are selected by drug design
speciﬁcations such as adequate drug regulatory ability, low toxicity and high sensitivity as
potential molecular drugs that can be combined as a multiple-molecule drug of OSCC.
(A) Real GWGEN of non-OSCC 
Figure 2. Cont.

## Page 5 (Section: Results )

Int. J. Mol. Sci. 2022, 23, 10409
5 of 29
(B) Real GWGEN of OSCC 
Figure 2. (A) The real GWGEN of non-OSCC. (B) The real GWGEN of OSCC. The numbers indicate
the node numbers of proteins, TFs, Receptors, LncRNAs and miRNAs. The purple lines indicate the
protein–protein interactions, and the orange lines denote the gene regulations.
(A) Core GWGEN of non-OSCC 
(B) Core GWGEN of OSCC 
Figure 3. (A) The core GWGEN of non-OSCC. (B) The core GWGEN of OSCC. The core GWGENs were
extracted by the PNP method from the real GWGENs to simplify the annotation of KEGG pathways

## Page 6 (Section: Results )

Int. J. Mol. Sci. 2022, 23, 10409
6 of 29
for the carcinogenic mechanism analysis of OSCC. The numbers denote the node numbers of proteins,
TFs, Receptors, LncRNAs and miRNAs, respectively. The purple lines indicate the protein–protein
interactions, and the orange lines denote the gene regulations.
Figure 4. The core signaling pathways in three blocks represent speciﬁc OSCC, common non-OSCC
and speciﬁc non-OSCC core signaling pathways from left to right, respectively. The core signaling
pathways of non-OSCC and OSCC are based on the annotation of core GWGENs of non-OSCC and
OSCC in Figure 3, respectively. For investigating the genetic and epigenetic carcinogenic mechanism
of OSCC, the core signaling pathways and the downstream abnormal cellular functions of non-
OSCC and OSCC are compared. The genes and proteins in the core signaling pathways were
chosen from core GWGENs of the non-OSCC and OSCC by the annotation of KEGG pathways. The
gene regulations and protein interactions were constructed based on the edges in core GWGENs of
non-OSCC and OSCC. The low and high expression arrow-head marks are relative to non-OSCC.
The collected microarray data were classiﬁed into non-OSCC and OSCC groups, as
shown in Table 1.
Table 1. Samples of microarray data from GSE30784 and GSE17913.
Microarray Data
Non-OSCC
OSCC
GSE30784 and GSE17913
102
167
Based on protein interaction and gene regulation databases, since the candidate GW-
GEN was constructed due to different biological conditions and computational predictions
in these databases, there are many false positives in the candidate GWGEN. Therefore,
the system identiﬁcation method in Systems Biology [32,33] is employed to identify the
protein interactions and gene regulations by the microarray data of OSCC and non-OSCC.
Systems order detection is employed to prune off the false positive protein interactions out
of the interaction order of each protein and the gene regulations out of the regulation order
of each gene in candidate GWGEN to obtain the real GWGENs of OSCC and non-OSCC.
The real GWGENs were too complex and large for analyzing the carcinogenesis of OSCC

## Page 7 (Section: Investigating the Genetic and Epigenetic Carcinogenic Mechanism of OSCC )

Int. J. Mol. Sci. 2022, 23, 10409
7 of 29
by the annotation of KEGG pathways. To solve this problem, the core GWGENs were
extracted from the real GWGENs of OSCC and non-OSCC by the PNP method to reduce
the network size in order to simplify the following carcinogenic analysis of OSCC by the
annotation through KEGG pathways. In Table 2, the sizes of the core GWGENs of OSCC
are smaller than real OSCC GWGENs. Both the real OSCC GWGEN and the real non-OSCC
were plotted by Cytoscape software in Figure 2. The corresponding core GWGENs for
non-OSCC and OSCC were plotted by Cytoscape software in Figure 3. Moreover, the core
signaling pathways were obtained by the annotation of core GWGENs by KEGG pathways
to investigate the carcinogenic mechanism by comparing core signaling pathways. The
KEGG pathway enrichment analyses of the core signaling pathways of OSCC and non-
OSCC are given in Tables 3 and 4, respectively. The core signaling pathways for OSCC
and non-OSCC are given in Figure 4. Then, based on the core signal pathways and their
downstream abnormal cellular functions of OSCC and non-OSCC in Figure 4, we will
investigate the genetic and epigenetic carcinogenic mechanism of OSCC in the following.
Table 2. The statistics of the nodes in real GWGEN and core GWGEN of OSCC.
Real GWGEN of OSCC
Core GWGEN of OSCC
Protein
13,855
4621
Receptor
2112
672
TF
1492
620
miRNA
31
2
LncRNA
419
85
Total nodes
17,909
6000
Table 3. KEGG pathway enrichment analysis of core OSCC signaling pathways.
KEGG Pathway Enrichment Analysis of OSCC Core Signaling Pathways
Pathway
Gene number
p-value
Cell cycle
91
8.3 × 10−20
Pathways in cancer
267
3.1 × 10−19
MAPK signaling pathway
149
3.6 × 10−11
Apoptosis
80
3.2 × 10−10
Proteoglycans in cancer
120
1.0 × 10−14
Table 4. KEGG pathway enrichment analysis of core non-OSCC signaling pathways.
KEGG Pathway Enrichment Analysis of Non-OSCC Core Signaling Pathways
Pathway
Gene number
p-value
Cellular senescence
95
2.3 × 10−13
MAPK signaling pathway
166
2.4 × 10−18
Human T-cell leukemia virus 1 infection
134
3.2 × 10−18
Cell cycle
84
4.2 × 10−15
P53 signaling pathway
46
1.6 × 10−7
The content in the table shows the number of nodes. The rows of the table contain
different types of nodes.
2.2. Investigating the Genetic and Epigenetic Carcinogenic Mechanism of OSCC
Cancer is a disease mainly caused by abnormal signaling pathways. Smoking and
drinking can cause changes in the microenvironment of the human body [34,35]. In our

## Page 8 (Section: Investigating the Genetic and Epigenetic Carcinogenic Mechanism of OSCC )

Int. J. Mol. Sci. 2022, 23, 10409
8 of 29
study, adverse factors such as JAG1, Wnt, ECM, EGF and IGF1 produced by the human
microenvironment ultimately lead to cellular dysfunctions. From comparing the core
signaling pathways of OSCC and non-OSCC in Figure 4, the core signaling pathways of
OSCC and their downstream abnormal cellular functions need to be investigated into the
genetic and epigenetic carcinogenic mechanism of OSCC. The core signal pathways and
their downstream cellular functions of OSCC are investigated as follows:
(i)
Abnormal MAPK signaling pathway in OSCC
In Figure 4, the ligand epithelial growth factor (EGF) in the micro-environment of
OSCC targets the EGF receptor (EGFR), activates the phosphorylation of its downstream
signaling proteins Src and PI3K and then leads to the well-known estrogen-mediated
Ras/Raf/MEK/ERK pathway [36]. Several mutations in the MAPK/ERK pathway have
been identiﬁed in human cancers. The mitogen-activated protein kinase (MAPK) cascade
is a critical pathway for human cancer cell survival, dissemination and resistance to drug
therapy. The extracellular signal-regulated kinase (ERK) pathway is a convergent signal-
ing node that receives input from numerous stimuli, including internal metabolic stress
and DNA damage pathways and altered protein concentrations, as well as from external
growth factors, cell–matrix interactions and communications from other cells. Mutated
genes responsible for regulating cell fate, genome integrity and survival can overactivate
this pathway by causing increased protein ampliﬁcation and altering the tumor microenvi-
ronment. These mutations can occur upstream of membrane receptor genes [37]. Current
and future drug development efforts will require altering and modulating tumor signal-
ing in this complex network of codependent pathways. ERK ultimately redirects to the
transcription factor SP1, which is abnormally upregulated in patients with OSCC, and SP1
promotes the expression of CCND1 and COX-2 [38,39]. COX-2 has been reported to be
involved in cancer cell migration, cancer cell proliferation, lymph-angiogenesis and metas-
tasis. There was a signiﬁcant positive correlation between angiogenesis and apoptosis [40].
CCND1 was negatively correlated with apoptosis and an accelerated cell cycle [41,42].
(ii)
The impact of the Wnt signaling pathway on OSCC
The ligand Wnt is common in embryonic development and cancer [43]. Wnts are
secreted glycoproteins that bind to frizzled class 1 (FZD1) receptors, which may be coupled
to heterotrimeric G proteins. Intracellularly, signal transduction passes through GBP,
glycogen synthase kinase 3β (GSK3β) and tumor suppressor gene product (APC) and then
activates a key protein (β-catenin). Consequentially, stable β-catenin enters the nucleus and
interacts with TF TCF/LEF, leading to the transcription of the Wnt target genes C-Myc and
CCND1 [44]. According to reports and studies [45], there is a regulation of underexpressed
TF TCF/LEF on C-Myc and CCND1. CCND1 was positively correlated with apoptosis and
an accelerated cell cycle. C-Myc was positively correlated with proliferation and negatively
correlated with apoptosis [46].
(iii)
Notch signaling pathway in OSCC
In Figure 4, the cell surface receptor Notch is activated and causes mutation by the
microenvironmental factor JAG1 of OSCC [47,48]. The constitutive activation of the Notch
pathway has been demonstrated in various types of malignancies [49]. In this study, the
Notch pathway was also found to be extremely important in OSCC. The Notch signaling
cascade affects several key aspects of normal development through proliferation and
apoptosis [50]. All the signaling pathways transduce down to the TF HES1 [51]. Finally,
the signal is transmitted to the proto-oncogene C-Myc [52]. According to reports and our
study, HES1 is underexpressed and upregulates C-Myc and then promotes cell apoptosis
and proliferation in OSCC patients [50].
(iv)
Key transcription factor NF-κB on OSCC
Integrin subunit alpha (ITGA) also plays a crucial role in OSCC. In Figure 4, it can be
seen that, after the receptor ITGA is affected by the extrinsic factor extra cellular matrix

## Page 9 (Section: Significant Biomarkers as Drug Targets for the Therapeutic Treatment of OSCC Utilizing the Systematic Drug Discovery Approach )

Int. J. Mol. Sci. 2022, 23, 10409
9 of 29
(ECM) in the micro-environment of OSCC [53], it will then successively affect the down-
stream signaling transduction proteins Src/PI3K/PKB/AKT. Insulin-like growth factor
1 (IGF-1R) signaling is partially mediated by the Src pathway. The activation of Src and
IGF-1R also activates Akt. It is a key effector of the PI3K/Akt pathway. It is abnormally
activated in most malignant tumors, promoting cell growth, proliferation and survival [54].
In many reports, AKT is underexpressed and phosphorylated in OSCC patients [55]. It then
affects the TFs IKK and NF-κB. NF-κB affects numerous target genes. Many reports indicate
that the genes COX-2 and VEGF are particularly important in OSCC patients [55,56]. The
genes NF-κB, COX-2 and VEGF are abnormally up-regulated to promote angiogenesis,
lympha-angiogenesis, migration, proliferation and apoptosis [55,56].
According to the description of OSCC above, poor diet and living habits can lead
to changes in the human microenvironment. Then, a series of pathway signaling leads
to downstream cellular dysfunction, among which abnormal apoptosis, proliferation,
migration and angiogenesis play crucial roles on the carcinogenesis of OSCC.
2.3. Signiﬁcant Biomarkers as Drug Targets for the Therapeutic Treatment of OSCC Utilizing the
Systematic Drug Discovery Approach
After investigating the carcinogenic mechanism of OSCC from the core signaling
pathways and their downstream abnormal cellular functions, the significant biomarkers
of the carcinogenic mechanism of OSCC will be identified as drug targets for therapeu-
tic treatment.
According to the investigation of carcinogenic mechanisms, OSCC suffers from prolifer-
ation and apoptosis. Based on the above core signaling pathways and their downstreaming
abnormal cellular functions, we properly selected signiﬁcant biomarkers that were related
to carcinogenically abnormal inﬂammation, apoptosis, proliferation, angiogenesis and cell
cycles. Consequently, we selected HES, TCF, NF-κB and SP1 as signiﬁcant biomarkers
and aimed to reverse their expression levels, i.e., to restore them to normal inﬂammation,
apoptosis, proliferation, angiogenesis and cell cycles. HES plays an important role in the
NOTCH pathway. TCF is also a main character in the Wnt pathway. NF-κB is involved in
cellular responses to many stimuli. Sp1 has been shown to be involved in apoptosis.
After identifying the signiﬁcant biomarkers as drug targets, we considered the chemi-
cal properties of drugs and targets to select candidate molecular drugs for these drug targets
(biomarkers) based on their drug–target bindings (dockings) predicted by the DNN-based
DTI model and to design a multiple-molecule drug for OSCC treatment before clinical
trials based on some suitable drug design speciﬁcations, i.e., adequate drug regulation
ability, low toxicity and high sensitivity. The ﬂowchart of the systematic drug discovery
and design method is described in Figure 5.

## Page 10 (Section: Significant Biomarkers as Drug Targets for the Therapeutic Treatment of OSCC Utilizing the Systematic Drug Discovery Approach )

Int. J. Mol. Sci. 2022, 23, 10409
10 of 29
Figure 5. The ﬂowchart of the systematic drug discovery and design procedure for OSCC. The
drug–target binding datasets were obtained from the binding database BindingDB, which integrates
the information of drugs and targets from several databases. Then, the drug and target features were
preprocessed respectively, including descriptor transformation, standardization and PCA dimension
reduction. Afterwards, the processed data were split into the training data for DNN-based DTI
model training and the testing data for DTI model performance validation in Figures 5 and 6. We
updated the model parameters through the model error between the true binding label and the
predicted binding label of drug–target pairs. The well-trained DNN-based DTI model was used to
predict the binding probability between drugs and targets (biomarkers). Therefore, candidate drugs
were predicted for each biomarker in Table 5 by the well-trained DNN-based DTI model from the
drug databases and further ﬁltered as potential drugs by the drug design speciﬁcations of suitable
regulation ability, low toxicity and high sensitivity, which are combined as a multiple-molecule drug
for OSCC in Table 6.
Figure 6. Training and validation loss of the DNN-based DTI model (ﬁve-fold cross validation).

## Page 11 (Section: Significant Biomarkers as Drug Targets for the Therapeutic Treatment of OSCC Utilizing the Systematic Drug Discovery Approach )

Int. J. Mol. Sci. 2022, 23, 10409
11 of 29
Table 5. Some candidate drugs for biomarkers of OSCC and their regulability, toxicity and sensitiv-
ity information.
HES1 (-)
Drug
Regulation Ability
(L1000)
Sensitivity (PRISM)
Toxicity
(LC50, mol/kg)
capsaicin
0.1690
−0.1217
4.202
gabazine
0.3716
−0.6103
3.079
phenolphthalein
−0.6116
−0.4833
5.297
tetramisole
0.1036
0.1136
4.111
geﬁtinib
0.2750
−0.5144
5.068
TCF (-)
Drug
Regulation Ability
(L1000)
Sensitivity (PRISM)
Toxicity
(LC50, mol/kg)
carvedilol
−0.0787
−0.0906
5.014
ﬁpronil
−0.1207
−0.0939
5.534
metformin
0.0770
−0.0789
2.039
diethylcarbamazine
0.0501
−0.0848
2.008
dyphylline
0.1372
0.0356
2.022
NF-κB (+)
Drug
Regulation Ability
(L1000)
Sensitivity (PRISM)
Toxicity
(LC50, mol/kg)
sirolimus
−0.0866
−0.2058
3.486
terfenadine
−0.7665
−0.7406
5.437
metformin
−0.2607
−0.0789
2.039
gallic-acid
−1.0620
0.6208
3.262
geﬁtinib
−0.3428
−0.5144
5.068
SP1 (+)
Drug
Regulation Ability
(L1000)
Sensitivity (PRISM)
Toxicity
(LC50, mol/kg)
niridazole
−0.6456
−0.1400
2.746
chlorambucil
−0.0559
−0.1424
3.249
bepridil
0.7249
0.2789
5.083
gallic-acid
−0.5239
0.6208
3.262
disopyramide
−0.3694
−0.1440
3.316
(+), abnormal overexpression; (-), abnormal low expression.
For our DNN-based DTI model in Figure 5, DNN was set with four hidden layers, and
each of them is connected with a ReLU activation function layer after it. ReLU activation
function could avoid vanishing gradient problems and converge much faster than the other
activation functions. Although ReLU is not the best activation function, it is useful for the
classiﬁcation issue. Additionally, the dropout layer is incorporated after each hidden layer
to prevent overﬁtting. The input layer has 996 nodes, and 512, 256, 128 and 64 neurons are
embedded, respectively, in four hidden layers. Before the output layer, a sigmoid activation
function is used to restrict the output value in the range of 0 to 1 as a probability value.
In general, the sigmoid function is usually used for binary classiﬁcation. The outcome of
DTI is a probability value, where a higher value corresponds to a more reliable interaction
(docking) between the drug and the target. The loss and accuracy during the training
process are separately recorded in Figures 6 and 7, respectively.

## Page 12 (Section: Significant Biomarkers as Drug Targets for the Therapeutic Treatment of OSCC Utilizing the Systematic Drug Discovery Approach )

Int. J. Mol. Sci. 2022, 23, 10409
12 of 29
Table 6. A potential multiple-molecule drug for OSCC from the candidate molecular drugs in Table 5
by the drug design speciﬁcations of suitable regulation ability, low toxicity and high sensitivity.
Drugs
Targets
HES1
TCF
NF-κB
SP1
Toxicity
(LC50, mol/kg)
Sensitivity
(PRISM)
metformin
(0.0770)
(−0.2607)
2.039
−0.0789
geﬁtinib
(0.2750)
(−0.3428)
5.068
−0.5144
gallic-acid
(−1.0620)
(−0.5239)
3.262
0.6208
metformin
geﬁtinib
gallic-acid
 denotes the drug that can bind to the biomarker with a desired regulation ability in (·).
Figure 7. Training and validation accuracy of the DNN-based DTI model (ﬁve-fold cross validation).
Furthermore, we also plot the receiver operating characteristic (ROC) curve measure of
the probability of the prediction accuracy of the DNN-based DTI model. The visualization
of the ROC curve comparison is denoted in Figure 8. From Figure 8, the prediction perfor-

## Page 13 (Section: Significant Biomarkers as Drug Targets for the Therapeutic Treatment of OSCC Utilizing the Systematic Drug Discovery Approach )

Int. J. Mol. Sci. 2022, 23, 10409
13 of 29
mance of our proposed DTI model indicates that the deep learning concept is promising to
adapt to the large and complicated drug–target interaction data.
 
Figure 8. The receiver operating characteristic (ROC) curve measure of the probability of the predic-
tion accuracy of the DNN-based DTI model, with the area under the curve of ROC (AUC-ROC) score
of 0.981.
To ﬁnd suitable drug candidates, predictions are made based on the high probability
of the candidate drug binding (docking) to the selected biomarker. At the same time, since
powerful drugs are often associated with a high risk of damage, attention should also
be paid to the balance between drug efﬁcacy and adverse effects. Correspondingly, we
guarantee the stability and safety of the drug in clinical trials, taking into account the drug
design speciﬁcations, such as regulatory ability, toxicity and sensitivity.
To measure the regulatory ability of drug candidates, available regulatory capacity data
were downloaded from the L1000 level5 dataset [57,58], which contains 978 genes treated
with 19,811 small molecule compounds in 78 different cell lines. In the accommodation
ability data, positive values indicate up-regulations and negative values indicate down-
regulations. Based on this criterion, we searched for molecular drugs in suitable cell lines
that could reverse the expression of carcinogenic biomarkers in OSCC to restore their
normal expressions to remedy their down streaming cellular dysfunctions of OSCC. In
addition, a lower drug toxicity has the effect of reducing side effect by referring to the
median lethal dose (LD50) value in DrugBank [59]. LD50 is often considered for disease
and cancer drug design. The lower the LD50 value, the greater the toxicity. In addition, a
higher drug sensitivity (lower EC50 value) can reduce the drug dosage. Drug susceptibility
data were obtained from the PRISM dataset [60], which includes 4518 drugs tested in
578 human cell lines based on the half-maximal effective concentration (EC50). EC50 is a
measure of the potency of a drug, where a lower EC50 indicates that the drug works best at
lower doses. As mentioned above, aberrant expression in a disease can be well reversed by
choosing the right drug. Some candidate drugs predicted by the DNN-based DTI model
for identiﬁed biomarkers and their regulability, toxicity, and sensitivity information are
shown in Table 5. The potential drugs metformin, gallic-acid and geﬁtinib are selected by
the three above-mentioned drug design speciﬁcations (i.e., suitable regulation ability, high
sensitivity and low toxicity) and are combined as a multiple-molecule drug for therapeutic
treatment of OSCC in Table 6.

## Page 14 (Section: Discussion )

Int. J. Mol. Sci. 2022, 23, 10409
14 of 29
3. Discussion
Potential Multiple-Molecule Drug for the Identiﬁed Biomarkers of OSCC
Recently, Cisplatin has been the most common drug for the treatment of OSCC [61,62],
but its powerful side effects are daunting; for example, renal toxicity, nausea, vomiting
and neurotoxicity [63]. In this study, we tried to ﬁnd novel multiple-molecular drugs to
treat OSCC. With the consideration of sensitivity, toxicity and regulation ability as drug
speciﬁcations, we combined deep learning and systems biology methods to ﬁnd the right
molecular drugs for the identiﬁed biomarkers of OSCC. Ultimately, the molecular drugs
metformin, geﬁtinib and gallic-acid are detected and combined as a multi-molecule drug in
Table 6 for the therapeutic treatment of OSCC.
Geﬁtinib is a drug that acts on the tyrosine kinase domain of the epidermal growth
factor receptor [64]. EGFR is overexpressed in certain human cancers, such as breast
and lung cancer [65,66]. The excessive activation of EGFR by the ligand EGF in the
microenvironment of OSCC leads to the abnormal activation of anti-apoptotic Ras cell
signaling, resulting in uncontrolled cell division [67,68]. Geﬁtinib binds covalently to the
enzyme adenosine triphosphate (ATP) and inhibits the epidermal growth factor receptor
tyrosine kinase [69].
Metformin, a low-cost antidiabetic drug [70], has been widely used to treat diabetes by
inhibiting hepatic gluconeogenesis and enhancing glucose uptake by skeletal muscle [71].
Several studies have shown that metformin is being repurposed as an anticancer therapeutic
for different types of cancer [72]. The insulin receptor transmits signals through growth
factor receptor binding protein 2 (GRB2) to the Ras/Raf/ERK pathway that drives cell
growth. There is evidence that these pathways play an important role in the changes
in cellular metabolism that are typical of tumor cells. Elevated circulating insulin/IGF1
levels and the upregulation of insulin/IGF receptor signaling have been implicated in the
development of various cancers. Metformin was found to reduce insulin levels, inhibit the
insulin/IGF signaling pathway and alter cellular metabolism in normal and cancer cells [73].
Interestingly, metformin can increase the sensitivity of oral cancer cells to chemotherapeutic
drugs such as geﬁtinib [74,75], improving therapeutic efﬁcacy and reducing dose and
toxicity [76]. Overall, metformin in combination with geﬁtinib may be a potential drug for
the development of new therapeutic strategies for human OSCC.
Gallic-acid is a phenolic compound widely found in the plant kingdom [77], such as
green vegetables, fruits and other plants [78]. The toxicity of gallic-acid to normal cells
of humans is very low [79]. It is highly toxic to bad cells such as ﬁbrotic cells and cancer
cells [80,81] and can kill these harmful cells; but when it encounters normal cells, the
toxicity will become weaker [82].
In summary, the molecular drugs metformin, geﬁtinib and gallic-acid are selected and
combined as a multi-molecule drug of OSCC in Table 6 from the proposed systematic drug
discovery and design perspectives.
4. Materials and Methods
4.1. A General Review of Constructing Core Genome-Wide Genetic and Epigenetic Networks
(GWGENs) of OSCC and Non-OSCC
At ﬁrst, we divided the data into a disease group and a control group. The disease group
data came from GSE30784, and the control group data came from GSE30784 and GSE17913.
Then, we used the following steps to construct core GWGENs of OSCC and non-OSCC.
(1)
Constructing the candidate GWGEN: We use big database mining to construct a
candidate PPIN and a candidate GRN, including genes, miRNAs and lncRNAs. Note
that the candidate GWGEN includes a candidate PPIN and a candidate GRN.
(2)
Identifying real GWGENs: We identify the parameters of PPIN and GRN through the
system identiﬁcation method by solving the corresponding constrained linear least
squares estimation problems with the help of the microarray data of OSCC and non-
OSCC. After performing system modeling and parameter identiﬁcation for proteins,
genes, miRNAs and lncRNAs in the candidate GWGEN, we used the system order

## Page 15 (Section: Data Preprocessing for Constructing the Candidate GWGEN )

Int. J. Mol. Sci. 2022, 23, 10409
15 of 29
detection method AIC to prune the false positives in the regulation and interactions
in the candidate GWGEN to obtain the real GWGENs of OSCC and non-OSCC.
(3)
Extracting the core GWGENs: To extract the core GWGENs of OSCC and non-OSCC,
we applied the PNP approach. By doing this, we could compute a projection value for
each node in the real GWGENs to 85% signiﬁcant network structures of real GWGENs.
The top 6000 nodes of real GWGENs with the highest projection values have remained
as core GWGENs.
(4)
Building and comparing the core signaling pathways: The core signaling pathways
for cells of OSCC and non-OSCC can be constructed by the annotation of the KEGG
pathways of core GWGENs of OSCC and non-OSCC, respectively. We investigated
the molecular mechanisms of carcinogenesis of OSCC by comparing the upstream
microenvironmental factors, core signaling pathways and their corresponding down-
stream abnormal cellular functions of OSCC and non-OSCC.
4.2. Data Preprocessing for Constructing the Candidate GWGEN
In this research, we downloaded the dataset with accession numbers GSE30784 and
GSE17913 from the National Center for Biotechnology Information (NCBI). We divided the
data into a disease group and a control group. The disease group data came from GSE30784,
and the control group data came from GSE30784 and GSE17913. Note that the candidate
GWGEN included a candidate PPIN and a candidate GRN. The candidate GWGEN matrix
is a binary matrix. If two nodes have an interaction or regulation, we assigned value one for
it; otherwise, we assigned a value zero for it. For building the candidate PPIN, we referred
to the following databases: DIP [22], IntAct [23], BioGRID [24] and MINT [25]. Moreover,
to construct the candidate GRN, we considered the following databases: HTRIdb [26],
ITFP [27], TRANSFAC [28], CircuitDB [29], TargetScanHuman [30] and StarBase 2.0 [31].
4.3. System Modeling of the Candidate GWGEN
To model the candidate GWGEN, we build system modeling for proteins, genes,
miRNAs and lncRNAs. First, in the candidate GWGEN, the following interactive equation
describes the q-th protein interaction with its Gq neighboring proteins in the candidate PPIN:
pq[n] =
Gq
∑
r = 1
κqrpq[n]pr[n] + λq,PPIM + µq,PPIM[n], for q = 1, . . . , Q, n = 1, . . . , N
where pq[n] means the expression level of the q-th protein in the n-th sample and pr[n] is the
expression level of the r-th protein in the n-th sample; κqr indicates the interaction ability
between the q-th protein and the r-th protein; Gq represents the total number of proteins
that interact with the q-th protein in the candidate PPIN; Q expresses the total number
of proteins in the candidate PPIN; N denotes the total number of samples; λq,PPIM is the
basal level in the model of the q-th protein for unknown protein interactions of histone
modiﬁcations such as phosphorylation, acetylation and ubiquitination; µq,PPIM[n] denotes
the environment and measurement noise of the q-th protein.
Second, the transcriptional regulation of the x-th gene in GRN is described by the
following equation:
gx[n] =
Ux
∑
u = 1
αxutu[n] +
Vx
∑
v=1
βxvlv[n] −
Wx
∑
w=1
γxwmw[n]gx[n] + λx,GRM + µx,GRM[n]
, for x = 1, . . . , X, n = 1, . . . , N
where gx[n] means the gene expression level of the x-th gene in the n-th sample;
tu[n], lv[n] and mw[n] individually indicate the gene expression level of the u-th TF, the
v-th lncRNA and the w-th miRNA in the n-th sample; Ux, Vx and Wx individually denote the
total binding number of TFs, lncRNAs and miRNAs; αxu is the transcriptional regulatory
ability of the u-th TF on the x-th gene; βxv expresses the transcriptional regulatory ability

## Page 16 (Section: The System Identification and System Order Detection Methods for Real GWGENs of OSCC and Non-OSCC from the Candidate GWGEN )

Int. J. Mol. Sci. 2022, 23, 10409
16 of 29
of the v-th lncRNA on the x-th gene; γxw ≥0 denotes the post-transcriptional regulatory
ability of the w-th miRNA on the x-th gene; X means the total number of genes in the
candidate GWGEN; N denotes the total number of samples; λx,GRM means the basal level
of the x-th gene because of the unknown gene regulations such as methylation and genetic
mutation; µx,GRM[n] represents the environment or measurment noise.
Third, TFs, lncRNAs and miRNAs also have a potential impact on the i-th lncRNA,
and we can depict this behavior by the lncRNA model (LRM) in the candidate GWGEN.
The regulatory equation is described as follows:
li[n] =
Ui
∑
u=1
σiutu[n] +
Vi
∑
v = 1
ςivlv[n] −
Wi
∑
w=1
τiwmw[n]li[n] + λi,LRM + µi,LRM[n]
, for i = 1, . . . , I, n = 1, . . . , N
where li[n] means the expression level of the i-th lncRNA; tu[n], lv[n] and mw[n] indicate
the expression level of the u-th TF, the v-th lncRNA and the the w-th miRNA of the n-th
sample, respectively; Ui, Vi and Wi individually represent the total binding number of
TFs, lncRNAs and miRNAs on the i-th lncRNAs, respectively; σiu is the transcriptional
regulatory ability from the u-th TF on the i-th lncRNA; ςiv expresses the transcriptional
regulatory ability from the v-th lncRNA on the i-th lncRNA; τiw ≥0 denotes the post-
transcriptional regulatory ability from the w-th miRNA on the i-th lncRNA; I denotes the
total number of lncRNAs and N means the total number of samples; λi,LRM indicates the
basal level of the i-th lncRNA; µi,LRM[n] is the data noise.
Fourth, the expression of the j-th miRNA is also affected by the TFs, lncRNAs and
miRNAs. Furthermore, we can illustrate the regulation of miRNA in the miRNA model
(MRM) of the candidate GWGEN through the following equation:
mj[n] =
Uj
∑
u=1
ωjutu[n] +
Vj
∑
v = 1
ξjvlv[n] −
Wj
∑
w=1
ψjwmw[n]mj[n] + λj,MRM + µj,MRM[n]
, for j = 1, . . . , J, n = 1, . . . , N
where mj[n] means the expression level of the j-th miRNA; tu[n], lv[n] and mw[n] separately
represent the expression level of the u-th TF, the v-th lncRNA and the w-th miRNA, re-
spectively; Uj, Vj and Wj are the binding total numbers of TFs, lncRNAs and miRNAs,
respectively; ωju expresses the transcriptional regulatory ability from the u-th TF on the
j-th miRNA; ξjv denotes the transcriptional regulatory ability from the v-th lncRNA on the
j-th miRNA; ψjw denotes the post-transcriptional regulatory ability from the w-th miRNA
on the j-th miRNA; J indicates the total number of miRNAs and N is the total number
of samples; λj.MRM represents the basal level of the j-th miRNA; µj,MRM[n] means the
data noise.
4.4. The System Identiﬁcation and System Order Detection Methods for Real GWGENs of OSCC
and Non-OSCC from the Candidate GWGEN
According to the interaction and regulation models we described above, the candidate
PPIN is generated from PPI models in (1); the candidate GRN is described and combined
by the corresponding regulation models in (2)–(4). We obtain the real GWGENs of OSCC
and non-OSCC through pruning the false positive interactions and regulations by system
identiﬁcation and system order detection methods based on the microarray data of OSCC
and non-OSCC, respectively. To identify the parameters of the above interactive and
regulatory models, Equations (1)–(4) could be respectively expressed by the following
linear regression forms.

## Page 17 (Section: The System Identification and System Order Detection Methods for Real GWGENs of OSCC and Non-OSCC from the Candidate GWGEN )

Int. J. Mol. Sci. 2022, 23, 10409
17 of 29
pq[n] =
h
pq[n]p1[n]
pq[n]p2[n]
· · ·
pq[n]pGq[n]
1
i
×


κq1
κq2
...
κqGq
λq,PPIM


+ µq,PPIM[n]
(1)
gx[n] =

t1[n]
· · ·
tUx
l1[n]
· · ·
lVx
m1[n]gx[n]
· · ·
mWx[n]gx[n]
1
 ×


αx1
...
αxUx
β1
...
βxVx
−γ1
...
−γxWx
λx,GRM


+ µx,GRM[n]
(2)
li[n] =

t1[n]
· · ·
tUi
l1[n]
· · ·
lVi
m1[n]li[n]
· · ·
mWi[n]li[n]
1
 ×


αi1
...
αiUi
β1
...
βiVi
−γ1
...
−γiWi
λi,LRM


+ µi,LRM[n]
(3)
mj[n] =
h
t1[n]
· · ·
tUj
l1[n]
· · ·
lVj
m1[n]mj[n]
· · ·
mWj[n]mj[n]
1
i
×


αj1
...
αjUj
β1
...
βjVj
−γ1
...
−γjWj
λj,MRM


+ µj,MRM[n]
(4)
for q = 1, . . . , Q, x = 1, . . . , X, i = 1, . . . , I, j = 1, . . . , J, n = 1, . . . , N, where (5)–(8) are
individually the regression forms for the protein interactions in PPIN and the regulations in
GRN in the candidate GWGEN. Q, X, I and J are, respectively, the total number of proteins,
genes, lncRNAs and miRNAs in the candidate GWGWN, and N means the total number
of samples.
The linear regression equations in (5)–(8) could be simply expressed as the follow-
ing equations:
pq[n] = φq,PPIM[n] · θq,PPIM + εq,PPIM, for q = 1, . . . , Q
(5)
gx[n] = φx,GRM[n] · θx,GRM + εx,GRM, for x = 1, . . . , X
(6)

## Page 18 (Section: The System Identification and System Order Detection Methods for Real GWGENs of OSCC and Non-OSCC from the Candidate GWGEN )

Int. J. Mol. Sci. 2022, 23, 10409
18 of 29
li[n] = φi,LRM[n] · θi,LRM + εi,LRM, for i = 1, . . . , I
(7)
mj[n] = φj,MRM[n] · θj,MRM + εj,MRM, for j = 1, . . . , J
(8)
where φq,PPIM[n], φx,GRM[n], φi,LRM[n] and φj,MRM[n] individually mean the regression
vectors of proteins, genes, lncRNAs and miRNAs in the candidate GWGEN in the n-th
sample; θq,PPIM is the parameter vector of the protein–protein interaction abilities and the
protein basal levels; θx,GRM, θi,LRM and θj,MRM respectively express the parameter vectors of
the transcriptional regulatory abilities and basal levels of the genes, lncRNAs and miRNAs;
εq,PPIM, εx,GRM, εi,LRM and εj,MRM are separately the noises for protein interactions and
regulations in the candidate GWGEN.
The above linear regression forms for N samples are denoted, respectively, as the
following:


pq[1]
pq[2]
...
pq[N]

=


φq,PPIM[1]
φq,PPIM[2]
...
φq,PPIM[N]

· θq,PPIM +


εq,PPIM[1]
εq,PPIM[2]
...
εq,PPIM[N]

, for q = 1, . . . , Q
(9)


gx[1]
gx[2]
...
gx[N]

=


φx,GRM[1]
φx,GRM[2]
...
φx,GRM[N]

· θx,GRM +


εx,GRM[1]
εx,GRM[2]
...
εx,GRM[N]

, for x = 1, . . . , X
(10)


li[1]
li[2]
...
li[N]

=


φi,LRM[1]
φi,LRM[2]
...
φi,LRM[N]

· θi,LRM +


εi,LRM[1]
εi,LRM[2]
...
εi,LRM[N]

, for i = 1, . . . , I
(11)


mj[1]
mj[2]
...
mj[N]

=


φj,MRM[1]
φj,MRM[2]
...
φj,MRM[N]

· θj,MRM +


εj,MRM[1]
εj,MRM[2]
...
εj,MRM[N]

, for j = 1, . . . , J
(12)
The above equations could be individually expressed as the following algebraic
equations:
Pq = Φq,PPIM · Θq,PPIM + Eq,PPIM, for q = 1, . . . , Q
(13)
Gx = Φx,GRM · Θx,GRM + Ex,GRM, for x = 1, . . . , X
(14)
Li = Φi,LRM · Θi,LRM + Ei,LRM, for i = 1, . . . , I
(15)
Mj = Φj,MRM · Θj,MRM + Ej,MRM, for j = 1, . . . , J
(16)
where Φq,PPIM, Φx,GRM, Φi,LRM and Φj,MRM separately express the regression matrix of
proteins, genes, lncRNAs and miRNAs of N samples. Θq,PPIM, Θx,GRM, Θi,LRM and Θj,MRM
individually mean the corresponding interactive and regulatory parameter vectors. Eq,PPIM,
Ex,GRM, Ei,LRM and Ej,MRM respectively denote the corresponding data noise vectors.
To identify the interactive and regulatory parameter of the candidate GWGEN, we
estimate the parameter vectors θq,PPIM, θq,GRM, θq,LRM and θq,MRM by the least square
method with the negative regulation constraint on miRNA, as follows:
ˆΘq,PPIM = argmin
Θq,PPIM
1
2∥Φq,PPIM · Θq,PPIM −Pq∥2
2
(17)

## Page 19 (Section: The System Identification and System Order Detection Methods for Real GWGENs of OSCC and Non-OSCC from the Candidate GWGEN )

Int. J. Mol. Sci. 2022, 23, 10409
19 of 29
ˆΘx,GRM = argmin
Θx,GRM
1
2∥Φx,GRM · Θx,GRM −Gx∥2
2
subject to


0
0
· · ·
· · ·
0
0
0
· · ·
· · ·
0
...
...
...
...
...
...
...
...
...
...
0
0
· · ·
· · ·
0
|
{z
}
Ui

0
0
· · ·
· · ·
0
0
0
· · ·
· · ·
0
...
...
...
...
...
...
...
...
...
...
0
0
· · ·
· · ·
0
|
{z
}
Vi

1
0
· · ·
· · ·
0
0
1
· · ·
· · ·
0
...
...
...
...
...
0
0
...
1
0
0
0
· · ·
0
1
|
{z
}
Wi

0
0
...
...
0


Θi,GRM ≤


0
0
...
...
0


(18)
ˆΘi,LRM = argmin
Θi,LRM
1
2∥Φi,LRM · Θi,LRM −Li∥2
2
subject to


0
0
· · ·
· · ·
0
0
0
· · ·
· · ·
0
...
...
...
...
...
...
...
...
...
...
0
0
· · ·
· · ·
0
|
{z
}
Ui

0
0
· · ·
· · ·
0
0
0
· · ·
· · ·
0
...
...
...
...
...
...
...
...
...
...
0
0
· · ·
· · ·
0
|
{z
}
Vi

1
0
· · ·
· · ·
0
0
1
· · ·
· · ·
0
...
...
...
...
...
0
0
...
1
0
0
0
· · ·
0
1
|
{z
}
Wi

0
0
...
...
0


Θi,LRM ≤


0
0
...
...
0


(19)
ˆΘj,MRM = argmin
Θj,MRM
1
2∥Φj,MRM · Θj,MRM −Mj∥2
2
subject to


0
0
· · ·
· · ·
0
0
0
· · ·
· · ·
0
...
...
...
...
...
...
...
...
...
...
0
0
· · ·
· · ·
0
|
{z
}
Uj

0
0
· · ·
· · ·
0
0
0
· · ·
· · ·
0
...
...
...
...
...
...
...
...
...
...
0
0
· · ·
· · ·
0
|
{z
}
Vj

1
0
· · ·
· · ·
0
0
1
· · ·
· · ·
0
...
...
...
...
...
0
0
...
1
0
0
0
· · ·
0
1
|
{z
}
Wj

0
0
...
...
0


Θj,MRM ≤


0
0
...
...
0


(20)
For the constrained optimization problems for the parameter estimation problems
(21)–(24), we look for the optimal parameter estimates of the candidate GWGEN through
the microarray data of OSCC and non-OSCC as follows: interactive parameters between
proteins ˆΘq,PPIM, the regulatory parameters of genes ˆΘx,GRM, lncRNAs ˆΘi,LRM and miR-
NAs ˆΘj,MRM. These constrained optimization problems for the parameter estimation of
the candidate GWGEN were solved by the MATLAB Optimization Toolbox. It is worth
noting that the negative inequality constraints in (22)–(24) represent that the regulatory
parameters of miRNAs should be less than or equal to zero to ensure the negative regulation
of miRNAs on genes, lncRNAs and miRNAs.
After the parameter estimation of the candidate GWGEN of non-OSCC and OSCC by
the respective microarray data, we used the system order detection method, AIC, to detect
the system order (the number of interactions of each protein or the number of regulations
of each gene, lncRNA and miRNA). The equations of AIC for each protein, gene, lncRNA
and miRNA are given as follows.
AIC(Qq) = log(Ωq,PPIM)+ 2(Gq+1)
N
, for q = 1, . . . , Q
whereΩq,PPIM = (Pq−Φq,PPIM· ˆΘq,PPIM)T(Pq−Φq,PPIM· ˆΘq,PPIM)
N
(21)

## Page 20 (Section: The System Identification and System Order Detection Methods for Real GWGENs of OSCC and Non-OSCC from the Candidate GWGEN )

Int. J. Mol. Sci. 2022, 23, 10409
20 of 29
where Ωq,PPIM is the estimated residual error of the q-th protein from the least square
parameter estimation ˆΘq,PPIM in (21), and Qq means the number of protein interactions
with the q-th protein.
AIC(Ux, Vx, Wx) = log(Ωx,GRM)+ 2(Ox,GRM+1)
N
, for x = 1, . . . , X
where Ωx,GRM = (Gx−Φx,GRM· ˆΘx,GRM)T(Gx−Φx,GRM· ˆΘx,GRM)
N
, Ox,GRM = Ux + Vx + Wx
(22)
where Ωx,GRM means the estimated residual error of the x-th gene in (22), and Ox,GRM is
the number of regulations of the genes, lncRNAs and miRNAs on the x-th gene; ˆΘx,GRM
denotes the estimated parameters in (22).
AIC(Ui, Vi, Wi) = log(Ωi,LRM)+ 2(Oi,LRM+1)
N
, for i = 1, . . . , I
where Ωi,LRM = (Li−Φi,LRM· ˆΘi,LRM)T(Li−Φi,LRM· ˆΘi,LRM)
N
, Oi,LRM = Ui + Vi + Wi
(23)
where Ωi,LRM denotes the estimated residual error of the i-th lncRNA in (23), and Oi,LRM is
the number of regulations of the genes, lncRNAs and miRNAs on the i-th lncRNA; ˆΘi,LRM
indicates the estimated parameters in (23).
AIC(Uj, Vj, Wj) = log(Ωj,MRM)+
2(Oj,MRM+1)
N
, for j = 1, . . . , J
where Ωj,MRM =
(Mj−Φj,MRM· ˆΘj,MRM)T(Mj−Φj,MRM· ˆΘj,MRM)
N
, Oj,MRM = Uj + Vj + Wj
(24)
where Ωj.MRM denotes the estimated residual error of the j-th miRNA in (24), and Oj.MRM
indicates the number of regulations of the genes, lncRNAs and miRNAs on the j-th miRNA;
ˆΘj,MRM denotes the estimated parameters in (24).
The AIC system order detection method in (25) means that if the system order (number
interactions) Qq increases, the second term of AIC in (25) will increase and the ﬁrst term
of AIC will decrease, and vice versa. The real number of interactions (system order) Qq*
will balance two terms and achieve the minimum AIC (Qq). Therefore, employ the AIC
technique to determine the real number of interactions or regulations for each protein, gene,
miRNA and lncRNA by their AICs in (25)–(28) in the candidate GWGEN to prune the false
positive interactions and regulations and obtain the real GWGENs of OSCC and non-OSCC
in the following.
Considering the order detection method of AIC in system identiﬁcation, the real order
of the system (i.e., the total number of interactions of the q-th protein in (1) or the number
of regulations on the x-th in (2)) is to minimize the AIC problems of system identiﬁcation
in (21)–(28). Therefore, the real number of interactions or regulations for every protein,
gene, lncRNA and miRNA in the candidate GWGEN can be obtained by solving the AIC
minimization problems below:
Q∗
q = argmin
Qq
AIC(Gq), for q = 1, . . . , Q
(25)
(U∗
x, V∗
x , W∗
x ) = argmin
Ux,Vx,Wx
AIC(Ux, Vx, Wx), for x = 1, . . . , X
(26)
(U∗
i , V∗
i , W∗
i ) = argmin
Ui,Vi,Wi
AIC(Ui, Vi, Wi), for i = 1, . . . , I
(27)
(U∗
j , V∗
j , W∗
j ) = argmin
Uj,Vj,Wj
AIC(Uj, Vj, Wj), for j = 1, . . . , J
(28)
where Q∗
q means the real number of protein interactions for the q-th protein; U∗
x, V∗
x and W∗
x
respectively express the real number of regulations of genes, lncRNAs and miRNAs on
the x-th gene; U∗
i , V∗
i and W∗
i represent the real number of regulations of genes, lncRNAs
and miRNAs on the i-th lncRNA, respectively; U∗
j , V∗
j and W∗
j are individually the real
number of regulations of genes, lncRNAs and miRNAs on the j-th miRNA. Therefore, the

## Page 21 (Section: The Principal Network Projection (PNP) Method for the Core GWGENs by Extracting from Real GWGENs )

Int. J. Mol. Sci. 2022, 23, 10409
21 of 29
interactions of proteins and the regulations of the gene, miRNA and lncRNA, which are
out of real order by solving the AIC minimization problems in (29)–(32), are thought of as
false positives in the candidate GWGEN of non-OSCC and OSCC and should be pruned
out to obtain the real GWGENs of non-OSCC and OSCC in Figure 2, respectively.
4.5. The Principal Network Projection (PNP) Method for the Core GWGENs by Extracting from
Real GWGENs
We want to compare the signaling pathways of non-OSCC and OSCC to investigate
their genetic and epigenetic carcinogenic molecular mechanism. Therefore, we need to
transform real GWGENs of non-OSCC and OSCC to signaling pathways of non-OSCC
and OSCC, respectively, by the annotation of KEGG pathways. However, at present,
only a GWGEN with 6000 nodes at most can be annotated by KEGG signal pathways.
Therefore, the principal network projection (PNP) method on the basis of the singular value
decomposition (SVD) is employed to extract the core GWGENs with 6000 nodes from the
real GWGENs for the annotation of core signaling pathways by KEGG pathways. Before we
extract the core GWGENs, a network matrix H of real GWGENs should be introduced. The
network matrix H consists of interactions among proteins and regulations of the TF-gene,
TF-lncRNA, TF-miRNA, lncRNA-gene, lncRNA-lncRNA, lncRNA-miRNA, miRNA-gene,
miRNA-lncRNA and miRNA-miRNA in real GWGENs, as follows:
H =


hprotein⇔protein
0
0
hTF⇒gene
hln cRNA⇒gene
hmiRNA⇒gene
hTF⇒ln cRNA
hln cRNA⇒ln cRNA
hmiRNA⇒ln cRNA
hTF⇒miRNA
hln cRNA⇒miRNA
hmiRNA⇒miRNA


(29)
where hprotein⇔protein is the sub-matrix of PPIs, of which the bidirectional arrow at the
subscript of the sub-matrix means that the protein interaction is bidirectional; hTF⇒gene,
hTF⇒ln cRNA, hTF⇒miRNA, hln cRNA⇒gene, hln cRNA⇒ln cRNA, hln cRNA⇒miRNA, hmiRNA⇒gene,
hmiRNA⇒ln cRNA and hmiRNA⇒miRNA represent the transcriptional regulatory sub-matrixes
of TFs on genes, lncRNAs and miRNAs; lncRNAs on genes, lncRNAs and miRNAs; and
miRNAs on genes, lncRNAs and miRNAs, respectively. The network matrix H of real
GWGENs is given in detail, as follows:
H =


ˆκ11
ˆκ12
· · ·
ˆκ1r
· · ·
ˆκ1Qq
0
0
· · ·
0
· · ·
0
0
0
· · ·
0
· · ·
0
ˆκ21
ˆκ22
· · ·
ˆκ2r
· · ·
ˆκ2Qq
0
0
· · ·
0
· · ·
0
0
0
· · ·
0
· · ·
0
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
ˆκq1
ˆκq2
· · ·
ˆκqr
· · ·
ˆκqQq
0
0
· · ·
0
· · ·
0
0
0
· · ·
0
· · ·
0
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
ˆκQ1
ˆκQ1
· · ·
ˆκQ1
· · ·
ˆκQQq
0
0
· · ·
0
· · ·
0
0
0
· · ·
0
· · ·
0
ˆα11
ˆα12
· · ·
ˆα1u
· · ·
ˆα1Ux
ˆβ11
ˆβ12
· · ·
ˆβ1v
· · ·
ˆβ1Vx
ˆγ11
ˆγ12
· · ·
ˆγ1w
· · ·
ˆγ1Wx
ˆα21
ˆα22
· · ·
ˆα2u
· · ·
ˆα2Ux
ˆβ21
ˆβ22
· · ·
ˆβ2v
· · ·
ˆβ2Vx
ˆω21
ˆω22
· · ·
ˆγ2w
· · ·
ˆγ2Wx
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
ˆαx1
ˆαx2
· · ·
ˆαxu
· · ·
ˆαxUx
ˆβx1
ˆβx2
· · ·
ˆβxv
· · ·
ˆβxVx
ˆγx1
ˆγx2
· · ·
ˆγxw
· · ·
ˆγxWx
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
ˆαX1
ˆαX2
· · ·
ˆαXu
· · ·
ˆαXUx
ˆβX1
ˆβX2
· · ·
ˆβXv
· · ·
ˆβXVx
ˆγX1
ˆγX2
· · ·
ˆγXw
· · ·
ˆγXWx
ˆσ11
ˆσ12
· · ·
ˆσ1u
· · ·
ˆσ1Ui
ˆς11
ˆς12
· · ·
ˆς1v
· · ·
ˆς1Vi
ˆτ11
ˆτ12
· · ·
ˆτ1w
· · ·
ˆτ1Wi
ˆσ21
ˆσ22
· · ·
ˆσ2u
· · ·
ˆσ2Ui
ˆς21
ˆς22
· · ·
ˆς2v
· · ·
ˆς2Vi
ˆτ21
ˆτ22
· · ·
ˆτ2w
· · ·
ˆτ2Wi
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
ˆσi1
ˆσi2
· · ·
ˆσiu
· · ·
ˆσiUi
ˆςi1
ˆςi2
· · ·
ˆςiv
· · ·
ˆςiVi
ˆτi1
ˆτi2
· · ·
ˆτiw
· · ·
ˆτiWi
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
ˆσI1
ˆσI2
· · ·
ˆσIu
· · ·
ˆσIUi
ˆςI1
ˆςI2
· · ·
ˆςIv
· · ·
ˆςIVi
ˆτI1
ˆτI2
· · ·
ˆτIw
· · ·
ˆτIWi
ˆω11
ˆω12
· · ·
ˆω1u
· · ·
ˆω1Uj
ˆξ11
ˆξ12
· · ·
ˆξ1v
· · ·
ˆξ1Uj
ˆψ11
ˆψ12
· · ·
ˆψ1w
· · ·
ˆψ1Wj
ˆω21
ˆω22
· · ·
ˆω2u
· · ·
ˆω2Uj
ˆξ21
ˆξ22
· · ·
ˆξ2v
· · ·
ˆξ2Uj
ˆψ21
ˆψ22
· · ·
ˆψ2w
· · ·
ˆψ2Wj
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
ˆωj1
ˆωj2
· · ·
ˆωju
· · ·
ˆωjUj
ˆξj1
ˆξj2
· · ·
ˆξjv
· · ·
ˆξjUj
ˆψj1
ˆψj2
· · ·
ˆψjw
· · ·
ˆψjWj
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
...
ˆωJ1
ˆωJ2
· · ·
ˆωJu
· · ·
ˆωJUj
ˆξJ1
ˆξJ2
· · ·
ˆξJv
· · ·
ˆξJUj
ˆψJ1
ˆψJ2
· · ·
ˆψJw
· · ·
ˆψJWj


∈R(Q∗+X∗+I∗+J∗)×(U∗+V∗+W∗)
(30)

## Page 22 (Section: The Principal Network Projection (PNP) Method for the Core GWGENs by Extracting from Real GWGENs )

Int. J. Mol. Sci. 2022, 23, 10409
22 of 29
where ˆκqr denotes the interaction ability between the q-th protein and the r-th protein;
ˆαxu, ˆβxv and ˆγxw are respectively the regulation abilities of the u-th TF on the x-th gene,
the v-th lncRNA on the x-th gene and the w-th miRNA on the x-th gene; ˆσiu, ˆςiv and ˆτiw
individually express the regulation abilities of the u-th TF on the i-th lncRNA, the v-th
lncRNA on the i-th lncRNA and the w-th miRNA on the i-th lncRNA; ˆωju, ˆξjv and ˆψjw
respectively mean the regulation abilities of the u-th TF on the j-th miRNA, the v-th lncRNA
on the j-th miRNA and the w-th miRNA on the w-th miRNA. Moreover, if there is neither
interaction nor regulation between the source and the target, some zeros should be padded
in the network matrix in (34). Then, the core GWGENs were obtained by using PNP on the
network matrix H with a signiﬁcant energy threshold of 85%. First, the network matrix H
is decomposed by singular value decomposition (SVD), as follows [11,83]:
H = SVDT
(31)
where S ∈R(Q∗+X∗+I∗+J∗)×(Q∗+X∗+I∗+J∗) and DT ∈R(U∗+V∗+W∗)×(U∗+V∗+W∗) are uni-
tary singular matrices; V = diag(v1, · · · , vi, · · · vU∗+V∗+W∗) ∈R(Q∗+X∗+I∗+J∗)×(U∗+V∗+W∗)
means the diagonal matrix of which the components at the diagonal are the singular
values of H and are arranged in descending order, i.e., v1 ≥v2 ≥· · · ≥vi ≥· · · ≥
vU∗+V∗+W∗≥0.
V =


v1
0
· · ·
0
· · ·
0
0
v2
· · ·
0
· · ·
0
...
...
...
...
...
...
0
0
· · ·
vi
· · ·
0
...
...
...
...
...
...
0
0
· · ·
0
· · ·
vU∗+V∗+W∗
0
0
· · ·
0
· · ·
0
...
...
...
...
...
...
0
0
· · ·
0
· · ·
0


(32)
Moreover, the normalization of singular values in (36) is deﬁned as follows.
Ei =
v2
i
U∗+V∗+W∗
∑
i=1
v2
i
and
U∗+V∗+W∗
∑
i=1
Ei = 1
(33)
I
∑
i=1
Ei ≥0.85
(34)
From the above equation, we chose the top I signiﬁcant singular vector structures to
indicate the signiﬁcant energy of real GWGENs, which is equal or more than the threshold
of 0.85. Then, we separately projected every node of real GWGENs (i.e., each row of the
network matrix H) to the top I signiﬁcant singular vectors, as follows.
Z(a, b) = ha,: · dT
b,:, for a = 1, . . . , Q∗+ X∗+ I∗+ J∗, b = 1, . . . , I
(35)
where Z(a, b) means the projection value of the a-th node on the b-th signiﬁcant singular
vector; ha,; is the a-th row vector of the network matrix H and dT
:,b expresses the b-th
column of DT, i.e., the transpose of the b-th singular vector. Then, we deﬁne the two-norm
projection value of each node such as protein, gene, lnRNA and miRNA in real GWGENs
on the top I signiﬁcant singular vectors as follows:
S(a) =
v
u
u
t
I
∑
i=1
Z2(a, b), for a = 1, . . . , Q∗+ X∗+ I∗+ J∗
(36)

## Page 23 (Section: Systematic Drug Discovery Based on the Drug/Target Interaction Prediction by the DNN-Based DTI Model and Drug Design Specifications for OSCC )

Int. J. Mol. Sci. 2022, 23, 10409
23 of 29
According to the two-norm projection values in (40), the top 6000 signiﬁcant proteins,
genes, miRNAs and lncRNAs with high projection values were chosen to comprise the core
GWGENs for OSCC and non-OSCC in Figure 3. Then, the core GWGENs were submitted
to the Database for Annotation, Visualization and Integrated Discovery (DAVID) website to
conduct the KEGG pathway enrichment analysis in Tables 3 and 4, and the core signaling
pathways of non-OSCC and OSCC in Figure 4 were obtained by exploring the annotation of
KEGG pathways. The enrichment analysis was used to check which signiﬁcant pathways
of our results were important to OSCC. Finally, the potential biomarkers were identiﬁed in
Table 5 for the OSCC carcinogenic mechanism investigated by comparing the core signaling
pathways and their downstream abnormal cellular functions of non-OSCC and OSCC in
Figure 4.
4.6. Systematic Drug Discovery Based on the Drug/Target Interaction Prediction by the
DNN-Based DTI Model and Drug Design Speciﬁcations for OSCC
Based on drug/target (biomarker) prediction and drug design speciﬁcations, we want
to discover a potential multiple-molecule drug for the carcinogenic biomarkers on OSCC.
First, we trained a DTI model based on a deep neural network (DNN) to predict the drug–
target interactions between the drugs and targets (biomarkers). However, it is not enough
to only consider the interactions between the molecular drugs and the targets in drug
design. Some drug design speciﬁcations, i.e., adequate regulation ability, low toxicity and
high sensitivity, are necessary to ﬁlter the candidate drugs predicted by the DNN-based
DTI model. This systems drug discovery method is introduced in the following paragraphs
for designing a multiple-molecule drug for OSCC treatment before clinical trials.
The ﬂowchart of the systematic drug discovery method is shown in Figure 5. First,
drug–target interaction databases by UniProt [84], DrugBank [59], ChEMBL [85] and
Pubchem [86] are combined to train DNN as the DTI model for drug–target interaction pre-
diction. In a few years, the feature-based method, i.e., molecular descriptor, will be widely
used to describe the structural and chemical properties of molecules such as characteristics
from the 2D, 3D spectrum of the structure, molecular weight, hydrophilic and hydropho-
bicity, etc. The chemical properties of the drug and genomic sequence of the target could
be described with the molecular descriptor for the purpose of convenient analysis in drug
design since the molecular descriptor can transform complicated chemical properties into a
feature vector. We used the molecule descriptor function and protein descriptor function of
python package pyBioMed to transform the drug and target into descriptors as drug and
target features, respectively, under the python2.7 environment. Drug features of molecule
descriptors include constitutional descriptors, connectivity indices, E-state indices, charge
descriptors, molecular properties and kappa shape indices. For the target features, the
protein descriptor calculates the structural and physicochemical features of proteins and
peptides from the amino acid sequence such as amino acid composition, dipeptide com-
position, etc. For more detailed information about the descriptor transformation, readers
can access the documents of pyBioMed. The drug descriptor and the target descriptor are
combined into the feature vector corresponding to the drug–target pair, as follows:
vdrug–target = [D, T] = [d1, d2, · · · , dM, t1, t2, · · · , tN]
(37)
where the former symbol D in vdrug–target is deﬁned as the drug descriptor and the latter
symbol T is the target descriptor. d1 means the ﬁrst drug feature; t1 represents the ﬁrst
target feature; M indicates the total number of features of the drug and N expresses the
total number of features of the target. We have 363 features for the drug and 996 features
for the target.
Before training our DNN-based DTI model, we encountered several problems: features
of different scales will affect our results—for example, large-scale features will have a great
dominance in the training process. There are far more unveriﬁed data in the data than
veriﬁed data, so there exists a between-class imbalance issue which could lead to a biased
parameter updating tendency to the larger class during the training process.

## Page 24 (Section: Systematic Drug Discovery Based on the Drug/Target Interaction Prediction by the DNN-Based DTI Model and Drug Design Specifications for OSCC )

Int. J. Mol. Sci. 2022, 23, 10409
24 of 29
To remedy the imbalance issue, we have to solve the problem of scale ﬁrst. We
use the min-max normalization to deal with this problem. Min-max normalization can
handle this problem effectively, but compared to normalization, it is very sensitive to
outliers. Additionally, feature normalization is performed before principal component
analysis (PCA) to improve the DNN-based DTI model training performance. Therefore,
the normalization to the features is given as follows:
d∗
i = di −µi
σi
, ∀i = 1, . . . , M
(38)
t∗
j = tj −µj
σj
, ∀j = 1, . . . , N
(39)
where di denotes the i-th drug feature and d∗
i
expresses the i-th drug feature after the
standardization; µi and σi respectively denote the mean and standard deviations of the i-th
drug feature; tj means the j-th feature of the target and t∗
j represents the j-th feature of the
target after standardization; µj and σj separately indicate the mean and standard deviation
of the j-th target feature; M expresses the total number of drug features and N denotes the
total number of target features.
In our data, the number of proven drug–target interaction samples, called the positive
class, is 1455, and the number of unveriﬁed drug–target interaction samples, called the
negative class, is much larger than the positive class. There exists a huge difference in the
amount between the negative class and the positive class, which leads to the between-class
imbalance issue. Before training the DNN-based DTI model, we also implemented data
preprocessing by the principal component analysis (PCA) method—(35)–(40)—to reduce
the dimension of the features of the drug and target to the dimension of the input of DNN.
The PCA extraction was conducted after down-sampling and standardization to ensure
that the PCA could accurately project the original data on the feature plane. It is worth
noting that data preprocessing, e.g., PCA, is only conducted in training data because testing
data should be deemed unknown to the model. The drug features were selected by the top
85% with higher singular values. The insigniﬁcant features of the drug and the target lower
than the dimension of the input of DNN are deleted, and the remainders were employed
to train DNN as the DTI model to predict candidate drugs for biomarkers (drug targets)
of OSCC.
We referenced the basic concept and knowledge of DNN to train a DNN-based DTI
model to predict drug–target interaction through the python Tensorﬂow and Keras package
under the python3.7 environment. In the model structure of the DNN-based DTI model in
Figure 4, the function in a feedforward step can be denoted as follows:
h = σ(wx + b)
(40)
where x and h respectively denote the input and output; w is the weighting matrix and b
is the bias vector; σ (.) indicates the activation function with ReLU in the hidden layer and
the sigmoid function at the output layer. Since the binary classiﬁcation issue is concerned,
the binary-cross entropy is chosen as the cost function to calculate the model loss [11]:
Cn(w, b) = −[ ˆpn log pn + (1 −ˆpn)log(1 −pn)]
(41)
L(w, b) = 1
N
N
∑
n=1
Cn(w, b)
(42)
where pn means the truth label of positive interaction; ˆpn indicates the predictive probability
of positive interaction, and 1 −pn shows the truth label of negative interaction; 1 −ˆpn
represents the predicted probability of negative interaction; L(w, b) denotes the average
of total loss Cn(w, b). According to the cost function, the backward propagation algorithm
is applied to update the model parameter set θ containing the weighting matrix w and the

## Page 25 (Section: Conclusions )

Int. J. Mol. Sci. 2022, 23, 10409
25 of 29
bias vector b through calculating the gradient of the cost function in (46) and eventually
obtain the optimal solution θ∗in (48), as follows.
θ =
w
b

(43)
θ∗= argmin
θ
L(θ)
(44)
θl = θl−1 −η∇L(θl−1)
(45)
where l is the l-th epoch of the learning procedure; η is learning rate and ∇L

θl−1
is the
gradient of L

θl−1
, as follows:
∇L(θl−1) =
" ∂L(θl−1)
∂w
∂L(θl−1)
∂b
#
(46)
Based on the backward propagation method, the DNN-based DTI model could adjust
the parameters to ﬁt the drug–target interaction data at each iteration well.
In addition, the hyperparameters were tuned to not only lower the training time but
also achieve the best model performance. We used an optimizer with default settings and
set the learning rate to 0.003 to make model parameter θ converge faster and precisely.
We set 100 for epochs and 100 for batch size. For the data, we split one-fourth of the
data as testing data and three-fourths of it as training data. Moreover, we divided the
training data into ﬁve equal folds to perform the ﬁve-fold cross-validation strategy. In
the ﬁve-fold data, four-ﬁfths of them were for the model training and one-ﬁfth of them
was used as the validation data, which play the role of supervisor to check whether the
model was better than that of the former epoch. Additionally, ﬁve-fold cross-validation
could verify the stability of the data and model. To avoid model overﬁtting, we applied an
early stopping strategy to check if the test accuracy decreased when the training accuracy
increased continuously. Moreover, we embedded the dropout layer after each hidden
layer to further prevent model overﬁtting and set 0.4 for the dropout rate. After training
the DNN-based DTI model, we adopted a performance measurement AUC (area under
the curve) score and ROC (receiver operating characteristics) curve in Figure 8 to check
the model performance. It is one of the most useful evaluation metrics to visualize the
model performance when it comes to the classiﬁcation problems. The higher the AUC score
(which means the area under the line is larger), the better the accuracy is for the DNN-based
DTI model in predicting the true positive and true negative drug–target interaction. The
formulas for the AUC score and ROC curve are shown below [83].
TPR(True Positive Rate) =
TP
TP + FN
(47)
speciﬁcity =
TN
TN + FP
(48)
FPR(False Positive Rate) = 1 −speciﬁcity =
FP
TN + FP
(49)
where TP (True Positive) means that the real value is true and is judged correctly; TN shows
that the real value is true and is judged by mistake; FP indicates that the real value is false
and is judged accurately; FN represents that the real value is false and is judged in error.
5. Conclusions
In this study, based on our proposed combination of systems biology and systems
drug discovery design methods, we investigated the complex carcinogenic molecular
mechanisms of OSCC from genome-wide data, genetic and epigenetic network perspectives,

## Page 26 (Section: Conclusions )

Int. J. Mol. Sci. 2022, 23, 10409
26 of 29
and designed prospective multiple-molecular drugs as a multi-molecule drug to target
multiple biomarkers of OSCC. We construct a genetic and epigenetic biological network
by exploring methods of systematic identiﬁcation and systematic sequential detection
of big data. Afterwards, we extracted core signaling pathways by the PNP method and
KEGG pathway annotation to select important biomarkers from OSCC carcinogenesis by
comparing core signaling pathways and their downstream abnormal cellular functions. To
discover drug candidates that interact with these biomarkers, we trained a DNN-based
DTI model by DTI databases to predict drug–target interaction probability values. In
addition, we took the drug regulation ability, low toxicity and high sensitivity as the drug
design criteria to screen out suitable potential drugs from the predicted drug candidates.
Therefore, a set of combined multi-molecular drugs is proposed as a multi-molecule drug
for OSCC treatment. In the future, more and more different types of genomics data will
be available for epigenetic and epigenetic regulations. A combination of multiple types of
genomics data is needed to help us enhance our work and gain a deeper understanding of
the signiﬁcant biomarkers of the carcinogenic mechanism of OSCC. It is anticipated that
the proposed systems biology and systems drug discovery design approach may provide
new directions for OSCC treatment.
Author Contributions: Conceptualization, Y.-C.L. and B.-S.C.; methodology, Y.-C.L. and B.-S.C.;
software, Y.-C.L. and B.-S.C.; validation, Y.-C.L. and B.-S.C.; formal analysis, Y.-C.L. and B.-S.C.;
investigation, Y.-C.L. and B.-S.C.; data curation, Y.-C.L.; writing—original draft preparation, Y.-C.L.;
writing—review and editing, Y.-C.L. and B.-S.C.; visualization, Y.-C.L.; supervision, B.-S.C.; funding
acquisition, B.-S.C. All authors have read and agreed to the published version of the manuscript.
Funding: This research received no external funding.
Institutional Review Board Statement: Not applicable.
Informed Consent Statement: Not applicable.
Data Availability Statement: The gene raw count datasets of human genes are integrated from
GSE30784 (https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE30784, accessed on 1 Novem-
ber 2021) and GSE17913 (https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE17913, ac-
cessed on 1 November 2021). The drug regulation ability data are from Phase I L1000 Level 5
datasets (https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE92742, accessed on 1 Novem-
ber 2021). The drug sensitivity datasets are from DepMapPRISM primary screen datasets (https:
//depmap.org/repurposing/, accessed on 1 November 2021).
Conﬂicts of Interest: The authors declare no conﬂict of interest.
References
1.
Da Silva, S.D.; Marchi, F.A.; Xu, B.; Bijian, K.; Alobaid, F.; Mlynarek, A.; Rogatto, S.R.; Hier, M.; Kowalski, L.P.; Alaoui-Jamali,
M.A. Predominant Rab-GTPase amplicons contributing to oral squamous cell carcinoma progression to metastasis. Oncotarget
2015, 6, 21950. [CrossRef] [PubMed]
2.
Petersen, P.E. Oral cancer prevention and control–the approach of the World Health Organization. Oral Oncol. 2009, 45, 454–460.
[CrossRef] [PubMed]
3.
Andisheh-Tadbir, A.; Mehrabani, D.; Heydari, S.T. Epidemiology of squamous cell carcinoma of the oral cavity in Iran. J.
Craniofacial Surg. 2008, 19, 1699–1702. [CrossRef] [PubMed]
4.
Dissanayaka, W.L.; Pitiyage, G.; Kumarasiri, P.V.R.; Liyanage, R.L.P.R.; Dias, K.D.; Tilakaratne, W.M. Clinical and histopathologic
parameters in survival of oral squamous cell carcinoma. Oral Surg. Oral Med. Oral Pathol. Oral Radiol. 2012, 113, 518–525.
[CrossRef] [PubMed]
5.
Chen, Y.J.; Chang, J.T.C.; Liao, C.T.; Wang, H.M.; Yen, T.C.; Chiu, C.C.; Lu, Y.C.; Li, H.F.; Cheng, A.J. Head and neck cancer in the
betel quid chewing area: Recent advances in molecular carcinogenesis. Cancer Sci. 2008, 99, 1507–1514. [CrossRef] [PubMed]
6.
Otero-Rey, E.M.; Suarez-Alen, F.; Peñamaria-Mallon, M.; Lopez-Lopez, J.; Blanco-Carrion, A. Malignant transformation of oral
lichen planus by a chronic inﬂammatory process. Use of topical corticosteroids to prevent this progression? Acta Odontol. Scand.
2014, 72, 570–577. [CrossRef]
7.
Tang, D.; Tao, D.; Fang, Y.; Deng, C.; Xu, Q.; Zhou, J. TNF-alpha promotes invasion and metastasis via NF-kappa B pathway in
oral squamous cell carcinoma. Med. Sci. Monit. Basic Res. 2017, 23, 141. [CrossRef]
8.
Scully, C.; Field, J.; Tanzawa, H. Genetic aberrations in oral or head and neck squamous cell carcinoma (SCCHN): 1. Carcinogen
metabolism, DNA repair and cell cycle control. Oral Oncol. 2000, 36, 256–263. [CrossRef]

## Page 27 (Section: Conclusions )

Int. J. Mol. Sci. 2022, 23, 10409
27 of 29
9.
Feller, L.; Altini, M.; Lemmer, J. Inﬂammation in the context of oral cancer. Oral Oncol. 2013, 49, 887–892. [CrossRef]
10.
Harada, K.; Ferdous, T.; Itashiki, Y.; Takii, M.; Mano, T.; Mori, Y.; Ueyama, Y. Cepharanthine inhibits angiogenesis and
tumorigenicity of human oral squamous cell carcinoma cells by suppressing expression of vascular endothelial growth factor and
interleukin-8. Int. J. Oncol. 2009, 35, 1025–1035. [CrossRef]
11.
Chang, S.; Chen, J.-Y.; Chuang, Y.-J.; Chen, B.-S. Systems Approach to Pathogenic Mechanism of Type 2 Diabetes and Drug
Discovery Design Based on Deep Learning and Drug Design Speciﬁcations. Int. J. Mol. Sci. 2020, 22, 166. [CrossRef] [PubMed]
12.
Ting, C.-T.; Chen, B.-S. Repurposing Multiple-Molecule Drugs for COVID-19-Associated Acute Respiratory Distress Syndrome
and Non-Viral Acute Respiratory Distress Syndrome via a Systems Biology Approach and a DNN-DTI Model Based on Five
Drug Design Speciﬁcations. Int. J. Mol. Sci. 2022, 23, 3649. [CrossRef] [PubMed]
13.
Yeh, S.-J.; Chang, C.-A.; Li, C.-W.; Wang, L.H.-C.; Chen, B.-S. Comparing progression molecular mechanisms between lung
adenocarcinoma and lung squamous cell carcinoma based on genetic and epigenetic networks: Big data mining and genome-wide
systems identiﬁcation. Oncotarget 2019, 10, 3760. [CrossRef]
14.
Li, C.-W.; Jheng, B.-R.; Chen, B.-S. Investigating genetic-and-epigenetic networks, and the cellular mechanisms occurring in
Epstein–Barr virus-infected human B lymphocytes via big data mining and genome-wide two-sided NGS data identiﬁcation.
PLoS ONE 2018, 13, e0202537.
15.
Hughes, J.P.; Rees, S.; Kalindjian, S.B.; Philpott, K.L. Principles of early drug discovery. Br. J. Pharmacol. 2011, 162, 1239–1249.
[CrossRef]
16.
Akhondzadeh, S. The importance of clinical trials in drug development. Avicenna J. Med. Biotechnol. 2016, 8, 151.
17.
Weaver, M.F.; Hopper, J.A.; Gunderson, E.W. Designer drugs 2015: Assessment and management. Addict. Sci. Clin. Pract. 2015,
10, 8. [CrossRef] [PubMed]
18.
Li, A.; Huang, H.-T.; Huang, H.-C.; Juan, H.-F. LncTx: A network-based method to repurpose drugs acting on the survival-related
lncRNAs in lung cancer. Comput. Struct. Biotechnol. J. 2021, 19, 3990–4002. [CrossRef]
19.
Cheng, L.-H.; Hsu, T.-C.; Lin, C. Integrating ensemble systems biology feature selection and bimodal deep neural network for
breast cancer prognosis prediction. Sci. Rep. 2021, 11, 14914.
20.
Lai, Y.-H.; Chen, W.-N.; Hsu, T.-C.; Lin, C.; Tsao, Y.; Wu, S. Overall survival prediction of non-small cell lung cancer by integrating
microarray and clinical data with deep learning. Sci. Rep. 2020, 10, 4679.
21.
Lee, K.-H.; Chang, Y.-C.; Chen, T.-F.; Juan, H.-F.; Tsai, H.-K.; Chen, C.-Y. Connecting MHC-I-binding motifs with HLA alleles via
deep learning. Commun. Biol. 2021, 4, 1194. [CrossRef] [PubMed]
22.
Salwinski, L.; Miller, C.S.; Smith, A.J.; Pettit, F.K.; Bowie, J.U.; Eisenberg, D. The database of interacting proteins: 2004 update.
Nucleic Acids Res. 2004, 32 (Suppl. 1), D449–D451. [CrossRef] [PubMed]
23.
Orchard, S.; Ammari, M.; Aranda, B.; Breuza, L.; Briganti, L.; Broackes-Carter, F.; Campbell, N.H.; Chavali, G.; Chen, C.; Del-Toro,
N. The MIntAct project—IntAct as a common curation platform for 11 molecular interaction databases. Nucleic Acids Res. 2014,
42, D358–D363. [CrossRef] [PubMed]
24.
Stark, C.; Breitkreutz, B.-J.; Reguly, T.; Boucher, L.; Breitkreutz, A.; Tyers, M. BioGRID: A general repository for interaction
datasets. Nucleic Acids Res. 2006, 34 (Suppl. 1), D535–D539. [CrossRef]
25.
Zanzoni, A.; Montecchi-Palazzi, L.; Quondam, M.; Ausiello, G.; Helmer-Citterich, M.; Cesareni, G. MINT: A Molecular INTeraction
database. FEBS Lett. 2002, 513, 135–140. [CrossRef]
26.
Bovolenta, L.A.; Acencio, M.L.; Lemke, N. HTRIdb: An open-access database for experimentally veriﬁed human transcriptional
regulation interactions. BMC Genom. 2012, 13, 405. [CrossRef]
27.
Zheng, G.; Tu, K.; Yang, Q.; Xiong, Y.; Wei, C.; Xie, L.; Zhu, Y.; Li, Y. ITFP: An integrated platform of mammalian transcription
factors. Bioinformatics 2008, 24, 2416–2417. [CrossRef]
28.
Wingender, E.; Chen, X.; Hehl, R.; Karas, H.; Liebich, I.; Matys, V.; Meinhardt, T.; Prüß, M.; Reuter, I.; Schacherer, F. TRANSFAC:
An integrated system for gene expression regulation. Nucleic Acids Res. 2000, 28, 316–319. [CrossRef]
29.
Friard, O.; Re, A.; Taverna, D.; De Bortoli, M.; Corá, D. CircuitsDB: A database of mixed microRNA/transcription factor
feed-forward regulatory circuits in human and mouse. BMC Bioinform. 2010, 11, 435. [CrossRef]
30.
Agarwal, V.; Bell, G.W.; Nam, J.-W.; Bartel, D.P. Predicting effective microRNA target sites in mammalian mRNAs. elife 2015,
4, e05005. [CrossRef]
31.
Li, J.-H.; Liu, S.; Zhou, H.; Qu, L.-H.; Yang, J.-H. starBase v2.0: Decoding miRNA-ceRNA, miRNA-ncRNA and protein–RNA
interaction networks from large-scale CLIP-Seq data. Nucleic Acids Res. 2014, 42, D92–D97. [CrossRef] [PubMed]
32.
Chen, B.-S.; Wu, C.-C. Systems biology as an integrated platform for bioinformatics, systems synthetic biology, and systems
metabolic engineering. Cells 2013, 2, 635–688. [CrossRef]
33.
Li, C.-W.; Chen, B.-S. Investigating core genetic-and-epigenetic cell cycle networks for stemness and carcinogenic mechanisms,
and cancer drug design using big database mining and genome-wide next-generation sequencing data. Cell Cycle 2016, 15,
2593–2607. [CrossRef] [PubMed]
34.
Wang, G.; Pan, C.; Cao, K.; Zhang, J.; Geng, H.; Wu, K.; Wen, J.; Liu, C. Impacts of cigarette smoking on the tumor immune
microenvironment in esophageal squamous cell carcinoma. J. Cancer 2022, 13, 413. [CrossRef]

## Page 28 (Section: Conclusions )

Int. J. Mol. Sci. 2022, 23, 10409
28 of 29
35.
Foy, J.-P.; Bertolus, C.; Michallet, M.-C.; Deneuve, S.; Incitti, R.; Bendriss-Vermare, N.; Albaret, M.-A.; Ortiz-Cuaran, S.; Thomas,
E.; Colombe, A. The immune microenvironment of HPV-negative oral squamous cell carcinoma from never-smokers and
never-drinkers patients suggests higher clinical beneﬁt of IDO1 and PD1/PD-L1 blockade. Ann. Oncol. 2017, 28, 1934–1941.
[CrossRef]
36.
Cheskis, B.J.; Greger, J.; Cooch, N.; McNally, C.; Mclarney, S.; Lam, H.-S.; Rutledge, S.; Mekonnen, B.; Hauze, D.; Nagpal, S.
MNAR plays an important role in ERa activation of Src/MAPK and PI3K/Akt signaling pathways. Steroids 2008, 73, 901–905.
[CrossRef]
37.
Burotto, M.; Chiou, V.L.; Lee, J.M.; Kohn, E.C. The MAPK pathway across different malignancies: A new perspective. Cancer 2014,
120, 3446–3456. [CrossRef]
38.
Mittal, M.; Kapoor, V.; Mohanti, B.K.; Das, S.N. Functional variants of COX-2 and risk of tobacco-related oral squamous cell
carcinoma in high-risk Asian Indians. Oral Oncol. 2010, 46, 622–626. [CrossRef]
39.
Ramos-Garcia, P.; Gil-Montoya, J.; Scully, C.; Ayén, A.; González-Ruiz, L.; Navarro-Triviño, F.; González-Moles, M. An update on
the implications of cyclin D1 in oral carcinogenesis. Oral Dis. 2017, 23, 897–912. [CrossRef] [PubMed]
40.
Lakshminarayana, S.; Augustine, D.; Rao, R.S.; Patil, S.; Awan, K.H.; Venkatesiah, S.S.; Haragannavar, V.C.; Nambiar, S.; Prasad,
K. Molecular pathways of oral cancer that predict prognosis and survival: A systematic review. J. Carcinog. 2018, 17, 7. [CrossRef]
41.
Freier, K.; Sticht, C.; Hofele, C.; Flechtenmacher, C.; Stange, D.; Puccio, L.; Toedt, G.; Radlwimmer, B.; Lichter, P.; Joos, S. Recurrent
coampliﬁcation of cytoskeleton-associated genes EMS1 and SHANK2 with CCND1 in oral squamous cell carcinoma. Genes
Chromosomes Cancer 2006, 45, 118–125. [CrossRef] [PubMed]
42.
Wang, Q.; Han, J.; Xu, P.; Jian, X.; Huang, X.; Liu, D. Silencing of LncRNA SNHG16 downregulates cyclin D1 (CCND1) to abrogate
malignant phenotypes in oral squamous cell carcinoma (OSCC) through upregulating miR-17–5p. Cancer Manag. Res. 2021,
13, 1831. [CrossRef] [PubMed]
43.
Giles, R.H.; Van Es, J.H.; Clevers, H. Caught up in a Wnt storm: Wnt signaling in cancer. Biochim. Biophys. Acta (BBA)-Rev. Cancer
2003, 1653, 1–24. [CrossRef]
44.
Huelsken, J.; Behrens, J. The Wnt signalling pathway. J. Cell Sci. 2002, 115, 3977–3978. [CrossRef] [PubMed]
45.
Lyou, Y.; Habowski, A.N.; Chen, G.T.; Waterman, M.L. Inhibition of nuclear Wnt signalling: Challenges of an elusive target for
cancer therapy. Br. J. Pharmacol. 2017, 174, 4589–4599. [CrossRef] [PubMed]
46.
Xiao, X.; Gu, Y.; Wang, G.; Chen, S. c-Myc, RMRP, and miR-34a-5p form a positive-feedback loop to regulate cell proliferation and
apoptosis in multiple myeloma. Int. J. Biol. Macromol. 2019, 122, 526–537. [CrossRef]
47.
Walker, L.; Lynch, M.; Silverman, S.; Fraser, J.; Boulter, J.; Weinmaster, G.; Gasson, J.C. The Notch/Jagged pathway inhibits
proliferation of human hematopoietic progenitors in vitro. Stem Cells 1999, 17, 162–171. [CrossRef]
48.
Chai, A.W.Y.; Lim, K.P.; Cheong, S.C. Translational genomics and recent advances in oral squamous cell carcinoma. In Seminars in
Cancer Biology; Elsevier: Amsterdam, The Netherlands, 2020; pp. 71–83.
49.
Hijioka, H.; Setoguchi, T.; Miyawaki, A.; Gao, H.; Ishida, T.; Komiya, S.; Nakamura, N. Upregulation of Notch pathway molecules
in oral squamous cell carcinoma. Int. J. Oncol. 2010, 36, 817–822.
50.
Sjölund, J.; Manetopoulos, C.; Stockhausen, M.-T.; Axelson, H. The Notch pathway in cancer: Differentiation gone awry. Eur. J.
Cancer 2005, 41, 2620–2629. [CrossRef]
51.
Ingram, W.; McCue, K.; Tran, T.; Hallahan, A.; Wainwright, B. Sonic Hedgehog regulates Hes1 through a novel mechanism that is
independent of canonical Notch pathway signalling. Oncogene 2008, 27, 1489–1500. [CrossRef]
52.
Subramaniam, D.; Ponnurangam, S.; Ramamoorthy, P.; Standing, D.; Battafarano, R.J.; Anant, S.; Sharma, P. Curcumin induces
cell death in esophageal cancer cells through modulating Notch signaling. PLoS ONE 2012, 7, e30590. [CrossRef] [PubMed]
53.
Bi, H.; Ming, L.; Cheng, R.; Luo, H.; Zhang, Y.; Jin, Y. Liver extracellular matrix promotes BM-MSCs hepatic differentiation
and reversal of liver ﬁbrosis through activation of integrin pathway. J. Tissue Eng. Regen. Med. 2017, 11, 2685–2698. [CrossRef]
[PubMed]
54.
Dayyani, F.; Parikh, N.U.; Varkaris, A.S.; Song, J.H.; Moorthy, S.; Chatterji, T.; Maity, S.N.; Wolfe, A.R.; Carboni, J.M.; Gottardis,
M.M. Combined Inhibition of IGF-1R/IR and Src family kinases enhances antitumor effects in prostate cancer by decreasing
activated survival pathways. PLoS ONE 2012, 7, e51189. [CrossRef] [PubMed]
55.
Yu, Z.; Weinberger, P.M.; Sasaki, C.; Egleston, B.L.; Speier IV, W.F.; Haffty, B.; Kowalski, D.; Camp, R.; Rimm, D.; Vairaktaris, E.
Phosphorylation of Akt (Ser473) predicts poor clinical outcome in oropharyngeal squamous cell cancer. Cancer Epidemiol. Biomark.
Prev. 2007, 16, 553–558. [CrossRef]
56.
Subarnbhesaj, A.; Miyauchi, M.; Chanbora, C.; Mikuriya, A.; Nguyen, P.T.; Furusho, H.; Ayuningtyas, N.F.; Fujita, M.; Toratani, S.;
Takechi, M. Roles of VEGF-Flt-1 signaling in malignant behaviors of oral squamous cell carcinoma. PLoS ONE 2017, 12, e0187092.
[CrossRef]
57.
Seçilmi¸s, D.; Hillerton, T.; Morgan, D.; Tjärnberg, A.; Nelander, S.; Nordling, T.E.; Sonnhammer, E.L. Uncovering cancer gene
regulation by accurate regulatory network inference from uninformative data. NPJ Syst. Biol. Appl. 2020, 6, 37. [CrossRef]
58.
Subramanian, A.; Narayan, R.; Corsello, S.M.; Peck, D.D.; Natoli, T.E.; Lu, X.; Gould, J.; Davis, J.F.; Tubelli, A.A.; Asiedu, J.K. A
next generation connectivity map: L1000 platform and the ﬁrst 1,000,000 proﬁles. Cell 2017, 171, 1437–1452.e17. [CrossRef]
59.
Knox, C.; Law, V.; Jewison, T.; Liu, P.; Ly, S.; Frolkis, A.; Pon, A.; Banco, K.; Mak, C.; Neveu, V. DrugBank 3.0: A comprehensive
resource for ‘omics’ research on drugs. Nucleic Acids Res. 2010, 39 (Suppl. 1), D1035–D1041. [CrossRef]

## Page 29 (Section: Conclusions )

Int. J. Mol. Sci. 2022, 23, 10409
29 of 29
60.
Corsello, S.M.; Nagari, R.T.; Spangler, R.D.; Rossen, J.; Kocak, M.; Bryan, J.G.; Humeidi, R.; Peck, D.; Wu, X.; Tang, A.A.
Discovering the anticancer potential of non-oncology drugs by systematic viability proﬁling. Nat. Cancer 2020, 1, 235–248.
[CrossRef]
61.
Li, X.; Guo, S.; Xiong, X.-K.; Peng, B.-Y.; Huang, J.-M.; Chen, M.-F.; Wang, F.-Y.; Wang, J.-N. Combination of quercetin and cisplatin
enhances apoptosis in OSCC cells by downregulating xIAP through the NF-κB pathway. J. Cancer 2019, 10, 4509. [CrossRef]
62.
Li, L.; Liu, H.-C.; Wang, C.; Liu, X.; Hu, F.-C.; Xie, N.; Lü, L.; Chen, X.; Huang, H.-Z. Overexpression of β-catenin induces cisplatin
resistance in oral squamous cell carcinoma. BioMed Res. Int. 2016, 2016, 5378567. [CrossRef] [PubMed]
63.
Ding, L.; Ren, J.; Zhang, D.; Li, Y.; Huang, X.; Ji, J.; Hu, Q.; Wang, H.; Ni, Y.; Hou, Y. The TLR3 Agonist Inhibit Drug Efﬂux and
Sequentially Consolidates Low-Dose Cisplatin-Based Chemoimmunotherapy while Reducing Side EffectsOrderly Combination
poly (I: C)/Low-Dose DDP. Mol. Cancer Ther. 2017, 16, 1068–1079. [CrossRef] [PubMed]
64.
Chou, T.-Y.; Chiu, C.-H.; Li, L.-H.; Hsiao, C.-Y.; Tzen, C.-Y.; Chang, K.-T.; Chen, Y.-M.; Perng, R.-P.; Tsai, S.-F.; Tsai, C.-M. Mutation
in the tyrosine kinase domain of epidermal growth factor receptor is a predictive and prognostic factor for geﬁtinib treatment in
patients with non–small cell lung cancer. Clin. Cancer Res. 2005, 11, 3750–3757. [CrossRef] [PubMed]
65.
Taron, M.; Ichinose, Y.; Rosell, R.; Mok, T.; Massuti, B.; Zamora, L.; Mate, J.L.; Manegold, C.; Ono, M.; Queralt, C. Activating
mutations in the tyrosine kinase domain of the epidermal growth factor receptor are associated with improved survival in
geﬁtinib-treated chemorefractory lung adenocarcinomas. Clin. Cancer Res. 2005, 11, 5878–5885. [CrossRef]
66.
Moulder, S.L.; Yakes, F.M.; Muthuswamy, S.K.; Bianco, R.; Simpson, J.F.; Arteaga, C.L. Epidermal growth factor receptor (HER1)
tyrosine kinase inhibitor ZD1839 (Iressa) inhibits HER2/neu (erb B2)-overexpressing breast cancer cells in vitro and in vivo.
Cancer Res. 2001, 61, 8887–8895. [PubMed]
67.
Khan, Z.; Bisen, P.S. Oncoapoptotic signaling and deregulated target genes in cancers: Special reference to oral cancer. Biochim.
Biophys. Acta Rev. Cancer 2013, 1836, 123–145. [CrossRef]
68.
Shortt, J.; Johnstone, R.W. Oncogenes in cell survival and cell death. Cold Spring Harb. Perspect. Biol. 2012, 4, a009829. [CrossRef]
69.
Peters, S.; Zimmermann, S.; Adjei, A.A. Oral epidermal growth factor receptor tyrosine kinase inhibitors for the treatment of
non-small cell lung cancer: Comparative pharmacokinetics and drug–drug interactions. Cancer Treat. Rev. 2014, 40, 917–926.
[CrossRef] [PubMed]
70.
Sanchez-Rangel, E.; Inzucchi, S.E. Metformin: Clinical use in type 2 diabetes. Diabetologia 2017, 60, 1586–1593. [CrossRef]
71.
Lv, Z.; Guo, Y. Metformin and its beneﬁts for various diseases. Front. Endocrinol. 2020, 11, 191. [CrossRef]
72.
Chae, Y.K.; Arya, A.; Malecek, M.-K.; Shin, D.S.; Carneiro, B.; Chandra, S.; Kaplan, J.; Kalyan, A.; Altman, J.K.; Platanias, L.
Repurposing metformin for cancer treatment: Current clinical studies. Oncotarget 2016, 7, 40767. [CrossRef] [PubMed]
73.
Kasznicki, J.; Sliwinska, A.; Drzewoski, J. Metformin in cancer prevention and therapy. Ann. Transl. Med. 2014, 2, 57. [PubMed]
74.
Li, Y.; Wang, M.; Zhi, P.; You, J.; Gao, J.-Q. Metformin synergistically suppress tumor growth with doxorubicin and reverse drug
resistance by inhibiting the expression and function of P-glycoprotein in MCF7/ADR cells and xenograft models. Oncotarget
2018, 9, 2158. [CrossRef] [PubMed]
75.
Shah, R.R. Hyperglycaemia induced by novel anticancer agents: An undesirable complication or a potential therapeutic
opportunity? Drug Saf. 2017, 40, 211–228. [CrossRef]
76.
Peng, M.; Darko, K.O.; Tao, T.; Huang, Y.; Su, Q.; He, C.; Yin, T.; Liu, Z.; Yang, X. Combination of metformin with chemotherapeutic
drugs via different molecular mechanisms. Cancer Treat. Rev. 2017, 54, 24–33. [CrossRef]
77.
Haslam, E.; Cai, Y. Plant polyphenols (vegetable tannins): Gallic acid metabolism. Nat. Prod. Rep. 1994, 11, 41–66. [CrossRef]
78.
Cai, Y.; Luo, Q.; Sun, M.; Corke, H. Antioxidant activity and phenolic compounds of 112 traditional Chinese medicinal plants
associated with anticancer. Life Sci. 2004, 74, 2157–2184. [CrossRef]
79.
Shabani, S.; Rabiei, Z.; Amini-Khoei, H. Exploring the multifaceted neuroprotective actions of gallic acid: A review. Int. J. Food
Prop. 2020, 23, 736–752. [CrossRef]
80.
Nikbakht, J.; Hemmati, A.A.; Arzi, A.; Mansouri, M.T.; Rezaie, A.; Ghafourian, M. Protective effect of gallic acid against
bleomycin-induced pulmonary ﬁbrosis in rats. Pharmacol. Rep. 2015, 67, 1061–1067. [CrossRef]
81.
Chuang, C.-Y.; Liu, H.-C.; Wu, L.-C.; Chen, C.-Y.; Chang, J.T.; Hsu, S.-L. Gallic acid induces apoptosis of lung ﬁbroblasts via a
reactive oxygen species-dependent ataxia telangiectasia mutated-p53 activation pathway. J. Agric. Food Chem. 2010, 58, 2943–2951.
[CrossRef]
82.
Bai, J.; Zhang, Y.; Tang, C.; Hou, Y.; Ai, X.; Chen, X.; Zhang, Y.; Wang, X.; Meng, X. Gallic acid: Pharmacological activities and
molecular mechanisms involved in inﬂammation-related diseases. Biomed. Pharmacother. 2021, 133, 110985. [CrossRef] [PubMed]
83.
Yeh, S.-J.; Chen, S.-W.; Chen, B.-S. Investigation of the genome-wide genetic and epigenetic networks for drug discovery based on
systems biology approaches in colorectal cancer. Front. Genet. 2020, 11, 117. [CrossRef]
84.
Consortium, U. UniProt: A worldwide hub of protein knowledge. Nucleic Acids Res. 2019, 47, D506–D515. [CrossRef]
85.
Liu, T.; Lin, Y.; Wen, X.; Jorissen, R.N.; Gilson, M.K. BindingDB: A web-accessible database of experimentally determined
protein–ligand binding afﬁnities. Nucleic Acids Res. 2007, 35 (Suppl. 1), D198–D201. [CrossRef] [PubMed]
86.
Kim, S.; Thiessen, P.A.; Bolton, E.E.; Chen, J.; Fu, G.; Gindulyte, A.; Han, L.; He, J.; He, S.; Shoemaker, B.A. PubChem substance
and compound databases. Nucleic Acids Res. 2016, 44, D1202–D1213. [CrossRef]


---

# Implications of Additivity and Nonadditivity for Machine Learning and Deep Learning Models in Drug Design

- **Authors:** Karolina Kwapien, Eva Nittinger, Jiazhen He, Christian Margreitter, Alexey Voronov, Christian Tyrchan
- **Issuer:** ACS omega
- **Type:** Scientific article
- **Published:** 2022-07-19
- **Language:** en
- **DOI:** 10.1021/acsomega.2c02738
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35936431/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractMatched molecular pairs (MMPs) are nowadays a commonly applied concept in drug design. They are used in many computational tools for structure–activity relationship analysis, biological activity prediction, or optimization of physicochemical properties. However, until now it has not been shown in a rigorous way that MMPs, that is, changing only one substituent between two molecules, can be predicted with higher accuracy and precision in contrast to any other chemical compound pair. It is expected that any model should be able to predict such a defined change with high accuracy and reasonable precision. In this study, we examine the predictability of four classical properties relevant for drug design ranging from simple physicochemical parameters (log D and solubility) to more complex cell-based ones (permeability and clearance), using different data sets and machine learning algorithms. Our study confirms that additive data are the easiest to predict, which highlights the importance of recognition of nonadditivity events and the challenging complexity of predicting properties in case of scaffold hopping. Despite deep learning being well suited to model nonlinear events, these methods do not seem to be an exception of this observation. Though they are in general performing better than classical machine learning methods, this leaves the field with a still standing challenge.

## Section: Introduction

A matched molecular pair (MMP) describes a pair of molecules that differs in one substituent only. Such a structural transformation is associated with a potential property change. MMP analysis is often used by medicinal chemists to compare properties in order to understand the structure–activity relationship (SAR) for a series of compounds. An extension from a pair to a series of molecules that differ in a single transformation forms a matched molecular series (MMS). MMS have been used to investigate automatic ways to derive an SAR similarity score1,2 and to predict ADME properties.3

The reason for the popularity of MMP analysis is its intuitivity: a particular change in a molecular structure introduces a certain change in a biological activity or physical property. However, this simple concept works only under the assumptions of linearity and additivity. Linearity means that the change in property due to a particular change in structure is constant. Additivity means that the effect of a structural change on a property is independent of other variables. It is important to take these assumptions into consideration before performing an MMP analysis or building a quantitative structure–activity relationship (QSAR) model.4 Unfortunately, most publications in the field do not report any such analysis on the data sets. We advocate that this relevant step becomes good practice in the QSAR/ML field. The use of a linear model would fail to capture the trend of nonadditive data mathematically, resulting in erroneous predictions.

Another important aspect of checking the validity of the additivity assumption is the identification of outliers. Outliers indicate so-called activity cliffs, a pair of molecules or even a single observation where a small structural change causes a significant change in property or biological activity.5−7 Analysis of outliers and its understanding can lead to more efficient and effective design of molecules. The interpretation of activity cliffs is hampered by the complexity of the underlying effects and the fact that they can arise from any combination of these.8−10 A common example of such an activity cliff is so-called magic methyls where a single methyl group has a large effect on bioactivity or selectivity of a molecule.11,12

Nonadditive data highlight critical changes in the SAR and are therefore the most interesting for a medicinal chemist. Most common causes of the nonadditive SAR are interactions between substituents, different binding modes, and changes in protein conformation.8,9 Identification and analysis of nonadditive effects are important and can lead to understanding of changes in binding modes or ligand conformation. Additionally, they prevent chemists from missing good compounds and can change the direction of ligand optimization.

Especially with recent advancement of deep learning, many methods have become available in order to predict molecular properties. State-of-the-art property prediction models make use of fingerprints as molecular representations.13−17 Furthermore, models can be trained on SMILES representations or molecular graphs in order for the network to learn the important features themselves, without the need for precalculated molecular descriptors.18−24

In this publication, we examine several machine learning and deep learning algorithms to predict four properties (log D, solubility, permeability, and clearance) using different data sets obtained from AstraZeneca’s (AZ) internal database. First, we determine experimental uncertainty for each property as this is an upper limit for predictability of in silico models.25,26 Then, we perform a nonadditivity analysis (NAA) using the algorithm published by Kramer27 to identify nonadditive datapoints. Based on this analysis, we generate four data sets: (1) all data, additive and nonadditive; (2) all MMPs; (3) additive MMPs (MMPs A); and (4) nonadditive MMPs (MMPs N). By comparing the different data sets, we analyze the influence of nonadditivity on the modeling and check if using only MMPs is beneficial for the performance of a model. A variety of methods are considered starting from simple partial least squares (PLS, serving as a benchmark), through random forest (RF), support vector regressor (SVR), gradient-boosted trees (XGBoost) to deep learning algorithm (single and multitask deep neural networks). The quality of the models was evaluated using statistical parameters (R2 and RMSE). Other common parameters in QSAR studies as receiver operating curves or precision recall curves are not taken into account as our intent is not to judge the performance in a virtual screening setting. Our aim is to evaluate the capability of machine learning methods to qualify and predict MMPs, the smallest possible compound change in a medicinal chemistry project.

## Section: Methods

The overview workflow of the whole study is presented in Figure S1. In the following sections, we describe each step in more detail.

## Section: Methods › Data Sets

In-house AstraZeneca data were used for all four properties, log D, solubility in DMSO, cell permeability, and liver microsome clearance. By using in-house data, a continuous assay setup is guaranteed for each property to reduce the influence of systematic errors in the analysis.

All in-house data were collected on September 14, 2020. Data were curated based on our previously developed pipeline.4 Herein, molecules were standardized using PipelinePilot (standardization of stereoisomers, neutralization of charges, and removal of unknown stereochemistry), and the canonical tautomer was generated and kept for further analysis. All properties were converted to log values (SI Table S 1). Further data curation involved removal of unknown or uncertain (“<”, “>”) values and molecules with more than 70 heavy atoms (data_all). Subsequently, for compounds measured multiple times the median was calculated (data_stereo). Finally, compounds with large differences between their multiple measurements (>2.5 log units) were discarded, and compounds only varying in their stereochemistry were combined, while keeping the more active compound (Table 1 and Set 1, Table 2).

Using the open-source package mmpdb,28 all MMPs were obtained (Set 2, Table 2). Based on the NAA, two additional sets were generated, one containing only additive compounds (Set 3) and one containing only nonadditive ones (Set 4). To determine (non-)additivity, a double transformation cycle (DTC) must be generated. Because not all MMPs are also in a DTC, the number of MMPs (Set 2) is larger than the combination of Set 3 and Set 4.

For log D and solubility, the size of the corresponding sets is similar, with clearance generally having slightly less compounds. The data sets for permeability are about 10 times smaller. The exception is permeability Set 4 with only 909 compounds in total.

For machine learning approaches, we would expect Set 4 to be most difficult to predict followed by Set 1. Set 3 should be the easiest, because all compounds are additive.

The training and test sets for the machine learning approaches were obtained by doing a classical stratified training-test split with 0.8 and 0.2 ratio.

## Section: Methods › Experimental Uncertainty and Rmax2

For all selected properties, data were collected for (a) multiple measurements for the same compound (data_all) and (b) measurements for compounds only differentiating in their stereochemistry (data_stereo). These data were used to calculate the experimental uncertainty of each respective assay.

Herein, the weighted mean was used to derive the experimental uncertainty for each property:

with x being the bin where 2.5% (0.5%) of datapoints for multimeasures (stereoduplicates) are included. A smaller amount of datapoints per bin only lead to an artificial increase of experimental uncertainty.

Based on the experimental uncertainty, the maximum R2 achievable for a machine learning approach can be determined:29

## Section: Methods › Nonadditivity Analysis

NAA was performed to determine (non-)additivity in a compound data set. Therefore, the open-source NA analysis code published by Christian Kramer was used (available on GitHub: https://github.com/KramerChristian/NonadditivityAnalysis).27 The code is written in Python and makes use of the cheminformatics libraries RDKit,30 Pandas, and NumPy. NA calculations are based on matched molecular squares, so-called DTCs, which consist of four MMPs (four compounds) linked by two distinct transformations. The MMPs in the NA code are generated by the open-source code developed by Dalke et al.,28 an implementation of the MMPA algorithm developed by Hussain and Rea.31 The NA value of each DTC is calculated as the difference in logged biological activities (pAct1–4) of the four compounds assembling the cycle:

## Section: Methods › Machine/Deep Learning › Machine Learning Models Using Optuna

PLS, RF, SVR, and gradient-boosted trees (XGBoost) models were built using Optuna (https://optuna.org).32 Optuna is a hyperparameter optimization framework and forms the basis of our in-house QPTUNA framework (available on GitHub: https://github.com/MolecularAI/Qptuna) that extends Optuna by adding chemoinformatics functionality. Optuna allows specifying the hyperparameter search space for a plethora of machine learning algorithms and automatically tries to optimize them with respect to a defined output metric for a specified number of trials. By using a surrogate model, such search should be more efficient than a mere random or grid search.

For each of the data sets provided, we trained a number of regressors for a minimum of 300 iterations each. This was done with threefold cross-validation (see Table S2 for details) to avoid overfitting during training, and models were then built from the entire training sets. Finally, the models were evaluated on the respective test sets.

For some of the SVR runs, we had to use a “downsampled” data set (10% of the corresponding original size) to be able to obtain optimized hyperparameters within a reasonable time frame. This was done for log D, solubility, and clearance (Sets 1–3). The rest of the sets (all permeability data sets and Set 4 for each property) were used all datapoints for hyperparameter optimization. The following steps, model training and prediction of the respective test sets, were performed on the full-size sets for all properties.

## Section: Methods › Machine/Deep Learning › Graph Neural Network Deep Learning Model

The message passing neural network (MPNN)33 framework operates on molecular graphs with atoms as nodes and bonds as edges. There are two main phases: (1) message passing phase, in which the node information is propagated and updated across the graph in order to build a neural representation of the whole graph, and (2) readout phase, when a final feature vector/representation describing the whole graph is created. Then a feed-forward neural network can be applied to this feature vector for prediction tasks.

The directed message passing neural network (D-MPNN)24 (available on GitHub: https://github.com/chemprop/chemprop) builds upon the MPNN framework with the difference that during the message passing phase, the directed edge information is used instead of node information.

In this study, the D-MPNN model was trained in a single-task setting and a multitask setting. In the single-task setting, the model was trained individually for each property task, while in the multitask setting, a multitask model was trained on the union of the training sets from all the property tasks where each molecule has four target values. Therefore, after training, the multitask model can predict the four properties simultaneously for the molecules of the test set.

Hyperparameter optimization was performed for each data set using Bayesian optimization (i.e., Hyperopt34) provided by chemprop, which finds the optimal parameters (hidden size, depth, dropout, and the number of feed-forward layers; details about the searching space can be found in chemprop) through multiple trials. In particular, 20 and 50 hyperparameter trial settings were tried in a single-task setting, which results in two models for each data set, hereafter named DNN-S_20 and DNN-S_50, respectively. For the multitask setting, only 20 hyperparameter trial settings were tried (DNN-M_20).

During the hyperparameter optimization, the original training set in Table 2 is split into training, validation, and test with the ratio 0.8, 0.1, and 0.1, to find out the best parameter configuration based on the RMSE metric. Then the model was trained using this parameter configuration, and the original training set in Table 2 is split into train and validation with the ratio 0.8 and 0.2. Finally, the trained model was applied to the test set to obtain the predictions.

## Section: Results and Discussion

R2 and RMSE for log D and clearance—Set 3 (only additive data) vs Set 4 (only nonadditive data). Comparison of different models and endpoints. Rmax2 (dashed line) is the upper limit for R2 derived from experimental uncertainty (Table 3). Full performance details can be found in the Supporting Information (SI Figures S6 and S7).

R2 against RMSE for test (a) Set 3 (only additive data) and (b) Set 4 (only nonadditive data). Comparison of different models and endpoints.

Predicted versus measured values for solubility. Comparison between RF (left column) and DNN-S_20 (right column) for Set 3: only additive data (blue) and Set 4: only nonadditive data (orange). The values are in log units.

## Section: Results and Discussion › Experimental Uncertainty and Rmax2

The experimental uncertainty of an assay can be calculated by leveraging the information from compounds measured multiple times (Table 1). Herein, two aspects were analyzed: first, the experimental uncertainty based on compounds measured multiple times and second, the experimental uncertainty for compounds with different stereochemistry. The idea of the latter analysis was that the stereochemistry should play a minor role for the different physicochemical properties. Thus, the experimental uncertainty for those compounds should be rather small.

Table 3 summarizes the experimental uncertainties as well as the resulting maximum R2 values (SI Figures S2–S5). Solubility has the highest experimental uncertainty for multimeasurements, followed by permeability, resulting for both assays in a twofold variability of the measured value. As expected, stereoduplicates show very low experimental uncertainties. Only for clearance this trend is not true; stereoduplicates display a similar experimental uncertainty. log D has the lowest experimental uncertainty with 0.07 log units. Thus, using the machine learning approach almost ideal performance is theoretically possible (Rmax2 = 0.993).

In the following, the experimental uncertainties are used as cutoffs for the NAA. Herein, compounds with a nonadditivity value greater than two times the experimental uncertainty are classified as nonadditive.

## Section: Results and Discussion › Nonadditivity Analysis

NAA allows the classification of compounds into additive and nonadditive ones. Herein, a prerequisite is the composition of matched molecular squares. These are used to determine whether a cycle is additive or nonadditive.

Surprisingly, log D, solubility, and clearance all have more than 12% nonadditive compounds (Table 4). In our previous study of nonadditivity in bioactivity data, 9% (5%) of compounds were nonadditive for in-house (and public ChEMBL) data. Compared to this, the amount of nonadditivity found here is significantly larger. The reasons might be manifold and different for each property,4 for example, in the case of log D solubility might play an important role, as in the case of solubility crystal packing seems to be important. Permeability displays an exception with only 5% of compounds being classified as nonadditive (Table 4).

The results of the NAA were used to generate the data sets for machine learning.

## Section: Results and Discussion › Machine/Deep Learning

Tables 5 and 6 present R2 and RMSE obtained for all algorithms, data sets, and properties discussed in this work. The results are also presented visually for Set 3 (only additive data) and Set4 (only nonadditive data) in Figures 1 and 2.

The analysis of R2 and RMSE shows the same accuracy ranking for all models when comparing different data sets: Set 3 > Set 2 > Set 1 > Set 4. This is valid for all properties considered in this work with the exception of log D modeled using PLS and SVR. Predictive models are most accurate for additive data sets (Set 3) while nonadditive data (Set 4) are least well predictable (SI Figures S6 and S7). Mixed data sets with both additive and nonadditive data (Set 1 and Set 2) are ranked in the middle. There is just a small difference in R2 and RMSE values between Set 1 (all data) and Set 3 (MMPs), indicating that using only MMPs instead of all datapoints does not improve the models significantly.

Figure 1 shows the comparison of performance metrics for additive vs nonadditive data for log D and clearance (Set 3 and Set 4). In most cases, deep learning algorithms give the best results (lowest RMSE and highest R2) followed by XGBoost and RF. The worst performance is observed for the linear model PLS, which serves as a benchmark.

Deep learning models based on additive data achieve for log D predictions almost Rmax2, which is calculated based on experimental uncertainty. For clearance, the achieved performance on the additive test set is significantly lower than Rmax2. For all properties, the performances of all models drop when applied to nonadditive data. The only exception is the SVR model based on nonadditive log D data, with an increase in R2 from 0.58 to 0.74 for additive and nonadditive data, respectively (SI Figures S6 and S7). Log D is the property for which the performance is least affected with both DNN models achieving R2 of 0.84 when trained on nonadditive data only. For solubility, permeability and clearance models based on nonadditive data only achieve R2 < 0.43.

In terms of the deep learning models, multitask modeling improves over single-task for all studied properties except for log D. More hyperparameter trial settings (20 compared to 50) improve the models only slightly and remain below the performance of multitask models (DNN-S_20 and DNN-S_50 in Tables 5 and 6).

Figure 2 displays the correlation between R2 and RMSE and shows different slopes for each property trendline. The lowest RMSE and R2 are for clearance, while the highest for log D, with permeability and solubility being placed in between. For most properties, the correlation between R2 and RMSE is linear, with some variation observed for log D Set 3 (only additive data).

Comparison between additive and nonadditive data (Table 5 and Figure 2) reveals that even deep learning methods, which are nonlinear, have problems with nonadditivity. It can be clearly seen in Figure 2 that only for log D the R2 range is similar for additive and nonadditive data, while for the other properties it is shifted toward lower values (below 0.45). Log D is a bulk property and should therefore be less impacted by nonadditivity. The observed nonadditivity might be the result of random experimental errors. For the rest of the studied properties, many factors can introduce nonadditivity, like crystal packing in case of solubility and efflux, sticking to the membranes, and metabolism for cell-based properties (permeability and clearance) among others. The aim of this paper, however, is not to disclose the underlying reason for nonadditivity, but to recognize its importance, as models built on data sets with nonadditivity included lead to reduced predictability.

Figure 3 displays the correlation between measured and predicted solubility values using RF and a deep learning model (DNN-S_20) for additive and nonadditive data. As expected, the deep learning model performs generally better than RF. This improved performance is observed throughout the whole range of values, for all data sets and properties (SI Figures S8–S10). We performed a zero-slope analysis using the t-test (see Tables S3 and S4 and details in the SI) to check the significance of R2. For all properties, P-values are below the significance level indicating that R2 obtained in our analysis is statistically significant.

R2 and RMSE for log D and clearance—Set 3 (only additive data) vs Set 4 (only nonadditive data). Comparison of different models and endpoints. Rmax2 (dashed line) is the upper limit for R2 derived from experimental uncertainty (Table 3). Full performance details can be found in the Supporting Information (SI Figures S6 and S7).

R2 against RMSE for test (a) Set 3 (only additive data) and (b) Set 4 (only nonadditive data). Comparison of different models and endpoints.

Predicted versus measured values for solubility. Comparison between RF (left column) and DNN-S_20 (right column) for Set 3: only additive data (blue) and Set 4: only nonadditive data (orange). The values are in log units.

## Section: Conclusions

In this publication, we have evaluated the implications of MMPs and (non-)additivity on machine learning and deep learning models. We hypothesized that due to the small molecular changes captured in MMPs, these should be easier to predict than non-MMPs. As expected, data sets with only additive datapoints are easiest to predict, as opposed to data sets with only nonadditive datapoints. Mixed data sets with both additive and nonadditive data are ranked in the middle. The sole reduction from all datapoints to MMPs only does not lead to a significant increase in predictability. Using only additive data thus leads to an improvement.

Comparison among properties shows the best performance for log D followed by solubility, permeability, and clearance. This is in accordance with the complexity of the physicochemical property. In terms of models, deep learning methods give the best results with lowest RMSE and highest R2. However, our study indicates that even deep learning algorithms have problems with nonadditivity. This highlights the importance of recognition of nonadditive events before building a QSAR/ML model. Unfortunately, NA analysis is not included in a predictive modeling workflow on a regular basis. We strongly advocate that this step becomes best practice, as the quality of model and the prediction error depend on nonadditive data. This would also allow more relevant comparisons of different models with similar endpoints, but based on different data sets with additive compounds. Moreover, identification and analysis of nonadditive effects are important, as they reveal critical changes in the SAR and are therefore the most interesting from a medicinal chemistry perspective.

## Section: Conclusions › Data and Software Availability › Data

Data underlying the findings described in this manuscript are considered proprietary to AstraZeneca and are not publicly available. The reason why we have used our internal database for this work, instead of public data, is that we needed to have assay consistency and enough nonlinear datapoints in order to test our hypothesis. Based on our recent publication “Nonadditivity in public and inhouse data: implications for drug design”4 we have shown that our internal AZ database contains more nonlinear events than the public database. Moreover, the assay data are more consistent in the AZ database. We strongly believe that the trends presented here are reproductible observations and general issues with QSAR models.

## Section: Conclusions › Data and Software Availability › Software

The software used in this work is available on GitHub:

## Section: Acknowledgments

We would like to thank Dea Gogishvili for her work on nonadditivity analysis and the preparation of the data curation pipeline. J.H. thanks the PostDoc program at AstraZeneca.

## Section: Supporting Information Available

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acsomega.2c02738.

## Section: Author Present Address

§ Data Science Department, Odyssey Therapeutics, Cambridge, Massachusetts, United States (C.M.)

## Section: Author Contributions

∥ K.K. and E.N. are shared first authors.

## Section: Author Contributions

E.N. and K.K. performed data curation. N.A. analyzed and wrote the paper. J.H., C.M., and A.V. realized the M.L. study. C.T. supervised the study and wrote the paper. All authors read and approved the final manuscript.

## Section: Text

The authors declare no competing financial interest.

## Section: Supplementary Material

ao2c02738_si_001.pdf

## Section: Associated Data

ao2c02738_si_001.pdf

## Section: Associated Data › Supplementary Materials

ao2c02738_si_001.pdf

## Section: Associated Data › Data Availability Statement › Data

Data underlying the findings described in this manuscript are considered proprietary to AstraZeneca and are not publicly available. The reason why we have used our internal database for this work, instead of public data, is that we needed to have assay consistency and enough nonlinear datapoints in order to test our hypothesis. Based on our recent publication “Nonadditivity in public and inhouse data: implications for drug design”4 we have shown that our internal AZ database contains more nonlinear events than the public database. Moreover, the assay data are more consistent in the AZ database. We strongly believe that the trends presented here are reproductible observations and general issues with QSAR models.

## Section: Associated Data › Data Availability Statement › Software

The software used in this work is available on GitHub:


---

# Introduction to the BioChemical Library (BCL): An Application-Based Open-Source Toolkit for Integrated Cheminformatics and Machine Learning in Computer-Aided Drug Discovery

- **Authors:** Benjamin P Brown, Oanh Vu, Alexander R Geanes, Sandeepkumar Kothiwale, Mariusz Butkiewicz, Edward W Lowe, Ralf Mueller, Richard Pape, Jeffrey Mendenhall, Jens Meiler
- **Issuer:** Frontiers in pharmacology
- **Type:** Scientific article
- **Published:** 2022-02-21
- **Language:** en
- **DOI:** 10.3389/fphar.2022.833099
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35264967/
- **Licence:** CC-BY

## Section: Abstract

AbstractThe BioChemical Library (BCL) cheminformatics toolkit is an application-based academic open-source software package designed to integrate traditional small molecule cheminformatics tools with machine learning-based quantitative structure-activity/property relationship (QSAR/QSPR) modeling. In this pedagogical article we provide a detailed introduction to core BCL cheminformatics functionality, showing how traditional tasks (e.g., computing chemical properties, estimating druglikeness) can be readily combined with machine learning. In addition, we have included multiple examples covering areas of advanced use, such as reaction-based library design. We anticipate that this manuscript will be a valuable resource for researchers in computer-aided drug discovery looking to integrate modular cheminformatics and machine learning tools into their pipelines.Keywords: drug discovery, drug design, cheminformatics, open-source, deep neural network, QSAR, biochemical library, BCL

## Section: Introduction

Computer-aided drug discovery (CADD) methods are routinely employed to improve the efficiency of hit identification and lead optimization (Macalino et al., 2015; Usha et al., 2017). The importance of in silico methods in drug discovery is exemplified by the multitude of cheminformatics tools available today. These tools frequently include capabilities for tasks such as high-volume molecule processing (Hassan et al., 2006; SciTegic, 2007), ligand-based (LB) small molecule alignment (Labute et al., 2001; Jain Ajay, 2004; Chan, 2017; Brown et al., 2019), conformer generation (Cappel et al., 2015; Kothiwale et al., 2015; Friedrich et al., 2017a, 2019), pharmacophore modeling (Hecker et al., 2002; Acharya et al., 2011; Vlachakis et al., 2015), structure-based (SB) protein-ligand docking (Friesner et al., 2004; Meiler and Baker, 2006; Davis and Baker, 2009; Hartmann et al., 2009; Morris et al., 2009; Kaufmann and Meiler, 2012; Lemmon et al., 2012), and ligand design. Increasingly, modern drug discovery relies on customizable and target-specific machine learning-based quantitative structure-activity relationship (QSAR) and structure-property relationship (QSPR) modeling during virtual high-throughput screening (vHTS) (Lo et al., 2018; Vamathevan et al., 2019).

Frequently, building a drug discovery pipeline with all of these parts requires users to combine multiple different software packages into their workflow. This can be challenging because of different version requirements in package dependencies. Moreover, file- and data-type incompatibilities between packages can lead to errors and pipeline inefficiencies. Here, we describe the BioChemical Library (BCL) cheminformatics toolkit, a freely available academic open-source software package with tightly integrated machine learning-based QSAR/QSPR capabilities.

The BCL is an application-based software package programmed and compiled in C++. This means that BCL applications can be integrated into existing pipelines without the need for package dependency management (i.e., maintaining directory-dependent virtual environments, or keeping separate Miniconda environments for each task). In addition, BCL applications are modular and can be easily combined into complex protocols with simple Shell scripts. Output files from the BCL are primarily common file types that can also be read as input by other software packages. Its command-line usage will be familiar to users of the popular macromolecular modeling software Rosetta (Kaufmann et al., 2010). The simple command line user interface (UI) makes it easy to create complex protocols without extensive coding or scripting experience. Our goal with this manuscript is to describe the core functionalities of the BCL cheminformatics toolkit and provide detailed examples for real use cases. At the end, we briefly discuss ongoing software developments that may be of interest to users.

## Section: Molecule Preparation and Processing

Overview of BCL application groups covered in this manuscript.

Fragment splits currently supported by the BCL.

## Section: Molecule Preparation and Processing › Fundamentals of BioChemical Library Command-Line Syntax

The first thing to complete after downloading and installing the BCL is to add the license file to the/path/to/bcl folder. We further recommend adding/<path>/<to>/bcl to the LD_LIBRARY_PATH and PATH environment variables in the. cshrc/.bashrc. This allows users to access the BCL from any terminal window simply by typing bcl. exe into the command-line. For detailed setup instructions, read the appropriate operating system (OS)-specific ReadMe file in bcl/installer/.

The BCL is organized into application groups each of which contains multiple applications. To view the application groups and associated applications, run the BCL help command:

The BCL has application groups for cheminformatics, protein folding, machine learning, and other tasks (Supplementary Table S1). To isolate and view the applications associated with the application group molecule, for example, run the application group help command:

Generally, the syntax to access a BCL application is as follows:

The help menu for any application cans similarly be accessed as

These help options list the basic arguments and parameters available for each application. More detailed help options are also frequently available for individual application parameters. In this way, all of the documentation required to run the BCL can be readily accessed from the command line. The application groups composing the core of the BCL cheminformatics toolkit include the following: Molecule, Descriptor, and Model (Table 1).

Overview of BCL application groups covered in this manuscript.

## Section: Molecule Preparation and Processing › Filtering

Molecules are input to the BCL in the MDL structure-data format (SDF) file. Often, molecules that are downloaded or converted from one source to another contain errors (e.g., incorrect bond order assignments, undesired protonation states/formal charge, etc.). Dataset sanitization is a critical component of computational chemistry and informatics projects. The BCL molecule: Filter application is the first step in correcting these errors or identifying molecules that cannot be easily and automatically corrected.

To see all of the options available in molecule:Filter, run the following command:

or view the supplementary material (Supplementary Table S2,S3).

For the following examples we will make use of a set of the Platinum Diverse Dataset, a subset of high-quality ligands in their protein-bound 3D conformations (Friedrich et al., 2017b).

This command reads in the SDF platinum_diverse_dataset_2017_01. sdf.gz, saturates all molecules with hydrogen atoms, neutralizes any formal charges, checks to see whether the molecules have valid atom types (e.g., carbon atoms making five covalent bonds are not valid), and then checks to see whether the molecules have simple connectivity (e.g., whether they are part of a molecular complex, such as a salt). The neutralization flag identifies atoms with formal charge and tries to remove the formal charge. The default behavior allows modification of the protonation state of the atom (i.e., pH) and/or the bond order. Other options (more or less aggressive neutralization schemes) are also available and can be seen in the help menu. Adding hydrogen atoms and neutralizing charges are not required operations but are shown above to demonstrate the functionality.

All molecules that match the filter (i.e., molecules with defined atom types and are not part of molecular complexes) are output into platinum_diverse_dataset_2017_01. matched.sdf, and molecules that fail to pass the filters are output into platinum_diverse_dataset_2017_01. unmatched.sdf. In this case, all molecules pass the filter. This allows the user to review the molecules that failed the filter and choose to either fix them or continue without them.

The molecule:Filter application can also be used to separate molecules by property and/or substructure using the compare_property_values flag. For example, to filter out molecules that contain 10 or more rotatable bonds and a topological polar surface area (TPSA) less than 140 Å2, the following command can be used:

Of 2,859 molecules, 395 were first filtered out for have a TPSA ≥140 Å2, and then an additional 84 molecules that had greater than 10 rotatable bonds were filtered out. Notice that the filters are applied sequentially, and molecules must pass both filters to be output to the matched file. Alternatively, the any flag can be specified such that if a molecule meets any one of the filter criteria, then it is output to the matched file:

In this example, 2,801 molecules passed at least one of the filters and only 58 were filtered out.

One may also filter based on substructure similarity. This is particularly useful if there are specific substructures that are desired or that need to be avoided. For example, aromatic amines are a well-known toxicophore and cannot be incorporated into potential druglike molecules; however, it is not uncommon to find these substructures in datasets. Here, we will filter a subset of DrugBank (Wishart et al., 2018) molecules to remove aniline-containing compounds:

In practice, we usually explicitly filter certain toxicophore substructures via graph search with the MoleculeTotalToxicFragments descriptor in conjunction with compare_property_values flag; however, this example illustrates the flexibility to filter by substructure similarity with molecule:Filter. In addition to the standard use cases presented here, molecule:Filter can identify molecules with clashes in 3D space, conformers outside of some tolerance value from a reference conformer, exact substructure matches, specific chemical properties, and more. Some of these filters will be further explored in other subsections.

## Section: Molecule Preparation and Processing › Removing Redundancy

Another critical aspect of dataset sanitization is removing redundancy. This is especially important when preparing datasets for QSAR model training and testing. If molecules appear more than once in a dataset, then it is possible that they could appear simultaneously in the training and test sets, leading to an artificial inflation in test set performance.

The BCL application molecule:Unique can help with this task. It has four levels at which it can compare and differentiate molecules:

The first time the BCL encounters a molecule in an SDF it will store it in memory. Any additional encounters with the same molecule (at the chosen level described above) will be marked as duplicate encounters. The default behavior is to output only the first encounter of each molecule. There are cases in which a molecule appears multiple times but has different MDL properties and/or property values. It may not be desirable to lose the stored properties on duplicate compounds. In such cases, the user can choose to merge the properties or overwrite the duplicate descriptors instead.

For example, one may want to see if any high-throughput screening (HTS) hits have activity on multiple targets. Previously, we published nine high-quality virtual HTS (vHTS) benchmark sets for QSAR modeling binary classification tasks (Butkiewicz et al., 2013). Here, we will take a look at the active compounds from each of those nine datasets and see if any of them have activity on multiple targets.

The output file all_actives.dupes.sdf.gz contains 22 molecules that are active in at least two different datasets (note that each individual dataset was pre-processed to remove redundant molecules). If we want to merge the properties of these 22 compounds and isolate them from the rest of the actives, we can perform a second molecule: Unique with the merge_descriptors flag set, and then use molecule:Filter with the contains flag to isolate the duplicated compounds:

followed by

When merge_descriptors is passed, all unique properties are included in the resultant output file. If the same property is present on duplicates, then the first observation of that property is stored on the output molecule. If overwrite_descriptors is passed instead of merge_descriptors, the last observation of a duplicate property is stored. By default, without either of these flags only the MDL properties on the first occurrence of a molecule are stored in the output.

It may be that some of the compounds in the previous example that have activity on multiple targets are actually stereoisomers. Here, the molecules were compared based on atom identity and connectivity (Constitutions). Iterative runs of molecule:Unique coupled with molecule:Filter can be used to identify such cases.

## Section: Molecule Preparation and Processing › Sorting and Reordering

Sorting molecules is also useful during vHTS. After making predictions on a million compounds with a QSAR model, frequently users will want to identify some small top fraction of most probable hits for experimental testing. This can be readily achieved with molecule:Reorder (note–this example utilizes pseudocode for filenames):

In this example, the reverse flag indicates that the scores will be sorted from largest to smallest (default behavior is smallest to largest). Not more than 100 molecules will be output into the file screened_molecules.best.sdf.gz because of the output_max specification (the default behavior returns all molecules in the new order).

In the previous section, we demonstrated that the BCL could identify duplicate compounds at multiple levels of discrimination. One important note is that redundant molecules are excluded (i.e., sent to the output_dupes file) in the order in which they are observed in the original input. Often, the user may want to control this sequence by sorting the molecules according to some property. In these cases, molecule:Reorder can be used to do just that.

Finally, a general note on SDF input and output. Aromaticity is automatically detected when reading input files; however, output structures are Kekulized (represented as alternating single-double bonds) by default. To output an SDF that contains explicit aromatic bonds (achieved by labeling bond order as 4 in the MDL SDF), pass the explicit_aromaticity flag on the command line.

## Section: Molecule Preparation and Processing › Making Fragments

The BCL application molecule:Split gives researchers a tool to derive fragments from starting small molecules to aid in pharmacophore modeling, fragment-based drug discovery, and de novo drug design. There are many different types of fragments molecule:Split is able generate from whole molecule(s) (Table 2).

For example, we can derive the Murcko scaffold from the FDA-approved 3rd generation tyrosine kinase inhibitor (TKI) osimertinib (Ramalingam et al., 2017) as follows:

Alternatively, we could remove the Murcko scaffold and return the other components:

Substructure comparisons are described in more detail in Section 5.1.

Fragment splits currently supported by the BCL.

## Section: Molecule Preparation and Processing › Coordinate Information

The last application of interest for molecule processing is molecule: Coordinates molecule: Coordinates is a minor application that performs several convenience tasks. First, molecule: Coordinates can recenter all molecules in the input file(s) to the origin. Second, it can compute molecular centroids. Third, molecule: Coordinates can compute statistics on molecular conformers.

For example, passing the statistics flag compute statistics on bond lengths, bond angles, and dihedral angles. Passing the dihedral_scores flag will compute a per-dihedral breakdown of the BCL 3D conformer score. The BCL 3D conformer score, or ConfScore, computes an amide non-planarity penalty in addition to a normalized dihedral score. Passing the amide_deviations and amide_penalties will output the amide deviations and penalties on a per-amide basis, respectively. This can be useful when comparing conformations obtained from conformation sampling algorithms, crystal structures, and/or molecular dynamics (MD) trajectory ensembles. See Section 4 for more information on conformer sampling.

## Section: Computing Molecular Properties

Computing molecular descriptors/properties is a critical component of cheminformatics model building. We use the term “properties” to refer to individual chemical features and “descriptors” to refer to combinations of properties, often used to train QSAR/QSPR models; however, the terms are often used interchangeably in the BCL. In conjunction with substructure-based comparisons, generating molecular descriptors is arguably the foundation of LB CADD. The BCL was designed with a modular descriptor interface and extensible property definitions framework. This allows both developers and users alike to write new descriptors for specific applications as needed. To see a list of available predefined molecular properties, perform the following command:

The property interface is organized into two general categories: 1) Descriptors of Molecules, and 2) Descriptors of Atoms. As you will see throughout this section and Section 6, properties can be modified and recombined in a highly customizable fashion. See the Supplementary Materials for an example containing multiple custom property definitions, as well as for sample output from the molecule:Properties help menu options detailing available features.

Classifying small molecules’ potential for hit optimization. Models were trained to predict whether medicinal chemists would perform hit optimization on target molecules (“yes” or “no”) starting with seven descriptors: molecular weight, logP, number of hydrogen bond acceptors, number of hydrogen bond donors, polar surface area, number of rotatable bonds, number of aromatic rings. Model types include linear regression (red), decision tree (blue), single-layer artificial neural network (yellow), and the quantitative estimate of druglikeness score with cutoffs at mean score for attractive molecules (0.67; gray) and the mean plus one standard deviation (0.83; black) by Bickerton et al. (Bickerton et al., 2012). Models trained on supplemental data from Bickerton et al. (Bickerton et al., 2012).

## Section: Computing Molecular Properties › Computing Whole Molecule Properties

As the names suggest, some descriptors are intrinsic to the whole molecule, while others are specific to atoms. For example, compute some whole molecule descriptors for the EGFR kinase inhibitor osimertinib:

The flag add will add the specified properties to the SDF as MDL properties. The tabulate flag will output the properties for each molecule in row-column format in the file specified by output_table. There is also a statistics flag that will compute basic statistics for each of the specific descriptors across all the molecules in the input SDFs and output to output_histogram. The key observation regarding the output file is that the values for Weight, NRotBond, etc., are emergent properties of the whole molecule.

## Section: Computing Molecular Properties › Computing Atomic Properties

Next, compute some atomic descriptors for osimertinib:

Notice here that the statistics flag outputs statistics across each atom property rather than across each molecule property. This is also the behavior when there are multiple input molecules. Importantly, here we see that the output is an array of values for each property. The indices of the array correspond to the atom indices of the molecule.

## Section: Computing Molecular Properties › Performing Operations on Descriptors

Each category of descriptors can further be modified by molecule-specific or atom-specific operations. For example, some whole molecule properties can be obtained by performing simple operations on the per-atom properties. TopologicalPolarSurfaceArea (whole molecule property) is the sum of Atom_TopologicalPolarSurfaceArea (atomic property) across the whole molecule.

Check to verify that TopologicalPolarSurfaceArea and MoleculeSum (Atom_TopologicalPolarSurfaceArea) yield the same value for osimertinib.

Examples of additional operations include other basic statistics (mean, max, min, standard deviation, etc.), property radial distribution function (RDF), Coulomb force, and shape moment. See the help menu for additional options and details.

## Section: Computing Molecular Properties › Combining Properties to Evaluate Druglikeness

In Section 2.2 we discussed using the molecule:Filter application to remove molecules from a dataset that failed specific druglikeness criteria (e.g., TPSA ≥140 Å2). Several familiar druglikeness metrics come prepackaged in the BCL (i.e., Lipinski’s Rule of 5 and Veber’s Rule), as well as several others inspired by the literature and conventional medicinal chemistry practices. For each molecule in the Platinum Diverse dataset, count how many Lipinski and Veber violations there are. In addition, count as drug-like all molecules that have fewer than two Lipinski violations:

The property LipinskiViolations counts how many times a molecule violates one of Lipinski’s Rules ( ≤ 5 hydrogen bond donors (HBD; –NH and–OH groups), ≤10 hydrogen bond acceptors (HBA; any–N or–O), molecular weight (MW) < 500 Daltons, and water-octanol partition coefficient (logP) < 5). The LipinskiViolationsVeber property computes the number of times a molecule violates Veber’s Rule (infraction if TPSA ≥140 Å2 and/or number of rotatable bonds >10). The LipinskiDruglike property is a Boolean that returns 1 if fewer than two Lipinski violations occur; 0 otherwise. There is no equivalent Boolean operator for Veber druglikeness; however, it is simple to implement one using the aforementioned operators.

This command makes use of the Define and Less operators to return 1 if there are no violations to Veber’s Rule and 0 otherwise. New properties created with Define can also be passed to subsequent operators on the same line. For example, one could create a descriptor called VeberAndLipinskiDruglike by doing the following:

This new descriptor returns 1 if a molecule passes both druglikeness filters, and 0 otherwise.

Many metrics can be created using the BCL descriptor framework without modifying the source code. This can be useful to users who come across novel methods in the literature and wish to implement them in their own work. Take as an example a seminal work from Bickerton et al., which sought to quantify the chemical aesthetics of potential druglike compounds. Bickerton et al. asked 79 medicinal chemists at AstraZeneca to answer “would you undertake chemistry on this compound if it were a hit?” for ∼200 compounds each, to which chemists replied either “yes” or “no” (Bickerton et al., 2012). They generated a regression function that yielded a quantitative estimate of druglikeness (QED) using eight chemical descriptors: molecular weight, logP, number of hydrogen bond acceptors, number of hydrogen bond donors, polar surface area, number of rotatable bonds, number of aromatic rings, and number of ALERTS (Bickerton et al., 2012).

Using the same dataset and descriptors as Bickerton et al. (generously provided in their Supplemental Materials), similar druglikeness metrics can be implemented in the BCL through the descriptor framework. One approach could be to use the operators described above to reproduce the algebraic expression described in Eq. 1 of Bickerton et al. with the parameters described in their Supplemental Materials. The algebra expressed in BCL notation can be saved to an external text file and passed to the command-line using standard shell script syntax (e.g., @File.txt in Bash). Because there are relatively few descriptors in the Bickerton et al. model, an alternative approach could be to create a classification model.

Here, we demonstrate the latter by (Eq. 1) generating a decision tree (DT) model and then 2) converting our DT into a single logic statement to pass to the BCL descriptor interface. For comparison, we also generate linear regression (LinReg) and artificial neural network (ANN) models, and we include the original QED score. All models are trained to predict a chemist’s verdict for each potential compound based on the descriptors used in Bickerton et al. (for details on model training and validation, see Supplementary Methods; for details on how to build machine learning models with the BCL, see Section 7).

Model classification performance is displayed as a receiver-operating characteristic (ROC) curve (Figure 1). Bickerton et al. found that the mean QED score for molecules that medicinal chemists found favorable was 0.67 (±0.16 standard deviation). Taking the mean and mean plus standard deviation QED scores as cutoffs, we see that QED performs comparably to multiple linear regression. The ANN and DT perform better, but perhaps owing to the small number of and simple relation between variables there is no performance benefit of the ANN over the DT (Figure 1).

Now that we have our DT, we can reduce it to a readable if-else style format that can be converted into a BCL descriptor. Run the script SimplifyDecisionTree.py, passing as an argument the DT model:

We can see in the contents of DT. logic_summary.txt that the first thing the DT checks is whether the small molecule has less than two aromatic rings. Molecules with no aromatic rings are excluded, and molecules with one aromatic ring are subject to different criteria than molecules with two or more. Subsequent criteria are then evaluated. We can rewrite the logic summary as a descriptor and save it in a file called “dt.obj”. Then, we pass that file to molecule:Properties as a descriptor definition and use it to classify molecules:

The “dt.obj” code object file is a plain text file that can be opened with any text editor. The syntax mimics the BCL command-line syntax. Code object files are a convenient way to write a long, multi-line BCL command-line that makes it easier to build and reuse feature sets.

On the topic of druglikeness, it is worth noting that additional advanced methods are also available to classify the chemical space of molecules in a dataset. In some cases, it is useful to identify potential drug-like compounds that not only fit the criteria discussed above but are also similar to some known class (es) of drugs. For example, when performing fragment-based combinatorial library design for kinase inhibitors, in addition to filtering out molecules that violate Veber’s rules, it may also be desirable to filter molecules that are not sufficiently chemically similar to existing kinase inhibitors. This can be accomplished by building and scoring against an applicability domain (AD) model. For further details on creating and using AD models in the BCL, see Section 7.4.3.

We have described multiple uses of the molecule:Properties application, placing special emphasis on how it can be utilized to build different types of druglikeness metrics. As it is fundamentally a tool to obtain information from small molecule chemical structures, molecule:Properties can also be used to help generate statistical potentials, chemical filters, QSAR/QSPR models, and more. Some of these use-cases will be explored in later sections.

Classifying small molecules’ potential for hit optimization. Models were trained to predict whether medicinal chemists would perform hit optimization on target molecules (“yes” or “no”) starting with seven descriptors: molecular weight, logP, number of hydrogen bond acceptors, number of hydrogen bond donors, polar surface area, number of rotatable bonds, number of aromatic rings. Model types include linear regression (red), decision tree (blue), single-layer artificial neural network (yellow), and the quantitative estimate of druglikeness score with cutoffs at mean score for attractive molecules (0.67; gray) and the mean plus one standard deviation (0.83; black) by Bickerton et al. (Bickerton et al., 2012). Models trained on supplemental data from Bickerton et al. (Bickerton et al., 2012).

## Section: Small Molecule Conformer Generation

Small molecule 3D conformer generation is a critical aspect of both SB and LB CADD because the biologically relevant conformation of the molecule of interest is rarely known a priori. In SB molecular docking, small molecule flexibility is often represented through the inclusion of multiple discrete pre-generated conformers (Brylinski and Skolnick, 2008; Morris et al., 2009; Lemmon and Meiler, 2012; Combs et al., 2013; DeLuca et al., 2015). Small molecule conformations need to be sampled to arrive at the correct binding pose. Molecules that appear in binding pockets of substantially different proteins often bind in distinct modes for each protein, suggesting that the binding pose of the molecule need not be near the global energy minima of the molecule (Nicklaus et al., 1995; Boström et al., 1998; Perola and Charifson, 2004; Sitzmann et al., 2012; Friedrich et al., 2018). Likewise, in LB pharmacophore modeling, small molecules need to be flexibly aligned according to their chemical properties to identify the biologically relevant 3D features conferring bioactivity.

The BCL conformer generator, also called BCL:Conf, utilizes a fragment-based rotamer library derived from the crystallography open database (COD) to combine rotamers consisting of one or more dihedral angles according to a statistically-derived energy (Mendenhall et al., 2020). Clashes are dynamically resolved by iteratively identifying clashed atom pairs and rotating the central-most bonds between them without changing dihedral bins. In this way, conformational ensembles are stochastically generated according to likely rotamer combinations from the COD.

The BCL small molecule conformation sampler is a leader among general purpose small molecule conformer generation algorithms (Kothiwale et al., 2015; Mendenhall et al., 2020). In this section, we demonstrate how to use the BCL to generate global and local conformational ensembles and sample discrete rotamers within a molecule.

Substructure sampling of small molecule rotamers with BCL:Conf. (A) Crystallographic structure of osimertinib bound to EGFR kinase (PDB ID 4ZAU) contains missing density of the ethyldimethylamine substituent of osimertinib. (B) Global conformational sampling of the osimertinib ethyldimethylamine substituent without perturbing the rest of the bound pose using BCL:Conf. Osimertinib electron density visualized with green mesh by importing the 2fo-fc map in PyMOL and contouring at 2σ.

## Section: Small Molecule Conformer Generation › Generating Global Conformational Ensembles

Start by generating conformers of osimertinib with the default settings. Here, all that is needed is an input filename and an output filename:

The ensemble_filenames argument is equivalent to the input_filenames argument used elsewhere (the difference is historical). The conformers_single_file argument is one of two output options. The other option is conformers_separate_files. As implied by the name, in the former case all conformers are output to a single file. In the latter case, if multiple molecules are input to ensemble_filenames, then a unique SDF will be written for the conformational ensembles of each of the input molecules [e.g., if the input SDF(s) contained 10 molecules, then conformers_separate_files would output 10SDFs each with a conformational ensemble of one of the input molecules].

By default, BCL:Conf will perform 8,000 conformer generation iterations, each of which rebuilds the molecule essentially from scratch (excepting rigid ring structures and bonds that do not vary substantially in length or angle). Without any other options, the top conformations will be clustered, yielding the 100 best-scoring representatives of each different cluster. An unbiased view of the conformational space around the ligand can be obtained by setting the skip_cluster flag. For this application, it is advisable to lower the number of iterations to roughly double the number of desired conformations; the conformers are rebuilt from scratch at every iteration, so there is little gain from doing more iterations than conformers desired. The returned conformers are sorted by score. Number of iterations and final conformers can be specified with the max_iterations and top_models flags, respectively.

Conformations can be filtered to remove highly-similar conformations using the conformation_comparer flag (e.g., to standard RMSD, dihedral distance, etc.) and the tolerance for what constitutes an “identical” conformer increased from the default (0.0) to an arbitrarily large value (note that RMSD- and dihedral-based metrics have units of Å and degrees, respectively) (Kothiwale et al., 2015). For most applications, we recommend the use of SymmetryRMSD with a modest tolerance of 0.25 Å. By default, the tolerance is adjusted automatically to yield the desired number of clusters so as to best represent conformational space, however, a user-provided tolerance is treated as a minimal acceptable difference between clusters.

For high-throughput applications, we recommend reducing iterations from 8,000 down to 800 or even 250. BCL:Conf’s speed is nearly linear in number of iterations. Generally, more iterations yield better performance, at a trade-off of slightly-faster than linear increase in time per conformation when clustering is used (Mendenhall et al., 2020).

Alternatively, if conformation_comparer is set to “RMSD 0.0”, then no filtering or clustering is specified, and BCL:Conf will perform max_iterations conformer generation iterations, randomly select top_models conformers, sort them from best to worst by score, and return them. This option is the fastest, and the ensembles returned are arguably the most Boltzmann-like. For a recent comparison of each set of parameters to one another and other conformer generation algorithms, please see Mendenhall et al., 2020 (Mendenhall et al., 2020). We recommend generating conformers with explicit hydrogen atoms added.

Generate conformers using two of the protocols described protocols. First, run

Then,

Notice that the ensemble generated with the SymmetryRMSD comparer and clustering enabled occupies the densest part of the broader conformational space sampled in the raw distribution.

## Section: Small Molecule Conformer Generation › Generating Local Conformational Ensembles

Local sampling was implemented in the recent algorithmic improvements to BCL:Conf (Mendenhall et al., 2020). The idea is that sometimes users know or have predicted with some degree of certainty a chemically meaningful or bioactive pose of a small molecule, but additional refinement is needed. This is a common use case when modeling protein-ligand complexes starting with another ligand with some similarity to the ligand of interest (Bozhanova et al., 2021; Hanker et al., 2021). When using pre-generated conformers for docking or small molecule flexible alignment, it is unlikely that the best ligand conformer will be chosen and simultaneously have its position fully optimized in Cartesian space. Local sampling around an input conformer allows the user to refine ligand poses after an initial search.

Local sampling in the BCL is accomplished by restricting the rotamer search in one of four ways:

These options are not mutually exclusive. Depending on how they are combined, different levels of sampling can be achieved. Moreover, they can be used in combination with any of the other options (e.g., conformation comparison type, clustering) described above. Generate local conformational ensembles of osimertinib by first placing all three restrictions:

Next, apply only the skip_rotamer_dihedral_sampling and skip_bond_angle_sampling restrictions to generate a local ensemble:

Both of the ensembles show less conformational diversity than the global conformational ensemble created in the previous section. Notice the relative sampling differences between each of the local conformation sampling protocols described.

## Section: Small Molecule Conformer Generation › Conformational Sampling of Substructures

Often times one may wish to only sample conformations of part of a molecule. For example, in docking congeneric ligand series, the core scaffold pose may be known with a high degree of confidence, and the goal is to optimize the pose of the rest of the molecule while keep the core scaffold fixed. Alternatively, crystal structures of protein-ligand complexes often have low or missing density for part of a bound ligand, and thus coordinate assignment may not accurate. Discretely sampling specific small molecule rotamers thus becomes a useful task to perform.

In the BCL, this is accomplished by first assigning an MDL miscellaneous property named “SampleByParts” to the molecule(s) of interest. The value of the SampleByParts property corresponds to the 0-indexed atom indices of atoms in dihedrals that are allowed to be sampled by molecule:ConformerGenerator. By encoding this as a molecule-specific property, we avoid multiple command-line calls with different atom index specifications, allowing users to generate conformers more rapidly for multiple molecules and/or different independent rotamers within a molecule.

As an example, consider a crystal structure of epidermal growth factor receptor (EGFR) kinase in complex with osimertinib (PDB ID 4ZAU) (Yosaatmadja et al., 2015). This is the first publicly available crystal structure of the EGFR-osimertinib complex. In this structure, the solvent-exposed ethyldimethylamine substituent is missing density. We will sample alternative conformations of the ethyldimethylamine substituent than that which is proposed in the PDB ID 4ZAU. First, add the corresponding atom indices to the file osimertinib. sdf:

Also, note that if you have many molecules for which you want to assign SampleByParts atom indices and you do not want to have to manually identify the relevant indices, you can also use the molecule:SetSampleByPartsAtoms application. This application sets SampleByParts indices based on comparison to user-supplied substructures. With the SampleByParts property defined in the SDF, generate global conformers as previously described:

Observe that sampling global conformers (i.e., sampling across dihedral bins allowing bond angle/length adjustment and ring conformer changes) with SampleByParts maintains the coordinates of all unspecified atoms. In this case, only dihedrals containing strictly the ethyldimethylamine atoms are sampled (Figure 2). Similarly, SampleByParts can be used in conjunction with the local sampling methods described above.

Substructure sampling of small molecule rotamers with BCL:Conf. (A) Crystallographic structure of osimertinib bound to EGFR kinase (PDB ID 4ZAU) contains missing density of the ethyldimethylamine substituent of osimertinib. (B) Global conformational sampling of the osimertinib ethyldimethylamine substituent without perturbing the rest of the bound pose using BCL:Conf. Osimertinib electron density visualized with green mesh by importing the 2fo-fc map in PyMOL and contouring at 2σ.

## Section: Molecule Property- and Substructure-based Comparisons

A critical component of LB CADD is molecular similarity analysis. Provided a set of molecules, we frequently want to know how similar each molecule is to a reference molecule(s). Fundamentally, this requires 1) defining what specifically will be compared between the molecules, and 2) defining the metric with which similarity will be measured. In the BCL, this is accomplished primarily through use of the molecule:Compare application. The command-line syntax of molecule:Compare differs from the syntax of other applications discussed so far. The SDF input files to molecule:Compare are passed as parameters instead of argument flags.

This syntax strictly enforces two types of behavior:

Finally, it is worth noting that molecule:Compare’s performance scales approximately linearly with number of threads for costly comparisons. To enable threads, set -scheduler PThread <number_threads>. We suggest setting number_threads to number of physical cores on the device for maximum performance.

Maximum common substructure between gefitinib and afatinib. (A) Afatinib (PDB ID 4G5J) and (B) gefitinib (PDB ID 4I22) in their binding mode 3D conformations next to (C) their maximum common substructure extracted with the BCL.

Property-based alignment of dihydrofolic acid and methotrexate with BCL:MolAlign. (A) Superimposed crystallographic structures of dihydrofolic acid (DHF; PDB ID 1DHF) and methotrexate (MTX; PDB ID 1DLS) in complex with dihydrofolate reductase (DHFR). (B) Rigid alignment of DHF and MTX starting from the bioactive conformers from the crystal structures. (C) Flexible alignment of MTX (flexible) to DHF (rigid, bioactive conformer). (D) Fully flexible alignment of DHF and MTX. DHF is colored white and MTX is colored wheat. MTX was randomly rotated and translated prior to rigid alignment to DHF. All flexible alignments performed using generate_3D to remove bias from start coordinates.

## Section: Molecule Property- and Substructure-based Comparisons › Defining Molecular Structures

The BCL encodes molecules as graphs where the edges are bonds, and the atoms are nodes. For substructure-based comparisons, we can define equivalence between bonds and atoms using various comparisons dubbed comparison types. For any substructure-based comparison between two or more molecules, some combination of atom and bond comparison types is required, which defines the equivalence class for the atoms and bonds, respectively. The default combination differs between tasks. For a summary of available atom and bond type comparisons, examine the help menu options of any comparer that utilizes substructures. For example,

will display the default atom and bond comparison types for this comparison method as well as list the available comparison types. For example, if atom type resolution occurs at AtomType, then an SP3 carbon would match another SP3 carbon but not an SP2. If the resolution is lowered to ElementType, then all carbon atoms can match one another independent of their orbital configuration. Similarly, bond type resolutions of BondOrder and BondOrderAmideWithIsometryOrAromaticWithRingness will yield different substructure matches.

Not all similarity comparisons occur at the structural/substructural level. A number of comparison metrics in the BCL occur between properties computed at the whole molecular, substructural, or atomic level. Further, distance-based comparisons between molecules that are constitutionally identical can also be made.

## Section: Molecule Property- and Substructure-based Comparisons › Similarity Scoring Between Constitutionally Unique Molecules

In cases where the similarity between unique molecules is desired there are broadly two approaches for measuring similarity: by substructure and by property. These are not mutually exclusive; depending on the desired resolution of the substructure comparisons, one can further measure property differences between substructures of different molecules.

One common substructure similarity metric is the Tanimoto coefficient (TC), expressed between two molecules as the ratio of matched-to-unmatched atoms:

where A and B are the two molecules. The intersection of atoms in (Eq. 1) is the size of the largest common substructure under the specified comparison types. This is a specific formalism of the more general Tversky index when both α and β are equal to 1:

The first-generation EGFR tyrosine kinase inhibitor gefitinib and the second-generation inhibitor afatinib are structurally very similar. Afatinib is modified from the gefitinib scaffold and incorporates an acrylamide linker. Visualize the maximum common substructure (MCS) of afatinib and gefitinib using molecule:Split (Figure 3):

Next, calculate the MCS TC of the gefitinib and afatinib:

This method searches for the single largest common connected substructure as the intersection of two molecules and computes the TC. In this case, the MCS TC is approximately 0.48. Sometimes searching for a single connected substructure can be disadvantageous. For example, if the primary differences between molecules results from core substitutions bridging two otherwise identical halves, then the single largest common substructure approach will fail to account for the complete degree of similarity. Alternatively, the user can calculate the maximum common disconnected substructure (MCDS) TC:

As expected, the MCDS TC is greater than the MCS TC at approximately 0.86.

Maximum common substructure between gefitinib and afatinib. (A) Afatinib (PDB ID 4G5J) and (B) gefitinib (PDB ID 4I22) in their binding mode 3D conformations next to (C) their maximum common substructure extracted with the BCL.

## Section: Molecule Property- and Substructure-based Comparisons › Distance-Based Scoring Between Constitutionally Identical Molecules

In Section 4 we demonstrated how the BCL can be used to generate small molecule conformational ensembles. One common way to measure the performance of small molecule conformer generators is to measure how close we can recover biologically relevant conformations. We can do this in the BCL by measuring the RMSD or SymmetryRMSD of molecules in our conformational ensemble to the experimentally determined conformations. Generate a global ensemble of osimertinib:

Note that we are generating the molecule completely de novo ignoring all information from input coordinates by using generate_3D. Measure the heavy-atom symmetric RMSD to the native conformation:

On examination of osi. sym_rmsd_native.txt, we see that see that of our 25 generated conformers, 3 are less than 2.0 Å from the native conformer, and the best is approximately 0.66 Å from native. If we repeat this process for two additional TKIs, the first-generation inhibitor erlotinib and the second-generation inhibitor afatinib, we also see that we are able to obtain multiple conformers less than 1.0 Å from native.

In addition to RMSD-based metrics, molecule:Compare can also measure distance in the form of dihedral angle sums and dihedral distance bins. For additional information, examine the help menu options.

## Section: Molecule Property- and Substructure-based Comparisons › Largest Common Substructure Alignment

The BCL can be used to align small molecules according to their MCS. Unlike most of the examples in this section, this is accomplished through the molecule:AlignToScaffold application by passing three parameters:

For example, to align afatinib to gefitinib based on their MCS, use the following command:

Instead of aligning by MCS, the user may also align the target ensemble to the largest rigid component of the scaffold structure by passing the align_rigid flag. Moreover, if the user wants to a define an alternative set of atoms to be aligned instead of the defaults, this can be accomplished by specifying those atoms for each the scaffold and target ensemble with align_scaffold_atoms and align_ensemble_atoms, respectively.

## Section: Molecule Property- and Substructure-based Comparisons › Property-Based Flexible Alignment

In addition to substructure-based alignment, we can also perform property-based alignment. Property-based alignment algorithms typically maximize the overlap or minimize the distance between molecular and/or atomic properties (Sliwoski et al., 2014). We have previously demonstrated that the performance of the BCL property-based alignment algorithm, also referred to as BCL:MolAlign, is on par with leading academic and commercial molecular alignment algorithms (Brown et al., 2019).

BCL:MolAlign combines the conformational sampling ability of BCL:Conf with the property framework described in Section 3 to minimize the property-distance between two molecules through flexible superimposition. The property-distance is computed between mutually-matching atom pairs that are dynamically updated with each iteration. Alignment pose sampling is accomplished through a series of moves that traverse the co-space defined by the relative position of the two molecules to one another (Brown et al., 2019). BCL:MolAlign can be used to perform alignments which can be classified as rigid (two molecules with fixed conformers), semi-flexible (one molecule with a fixed conformer, one molecule whose conformers are sampled), and fully-flexible (two molecules whose conformers are sampled).

To demonstrate how BCL:MolAlign can be used to perform each of these alignments, consider the classic problem of obtaining the crystallographic alignment of methotrexate (MTX) and dihydrofolic acid (DHF). This example is a good one because the intuitive heterocyclic overlap is not the correct one (Labute et al., 2001). Instead, alignment of the binding pockets of dihydrofolate reductase (DHFR) co-crystallized with MTX (PDB ID 1DLS) and DHF (PDB ID 1DHF) shows only partial heterocycle overlap and superimposition of the heterocycle carbonyl in DHF and an aromatic hydrogen bond accepting nitrogen in MTX (Figure 4A). Perform a rigid alignment of MTX to DHF with the following command:

The rigid alignment ranks the correct alignment mode as the top scoring alignment (Figure 4B). Rigid alignments are rarely useful for drug discovery because the bioactive conformation of the target small molecule is usually unknown; however, they provide a useful check for alignment scoring functions. Next, flexibly align MTX to the DHFR-binding pose of DHF:

Here, we can see that BCL:MolAlign correctly determines the alignment of the heterocycles, central aromatic rings, and (partially) the acidic groups (Figure 4C). Note that rigid_mol_b is enabled, which fixes the pose of the second parameter molecule. For a detailed description of how each argument modifies the alignment algorithm, see Brown et al. (Brown et al., 2019). For performance considerations, we generally find that the number of conformer pairs is more critical to pose recovery than the numbers of iterations at each stage. For complex ligands with many rotational bonds, we recommend increasing max_conformations and conformer_pairs.

Fully-flexible alignment is useful when one is trying to recover pharmacophore features without knowing the binding pose of either molecule. Here, the goal is to align pharmacophore features of the molecules, not recover the native pose of the target molecule(s) by aligning to another molecule with a known binding mode. Perform a fully-flexible alignment of MTX and DHF.

Fully-flexible alignment of MTX and DHF does not recover the most native-like conformations of MTX and DHF; however, it does recover correct alignments of the heterocycles, central aromatic rings, and acidic groups (Figure 4D). Notice that we increased the number of conformer pairs from 500 to 2,500 when we went from semi-flexible to fully-flexible alignment.

Property-based alignment of dihydrofolic acid and methotrexate with BCL:MolAlign. (A) Superimposed crystallographic structures of dihydrofolic acid (DHF; PDB ID 1DHF) and methotrexate (MTX; PDB ID 1DLS) in complex with dihydrofolate reductase (DHFR). (B) Rigid alignment of DHF and MTX starting from the bioactive conformers from the crystal structures. (C) Flexible alignment of MTX (flexible) to DHF (rigid, bioactive conformer). (D) Fully flexible alignment of DHF and MTX. DHF is colored white and MTX is colored wheat. MTX was randomly rotated and translated prior to rigid alignment to DHF. All flexible alignments performed using generate_3D to remove bias from start coordinates.

## Section: Feature Generation

The descriptor application group is the workhorse for molecule featurization. Similar to the molecule:Properties application, the descriptor application group provides command-line access to the internal descriptor framework. Unlike molecule, descriptor is dataset centric; its primary purpose is to generate, manipulate, and analyze feature datasets for QSAR/QSPR. In this section, we will demonstrate core applications in descriptor and how they can be utilized in QSAR/QSPR modeling.

Illustration of signed autocorrelation descriptors. Signed autocorrelations are the sums of products of each atom property pair (e.g., i0,j2) in a distance bin defined by (A) bond separation, or (B) Euclidean distance in 3D space. Within each distance bin, atom property pairs are further separated into bins corresponding to the sign of the property of the first (left hand side of ‘/’) and second (right hand side of ‘/’) atoms in the pair.

Signed 3DA variance increases with bin distance in flexible molecules. The 3DA distance bins extend to 6.0 Å at intervals of 0.25 Å. At each distance bin, there are three sign-pair bins (−/−, +/+, −/+).

## Section: Feature Generation › Generating Simple Datasets From Molecules

Four specifications are required to generate feature datasets from small molecules:

Generate a simple feature dataset consisting of several scalar descriptors for a set of confirmed active M1 Muscarinic Receptor positive allosteric modulators (PAMs) and corresponding true negatives (Butkiewicz et al., 2013). The SDF corresponding to these compounds is 1798. combined.sdf. These molecules have been labeled with the MDL property “IsActive” such that the confirmed actives have a value of 1 and the negatives have a value of 0.

Binary files were designed for rapid non-consecutive reading and writing, but the interested reader will find that the file format consists of a textual header specifying the properties and their sizes followed by a simple binary output of all features. Dataset information and statistics can be obtained by calling descriptor:GenerateDataset compare. For example:

To better understand the binary file encodings, convert 1798. combined.scalars.bin to a CSV file:

The first column of every row contains the ID label “M1” as specified when the binary file was generated. The next four columns contain the descriptors specified above: Weight, LogP, HbondDonor, and HbondAcceptor. The very last column is the result value, which contains either 0 or 1 depending on the value in the SDF MDL property “IsActive”.

Convert CSV file back to a binary file:

CSV files do not contain all of the supplementary information contained within the partial binary file format. Thus, certain information needs to be provided directly. For example, we need to specify the number of characters that are part of the row ID label, otherwise the BCL will try to convert the string (or numerical) ID into feature values. ID labels therefore must be fixed-width. In addition, we need to tell the BCL how many of the columns are result values. By default, the BCL will assume that only the last column is the result label. By specifying number result cols = N, we tell the BCL to take the last N columns of the CSV as the result value(s).

Also notice that the feature and result label information is not informative after converting from CSV to binary. The values are transferred to the new file format, but the BCL obviously cannot know where those values came from. These must be manually specified.

In this case, the feature labels are internal parsable properties of the BCL; however, when relabeling feature labels upon converting from CSV to binary format, the user can specify any labels so long as the total number of labels is consistent with the number of feature columns.

## Section: Feature Generation › Modifying Datasets

After generating a dataset or importing a CSV file and converting it to binary format, feature datasets can be modified. The most frequent form of modification is randomization. Training a machine learning model, for example a neural network, often requires dataset randomization.

Binary files are read by the “Subset” retriever. The Randomize operator is passed through the source flag and provided the dataset retriever option corresponding to the binary file.

Additional dataset operators can be classified by how they modify the dataset. For example, the PCA (principal components analysis) and EncodeByModel operators perform dimensionality reduction across feature (column) space, while the KMeans operator reduces dimensionality across molecule (row) space. Other operators are useful during model training and validation, such as Balanced, Chunks, and YScramble. Still others can be used to select particular ranges of rows from a dataset, such as Rows. Here, we will take a look at a few dataset operators. For full details on all available dataset operators, see the descriptor:GenerateDataset help menu.

Start by generating a dataset for the Kir2.1 inward rectifying potassium channel using the dataset compiled in Butkiewicz et al. (Butkiewicz et al., 2013) and the best performing LB descriptor set from Mendenhall and Meiler (Mendenhall and Meiler, 2016). This dataset contains 301,493 small molecules, 172 of which are confirmed active molecules. For each molecule, there will be 1,315 feature columns and 1 result column.

Randomize the dataset:

Note that we could have generated a randomized dataset with a single command by wrapping the SdfFile dataset retriever with Randomize; however, the Randomize dataset retriever is unable to support hyperthreading. Consequently, it is faster to generate larger datasets first using multiple threads and randomize them afterward. Next, perform PCA on the dataset using OpenCL to accelerate the calculation with a GPU. The flag opencl is optional and may not be supported on all platforms, but may provide a substantial speedup, depending on the GPU and dataset size:

Finally, generate a new feature dataset accounting for 95% of the variance:

Performing PCA on the dataset has reduced the number of descriptors from 1,315 to 695. Alternatively, one could use EncodeByModel to reduce the number of feature columns using a pre-generated model. The following example utilizes pseudocode and a hypothetical pre-generated ANN with the MendenhallMeiler2015. Minimal.object features.

The input file < my_binary_file.bin > would have 1,315 descriptors from MendenhallMeiler2015. Minimal.object, and the output file < my_encoded_binary_file.bin > would have a number of descriptors corresponding to the number of neurons in the final hidden layer preceding the output layer of our hypothetical pre-generated ANN.

As a practical note, we have found that PCA-based dimensionality reduction useful for dataset visualization, but of limited value in improving model performance. Performance can often be recovered to that of the initial dataset when requiring at least 95% of the variance to be preserved, but performance improvement is rare from PCA, when using a regularized method such as dropout-ANNs.

Suppose you encoded the same original feature set using two different models and now want to combine the new encoded files for further training. This can readily be accomplished with the Combine operator.

Next, instead of performing dimensionality reduction along the column (features) axis, we will reduce the dimensionality along the row (molecule) axis. Perform K-means clustering of the feature dataset to reduce our row number from 301,493 to 300.

This form of dimensionality reduction is unlikely to be as useful for training a deep neural network (DNN); however, it can be useful in similarity analysis in low dimensional feature space. Some of the datasets generated in this section will be referenced again in Section 7 to train classification machine learning models.

## Section: Feature Generation › Small Molecule Autocorrelation Descriptors

As indicated in the previous section, the BCL can also compute signed autocorrelation functions. Autocorrelations are regularly used as features in cheminformatics machine learning models (Sliwoski et al., 2014). When computed for atomic descriptors, such as Atom_SigmaCharge, the autocorrelations sum pairwise property products into distance bins by calculating the separation between molecule atom pairs in number of bonds (2DA) or Euclidean distance (3DA). Each distance bin is further separated into three sign-pair bins corresponding to property value sign of each atom in the pair (Eq. 3) (Sliwoski et al., 2015).

where ra and rb are the boundaries of the current distance interval, N is the total number of atoms in the molecule, r(i,j) is the distance between the two atoms being considered, δ is the Kronecker delta, and P is the property computed for each atom. 2DAs are conformation-independent, while 3DAs are conformation-dependent (Figure 5).

The “dasatinibs.sdf” file contains the coordinates and connectivity for two dasatinib molecules: one with 2D coordinates, the other with 3D coordinates. Compute the signed 2DA and 3DA for Atom_SigmaCharge on both dasatinib molecules.

Upon examination of the tabulated 2DA and 3DA values for the two different dasatinib molecules, we observe that the 2DA contains the same values in both cases, while the 3DA contains unique values for the different conformers. To visualize the variance in each 3DA distance bin, we can tabulate the 3DAs for Atom_SigmaCharge on an ensemble of 3D conformations for several different molecules (Figure 6). Dasatinib is a TKI with 7 rotatable bonds, amprenavir is a HIV protease inhibitor with 12 rotatable bonds, AZD1283 is an antagonist of the P2Y12 receptor with 9 rotatable bonds, and ethinyl estradiol is a synthetic estradiol with only 1 rotatable bond that binds and activates estrogen receptors.

We can see that the variance in each descriptor column increases as a function of distance and number of rotatable bonds. In ethinyl estradiol there is little change in descriptor column variance as a function of distance. In contrast, molecules with increasing numbers of rotatable bonds display increasingly large variances at longer distance bins. This suggests that increasing conformational heterogeneity at longer distance bins leads to increased noise. Indeed, we have previously found that extending LB 3DAs beyond approximately 6.0 Å generally results in reduced performance on QSAR classification tasks (Sliwoski et al., 2015), consistent with our example here (Figure 6). Importantly, however, at shorter distances where there is less conformational heterogeneity we are able to improve our performance with 3DAs even when the active conformation of the small molecule is unknown (Sliwoski et al., 2015; Mendenhall and Meiler, 2016). Moreover, models making predictions on molecules that are fairly rigid (e.g., steroid derivatives) may benefit from longer range distance bins.

It is also possible to use molecule:Properties to tabulate and compute statistics for molecules instead of plotting the CSV file data from descriptor:GenerateDataset. Here, we used descriptor:GenerateDataset to illustrate its usage. In practice, we do not just use a single 3DA or 2DA, but instead build sets of descriptors for feature and result labels and store them as separate code object files. As mentioned previously, the code object file format is the same format as allowed on the command line.

Illustration of signed autocorrelation descriptors. Signed autocorrelations are the sums of products of each atom property pair (e.g., i0,j2) in a distance bin defined by (A) bond separation, or (B) Euclidean distance in 3D space. Within each distance bin, atom property pairs are further separated into bins corresponding to the sign of the property of the first (left hand side of ‘/’) and second (right hand side of ‘/’) atoms in the pair.

Signed 3DA variance increases with bin distance in flexible molecules. The 3DA distance bins extend to 6.0 Å at intervals of 0.25 Å. At each distance bin, there are three sign-pair bins (−/−, +/+, −/+).

## Section: Machine Learning Architectures and Applications

The BCL supports multiple machine learning algorithms for QSAR/QSPR modeling. Among the methods available are ANNs (including DNNs and multitasking neural networks) (Dahl, 2014; Bharath et al., 2015; Mendenhall and Meiler, 2016; Xu et al., 2017), support vector machines (SVM) (Kawai et al., 2008; Ma et al., 2008; Mariusz et al., 2009), Kohonen networks (KN) (Kohonen, 1990; Korolev et al., 2003; Wang et al., 2005), restricted Boltzmann machines (RBM) (Le Roux and Bengio, 2008; Tijmen Tieleman, 2008), and decision trees (DT) (Mariusz et al., 2009; Sheridan, 2012; Butkiewicz et al., 2013). GPU acceleration is available for ANNs and SVMs through OpenCL (Munshi, 2008). The primary application group for machine learning in the BCL is model. To see the applications within model, check the help menu:

Machine learning model types.

Objective functions for machine learning models.

ROC curve comparison Kir2.1 activity prediction models with different descriptors. Models were trained with either (A,B) the Minimal dataset containing 959 non-redundant standard LB descriptors (see Supplemental Data) on a log10 (A) or linear (B) x-axis, or PCA-modified LB descriptors accounting for 95% variance on a log10 (C) or linear (D) x-axis.

Result value overlap between the Full and Dense datasets. Density normalized histograms of LogP, LogS, and ΔGhydration between the Full (35874 total, 35113 LogP, 20721 LogS, 1,339 ΔGhydration; gray) and Dense (448 total for all values; green) datasets.

Five-fold cross validation results for multitask modeling of solubility prediction. These table values are automatically calculated and output in the log_merge.txt file in the corresponding subdirectory of the autogenerated “log_files” directory. The Full set consisted of 35,874 molecules (with 35113 LogP, 20721 LogS, and 1,339 ΔGhydration result labels). The Dense set consisted of 448 molecules (with 448 LogP, 448 LogS, and 448 ΔGhydration result labels). The Full–Dense set contained 35,428 molecules (with 34665 LogP, 20273 LogS, and 891 ΔGhydration result labels).

QSPR external test-set predictions. Results of predicting QSPR properties on the Dense dataset with the model trained on the Full–Dense feature set, and results of predicting QSPR properties on the Full–Dense dataset with the model trained on the Dense feature set. The table is organized such that the values indicate the performance of the model trained with the indicated set of descriptors on the alternate test set. The Dense set consisted of 448 molecules (with 448 LogP, 448 LogS, and 448 ΔGhydration result labels). The Full–Dense set contained 35,428 molecules (with 34665 LogP, 20273 LogS, and 891 ΔGhydration result labels).

Applicability domain models differentiate molecular structures targeting unique proteins. Each box plot represents AD scores of five drugs that target either kinases or opioid receptors. AD models trained on kinase and opioid training datasets are colored in red (legend: kinaseAD) and blue (legend: opioidAD), respectively.

## Section: Machine Learning Architectures and Applications › Overview of BioChemical Library Model Training and Validation

Here, we will first introduce the user to the overall workflow involved in training, analyzing, and subsequently testing BCL machine learning models. The basic workflow for model training is the same for each machine learning method and can be completed via the model:Train application. To see the available machine learning methods, access the help options within model:Train.

As of this writing, the available model types can be found in Table 3. The most reliable way to see available model types is via the help menu options of your version of the BCL.

To expose all options for a particular machine learning method, pass the algorithm name as the first parameter to the application with the help menu request:

The following is a typical command-line format to train a model beginning with a pre-generated descriptor binary file:

Model performance is evaluated with the user-specified objective function. The choice of objective function is typically related to the task being performed (e.g., classification vs regression) (Table 4).

BCL model:Train is designed to readily enable cross-validation. The application is flexible with respect to serialization of model predictions for each of the monitoring, independent, and training partitions as well as writing of the model itself. For example, in five-fold cross-validation, the dataset is split into five chunks. For each round of cross-validation, the model is trained on four-fifths of the dataset, and the other fifth “independent” set is left out for testing. One of the chunks can additionally be specified as the monitoring dataset. The monitoring dataset can be used for early termination of the model training session to prevent overtraining (early termination is largely deprecated in favor of dropout to prevent earlier termination; we demonstrate it here to illustrate the syntax).

The initial dataset set is split into monitoring, independent, and training partitions with model:Train by assigning chunks with the dataset retriever responsible for binary format files, Subset. In the following pseudocode example, we will set the options to divide the training set into the following five chunks (0-indexed): chunks one to four will be used as the training set, and chunk 0 will be used as both the monitoring set and the independent set (this is appropriate only if the monitoring dataset is not being used for early termination).

Dataset partitioning is repeated for each round of cross-validation until each chunk takes a turn as the independent set. Then, the predictions of all the test sets are pooled together by the model:PredictionMerge application:

This command line averages predictions made on the same independent set, though other pooling operations are available (see help). Prediction performance is evaluated with the specified objective function on the pooled predictions using the model:ComputeStatistics application:

Machine learning model types.

Objective functions for machine learning models.

## Section: Machine Learning Architectures and Applications › Simplifying the Model Training and Validation Framework in Practice

To simplify model training, we have written a Python script “launch.py” to perform training and cross-validation with one command.

To see a list of model training operations (descriptor selection or scoring, for example):

To see the list of available flags for cross-validation, call

The following pseudocode example generates a simple linear regression model:

More complex commands can be easily prepared inside of a configuration file to be passed to the “launch.py” script. A sample configuration file is available in the Supplementary Material.

The “launch.py” script will automatically generate three new directories titled “log_files”, “results”, and “models”. Into each of those three directories a labeled directory (name specified with the id flag) is made. Model prediction output files and results of the final objective function are stored in the labeled directory within the “results” folder. Log files, commands, and autogenerated scripts are stored in the labeled directory within the “log_files” folder. Finally, final model details are stored in the labeled directory within the “models” folder.

In addition to running the training jobs locally, training can be run on a SLURM cluster using the slurm flag. In this way, large cross-validation jobs may leverage high-performance computing with minimal changes to the configuration. See additional configuration operations, such as slurm-host, using launch. py–t cross-validation–h.

## Section: Machine Learning Architectures and Applications › Applying Models to Independent Test Sets for Virtual High-Throughput Screening

Note that in the above examples the training and test splits are derived from the same binary format file. This is not strictly necessary, and the user can supply alternatively derived validation splits prepared in separate files. Moreover, using a dataset split as the independent test set is generally only useful for model validation. To apply trained model predictions to new molecules in a vHTS, either model:Test or molecule:Properties can be used. For example, if a model is trained and validated using five-fold cross-validation, then the merged prediction on an external test set can be made as follows with model:Test:

Likewise, predictions can be made with molecule:Properties using the Prediction operators:

Notice that scoring new compounds via molecule:Properties allows multiple outcome metrics to be reported and modified on-the-fly, while scoring with model:Test just outputs the raw prediction values (and optionally just the mean with average). In this case, the output of model:Test is equivalent to “predicted_activity” from molecule:Properties. The property “XActive” is the “predicted_activity” score when the local PPV is greater than 0.5, and 0.0 otherwise. The localPPV metric calibrates model output values to local classification probability on the test sets. It is an estimate of the PPV at a singular model output value. This is in contrast to traditional PPV, which specifies the value of a prediction at, or above, a given output value (assuming positive parity). This metric assumes that the trained model prediction value varies monotonically with the actual prediction likelihood.

## Section: Machine Learning Architectures and Applications › Supervised Learning

ROC curve comparison Kir2.1 activity prediction models with different descriptors. Models were trained with either (A,B) the Minimal dataset containing 959 non-redundant standard LB descriptors (see Supplemental Data) on a log10 (A) or linear (B) x-axis, or PCA-modified LB descriptors accounting for 95% variance on a log10 (C) or linear (D) x-axis.

Result value overlap between the Full and Dense datasets. Density normalized histograms of LogP, LogS, and ΔGhydration between the Full (35874 total, 35113 LogP, 20721 LogS, 1,339 ΔGhydration; gray) and Dense (448 total for all values; green) datasets.

Five-fold cross validation results for multitask modeling of solubility prediction. These table values are automatically calculated and output in the log_merge.txt file in the corresponding subdirectory of the autogenerated “log_files” directory. The Full set consisted of 35,874 molecules (with 35113 LogP, 20721 LogS, and 1,339 ΔGhydration result labels). The Dense set consisted of 448 molecules (with 448 LogP, 448 LogS, and 448 ΔGhydration result labels). The Full–Dense set contained 35,428 molecules (with 34665 LogP, 20273 LogS, and 891 ΔGhydration result labels).

QSPR external test-set predictions. Results of predicting QSPR properties on the Dense dataset with the model trained on the Full–Dense feature set, and results of predicting QSPR properties on the Full–Dense dataset with the model trained on the Dense feature set. The table is organized such that the values indicate the performance of the model trained with the indicated set of descriptors on the alternate test set. The Dense set consisted of 448 molecules (with 448 LogP, 448 LogS, and 448 ΔGhydration result labels). The Full–Dense set contained 35,428 molecules (with 34665 LogP, 20273 LogS, and 891 ΔGhydration result labels).

## Section: Machine Learning Architectures and Applications › Supervised Learning › Training a Standard Artificial Neural Network to Classify Kir2.1 Positive Allosteric Modulators

ANNs are one of the most commonly employed classes of non-linear classifiers in QSAR modeling for LB-CADD due to their strong predictive power (Dahl, 2014; Xu et al., 2017; Vamathevan et al., 2019). To see all the options available to a neural network in the BCL, call

The BCL supports shallow and deep single- and multi-tasking neural networks. Transfer functions include linear, sigmoid, rectified linear, and leaky rectified linear. For a network with L hidden layers indexed l∈(1…L) , forward propagation for l∈(0…L−1) can be described as

where yl is the output vector at layer l connected to the input vector z(l+1) at layer l+1 by weights w and biases b , and f is the transfer function applied to each set of inputs into the l+1 layer. Correspondingly, the activation of a single neuron i in hidden layer l+1 can be represented as

to yield the output yi(l+1) from layer l+1. We have found that for classical QSAR tasks a simple mean-squared error (MSE) cost function is adequate.

Historically, overtraining in ANNs has been prevented by early termination of training when the monitoring dataset improvement rate or improvement scores fail to progress beyond a pre-determined extent. More recently, we have demonstrated that dropout is a better alternative to prevent model overtraining in QSAR tasks (Mendenhall and Meiler, 2016). The dropout approach has been described elsewhere in detail (Nitish et al., 2014). Briefly, during forward propagation each layer of the ANN is assigned a probability p according to which the output value yil of each i neuron in the layer l will be independently set to zero (i.e., “dropped”).

Here, rl is a vector with the same dimensions as yl whose values are either 0 (at fraction p) or 1 (at fraction 1—p) and multiplied elementwise by the values in yl . At the end of every training batch, rl is shuffled. If neurons are dropped with a probability p, then at test time the corresponding weights are scaled down by the factor 1—p.

Train a shallow (single hidden layer) neural network to classify molecules as either active or inactive PAMs of Kir2.1 beginning with the randomized dataset we generated in Section 6.2:

The configuration file specifies the learning method as follows:

Note that we are asking for an ANN with one hidden layer composed of 32 neurons. The input and hidden layers will have 5 and 25% dropout, respectively. In addition, we have enabled class balancing. We have far fewer active (172) than inactive (301,321) compounds. Balancing oversamples the underrepresented (minor) class to achieve a ratio of (in this case) 0.10 with the most common class (major). The balance max repeats flag can also be set to specify the maximum number of times that a feature can be repeated. This does not lead to overtraining because of dropout. Batch size is controlled with the steps per update flag. The objective-function variable is defined in the configuration file as

Additional variables, such as the maximum number of training iterations (20), number of rounds of cross-validation (5), monitoring dataset (independent set), etc. are also set in the configuration file.

As a comparison, train an additional ANN with the same parameters using the feature set whose dimensions were reduced with PCA in Section 6.2:

The “launch.py” pipeline automatically generates a ROC curve for each model with and without a log scaled x-axis (Figure 7). The overall AUC is quite similar between the two methods (Figures 7B,D); however, the model trained with the PCA descriptors has worse early enrichment (logAUC = 0.39) than the model trained with the full descriptors (logAUC = 0.46) (Figures 7A,C).

ROC curve comparison Kir2.1 activity prediction models with different descriptors. Models were trained with either (A,B) the Minimal dataset containing 959 non-redundant standard LB descriptors (see Supplemental Data) on a log10 (A) or linear (B) x-axis, or PCA-modified LB descriptors accounting for 95% variance on a log10 (C) or linear (D) x-axis.

## Section: Machine Learning Architectures and Applications › Supervised Learning › Training a Deep, Multitasking Neural Network to Predict Solubility

Predicting physicochemical properties such as solubility is a challenging but critical component of lead compound optimization. Many substitutions to a candidate molecule may increase the potency or selectivity, but at the cost of worsening solubility, metabolic stability, or other properties. Therefore, it is advantageous to prioritize synthesis and evaluation of derivatives that are simultaneously predicted to be active and have a promising chemical profile. To do this, we need a target-agnostic QSPR model.

Dahl and colleagues demonstrated that multitask learning could improve the prediction of multiple outputs simultaneously if the training tasks are correlated (Dahl, 2014; Xu et al., 2017). As an example of how such a model is trained with the BCL, we will train a deep neural network to simultaneously predict three measures relating to solubility: the water-octanol partition coefficient (logP), the aqueous solubility (logS), and the hydration free energy (i.e., the solvation free energy in water; ΔGhydration). Note that not the descriptors, model architecture, nor hyper-parameters have been optimized for performance. This can be seen as an “out of the box” model a user might create.

Molecules for training and validation are sourced from previously published databases (Syracuse Research Corporation, 1994; Edward W.; Lowe et al., 2011; Mobley and Guthrie, 2014; Wu et al., 2018) and combined with BCL molecule:Unique to remove redundant compounds (see Supplementary Methods for details). Note that we anticipate some additional error in predictions introduced by not averaging replicate experimental measurements of QSPR properties prior to removing redundancy. Generate three datasets: One with all of the unique compounds (Full), another that contains only those compounds with all three result labels (Dense), and one that contains all of the compounds minus those with all three result labels (Full–Dense). The following command generates the feature set for all of the compounds with three result labels encoded by MDL property labels:

To generate the Dense feature set, add the–forbid_incomplete_records flag. The two binary format files should contain 35,874 and 448 rows, respectively, and the third dataset should contain the difference between them, 35,426. The distribution of result values overlaps reasonably well between the Full and Dense datasets, with the exception of the LogS distributions (Figure 8).

Randomize the datasets before training the model. The configuration file config. exmple.mdnn.ini sets up the neural network architecture:

Note that our network contains 2 hidden layers with 128 and 32 neurons, respectively, with 5% dropout on the input layer, 25% dropout on the first hidden layer, and 5% dropout on the second hidden layer. Our objective function will be MAE_NMAD since this is a regression task. We will perform five-fold cross validation (specified in the configuration file). Train the network:

The just-submit flag sends the process to the background. Train the dense network as well; it should take less time since there are relatively few examples in the training sets. Check the log_merge.txt file in the corresponding “log_files” subdirectory to view the final objective function for each of the three result labels (Table 5).

In cases where the training set has small deviation from the mean value, MAE will be lower, which can be misleading. To address this, we normalize MAE by MAD. Here, we see that the model trained on the Dense set of features learned LogP the best. However, this may be an artifact of the reduced training space. If we were to evaluate whether the Dense model was able to extrapolate beyond the very small training set, we would almost certainly see worse performance.

To illustrate this, evaluate the predictive power of our Dense model on molecules in our Full–Dense training set, and vice versa. This can be accomplished using either model:Test or molecule:Properties as described in Section 7.1. The results of this analysis are in Table 6. The model trained on the Full–Dense set does a good job predicting the QSPR properties for the Dense molecule set, achieving Pearson correlation coefficients between 0.82 and 0.99 for the three tasks. We see that the values we obtained in the internal random-split 5-fold cross validation (Table 5) agree with those obtained on the Dense set predictions (Table 6). In contrast, despite having the best five-fold cross-validation performance (Table 5), the model trained on the Dense feature set performs extremely poorly at predicting quantitative QSPR properties of the Full–Dense molecule set (Table 6).

Taken together, these data suggest that there is likely a significant fraction of molecules in the Full–Dense set that occupy an area of feature space not represented in the 448 molecule Dense set. This is a good example that internal randomized cross-validation on a small training set is not an accurate predictor of external test set performance unless the external test set is within a similar domain of applicability (Tetko et al., 2008; Sheridan, 2012). Applicability domains in the BCL will be discussed in more detail in Section 7.5.

Result value overlap between the Full and Dense datasets. Density normalized histograms of LogP, LogS, and ΔGhydration between the Full (35874 total, 35113 LogP, 20721 LogS, 1,339 ΔGhydration; gray) and Dense (448 total for all values; green) datasets.

Five-fold cross validation results for multitask modeling of solubility prediction. These table values are automatically calculated and output in the log_merge.txt file in the corresponding subdirectory of the autogenerated “log_files” directory. The Full set consisted of 35,874 molecules (with 35113 LogP, 20721 LogS, and 1,339 ΔGhydration result labels). The Dense set consisted of 448 molecules (with 448 LogP, 448 LogS, and 448 ΔGhydration result labels). The Full–Dense set contained 35,428 molecules (with 34665 LogP, 20273 LogS, and 891 ΔGhydration result labels).

QSPR external test-set predictions. Results of predicting QSPR properties on the Dense dataset with the model trained on the Full–Dense feature set, and results of predicting QSPR properties on the Full–Dense dataset with the model trained on the Dense feature set. The table is organized such that the values indicate the performance of the model trained with the indicated set of descriptors on the alternate test set. The Dense set consisted of 448 molecules (with 448 LogP, 448 LogS, and 448 ΔGhydration result labels). The Full–Dense set contained 35,428 molecules (with 34665 LogP, 20273 LogS, and 891 ΔGhydration result labels).

## Section: Machine Learning Architectures and Applications › Supervised Learning › Training a Decision Tree

DT is a tree-based machine learning algorithm that partitions the dataset into smaller subsets as it develops. A DT starts from a root node, branches out to internal nodes, and ends at leaf nodes. To see the different options of a decision tree, call

The default option of the decision method chooses the features for data splitting with the maximum information gain, and its prediction performance is scored by accuracy.

There are two factors that determine the order of features and their corresponding splitting values in dataset partitioning in a decision tree: partitioners and node scores. Four types of partitioners are currently implemented in the BCL: InformationGain, Gini, ROC, and Sequence. The first three options rate the feature to split the dataset by information gain, Gini index, and area under the curve of the local ROC curves (Ferri et al., 2002), respectively. The last option only allows splits that result in at least one pure node.

While the partitioner determines how to calculate the split rating of different configurations of dataset partition, the node score type dictates how to rank different combinations of feature order and their corresponding splitting values. Four types of node scores are currently implemented in the BCL: split rating (SplitRating), number of correct predictions before splitting (InitialNumIncorrect), split rating times initial number of correct predictions (RatingTimesInitialNumIncorrect), and sum of number of incorrect predictions before and after data splitting (InitialIncorrectPlusFinalCorrect). The users can also control the minimum number of incorrect classifications of a node by assigning a value to the min split flag.

A DT was employed in Section 3.4 to classify small molecules’ potential for hit optimization. The BCL can convert DTs into descriptor files that can be used to help defined new properties. For more details, see Section 3.4.

## Section: Machine Learning Architectures and Applications › Unsupervised Learning

Applicability domain models differentiate molecular structures targeting unique proteins. Each box plot represents AD scores of five drugs that target either kinases or opioid receptors. AD models trained on kinase and opioid training datasets are colored in red (legend: kinaseAD) and blue (legend: opioidAD), respectively.

## Section: Machine Learning Architectures and Applications › Unsupervised Learning › Adjusting Tunable Parameters in a Self-Organizing Map

A self-organizing map (SOM), also commonly referred to as a Kohonen map, is an unsupervised learning method that is commonly used in clustering and dimensionality reduction. The SOM produces a low-dimensional (typically one to two dimensions), discretized representation of the input space of the training samples, called a map. This method applies competitive learning to reach a solution, as opposed to conventional feed-forward neural networks, which utilize error-correction learning. To see the options available to a Kohonen map model, call

Here is the typical configuration file setup to build a Kohonen map model:

Before training a Kohonen map, users may shuffle the training set (shuffle = True). Similar to the ANNs, there are two options for scaling the input: AveStd and MinMax. The former works best when the input descriptors are continuous, and the latter is ideal for sparse and/or discretized input data. Regarding the configuration of the SOM, the map dimensions option dictates the number of nodes, or neurons, in each direction of the map. Setting the steps per update flag (i.e., batch size) to 0 indicates that all training rows will be used for each iteration.

The initial radius of the neighborhood function, radius, is the maximum distance between the neighbor neuron and the best matching unit (BMU). Increasing the radius generally increases model quality at the expense of training time. In our experience, diminishing returns are met when the radius approaches 1/3 to 1/2 the total distance of the map. The number of iterations it takes for the radius to decrease to 0 in the given neighbor kernel function is given by length. The radius of the neighborhood is gradually reduced as the number of the iterations t increases, such that by 4∗length the original radius is reduced to size 0:

Each iteration, the neurons compete by measuring their distances to the input dataset. The neuron j, with associated weight vector w, with the lowest distance d to the randomly selected input vector x is the winner.

Iterations proceed for the entire batch size prior to updating neuron weights. The next step is updating the weights within the neighborhood of the winning node. There are two options for the neighbor kernel function: Bubble and Gaussian. The new weights are updated as

where the β is 0.8 for the wining node and 0.2 for other nodes in the neighborhood and learning rate α is exp(−(distance to winner)22×radius2) for the Gaussian kernel and 1 for the Bubble kernel. The Bubble kernel keeps the learning rate constant inside the neighborhood, while the Gaussian kernel reduces the learning rates for more distant nodes, at a substantial performance cost.

Finally, users can select one of the objective functions mentioned above to evaluate the prediction performance of the model. At test time, the model will assign an AD score for each external compound. This AD score is the normalized distance of that compound to the closest node of the training set. For instance, a tested molecule with an AD score of 0.90 is further from the closest node than 90% of other molecules in the training set. In other words, that molecule’s feature space was not so well-represented in the training dataset.

## Section: Machine Learning Architectures and Applications › Unsupervised Learning › Training a Self-Organizing Map Druglikeness Applicability Domain

We will use the BCL to build class-specific druglikeness applicability domain (AD) models from the structures of FDA approved drugs: 58 opioid receptor modulators and 82 kinase inhibitors (Wishart et al., 2018). From each set of molecules, 5 molecules are randomly removed from the training set for external validation. Training occurs on the remaining molecules. The AD models will be used to measure the similarity between external compounds and a “typical drug” targeting opioid receptors or kinases. Generate a configuration file for the AD called AD. config containing the following:

Note that the map dimensions are set by the cluster_num flag in the training command. Generate feature set for each molecule file using descriptor:GenerateDataset. Train the kinase set AD model:

Afterward, train the opioid receptor set AD model. Next, we can evaluate the test sets with each AD model, beginning with the kinase inhibitor test set with the kinase inhibitor AD model:

The AD scores are listed in the output data file. The first two lines are the format name, and the dimension of the data table. The AD scores of five test compounds are stored in the second columns of the last 5 lines. We can see that our test set compounds from the FDA approved kinase inhibitor list have a shorter AD distance than our molecules in the opioid receptor test set, and vice versa (Figure 9). These scores represent the distance of each test compound to the feature space occupied by the training set FDA approved kinase inhibitors. In other words, they tell us how far we are from drug-like feature space for this group of inhibitors. The output AD scores are summarized in Figure 9.

Applicability domain models differentiate molecular structures targeting unique proteins. Each box plot represents AD scores of five drugs that target either kinases or opioid receptors. AD models trained on kinase and opioid training datasets are colored in red (legend: kinaseAD) and blue (legend: opioidAD), respectively.

## Section: Drug Design

Up to this point we have demonstrated vHTS predictions on pre-existing external datasets. Screening external datasets can be very valuable because of the ever-increasing number and availability of public, commercial, and institutional small molecule repositories. Nevertheless, it is also frequently the case that computation can be applied to assist specific medicinal chemistry projects. For example, in silico drug design can conceivably be utilized for library design, hit explosion, or scaffold hopping. Here, we will demonstrate how to perform multicomponent reaction (MCR)-based drug design with the BCL.

Multicomponent reaction-based design of dopamine receptor D4 antagonist candidates. (A) The 4-component split-Ugi reaction utilizing a piperazine as the diamine. Hydrogen atoms are represented implicitly. Atom numbers correspond to mappings between reactant and product atoms. The density of molecules generated with respect to (B) the predicted activity local PPV for each classification result label, (C) number of hydrogen bond donors, hydrogen bond acceptors, or rotatable bonds, (D) topological polar surface area, and (E) the computed logP. LogP estimates are computed using the Full neural network from Section 7.4 (XLogP; gray), the property-based cLogP approach from Xing and Glen, 2002 (Xing and Glen, 2002), and the atom-based cLogP approach from Mannhold et al., 2008 (Mannhold and Van de Waterbeemd, 2001). (F) Density of generated molecules with respect to synthetic accessibility score (x-axis) and predicted dopamine receptor D4 antagonist activity (local PPV for 100 nM classification; y-axis). The 2D histogram density is log10-scaled. (G) Structural representation of six randomly selected molecules from a sample of 198 designs that had local PPV values greater than or equal to 0.80 for predicted activity at 100 nM.

## Section: Drug Design › Defining Reaction Files for Drug Design

Reaction-based drug design in the BCL proceeds according to user-defined MDL RXN (.rxn) files. There are a number of predefined reactions located in bcl/rotamer_library/functional_reactions. Reactions can be single-component intramolecular reactions, or multi-component intermolecular reactions of up to four unique reagents. Reactants must have their atoms mapped to corresponding atoms in the product(s). Atom mapping is required for substituents on the input reagents to be merged with the product(s).

The reaction design framework functions in part by performing substructure comparisons of candidate reagents to reactant structures drawn in the RXN file. Substructure matching occurs at a resolution of ElementType for atoms and BondOrderOrAromatic for bonds. If there are candidate reagents that collectively can match all reactant positions in a reaction, then the reaction can proceed. Note that unlike input SDFs for molecule files, aromaticity must be shown explicitly in the RXN file to be interpreted. Also note that reactant matching will only match hydrogen atoms if they are drawn explicitly.

## Section: Drug Design › Executing Reaction Design

In this example, we will generate products according to a 4-component split-Ugi reaction utilizing piperazine as the diamine scaffold in all designs (Figure 10A).

The individual molecule fragments passed via starting_fragments are treated as required reaction components. The reactions flag is given the path to a directory containing all RXN files the user wishes to include in the reaction. The reagents flag specifies candidate reactants with which the starting_fragments molecules are reacted. Thus, for every entry in the SDF passed via starting_fragments, the molecule: React application will check to see if it is a valid reactant for any of the reactions in the directory specified by reactions; for those reactions that the current starting_fragments molecule is a valid reactant, the remaining possible reactant positions are fit against the molecule fragments provided via reagents.

The routine flag specifies how to continue with reaction sampling. Currently, there are two options, though additional options are under development. The default is Random, which will perform one valid reaction (if any exist) for each molecule in starting_fragments using a randomly selected reaction and reagents from the user input. By default, the Random routine will run one time; however, by specifying repeats users can increase the number of cycles. If the starting_fragments SDF contains 100 entries and repeats is set to 4, then the molecule:React application will run 500 times–one initial run for all entries followed by four repeats of all 100 entries. Alternatively, users may specify Exhaustive, which will enumerate all possible products from all given reactions and reagents for each starting_fragments molecule. Ongoing efforts to expand the reaction-based drug design framework include additional optimization routines, such as evolutionary fragment generation and simulated annealing, as well as mixed intra- and inter-reagent reactions. Other options are related to generation of 3D conformers for the product molecules and are explained in the help menu.

Multicomponent reaction-based design of dopamine receptor D4 antagonist candidates. (A) The 4-component split-Ugi reaction utilizing a piperazine as the diamine. Hydrogen atoms are represented implicitly. Atom numbers correspond to mappings between reactant and product atoms. The density of molecules generated with respect to (B) the predicted activity local PPV for each classification result label, (C) number of hydrogen bond donors, hydrogen bond acceptors, or rotatable bonds, (D) topological polar surface area, and (E) the computed logP. LogP estimates are computed using the Full neural network from Section 7.4 (XLogP; gray), the property-based cLogP approach from Xing and Glen, 2002 (Xing and Glen, 2002), and the atom-based cLogP approach from Mannhold et al., 2008 (Mannhold and Van de Waterbeemd, 2001). (F) Density of generated molecules with respect to synthetic accessibility score (x-axis) and predicted dopamine receptor D4 antagonist activity (local PPV for 100 nM classification; y-axis). The 2D histogram density is log10-scaled. (G) Structural representation of six randomly selected molecules from a sample of 198 designs that had local PPV values greater than or equal to 0.80 for predicted activity at 100 nM.

## Section: Drug Design › Analyzing Designs

For illustration purposes, we generated ∼700,000 configurationally unique molecules with the split-Ugi reaction (Figure 10A). As our starting fragment, we used a solitary piperazine ring. For simplicity and to keep the size of the product library reasonably small, we also utilized a formaldehyde in the second reactant position (though another aldehyde is possible). We passed a collection of commercially available building block fragments, filtered such that the heavy atom count was less than or equal to 20, to fill positions three and four via our reagents flag. We analyzed the resulting library without any additional filtering (e.g., for druglikeness, predicted mutagenicity, Lipinski’s rules, etc.).

Piperazine rings and related substructures are well-defined core components of dopamine receptor (DR) antagonists (Lindsley and Hopkins, 2017). Utilizing BCL commands described in previous sections along with publicly available PubChem Bioassays, we trained a single QSAR model to simultaneously predict dopamine receptor D4 (DRD4) antagonist activity at multiple thresholds (10, 100, 500, 1,000, and 5,000 nM). Subsequently, we employed this QSAR model to predict the DRD4 antagonist activity of our newly created library (Figure 10B).

As might be expected, there are a high density of molecules with a low (< 0.20) local PPV for activity at 10 nM; however, as the threshold for activity increases, the density of molecules that are identified as active increases (Figure 10B). We also quantified the number of HBDs, HBAs, and rotatable bonds in our molecules (Figure 10C). Most compounds have fewer than 5 HBD and 10 rotatable bonds. Approximately half of the dataset contains 10 or more HBA, which would contribute to Lipinski’s rules violations, though many FDA-approved molecules do not follow Lipinski rules strictly (DeGoey et al., 2018). Nevertheless, number of HBAs may be one criterion by which to filter out molecules from the library from further analysis.

We also estimated topological polar surface area (TPSA) (Figure 10D) and water-octanol partition coefficient (logP) (Figure 10E). More than half of the molecules have a TPSA less than 150 Å2. One could also filter out molecules from the library that have TPSA greater than 150 Å2 and/or greater than 10 rotatable bonds (Veber rules for druglikeness). We performed logP estimates with three unique methods: 1) the DNN we trained in Section 7.4.2; 2) a property-based metric from Xing and Glen, 2002 (Xing and Glen, 2002); and 3) an atom-based metric from Mannhold et al., 2008 (Mannhold and Van de Waterbeemd, 2001). Each of these metrics are available in the BCL as molecular properties and can be employed to characterize the solubility of candidate compound libraries.

Finally, we display predicted activity at 100 nM as a function of synthetic accessibility score (SAScore) (Ertl and Schuffenhauer, 2009) (Figure 10F). Encouragingly, the molecules predicted most likely to be active at 100 nM (local PPV ≥0.80) have SAScores below 2.0, well-within an acceptable range (Ertl and Schuffenhauer, 2009). Overall, the SAScores of the library are low, reflective of the reaction type and selected reagents (Figure 10F). We selected six random molecules with local PPV greater than 0.80 at the 100 nM activity cutoff for display (Figure 10G). These molecules are topologically similar to known antagonists of DRs, specifically DRD4; however, it is possible that this reaction produces a scaffold with an activity cliff (loss of protonation of the piperazine ring) (Berry et al., 2010; Lindsley and Hopkins, 2017).

## Section: Discussion

The BCL is an academic research project made available for public use. As an academic research project, the BCL is under continuous development. Ongoing improvements are anticipated for many of the applications described here, including small molecule conformer sampling, small molecule flexible alignment, descriptor/feature generation, and additional machine learning architectures (e.g., random forest, gradient boosting, and convolutional neural networks), strategies, and pre-generated models. In addition, several new tools are currently under active development for tasks such as library design, de novo drug design, pharmacophore mapping, and more.

This manuscript has focused extensively on LB in silico drug discovery tools; however, we have also begun incorporating SB tools, such as deep learning-based protein-ligand interaction scoring (Brown et al., 2021). Two primary goals moving forward are 1) continuing to increase the accessibility of the BCL to other scientists, and 2) integrating the BCL with other state-of-the-art software packages to allow for more complex protocol design. To accomplish these goals in tandem, we are completing scientific advances and software changes required to functionally integrate and compile the BCL in the Rosetta macromolecular modeling suite (Leman et al., 2020), enabling access to protocol development at the C++ (Rosetta applications), Python (PyRosetta), and XML (RosettaScripts) levels, in addition to the API described in this manuscript. We are also developing a graphical user interface (GUI) for the BCL LB drug discovery. The GUI will enable on-the-fly QSAR/QSPR calculations and druglikeness evaluation while the user is drawing molecules.

Our hope is that this manuscript will serve as a resource for those interested in utilizing the BCL for cheminformatics research. Several high level BCL applications can also be accessed via webserver for non-expert users. The webserver is available through the BCL Commons website at http://www.meilerlab.org/bclcommons. Example files mentioned throughout the manuscript are freely available on the Meiler Lab GitHub page.

The BCL can be downloaded freely from http://www.meilerlab.org/bclcommons and requires a supporting license from http://meilerlab.org/servers/bcl-academic-license that is free for academic and non-profit users, with commercial licenses available for a fee.

## Section: Data Availability Statement

The datasets presented in this study can be found in online repositories. The names of the repository/repositories and accession number(s) can be found below: https://github.com/Meilerlab.

## Section: Author Contributions

Original code conceptualization and code development: JMei Conceptualization (manuscript): BB, JMen, and JMei Code contributions: All authors Code review: All authors Manuscript writing: BB, OV.

## Section: Funding

Work in the JMei laboratory is supported through the NIH (R01 DA046138, R01 GM099842) and Deutsche Forschungsgemeinschaft (DFG, German Research Foundation, through SFB1423, project number 421152132). BB is supported through the NIH by a Ruth L. Kirschstein NRSA fellowship (F30DK118774). The content is solely the responsibility of the authors and does not necessarily represent the official views of the National Institutes of Health.

## Section: Conflict of Interest

The authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.

## Section: Publisher’s Note

All claims expressed in this article are solely those of the authors and do not necessarily represent those of their affiliated organizations, or those of the publisher, the editors, and the reviewers. Any product that may be evaluated in this article, or claim that may be made by its manufacturer, is not guaranteed or endorsed by the publisher.

## Section: Supplementary Material

The Supplementary Material for this article can be found online at: https://www.frontiersin.org/articles/10.3389/fphar.2022.833099/full#supplementary-material

Click here for additional data file.

Click here for additional data file.

Click here for additional data file.

Click here for additional data file.

## Section: Associated Data

Click here for additional data file.

Click here for additional data file.

Click here for additional data file.

Click here for additional data file.

## Section: Associated Data › Supplementary Materials

Click here for additional data file.

Click here for additional data file.

Click here for additional data file.

Click here for additional data file.

## Section: Associated Data › Data Availability Statement

The datasets presented in this study can be found in online repositories. The names of the repository/repositories and accession number(s) can be found below: https://github.com/Meilerlab.


---

# Investigating the Role of Obesity in Prostate Cancer and Identifying Biomarkers for Drug Discovery: Systems Biology and Deep Learning Approaches

- **Authors:** Shan-Ju Yeh, Yun-Chen Chung, Bor-Sen Chen
- **Issuer:** Molecules (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2022-01-28
- **Language:** en
- **DOI:** 10.3390/molecules27030900
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35164166/
- **Licence:** CC-BY

## Section: Abstract

Prostate cancer (PCa) is the second most frequently diagnosed cancer for men and is viewed as the fifth leading cause of death worldwide. The body mass index (BMI) is taken as a vital criterion to elucidate the association between obesity and PCa. In this study, systematic methods are employed to investigate how obesity influences the noncutaneous malignancies of PCa. By comparing the core signaling pathways of lean and obese patients with PCa, we are able to investigate the relationships between obesity and pathogenic mechanisms and identify significant biomarkers as drug targets for drug discovery. Regarding drug design specifications, we take drug–target interaction, drug regulation ability, and drug toxicity into account. One deep neural network (DNN)-based drug–target interaction (DTI) model is trained in advance for predicting drug candidates based on the identified biomarkers. In terms of the application of the DNN-based DTI model and the consideration of drug design specifications, we suggest two potential multiple-molecule drugs to prevent PCa (covering lean and obese PCa) and obesity-specific PCa, respectively. The proposed multiple-molecule drugs (apigenin, digoxin, and orlistat) not only help to prevent PCa, suppressing malignant metastasis, but also result in lower production of fatty acids and cholesterol, especially for obesity-specific PCa.

## Section: 1. Introduction

Over the past twelve years, the prevalence of obesity in populations has grown by up to 10.3%. This situation has been even more dramatic in the past five years, with growth of up to approximately 20% [1]. Although there are declining mortality rates from prostate cancer (PCa) in high-income countries, the cancer incidence and death rates are increasing due to excess body weight in developing countries [2]. Following the definition of overweight and obesity based on the investigation of the WHO, we find that abnormal or excessive fat accumulation may influence every aspect of human life. As well as increasing the risk of chronic diseases and cardiovascular diseases, obesity is also a decisive factor in causing a large number of cancer categories [3]. Especially for PCa, obesity has an impact on higher cancer incidence, mortality, and poor prognosis. Bearing in mind the association between obesity and PCa, we took the body mass index (BMI) into consideration as a critical criterion for distinguishing the formation of PCa from that of normal prostate cells [4]. Several studies have shown that a higher BMI is associated with a higher risk of lethal PCa, leading to higher mortality rates in the groups of middle-aged and older men [5,6,7]. Therefore, we explored several aspects of PCa, such as multifactorial aberrations of genetic, epigenetic, microenvironment, and biological signaling cascades, and also the obesity factor, for the purpose of preventing the occurrence of PCa.

According to the previous statistics on noncutaneous malignancies in men [8], PCa is the most common heterogeneous disease, and it presents a complex combination of the deregulation of the insulin growth factor (IGF) and genetic, epigenetic, and microenvironmental factors. One biological mechanism corresponding to obesity and PCa involves alterations in sex-hormone secretion and variation of adipokine signaling [9], which facilitate the progression of PCa on the basis of their interactions with IGF [10]. As the relationship between the level of insulin and the concentration of sex hormones has opposite interactive influence [11], we could propose a hypothesis that the development of poorly differentiated PCa is indirectly promoted to aggressive PCa via the driving force of obesity [12]. Moreover, it is reported that hyperinsulinemia, lowering testosterone and dihydrotestosterone levels, demonstrates a vital connection between obesity and the development of poorly differentiated PCa [11]. It is noted that patients suffering from invasive PCa have the characteristics of higher recurrence and poorer survival rate compared with normal PCa. Many studies have shown that the PCa aggressiveness is related to testosterone level [13,14,15,16], which could help in further investigating the mechanisms for the development of benign prostate hyperplasia (BPH) and PCa. In addition, participating in the interference with adjacent tumor cells, adipocytes are also affected by the PCa cells at the same time as stimulating migration [17,18]. From the above speculation, we could obtain a deep insight into several aspects of carcinogenic mechanisms including endocrine status alteration, intra-abdominal pressure ascension, insulin resistance, and adipokine secretion alteration, which favor the realization of the effects of inflammation on causing high-grade PCa [19]. As a result, based on the carcinogenic molecular mechanism analysis, we were able to identify significant biomarkers for systems drug design.

For analyzing the molecular mechanisms of prostate cancer and identifying essential biomarkers, we needed to fully compare four core genome-wide genetic and epigenetic networks (GWGENs) of normal prostate cells in in the lean group, normal prostate cells in the obese group, lean PCa cells, and obese PCa cells, respectively. Furthermore, a BMI of 25 is considered as the obesity threshold, used for splitting the data into two groups: one for lean people and the other for obese people. The flowchart of the systems biology approach for PCa shown in Figure 1 can be divided into five steps as follows: (1) the construction of a candidate GWGEN; (2) performing system identification and using the system order detection scheme to obtain real GWGENs of normal prostate cells (lean and obese groups), and lean and obese PCa cells, as shown in Figures S1–S4; (3) the extraction of core GWGENs for normal prostate cells (lean and obese groups), and lean and obese PCa cells, as shown in in Figures S5–S8 using the principal network projection (PNP) approach; (4) the comparison of core signaling pathways, as shown in Figures S9–S12, and the investigation of carcinogenic mechanisms for identifying significant biomarkers as drug targets for PCa (covering lean and obese) and obesity-specific PCa; and (5) multiple-molecule drug discovery via drug design specifications including drug–target interaction, drug regulation ability, and drug toxicity toward identified biomarkers. Consequently, we suggested two multiple-molecule drugs, one with apigenin and digoxin for PCa (covering lean and obese) and the other with apigenin, digoxin, and orlistat for obesity-specific PCa.

## Section: 2. Results › 2.1. Overview of Systems Biology Approaches and Drug Design Specification

For the purpose of understanding the effect of obesity on prostate cancer (PCa) comprehensively, we used a systems biology approach. The related flowchart is shown in Figure 1. Firstly, via big database mining, we constructed a candidate GWGEN. It consisted of a protein–protein interaction network (PPIN) and a gene regulatory network (GRN). We then performed system modeling for proteins, genes, miRNAs, and lncRNAs. In this study, we separated our microarray data into four groups: lean normal, obese normal, lean PCa, and obese PCa. With the help of the microarray data, we performed system identification and used the system order detection scheme to obtain real GWGENs for two groups of normal cells (lean and obese), lean PCa, and obese PCa. The overall statistics for nodes and edges for the candidate GWGEN and the real GWGENs are given in Table S1. Compared to the total number edges in the candidate GWGEN, it is noted that the total number of edges decreased considerably in real GWGENs, since the false positives were removed by the system order detection scheme. However, the real GWGENs (Figures S1–S4) were still too complex to analyze. Hence, the PNP method was used to extract their core GWGENs (Figures S5–S8) by choosing the top 3000 nodes based on their 2-norm projection values in the 85%-significant network energy structure, to narrow down the real GWGENs. In order to investigate carcinogenic mechanisms, the core signaling pathways were delineated with the annotation of the KEGG pathway. The core signaling pathways of the two groups of normal cells (lean and obese), lean PCa, and obese PCa are shown in Figures S9–S12. Their corresponding gene enrichment analysis results are shown in Tables S2–S5. After comparing the core signaling pathways of lean PCa in Figure S11 and normal prostate cells (lean) in Figure S9, we could investigate the carcinogenic mechanisms of lean PCa (Figure S13). In the same way, the carcinogenic mechanisms of obese PCa could be found (Figure S14) by comparing the core signaling pathways of obese PCa (Figure S12) and normal prostate cells (obese) in Figure S10. After summarizing, we could illustrate the common and specific core signaling pathways for lean and obese PCa (Figure 2). The common and obesity-specific biomarkers of PCa were then identified based on the carcinogenic mechanism analyses. Utilizing the database for annotation, visualization, and integrated discovery (DAVID), we performed a gene enrichment analysis in the core GWGEN for normal PCa in the lean group, normal PCa in the obese group, lean PCa, and obese PCa (Tables S2–S5, respectively). Moreover, the drug discovery targeting the identified biomarkers is based on the drug design specifications. It considers drug–target interaction, drug regulation ability, and drug toxicity. One DNN-based DTI model was constructed in advance for predicting the candidate drugs with higher interaction ability with identified biomarkers. The number of predicted candidate drugs decreased after passing through drug regulation ability and drug toxicity filters. Consequently, two multiple-molecule drugs were suggested for preventing PCa (covering lean and obese) and obesity-specific PCa, respectively. Details are discussed in the following sections.

## Section: 2. Results › 2.2. The Common Carcinogenic Molecular Mechanism between Lean and Obese PCa

The core signaling pathway, which is related to the immune response, is induced by receptor NOD1, gradually weakening immunity. Immune microenvironment factor IE-DAP is received by receptor NOD1, resulting in the phosphorylation of downstream molecules, which initiates chronic inflammation [20]. From the perspective of the carcinogenic mechanism for inhibiting immune response triggered by the activation of receptor NOD1 (see Figure 2), the sequential phosphorylation of proteins KLK4 [21] and COX2 are found. This gives the protein COX2 an intermediate role in PCa. Overexpression of protein COX2 could promote tumor progression, e.g., cell proliferation, angiogenesis, suppression of immune response, and enhanced metastasis [22]. Owing to the upstream phosphorylation, protein FOXB1 is activated with attenuated E-cadherin [23], which strengthens the overexpression of the downstream target gene NANOG in a metastasis-related pathway triggered by the receptor SORT1. Furthermore, we find that the immune response has a strong correlation with driving migration and invasion in obese PCa. Subsequently, the protein MYB is promoted, exhibiting a strong malignant phenotype. It indirectly causes cell cycle arrest in tumor cells. Once moving towards the worsening direction of cell proliferation, this aggressive feature not only plays a role of strong resistance in the treatment of drug resistance but also improves the motility of cancer cells, leading to EMT effects. Consequently, the mechanism of castration resistance, affected continuously by activation of the protein MYB, could enhance the invasive capability of both lean and obese PCa. In addition, the activation of the NOD1 receptor induced by IE-DAP could upregulate TF STAT1, acting as an active transcription factor to boost tumor metastasis in PCa and upregulate the target gene CD3G [24]. Eventually, under the overexpression of target gene CD3G, this indirectly results in the chronic inflammation of prostate tumors. Moreover, PCa cells could proliferate in the immunosuppressed microenvironment [25].

The most relevant pathway of cell proliferation is the invasive signaling pathway triggered by receptor FZD10, which is activated by ligand SS18–SSX2 in order to transduce the Wnt-11 signal [26]. In Figure 2, the microenvironment factor SS18–SSX2, related to the invasive signaling pathway, is received by receptor FZD10. It could upregulate TF SNW1 by signaling transduction proteins RBM25 and MYB, and by the activation of TF ESF1. Its target gene TMPRSS2 is upregulated, giving rise to cell proliferation, differentiation, angiogenesis, and indirectly causing an excessive inflammatory response. Consequently, the overexpression of target gene TMPRSS2 plays an important role in promoting the progression of metastatic prostate cancer. On the other hand, ATF2 protein is activated through the same signaling transduction proteins RBM25 and MYB to inhibit TF RBMX. Moreover, with the low expression of TF RBMX, it could upregulate miRNA MIR222 for the purpose of downregulating the downstream target genes DIRAS3 and DCTN6, enhancing cancer cell proliferation, cell survival rate, and inducing invasion. The inhibition of protein RBM25 is also influenced by the strongest induction effect from both the upstream signal and the downregulation of upstream TP53 suppressor in another invasive signaling pathway, for the purpose of activating protein MYB [27]. Then, the activity of protein MYB demonstrates a strong malignant phenotype in prostate tumors [28]. Most important of all, it could trigger the progression of PCa cell proliferation. Furthermore, TF ESF1 could not only upregulate target gene TMPRSS2, known as the fusion gene, via the upregulation of TF SNW1 but also specifically upregulate miRNA MIR193A in the signaling pathway of lean PCa (see Figure 2). The overexpression of TF SNW1 participates in androgen receptor splicing and transcription control, and is regarded as a co-activator of nuclear receptors [29]. Finally, influenced by the above effects, the target gene TMPRSS2, expressing a type of transmembrane protein, is overexpressed, resulting in the carcinogenic mechanism. This specific androgen response gene TMPRSS2 not only contributes to cell proliferation, differentiation, angiogenesis, inflammation, and anti-apoptotic effects but also dysregulates the body’s immune response, which enhances the late invasive ability of PCa [30]. Therefore, considering the phenomenon mentioned above, it is speculated that TMPRSS2 is a common target gene for PCa treatment. On the other hand, owing to the fact that TF RBMX, a kind of tumor suppressor, loses its function, its low expression is related to a high fructose diet and the synthesis of cholesterol [31]. Subsequently, MIR222 is upregulated through the inhibition of TF RBMX and increases the possibility of PCa recurrence, proving that MIR222 plays a significant role in obese prostate tissue [32]. Furthermore, the upregulated MIR222 induces fat formation, having a positive correlation with BMI value. Therefore, it is referred to as a key indicator for the impact of obesity on the progression of advanced PCa. Eventually, low expression of target genes DCTN6 and DIRAS3 enhance cancer cell proliferation and cell survival rate, and accelerate cancer cell invasion [32]. Overall, the upregulation of MIR222 could not only inhibit the expression of tumor suppressors such as target genes DIRAS3 and DCTN6 in prostate cancer but also prove that obesity has a strong correlation with cancer metastasis.

The most relevant pathway for EMT and metastasis is driven by the metabolic signaling pathway stimulated by receptor GALR2, as shown in Figure 2. In the obese prostate tumor, when receptor GALR2 receives a high concentration of galanin ligand, the galanin activates receptor GALR2 to increase human food intake and indirectly promote fat intake [33]. Furthermore, galanin is capable of regulating the related nerve conduction; a high concentration could trigger the absorption of fat. Through signaling transduction proteins ENPP5 and AMMECR1, transmitted into the nucleus, the signal not only suppresses miRNA MIR130B but also promotes miRNA MIR217, leading to the low expression of target gene FOXF2 [34]. FOXF2, known as a tumor suppressor, is downregulated in the epithelial mesenchyme to destroy the differentiation effect. Moreover, the mesenchymal transcription factor FOXF2 could make EMT more vigorous. On the other hand, TF SIM2 is upregulated through sequentially regulated proteins for the purpose of enhancing the invasive ability of PCa [35]. Finally, the upregulation of target gene FOXM1 resulting from overexpression of TF SIM2 cooperates with target gene FOXF2 to accelerate the process of cell proliferation and strengthen EMT [36]. In addition, influenced by the activation of receptor GALR2, TF MYOCD is upregulated after the signal is transmitted into the nucleus, which causes the development and differentiation of smooth muscle, indirectly promoting the migration of cancer cells [37]. Finally, target gene FOXF2 is inhibited through the overexpression of miRNA MIR182, also due to the activation of TF MYOCD [38].

The common pathway of metabolism is induced by receptor TMEM123, a kind of transmembrane protein. When receiving the protein-complex ligand, as shown in Figure 2, the highly glycosylated TMEM123 receptor could not only lose the capability of triggering tumor cell apoptosis but also activate downstream protein SYMPK [39,40]. In addition to influencing the downstream lipid metabolism, this signaling transmission induced by protein SYMPK could suppress protein SAMD2, in order to make the apoptotic mechanism abnormal after entering the nucleus. Moreover, the repression of protein SMAD2 could lead to malignant transformation of tumors owing to abnormal expression of genes related to cancer cell apoptosis [41]. Then, as a crucial tumor suppression factor of PCa epithelium, protein SMAD2 is inhibited, resulting in TF ESF1 upregulation and oxidatively induced DNA damage. As a result of the overexpression of TF ESF1, miRNA MIR133A1 is downregulated to upregulate the target gene EGFR, responsible for cell proliferation, local recurrence, and distant-organ metastasis in prostate tumors [34].

In summary, according to our investigation of carcinogenic mechanisms, PCa suffers not only from the suppression of apoptosis, immune response, and metabolism but also from the stimulation of proliferation, EMT, and metastasis. Furthermore, in the common signaling pathway shown in Figure 2, the phosphorylated protein COX2 plays the role of mediator, and can accept the activation response of phosphorylation of CERK from the metabolic signaling pathway. It is indicated that the metabolic response is closely related to the secretion of chemokines and cytokines in the immune response, further influencing the migration ability of tumor cells. That is, the overall enhancement of ability in cell proliferation, angiogenesis, and anti-apoptosis proves that COX2 is a key driving gene. Therefore, overexpression of target gene CD3G could inhibit the immune response and gradually destroy the immune system in the human body via chronic inflammation, building a bridge between immune response and metabolism. This phenomenon explains how, in the incubation period of tumors in the early stage of PCa, tumors can resist the immune system of the host. Consequently, we took FOXF2, EGFR, MYB, SIM2, STAT1, and SMAD2 as biomarkers. We aimed to restore them to their normal expression levels via drug discovery and design. Generally, FOXF2 and EGFR are associated with proliferation and anti-apoptosis in cancer, showing that the FOXF2 gene plays a critical role in tumor suppression. MYB not only reduces the motility of cancer cells but also slows down the secretion of cytokines and chemokines by cancer cells, showing a strong malignant phenotype in prostate tumors. The upregulation of TF SIM2 stimulates the activity of downstream oncogene FOXM1 to construct an appropriate microenvironment for cancer cell metastasis through the secretion of exosomes from the malfunction of metabolism. The unphosphorylated state of TF STAT1 enduring upregulation is responsible for the promotion of cancer growth and metastasis, and the deterioration of the immune response, leading to drug resistance and forcing cancer cells to invade and migrate to other organs in advanced PCa. The inhibition of SMAD2 protein in the highly glycosylated signaling pathway stimulated by receptor TMEM123 can regulate the anti-apoptosis ability of cancer cells.

## Section: 2. Results › 2.3. The Specific Molecular Mechanism in Lean PCa

In the specific core signaling pathway of apoptosis in Figure 2, with high concentration of growth hormone (GH) in the microenvironment of lean PCa, receptor GHR receives GH ligands to repress the downstream AKT signaling pathway, stimulating GHR itself. Due to the high concentration of GH in lean PCa cells, it will regulate somatic cell growth and substrate metabolism, preventing the cancer cells from being prone to local autocrine and paracrine effects [42]. Additionally, it will also inhibit the capability of interacting with androgens or growth factors, leading to the downstream suppression of proliferation and the promotion of apoptosis in tumors. Then, through the signaling transmission of cascade proteins DNAH14 and CPSF4, it could enter the nucleus to downregulate TF MED17, resulting in an androgen-dependent reduction of cancer cells [43]. Inhibited by TF MED17, target gene DNMT1 undergoes a DNA demethylation reaction, not only weakening its carcinogenicity but also contributing to a gradual slowdown of the cell proliferation rate and a promotion of apoptosis, which plays a crucial role prior to tumor cell metastasis [44].

In another specific core signaling pathway related to the immune response (see Figure 2), the ligand WNT5A in the lean PCa microenvironment is relevant to the signal transduction of lipid modification and the glycoprotein. Moreover, WNT5A plays a different kind of role in normal cells (lean) and lean PCa, depending on its concentration. When receptor ROR2 binds to a small amount of WNT5A, it could slow down the secretion of cytokines and chemokines from cancer cells [45], regulating the mutated LRSAM1. Influenced by the secreted signal of lipid-modified glycoprotein, the dysregulation of protein LRSAM1 could inhibit downstream protein MYB, indirectly reducing the motility of cancer cells. Furthermore, the inhibition of protein HOXB13 downregulates TF ESF1, to stabilize the ability to repair oxidatively induced DNA damage [46]. It is noted that miRNA MIRLET7A1 is upregulated to inhibit the expression of target gene IGF1R [47]. Once target gene IGF1R is downregulated, it could trigger the metabolism for the purpose of accelerating cancer cell apoptosis and inhibiting cancer cell proliferation. At the same time, the inhibition of target gene EZH2 plays a role as a cell cycle regulator, inhibiting cancer cell proliferation [34]. Therefore, we infer that this immune-like signaling pathway plays a significant role in inducing downstream metabolism.

## Section: 2. Results › 2.4. The Specific Carcinogenic Molecular Mechanism in Obese PCa

In one specific core signaling pathway related to metabolism shown in Figure 2, receptor OSBPL2 combines with sterols and a microenvironment factor PI4P to regulate cell proliferation signals [48]. Obesity will trigger PI4P ligands to inhibit the expression of receptor OSBPL2, resulting in the accumulation of fat and cholesterol in the downstream signaling pathway. Then, the activation of protein VCAM1 induced by receptor OSBPL2 could result in PCa easily acquiring aggressive characteristics. In other words, distant metastasis is more likely to occur [49]. It is speculated that obesity is a critical factor in the advanced malignant phenotype of PCa. Subsequently, protein CERK is phosphorylated to induce the synthesis of ceramide, including the main components of lipids, cholesterol, and fatty acids, which form a lipid bilayer structure [50]. The activation of conduction factor CERK indirectly triggers dysregulation of the immune response, cancer cell proliferation, and metastasis by upregulating TF MYBL2 to overexpress. When enhancing the adhesion ability of the extracellular matrix (including laminin, collagen, and fibronectin), TF MYBL2 is upregulated to promote the activity of epithelial–mesenchymal transition (EMT), enabling tumor cells to acquire the characteristics of migration and invasion [51]. As a result of the decreased expression of cadherin E, TF MYBL2 upregulates target gene IRS2 to be phosphorylated and overexpressed, which stimulates IRS2 to interact with membrane insulin tyrosine kinase receptors resulting in activating the downstream Ras/mitogen-activated protein kinase (MAPK) pathway [52]. Consequently, the overexpression of target gene IRS2 may disrupt the secretion of insulin, promote cell growth, and repress the normal metabolism of the human body.

In the specific core signaling pathway concerning immune response shown in Figure 2, receptor TLR4 generally stimulates its own anti-tumor immune signaling pathway without binding the IL1B ligand, triggering immune surveillance in the tumor microenvironment with the mechanism of allowing macrophages to play a pro-apoptotic role [53]. Then, it could promote DNA hypomethylation of protein TOLLIP, negatively stimulating its expression. Nevertheless, there is an opposite effect in the same signaling pathway in obese PCa, as shown in Figure 2. The anti-tumor immune signaling pathway is inhibited when receptor TLR4 is bound by the IL1B ligand in the microenvironment. Furthermore, because of the negative correlation between expression of the protein TOLLIP and DNA methylation, sex steroid hormones could stimulate an inflammatory response by the inhibition of the protein TOLLIP [54], that is, the hypermethylation of these hormones activates the expression of proinflammatory cytokines, which gives rise to downstream phosphorylation of protein STAT3 [55] (see Figure 2). Subsequently, TF MYC is overexpressed through high expression of protein STAT3. As well as driving the formation of prostate intraepithelial neoplasia [56], overexpression of TF MYC could further suppress target gene HSH2D. Since target gene HSH2D plays an important role in T cell activation, its low expression could reduce the activity of anti-tumor T cells [57]. It is speculated that this immune-like pathway occurs particularly in obese patients of PCa, and the metabolism-related pathway induced by receptor OSBPL2 plays a significant role in interacting with it.

In the specific core signaling pathway concerning metastasis shown in Figure 2, once the microenvironment factor PCSK9 binds to receptor SORT1 to drive itself to be activated [58], it could not only stimulate protein CERK, making it phosphorylated, but also induce downstream mutation of protein TP53. Through the activation of protein CERK, it could stimulate the neurotensin signal to produce excessive fatty acid, resulting in obesity. Therefore, it is proved that this invasive signaling pathway indirectly leads to an accumulation of excess fatty acids and the production of cholesterol, making obese PCa capable of malignant metastasis. Then, when protein TP53 is mutated and further suppressed to a low-expression state, it could play an indispensable role in EMT before activating metastasis procedures [27]. It is reported that this suppressive gene is particularly common in advanced PCa. Subsequently, the inhibition of protein TP53 could promote protein OSR2 for the purpose of strengthening the ability for castration resistance and increasing the treatment difficulty of androgen deprivation [59]. After protein OSR2 is activated, it could trigger downstream TF NKX2-5 to be highly methylated and overexpressed, resulting in a methylation frequency higher than the mutation rate [33]. Apart from being a characteristic of advanced PCa, methylation of NKX2-5 upregulates target gene NANOG to influence the regulatory function of androgen receptors, disrupting the secretion system [60]. Finally, the overexpression of target gene NANOG is a significant indicator of castration-resistant prostate, contributing to cell proliferation, cancer cell regeneration, induction of the shortened cell cycle, severe invasiveness, and cancer metastasis. Additionally, the metastasis-related signaling pathway induced by receptor FZD10 is enhanced by the mutation of upstream protein TP53 and the capability for tumor metastasis is strengthened through the signaling pathway of chronic inflammation triggered by receptor NOD1.

To summarize, according to the cooperative reaction of two pathways induced by activation of receptors SORT1 and OSBPL2 (see Figure 2), obesity can drive malignant obese PCa. The overall carcinogenic mechanisms of obese PCa include the promotion of metabolism and metastasis, and the inhibition of the immune response. Finally, STAT1, FOXF2, SIM2, SMAD2, CERK, STAT3, and TP53 were selected as essential biomarkers (drug targets) for obese PCa.

## Section: 2. Results › 2.5. The Application of Deep Neural Network to Drug–Target Interaction Prediction and the Drug Design Specifications Considering Drug Regulation Ability and Drug Toxicity

In order to predict the drug–target interaction probability for our identified biomarkers, we trained a DNN-based DTI model in advance for drug–target interaction prediction. Subsequently, we introduced drug regulation ability and drug toxicity into our drug design specifications. The whole drug design flowchart, including one DNN-based DTI model, can be seen in Figure 3. The interaction dataset used for training was from BindingDB [61]. In total, there are 80291 known drug–target interactions between 38015 drugs and 7292 proteins. The number of unknown drug–target interactions is 19966109. To avoid the class imbalance issue, we randomly chose a set of unknown interactions to be the same size as the known interactions. We trained the model using 70% of the data, including 10% of the data as a validation set. The remaining 30% of the data were used as the testing set. Before training the DNN-based DTI model, we performed feature scaling by standardization. Then, PCA was adopted to perform the dimension reduction, giving 694 out of 1359 features. For the architecture of the DNN-based DTI model, we used Adam as an optimizer (learning rate = 0.0001) with binary cross-entropy loss. The input layer had 694 nodes followed by 512, 256, 128, and 64 nodes in the four hidden layers, respectively. The output layer had one node. We used the sigmoid function in the output layer and set the nonlinear activation function ReLU for each hidden layer. Furthermore, dropout was added to each hidden layer for reducing overfitting. Meanwhile, early stopping was used to terminate the model training once the model performance stopped improving on the validation set. Here, we applied 10-fold cross validation to evaluate the model performance, as shown in Table S6. The learning curve for the 10-fold cross validation is shown in Figure S16a,b. Finally, the average accuracy for the 10-fold cross validation was 94.89% (standard deviation: 0.131). It is noted that the model with the best testing accuracy was reserved for making drug–target interaction predictions for our identified biomarkers. The area under the receiver operating characteristic curve (AUC) is useful for organizing binary classifiers and visualizing their performance. The AUC of the reserved model was 0.99, as shown in Figure S17.

In order to narrow down the range of candidate drugs predicted by the DNN-based DTI model, we took drug regulation ability and drug toxicity into account in our drug design specifications. Furthermore, we aimed to find compounds that had the ability to target multiple identified drug targets. For drug regulation ability, we referred to the library of integrated network-based cellular signatures (LINCS) L1000 level 5 dataset [62]. We could identify whether a gene expression was up or downregulated after treatment with the small-molecule compound. Our goal here was to reverse the abnormal gene expression for our identified biomarkers. For drug toxicity, we looked up the median lethal dose (LD50) in DrugBank for our candidate drugs. We aimed to find drugs that not only could reverse the abnormal gene expression but also had higher LD50 values. In addition, drugs with lower toxicity have fewer side effects.

## Section: 3. Discussion › 3.1. Systems Biology Approaches and Traditional Treatments for PCa

By leveraging systems biology approaches, we investigated differential core signaling pathways with carcinogenic molecule mechanisms for PCa. Compared with normal PCa (lean and obese groups), for lean PCa and obese PCa we focused on the common and specific core signaling pathways induced by microenvironmental factors, which further trigger downstream target genes to exert effects on cellular functions including metabolism, immune response, metastasis, epithelial–mesenchymal transition (EMT), apoptosis, and cell proliferation. The common and specific core signaling pathways (Figure 2) have been discussed in detail, based on their corresponding cellular functions. Moreover, the supervised learning method was employed to construct a DNN-based DTI model. In terms of the application, we used this to help us predict potential candidate drugs that had a higher interaction probability with our identified biomarkers. Following the drug design specification, we further considered drug regulation ability and drug toxicity. Finally, we suggested two multiple-molecule drugs for PCa (covering lean and obese PCa) and obesity-specific PCa after filtering the candidate drugs shown in Table S7 based on the drug design specifications.

Nowadays, there are few drawbacks in traditional treatments including active surveillance, surgery, and radiation therapy in patients with PCa. For low-risk PCa, active surveillance methods such as monitoring PSA level, repeat biopsies, or determining the Gleason grade are not suitable for men with other low-risk diseases that cause side effects [63]. If patients have other organ problems, active surveillance could not only potentially result in general health changes but also cause severe discomfort or pain to patients. In addition, after radical prostatectomy surgery, it may increase the chance of erectile dysfunction and a large number of complications such as blood clots, a reaction to the medicine, or an infection [64]. If surgery is conducted after radiation therapy, it could elevate the incidence of wound complications and poor healing. Without killing all the cancer cells in tumors, radiation therapy leads to damage to surrounding tissues, according to the distance between the area of interest and the prostate tumor, resulting in further patient fatigue due to the energy consumption used to kill normal cells in the procedure [65]. Moreover, from the point of view of using molecular drugs, there are some obstacles to treatments using a single drug for a single target in a single disease. For example, bicalutamide is commonly known as a selective antagonist towards the androgen receptor (AR), which plays a role in targeting androgens such as DHT and testosterone. Although it was found to accelerate the degradation of AR, it has estrogenic effects, inducing gynecomastia for men with monotherapy, paradoxically stimulating the occurrence of late-stage PCa. Therefore, in this study, we attempted to find multiple-molecule drugs that could influence multiple identified biomarkers. Additionally, it is noted that drug repositioning methods are gradually becoming spotlighted due to the short time frame for drug development and low cost. The systems biology approach provides an alternative method for exploring new therapeutics for PCa and obesity-specific PCa.

## Section: 3. Discussion › 3.2. Multiple-Molecule Drugs for PCa and Obesity-Specific PCa

We have taken advantage of systems biology methods to recognize significant biomarkers as indispensable drug targets (see Table 1) for PCa (covering lean and obese) and obesity-specific PCa, individually. Moreover, these drug targets were chosen based on the carcinogenic molecular mechanisms. The systems drug discovery method involves designing multiple-molecule drugs to restore the abnormal expression of drug-targeted genes to their normal expression, with higher drug–target interaction probability and lower drug toxicity. According to the results predicted by the DNN-based DTI model, we firstly obtained candidate drugs with higher interaction probability with our identified biomarkers. Subsequently, the range of candidate drugs was narrowed down by considering drug regulation ability using CMap and drug toxicity using a median lethal dose (LD50) filter. Generally, LD50 is used as reference during drug discovery, since lower drug toxicity is associated with reduced side effects. A drug with a lower LD50 value is more toxic. Gathering the results of the drug design specifications, including drug–target interaction, drug regulation ability, and drug toxicity for the identified biomarkers shown in Table S7, we suggested two multiple-molecule drugs for PCa (covering lean and obese) and obesity-specific PCa, respectively.

In Table 2 and Table 3, we observe that apigenin has six drug targets, including STAT1, SIM2, EGFR, MYB, CERK, and STAT3. Apigenin, a nutraceutical drug, plays a significant role in tumor suppression efficacy and in preventing a large number of chronic diseases, especially diabetes. More and more evidence has demonstrated that apigenin functions as a promising therapeutic anti-inflammatory, presenting properties with anti-tumor efficacy against various types of tumors. In PCa, it has been reported in clinical trials that apigenin could target STAT1 as an inhibitor to stimulate the activity of T cells and immune surveillance, further recovering the patient’s own immune-system-associated cell-death genes [66]. As a natural bioactive flavone-type molecule, it has been claimed that apigenin shows pro-health properties, including stimulating immune-like pathways, inhibiting cell proliferation by inducing apoptosis, and suppressing metastasis. Therefore, we considered apigenin as one of the constituents of our potential multiple-molecule drug, to slow down cancer cell motility and decrease the occurrence of severe invasion in obese PCa [67]. This result provides a novel perspective for cancer immunotherapy in preventive healthcare. Interestingly, digoxin, a cardiac glycoside, was chosen as a constituent in our potential multiple-molecule drug, for drug targets containing FOXF2, SMAD2, CERK, and TP53. Digoxin can influence the properties of the sodium potassium channel on the plasma membrane to alter the calcium ion concentration, enhancing apoptosis of cancer cells. Moreover, for patients not receiving androgen deprivation therapy (ADT) as the primary treatment for PCa, digoxin is a promising therapeutic agent exerting protective effects on anti-tumor characteristics [68]. It was also reported that digoxin could significantly suppress MYC expression and elevate SMAD2 expression to induce apoptosis, revealing its vigorous cytotoxic effects in regulating apoptosis-related signaling pathways, with the benefit of low drug toxicity in tumors [69]. Additionally, there is a significant anti-obesity drug, orlistat, that has a tremendous drug effect on inhibiting fatty acid synthase. With fewer side effects, moderate toxicity, and exceptional regulation ability, orlistat, combined with other anti-proliferative drugs, could exert its influence on the vital increase in apoptosis and the suppression of tumor cell viability and proliferation. Through blocking the synthesis of the vast majority of fatty acids in the tumor microenvironment, orlistat favors the boosting of the metabolism to impede the efforts of the cell energy machinery to stimulate proliferation, demonstrating that it is a promising therapeutic agent for obese PCa [70].

In summary, two multiple-molecule drugs for PCa (covering lean and obese) and obesity-specific PCa are suggested, as shown in Table 2 and Table 3, respectively. Apigenin has the ability to inhibit MYC in obese PCa by downregulating STAT3. It is noted that apigenin does not drive the formation of prostate intraepithelial neoplasia and suppresses MYB to indirectly reduce the mobility of cancer cells, to avoid metastasis and cell proliferation for lean PCa. Most important of all, apigenin plays a role in triggering the immune response by activating T cells. Digoxin is beneficial in resisting the malignant transformation of tumors through the upregulation of SMAD2, inducing apoptosis for PCa. In addition, orlistat not only helps in suppressing malignant metastasis procedures but also favors the strengthening of the human immune response by dephosphorylating CERK to reduce the synthesis of ceramide, resulting in less fatty acid and cholesterol production.

## Section: 4. Materials and Methods › 4.1. A General Review of Constructing Core Genome-Wide Genetic and Epigenetic Networks (GWGENs) of Normal Prostate Cells, and Lean and Obese PCa

In order to perform a comprehensive analysis of molecular mechanisms in PCa and discover the common and specific molecular mechanisms, we needed to fully compare four core genome-wide genetic and epigenetic networks (GWGENs). Adopting a BMI of 25 as the obesity threshold, the data were split into two groups: one for lean people and the other for obese people. With the benefit of systems biology [71], we can further extract the four core signaling pathways of normal prostate cells (including lean and obese groups), and lean and obese PCa from their core GWGENs. The methods for finding the core signaling pathways from the candidate GWGEN can be seen in the flowchart in Figure 1. Here, we split the process into five steps as follows:

## Section: 4. Materials and Methods › 4.2. Data Preprocessing for Constructing the Candidate GWGEN

In this study, we downloaded the dataset with accession number GSE79021 from the National Center for Biotechnology Information (NCBI). The samples in the dataset were divided into four groups, containing normal prostate cells (lean and obese groups), and lean and obese PCa. We only used samples that had BMI information. Hence, we had 49 samples for normal prostate cells and 153 samples for PCa. Subsequently, we individually classified the normal prostate cells and PCa cells into two categories using the body mass index (BMI, threshold: 25) for investigating the influence of obesity on PCa. In this way, 25, 24, 70, and 83 samples were obtained for normal prostate cells in the lean group, normal prostate cells in the obese group, PCa in the lean group, and PCa in the obese group, respectively. It is noted that the candidate GWGEN comprised a candidate PPIN and a candidate GRN. Therefore, it was a binary matrix. If two nodes have an interaction, we assigned a value of one, otherwise we assigned a value of zero. For building the candidate PPIN, we referred to the following databases: DIP [72], IntAct [73], BioGRID [74], and MINT [75]. Moreover, to construct the candidate GRN, we considered the following databases: HTRIdb [76], ITFP [77], TRANSFAC [78], CircuitDB2 [79], TargetScanHuman [80], and starBase 2.0 [81].

## Section: 4. Materials and Methods › 4.3. System Modeling for Normal Prostate Cells and PCa

After constructing the candidate GWGEN, we performed system modeling for proteins, genes, miRNA, and lncRNA [82]. We can describe the i-th protein in the candidate PPIN by the following equation:(1)pi[n]=∑h=1h≠iHiαihpi[n]ph[n]+λi,PPI+ϕi,PPIs[n], for i=1,…,I , n=1,…,N where pi[n] and ph[n], respectively, denote the expression level of the i-th and h-th protein for the n-th sample; αih denotes the interaction ability between the i-th protein and the h-th protein; Hi indicates the total number of proteins interacting with the i-th protein; I indicates the total number of proteins in the candidate PPIN; N represents the total number of data samples; and λi,PPI expresses the basal level of the i-th protein. The change in basal level is related to post-translational modification, including phosphorylation, acetylation, and methylation. In addition, ϕi,PPIs[n] shows the stochastic data noise of the i-th protein.

Similarly, the j-th gene in the candidate GRN, which is part of the candidate GWGEN for sample n is given as shown below:(2)gj[n]=∑r=1r≠jRjajrTr[n]+∑s=1SjbjsLs[n] − ∑u=1UjcjuMu[n]gj[n]+λj+ϕj[n], for j=1,…,J , n=1,…,N where gj[n] indicates the expression level of the j-th gene; ajr and bjs individually represent the transcription regulatory ability from the r-th TF and the s-th lncRNA to the j-th gene; −cju≤0 denotes the post-transcription regulatory ability by which the u-th miRNA restrains the j-th gene; Rj and Sj, respectively, denote the total number of TFs and lncRNAs binding to the j-th gene; Uj indicates the total number of miRNAs inhibiting the j-th gene; and Tr[n], Ls[n], and Mu[n] individually denote the expression of the r-th TF, the s-th lncRNA, and the u-th miRNA. N and J are respectively the total number of data samples and genes; λj indicates the basal level of the j-th gene expression; and ϕj[n] represents the stochastic data noise of the gene expression in the j-th gene for the sample n. The system modeling for miRNA and lncRNA is described in the Supplementary Materials.

## Section: 4. Materials and Methods › 4.4. Utilizing System Identification and System Order Detection Methods to Identify Real GWGENs from the Candidate GWGEN

So far, we have formulated each protein, gene, lncRNA, and miRNA in the candidate GWGEN. Further, with the help of the microarray data, we estimate the regulation parameters shown in Equations (1) and (2). Hence, firstly, we can rewrite Equations (1) and (2) as follows:(3)pi[n]=pi[n]p1[n]⋯pi[n]pHi[n] 1×αi1⋮αiHiλi+ϕi[n] (4)gj[n]=T1[n]⋯TRj[n] L1[n]⋯LSj[n] gj[n]M1[n]⋯gj[n]MUj[n] 1×aj1⋮ajRjbj1⋮bjSj−cj1⋮−cjUjλj+ϕj[n]

For simplicity, Equations (3) and (4) can be represented by the following linear regression forms, respectively:(5)pi[n]=βi,P[n]⋅γi,P+ϕi[n], for i=1,…,I, n=1,…,N (6)gj[n]=βj,G[n]⋅γj,G+ϕj[n], for j=1,…,J, n=1,…,N where γi,P indicates the parameter vector related to the protein–protein interaction abilities; γj,G represents the parameter vectors, including the regulation abilities of TFs and the post-transcriptional regulatory abilities of lncRNAs and miRNAs; and βi,P[n] and βj,G[n] separately denote the expression vectors of the protein and gene for sample n.

Since we have N samples, Equations (5) and (6) can be augmented into the following equations:(7)pi[1]pi[2]⋮pi[N]=βi,P[1]βi,P[2]⋮βi,P[N]⋅γi,P+ϕi[1]ϕi[2]⋮ϕi[N] (8)gj[1]gj[2]⋮gj[N]=βj,G[1]βj,G[2]⋮βj,G[N]⋅γj,G+ϕj[1]ϕj[2]⋮ϕj[N]

In addition, the above equations can be represented as follows: (9)Pi = εi,P⋅γi,P + φi (10)Gj = εj,G⋅γj,G + φj

To estimate the regulatory parameters in Equations (9) and (10), we transform them into linear least squares estimation or constrained linear least squares estimation problems as below:(11)γ^i,P=minγi,P12εi,P⋅γi,P−Pi22 (12)γ^j,G=minγj,G12εj,G⋅γj,G−Gj22 subject to [0⋯⋯0⋮⋱⋮⋮⋱⋮0⋯⋯00⋯⋯0⋮⋱⋮⋮⋱⋮0⋯⋯010⋯00⋱⋱⋮⋮⋱⋱00⋯010⋮⋮0]γj,G≤0⋮⋮0Rj Sj Uj

It is noted that (12) represents a constrained linear least squares estimation problem. By adding a matrix inequality in (12), we can guarantee that the estimated post-transcriptional regulatory abilities from miRNA are negative. Moreover, Equations (11) and (12) can be solved via the MATLAB optimization toolbox.

The candidate GWGEN is built from various databases. False-positive interactions may exist within the candidate GWGEN. Therefore, we performed system order selection by computing the AIC. According to AIC theory, the real system order would lead to the smallest AIC value [83]. The AICs for the i-th protein and the j-th gene are as given below:(13)AIC(Hi)=log(ℏ^i,P2)+2(ƛi,P)Nwhere ℏ^i,P=(Pi−(εi,P⋅γ^i,P))T(Pi−(εi,P⋅γ^i,P))N , ƛi,P=Hi+1 (14)AIC(Rj,Sj,Uj)=log(ℏ^j,G2)+2(ƛj,G)Nwhere ℏ^j,G=(Gj−(εj,G⋅γ^j,G))T(Gj−(εj,G⋅γ^j,G))N , ƛj,G=Rj+Sj+Uj+1 where ℏ^i,P2 and ℏ^j,G2 individually denote the estimated residual error of the i-th protein and the j-th gene; ƛi,P and ƛj,G are the number (order) of parameters for the i-th protein in the parameter estimation problem in (11) and the number (order) of parameters for the j-th gene in the parameter estimation problem in (12), respectively; and γ^i,P and γ^j,G individually indicate the estimated parameters of the i-th protein in (11) and the estimated parameters of the j-th gene in (12). The real system order Hi* for the i-th protein and Rj*,Sj*,Uj* for the j-th gene would give the smallest AIC value. In other words, all the insignificant interactions and regulations outside the real system order are pruned for each protein, gene, lncRNA, and miRNA in the candidate GWGEN. The method of performing system identification and utilizing the system order detection scheme for lncRNA and miRNA is given in the Supplementary Materials. The real GWGENs of normal prostate cells (including lean and obese groups), and lean and obese PCa are shown in Figures S1–S4, respectively.

## Section: 4. Materials and Methods › 4.5. Extracting Core GWGENs from the Real GWGENs Using the Principal Network Projection Method

The real GWGEN is too complex for investigating the discrepancies in genetic and epigenetic mechanisms between normal prostate cells (including lean and obese), and lean and obese PCa. Therefore, we employed the PNP method on the real GWGEN to extract the relevant core GWGEN. Firstly, we constructed a system matrix K, including all estimated parameters of the real GWGEN. The system matrix K is:(15)K=kprotein↔protein00kTF→geneklncRNA→genekmiRNA→genekTF→lncRNAklncRNA→lncRNAkmiRNA→lncRNAkTF→miRNAklncRNA→miRNAkmiRNA→miRNA where the sub-network matrix kprotein↔protein denotes the system matrix of interactive abilities of proteins; the sub-network matrices kTF→gene, kTF→lncRNA and kTF→miRNA indicate the relevant system matrices associated with TFs transcriptional regulatory abilities for genes, lncRNAs, and miRNA, respectively; the sub-network matrices klncRNA→gene, klncRNA→lncRNA, and klncRNA→miRNA represent the relevant system matrices associated with lncRNAs post-transcriptional regulatory abilities for genes, lncRNAs, and miRNA, respectively; and the sub-network matrices kmiRNA→gene, kmiRNA→lncRNA, and kmiRNA→miRNA show the relevant system matrices associated with miRNAs post-transcriptional regulatory abilities for genes, lncRNAs, and miRNA, respectively. The detailed elements of system matrix K are shown in the following: (16)K=[α^11⋯α^1h⋯α^1I⋮⋱⋮⋱⋮α^i1⋯α^ih⋯α^iI⋮⋱⋮⋱⋮α^I1⋯α^Ih⋯α^II0⋯0⋯0⋮⋱⋮⋱⋮0⋯0⋯0⋮⋱⋮⋱⋮0⋯0⋯00⋯0⋯0⋮⋱⋮⋱⋮0⋯0⋯0⋮⋱⋮⋱⋮0⋯0⋯0α^11⋯α^1r⋯α^1R⋮⋱⋮⋱⋮α^j1⋯α^jr⋯α^jR⋮⋱⋮⋱⋮α^J1⋯α^Jr⋯α^JRb^11⋯b^1s⋯b^1S⋮⋱⋮⋱⋮b^j1⋯b^js⋯b^jS⋮⋱⋮⋱⋮b^J1⋯b^Js⋯b^JS−c^11⋯−c^1u⋯−c^1U⋮⋱⋮⋱⋮−c^j1⋯−c^ju⋯−c^jU⋮⋱⋮⋱⋮−c^J1⋯−c^Ju⋯−c^JUd^11⋯d^1r⋯d^1R⋮⋱⋮⋱⋮d^x1⋯d^xr⋯d^xR⋮⋱⋮⋱⋮d^X1⋯d^Xr⋯d^XRf^11⋯f^1s⋯f^1S⋮⋱⋮⋱⋮f^x1⋯f^xs⋯f^xS⋮⋱⋮⋱⋮f^X1⋯f^Xs⋯f^XS−q^11⋯−q^1u⋯−q^1U⋮⋱⋮⋱⋮−q^x1⋯−q^xu⋯−q^xU⋮⋱⋮⋱⋮−q^X1⋯−q^Xu⋯−q^XUη^11⋯η^1r⋯η^1R⋮⋱⋮⋱⋮η^y1⋯η^yr⋯η^yR⋮⋱⋮⋱⋮η^Y1⋯η^Yr⋯η^YRμ^11⋯μ^1s⋯μ^1S⋮⋱⋮⋱⋮μ^y1⋯μ^ys⋯μ^yS⋮⋱⋮⋱⋮μ^Y1⋯μ^Ys⋯μ^YS−ν^11⋯−ν^1u⋯−ν^1U⋮⋱⋮⋱⋮−ν^y1⋯−ν^yu⋯−ν^yU⋮⋱⋮⋱⋮−ν^Y1⋯−ν^Yu⋯−ν^YU]∈ℜ(I*+J*+X*+Y*)×(R∗+S∗+U∗) where α^ih is the estimated interactive ability between the i-th protein and the h-th protein; a^jr, b^js, and c^ju individually represent the estimated regulation abilities of the r-th TF on the j-th gene, the s-th lncRNA on the j-th gene, and the u-th miRNA on the j-th gene; d^xr, f^xs, and q^xu are separately the r-th TF on the x-th lncRNA, the s-th lncRNA on the x-th lncRNA, and the u-th miRNA on the x-th lncRNA; and η^yr, μ^ys, and ν^yu indicate the r-th TF on the y-th miRNA, the s-th lncRNA on the y-th miRNA, and the u-th miRNA on the y-th miRNA.

Subsequently, we performed singular value decomposition (SVD) on the system matrix K.

The SVD of K is described as follows: (17)K=BDZT where B∈ ℜ(I∗+J∗+X∗+Y∗)×(I∗+J∗+X∗+Y∗) and ZT∈ ℜ(R∗+S∗+U∗)×(R∗+S∗+U∗) denote the unitary singular matrix and D=diag(d1,…,di,…,dR*+S*+U*)∈ℜ(I*+J*+X*+Y*)×(R∗+S∗+U∗) indicates the diagonal matrix composed of R∗+S∗+U∗ singular values in descending order (i.e., d1≥⋯≥di≥⋯≥dR*+S*+U*). Then, we normalize the singular values as below:(18)Pi=di2∑i=1R*+S*+U*di2

From the viewpoint of energy, the top r singular values represent 85% of the principal network (i.e., ∑i=1IPi≥0.85). Subsequently, we project each node in the system matrix K to the r-th singular vector. The corresponding equation is:(19)Z(t,r)=kt,:⋅z:,rT, for t=1,…I*+J*+X*+Y*, r=1,…I where kt,: denotes the t-th row vector of K and z:,rT is the r-th singular vector. We define the 2-norm projection value for each node, including protein, gene, lncRNA, and miRNA, on the 85% principal structure of the real GWGEN as below:(20)R(t)=∑r=1IZ2(t,r), for t=1,…I*+J*+X*+Y*, r=1, …, I

If the value of R(t) is larger, the t-th node is more important to the principal structure. On the other hand, if the projection value of R(t) is close to zero, the relevant node is insignificant and practically independent of the principal structure of the real GWGEN. According to the projection value, we chose the top 3000 nodes to construct the core GWGENs of normal prostate cells (including lean and obese groups), and lean and obese PCa, as shown in Figures S5–S8. Combining this with the literature survey, we can obtain core signaling pathways in the annotation of KEGG pathways. The core signaling pathways of normal prostate cells (including lean and obese groups), and lean and obese PCa refer to Figures S9–S12, respectively.

## Section: 4. Materials and Methods › 4.6. Deep-Neural-Network-Based Drug–Target Interaction Prediction Model

Investigating the core signaling pathways, we identified essential biomarkers based on carcinogenic molecular mechanisms for PCa (covering lean and obese groups) and obesity-specific PCa. The corresponding biomarkers (drug-targets) are shown in Table 1. The systems drug discovery method was proposed to design multiple-molecule drugs targeting these biomarkers. With the help of the DNN-based DTI model, we considered the drug–target interaction probability, which was one of the drug design specifications.

As shown in the flowchart for system drug discovery and design in Figure 3, the drug–target interaction dataset was from BindingDB [61]. In order to delineate the drug–target interactions in a numerical vector, we transformed them into a feature vector using the PyBioMed Python package in a Python 2.7 environment [84]. We used the PyMolecule module in PyBioMed to transform the drug descriptors. The drug features contain commonly used structural and physicochemical information. The PyProtein module in PyBioMed was applied to transform the target descriptors. The target features were computed based on the widely used structural and physicochemical properties of proteins and peptides from amino acid sequences. The total numbers of drug and target features were 363 and 996, respectively. More details about descriptor transformation are given in the PyBioMed documentation. In this way, we could use a united vector to describe a drug–target interaction pair, as shown below:(21)υdrug−target=[W, F]=[w1,w2,…,wx,f1,f2,…,fy] where υdrug−target denotes the feature vector of a drug–target pair; x and y are the total number of drug features and target features, respectively; W and F individually represent the feature vector of the relevant drug and relevant target; wx is the x-th drug feature; and fy is the y-th target feature. Moreover, before training the DNN-based DTI model, we scaled the data via standardization, since the drug and target features are measured on different scales. Lastly, to remove noisy features and reduce memory consumption, we applied principal component analysis (PCA), to decrease the feature size from 1359 to 618 [85].

For the DNN-based DTI model, each output layer could be described as follows:(22)kn=δ(wTxn+b), where w=w1w2⋮wh, b=b1b2⋮bh where kn represents the output of each layer when input vector xn is the n-th drug–target vector; δ denotes the activation function (ReLU for the hidden layers and sigmoid for the output layer); w represents the weighting parameters; and b signifies bias parameters. The drug–target interaction prediction is a binary classification problem. Hence, the binary cross-entropy is selected to be the cost function:(23)Cn(w,b)=−1N∑n=1N(snlog(s^n)+(1−sn)log(1−s^n))L(w,b)=1N∑n=1NCn(sn,s^n) where L(w,b) denotes the average total loss; sn is the n-th true positive instance (1) or true negative instance (0) of drug–target binding; and s^n denotes the n-th predicted probability of a positive instance (1) or predicted probability of a negative instance (0) of drug–target binding. For obtaining the optimal network parameter set ϕ*, the cost function is used in the following:(24)ϕ*=argminϕ L(ϕ)

The above equation could be achieved using the backpropagation algorithm [86]. The updated weight and bias parameters for the j-th epoch are shown below:(25)ϕj=ϕj−1−η∇L(ϕj−1),where ∇L(ϕj−1)=∂L(ϕj−1)∂w1⋮∂L(ϕj−1)∂wh∂L(ϕj−1)∂b1⋮∂L(ϕj−1)∂bh. where η is the learning rate, which is 0.001 and ∇L(ϕj−1) denotes the gradient of L(ϕj−1).

## Section: 5. Conclusions

In this study, we proposed a systems biology approach to investigating the role of obesity in PCa and identifying essential biomarkers as drug targets for PCa (covering lean and obese) and obesity-specific PCa. In addition, we provided drug design specifications, including drug–target interaction, drug regulation ability, and drug toxicity. For considering the drug–target interactions, we trained a DNN-based DTI model in advance. Utilizing this, we could obtain predicted drug candidates based on the identified biomarkers. These drug candidates then passed through filters for drug regulation ability and drug toxicity. Finally, we suggested two potential multiple-molecule drugs (drug combinations) to prevent PCa (covering lean and obese) and obesity-specific PCa. Nonetheless, there is still room for improvement, especially in the case of leveraging more genomics data and applying advanced DNN-based DTI models that consider the compounds’ chemical structures in graphs to enhance the pipeline. Moreover, it is noted that the process of developing a novel drug is time-consuming, risky, and costly. By combining the proposed systems biology approach with computational drug discovery, the steps of target identification and target validation in drug discovery might be accelerated and optimized before the drug enters clinical trials.


---

# Limits of Prediction for Machine Learning in Drug Discovery

- **Authors:** Modest von Korff, Thomas Sander
- **Issuer:** Frontiers in pharmacology
- **Type:** Scientific article
- **Published:** 2022-03-10
- **Language:** en
- **DOI:** 10.3389/fphar.2022.832120
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35359835/
- **Licence:** CC-BY

## Section: Abstract

In drug discovery, molecules are optimized towards desired properties. In this context, machine learning is used for extrapolation in drug discovery projects. The limits of extrapolation for regression models are known. However, a systematic analysis of the effectiveness of extrapolation in drug discovery has not yet been performed. In response, this study examined the capabilities of six machine learning algorithms to extrapolate from 243 datasets. The response values calculated from the molecules in the datasets were molecular weight, cLogP, and the number of sp3-atoms. Three experimental set ups were chosen for response values. Shuffled data were used for interpolation, whereas data for extrapolation were sorted from high to low values, and the reverse. Extrapolation with sorted data resulted in much larger prediction errors than extrapolation with shuffled data. Additionally, this study demonstrated that linear machine learning methods are preferable for extrapolation.

## Section: Introduction

In drug discovery, new molecules undergo clinical trials in human subjects only after numerous checks for safety and potency in biological test systems. Often, a drug suitable for oral administration is desired, i.e., a molecule that can cross cellular membranes separating the gastrointestinal system and blood vessels. After absorption, blood vessels distribute the molecule throughout the organism and to its site of action. Blood contains many proteins that bind a substantial fraction of any compound. During distribution, molecules pass through the liver, which contains enzymes able to metabolize many types of chemical substances, thus reducing the concentration of the active drug (clearance). An important measure used in the optimization of a bioactive molecule is plasma exposure after oral administration, often expressed as “area under the curve” (AUC), i.e., the concentration of the active molecule in blood plasma integrated over time. Bioavailability depends on multiple properties of the molecule including cell layer permeability and clearance in the liver. When a molecule reaches the target protein, it must bind in such a way that it has the desired effect. A specific assay is usually developed to measure the effect of the molecule on the target protein. At present, it is still not possible to design a successful drug, fulfilling all necessary requirements, without biological tests. However, biological testing requires time and resources, which limit the number of compounds that can be explored. Medicinal chemists require quantitative models allowing prioritization the most promising molecules for biological testing.

## Section: Introduction › Related Work

The use of quantitative structure-activity relationships (QSAR) is essential in drug discovery and has been investigated in multiple publications (Gramatica, 2007; Cherkasov et al., 2014). Recently, huge efforts has been undertaken to find appropriate meta-parameter for QSAR models (Olier et al., 2018). It is well known that statistical models lose their predictive power when they are outside the range of calibration. Outside the calibration range, confidence intervals become infinite. These limits have been previously discussed for QSAR from (Tong et al., 2005) and were formulated in OECD policies for the validation of QSAR models (Member countries, 2004; OECD, 2014). Closely related to the calibration range is the term applicability domain. The term applicability domain is used in cheminformatics for quantitative structure activity models. The OECD guideline demands to consider the applicability domain but does not give a binding definition. By Roy et al. the application domain was defined as “The AD is a theoretical region in chemical space encompassing both the model descriptors and modeled response which allows one to estimate the uncertainty in the prediction of a particular compound based on how similar it is to the training compounds employed in the model development” (Roy et al., 2015). If the predicted molecules are similar to the training molecules in descriptor space, they are in the application domain (Jaworska et al., 2005). In drug discovery, the modeled response are molecular properties which the medicinal chemists aim to optimise. So, the properties medicinal chemists would like to predict are often outside the range of response values, which were already covered by experiments. At the start of a drug discovery project, a few molecules are usually identified which show modest activity at the target protein site. Starting compounds are modified by medicinal chemists to improve their properties. By adding all available information into the new compounds, they improve their characteristics over time. The next compound is often designed with the aim to show a lower binding constant to the target protein. Usually, this compound is similar to the already synthesized compounds and therefore in the applicability domain. During this optimization process, the desired response values are outside the range of the available response values. A model that aims to support the medicinal chemist in his work needs the capability of extrapolation. Recently, the use of extrapolation through machine learning, to assess the bioactivity of a molecule in drug discovery, has been evaluated (Cortés-Ciriano et al., 2018). Extrapolation outside the upper limits of the measured value range is wanted for the plasma exposure after oral administration. The plasma exposure should be as high as possible, but in a drug discovery project it is often to low. Additionally, frequently the majority of available response values are far away from the desired value range.

## Section: Introduction › Our Work

The missing information in QSAR literature about differences between the errors of interpolation and extrapolation triggered a question. How effective can extrapolation of response values for chemical molecules be? To answer this question, we decided to use organic molecule datasets with calculated physicochemical properties. The physicochemical properties were used as response values in this study and were calculated from the molecular structure. Mathematically, a molecule is represented as a small graph with colored edges and colored nodes. This molecular graph cannot directly be used as input for the applied machine learning methods. The graph must be transformed into a vector, a chemical descriptor. Machine learning creates models that relate descriptor vectors to the corresponding response values. With our setup a fully correct machine learning model was theoretically possible. The complete information needed to predict the response values was enclosed in the molecular structure. If this information is transferred to the descriptor vector and the machine learning algorithm constructs a perfect fitting model, a correct prediction will result. This model is “semi-mechanistic”, which is covered by the OECD guideline “When the AD is defined in more mechanistic terms, the (Q)SAR can predict reliably beyond the physicochemical and response space of the training set”. In our experimental setup the used response values allowed the machine learning algorithms to create such “semi-mechanistic” models.

## Section: Methods

Seed molecules for dataset generation.

Comparison of 25,000 experimental logP values with DataWarrior calculated logP.

Summary of the response values for all datasets. The first column indicates the property and the other columns the minimum, maximum, average, standard deviation, and median values.

## Section: Methods › Datasets

For the construction of our molecule datasets, the size and structure of typical datasets in drug discovery was considered. In a drug discovery project, the molecules usually show a high similarity. New molecules are derived from a starting molecule that is explored by medicinal chemists. The newly synthesized molecules are similar to the starting molecule, but ideally have the desired features. We mimicked this process by taking a known drug molecule and removing randomly peripheral non hydrogen atoms. The removed atom was replaced with an appropriate number of hydrogen atoms. Rings were also randomly cut. Three top selling drug molecules were chosen: apixaban, rosuvastatin, and sofosbuvir (Figure 1). From each molecule, three sets, S apix,1–3 , S rosu,1–3 and S sofo,1–3 , of about 300 molecules each were created. Consequently, nine datasets were constructed from three blockbuster drugs. Similar molecules are needed for successful machine learning models in QSAR (Netzeva et al., 2005). The similarity of test- and training molecules was guaranteed by our molecule degradation approach.

Seed molecules for dataset generation.

## Section: Methods › Dependent Variables

Dependent variables and response variables were calculated for each molecular structure. The simplest dependent variable in this study was molecular weight, which was calculated from the corresponding molecular formula. The logP value, the logarithm of the 1-octanol/water partition coefficient, is a more sophisticated variable which estimates the distribution of a drug based on an octanol/water system. The cLogP value assesses the permeation of a molecule from the gastrointestinal tract into blood vessels, and it is an important measure in drug discovery. Here, a fragmental approach from DataWarrior (Sander et al., 2015) was used to calculate the cLogP. This fragmental approach was developed for the OSIRIS Property Explorer (OsirisP) and successfully benchmarked in a large study with 90,000 compounds (Mannhold et al., 2009). In this independent examination, OsirisP ranked between the top logP calculation methods. An improved version of the Osiris logP calculator was implemented in DataWarrior in 2014. This updated OsirisP calculation is implemented as increment system adding contributions of every atom based on its atom type. OsirisP distinguishes around 400 atom types. This includes hybridisation state, ring membership, aromaticity, and additionally to the older version charges. More than 5,000 compounds with experimentally determined logP values were used as training set to calculate the increments. A recent comparison with 25,000 experimental logP values is given in Figure 2. The strong relation between the experimental and the calculated logP is shown by a correlation coefficient of 0.93. However, this strong correlation is not needed for our experimental setup. Important for the experiment is the linear dependency between the molecular structure and the calculated logP values. Theoretically, this linear dependency allows linear regression methods like partial least square regression a perfect fit of dependent and independent variables.

A third response variable was the number of sp3-carbon atoms in a molecule, where each sp3-carbon atom has 4 neighboring atoms. In early drug discovery, the number of sp3-carbon atoms is used to chose molecules for high throughput screening in biological assays. For every molecule in the nine datasets S apix,1–3 , S rosu,1–3 and S sofo,1–3 , the three dependent variables were calculated. By considering independent and dependent variables, a set of 27 datasets was obtained. A summary of the obtained values is given in Table 1.

Comparison of 25,000 experimental logP values with DataWarrior calculated logP.

Summary of the response values for all datasets. The first column indicates the property and the other columns the minimum, maximum, average, standard deviation, and median values.

## Section: Methods › Descriptors

A molecular graph is inappropriate input for most machine learning algorithms. Molecular descriptors are used in cheminformatics to describe molecular structure in algebraic form (Todeschini and Consonni, 2008). For a descriptor, a molecular graph is usually converted into a vector, which is the input for machine learning. The transformation from a molecule into a vector is one directional and comes with a loss of information. The molecular structure can not be recovered from the vector. Different transformations result in different losses of information. For this reason, three different topological molecule descriptors were chosen.

## Section: Methods › Fragment Fingerprint Descriptor

The fragment fingerprint is a dictionary based descriptor with a length of 512 bits. Each bit represents a substructure fragment. The dictionary of 512 substructures was created by a computational procedure, which had been optimized to achieve two goals: 1) any of these fragments should occur frequently in organic molecule structures and 2) each fragment should be linearly independent with regard to their substructure-match-pattern in diverse organic compound sets. To generate a descriptor vector, the molecular structure is searched for any of the substructures in the dictionary. For any match, the corresponding bit of the vector is set to 1. Any molecular structure is represented by a binary vector of length 512. The fragment fingerprint descriptor belongs to the same class as the “MDL structure keys” (McGregor and Pallai, 1997), which have recently been shown to outperform 3D descriptors in virtual screening (Nettles et al., 2006).

## Section: Methods › Path Fingerprint Descriptor

The path fingerprint is a molecular graph path walking fingerprint descriptor. All distinguishable paths with up to 7 atoms are hashed into a descriptor vector of 512 bits. This descriptor is conceptually similar to ChemAxCFp, the chemical fingerprints from ChemAxon (ChemAxon, 1998) and to the Daylight fingerprints (Daylight, 1998).

## Section: Methods › Skeleton Spheres Descriptor

The skeleton spheres descriptor is a vector of integers which counts the occurrence of different substructures in a molecule. Five circular layers with increasing bond distance are located for each atom in the molecule. Hydrogen atoms are not considered. This results in four fragments starting with the naked central atom, adding one layer at a time. Every fragment is encoded as a canonical string (id-code), similar to the generation of canonical SMILES (Weininger et al., 1989). The canonical id-code includes the stereochemistry of the encoded fragment, which is a feature missing in other molecular descriptors. The id-code is then assigned to one of 1,024 fields in a vector. Therefore, the hash value of the id-code is calculated and the corresponding value in the vector is increased by one. The Hashlittle algorithm (Jenkins, 2006) is used as a binning function, which takes a text string as input and returns an integer value between 0 (inclusive) and 1,024 (exclusive). In preliminary experiments, this hash function showed a good uniform distribution of the generated hash values. To consider the molecular scaffold without the influence of the heteroatoms, the whole calculation is repeated while replacing the hetero atoms with carbon. The resulting hash values are used to increment the corresponding fields in the vector. By adding this skeleton information to the descriptor vector, the similarity calculation between two descriptor vectors becomes a bit insensitive to the exact position of the heteroatoms in two molecules. This directs the similarity value towards the perception of similarity by medicinal chemists. For medicinal chemists, the exact position of a hetero atom is not as discriminating as it would be for the spheres descriptor without the skeleton coding part. The additional consideration of the scaffold information and the use of a histogram instead of a binary vector distinguishes the skeleton spheres descriptor from other circular fingerprints. (Glem et al., 2006).

Each of the nine molecule sets S apix,1–3 , S rosu,1–3 , and S sofo,1–3 was compiled into three descriptor sets fragment fingerprint, path fingerprint and skeleton spheres.

## Section: Methods › Dataset Construction

A dataset D contains a matrix X and a vector y . Every row in the matrix X represents a molecule by one of the three descriptors, fragment fingerprint, path fingerprint, and skeleton spheres. Corresponding to a row i in X is a response value i in y . Three response values, molecular weight, cLogP and sp3-carbon, were available for each row in X . In drug discovery projects, the optimization process aims for response values outside the range of response values initially obtained. To assess the predictive power of a machine learning tool in a drug discovery project, we sorted the compounds by their response values. One dataset contained the ascending response values, a second the descending values and a third dataset was compiled from the shuffled response values. Summarizing the data set up, nine sets with molecules, each set compiled three descriptors, gave 27 descriptor matrices X . Three different response values, molecular weight, cLogP, and the number of sp3-carbon atoms were sorted according to ascending, descending or shuffled data. Combined with the 27 X matrices, a total of 243 datasets were obtained. The molecules together with the descriptors and the calculated response values are available from (Korff, 2021). Each of these datasets underwent the successive regression procedure, as described in the next two paragraphs.

## Section: Methods › Machine Learning Techniques

Six modeling techniques were applied to construct regression models for the datasets: k next neighbor regression (kNN), partial least square regression (PLS), partial least square regression with power transformation (PLSP), random forest regression (RFR), Gaussian process regression (GPR), and support vector (SVM) regression. All parameters for these machine learning models were optimized by an exhaustive search. The median model was used as a baseline model. Any successful machine learning model should be significantly better than the baseline model. Also easy to calculate was the k next neighbor model for regression. In this model, the k next neighbors in the training set were screened for the query descriptor vector. The predicted y^ value was the average of the corresponding y values weighted by similarity. Partial least square regression (PLSR) is a multivariate linear regression technique (De Jong, 1993), which only requires the number of factors as the input parameter. PLSR with power transformation includes a Box Cox transformation and is often used to model biological data, which are notoriously not normally distributed (Sakia, 1992). For random forests and Gaussian process regression, we used the implementation from Haifeng Li. (Li, 2021). Random forest regression was only included because it is frequently used for models in drug discovery. Random forests base on decision trees and are not capable of extrapolation. The Java program library libsvm was used for the support vector machine regression (Chang and Lin, 2011). Details for meta-parameter search: kNN: k from 1 to 9, step 1. PLSR: factors from 1 to 31, step 1. PLSR power transformation: factors like PLSR; λ from 0.05 to 2, step 0.05. Gaussian process regression: λ 0.001, 0025 … 1, … 10,10,000. Random forest: trees 50, 100, 250, 500, 1,000; Maximum number leaf nodes from 2 to 54 step 2. Mtry: 0.15, 0.333, 0.45. Maximum node size from 2 to 54, step 2. Support vector regression: (Smola and Schölkopf, 2004) Epsilon regression, RBF kernel, power of 2 rule for: C from 2 to 5 to 215; ϵ from 2 to 10 to 26; γ 1/(number of fields in the descriptor). Details for the objective function are given in the next section.

## Section: Methods › Successive Regression

A two-step process was implemented to ensure an unbiased estimation for the extrapolation power of a model. The first step was the selection of one meta-parameter set for every machine learning technique. The algorithm started with the first 20% of the molecule descriptors X 0,0.2, y 0,0.2 together with the measured response values to determine the meta parameters of the machine learning models via an exhaustive search. An eleven-fold Monte Carlo cross validation was employed to split all data into the training and validation datasets (Xu and Liang, 2001). A left out fraction of 25% was chosen as the size of the validation dataset. With this set up, the average error for all meta-parameter sets was calculated. For each machine learning technique t , the meta-parameter set M min,t was chosen that showed the minimum average error. This meta-parameter set was used to construct a model from all data in X 0,0.2, y 0,0.2. In the second step, an independent test set was compiled from the next 10% of data, X 0.3, y 0.3. The average prediction error of y0.3^ gave an unbiased estimator for the model, because the machine learning algorithm M min,t,0.2 had not seen these data before prediction. Subsequently, step one was repeated, this time with the dataset X 0.3, y 0.3. So, the former test data were added to X 0,0.2, y 0,0.2. The meta parameter for the machine learning algorithms M min,t,0.3 were now determined with X 0,0.3, y 0,0.3. So, the prediction was done for y 0.4. This process was repeated eight times, up to a model size with X 0,0.9, y 0,0.9 and a prediction for y 1.0. Using this method, we assessed the extrapolation power of the machine learning method together with the applied molecular descriptor for the sorted response data. The 10% test set, with higher or lower response values than the training set, was an unbiased estimator of the model’s quality for extrapolation. As a quality measure for prediction, we used the relative error.

## Section: Methods › Technical Details

The source code was implemented in Java 1.8. The calculations were done on a SuperMicro computer with 176 processor cores. Meta-parameter calculation and test data prediction took approximately 72 h for all datasets. Data visualization was done with DataWarrior (Sander et al., 2015), an open source tool for data visualization and evaluation (Sander, 2021).

## Section: Results

The successive regression procedure was applied to all 243 datasets. In the following, the results for nine datasets with the molecular structures S apix,1–3 , S rosu,1–3 and S sofo,1–3 are summarized by their median relative error. No extrapolation was needed for the shuffled datasets. Figure 3 and Table 2 show the machine learning results for the prediction for the shuffled data for three descriptors and three properties. The three descriptors, fragment fingerprint, path fingerprint and skeleton spheres, are indicated by shape. Circles, squares and triangles indicate fragment fingerprint, path fingerprint and skeleton spheres descriptors, respectively. A color code was used for the machine learning algorithms. Green indicated our base line model, which was the prediction by median, kNN regression in red, Gaussian process regression in blue, partial least square regression in yellow, partial least square regression with power transformation in light blue, random forest regression in magenta, and support vector regression in orange. All results are available as Data Warrior files (Korff, 2021).

For almost all models, the relative error for predicted molecular weight was less than 10%. For the majority of predictions, relative error was less than or equal 5%. No preference for any of the descriptors was observed, as indicated in Figure 3. A higher separation was shown by the machine learning techniques. The error for the median model is not shown in Figure 3. A relative error of approximately 30% was observed for all fractions of the model. Three machine learning models performed equally well. Gaussian process regression, partial least square regression and partial least square regression with power transformation showed a relative error below 3%. These results were obtained together with the skeleton spheres descriptor.

Figure 4 shows the results for the sp3-atoms with the shuffled data. The results were similar to the predicted molecular weight in 3. Relative error was higher than for the molecular weight prediction, but all models were better than the median model. In contrast to the molecular weight prediction, all three descriptors performed equally well for the models with the lowest error.

The predictions for cLogP, draw a different picture than the predictions for molecular weight and number of sp3-atoms, Figure 5. Only one model showed a relative error below 20%. Many models were worse than the median model, indicated in green. The best performing machine learning models were partial least square regression and Gaussian process regression.

The prediction for shuffled data did not require extrapolation. The data range of the response values is covered by the training data. To simulate the requirements of drug discovery, the datasets were sorted by their response values. In the following, we discuss the results for sorting from high to low response values. This experimental set up forced the machine learning algorithms into extrapolation. The range of predicted response values was always outside the range of the training data. Figure 6 shows the results for the prediction of molecular weight. The data were sorted from high to low.

As for the molecular weight prediction for shuffled data, the skeleton spheres descriptor together with partial least square regression, partial least square regression with power transformation and Gaussian process regression delivered the most predictive models. The range of the relative errors was very large, below 10% for the best models up to 50% for the kNN models with the skeleton spheres descriptor, depicted in red triangles. But, relative errror was higher for all predictions than for the shuffled data. For the shuffled data, only one prediction was above a relative error of 0.1, with the kNN model at a fraction of 0.2. For the high to low sorted molecular weight data the majority of predictions showed a relative error above 0.1.

Two trends were observed for the prediction of number of sp3-atoms, Figure 7. The relative error of the median prediction increased with an increasing fraction of data used to construct the models. This also happened with the relative error for the kNN models, in red, and the random forest, in magenta. The relative error for Gaussian process regression, partial least squares, partial least squares with power transformation and support vector regression remained almost constant. As for molecular weight, the predictions for high to low sorted data had a much higher relative error than predictions for sorted data.

Figure 8 shows the results for cLogP. Data were sorted from high to low. Curve progression was similar to the curve progression of the relative error for the sp3-atom number prediction. However, the values for the relative error are much higher. Only four predictions had relative errors less than 100%.

When molecular weight values were sorted from low to high, the values to be predicted were higher than the values used for model construction. For the molecular weight prediction, the results are depicted in Figure 9. The skeleton spheres descriptor resulted in models with the lowest relative error. In the figures, the skeleton spheres descriptor is indicated by triangles. For the prediction of the number of sp3-atoms in Figure 10 the models constructed from the path fingerprint were better than the models constructed from the skeleton spheres descriptor. As for the high to low sorted values in Figure 7, the path fingerprint was the best performing descriptor. Also, for cLogP value prediction, given in Figure 11, the path fingerprint was the best performing descriptor.

For each of the experimental set ups, including 243 individual datasets, all machine learning algorithms outperformed median predictions, which were used as baseline controls. kNN regression and random forest regression were very similar in their prediction quality. These two algorithms were outperformed by support vector regression. The best performing machine learning algorithms were Gaussian process regression, partial least square regression and partial least square regression with power transformation. Together with the path fingerprint and the skeleton spheres descriptor, the best results were obtained. The relative errors for the successive predictions were lower for the low to high sorted values than for the high to low sorted values. This was caused by numeric effects, the absolute prediction error for big values results in a lower relative error than the same absolute prediction error for small values.

Prediction of molecular weight, random shuffling.

Prediction of molecular weight, random shuffling, skeleton spheres descriptor. The first column indicates the machine learning algorithm. The first row is the fraction of data used for model construction. The other values are the relative errors of the test data.

sp3-atoms, random shuffling.

cLogP, random shuffling.

Molecular weight, high to low sorted response values.

Number of sp3-atoms, high to low sorted response values.

cLogP, high to low sorted response values.

Molecular weight, low to high sorted response values.

Number of sp3-atoms, low to high sorted response values.

cLogP, low to high sorted response values.

## Section: Results Summary and Conclusion

All results are summarized in Tables 3–5. The figure of merit was the rank of the median error. For every successive fraction of test data, a median error was calculated from the nine molecule datasets S apix,1–3 , S rosu,1–3 and S sofo,1–3 . By using the ranks of the errors, a bias was prevented, which would have been otherwise introduced by the error dependency on the fraction of training data. Because, a higher fraction of training data generally results in better models. This would have resulted in a bias if the median would have been used. By using the ranks the results for different fractions of training could be combined. In Tables 3–5, the frequency of the top three ranks is given. This means, the rank count increased by one, if the corresponding error belonged to the three lowest errors for the given conditions. Results for the machine learning algorithms are provided in Table 3. For shuffled response data, Gaussian process regression delivered the highest number of top models 9) for prediction. For extrapolation, for high to low sorted and for low to high sorted data, the partial least square regression outperformed the other machine learning algorithms. That the linear method outperformed the non-linear method is in accordance with the results from (Cortés-Ciriano et al., 2018), where the linear method, ridge regression, also outperformed the non-linear method, random forest.

Results for the descriptors are provided in Table 4. In total, the skeleton spheres descriptor outperformed the other two descriptors. However, the path fingerprint slightly outperformed the skeleton spheres descriptor for extrapolation for the high to low sorted response values. Table 5 presents the rank counts for the most accurately predicted response values. As expected, the best models were obtained for molecular weight, followed by the number of sp3-atoms.

The purpose of this study was to examine the difference between prediction in the range of the training response values and extrapolation outside the training response values. It must be considered that the molecules in each dataset were derived from a single molecule. Consequently, there was a high similarity between molecules in a dataset. All molecules in this examination were in the domain of applicability. They were similar to the training molecules in descriptor space. Nevertheless, the differences between the relative errors for the shuffled data and sorted data were striking. Even for molecular weight, with a very low error for shuffled data, the extrapolation for high to low sorted data became much more difficult. This was unexpected, because molecular weight depends solely on the molecular formula and does not need any molecular graph dependent feature. In addition, the relation between the molecular formula and molecular weight is strictly linear. cLogP values were hardest to predict. Prediction was achieved with a moderate error for shuffled data using linear regression techniques. However, after sorting the response values from high to low and successively extrapolating the lower values, no meaningful prediction for cLogP was possible. None of the machine learning algorithms were able to extrapolate cLogP values for high to low sorted data. This result was unexpected because the cLogP model is an incremental model that relies on substructure contributions to the overall cLogP. Therefore the contributions are linear and theoretically can be modelled by linear regression with chemical descriptors. We had expected, that the linear regression algorithms would be able to create “semi-mechanistic” models with more predictive power. There is a high demand in drug discovery for extrapolation of molecular features. The results of this study show large differences in prediction quality between interpolation and extrapolation. This demonstrates that any model used for extrapolation should be validated with extrapolation. For this validation, we suggest the successive prediction as described in this contribution. We suggest to add the prediction of calculated values as reference standard to all publications in cheminformatics when regression methods are applied. Partial least square regression was by far the most successful extrapolation method. The successful extrapolation of molecular features show that partial least square regression is capable of providing meaningful models for extrapolation.

Summary of the best results for the machine learning techniques. Rank count for the top three ranks. The ranks were calculated from all descriptors, predicted properties, and fractions of training data. The columns show the three different orientations of the response data: shuffled, sorted from high to low and from low to high.

Summary of the best results for the three descriptors. Rank count for the top three ranks. The ranks were calculated from all methods, predicted properties, and fractions of training data.

Summary of the best results for the three response datasets. Rank count for the top three ranks. The ranks were calculated from all descriptors, methods, and fractions of training data.


---

# Machine Learning guided early drug discovery of small molecules

- **Authors:** Nikhil Pillai, Aparajita Dasgupta, Sirimas Sudsakorn, Jennifer Fretland, Panteleimon D Mavroudis
- **Issuer:** Drug discovery today
- **Type:** Scientific article
- **Published:** 2022-03-29
- **Language:** en
- **DOI:** 10.1016/j.drudis.2022.03.017
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35364270/
- **Licence:** CC-BY

## Section: Abstract

Machine learning (ML) approaches have been widely adopted within the early stages of the drug discovery process, particularly within the context of small-molecule drug candidates. Despite this, the use of ML is still limited in the pharmacokinetic/pharmacodynamic (PK/PD) application space. Here, we describe recent progress and the role of ML used in preclinical drug discovery. We summarize the advances and current strategies used to predict ADME (absorption, distribution, metabolism and, excretion) properties of small molecules based on their structures, and predict structures based on the desired properties for molecular screening and optimization. Finally, we discuss the use of ML to predict PK to rank the ability of drug candidates to achieve appropriate exposures and hence provide important insights into safety and efficacy.


---

# Machine Learning in Antibacterial Drug Design

- **Authors:** Marko Jukič, Urban Bren
- **Issuer:** Frontiers in pharmacology
- **Type:** Scientific article
- **Published:** 2022-05-03
- **Language:** en
- **DOI:** 10.3389/fphar.2022.864412
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35592425/
- **Licence:** CC-BY

## Section: Abstract

AbstractAdvances in computer hardware and the availability of high-performance supercomputing platforms and parallel computing, along with artificial intelligence methods are successfully complementing traditional approaches in medicinal chemistry. In particular, machine learning is gaining importance with the growth of the available data collections. One of the critical areas where this methodology can be successfully applied is in the development of new antibacterial agents. The latter is essential because of the high attrition rates in new drug discovery, both in industry and in academic research programs. Scientific involvement in this area is even more urgent as antibacterial drug resistance becomes a public health concern worldwide and pushes us increasingly into the post-antibiotic era. In this review, we focus on the latest machine learning approaches used in the discovery of new antibacterial agents and targets, covering both small molecules and antibacterial peptides. For the benefit of the reader, we summarize all applied machine learning approaches and available databases useful for the design of new antibacterial agents and address the current shortcomings.Keywords: artificial intelligence, machine learning, computer-aided drug design (CADD), infectious diseases, antibacterial drug design, antibacterial, antibacterial target discovery, antibacterial drug resistance

## Section: Introduction

Modern antibacterial drug development currently notes a lack of novel antibacterial classes, an observation that is critical in the context of antibacterial drug resistance (Brown and Wright, 2016). Furthermore, not only single-drug resistance but also multiple-drug antibiotic resistance (MDR) has been observed in clinically relevant pathogens worldwide, rendering current established therapies ineffective (Laxminarayan et al., 2020; Vila et al., 2020). The annual number of deaths caused by infections with resistant pathogens alone is currently high and is expected to reach into millions by 2050, making high-quality data collection and reporting and antibacterial research essential (de Kraker et al., 2016; Matamoros-Recio et al., 2021). Recent advances in Computer-aided drug design (CADD) coupled with parallel and high-performance computing (HPC) platforms and new in silico methods represent a new paradigm for antibacterial drug discovery. In particular, machine learning methods have the potential to increase the accuracy of high-throughput virtual screening using ligand-based, structure-based, or consensus-based approaches (Serafim et al., 2020). It should be noted that modern software implementations of machine learning algorithms efficiently utilize computer hardware and are ideal for the bioinformatics or chemoinformatics scenario; however, extreme care should be taken with input data (Bzdok et al., 2017). Most importantly, the increasing availability of data makes machine learning methods even more important, either as a stand-alone method or in a consensus scenario where they can boost traditional medicinal chemistry approaches (He et al., 2021). In this review, we focus on machine learning approaches in CADD that have been reported in recent years and have been used in the development of novel antibacterials. We summarize the relevant databases and consolidate the general workflow along with the methods used in Figure 1.

Common machine learning methodology in novel antibacterial drug design and a typical modeling workflow. ANN, artificial neural network; DT, decision tree; FSC, feedback system control; HTVS, high-throughput virtual screening; kNN, k-nearest neighbors; LBVS, ligand-based virtual screening; LOR, logistic regression; (M)LR, (multiple) linear regression; NB, naïve Bayes; QSAR, quantitative structure–activity relationship; RF, random forest; SBVS, structure-based virtual screening; SCM, set covering machine; SVM, support vector machines.

## Section: Relevant Databases for Antibacterial Drug Design

The currently accessible libraries of antibacterial compounds are enlisted that include small molecules or peptides that can be used for the design of new antibacterial agents and model development (Table 1). The reader should also be aware of tailored or focused libraries and antibacterial libraries offered by commercial compound suppliers and complete online antibacterial drug discovery communities (CO-ADD; of special mention is that the industry also contributes to the CO-ADD community, or previously SPARK-database). The ChEMBL bioinformatics platform is by far the most comprehensive resource (especially considering small molecules), followed by CO-ADD (SPARK) and antimicrobial index. Databases supporting antibacterial peptides are far more common and offer quality data.

Currently available antibacterial compound and peptide databases suitable for in silico drug design.

## Section: Small Molecules

To utilize machine learning approaches in the design of antibacterial small molecules and test different machine learning approaches, Yang et al. computed a simple set of molecular descriptors for small molecules with and without antibacterial properties and evaluated the decision tree, k-nearest neighbor, and support vector machine (SVM) classification models. The authors noted the good accuracy of the SVM approach and the applicability of the methodology for antibacterial drug design. Developed models produced the best prediction accuracies of 96.66 and 98.15% for antibacterial compounds and 99.50 and 98.02% for non-antibacterial compounds (Yang et al., 2009). Ivanenkov et al. (2019) compiled a database of 145,000 small molecules, most of which came from a proprietary high-throughput screening campaign with Escherichia coli (E. coli; 1,786 active and 130,855 inactive compounds; all data points were obtained under the same experimental conditions). 1243 molecular descriptors were calculated using Dragon, ChemoSoft, MOE, and SmartMining software tools. Subsequently, self-organizing maps (Kohonen maps) were used for classification and prediction of antibacterial activity with SmartMining software, and good results were obtained (predictive power of 75.5% on average). The developed models were deployed to identify new agents against E. coli (compound 9, Figure 2). Maltarollo (2019) focused on Staphylococcus aureus (S. aureus), specifically FabI inhibitors. 166 literature compounds were collected and molecular descriptors and fingerprints were calculated using PaDEL software. Decision trees (DTs), random forests (RF), multilayer perceptron (MLP), k-nearest neighbors (kNN), Naive Bayes (NB), and support vector machine (SVM) models were trained for classification. RF models performed best in classifying known connections.

Shi et al. collected a database of New Delhi metallo beta-lactamase (NDM-1) inhibitors (511 compounds) from the literature (Shi et al., 2020). This was followed by the calculation of molecular descriptors (34 descriptors, MOE software) and the representation of SMILES strings padded with zeros up to a length of 550. Different methods were tested, such as RF, SVM, and linear discriminant analysis. Finally, it was decided to use the RF model, which performed much better than the classical virtual screening model (90.5 and 69.14%, respectively). The model was used to predict potential NDM-1 inhibitors from a natural product library that contained 2,172 compounds (compound 1, Figure 2). The authors noted that the deep-learning method was not very powerful because of low data availability. Li et al. approached in a more general manner using more data points from the ChEMBL database (Li et al., 2021). The group collected a library of 2708 active antibacterial compounds (IC50 cut-off of 10 μM) and 78,620 inactive compounds and proceeded to calculate fingerprints (FP2, FP3, FP4, DLFP, MACCS, ECFP2, ECFP4, ECFP6, FCFP2, FCFP4, and FCFP6) and vector representations (mol2vec, SMILES2Vec, FP2VEC software; Jaeger et al., 2018; Öztürk et al., 2018; Jeon and Kim, 2019). Several machine learning methods were reviewed, and the FP2 database along with RF, SVM, and MLP methods was selected for screening (scikit-learn library; average accuracy of 0.85). The team then constructed a predictor for antibacterial agents based on all three models and applied it to the FDA-approved small-molecule database (DrugBank, Wishart et al., 2018). Of interest is the observed low FP2 similarity (<0.2) between the predicted and FDA-approved antibacterial agents. The group focused on the nine most different predicted compounds from the FDA antibacterials with the highest screening scores in all three models; however, it did not follow up with biological evaluation. The identified compounds belonged to the classes of anticancer drugs, ocular antihypertensives, and general anesthetics, with enflurane scoring the highest. Enflurane was previously demonstrated to possess antibacterial properties in vitro (enflurane, Figure 2).

The superiority of machine learning–assisted molecular docking was reported by de Avila et al. (2018). The group collected a database of 22 structurally supported 3-dehydroquinate dehydratase (DHQD) inhibitors with measured inhibition constants. They developed a new polynomial scoring function with selected energy terms from classical scoring functions. Using Sandres software (Lasso and Ridge Regression), the newly developed scoring functions performed significantly better in the DHQD system test set supplemented by decoy compounds (the group did not further deploy the model).

Mansbach et al. focused on the permeation of Gram-negative bacteria and developed a fragment-based approach. They collected a database of compounds with MIC values in Pseudomonas aeruginosa (P. aeruginosa) and calculated fragment-based molecular representations for sparse regression and hierarchical clustering to identify the most relevant fragments thought to influence antibacterial activity (Mansbach et al., 2020). The method was used to predict new compounds with antibacterial properties and design “hybrid” molecules from multiple fragments (OU-457, Figure 2). Predicted molecules were experimentally evaluated.

Interestingly, an approach combining both antibacterial small molecules and antimicrobial peptides in a heterogenous library was reported by Nava Lara et al. (2019). To identify compounds with antimicrobial activity in the intestinal flora, 1444 descriptors were calculated (Padel Descriptor software) and 52 different machine learning algorithms were tested (WEKA, AutoWEKA software) to finally select a random committee algorithm classifier with receiver operating characteristic (ROC) area under the curve (AUC) performance of 0.83 for the classification. The model was applied to the FDA-approved antimicrobial agents and found that almost half of them had potential broad-spectrum activity against intestinal bacteria; however, the predictions were not experimentally substantiated. Since antibacterial peptides make up a large proportion of antibacterial chemical substances, they are discussed in more detail in the section Antibacterial Peptides.

Mycobacteria infections are a significant public health problem worldwide. The development of novel antimycobacterial agents remains a challenge, especially in light of the increasing emergence of multidrug-resistant strains of mycobacteria. Several reviews have been published collecting the main therapeutic targets in this field and highlighting the importance of in silico methods, particularly promoted by machine learning approaches and focusing on cell-wall permeability studies (Aleksandrov and Myllykallio, 2019; Pushkaran et al., 2019; Ejalonibu et al., 2021). In this way, classical approaches of virtual screening against the mycobacterial target PrpR (Vina, Glide software), MMGBSA, and molecular dynamics (MD) studies on hit compounds were complemented by the MycoCSM method to identify novel benzimidazole derivatives as potential PrpR inhibitors (compound 1p, Figure 2; Rajasekhar et al., 2021). MycoCSM is a graph-based DT model (scikit-learn library) based on 15,000 unique compounds (featurized with RDkit descriptors) with activity against bacteria of the genus Mycobacterium (MIC cut-off of 1 μM), achieving correlation coefficients of up to 0.89 in predicting bioactivity in terms of minimum inhibitory concentration (Pires and Ascher, 2020).

Korbee et al. used predictive clustering trees (PCTs) to explore host-directed pathways toward antimycobacterial drug design (Clus software; https://sourceforge.net/projects/clus/). The group deployed their models on a library of pharmacologically active compounds in a (LOPAC)-based drug-repurposing screen to identify experimentally validated compounds which target receptor tyrosine kinases (RTKs) and inhibit intracellular mycobacteria (SU-6656, Figure 2) and salmonellae (haloperidol, Figure 2; Korbee et al., 2018).

Antibacterial compounds identified by machine learning boosted in silico methods in CADD.

## Section: Natural Compounds

Prediction of antibacterial activity while considering molecular structure and metabolic reaction networks was also attempted by Nocedo-Mena et al. (2019) (dataset: Jeong et al., 2000). The metabolic reaction network data were merged with compounds with MIC properties in ChEMBL, and machine learning modeling with multi-output perturbations was used to build predictive models. The models were deployed to identify natural antibacterial compounds from C. incisa (phytol, Figure 2).

The natural compounds were further explored by Masalha et al., (2018). The group assembled a library of 628 antibacterial compounds (Comprehensive Medicinal Chemistry Database) along with an inactive set of 2892 natural compounds (AnalytiCon Discovery GmbH database) and proceeded to calculate molecular descriptors (MOE software). An iterative indexing model based on stochastic elimination was created for discriminative filtering and antibacterial identification via the calculated molecular bioactivity index (Rayan et al., 2010). The model ROC AUC for antibacterial classification was 0.96, and the model was deployed for screening of the natural product database to identify 10 potential antibacterial hits, two of which were experimentally confirmed as active and others are still under research (glucosinalbin, Figure 2). It is interesting to note that the authors found that comparable performance could not be achieved with either structure-based or ligand-based approaches due to non-efficient scoring or the number of false-positives.

Another report focused on marine natural sources to identify new compounds with activity against MRSA (Dias et al., 2019). Construction of a database of 6645 small molecules (ChEMBL, PubChem, ZINC; active molecules with MIC <5 μM and inactive molecules with MIC ≥5 μM) was followed by a calculation of a comprehensive list of molecular descriptors and fingerprints (PaDEL and CDK Descriptor Software) to finally build a regression model using RF, SVM, Gaussian processes (GPs), and consensus approaches for pMIC determination against MRSA. The best consensus model (R 2 of 0.68) was deployed on the StreptomeDB database and resulted in 150 hits with 12 prioritized compounds, all with confirmed anti-MRSA experimental activity (AGN-PC-07NPF8H, Figure 2). The same group also reported a nuclear magnetic resonance (1H and 13C NMR)–based approach where compounds were featurized using experimental NMR-spectra assignation data. The compound library was a dataset of 155 samples that included 50 crude extracts, 55 fractions, and 50 pure compounds obtained from microbial actinobacteria isolated from marine sediments off the Madeira archipelago. RF, SVN, and convolutional neural network (CNN) models were generated with an accuracy of 0.77 for the test set and were ready for further research and application.

Drug similarity identification was also attempted using molecular descriptors and fingerprints calculated using a database from the Current Medicinal Chemistry Database, MDL Drug Data Repot, World Drug Index (drug-like molecules), and Available Chemicals Directory for non–drug-like molecules (180,000 compounds in total). Naive Bayesian classifiers and recursive partitioning models were developed and used for drug similarity prediction in the Traditional Chinese Medicine Compound Database (TCMD) (Tian et al., 2012). The research found that the classifiers can successfully provide valuable information in the early stages of drug design (drug-like compound identification accuracy of 0.86) and identify important drug-like scaffolds and even classify them by pharmacological activity, for example, label scaffolds of antibacterial compounds (BE-52211D, Figure 2).

Indeed, natural compounds represent an invaluable source of chemical diversity, and their drawbacks (availability, complexity, synergistic pharmacodynamics) in drug development could be mitigated by modern machine learning methods (Rodrigues et al., 2016). To this end, Zhang et al. have collected several machine learning protocols for activity prediction of natural products (Zhang et al., 2021).

## Section: Antibacterial Peptides

An important subfield of the discovery of new antibacterials is also the discovery of antibacterial peptides. The latter can serve as active agents, starting points for the design of peptidomimetics, or probes for further studies. The field and in silico tools have been reviewed previously (Lee et al., 2017; Cardoso et al., 2020; Wang et al., 2021), with the emphasis on machine learning–enabled antimicrobial peptide discovery and SVM for the discovery of membrane-active peptides (Lee et al., 2018). However, Frecer reported a successful design of cationic antibacterial peptides derived from protegrin-1 as early as 2006 (Frecer, 2006), and machine learning methodology contributed significantly to the design and discovery of novel peptides, as demonstrated by Fjell et al. To single out just one report, they reinforced the traditional QSAR approach with an artificial neural network model (ANN) that inferred a set of peptides with known antibacterial properties from computed descriptors (MOE software). After deploying the model in a screening scenario (in silico library with random peptides), short cationic peptides with MICs in the range of 0.3–10 μM were identified (Fjell et al., 2009). The extended research group later reported an interesting approach for relational learning algorithms (RelF and WEKA software for regression) to explore patterns from the relational structures of the antibacterial peptides or an approximate attribute-value representation of the peptides (Szaboova et al., 2012). Feature vectors for peptide representation were also usedusing Chou’s pseudo-amino acid composition (PseAAC), and the SVM was successfully used to classify antibacterial peptides (Khosravian et al., 2013).

The later approaches were also extended beyond antibacterial peptide identification to peptide target selectivity or prediction of Gram-positive or Gram-negative activities (Veltri et al., 2015). The group used an evolutionary feature construction and a fast correlation-based filter selection algorithm with logistic regression (WEKA) to successfully identify antibacterial peptides of up to 11 amino acids in length. The same group used APD3 database, converted peptide sequences into zero-padded numerical vectors of length 200, and trained a deep neural network (DNN; Keras, TensorFlow software) model to classify antimicrobial peptides (accuracy of 0.98 on APD3 data). Embedding vector visualization was also performed, and a reduced alphabet learnt from the DNN model was developed. Reduced sequence space retained good classification performance (Veltri et al., 2018). Müller et al. trained a recurrent neural network (RNN) with helical antimicrobial peptides (1554 peptides, APD). The sequences were padded according to the length of the longest sequence, N-terminal token added, and One-hot encoding employed (Müller et al., 2018). The resulting model was developed for de novo sequence generation, where 82% were predicted to be active antimicrobial peptides compared to 65% of randomly sampled sequences with the same amino acid distribution as the training set (CAMP AMP prediction tool; Waghu et al., 2014). Wu et al. used previous amino acid substitution data for antibacterial peptides and developed an amino acid activity contribution matrix (Wu et al., 2014). Using this methodology, the group developed a 12-mer DP7 peptide with antibacterial properties against multiple strains (Zhang et al., 2019). Similarly, Yoshida et al. used a natural antibacterial peptide Temporin-Ali (FFPIVGKLLSGLL-NH2) and PSI BLAST to create a library of distantly related and functionally similar sequences, prepared the peptides, and evaluated their antibacterial activities in vitro on E. coli to construct a fitness matrix. The data were then used to train a model and deploy it to optimize peptide sequences. The group produced a peptide with 163-fold lower activity on E. coli bacteria (Yoshida et al., 2018). Another approach using rough set theory constructed quantitative structure–activity relationship rules for existing antibacterial peptides. New sequence development via a genetic algorithm and further in vitro testing resulted in a peptide being active against Staphylococcus epidermidis (S. epidermidis) (Boone et al., 2021).

Approaches were again extended by considering toxicity data in the development of novel antibacterial peptides intended for human drug development campaigns. Capecchi et al. used the Database of Antimicrobial Activity and Structure of Peptides (DBAASP; 4774 active peptides with an MIC threshold of 32 mg/ml) to train a recurrent neural network (RNN) generative model to develop nonhemolytic antibacterial peptides with activity against P. aeruginosa, Acinetobacter baumannii (A. baumannii), MRSA, and a broader range of MDR strains. To test the performance of machine learning models for antibacterial peptide design, Wani et al. trained models on a database of antibacterials (2638) and inactive peptides (3700) using RF, kNN, SVM, DT, NB, quadratic discriminant analysis (QDA), and ensemble learning. RF models were found to perform best in validation experiments. The group also highlighted three important peptide descriptors as essential for antibacterial activity, namely, charge, polarity, and pseudo-amino acid composition (Wani et al., 2021). The field of in silico tools for designing antibacterial peptides using machine learning is also gaining traction, and targeted tools such as AMPGAN v2 are being developed (Van Oort et al., 2021). AMPGAN v2 is a bidirectional conditional generative adversarial network (BiCGAN) that targets de novo generation of antibacterial peptides. The group used training data by compiling the Database of Antimicrobial Activity and Structure of Peptides (DBAASP), Antiviral Peptide database (AVPdb), and UniProt databases (Apweiler et al., 2004; Gogoladze et al., 2014; Qureshi et al., 2014).

## Section: Antibacterial Drug Resistance

Machine learning approaches are also being used to combat antibiotic resistance. Back in 2017, Macesic et al. published a review of antibacterial susceptibility testing using genotype–phenotype prediction, machine learning approaches to identify resistant strains, and the use of machine learning to improve treatment and optimize clinical approaches to MDR infections (Macesic et al., 2017). Interestingly, the authors lamented data abstraction and quality but pointed out that the methodology gains strength with the availability of quality data. A recent review article discusses several bioinformatics approaches involving machine learning that are useful for studying bacterial resistance, such as the use of modern bioinformatics approaches for the interpretation of data from increasing sequencing libraries; study of protein structures; in silico analysis of serovar, serogroup, and antigen markers; the development of in silico plasmid detection methods; in silico identification of resistance genes; antibacterial surveillance; and in turn, the prediction of the evolution of antibacterial drug resistance (Ndagi et al., 2020). In addition, machine learning approaches have been used beyond resistance prediction using genomic data to elucidate resistance mechanisms and for antibacterial stewardship applications. The latter are mainly concerned with patient data analysis, diagnosis, treatment, and prevention of resistance development in a clinical scenario (Anahtar et al., 2021). With the increasing use of antibiotics and the accompanying bacterial resistance, we cannot overemphasize the importance of these new approaches in translational research. Furthermore, the power of reported methods is increasing with the growth of quality data and availability of curated and resistance-focused libraries such as Plasmid ATLAS by Jesus et al., (2019), Ensembl Genomes (Bacteria) by Yates et al., (2022), BacDive by Reimer et al., (2019), Virulence Factor Database VFDB by Chen et al., (2005), Beta-Lactamase Database (BLDB) by Naas et al., (2017), Antibiotic Resistance Genes Database (ARDB, Liu and Pop, 2009), BacMed (Pal et al., 2014), and Comprehensive Antibiotic Resistance Database (CARD, McArthur et al., 2013 and Alcock et al., 2020).

## Section: Modern Approaches

As reviewed already by Durrant and Amaro in 2014 (Durrant and Amaro, 2015) up to now, the medicinal chemistry community and pharmaceutical industry are adopting machine learning techniques in medicinal chemistry and drug design in general (Ekins et al., 2019) and antibacterial drug development (Patel et al., 2020; Serafim et al., 2020). Of special mention would be the acknowledgment of enormous data availability, its application toward drug design (Burki, 2020), and utilization of modern artificial intelligence approaches (David et al., 2021). Specifically, the applications of modern deep learning methods in antibacterial drug design are evident from a multitude of published reports in scientific literature, tailored offerings by commercial drug design software developers, and emergence of deep-learning in drug design–focused CROs and start-ups (Schroedl, 2019; Chang et al., 2019; Gupta et al., 2021; da Silva et al., 2021).

## Section: Modern Approaches › Deep-Learning and Artificial Neural Networks

An excellent example of the development and use of deep learning supervised, semi-supervised, or unsupervised models in the area of novel antibacterial drug development and discovery was recently reported (Stokes et al., 2020). The group initially generated the dataset by computing graph representations, Morgan fingerprints, and molecular features computed using RDKit (internal training set of 2560 compounds, 120 positive controls; with a test set: Broad’s Drug Repurposing Hub of 6111 compounds) and used a Directed Message Passing Neural Network (D-MPNN; Chemprop implementation available on Github), a type of graph convolutional neural network for model development. After prioritization by toxicity prediction, the authors identified one promising new antibiotic, halicin (SU -3327, Figure 2), and eight (ZINC000098210492, ZINC000001735150, ZINC000225434673, ZINC000019771150, ZINC000004481415, ZINC000004623615, ZINC000238901709, and ZINC000100032716) other potential antibiotic candidates and experimentally validated the obtained hits to have an antibiotic activity on E. coli.

## Section: Modern Approaches › K-Nearest Neighbor

kNN is a supervised learning method that can be applied for classification and regression tasks and is effectively utilized in medicinal chemistry for novel antibacterial drug design. A classification application of kNN was reported by Karakoc et al. for classification of small molecules based on selecting the most relevant set of chemical descriptors used for ultimate discrimination between active and inactive compounds on various biological systems (Karakoc et al., 2007). A comprehensive list of kNN applications in classification and regression tasks all applied toward drug delivery for infectious disease treatment, treatment regimen optimization, drug delivery system and administration route design, and drug delivery outcome prediction was reported by He et al. (2021).

## Section: Modern Approaches › Support Vector Machines

SVM supervised learning models are also widely applied for classification, regression, and ranking/virtual screening tasks in medicinal chemistry in a range of fields such as novel anticancer research, design of antivirals, protein–protein interaction research etc. (Romero-Molina et al., 2019). Focusing on antibacterial drug design, Li et al. reported SVM model development from the fingerprint-featurized ChEMBL database in order to identify novel antibacterial compounds (Li et al., 2021). SVM model applications in antibacterial design and antibacterial drug resistance research were reviewed by Serafim et al. (2020). In a broader scope, recent advances in SVMs and their numerous drug discovery applications are summarized by Maltarollo et al. (2019).

## Section: Modern Approaches › Random Forest and Decision Trees

RF is a supervised ensemble learning method that consists of a multitude of decision trees, constructed at a training phase. Upon reviewing literature on novel antibacterial design supported by machine learning, RF models were found to be one of the most commonly applied for classification, regression, and other tasks and represent a performance and computationally lean approach. In this review, a number of RF applications are presented, for small molecules, peptides (Bhadra et al., 2018), natural product–based antibacterial design, and studying antibacterial drug resistance (Dias et al., 2019; Maltarollo et al., 2019; Shi et al., 2020; Li et al., 2021; Wani et al., 2021). A good example of underlying supervised learning DT method was reported by Suay-Garcia et al. (2020). The authors created a QSAR model to predict antibacterial activity against E. coli. The compounds were classified using a tree-based method and linear discriminant analysis. A comprehensive review on other DT applications is also provided by Serafim et al., (2020).

## Section: Modern Approaches › Coupling to Big Data

Needless to say, we must emphasize the coupling of modern machine learning approaches to valuable data sources. Sripriya Akondi et al., (2022) emphasize the use of compound and protein conformational data which in its abundance classifies as big data in all respects. However, common problems with big data sources such as data quality, over-fitting, and difficult or lengthy protocols should be taken in consideration (Motamedi et al., 2022). Taken together, the big data era will walk hand-in-hand with future drug design and will have a significant impact on how to approach a drug discovery campaign (Zhu, 2020; Bhattarai, et al., 2022; Lee et al., 2022). Zhao et al. point out in a wonderful report “10 Vs.” or characteristics that are intrinsic in drug discovery big data that we should be aware of and utilize, namely: volume (size of data), velocity (data growth), variety (lots of data sources), veracity (variable data quality), validity (authenticity of data), vocabulary (aware of the terminology), venue (numerous data platforms), visualization (presentation and patterns in data), volatility (time domain of the data and usefulness time window), and value (associated economic and added value, Zhao et al., 2020).

## Section: Conclusion

In conjunction with antibacterial compound databases (Table 1) and general (big) data sources such as ChEMBL and CO-ADD (SPARK), efficient research in the area of new antibacterial drug design and target identification is possible (Gaulton et al., 2017; Wishart et al., 2018). Incorporating novel machine learning methods can successfully boost the traditional medicinal chemistry approaches, and this review highlights a host of applications and machine learning model deployments. The examples include synthetic and natural small molecules, as well as peptides, ranging from a narrow spectrum of Gram-positive or Gram-negative bacteria to a broad spectrum of compounds acting on mycobacteria and eventually even MDR bacteria. However, in reviewing the literature, it is immediately apparent that medicinal chemistry is currently still in the introductory phase of exploring modern (and also established) machine learning methods and adapting them to the field. Most of the reports are proof-of-concept works where the models are only deployed to test the data and no experimental biological evaluation is performed. However, the analysis of the best performing featurization approaches and the methods themselves may be even more important takeaways.

Input data is of critical importance, and the available tailored or focused antibacterial data libraries, especially public resources, leave much to be desired. The good availability of antimicrobial peptide data and general relational databases, such as the ones mentioned above, improves the situation. In conclusion, the immense value of modern machine learning methods is obvious—coupled with classical and experimental approaches in medicinal chemistry— and new advances in antibacterial drug design and mode of action research are possible.

## Section: Author Contributions

MJ and UB interpreted the data from the literature. MJ and UB wrote the original draft. MJ and UB reviewed, edited, and drafted the manuscript and approved the final version.

## Section: Funding

This work was supported by the Slovenian Ministry of Science and Education infrastructure project grants HPC-RIVR and RI-SI-ELIXIR and by the Slovenian Research Agency (ARRS) program and project grants P2-0046, J1-2471, J1-1715, N1-0209, P1-0403, L2-3175 and J1-9186.

## Section: Conflict of Interest

The authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.

## Section: Publisher’s Note

All claims expressed in this article are solely those of the authors and do not necessarily represent those of their affiliated organizations, or those of the publisher, the editors, and the reviewers. Any product that may be evaluated in this article, or claim that may be made by its manufacturer, is not guaranteed or endorsed by the publisher.

## Section: Abbreviations

AI, artificial intelligence; ANN, artificial neural network; CADD, computer-assisted drug design; DT, decision tree; FSC, feedback system control; kNN, k-nearest neighbors; LOR, logistic regression; (M)LR, (multiple) linear regression; MDR, multidrug resistant; MIC, minimum inhibitory concentration; MRSA, methicillin-resistant Staphylococcus aureus; NB, naïve Bayes; RF, random forest; RiPPS, ribosomally synthesized and posttranslationally modified peptides; SCM, set covering machine; SVM, support vector machines.


---

# Masked Autoencoders Are Scalable Vision Learners

- **Authors:** Kaiming He, Xinlei Chen, Saining Xie, Yanghao Li, Piotr Dollár, Ross Girshick
- **Issuer:** IEEE Computer Society Conference on Computer Vision and Pattern Recognition/Proceedings - IEEE Computer Society Conference on Computer Vision and Pattern Recognition/Proceedings
- **Type:** Scientific article
- **Published:** 2022-06-01
- **Language:** en
- **DOI:** 10.1109/cvpr52688.2022.01553
- **Source:** https://doi.org/10.1109/cvpr52688.2022.01553
- **Licence:** CC-BY

## Page 1

Masked Autoencoders Are Scalable Vision Learners
Kaiming He∗,†
Xinlei Chen∗
Saining Xie
Yanghao Li
Piotr Doll´ar
Ross Girshick
∗equal technical contribution
†project lead
Facebook AI Research (FAIR)
Abstract
This paper shows that masked autoencoders (MAE) are
scalable self-supervised learners for computer vision. Our
MAE approach is simple: we mask random patches of the
input image and reconstruct the missing pixels. It is based
on two core designs.
First, we develop an asymmetric
encoder-decoder architecture, with an encoder that oper-
ates only on the visible subset of patches (without mask to-
kens), along with a lightweight decoder that reconstructs
the original image from the latent representation and mask
tokens. Second, we ﬁnd that masking a high proportion
of the input image, e.g., 75%, yields a nontrivial and
meaningful self-supervisory task. Coupling these two de-
signs enables us to train large models efﬁciently and ef-
fectively: we accelerate training (by 3× or more) and im-
prove accuracy. Our scalable approach allows for learning
high-capacity models that generalize well: e.g., a vanilla
ViT-Huge model achieves the best accuracy (87.8%) among
methods that use only ImageNet-1K data.
Transfer per-
formance in downstream tasks outperforms supervised pre-
training and shows promising scaling behavior.
1. Introduction
Deep learning has witnessed an explosion of archi-
tectures of continuously growing capability and capacity
[33, 25, 57]. Aided by the rapid gains in hardware, mod-
els today can easily overﬁt one million images [13] and
begin to demand hundreds of millions of—often publicly
inaccessible—labeled images [16].
This appetite for data has been successfully addressed in
natural language processing (NLP) by self-supervised pre-
training. The solutions, based on autoregressive language
modeling in GPT [47, 48, 4] and masked autoencoding in
BERT [14], are conceptually simple: they remove a portion
of the data and learn to predict the removed content. These
methods now enable training of generalizable NLP models
containing over one hundred billion parameters [4].
The idea of masked autoencoders, a form of more gen-
eral denoising autoencoders [58], is natural and applicable
in computer vision as well. Indeed, closely related research
encoder
....
....
decoder
input
target
Figure 1. Our MAE architecture. During pre-training, a large
random subset of image patches (e.g., 75%) is masked out. The
encoder is applied to the small subset of visible patches. Mask
tokens are introduced after the encoder, and the full set of en-
coded patches and mask tokens is processed by a small decoder
that reconstructs the original image in pixels. After pre-training,
the decoder is discarded and the encoder is applied to uncorrupted
images (full sets of patches) for recognition tasks.
in vision [59, 46] preceded BERT. However, despite signif-
icant interest in this idea following the success of BERT,
progress of autoencoding methods in vision lags behind
NLP. We ask: what makes masked autoencoding different
between vision and language? We attempt to answer this
question from the following perspectives:
(i) Until recently, architectures were different. In vision,
convolutional networks [34] were dominant over the last
decade [33]. Convolutions typically operate on regular grids
and it is not straightforward to integrate ‘indicators’ such as
mask tokens [14] or positional embeddings [57] into con-
volutional networks. This architectural gap, however, has
been addressed with the introduction of Vision Transform-
ers (ViT) [16] and should no longer present an obstacle.
(ii) Information density is different between language
and vision. Languages are human-generated signals that
are highly semantic and information-dense. When training
a model to predict only a few missing words per sentence,
this task appears to induce sophisticated language under-
standing. Images, on the contrary, are natural signals with
heavy spatial redundancy—e.g., a missing patch can be re-
covered from neighboring patches with little high-level un-
1
arXiv:2111.06377v3  [cs.CV]  19 Dec 2021

## Page 2

Figure 2. Example results on ImageNet validation images. For each triplet, we show the masked image (left), our MAE reconstruction†
(middle), and the ground-truth (right). The masking ratio is 80%, leaving only 39 out of 196 patches. More examples are in the appendix.
†As no loss is computed on visible patches, the model output on visible patches is qualitatively worse. One can simply overlay the output with the visible
patches to improve visual quality. We intentionally opt not to do this, so we can more comprehensively demonstrate the method’s behavior.
Figure 3. Example results on COCO validation images, using an MAE trained on ImageNet (the same model weights as in Figure 2).
Observe the reconstructions on the two right-most examples, which, although different from the ground truth, are semantically plausible.
derstanding of parts, objects, and scenes. To overcome this
difference and encourage learning useful features, we show
that a simple strategy works well in computer vision: mask-
ing a very high portion of random patches. This strategy
largely reduces redundancy and creates a challenging self-
supervisory task that requires holistic understanding beyond
low-level image statistics. To get a qualitative sense of our
reconstruction task, see Figures 2 – 4.
(iii) The autoencoder’s decoder, which maps the latent
representation back to the input, plays a different role be-
tween reconstructing text and images. In vision, the decoder
reconstructs pixels, hence its output is of a lower semantic
level than common recognition tasks. This is in contrast
to language, where the decoder predicts missing words that
contain rich semantic information. While in BERT the de-
coder can be trivial (an MLP) [14], we found that for im-
ages, the decoder design plays a key role in determining the
semantic level of the learned latent representations.
Driven by this analysis, we present a simple, effective,
and scalable form of a masked autoencoder (MAE) for
visual representation learning. Our MAE masks random
patches from the input image and reconstructs the missing
patches in the pixel space. It has an asymmetric encoder-
decoder design. Our encoder operates only on the visible
subset of patches (without mask tokens), and our decoder is
lightweight and reconstructs the input from the latent rep-
resentation along with mask tokens (Figure 1).
Shifting
the mask tokens to the small decoder in our asymmetric
encoder-decoder results in a large reduction in computation.
Under this design, a very high masking ratio (e.g., 75%) can
achieve a win-win scenario: it optimizes accuracy while al-
lowing the encoder to process only a small portion (e.g.,
25%) of patches. This can reduce overall pre-training time
by 3× or more and likewise reduce memory consumption,
enabling us to easily scale our MAE to large models.
Our MAE learns very high-capacity models that gen-
eralize well. With MAE pre-training, we can train data-
hungry models like ViT-Large/-Huge [16] on ImageNet-1K
with improved generalization performance. With a vanilla
ViT-Huge model, we achieve 87.8% accuracy when ﬁne-
tuned on ImageNet-1K. This outperforms all previous re-
sults that use only ImageNet-1K data. We also evaluate
transfer learning on object detection, instance segmentation,
and semantic segmentation. In these tasks, our pre-training
achieves better results than its supervised pre-training coun-
terparts, and more importantly, we observe signiﬁcant gains
by scaling up models.
These observations are aligned
with those witnessed in self-supervised pre-training in NLP
[14, 47, 48, 4] and we hope that they will enable our ﬁeld to
explore a similar trajectory.
2

## Page 3

original
mask 75%
mask 85%
mask 95%
Figure 4. Reconstructions of ImageNet validation images using
an MAE pre-trained with a masking ratio of 75% but applied on
inputs with higher masking ratios. The predictions differ plausibly
from the original images, showing that the method can generalize.
2. Related Work
Masked language modeling and its autoregressive coun-
terparts, e.g., BERT [14] and GPT [47, 48, 4], are highly
successful methods for pre-training in NLP. These methods
hold out a portion of the input sequence and train models
to predict the missing content. These methods have been
shown to scale excellently [4] and a large abundance of ev-
idence indicates that these pre-trained representations gen-
eralize well to various downstream tasks.
Autoencoding is a classical method for learning representa-
tions. It has an encoder that maps an input to a latent repre-
sentation and a decoder that reconstructs the input. For ex-
ample, PCA and k-means are autoencoders [29]. Denoising
autoencoders (DAE) [58] are a class of autoencoders that
corrupt an input signal and learn to reconstruct the origi-
nal, uncorrupted signal. A series of methods can be thought
of as a generalized DAE under different corruptions, e.g.,
masking pixels [59, 46, 6] or removing color channels [70].
Our MAE is a form of denoising autoencoding, but different
from the classical DAE in numerous ways.
Masked image encoding methods learn representations
from images corrupted by masking. The pioneering work
of [59] presents masking as a noise type in DAE. Context
Encoder [46] inpaints large missing regions using convolu-
tional networks. Motivated by the success in NLP, related
recent methods [6, 16, 2] are based on Transformers [57].
iGPT [6] operates on sequences of pixels and predicts un-
known pixels. The ViT paper [16] studies masked patch
prediction for self-supervised learning. Most recently, BEiT
[2] proposes to predict discrete tokens [44, 50].
Self-supervised learning approaches have seen signiﬁcant
interest in computer vision, often focusing on different pre-
text tasks for pre-training [15, 61, 42, 70, 45, 17].
Re-
cently, contrastive learning [3, 22] has been popular, e.g.,
[62, 43, 23, 7], which models image similarity and dis-
similarity (or only similarity [21, 8]) between two or more
views. Contrastive and related methods strongly depend on
data augmentation [7, 21, 8]. Autoencoding pursues a con-
ceptually different direction, and it exhibits different behav-
iors as we will present.
3. Approach
Our masked autoencoder (MAE) is a simple autoencod-
ing approach that reconstructs the original signal given its
partial observation.
Like all autoencoders, our approach
has an encoder that maps the observed signal to a latent
representation, and a decoder that reconstructs the origi-
nal signal from the latent representation. Unlike classical
autoencoders, we adopt an asymmetric design that allows
the encoder to operate only on the partial, observed signal
(without mask tokens) and a lightweight decoder that re-
constructs the full signal from the latent representation and
mask tokens. Figure 1 illustrates the idea, introduced next.
Masking. Following ViT [16], we divide an image into reg-
ular non-overlapping patches. Then we sample a subset of
patches and mask (i.e., remove) the remaining ones. Our
sampling strategy is straightforward: we sample random
patches without replacement, following a uniform distribu-
tion. We simply refer to this as “random sampling”.
Random sampling with a high masking ratio (i.e., the ra-
tio of removed patches) largely eliminates redundancy, thus
creating a task that cannot be easily solved by extrapolation
from visible neighboring patches (see Figures 2 – 4). The
uniform distribution prevents a potential center bias (i.e.,
more masked patches near the image center). Finally, the
highly sparse input creates an opportunity for designing an
efﬁcient encoder, introduced next.
MAE encoder. Our encoder is a ViT [16] but applied only
on visible, unmasked patches. Just as in a standard ViT, our
encoder embeds patches by a linear projection with added
positional embeddings, and then processes the resulting set
via a series of Transformer blocks. However, our encoder
only operates on a small subset (e.g., 25%) of the full set.
Masked patches are removed; no mask tokens are used.
This allows us to train very large encoders with only a frac-
tion of compute and memory. The full set is handled by a
lightweight decoder, described next.
MAE decoder. The input to the MAE decoder is the full
set of tokens consisting of (i) encoded visible patches, and
(ii) mask tokens. See Figure 1. Each mask token [14] is a
shared, learned vector that indicates the presence of a miss-
3

## Page 4

ing patch to be predicted. We add positional embeddings to
all tokens in this full set; without this, mask tokens would
have no information about their location in the image. The
decoder has another series of Transformer blocks.
The MAE decoder is only used during pre-training to
perform the image reconstruction task (only the encoder
is used to produce image representations for recognition).
Therefore, the decoder architecture can be ﬂexibly designed
in a manner that is independent of the encoder design. We
experiment with very small decoders, narrower and shal-
lower than the encoder. For example, our default decoder
has <10% computation per token vs. the encoder. With this
asymmetrical design, the full set of tokens are only pro-
cessed by the lightweight decoder, which signiﬁcantly re-
duces pre-training time.
Reconstruction target. Our MAE reconstructs the input
by predicting the pixel values for each masked patch. Each
element in the decoder’s output is a vector of pixel values
representing a patch. The last layer of the decoder is a lin-
ear projection whose number of output channels equals the
number of pixel values in a patch. The decoder’s output is
reshaped to form a reconstructed image. Our loss function
computes the mean squared error (MSE) between the recon-
structed and original images in the pixel space. We compute
the loss only on masked patches, similar to BERT [14].1
We also study a variant whose reconstruction target is
the normalized pixel values of each masked patch. Specif-
ically, we compute the mean and standard deviation of all
pixels in a patch and use them to normalize this patch. Us-
ing normalized pixels as the reconstruction target improves
representation quality in our experiments.
Simple implementation. Our MAE pre-training can be im-
plemented efﬁciently, and importantly, does not require any
specialized sparse operations. First we generate a token for
every input patch (by linear projection with an added po-
sitional embedding). Next we randomly shufﬂe the list of
tokens and remove the last portion of the list, based on the
masking ratio. This process produces a small subset of to-
kens for the encoder and is equivalent to sampling patches
without replacement. After encoding, we append a list of
mask tokens to the list of encoded patches, and unshufﬂe
this full list (inverting the random shufﬂe operation) to align
all tokens with their targets. The decoder is applied to this
full list (with positional embeddings added). As noted, no
sparse operations are needed. This simple implementation
introduces negligible overhead as the shufﬂing and unshuf-
ﬂing operations are fast.
1Computing the loss only on masked patches differs from traditional
denoising autoencoders [58] that compute the loss on all pixels.
This
choice is purely result-driven: computing the loss on all pixels leads to
a slight decrease in accuracy (e.g., ∼0.5%).
10
20
30
40
50
60
70
80
90
83
84
85
83.2
83.4
83.4
84.7
84.9
85.0
84.9 84.9
84.5
83.0
fine-tuning
masking ratio (%)
10
20
30
40
50
60
70
80
90
50
60
70
54.6
58.9
61.7
67.0
69.9
71.8
73.2 73.5 71.8
66.1
linear probing
masking ratio (%)
Figure 5. Masking ratio. A high masking ratio (75%) works well
for both ﬁne-tuning (top) and linear probing (bottom). The y-axes
are ImageNet-1K validation accuracy (%) in all plots in this paper.
4. ImageNet Experiments
We do self-supervised pre-training on the ImageNet-1K
(IN1K) [13] training set. Then we do supervised training to
evaluate the representations with (i) end-to-end ﬁne-tuning
or (ii) linear probing. We report top-1 validation accuracy
of a single 224×224 crop. Details are in Appendix A.1.
Baseline: ViT-Large. We use ViT-Large (ViT-L/16) [16]
as the backbone in our ablation study. ViT-L is very big (an
order of magnitude bigger than ResNet-50 [25]) and tends
to overﬁt. The following is a comparison between ViT-L
trained from scratch vs. ﬁne-tuned from our baseline MAE:
scratch, original [16]
scratch, our impl.
baseline MAE
76.5
82.5
84.9
We note that it is nontrivial to train supervised ViT-L from
scratch and a good recipe with strong regularization is
needed (82.5%, see Appendix A.2). Even so, our MAE pre-
training contributes a big improvement. Here ﬁne-tuning is
only for 50 epochs (vs. 200 from scratch), implying that the
ﬁne-tuning accuracy heavily depends on pre-training.
4.1. Main Properties
We ablate our MAE using the default settings in Table 1
(see caption). Several intriguing properties are observed.
Masking ratio. Figure 5 shows the inﬂuence of the mask-
ing ratio. The optimal ratios are surprisingly high. The ra-
tio of 75% is good for both linear probing and ﬁne-tuning.
This behavior is in contrast with BERT [14], whose typical
masking ratio is 15%. Our masking ratios are also much
higher than those in related works [6, 16, 2] in computer
vision (20% to 50%).
The model infers missing patches to produce different,
yet plausible, outputs (Figure 4).
It makes sense of the
gestalt of objects and scenes, which cannot be simply com-
pleted by extending lines or textures. We hypothesize that
this reasoning-like behavior is linked to the learning of use-
ful representations.
Figure 5 also shows that linear probing and ﬁne-tuning
results follow different trends. For linear probing, the ac-
4

## Page 5

blocks
ft
lin
1
84.8
65.5
2
84.9
70.0
4
84.9
71.9
8
84.9
73.5
12
84.4
73.3
(a) Decoder depth. A deep decoder can im-
prove linear probing accuracy.
dim
ft
lin
128
84.9
69.1
256
84.8
71.3
512
84.9
73.5
768
84.4
73.1
1024
84.3
73.1
(b) Decoder width. The decoder can be nar-
rower than the encoder (1024-d).
case
ft
lin
FLOPs
encoder w/ [M]
84.2
59.6
3.3×
encoder w/o [M]
84.9
73.5
1×
(c) Mask token. An encoder without mask to-
kens is more accurate and faster (Table 2).
case
ft
lin
pixel (w/o norm)
84.9
73.5
pixel (w/ norm)
85.4
73.9
PCA
84.6
72.3
dVAE token
85.3
71.6
(d) Reconstruction target. Pixels as recon-
struction targets are effective.
case
ft
lin
none
84.0
65.7
crop, ﬁxed size
84.7
73.1
crop, rand size
84.9
73.5
crop + color jit
84.3
71.9
(e) Data augmentation. Our MAE works with
minimal or no augmentation.
case
ratio
ft
lin
random
75
84.9
73.5
block
50
83.9
72.3
block
75
82.8
63.9
grid
75
84.0
66.0
(f) Mask sampling. Random sampling works
the best. See Figure 6 for visualizations.
Table 1. MAE ablation experiments with ViT-L/16 on ImageNet-1K. We report ﬁne-tuning (ft) and linear probing (lin) accuracy (%). If
not speciﬁed, the default is: the decoder has depth 8 and width 512, the reconstruction target is unnormalized pixels, the data augmentation
is random resized cropping, the masking ratio is 75%, and the pre-training length is 800 epochs. Default settings are marked in gray .
curacy increases steadily with the masking ratio until the
sweet point: the accuracy gap is up to ∼20% (54.6% vs.
73.5%). For ﬁne-tuning, the results are less sensitive to the
ratios, and a wide range of masking ratios (40–80%) work
well. All ﬁne-tuning results in Figure 5 are better than train-
ing from scratch (82.5%).
Decoder design. Our MAE decoder can be ﬂexibly de-
signed, as studied in Table 1a and 1b.
Table 1a varies the decoder depth (number of Trans-
former blocks). A sufﬁciently deep decoder is important
for linear probing. This can be explained by the gap be-
tween a pixel reconstruction task and a recognition task: the
last several layers in an autoencoder are more specialized
for reconstruction, but are less relevant for recognition. A
reasonably deep decoder can account for the reconstruction
specialization, leaving the latent representations at a more
abstract level. This design can yield up to 8% improvement
in linear probing (Table 1a, ‘lin’). However, if ﬁne-tuning
is used, the last layers of the encoder can be tuned to adapt
to the recognition task. The decoder depth is less inﬂuential
for improving ﬁne-tuning (Table 1a, ‘ft’).
Interestingly, our MAE with a single-block decoder can
perform strongly with ﬁne-tuning (84.8%). Note that a sin-
gle Transformer block is the minimal requirement to propa-
gate information from visible tokens to mask tokens. Such
a small decoder can further speed up training.
In Table 1b we study the decoder width (number of chan-
nels). We use 512-d by default, which performs well un-
der ﬁne-tuning and linear probing. A narrower decoder also
works well with ﬁne-tuning.
Overall, our default MAE decoder is lightweight. It has
8 blocks and a width of 512-d ( gray in Table 1). It only
has 9% FLOPs per token vs. ViT-L (24 blocks, 1024-d).
As such, while the decoder processes all tokens, it is still a
small fraction of the overall compute.
encoder
dec. depth
ft acc
hours
speedup
ViT-L, w/ [M]
8
84.2
42.4
-
ViT-L
8
84.9
15.4
2.8×
ViT-L
1
84.8
11.6
3.7×
ViT-H, w/ [M]
8
-
119.6†
-
ViT-H
8
85.8
34.5
3.5×
ViT-H
1
85.9
29.3
4.1×
Table 2.
Wall-clock time of our MAE training (800 epochs),
benchmarked in 128 TPU-v3 cores with TensorFlow. The speedup
is relative to the entry whose encoder has mask tokens (gray). The
decoder width is 512, and the mask ratio is 75%. †: This entry is
estimated by training ten epochs.
Mask token. An important design of our MAE is to skip
the mask token [M] in the encoder and apply it later in the
lightweight decoder. Table 1c studies this design.
If the encoder uses mask tokens, it performs worse: its
accuracy drops by 14% in linear probing.
In this case,
there is a gap between pre-training and deploying: this en-
coder has a large portion of mask tokens in its input in pre-
training, which does not exist in uncorrupted images. This
gap may degrade accuracy in deployment. By removing the
mask token from the encoder, we constrain the encoder to
always see real patches and thus improve accuracy.
Moreover, by skipping the mask token in the encoder,
we greatly reduce training computation. In Table 1c, we
reduce the overall training FLOPs by 3.3×. This leads to
a 2.8× wall-clock speedup in our implementation (see Ta-
ble 2). The wall-clock speedup is even bigger (3.5–4.1×),
for a smaller decoder (1-block), a larger encoder (ViT-H),
or both. Note that the speedup can be >4× for a masking
ratio of 75%, partially because the self-attention complexity
is quadratic. In addition, memory is greatly reduced, which
can enable training even larger models or speeding up more
by large-batch training. The time and memory efﬁciency
makes our MAE favorable for training very large models.
5

## Page 6

block 50%
grid 75%
random 75%
Figure 6. Mask sampling strategies determine the pretext task
difﬁculty, inﬂuencing reconstruction quality and representations
(Table 1f). Here each output is from an MAE trained with the spec-
iﬁed masking strategy. Left: random sampling (our default). Mid-
dle: block-wise sampling [2] that removes large random blocks.
Right: grid-wise sampling that keeps one of every four patches.
Images are from the validation set.
Reconstruction target. We compare different reconstruc-
tion targets in Table 1d. Our results thus far are based on
pixels without (per-patch) normalization. Using pixels with
normalization improves accuracy. This per-patch normal-
ization enhances the contrast locally. In another variant, we
perform PCA in the patch space and use the largest PCA
coefﬁcients (96 here) as the target. Doing so degrades ac-
curacy. Both experiments suggest that the high-frequency
components are useful in our method.
We also compare an MAE variant that predicts tokens,
the target used in BEiT [2]. Speciﬁcally for this variant,
we use the DALLE pre-trained dVAE [50] as the tokenizer,
following [2]. Here the MAE decoder predicts the token in-
dices using cross-entropy loss. This tokenization improves
ﬁne-tuning accuracy by 0.4% vs. unnormalized pixels, but
has no advantage vs. normalized pixels. It also reduces lin-
ear probing accuracy. In §5 we further show that tokeniza-
tion is not necessary in transfer learning.
Our pixel-based MAE is much simpler than tokeniza-
tion. The dVAE tokenizer requires one more pre-training
stage, which may depend on extra data (250M images [50]).
The dVAE encoder is a large convolutional network (40%
FLOPs of ViT-L) and adds nontrivial overhead. Using pix-
els does not suffer from these problems.
Data augmentation. Table 1e studies the inﬂuence of data
augmentation on our MAE pre-training.
Our MAE works well using cropping-only augmenta-
tion, either ﬁxed-size or random-size (both having random
horizontal ﬂipping). Adding color jittering degrades the re-
sults and so we do not use it in other experiments.
Surprisingly, our MAE behaves decently even if using
no data augmentation (only center-crop, no ﬂipping). This
property is dramatically different from contrastive learning
and related methods [62, 23, 7, 21], which heavily rely
on data augmentation.
It was observed [21] that using
cropping-only augmentation reduces the accuracy by 13%
100
200
400
800
1600
82
83
84
85
82.3
83.3
84.3
84.9
85.1
fine-tuning
epochs (log-scale)
100
200
400
800
1600
60
65
70
75
57.3
64.4
69.7
73.5
75.1
linear probing
epochs (log-scale)
Figure 7. Training schedules. A longer training schedule gives a
noticeable improvement. Here each point is a full training sched-
ule. The model is ViT-L with the default setting in Table 1.
and 28% respectively for BYOL [21] and SimCLR [7]. In
addition, there is no evidence that contrastive learning can
work without augmentation: the two views of an image are
the same and can easily satisfy a trivial solution.
In MAE, the role of data augmentation is mainly per-
formed by random masking (ablated next). The masks are
different for each iteration and so they generate new training
samples regardless of data augmentation. The pretext task
is made difﬁcult by masking and requires less augmentation
to regularize training.
Mask sampling strategy. In Table 1f we compare different
mask sampling strategies, illustrated in Figure 6.
The block-wise masking strategy, proposed in [2], tends
to remove large blocks (Figure 6 middle). Our MAE with
block-wise masking works reasonably well at a ratio of
50%, but degrades at a ratio of 75%. This task is harder
than that of random sampling, as a higher training loss is
observed. The reconstruction is also blurrier.
We also study grid-wise sampling, which regularly keeps
one of every four patches (Figure 6 right). This is an eas-
ier task and has lower training loss. The reconstruction is
sharper. However, the representation quality is lower.
Simple random sampling works the best for our MAE. It
allows for a higher masking ratio, which provides a greater
speedup beneﬁt while also enjoying good accuracy.
Training schedule. Our ablations thus far are based on
800-epoch pre-training. Figure 7 shows the inﬂuence of the
training schedule length. The accuracy improves steadily
with longer training. Indeed, we have not observed sat-
uration of linear probing accuracy even at 1600 epochs.
This behavior is unlike contrastive learning methods, e.g.,
MoCo v3 [9] saturates at 300 epochs for ViT-L. Note that
the MAE encoder only sees 25% of patches per epoch,
while in contrastive learning the encoder sees 200% (two-
crop) or even more (multi-crop) patches per epoch.
6

## Page 7

method
pre-train data
ViT-B
ViT-L
ViT-H
ViT-H448
scratch, our impl. -
82.3
82.6
83.1
-
DINO [5]
IN1K
82.8
-
-
-
MoCo v3 [9]
IN1K
83.2
84.1
-
-
BEiT [2]
IN1K+DALLE
83.2
85.2
-
-
MAE
IN1K
83.6
85.9
86.9
87.8
Table 3.
Comparisons with previous results on ImageNet-
1K. The pre-training data is the ImageNet-1K training set (ex-
cept the tokenizer in BEiT was pre-trained on 250M DALLE data
[50]). All self-supervised methods are evaluated by end-to-end
ﬁne-tuning. The ViT models are B/16, L/16, H/14 [16]. The best
for each column is underlined. All results are on an image size of
224, except for ViT-H with an extra result on 448. Here our MAE
reconstructs normalized pixels and is pre-trained for 1600 epochs.
0
200
400
600
76
78
80
82
84
86
88
ViT-B/16
ViT-L/16
ViT-H/14
MAE, IN1K
supervised, IN1K, our impl.
supervised, IN1K
supervised, JFT300M
[16]
[16]
params (M)
Figure 8. MAE pre-training vs. supervised pre-training, evalu-
ated by ﬁne-tuning in ImageNet-1K (224 size). We compare with
the original ViT results [16] trained in IN1K or JFT300M.
4.2. Comparisons with Previous Results
Comparisons with self-supervised methods. In Table 3
we compare the ﬁne-tuning results of self-supervised ViT
models. For ViT-B, all methods perform closely. For ViT-L,
the gaps among methods are bigger, suggesting that a chal-
lenge for bigger models is to reduce overﬁtting.
Our MAE can scale up easily and has shown steady im-
provement from bigger models. We obtain 86.9% accuracy
using ViT-H (224 size). By ﬁne-tuning with a 448 size, we
achieve 87.8% accuracy, using only IN1K data. The pre-
vious best accuracy, among all methods using only IN1K
data, is 87.1% (512 size) [67], based on advanced networks.
We improve over the state-of-the-art by a nontrivial margin
in the highly competitive benchmark of IN1K (no external
data). Our result is based on vanilla ViT, and we expect
advanced networks will perform better.
Comparing with BEiT [2], our MAE is more accurate
while being simpler and faster. Our method reconstructs
pixels, in contrast to BEiT that predicts tokens: BEiT re-
ported a 1.8% degradation [2] when reconstructing pixels
with ViT-B.2 We do not need dVAE pre-training. More-
over, our MAE is considerably faster (3.5× per epoch) than
BEiT, for the reason as studied in Table 1c.
2We observed the degradation also in BEiT with ViT-L: it produces
85.2% (tokens) and 83.5% (pixels), reproduced from the ofﬁcial code.
0 1 2 
4 
6 
12
18
24
70
75
80
85
73.5
81.0
83.1
84.2
84.4
84.6
84.7
84.9
77.6
79.9
80.8
81.6
81.9
83.2
83.8
84.1
MAE baseline
MoCo v3
# blocks ﬁne-tuned
Figure 9. Partial ﬁne-tuning results of ViT-L w.r.t. the number
of ﬁne-tuned Transformer blocks under the default settings from
Table 1. Tuning 0 blocks is linear probing; 24 is full ﬁne-tuning.
Our MAE representations are less linearly separable, but are con-
sistently better than MoCo v3 if one or more blocks are tuned.
The MAE models in Table 3 are pre-trained for 1600
epochs for better accuracy (Figure 7). Even so, our total
pre-training time is less than the other methods when trained
on the same hardware. For example, training ViT-L on 128
TPU-v3 cores, our MAE’s training time is 31 hours for 1600
epochs and MoCo v3’s is 36 hours for 300 epochs [9].
Comparisons with supervised pre-training. In the origi-
nal ViT paper [16], ViT-L degrades when trained in IN1K.
Our implementation of supervised training (see A.2) works
better, but accuracy saturates. See Figure 8.
Our MAE pre-training, using only IN1K, can general-
ize better: the gain over training from scratch is bigger for
higher-capacity models. It follows a trend similar to the
JFT-300M supervised pre-training in [16]. This compari-
son shows that our MAE can help scale up model sizes.
4.3. Partial Fine-tuning
Table 1 shows that linear probing and ﬁne-tuning results
are largely uncorrelated. Linear probing has been a popular
protocol in the past few years; however, it misses the oppor-
tunity of pursuing strong but non-linear features—which is
indeed a strength of deep learning. As a middle ground, we
study a partial ﬁne-tuning protocol: ﬁne-tune the last sev-
eral layers while freezing the others. This protocol was also
used in early works, e.g., [65, 70, 42].
Figure 9 shows the results. Notably, ﬁne-tuning only one
Transformer block boosts the accuracy signiﬁcantly from
73.5% to 81.0%. Moreover, if we ﬁne-tune only “half” of
the last block (i.e., its MLP sub-block), we can get 79.1%,
much better than linear probing. This variant is essentially
ﬁne-tuning an MLP head. Fine-tuning a few blocks (e.g., 4
or 6) can achieve accuracy close to full ﬁne-tuning.
In Figure 9 we also compare with MoCo v3 [9], a con-
trastive method with ViT-L results available. MoCo v3 has
higher linear probing accuracy; however, all of its partial
ﬁne-tuning results are worse than MAE. The gap is 2.6%
when tuning 4 blocks. While the MAE representations are
less linearly separable, they are stronger non-linear features
and perform well when a non-linear head is tuned.
7

## Page 8

APbox
APmask
method
pre-train data
ViT-B
ViT-L
ViT-B
ViT-L
supervised
IN1K w/ labels
47.9
49.3
42.9
43.9
MoCo v3
IN1K
47.9
49.3
42.7
44.0
BEiT
IN1K+DALLE
49.8
53.3
44.4
47.1
MAE
IN1K
50.3
53.3
44.9
47.2
Table 4. COCO object detection and segmentation using a ViT
Mask R-CNN baseline. All entries are based on our implementa-
tion. Self-supervised entries use IN1K data without labels. Mask
AP follows a similar trend as box AP.
These observations suggest that linear separability is not
the sole metric for evaluating representation quality. It has
also been observed (e.g., [8]) that linear probing is not well
correlated with transfer learning performance, e.g., for ob-
ject detection. To our knowledge, linear evaluation is not
often used in NLP for benchmarking pre-training.
5. Transfer Learning Experiments
We evaluate transfer learning in downstream tasks using
the pre-trained models in Table 3.
Object detection and segmentation. We ﬁne-tune Mask
R-CNN [24] end-to-end on COCO [37]. The ViT backbone
is adapted for use with FPN [36] (see A.3). We apply this
approach for all entries in Table 4. We report box AP for
object detection and mask AP for instance segmentation.
Compared to supervised pre-training, our MAE performs
better under all conﬁgurations (Table 4). With the smaller
ViT-B, our MAE is 2.4 points higher than supervised pre-
training (50.3 vs. 47.9, APbox). More signiﬁcantly, with the
larger ViT-L, our MAE pre-training outperforms supervised
pre-training by 4.0 points (53.3 vs. 49.3).
The pixel-based MAE is better than or on par with the
token-based BEiT, while MAE is much simpler and faster.
Both MAE and BEiT are better than MoCo v3 and MoCo
v3 is on par with supervised pre-training.
Semantic segmentation. We experiment on ADE20K [72]
using UperNet [63] (see A.4). Table 5 shows that our pre-
training signiﬁcantly improves results over supervised pre-
training, e.g., by 3.7 points for ViT-L. Our pixel-based MAE
also outperforms the token-based BEiT. These observations
are consistent with those in COCO.
Classiﬁcation tasks. Table 6 studies transfer learning on
the iNaturalists [56] and Places [71] tasks (see A.5). On
iNat, our method shows strong scaling behavior: accuracy
improves considerably with bigger models. Our results sur-
pass the previous best results by large margins. On Places,
our MAE outperforms the previous best results [19, 40],
which were obtained via pre-training on billions of images.
Pixels vs. tokens. Table 7 compares pixels vs. tokens as the
MAE reconstruction target. While using dVAE tokens is
better than using unnormalized pixels, it is statistically sim-
ilar to using normalized pixels across all cases we tested. It
again shows that tokenization is not necessary for our MAE.
method
pre-train data
ViT-B
ViT-L
supervised
IN1K w/ labels
47.4
49.9
MoCo v3
IN1K
47.3
49.1
BEiT
IN1K+DALLE
47.1
53.3
MAE
IN1K
48.1
53.6
Table 5. ADE20K semantic segmentation (mIoU) using Uper-
Net. BEiT results are reproduced using the ofﬁcial code. Other
entries are based on our implementation. Self-supervised entries
use IN1K data without labels.
dataset
ViT-B
ViT-L
ViT-H
ViT-H448
prev best
iNat 2017
70.5
75.7
79.3
83.4
75.4 [55]
iNat 2018
75.4
80.1
83.0
86.8
81.2 [54]
iNat 2019
80.5
83.4
85.7
88.3
84.1 [54]
Places205
63.9
65.8
65.9
66.8
66.0 [19]†
Places365
57.9
59.4
59.8
60.3
58.0 [40]‡
Table 6. Transfer learning accuracy on classiﬁcation datasets,
using MAE pre-trained on IN1K and then ﬁne-tuned. We provide
system-level comparisons with the previous best results.
†: pre-trained on 1 billion images. ‡: pre-trained on 3.5 billion images.
IN1K
COCO
ADE20K
ViT-B
ViT-L
ViT-H
ViT-B
ViT-L
ViT-B
ViT-L
pixel (w/o norm)
83.3
85.1
86.2
49.5
52.8
48.0
51.8
pixel (w/ norm)
83.6
85.9
86.9
50.3
53.3
48.1
53.6
dVAE token
83.6
85.7
86.9
50.3
53.2
48.1
53.4
△
0.0
-0.2
0.0
0.0
-0.1
0.0
-0.2
Table 7. Pixels vs. tokens as the MAE reconstruction target. △is
the difference between using dVAE tokens and using normalized
pixels. The difference is statistically insigniﬁcant.
6. Discussion and Conclusion
Simple algorithms that scale well are the core of deep
learning. In NLP, simple self-supervised learning methods
(e.g., [47, 14, 48, 4]) enable beneﬁts from exponentially
scaling models. In computer vision, practical pre-training
paradigms are dominantly supervised (e.g. [33, 51, 25, 16])
despite progress in self-supervised learning. In this study,
we observe on ImageNet and in transfer learning that
an autoencoder—a simple self-supervised method similar
to techniques in NLP—provides scalable beneﬁts.
Self-
supervised learning in vision may now be embarking on a
similar trajectory as in NLP.
On the other hand, we note that images and languages
are signals of a different nature and this difference must
be addressed carefully. Images are merely recorded light
without a semantic decomposition into the visual analogue
of words. Instead of attempting to remove objects, we re-
move random patches that most likely do not form a seman-
tic segment. Likewise, our MAE reconstructs pixels, which
are not semantic entities. Nevertheless, we observe (e.g.,
Figure 4) that our MAE infers complex, holistic reconstruc-
tions, suggesting it has learned numerous visual concepts,
i.e., semantics. We hypothesize that this behavior occurs
by way of a rich hidden representation inside the MAE. We
hope this perspective will inspire future work.
8

## Page 9

Broader impacts. The proposed method predicts content
based on learned statistics of the training dataset and as such
will reﬂect biases in those data, including ones with nega-
tive societal impacts. The model may generate inexistent
content. These issues warrant further research and consid-
eration when building upon this work to generate images.
References
[1] Jimmy Lei Ba, Jamie Ryan Kiros, and Geoffrey E Hinton. Layer
normalization. arXiv:1607.06450, 2016.
[2] Hangbo Bao, Li Dong, and Furu Wei. BEiT: BERT pre-training
of image transformers. arXiv:2106.08254, 2021. Accessed in June
2021.
[3] Suzanna Becker and Geoffrey E Hinton. Self-organizing neural
network that discovers surfaces in random-dot stereograms. Na-
ture, 1992.
[4] Tom Brown, Benjamin Mann, Nick Ryder, Melanie Subbiah,
Jared D Kaplan, Prafulla Dhariwal, Arvind Neelakantan, Pranav
Shyam, Girish Sastry, Amanda Askell, Sandhini Agarwal, Ariel
Herbert-Voss, Gretchen Krueger, Tom Henighan, Rewon Child,
Aditya Ramesh, Daniel Ziegler, Jeffrey Wu, Clemens Winter, Chris
Hesse, Mark Chen, Eric Sigler, Mateusz Litwin, Scott Gray, Ben-
jamin Chess, Jack Clark, Christopher Berner, Sam McCandlish,
Alec Radford, Ilya Sutskever, and Dario Amodei. Language mod-
els are few-shot learners. In NeurIPS, 2020.
[5] Mathilde Caron, Hugo Touvron, Ishan Misra, Herv´e J´egou, Julien
Mairal, Piotr Bojanowski, and Armand Joulin. Emerging properties
in self-supervised vision transformers. In ICCV, 2021.
[6] Mark Chen, Alec Radford, Rewon Child, Jeffrey Wu, Heewoo Jun,
David Luan, and Ilya Sutskever. Generative pretraining from pix-
els. In ICML, 2020.
[7] Ting Chen, Simon Kornblith, Mohammad Norouzi, and Geoffrey
Hinton. A simple framework for contrastive learning of visual rep-
resentations. In ICML, 2020.
[8] Xinlei Chen and Kaiming He. Exploring simple Siamese represen-
tation learning. In CVPR, 2021.
[9] Xinlei Chen, Saining Xie, and Kaiming He. An empirical study of
training self-supervised Vision Transformers. In ICCV, 2021.
[10] Kevin Clark, Minh-Thang Luong, Quoc V Le, and Christopher D
Manning. ELECTRA: Pre-training text encoders as discriminators
rather than generators. In ICLR, 2020.
[11] Corinna Cortes and Vladimir Vapnik.
Support-vector networks.
Machine learning, 1995.
[12] Ekin D Cubuk, Barret Zoph, Jonathon Shlens, and Quoc V Le. Ran-
daugment: Practical automated data augmentation with a reduced
search space. In CVPR Workshops, 2020.
[13] Jia Deng, Wei Dong, Richard Socher, Li-Jia Li, Kai Li, and Li
Fei-Fei. ImageNet: A large-scale hierarchical image database. In
CVPR, 2009.
[14] Jacob Devlin, Ming-Wei Chang, Kenton Lee, and Kristina
Toutanova. BERT: Pre-training of deep bidirectional transformers
for language understanding. In NAACL, 2019.
[15] Carl Doersch, Abhinav Gupta, and Alexei A Efros. Unsupervised
visual representation learning by context prediction.
In ICCV,
2015.
[16] Alexey Dosovitskiy, Lucas Beyer, Alexander Kolesnikov, Dirk
Weissenborn, Xiaohua Zhai, Thomas Unterthiner, Mostafa De-
hghani, Matthias Minderer, Georg Heigold, Sylvain Gelly, Jakob
Uszkoreit, and Neil Houlsby. An image is worth 16x16 words:
Transformers for image recognition at scale. In ICLR, 2021.
[17] Spyros Gidaris, Praveer Singh, and Nikos Komodakis. Unsuper-
vised representation learning by predicting image rotations.
In
ICLR, 2018.
[18] Xavier Glorot and Yoshua Bengio. Understanding the difﬁculty of
training deep feedforward neural networks. In AISTATS, 2010.
[19] Priya Goyal, Mathilde Caron, Benjamin Lefaudeux, Min Xu,
Pengchao Wang, Vivek Pai, Mannat Singh, Vitaliy Liptchinsky, Is-
han Misra, Armand Joulin, and Piotr Bojanowski. Self-supervised
pretraining of visual features in the wild. arXiv:2103.01988, 2021.
[20] Priya Goyal, Piotr Doll´ar, Ross Girshick, Pieter Noordhuis, Lukasz
Wesolowski, Aapo Kyrola, Andrew Tulloch, Yangqing Jia, and
Kaiming He. Accurate, large minibatch SGD: Training ImageNet
in 1 hour. arXiv:1706.02677, 2017.
[21] Jean-Bastien Grill, Florian Strub, Florent Altch´e, Corentin Tallec,
Pierre Richemond, Elena Buchatskaya, Carl Doersch, Bernardo
Avila Pires, Zhaohan Guo, Mohammad Gheshlaghi Azar, Bilal
Piot, Koray Kavukcuoglu, Remi Munos, and Michal Valko. Boot-
strap your own latent - a new approach to self-supervised learning.
In NeurIPS, 2020.
[22] Raia Hadsell, Sumit Chopra, and Yann LeCun.
Dimensionality
reduction by learning an invariant mapping. In CVPR, 2006.
[23] Kaiming He, Haoqi Fan, Yuxin Wu, Saining Xie, and Ross Gir-
shick. Momentum contrast for unsupervised visual representation
learning. In CVPR, 2020.
[24] Kaiming He, Georgia Gkioxari, Piotr Doll´ar, and Ross Girshick.
Mask R-CNN. In ICCV, 2017.
[25] Kaiming He, Xiangyu Zhang, Shaoqing Ren, and Jian Sun. Deep
residual learning for image recognition. In CVPR, 2016.
[26] Dan Hendrycks, Steven Basart, Norman Mu, Saurav Kadavath,
Frank Wang, Evan Dorundo, Rahul Desai, Tyler Zhu, Samyak
Parajuli, Mike Guo, et al. The many faces of robustness: A critical
analysis of out-of-distribution generalization. In ICCV, 2021.
[27] Dan Hendrycks and Thomas Dietterich. Benchmarking neural net-
work robustness to common corruptions and perturbations.
In
ICLR, 2019.
[28] Dan Hendrycks, Kevin Zhao, Steven Basart, Jacob Steinhardt, and
Dawn Song. Natural adversarial examples. In CVPR, 2021.
[29] Geoffrey E Hinton and Richard S Zemel. Autoencoders, minimum
description length, and helmholtz free energy. In NeurIPS, 1994.
[30] Gao Huang, Yu Sun, Zhuang Liu, Daniel Sedra, and Kilian Q Wein-
berger. Deep networks with stochastic depth. In ECCV, 2016.
[31] Sergey Ioffe and Christian Szegedy. Batch normalization: Accel-
erating deep network training by reducing internal covariate shift.
In ICML, 2015.
[32] Insoo Kim, Seungju Han, Ji-won Baek, Seong-Jin Park, Jae-Joon
Han, and Jinwoo Shin. Quality-agnostic image recognition via in-
vertible decoder. In CVPR, 2021.
[33] Alex Krizhevsky, Ilya Sutskever, and Geoff Hinton. Imagenet clas-
siﬁcation with deep convolutional neural networks. In NeurIPS,
2012.
[34] Yann LeCun, Bernhard Boser, John S Denker, Donnie Hender-
son, Richard E Howard, Wayne Hubbard, and Lawrence D Jackel.
Backpropagation applied to handwritten zip code recognition. Neu-
ral computation, 1989.
[35] Yanghao Li, Saining Xie, Xinlei Chen, Piotr Doll´ar, Kaiming He,
and Ross Girshick. Benchmarking detection transfer learning with
vision transformers. In preparation, 2021.
9

## Page 10

[36] Tsung-Yi Lin, Piotr Doll´ar, Ross Girshick, Kaiming He, Bharath
Hariharan, and Serge Belongie. Feature pyramid networks for ob-
ject detection. In CVPR, 2017.
[37] Tsung-Yi Lin, Michael Maire, Serge Belongie, James Hays, Pietro
Perona, Deva Ramanan, Piotr Doll´ar, and C Lawrence Zitnick. Mi-
crosoft COCO: Common objects in context. In ECCV, 2014.
[38] Ilya Loshchilov and Frank Hutter. SGDR: Stochastic gradient de-
scent with warm restarts. In ICLR, 2017.
[39] Ilya Loshchilov and Frank Hutter. Decoupled weight decay regu-
larization. In ICLR, 2019.
[40] Dhruv Mahajan, Ross Girshick, Vignesh Ramanathan, Kaiming
He, Manohar Paluri, Yixuan Li, Ashwin Bharambe, and Laurens
van der Maaten. Exploring the limits of weakly supervised pre-
training. In ECCV, 2018.
[41] Xiaofeng Mao, Gege Qi, Yuefeng Chen, Xiaodan Li, Ranjie Duan,
Shaokai Ye, Yuan He, and Hui Xue. Towards robust vision trans-
former. arXiv:2105.07926, 2021.
[42] Mehdi Noroozi and Paolo Favaro. Unsupervised learning of visual
representations by solving jigsaw puzzles. In ECCV, 2016.
[43] Aaron van den Oord, Yazhe Li, and Oriol Vinyals. Representa-
tion learning with contrastive predictive coding. arXiv:1807.03748,
2018.
[44] Aaron van den Oord, Oriol Vinyals, and Koray Kavukcuoglu. Neu-
ral discrete representation learning. In NeurIPS, 2017.
[45] Deepak Pathak, Ross Girshick, Piotr Doll´ar, Trevor Darrell, and
Bharath Hariharan. Learning features by watching objects move.
In CVPR, 2017.
[46] Deepak Pathak, Philipp Krahenbuhl, Jeff Donahue, Trevor Darrell,
and Alexei A Efros. Context encoders: Feature learning by inpaint-
ing. In CVPR, 2016.
[47] Alec Radford, Karthik Narasimhan, Tim Salimans, and Ilya
Sutskever. Improving language understanding by generative pre-
training. 2018.
[48] Alec Radford, Jeffrey Wu, Rewon Child, David Luan, Dario
Amodei, and Ilya Sutskever. Language models are unsupervised
multitask learners. 2019.
[49] Colin Raffel, Noam Shazeer, Adam Roberts, Katherine Lee, Sharan
Narang, Michael Matena, Yanqi Zhou, Wei Li, and Peter J. Liu.
Exploring the limits of transfer learning with a uniﬁed text-to-text
transformer. JMLR, 2020.
[50] Aditya Ramesh, Mikhail Pavlov, Gabriel Goh, Scott Gray, Chelsea
Voss, Alec Radford, Mark Chen, and Ilya Sutskever. Zero-shot
text-to-image generation. In ICML, 2021.
[51] Karen Simonyan and Andrew Zisserman. Very deep convolutional
networks for large-scale image recognition. In ICLR, 2015.
[52] Christian Szegedy, Vincent Vanhoucke, Sergey Ioffe, Jonathon
Shlens, and Zbigniew Wojna. Rethinking the inception architec-
ture for computer vision. In CVPR, 2016.
[53] Hugo Touvron, Matthieu Cord, Matthijs Douze, Francisco Massa,
Alexandre Sablayrolles, and Herv´e J´egou. Training data-efﬁcient
image transformers & distillation through attention.
In ICML,
2021.
[54] Hugo Touvron, Alexandre Sablayrolles, Matthijs Douze, Matthieu
Cord, and Herv´e J´egou. Graﬁt: Learning ﬁne-grained image repre-
sentations with coarse labels. In ICCV, 2021.
[55] Hugo Touvron, Andrea Vedaldi, Matthijs Douze, and Herv´e J´egou.
Fixing the train-test resolution discrepancy.
arXiv:1906.06423,
2019.
[56] Grant Van Horn, Oisin Mac Aodha, Yang Song, Yin Cui, Chen
Sun, Alex Shepard, Hartwig Adam, Pietro Perona, and Serge Be-
longie. The iNaturalist species classiﬁcation and detection dataset.
In CVPR, 2018.
[57] Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit,
Llion Jones, Aidan N Gomez, Lukasz Kaiser, and Illia Polosukhin.
Attention is all you need. In NeurIPS, 2017.
[58] Pascal Vincent, Hugo Larochelle, Yoshua Bengio, and Pierre-
Antoine Manzagol. Extracting and composing robust features with
denoising autoencoders. In ICML, 2008.
[59] Pascal Vincent, Hugo Larochelle, Isabelle Lajoie, Yoshua Bengio,
Pierre-Antoine Manzagol, and L´eon Bottou. Stacked denoising au-
toencoders: Learning useful representations in a deep network with
a local denoising criterion. JMLR, 2010.
[60] Haohan Wang, Songwei Ge, Zachary Lipton, and Eric P Xing.
Learning robust global representations by penalizing local predic-
tive power. In NeurIPS, 2019.
[61] Xiaolong Wang and Abhinav Gupta. Unsupervised learning of vi-
sual representations using videos. In ICCV, 2015.
[62] Zhirong Wu, Yuanjun Xiong, Stella Yu, and Dahua Lin. Unsuper-
vised feature learning via non-parametric instance discrimination.
In CVPR, 2018.
[63] Tete Xiao, Yingcheng Liu, Bolei Zhou, Yuning Jiang, and Jian
Sun. Uniﬁed perceptual parsing for scene understanding. In ECCV,
2018.
[64] Tete Xiao, Mannat Singh, Eric Mintun, Trevor Darrell, Piotr Doll´ar,
and Ross Girshick. Early convolutions help transformers see better.
In NeurIPS, 2021.
[65] Jason Yosinski, Jeff Clune, Yoshua Bengio, and Hod Lipson. How
transferable are features in deep neural networks?
In NeurIPS,
2014.
[66] Yang You, Igor Gitman, and Boris Ginsburg. Large batch training
of convolutional networks. arXiv:1708.03888, 2017.
[67] Li Yuan, Qibin Hou, Zihang Jiang, Jiashi Feng, and Shuicheng Yan.
VOLO: Vision outlooker for visual recognition. arXiv:2106.13112,
2021.
[68] Sangdoo Yun, Dongyoon Han, Seong Joon Oh, Sanghyuk Chun,
Junsuk Choe, and Youngjoon Yoo. Cutmix: Regularization strategy
to train strong classiﬁers with localizable features. In ICCV, 2019.
[69] Hongyi Zhang, Moustapha Cisse, Yann N Dauphin, and David
Lopez-Paz. mixup: Beyond empirical risk minimization. In ICLR,
2018.
[70] Richard Zhang, Phillip Isola, and Alexei A Efros. Colorful image
colorization. In ECCV, 2016.
[71] Bolei Zhou, Agata Lapedriza, Jianxiong Xiao, Antonio Torralba,
and Aude Oliva. Learning deep features for scene recognition using
Places database. In NeurIPS, 2014.
[72] Bolei Zhou, Hang Zhao, Xavier Puig, Tete Xiao, Sanja Fidler,
Adela Barriuso, and Antonio Torralba.
Semantic understanding
of scenes through the ADE20K dataset. IJCV, 2019.
10

## Page 11

A. Implementation Details
A.1. ImageNet Experiments
ViT architecture. We follow the standard ViT architecture
[16]. It has a stack of Transformer blocks [57], and each
block consists of a multi-head self-attention block and an
MLP block, both having LayerNorm (LN) [1]. The encoder
ends with LN. As the MAE encoder and decoder have dif-
ferent width, we adopt a linear projection layer after the
encoder to match it. Our MAE adds positional embeddings
[57] (the sine-cosine version) to both the encoder and de-
coder inputs. Our MAE does not use relative position or
layer scaling (which are used in the code of [2]).
We extract features from the encoder output for ﬁne-
tuning and linear probing. As ViT has a class token [16],
to adapt to this design, in our MAE pre-training we append
an auxiliary dummy token to the encoder input. This token
will be treated as the class token for training the classiﬁer in
linear probing and ﬁne-tuning. Our MAE works similarly
well without this token (with average pooling).
Pre-training.
The default setting is in Table 8.
We do
not use color jittering, drop path, or gradient clip. We use
xavier uniform [18] to initialize all Transformer blocks, fol-
lowing ViT’s ofﬁcial code [16]. We use the linear lr scaling
rule [20]: lr = base lr×batchsize / 256.
End-to-end ﬁne-tuning. Our ﬁne-tuning follows common
practice of supervised ViT training. The default setting is in
Table 9. We use layer-wise lr decay [10] following [2].
Linear probing. Our linear classiﬁer training follows [9].
See Table 10. We observe that linear probing requires a very
different recipe than end-to-end ﬁne-tuning. In particular,
regularization is in general harmful for linear probing. Fol-
lowing [9], we disable many common regularization strate-
gies: we do not use mixup [69], cutmix [68], drop path [30],
or color jittering, and we set weight decay as zero.
It is a common practice to normalize the classiﬁer input
when training a classical linear classiﬁer (e.g., SVM [11]).
Similarly, it is beneﬁcial to normalize the pre-trained fea-
tures when training the linear probing classiﬁer. Follow-
ing [15], we adopt an extra BatchNorm layer [31] without
afﬁne transformation (affine=False). This layer is ap-
plied on the pre-trained features produced by the encoder,
and is before the linear classiﬁer. We note that the layer
does not break the linear property, and it can be absorbed
into the linear classiﬁer after training: it is essentially a re-
parameterized linear classiﬁer.3 Introducing this layer helps
calibrate the feature magnitudes across different variants in
our ablations, so that they can use the same setting without
further lr search.
3Alternatively, we can pre-compute the mean and std of the features
and use the normalized features to train linear classiﬁers.
conﬁg
value
optimizer
AdamW [39]
base learning rate
1.5e-4
weight decay
0.05
optimizer momentum
β1, β2=0.9, 0.95 [6]
batch size
4096
learning rate schedule
cosine decay [38]
warmup epochs [20]
40
augmentation
RandomResizedCrop
Table 8. Pre-training setting.
conﬁg
value
optimizer
AdamW
base learning rate
1e-3
weight decay
0.05
optimizer momentum
β1, β2=0.9, 0.999
layer-wise lr decay [10, 2]
0.75
batch size
1024
learning rate schedule
cosine decay
warmup epochs
5
training epochs
100 (B), 50 (L/H)
augmentation
RandAug (9, 0.5) [12]
label smoothing [52]
0.1
mixup [69]
0.8
cutmix [68]
1.0
drop path [30]
0.1 (B/L) 0.2 (H)
Table 9. End-to-end ﬁne-tuning setting.
conﬁg
value
optimizer
LARS [66]
base learning rate
0.1
weight decay
0
optimizer momentum
0.9
batch size
16384
learning rate schedule
cosine decay
warmup epochs
10
training epochs
90
augmentation
RandomResizedCrop
Table 10. Linear probing setting. We use LARS with a large
batch for faster training; SGD works similarly with a 4096 batch.
Partial ﬁne-tuning. Our MAE partial ﬁne-tuning (§4.3)
follows the setting in Table 9, except that we adjust the num-
ber of ﬁne-tuning epochs. We observe that tuning fewer
blocks requires a longer schedule. We set the numbers of
ﬁne-tuning epochs as {50, 100, 200} and use the optimal
one for each number of blocks tuned.
A.2. Supervised Training ViT-L/H from Scratch
We ﬁnd that it is nontrivial to train supervised ViT-L/H
from scratch on ImageNet-1K. The training is unstable.
While there have been strong baselines with publicly avail-
able implementations [53] for smaller models, the recipes
for the larger ViT-L/H are unexplored. Directly applying
the previous recipes to these larger models does not work.
A NaN loss is frequently observed during training.
We provide our recipe in Table 11. We use a wd of 0.3,
a large batch size of 4096, and a long warmup, following
the original ViT [16]. We use β2=0.95 following [6]. We
use the regularizations listed in Table 11 and disable others,
following [64]. All these choices are for improving training
stability. Our recipe can ﬁnish training with no NaN loss.
11

## Page 12

conﬁg
value
optimizer
AdamW
base learning rate
1e-4
weight decay
0.3
optimizer momentum
β1, β2=0.9, 0.95
batch size
4096
learning rate schedule
cosine decay
warmup epochs
20
training epochs
300 (B), 200 (L/H)
augmentation
RandAug (9, 0.5) [12]
label smoothing [52]
0.1
mixup [69]
0.8
cutmix [68]
1.0
drop path [30]
0.1 (B), 0.2 (L/H)
exp. moving average (EMA)
0.9999
Table 11. Supervised training ViT from scratch.
The accuracy is 82.6% for ViT-L (81.5% w/o EMA), and
83.1% for ViT-H (80.9% w/o EMA). Both ViT-L and ViT-H
show an overﬁtting trend if not using EMA.
As a by-product, our recipe for ViT-B has 82.3% accu-
racy (82.1% w/o EMA), vs. 81.8% in [53].
A.3. Object Detection and Segmentation in COCO
We adapt the vanilla ViT for the use of an FPN backbone
[36] in Mask R-CNN [24]. ViT has a stack of Transformer
blocks that all produce feature maps at a single scale (e.g.,
stride 16). We equally divide this stack into 4 subsets and
apply convolutions to upsample or downsample the inter-
mediate feature maps for producing different scales (stride
4, 8, 16, or 32, the same as a standard ResNet [25]). FPN is
built on these multi-scale maps.
For fair comparisons among different methods, we
search for hyper-parameters for each entry in Table 4 (in-
cluding all competitors). The hyper-parameters we search
for are the learning rate, weight decay, drop path rate, and
ﬁne-tuning epochs. We will release code along with the
speciﬁc conﬁgurations. For full model and training details,
plus additional experiments, see [35].
A.4. Semantic Segmentation in ADE20K
We use UperNet [63] following the semantic segmenta-
tion code of [2]. We ﬁne-tune end-to-end for 100 epochs
with a batch size of 16. We search for the optimal lr for
each entry in Table 5 (including all competitors).
The semantic segmentation code of [2] uses relative po-
sition bias [49]. Our MAE pre-training does not use it. For
fair comparison, we turn on relative position bias only dur-
ing transfer learning, initialized as zero. We note that our
BEiT reproduction uses relative position bias in both pre-
training and ﬁne-tuning, following their code.
A.5. Additional Classiﬁcation Tasks
We follow the setting in Table 9 for iNaturalist and
Places ﬁne-tuning (Table 6).
We adjust the lr and ﬁne-
tuning epochs for each individual dataset.
method
model
params
acc
iGPT [6]
iGPT-L
1362 M
69.0
iGPT [6]
iGPT-XL
6801 M
72.0
BEiT [2]
ViT-L
304 M
52.1†
MAE
ViT-B
86 M
68.0
MAE
ViT-L
304 M
75.8
MAE
ViT-H
632 M
76.6
Table 12. Linear probing results of masked encoding methods.
Our ﬁne-tuning results are in Table 3. †: our implementation.
dataset
ViT-B
ViT-L
ViT-H
ViT-H448 prev best
IN-Corruption ↓[27]
51.7
41.8
33.8
36.8
42.5 [32]
IN-Adversarial [28]
35.9
57.1
68.2
76.7
35.8 [41]
IN-Rendition [26]
48.3
59.9
64.4
66.5
48.7 [41]
IN-Sketch [60]
34.5
45.3
49.6
50.9
36.0 [41]
our supervised training baselines:
IN-Corruption ↓
45.8
42.3
41.3
IN-Adversarial
27.2
29.6
33.1
IN-Rendition
49.4
50.9
50.3
IN-Sketch
35.6
37.5
38.0
Table 13. Robustness evaluation on ImageNet variants (top-1
accuracy, except for IN-C [27] which evaluates mean corruption
error). We test the same MAE models (Table 3) on different Im-
ageNet validation sets, without any specialized ﬁne-tuning. We
provide system-level comparisons with the previous best results.
B. Comparison on Linear Probing Results
In §4.3 we have shown that linear probing accuracy and
ﬁne-tuning accuracy are largely uncorrelated and they have
different focuses about linear separability. We notice that
existing masked image encoding methods are generally less
competitive in linear probing (e.g., than contrastive learn-
ing). For completeness, in Table 12 we compare on linear
probing accuracy with masking-based methods.
Our MAE with ViT-L has 75.8% linear probing accu-
racy. This is substantially better than previous masking-
based methods. On the other hand, it still lags behind con-
trastive methods under this protocol: e.g., MoCo v3 [9] has
77.6% linear probing accuracy for the ViT-L (Figure 9).
C. Robustness Evaluation on ImageNet
In Table 13 we evaluate the robustness of our models on
different variants of ImageNet validation sets. We use the
same models ﬁne-tuned on original ImageNet (Table 3) and
only run inference on the different validation sets, without
any specialized ﬁne-tuning. Table 13 shows that our method
has strong scaling behavior: increasing the model sizes has
signiﬁcant gains. Increasing the image size helps in all sets
but IN-C. Our results outperform the previous best results
(of specialized systems) by large margins.
In contrast, supervised training performs much worse
(Table 13 bottom; models described in A.2). For example,
with ViT-H, our MAE pre-training is 35% better on IN-A
(68.2% vs 33.1%) than the supervised counterpart.
12

## Page 13

Figure 10. Uncurated random samples on ImageNet validation images. For each triplet, we show the masked image (left), our MAE
reconstruction (middle), and the ground-truth (right). The masking ratio is 75%.
13

## Page 14

Figure 11. Uncurated random samples on COCO validation images, using an MAE trained on ImageNet. For each triplet, we show the
masked image (left), our MAE reconstruction (middle), and the ground-truth (right). The masking ratio is 75%.
14


---

# MGraphDTA: deep multiscale graph neural network for explainable drug–target binding affinity prediction

- **Authors:** Ziduo Yang, Weihe Zhong, Lu Zhao, Calvin Yu‐Chian Chen
- **Issuer:** Chemical Science
- **Type:** Scientific article
- **Published:** 2022-01-01
- **DOI:** 10.1039/d1sc05180f
- **Source:** https://doi.org/10.1039/d1sc05180f
- **Licence:** CC-BY-NC

## Section: Abstract

Predicting drug–target affinity (DTA) is beneficial for accelerating drug discovery. Graph neural networks (GNNs) have been widely used in DTA prediction. However, existing shallow GNNs are insufficient to capture the global structure of compounds. Besides, the interpretability of the graph-based DTA models highly relies on the graph attention mechanism, which can not reveal the global relationship between each atom of a molecule. In this study, we proposed a deep multiscale graph neural network based on chemical intuition for DTA prediction (MGraphDTA). We introduced a dense connection into the GNN and built a super-deep GNN with 27 graph convolutional layers to capture the local and global structure of the compound simultaneously. We also developed a novel visual explanation method, gradient-weighted affinity activation mapping (Grad-AAM), to analyze a deep learning model from the chemical perspective. We evaluated our approach using seven benchmark datasets and compared the proposed method to the state-of-the-art deep learning (DL) models. MGraphDTA outperforms other DL-based approaches significantly on various datasets. Moreover, we show that Grad-AAM creates explanations that are consistent with pharmacologists, which may help us gain chemical insights directly from data beyond human perception. These advantages demonstrate that the proposed method improves the generalization and interpretation capability of DTA prediction modeling.

## Section: Introduction

Drug discovery aims to detect drugs that can bind to the target and then change disease progression. The identification of drug–target interactions is an important step in developing new drugs and understanding their side effects.1 Binding affinity provides information on the strength of the interaction between a drug–target pair, and it is usually expressed in measures such as dissociation constant (Kd), inhibition constant (Ki), or the half-maximal inhibitory concentration (IC50).2 Protein microarrays3 and affinity chromatography4 are two biological experimental methods to measure binding affinity. To identify effective and safe drugs for a given protein, pharmacologists have to test thousands of chemical compounds.5 However, the experimental measurement of drug–target affinities (DTAs) is both time- and resource-consuming. In silico methods for DTA prediction have received great attention due to their efficiency and low cost. The existing in silico methods can be mainly divided into three categories: structure-based methods, feature-based methods, and deep learning methods.

Structure-based methods can explore the potential binding sites by considering the 3D structure of a small molecule and a protein. Docking is a well-established structure-based method that uses numerous mode definitions and scoring functions to minimize free energy for binding. Molecular dynamics simulation is another popular structure-based method that can provide the ultimate detail concerning individual particle motions as a function of time.6 However, the structure-based methods are time-consuming and can not be employed if the 3D structure of the protein is unknown.7

Feature-based methods for DTA prediction modeling are also known as proteochemometrics (PCM),8–10 which relies on a combination of explicit ligand and protein descriptors. Any pairs of drugs and targets can be represented in terms of biological feature vectors with a certain length, often with binary labels that determine whether the drug can bind to the target or not. The extracted biological feature vectors can be used to train machine/deep learning models such as feed-forward neural networks (FNNs), support vector machine (SVM), random forest (RF), and other kernel-based methods.11–19 For example, DeepDTIs20 chose the most common and simple features: extended connectivity fingerprints (ECFP) and protein sequence composition descriptors (PSC) for drugs and targets representation, and then used a deep belief network for DTA prediction. Lenselink et al.11 compared FNNs with different machine learning methods such as logistic regression, RF, and SVM on one single standardized dataset and found that FNNs are the top-performing classifiers. A study conducted by Mayr et al.12 also found a similar result that FNNs outperform other competing methods. MDeePred21 represented protein descriptors by the combination of various types of protein features such as sequence, structural, evolutionary, and physicochemical properties, and a hybrid deep neural network was used to predict binding affinities from the compound and protein descriptors. MoleculeNet22 introduced a featurization method called grid featurizer that used structural information of both ligand and target. The grid featurizer considers not only features of the protein and ligand individually but also the chemical interaction within the binding pocket.

Over the past few years, there has been a remarkable increase in the amount of available compound activity and biomedical data owing to the emergence of novel experimental techniques such as high throughput screening, parallel synthesis among others.23–25 The high demand for exploring and analyzing massive data has encouraged the development of data-hungry algorithms like deep learning.26,27 Many types of deep learning frameworks have been adopted in DTA prediction. DeepDTA2 established two convolutional neural networks (CNNs) to learn the representations of the drug and protein, respectively. The learned drug and protein representations are then concatenating and fed into a multi-layer perceptron (MLP) for DTA prediction. WideDTA28 further improved the performance of DeepDTA by integrating two additional text-based inputs and using four CNNs to encode them into four representations. Lee et al.29 also utilized CNN on the protein sequence to learn local residue patterns and conduct extensive experiments to demonstrate the effectiveness of CNN-based methods. On the other hand, DEEPScreen represented compounds as 2-D structural images and used CNN to learn complex features from these 2-D structural drawings to produce highly accurate DTA predictions.30

Although CNN-based methods have achieved remarkable performance in DTA prediction, most of these models represent the drugs as strings, which is not a natural way to represent compounds.31 When using strings, the structural information of the molecule is lost, which could impair the predictive power of a model as well as the functional relevance of the learned latent space. To address this problem, graph neural networks (GNNs) have been adopted in DTA prediction.31–36 The GNN-based methods represent the drugs as graphs and use GNN for DTA prediction. For instance, Tsubaki et al.34 proposed to use GNN and CNN to learn low-dimensional vector representation of compound graphs and protein sequences, respectively. They formulated the DTA prediction as a classification problem and conducted experiments on three datasets. The experimental results demonstrate that the GNN-based method outperforms PCM methods. GraphDTA31 evaluated several types of GNNs including GCN, GAT, GIN, and GAT–GCN for DTA prediction, in which DTA was regarded as a regression problem. The experimental results confirm that deep learning methods are capable of DTA prediction, and representing drugs as graphs can lead to further improvement. DGraphDTA37 represented both compounds and proteins as graphs and used GNNs on both the compound and protein sides to obtain their representations. Moreover, to increase the model interpretability, attention mechanisms have been introduced into DTA prediction models.32,36,38–40

On the other hand, some researches focused on improving DTA prediction by using structural-related features of protein as input.37,41 For example, DGraphDTA37 utilized contact maps predicted from protein sequences as the input of the protein encoder to improve the performance of DTA predictions. Since protein structural information is not always available, they use contact maps predicted from the sequences, which enables the model to take all sorts of proteins as input.

Overall, many novel models for DTA prediction based on shallow GNNs have been developed and show promising performance on various datasets. However, at least three problems have not been well addressed for GNN-based methods in DTA prediction. First, we argue that GNNs with few layers are insufficient to capture the global structure of the compounds. As shown in Fig. 1(a), a GNN with two layers is unable to know whether the ring exists in the molecule, and the graph embedding will be generated without considering the information about the ring. The graph convolutional layers should be stacked deeply in order to capture the global structure of a graph. Concretely, to capture the structures make up of k-hop neighbors, k graph convolutional layers should be stacked.42 However, building a deep architecture of GNNs is currently infeasible due to the over-smoothing and vanishing gradient problems.43,44 As a result, most state-of-the-art (SOTA) GNN models are no deeper than 3 or 4 layers. Second, a well-constructed GNN should be able to preserve the local structure of a compound. As shown in Fig. 1(b), the methyl carboxylate moiety is crucial for methyl decanoate and the GNN should distinguish it from the less essential substituents in order to make a reasonable inference. Third, the interpretability of graph-based DTA models highly relies on the attention mechanism. Although the attention mechanism provides an effective visual explanation, it increases the computational cost. In addition, the graph attention mechanism only considers the neighborhood of a vertex (also called masked attention),45,46 which can not capture the global relationship between each atom of a molecule.

To address the above problems, we proposed a multiscale graph neural network (MGNN) and a novel visual explanation method called gradient-weighted affinity activation mapping (Grad-AAM) for DTA prediction and interpretation. An overview of the proposed MGraphDTA is shown in Fig. 2. The MGNN with 27 graph convolutional layers and a multiscale convolutional neural network (MCNN) were used to extract the multiscale features of drug and target, respectively. The multiscale features of the drug contained rich information about the molecule's structure at a different scale and enabled the GNN to make a more accurate prediction. The extracted multiscale features of the drug and target were fused respectively and then concatenated to obtain a combined descriptor for a given drug–target pair. The combined descriptor was fed into a MLP to predict binding affinity. Grad-AAM used the gradients of the affinity flowing into the final graph convolutional layer of MGNN to produce a probability map highlighting the important atoms that contribute most to the DTA. The proposed Grad-AAM was motivated by gradient-weighted class activation mapping (Grad-CAM) that can produce a coarse localization map highlighting the important regions in the image.47 However, the Grad-CAM was designed for neural network classification tasks based CNNs. Unlike Grad-CAM, Grad-AAM was activated by the binding affinity score based on GNNs. The main contributions of this paper are twofold:

(a) We construct a very deep GNN for DTA prediction and rationalize it from the chemical perspective.

(b) We proposed a simple but effective visualization method called Grad-AAM to investigate how GNN makes decisions in DTA prediction.

## Section: Methods › Input representation

The input molecules are SMILES (Simplified Molecular Input Line Entry System) that describes the structure of chemical species using short ASCII strings, while the input targets are protein sequences (strings) in which each character represents an amino acid. We preprocessed the SMILES into graphs with vertex (or node) features and adjacency matrix using RDkit48 as shown in Fig. 3(a). More detailed information about the vertex features can be found in ESI Tables S1 and S2.† For protein sequences, we first built a vocabulary to map each character to an integer (e.g. alanine (A) is 1, cysteine (C) is 2, glutamic acid (E) is 4, and so on) so that the protein can be represented as an integer sequence. To make it convenient for training, we decided on fixed maximum lengths of 1200 for protein sequence so that the maximum lengths cover at least 80% of the proteins as suggested by the earlier study.2 We then mapped each integer into a learnable 128-dimensional vector by an embedding layer2,29 (i.e., each amino acid can be represented by a 128-dimensional embedding vector). Although one-hot vectors can also be used to encode proteins, they are not able to describe the semantical similarity between two different amino acids. For example, each pair of different one-hot vectors has a zero cosine similarity.

## Section: Methods › Graph neural network

A graph is represented as where is the set of vertices and is the set of edges. In a molecule, is the i-th atom and is the chemical bond between i-th and j-th atoms. A GNN maps a graph to a vector usually with a message passing phase and readout phase.49 As shown in Fig. 3(b) and (c), The message passing phase updates each vertex information by considering its neighboring vertices in , and the readout phase computes a feature vector y for the whole graph.

## Section: Methods › Graph neural network › Message passing phase

Given a graph , we denoted the i-th vertex embedding at time step t as . We then updated xi(t) into using the following graph convolutional layer:501where are learnable weight matrices shared across all vertices, is the set of neighbors of vertex i, and σ contains a node-level batch normalization44 followed by a ReLU activation function, in which batch normalization is essential for very deep models.51 By using eqn (1) to aggregate the neighboring messages and iterate them over time steps, vertex embeddings can gradually gather more global information on the graph.

## Section: Methods › Graph neural network › Readout phase

To obtain the final output vector y from the set of vertex vectors in , we take the average of the vertex embeddings:2where is the number of vertices in the molecular graph, and L is the final time step. The readout phase aggregates vertex embeddings into a unified graph embedding.

## Section: Methods › Multiscale graph neural network for drug encoding

After representing the drug compounds as graphs, we designed a MGNN based on chemical intuition that learns effectively from graphical data. Fig. 4 shows the network architecture of the proposed MGNN. The MGNN includes three multiscale blocks in which each multiscale block is followed by a transition layer as shown in Fig. 4(a).

## Section: Methods › Multiscale graph neural network for drug encoding › Multiscale block

A multiscale block contains N graph convolutional layers described by eqn (1). Motivated by DenseNet,43,52 we introduced the dense connection into the GNN. The dense connection links each layer to every other layer in a feed-forward fashion, as shown in Fig. 4(b). Dense connections allow all layers to have direct access to receive the gradients of the loss function with respect to each weight, thereby avoiding the vanishing gradient problem and allowing for training very deep GNNs. Formally, we can express the multiscale block as3where is a graph convolutional layer described by eqn (1) with parameters Θn (consist of W1 and W2) in which n represents n-th layer, and ∥ is the concatenate operation. The multiscale block extracts multiscale features which described the structure information of a molecule in both local and global contexts.

## Section: Methods › Multiscale graph neural network for drug encoding › Transition layer

To increase the depth of the MGNN, we used the transition layers to connect two adjacent multiscale blocks. The transition layer aims to integrate the multiscale features from the previous multiscale block and reduce the channel number of the feature map. Specifically, for an input multiscale features at time step N + 1 as we expressed the transition layer as follow:4where are learnable weight matrices shared across all vertices in which M = d + (N − 1)h. By using the transition layer, we reduced the channel numbers to half of the input to save computational cost. Finally, a readout layer described by eqn (2) was used to convert the whole graph to a feature vector

## Section: Methods › Multiscale convolutional neural network for target encoding

Following the idea of MGNN, we used a MCNN to extract the multiscale features of a protein, as shown in Fig. 5. In particular, we designed a network with three branches consisting of convolutional layers with different receptive fields to detect the local residue patterns of proteins at different scales. We increased the receptive fields by stacking 3 × 3 convolutional layers and the receptive fields of the three branches were 3, 5, and 7, respectively. Since there are only certain parts of a protein, such as specific domains or motifs, are involved in DTAs, rather than the whole protein structure.29 As a result, increasing the receptive field to cover the whole protein sequence does not seem to be appropriate for DTA prediction due to noise information from the portions of the sequence that are not involved in DTA.29 Formally, for an input integer protein sequence with a length of 1200, we first used an embedding layer2,28,29,31 to map each integer to a 128-dimensional vector following the previous studies2,28,31 and obtained an input matrix We then used the MCNN to map the S into a feature vector as5where is the i-th branch with i 3 × 3 convolutional layers that maps into a matrix in which each convolutional layer is followed by ReLU activation, m represents maxpool operation that maps into a h-dimensional vector, and is a learnable matrix.

## Section: Methods › MGraphDTA network architecture

After obtaining the vector representation of drug and target, the two representations are then concatenated and fed into a MLP to predict the binding affinity score, as shown in Fig. 2. Concretely, the MLP contains three linear transformation layers to map the combined representation into affinity score in which each linear transformation layer is followed by a ReLU activation and dropout layer with a dropout rate of 0.1 following with the previous studies.2,28 MGraphDTA contains a MGNN for drug encoding, a MCNN for target encoding, and a MLP for DTA prediction, as shown in Fig. 2. We used the mean squared error (MSE) as the loss function as follows.6where Pi and Yi are the predictive score and the ground truth score of i-th drug–target pair, and n is the sample size. We also considered DTA prediction as a binary classification problem by simply replacing the MSE loss with cross-entropy loss.53

## Section: Methods › Gradient-weighted affinity activation mapping

To improve the interpretation capability of DTA modeling, we proposed an attention-free visual interpretation method called Grad-AAM. Grad-AAM used the gradient information flowing into the last graph convolutional layer of the MGNN to understand the importance of each neuron for a decision of affinity. The graph convolutional layer naturally retains spatial information which is lost in fully connected layers. Therefore, we can expect the last graph convolutional layer to have the best compromise between high-level semantics and detailed spatial information.47 Specifically, denoting the feature map of the last graph convolutional layer as A, in order to obtain the chemical probability map with vertex numbers for a given molecule, we first computed the gradient of the affinity score P with respect to a neuron Avk at k-th channel and v-th vertex of A as . Then the channel importance weights αk can be computed as7

We then performed a weighted combination of the forward activation maps followed by a ReLU activation as8

Finally, min–max normalization was used to map the probability map PGrad-AAM ranging from 0 to 1. The chemical probability map PGrad-AAM can be thought of as a weighted aggregation of important geometric substructures of a molecule that are captured by a GNN as shown in Fig. 6.

## Section: Methods › Dataset

The benchmark datasets for the regression task used in this study are the Metz,54 KIBA,55 Davis56 datasets. The binding affinities of the three datasets are measured in inhibition constant (Ki), KIBA score,55 and dissociation constant (Kd), respectively. Note that the Davis dataset is highly biased in terms of that all drug–target pairs where the activity could not be experimentally measured are labeled with 10 μM bioactivity value (i.e., pKd value 5), and the number of data points that fit into this definition is extremely high (as shown in Fig. S1†). Therefore, we also evaluated the model's performance in the filtered Davis dataset21 in which data points with 10 μM bioactivity are removed.

We also formulated DTA prediction as a binary classification problem and evaluated the proposed MGraphDTA in two widely used classification datasets, Human and Caenorhabditis elegans (C. elegans).34,38,46

Moreover, we conducted a case study to evaluate the Grad-AAM using the ToxCast dataset.35 Since the ToxCast dataset contains multiple assays which means that one drug–target pair may have different binding affinity depending on the type of assay. For simplicity, we only selected one of the assays containing the largest drug–target pairs. Table 1 summarizes these datasets. Fig. S1–S3† show the distribution of binding affinities, SMILES length, and protein sequence length of these datasets.

## Section: Methods › Experimental setup

Experiments were conducted using an NVIDIA GeForce GTX 2080TI with 11 GB memory. Adam optimizer57 with a 0.0005 learning rate was used to update model parameters. The batch size was set to 512. We optimized the hyper-parameters for MGraphDTA in the training set of Davis under the five-fold cross-validation using an automatic hyper-parameters optimization software Optuna.58 The optimized hyper-parameters were then kept fixed for all other datasets. Table S3† lists the detailed hyper-parameters setting. The MGNN consisted of 27 graph convolutional layers containing three multiscale blocks with N = 8 graph convolutional layers and three transition layers.

## Section: Results and discussion › Compare with SOTA DTA prediction models in classification tasks

For the classification task, we used the area under curve (AUC), precision, and recall as performance metrics to evaluate the model following the previous studies.34,38,46 We compared the MGraphDTA with the SOTA GNN,34 GraphDTA,31 TrimNet,46 VQA-seq,41 and TransformerCPI38 models. It should be noted that DrugVQA41 uses structural-related features of protein as input, while its alternative version VQA-seq41 that only uses protein sequence information is listed here for a fair comparison. To ensure a fair comparison, we experimented with the same dataset and data split scheme as the previous studies.34,46 GraphDTA31 was originally designed for regression tasks and had been tailored for classification tasks by Chen et al.38 and we used the results they reported for comparisons. All experiments were repeated three times, each with a different random seed following the previous studies.38,41 We finally reported the mean and standard deviation of results in DTA prediction.

Table 2 summarizes the quantitative results. For the Human dataset, the proposed method yielded a significantly higher precision than that of other methods for DTA prediction. For the C. elegans dataset, the proposed method achieved considerable improvements in both precision and recall. These results reveal MGraphDTA's potential to master molecular representation learning for drug discovery. Besides, we observed that replacing CNN with MCNN can yield a slight improvement, which corroborates the efficacy of the proposed MCNN.

## Section: Results and discussion › Compare with SOTA DTA prediction models in regression tasks

For the regression task on Davis, KIBA, and Metz datasets, we used mean square error (MSE, the smaller the better), concordance index (CI, the larger the better),59 and rm2 index (the larger the better)60 as performance metrics to evaluate the model following the previous studies.2,28,31 We compared the proposed MGraphDTA with the SOTA DeepDTA,2 WideDTA,28 GraphDTA,31 and DeepAffinity32,33 models. We excluded DGraphDTA37 which used structural-related features of protein as input for a fair comparison. We also compared the proposed method with five traditional PCM models11,12 including KronRLS, SimBoost, random forest (RF), support vector machine (SVM), and feed-forward neural network (FNN). The results of KronRLS and SimBoost were taken from DeepDTA,2 while the other three methods were implemented using sklearn61 and PyTorch62 (details of the PCM models construction are available in Section S1 of ESI†). For Davis and KIBA datasets, we used the same training and test set as DeepAffinity and GraphDTA for a fair comparison. Since the previous studies did not report the experimental results on the Metz dataset, we randomly split the Metz dataset into training (28207) and test (7052) sets and retrained the models using the source codes2,31 they provided with published hyperparameter grids. All experiments were repeated three times, each with a different random seed.

For the regression task on the filtered Davis dataset, we compared the proposed MGraphDTA with SOTA methods in this dataset, which were MDeePred,21 CGKronRLS,63 and DeepDTA.2 We used root mean square error (RMSE, the smaller the better), CI, and Spearman rank correlation (the higher the better) as performance indicators following MDeePred. The whole dataset was randomly divided into six parts; five of them were used for fivefold cross-validation and the remaining part was used as the independent test dataset. The final performance was evaluated on the independent test dataset following MDeePred. Note that the data points in each fold are exactly the same as MDeePred for a fair comparison.

Tables 3 and 4 summarize the predictive performance of MGraphDTA and previous models on the Davis, KIBA, and Metz datasets. The graph-based methods surpassed CNN-based and recurrent neural network (RNN) based methods, which demonstrates the potential of graph neural networks in DTA prediction. Since CNN-based and RNN-based models represent the compounds as strings, the predictive capability of a model may be weakened without considering the structural information of the molecule. In contrast, the graph-based methods represent compounds as graphs and capture the dependence of graphs via message passing between the vertices of graphs. Compared to other graph-based methods, MGraphDTA achieved the best performances as shown in Tables 3 and 4. The paired Student's t-test shows that the differences between MGraphDTA and other graph-based methods are statistically significant on the Metz dataset (p < 0.05). Moreover, MGraphDTA was significantly better than traditional PCM models on three datasets (p < 0.01). It is worth noting that FNN was superior to other traditional PCM models (p < 0.01), which is consistent with the previous studies.11,12Table 5 summarizes the results of four methods in the filtered Davis dataset. It can be observed that MGraphDTA achieved the lowest RMSE. Overall, MGraphDTA showed impressive results on four benchmark datasets that exceed other SOTA DTA prediction models significantly, which reveals the validity of the proposed MGraphDTA.

## Section: Results and discussion › Performance evaluation on more realistic experimental settings

Sections 3.1 and 3.2 describe the experimental results using the random split setting (i.e., training and test sets share common drugs and targets). However, it is noteworthy that the random split setting can lead to over-optimistic results because it results in information leakage (e.g., drug or target information) to the test set.12 To further demonstrate the efficacy of the proposed MGNN, we assessed the MGraphDTA in three additional splitting schemes besides the random split setting used in the previous studies:2,28,31,32

(1) Orphan–target split: each protein in the test set is unavailable in the training set.

(2) Orphan–drug split: each drug in the test set is inaccessible in the training set.

(3) Cluster-based split: compounds in the training and test sets are structurally different (i.e., the two sets have guaranteed minimum distances in terms of structure similarity). We used Jaccard distance on binarized ECFP4 features to measure the distance between any two compounds following the previous study.12 Single-linkage clustering12 was applied to find a clustering with guaranteed minimum distances between any two clusters.

Given that the DTA prediction models are typically used to discover drugs or targets that are absent from the training set, the orphan splits provide realistic and more challenging evaluation schemes for the models. The cluster-based split further prevents the structural information of compounds from leaking to the test set. We compared the proposed MGraphDTA to GraphDTA and three traditional PCM models (RF, SVM, and FNN). For a fair comparison, we replaced the MGNN in MGraphDTA with GCN, GAT, GIN, and GAT–GCN using the source code provided by GraphDTA with the hyper-parameters they reported. We used the five-fold cross-validation strategy to analyze model performance. In each fold, all methods shared the same training, validation, and test sets. Note that the experimental settings remain the same for the eight methods.

Fig. 7 shows the experimental results for eight methods using the orphan-based and cluster-based split settings. Compared with the results using the random split setting shown in Tables 3 and 4, we found that the model's performance decreases greatly in the orphan-based and cluster-based split settings. Furthermore, as shown in Fig. 7(a) and (c), the MSE for MGraphDTA on Davis, KIBA, and Metz datasets using the orphan–drug split were 0.572 ± 0.088, 0.390 ± 0.023, and 0.555 ± 0.043, respectively while those using the cluster-based split were 0.654 ± 0.207, 0.493 ± 0.097, and 0.640 ± 0.078, respectively. In other words, the cluster-based split is more challenging to the DTA prediction model compared to the orphan–drug split, which is consistent with the fact that the cluster-based split setting can prevent the structural information of compounds from leaking to the test set. These results suggest that improving the generalization ability of the DTA model is still a challenge. From Fig. 7(a), we observed that MGNN exceeded other methods significantly in the Davis dataset using the orphan–drug split setting (p < 0.01). On the other hand, there were no statistical differences between MGNN, GAT, and RF (p > 0.05) in the KIBA dataset while these three methods surpassed other methods significantly (p < 0.01). In addition, SVM and FNN methods were superior to other methods significantly in the Metz dataset (p < 0.01). Overall, the traditional PCM models showed impressive results that even surpassed graph-based methods in the KIBA and Metz datasets using the orphan–drug split setting as shown in Fig. 7(a). These results suggest that it may be enough to use simple feature-based methods like RF in this scenario, which is consistent with a recent study.64 Since the number of drugs in the Davis dataset is significantly less than that in KIBA and Metz datasets as shown in Table 1, the generalization ability of a model trained on limited drugs can not be guaranteed for unseen drugs. Fig. 8 shows the correlations between predictive values and ground truths of five graph-based models in the Davis dataset using orphan–drug splitting. The predictive value of MGNN was broader than that of other graph-based models as shown in Fig. 8(a). We also noticed that the ground truths and predictive values of MGNN have the most similar distributions as shown in Fig. 8(b). The Pearson correlation coefficients of GCN, GAT, GIN, GAT–GCN, and MGNN for DTA prediction were 0.427, 0.420, 0.462, 0.411, and 0.552, respectively. These results further confirm that MGNN has the potential to increase the generalization ability of the DTA model. From Fig. 7(b), we observed that MGNN outperforms other models significantly in three datasets using the orphan–target split setting (p < 0.01). MGNN also exceeded other methods significantly in KIBA and Metz datasets using the cluster-based split setting as shown in Fig. 7(c) (p < 0.05). It is worth noting that graph-based methods outperformed traditional PCM models in the random split setting as shown in Tables 3 and 4, while the superiority of the graph-based methods was less obvious in the orphan-based and cluster-based split settings as shown in Fig. 7. Overall, the results show the robustness of MGNN in different split setting schemes and prove that both local and nonlocal properties of a given molecule are essential for a GNN to make accurate predictions.

## Section: Results and discussion › Ablation study

In our designs, the successful construction of the very deep GNN highly relies on dense connection and batch normalization. The dense connection boosts the model performance by alleviating the over-smoothing and vanishing gradient problems, while the batch normalization is able to reduce the over-fitting of very deep models.51 An ablation study has been conducted to investigate the individual contributions of the dense connection and batch normalization. The experiments were performed from two ends; in the first case we removed the dense connection, and in the second, we removed the batch normalization. Table 6 summarizes the experimental results on the filtered Davis dataset. The results show that both dense connection and batch normalization are necessary for MGNN.

Furthermore, an ablation study was performed on the filtered Davis dataset to investigate the effect of the receptive field of MCNN on the performance. Specifically, we increased the receptive field gradually by using convolutional layers with a more and more large kernel (i.e., 7, 15, 23, 31). From the results shown in Table 7, it can be observed that the model performance was slightly decreased as increasing the receptive field. Since there are usually a few residues that are involved in protein and ligand interaction,65 increasing the receptive field to cover more regions may bring noise information from the portions of the sequence that are not involved in DTA into the model.

We also conducted an experiment to show that the MGraphDTA uses both compound and protein information for DTA prediction instead of learning the inherent bias in the dataset as reported in previous studies.66,67 In particular, we computed the activation values of each unit in the last layer of the two encoders (i.e., and described in Sections 2.3 and 2.4) in the Davis, filtered Davis, KIBA, and Metz datasets, respectively. The higher activation value indicates more contribution of the unit in the model's decision-making.68Fig. 9 shows the distribution of these activation values from the protein and ligand encoders. It can be observed that MGraphDTA used both protein and ligand information to make inferences. However, the model was biased toward the protein information in the Davis dataset. The bias is partly due to the unbalanced distribution of binding affinities (labels) of the Davis dataset as shown in Fig. S1† because it is lessened in the filtered Davis dataset as shown in Fig. 9. More precisely, the Davis dataset contains 63 proteins where any drug–target pairs relating to these proteins are labeled with 10 μM bioactivity values (i.e., pKd value 5). Therefore, a predictive model may simply output binding affinity values around 10 μM for drug–target pairs associated with these proteins, which causes the model biasing toward protein encoder. While these proteins are removed in the filtered davis dataset; thus the bias is alleviated. Another possible reason is that the Davis dataset only contains 68 compounds, which is insufficient to learn a robust drug encoder.

## Section: Results and discussion › Grad-AAM provides the visual explanation

Deep learning is usually referred to as the black-box model because it is difficult to trace a prediction back to which features are important. The lack of interpretability limits the applications of deep learning methods, especially in computer-aid drug discovery. Aiming to rationalize the graph-based models, we visualized the atom importance of molecules based on the Grad-AAM. We compared Grad-AAM with graph attention mechanism in the ToxCast dataset to see whether the graph-based models can detect key substructures responsible for certain toxicity or not (also called structural alerts69,70). We conducted three groups of experiments as follows:

(1) Visualizing MGNN model based on Grad-AAM.

(2) Visualizing GAT model based on Grad-AAM.

(3) Visualizing GAT model based on graph attention mechanism.

Specifically, we first replaced MGNN with a two layers GAT in which the first graph convolution layer had ten parallel attention heads using the source code provided by GraphDTA.31 We then trained MGNN-based and GAT-based DTA prediction models under the five-fold cross-validation strategy using the random split setting. Finally, we calculated the atom importance using Grad-AAM and graph attention mechanism and showed the probability map using RDkit.48

Table 8 shows the quantitive results of MGNN and GAT. MGNN outperformed GAT by a notable margin (p < 0.01), which further corroborates the superiority of the proposed MGNN. Fig. 10 shows the visualization results of some molecules based on Grad-AAM (MGNN), Grad-AAM (GAT), and graph attention (more examples can be found in ESI Fig. S4 and S5†). According to previous studies,71–75 epoxide,73 fatty acid,72,75 sulfonate,71 and aromatic nitroso74 are the structural alerts that correlate with specific toxicological endpoints. We found that Grad-AAM (MGNN) does give the highest weights to these structural alerts. Grad-AAM (MGNN) can not only identify important small moieties as shown in Fig. 10(a)–(d) but also reveal the large moieties as shown in Fig. 10(f), which proves that the MGNN can capture the local and global structures simultaneously. Grad-AAM (GAT) also discerned the structural alerts as shown in Fig. 10(b), (c), (e), and (f). However, Grad-AAM (GAT) sometimes failed to detect structural alerts as shown in Fig. 10(a) and (d) and we might also notice that the highlighted region involves more extensive regions, and does not correspond to the exact structural alerts as shown in Fig. 10(b), (c), and (e). These results suggest that the hidden representations learned by GAT were insufficient to well describe the molecules. On the other hand, the graph attention can only reveal some atoms of structural alerts as shown in Fig. 10(c), (d), and (f). The attention map contained less information about the global structure of a molecule since it only considers the neighborhood of an atom.45 The superiority of graph attention was that it can highlight atoms and bonds simultaneously, which the Grad-AAM can only highlight the atoms. Fig. 11 shows the distribution of atom importance for Grad-AAM (MGNN), Grad-AAM (GAT), and graph attention. The distribution for Grad-AAM (MGNN) was left-skewed, which suggested that MGNN pays more attention to some particular substituents contributing most to the toxicity while suppressing the less essential substituents. We also found that Grad-AAM (GAT) tends to highlight extensive atoms from the distribution which was consistent with the results shown in Fig. 10(b), (c), and (e). Conversely, the distribution of graph attention was narrow with most values less than 0.5, which suggested that graph attention often failed to detect important substructures. It is worth noting that some studies utilize global attention mechanisms while dropping all structural information of a graph to visualize a model and may also provide reasonable visual explanations.46,76 However, these global attention-based methods are model-specific so that the methods can not easily transfer to other graph models. Conversely, Grad-AAM is a universal visual interpretation method that can be easily transferred to other graph models. Moreover, the visual explanation results produced by Grad-AAM may be further improved by applying regularization techniques during the training of MGraphDTA.77

Overall, Grad-AAM tends to create more accurate explanations than the graph attention mechanism, which may offer biological interpretation to help us understand DL-based DTA prediction. Fig. 12 shows Grad-AAM (MGNN) on compounds with symmetrical structures. The distribution of Grad-AAM (MGNN) was also symmetrical, which suggests that representing compounds as graphs and using GNNs to extract the compounds' pattern is able to preserve the structures of the compounds.

## Section: Results and discussion › How does MGNN solve over-smoothing problems?

As we mentioned before, the very deep GNN was designed to capture the global and local structures of a compound simultaneously. However, the very deep GNN may cause an over-smoothing representation of vertices. In other words, our quest for a model that is more expressive and aware of the graph structure (by adding more layers so that vertices can have a large receptive field) could be transformed into a model that treats vertices all the same (the vertex representations converging to indistinguishable vectors).78 The message passing framework gather feature vectors from neighbors and combine them with the vertex features to update their representation. Therefore, the over-smoothing shows itself in the form of similarity between vertices' embedding. As illustrated in Fig. 13, more and more atoms are included in the calculation of the vertex representation as the model depth is increased. Meanwhile, the vertex embeddings of atom C2 and C1 become more and more similar and we can observe that the only difference in layer 3 is atom C5. Therefore, GNNs may be incapable to distinguish different substructures in a molecule as the model depth is increased. The proposed MGNN addresses the over-smoothing problem by integrating features from different receptive fields for a given vertex or atom as shown in Fig. 4(b). By introducing dense connections into GNN, substructures from different scales of a molecule can be kept despite the increasing model depth. The dense connections also increase the discrimination between each vertex embedding and therefore alleviate the over-smoothing problem. Table 6 shows that the dense connection can improve the model performance significantly (p < 0.01). Fig. 14 shows molecules with similar structures highlighted by Grad-AAM (MGNN). Grad-AAM (MGNN) detected subtle distinctions between the four molecules, which suggests that the MGNN can mitigate the over-smoothing problem.

## Section: Results and discussion › Limitations

Although MGraphDTA has shown significant improvements for DTA prediction tasks, there are some limitations in this study. First, this study only focuses on relatively small datasets. We will test MGraphDTA on large-scale datasets11,12 in future work. Second, it's worth noting that many compounds containing structural alerts are inactive (not having the specific toxicity). In order to determine whether a compound has toxicity to a specific target, we should analyze the drug–target binding mode. Future work will focus on binding mode visualization using Grad-AAM.

## Section: Conclusion

This work presented a novel graph-based framework based on chemical intuition called MGraphDTA for DTA prediction. MGraphDTA harnessed a MGNN with 27 graph convolutional layers to capture multiscale structures of a molecule and utilized Grad-AAM for visual interpretation. Extensive experiments corroborated the superiority of the proposed method which outperformed the state-of-the-art methods significantly on seven datasets. Moreover, we visualized the atom importance of certain molecules using Grad-AAM from the ToxCast dataset with toxicity as the labels and showed that MGNN was capable of detecting structural alerts. Our results demonstrate that MGraphDTA is a powerful tool to improve the generalization and interpretation capability of DTA prediction modeling.

## Section: Code availability

Demo, instructions, and code for MGraphDTA and Grad-AAM are available at https://github.com/guaguabujianle/MGraphDTA.

## Section: Data availability

All data used in this paper are publicly available and can be accessed at https://github.com/hkmztrk/DeepDTA/tree/master/data for the Davis and KIBA datasets, https://github.com/cansyl/MDeePred for the filtered Davis dataset, https://github.com/simonfqy/PADME for the Metz dataset and ToxCast datasets, and https://github.com/masashitsubaki/CPI_prediction for the Human and C. elegans datasets.

## Section: Author contributions

Calvin Yu-Chian Chen designed research. Ziduo Yang, Weihe Zhong worked together to complete the experiment and analyze the data. Calvin Yu-Chian Chen contributed to analytic tools. Ziduo Yang, Weihe Zhong, Lu Zhao, and Calvin Yu-Chian Chen wrote the manuscript together.

## Section: Conflicts of interest

The authors declare that they have no competing interests.


---

# MolData, a molecular benchmark for disease and target based machine learning

- **Authors:** Arash Keshavarzi Arshadi, Milad Salem, Arash Firouzbakht, Jiann Shiun Yuan
- **Issuer:** Journal of cheminformatics
- **Type:** Scientific article
- **Published:** 2022-03-07
- **Language:** en
- **DOI:** 10.1186/s13321-022-00590-y
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35255958/
- **Licence:** CC-BY

## Section: Abstract

Deep learning’s automatic feature extraction has been a revolutionary addition to computational drug discovery, infusing both the capabilities of learning abstract features and discovering complex molecular patterns via learning from molecular data. Since biological and chemical knowledge are necessary for overcoming the challenges of data curation, balancing, training, and evaluation, it is important for databases to contain information regarding the exact target and disease of each bioassay. The existing depositories such as PubChem or ChEMBL offer the screening data for millions of molecules against a variety of cells and targets, however, their bioassays contain complex biological descriptions which can hinder their usage by the machine learning community. In this work, a comprehensive disease and target-based dataset is collected from PubChem in order to facilitate and accelerate molecular machine learning for better drug discovery. MolData is one the largest efforts to date for democratizing the molecular machine learning, with roughly 170 million drug screening results from 1.4 million unique molecules assigned to specific diseases and targets. It also provides 30 unique categories of targets and diseases. Correlation analysis of the MolData bioassays unveils valuable information for drug repurposing for multiple diseases including cancer, metabolic disorders, and infectious diseases. Finally, we provide a benchmark of more than 30 models trained on each category using multitask learning. MolData aims to pave the way for computational drug discovery and accelerate the advancement of molecular artificial intelligence in a practical manner. The MolData benchmark data is available at https://GitHub.com/Transilico/MolData as well as within the additional files.Supplementary InformationThe online version contains supplementary material available at 10.1186/s13321-022-00590-y.

## Section: Introduction

In the last decade, Artificial Intelligence (AI) has played a major role in modern computer aided drug discovery (CADD). Major improvements in both structure-based and ligand-based virtual screening have been recorded by training smart systems capable of identifying hidden molecular patterns [1–3]. Training models for Ligand-Based Drug Discovery (LBDD), or non-structural drug discovery, have been truly revolutionary in multiple aspects of the early drug discovery process. Deep Learning (DL) models have demonstrated the ability to discover abstract features of small molecules, allowing for better screening of both cell-based and target-based CADD. Using conventional methods, scientists would need to screen every molecule in a library on a specific target or cell, which is expensive, labor intensive, and time consuming. Virtual screening algorithms have introduced more affordable and faster alternatives that eliminate most of the early drug discovery costs. However, despite advances in CADD, the accuracy of traditional molecular modeling methods in most cases had not been satisfactory, prior to the introduction of Machine Learning (ML). Automatic feature extraction from molecules and learning of hidden patterns in a large molecular library, are just some examples of what AI has changed forever in the drug discovery field [1, 4].

One of the most important factors of a reliable model is its training data, and deep learning models utilize this data to automate both pattern extraction and the prediction of bioactive molecules [5, 6]. In general, datasets that are large, more diverse, and less biased result in training smarter systems with better inner features, performance, and generalization. Therefore, the first goal for machine learning scientists should be identifying and curating the right dataset per disease state. This curation can include selection of bioassays that relate to the biological question at hand typically guided by the description of the bioassays, cleaning the molecular data and dealing with the sparse and missing values within the molecular dataset. In addition, understanding the biological knowledge behind a dataset is as important as the data quality. Since data curation, model training, and model evaluation are time consuming and tedious, it is crucial to know the exact applications of the biological target for the disease of interest. To this end, current input datasets need to be improved upon. Firstly, biomedical datasets tend to be very biased and imbalanced based on the biological assay and the chemical library [7]. Secondly, understanding the exact cellular and molecular background and description of the assays requires expert knowledge that ML scientists or cheminformaticians might not possess. Without knowing the biological background of the data, it would be difficult to devise solutions for data balancing and model evaluation. This knowledge is also necessary for finding appropriate public datasets due to their complicated descriptions and goals. Lastly, the chemical diversity, druggability, and toxicity of the predicted molecules need to be investigated [8, 9]. With the emergence of AI in non-structural drug discovery, there has been a renewed need for cleaned and clustered public molecular databases with simple and sufficient biological information, including the proper disease and targets involved in each bioassay.

There are multiple molecular depositories containing millions of molecules and hundreds of thousands of bioassays for specific biomedical aims. PubChem bioassays [10], ChEMBL datasets [12], and ChemSpider [13] are among some of the most comprehensive and well-known examples. These databases collect large sets of molecular activity outcomes for specific cells or protein targets. Even though these databases are excellent resources for model training, discovering the right bioassays and categorizing them based on disease, targets, and signaling pathways can often be challenging and non-intuitive due to their non-standardized descriptions [14, 15]. However, the scientific community persists and has been benchmarking datasets and methods with these depositories, and in-house databases, in order to facilitate their usage and accelerate the advancement of molecular machine learning [16]. To do so, researchers often curate, analyze, and publish datasets with intended targets for discovering specific patterns in bioactive molecules. One of the first examples would be the ‘Merck Molecular Activity Challenge’ which had 15 biological assay tasks. In this dataset, targets are selected based on their molecular classes [17]. In toxicity field, the Tox21 dataset from National Center for Advancing Translational Science (NCATS) containing 12 specific assays for nuclear receptor (NR) and stress response (SR) signaling pathway has been one of the most popular sources for advancing different learning methods such as transfer learning, multitask learning, few-shot learning etc. [9, 18, 19]. Additionally, the PCBA dataset [10] from MoleculeNet and Massively Multitask Learning projects provided more than 120 PubChem bioassays with diverse sets of targets. It consists of curated public datasets, metrics for evaluations, and an open-source library in python called DeepChem [1, 16]. Even though these benchmarks have served to aid cheminformaticians and ML scientists in discovering candidate drugs and allowed for better modeling, their bioassays lack the essential information like disease and target relevance. Benchmarks such as MoleculeNet and ChemProp mostly focus on basic fields like Quantum mechanics or biophysics, but none has focused on specific diseases, the comprehensive class of targets and specially the comparison of these two. The main aim of this article is to connect the biomedical side of the molecular machine learning to the data science side, to infuse the disease classification into training for a real-world purpose. The aim is not to prove that disease categorization is beneficial for every specific type of learning, but to give machine learning scientists the means to model based on disease categorization and to develop better computational technologies with a biological purpose [1, 20].

Annotation and ontology development have been very important sources for scientists to better understand and find the bioassays with unstandardized descriptions in depositories. As an example, Vempati et al. developed a very comprehensive list of classes for a diverse set of variables in bioassays, from diseases to bioassay types [15]. Despite huge contribution to biomedical community to identify the bioassay of interest using specific ontologies, they lack resolution in terms of classes offered for diseases and targets. We believe a reliable and practical ML model can be designed based on a known set of targets for a specific disease, fulfilling the need for a benchmark dataset that provides a comprehensive set of related assays. However, there are major challenges of developing a comprehensive benchmark dataset containing all information such as target classes and disease categories. Firstly, assigning each task to specific disease(s), protein target(s), and signaling pathway(s) categories would be very time consuming, labor intensive, and in some cases, impossible with traditional approaches. Moreover, manually assigning each bioassay to different classes is very error prone. Secondly, clustering such big data requires chemical, biomedical, and computational knowledge which makes it difficult to perform. Therefore, we believe novel technology such as deep learning and natural language processing (NLP) should be employed to confront such challenges of dataset benchmarking. MolData, which is developed by the implementation of novel methods such as NLP, is one of the most comprehensive disease and target-based benchmarks for democratizing molecular machine learning. It consists of 600 diverse bioassays from PubChem which are curated and clustered into 15 different diseases categories, one Toxicity dataset, and 14 unique protein target classes. One of the most important steps in every drug discovery and development process would be molecular toxicity and side effect assessment. Therefore, we decided to have one comprehensive category for Toxicity related tasks due to the importance of it for successful drug discovery. More than 1.4 million distinct molecules are presented in this benchmark, which consists of more than 170 million molecular screening data points. The majorities of the Bioassays (> 85%) include UniProt IDs to assist the extraction of diverse kinds of information including Molecular Function, Biological Process, Pathway Dataset, Protein Family Group, Taxonomy, Subcellular Location, Topology and BLAST, Expression and interactions, etc. MolData aims to assist in the discovery of better and more diverse candidate drugs via the meaningful aggregation of large datasets. In doing so, it can be one of the main sources for the ML and Data Science community to develop practical molecular machine learning models. The main reasons for developing a disease categorized dataset are firstly, to ease the search of ML community and cheminformaticians for datasets of one specific disease or protein targets. Secondly, to help the ML community to develop better technology and modeling not only based on random datasets, but on meaningful disease categorized ones. To demonstrate the application of MolData, we have run a correlation analysis to investigate drug repurposing, from which we have discovered three sets of bioassays highly correlated in both active and inactive molecules. Lastly, we trained more than 30 different multitask learning-based models, each for a specific disease or target, and one for all bioassays combined. These models can serve as a baseline for the data science community in order to advance molecular machine learning and enable better drug discovery.

## Section: Results

The pipeline of MolData benchmark creation

Data

source summary. MolData was created using 9 data sources, the number of bioassays within each data source is shown in AID count column. Each molecule in a given source can have bioactivity for multiple bioassays and constitute multiple data points. Unique active molecules are defined as molecules that demonstrate bioactivity in at least one bioassay

Map of the bioassays’ descriptions using the output of the BioBERT model (The explained variance ratio for the first and second principal components are 14.72% and 5.40% respectively)

Disease-based information for the MolData Benchmark

Target-based information for the MolData Benchmark

The composition of the disease benchmark: Number of bioassays for each disease category (as well as toxicity) and their original source

The composition of the target benchmark: Number of bioassays for each target category and their original source

Cumulative histogram of the largest Tanimoto Similarity Coefficient for 200,000 molecules within the MolData dataset. More than 92% of the molecules have other similar molecules to them within the dataset with Tanimoto Coefficient of higher than 0.5, and more than 44% of the molecules for Coefficient of 0.7

Correlation matrix between a Toxicity bioassays, b Non-Toxic bioassays with correlation > 0.5

Classification results on the validation and test sets of disease categories, averaged on all tasks within each category

Classification results on the validation and test sets of target categories, averaged on all tasks within each category

## Section: Results › Benchmark creation pipeline

The overview of the benchmark creation pipeline is depicted in Fig. 1. The process started by downloading the descriptions and summary of each data-source from PubChem. Due to the large number of selected bioassays, computational methods were implemented to aid in the creation of the benchmark and serve as guideline for the manual tagging of each bioassay. The assay descriptions were first grouped into 10 clusters using BioBERT [21, 22], and tagged using a similar disease entity recognition model. Having done so, each description was tagged manually with the assistance of the computational model results. By tagging assays in clusters separately, the similar keywords used for tagging were easier to detect. Manual tagging resulted in sixteen different disease-based categories of data. In addition, we used ChEMBL repository [12] to identify each task’s target class. After assigning each bioassay to one or more disease and target categories, the benchmark was analyzed with multiple approaches. After assigning each bioassay to one or more disease categories using specific keywords, the benchmark was analyzed with multiple approaches, such as mapping the molecular domain. For the application of drug repurposing, we ran a correlation analysis on the data and discovered three sets of correlated bioassays. Finally, different multitask graph convolutional neural networks (GCNNs) [23] were trained in order to create a baseline for the performance of multitask learning models in each disease related category. The main dataset of MolData which is the result of this pipeline can be found on the GitHub repository as well as in Additional file 1.Fig. 1The pipeline of MolData benchmark creation

The pipeline of MolData benchmark creation

## Section: Results › Data aggregation results

MolData benchmark originates from 9 open-source data sources on PubChem, which are the largest in terms of number of screened molecules and number of active bioassays [24], as shown in Table 1. Initially, these collected data contained more than 1000 bioassays, which were then triaged to 600 bioassays (Bioassay Identifier will start by “AID” acronym) after filtering datasets smaller than 100,000 molecules or 15 active molecules. We included the updated Tox21 source [25] with more than 55 different bioassays due to their applicability to drug screening. As seen in Table 1, the activity percentage of each screening task was usually less than 1%, showing the imbalanced nature of the screening datasets. The bioassay IDs of the used datasets as well as their related source are available in Additional file 2. All 600 bioassays are cited within an additional reference list included in Additional file 3.Table 1Data source summary. MolData was created using 9 data sources, the number of bioassays within each data source is shown in AID count column. Each molecule in a given source can have bioactivity for multiple bioassays and constitute multiple data points. Unique active molecules are defined as molecules that demonstrate bioactivity in at least one bioassayPubChem SourceAID countActive data pointsTotal data points% Active datapointsUnique active moleculesTotal unique molecules% Unique active moleculesBroad Institute67125,62722.2 m0.56%85,579472,85818.1%Burnham Center for Chemical Genomics67139,02121.9 m0.63%77,159381,79420.21%Emory University Molecular Libraries Screening Center1224,1952.47 m0.98%20,964348,2316.02%ICCB-Longwood Screening Facility, Harvard Medical School1183582.1 m0.39%6656564,0211.18%Johns Hopkins Ion Channel Center2248,5456.8 m0.71%35,487344,49710.30%NMMLSC4248,18611.5 m0.42%37,949369,43110.27%National Center for Advancing Translational Sciences (NCATS)174720,31953.4 m1.35%240,096592,61640.51%The Scripps Research Institute Molecular Screening Center148275,22447.6 m0.58%142,055920,41815.43%Tox215721,4750.47 m5.67%4183874347.84%

Data

source summary. MolData was created using 9 data sources, the number of bioassays within each data source is shown in AID count column. Each molecule in a given source can have bioactivity for multiple bioassays and constitute multiple data points. Unique active molecules are defined as molecules that demonstrate bioactivity in at least one bioassay

## Section: Results › Data description domain

To better understand the diversity within the 600 gathered bioassays, the description of each assay was fed to a BioBERT model [21]. BioBERT is an attention-based model, which is trained on a large corpus of biomedical text to predict masked words. This type of training and language modeling gives the model the ability to create meaningful representations from biomedical text inputs which encode the context of the input within fixed size vectors. In this work, BioBERT is used on the description of each assay to extract features and map the domain which these descriptions cover. Figure 2 depicts this map after clustering, showing how descriptions from different sources can have similar context to each other (e.g., bioassays from John Hopkins Ion Channel Center and The Scripps Research Institute Molecular Screening Center in cluster 2) or be distinct from the rest (e.g., bioassays from Tox21 in cluster 9).Fig. 2Map of the bioassays’ descriptions using the output of the BioBERT model (The explained variance ratio for the first and second principal components are 14.72% and 5.40% respectively)

The same model trained on disease entity recognition was also used to identify disease related key words in each description [26]. While each cluster had some degree of similarity in terms of the diseases covered within each domain, it was far from perfect in correctly dividing the data domain based on their disease categories. Therefore, manual tagging was performed using the clusters and the disease entities as guidance. This process included highlighting disease related words within each bioassay’s description and using them as tags to represent each bioassay. The dataset descriptions as well as their highlighted words are available in Additional file 2.

Map of the bioassays’ descriptions using the output of the BioBERT model (The explained variance ratio for the first and second principal components are 14.72% and 5.40% respectively)

## Section: Results › MolData

Disease-based information for the MolData Benchmark

Target-based information for the MolData Benchmark

The composition of the disease benchmark: Number of bioassays for each disease category (as well as toxicity) and their original source

The composition of the target benchmark: Number of bioassays for each target category and their original source

Cumulative histogram of the largest Tanimoto Similarity Coefficient for 200,000 molecules within the MolData dataset. More than 92% of the molecules have other similar molecules to them within the dataset with Tanimoto Coefficient of higher than 0.5, and more than 44% of the molecules for Coefficient of 0.7

Correlation matrix between a Toxicity bioassays, b Non-Toxic bioassays with correlation > 0.5

Classification results on the validation and test sets of disease categories, averaged on all tasks within each category

Classification results on the validation and test sets of target categories, averaged on all tasks within each category

## Section: Results › MolData › Data summary

After collecting all the specific disease identifiers or key words, we clustered them into 15 different categories. These categories were selected after carefully investigating all disease related words and their counts. The categories are: (1) Cancer, (2) Aging, (3) Bacterial, (4) Viral, (5) Fungal, (6) Parasitic, (7) Cardiovascular, (8) Immunological, (9) Nervous System, (10) Diabetes, (11) Epigenetic and Genetics, (12) Pulmonary, (13) Obesity, (14) Metabolic Disorder, and (15) General Infection. The sixteenth benchmark is for the toxicity of candidate drugs which is a very important part of MolData dataset and the drug discovery process. Since Diabetes is a very important disease involving a large population worldwide [27], we also decided to give Diabetes an independent category even though it should be listed under metabolic disorders. The count of assays for each disease and target categories are shown in Tables 2 and 3, respectively. Overall, MolData consists of 600 bioassays with 1.4 million unique molecules, with nearly half of the molecules possessing activity in at least one bioassay. Moreover, MolData contains 224 tasks belonging to 2 or more disease categories (e.g., a bioassay that relates to both cancer and immune system). The MolData benchmark data is available at https://GitHub.com/Transilico/MolData. All molecules, binary labels and splits are available in one file (Additional file 1), with two mapping files containing the mapping of each bioassay to each disease category and to each target category. Overall, MolData offers two benchmark categories: disease categories (as well as toxicity) and target categories, and using these mapping files the molecular data can be selected to create each category.Table 2Disease-based information for the MolData BenchmarkTagAID countActive data pointsTotal data points% Active datapointsUnique active moleculesTotal unique molecules% Unique active moleculesAll Categories6001,410,950168,345,5320.84672,9351,429,98947.06Cancer236575,45468,649,7710.84230,0491,323,31117.38Nervous System174378,81254,753,9750.69170,353651,24926.16Immune system129322,36238,418,6610.84157,333579,65827.14Cardiovascular94212,16228,660,6270.74124,270542,90222.89Toxicity5448,6532,452,6561.9830,936487,2196.35Obesity5390,83714,516,1990.6365,993545,51312.1Virus47113,94614,679,3120.7881,702621,94513.14Diabetes4361,40811,645,1510.5347,830543,6008.8MetabolicDisorders42126,7729,985,4911.2770,665527,38213.4Bacteria40132,59312,314,7371.0889,5541,290,7826.94Parasite2498,9507,302,2061.3675,027500,22815Epigenetics, Genetics2392,8376,815,5971.3665,244439,53714.84Pulmonary1945,9406,122,2970.7536,467524,1676.96Infection1193,4443,312,9202.8263,782521,47312.23Aging1090303,079,5800.298527511,4711.67Fungal792532,147,7510.438824444,3731.99Table 3Target-based information for the MolData BenchmarkTargetAID countUnique target countActive data pointsTotal data points% Active datapointsUnique active moleculesTotal unique molecules% Unique active moleculesAll Targets383296862,370103,440,5150.83261,715675,16138.76Membrane receptor8544146,95625,922,5330.5691,489458,81819.94Enzyme (other)545183,65716,210,0900.5157,808632,1429.14Nuclear receptor532574,7766,083,5091.2242,838442,4879.68Hydrolase3632113,18510,830,3241.0566,195526,39112.57Protease292637,9437,965,3130.4730,619606,7935.05Transcription factor271853,4164,775,6851.1140,067503,2497.96Kinase242338,2577,369,6900.5231,327377,5198.29Epigenetic regulator232076,7936,840,0951.1251,776523,9049.88Ion channel221437,4026,745,7620.5528,853511,8735.63Transferase181743,9556,279,6510.730,432519,6465.85Oxidoreductase10833,9562,953,7601.1530,054432,5786.94Transporter9815,3902,538,5790.6015,046369,6214.07NTPase65114,4651,981,5755.7876,334439,96717.34Phosphatase5580901,693,7730.486913368,3291.87

The composition of each data category is depicted in Fig. 3; showing how combining data from each data source resulted in the creation of each category. This combination demonstrates one of the main motivations for this work’s data aggregation, as each disease category has related bioassays with multiple data sources. Furthermore, some categories such as Aging and Pulmonary are unexplored compared to those like Cancer and Nervous System, when large screening data is examined. These categories were selected based on their importance and the number of occurrences. Fig. 3The composition of the disease benchmark: Number of bioassays for each disease category (as well as toxicity) and their original sourceFig. 4The composition of the target benchmark: Number of bioassays for each target category and their original source

The protein targets of MolData in Fig. 4 were classified by either (1) direct mapping to the ChEMBL database, (2) finding highly similar target in ChEMBL, or (3) manual curation (see “Methods” section). From the 419 total unique targets in MolData, 296 were classified into 14 classes (Fig. 4). Enzymes (167/296) (Enzyme (other) + Hydrolase + Protease + Kinase + Transferase + oxidoreductase + NTPase + phosphatase) are the most prevalent class, followed by membrane receptors (44/296) and nuclear receptors (25/296). The occupancy of target classes is also reflected in the total assays for each class. For example, enzymes constitute the most prevalent class among the targeted assays (182/383), followed by membrane receptors (85/383) and nuclear receptors (53/383). The assays are overall enriched in the “privileged” targets, that is, membrane receptors, kinases, nuclear receptors, and ion channels. These four classes have been historically the most prevalent among approved drug targets [28], accounting for 70% of the total approved drugs. In our dataset, however, 199 assays (52% total) represent targets from classes other than membrane receptors, kinases, nuclear receptors, and ion channels. When counting the total unique targets, these historically “unprivileged” targets even give a higher representation of the dataset with 190 counts (64% total). Therefore, MolData captures a higher diversity in the target classes compared to those of the approved drugs. There are 515 tasks with PubChem designated targets within the 600 tasks. This work was able to categorize 383 of those tasks into specific target categories that have 5 or more bioassays within each category.

There are, additionally, classes that are overrepresented by our dataset compared to the set of targets with available approved drugs. For example, NTPases are targeted by 76,334 unique compounds (29% of the total compounds from targeted assays), while only 2% of drugs target NTPases. Additionally, epigenetic regulators represent the target of 51,776 unique compounds (20% of the total compounds from targeted assays), while only 0.3% of drugs interact with this class of proteins [28]. These higher hit rate in the targets of MolData compared to the approved drugs could imply the inherent low druggability of such target classes or the lower significance of the targets for pharmaceutical industries.

Disease-based information for the MolData Benchmark

Target-based information for the MolData Benchmark

The composition of the disease benchmark: Number of bioassays for each disease category (as well as toxicity) and their original source

The composition of the target benchmark: Number of bioassays for each target category and their original source

## Section: Results › MolData › Molecular domain

To investigate the diversity of the screened molecules, all collected molecules are represented as vectors using ECFP4 [26]. This binary fingerprint of size 1024 encodes the existence of sub-structures within the molecules using ones and zeros. Similarity between the fingerprint of two molecules can be calculated using the Tanimoto coefficient, where the overlap between the fingerprints is divided by the union of the fingerprints. This similarity coefficient can be used to find the similarity between all molecules within a dataset to assess the diversity of a molecular dataset [30, 31]. The cumulative histogram for maximum similarity coefficient for a random selection of 200,000 molecules within MolData is shown in Fig. 5.Fig. 5Cumulative histogram of the largest Tanimoto Similarity Coefficient for 200,000 molecules within the MolData dataset. More than 92% of the molecules have other similar molecules to them within the dataset with Tanimoto Coefficient of higher than 0.5, and more than 44% of the molecules for Coefficient of 0.7

Figure 5 demonstrates that more than 44% of the molecules within the MolData dataset have at least one other similar molecule to them with a Tanimoto Coefficient of 0.7 or higher. This high percentage of the similarity can denote lack of diversity within this portion of the dataset and may be result of existing predefined rules within the tradition molecule selection techniques for drug candidate screening. The effect of this lack of diversity is discussed as bias within the discussion section.

Cumulative histogram of the largest Tanimoto Similarity Coefficient for 200,000 molecules within the MolData dataset. More than 92% of the molecules have other similar molecules to them within the dataset with Tanimoto Coefficient of higher than 0.5, and more than 44% of the molecules for Coefficient of 0.7

## Section: Results › MolData › Correlation analysis, a showcase for drug repurposing

Drug repurposing is the process of finding new applications for already approved molecular drugs. These new applications can be target or disease based depending on the specific case of study. For example, during an outbreak, drug repurposing could be the fastest and most efficient option due to a lack of information about the new virus/bacteria. [32]. Azithromycin, a macrocyclic antibacterial, has shown to be effective against Ebola virus with EC50 of 5.1 \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\upmu$$\end{document}μM [33]. It also has shown promising results as a potential antimalarial (Plasmodium falciparum) when prescribing alone or in combination therapy [34–36]. For this benchmark, we hypothesized that correlating bioassays screened on different sets of targets would provide interesting information for better and faster drug repurposing. Therefore, the correlation score between the molecule bioactivity labels were calculated using a Pearson correlation coefficient.

Between all categories, toxicity showed the highest correlation of tasks, which is understandable due the nature of toxicity and the close biological relationship between the assays. In Fig. 6, correlation heatmaps are shown for Toxicity assays and all non-toxicity assays with a correlation of 0.5 or more which have different targets. The second chosen group indicates higher correlation can exist between the labels of bioassays from the same, or different sources. Two sets of correlating targets and a viral similarity were discovered through this analysis. The first set of targets with a high correlation were (1) NPC1 (2) SMN1 (3) ATAD5 (4) Rab9 (5) STAT1. NPC1 and Rab9, with a 98% correlation, are important players in cholesterol metabolism and Niemann Pick Disease Type C (Additional file 4) [37, 38]. AIDs 485,297 and 485,313 were designed to discover the activators of mentioned proteins using luciferase reporter assays. Their high correlation to assays targeting STAT1 or ATAD5, which are important in cancer and immune disorders [39–41], is a valuable finding by a simple linear correlation analysis of MolData benchmark for drug repurposing. Another interesting discovery was infectious disease based, as molecules targeting the Lassa Virus and Marburg Virus showed a high correlation. The Lassa Virus is a single stranded RNA virus with a circular morphology from the family of Arenaviridae, and is cause of Lassa hemorrhagic fever [42, 43]. Moreover, the Marburg virus belongs to the family of Filoviridae, with a shepherd's crook morphology, and causes similar symptoms to the Ebola virus, with a fatality rate of ~ 50% [44, 45]. Both bioassays used the viruses envelop glycoproteins on a pseudotype virus system. We were curious to see if there has been any candidate drug with promising potency against both viruses. Favipiravir is a pyrazine carboxamide derivative that has shown effectiveness against both the Lassa and Marburg viruses [46, 47]. These data suggest that MolData would be valuable source for further drug repurposing investigations. We suggest the further investigation of MolData correlation analysis using experimental assays to better understand the findings of this paper.Fig. 6Correlation matrix between a Toxicity bioassays, b Non-Toxic bioassays with correlation > 0.5

Correlation matrix between a Toxicity bioassays, b Non-Toxic bioassays with correlation > 0.5

## Section: Results › MolData › Benchmark classification modeling, a showcase for bioactivity prediction

The data from each disease and target category, as well as the aggregation of all bioassays, are used as training inputs for GCNNs. The classification results are shown in Tables 4 and 5 as the baseline for each category. These results are from the imbalanced (untransformed) test sets and validation sets, weighted to ignore missing data points for each task (weight of 0), then averaged across all tasks within each category. This weighted evaluation on untransformed data with missing values is made accessible in “training” script on the GitHub repository. The detailed results for each model and bioassay are presented in Additional file 5. These results show the baseline performance for multitask models, with ROC AUC serving as the most important comparison metric due to the imbalance nature of the data.Table 4Classification results on the validation and test sets of disease categories, averaged on all tasks within each categoryBenchmarkValidation SetTest SetAccuracy (%)Recall (%)Precision (%)ROC AUCAccuracy (%)Recall (%)Precision (%)ROC AUCAll Tasks64.7763.930.780363.9675.693.980.774Cancer73.6168.763.680.780972.9668.443.760.7765Nervous System73.3465.12.390.757373.0164.922.490.7556Immune System79.761.343.410.77779.4961.013.50.7739Cardiovascular80.0656.842.980.749880.0656.393.130.7457Toxicity86.933.4124.460.744586.5134.2727.540.7309Obesity86.0154.15.420.792585.3751.55.510.7704Virus77.7362.082.620.762577.961.912.840.7643Diabetes86.6951.275.80.784585.8851.335.990.7795Metabolic Disorders83.1453.046.890.761982.7154.857.060.7619Bacteria83.160.824.630.791682.2664.494.690.8089Parasite91.5146.6511.310.829291.3744.6311.170.8243Epigenetics-Genetics88.4645.276.360.780488.3240.985.650.7251Pulmonary76.8256.72.340.729376.0654.792.50.7168Infection92.1731.5812.530.80192.0129.8711.410.7871Aging94.8323.591.860.720594.2829.362.380.7402Fungal92.3635.223.50.7592.7733.933.610.7335Table 5Classification results on the validation and test sets of target categories, averaged on all tasks within each categoryTarget BenchmarkValidation setTest setAccuracy (%)Recall (%)Precision (%)ROC AUCAccuracy (%)Recall (%)Precision (%)ROC AUCAll Tasks w/Targets73.8969.74.810.78973.5468.64.860.7786Membrane receptor79.6756.292.450.747979.7753.542.440.7251Enzyme (other)85.3260.812.860.812385.0560.22.980.8019Nuclear receptor84.4547.1516.980.751684.9545.9618.230.7511Hydrolase84.3565.13.350.816584.0959.53.430.7879Protease85.8851.433.90.787485.2152.533.890.7792Transcription factor86.7249.4512.590.794785.3551.913.370.7858Kinase77.5651.292.340.714277.5349.772.330.6955Epigenetic regulator86.2258.256.120.809785.5555.256.230.8077Ion channel96.8222.636.810.749696.6821.136.160.7393Transferase93.3245.948.430.83792.8642.597.750.8234Oxidoreductase93.2525.4219.10.797792.7726.411.270.7994Transporter94.9319.213.670.700894.8616.883.970.663NTPase93.6810.4541.430.747993.339.5926.780.7639Phosphatase98.5321.8615.270.799398.4519.1314.480.815

While the results differ between all benchmark categories, in general the models have higher recall and lower precision. Further interpretations of these results as well as the next steps for improving model performance is discussed within the discussion section.

Moreover, in conjunction to the GCNN model, to further investigate the values of the baseline and to better evaluate the results of the benchmark on traditional virtual screening models, a simple fully connected neural network model was trained on the Extended Connectivity Fingerprint (ECFP) features of the molecules. The results of this neural network model can be viewed in Additional file 6, where all benchmark results follow the trend of the GCNN, with slightly lower values across the tables, demonstrating that GCNN was able to give better results that the fully connected neural network.

Classification results on the validation and test sets of disease categories, averaged on all tasks within each category

Classification results on the validation and test sets of target categories, averaged on all tasks within each category

## Section: Results › MolData › Use cases of MolData

The current available assays within the PubChem database include detailed biological descriptions on the purpose of the assays and the specific question they investigate. While this is essential and useful for experts within the field of biomedical sciences, the narrow scope of these questions makes it hard for the machine learning and data scientists to pursue modeling the available dataset. The description of public dataset often contains extensive information about their cellular target, the final purpose of the assay, applications of the assay for specific disease(s). Therefore, it would be very hard to completely understand all important information in such dataset by scientists without biomedical background. In this work, these datasets with narrow scopes are categorized in ways that would give a wider scope to what they are investigating (e.g. disease or target categories) and would define a more tangible purpose for the in-silico drug discovery community to pursue.

From a biological point of view, MolData can be used to offer a large list of datasets, where each dataset is tagged and labeled to be related to a disease. Given the interest of the user, MolData datasets can be examined and selected for further research in two manners. The user can either create models using the offered dataset, or augment the related datasets within MolData to other data to increase the scope of modeling or to investigate new questions of interest that arise from the diversity of datasets within each disease category.

From a machine learning point of view, MolData offers three use cases: firstly, a molecular database with 1.4 million molecules and 600 possible labels, where each label relates to a disease category. This dataset proposes a challenge to the machine learning community due to its size and its imbalanced nature and can be of interest to the in-silico drug screening community due to its composition of completely disease related tasks. Secondly, MolData offers individual benchmarks with biological purposes, where the categories are designed to have tangible objectives such as diseases and targets. Therefore, any improvement within the benchmark values can be associated with impact on the early drug discovery stage for those diseases and targets. And lastly, MolData can be combined with other datasets to investigate the effects of multitask learning when multiple tasks from a disease category or multiple tasks from a target category are used for training. This last use case is further investigated in Additional file 6.

## Section: Discussion

Overall, the pipeline implemented in the creation of MolData resulted in aggregation of molecules from 9 large data sources (Table 1) with 600 bioassays that have a diverse set of descriptions (Fig. 2). Even though these descriptions have a wide range, different data sources can have similar descriptions (Fig. 2), which encourages combining the data from these sources. However, the BioBERT clusterization of bioassays did not provide an accurate disease or target related label in most cases, due to the existence of disease related words (i.e., cancer) in many bioassay descriptions that did not relate to that disease. To overcome this problem and to present accurate tagging, BioBERT clusters were only taken as recommendation and manual tagging was performed, where highlighted keywords were used to categorize bioassays into disease and target related categories. The resulting dataset consisted of bioassays covering multiple diseases and targets (Figs. 3, 4) which gave the opportunity to create multiple benchmarks with biological purpose.

One of the main topics worth discussing is bias within the dataset. MolData consists of roughly 170 million data points. However, this screening was performed on 1.4 million molecules, denoting that each molecule exists on average in nearly 117 assays. Since the data sources are different, this level of repetitiveness shows a large overlap of molecules within the original data sources. Furthermore, as seen from the results of the molecular domain analysis in Fig. 5, many of the molecules are also similar to each other within the dataset. Therefore, a degree of bias exists within the gathered dataset with similar molecules being screened for each assay and in all data sources. We speculate this bias is due to the traditional rules used for selecting molecules as candidates for screening.

One effective way to increase the diversity of chemicals would be switching from screening synthetic libraries to natural product libraries. Natural derived compounds have shown a higher hit rate with the potential of targeting unknown and complex biotargets [48, 49]. The first reason why natural product-based molecules show better hit rate and potency would be their complexity and structural diversity [49, 50]. Secondly, these molecules have helped live organism to battle microbial invasions during millions of years of evolution which have made them better over time [51, 52]. However, there have been major challenges with their discovery and the use of natural products. Since most of these natural product’s libraries are discovered from natural organisms and animals, their extraction imposes a threat to many species and increase the risk of their extinction. Also, their discoveries are more tedious and expensive than just synthesizing non diverse organic molecules in labs. At the end, synthesizing some of nature driven molecules are very hard and sometimes impossible. Finally, since their major roles in microorganisms have been as a defense line, they would show activity against multiple bio-targets in a cell which increase the probability of showing toxicity in drug development [49, 50, 52]. Therefore, there has not been practiced in HTS assays like simple synthesized molecules. However, learning methods like GCNN has shown potentials in discovering them even with no nature driven molecular data when training [35].

Another important topic to consider is the benchmark modeling result. The model architecture was selected to be shared within all models; however, this is suboptimal, and hyper-parameter optimization can be performed to find better possible architectures for each data category. This can apply to other hyper-parameters such as learning rate and batch size, which can be improved via a grid-search hyper-parameter optimization. Lastly, the low precision of the models is a focus of improvement since precision plays an important role in selecting molecules for future screening at inference time, directly affecting the cost and time of screening.

## Section: Conclusion

MolData is one of the largest efforts in the collection, curation, and categorization of labeled molecular datasets. It consists of roughly 170 million screens of 1.4 million unique molecules distributed in 600 different bioassays and 15 disease categories and one toxicity category, from cancer to infectious diseases. It also consists of a state-of-the-art target benchmark with 14 categories. We explored all the disease and target-related details in each bioassay for the development of a comprehensive benchmark to assist data scientists and the ML community in improving model development and computational drug discovery with benchmarks that have tangible biological purposes. We believe a key feature of any learning system is the training data, and the validation of a model is only possible with appropriate molecular and biological knowledge of the dataset. MolData takes advantage of a greater amount of labeled data compared to other benchmark datasets, which is an important addition to CADD. It is beneficial for the data science community to have a similar dataset for comparison of model performances; therefore, baseline performance is presented for 32 different categories. MolData hopes to take a step in furthering the molecular machine learning revolution, by providing the means for drug discovery and model development with a biological purpose.

## Section: Methods › Data aggregation

The dataset was collected from PubChem bioassays due to its comprehensiveness and the high diversity of diseases and targets. We started with the selection of PubChem sources with highest number of Live Bioassays Counts, High Throughput Screening (HTS) capabilities, and being open-source. Hence, we selected nine sources as follows:National Center for Advancing Translational Sciences (NCATS) is one of the most comprehensive centers for drug screening with a goal of therapeutic development trough collaborative research [5, 10],Broad Institute of Harvard and MIT with a focus on assay development and scientific collaboration for the advancement of Discovery Science and Translational Pharmacology. They have the capability of screening 100 s to 1,000 s of compound plates a day [54, 55],Sanford-Burnham Center for Chemical Genomics is a well stablished screening center working on multiple projects including NIH Molecular Libraries program (MLP) with applications on multiple diseases [56, 57],NMMLSC is an screening center with capability of using high throughput flow cytometry to discover molecules as chemical probes for drug discovery [58, 59],Emory University Molecular Libraries Screening Center with focus on Biological Discovery through Chemical Innovation and also molecular pathogenesis to global pandemics. [60, 61],Tox21 which contains thousands of medicinal or environmental substances which is a collaboration between NCATS and national toxicology program. Tox21 is an ongoing project with yearly update [62, 63],The Scripps Research Institute Molecular Screening Center is an automated center with projects on a variety of diseases like Alzheimer and cancer. They also have capability of assay development, Compound synthesis cheminformatics, mechanism of action discovery etc. [64, 65],Johns Hopkins Ion Channel Center with a focus on membrane proteins and transporters which are permeable to ions [67]. Due to the importance of this class of targets, we decided to include them as one of main sources.ICCB-Longwood Screening Facility, Harvard Medical School which performs most of the HTS assays with the availability of over 500,000 molecules for screening [68, 69].

Aforementioned sources were also selected due to their credibility of HTS data. As the final goal of this article is providing the machine learning community with a large, clustered dataset, we decided to include bioassays containing 100,000 or more molecules screened, as well as bioassays with more than 15 unique active molecules. This threshold was not applied to the Tox21 assays, which have a lower number of screened molecules, which were selected due to the importance of toxicity prediction to drug discovery. Table 1 shows the exact number of each sources’ count, as well as active/inactive molecules. To collect data from each source, the PubChem website interface was used, where data sources were sorted by their bioassay count. The same interface also offers the ability to download the molecular data as well as the summary (and descriptions) of all bioassays within each source.

## Section: Methods › Mapping the data domain with natural language processing

After the assays are gathered and filtered by a size threshold, the process of understanding the context of the assays begins. Each assay contains information including the title of the assay, a general description, and optionally the biological target of the screening. To understand the diversity of the assays and map the domains which they cover, the description of each assay is analyzed using natural language processing tools, as elaborated upon in the following subsections.

## Section: Methods › Mapping the data domain with natural language processing › Description pre-processing

The description of each bioassay was acquired from the PubChem website. Each description can contain a complete molecular and biological background, goal of each assay, and finally a brief description of the biological assay. However, each description may also contain unusable information such as the affiliated center, references, scientists involved in the screening, and grant information. Using Python string parsing capabilities, manual rules were written for of each of the eight data sources to filter out the lines containing the unusable information, resulting in cleaned descriptions explaining the assays’ goal. These rules can include deletion of lines pertaining to Principal Investigators, grant numbers, Screening Center Affiliation, Network, Assay provider, Grant Proposal Number, etc. from the description to extract only the assay description from the text. Description preprocessing is made accessible in “preprocessing” script on the GitHub repository.

## Section: Methods › Mapping the data domain with natural language processing › Feature extraction using BioBERT

Feature extraction from a piece of text is typically done via a model which is capable of taking a varied length piece of text and turn it into a fixed-length numerical vector. In the biomedical processing domain, this is typically done via Word2Vec [70] models or language models such as ELMO [71] or BERT [72]. The descriptions that are found for each bioassay typically contain many biologically relative information and words, which the normal language models are not suitable to handle. Therefore, a language model is needed which is trained on biological text and has the related words within its vocabularies. BioBERT is a bidirectional transformer model constructed of multi-head attention modules. This model is trained for language modeling on a plethora of biomedical literature, predicting the masked tokens from raw unlabeled text. Using this pre-training, the model can generate meaningful representation from biomedical text and encode the input in a discernible feature vector. In this work, The cleaned descriptions were lower-cased and fed to a BioBERT model for feature extraction. Leveraging the feature extraction capability of this model, each description is transformed to a numerical vector of size 2048, representing what each assay’s description contained. One disadvantage of this technique is the limited input size of BioBERT (512 token), which resulted in truncation of some of the descriptions. This process is repeated for the titles of each bioassay as well, resulting in another vector of size 2048, which was concatenated with description’s vector. With the rule-based cleaning of the descriptions as described in previous subsection, the inputs of the model were cleaned to be the description itself, to include the most information possible within the 512 tokens. Moreover, the title of the bioassay was added to the beginning of the description to always be included within the input of the model. It is noteworthy that the descriptions examined for manual tagging were the full untruncated descriptions, and since BioBERT is used just as a tag recommender, this truncation does not affect the final output of the manual tagging. Feature extraction using BioBERT is made accessible in “clustering” script on the GitHub repository.

## Section: Methods › Mapping the data domain with natural language processing › Clustering

Having acquired feature vectors of assay descriptions and titles, they are clustered using K-Means clustering. Since the target of this clustering is to explore the domain which the descriptions cover, the number of clusters are unknown. To find the optimum number of clusters, the sum of squared distances of data points to their closest cluster center (SSE) are calculated and plotted based on the number of clusters. The optimum number of clusters is then found by detecting the knee point of the plot. Clustering the descriptions using KMeans is made accessible in “clustering” script on the GitHub repository.

## Section: Methods › Tagging the assays

After distinct clusters are formed from assay descriptions and the domains covered by the datasets are better defined, different assays can be grouped together to form a benchmark. The main form of distinction between the assays chosen in this work is disease category relations. As previously mentioned, it is important for a dataset to provide each bioassay with simple disease and target categories for better computational drug discovery. To find the related disease categories for each assay, the process of tagging is used, during which certain words in the description are chosen as tags to represent the assay. This process was implemented both using AI assistance and manual annotation.

## Section: Methods › Tagging the assays › BioBERT disease category entity recognition

The first approach implemented in this work to extract the disease related words from the description text of an assay is using a BioBERT model trained for disease category entity recognition. This model takes a text sequence as input and returns the entity class related to each token, with the classes consisting of disease and non-disease category entities. Using this model, all related disease keywords are extracted from each assay, automating the process of tagging. The script for disease category entity recognition is provided as “ner” script within the GitHub repository. However, one major disadvantage of this technique is that many words within the description are disease category related, but not defining for that assay. As an example, a task would claim that an older drug for a specific virus would be a carcinogen, falsely adding a disease tag related to “cancer” to the assay. The mentioned assay would have nothing to do with cancer and was just an effort for antiviral drug discovery.

## Section: Methods › Tagging the assays › Manual tagging

Since many of descriptions contain some biomedical-related words that are not defined for that specific task, understanding the exact biological assay and diseases related to the screening are crucial for tagging. A bioassay description contains a large amount of information regarding the target, related disease categories, other proteins/RNAs/DNA down or up-stream, and in some cases the experimental details of the bioassay. In a task description below, we provide a description from BioBERT cluster zero for AID 1,259,313 from Burnham Center for Chemical Genomics entitled “uHTS identification of small molecule modulators of NR3A”. As shown in this figure, we first read the description for better understanding the assay as a whole, as well as the tags found by the computational method, and then highlight any words with the potential of directing us to a special disease category. Here, Central Nervous System (CNS), Down Syndrome, and Neurological Disorders are the main words that direct us to the subcategories of ‘Nervous System’ and ‘Epigenetics-Genetics’. Reading manual tags from a word file is provided in the “manual_tag” script within the GitHub Repository. Activity of N-methyl-D-aspartate subtype of glutamate receptor (NMDAR) is essential for normal central nervous system (CNS) function. However, excessive activation of NMDAR mediates, at least in part, neuronal or synaptic damage in many neurological disorders, including hypoxic-ischemic brain injury and in Down syndrome. The dual role of NMDARs in normal and abnormal CNS function imposes important constraints on possible therapeutic strategies aimed at ameliorating or abating developmental disorders and neurological disease: blockade of excessive NMDAR activity must be achieved without interference with its normal function. We propose an approach for NMDAR modulation via modulation of the NR3A subunit, a representative of a novel family of NMDAR subunits with the goal to modulate the NMDAR activity. NR3 subunits have a unique structure in their M3 domain forming part of the channel region that contributes to decreased magnesium sensitivity and calcium permeability of NMDARs. It potently and specifically binds glycine and D-serine, but not glutamate. In addition, we have shown that glycine binding to the ligand-binding domain (LBD) of NR3A is essential for NR1/NR3 receptor activation, as opposed to internalization caused by ligand binding to NR1 LBD.

## Section: Methods › Benchmark creation

After the disease related words are highlighted and extracted, each assay can be represented by its tags. The next step of the process is to use these tags for grouping related assays together, and to create the benchmark. To do so, major disease categories were first identified which could encompass all tags; and second, each tag was assigned to one or more related major disease categories. The relation between each tag and the major disease category can be found in Additional file 7.

The classification of the protein targets of our dataset was gleaned by downloading and searching against the ChEMBL 29 [12] database (https://ftp.ebi.ac.uk/pub/databases/chembl/ChEMBLdb/latest/chembl_29.fa.gz). If the sequence of a given target—retrieved from UniProtKB using its UniProt ID matched identically to that of a ChEMBL target, the target classification was copied from ChEMBL. To classify the targets missing in ChEMBL, an all-by-all pairwise alignment was performed between MolBio targets and ChEMBL 29 dataset using phmmer 3.3 [73]. If the top-scoring phmmer hit from ChEMBL aligns to the query sequence with a bit score of at least 100 and shares more than 80% similarity in sequence length, the classification is copied from the ChEMBL hit. The targets that neither mapped to ChEMBL nor aligned confidently to ChEMBL using the mentioned criteria were annotated manually. The dataset originally contained 17 classes, but the list was curtailed to 13 classes to remove the ones with assay occupancy of fewer than 5.

## Section: Methods › Benchmark creation › Molecular data pre-processing

Having populated the disease categories, the molecular data for each assay was downloaded in the form of Simplified Molecular-Input Line-Entry System (SMILES) and their related bioactivity [74]. To curate the SMILES, During this step, the SMILES is first transformed into a Mol Object, then reverted back to a canonical SMILES format with isomeric information. The SMILES input for each molecule was canonicalized with isomeric information included using RDKit version 2020.09.1. Duplicate or missing SMILES entries were then deleted using Python 3.6 and Pandas library version 1.1.5. Regarding the bioactivity of the molecules, the existing labels in all assays are “Active”, “Inactive”, “Inconclusive”, and “Unspecified”. For the sake of consistency, molecules with inconclusive and unspecified labels were removed, and active and inactive molecules were respectively labeled as 1 and 0. Having cleaned the datasets, those bioassays with less than 15 active molecules were deleted, since they would offer a challenge during data splitting. Molecular data preprocessing is made available in the “molecular_data_cleaning” script of the GitHub repository.

After the datasets are aggregated and preprocessed, Extended-Connectivity Fingerprints (ECFP4) [29] are used to represent each molecule as a binary vector of 1024 length. The fingerprints were extracted using RDKit and DeepChem version 2.5.0. The scripts for the pre-processing and fingerprint extraction are available on the GitHub repository alongside the data. This binary fingerprint represents existence or non-existence of certain sub-graphs within each molecule, with “one” denoting existence of a sub-structural and “zero” denoting its lack of existence. Given two similar molecules, the extracted fingerprints share most of the same positions for “ones” within the binary vector. To calculate how similar two binary fingerprints are Tanimoto score can be used, which is defined as the number of overlapping “ones” divided by the union of “ones” within both fingerprints. This score is used in this work to find the similarity between all molecules within the MolData dataset.

To find the diversity of all molecules within the dataset, first the ECFP fingerprints are calculated. Then, the Tanimoto Similarity Coefficient is calculated between one molecule and the rest of the dataset. The highest Tanimoto Coefficient is then recorded for that molecule, which demonstrates how close the most similar molecule is to the selected molecule. This process is repeated for all molecules and the cumulative histogram of this score is defined. If a large portion of the molecules result in higher Tanimoto Coefficients (higher than 0.7), the dataset as a whole becomes a collection of similar molecules, which in turn hurts the diversity of the dataset. Due to computational constraint caused by calculating the Tanimoto Coefficient matrix, 200,000 molecules were sampled to represent the dataset and this process was implemented on these sampled molecules. ECFP fingerprint extraction as well as Tanimoto Coefficient calculation are made available in the “fingerprint_extraction” script within the GitHub repository.

## Section: Methods › Benchmark creation › Correlation analysis

To find correlating bioassay, the bioactivity labels of all molecules are taken as representing vectors of each bioassay. To begin, the shared labels between two bioassays that are non-missing are found. The Pearson correlation coefficient is calculated between these two vectors. This process is repeated for all bioassays within each disease category, as well as all the data. The resulting matrices are depicted in the result section. In order to find interesting correlations, the bioassays with a correlation coefficient higher than 0.5 or lower than -0.5 are selected. If the AID number of these bioassays are within 5 of each other (neighbors), they are dismissed, because in most cases they are very closely related screens. The remaining bioassays are further examined to check for any biological cause for this correlation. Correlation calculation is made available in the “correlation” script within the GitHub repository.

## Section: Methods › Benchmark creation › Classification and performance benchmark

After the data is categorized based on their related diseases, using DeepChem the data is split into training, validation, and test sets, with 80, 10, 10 percent shares respectively. This splitting is done after finding the Bemis-Murcko scaffold of each molecule y [75], and molecules with shared scaffolds are put into same splits. Splitting based on the scaffolds creates more distinct splits, making the problem of classification harder and more like real-world scenarios where the inference set can often have a different distribution than the training set. Having split the data, some tasks may have no positive data points in the smaller splits, which creates a problem for calculating performance metrics, therefore, those tasks are identified, and one of their positive datapoints from the training set is randomly moved to the smaller split. Data splitting is offered in the “splitting” script within the GitHub repository.

The molecules are featurized and converted into graphs with the chirality included in the features. DeepChem was used to featurize the molecules and convert them into undirected graphs with nodes representing atoms and edges representing bonds. These graphs are computationally represented as two matrices: the connectivity matrix and the feature matrix. The feature matrix includes 75 features for each node (atom) within the graph, which include one-hot encoding of the atom type, number of directly bonded neighbors, number of implicit Hydrogens on the atom, formal charge, number of radical electrons, one-hot encoding of the atom's hybridization, and aromaticity. DeepChem also has the option to add chirality features to the feature vectors, which adds three additional values to each vector (78 features in total) representing if the chirality property exists and if so, the classification of the chirality to right-hand or left-hand. The script for featurization of the molecules is available in the “training” scripts within the GitHub repository.

To assist the process, the training split is balanced using weight transformers that affect how the loss is aggregated, amplifying the effect of positive samples during training. The training split is used to train a GCNN in a multitask manner for each category, including one model trained on 600 bioassays combined. The parameters for training and the related model are shown in Table 5. The script for training the GCNN model is made available in the “training” scripts within the GitHub repository.

The evaluation metrics for the training of the models selected in this work are accuracy, recall, precision, and Area Under the Receiver Operator Curve (ROC AUC). While accuracy is a palpable metric of performance, it is not suitable for comparing models in imbalanced scenarios, where ROC AUC can correctly represent performance. Moreover, recall and precision are important in evaluating virtual screening models, since recall denotes how many of the valuable active molecules were correctly predicted, while precision demonstrates how well the trained model can do at inference time, selecting active molecules from a plethora of possible candidates for screening.

To further assess the values of the benchmark and to train another model on the MolData dataset, a fully connected neural network is also trained on all categories. The input to this model is the ECFP4 features of the molecules (binary vectors of length 1024), similar to how traditional virtual screening model are trained. Having this approach allows us to compare the deep learning-based method of virtual screening via automatic feature extraction, to a traditional virtual screening where feature extraction and classification are isolated. The script for training the ECFP based model is made available in the “training” scripts within the GitHub repository.

## Section: Supplementary Information

Additional file 1. MolData Data. The main training dataset consisting of 1.4 million molecules with 600 label columns (all_molecular_data). Moreover, the mapping between the 600 datasets and their corresponding disease (aid_disease_mapping) and target (aid_target_mapping) categories.

Additional file 2. Data Summary. Summary of all datasets including their AID number, descriptions, statistics, and their disease and target category.

Additional file 3. Additional Reference List. A comprehensive list of references to the PubChem datasets used within MolData as well as their corresponding ChEMBL datasets.

Additional file 4. Interesting Correlations. Interesting linear correlations found between the labels of different datasets.

Additional file 5. Detailed Results. Detailed results of all models and benchmarks.

Additional file 6. Additional Results. Training Results for the simple fully connected neural network.

Additional file 7. Tagging Keywords. All keywords used for tagging a dataset with a disease benchmark label (i.e., cancer, nervous system, etc.).

## Section: Supplementary Information

Additional file 1. MolData Data. The main training dataset consisting of 1.4 million molecules with 600 label columns (all_molecular_data). Moreover, the mapping between the 600 datasets and their corresponding disease (aid_disease_mapping) and target (aid_target_mapping) categories.Additional file 2. Data Summary. Summary of all datasets including their AID number, descriptions, statistics, and their disease and target category.Additional file 3. Additional Reference List. A comprehensive list of references to the PubChem datasets used within MolData as well as their corresponding ChEMBL datasets.Additional file 4. Interesting Correlations. Interesting linear correlations found between the labels of different datasets.Additional file 5. Detailed Results. Detailed results of all models and benchmarks.Additional file 6. Additional Results. Training Results for the simple fully connected neural network.Additional file 7. Tagging Keywords. All keywords used for tagging a dataset with a disease benchmark label (i.e., cancer, nervous system, etc.).

Additional file 1. MolData Data. The main training dataset consisting of 1.4 million molecules with 600 label columns (all_molecular_data). Moreover, the mapping between the 600 datasets and their corresponding disease (aid_disease_mapping) and target (aid_target_mapping) categories.

Additional file 2. Data Summary. Summary of all datasets including their AID number, descriptions, statistics, and their disease and target category.

Additional file 3. Additional Reference List. A comprehensive list of references to the PubChem datasets used within MolData as well as their corresponding ChEMBL datasets.

Additional file 4. Interesting Correlations. Interesting linear correlations found between the labels of different datasets.

Additional file 5. Detailed Results. Detailed results of all models and benchmarks.

Additional file 6. Additional Results. Training Results for the simple fully connected neural network.

Additional file 7. Tagging Keywords. All keywords used for tagging a dataset with a disease benchmark label (i.e., cancer, nervous system, etc.).


---

# Novel Big Data-Driven Machine Learning Models for Drug Discovery Application

- **Authors:** Vishnu Sripriya Akondi, Vineetha Menon, Jerome Baudry, Jana Whittle
- **Issuer:** Molecules (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2022-01-18
- **Language:** en
- **DOI:** 10.3390/molecules27030594
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35163865/
- **Licence:** CC-BY

## Section: Abstract

AbstractMost contemporary drug discovery projects start with a ‘hit discovery’ phase where small chemicals are identified that have the capacity to interact, in a chemical sense, with a protein target involved in a given disease. To assist and accelerate this initial drug discovery process, ’virtual docking calculations’ are routinely performed, where computational models of proteins and computational models of small chemicals are evaluated for their capacities to bind together. In cutting-edge, contemporary implementations of this process, several conformations of protein targets are independently assayed in parallel ‘ensemble docking’ calculations. Some of these protein conformations, a minority of them, will be capable of binding many chemicals, while other protein conformations, the majority of them, will not be able to do so. This fact that only some of the conformations accessible to a protein will be ’selected’ by chemicals is known as ’conformational selection’ process in biology. This work describes a machine learning approach to characterize and identify the properties of protein conformations that will be selected (i.e., bind to) chemicals, and classified as potential binding drug candidates, unlike the remaining non-binding drug candidate protein conformations. This work also addresses the class imbalance problem through advanced machine learning techniques that maximize the prediction rate of potential protein molecular conformations for the test case proteins ADORA2A (Adenosine A2a Receptor) and OPRK1 (Opioid Receptor Kappa 1), and subsequently reduces the failure rates and hastens the drug discovery process.Keywords: drug discovery, class imbalance, machine learning, protein conformation selecton, drug candidates, ADORA2A, OPRK1

## Section: 1. Introduction

The core concept of any drug discovery application involves, in most cases, a protein biological target which binds with a chemical (known as ’ligand’) to achieve a biological function. The ligand is most often, although not always, a small organic chemical that binds to the protein target and modulates its function in a way that achieves a therapeutic benefit to the patient. Indeed, drug discovery can be inferred as the process of identification of small molecules that will bind selectively and safely to specific protein targets that are responsible for diseases.

The modern-day drug discovery and development timeline is a complex process that starts with protein target identification and ends with an FDA approval, and that takes an average of 12–15 years and costs more than $1 billion until the launch of the finished product. These time and cost issues are mostly due to (i) the time it takes in the early stage to identify drug candidates effective against a protein target, and (ii) the inflated failure rates of over 90% during later clinical trial stages, where the identified potential drug candidate proteins fail to succeed during various stages of developmental clinical trials. The prominent cause of these late-stage failures is that the potential drug candidates often have a tendency to bind off-target proteins, instead of only binding to their intended protein targets. This off-target drug binding can lead to a spectrum of adverse effects ranging from lack of potency and selectivity to more serious issues of drug toxicity [1].

A popular and efficient approach to identify in silico chemicals that have the potential to bind to specific proteins is called docking. In docking, computational models of chemicals are used together with computational models of the protein of interest to compute their respective binding free energies. These chemicals that are predicted to bind strongly to the protein of interest would be prioritized for further experimental testing. This approach has been historically used in many early-scale drug discovery projects. Thanks to the availability of supercomputers, this process is now beginning to be applied to the prediction of later-stage clinical trial outcomes, predicting not only of the chemicals of interest can bind to the protein of interest, but also if they can bind to several proteins known to be responsible for many clinical trial failures because of off-target binding [1].

A recent major development of this docking approach is the use of ensemble docking [2]. In ensemble-docking, more than one computational model of the protein target is used, combinatorially, to predicted the binding affinities of chemicals against the protein. The idea behind ensemble-docking is that, in the living cells, proteins are not static objects, but they undergo constant conformational dynamics that change their shapes to a significant extent at the atomistic level, and hence the binding affinities of chemicals. We have shown that in the many conformations that a protein can adopt, some, a small minority, will be much better at binding chemicals than others, confirming the chemical concept of conformational selection of protein conformations by their ligands [1]. In order to describe the range of conformations that the target proteins can adopt, various approaches such as molecular dynamics (MD) simulations Monte Carlo or Markov-State models are often employed [3]. However, the use of MD simulations to emulate the protein-ligand docking process has its own share of challenges beyond the knowledge of the structure of both the target protein and ligands [3]. In the context of ensemble docking, the most important challenge is how to identify, among a large number of conformational variations of a protein structure, the few ones that will end up being selected by the drugs for binding [1]. This work aims at addressing this important question by looking at physical and data properties of protein conformations that are associated with conformational selection. MD simulations do not provide data-driven insights into the identification of data-patterns such as the biophysical or chemical properties of ligand at-large that enables the selection of specific target protein conformations over the others. These problems highlight the need for advanced machine learning (ML) techniques that can analytically determine a precise binding with the least amount of time, cost expended with minimal pre-clinical lab trials and reduced failure rates at much early-stages in the drug discovery pipeline.

In literature, commonly used ML techniques based on characterizing protein conformational selection include root mean squared deviation (RMSD) clustering, Perron cluster analysis (PCCA+), and Markov-clustering (MCL) methods [4]. RMSD is a least squares approach that computes protein conformational RMSD values to generate clusters or protein conformational states based on a user-defined threshold. PCCA+ is a fuzzy clustering algorithm that performs clustering on the eigenvalues of the protein conformational transitions. MCL is a graph based clustering algorithm that uses the probability of a random walker to transition to a particular sequence of states. Strecker and Meyer performed clustering methods such as K-Means and hierarchical clustering (with average linkage) analysis on the cluster representatives to measure the docking performance in terms of binding pose prediction, screening utility and scoring accuracy [5]. Other mutual information based methods [6,7] and dimensionality reduction methods have also been proposed for information extraction [8].

However, the current ML methods do not address the caveats of statistically ill-conditioned and limited real-world data availability scenarios. This brings us to the class imbalance problem, where the detection of smaller sample-size potential drug-binding protein conformations is dominated by the larger population of non-drug-binding protein conformations. Consequently, most of the ML techniques employed for data-learning on such a biased population dataset will result in a high risk that the smaller population of potential drug candidate protein conformations (minority class samples) will be misclassified/ misidentified as the non-drug candidate protein conformations. In practice, this class imbalance problem could lead to serious effects where the researchers arrive at erroneous conclusions on the probable subset of proteins that will generate, from docking, a correct and useful list of chemicals predicted to bind to the protein targets, thereby drastically reducing the impact and reliability of analytical solutions for drug discovery applications. Therefore, to address the challenges in drug discovery domain, this paper introduces a two-stage sampling-based classifier drug discovery system. This system uses sampling strategies to study the class imbalance problem, to maximize the detection of potential drug-candidate conformations and recommend them to the biologists/pharmacologists during in vitro analysis. It also suggests the non-drug candidate protein conformations that could be discarded during the clinical trials, thus reducing the substantial investment of resources.

The novel contributions of this work are outlined as below:

The rest of the paper is organized as follows: background and related work is discussed in Section 2 followed by the proposed two-stage sampling based ML classification framework in Section 3. In Section 4, we experimentally demonstrate and validate the efficacy of the two-stage sampling based ML classification framework in identification of potential drug candidate protein conformations. Finally, we summarize the effectiveness of our proposed automated ML-based models for prediction of potential drug candidate protein conformational selection in Section 5.

## Section: 2. Background and Related Work

Protein descriptors for ADORA2A and OPRK1 datasets.

## Section: 2. Background and Related Work › 2.1. Class Imbalance Problem

In real-world drug discovery applications, most of the biomedical datasets observed are imbalanced in nature. The training phase of a supervised classifier constitutes data-learning performed on the given unequal distribution of representative samples from the imbalanced dataset. Here, the classifier aims to achieve a good classification/prediction performance without any consideration for the data distribution of each class. Hence, the resultant decision-making process tends to be more biased towards the majority class (which in the present case would be protein conformations that will not bind drugs), thereby leading to the misclassification of minority class samples (which in the present case would be protein conformations that will bind the drugs) [9]. Thus, the penalty cost of misclassification of minority samples is higher than the majority samples for a class imbalance problem [10]. Especially in drug discovery application, the class imbalance problem is of great consequence, since it leads to a higher risk of discarding the smaller population of protein conformations that can successfully bind to drugs due to them being misclassified as non-drug-binding protein conformations. In drug discovery literature, ensemble learning techniques have been proposed as a solution to handle the within- and between-class imbalance problem for prediction of drug–target interaction [11]. The main difference between our approach and other approaches is that, in our work, we tackle the class imbalance problem and also introduce a new perspective to maximize the detection of both potential drug candidate conformations and non-drug candidate conformations via the proposed two-stage sampling-based classifier system. The remainder of this paper discusses more about the proposed method, design of the two-stage sampling-based classifier system, and its experimental efficacy.

## Section: 2. Background and Related Work › 2.2. Sampling Strategies

The two broad categories of sampling strategies often employed are: (1) Undersampling approach: where sampling is performed by removal of additional data instances from the majority class samples and (2) Oversampling approach: where sampling is performed by the addition of artificial data instances to the minority class samples [10]. One of the most popular undersampling techniques is a random undersampling approach, wherein N samples are selected at random from the majority class to be included as part of a new smaller training set that consists of equal distribution (same N number of samples) of minority class samples. The main drawback of the undersampling approach is that it entails a substantial risk of loss of important information due to elimination of a large amount of original data samples from the new training phase [10,12,13], whereas the oversampling approach has no loss of information involved since all the original data samples are retained in the training phase. The oversampling approach generates artificial data samples of the minority class and adds them to the new training dataset to obtain the desired well-balanced data, which consists of equal distribution of majority and minority class data samples [10]. A synthetic minority oversampling technique (SMOTE) proposed by Chawla [14] creates new synthetic data samples of the minority class and adds them to the new training data set, thus reducing the overfitting problem that arises due to data replication. For this, SMOTE identifies K nearest neighbors for each data sample belonging to the minority class and then performs regression to fit the data samples to a line in order to generate the new synthetic data samples for the minority class [14]. The only problem with oversampling approach is that, for larger datasets, the increase in training data size also implies a corresponding increase in time-complexity of the data-learning phase. In the remainder of this paper, we will discuss several existing supervised ML techniques and introduce our novel ML approaches that leverage the sampling strategies to alleviate the class imbalance problem and maximize detection of potential drug-candidate molecular conformations for proteins ADORA2A and OPRK1.

## Section: 2. Background and Related Work › 2.3. Datasets Description

In this work, proteins ADORA2A (Adenosine A2a Receptor) and OPRK1 (Opioid Receptor Kappa 1) are considered for case study and experimental validation of the proposed method. The conformations of these two proteins have been extensively characterized, and the protein conformations that (i) will bind ligands and (ii) will not bind ligands are known and have been documented and published [1]. The conformations of the proteins were collected from 0.6 microsecond molecular dynamics simulations using full protein, membrane, and hydration environments on the Moldyn High Performance Cluster, and the docking was performed on the Titan Supercomputer at the Oak Ridge National Laboratory in Oak Ridge, TN, USA and on the Newton Supercomputer at the University of Tennessee, using the VinaMPI docking engine as described in Evangelista et al. The protein conformations that were docking the protein ligands with a high score were identified as described in [1]. Each protein MD trajectory consisted of 3000 protein conformations.

ADORA2A: This gene encodes a member of the guanine nucleotide-binding protein (G protein)-coupled receptor (GPCR) superfamily, which is subdivided into classes and subtypes. The given dataset consists of 50 attributes with 3000 molecular conformations among which 850 conformations have the potential to bind with the protein and 2147 conformations do not bind with the protein. Here, the imbalance ratio is 3:1 i.e., or every datasample belonging to minority class, there are three data samples belonging to the majority class.

OPRK1: This gene encodes an opioid receptor, and is a member of the 7 transmembrane spanning GPCR family.This is a Protein Coding gene. The given dataset consists of 50 attributes with 2999 molecular conformations among which 137 conformations have the potential to bind with the protein and 2862 conformations do not bind with the protein. Here, the imbalance ratio is 20:1 i.e., for every datasample belonging to minority class, there are 20 datasamples belonging to the majority class.

For each of the conformations of the ADORA2A and OPRK1 proteins described in Table 1, the molecular descriptors were calculated using the protein descriptors of the program MOE [15]. These descriptors are used to quantify various physical and chemical properties of the protein conformations. These descriptors are mostly based on the whole protein conformations, i.e., they are not limited to the small part of the protein where the ligands do bind. These descriptors have been found useful to characterize proteins and their conformations in ways that can distinguish them from other proteins or conformations [16].

The goal is to identify the maximum number of molecular conformations related to the ADORA2A and OPRK1 proteins to recommend the identified smaller subset of potential drug candidate conformations for more efficient docking calculations.The datasets have an active binding feature as the “dependent variable” which has 2 classes labeled as either 0 or 1 to indicate the binding outcome. Class 0 describes that known ligands do not bind well to the given protein conformation, and class 1 conveys that known ligands bind well to the given protein conformation. In this work, we have explored seven supervised ML classification models: Methodology 1 classification using LR, Methodology 2 classification using GB and KNN, re-balance the dataset using SMOTE followed by Methodology 2 classification techniques: SMOTE-GB, and SMOTE-KNN, and decision fusion using LR+SMOTE-GB and LR+SMOTE-KNN techniques. Their performance evaluation was conducted on 10%, 20% and 30% of training data sizes, where the training samples were randomly chosen from the original dataset. This training set range was chosen because, in reality, there are only a smaller number of conformations available for data-learning and training the supervised classifier. The LR classifier hyperparameter was empirically chosen as C=5. In the context of protein conformational selection for drug discovery application, a confusion matrix presents the summary of prediction/classification results of a given protein conformation as belonging to one of the below four cases:

Protein descriptors for ADORA2A and OPRK1 datasets.

## Section: 2. Background and Related Work › 2.4. Logistic Regression

Logistic regression (LR) is one of the popular ML techniques that is used to perform predictive analysis of data, when the data are categorical or has binary classes. The goal of LR is to determine the best fitting model that describes the relationship between one dependent binary variable against a group of independent variables [17]. LR models the transformed probability as a linear relationship of independent variables. Let y be the binary outcome indicating failure/success (not belong to the class/belongs to the class) with 0/1, respectively, and p be the probability of y=1 as p=prob(y=1). Conversely, y=0 can be expressed as 1−p. Then, LR models the outcome y based on linear combination of the independent data variables x1,x2,…,xk and their respective parameter/weight values β1, β2, …, βk via maximum likelihood method as given by:

For an accurate LR model with minimum error, we determine the cost function J(θ) such that the square error between the actual values of y and its predicted values y^ is minimized. Thus, using mean squared error formulation for LR makes the cost function J(θ) non-convex with multiple local minima. Therefore, we use cross entropy based LR formulation, where cross entropy H is defined as the dissimilarity measure between the probability p corresponding to actual values y and predicted probability p^ corresponding to the predicted values y^ can be calculated as:

From Equation (2), the new cross entropy based LR cost function is formulated as:

## Section: 2. Background and Related Work › 2.5. Gaussian Naive Bayes Classifier

Naive Bayes classifier is another commonly used ML supervised technique for data classification purposes. It follows the principle of maximum a posteriori probability (MAP) estimation for a probabilistic classification of data. Let y∈{0,1} be the binary class outcome for a given new data point x. According to Bayes theorem, the posterior probability P(y|x) can be expressed in terms of prior probability P(y) and likelihood P(y|x) as described by:

where

Therefore, the posterior probability for different classes can be calculated from Equation (4). The class with highest probability is chosen for classifying the new data point x. This strategy is called the MAP estimation as formulated below:

Gaussian Naive Bayes (GB) classifier is used when the features have continuous values and follow Gaussian or normal distribution [18]. The likelihood of features is assumed to be Gaussian and is given by

where μy denotes the mean of class y and σy2 gives the variance of class y. The standard normal distribution N(μ,σ) is a bell shaped density described by its mean μ=0 and standard deviation σ=1.

## Section: 2. Background and Related Work › 2.6. K-Nearest Neighbor Classifier

K-nearest neighbor (KNN) classifier is a widely used ML technique for its easy interpretation and low calculation time for both classification and regression problems. Given a new data point x which has to be assigned to one of the classes y∈{0,1}, the KNN algorithm performs the classification task as described by the following steps [19]:

## Section: 2. Background and Related Work › 2.7. SMOTE Algorithm

SMOTE is a popular oversampling technique which creates new synthetic data points rather than by oversampling with replacement or redundant samples of the minority class data [9]. SMOTE algorithm is detailed below [12,14,20]:

## Section: 3. Proposed Methodologies

Among several classifiers applied to the training phase of the dataset, it was experimentally found that LR had excellent classification performance in detection of maximum non-drug conformations and GB classifier provided better detection of potential binding drug candidate conformations compared to other classifiers from our previous work [21]. For classification purposes, we denote the non-drug molecular conformation samples that have inactive binding to target proteins as belonging to class 0 and potential drug candidate molecular conformations that have active binding to target proteins as class 1 samples. Thus, this is a binary classification problem. We use this as a basis to design our comprehensive drug-candidate conformation detection system that leverages the detection of both potential drug- and non-drug conformations for expedited clinical trials. This system comprises of two stages:

Flowchart of the proposed two-stage sampling-based classifier.

## Section: 3. Proposed Methodologies › Two-Stage Sampling-Based Classifier Algorithm

The motivation behind using methodology 1 is to identify the maximum number of non-drug protein conformations, whereas methodology 2 is used to provide an additional layer of security to reconfirm the potential-drug conformations identified by the methodology 1 along with the identification of new potential-drug conformations through decision fusion strategy. This form of two-stage tailored binary classification system ensures maximum detection of both potential drug candidate- and non-drug protein conformations at each step. Consequently, it aims to reduce the failure rates incurred during the clinical trials involved in the drug development process. The identified protein conformations can considered by the clinicians for informed decision-making to discard the non-drug candidate protein conformations and retain only the potential drug-candidate protein conformations for in vitro experimental approaches, thus reducing the substantial investment of resources that include time, cost, and rigorous lab testing trials.

Flowchart of the proposed two-stage sampling-based classifier.

## Section: 4. Results and Discussion

Number of class 0 samples and class 1 samples in the original training dataset.

Classification performance of Methodology 1-LR on the original training dataset.

Classification performance of Methodology 2—GB and KNN on the original training dataset.

Number of class 0 samples and class 1 samples in the new training dataset.

Classification performance of SMOTE-GB and SMOTE-KNN on the new training dataset.

Reconfirmation and identification of new TP by Methodology 2—SMOTE-GB and SMOTE-KNN.

Decision fusion of Methodology 1 and Methodology 2: LR+SMOTE-GB and LR+SMOTE-KNN.

Plot of overall classification accuracies across varying training sizes for case 1, case 2, and decision fusion for protein ADORA2A.

Plot of TP accuracies across varying training sizes for case 1, case 2, and decision fusion for protein ADORA2A.

Plot of TN accuracies across varying training sizes for case 1, case 2, and decision fusion for protein ADORA2A.

Number of class 0 samples and class 1 samples in the original training dataset.

Classification performance of Methodology 1-LR on the original training dataset.

Classification performance of Methodology 2—GB and KNN on the original training dataset.

Number of class 0 samples and class 1 samples in the new training dataset.

Classification performance of SMOTE-GB and SMOTE-KNN on the new training dataset.

Reconfirmation and identification of new TP by Methodology 2—SMOTE-GB and SMOTE-KNN.

Decision fusion of Methodology 1 and Methodology 2: LR+SMOTE-GB and LR+SMOTE-KNN.

Plot of overall classification accuracies across varying training sizes for case 1, case 2, and decision fusion for protein OPRK1.

Plot of TP accuracies across varying training sizes for case 1, case 2, and decision fusion for protein OPRK1.

Plot of TN accuracies across varying training sizes for case 1, case 2, and decision fusion for protein OPRK1.

Plot of ROC curve for ADORA2A protein for a training size of 30%.

AUC Score and F1 Score of the proposed ML methodologies for ADORA2A.

Plot of ROC curve for OPRK1 protein for a training size of 30%.

AUC Score and F1 score of the proposed ML methodologies for OPRK1.

## Section: 4. Results and Discussion › 4.1. Datasets Description

In our initial experiments, several ML classifiers such as support vector machines (SVMs), GB, LR, and KNN classifiers were explored. Most of them yielded a good classification performance with a high detection of non-drug conformations/TNs, but a very low detection of drug candidate conformations/TPs. This was mainly because of the class imbalance problem, due to which the performance of ML classification models was more biased towards the majority class; (i.e., class 0 samples). This prompted us to design a system specifically to tackle the class imbalance problem and maximize the detection of TPs and TNs, and evaluate the performance of our proposed methods through the standard classification metrics that adequately represent the model performance.

## Section: 4. Results and Discussion › 4.2. Performance Evaluation

This section comprises of three test cases, namely, Case 1: Training set with biased population of class 0 samples. Case 2: Training set with biased population of class 1 samples. Finally Case 3: Decision fusion strategy. The quantitative performance analysis of the proposed classification techniques for each of the test cases are conducted using the measures as defined below:

Classification Accuracy (Acc): The accuracy of a test is defined as the ability to differentiate the “Active Binding” and “Inactive Binding” cases correctly. Mathematically, it is given by

where

Sensitivity (Se): The sensitivity of a test is defined as the ability to determine the “Active Binding” cases correctly. Mathematically, it is given by

Specificity (Sp): The specificity of a test is defined as the ability to determine the “Inactive Binding” cases correctly. Mathematically, it is given by

Performance Evaluation using AUC-ROC Curve: ROC curve (or receiver operating characteristic curve) is a plot that summarizes the performance of a binary classification model on the positive class and the area under the curve (AUC) represents degree or measure of separability. It measures the capability of the model to distinguish between the classes. AUC can be calculated to give a single score for a classifier model across all threshold values. Higher AUC represents better prediction or classification capabilities of the model. The ROC curve is plotted with True Positive Rate (TPR) against the False Positive Rate(FPR) where TPR is on y-axis and FPR is on the x-axis.

## Section: 4. Results and Discussion › 4.3. Computational Evaluation on the ADORA2A Dataset

Case 1: Training set biased population of class 0 samples: Table 2 gives the per-class samples present in accordance with the various training sizes considered.

From Table 3, it can be noted that LR identified 151 TPs from 579 samples of class 1 and 1313 TNs from 1519 samples of class 0 for a training size of 30%. Thus, the observed results across all cases validate our argument that LR has the best classification performance for detection of TNs or non-drug conformations.

From Table 4, it can be seen that GB identified 279 TPs from 579 samples of class 1 and 1059 TNs from 1519 samples of class 0. Similarly, KNN identified 149 TPs from 579 samples of class 1 and 1245 TNs from 1519 samples of class 0 for training size of 30%. Thus, it can be noted that overall GB had the best classification performance in methodology 2 and gave better detection rates of TPs or potential drug candidate conformations over the KNN classifier.

Case 2: New training set with biased population of class 1 samples: This case studies the effects of induced class imbalance on the prediction rates of molecular conformations. The goal here is to maximize the detection of TPs identified by methodology 2 via the two stage sampling based approach in order to improve the model performance. For this, we perform SMOTE oversampling of class 1 samples and undersampling of class 0 samples, such that the new training data size is consistent with the original training data size. Methodology 2 is then employed for data-learning on the resultant new training set. Table 5 gives the per-class distribution in the new training dataset. From Table 5 results, we observe that the size of the new training dataset is the same as that of the original training dataset. For instance, the original training dataset had 628 class 0 samples and 271 class 1 samples for training size of 30%. The new training dataset has the same number of class 0 samples = 271 and number of class 1 samples = 628 for 30% training size.

Table 6 describes the overall improved classification performance of the proposed two-stage classification system and the effects of induced class imbalance of class 1 data population. From Table 6, SMOTE-GB identified 384 TPs, which is more than the 279 TPs identified using the original training dataset in Table 4 for training size of 30%. In particular, the SMOTE-KNN classifier had the best methodology 2 classification performance, wherein it identified 504 TPs, which is more than the 149 TPs identified using the original training dataset in Table 4 for training size of 30%. The affable effects of induced class imbalance are evident from the boost in classification performance of methodology 2 techniques. In particular, the SMOTE-KNN technique works on the concept of nearest neighbor algorithm and more induced neighbors via oversampling of class 1 samples implies better statistical conclusion of the underlying population distribution of the potential drug candidate conformations.

Table 7 describes the overall TPs and TNs reconfirmed and identified, including the unique TPs identified by Methodology 2. For the training size of 30%, SMOTE-GB reconfirmed on 134 TPs identified by methodology 1 apart from identifying 250 new TPs. Thus, in total, it identified 384 TPs using the new training dataset. The SMOTE-KNN classifier reconfirmed the 140 TPs identified by methodology 1 classifier aside from identifying 364 new TPs. Thus, in total, 504 TPs were identified using the new training dataset. Thereby, Table 7 further demonstrates the effectiveness of the proposed two-stage sampling-based classification approach.

Case 3: Decision Fusion: This case explores a decision fusion strategy via a majority voting scheme as a means to assimilate the classification conclusions from methodology 1—LR with the results from the methodology 2 system: SMOTE-GB and SMOTE-KNN techniques to arrive at a global consensus of the overall identified molecular conformations that possess active binding property. The quantitative performance of proposed decision fusion method is determined in terms of the below measures:

where Ntest represents the total number of class 1 and class 0 samples in the test set.

where Ntest1 represents the total number of class 1 samples in the test set.

where Ntest0 represents the total number of class 0 samples in the test set.

Table 8 demonstrates the overall classification performance of the proposed decision fusion case. From Table 8 and Figure 2, Figure 3 and Figure 4, it can be inferred that the overall classification performance of the proposed methods: LR+SMOTE-GB and LR+SMOTE-KNN techniques were significantly superior to individual classification performance of LR, GB, and KNN classifiers as given in Table 3 and Table 4. From Figure 2, Figure 3 and Figure 4, especially, LR+SMOTE-KNN had excellent classification performance for identification of the molecular conformations for protein ADORA2A in terms of overall classification accuracy and TP accuracy measures.

Number of class 0 samples and class 1 samples in the original training dataset.

Classification performance of Methodology 1-LR on the original training dataset.

Classification performance of Methodology 2—GB and KNN on the original training dataset.

Number of class 0 samples and class 1 samples in the new training dataset.

Classification performance of SMOTE-GB and SMOTE-KNN on the new training dataset.

Reconfirmation and identification of new TP by Methodology 2—SMOTE-GB and SMOTE-KNN.

Decision fusion of Methodology 1 and Methodology 2: LR+SMOTE-GB and LR+SMOTE-KNN.

Plot of overall classification accuracies across varying training sizes for case 1, case 2, and decision fusion for protein ADORA2A.

Plot of TP accuracies across varying training sizes for case 1, case 2, and decision fusion for protein ADORA2A.

Plot of TN accuracies across varying training sizes for case 1, case 2, and decision fusion for protein ADORA2A.

## Section: 4. Results and Discussion › 4.4. Computational Evaluation on the OPRK1 Dataset

Case 1: Training set biased population of class 0 samples: Table 9 gives the per-class distribution in accordance with the various training sizes considered.

From Table 10, the observed results across all cases validate our argument that LR has the best classification performance for detection of TNs or non-drug conformations due to the class imbalance problem.

From Table 11, it can be seen that GB identified 51 TPs from 96 samples of class 1 and 804 TNs from 2004 samples of class 0 for a training size of 30%. Similarly, KNN could not identify any TPs from 96 samples of class 1 but identified 100% of TNs of class 0 samples for a training size of 30% due to the class imbalance problem. Thus, it can be noted that overall GB had the best classification performance as in Methodology 2 with better detection rates of TPs or potential drug candidate conformations over the KNN classifier.

Case 2: New training set with biased population of class 1 samples: Table 12 gives the per-class distribution in the new training dataset. From Table 12, it can be noted that the size of new and original training datasets are the same. From Table 13, SMOTE-GB identified 61 TPs and SMOTE-KNN identified 93 TPs, which is more than the TPs identified using the original training dataset in Table 11 for the training size of 30%. The effects of induced class imbalance are evident from the boost in classification performance of both of the methodology 2 classifiers. From Table 14 for the training size of 30%, methodology 1 could not identify any TP, but methodology 2 classifiers—SMOTE-GB identified 61 new TPs and the SMOTE-KNN classifier identified 93 new TPs.

Case 3: Decision Fusion: Table 15 demonstrates the overall classification performance of the proposed decision fusion case. From Table 15 and Figure 5, Figure 6 and Figure 7, LR+SMOTE-KNN had excellent classification performance for identification of the molecular conformations for protein OPRK1 in terms of overall classification accuracy and TP accuracy measures. Therefore, it can be surmised that this work presents a new avenue that successfully leverages the class imbalance problem to design a novel and effective drug conformation detection system for efficient clinical trials in drug discovery application.

Performance evaluation using ROC curves, AUC, and F1 scores: To further quantitatively validate the efficacy of our proposed methodologies, statistical measures such as ROC curves, F1, and AUC scores were computed. Figure 8 presents the ROC curves and Table 16 gives the AUC scores and F1 scores for the proposed ML methodologies for protein ADORA2A. It can be noted that the proposed LR+SMOTE-GB approach has the best performance in terms of AUC score = 0.638, whereas the other proposed method LR+SMOTE-KNN had better F1 score = 0.792 for protein ADORA2A. Similarly, Figure 9 illustrates the ROC curves for the proposed ML methodologies and Table 17 gives the AUC scores obtained for protein OPRK1. It can be noted that both LR+SMOTE-GB and LR+SMOTE-KNN had performed well and has the best area under the curve with an AUC score of 0.475 and 0.470 respectively. Similarly, the proposed method LR+SMOTE-KNN had the best F1 score = 0.968 than the LR+SMOTE-GB method with F1 score = 0.770. These results corroborate our argument that it is highly beneficial to look into a comprehensive drug discovery system that maximizes detection of both the potential drug and non-drug protein conformations for efficient drug discovery process.

Number of class 0 samples and class 1 samples in the original training dataset.

Classification performance of Methodology 1-LR on the original training dataset.

Classification performance of Methodology 2—GB and KNN on the original training dataset.

Number of class 0 samples and class 1 samples in the new training dataset.

Classification performance of SMOTE-GB and SMOTE-KNN on the new training dataset.

Reconfirmation and identification of new TP by Methodology 2—SMOTE-GB and SMOTE-KNN.

Decision fusion of Methodology 1 and Methodology 2: LR+SMOTE-GB and LR+SMOTE-KNN.

Plot of overall classification accuracies across varying training sizes for case 1, case 2, and decision fusion for protein OPRK1.

Plot of TP accuracies across varying training sizes for case 1, case 2, and decision fusion for protein OPRK1.

Plot of TN accuracies across varying training sizes for case 1, case 2, and decision fusion for protein OPRK1.

Plot of ROC curve for ADORA2A protein for a training size of 30%.

AUC Score and F1 Score of the proposed ML methodologies for ADORA2A.

Plot of ROC curve for OPRK1 protein for a training size of 30%.

AUC Score and F1 score of the proposed ML methodologies for OPRK1.

## Section: 5. Conclusions

In this paper, we introduced a novel two-stage sampling-based ML classification techniques to overcome the class imbalance problem and maximize the prediction of non-drug-binding and potential drug-binding molecular conformations for the target proteins ADORA2A and OPRK1. The motivation of this work is to accelerate the drug discovery process. Applied to novel protein targets, this approach will lead to reducing of the failure rates in clinical trials for an efficient drug development process, as it will allow for identifying the drug-binding conformations of frequent off-target proteins. It was experimentally evaluated that the proposed decision fusion techniques: LR+SMOTE-GB and LR+SMOTE-KNN demonstrated superior classification performance compared to the individual classifier ML models: LR, GB, and KNN. In particular, LR+SMOTE-KNN outperformed other methods and gave the maximum prediction rate of molecular conformations for proteins ADORA2A and OPRK1 with a total accuracy of 87.6% and 99.7% for training size 30%. This work further highlights the need and advantages of ML techniques to hasten the drug discovery process.

## Section: 6. Future Scope

Random undersampling could lead to a high probability of important information loss pertinent to non-drug molecular conformations. Hence, as a future endeavor, this work will be a foundation for improved drug discovery system design that will preserve the information present in both potential drug- and non-drug conformations.

## Section: Acknowledgments

This research work was supported by an Early Career Research Fellowship from the Gulf Research Program of the National Academies of Sciences, Engineering, and Medicine for supporting this work. DISCLAIMER: “The content is solely the responsibility of the authors and does not necessarily represent the official views of the Gulf Research Program of the National Academies of Sciences, Engineering, and Medicine”.

## Section: Author Contributions

Conceptualization, V.S.A., V.M. and J.B.; methodology, V.S.A. and V.M.; software, and validation, V.S.A. and V.M.; formal analysis, investigation, V.S.A., V.M. and J.B.; resources, data curation, J.W. and J.B.; writing—original draft preparation, review and editing, V.S.A., V.M. and J.B.; visualization, V.S.A. and J.W.; supervision, V.M. and J.B.; project administration, V.M. and J.B.; funding acquisition, V.M. All authors have read and agreed to the published version of the manuscript.

## Section: Funding

Publication costs were supported by an Early Career Research Fellowship from the Gulf Research Program of the National Academies of Sciences, Engineering, and Medicine.

## Section: Institutional Review Board Statement

Not applicable.

## Section: Informed Consent Statement

Not applicable.

## Section: Data Availability Statement

Statistical and computational models used are fully detailed in the main text. Data will be made available upon personal requests to authors.

## Section: Conflicts of Interest

The authors declare no conflict of interest.

## Section: Associated Data › Data Availability Statement

Statistical and computational models used are fully detailed in the main text. Data will be made available upon personal requests to authors.
