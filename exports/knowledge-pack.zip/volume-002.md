# Drug Repurposing for COVID-19 using Graph Neural Network with Genetic, Mechanistic, and Epidemiological Validation

- **Authors:** Kang-Lin Hsieh, Yinyin Wang, Luyao Chen, Zhongming Zhao, Sean Savitz, Xiaoqian Jiang, Jing Tang, Yejin Kim
- **Issuer:** Preprint server
- **Type:** Preprint
- **Published:** 2020-12-11
- **DOI:** 10.21203/rs.3.rs-114758/v1
- **Source:** https://doi.org/10.21203/rs.3.rs-114758/v1
- **Licence:** CC-BY

## Section: Abstract

Abstract Amid the pandemic of 2019 novel coronavirus disease (COVID-19) infected by SARS-CoV-2, a vast amount of drug research for prevention and treatment has been quickly conducted, but these efforts have been unsuccessful thus far. Our objective is to prioritize repurposable drugs using a drug repurposing pipeline that systematically integrates multiple SARS-CoV-2 and drug interactions, deep graph neural networks, and in-vitro/population-based validations. We first collected all the available drugs (n= 3,635) involved in COVID-19 patient treatment through CTDbase. We built a SARS-CoV-2 knowledge graph based on the interactions among virus baits, host genes, pathways, drugs, and phenotypes. A deep graph neural network approach was used to derive the candidate drug’s representation based on the biological interactions. We prioritized the candidate drugs using clinical trial history, and then validated them with their genetic profiles, in vitro experimental efficacy, and electronic health records. We highlight the top 22 drugs including Azithromycin, Atorvastatin, Aspirin, Acetaminophen, and Albuterol. We further pinpointed drug combinations that may synergistically target COVID-19. In summary, we demonstrated that the integration of extensive interactions, deep neural networks, and rigorous validation can facilitate the rapid identification of candidate drugs for COVID-19 treatment. This paper had been uploaded to arXiv : https://arxiv.org/abs/2009.10931


---

# Machine Learning in Prediction of Intrinsic Aqueous Solubility of Drug-like Compounds: Generalization, Complexity or Predictive Ability?

- **Authors:** Mario Lovric, Kristina Pavlović, Petar Žuvela, Adrian Spataru, Bono Lučić, Roman Kern, Richard Ming Wah Wong
- **Issuer:** Preprint server
- **Type:** Preprint
- **Published:** 2020-08-04
- **DOI:** 10.26434/chemrxiv.12746948.v1
- **Source:** https://doi.org/10.26434/chemrxiv.12746948.v1
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Here, we present a collection of publicly availableintrinsic aqueous solubility data of 829 drug-likecompounds. Four different machine learning algorithms(random forest, light GBM, partial least squares andLASSO) coupled with multi-stage permutationimportance for feature selection and Bayesian hyperparameter optimization were employed for theprediction of solubility based on chemical structuralinformation. Our results have shown that LASSOyielded the best predictive ability on an external test setwith and RMSE(test) of 0.70 log points and 105 featuresin the model. Taking into account the number ofdescriptors as well, an RF model achieved the bestbalance between complexity and predictive ability withan RMSE(test) of 0.72 with only 17 features. Wepropose a ranking score for choosing the best model, astest set performance is only one of the factors in creatingan applicable model. The ranking score is a weightedcombination of generalization, number of featuresinvolved and test set performance The data related to this paper can be downloaded from 10.5281/zenodo.3968754


---

# A narrative review of estimands in drug development and regulatory evaluation: old wine in new barrels?

- **Authors:** M Mitroiu, K Oude Rengerink, S Teerenstra, F Pétavy, K C B Roes
- **Issuer:** Trials
- **Type:** Scientific article
- **Published:** 2020-07-23
- **Language:** en
- **DOI:** 10.1186/s13063-020-04546-1
- **Source:** https://pubmed.ncbi.nlm.nih.gov/32703247/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackgroundAn estimand defines the target of estimation for a clinical trial through specification of the treatment, target population, variable, population-level summary and of the strategies for intercurrent events. A carefully defined estimand aligns the clinical trial design and analysis with the scientific question of interest and adequately accounts for so-called intercurrent events. The ICH E9(R1) addendum suggests five estimand strategies. We evaluated to what extent current practice in drug development and regulatory assessment fits in the estimand framework.MethodsWe systematically evaluated what estimands, especially what strategies for intercurrent events are advised in European Medicines Agency disease guidelines, used in sponsors’ trials and additionally requested by the European Medicines Agency in assessment dossiers. We selected four therapeutic areas: nervous system, oncology, cardiovascular diseases and respiratory diseases. For each, we evaluated all disease guidelines with approved drugs, the dossiers of the most recently approved drugs matching the guidelines and corresponding regulatory questions.ResultsStrategies for intercurrent events were present in 18 (53%) of 34 guidelines, in all 34 sponsor documentations and in 15 (44%) of 34 sets of regulatory questions. Treatment policy was advised in 13 (38%) guidelines and was applied in 9 corresponding sponsor documentations. Of these 9, it was the sole strategy in 4 cases and accompanied by another strategy in 5 cases. Hypothetical strategy was not advised in guidelines. However, it was the leading strategy applied in 25 (74%) sponsor documentations. Composite strategy was advised in 3 (9%) guidelines and applied accompanied by another strategy in 2 corresponding sponsor documentations. While on treatment strategy was not advised in guidelines, but was applied in 2 sponsor documentations. Principal stratum strategy was advised in 2 guidelines but not applied in corresponding sponsor documentations. Of the regulatory questions, treatment policy was present in 2 cases (6%), hypothetical in 6 cases (18%), composite in 6 cases (18%) and while on treatment in 1 case (3%).ConclusionsEstimand attributes are present in guidelines, sponsor documentations and regulatory questions, but not described as estimands. Treatment policy was most often advised in guidelines, but hypothetical was the leading strategy applied in sponsor documentations. Thus, results indicate not a full concordance between the regulatory target of estimation and what is actually estimated. The lack of concordance was mostly due to limitations in collection of intercurrent events data to enable a treatment policy strategy. There is, therefore, a need to better define estimands at the design stage and throughout the applications dossiers and assessment reports.Keywords: Estimand, Intention-to-treat, Per protocol, Intercurrent event, Post-randomisation event, Study withdrawal, Treatment compliance, Treatment adherence, Treatment discontinuation, Missing data

## Section: Background

In randomised controlled clinical trials, the aim is to estimate the effect of an intervention compared to a control treatment, unconfounded by assignment to intervention or control. Through randomisation, it is intended that any difference in clinical outcome can be attributed to the intervention and can be causally interpreted [1]. In practice, post-randomisation events, such as treatment discontinuation, use of concomitant medication or a switch in treatment arm, may be related to the treatment. These post-randomisation events cause missing outcome values or more complex; they introduce bias in outcomes obtained. They do not preserve randomisation and subsequently do not allow the randomisation-based inference, hence impacting the estimation of the treatment effect and/or its interpretation. In this context, many methods were proposed to deal with missing data, such as mixed models or imputation methods, or using a composite endpoint treating missing values as non-responders in order to minimise bias [2–4]. However, little attention was given to what impact these missing data handling methods actually have on the treatment effect to be estimated at target population level in realistic conditions. There was a fundamental lack of common understanding between involved stakeholders of what these methods aim to estimate in relevant target patient population terms, as well as a lack of harmonisation in applying and interpreting these methods [5].

The ICH E9 ([6]) describes the intention-to-treat (ITT) principle and the analysis set (FAS).

Hence, it points out to the reader that in practice, it may not be possible to have all outcomes observed for all randomised patients in order to comply with the intention-to-treat principle. Furthermore, the full analysis set is used to describe the population almost the same as all randomised patients and certain criteria are mentioned (with respect to treatment intake and missing data) that could lead to patients being excluded from the FAS, e.g. “the failure to take at least one dose of trial medication and the lack of any data post randomisation”. However, it does not mention the scenario when some of the randomised patients have only partially observed outcome data, such as in a longitudinal trial with repeated measurements at protocolled visits, that have all visits but the last one at end of trial, irrespective of other post-randomisation events that did not lead to missing data. Therefore, the trialists are in a difficult and challenging position where something has to be done for the patients with partially or fully missing outcomes (e.g. after they discontinue study, regardless of their reason) in order to comply with the intention-to-treat principle and to reach a full analysis set. It is yet unclear what was done or what can be done in order to include these patients in the (m)ITT analysis.

The term “estimand” is not new in statistics [7]. More recently, it was used as a solution for the “missing data problem” [8, 9]. In 2017, it was incorporated into ICH E9(R1) draft addendum on estimands and sensitivity analysis in clinical trials ([10, 11]), primarily to precisely define the treatment effect in a randomised trial. This addendum supplements the ICH E9 guideline “Statistical Principles for Clinical Trials” ([6]) from the International Council for Harmonisation of Technical Requirements for Pharmaceuticals for Human Use (ICH) [12]. The addendum recommends that the estimand should be precisely defined upfront, which addresses more than the “missing data problem”.

The draft E9(R1) addendum defines four attributes to describe the estimand: variable (or outcome), population, population-level summary and strategies to account for intercurrent events.

The variable (or outcome) to be obtained or measured for each individual patient that is required to address the scientific question. If we use an example from pain medication, the variable could be a visual analogue score (VAS) obtained at pre-specified visit times in a trial for acute pain treatment, e.g. VAS to be measured or obtained at baseline, at week 4, week 8 and at week 12 (end of trial).

The population, referring to the patients targeted by the scientific question. In the trial for pain treatment, the population could be “adults suffering from acute pain”.

The population-level summary for the variable which provides a basis for a comparison between treatment conditions. For example, it could be the difference in VAS means between the experimental and control arm at a pre-planned timepoint, e.g. at 12 weeks.

The specification of how to account for intercurrent events to reflect the scientific question of interest (through strategies for intercurrent events); intercurrent events are defined in E9(R1) addendum as “events occurring after treatment initiation that affect either the interpretation or the existence of the measurements associated with the clinical question of interest.” The E9(R1) addendum suggests five strategies to address intercurrent events: (1) “treatment policy”, (2) “hypothetical”, (3) “composite”, (4) “while on treatment” and (5) “principal stratum”. For instance in the trial for pain treatment, self-administration of additional medication for pain might be prohibited by the protocol, but some patients do take it. With a treatment policy strategy, the intercurrent event “need for additional medication for pain” is actively ignored, and the VAS is used as it is for those patients that take additional medication. The treatment policy strategy would technically correspond to the intention-to-treat principle. With a hypothetical strategy, a scenario is envisaged where the intercurrent event “need for additional medication for pain” would not occur. With this strategy for instance, the VAS values following intercurrent event are set to missing if such is in accordance with the hypothetical scenario considered. With a composite strategy, the intercurrent event is explicitly taken into account and made part of the outcome, for instance, by assigning a worst value of VAS, or by considering the patient a non-responder if a binary outcome is used. With a while on treatment strategy, for this intercurrent event takes the form “while no need for additional medication for pain” and VAS values following intercurrent event are not of interest. With a principal stratum strategy, based on baseline covariates, the stratum of patients that would not experience the intercurrent event is tried to be identified. Analysis is then conducted on this stratum. The addendum informs that principal stratum should be distinguished from any type of analysis in a subgroup of patients, such as per protocol or complete case analysis. The E9(R1) addendum also describes scenarios with two different intercurrent events handled by the same strategy or each of the two intercurrent events handled by a different strategy.

The final version of the ICH E9(R1) addendum was published in December 2019 and uses five attributes [13]. One of the five attributes from the final addendum, the “treatment”, was added compared to the four attributes of the draft addendum. The strategies for intercurrent events and their definitions are not different between the draft and the final versions of the addendum. The other three attributes were slightly restructured. In the remainder of this article, we followed the structure and the four attributes from the draft version of ICH E9(R1) addendum.

It was expected that the estimand was not defined explicitly in the terms of these attributes in protocols and reports before publication of the draft addendum. However, clinical trials still had a primary objective with a primary outcome variable, a target of estimation at population level and a pre-specified statistical analysis. This entails that to some extent and at least implicitly, the key elements of an estimand are expected to be present in clinical trials before the E9(R1) addendum concepts became public.

A survey published in 2017 found that an intention-to-treat estimand was most often aimed at and that the most often used methods for missing data handling were mixed-models repeated measures (MMRM) or last observation carried forward (LOCF) imputation [14]. In the precise language of E9(R1), there is likely a mismatch between the aim of intention-to-treat (“treatment policy”) and these often used methods of dealing with missing data. Hence, impact of implementation on design and analysis of trials can certainly be expected, but it is currently unclear how large the impact of the proposed estimand framework may be. It is important to identify to what extent the framework leads to different effect estimates compared to current practice in drug development and regulatory assessment. We therefore aimed to answer the following research questions:

## Section: Methods

We systematically evaluated what estimands were targeted in regulatory disease guidelines, in trials from recently approved applications and in regulatory questions. We scrutinised what strategies to account for intercurrent events were advised, used and further requested in drug development and evaluation. We performed this review on EMA ([15]) disease guidelines ([16]) and on corresponding approved medicinal products dossiers [17].

Illustration of the process employed for data extraction and interpretation

Flow diagram detailing the identification, selection and inclusion of disease guidelines and approved products for data extraction and interpretation. *one approved product= one sponsor documentation and one corresponding set of regulatory questions

## Section: Methods › Selection of disease guidelines and medicinal products for evaluation

First, we selected all EMA disease guidelines (described hereafter as the “guidelines”) within four therapeutic areas: nervous system, oncology, cardiovascular diseases and respiratory diseases, to identify the diseases for which regulatory guidance is available for clinical efficacy investigation. We considered these four main therapeutic areas to have the broadest coverage of most estimands practices.

In November 2017, for all identified diseases within these four therapeutic areas for which regulatory guidance is available, we selected the most recently approved innovative product in the centralised procedure (Figs. 1 and 2), defined by the date of positive opinion from the Committee for Medicinal Products for Human Use (CHMP) [18]. The most recently approved products were assumed to best reflect current practice. We limited our selection to one product within each disease as a snapshot of how the estimands principles were employed in practice. We excluded guidelines for which there was no approved product available up to November 2017. We used the version of the guideline that was effective at the time of approval for each particular medicinal product, with a few exceptions. In case a new guideline became effective closely after product approval, it was assumed that draft information was available through the public consultation phase, therefore impacting already clinical trial design in practice.

For each selected product, we used the sponsor’s protocols, statistical analysis plans and clinical study reports (altogether described hereafter as the “sponsor documentation”) for the confirmatory clinical trials supporting the application for authorisation. We extracted the questions raised by the EMA during the assessment procedure verbatim from the “day 120 list of questions” of the centralised procedure (described hereafter as the “regulatory questions”). This list of questions is expected to capture the most extensive and least selective list of efficacy-related questions raised by the EMA. Regulatory questions contain the “major objections” and the “other concerns”, which can be supplementary questions addressed by regulators to the sponsor, based on the evidence provided in the application dossier which includes the sponsor’s documentation [19].

Illustration of the process employed for data extraction and interpretation

Flow diagram detailing the identification, selection and inclusion of disease guidelines and approved products for data extraction and interpretation. *one approved product= one sponsor documentation and one corresponding set of regulatory questions

## Section: Methods › Data extraction

We used three sources of information for data extraction: the guidelines, the sponsor documentation and regulatory questions. We extracted from each data source all relevant phrases and paragraphs pertaining to the target of estimation (estimand and its attributes as per ICH E9(R1) draft addendum) corresponding to the primary analyses and corresponding supplementary/sensitivity analyses:

For each selected disease guideline, we used the most recent version from the EMA website. For each selected medicinal product, we used the dossiers that we retrieved from the document management system of CBG-MEB and EMA database. We created a data extraction form, collected and stored the information in Microsoft Office Access Database (Appendix 2).

We pilot-tested the first version of the data extraction form on two products for guideline, sponsor documentation and regulatory questions. Following this pilot test, we refined the form.

## Section: Methods › Data interpretation and translation from efficacy-related information to estimand attributes

During the research, it became obvious it is necessary to add a data interpretation step in order to translate the raw, unstructured information derived from the documentation into estimand constructs. This was the case especially for the intercurrent events and strategies to account for them. The information pertaining to variable, population-level summary and target population was more straightforward to map from the basic information.

For each guideline, corresponding sponsor documentation and regulatory questions respectively, we interpreted the estimand attributes in order to reconstruct the corresponding implied estimand.

The E9(R1) draft addendum was not yet published when the guidelines were published, when the trials were conducted or when the regulatory questions were raised; therefore, the attributes were not expected to be phrased and framed in a dedicated section and not in the shape specified in E9(R1) draft addendum. The information had to be translated from text referring to the efficacy analysis into an estimand attribute (e.g. “concomitant medication use” as intercurrent event). For population-level summary, we used the comparison (statistical contrast such as difference in means, odds ratio) on which the treatment effect quantification and/or magnitude is assessed and concluded on. This was typically derived from the proposed primary analysis. For population, we used the population description in analyses or in analyses sets. The variable could be extracted as it was described. We categorised the attributes as “present” or “not present”. The attributes are qualified as “present” if they fulfil the above definitions as per draft E9(R1), regardless of where in the documents the information was found. In the example below, the attributes were considered “present”.

Conversely, if only non-specific statements, such as “The effect of missing values will need to be taken into account in the efficacy analysis and the method to address this problem needs to be pre-specified”, without being incorporated in the analysis or without clear and explicit instruction, then the intercurrent event attribute is considered “not present”. All other attributes will be qualified as “not present” if they are not specified and cannot be determined given their definitions in E9(R1) draft addendum.

Within intercurrent events, we created the category of intercurrent events “not accounted for” (NAF). This category represents the intercurrent events that were identified and possibly collected, but not included or referred to in the primary efficacy analyses, for example, “concomitant administration of systemic corticosteroids”, “change in background medication” or “salty food intake”.

We determined whether the estimand could be reconstructed from the information provided. If all attributes are scored “present”, then the estimand is classified as “can be determined”. If any of the attributes are deemed “not present”, then the implied estimand will be classified as “cannot be determined”. We interpreted the strategies using the five types of strategies proposed and defined in E9(R1) addendum: treatment policy, hypothetical, composite, while on treatment and principal stratum. Where the strategies type did not fit in one of the E9(R1) definitions, we described the strategy in detail and classified them as “other”. Per protocol analysis was not defined in the addendum, but depending on how it is defined then it could have been correspondent to a strategy, e.g. while on treatment.

To understand the strategies for intercurrent events and reconstruct the estimand, we also extracted information pertaining to the statistical analysis and imputation methods.

## Section: Methods › Quality review

The concept of intercurrent events is the novel aspect introduced with the estimand framework. The quality review therefore focused especially on the strategies to account for the intercurrent events, as these needed most interpretation. The other estimand attributes were deemed unambiguous to determine by the primary data extractor and interpreter (primary reviewer) as well as by the secondary reviewers. As we found that guideline texts often led to difference in opinions regarding presence of intercurrent events and strategies to account for them, we proceeded with full double review of all guidelines.

One person (MM—primary reviewer) extracted the data, translated it to estimand attributes and reconstructed the implied estimand. For quality control of all guidelines estimand constructs, two secondary reviewers (ST and KOR) each read the entire guidelines content and reviewed the estimands constructs next to the primary reviewer. Differences were solved in consensus between the primary and secondary reviewers. If consensus could not be reached between the primary and secondary reviewer, a third reviewer would be consulted (KR/FP) and discussed until consensus was reached. Each secondary reviewer performed the quality review for half of the selected set of guidelines.

The sponsor documentations and regulatory questions were less ambiguous to interpret, and we considered the efficacy analyses in general detailed enough in order to adjust the depth of the quality review. Each secondary reviewer performed the quality review independently for five different products dossiers (sponsor documentations and the corresponding regulatory questions). If > 25% of the intercurrent events and implied strategies would not match, then a full review would be triggered for all sponsor documentations and corresponding regulatory questions. If < 25% discrepancies but with systematic or recurrent errors (e.g. consistent mismatch in a particular strategy or combination of strategies), the primary reviewer would re-review all dossiers for that particular error.

## Section: Methods › Analysis and summary of results

We summarised the estimands and attributes overall and per therapeutic area. The experimental unit for analysis was considered a guideline, the set of sponsor documentation pertaining to one product or the set of regulatory questions related to the sponsor documentation corresponding to that product, respectively. We created cross-tabulations for attributes (“present” or “not present”), intercurrent events and type of strategy for intercurrent events according to the types proposed in E9(R1) draft addendum. We summarised what strategies for intercurrent events and in which combination they were used with the other attributes to define the estimands. If no strategy or no estimand was specified or described, these were summarised as “strategy not present” or “no estimand present”. Given the nature of the review and summaries, no statistical testing was performed.

## Section: Results

We included 34 guidelines for which products were approved, 34 sponsor documentations for the approved products corresponding to the guidelines and 34 sets of regulatory questions corresponding to the approved products we had selected (Appendix 3). Those were selected from the therapeutic areas nervous system (n = 16), oncology (n = 5), cardiovascular diseases (n = 10) and respiratory diseases (n = 3). Guidance documents effective dates ranged from 1992 to 2017, products approval ranged from 1996 to 2017 and regulatory questions dates ranged from 1995 to 2016. Two secondary reviewers agreed without or with limited changes with the data extracted and their interpretation. For the 10 sponsor documentations and regulatory questions that were reviewed in pairs, reviewers agreed more than 75% of extractions (90% with ST, 80% with KOR); hence, full peer review of all sponsor documentations and regulatory questions was not triggered.

Frequency of attribute presence/description in guidelines, sponsor documentations and regulatory questions

Variations of intention-to-treat (ITT)

Stacked barplot with strategies in guidelines, sponsor documentations and regulatory questions

Strategies by therapeutic area in a guidelines, b sponsor documentations and c regulatory questions. CNS, central nervous system; CVD, cardiovascular diseases; Onco, oncology; Resp, respiratory diseases

## Section: Results › Description of the four estimand attributes

All four estimand attributes were specified in 12% of the guidelines, in all sponsor documentations and in 3% of the regulatory questions (Table 1). We found the information pertaining to attributes scattered in different sections throughout the statistical analysis plans, protocols and clinical study reports. The information pertaining to attributes was easy to find in guidelines, but more difficult to find in sponsor documentations. The attributes were not described explicitly and often embedded in primary efficacy and statistical methods, missing data handling, data collection or results sections. If described, the attributes were found relatively easy in the regulatory questions in the section for clinical efficacy (Appendix 1). However, not all attributes are described explicitly for all analyses requested in the regulatory questions.

Frequency of attribute presence/description in guidelines, sponsor documentations and regulatory questions

Variations of intention-to-treat (ITT)

Stacked barplot with strategies in guidelines, sponsor documentations and regulatory questions

Strategies by therapeutic area in a guidelines, b sponsor documentations and c regulatory questions. CNS, central nervous system; CVD, cardiovascular diseases; Onco, oncology; Resp, respiratory diseases

## Section: Results › Description of the four estimand attributes › The variable (or outcome)

The variable was present in all 34 guidelines, in all 34 sponsor documentations and in 23 (68%) of 34 sets of regulatory questions.

## Section: Results › Description of the four estimand attributes › The population

The population was described in 8 (24%) guidelines, in all 34 sponsor documentations and in 1 (3%) set of regulatory questions. An intention-to-treat analysis (ITT corresponding to a treatment policy strategy) is advised in most guidelines.

We found in sponsor documentations multiple ways in which the analysis population deviated from the definition of the intention-to-treat principle [6]. Even if described using the same term “modified intention-to-treat”, the modifications varied between products and studies (Table 2). And, although the term “Intention-to-treat” was used, not all randomised patients were included in the analysis as the ITT principle dictates.

Variations of intention-to-treat (ITT)

## Section: Results › Description of the four estimand attributes › The population-level summary for the variable

The population-level summary was present in 13 (38%) guidelines, in all 34 sponsor documentations and in 1 (3%) set of regulatory questions.

## Section: Results › Description of the four estimand attributes › The strategies to account for intercurrent events

Intercurrent events were described in 27 (79%) guidelines, in all 34 sponsor documentations and in 23 (68%) sets of regulatory questions. Strategies to account for intercurrent events were present in just over half of the guidelines (n = 18, 53%), in all sponsor documentations (n = 34, 100%) and in almost half of the regulatory questions (n = 15, 44%) (Table 1).

Treatment policy strategy was advised in 13 (38%) guidelines. It was applied in 9 corresponding sponsor documentations. Of the 9, it was the only strategy applied in 4, and in 5 it was applied accompanied by another strategy or analysis for different intercurrent events. In the four remaining sponsor documentations, a different strategy (or a mix of other strategies) than treatment policy was applied. Treatment policy strategy was applied in total in 13 sponsor documentations; hence, in 4 of these 13 sponsor documentations, it was applied in the absence of being advised in the guideline.

Hypothetical strategy was not advised in any of the 34 guidelines. However, it was the sponsors’ preferred strategy, applied in 25 sponsor documentations, especially to account for missing outcome values (caused by known or unknown intercurrent events). Hypothetical strategy was generally used in the same estimand simultaneously with another strategy, usually with the treatment policy strategy applied for a different intercurrent event. The typical hypothetical strategies were identified in relation to LOCF, MMRM and censoring in time-to-event analysis. These were related to missing data and were used as a measure to explicitly/implicitly impute or handle missing outcomes that were planned to be collected but were not.

Composite strategy was advised in 3 (9%) guidelines. It was applied in 2 corresponding sponsor documentations. Of the 2, it was not applied as single strategy in any of the corresponding sponsor documentations; it was applied accompanied by another strategy or analysis for different intercurrent events. In the one remaining corresponding sponsor documentation, a different strategy (or a mix of other strategies) than composite was applied. Composite strategy was applied in total in 6 sponsor documentations; hence in 4 of these 6 sponsor documentations, it was applied in the absence of being advised in the guideline.

While on treatment strategy was not advised in any guideline but was applied in 2 (6%) sponsor documentations. Clinical outcome (events) was measured over the non-missing days or number of events were adjusted for the treatment period (a negative binomial model with offset for treatment exposure period), both in CNS therapeutic area. The population-level summary was a contrast for rates of events.

Principal stratum strategy was advised in 2 (6%) guidelines but was not applied in any sponsor documentations.

The estimands advised in guidelines and requested in regulatory questions contained a single strategy intending to cover one or multiple different intercurrent events at the same time, such as a treatment policy strategy applied for all intercurrent events. The estimands in sponsor documentations contained multiple strategies to concomitantly handle multiple different intercurrent events at the same time, such as a treatment policy strategy applied for one intercurrent event and hypothetical strategy for another.

In the 16 sponsor documentations corresponding to guidelines where a strategy was not advised, the hypothetical strategy was most often used for some intercurrent events and in conjunction with another strategy for other intercurrent events.

Of the regulatory questions, treatment policy strategy was present in 2 (6%), hypothetical strategy in 6 (18%), composite strategy in 6 (18%), while on treatment strategy in 1 (3%) and principal stratum strategy in none (0%).

Apart from the five strategies suggested and defined in the draft E9(R1), we found other types of analyses that do not fall within any of the five strategies definitions, we summarised these as “other” (Fig. 3). We found them in guidelines, sponsor documentations and regulatory questions. Over half of the “other” category was a per protocol analysis, using various definitions of protocol violations or deviations. Furthermore, we also encountered complete cases or available case analyses. None of these could be usefully categorised as estimand strategy.

Stacked barplot with strategies in guidelines, sponsor documentations and regulatory questions

## Section: Results › Description of the four estimand attributes › Strategies by therapeutic area

Treatment policy was the most often advised strategy in guidelines for each therapeutic area. Composite and principal stratum strategies were present in central nervous system and cardiovascular disease guidelines but were not present in guidelines for oncology and respiratory diseases (Fig. 4a).

The estimands suggested in guidelines contained a single strategy covering multiple different intercurrent events at the same time, such as a treatment policy strategy applied for all intercurrent events.

In sponsor documentations, hypothetical strategy was the leading strategy in each therapeutic area, followed by treatment policy strategy. While on treatment strategy was seen only in cardiovascular diseases. All therapeutic areas, except respiratory diseases, used the composite strategy (Fig. 4b).

In sponsor documentations, they usually aimed at a treatment policy estimand. This, however, is often not strictly achievable as per ICH E9 mainly due to limitations in the data. Reported estimands contained multiple different strategies for different intercurrent events or other analyses. For example, they applied within the same analysis treatment policy for some intercurrent event(s) and a hypothetical strategy for other intercurrent events that led to missing data.

Regulatory questions typically contained one estimand (strategy) or analysis per question. The strategies or analyses requested were usually different from a treatment policy strategy, with no clear different pattern between therapeutic areas (Fig. 4c).

Strategies by therapeutic area in a guidelines, b sponsor documentations and c regulatory questions. CNS, central nervous system; CVD, cardiovascular diseases; Onco, oncology; Resp, respiratory diseases

## Section: Discussion

With this review, we provide an overview of what the implied estimand practices were in drug development and regulatory evaluation before the publication of the draft version of ICH E9(R1) estimand framework (Fig. 3). Sponsor documentations contained more detailed descriptions of the estimand attributes than guidelines and regulatory questions. A treatment policy strategy was most often advised in guidelines and targeted in sponsor documentations. However, a treatment policy strategy could often not be fully achieved due to incomplete follow-up, resulting in a hypothetical estimand being the most frequent approach by sponsors. Apart from the five strategies defined in the addendum, we also identified other analyses types.

The variable was the estimand attribute most present and clearly defined in guidelines, sponsor documentations and regulatory questions. This was not surprising, as the clinical outcome to be obtained or measured in patients is a pivotal item to decide on, when designing a trial. It already is thoroughly discussed between involved parties. Hence, it is usually described in detail and concordant in all types of documents.

In all sponsor documentations, we found data collected and reported, for example, for drop-out due to adverse events or concomitant medication and these data are used for instance, in safety analyses. However, the included information on intercurrent events (such as an adverse event leading to study withdrawal) was not used nor referred to in the primary efficacy analysis.

We found that strategies advised in guidelines, applied in sponsor documentations and asked for in regulatory questions, were different. There could be several reasons behind this finding; it could be due to the fact that sponsors may have followed advice from disease guidelines under the remit of other regulatory authorities than EMA, such as the FDA guidelines.

Furthermore, guidelines may have advised a single general strategy that cannot be applied for all intercurrent events, such as treatment policy. Sponsors applied the advised strategy for part of the intercurrent events where the advised strategy could be applied, but also had to apply another strategy or analysis for other intercurrent events where the advised strategy could not be applied.

This could be due to lack of precision in articulating the targeted treatment effect in guidelines and also due to feasibility of applying only one strategy given the data and not because of sponsors’ lack of intent to apply advised strategies. It may also be the case that sponsors identified different or more intercurrent events than the ones suggested by guidelines and, hence, based on their treatment effect of interest, decided to apply other strategies than the strategies advised in guidelines. EMA can provide sponsors with scientific advice regarding their trials; however, not all sponsors apply for scientific advice. Moreover, having been provided with scientific advice, as it is not legally binding, it does not make it mandatory for the sponsors to follow it [20].

In spite of sponsor documentations providing more detailed specifications of analyses and estimand-related information, it could often not be inferred from the documentation why certain choices were made for specific intercurrent events. Similarly, the clinical questions raised during the assessment were not phrased precise enough to translate into the intended estimand. Therefore, it was not possible in general to determine how well aligned the estimand was with the clinical question of interest.

Although the strategies in guidelines seem to differ between therapeutic areas, the types of strategies found in sponsor documentations seemed to be similar between therapeutic areas.

The difference between strategies advised in guidelines and implemented by the sponsors could be attributed to several reasons. First, strategies advised in guidelines may not be fully achievable in practice. Secondly, sponsors may have followed disease guidelines and feedback from other regulatory regions, such as from FDA, which might have advised different strategies.

Over half of the “other” category was a per protocol analysis, using various definitions of protocol violations or deviations. We also encountered complete cases or available case analyses. However, none of these yields a proper estimate for a meaningful estimand as the results cannot be generalisable to a broader target population. It is debatable if such an analysis is actually targeting estimates in a principal stratum. It would be at very best an improper analysis for it. In this respect, the draft addendum informs that “treatment effects in principal strata should be clearly distinguished from any type of subgroup or per-protocol analyses where membership is based on the trial data”. To enable analyses in strata, causal inference approaches are likely necessary.

A strength of this research is that this review is the first of this nature. It acts as a snapshot of actual practices with estimands and strategies present in documents pertaining to medicines development and regulatory evaluation. It was done with access to extensive and full documentation of the actual protocols, results and regulatory interaction. It could be used as baseline in future publications following implementation of ICH E9(R1) addendum. We used publicly available guidelines and had access to regulatory agencies databases. Concomitantly with the publication of the E9(R1) addendum and from its perspective, this review provides valuable insights into current estimand practices. Thus, it can facilitate the implementation of the estimand framework in drug development and regulatory evaluation of medicinal products.

Our review also has some limitations. First, there could be other guidelines in other therapeutic areas or within those therapeutic areas for which products were not approved that contain other strategies for intercurrent events. The results observed might not be fully generalisable to those areas. However, this review represents an overview of the estimand practices in the four biggest therapeutic areas. Second, we had to interpret the intercurrent events and strategies to reverse-engineer the estimand. This process was difficult mainly because the clinical question was not detailed and clear enough to understand the targeted treatment effect and the attributes’ information was not structured consistently throughout all documentation. The possible bias due to the interpretation was partly addressed with an independent quality review from two different secondary reviewers which resulted in high percentages of concordance. It is therefore likely that it did not have much impact on the results. Furthermore, we extracted the estimand attributes as defined in the draft addendum and not as in the final addendum. Therefore, we did not collect data for “treatment” attribute. As our attention was focused mainly on the strategies used for intercurrent events, it did not impact our results and conclusions. We were not able to identify clear and unambiguous clinical questions that are addressed in the trials. Most of the times, the clinical trial objective is phrased as “to study the effect of experimental treatment X over control in patients suffering from Y”. We consider this to be insufficiently described, and according to the addendum, this is key to enunciate in detail and adequately. This impacts what treatment or treatment strategy is investigated and directly affects the estimand, regulatory evaluation and approval, and ultimately the label of the medicinal product.

The estimand framework is expected to impact all phases of drug development and regulatory evaluation. Defining the estimand aims to provide clarity and better define the treatment effect in perspective to the question of interest. It will consequently facilitate interaction between regulators, patients, clinicians, investigators, HTA bodies, statisticians and other trialists. Therefore, changes are needed for successful roll-out and alignment with the estimand principles. The estimand framework may not solve the causes of trials issues, such as incomplete patient retention or poor treatment compliance, but it would add clarity on how these can be handled in a transparent and principled manner. Apart from dissemination of the estimand framework in all branches of the medical community by means of training materials, workshops or research articles, another important step might be to update templates of trial protocols. These templates are used at initial stages of development by every involved stakeholder, irrespective of trial type or phase. One such commonly used document where the estimand framework can be introduced is the ICH M11 guideline [21]. This would formalise the need for estimand discussions early in a trial and by all stakeholders. Starting drug development using the estimand framework would ensure that subsequent stages (e.g. study or assessment reports, prescription information for patients etc.) follow the same structure and principles.

In practice, it would be very unlikely that one type of estimand or one type of strategy for intercurrent events would be satisfactory for all stakeholders [22]. For example, a regulatory body might be interested in a treatment policy strategy for an intercurrent event, while a patient would be interested in a principal stratum strategy for the same intercurrent event. It is still to be revealed by further research, how and under which conditions a clinical trial can answer different clinical questions of interest for different stakeholders, with different estimands and/or different strategies for intercurrent events. We suggest to be descriptive and explicit regarding what strategy or strategies are advised, applied or requested, for what intercurrent events. Additional to detailed descriptions, we could use for instance “single-strategy estimand” to define an estimand with one strategy handling one or more intercurrent events at the same time and “multiple-strategies estimand” to define an estimand with two/more different strategies handling two/more different intercurrent events.

Furthermore, we hope the estimand framework is implemented as envisaged in the addendum, to improve the quality with which clinical research questions are addressed by clinical trials. This includes reaching agreement between stakeholders on the estimand(s) of interest, in a transparent, principled and efficient manner.

In ICH E9, the ITT principle is defined [6]. In actual practice, many different deviations from the principle were encountered under the term “modified ITT”. However, any modification to ITT definition based on observed trial data (e.g. patients having to take at least one dose of assigned treatment) may not clearly define an actual targeted population anymore and make results difficult to interpret.

Aiming for an estimand does not guarantee estimability of that estimand from the trial data, and we think this is a common pitfall for interpretation of trials. For instance, treatment policy strategy can be pre-planned to be applied for all intercurrent events but cannot be achieved in full because of missing outcome values for other reasons. ICH E9 informed the reader that the ITT principle may be difficult to achieve as it needs complete follow-up of all randomised subjects for study outcomes [6]. For intercurrent events causing missing data or for missing outcome values, another strategy (e.g. hypothetical or composite) might be applied. Thus, this may lead to an actual estimand that is different from the one aimed at and to answering a question that deviates from the intended clinical question of interest. This situation is encountered in trials and should be acknowledged.

The estimand framework can help in the design of a trial, to pro-actively strike a balance between the estimand aimed for in principle and an estimand that is actually possible to estimate. It will also help revealing the gap between targeted and realised estimands and facilitate discussion among all stakeholders resulting also in a better understanding of drug effect and better comparison across trials or in meta-analysis of clinical trials.

So, are estimands old wine in new barrels? Estimands are both new and old, and missing data as well as intercurrent events in clinical trials are a long existing issue in medical research. Conceptually, it appears the estimands are as “old” as medical research and clinical trials, because it always had estimand elements (e.g. outcome measured) and even if empirically estimated, there was a target of estimation. Estimands in the shape principled by ICH E9(R1) are an innovative solution to deal with fundamental elements of clinical trials, starting from the research question and dealing with intercurrent events, missing data and treatment effect definitions. The estimand framework provides a new framework to align key elements of design, conduct and analysis of clinical trials to adequately answer the clinical question at hand [23].

## Section: Conclusions

Estimand attributes are present in guidelines, sponsor documentations and regulatory questions, but not described as estimands. Treatment policy was most often advised in guidelines, but hypothetical was the leading strategy applied in sponsor documentations. Thus, results indicate not a full concordance between the regulatory target of estimation and what is actually estimated. The lack of concordance was mostly due to limitations in collection of intercurrent events data to enable a treatment policy strategy. There is, therefore, a need to better define estimands at the design stage and throughout the applications dossiers and assessment reports.

## Section: Supplementary information

Additional file 1.

Additional file 2.

Additional file 3.

## Section: Supplementary information

Additional file 1.

Additional file 2.

Additional file 3.

## Section: Acknowledgements

We are deeply thankful to André Elferink, Veronica Quinto, Florian Lasch, Simona Vila, Beatriz Rabazo, Victoria Palmi Reig, Catherine Drai and Ralf Herold for their help and useful comments.

## Section: Acknowledgements › Authors’ note

The views expressed in this article are the personal views of the author(s) and may not be understood or quoted as being made on behalf of or reflecting the position of the regulatory agency/agencies or organisations with which the author(s) is/are employed/affiliated.

## Section: Authors’ contributions

MM produced and refined several drafts and iterations of this manuscript following thorough input from ST, KOR, FP and KR. All authors critically revised and approved the final version of this manuscript.

## Section: Funding

MM was supported by CBG-MEB research project funding.

## Section: Availability of data and materials

The guidelines used in this research are available from European Medicines Agency website: www.ema.europa.eu

The dossiers data are not publicly available.

## Section: Ethics approval and consent to participate

N/A

## Section: Consent for publication

N/A

## Section: Competing interests

The authors declare that there is no conflict of interest.

## Section: Contributor Information

M. Mitroiu, Email: M.Mitroiu@umcutrecht.nl

K. Oude Rengerink, Email: K.OudeRengerink-2@umcutrecht.nl

S. Teerenstra, Email: Steven.Teerenstra@radboudumc.nl

F. Pétavy, Email: Frank.Petavy@ema.europa.eu

K. C. B. Roes, Email: Kit.Roes@radboudumc.nl

## Section: Supplementary information

Supplementary information accompanies this paper at 10.1186/s13063-020-04546-1.

## Section: Associated Data

Additional file 1.

Additional file 2.

Additional file 3.

## Section: Associated Data › Supplementary Materials

Additional file 1.

Additional file 2.

Additional file 3.

## Section: Associated Data › Data Availability Statement

The guidelines used in this research are available from European Medicines Agency website: www.ema.europa.eu

The dossiers data are not publicly available.


---

# Addressing COVID-19 Drug Development with Artificial Intelligence

- **Authors:** Dean Ho
- **Issuer:** Advanced intelligent systems (Weinheim an der Bergstrasse, Germany)
- **Type:** Scientific article
- **Published:** 2020-04-27
- **Language:** en
- **DOI:** 10.1002/aisy.202000070
- **Source:** https://pubmed.ncbi.nlm.nih.gov/32838299/
- **Licence:** CC-BY

## Section: Abstract

AbstractThe emergence of severe acute respiratory syndrome coronavirus 2 (SARS‐CoV‐2), the virus that led to the COVID‐19 (Coronavirus Disease 2019) pandemic, has resulted in substantial overburdening of healthcare systems as well as an economic crisis on a global scale. This has in turn resulted in widespread efforts to identify suitable therapies to address this aggressive pathogen. Therapeutic antibody and vaccine development are being actively explored, and a phase I clinical trial of mRNA‐1273 which is developed in collaboration between the National Institute of Allergy and Infectious Diseases and Moderna, Inc. is currently underway. Timelines for the broad deployment of a vaccine and antibody therapies have been estimated to be 12–18 months or longer. These are promising approaches that may lead to sustained efficacy in treating COVID‐19. However, its emergence has also led to a large number of clinical trials evaluating drug combinations composed of repurposed therapies. As study results of these combinations continue to be evaluated, there is a need to move beyond traditional drug screening and repurposing by harnessing artificial intelligence (AI) to optimize combination therapy design. This may lead to the rapid identification of regimens that mediate unexpected and markedly enhanced treatment outcomes.Keywords: artificial intelligence, combination therapy, COVID-19, drug development, severe acute respiratory syndrome coronavirus 2

## Section: Challenges with Traditional Combination Therapy and Drug Repurposing

Given the aforementioned timelines to realizing novel drugs/vaccines, drug repurposing particularly as combination therapies has been perhaps the most widely explored among the arsenal of available treatments. In times of urgency, administering drugs that are approved for human use based on the mechanisms of drug action that may also effectively treat COVID‐19 allows for a rapid response. Multiple therapies are currently being studied (Table 1). An open label, individually randomized and controlled trial (NCT02845843) was conducted comparing a combination regimen composed of ritonavir and lopinavir (Kaletra) against the standard of care therapy (e.g., supplemental oxygen, ventilation, antibiotics, and other approaches). The study revealed no benefit of ritonavir/lopinavir administration over the standard of care treatment, and the authors discussed the possibility of combining this regimen with additional therapies to further assess the effectiveness of treatment.1 A trial to assess a combination of hydroxychloroquine and azithromycin is underway (NCT04321278). Remdesivir (Gilead Sciences), an investigational therapy previously developed for Ebola, is currently being investigated via two regimens in a phase 3 clinical trial, with the primary outcome being the normalization of oxygen saturation and temperature from first dose to day 14. A secondary outcome is assessing adverse events from first dose to day 10 that may lead to treatment discontinuation (NCT04292899).

Aside from these studies, a number of trials are being run to assess other repurposed drug combinations. These range from favipiravir in combination with tocilizumab (NCT04310228); lopinavir/ritonavir, ribavirin, and interferon‐beta (NCT04276688); hydroxychloroquine, azithromycin, and tocilizumab (NCT04332094); and others. It is evident that combinatorial drug repurposing is a prevalent and likely on the fastest means of identifying a possible effective therapy against the severe acute respiratory syndrome coronavirus 2 (SARS‐CoV‐2) virus/COVID‐19 disease. However, current strategies used to design repurposed drug combinations primarily involve the codelivery of therapies based on the mechanism of action (MOA) followed by dose finding with the objective of finding drug synergy. Unfortunately, drug synergy does not guarantee a successful treatment outcome. This approach, while established, strongly limits the range of drugs that can be considered for use. This is because the addition of more drugs into consideration markedly increases the parameter space that is searchable for optimal combinations. In addition, properly identifying the right doses of each drug in a combination is essential. When both drug selection and drug dosing are considered, sufficiently interrogating the parameter space becomes insurmountable using traditional screening approaches. Of note, the limited sampling of this parameter space, which is virtually assured via traditional combination design and screening, is a core driver of why in vitro results do not translate successfully into the clinic.

Take, for example, a set of 15 candidate therapies against COVID‐19, or any other disease indication. If drug 1 is evaluated against the disease model, and does not exhibit any apparent efficacy, it will conventionally be removed from further consideration. However, it is possible that drug 1 may be a vital component of the drug combination that mediates optimal treatment efficacy and safety. Although a 15‐drug set does not represent a large set of candidate compounds, the parameter space that results from 15 drugs and their respective doses is in fact extraordinarily large. Unfortunately, neither traditional drug screening nor traditional combination therapy design is capable of globally optimal drug combinations from a parameter space of this magnitude. Traditional screening and combination therapy design may also lead to insufficient surveying of a full drug–dose parameter space, resulting in drug combinations that will not comprehensively reflect the unpredictable drug activity or interactions which can be leveraged to globally optimize therapeutic efficacy and safety. In addition, partial drug–dose parameter space screening can lead to the combinations that may exhibit suitable efficacy in vitro that, as previously mentioned, cannot be replicated at the patient level. Unfortunately, this approach can often identify certain drugs or combinations as nonefficacious; in fact, they could be clinically effective while administered in nonobvious combinations at unexpected doses. Therefore, in lieu of MOA‐based drug selection followed by synergistic dose finding, simultaneous drug and dose identification among high‐dimensional search spaces is needed. Although it is well established in drug dosing that dosing impacts drug efficacy and toxicity, it can also determine which drugs belong in a combination therapy regimen in the first place. This is among the most overlooked aspects of drug development. This is a barrier that can be uniquely addressed using artificial intelligence (AI), and, importantly, could enable a markedly enhanced response to COVID‐19 treatment as well as rapid intervention against future outbreaks.

Examples of single/combination drug trials to address COVID‐19

## Section: Accelerating Combination Therapy Development and Optimization with AI

In the context of deploying AI alongside the infectious disease treatment roadmap, it is important to differentiate between the segments of this roadmap. First, the aforementioned use of AI in drug discovery will undoubtedly lead to promising candidates, and these candidates will likely follow a conventional longer‐term drug development pathway toward clinical validation studies. Another segment of this roadmap pertains to drug development, which involves patient matching to trials, and of note combination therapy design.2 When rapid intervention is needed during pandemics, for example, AI‐based combination therapy design represents a vital strategy that can identify optimal regimens within a matter of days.

A number of promising methods have previously been explored in an effort to develop infectious disease drug combinations.3 Many of the resulting multidrug regimens are based on synergistic drug interactions to amplify treatment efficacy. Synergy can also be used to predict potent drug combinations during the design process. Among all of the strategies that are being used, however, AI‐based platforms have emerged as promising solutions, particularly when they are capable of rapidly optimizing drug combinations without complex disease mechanism data. Project IDentif.AI, a recently developed strategy, does not require big data‐based training sets to rapidly pinpoint suitable drug combinations from extraordinarily large parameter spaces.4 Project IDentif.AI is a neural network‐based approach based on a quadratic correlation between inputs defined by drugs and their respective doses and outputs defined by treatment efficacy and safety. This correlation markedly reduces the number of assays needed to pinpoint a list of ranked drug combinations that optimize the treatment outcomes based on a maximized index of efficacy and treatment tolerability. Importantly, Project IDentif.AI can be implemented across the in vitro through clinical phases of drug combination validation. Importantly, the platforms that have served as foundations for the development of Project IDentif.AI have shown prior clinical successes in indications ranging from oncology to infectious diseases. Specifically, positive treatment outcomes were observed in direct ex vivo to clinical validation studies for hematologic cancer (Quadratic Phenotypic Optimization Platform [QPOP]),5 and the key role of dynamic clinical dosing on efficacy was further validated on an advanced solid cancer patient (CURATE.AI).6 In the area of infectious diseases, low‐dose treatment for human immunodeficiency virus (HIV) was shown to mediate undetectable viral loads while opening the doors to possible downstream reductions in treatment complications arising from side effects of high‐dose therapy (CURATE.AI).7

Project IDentif.AI operates in a mechanism and disease indication‐agnostic fashion in that it uses prospectively conducted assays composed of systematically designed drug/dose combinations on a disease model. As such, it does not require training data. This is because these prospectively conducted assays are conducted in a way to effectively survey the full drug–dose parameter space. Importantly, these rationally designed assays define the notion that the way the data are acquired determines our ability to harness AI to optimize treatment as opposed to the sheer volume of data. Once these prospectively executed assays are completed, the corresponding response of the disease model actively drives the optimization process to map out the quadratic correlation from which the optimized combinations can be identified. This is akin to agnostically crowdsourcing the disease model to rank out for us what the best to worst drug combinations are, without prior knowledge of the drug targets being addressed. This is in contrast to traditional approaches which involve validating a set of drugs and set doses. Among such a massive parameter space, there is virtually no way that this strategy can optimize the right drugs and right corresponding doses. As such, AI‐driven drug combination design serves as a potential first line of defense in determining the ideal combination therapies to start with, as opposed to waiting for the results from completed trials to inform subsequent treatment design. AI‐driven combination therapy design may also avoid the use of suboptimal clinical treatments, unnecessary patient mortality, and morbidity, and may even play a role in preventing downstream drug shortages.

## Section: A Globalized Effort to Harness Technology to Optimize COVID‐19 Intervention

In looking at all of the existing/ongoing and upcoming clinical trials against COVID‐19, it is clear that many varieties of combinations have been proposed, and will continue to be proposed as potential solutions. Unfortunately, many of these regimens may not result in positive outcomes because the range of combinatorial permutations and corresponding dosing will ultimately not be assessed to a sufficient degree. A cursory examination of clinical trial databases of the drugs being repurposed, resulting combinations, and dosing regimens reveal that only a fraction of the combinatorial space is being addressed. Although clinical dosing guidelines are well established and are in part guiding the protocols of how these investigational combinations are being deployed, there is an opportunity to harness platforms such as IDentif.AI to substantially increase the degree of actionability of the interventions being developed. When drug combinations are eventually optimized using AI‐driven and related methods, new capabilities will likely emerge. For example, AI‐driven optimization that is conducted during varying stages of infection will likely result in drug–dose compositions and rankings that correspond with each stage. As pathogens evolve over time, the ability to rapidly intervene using AI‐driven reoptimization may also be enabled.

Despite the considerable challenges being encountered with COVID‐19 therapy, the results observed thus far represent an opportunity to unite multinational capabilities in infectious disease drug development with AI to develop broadly deployable regimens for the benefit of the global community. At present, Novartis, Mylan, Teva Pharmaceuticals, and Bayer have collectively committed to donating over 220 million chloroquine and hydroxychloroquine tablets. These efforts have been backed by the manufacturing capabilities of Torrent Pharmaceuticals, Cadila Pharmaceuticals, and Ipca Laboratories, among others. Gilead Sciences has committed to donating 1.5 million doses of remdesivir, and Toyama Chemical has also committed its favipiravir therapy for free to the global community. To complement the trials currently underway, the World Health Organization (WHO) has initiated the SOLIDARITY clinical trial in an effort to facilitate data sharing to accelerate the assessment of treatment outcomes of multiple regimens being studied across the globe. These include local standard of care in addition to remdesivir; chloroquine or hydroxychloroquine; ritonavir and lopinavir; and ritonavir, lopinavir, and interferon beta 1‐alpha. This collection of monotherapies and combinations being assessed represents an ideal opportunity for AI deployment and the systematic derivation of actionably optimized regimens, and can potentially provide a path toward sustained preparedness for future outbreaks and pandemic prevention.

## Section: Conflict of Interest

The author is an inventor of pending patents pertaining to artificial intelligence‐based drug development.

## Section: Acknowledgements

D.H. gratefully acknowledges support by the National Research Foundation Singapore under its AI Singapore Programme (award number AISG‐GC‐2019‐002), Ministry of Education (MOE) Tier 1 FRC grant, and Singapore Ministry of Health's National Medical Research Council under its Open Fund‐Large Collaborative Grant (“OF‐LCG”; MOH‐OFLCG18May‐0003).

## Section: Biography

Dean Ho is Provost's Chair Professor in the Departments of Biomedical Engineering and Pharmacology, Director of the N. 1 Institute for Health (N. 1), Director of the Institute for Digital Medicine (WisDM), and Head of the Department of Biomedical Engineering at the National University of Singapore. Dr. Ho's team is spearheading multiple prospective/interventional clinical trials at the interface of artificial intelligence/digital medicine and disease indications including oncology, infectious diseases, digital therapeutics, and beyond. He is an elected member of the US National Academy of Inventors (NAI), and a fellow of the American Institute of Medical and Biological Engineering (AIMBE).


---

# ADMET evaluation in drug discovery. 20. Prediction of breast cancer resistance protein inhibition through machine learning

- **Authors:** Dejun Jiang, Tailong Lei, Zhe Wang, Chao Shen, Dongsheng Cao, Tingjun Hou
- **Issuer:** Journal of cheminformatics
- **Type:** Scientific article
- **Published:** 2020-03-05
- **Language:** en
- **DOI:** 10.1186/s13321-020-00421-y
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33430990/
- **Licence:** CC-BY

## Page 1 (Section: ADMET evaluation in drug discovery. 20. Prediction of breast cancer resistance protein inhibition through machine learning)

Jiang et al. J Cheminform           (2020) 12:16  
https://doi.org/10.1186/s13321-020-00421-y
RESEARCH ARTICLE
ADMET evaluation in drug discovery. 20. 
Prediction of breast cancer resistance protein 
inhibition through machine learning
Dejun Jiang1, Tailong Lei1, Zhe Wang1, Chao Shen1, Dongsheng Cao2* and Tingjun Hou1* 
Abstract 
Breast cancer resistance protein (BCRP/ABCG2), an ATP-binding cassette (ABC) efflux transporter, plays a critical role 
in multi-drug resistance (MDR) to anti-cancer drugs and drug–drug interactions. The prediction of BCRP inhibition 
can facilitate evaluating potential drug resistance and drug–drug interactions in early stage of drug discovery. Here 
we reported a structurally diverse dataset consisting of 1098 BCRP inhibitors and 1701 non-inhibitors. Analysis of 
various physicochemical properties illustrates that BCRP inhibitors are more hydrophobic and aromatic than non-
inhibitors. We then developed a series of quantitative structure–activity relationship (QSAR) models to discriminate 
between BCRP inhibitors and non-inhibitors. The optimal feature subset was determined by a wrapper feature selec-
tion method named rfSA (simulated annealing algorithm coupled with random forest), and the classification models 
were established by using seven machine learning approaches based on the optimal feature subset, including a 
deep learning method, two ensemble learning methods, and four classical machine learning methods. The statisti-
cal results demonstrated that three methods, including support vector machine (SVM), deep neural networks (DNN) 
and extreme gradient boosting (XGBoost), outperformed the others, and the SVM classifier yielded the best predic-
tions (MCC = 0.812 and AUC = 0.958 for the test set). Then, a perturbation-based model-agnostic method was used 
to interpret our models and analyze the representative features for different models. The application domain analysis 
demonstrated the prediction reliability of our models. Moreover, the important structural fragments related to BCRP 
inhibition were identified by the information gain (IG) method along with the frequency analysis. In conclusion, we 
believe that the classification models developed in this study can be regarded as simple and accurate tools to distin-
guish BCRP inhibitors from non-inhibitors in drug design and discovery pipelines.
Keywords:  Breast cancer resistance protein, Multi-drug resistance, Machine learning, Extreme gradient boosting, 
Ensemble learning, ADMET, Deep learning
© The Author(s) 2020. This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, 
adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and 
the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material 
in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material 
is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the 
permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http://creat​iveco​
mmons​.org/licen​ses/by/4.0/. The Creative Commons Public Domain Dedication waiver (http://creat​iveco​mmons​.org/publi​cdoma​in/
zero/1.0/) applies to the data made available in this article, unless otherwise stated in a credit line to the data.
Introduction
The breast cancer resistance protein (BCRP/ABCG2) 
is the second member of the G subfamily of the ATP-
binding cassette (ABC) transporter superfamily. It is 
widely distributed and expressed in many normal tissues, 
especially the small intestine, liver, brain endothelium, 
and placenta [1]. BCRP functions as a xenobiotic efflux 
pump by exporting antineoplastic drugs out of cells, such 
as topotecan and mitoxantrone, and its overexpression 
or activation results in multi-drug resistance (MDR) to 
many chemotherapeutic agents [2–4]. It is also a vital 
constituent part of blood–tissue barriers and is closely 
involved in absorption blocking and excretion enhancing. 
Therefore, BCRP has been recognized as an important 
Open Access
Journal of Cheminformatics
*Correspondence:  oriental‑cds@163.com; tingjunhou@zju.edu.cn
1 Hangzhou Institute of Innovative Medicine, College of Pharmaceutical 
Sciences, Zhejiang University, Hangzhou 310058, Zhejiang, People’s 
Republic of China
2 Xiangya School of Pharmaceutical Sciences, Central South University, 
Changsha 410004, Hunan, People’s Republic of China

## Page 2 (Section: ADMET evaluation in drug discovery. 20. Prediction of breast cancer resistance protein inhibition through machine learning)

Page 2 of 26
Jiang et al. J Cheminform           (2020) 12:16 
player in drug absorption, distribution, metabolism, 
excretion, and toxicity (ADMET) [5, 6], and has also been 
regarded by the Food and Drug Administration (FDA) as 
one of the key drug transporters in clinical drug disposi-
tion [4, 7].
Many drugs, such as mitoxantrone and topotecan, 
have been identified as BCRP substrates [3, 8], and BCRP 
inhibitors can enhance the bioavailability of these drugs 
[9, 10]. For instance, the co-administration of topotecan 
(an anti-cancer drug) and GF120918 (a BCRP inhibitor) 
resulted in a significant increase of the systemic expo-
sure of topotecan [9]. Gefitinib, a potent BCRP inhibitor, 
could considerably improve the bioavailability of irinote-
can in mice [10]. Therefore, the discovery of novel BCRP 
inhibitors can contribute to the design of better thera-
peutic strategies for cancer treatment and identification 
of potential drug–drug interactions [11]. Many experi-
mental techniques have been employed to measure the 
BCRP inhibition of drugs or drug candidates, but these 
assays are expensive, resource-intensive, and time-con-
suming. Thus, it is of critical importance to develop in 
silico models to predict BCRP inhibition in the process of 
drug design and discovery in order to reduce the failure 
rates and avoid adverse drug–drug interactions.
Quantitative structure–activity relationship (QSAR) 
analysis is one of the most classical techniques in the 
realm of computer-aided drug design (CADD) to cor-
relate the chemical structures of molecules with their 
bioactivities. To date, numerous computational QSAR 
models based on various machine learning (ML) 
approaches and pharmacophore modeling have been pro-
posed to predict BCRP inhibition [12–22] For example, 
in 2005, based on a dataset of 25 flavonoids, Zhang et al. 
[15] built a multiple linear regression model to quantita-
tively predict the BCRP inhibition of flavonoids. In 2007, 
Matsson and co-workers used the orthogonal partial 
least-squares projection to latent structures discriminant 
analysis (OPLS-DA) to construct a classification model 
to differentiate BCRP inhibitors from non-inhibitors 
with predictive accuracies of 93% and 79% for the train-
ing and test sets, respectively [16]. It is surprising that 
an easily interpretable model could be established based 
on only two descriptors: octanol–water partition coef-
ficient at pH 7.4 and molecular polarizability. In 2013, 
Pan et al. generated the Bayesian classification and phar-
macophore models based on a training set of 124 BCRP 
inhibitors and non-inhibitors, and the best Bayesian clas-
sification model achieved a Matthews correlation coeffi-
cient (MCC) of 0.69 for the test set with 79 compounds 
and the best pharmacophore model yielded a MCC of 
0.29 for the same test set [11]. In 2014, based on a large 
dataset containing 780 diverse compounds, Montanari 
et al. also used the naïve Bayesian approach to establish 
a model with an encouraging global accuracy of 0.92 but 
a relatively low AUC (the area under the receiver oper-
ating characteristic curve) value of 0.854 for the training 
set under tenfold cross-validation. In addition, this model 
was not validated by a test set [20]. In 2015, based on a 
training set of 197 compounds, Belekar et al. developed 
a number of models to distinguish BCRP inhibitors from 
non-inhibitors by using support vector machine (SVM), 
k-nearest neighbor (k-NN), and artificial neural net-
works (ANN), and the models achieved global accuracies 
of 0.828–0.878 for the test set with 99 compounds and 
0.745–0.775 for the validation set with 99 compounds 
[21]. Recently, Montanari et  al. developed a computa-
tional model to qualitatively predict BCRP inhibition by 
using logistic regression (LR) based on a relatively large 
dataset with 978 compounds [22], and the tenfold cross-
validation of the LR model for the training set yielded 
a MCC of 0.65 and an AUC of 0.90. Apparently, most 
reported computational models for differentiating BCRP 
inhibitors from non-inhibitors were developed based on 
relatively small datasets (less than 1000 compounds) or 
congeneric compounds and suffered from relatively low 
accuracy. As a result, the reliability and general applica-
bility of the developed models may be limited. Therefore, 
it is an urgent need to develop computational models 
with high reliability and robustness to predict BCRP inhi-
bition based on an extensive dataset.
Recently, new artificial intelligence (AI) methods, 
such as ensemble learning represented by extreme gra-
dient boosting (XGBoost) and deep learning (DL) rep-
resented by deep neural networks (DNN), have been 
widely employed in CADD, such as drug-target inter-
actions prediction [23], cancer diagnosis [24], ADMET 
predictions and QSAR modeling [25–33]. DL is a cat-
egorization of artificial neural networks-based (ANN-
based) ML methods that gradually extract features from 
the raw input using multiple layers. The application of DL 
in drug discovery was hindered by computability, but it 
can be well alleviated by using graphics processing units 
(GPUs) acceleration [34]. Ensemble learning represented 
by XGBoost attracted the attention of researchers in drug 
discovery due to its accurate predictions and low com-
putational cost, and some studies reported that XGBoost 
could achieve comparative or even better performance 
than other widely-used ML methods such as RF and 
DNN [31]. Thus, it is a recognized need to explore how 
well those state-of-the-art methods perform in the pre-
diction of BCRP inhibition. In this study, we reported a 
large and structurally diverse dataset with 1098 BCRP 
inhibitors and 1701 non-inhibitors. Then, based on the 
extensive dataset, the classification models to discrimi-
nate between  BCRP inhibitors and non-inhibitors were 
developed by using seven ML approaches, including a

## Page 3 (Section: Materials and methods)

Page 3 of 26
Jiang et al. J Cheminform           (2020) 12:16 
	
representative DL method: DNN, two representative 
ensemble learning methods: stochastic gradient boosting 
(SGB) and XGBoost, and four traditional ML methods: 
naive Bayes (NB), k-NN, regularized logistic regression 
(RLR), and SVM. The optimal feature subset used in 
model development was determined by a wrapper fea-
ture selection method that couples simulated annealing 
(SA) algorithm and random forest (RF) and the hyper-
parameters were determined by the Bayesian optimiza-
tion technique. To our knowledge, there are relatively 
few studies devoted to using new AI methods, such as 
ensemble learning and deep learning, to the prediction 
of BCRP inhibition. The robustness and reliability of the 
models were validated internally and externally, and the 
statistical results demonstrated that one traditional ML 
method (SVM) and two new ML methods (DNN and 
XGBoost) could generate reliable classification mod-
els for the prediction of BCRP inhibition, and the SVM 
model achieved the best predictions. The identification 
and analyses of representative features for different mod-
els were accomplished through a perturbation-based 
method. Furthermore, the important structural frag-
ments related to BCRP inhibition were recognized by the 
information gain method along with the frequency anal-
ysis, which may provide valuable clues for the design of 
potent BCRP inhibitors and avoiding undesirable drug–
drug interactions.
Materials and methods
Dataset preparation
In this study, three data sources were integrated to build 
up an extensive BCRP inhibition dataset. The first data 
source is the dataset of 978 compounds reported by 
Montanari et al. [20], and it contains 433 inhibitors and 
545 non-inhibitors. The second data source that has 765 
BCRP inhibitors and 220 non-inhibitors were manu-
ally collected from 51 literatures [22, 35–84]. However, 
considering the fact that BCRP non-inhibitors should be 
much more than inhibitors, the third data source con-
taining 1000 non-inhibitors was also integrated into the 
final dataset. The 1000 non-inhibitors were extracted 
from the PubChem database (PubChem AID: 1325), 
and they have the lowest efflux pump activity, which was 
defined as “% inhibition of efflux pump activity”. Accord-
ing to the authors’ statement, compounds with percent-
age inhibition lower than 80% were decisively inactive. 
The molecules from the above three data sources were 
integrated into a single dataset and the duplicated mol-
ecules with incoherent labels were removed. Then, the 
salts, mixtures, and metal–organic compounds were 
eliminated using the wash tool in the Molecular Oper-
ating Environment (MOE) software package (version 
2015), and then all the compounds were minimized with 
the MMFF94 force field [85]. The final dataset contains 
1098 BCRP inhibitors and 1701 BCRP non-inhibitors. 
The whole dataset can be accessed from Additional file 1: 
Table S1 or the supporting website: http://cadd.zju.edu.
cn/pkkb/. As far as we know, the dataset reported in this 
study is the largest one of its kind available to the public. 
The BCRP inhibitors were labeled as 1 and non-inhibi-
tors were labeled as 0.
Generation of molecular descriptors and fingerprints
A total of 379 molecular descriptors, which characterize 
the physicochemical, structural and drug-like proper-
ties of the studied compounds, were calculated using the 
MOE 2015 as the molecular features. According to many 
previous studies, the addition of molecular fingerprints 
can improve the performance of QSAR modeling [86–
88]. Therefore, the PubChem fingerprints (PubchemFP) 
with 881 substructures generated by PaDEL-Descriptor 
[89], which characterize 2-dimensional substructures in a 
binary format, were also used as molecular features. The 
molecular features with missing values were removed. 
Then, the features that have one unique value (i.e., zero-
variance features) or features have very few unique val-
ues relative to the number of compounds or features have 
a large frequency gap between the most common value 
and the second most common value were removed by 
the nearZeroVar function in the caret package of R (ver-
sion 3.5.3 ×64). In addition, the correlation between any 
two features was calculated and the feature that has high 
correlation (r > 0.90) with another feature was removed. 
After this step, 382 molecular features were retained and 
the whole dataset was randomly divided into the training 
and test sets with a ratio of 4:1 using a stratified sampling 
method. As a result, the training set contains 2240 com-
pounds (879 inhibitors and 1361 non-inhibitors), and the 
test set contains 559 compounds (219 inhibitors and 340 
non-inhibitors).
Feature selection by rfSA
All the calculated molecular features cannot be used for 
the QSAR modeling due to the curse of dimension for 
high-dimensional data and the phenomenon of over-
fitting. Therefore, a wrapper feature selection method 
named rfSA (SA algorithm coupled with RF) was used 
to remove redundant or irrelevant features without sac-
rificing too much information based on the training set. 
The SA algorithm is used to search the feature subset 
from the origin feature space and the performance of the 
RF model developed from the selected feature subset is 
used to guide the search. As a common method for com-
binatorial optimization problems, SA has good capabil-
ity to avoid being trapped into local minima [90]. In the 
feature subset search process, the RF model developed

## Page 4 (Section: QSAR model construction and hyper-parameters optimization)

Page 4 of 26
Jiang et al. J Cheminform           (2020) 12:16 
from a new feature subset selected by the SA algorithm is 
compared with that developed from the previous feature 
subset identified in the previous step according to the RF 
model performance (e.g. accuracy of RF model). If the 
new feature subset performs better, it would be accepted, 
otherwise acceptance probability is calculated based 
on the accuracy difference between the two RF models 
developed from the two feature subsets and the current 
iteration of the search. This process is repeated until the 
stopping criteria are satisfied. The rfSA was implemented 
using a built-in safs function in the caret package of R 
(version 3.5.3 ×64). Here, the resample method was set 
as fivefold cross-validation with five repetitions to guar-
antee the statistical significance, where four-fifth of the 
training set (internal set) was used in the feature sub-
set search conducted by SA and the remaining one-fifth 
(external set) was used to estimate the external accuracy. 
The best iteration of SA was determined by maximizing 
the external accuracy. The maximum iterations of the SA 
optimization were set to 1000. More descriptions about 
the feature selection process can be found in the docu-
mentations [91, 92].
QSAR model construction and hyper‑parameters 
optimization
Here, seven ML methods were employed to develop 
the classification models to discriminate BCRP inhibi-
tors and non-inhibitors, including a representative DL 
method (DNN), two representative ensemble learning 
methods (SGB and XGBoost), and four traditional ML 
methods (NB, k-NN, RLR and SVM). The DNN method 
was implemented in the h2o package of R (version 3.5.3 
×64), and the other six ML methods were implemented 
in the caret package of R (version 3.5.3 ×64). The caret 
package provides miscellaneous functions for build-
ing classification and regression models and focuses on 
simplifying model training at the same time. The whole 
QSAR modeling pipeline is presented in Fig.  1.  The 
source code that implements the workflow is available in 
the supplementary information (Additional file 2).
Naive Bayes (NB)
The NB algorithm is a simple and interpretable proba-
bilistic classification method, and it estimates the corre-
sponding class probability for an instance represented by 
conditionally independent feature variables based on the 
Bayes’ theorem. Despite the simple theorem and over-
simplified assumptions, NB has been extensively used in 
classification and achieved outstanding performance in 
many intricate real-world situations, such as text classifi-
cation. In addition, NB is fast and efficient for large data-
sets, and it is less affected by “curse of dimensionality” 
when a large number of descriptors are used [93]. The 
detailed descriptions of the NB algorithm were docu-
mented previously [88].
k‑Nearest neighbors (k‑NN)
The k-NN algorithm is a commonly used non-para-
metric supervised learning approach for classification 
and regression [94]. The principle of this algorithm is to 
find the k closest training instances when a test instance 
is given and this test instance is predicted based on the 
information of the closest training instances. In our 
study, the “weighted voting method” was employed, 
Fig. 1  The workflow of QSAR modeling

## Page 5 (Section: Regularized logistic regression (RLR))

Page 5 of 26
Jiang et al. J Cheminform           (2020) 12:16 
	
which weights the contributions of the k closest instances 
using a distance weighting function, where the closest 
instance contributes most to the voting and the furthest 
instance contributes least.
Regularized logistic regression (RLR)
As an efficient and simple classification methods, the 
logistic regression (LR) algorithm uses the logistic func-
tion as the link function of generalized linear model [22, 
95]. It is suited for conducting regression analysis where 
the response variable is binary. Different from con-
ventional linear regression which fits a straight line or 
hyperplane, LR converts the output of a linear regression 
model to values between 0 and 1 using a logistic function. 
In this study, a regularization term by penalizing high 
values of the optimized parameters was introduced into 
the cost function of the LR algorithm to prevent over-fit-
ting, which is the so-called regularized logistic regression 
(RLR).
Support vector machine (SVM)
Support vector machine is one of the most popular 
ML approaches in QSAR modeling. It is appropriate to 
develop the classification models for complex but small- 
or medium-sized datasets. The fundamental principle of 
SVM is to find a separating hyper-plane with maximum 
margin in the feature space for classifying instances of 
different categories, and the classification results pro-
duced by this hyper-plane should be insusceptible to 
local perturbations of training instances. In this study, 
the radial basis function (RBF) was used as the kernel.
Ensemble learning
Ensemble learning is a group of popular algorithms that 
can produce a strong learner in the form of an ensem-
ble of weak learners. Gradient boosting is one of the 
most representative ensemble learning methods and it 
improves the strong learner gradually through fitting the 
new weak learner to residuals: an approximation of the 
negative gradient of the loss function being minimized. 
Here two gradient boosting-based methods, SGB and 
XGBoost, were employed to build the classification mod-
els. In SGB, a subsample of the training data is selected 
randomly to fit the new weak learner and update the 
strong learner for the current iteration, and this ran-
domized approach increases both the approximation 
accuracy and execution speed of gradient boosting [96]. 
In XGBoost, some optimization algorithms are intro-
duced based on the gradient boosting framework, such 
as minor improvements in the loss function by penalizing 
the complexity of the model, introduction of shrinkage 
and column subsampling for further preventing over-
fitting, and employment of sparsity-aware split finding 
technique for efficient training on sparse data, etc. The 
significant predictive power of XGBoost on QSAR mod-
eling has been illustrated in previous studies [29, 31].
Deep neural networks (DNN)
Deep learning has revolutionized many applications such 
as natural language processing, computer vision, and 
speech recognition due to its capability to learn com-
plicated and rapidly-varying non-linear functions and 
extract a hierarchy of useful features from input [97]. 
DNN is one of the typical DL models which have an 
input layer, an output layer, and many hidden layers (typi-
cally more than three hidden layers). It is inspired from 
biological neurons networks and the basic component in 
DNN is the neuron model. In 2012, Merck sponsored a 
molecular activity challenge at the Kaggle data mining 
platform, and the competition was won by a group that 
utilized DNN as the main ML technique [25]. In addi-
tion, the Tox21 data challenge 2014 for toxicity assess-
ment was won by a group that also utilized DNN as the 
main ML technique [26]. In DNN, each neuron receives 
the input signals from its connected neurons, and those 
input signals are multiplied by their respective weights 
and then summed up. The weighted sum plus the bias 
in each neuron to feed into the activation function and 
produce an output. Here the weights and biases in each 
neuron are the parameters in DNN and they are typically 
learned by error back-propagation algorithm in combi-
nation with optimization method such as stochastic gra-
dient descent. It is commonly known that DNN learns 
to pick up important features from the original feature 
space by down-weighing irrelevant features. However, 
for the sake of fairness, DNN was trained based on the 
selected features from the training set although it seems 
redundant or not necessary.
Model hyper‑parameters optimization
The performance of the models developed by ML 
approaches are closely related to important hyper-param-
eters. In this study, the hyper-parameters were optimized 
by the Bayesian optimization (aka model-based optimi-
zation) algorithm based on the MCC value of the fivefold 
cross-validation to the training set [98]. As a compelling 
global optimization method for black-box functions, the 
Bayesian optimization framework can obtain an ideal 
solution only after a few objective function evaluations 
by designing appropriate surrogate model and acquisi-
tion function. Before Bayesian optimization, a coarse 
hyper-parameter tuning based on grid search within rela-
tively wide ranges was performed to determine a smaller

## Page 6 (Section: Statistical validation of the QSAR models)

Page 6 of 26
Jiang et al. J Cheminform           (2020) 12:16 
region of hyper-parameters where the models work well. 
The Bayesian optimization was then used to zoom into 
these smaller regions and find more optimal settings of 
hyper-parameters. The Bayesian optimization algorithm 
was implemented by the mlrMBO package in R (version 
3.5.3 ×64). The search space of the Bayesian optimiza-
tion and the optimal hyper-parameters for all the stud-
ied models are summarized in Additional file 1: Table S2. 
It should be noted that some other important hyper-
parameters of the DNN model were fixed in our study. 
Here, the optimizer of the DNN modeling was set to an 
adaptive learning rate algorithm: ADADELTA, and the 
activation function was set to ReLU which is highly rec-
ommended for DNN according to the previous studies 
[25, 99]. All the tested DNN configurations were trained 
for 300 epochs.
Statistical validation of the QSAR models
According to the Organization for Economic Co-opera-
tion and Development (OECD) Validation Principle [4, 
100], a QSAR model should be associated with appropri-
ate measures of goodness-of-fit, robustness, and predic-
tivity. Here, the random fivefold cross-validation of the 
training set was used to evaluate the robustness of each 
model, and the external validation given by the predic-
tions to the test set was used to measure the actual pre-
dictivity of each model. In addition to the random fivefold 
cross-validation, the performance of the seven studied 
ML algorithms was also evaluated by the cluster cross-
validation method proposed by Mayr et  al. [101, 102]. 
The agglomerative hierarchical clustering using complete 
linkage was used to identify different compound clusters. 
The distance between any two compounds was measured 
by the Tanimoto similarity based on the PubChem fin-
gerprints. The maximum distance between any identified 
clusters was set to 0.7 and the generated smaller com-
pound clusters were distributed across the fivefolds ran-
domly. The following statistical parameters based on the 
confusion matrix were used to assess the performance of 
each model: confusion matrix [true positives (TP), true 
negatives (TN), false positives (FP), false negatives (FN)], 
global accuracy (GA), balanced accuracy (BA), Matthews 
correlation coefficient (MCC), and the area under the 
receiver operating characteristic (ROC) curve (AUC). 
The GA, BA and MCC are defined as following:
(1)
GA =
TP + TN
TP + TN + FP + FN
(2)
BA = 0.5 ×

TP
TP + FN +
TN
TN + FP

Moreover, the residual (the binary cross entropy was 
used as the residual function in this study) distribution 
plots for the fivefold cross-validated training set and 
the test set were used to further diagnose the quality of 
the classification models. Different from the confusion 
matrix based statistical parameters which only supports 
the predicted class of a compound, it is capable of pro-
viding information about the predicted class probability 
distribution of a compound. For example, for an inhibi-
tor: I [the class probability distribution is (0,1)] and a 
non-inhibitor: NI [the class probability distribution is 
(1,0)], the predictions (class probability) for I and NI 
given by model A are (0.4, 0.6) and (0.65, 0.35), respec-
tively and those given by model B are (0.1, 0.9) and (0.95, 
0.05), respectively. Both models give the same confusion 
matrix and the statistical parameters would be identical 
[for the majority of ML approaches, the class of a certain 
compound was derived from its class probability distri-
bution. If the probability for a certain class is larger than 
or equal to a certain threshold (generally 0.5), this com-
pound would be predicted as the corresponding class], 
which model should be used in this case? Actually, we 
still believe that model B is better than model A because 
the residual to the referenced class probability distribu-
tion of model B is smaller than that of model A. In this 
study, the binary cross entropy was used as the residual 
function, which was defined as:
where y is the true class label of compound (1 for inhibi-
tor and 0 for non-inhibitor); p is the probability of being 
inhibitor for a compound and the greater the binary cross 
entropy is, the larger the residual is, and vice versa.
Definition of application domain (AD)
Defining AD is an important step for QSAR modeling 
in the OECD guidelines because a developed model 
can only be expected to give reliable predictions for 
query chemicals that fall within the AD [100]. In this 
study, the non-parametric probability density distribu-
tion-based method was applied to identify the AD of 
a QSAR model. This method estimates the probability 
density function for the given data and it can be mainly 
classified into two categories: parametric and non-par-
ametric approaches. Parametric approaches assume 
the data distribution follows a standard distribution, 
such as Gaussian or Poisson distribution. Non-para-
metric approaches do not make any assumptions about 
(3)
MCC =
TP × TN −FN × FP
√(TP + FN)(TP + FP)(FN + TN)(TN + FP).
(4)
CEbinary = −

y × log (p) +

1 −y

× log (1 −p)

## Page 7 (Section: Interpretation of QSAR models)

Page 7 of 26
Jiang et al. J Cheminform           (2020) 12:16 
	
the data distribution and they can estimate the prob-
ability density solely from data [103, 104]. An advan-
tage of non-parametric approaches is that they can 
identify internal empty spaces, and it has been argued 
that they are more accurate and appropriate than other 
common approaches, such as the range, distance and 
leverage approaches [103]. More details of the prob-
ability density distribution-based method have been 
documented in literature [103, 104]. The AD analysis 
was conducted by the AMBIT Discovery software (ver-
sion 0.04) [105].
Interpretation of QSAR models
Identification and analysis of important features may 
contribute to a better understanding of QSAR models 
and provide new domain knowledge. Here the agnostic 
feature importance assessment algorithm, a perturba-
tion-based method, was employed to identify the most 
important features for different well-performing QSAR 
models. This algorithm is model agnostic and not rel-
evant to the specific structure of a model. A couple 
of previous studies only identified and analyzed the 
important features given by feature selection proce-
dure for QSAR models [21, 29, 106] but did not explore 
the relationships between features and different QSAR 
models. It is quite possible that a set of important 
descriptors/fingerprints for a well-performing QSAR 
model may be not important to another QSAR model. 
In view of that, this perturbation-based model-agnos-
tic method was used to recognize important features 
for different well-performing QSAR models and fur-
ther compare the important features between models 
for interpreting how different QSAR models handle 
particular features. The basic principle of this method 
is to evaluate how much the model performance is 
gone from the performance of the original model 
after the selected feature is perturbed or resampled. 
The more the model performance is gone, the more 
important the feature is, and vice versa. In a more spe-
cific way, L = L

Y , f (X)

 denotes the loss function of 
a model where Y is the observations for all instances 
and f (X) is the predictions of all instances. The flow-
ing steps were conducted for each single feature vi in 
the V : first, a perturbed data X∗,−i with feature vi per-
turbed or resampled was generated; second, the model 
predictions f

X∗,−i
 on the perturbed data were cal-
culated; then, the loss function L∗,−i = L

Y , f

X∗,−i
 
on the perturbed data was obtained; finally, the feature 
importance of vi is measured as the difference or ratio 
of the original loss L and loss on perturbed data L∗,−i 
[107, 108]. Here, the binary cross entropy was used as 
the loss function, and the identification and analysis 
procedure was implemented in the DALEX package 
of R (version 3.5.3 ×64). In addition, the analysis for 
each single feature was repeated 10 times to guaran-
tee the repeatability of results due to the perturbation 
randomness and the importance score was obtained by 
averaging the results of the 10 times repetitions.
Analysis of important fragments to characterize BCRP 
inhibitors and non‑inhibitors
In order to better understand important chemical features 
related to BCRP inhibition, each compound was decom-
posed into three structural fragments and analyzed. The 
generated structural fragments include contiguous ring 
systems (Ring Assemblies), contiguous ring systems that 
share two or more bonds (Bridge Assemblies), and con-
tiguous ring systems plus chains that link two or more 
rings (BemisMurcko Assemblies). The details of these 
three structural fragments can be found in previous stud-
ies [109]. The structural fragments for all the compounds 
were generated using the Generate Fragments component 
in Pipeline Pilot 2017, and the Merge Molecules component 
was then used to merge records containing identical frag-
ments into a single record for the next statistical analysis.
The important fragments that have large contributions 
to BCRP inhibitors or non-inhibitors were identified by 
the information gain (IG) method coupled with frequency 
analysis [110, 111]. The IG value of a fragment was used to 
measure its importance to the classification system, and the 
fragments with low IG values are less effective in a classifi-
cation system and vice versa. In this study, the IG value of a 
fragment was calculated as followings:
where V represents the possible value of a fragment (0 
or 1); 0 represents the fragment is absent in a compound 
and 1 represents the fragment is present in a compound. 
N denotes the total number of compounds; N v is the 
number of compounds where the fragment is present or 
absent. Ent(D) and Ent

Dv
 represent the information 
entropy and conditional entropy of all the compounds, 
respectively, and both of them were calculated by Eq. 6, 
where K represents the classes of the compounds (1 rep-
resents inhibitors and 0 represents non-inhibitors), and 
pk is the ratio of each class compounds. The frequency of 
a fragment was defined as:
(5)
IG

fragment

= Ent(D) −
V

v=0
N v
N × Ent

Dv
(6)
Ent(D) = −
K

k=0
pk × log2 pk

## Page 8 (Section: Results and discussion)

Page 8 of 26
Jiang et al. J Cheminform           (2020) 12:16 
where Nfragment_class is the number of compounds con-
taining the fragment in each class; Ntotal is the total 
number of compounds; Nfragment_total is the total num-
ber of compounds containing the fragment; Nclass is the 
number of compounds in each class. If the occurrence 
of a fragment is more frequent in inhibitors than in non-
inhibitors, this fragment was considered as an important 
fragment for the inhibitors and vice versa.
Results and discussion
Dataset collection
Except 978 BCRP inhibitors and non-inhibitors reported 
by Montanari et  al. [20] and 1000 non-inhibitors 
extracted from the PubChem database (PubChem AID: 
1325), 985 BCRP inhibitors and non-inhibitors collected 
manually from 51 publications were integrated into the 
whole BCRP inhibition dataset. The basic information 
of the compounds in these 51 publications, including 
compound name, compound structure, activity source, 
activity index, and reported value, were collected manu-
ally and stored into a Molecular Operating Environment 
(MOE) database. The reported inhibition activity index is 
represented by ­IC50, ­EC50, %inhibition at a given concen-
tration, or substrate fold-increase, etc. The experimental 
assays to determine the BCRP inhibition activity can be 
roughly categorized into two types: (1) fluorescent or 
radioactivity substrate intracellular accumulation assay 
and (2) membrane vesicular transport assay. In the fluo-
rescent or radioactivity substrate intracellular accumula-
tion assay, cells overexpressing BCRP are incubated with 
both fluorescent or radiolabeled substrate (pheophorbide 
A, mitoxantrone, BODIPY-prazosin, or Hoechst 33342) 
and the tested compound [52], and the quantity of fluo-
rescence or radioactivity accumulation was measured 
and it is related to the inhibitory effect of the tested com-
pound. The membrane vesicular transport assay employs 
inside-out-oriented membrane vesicles, prepared from 
cells expressing BCRP, to measure the influx of radioac-
tive substrate such as 3H-methotrexate [19], and it can 
be used as an indirect (inhibition-type) way to determine 
the inhibitory effect of a tested compound [112].
Because the inhomogeneity of the experimental data, 
we used the following rules to convert the reported val-
ues into the inhibitor and non-inhibitor classes. First, 
the suggestions recommended by the authors were used 
to assign the possible classification threshold or the 
compound category. It should be noted that the sugges-
tions recommended by the authors may be arbitrary, but 
it is the situation we are facing now. For example, Gros 
(7)
frequency of a fragment = Nfragment_class × Ntotal
Nfragment_total × Nclass
et al. [40] checked if some compounds could inhibit the 
transport activity of BCRP, and the authors found that 
a portion of the studied compounds had no any effect 
on the mitoxantrone efflux and therefore they were not 
inhibitors of BCRP. Naturally, those compounds were 
considered to be non-inhibitors in our study. Elsby et al. 
[36] suggested a rheumatoid arthritis candidate drug 
(AZD9056) was an inhibitor of BCRP based on biologi-
cal activity assay. Similarly, AZD9056 was considered as 
an inhibitor. The study reported by Sjostedt et  al. [73] 
defined compounds that result in normalized transport 
values below 50% as BCRP inhibitors. Second, the ­IC50 
or ­EC50 value was used to categorize a compound. More 
specifically, a compound with ­IC50 or ­EC50 < 10 μM was 
classified as an inhibitor, and a compound with ­IC50 or 
­EC50 > 50 μM was classified as a non-inhibitor, and those 
compounds with ­IC50 or ­EC50 between 10 and 50  μM 
were excluded because the testing results are suscep-
tible to experimental conditions. In addition, for com-
pounds that have multiple reported ­IC50 or ­EC50 values, 
the average values were used to assign inhibitors or 
non-inhibitors. But if the discrepancy between multiple 
values was significant for a compound, such compound 
was excluded. Third, for the activity index: %inhibition 
at a given concentration, only the concentration at l0 μM 
was taken into consideration. A compound with %inhibi-
tion at 10 μM > 50% was classified as an inhibitor, and the 
compound with %inhibition at 10 μM < 25% was classified 
as a non-inhibitor. Similarly, the compounds with %inhi-
bition at 10 μM ranging from 25 to 50% were removed 
from the dataset owing to their susceptibilities to experi-
mental conditions.
Unfortunately, some compounds still could not be cat-
egorized after this step. For those compounds, the “out-
come” column of the PubChem database was employed 
to define the compound category. The “outcome” column 
can be one of the following four values, including “Active”, 
“Inactive”, “Inconclusive”, and “Unspecified”, and it is in 
some ways equivalent to the author’s subjective definition 
of what the compound is. In the light of the “outcome” 
column, the compounds with the “Active” label were con-
sidered as inhibitors in our study, and those “Inactive” 
labeled compounds were considered as non-inhibitors. 
Certainly, “Inconclusive” or “Unspecified” labeled com-
pounds were removed.
It should be noted that the inhibitory mechanisms 
of different compounds towards BCRP may vary from 
one to another and the BCRP inhibitors can be approxi-
mately classified into the following three categories: [4] 
(a) compounds are regarded as “general” inhibitors to 
BCRP if they are able to inhibit ATPase activity of BCRP, 
such as the compounds No. 87 (fumitremorgin C) and 
No. 25 (Ko143) in the final dataset; (b) compounds were

## Page 9 (Section: The impact of simple molecular descriptors on BCRP inhibition)

Page 9 of 26
Jiang et al. J Cheminform           (2020) 12:16 
	
considered as competitive inhibitors if they are the sub-
strates of BCRP and capable of competitively binding to 
the substrate site to block the transport of substrates, 
such as the compounds No. 1539 (dipyridamole), No. 
440 (2-(2-methoxyphenyl)-N-(3-nitrophenyl)quinazolin-
4-amine), and No. 259 (2-(3,4-dimethoxyphenyl)-N-(4-
nitrophenyl)quinazolin-4-amine) in the final dataset; 
(c) compounds are not the substrates of BCRP, but they 
can bind to BCRP and induce conformational changes 
to affect the transport function of BCRP, for example, 
the compound No. 1633 (nelfinavir) in the final dataset. 
To better understand the complicated molecular mecha-
nisms of BCRP inhibition, it is highly valuable to develop 
computational classification model for “general” inhibi-
tors and “non-general” inhibitors, respectively. However, 
considering the fact that the inhibitory mechanisms for 
most inhibitors in the final dataset are still not clear, in 
this study, “global” classification models were developed 
to discriminate BCRP inhibitors and BCRP non-inhib-
itors with no consideration of their specific inhibitory 
mechanisms.
The Tanimoto similarity index based on the 881 
PubChem fingerprints was used to evaluate the chemical 
diversity of the final dataset. As shown in Fig. 2, for the 
overwhelming majority of the compounds, the Tanimoto 
similarities between any two of compounds are relatively 
low and the average Tanimoto similarity for the whole 
dataset is 0.464, highlighting the structural diversity of 
the final dataset.
The impact of simple molecular descriptors on BCRP 
inhibition
Various simple molecular descriptors have been used 
extensively in ADMET prediction and proven to be help-
ful [86], and they can characterize molecular properties 
from different aspects, such as hydrophobicity, flexibility, 
H-bonding ability, etc. It is interesting to analyze whether 
BCRP inhibitors and non-inhibitors can be distinguished 
by any of those molecular descriptors. Thus, we system-
atically explored the discrimination capability of eight 
molecular descriptors on BCRP inhibition. The examined 
descriptors include octanol–water partition coefficient 
(SlogP), aqueous solubility (logS), H-bond acceptor count 
(a_acc), H-bond donor count (a_don), flexible rotatable 
bond count (b_rotN), molecular flexibility index (Kier-
Flex), aromatic atom count (a_aro), and aromatic bond 
count (b_aro). A non-parametric test method, known 
as Mann–Whitney U-test, was used to assess the sig-
nificance of the difference between the means for inhibi-
tors and non-inhibitors. Compared with Student’s t-test, 
Mann–Whitney U-test gains a competitive advantage 
because it does not require the assumption of normal dis-
tributions for the dataset. The distributions of these eight 
descriptors for the BCRP inhibitors and non-inhibitors 
are shown in Fig.  3. Besides, the means and associated 
p-values of the eight descriptors between the inhibitors 
and non-inhibitors are listed in Table 1. 
In the eight studied descriptors, both SlogP and logS 
are related to the hydrophobicity and solubility of a mol-
ecule. As shown in Table 1, the mean values of SlogP for 
the inhibitors versus non-inhibitors are 4.26 and 3.29, 
respectively, and those of logS for the inhibitors versus 
non-inhibitors are − 6.07 and − 5.25, respectively. In 
other words, BCRP inhibitors are more hydrophobic and 
less soluble than non-inhibitors, which is consistent with 
the finding that the pharmacophore models for BCRP 
inhibitors contain hydrophobic features reported in the 
previous studies [11, 113]. By investigating the molecu-
lar descriptors that determine the interaction between 
BCRP and its inhibitors, Matsson et  al. found that 
octanol–water partition coefficient at pH 7.4 ­(logD7.4) is 
an influential descriptor for the binding of inhibitors to 
BCRP [16]. The p-value for SlogP is 2.16 × 10−50 at the 
95% confidence level, suggesting that the SlogP distribu-
tions for the inhibitors and non-inhibitors are remarkably 
different. Compared with the p-value for SlogP, that for 
logS is relatively higher (4.63 × 10−27 ).
As shown in Fig.  3 and Table  1, we can observe that 
the two H-bond features, a_acc and a_don, demonstrate 
relatively high impact on BCRP inhibition. The mean 
values of a_acc for the inhibitors and non-inhibitors are 
4.10 and 3.70, respectively, and the associated p-value is 
1.32 × 10−9. The mean values of a_don for the inhibitors 
Fig. 2  The chemical diversity of the final dataset evaluated by 
the Tanimoto similarities between any two of the compounds. 
The Tanimoto index was calculated based on the 881 PubChem 
fingerprints

## Page 10 (Section: The impact of simple molecular descriptors on BCRP inhibition)

Page 10 of 26
Jiang et al. J Cheminform           (2020) 12:16 
and non-inhibitors are 1.19 and 1.41, respectively, and 
the associated p-value is 1.12 × 10−8. That is to say, 
BCRP inhibitors tend to contain more H-bond accep-
tors and less H-bond donors than BCRP non-inhibitors. 
This finding was supported by the previous studies that 
H-bond acceptors are quite important for BCRP inhibi-
tion [11, 16, 114].
Fig. 3  Distributions of the eight simple molecular descriptors, including SlogP, logS, a_acc, a_don, b_rotN, KierFlex, a_aro, and b_aro for the BCRP 
inhibitors and non-inhibitors

## Page 11 (Section: Feature selection based on rfSA)

Page 11 of 26
Jiang et al. J Cheminform           (2020) 12:16 
	
The descriptors b_rotN and KierFlex are mainly used to 
describe the flexibility of a molecule. As can be seen from 
Table  1, the mean values of b_rotN for the two classes 
are very close and the associated p-value is 6.38 × 10−1 
at the 95% confidence level, showing that the distribution 
of b_rotN for inhibitors and non-inhibitors is not statisti-
cally significant, and it is the same situation for KierFlex 
but its associated p-value is 3.14 × 10−4 at the 95% con-
fidence level, demonstrating that the difference between 
the two distributions of KierFlex is statistically signifi-
cant. However, as can be seen from Fig. 3 and Table 1, the 
distribution differences of these two properties between 
the two classes are not as significant as some other prop-
erties, such as hydrophobicity-related descriptors. The 
other two descriptors, a_aro and b_aro, are related to the 
aromaticity of a molecule. The mean values of a_aro for 
the inhibitors and non-inhibitors are 17.51 and 13.46, 
respectively, and the mean values of b_aro for the inhibi-
tors and non-inhibitors are 18.01 and 13.73, respectively, 
which indicates that BCRP inhibitors exhibit stronger 
aromaticity than non-inhibitors. Our finding is in good 
agreement with the previous observations that aromatic-
ity is an important molecular feature for BCRP inhibitors 
revealed by the computational model developed by Mats-
son and co-workers [115]. As can be seen from Fig. 3, the 
distributions of these two aromaticity-related descriptors 
differ notably between the two classes, and the associ-
ated p-values are 6.90 × 10−75 and 5.90 × 10−80, respec-
tively, indicating that aromaticity is the best indicator to 
discriminate inhibitors from non-inhibitors. In summary, 
our findings imply that BCRP inhibitors are generally 
more hydrophobic and aromatic than non-inhibitors, 
which are consistent with the results reported by the 
previous studies [16, 73, 115, 116]. However, as shown in 
Fig. 3, for any descriptor, the distributions for the BCRP 
inhibitors and non-inhibitors still overlap largely, sug-
gesting that any single molecular property cannot dis-
criminate between BCRP inhibitors and non-inhibitors 
effectively.
Feature selection based on rfSA
At first, a total of 1260 molecular features, including 379 
molecular descriptors and 881 PubChem fingerprints, 
were calculated for each molecule in the final dataset. 
After eliminating the features with missing values and 
the redundant features, a smaller feature subset contain-
ing 382 molecular features was obtained and normal-
ized. Then, a wrapper feature selection method known 
as rfSA was employed to identify the most representative 
features for QSAR modeling based on the training set. 
As shown in Fig. 4, the mean predictive accuracy of the 
external set in the fivefold cross-validation with five rep-
etitions has reached the maximum at the 873th iteration 
(0.896). Therefore, the best iteration for the SA optimiza-
tion was set to 873, and the SA algorithm at this iteration 
selected 144 features. As mentioned earlier, the selected 
144 features were regarded as the optimal feature subset, 
where includes 65 molecular descriptors and 79 finger-
prints. The detailed descriptions of these representative 
descriptors and fingerprints are listed in Additional file 1: 
Tables S3 and S4.
The chemical space distributions of the training and 
test sets were characterized by the scatter plots of the 
first three principal components derived from the prin-
cipal component analysis (PCA) based on the 144 molec-
ular features. Furthermore, the scattered distributions 
of molecular weight and SlogP [117] were also used to 
determine the chemical space distributions. As shown in 
Fig. 5a–d, the chemical space of the test set roughly falls 
Table 1  The mean values of  eight simple descriptors for  inhibitors and  non-inhibitors and  the  associated p-values 
determined by Mann–Whitney U-test for each descriptor
Class
SlogP
logS
a_acc
a_don
b_rotN
KierFlex
a_aro
b_ar
Inhibitors
4.26
− 6.07
4.10
1.19
6.09
4.36
17.51
18.01
Non-inhibitors
3.29
− 5.25
3.70
1.41
5.88
4.53
13.46
13.73
p-value
2.16 × 10−50
4.63 × 10−27
1.32 × 10−09
1.12 × 10−08
6.38 × 10−01
3.14 × 10−04
6.90 × 10−75
5.90 × 10−80
Fig. 4  The feature selection process of molecular features through 
the rfSA method. Internal: four fifth of the training set in the fivefold 
cross-validation with five repetitions; External: one-fifth of the training 
set in the fivefold cross-validation with five repetitions

## Page 12 (Section: Comparison of various classification models for BCRP inhibition)

Page 12 of 26
Jiang et al. J Cheminform           (2020) 12:16 
within that of the training set, implying that it is feasible 
and reliable to use the test set to validate the prediction 
performance and generalization capability of the QSAR 
models developed from the training set.
Comparison of various classification models for BCRP 
inhibition
Base on the 144 molecular features selected from 
the training set, seven ML methods, including one 
DL method (DNN), two ensemble learning methods 
(XGBoost and SGB) and four traditional ML methods 
(NB, k-NN, RLR, and SVM), were used to develop the 
QSAR models to distinguish BCRP inhibitors from non-
inhibitors. In model development, the Bayesian optimi-
zation technique was employed to determine the optimal 
settings of hyper-parameter for all the methods. The 
statistical results for the random fivefold cross-validated 
training and test sets given by the optimized QSAR mod-
els are summarized in Table 2.
As shown in Table  2, it can be observed that four 
models (i.e., SVM, DNN, XGBoost, and SGB) give sat-
isfactory statistical parameters for both the fivefold 
cross-validated training set and the test set. It is obvi-
ous that they have potential advantage over the other 
three traditional models (i.e., NB, RLR, k-NN) on the 
BCRP inhibition prediction in general. Here, SVM, a 
classical ML method, yields the best predictions for the 
test set when MCC and GA were used as the main crite-
ria for the classification ability of models (MCC = 0.812 
and GA = 0.911). Compared with GA, BA may give a 
more comprehensive consideration on sensitivity and 
specificity and it is capable of avoiding exaggerated 
assessment of model performance on an unbalanced 
Fig. 5  The chemical space distributions based on the principal components analysis (PCA): a The distributions of PC1 and PC2; b The distributions 
of PC1 and PC3; c The distributions of PC2 and PC3. d The chemical space defined by molecular weight as X-axis and SlogP as Y-axis

## Page 13 (Section: Comparison of various classification models for BCRP inhibition)

Page 13 of 26
Jiang et al. J Cheminform           (2020) 12:16 
	
data set. According to BA, the SVM model also gives 
the best prediction (BA = 0.905) on the test set. How-
ever, we found that the other three methods, including 
DNN, XGBoost, and SGB, showed similar performance 
to SVM (Table 2). Therefore, it is difficult to determine 
which model is the best only according to the confusion 
matrix based statistical parameters. In view of that, the 
residual distribution plot was used to further diagnose 
the quality of those four well-performing models (i.e., 
SVM, DNN, XGBoost, and SGB). As shown in Fig.  6, 
the residuals derived from the DNN model are larger 
than those derived from the other three models for 
both the fivefold cross-validated training set and test 
set, implying that the DNN model gives the worst class 
probability estimation for some compounds although it 
may still give correct classification for them. As shown 
in Fig.  6, the residual distribution of the XGBoost 
model is similar to that of the SVM model. However, 
it should be noted that, for those compounds with 
smaller residuals (smaller than 0.7), the DNN model 
Table 2  Statistical results of the seven classification models based on 144 molecular features for the training (random 
fivefold cross-validation) and test sets
NA not available
Training set (random fivefold cross-validation)
Test set
GA
BA
MCC
AUC​
GA
BA
MCC
AUC​
SVM
0.902
0.893
0.793
0.947
0.911
0.905
0.812
0.958
DNN
0.894
0.892
0.780
0.950
0.907
0.904
0.806
0.960
XGBoost
0.902
0.894
0.793
0.956
0.891
0.883
0.770
0.957
SGB
0.901
0.894
0.792
0.952
0.886
0.879
0.759
0.958
RLR
0.875
0.872
0.740
0.932
0.873
0.867
0.734
0.936
k-NN
0.863
0.862
0.717
0.913
0.857
0.856
0.705
0.917
NB
0.826
0.834
0.654
0.898
0.780
0.793
0.572
0.888
Consensus1
0.902
0.893
0.793
NA
0.903
0.897
0.797
NA
Consensus2
0.901
0.895
0.793
0.956
0.909
0.903
0.808
0.963
Fig. 6  The residual (binary cross entropy) distribution plots of the a fivefold cross-validated training set and b test set (b) for the four 
well-performing QSAR models (DNN, SGB, XGBoost, and SVM). X axis represents the value of binary cross entropy, and Y axis represents the ratio of 
number of compounds with the residuals higher than a value to the total number of compounds in the training or test set

## Page 14 (Section: Comparison with published models and interpretation of models)

Page 14 of 26
Jiang et al. J Cheminform           (2020) 12:16 
gives the best class probability estimation and the other 
three models show similar performance. In conclusion, 
based on the statistical parameters and residual distri-
butions, SVM, DNN and XGBoost were recommended 
to develop the classification models for BCRP inhibi-
tion, and among them, SVM is the best choice.
Notably, considerable efforts have been dedicated to 
explore the performance of DNN on QSAR modeling 
and many previous studies demonstrated that DNN is 
the best classifier compared with other conventional 
methods such as NB, RF, and SVM [32, 99, 118]. In this 
study, the DNN model is an outstanding but not the best 
classifier for BCRP inhibition prediction. As all we know, 
the DNN method can benefit from big data and is able to 
perform automatic representation learning from original 
feature space without the requirement of feature selec-
tion. In this study, it is possible that the performance of 
DNN was limited by the size of the dataset, the number 
of features used, and even the DNN implementation or 
hardware used. Finally, two consensus models (Consen-
sus1 and Consensus2) were developed by combining 
the outputs from multiple models. Consensus1 is a class 
label consensus model based on the predictions given 
by the SVM, DNN, and XGBoost models, and Consen-
sus2 is a class probability consensus model based on 
the predictions given by the SVM, DNN, and XGBoost 
models. All the contributions from the individual mod-
els were equal, and we could avoid overemphasizing any 
ML approach. As shown in Table 2, the two consensus 
models did not improve the predictivity obviously. How-
ever, the class probability consensus model gives the best 
AUC values for both the fivefold cross-validated training 
set (AUC = 0.956) and test set (AUC = 0.963). It could 
be found that the class probability consensus model is 
slightly better than the class label consensus model.
As described earlier, in addition to the evaluation for 
the random fivefold cross-validated training set, we also 
performed a cluster fivefold cross-validation for the 
training set to check the predictive capacity of the well-
established model for the unseen compounds. A thresh-
old value of 0.7 for complete linkage clustering identified 
213 different compound clusters and the random dis-
tribution of them across fivefolds results in the num-
bers of compounds for different folds are 445, 447, 452, 
442, and 454, respectively. Based on the cluster fivefold 
cross-validated training set, the seven ML methods were 
employed to developed the classification models with 
the same hyper-parameters determined in the random 
fivefold cross-validation and the optimal feature subsets 
determined by rfSA. As shown in Table 3, the four ML 
approaches (i.e., SVM, DNN, XGBoost, and SGB) that 
have better performance for the random fivefold cross-
validated training set also give satisfactory predictions to 
the clustered fivefold cross-validated training set. Moreo-
ver, the SVM model gives the best MCC value of 0.810 
to the cluster fivefold cross-validated training set, illus-
trating that the models developed in this study can also 
be used to predict the compounds with new scaffolds. 
Briefly, the SVM model gives the best predictions to 
both the training and test set. The AD statistical results 
defined by the non-parametric probability density dis-
tribution-based method shown in Table 4 illustrate that 
only 11 compounds are outside the AD. The AD cover-
ages for the training and test sets are 100% and 98%, 
respectively, indicating that the predictions of the test set 
are reliable.
Comparison with published models and interpretation 
of models
In order to further estimate the prediction capacities of 
the built models, the performance of our models was 
compared with those of some models reported in the 
previous studies. As shown in Table 5, a majority of the 
reported classification models for differentiating BCRP 
inhibitors and non-inhibitors were developed using 
conventional ML methods such as NB, k-NN, SVM 
and RF based on relatively small datasets less than 1000 
Table 3  Statistical results of  the  seven classification 
models for the cluster fivefold cross-validated training set
Training set (cluster fivefold cross-validation)
GA
BA
MCC
AUC​
SVM
0.910
0.901
0.810
0.954
DNN
0.905
0.897
0.794
0.949
XGBoost
0.905
0.897
0.800
0.959
SGB
0.901
0.892
0.791
0.956
RLR
0.879
0.876
0.748
0.935
k-NN
0.867
0.863
0.722
0.918
NB
0.819
0.823
0.634
0.896
Table 4  The 
number 
of 
compounds 
that 
are 
inside  and  outside the  AD determined by  the  non-
parametric probability density distribution-based method 
in the training and test sets
a  N1: the number of inhibitors
b  N2: the number of non-inhibitors
Dataset
Inside AD
Outside AD
AD 
coverage 
(%)
N1a
N2b
N1a
N2b
Training set
879
1361
0
0
100
Test set
219
340
1
10
98

## Page 15 (Section: Comparison with published models and interpretation of models)

Page 15 of 26
Jiang et al. J Cheminform           (2020) 12:16 
	
Table 5  The reported classification models for BCRP inhibitors and non-inhibitors
Mean ± st.dev across fivefold CV
TR training set, TE test set, OPLS-DA orthogonal partial least-squares projection to latent structures discriminant analysis, NA not available, GA global accuracy, Y-Rand Y-Randomization test, PLS-DA partial least-squares 
projection to latent structures discriminant analysis, NB Naive Bayes, LOO CV leave-one-out cross-validation, AUC​ the area under the receiver operating characteristic curve, MCC Matthews correlation coefficient, SVM 
support vector machine, k-NN k-nearest neighbors, RF random forest, CV cross-validation, BA balanced accuracy, ANN artificial neural networks, GTM generative topographic mapping, LR logistic regression
There are many models developed based on different methods or descriptors, and we only extracted the best statistical results for the test set or cross-validation
a  The exact values are not available in the publication
Year
Data size Data set
Method
Descriptors
Model validation
Statistical results
Refs.
Training Test
2007 123
80
43
OPLS-DA
Descriptors from SELMA 
software package
Y-rand
GATE = 0.79
Matsson et al. [16]
2009 122
83
39
PLS-DA
Descriptors from DragonX 
version 3.0
Y-rand
aNA
Matsson et al. [115]
2013 109
30
79
Pharmacophore modeling
NA
NA
MCCTE = 0.29, ­GATE = 0.66
Pan et al. [11]
2013 203
124
79
NB
ECFP_6, FCFP_6 fingerprints
LOO CV
AUC​TR(LOO CV) = 0.795, 
­MCCTE = 0.69
Pan et al. [11]
2013 382
382
NA
SVM, k-NN, RF, and consen-
sus modeling
Dragon, MOE descriptors
Fivefold CV, Y-rand
BATR(fivefold cv) = 0.83 ± 0.04 
(Consensus)
Sedykh et al. [121]
2014 275
96
Test: 32, external set: 147 ensembles of ANN, ensem-
bles of SVM
Descriptors from ADMET 
Modeler
NA
GATE = 0.87, ­GAExternal = 0.67 
(ensembles of ANN)
Eric et al. [122]
2014 780
780
NA
NB
ECFP_6 fingerprints
Tenfold CV
GATR(tenfold CV) = 0.919, AUC​
TR(tenfold cv) = 0.854
Montanari et al. [20]
2015 394
197
Test: 99, external set: 98
SVM, k-NN, ANN, and Con-
sensus Modeling
Dragon descriptors
NA
GATE = 0.878, ­MCCTE = 0.73; 
­GAExternal = 0.745, 
­MCCExternal = 0.46 (ANN)
Belekar et al. [21]
2016
aNA
NA
NA
GTM-kNNd, GTM-Bayes, RF, 
SVM, and k-NN
MOE descriptors
Fivefold CV with five repeti-
tions
NA
Gimadiev et al. [123]
2017 978
978
NA
NB, LR, SVM, and RF
MACCS, Morgan, ECFP8 
fingerprints, VolSurf 
descriptors
Tenfold CV, leave-sources-
out validation
MCCTR(tenfold CV) = 0.65, AUC​
TR(tenfold CV) = 0.90 (LR)
Montanari et al. [22]
2019 2799
2240
559
NB, LR, SVM, k-NN, XGBoost, 
SGB, DNN and consensus 
modeling
MOE descriptors and 
Pubchem fingerprints
Fivefold CV
MCCTE = 0.812, AUC​
TE = 0.958, ­GATE = 0.911, 
­BATE = 0.905 (SVM)
This study

## Page 16 (Section: Comparison with published models and interpretation of models)

Page 16 of 26
Jiang et al. J Cheminform           (2020) 12:16 
compounds. The GA values of the published models for 
the test or external set varied from 0.66 to 0.878 and the 
MCC values varied from 0.29 to 0.73. In the reported 
classification models, it seems that the classifier reported 
by Montanari et al. gives the best performance, indicated 
by a GA value of 0.919 for the tenfold cross-validated 
training set. Unfortunately, this classifier gives an unsat-
isfactory AUC value of 0.854 for the tenfold cross-vali-
dated training set and it was not validated by any test set. 
Compared with the published classification models, the 
models developed in this study show better prediction 
capability. The GA and MCC values given by the SVM 
model for the test set are 0.911 and 0.812, respectively, 
and the AUC value given by the Consensus2 model is 
0.963.
Model interpretation is a recommended procedure 
during QSAR modeling in the OECD principles [100]. 
Here a perturbation-based model-agnostic method was 
employed to identify and analyze the important features 
for the SVM, DNN, XGBoost and SGB models. The top 
ten descriptors for each model are shown in Fig. 7. It can 
be observed that the DNN model has the highest aver-
age binary cross entropy for the test set (0.476), and the 
SVM model has the lowest value (0.249). Those results 
are in good agreement with the observed residual dis-
tributions shown in Fig. 6 that the residual distribution 
curve of the DNN model is the highest, to some extent, 
among the four curves and that of the SVM model is 
the lowest. Another interesting finding is that different 
important features were identified for different models, 
indicating that different methods handle the features in 
a very varying ways and it potentially depends on the 
basic principle of approach. Besides, it is quite possi-
ble that a set of important descriptors/fingerprints for a 
well-performing model may be not suitable for another 
model.
However, we found that some descriptors/finger-
prints related to molecular lipophilicity (BCUT_
SLOGP_2, 
GCUT_SLOGP_0, 
and 
SlogP_VSA5), 
molecular surface area, volume and shape (std_dim2, 
glob, and vsurf_descriptors) and electronic proper-
ties (PEOE_VSA_ descriptors and Q_VSA_POS) were 
captured by most well-performing models. The impor-
tance of molecular lipophilicity descriptors in the 
development of QSAR models to distinguish BCRP 
inhibitors from non-inhibitors has been highlighted 
by the previous studies [8, 15, 21]. Moreover, accord-
ing to the two-step mechanism for the inhibition of 
Fig. 7  The top ten descriptors/fingerprints for the a DNN, b XGBoost, c SGB and d SVM models identified by the perturbation-based 
model-agnostic method with 10 repetitions. The term “full_model_” denotes the estimation of a model performance on the test set based on the 
cross entropy loss function

## Page 17 (Section: The important fragments identified by the IG method)

Page 17 of 26
Jiang et al. J Cheminform           (2020) 12:16 
	
BCRP proposed by Matsson et al., high lipophilicity is 
a prerequisite for an inhibitor to reach the binding site 
of BCRP in the first step, and then geometrical com-
plementary, H-bonding and π–π interactions, which 
can be described by the shape, H-bond and electronic 
descriptors (such as std_dim2, PEOE_VSA_FPNEG and 
PEOE_VSA+4) [115], determine the binding of inhibi-
tors to BCRP in the second step.
It has been reported that the addition of fingerprints 
can significantly improve the prediction accuracy for 
many QSAR models [86, 88]. As shown in Fig. 7, some 
important features are fingerprints. The fingerprint 
PubchemFP758 (Cc1c(N)cccc1) was identified by three 
well-performing models (XGBoost, SGB and SVM) and 
PubchemFP293 (C-S) was identified by two well-per-
forming models (XGBoost and SGB). We then analyzed 
the frequencies of these two important fingerprints, and 
found that their distributions for the inhibitors and non-
inhibitors are quite different: 48.4% inhibitors (531 out 
of 1098) and 20.1% non-inhibitors (342 out of 1701) con-
tain PubChem758, respectively, and 47.2% non-inhibitors 
(803 out of 1701) and 6.2% inhibitors (68 out of 1098) 
contain PubChem293, respectively. The frequency anal-
ysis of PubchemFP758 that is a o-Toluidine fragment 
implies that BCRP inhibitors are more aromatic than 
non-inhibitors, which is in line with the results reported 
by Sjöstedt et  al. and Matsson et  al. that aromaticity 
is an important feature of BCRP inhibitors [73, 115]. 
PubChem293 contains a sulfur atom, which is supported 
by the results reported by Montanari and Ecker that the 
presence of a sulfur atom is unfavorable to BCRP inhibi-
tion due to its steric hindrance in the binding site [20].
The important fragments identified by the IG method
As described in “Materials and methods”, three kinds of 
fragments were generated for all the compounds and the 
frequency values of generated fragments in the inhibi-
tor class and non-inhibitor class were calculated. If the 
occurrence of a fragment is more frequent in the inhibi-
tor class than in non-inhibitor class, this fragment was 
considered as an important fragment for the inhibitor 
class, and it has positive contribution to BCRP inhibition 
and vice versa. The IG value was also calculated for all the 
generated fragments to identify the important structural 
fragments to BCRP inhibition.
As shown in Fig.  8, the IG values of the fragments 
range from 0 to 0.067, and most fragments have relatively 
low IG values. Analyses of the IG values and frequen-
cies of the fragments show that 12 positive fragments 
are responsible for BCRP inhibition (Table  6). All of 
them have high IG values and their frequencies for the 
inhibitor and non-inhibitor classes are obviously differ-
ent. Similarly, 11 negative fragments were identified to be 
responsible for BCRP non-inhibition (Table 7).
As shown in Tables  6 and 7, it can be observed that 
those positive fragments contain more abundant nitro-
gen atoms, and 6 of them contain at least three nitrogen 
atoms (No. 2, 3, 6, 8, 11, and 12). However, most nega-
tive fragments have only one or two nitrogen atoms or 
even do not contain any nitrogen atom. In addition, 
it is obvious that the positive fragments are more pla-
nar. According to the previous studies, it is suggested 
that the abundance of nitrogen atoms and molecular 
planarity have a high impact on BCRP inhibition [16, 
20]. Among the 12 positive fragments, No. 2 fragment 
(N,2-diphenylquinazolin-4-amine) has been reported to 
be favorable to BCRP inhibition [119]. In addition, It is 
obvious that almost all the negative fragments, with the 
exception of No. 19, contain only one individual ring in 
their structures, but most positive fragments contain at 
least two individual rings. This is in good agreement with 
the results that BCRP inhibitors tend to have more rings 
than non-inhibitors [73]. The 11 fragments shown in 
Table 7 have negative contributions to BCRP inhibition. 
It is obvious that many fragments do not contain planar 
components, and they have unfavorable effects on BCRP 
inhibition because molecular planarity is critical to BCRP 
inhibition as mentioned above. Many negative fragments 
contain a sulfate group, including No. 14, 15, 18, 19, and 
20. According to the previous study, it is noted that the 
presence of sulfate is unfavorable to BCRP inhibition 
because sulfate is bulky, which may lead to some kinds of 
steric hindrance in the binding site [20].
Generally speaking, the positive fragments are larger 
than negative fragments, and contain more rings and 
Fig. 8  The information gain (IG) value distributions of the generated 
fragments

## Page 18 (Section: The important fragments identified by the IG method)

Page 18 of 26
Jiang et al. J Cheminform           (2020) 12:16 
Table 6  The identified fragments by the information gain (IG) method couple with frequency analysis for BCRP inhibitors
Fragment
Name
Count1a
Count2b
F1c
F2d
IG
No.1
Quinazoline
175
14
2.3604
0.1219
0.0665
No. 2
N,2-diphenylquinazolin-4-amine
92
0
2.5492
0.0000
0.0456
No. 3
Pyrazolo[1,5-a]pyrimidine
85
8
2.3299
0.1415
0.0299
No. 4
4H-chromene
104
23
2.0875
0.2980
0.0263
No. 5
2-phenyl-4H-chromene
55
3
2.4173
0.0851
0.0216
No. 6
2H-tetrazole
65
12
2.1519
0.2564
0.0177
No. 7
Piperazine
90
30
1.9119
0.4114
0.0171

## Page 19 (Section: The important fragments identified by the IG method)

Page 19 of 26
Jiang et al. J Cheminform           (2020) 12:16 
	
Table 6  (continued)
Fragment
Name
Count1a
Count2b
F1c
F2d
IG
No. 8
N,2-diphenylpyrido[2,3-d]pyrimidin-4-amine
31
0
2.5492
0.0000
0.0151
No. 9
2,3,4,9-tetrahydro-1H-pyrido[3,4-b]indole
29
0
2.5492
0.0000
0.0141
No. 10
(R)-2-benzyl-1-phenyl-2,3,4,9-tetrahydro-
1H-pyrido[3,4-b]indole
27
0
2.5492
0.0000
0.0131
No. 11
N-benzyl-2-(2-phenyl-2H-tetrazol-5-yl)aniline
41
5
2.2721
0.1789
0.0131
No. 12
Pyrido[2,3-d]pyrimidine
32
2
2.3992
0.0968
0.0122
a  Count1 denotes the number of inhibitors containing the fragment
b  Count2 denotes the number of non-inhibitors containing the fragment
c  F1 denotes the fragment frequency in the inhibitor class
d  F2 denotes the fragment frequency in the non-inhibitor class

## Page 20 (Section: The important fragments identified by the IG method)

Page 20 of 26
Jiang et al. J Cheminform           (2020) 12:16 
Table 7  The identified fragments by  the  information gain (IG) method couple with  frequency analysis for  BCRP non-
inhibitors
Fragment
Name
Count1a
Count2b
F1c
F2d
IG
No.13
1H-pyrazole
1
67
0.0375
1.6213
0.0153
No.14
Thiazolidine
0
56
0.0000
1.6455
0.0146
No.15
Thiophene
16
118
0.3044
1.4490
0.0133
No.16
Morpholine
0
51
0.0000
1.6455
0.0132
No.17
4H-1,2,4-triazole
0
48
0.0000
1.6455
0.0125
No.18
Thiazole
3
62
0.1177
1.5696
0.0113
No.19
Benzo[d]thiazole
1
50
0.0500
1.6132
0.0109
No.20
1,3,4-thiadiazole
0
36
0.0000
1.6455
0.0093
No.21
Hexahydropyrimidine
2
44
0.1108
1.5740
0.0081
No.22
Piperidine
3
46
0.1561
1.5448
0.0075
No.23
Pyrrolidine
1
36
0.0689
1.6010
0.0074

## Page 21 (Section: Analysis of the misclassified compounds)

Page 21 of 26
Jiang et al. J Cheminform           (2020) 12:16 
	
nitrogen atoms. The negative fragments are less planar 
and contain more sulfate groups.
Analysis of the misclassified compounds
As discussed above, the SVM model developed based 
on the selected features from the training set yields the 
best predictions for the test set, but it still misclassified 
50 compounds in the test set. These misclassified com-
pounds include 27 false negatives and 23 false positives. 
The detailed descriptions of the misclassified molecules 
are listed in Additional file 1: Table S5.
First, we analyzed the scaffolds of the 50 misclassi-
fied compounds. Each compound was decomposed 
into three kinds of structural scaffolds including Ring 
Assemblies, Bridge Assemblies, and BemisMurcko 
Assemblies. For the generated fragments whose counts 
in the misclassified compounds are equal or larger 
than 2 were kept and their occurrence ratios were cal-
culated. In the same way, their counts and occurrence 
ratios were also calculated for the training and test sets 
(Table 8). Most of those representative fragments con-
tain hetero-cycles with nitrogen, oxygen or sulfur atom. 
These fragments are not abundant in the whole dataset 
(average occurrence ratio in the dataset is 3.65%) and 
some fragments in the test set are not enriched in the 
training set (fragments No. 26 and 36). It is quite possi-
ble that the SVM model could not give accurate predic-
tions to those infrequent fragments.
Among the 50 misclassified compounds, except com-
pound No. 221 that only contains a single ring, most of 
them have complicated structures. It is quite possible 
that some specific groups in those complex compounds 
need specific spatial arrangements to form favorable 
interaction with BCRP, which may not be well character-
ized by traditional descriptors or fingerprints [29]. Fur-
thermore, in this study, the reported experimental data 
were binarized according to a predefined threshold, and 
therefore the compounds with experimental data close 
to the threshold may be more likely to be misclassified 
than those with experimental data far from the thresh-
old, which has been well explained by Wu et al. [120]. In 
addition, existence of a few activity cliffs (similar struc-
tures but different activities) that distort the models may 
lead to misclassifications [29]. For example, in the 48 mis-
classified compounds, a pair of compounds (compounds 
No. 90 and 1360) may be a pair of activity cliffs (Tani-
moto similarities based on the 881 PubChem fingerprints 
are 0.923).
Here, five of the 27 misclassified inhibitors (compounds 
No. 3, No. 472, No. 1606, No. 1657, and No. 1806) con-
tain a sulfate group, which is unfavorable to BCRP inhi-
bition as mentioned above [20]. Thus, this is one of the 
potential reasons why they were easily predicted as non-
inhibitors. Two misclassified non-inhibitors (compounds 
No. 237 and No. 239) have abundant methoxyl (–OCH3) 
groups. The methoxyl groups observed in most QSAR 
studies could be interpreted as favorable H-bond accep-
tors [8], which may have positive contributions to BCRP 
inhibition [11, 16, 114].
Conclusion
As an important efflux transporter, BCRP plays a cru-
cial role in drug metabolism, multi-drug resistance to 
chemotherapeutic agents, and drug–drug interactions. 
It is an increasingly important area to develop com-
putational models with high reliability and robustness 
to predict BCRP inhibition. In this study, we reported 
an extensive and structurally diverse BCRP inhibi-
tion dataset, where includes 1098 BCRP inhibitors and 
1701 non-inhibitors. The relationships between the 
eight simple molecular descriptors and BCRP inhibi-
tion were examined. It is observed that BCRP inhibi-
tors were characterized by higher hydrophobicity and 
aromaticity. The optimal feature subset of 144 molecu-
lar features was determined based on a wrapper feature 
selection named rfSA. Then, based on the extensive 
BCRP inhibition dataset and the optimal subset, seven 
ML approaches, including one DL method: DNN, two 
ensemble learning methods: SGB and XGBoost, and 
four classical methods: NB, weighted k-NN, RLR, and 
SVM, were used to develop a number of accurate clas-
sification models. Bayesian optimization technique 
was used to select the optimal hyper-parameters for 
Table 7  (continued)
a  Count1 denotes the number of inhibitors containing the fragment
b  Count2 denotes the number of non-inhibitors containing the fragment
c  F1 denotes the fragment frequency in the inhibitor class
d  F2 denotes the fragment frequency in the non-inhibitor class

## Page 22 (Section: Analysis of the misclassified compounds)

Page 22 of 26
Jiang et al. J Cheminform           (2020) 12:16 
Table 8  The representative fragments whose counts are equal or larger than 2 in the 50 misclassified compounds
Fragment
Name
Count1a
Count2a
Count3a
OR1a (%)
OR2a (%)
OR3a (%)
No.24
Pyridine
125
43
5
5.58
7.69
10.00
No.25
Tetrahydro-2H-pyran
37
6
3
1.65
1.07
6.00
No.26
Adamantane
6
3
2
0.27
0.54
4.00
No.27
(E)-prop-1-ene-1,3-diyldibenzene
58
16
3
2.59
2.86
6.00
No.28
1H-indole
82
25
3
3.66
4.47
6.00
No.29
4H-chromene
110
17
4
4.91
3.04
8.00
No.30
Furan
175
37
2
7.81
6.62
4.00
No.31
Piperazine
98
22
3
4.38
3.94
6.00
No.32
Quinazoline
150
39
2
6.70
6.98
4.00
No.33
Quinoline
58
16
3
2.59
2.86
6.00

## Page 23 (Section: Acknowledgements)

Page 23 of 26
Jiang et al. J Cheminform           (2020) 12:16 
	
all the models. This is the first attempt that the new AI 
methods (i.e., XGBoost and DNN) were used to predict 
BCRP inhibition. The statistical results indicated that 
one conventional ML method (SVM) and two new ML 
methods (XGBoost and DNN) outperformed the other 
three traditional ML methods, and among them SVM 
yielded the best prediction capability. Then, a pertur-
bation-based method was used to interpret our mod-
els and analyze the representative features for different 
models. In addition, the favorable and unfavorable frag-
ments to BCRP inhibition identified by information 
gain (IG) method along with frequency analysis were 
then analyzed. The results may provide some valu-
able information for the design and discovery of BCRP 
inhibitors.
Supplementary information
Supplementary information accompanies this paper at https​://doi.
org/10.1186/s1332​1-020-00421​-y.
Additional file 1: Table S1. The detailed descriptions of the final dataset 
containing 1098 BCRP inhibitors and 1701 BCRP non-inhibitors. Table S2. 
The searching space of the Bayesian optimization and the optimal hyper-
parameters determined by the Bayesian optimization for all the studied 
models; Table S3. The detailed descriptions of the 65 representative 
descriptors chosen by rfSA; Table S4. The detailed descriptions of the 79 
representative fingerprints chosen by rfSA; Table S5. The detailed descrip-
tions of the misclassified molecules given by the SVM mode1. 
Additional file 2. The R source code that implements the workflow.
Acknowledgements
Not applicable.
Authors’ contributions
DJ developed the prediction models, analyzed the data, wrote the manuscript; 
TL, ZW and CS evaluated and interpreted the results, wrote the manuscript; 
DC and TH conceived and supervised the project, interpreted the results, 
wrote the manuscript. All authors read and approved the final manuscript.
Funding
This study was supported by Key R&D Program of Zhejiang Province 
(2020C03010), National Science Foundation of China (21575128 and 
81773632), and Zhejiang Provincial Natural Science Foundation of China 
(LZ19H300001).
Competing interests
The authors declare that they have no competing interests.
Received: 27 September 2019   Accepted: 20 February 2020
References
	
1.	 Ni Z, Bikadi Z, Rosenberg MF, Mao Q (2010) Structure and function of 
the human breast cancer resistance protein (BCRP/ABCG2). Curr Drug 
Metab 11:603–617
	
2.	 Mao QC, Unadkat JD (2005) Role of the breast cancer resistance protein 
(ABCG2) in drug transport. AAPS J 7:E118–E133
	
3.	 Doyle LA, Ross DD (2003) Multidrug resistance mediated by the breast 
cancer resistance protein BCRP (ABCG2). Oncogene 22:7340–7358
	
4.	 Mao Q, Unadkat JD (2015) Role of the breast cancer resistance protein 
(BCRP/ABCG2) in drug transport-an update. AAPS J 17:65–82
	
5.	 Garg P, Dhakne R, Belekar V (2015) Role of breast cancer resistance 
protein (BCRP) as active efflux transporter on blood–brain barrier (BBB) 
permeability. Mol Divers 19:163–172
	
6.	 Szakacs G, Varadi A, Oezvegy-Laczka C, Sarkadi B (2008) The role of ABC 
transporters in drug absorption, distribution, metabolism, excretion 
and toxicity (ADME-Tox). Drug Discov Today 13:379–393
	
7.	 Krishnamurthy P, Schuetz J (2006) Role of ABCG2/BCRP in biology and 
medicine. Annu Rev Pharmacol Toxicol 46:381–410
	
8.	 Nicolle E, Boccard J, Guilet D, Dijoux-Franca M-G, Zelefac F, Macalou S, 
Grosselin J, Schmidt J, Carrupt P-A, Di Pietro A, Boumendjel A (2009) 
a  Count1, 2, and 3 represent the number of the training compounds, testing compounds and misclassified compounds containing the fragment, respectively, and 
OR1, 2 and 3 represent the occurrence ratio of the fragment in the training compounds, testing compounds and misclassified compounds, respectively
Table 8  (continued)
Fragment
Name
Count1a
Count2a
Count3a
OR1a (%)
OR2a (%)
OR3a (%)
No.34
Thiophene
109
25
3
4.87
4.47
6.00
No.35
1,2,3,4-tetrahydroi
56
14
3
2.50
2.50
6.00
No.36
2-(4-((quinolin-3-ylmethyl)amino)
phenethyl)-1,2,3,4-tetrahydroi
0
2
2
0.00
0.36
4.00

## Page 24 (Section: Acknowledgements)

Page 24 of 26
Jiang et al. J Cheminform           (2020) 12:16 
Breast cancer resistance protein (BCRP/ABCG2): new inhibitors and 
QSAR studies by a 3D linear solvation energy approach. Eur J Pharm Sci 
38:39–46
	
9.	 Kruijtzer CMF, Beijnen JH, Rosing H, Huinink WWT, Schot M, Jewell 
RC, Paul EM, Schellens JHM (2002) Increased oral bioavailability of 
topotecan in combination with the breast cancer resistance protein 
and P-glycoprotein inhibitor GF120918. J Clin Oncol 20:2943–2950
	 10.	 Stewart CF, Leggas M, Schuetz JD, Panetta JC, Cheshire PJ, Peterson J, 
Daw N, Jenkins JJ, Gilbertson R, Germain GS, Harwood FC, Houghton PJ 
(2004) Gefitinib enhances the antitumor activity and oral bioavailability 
of irinotecan in mice. Cancer Res 64:7491–7499
	 11.	 Pan Y, Chothe PP, Swaan PW (2013) Identification of novel breast cancer 
resistance protein (BCRP) inhibitors by virtual screening. Mol Pharm 
10:1236–1248
	 12.	 Pick A, Mueller H, Mayer R, Haenisch B, Pajeva IK, Weigt M, Boenisch H, 
Mueller CE, Wiese M (2011) Structure-activity relationships of flavonoids 
as inhibitors of breast cancer resistance protein (BCRP). Bioorg Med 
Chem 19:2090–2102
	 13.	 Saito H, Hirano H, Nakagawa H, Fukami T, Oosumi K, Murakami K, 
Kimura H, Kouchi T, Konomi M, Tao E, Tsujikawa N, Tarui S, Nagakura M, 
Osumi M, Ishikawa T (2006) A new strategy of high-speed screening 
and quantitative structure-activity relationship analysis to evaluate 
human ATP-binding cassette transporter ABCG2-drug interactions. J 
Pharmacol Exp Ther 317:1114–1124
	 14.	 Pick A, Mueller H, Wiese M (2008) Structure–activity relationships of 
new inhibitors of breast cancer resistance protein (ABCG2). Bioorg Med 
Chem 16:8224–8236
	 15.	 Zhang SZ, Yang XN, Coburn RA, Morris ME (2005) Structure activity 
relationships and quantitative structure activity relationships for the 
flavonoid-mediated inhibition of breast cancer resistance protein. 
Biochem Pharmacol 70:627–639
	 16.	 Matsson P, Englund G, Ahlin G, Bergstrom CAS, Norinder U, Artursson P 
(2007) A global drug inhibition pattern for the human ATP-binding cas-
sette transporter breast cancer resistance protein (ABCG2). J Pharmacol 
Exp Ther 323:19–30
	 17.	 Gandhi YA, Morris ME (2009) Structure–activity relationships and 
quantitative structure–activity relationships for breast cancer resistance 
protein (ABCG2). AAPS J 11:541–552
	 18.	 Ishikawa T, Hirano H, Saito H, Sano K, Ikegami Y, Yamaotsu N, Hirono S 
(2012) Quantitative structure–activity relationship (QSAR) Analysis to 
predict drug–drug interactions of ABC transporter ABCG2. Mini-Rev 
Med Chem 12:505–514
	 19.	 Nicolle E, Boumendjel A, Macalou S, Genoux E, Ahmed-Belkacem A, 
Carrupt PA, Di Pietro A (2009) QSAR analysis and molecular modeling of 
ABCG2-specific inhibitors. Adv Drug Deliv Rev 61:34–46
	 20.	 Montanari F, Ecker GF (2014) BCRP inhibition: from data collection to 
ligand-based modeling. Mol Inform 33:322–331
	 21.	 Belekar V, Lingineni K, Garg P (2015) Classification of breast can-
cer resistant protein (BCRP) inhibitors and non-inhibitors using 
machine learning approaches. Comb Chem High Throughput Screen 
18:476–485
	 22.	 Montanari F, Cseke A, Wlcek K, Ecker GF (2017) Virtual screening of 
DrugBank Reveals two drugs as new BCRP inhibitors. Slas Discov 
22:86–93
	 23.	 Ryu JY, Kim HU, Lee SY (2018) Deep learning improves predic-
tion of drug–drug and drug–food interactions. Proc Natl Acad Sci 
115:E4304–E4311
	 24.	 Munir K, Elahi H, Ayub A, Frezza F, Rizzi A (2019) Cancer diagnosis using 
deep learning: a bibliographic review. Cancers 11:1235
	 25.	 Ma J, Sheridan RP, Liaw A, Dahl GE, Svetnik V (2015) Deep neural nets as 
a method for quantitative structure–activity relationships. J Chem Inf 
Model 55:263–274
	 26.	 Klambauer G, Unterthiner T, Mayr A, Hochreiter S (2017) DeepTox: toxic-
ity prediction using deep learning. Toxicol Lett 280:S69–S69
	 27.	 Wu Z, Ramsundar B, Feinberg EN, Gomes J, Geniesse C, Pappu AS, 
Leswing K, Pande V (2018) MoleculeNet: a benchmark for molecular 
machine learning. Chem Sci 9:513–530
	 28.	 Altae-Tran H, Ramsundar B, Pappu AS, Pande V (2017) Low data drug 
discovery with one-shot learning. ACS Cent Sci 3:283–293
	 29.	 Lei T, Chen F, Liu H, Sun H, Kang Y, Li D, Li Y, Hou T (2017) ADMET 
evaluation in drug discovery. Part 17: development of quantitative and 
qualitative prediction models for chemical-induced respiratory toxicity. 
Mol Pharm 14:2407–2421
	 30.	 Lei T, Li Y, Song Y, Li D, Sun H, Hou T (2016) ADMET evaluation in drug 
discovery: 15. Accurate prediction of rat oral acute toxicity using 
relevance vector machine and consensus modeling. J Cheminform 8:6
	 31.	 Sheridan RP, Wang WM, Liaw A, Ma J, Gifford EM (2016) Extreme gradi-
ent boosting as a method for quantitative structure–activity relation-
ships. J Chem Inf Model 56:2353–2360
	 32.	 Korotcov A, Tkachenko V, Russo DP, Ekins S (2017) Comparison of deep 
learning with multiple machine learning methods and metrics using 
diverse drug discovery data sets. Mol Pharm 14:4462–4475
	 33.	 Aliper A, Plis S, Artemov A, Ulloa A, Mamoshina P, Zhavoronkov A (2016) 
Deep learning applications for predicting pharmacological properties 
of drugs and drug repurposing using transcriptomic data. Mol Pharm 
13:2524–2530
	 34.	 Gawehn E, Hiss JA, Brown JB, Schneider G (2018) Advancing drug 
discovery via GPU-based deep learning. Expert Opin Drug Discov 
13:579–582
	 35.	 D’Cunha R, Bae S, Murry DJ, An G (2016) TKI combination therapy: 
strategy to enhance dasatinib uptake by inhibiting Pgp- and BCRP-
mediated efflux. Biopharm Drug Dispos 37:397–408
	 36.	 Elsby R, Fox L, Stresser D, Layton M, Butters C, Sharma P, Smith V, Surry D 
(2011) In vitro risk assessment of AZD9056 perpetrating a transporter-
mediated drug–drug interaction with methotrexate. Eur J Pharm Sci 
43:41–49
	 37.	 Fleisher B, Unum J, Shao J, An G (2015) Ingredients in fruit juices interact 
with dasatinib through inhibition of BCRP: a new mechanism of bever-
age–drug interaction. J Pharm Sci 104:266–275
	 38.	 Gozzi GJ, Bouaziz Z, Winter E, Daflon-Yunes N, Aichele D, Nacereddine A, 
Marminon C, Valdameri G, Zeinyeh W, Bollacke A, Guillon J, Lacoudre A, 
Pinaud N, Cadena SM, Jose J, Le Borgne M, Di Pietro A (2015) Convert-
ing potent indeno 1,2-b indole inhibitors of protein kinase CK2 into 
selective inhibitors of the breast cancer resistance protein ABCG2. J 
Med Chem 58:265–277
	 39.	 Gozzi GJ, Bouaziz Z, Winter E, Daflon-Yunes N, Honorat M, Guragossian 
N, Marminon C, Valdameri G, Bollacke A, Guillon J, Pinaud N, Marchivie 
M, Cadena SM, Jose J, Le Borgne M, Di Pietro A (2015) Phenolic indeno 
1,2-b indoles as ABCG2-selective potent and non-toxic inhibitors stimu-
lating basal ATPase activity. Drug Des Dev Ther 9:3481–3495
	 40.	 Gros G, Martinez L, Gimenez AS, Adler P, Maurin P, Wolkowicz R, Falson 
P, Hasserodt J (2013) Modular construction of quaternary hemiaminal-
based inhibitor candidates and their in cellulo assessment with HIV-1 
protease. Bioorg Med Chem 21:5407–5413
	 41.	 Gu X, Ren Z, Peng H, Peng S, Zhang Y (2014) Bifendate-chalcone 
hybrids: a new class of potential dual inhibitors of P-glycoprotein 
and breast cancer resistance protein. Biochem Biophys Res Commun 
455:318–322
	 42.	 Gu X, Tang X, Zhao Q, Peng H, Peng S, Zhang Y (2014) Discovery of 
alkoxyl biphenyl derivatives bearing dibenzo c, e azepine scaffold as 
potential dual inhibitors of P-glycoprotein and breast cancer resistance 
protein. Bioorg Med Chem Lett 24:3419–3421
	 43.	 Gujarati NA, Zeng L, Gupta P, Chen Z-S, Korlipara VL (2017) Design, 
synthesis and biological evaluation of benzamide and phenyltetrazole 
derivatives with amide and urea linkers as BCRP inhibitors. Bioorg Med 
Chem Lett 27:4698–4704
	 44.	 Han Y, Riwanto M, Go M-L, Ee PLR (2008) Modulation of breast cancer 
resistance protein (BCRP/ABCG2) by non-basic chalcone analogues. Eur 
J Pharm Sci 35:30–41
	 45.	 Hayashi D, Tsukioka N, Inoue Y, Matsubayashi Y, Iizuka T, Higuchi K, 
Ikegami Y, Kawasaki T (2015) Synthesis and ABCG2 inhibitory evaluation 
of 5-N-acetylardeemin derivatives. Bioorg Med Chem 23:2010–2023
	 46.	 Henrich CJ, Bokesch HR, Dean M, Bates SE, Robey RW, Goncharova EI, 
Wilson JA, McMahon JB (2006) A high-throughput cell-based assay for 
inhibitors of ABCG2 activity. J Biomol Screen 11:176–183
	 47.	 Henrich CJ, Robey RW, Takada K, Bokesch HR, Bates SE, Shukla S, 
Ambudkar SV, McMahon JB, Gustafson KR (2009) Botryllamides: natural 
product inhibitors of ABCG2. ACS Chem Biol 4:637–647
	 48.	 Juvale K, Gallus J, Wiese M (2013) Investigation of quinazolines as inhibi-
tors of breast cancer resistance protein (ABCG2). Bioorg Med Chem 
21:7858–7873

## Page 25 (Section: Acknowledgements)

Page 25 of 26
Jiang et al. J Cheminform           (2020) 12:16 
	
	 49.	 Juvale K, Stefan K, Wiese M (2013) Synthesis and biological evaluation 
of flavones and benzoflavones as inhibitors of BCRP/ABCG2. Eur J Med 
Chem 67:115–126
	 50.	 Karthikeyan C, Malla R, Ashby CR Jr., Amawi H, Abbott KL, Moore J, Chen 
J, Balch C, Lee C, Flannery PC, Trivedi P, Faridi JS, Pondugula SR, Tiwari AK 
(2016) Pyrimido 1″, 2″:1,5 pyrazolo 3,4-b quinolines: novel compounds 
that reverse ABCG2-mediated resistance in cancer cells. Cancer Lett 
376:118–126
	 51.	 Kee WT, Cooney J, Jensen D, Yan L, Paxton JW, Birch NP, Scheepens A 
(2014) Hop-derived prenylflavonoids are substrates and inhibitors of 
the efflux transporter breast cancer resistance protein (BCRP/ABCG2). 
Mol Nutr Food Res 58:2099–2110
	 52.	 Koehler SC, Silbermann K, Wiese M (2016) Phenyltetrazolyl-phenyla-
mides: substituent impact on modulation capability and selectivity 
toward the efflux protein ABCG2 and investigation of interaction with 
the transporter. Eur J Med Chem 124:881–895
	 53.	 Koehler SC, Vandati S, Scholz MS, Wiese M (2018) Structure activity 
relationships, multidrug resistance reversal and selectivity of heteroaryl-
phenyl ABCG2 inhibitors. Eur J Med Chem 146:483–500
	 54.	 Koehler SC, Wiese M (2015) HM30181 derivatives as novel potent and 
selective inhibitors of the breast cancer resistance protein (BCRP/
ABCG2). J Med Chem 58:3910–3921
	 55.	 Kraege S, Koehler SC, Wiese M (2016) Acryloylphenylcarboxamides: 
a new class of breast cancer resistance protein (ABCG2) modulators. 
ChemMedChem 11:2422–2435
	 56.	 Kraege S, Stefan K, Juvale K, Ross T, Willmes T, Wiese M (2016) The com-
bination of quinazoline and chalcone moieties leads to novel potent 
heterodimeric modulators of breast cancer resistance protein (BCRP/
ABCG2). Eur J Med Chem 117:212–229
	 57.	 Kraege S, Stefan K, Koehler SC, Wiese M (2016) Optimization of Acry-
loylphenylcarboxamides as inhibitors of ABCG2 and comparison with 
acryloylphenylcarboxylates. ChemMedChem 11:2547–2558
	 58.	 Krapf MK, Gallus J, Vahdati S, Wiese M (2018) New inhibitors of breast 
cancer resistance protein (ABCG2) containing a 2,4-disubstituted pyri-
dopyrimidine scaffold. J Med Chem 61:3389–3408
	 59.	 Krapf MK, Gallus J, Wiese M (2017) Synthesis and biological investiga-
tion of 2,4-substituted quinazolines as highly potent inhibitors of breast 
cancer resistance protein (ABCG2). Eur J Med Chem 139:587–611
	 60.	 Krapf MK, Gallus J, Wiese M (2017) 4-Anilino-2-pyridylquinazolines and 
-pyrimidines as highly potent and nontoxic inhibitors of breast cancer 
resistance protein (ABCG2). J Med Chem 60:4474–4495
	 61.	 Krapf MK, Wiese M (2016) Synthesis and biological evaluation of 
4-anilino-quinazolines and -quinolines as inhibitors of breast cancer 
resistance protein (ABCG2). J Med Chem 59:5449–5461
	 62.	 Krauze A, Grinberga S, Krasnova L, Adlere I, Sokolova E, Domracheva 
I, Shestakova I, Andzans Z, Duburs G (2014) Thieno 2,3-b pyridines-A 
new class of multidrug resistance (MDR) modulators. Bioorg Med Chem 
22:5860–5870
	 63.	 Li X-Q, Wang L, Lei Y, Hu T, Zhang F-L, Cho C-H, To KKW (2015) Reversal 
of P-gp and BCRP-mediated MDR by tariquidar derivatives. Eur J Med 
Chem 101:560–572
	 64.	 Li Y, Woo J, Chmielecki J, Xia CQ, Liao M, Chuang B-C, Yang JJ, Guan MY, 
Plesescu M, Prakash SR (2016) Synthesis of a new inhibitor of breast 
cancer resistance protein with significantly improved pharmacokinetic 
profiles. Bioorg Med Chem Lett 26:551–555
	 65.	 Marighetti F, Steggemann K, Karbaum M, Wiese M (2015) Scaffold 
identification of a new class of potent and selective BCRP inhibitors. 
ChemMedChem 10:742–751
	 66.	 Miyata H, Takada T, Toyoda Y, Matsuo H, Ichida K, Suzuki H (2016) 
Identification of febuxostat as a new strong ABCG2 inhibitor: potential 
applications and risks in clinical situations. Front Pharmacol 7:518
	 67.	 Ochoa-Puentes C, Bauer S, Kuehnle M, Bernhard G, Buschauer A, Koenig 
B (2013) Benzanilide-biphenyl replacement: a bioisosteric approach to 
quinoline carboxamide-type ABCG2 modulators. ACS Med Chem Lett 
4:393–396
	 68.	 Pires ARA, Lecerf-Schmidt F, Guragossian N, Pazinato J, Gozzi GJ, Winter 
E, Valdameri G, Veale A, Boumendjel A, Di Pietro A, Peres B (2016) New, 
highly potent and non-toxic, chromone inhibitors of the human breast 
cancer resistance protein ABCG2. Eur J Med Chem 122:291–301
	 69.	 Revalde JL, Li Y, Hawkins BC, Rosengren RJ, Paxton JW (2015) Hetero-
cyclic cyclohexanone monocarbonyl analogs of curcumin can inhibit 
the activity of ATP-binding cassette transporters in cancer multidrug 
resistance. Biochem Pharmacol 93:305–317
	 70.	 Schexnayder C, Stratford RE (2016) Genistein and glyceollin effects 
on ABCC2 (MRP2) and ABCG2 (BCRP) in Caco-2 cells. Int J Environ Res 
Public Health 13:17
	 71.	 Schmitt F, Draut H, Biersack B, Schobert R (2016) Halogenated 
naphthochalcones and structurally related naphthopyrazolines with 
antitumor activity. Bioorg Med Chem Lett 26:5168–5171
	 72.	 Schmitt SM, Stefan K, Wiese M (2016) Pyrrolopyrimidine derivatives as 
novel inhibitors of multidrug resistance-associated protein 1 (MRP1, 
ABCC1). J Med Chem 59:3018–3033
	 73.	 Sjostedt N, Holvikari K, Tammela P, Kidron H (2017) Inhibition of breast 
cancer resistance protein and multidrug resistance associated protein 2 
by natural compounds and their derivatives. Mol Pharm 14:135–146
	 74.	 Song JG, Lee YS, Park J-A, Lee E-H, Lim S-J, Yang SJ, Zhao M, Lee K, Han 
H-K (2016) Discovery of LW6 as a new potent inhibitor of breast cancer 
resistance protein. Cancer Chemother Pharmacol 78:735–744
	 75.	 Spindler A, Stefan K, Wiese M (2016) Synthesis and investigation of 
tetrahydro-beta-carboline derivatives as inhibitors of the breast cancer 
resistance protein (ABCG2). J Med Chem 59:6121–6135
	 76.	 Suzuki M, Suzuki H, Sugimoto Y, Sugiyama Y (2003) ABCG2 trans-
ports sulfated conjugates of steroids and xenobiotics. J Biol Chem 
278:22644–22649
	 77.	 Tan KW, Killeen DP, Li Y, Paxton JW, Birch NP, Scheepens A (2014) Dietary 
polyacetylenes of the falcarinol type are inhibitors of breast cancer 
resistance protein (BCRP/ABCG2). Eur J Pharmacol 723:346–352
	 78.	 Tan KW, Li Y, Paxton JW, Birch NP, Scheepens A (2013) Identification of 
novel dietary phytochemicals inhibiting the efflux transporter breast 
cancer resistance protein (BCRP/ABCG2). Food Chem 138:2267–2274
	 79.	 Valdameri G, Gauthier C, Terreux R, Kachadourian R, Day BJ, Winnis-
chofer SMB, Rocha MEM, Frachet V, Ronot X, Di Pietro A, Boumendjel A 
(2012) Investigation of chalcones as selective inhibitors of the breast 
cancer resistance protein: critical role of methoxylation in both inhibi-
tion potency and cytotoxicity. J Med Chem 55:3193–3200
	 80.	 Valdameri G, Genoux-Bastide E, Peres B, Gauthier C, Guitton J, Terreux 
R, Winnischofer SMB, Rocha MEM, Boumendjel A, Di Pietro A (2012) 
Substituted chromones as highly potent nontoxic inhibitors, specific for 
the breast cancer resistance protein. J Med Chem 55:966–970
	 81.	 Wieczorek A, Blauz A, Zakrzewski J, Rychlik B, Plazuk D (2016) Ferrocenyl 
2,5-piperazinediones as tubulin-binding organometallic ABCB(1) 
and ABCG(2) inhibitors active against MDR cells. ACS Med Chem Lett 
7:612–617
	 82.	 Winter E, Gozzi GJ, Chiaradia-Delatorre LD, Daflon-Yunes N, Terreux 
R, Gauthier C, Mascarello A, Leal PC, Cadena SM, Yunes RA, Nunes 
RJ, Creczynski-Pasa TB, Di Pietro A (2014) Quinoxaline-substituted 
chalcones as new inhibitors of breast cancer resistance protein ABCG2: 
polyspecificity at B-ring position. Drug Des Dev Ther 8:609–619
	 83.	 Winter E, Lecerf-Schmidt F, Gozzi G, Peres B, Lightbody M, Gauthier C, 
Ozvegy-Laczka C, Szakacs G, Sarkadi B, Creczynski-Pasa TB, Boumend-
jel A, Di Pietro A (2013) Structure–activity relationships of chromone 
derivatives toward the mechanism of interaction with and inhibition of 
breast cancer resistance protein ABCG2. J Med Chem 56:9849–9860
	 84.	 Winter E, Neuenfeldt PD, Chiaradia-Delatorre LD, Gauthier C, Yunes 
RA, Nunes RJ, Creczynski-Pasa TB, Di Pietro A (2014) Symmetric Bis-
chalcones as a new type of breast cancer resistance protein inhibitors 
with a mechanism different from that of chromones. J Med Chem 
57:2930–2941
	 85.	 (2015) MOE molecular simulation package. Chemical Computing 
Group ULC, Montreal
	 86.	 Chen L, Li Y, Zhao Q, Peng H, Hou T (2011) ADME evaluation in drug 
discovery. 10. Predictions of P-glycoprotein inhibitors using recursive 
partitioning and Naive bayesian classification techniques. Mol Pharm 
8:889–900
	 87.	 Wang S, Li Y, Wang J, Chen L, Zhang L, Yu H, Hou T (2012) ADMET 
evaluation in drug discovery. 12. Development of binary classification 
models for prediction of hERG potassium channel blockage. Mol Pharm 
9:996–1010
	 88.	 Li D, Chen L, Li Y, Tian S, Sun H, Hou T (2014) ADMET evaluation in 
drug discovery. 13. Development of in silico prediction models for 
P-glycoprotein substrates. Mol Pharm 11:716–726

## Page 26 (Section: Acknowledgements)

Page 26 of 26
Jiang et al. J Cheminform           (2020) 12:16 
•
 
fast, convenient online submission
 
•
  
thorough peer review by experienced researchers in your ﬁeld
• 
 
rapid publication on acceptance
• 
 
support for research data, including large and complex data types
•
  
gold Open Access which fosters wider collaboration and increased citations 
 
maximum visibility for your research: over 100M website views per year 
•
  
At BMC, research is always in progress.
Learn more biomedcentral.com/submissions
Ready to submit your research ?  Choose BMC and benefit from: 
	 89.	 Yap CW (2011) PaDEL-descriptor: an open source software to calculate 
molecular descriptors and fingerprints. J Comput Chem 32:1466–1474
	 90.	 Brooks SP, Morgan BJT (1995) Optimization using simulated annealing. 
Statistician 44:241–257
	 91.	 Kuhn M. Feature selection using simulated annealing. https​://topep​
o.githu​b.io/caret​/featu​re-selec​tion-using​-simul​ated-annea​ling.html. 
Accessed 16 Apr
	 92.	 Kuhn M. Package ‘caret’. https​://cran.r-proje​ct.org/web/packa​ges/caret​/
caret​.pdf. Accessed 16 Apr
	 93.	 Xia XY, Maliski EG, Gallant P, Rogers D (2004) Classification of kinase 
inhibitors using a Bayesian model. J Med Chem 47:4463–4470
	 94.	 Mitchell JB (2014) Machine learning methods in chemoinformatics. 
Wiley Interdiscip Rev Comput Mol Sci 4:468–481
	 95.	 Ren Y, Zhou L, Yang L, Liu P, Zhao B, Liu H (2016) Predicting the aquatic 
toxicity mode of action using logistic regression and linear discriminant 
analysis. SAR QSAR Environ Res 27:721–746
	 96.	 Friedman JH (2002) Stochastic gradient boosting. Comput Stat Data 
Anal 38:367–378
	 97.	 Dahl GE, Jaitly N, Salakhutdinov R. Multi-task neural networks for 
QSAR predictions. arXiv e-prints. 2014. https​://ui.adsab​s.harva​rd.edu/
abs/2014a​rXiv1​406.1231D​. Accessed 01 June 2014
	 98.	 Snoek J, Larochelle H, Adams RP (2012) Practical bayesian optimiza-
tion of machine learning algorithms. Adv Neural Inf Process Syst 
2012:2951–2959
	 99.	 Koutsoukas A, Monaghan KJ, Li X, Huan J (2017) Deep-learning: 
investigating deep neural networks hyper-parameters and comparison 
of performance to shallow methods for modeling bioactivity data. J 
Cheminform 9:42
	100.	 Guidance document on the validation of (quantitative) structure–activ-
ity relationship [(Q) SAR] models. OECD Series on Testing and Assess-
ment, 1–154, 2014
	101.	 Mayr A, Klambauer G, Unterthiner T, Hochreiter S (2016) DeepTox: toxic-
ity prediction using deep learning. Front Environ Sci 3:80
	102.	 Mayr A, Klambauer G, Unterthiner T, Steijaert M, Wegner JK, Ceulemans 
H, Clevert D-A, Hochreiter S (2018) Large-scale comparison of machine 
learning methods for drug target prediction on ChEMBL. Chem Sci 
9:5441–5451
	103.	 Jaworska J, Nikolova-Jeliazkova N, Aldenberg T (2005) QSAR applicabil-
ity domain estimation by projection of the training set in descriptor 
space: a review. Atla-Altern Lab Anim 33:445–459
	104.	 Sahigara F, Mansouri K, Ballabio D, Mauri A, Consonni V, Todeschini RJM 
(2012) Comparison of different approaches to define the applicability 
domain of QSAR models. Molecules 17:4791–4810
	105.	 Nina Nikolova-Jeliazkova JJ (2006) AmbitDiscovery-v0.04
	106.	 Lei T, Sun H, Kang Y, Zhu F, Liu H, Zhou W, Wang Z, Li D, Li Y, Hou T 
(2017) ADMET evaluation in drug discovery. 18. Reliable prediction of 
chemical-induced urinary tract toxicity by boosting machine learning-
approaches. Mol Pharm 14:3935–3953
	107.	 Fisher A, Rudin C, Dominici F (2018) All models are wrong but many 
are useful: variable importance for black-box, proprietary, or misspeci-
fied prediction models, using model class reliance. arXiv preprint arXiv​
:1801.01489​
	108.	 Burzykowski PBT. Chapter 15 feature importance. https​://pbiec​ek.githu​
b.io/PM_VEE/featu​reImp​ortan​ce.html. Accessed 24 Sept
	109.	 Tian S, Wang J, Li Y, Li D, Xu L, Hou T (2015) The application of in silico 
drug-likeness predictions in pharmaceutical research. Adv Drug Deliv 
Rev 86:2–10
	110.	 Jensen BF, Vind C, Padkjær SB, Brockhoff PB, Refsgaard HH (2007) In 
silico prediction of cytochrome P450 2D6 and 3A4 inhibition using 
Gaussian kernel weighted k-nearest neighbor and extended connectiv-
ity fingerprints, including structural fragment analysis of inhibitors 
versus noninhibitors. J Med Chem 50:501–511
	111.	 Zhang C, Cheng F, Li W, Liu G, Lee PW, Tang Y (2016) In silico prediction 
of drug induced liver toxicity using substructure pattern recognition 
method. Mol Inform 35:136–144
	112.	 Hegedus C, Szakacs G, Homolya L, Orban TI, Telbisz A, Jani M, Sarkadi B 
(2009) Ins and outs of the ABCG2 multidrug transporter: an update on 
in vitro functional assays. Adv Drug Deliv Rev 61:47–56
	113.	 Ding Y-L, Shih Y-H, Tsai F-Y, Leong MK (2014) In silico prediction of inhi-
bition of promiscuous breast cancer resistance protein (BCRP/ABCG2). 
PLoS ONE 9:e90689
	114.	 Wei Y, Ma Y, Zhao Q, Ren Z, Li Y, Hou T, Peng H (2012) New use for an old 
drug: inhibiting ABCG2 with sorafenib. Mol Cancer Ther 11:1693–1702
	115.	 Matsson P, Pedersen JM, Norinder U, Bergstrom CAS, Artursson P (2009) 
Identification of novel specific and general inhibitors of the three major 
human ATP-binding cassette transporters P-gp, BCRP and MRP2 among 
registered drugs. Pharm Res 26:1816–1831
	116.	 Yoshikawa M, Ikegami Y, Hayasaka S, Ishii K, Ito A, Sano K, Suzuki T, 
Togawa T, Yoshida H, Soda H (2004) Novel camptothecin analogues that 
circumvent ABCG2-associated drug resistance in human tumor cells. Int 
J Cancer 110:921–927
	117.	 Wildman SA, Crippen GM (1999) Prediction of physicochemical param-
eters by atomic contributions. J Chem Inf Comput Sci 39:868–873
	118.	 Lenselink EB, ten Dijke N, Bongers B, Papadatos G, van Vlijmen HWT, 
Kowalczyk W, Ijzerman AP, van Westen GJP (2017) Beyond the hype: 
deep neural networks outperform established methods using a 
ChEMBL bioactivity benchmark set. J Cheminform 9:1–14
	119.	 Montanari F, Zdrazil B, Digles D, Ecker GF (2016) Selectivity profiling of 
BCRP versus P-gp inhibition: from automated collection of polypharma-
cology data to multi-label learning. J Cheminform 8:1–13
	120.	 Wu Z, Lei T, Shen C, Wang Z, Cao D, Hou T (2019) ADMET evaluation 
in drug discovery. 19. Reliable prediction of human cytochrome P450 
inhibition using artificial intelligence approaches. J Chem Inf Model 
59:4587–4601
	121.	 Sedykh A, Fourches D, Duan J, Hucke O, Garneau M, Zhu H, Bonneau P, 
Tropsha A (2013) Human intestinal transporter database: QSAR mod-
eling and virtual profiling of drug uptake, efflux and interactions. Pharm 
Res 30:996–1007
	122.	 Eric S, Kalinic M, Ilic K, Zloh M (2014) Computational classification 
models for predicting the interaction of drugs with P-glycoprotein and 
breast cancer resistance protein. SAR QSAR Environ Res 25:955–982
	123.	 Gimadiev TR, Madzhidov TI, Marcou G, Varnek A (2016) Generative 
topographic mapping approach to modeling and chemical space visu-
alization of human intestinal transporters. BioNanoScience 6:464–472
Publisher’s Note
Springer Nature remains neutral with regard to jurisdictional claims in pub-
lished maps and institutional affiliations.


---

# Advanced machine-learning techniques in drug discovery

- **Authors:** Moe Elbadawi, Simon Gaisford, Abdul W Basit
- **Issuer:** Drug discovery today
- **Type:** Scientific article
- **Published:** 2020-12-05
- **Language:** en
- **DOI:** 10.1016/j.drudis.2020.12.003
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33290820/
- **Licence:** CC-BY

## Section: Abstract

The popularity of machine learning (ML) across drug discovery continues to grow, yielding impressive results. As their use increases, so do their limitations become apparent. Such limitations include their need for big data, sparsity in data, and their lack of interpretability. It has also become apparent that the techniques are not truly autonomous, requiring retraining even post deployment. In this review, we detail the use of advanced techniques to circumvent these challenges, with examples drawn from drug discovery and allied disciplines. In addition, we present emerging techniques and their potential role in drug discovery. The techniques presented herein are anticipated to expand the applicability of ML in drug discovery.


---

# Artificial intelligence and machine learning-aided drug discovery in central nervous system diseases: State-of-the-arts and future directions

- **Authors:** Sezen Vatansever, Avner Schlessinger, Daniel Wacker, H Ümit Kaniskan, Jian Jin, Ming-Ming Zhou, Bin Zhang
- **Issuer:** Medicinal research reviews
- **Type:** Scientific article
- **Published:** 2020-12-09
- **Language:** en
- **DOI:** 10.1002/med.21764
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33295676/
- **Licence:** CC-BY

## Section: Abstract

AbstractNeurological disorders significantly outnumber diseases in other therapeutic areas. However, developing drugs for central nervous system (CNS) disorders remains the most challenging area in drug discovery, accompanied with the long timelines and high attrition rates. With the rapid growth of biomedical data enabled by advanced experimental technologies, artificial intelligence (AI) and machine learning (ML) have emerged as an indispensable tool to draw meaningful insights and improve decision making in drug discovery. Thanks to the advancements in AI and ML algorithms, now the AI/ML‐driven solutions have an unprecedented potential to accelerate the process of CNS drug discovery with better success rate. In this review, we comprehensively summarize AI/ML‐powered pharmaceutical discovery efforts and their implementations in the CNS area. After introducing the AI/ML models as well as the conceptualization and data preparation, we outline the applications of AI/ML technologies to several key procedures in drug discovery, including target identification, compound screening, hit/lead generation and optimization, drug response and synergy prediction, de novo drug design, and drug repurposing. We review the current state‐of‐the‐art of AI/ML‐guided CNS drug discovery, focusing on blood–brain barrier permeability prediction and implementation into therapeutic discovery for neurological diseases. Finally, we discuss the major challenges and limitations of current approaches and possible future directions that may provide resolutions to these difficulties.

## Section: INTRODUCTION

Disorders of the central nervous system (CNS) are responsible for multiple disease states of significant economic and social impact. Despite huge progress in our understanding of the structure and functions of the CNS, the development of new drugs for CNS disorders poses unique challenges. CNS drugs have lower success rates than other drug classes due to multiple factors, including an insufficient understanding of the pathophysiology of complex CNS conditions, poor target selection/engagement, lack of efficacy in early stages of development, and the presence of a blood–brain barrier (BBB). Such challenges have led to significantly longer development time for CNS drugs, which is, on average, 15–19 years to advance from discovery to regulatory approval. 1 The whole process of developing a new drug generates a lot of data. Over the past decades, the advances in “omics” technologies, high‐throughput screening (HTS), and chemical synthesis have led to a dramatic increase in the amount of available data on chemical activity 2 and functional genomics. 3 , 4 As a result, how to efficiently combine, correlate, and analyze existing large‐scale data has become a crucial problem for CNS drug discovery.

Artificial intelligence (AI) concepts such as machine learning (ML) have the potential to accelerate pharmaceutical research by extracting novel and important information from the vast amount of complex data generated from the drug discovery process. In recent years, AI/ML‐based methods have been widely applied to many therapeutic areas and achieved state‐of‐the‐art performance in addressing diverse problems in drug discovery. Such applications of AI/ML algorithms also have shown promise in the development of CNS therapeutics—the most challenging area in drug discovery. However, we have only just begun to explore the potential of these technologies for discovering novel therapeutics and repurposing old ones for CNS diseases. Therefore, this review will focus on AI/ML‐assisted drug discovery applications in this promising direction.

Here, we provide an overview of recent developments and applications in AI/ML‐assisted drug discovery, particularly for CNS diseases. This review is intended for biomedical researchers who are curious about the potential of AI/ML for advancing CNS drug discovery and consider AI‐based tools in their research. We first provide a broad overview of AI/ML approaches in drug discovery and then review AI/ML solutions to the issues in drug discovery specific for CNS diseases. We start with a brief introduction to AI algorithms and their input molecular descriptors and then summarize AI/ML‐based methods in various stages of drug discovery, including target identification and characterization, virtual screening, lead discovery, and physicochemical pharmacokinetic property prediction. We further review recent AI/ML applications in de novo design, predicting drug sensitivity and response, drug synergy prediction, and drug repurposing. For CNS diseases specific drug discovery, we focus on AI/ML solutions to key challenges such as BBB permeability and introduce AI/ML‐assisted applications to neurological diseases, including neurodevelopmental disorders, depression, Parkinson's disease, Alzheimer's disease, anesthesia and pain treatment. We conclude the review by highlighting challenges, limitations, and future directions of AI/ML‐aided drug discovery, especially for CNS diseases.

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY

AI/ML has been utilized at three different stages of early drug discovery process, including target identification, lead generation and optimization, and preclinical development (Figure 1). In target discovery, AI‐based approaches have been used to integrate heterogeneous data sets to identify patterns so as to understand molecular mechanisms underlying diseases and drug activities. For lead generation and optimization, AI/ML algorithms improve the scoring functions and quantitative structure–activity relationship (QSAR) models in virtual screening pipelines and support the automation and optimization of the de novo drug design processes. In preclinical development, AI/ML approaches are employed to generate predictive models of physicochemical properties by efficiently processing large amount of chemical data and further optimize absorption, distribution, metabolism, and excretion—toxicity (ADME‐T) profiles.

AI/ML applications in the drug discovery pipeline. AI/ML approaches provide a range of tools that can be applied in all the three stages of early drug discovery to improve decision making and speed up the process. ADME, absorption, distribution, metabolism, and excretion; AI, artificial intelligence; ML, machine learning; QSAR, quantitative structure–activity relationship

AI‐related learning techniques used in drug discovery

The basic steps of building an artificial intelligence (AI) platform for drug discovery. The process for developing an AI model as follows: (1) Define the problem appropriately (objective, desired outputs, etc.), (2) prepare the data (collection, exploration and profiling, formatting, and improving the quality), (3) transform raw data into features and select meaningful features (a.k.a. feature engineering), (4) split data into training and validation sets, (5) develop a model, (6) train the model with a fraction of the data, test its performance (cross‐validation) and tune its parameters with the validation set (7) evaluate model performance on the validation set and refine the model, and (8) evaluate the model on independent data not used for method development

AI‐guided target discovery. AI/ML methods can efficiently analyze all available information to speed up the discovery of disease‐related drug targets. Specifically, AI/ML methods are utilized for disease subtyping, identification of disease driver genes and microRNAs, alternative splicing prediction, triaging of novel drug targets, modeling of three‐dimensional target structures, and druggability assessment. AI, artificial intelligence; ML, machine learning

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › Overview of the AI/ML algorithms

To help the reader better understand AI/ML applications in CNS drug discovery, we provide a summary of AI‐based algorithms that are widely used in drug discovery. AI uses a large variety of models to build up intelligent systems, which can be classified by learning procedures. AI is frequently used to denote ML algorithms—yet they are not the same. So, it would be worth clarifying both terms at first. In this review, we follow the US Food and Drug Administration's (FDA) definition of AI. They describe AI as “the science and engineering of making intelligent machines”, while ML is “an artificial intelligence technique that can be used to design and train software algorithms to learn from and act on data”, 5 adding that all ML techniques are AI techniques, but not all AI techniques are ML techniques. Here, we provide brief definitions of the basic learning algorithms in Table 1, as these are most relevant in the context of drug discovery. AI‐related learning techniques are broadly categorized as supervised, unsupervised, semisupervised, active, reinforcement, transfer, and multitask learning. Different algorithms are used in those learning architectures to perform specific tasks such as classification or clustering. However, success with AI requires more than training an AI model. A robust AI workflow involves (i) formulating a problem, (ii) preparing data, (iii) extracting features, (iv) selecting training and testing data sets, (v) developing a model, (vi) training the model and testing its performance (cross‐validation), and (vii) applying the model to testing data sets and refining the model. Figure 2 displays the basics steps of building an AI architecture.

AI‐related learning techniques used in drug discovery

The basic steps of building an artificial intelligence (AI) platform for drug discovery. The process for developing an AI model as follows: (1) Define the problem appropriately (objective, desired outputs, etc.), (2) prepare the data (collection, exploration and profiling, formatting, and improving the quality), (3) transform raw data into features and select meaningful features (a.k.a. feature engineering), (4) split data into training and validation sets, (5) develop a model, (6) train the model with a fraction of the data, test its performance (cross‐validation) and tune its parameters with the validation set (7) evaluate model performance on the validation set and refine the model, and (8) evaluate the model on independent data not used for method development

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › Molecular descriptors and fingerprints for input data preparation

A key consideration in early drug discovery is to identify drug candidates with the desirable initial characteristics, which are then further developed into chemical structures with the desirable potency against the target molecule. Molecular descriptors and fingerprints are used for quantifying such physicochemical characteristics of both chemical entities and their biological target molecules. Molecular descriptors are experimentally quantified or theoretically characterized properties of a corresponding molecule that represent the physical, chemical, or topological characteristics, while molecular fingerprints are more complex descriptors that are encoded as binary bit strings. 6 , 7 Both molecular descriptors and fingerprints have crucial functions in ML‐based applications in drug discovery processes such as target molecule ranking, 8 , 9 similarity‐based compound search, 10 , 11 , 12 , 13 , 14 , 15 virtual screening, 16 , 17 QSAR analysis, 18 , 19 ADME‐T prediction of lead molecules. 20 , 21 , 22 , 23

There are various tools for molecular descriptor and fingerprint calculation, and each has a different set of features. Here, we explain the molecular descriptors (i.e., target protein descriptors and compound descriptors) and compound fingerprints, and provide the highly used programs for generating them (i.e., sequence‐based tools and structure‐based tools) in the Supporting Information. Additionally, Chuang et al. 24 comprehensively discussed how AI‐based methods (i.e., deep learning [DL]) could address limitations of molecular descriptors and fingerprints and thereby improve the predictive modeling of compound bioactivities.

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › AI/ML applications in target identification

A dominant approach to drug discovery is to design drug molecules that will reverse a disease course by modulating the activity of a target. 25 Drug development often begins with identification of a novel target whose modulation can lead to a therapeutic benefit with an acceptable safety margin. This is followed by validating the role of the selected target in disease in in vivo models and, ultimately, in clinical trials. Therefore, the ultimate success of a drug development project depends on early identification of promising drug targets.

A good drug target need be relevant to the disease phenotype as well as be suitable for therapeutic modulation (“druggable”). Biological and technological advances have continuously driven the generation of high‐throughput biomedical data, which present new opportunities for early identification of potential drug targets. However, the analysis of such large‐scale multidimensional biological data requires effective techniques that can produce accurate predictions for target identification. AI/ML has emerged as a powerful technology for analyzing the rapidly increasing multiomics data in the identification of potential therapeutic targets.

In literature, the “target identification” term is often used in two different contexts: Target discovery and target deconvolution. 26 The first is the discovery of a new disease target whose modulation would have therapeutic effects. The second is the identification of a target with a known active compound, which is also called “target fishing.” To avoid confusion, we will use context‐specific terms of target discovery and deconvolution rather than generic target identification.

AI‐guided target discovery. AI/ML methods can efficiently analyze all available information to speed up the discovery of disease‐related drug targets. Specifically, AI/ML methods are utilized for disease subtyping, identification of disease driver genes and microRNAs, alternative splicing prediction, triaging of novel drug targets, modeling of three‐dimensional target structures, and druggability assessment. AI, artificial intelligence; ML, machine learning

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › AI/ML applications in target identification › Target discovery

Drug discovery begins with the identification of a novel target candidate that is followed by a target evaluation consisting of experimental target validation and theoretical assessment of its ability to bind small molecule drugs (druggability). 27 The target discovery process includes identification of targets that play a role in the disease pathophysiology, 28 assessment of druggability, and prioritization of candidate targets. However, because of the complex nature of human diseases, this process often requires more comprehensive approaches that integrate available heterogeneous data and information to understand the molecular mechanisms underlying disease phenotypes and identifying the patient‐specific changes. 29 To overcome such difficulties, researchers have applied AI/ML methods to predict “reliable” drug targets. The following sections demonstrate the AI/ML applications in different stages of the target discovery process (Figure 3).

AI‐guided target discovery. AI/ML methods can efficiently analyze all available information to speed up the discovery of disease‐related drug targets. Specifically, AI/ML methods are utilized for disease subtyping, identification of disease driver genes and microRNAs, alternative splicing prediction, triaging of novel drug targets, modeling of three‐dimensional target structures, and druggability assessment. AI, artificial intelligence; ML, machine learning

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › AI/ML applications in target identification › Target discovery

In complex heterogeneous diseases, classifying patients into clinically and biologically homogenous subtypes is critical for understanding disease pathophysiology and developing appropriate subtype specific therapies. 30 Researchers have developed AI/ML algorithms that can integrate multiscale data to identify different etiological subtypes of complex diseases. For example, Shen et al. 31 developed iCluster, a joint latent variable model for integrative clustering analysis, which was applied to breast cancer and lung cancer and identified subtypes characterized by concordant DNA copy number changes and gene expression. 31 Yuan et al. 32 also integrated copy number variation and gene expression data by using a nonparametric Bayesian model and discovered prognostic subtypes in prostate cancer and breast cancer. 32 Zhang et al. 33 revealed the prognostic subtypes in neuroblastoma using DL‐based integration of multi‐Omics data and K‐means clustering analysis. Recently, Gao et al. 34 described a cancer classification method, deep cancer subtype classification (DeepCC), based on DL of functional spectra, which is a vector of gene set enrichment scores associating with biological functions for each patient sample. Overall, in recent years, AI/ML methods have been employed to analyze large‐scale genomic and other molecular profiling data in cancer for the identification of distinct, molecular disease subtypes. However, such AI‐based subtyping analysis have not been widely applied to other complex diseases. Implementation of robust and scalable AI/ML techniques for discovery of disease subtypes paves the way for developing more efficacious therapeutic strategies.

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › AI/ML applications in target identification › Target discovery

One of the most challenging tasks in target discovery is the prediction of disease‐causing genes from huge amount of genetic and functional genomic data. To predict these disease‐associated genes from multiomics data, researchers have employed various ML classifiers, 35 , 36 , 37 , 38 including Random Forest (RF)‐, 39 , 40 support vector machines (SVM)‐, 41 , 42 and decision tree (DT)‐based classifiers. 43 More detailed information about those applications can be found in the Supporting Information. Besides the ML‐methods using multiomics data, DriverML, 44 a supervised learning tool, identified cancer driver genes based on DNA sequence alterations from The cancer Genome Atlas (TCGA) data with superior performance over the other tools such as DriverDBv2 database. 45

In addition to ML classifiers, DL‐based methods have been implemented in more recently developed tools. For example, deepDriver 46 trained similarity networks and a convolutional neural network (CNN) on mutation data simultaneously to predict driver genes with better performance than the competing approaches when applied in breast cancer and colorectal cancer. In another example, Peng et al. 47 used deep neural network (DNN) to reduce the dimensionality of transcriptomics data to predict Parkinson's disease genes. This DNN‐based tool, namely, N2A‐SVM, consists of three steps, including extraction of vector representation of each gene in the protein–protein interaction (PPI) network, dimension reduction for the obtained vector with autoencoder, and prediction of the genes associated with Parkinson's disease using SVM.

Multitask learning has also been employed for the prediction of cancer driver genes. LOTUS, an ML‐based algorithm, predicts cancer driver genes in a pan‐cancer setting, as well as for specific cancer types, using a multitask learning strategy sharing information across cancer types. 48 For the readers who want to learn more about opportunities and challenges in predictive modeling for multiomics data sets, we suggest the review paper of Kim and Tagkopoulos. 49

Different from the tools using omics data sets, BeFree 50 was developed to extract relations between genes and diseases from text mining. This supervised learning approach utilized natural language processing (NLP) Kernel methods to identify gene–disease associations from the abstracts collected by Medline.

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › AI/ML applications in target identification › Target discovery

The challenges in targeting disease proteins have shifted the focus in target selection to disease microRNAs (miRNAs), which are small noncoding RNAs that regulate gene expression by targeting messenger RNAs. 51 miRNAs are regarded as high‐potential drug targets due to their involvement in various diseases. 52 Therefore, considerable effort has been devoted in identifying relationships between miRNAs and diseases using ML‐based methods, such as the network based approach by Xu et al. 53 , 54 and RLSMDA. New strategies in miRNA target discovery have utilized neural networks (NN). Zeng et al. 55 developed a NN method, NNMDA to predict miRNA‐disease associations with the best performance among the existing algorithms. Application of NNMDA to lung neoplasm and breast neoplasm predicted novel disease‐related miRNAs. Very soon after that, Zheng et al. 56 published a new ML‐based method, MLMDA, which predicts miRNA–disease associations by integrating miRNA sequence, disease semantics, miRNA–disease association, and miRNA function but with slightly worse performance than NNMDA.

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › AI/ML applications in target identification › Target discovery

Alternative splicing (AS) plays a fundamental role in gene expression regulation and protein diversity by causing the generation of different transcripts from single genes. 57 Understanding the genetic variation in splicing signals is within the scope for AI/ML‐based models to discover therapeutic opportunities through novel targets. For splicing prediction and analysis, a web tool, AVISPA, 58 has been developed. For a given exon and its proximal sequence, AVISPA predicts if the exon is alternatively spliced and if it has associated regulatory elements by using a Bayesian NN classifier. However, the method by Leung et al. 59 outperformed the Bayesian NN approach for predicting AS by developing a DNN model inferred from mouse RNA‐Seq data that can predict splicing patterns in individual tissues and differences in splicing patterns across tissues. Later, Jha et al. 60 compared those two previous modeling approaches, Bayesian and Deep NN, and determined the confounding effects of data sets and target functions. On the basis of this knowledge, they developed a new target function for AS prediction with higher accuracy. For further improvement of the prediction, they developed a modeling framework that uses transfer learning to combine CLIP‐Seq, knockdown, and overexpression experiments. For enabling the usage of unlabeled data and the latent information, Stanescu et al. 61 applied semisupervised learning algorithms to AS prediction. Xiong et al. 62 built up a DL model trained to predict splicing from DNA sequence alone and successfully identified new autism‐linked genes.

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › AI/ML applications in target identification › Target discovery

While increasing effort has been devoted to nominating novel drug targets involved in diseases, experimental validation of identified target candidates is an expensive and time‐consuming task. 63 Therefore, researchers have utilized AI/ML approaches to support the prioritization of the most promising target candidates for subsequent experiments. To identify and prioritize novel cancer drug targets, Jeon et al. 64 built an SVM classifier that uses features from various data types (DNA copy number, messenger RNA expression, mutation occurrence, and PPI) to prioritize drug targets specific for breast, pancreatic and ovarian cancers. To improve the disease gene prioritization process, Valentini et al. 65 combined different functional gene networks and applied a kernel‐based method to prioritize genes according to the disease MeSH terms. Then, Ferrero et al. 66 took advantage of the publicly available target–disease association data from the open targets platform training an NN classifier with semisupervised learning and predicted novel therapeutic targets. As another publicly available data source, Medline abstracts also have been benefited for developing prediction tools (i.e., DigSee 67 ) that identify disease–gene relationships and prioritize the genes based on evidence. Specifically, DigSee uses NLP to extract the relationship between diseases and genes and ranks the evidence sentences with a Bayesian classifier. Recently, Arabfard et al. 68 predicted and prioritized over 3,000 candidate age‐related human genes using three positive unlabeled learning algorithms, Naïve Bayes, Spy, and Rocchio‐SVM. They ranked the human genes according to their implication in aging based on binary gene features from 11 human biology databases. 68

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › AI/ML applications in target identification › Target discovery

AI/ML architectures have been applied in protein structure prediction over 30 years, and several groups have comprehensively reviewed those strategies. 69 , 70 , 71 , 72 , 73 Therefore, we will focus on recent applications in this field. Also, we provide a background of conventional protein structure prediction methods (i.e., template‐based and template‐free) for those who want to learn more about this field in the Supporting Information.

Since 1994, the Critical Assessment of protein Structure Prediction (CASP) competitions have been organized biannually for blind evaluation of the state‐of‐the‐art methods that predict three‐dimensional (3D) protein structures from protein sequences. There, each group submits structure predictions for each of the given protein sequences for which experimentally determined structures were sequestered. In December 2018, Google's AI firm DeepMind won the CASP13 competition with its latest AI system, AlphaFold. DeepMind's success generated significant interest in the protein folding community, where the researchers published several articles discussing the method. 74 , 75 , 76 , 77 AlphaFold determines the 3D shape of a protein from its amino acid sequence by merging two approaches: (i) Inferring physical contact in protein structure from residue covariation in protein sequence based on coevolution analysis of a multiple sequence alignment and (ii) identifying coevolutionary patterns in protein sequences as contact distributions by using DNNs and convert them into protein‐specific statistical energy potentials. AlphaFold system has achieved an unprecedented prediction accuracy among the ab initio methods. Although AlphaFold's performance represents a big leap in protein structure prediction, its accuracy still needs to be improved.

Inspired by AlphaFold as well as previous successful applications of DL to residue contact predictions, 78 researchers have developed different strategies to improve the protein structure prediction, including a deep residual network model, 79 a fragment library that is built using deep contextual learning techniques called DeepFragLib 80 and a community‐built, open‐source implementation of Alphafold (i.e., ProSPr). 81 The emergence of DL has suggested the rethinking of how to address the problem of protein structure and thereby, encourages the new approaches. RGN (recurrent geometric network) is an end‐to‐end differentiable model that takes a sequence of amino acids and position‐specific scoring matrices (a summary of residue propensities for mutation) as inputs and outputs a 3D structure. In contrast to the complexity of conventional structure prediction models, a trained RGN model is a single mathematical function that is evaluated once per prediction. Hence, a trained RGN makes predictions six to seven orders of magnitude faster than other methods. The same lab developed the RGN also published a data set to provide a standardized resource for training and assessing ML frameworks for predicting protein structures. The data set called ProteinNet integrates sequence, structure, and evolutionary information into preformatted input/output records. ProteinNet is available in a public repository, https://github.com/aqlaboratory/proteinnet.

Going beyond the structure prediction, researchers have employed the ML for the prediction of protein dynamics since target proteins are dynamic and sample multiple states. Ung et al. 82 used RF to classify pharmacologically relevant conformations of protein kinases. Using a 3D‐CNN, Okuno et al. 83 developed DEFMap, which extracts the dynamics information hidden in a given cryo‐EM density map. This approach allows us to grasp the dynamic changes associated with molecular recognition and the accompanying conformational selections from the cryo‐EM structure, which derive insights into the protein function as well.

The studies discussed above clearly demonstrate the utility of the AI/ML frameworks to make predictions of protein structural features from sequence alone. Rost et al. 84 comprehensively discussed how ML algorithms help to understand the effects of protein sequence variants on protein function and pathways. AI/ML algorithms are readily available for structural biologists to quickly estimate protein structures. Of course, the accuracy and speed of a framework will depend on the creativity in problem formulation, network design, and data storage. We can look forward to a rapid growth in the number of AI/ML applications in the prediction of protein structures.

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › AI/ML applications in target identification › Target discovery

In target discovery, another crucial step is the evaluation of the target's druggability, “the likelihood of being able to modulate a target with a small‐molecule drug”. 85 In drug design, a selected target must have the biophysical properties that allow it to bind small molecules with drug‐like properties. ML‐based models usually estimate a target's druggability by using different features of it. As one of the earliest applications, SCREEN (Surface Cavity REcognition and EvaluatioN) webserver 86 was built based on an RF classifier trained on geometric, structural, and physicochemical features of drug‐binding and nondrug‐binding cavities on proteins. The classification process reveals that the most critical attributes to estimate druggability are the size and shape of the surface cavities of the protein. In the following studies, SVMs were applied to predict druggable targets based on various physicochemical properties from protein sequences. 87 , 88 Then, Costa et al. 89 constructed a DT‐based meta‐classifier by training on attributes including network topological features, tissue expression profile, and subcellular localization for each druggable and nondruggable gene. Later, Wang et al. 90 combined a biased SVM with a DL model, stacked autoencoders, to identify drug target proteins based on the sequence information of proteins. Recently, Kokh et al. 91 developed an ML tool for the druggability analysis of binding pocket variations during the protein movement. They used a logistic regression model and a CNN to identify potentially druggable protein conformations in trajectories from molecular dynamics simulations. On the contrary, Dezső and Ceccarelli 92 built up RF models for the druggability prediction of oncology drug targets to prioritize proteins according to their similarity to approved drug targets. More details on ML‐based tools designed to predict the druggability of targets can be found in the review from Kandoi et al. 93

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › AI/ML applications in target identification › Target deconvolution

Target deconvolution (a.k.a. target fishing) is an important step following the discovery of compounds that cause a desirable change in phenotype. Understanding the binding targets of phenotypic screen‐derived compounds can help design better analogs, find potential off‐targets, and thereby explain observed adverse events. However, existing experimental approaches for target deconvolution are labor, resource, and time‐intensive. Researchers have adapted computational approaches to target deconvolution problems to reduce the required sources for the experiments. Several studies implemented AI/ML algorithms into computational target deconvolution tools for higher predictive power. For example, Schneider and colleagues have widely applied self‐organizing maps (SOMs) to predict the macromolecular targets of compounds. 94 , 95 , 96 , 97 They preferred to use “fuzzy” molecular representations, such as pharmacophoric feature descriptors, since such fuzzy molecular representations demonstrated greater scaffold‐hopping potential than atomistic approaches in similarity searches. On the basis of the similarity of pharmacophoric features, their unsupervised SOM algorithm clustered the query molecules with unknown targets as well as drug‐like molecules with known targets. Hence, the trained SOM was able to transfer the knowledge of annotated drug targets to query molecules that are the nearest neighbors to known drugs. 94 They have applied this SOM approach to identify the macromolecular targets of de novo‐designed molecules, 95 complex natural products, 94 fragment‐like natural products, 96 and a natural anticancer compound. 97 Besides the SOM models, a multiple‐category Naïve Bayesian model was developed for the rapid identification of potential targets for compounds based on only chemical structure information, which is the connectivity fingerprints of compounds from 964 target classes in the WOMBAT (World Of Molecular BioAcTivity) chemogenomics database. 98 Moreover, a target‐fishing server named RF‐QSAR was built based on target SAR models that were created using an RF algorithm to rank candidate targets for a query compound. 99 A recent target identification tool, BANDIT, 100 uses a Bayesian approach to integrates six distinct data types—drug efficacies, posttreatment transcriptional responses, chemical structures, reported side effects, bioassay results, and known targets.

In the identification of the novel targets of drugs, there has been increasing interest in predicting drug–target interaction (DTI), given its relevance for side effect prediction and drug‐repositioning attempts. 101 The availability of heterogeneous biological data on known DTI has enabled the development of various AI/ML‐based strategies to exploit unknown DTI, 102 including ensemble learning, 103 , 104 , 105 , 106 tree‐ensemble learning, 107 active learning, 108 DL, 109 end‐to‐end DL, 110 and kernel‐based learning. 111 , 112 , 113 , 114 , 115 Such AI/ML‐enabled data integration strategies outperform the traditional methods in classifying both positive and negative interactions, 110 improved the quality of the predicted interactions, and expedited the identification of new DTI. 115

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › AI/ML applications in compound screening and lead discovery

To identify new compounds with potential interactions to target proteins, researchers commonly use HTS, an in vitro method that automatically tests large compound libraries towards a specific target. However, high cost and low hit rate of HTS have expedited the development of virtual screening (VS) alternatives, which enable cheaper and faster screening of larger compound libraries. 116 , 117 VS predicts the compounds that most likely to bind to a protein of interest using various approaches. Two broad categories of VS are structure‐based VS (SBVS) and ligand‐based VS (LBVS)—the former takes the structures of target proteins as input, 118 , 119 and the latter uses information on known inhibitors. 120 LBVS is basically “analoging” to some extent based on that similar molecules tend to exhibit similar properties, 121 and it also helps to build better pharmacophore models. SBVS and LBVS are often used synergistically: Leads from SBVS can be improved with LBVS, and data from improved yields can be used to refine models for SBVS. 122 For achieving better performance in VS workflows, AI/ML‐based methods have been utilized for both SBVS and LBVS. We will begin with the application of AI/ML methods in SBVS and continue with their applications in LBVS in the next section.

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › AI/ML applications in compound screening and lead discovery › Structure‐based virtual screening

SBVS requires the 3D structure of a target protein to predict whether a compound is likely to bind the target. One widely used method to do this is molecular docking, which models the protein–ligand complex based on the estimated interaction energy. In recent years, ML methods have been employed in SBVS workflow to increase the robustness and accuracy of scoring functions (SFs), conformational sampling and ranking. Researchers have developed SFs using RF‐, 123 , 124 , 125 , 126 SVM‐, 127 , 128 and NN‐ 129 , 130 , 131 , 132 , 133 , 134 based learning algorithms and they outperformed the conventional SF predictions. 135 However, no ML‐based SF is superior to all the other approaches in all respects. 136 Indeed, the performance of an SF differs from target to target. 137 Therefore, researchers have developed ML‐based, target‐specific SFs to improve the efficiency of existing SFs for kinases, 138 , 139 , 140 , 141 histone methyltransferases, 142 cyclin‐dependent kinases and G protein‐coupled receptors (GPCRs), 137 and cytochrome P450 aromatase. 143

Moreover, such ML‐based models have been applied to post‐docking processes to improve the accuracy of molecular docking. For example, ML algorithms 142 , 144 , 145 , 146 , 147 , 148 improve pose/compound selection by automating the evaluation of docked ligands, which was done manually before. 149 Details about ML‐based scoring functions and AI/ML applications in the post‐docking stage can be found in the Supporting Information.

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › AI/ML applications in compound screening and lead discovery › Ligand‐based virtual screening

When the 3D structure of a given target is available, SBVS approaches (i.e., molecular docking) can be employed. However, LBVS methods are the only option if the 3D structure of the target protein is not known. In contrast to the molecular docking that predicts the binding pose of ligands to the target protein using the protein structure, LBVS is based on the principle that ligands structurally similar to an active compound tend to have similar activity. 150 Hence, LBVS requires the information of known active compounds rather than the target protein structure. In drug discovery efforts, researchers often have a set of active compounds generated from testing molecules in biochemical or functional assays without knowing the target protein structure. In such cases, the LBVS approach can be utilized to find new ligands by assessing the structural similarity of candidate ligands to the known active compounds. The challenge is thereby to find an appropriate model for similarity that relates compound features to assay outcomes. In recent years, ML has emerged as an attractive approach to boost the predictive power of LBVS models. The specific aims of ML approaches include prediction of the active compounds against a particular target using models trained on input data sets, discrimination of drug modules from nondrug ones, and prioritization of compounds based on the probability of activity. For these purposes, researchers have used SVMs, Bayesian architectures, and artificial neural networks (ANNs) (Table S2). Further information regarding AI/ML applications in LBVS is available in some comprehensive review papers. 136 , 151 , 152

On the contrary, one of the most recent advances in AI/ML‐based LBSV was made by Stokes et al. 153 They successfully discovered new antibiotics by employing graph convolutional networks (GCN), whose outstanding performance over conventional ML models in predicting molecular properties was confirmed by two studies. 154 , 155 Using their GCN model, the authors performed a large‐scale screening and identified a promising new antibiotic, halicin. 153

In conclusion, the advances in selection and design of AI/ML algorithms for LBVS and the availability of large bioactivity data sets have enabled more accurate and faster selection of compounds that are predicted to be active against a particular target and will undergo further experimental assays eventually. Although traditional ML classifiers had been widely used in LBVS, recent successful applications have shown GCN's potential to become a popular approach for LBVS. 151

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › AI/ML applications in compound screening and lead discovery › QSAR prediction

QSAR models are developed to identify a mathematical relationship between the physicochemical properties, which are represented by molecular descriptors, and biological activity of chemicals. These models play a prominent role in drug optimization, providing a preliminary in silico evaluation of essential attributes related to the activity, selectivity, and toxicity of candidate compounds. 156 , 157 , 158 By doing that, they significantly reduce the number of candidate compounds to be tested by in vivo experiments. QSAR models can be based on regression or classification models that depend on the underlying computational strategy. AI/ML approaches (i.e., RF, 159 , 160 SVM, 161 , 162 , 163 Naïve Bayesian, 164 , 165 , 166 , 167 , 168 , 169 , 170 , 171 , 172 , 173 and ANN 143 , 174 , 175 , 176 , 177 , 178 , 179 , 180 , 181 , 182 , 183 , 184 ) have been extensively employed in QSAR modeling (For the detailed discussion of the applications, see the Supporting Information). Notably, the RF algorithm is commonly used as a classification and regression tool 159 and considered to be the golden standard in QSAR studies. 185 Hence, the performance of new QSAR prediction tools often is compared with that of RF. Many RF‐based QSAR models have been developed, such as pQSAR, 186 a method for the soluble epoxide hydrolase, 187 and a model for Janus kinase 2. 188 When the predictive performance and interpretability of RF‐based QSAR models are compared to those of two widely used linear modeling approaches—SVMs and partial least‐squares, RF not only yields better predictive performance but also enables an amenable chemical and biological interpretation. 189

In the applications of NN to QSAR prediction, researchers use the data from a single assay using molecular descriptors as input to train an NN and record activities as training labels. However, the efficiency of those simple single‐task NN models depends on having sufficient training data in a single assay. To benefit from the data obtained from multiple assays, researchers aim to develop multitask QSAR models. Several groups constructed the multitask learning structures based on plain feed‐forward NN to avoid overfitting by learning multiple bioassays simultaneously. 190 , 191 , 192 , 193 , 194 , 195 , 196 Moreover, multitask QSAR models were also utilized for predicting the activity against multiple targets. 197 , 198 , 199

In 2012, a data science competition (www.kaggle.com/c/MerckActivity) was organized to find state‐of‐the‐art methods for QSAR. Using multitask DNNs, the winning team improved the prediction accuracy by 15% over the baseline RF method. 200 Since its introduction into the QSAR modeling, 159 RF has served as a “golden standard” and no QSAR methods other than DNNs outperform it. On the contrary, in the following DREAM challenges on predicting kinase‐drug‐binding, 201 the models based on DL algorithms did not perform better than the other learning algorithms. 202 In the next study, using the DNNs, Ma et al. 185 showed that DNNs could make better prospective predictions than RF, on large and diverse QSAR data sets. However, they could not propose a clear strategy for choosing between multitask and single‐task DNNs. Xu et al. 203 focused on demystifying multitask DNNs and explored why multitask DNNs perform significantly better or worse for some QSAR tasks. They found that multitask DNNs can boost the predictive performance if the assistant tasks have molecules in a training set with structures similar to those in the test set of the primary task and the activities between these similar molecules are correlated. Contrarily, if the assistant tasks do not include compounds structurally similar to those in the primary task test set, multitask DNNs show no improvement in prediction, regardless of correlated or uncorrelated activities. Recently, Zakharov et al. 204 combined multitask DNNs with consensus modeling to generate large‐scale QSAR models with improved prediction accuracy over the state‐of‐the‐art QSAR models.

Ensemble‐based ML approaches combining several basic models have also been used to overcome the weaknesses of individual learning models and thereby improve the overall performance of the QSAR predictors. There are various ensemble learning applications in QSAR predictions, including data sampling ensembles, method ensembles, and representation ensembles. Recently, Kwon et al. 205 proposed a model that is a combined ensemble of sampling, method, and representation with an end‐to‐end NN‐based individual classifier. Their ensemble model achieved better performance than the individual models in QSAR prediction.

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › AI/ML applications in prediction of physicochemical properties and ADME‐T › Prediction of physicochemical properties

Physicochemical properties indicate all aspects of drug action and profoundly affect the clinical success rates of drug candidates. A small molecule drug candidate must be sufficiently soluble and permeable to access its site of action and thereby engage its targets, with optimal safety profiles. Therefore, accurate prediction of the physicochemical characteristics can be beneficial for designing a new chemical entity with suitable pharmacokinetic and pharmacodynamic profiles. Researchers have adopted ML‐driven approaches to predict some key physicochemical properties, such as water solubility, membrane permeability, and lipophilicity. We provide a detailed description of each property and discuss the ML‐based techniques that specifically predict the water solubility, 206 , 207 , 208 , 209 , 210 membrane permeability, 211 , 212 , 213 and lipophilicity 214 , 215 , 216 , 217 , 218 , 219 in the Supporting Information. Although improved ML models have led to better prediction of molecular properties, the lack of standard criteria for performance evaluation has limited the progress. To address this, MoleculeNet, a benchmark collection for molecular ML was developed to serve as a unique resource for the scientific community to create advanced models for learning molecular properties. 154 To further support the comparison and development of novel models, MoleculeNet has implemented various ML algorithms. Benchmark results have shown that graph convolutional network (GCN) outperforms other traditional ML methods based on molecular fingerprints and descriptors to predict molecular properties. Recent studies have supported the superior performance of GCN. Applying GCN, Feinberg et al. 155 achieved an unprecedentedly high accuracy in predicting molecular physicochemical properties.

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › AI/ML applications in prediction of physicochemical properties and ADME‐T › ADME‐T predictions

A successful drug development pathway must include the evaluation and optimization of pharmacokinetics, pharmacodynamics, and safety profiles of a candidate molecule. In early drug discovery, evaluation of the ADME‐T properties help researchers select good drug candidates for further development. ADME‐T properties are estimated to be responsible for half of all clinical failures. 220 In this context, in silico ADME‐T prediction models have received considerable progress over the past 40 years due to the availability of many compounds with known pharmacokinetic properties. 23 , 221 Prediction models usually try to build a direct relationship between a set of molecular descriptors and a given ADME‐T property. 222 These methods represent a compound by chemical descriptors as input features such as atom counts, surface areas, weight, van der Waals volume, partial charge information, and the presence or absence of a predefined substructure. The key substructures responsible for certain toxicity are structural alerts, of which detection in given small molecules could be used for toxicity prediction. 223 On the contrary, in these models, the toxicity properties of input compounds are HTS assay measurements of toxic effects that are highly relevant to human health, including nuclear receptor pathway assays (i.e., aryl hydrocarbon receptor, aromatase, androgen and estrogen receptor, PPAR‐gamma) and stress response pathway assays (i.e., ATAD5, antioxidant responsive element, heat shock factor response element, mitochondrial membrane potential, p53). 224 While the conventional approaches have yielded physiologically based pharmacokinetic and pharmacokinetic‐pharmacodynamic/quantitative systems pharmacology models, researchers have applied AI/ML algorithms to produce high‐quality models with improved accuracy and thus provide meaningful predictions of ADME‐T responses using chemical structure information. For predicting regulators of drug ADME‐T properties, the classification models—DT, K‐nearest‐neighbor (KNN), SVM, RF, and NN have been extensively used. Even beyond that, the introduction of DL models has led to further developments in this area. As a good example of recent advancements in AI. ML‐aided ADME‐T prediction, Alchemite 225 —a DL model—predicts ADME‐T properties by imputing heterogeneous drug discovery data, including multitarget biochemical activities, phenotypic activities in cell‐based assays, and ADME‐T endpoints.

Moreover, the introduction of capsule networks, a new class of DNN architectures, has remarkably improved the ADME‐T prediction. To predict the cardiotoxicity of drugs, Wang et al. 226 developed two capsule network architectures, including a convolution‐capsule network (Conv‐CapsNet) and a restricted Boltzmann machine‐capsule network (RBM‐CapsNet). Both models showed excellent performance with an accuracy of 91.8% for Conv‐CapsNet and 92.2% for RBM‐CapsNet. As the volume and chemotype coverage of the available ADME‐T databases are continually growing, we have witnessed a great progress in AI/ML‐guided ADME‐T prediction in recent years. Such advances in the field have been extensively reviewed. 136 , 227 , 228 , 229 , 230 , 231 , 232

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › AI/ML applications in de novo drug design

In de novo drug design, scientists generate novel chemical entities with desired chemical and biological characteristics from scratch, aiming to achieve particular efficacy and safety profiles in a cost‐ and time‐efficient manner. Advanced AI/ML‐based tools have enabled the automated generation of new chemical entities with suitable properties. As a result of such achievements, application of AI/ML to de novo discovery has become a popular topic over the last few years. Particularly, generative molecular design based on AI/ML has aroused considerable attention. In this section, we summarize the AI/ML algorithms utilized for de novo drug design with a focus on generative models. Those who want to learn more about this subject can check other comprehensive sources in the literature. 136 , 233 , 234

Traditional methods for generating novel chemical structures depend on the previously defined reaction or transformation rules, which bias the chemical space towards prior chemical knowledge. AI/ML‐based generative models are entirely data‐driven without relying on any explicit rules and can generate new molecules that are not present in a training set. Briefly, these generative models first learn from data, then create an abstract representation of the data, and finally use this representation to generate new data instances. 235 Thus, these generative models demonstrate all aspects of an artificially intelligent system (i.e., problem‐solving, learning from experience, and coping with new situations). 235

Recent de novo molecule‐generative models with an ML structure include adversarial autoencoders (AAE), 236 , 237 , 238 variational autoencoders (VAE), 239 , 240 and recurrent neural networks (RNN). 241 , 242 , 243 , 244 In generating novel molecules represented by simplified molecular input‐line entry system (SMILES) strings, RNN is a promising approach for learning from large sets of SMILES strings and generating ligands with similar activities to those of the training set templates, but with novel scaffolds. However, the percentage of valid SMILES, internal diversity, and the similarity of molecules to the training data set in the libraries generated by any given approach have been a matter of debate. To address these issues, Reinforcement learning (RL) has been embedded in ML architectures. 239 , 245 , 246 , 247 , 248 Introducing a task‐specific reward function, RL‐assisted models are able to produce chemically feasible and predominantly novel molecules with appropriate molecular properties. For the generation of novel small molecules with the desired characteristics, generative adversarial networks (GAN) also have been employed. For example, druGAN 237 (drug‐generative adversarial network) has been developed for producing new molecules with specific anticancer properties.

Another commonly used drug design approach is to generate new analogs/similar drugs of a given set of drugs. In such cases, the transfer learning models have been integrated into NN architectures to increase the prediction accuracy by taking knowledge acquired from training on a previous problem and applying them to a new but related problem. 249 , 250

In the generative drug design models above, many ML architectures use the SMILES as molecular representation. SMILES provides a linear representation, referred to as a SMILES string that can be translated into a graph and enables a straightforward application. However, it has one or more limitations: Generated SMILES may not represent a chemically feasible structure, and even a single character alteration in a SMILES representation can change the underlying molecular structure significantly. 251 To overcome its limitations, researchers proposed several solutions like converting SMILES strings into a new SMILES‐like syntax 252 or utilizing grammatical evaluation of the SMILES syntax. 253 Besides the SMILES string representation, molecular graphs have also been used to train ML‐based molecule generation algorithms. 254 In molecular graph generators, structures are directly represented as graphs in every step and substructures are inferred from the partially generated molecular graphs. 255 Examples of such ML models to design de novo molecules based on graph representation includes GANs 256 , 257 and VAEs. 258 , 259

In addition to the models mentioned above, some AI/ML‐driven de novo molecule design tools are distinguished by introducing novel approaches. An automated de novo molecular design tool, DINGOS, 260 has been developed to emulate the approach of a synthetic chemist. It assembles drug‐like new compounds through modular and synthetically feasible design schemes, considering the synthetic feasibility of each step. In brief, the DINGOS algorithm combines a rule‐based approach with an ML model trained on known successful synthetic routes, while the former ensures the synthesizability and the later provides a directed approach to limiting the output molecules to compounds with desirable similarity to the template. Another remarkable ML‐based generative approach is proposed by Méndez‐Lucio et al., 261 which bridges systems biology and molecular design. To our knowledge, it is the first AI/ML‐based drug design tool that combines transcriptomic and structural data. Conditioning a GAN architecture with compound‐induced transcriptomic data (i.e., L1000 data set), they can automatically design molecules that potentially produce the desired transcriptomic outcome. Their model allows the design of active‐like molecules for a desired target using just gene expression signature of target perturbation. However, the current version is not capable of generating compounds that can reverse disease‐related gene expression signatures. Also, its performance has not been evaluated in a real drug‐discovery setting yet.

Among all the studies of AI/ML‐based generative molecular design, maybe the most‐mentioned 262 one is published by Insilico Medicine, 263 showing how AI for generative chemistry can be used to drive rapid drug discovery. The goal of the study was to demonstrate that efficacious drugs can be developed in just 21 days for a new target. For this purpose, they have developed a generative tensorial reinforcement learning (GENTRL) model, which can be seen as an advanced version of their earlier algorithms on VAE 238 and GAN, 247 to design DDR1 kinase inhibitors. Notably, this study has two major limitations: First, DDR1 is considered to be the most promiscuous kinase 264 ; thus, developing compounds targeting this protein may be considered low hanging‐fruit. Second, the seemingly novel compound is highly similar to the widely used cancer drug ponatinib, indicating the limitation of the approach 265 in assessing truly novel scaffolds. Therefore, there is still room for improvement of AI/ML‐inferred small molecules to obtain a clinical candidate.

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › AI/ML applications in prediction of drug sensitivity and response

Personalized drug response prediction aims to improve the targeted therapy response in complex diseases like cancer. 266 However, the limited application of candidate drugs in clinical settings and the heterogeneity among cancer patients make it difficult to tailor therapy for each individual cancer patient. Personalized treatment design requires predictive methods that are capable of exploiting large, heterogeneous, and sparsely sampled data sets. Accurate AI/ML‐based models employing in vitro and in vivo data sets have the potential to improve the prediction of response of cancer cells to a given compound. There are various AI/ML models to predict drug sensitivity and anticancer drug response. In such efforts, elastic net regression, 267 , 268 , 269 ensemble‐based approaches, 270 , 271 transfer learning, 272 autoencoders, 266 , 273 , 274 , 275 and multitask learning approaches 276 , 277 , 278 have been widely used. The details about these AI/ML applications can be found in the Supporting Information.

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › AI/ML applications in prediction of drug–drug interactions

In the treatment of complex diseases such as neurological disorders, diabetes, cancer, or cardiovascular disease, drug combinations are highly utilized for medical intervention. Coadministration of drugs in the treatment aims to enhance efficacy, reduced toxicity, and prevent the emergence of resistance. Drug combinations are classified as synergistic, antagonistic, or additive. Drug synergy is the interaction of two or more drugs, causing the total effect of drugs to be greater than sum of individual effects of each drug. 279 If drugs act synergistically, lower doses of each drug could potentially be enough to provide the desired outcome allowing for less adverse effects. Opposite to synergism, the antagonistic combination means that the combined activity of the drugs is lower than the response of the individual agents. 280 Finally, a drug combination is considered to be additive when the response of each drug neither masks nor enhances the efficacy of others. 281 Although combinatorial therapy has advantages over monotherapy, developing a new drug combination regimen that can be transferred to the clinic is still challenging. So far, the effective drug combinations have been suggested based on either clinical experience or HTS of drug pairs at different concentrations on cell lines. However, the former involves the risk of harm to patients, and the latter is unfeasible to test the complete combinatorial space. 282 To accelerate conventional combinatorial therapy efforts, AI/ML algorithms have begun to be utilized for prioritizing the drug pairs and exploring the larger combinatorial space. Tonekaboni et al. 283 introduced some examples of various ML‐based prediction frameworks for drug–drug interactions. To avoid duplication, we overview the AI/ML applications in combinatorial therapy after that time, including the applications in cancer 284 , 285 , 286 , 287 , 288 and depression treatment, 289 antimalarial, 290 and antibiotic 291 discovery, along with the available AI/ML‐based tools to predict the synergistic effects of drug combinations 292 , 293 , 294 in the Supporting Information.

In addition to the synergistic effects, drug–drug interactions can induce unexpected adverse drug reactions. Such adverse reactions caused by drug–drug interactions could lead to death in some extreme cases. 295 Therefore, AI/ML‐based models have been developed to predict the risk of side effects due to drug–drug interactions. Applications of GCN, 296 DNN, 297 and ML architectures 298 showed promising results for predicting adverse drug reactions of drug combinations. Lee and Chen 299 extensively discussed the role of ML approaches in detection and classification of side effects caused by drug–drug interactions in their review of previous studies. In a recent study, Shankar et al. 300 predicted the adverse drug reactions of coadministered drug pairs using an ANN trained on transcriptomic data, compound chemical fingerprint, and Gene Ontologies. 300

## Section: AI/ML APPLICATIONS IN DRUG DISCOVERY › AI/ML applications in drug repurposing

Drug development and trials in animals and humans is a time‐consuming and expensive process. In general, the whole process for developing a new FDA‐approved drug requires 10–17 years of period and the tremendous cost of $2.6 billion. 301 However, high expenditures for drug development has not been able to increase the rate of approved drugs. 302 Among the reasons for this limited approval rate, a key factor is the continued adherence to the classical “one gene, one drug, one disease” paradigm in the traditional drug development. 303 Since drug targets do not operate in isolation from the biochemical system, each DTI must be studied in a broader integrative context. 304 This approach provides new insights into “off‐target” effects (i.e., side effects), resistance to precision therapy, and drug mechanism of action that can inform drug‐repurposing efforts.

Drug repurposing, also known as drug repositioning, denotes the new indications of existing drugs and is an alternative over the de novo drug development. Although the unknown underlying complex biology and pharmacology has challenged the drug‐repurposing attempts, intelligent computer algorithms offer a strategy for detecting potential drug indications by integrating large‐scale heterogeneous data (i.e., genomic, transcriptomic, phenotypic, chemical, and bioactivity) from hundreds of approved drugs. Various specially designed AI/ML models have been proposed for detecting novel drug indications. Here, we classify the ML applications for drug repositioning into the following three categories: (i) Similarity‐based methods that employ different types of classifiers like logistic regression, 305 , 306 SVM, 307 , 308 , 309 RF, 310 , 311 KNN, 312 and CNN, 313 (ii) feature vector‐based methods that utilize supervised 314 , 315 , 316 , 317 , 318 and semisupervised 319 , 320 , 321 learning algorithms, and (iii) network‐based methods that mainly use semisupervised learning algorithms (e.g., Laplacian regularized least square, 322 , 323 , 324 label propagation, 325 random walk, 326 and RF 310 ). We provide an in‐depth discussion of these three classes of AI‐based drug repositioning applications in the Supporting Information. Particularly, in early 2020, researchers at MIT published a milestone paper using a DL approach to antibiotic discovery. 153 They trained the deep GCN model based on molecular features and predicted halicin as an antibacterial molecule from the Drug‐Repurposing Hub. Halicin showed a broad‐spectrum activity against drug‐resistant strains in mice. This is the first time an AI/ML‐assisted tool was used to identify thoroughly new types of antibiotic from scratch, without the need for any previous human assumptions.

## Section: AI/ML APPLICATIONS IN CNS DRUG DISCOVERY

CNS diseases are a group of neurological disorders that impose a significant economic and social impact. Development of new drugs for CNS diseases poses unique challenges compared to other diseases, including the complexity of brain anatomy and function, incomplete understanding of the biology of the complex nature of CNS diseases and the presence of BBB. In this section, we present an overview of AI/ML‐based approaches to meet challenges such as BBB permeability in CNS drug discovery (Figure 4).

AI/ML‐enabled improvements in the treatment of CNS diseases. DL is a subset of ML, which is a subset of AI and their applications address a wide range of challenges in CNS drug discovery and development. The application fields portrayed here are discussed in the Section 3. AI, artificial intelligence; CNS, central nervous system; DL, deep learning; ML, machine learning

## Section: AI/ML APPLICATIONS IN CNS DRUG DISCOVERY › BBB permeability prediction

Despite significant progress in our understanding of CNS diseases, the development of novel therapies for CNS diseases faces some great challenges. In addition to the difficulties in CNS target identification, designing new molecules with the ability to penetrate the BBB is also a major obstacle. The role of the BBB is to protect the brain from variations in blood composition (e.g., hormones, amino acids, and potassium) and circulating pathogens. It consists of capillary endothelial cells that are lined by the basal lamina made from structural proteins (i.e., extracellular matrix proteins collagen and laminin), pericytes, astrocytic endfeet, and microglial cells. 327 This biologic membrane allows the uptake of water, glucose, and essential amino acids, the efflux of small molecules and nonessential amino acids from the brain to the blood and the passage of some molecules by passive diffusion. 328 While negligible penetration is desirable to minimize the brain side effects for peripheral drugs, high penetration is needed for CNS‐active drugs. To improve success rates in CNS drug discovery, the BBB permeability of drug candidates needs to be addressed early in the drug discovery process.

In recent years, AI‐based predictive models have been proposed to minimize the number of laborious, expensive, time‐consuming BBB permeability experiments that need be carried out in CNS drug discovery. For the construction of BBB permeability predictive models, researchers have employed various supervised learning approaches, such as SVM, 222 , 329 , 330 , 331 , 332 , 333 recursive partitioning (RP), 334 , 335 Gaussian process, 336 DT, 337 KNN, 338 linear discriminant analysis, 339 consensus classifier, 340 and ANN. 341 , 342 , 343 All of these methods were developed to process physical and chemical features, which mainly include molecular weight, hydrophilicity (ClogP), lipophilicity (ClogD), topological polar surface area, acidic and basic atoms numbers, hydrogen bond donors and acceptors, water‐accessible volume, flexibility (rotatable bonds), van der Waals volume, and ionization potential.

The predictive capability of all the methods mentioned above is limited to passive diffusional uptake and predominantly relies on few molecular descriptors. However, many molecules, for example, glucose and insulin, pass BBB via complex mechanisms that involve specific drug‐transporter/drug‐receptor interactions. 344 , 345 Hence, such mechanisms are hard to be described by simple physicochemical features of compounds. Moreover, achieving therapeutic drug concentrations in CNS may be limited by membrane transporters such as the ATP‐binding cassette and efflux transporter P‐glycoprotein (P‐gp), 346 which mediates efflux of drugs from the BBB. Although the primary role of these efflux transporters is limiting the brain entry of neurotoxins, they also limit the entry of many therapeutics and may contribute to CNS pharmacoresistance. 347 , 348 Therefore, prediction methods need to both overcome the limitations of physicochemical features and address the multiple mechanisms associated with the drugs that pass the barrier and sustain in the brain. For this purpose, Yuan et al. 333 developed an SVM model by combining physicochemical properties and molecular fingerprints: The former is related to passive diffusion while the latter is associated with specific interactions, such as uptake, efflux, and protein binding. When compared to other SVM‐based BBB permeability predictors, the improved accuracy of their model shows that integration of the physicochemical properties and fingerprints can yield better predictions. Actually, all the AI/ML‐based models we have mentioned so far have been trained only on molecular properties disregarding the other types of information related to the efficacy of CNS drugs.

Clinical trials of many drug candidates generate a large amount of phenotypic data in CNS, but the relationship between the CNS side‐effects of drugs and their BBB permeation has not been adequately captured. To bridge the knowledge gap, Gao et al. 349 developed a BBB permeability prediction tool utilizing drug clinical phenotypes (drug side effects and drug indications). Although they explored the BBB permeability prediction from a new angle by accounting for passive diffusion as well as putative contributions of active transport and other complex mechanisms, the accuracy of their SVM method still needs to be improved. In fact, the features based on physics and chemistry are different; hence, the relation between drug side effects and therapeutic effects is more abstract and deeper. 350 For this reason, classical classification algorithms are not able to efficiently explore the relationship between data and results. On the contrary, DL architectures have the ability to extract useful information from complex data structures with abstract relationships. Therefore, Miao et al. 350 built a DL model to predict the BBB permeability of drugs based on clinical features and achieved better performance than the other existing methods.

## Section: AI/ML APPLICATIONS IN CNS DRUG DISCOVERY › AI/ML applications in drug discovery for neurological disorders › AI/ML applications in drug discovery for neurodevelopmental disorders

Schizophrenia is arguably the most puzzling of psychiatric disorders. 351 As a neurodevelopmental disorder, 352 schizophrenia shows a lifetime prevalence of 0.30%–0.66%, 353 generally beginning before age 25 years and persisting throughout life, making it one of the leading factors of global disease burden. 354 Despite more than a century of research, its complex pathophysiology remains unknown, 355 and currently, there is no effective drug for schizophrenia. Therefore, there is a need for alternative strategies to develop innovative drug treatments for schizophrenia. 356 In recent years, AI/ML has seen as a promising technology to inform schizophrenia diagnosis, 355 , 357 detecting heterogeneity, 358 , 359 , 360 subtyping, 361 , 362 and treatment.

In drug discovery studies for schizophrenia, researchers have utilized AI/ML methods with various purposes, including drug target identification, 363 , 364 developing QSAR models, 365 predicting monitoring dosing compliance, 366 predicting GPCRs targeting compounds, 364 and drug repositioning. 367 Specifically, schizophrenia target genes were identified based on publicly available microarray data sets using an SVM‐RFE (recursive feature elimination)‐based feature selection, where the genes initially ranked by an SVM classifier and the signature was then identified by discarding the genes that were not differentially expressed. To detect optimal biomarkers of presynaptic dopamine overactivity, which may cause schizophrenia, an SVM classifier was used. 363 SVM classifiers were also used to predict QSAR models of the GABA (gamma aminobutyric acid) uptake inhibitor drugs, which can be beneficial in the treatment of schizophrenia. 365 Moreover, SVM outperformed the other ML methods in predicting the repositioning drugs for schizophrenia when trained on drug expression profiles. 367 On the contrary, for schizophrenia subtyping, an unsupervised learning approach, multi‐view clustering, was employed by combining transcriptomic data with clinical phenotypes. 368 Setting a good example of the beneficiary of AI/ML in clinical drug trials, a novel AI platform AiCure 366 on mobile devices was used to assess the dosing compliance in Phase 2 clinical trial in schizophrenia patients. It, simply, confirms the medication ingestion visually by using facial recognition and computer vision.

One of the major obstacles in developing AI/ML methods for schizophrenia drug discovery is data availability. 369 Publicly available, large‐scale, well‐structured information on neural phenotypes, genomics, and clinical stages are greatly lacking, which arouses questions for the generalizability of AI/ML algorithms across different data sets without performance loss. However, the availability of such integrative databases can encourage the development of AI/ML‐based methods to investigate personalized therapies by solving the disease heterogeneity.

Another neurodevelopmental disorder is autism spectrum disorder (ASD), which is characterized by deficits in social communication and social interaction and the presence of restricted, repetitive patterns in behaviors or interests. 370 ML methods have been utilized in ASD research for improving the diagnosis 371 and prognosis prediction. 371 Also, there are few ML applications in drug discovery for ASD. For example, ML‐based cluster analysis (i.e., affinity propagation and k‐medoids) of clinical data (i.e., signs and biomarkers) exhibited a good performance in drug response prediction of ASD patients. 372 Moreover, Bayesian ML models trained on HTS data revealed the potential repurposing of nicardipine or other dihydropyridine calcium channel antagonists for the treatment of Pitt Hopkins Syndrome, a rare genetic disorder that exhibits features of autistic spectrum disorders. 373 Recently, ML algorithms have been employed to predict the functional effects of variants in voltage‐gated sodium and calcium ion channels, which have been associated with ASD, schizophrenia and developmental encephalopathy. 374 Being trained on sequence‐ and structure‐based features, the ML model predicted the gain or loss of function effects of likely pathogenic missense variants in ion channels and the results were validated in exome‐wide data. On the contrary, the toxic compounds may trigger the recent increases in neurodevelopmental disorders among children. 375 To identify developmental neurotoxicants, researchers developed ML algorithms to predict the neurodevelopmental toxicity of compounds. 376 , 377

## Section: AI/ML APPLICATIONS IN CNS DRUG DISCOVERY › AI/ML applications in drug discovery for neurological disorders › AI/ML applications in drug discovery for depression

AI/ML‐based methods have been utilized in psychiatric drug discovery, especially for pharmacological decision support. 367 , 378 , 379 In a depression study, researchers have developed a gradient boosting machine using the predictors identified by the elastic net to predict whether a patient will achieve symptomatic remission using an antidepressant, citalopram. 380 This model was also successfully applied to an escitalopram treatment group of an independent clinical trial. 378 In the next study of Chekroud et al., 381 they clustered the symptoms using an unsupervised learning approach (hierarchical clustering) and predict the responsiveness of each cluster to the treatment of different antidepressant drugs using the same model in the previous study. To provide decision support for clinicians to select the best drugs for a given cluster of symptoms, a web‐based application was designed. This AI‐based service is prospectively tested in hospital settings and thereby serve as a promising model for direct research translation. 382

On the contrary, the model of Chekroud et al. 380 has some limitations. The model only predicts whether a patient responds to a specific antidepressant without measuring the degree of antidepressant response. Since it was designed for only one antidepressant, the model is not capable of selecting the most effective drugs among various antidepressant candidates for patients. 383 To address these limitations, Chang et al. 383 developed an Antidepressant Response Prediction Network (ARPNet) model based on an NN architecture. Through the literature‐based and data‐driven feature selection process, ARPNet predicts the degree of antidepressant response, whether the patient will reach clinical remission from depression, and a patient's response to a combination of one or more antidepressants.

Electroencephalography (EEG) and functional magnetic resonance imaging (fMRI) data also have been employed in predicting drug responses to treatments of depression. Zhdanov et al. 384 used an SVM classifier to accurately predict the outcome of escitalopram treatment using patients' EEG data at the baseline and after the first 2 weeks of treatment. To identify a robust signature from resting‐state EEG that would predict response to antidepressants, Wu et al. 385 designed an end‐to‐end prediction algorithm with a latent space model. They applied their algorithm, Sparse EEG Latent SpacE Regression (SELSER), to data from an imaging‐coupled, placebo‐controlled antidepressant study and identified an EEG signature of patient's response to antidepressant treatment (i.e., sertraline). Ichikawa et al. 386 aimed to develop a melancholic depressive disorder biomarker to extract critically important functional connections (FCs) from fMRI data. By combining two ML algorithms (i.e., L1‐regularized sparse canonical correlation analysis and sparse logistic regression), they developed a classifier for melancholic depressive disorder and found out that antidepressants had a heterogeneous effect on the identified FCs of melancholic depressive disorder.

Although some of the recent AI/ML‐aided tools have been rapidly translated into the clinical trials, the AI/ML methods still are not used widely in clinical practice, while AI has been employed in psychiatric research over 20 years. 387 To close the gap between research and clinic, we need to improve the validity of diagnostic and prognostic labels, representability of the features, and generalizability of models. 388 As scientists continue to work to bridge the gap between research and clinic, it will be possible to provide efficient, personalized treatments based on a patient's unique characteristics. 389

## Section: AI/ML APPLICATIONS IN CNS DRUG DISCOVERY › AI/ML applications in drug discovery for neurological disorders › AI/ML applications in drug discovery for Parkinson's disease

Parkinson's disease (PD) is the second most common age‐related neurodegenerative disorder, affecting over 1% of the population above the age of 60, increasing to 5% in individuals above 85 years of age. 390 PD is a prime example of a multifaceted disease, including a broad range of motor and non‐motor symptoms and possible contribution of genetic and environmental risk factors. 391 Currently, there is no treatment to prevent the progressive depletion of dopaminergic neurons in the substantia nigra that underlies the movement control and cognitive loss, which is manifested with tremors and memory loss. 392 , 393 Available drug treatments are based on the administration of levodopa (l‐dopa) and catechol‐O‐methyltransferase or monoamine oxidase B inhibitors, offering only symptomatic relief to the patients. 392

In PD research, previous AI applications have focused on diagnostic biomarker discovery in cerebrospinal fluid (CSF) and blood 394 , 395 , 396 , 397 and remote monitoring of treatment response by using electronic wearables. 398 , 399 , 400 , 401 , 402 On the contrary, recently, AI/ML has received little attention in PD drug discovery. Particularly, Shao et al. 403 initially built SVM models to quickly select the compounds containing indole–piperazine–pyrimidine scaffold among large chemical databases and subsequently identified novel compounds that simultaneously bind the two receptors—adenosine A2A receptor and dopamine D2 receptor—implicated in the PD pathophysiology. In another study, Sebastián‐Pérez 404 utilized several ML techniques to infer QSAR models for the identification of putative inhibitors of LRRK2 protein, a key genetic risk factor for familiar and sporadic PD. Moreover, AI‐based technologies have helped overcome the drug side effects in PD treatment. While l‐dopa has remained the cornerstone of PD therapy for reducing the symptoms associated with dopamine deficiency, almost half of PD patients treated with it eventually develop levodopa‐induced dyskinesia (LID), a side effect that causes abnormal involuntary movements. In a review paper, Johnston et al. 405 discussed the use of AI platforms to identify repurposing candidates for LID treatment and highlighted the potential of AI approaches by designing a drug repositioning case study. To identify novel repurposing candidates that may reduce LID, they utilized a literature mining approach based on an IBM Watson engine, where the semantic similarity and a “graph diffusion” algorithm were applied to score and rank each candidate drug.

Along with the identification of novel and repurposing candidates, AI/ML techniques have been applied to the development of in vitro and in vivo PD models for drug screening. Monzel et al. 406 created a human midbrain organoid model of PD as an in vitro toxicity assay and built an RF classifier to predict compounds' neurotoxic effect on organoids based on cellular features. To establish an efficient drug‐testing route, Hughes et al. 407 developed a zebrafish model of PD together with an AI/ML‐based method to classify movement disorders in this model using high‐resolution video captures. Encouraging results of all the studies discussed above, highlight the potential benefits of AI/ML applications for the discovery of efficient and multitargeting drugs against emerging targets in PD as well as the screening of the drug effects on PD models.

## Section: AI/ML APPLICATIONS IN CNS DRUG DISCOVERY › AI/ML applications in drug discovery for neurological disorders › AI/ML applications in drug discovery for Alzheimer's disease

Increasing life expectancy has produced a dramatic rise in the prevalence, and thus impact, of aging‐related diseases. The most prevalent neurodegenerative disease in older adults is Alzheimer's disease (AD), characterized by insidious and progressive impairment of behavioral and cognitive functions, including memory. 408 The cause of AD is still unclear; however, generally accepted neuropathological hallmarks of AD include extracellular A‐beta plaques and intracellular neurofibrillary tangles, along with neuronal and synaptic loss and/or dysfunction. 409 Current drugs for AD target cholinergic and glutamatergic neurotransmission, thus improving symptoms, although they show limited benefits to most AD patients. 410 Therefore, new treatments are urgently needed to prevent or delay disease onset, slow its progression, or improve patients' symptoms. 411 However, drug development for AD has been extraordinarily difficult, with a failure rate of over 99% and no new drug approved since 2003. 411 AD drug failures are likely due to the lack of sufficient target engagement and toxicity, while drug discovery efforts mainly challenged by an incomplete understanding of AD pathogenesis, multifactorial etiology, and complex pathophysiology.

In recent years, AI/ML‐based models have become popular in AD research, mostly utilizing for AD diagnosis and prognosis in dealing with electronic health records and images. 412 On the contrary, AI/ML techniques have not been widely employed in AD drug discovery. However, there have been a few studies that show the potential benefits of AI/ML applications for the discovery of AD drugs. ML approaches have assisted the target identification and characterization in AD, which is the initial phase of drug discovery. For example, Cordax 413 (https://cordax.switchlab.org) is a novel structure‐based amyloid core sequence prediction method that implements ML to detect aggregation‐prone regions in proteins as well as to predict the structural topology, orientation and overall architecture of the resulting amyloid core. As an aggregation predictor, it uses structural information on amyloid cores currently available in the protein databank and translates structural compatibility and interaction energies into sequence aggregation propensity using logistic regression. Along with the characterization of amyloid fibrils, ML approaches have been utilized for identifying potential drug targets. HENA, 414 a heterogeneous network‐based data set for AD, integrates distinct data types (i.e., PPI, gene coexpression, epistasis, genome‐wide association study, gene expression in different brain regions, and positive selection data) through GCN to predict AD‐associated genes.

Researchers have built ML models—SVM, ANN, and RF—to predict the inhibitory effect of compounds against AD‐related proteins—histone deacetylase (HDAC), 415 acetylcholinesterase (AChE), 416 and S100 calcium‐binding protein A9 (S100A9), 417 respectively. Although these target‐specific models were successful for predicting the bioactive compounds, a high level of reliability is necessary for prioritizing compounds that are ultimately translated into assays. To generate hyper‐predictive ML models, Jamal et al. 418 have included dynamic properties of compounds and protein–ligand interactions. Extracting the dynamic descriptors from molecular dynamics simulations of caspase‐8 ligand complexes to train ANN and RF models, they predicted the active compounds against caspase‐8, which plays a key role in causing AD. The major challenge in developing such predictive models of inhibitor activity is the lack of data on true‐negative compound–protein interactions. To address this challenge, Miyazaki et al. 419 constructed a graph CNN model to explore compounds specifically targeting proteins without using the information on the true‐negative interaction and applied the model to identify inhibitors of BACE1 enzyme, a major target for AD.

Although these ML applications have advanced the discovery of single‐target inhibitors, the complex nature of AD requires the discovery of multitarget drugs to address the multiple pathways contributing to disease pathogenesis. Therefore, researchers have developed ML algorithms for predicting multitarget‐directed compounds against AD. Kleandrova et al. 420 designed seven molecules as triple target inhibitors of AD‐related proteins, namely GSK3B, HDAC1, and HDAC6 by combining perturbation theory and ML‐based on ANN. Using a new multitask QSAR model based on the linear discriminant analysis, Concu et al. 421 predicted the inhibitors of the two isoforms of the monoamine oxidase (MAO) enzymes, MAO‐A and MAO‐B, which are involved in the pathology of AD, PD, and other neuropsychiatric disorders. As epigenetic therapeutics for AD, HDAC inhibitors have shown promise; however, nonspecificity and nonselectivity are the major problems of current HDAC inhibitors. Therefore, Gupta et al. 422 combined VS and ML to classify the HDAC inhibitors and identified a novel compound that potentially inhibits all isoforms of class I and class IIb HDAC for AD therapy. In addition to these, Fang et al. 423 built 100 binary classifiers based on the naive Bayesian and RP algorithms to predict active small molecules against 25 key targets toward AD. Experimental validation of the predicted molecules yielded a compound that is a dual cholinesterase inhibitor and H3R antagonist. In their following study, 424 the system has been updated by assembling 204 binary classifiers towards 54 critical targets related to AD and the information of the classifiers was shared in a web server named AlzhCPI. Utilizing this classifier system, another group of researchers 425 has identified multiple targets of a traditional Chinese herbal medicine formula, Naodesheng, for application to AD. Natural products has continued to generate an increased interest as a mean of discovering novel bioactive compounds against AD. Grisoni et al. 426 proposed a VS protocol based on ML models to explore the bioactive synthetic mimetics of the natural product galantamine, which is the first natural product‐based AD drug approved by the FDA in 2001. 427 Using an ML‐based selection and target profiling program, they identified galantamine‐mimetic small molecules with multitarget activity on enzymes and receptors related to AD.

Besides the predictions of multitarget compounds based on their bioactivity against known drug targets in AD, Jamal et al. 428 predicted small molecules that show a high binding affinity for ML‐inferred possible therapeutic targets. Unlike previous studies that target known AD‐related proteins, they initially predicted the probable AD‐associated genes using ML classifiers that are trained on network, sequence and functional features. Then, they used a conventional VS tool to select the compounds that have high affinity for the majority of the predicted targets.

In addition to applications for identifying small molecules towards therapeutic targets for AD, ML techniques also have been utilized in drug repositioning efforts. For example, telmisartan has been associated with AD by a network‐based classification model. 310

AI/ML approaches have also been applied to drug response studies to treat AD patients in a more precise, personalized way. Hampel et al. 429 has built an AI/ML‐based precision medicine framework for identifying the genomic biomarkers of response to AD therapy. Specifically, they studied blarcamesine (ANAVEX2‐73), a selective sigma‐1 receptor agonist, in a Phase 2a trial, where they obtained the patients' whole‐exome and transcriptome data and recorded the measures of safety, clinical features, pharmacokinetics, and efficacy. They analyzed the relationship between the patient data and efficacy outcome measures using unsupervised formal concept analysis, which ultimately identified the biomarkers of drug response. On the contrary, Lu et al. 430 evaluated the therapeutic effects of Dengzhan Shengmai formula, a traditional Chinese medicine, on AD patients by analyzing the diffusion tensor imaging data with ML. Their ML classifier revealed significant white‐matter network alterations after treatment.

## Section: AI/ML APPLICATIONS IN CNS DRUG DISCOVERY › AI/ML applications in drug discovery for neurological disorders › AI/ML applications in anesthesia and pain treatment

The CNC drugs include general anesthetics and the analgesics, as well. In the past few years, we have witnessed the widespread use of autonomous and AI‐based recommender systems in therapeutic decision making in anesthesia and pain management. Especially, pharmacological robots have become an integral part of the anesthesia field, offering a personalized anesthetic drug dosage for maintaining patient homeostasis during general anesthesia and sedation. 431 These robots use complex ML algorithms based on patient data (e.g., EEG monitor, blood pressure, heart rate, etc.) and pharmacokinetic features of drugs to provide the optimal drug dosage. The role of pharmacological robots and even more intelligent autonomous systems (i.e., cognitive robot, which can recognize crucial clinical state that requires human intervention) in the anesthesia field has been comprehensively overviewed by Cédrick et al. 432 Besides the robotic systems, ML applications assisted the clinicians 433 to monitor the drug‐specific anesthetic states 434 , 435 , 436 and predict the adverse outcomes in anesthesia patients. 437 , 438 , 439

Similar to the anesthesia field, AI models have mainly utilized for clinical decision support in pain management. With the increasing amount of data collected by state‐of‐the‐art monitoring sensors and the Internet of Things, the AI‐assisted patient‐controlled analgesia has a great potential for personalized pain therapy. 440 The other clinical applications of AI systems in pain management include prediction of pain severity/modality and analgesic requirements, 441 , 442 , 443 individualized medicine decision support in analgesic treatment, 444 , 445 prediction of the effectiveness of the analgesics, 446 , 447 and prediction of medication overuse. 448 , 449 , 450 Besides the clinical applications, researchers have employed ML methods at the early stages of analgesic discovery, such as identifying novel genes and pathways associated with acute and chronic pain 451 and predicting inhibitors of a drug target for pain (i.e., NaV1.7 sodium channel). 452 To facilitate the prediction of novel multi‐target analgesics or drug combinations for pain treatment, researchers have established a comprehensive pain‐domain‐specific chemogenomics knowledgebase that includes the analgesics in current use, pain‐related targets with all available 3D structures, and the compounds reported for these target proteins. 453

## Section: CONCLUSIONS AND FUTURE DIRECTIONS

Given the complexity of neurological disorders, CNS drug development is still a long, expensive, inefficient, and challenging process with a low rate of new successful therapeutic discovery. To overcome the challenges of CNS drug discovery, researchers have utilized AI/ML‐based methods, which have played a promising role in all stages of drug discovery for a variety of diseases (Table 2). In general, AI/ML practices in pharmaceutical development have aroused great interest among researchers working in academia and industry. The number of start‐ups in this area has grown rapidly and reached 230 by June 2020. 454 Also, many pharmaceutical companies have invested in internal AI‐based research programs as well as in collaboration with AI start‐ups and academic institutions. 455 , 456 Recently, we have witnessed a massive collaborative effort by both academia and industry in response to the COVID‐19 outbreak. Labs and AI firms have shared their data and pipelines in open‐sourced platforms. For example, Google Deepmind has released the 3D structures of SARS‐CoV‐2 proteins that have been predicted by their AlphaFold system. Although AI‐enabled solutions have emerged as a crucial tool for transforming the process of therapeutic development, the use of AI technologies to improve CNS drug discovery is still at an early stage. Below, we discuss the limitations as well as the future directions to guide further advancement in this evolving field.

The main bottleneck in applying AI/ML into CNS drug discovery is the lack of high‐quality, well‐annotated data sets to train effective algorithms. The data collected in the public databases are generally generated by different biological assays, methods, or conditions, which are not comparable. Also, multiple data sets on the same subject may contradict each other. Therefore, filtering the raw inputs to obtain high‐quality data is a crucial step before performing specific AI/ML tasks.

The “black box” nature of most next‐generation AI architectures an additional challenge in CNS drug discovery. The lack of interpretability of AI/ML‐generated results limits their applications. While this is not the case for simpler ML models (i.e., XGBoost, TensorFlow, Lasso, Ridge, Elastic Net), for more advanced ML models (i.e., DNN) the internal workings remain a mystery. Hence, researchers cannot explain how the model arrives at the result and understand the underlying biological mechanisms. This also makes it more difficult to troubleshoot these models when they unexpectedly fail. Therefore, there is a critical need to develop methods for decoding the black boxes of DL.

Also, the amount of the available data directly affects the performance of AI/ML models, since successful training of algorithms relies on suitably large amounts of training data. This is a particular challenge in nominating new targets or drugs for many neurological conditions for which no treatment reverses the disease state. When there are not sufficient training examples for performing a drug discovery task, transfer learning technology, which learns from one task and applies it to the other task, can offer a solution. However, in the long term, the most promising solution to overcome data scarcity would be for the scientific community to share their data. Such large‐scale sharing of data would make significant improvement in the CNS drug discovery process, with advances in hardware that lead to faster machines such as quantum computers in the near future.

A particular limitation for the AI/ML applications in CNS drug discovery is the unknown pathophysiology for many nervous system disorders, which makes target identification very challenging. To explore the complex disease mechanisms and define the right biological targets, we need better AI/ML tools that can pull information out of the data sets generated across the different biological layers (e.g., transcriptomics, proteomics, and metabolomics). Here, capsule networks, 457 a next‐generation AI architecture where CNNs are encapsulated in an interconnected module, can provide a solution. As the first application of capsule networks to drug discovery, capsule networks showed excellent performance to predict the cardiotoxicity of compounds, which highlights their unique potential in drug discovery efforts. 226 Because of the modular representation of the CNNs, capsule networks can learn from heterogeneous data sets by preserving the hierarchical aspects of the data itself. Considering the highly modular nature of CNS data sets with specified layers of genes, proteins, metabolites, capsule networks can analyze the changes in the functional organization and interplay of these layers upon the diseases.

Another critical issue in the application of AI/ML models into CNS drug discovery is the integration of different data types, including genotypic data from patients, multiomics data from drug treatments, and chemical data from bioactivity and toxicity assays. Considering the availability of various databases that include biological, structural, and chemical information, how to integrate these data to generate AI/ML models becomes a critical question in CNS drug discovery applications. Multitask learning, learning of different tasks jointly, can be suitable for these types of applications. Multitask NNs are capable of integrating data from many distinct sources. For example, a multitask architecture can predict the effects of a drug and its BBB permeability at the same time by learning from multiomics data sets, physicochemical properties, HTS, and bioactivity assays.

In recent years, we have seen the emergence of novel neuroimaging techniques such as pharmacological functional magnetic resonance imaging (pharmacoMRI) and pharmacologically induced functional ultrasound (pharmaco‐fUS), which provide in vivo functional data of specific effects of drugs on the brain. Although pharmacoMRI continues to play a useful role in neuropharmacology studies as a well‐established technique, 458 , 459 , 460 , 461 a variety of challenges (i.e., low sensitivity, the requirement for anesthesia, and blood oxygenation‐level dependent imaging) limit the preclinical use of it. A newer tool, pharmaco‐fUS enables brain activity imaging through the local monitoring of cerebral blood volume dynamics at an unprecedented spatiotemporal resolution without the bias of anesthesia. 462 , 463 Recent studies demonstrated fUS imaging's potential to characterize dynamic profiles of CNS drugs, including a drug combination of donepezil plus mefloquine for AD 464 and atomoxetine for attention‐deficit/hyperactivity disorder. 465 Moreover, Rabut et al. 466 adapted ML to analyze the rich data content provided by fUS connectivity imaging. Their ML model identified the “fingerprint” of drug‐induced brain connectivity changes in awake mice for scopolamine, a major preclinical drug to model AD. As evident from the previous applications, AI/ML methods hold the promise of characterization of treatment effects from novel neuroimaging data sets and thereby improving our understanding of the mechanism of action of drugs in the brain. Getting drugs across the BBB is an essential step to developing successful therapies to treat CNS disorders. However, it is often overlooked that BBB is not only a physical barrier for drug delivery to the CNS but also a complex, dynamic interface that might be affected by diseases. CNS disorders may result in dysfunction of BBB, such as its disruption or dysfunctions related to BBB transporters. To date, AI/ML‐based predictive algorithms have assumed that BBB is a static entity by neglecting the effects of CNS pathologies on it. Therefore, a prediction model for BBB penetrance that trained on data from non‐CNS diseases may not work for a CNS disease. To develop better prediction models for BBB permeability, we need to take into account disease‐related changes in the barrier. This also provides many unique opportunities for developing disease‐specific AI/ML tools in CNS drug discovery.

It is important to highlight that CNS drug discovery has a nondeterministic nature, where the neurological targets involve different pathways and their biological consequences are not the sums of the single functions, most drugs have diverse activities through multiple biological targets, and drug response is dependent on a range of factors (i.e., patient's genetic profile and drug's membrane permeability). Moreover, physiologic events are highly context‐specific: A receptor interaction may take place in the liver but not in the brain. AI/ML systems often fail to pick up such context‐specific nonlinear relationships and many other unknown contributing factors. As a result of incomplete domain representation, partial predictability in CNS drug discovery is inevitable. For example, an AI/ML algorithm may predict drug targets that neuroscientists know will likely have significant side effects in the brain or generate unsynthesizable molecules. Here, we need the human refinement process and hypothesis‐driven approach 467 to address many of these challenges to achieve better performance. Knowledge acquisition from the human experts to the AI systems can help the AI/ML system learn and thereby guarantee the best scientific results. In consequence, this mixture of machine and mind 468 will improve decision making as an essential component of the CNS drug discovery process.

Although AI/ML algorithms have already revolutionized other fields, the adoption of them to drug discovery is still at an eraly stage. Initially, AI/ML algorithms have been developed and practically used for certain areas such as image recognition, gaming, and internet search. Inspired by the successful applications in other disciplines, scientists have applied AI/ML algorithms to pharmaceutical research. And yet, we do not have any AI/ML algorithm that is developed specifically for a drug discovery problem. But this means that there should be many opportunities to develop innovative and novel algorithms in the field of therapeutic discovery. In this way, AI/ML methods will play an increasingly important role in not just the field of general pharmaceutical research but also CNS drug discovery.

In conclusion, we extensively review the latest AI/ML‐assisted drug discovery applications for the therapy of CNS diseases. These applications have been overgrowing in the past couple of years, fueled by the unprecedented success of AI/ML‐based approaches in different fields of science and technology. We envision that in the future, AI/ML will play more and more critical roles in CNS drug discovery towards personalized medicine, especially in the following areas: (1) patient subtyping, (2) identification of key disease drivers, (3) prediction of cell type‐specific drug response, (4) autonomous design of novel drugs, and (5) disease‐specific BBB permeability testing. Today there are structural constraints in data and algorithms that are limiting the role of AI/ML. Nonetheless, in the long run, ongoing and emerging developments in AI/ML approaches to neuropharmacology will enable us to develop more effective drugs for CNS diseases.

The promise of AI/ML‐based drug discovery strategies in CNS disorders


---

# Artificial Intelligence Effecting a Paradigm Shift in Drug Development

- **Authors:** Masturah Bte Mohd Abdul Rashid
- **Issuer:** SLAS technology
- **Type:** Scientific article
- **Published:** 2020-09-17
- **Language:** en
- **DOI:** 10.1177/2472630320956931
- **Source:** https://pubmed.ncbi.nlm.nih.gov/32940124/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

The inverse relationship between the cost of drug development and the successful integration of drugs into the market has resulted in the need for innovative solutions to overcome this burgeoning problem. This problem could be attributed to several factors, including the premature termination of clinical trials, regulatory factors, or decisions made in the earlier drug development processes. The introduction of artificial intelligence (AI) to accelerate and assist drug development has resulted in cheaper and more efficient processes, ultimately improving the success rates of clinical trials. This review aims to showcase and compare the different applications of AI technology that aid automation and improve success in drug development, particularly in novel drug target identification and design, drug repositioning, biomarker identification, and effective patient stratification, through exploration of different disease landscapes. In addition, it will also highlight how these technologies are translated into the clinic. This paradigm shift will lead to even greater advancements in the integration of AI in automating processes within drug development and discovery, enabling the probability and reality of attaining future precision and personalized medicine.


---

# Artificial Intelligence for COVID-19 Drug Discovery and Vaccine Development

- **Authors:** Arash Keshavarzi Arshadi, Julia Webb, Milad Salem, Emmanuel Cruz, Stacie Calad-Thomson, Niloofar Ghadirian, Jennifer Collins, Elena Diez-Cecilia, Brendan Kelly, Hani Goodarzi, Jiann Shiun Yuan
- **Issuer:** Frontiers in artificial intelligence
- **Type:** Scientific article
- **Published:** 2020-08-18
- **Language:** en
- **DOI:** 10.3389/frai.2020.00065
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33733182/
- **Licence:** CC-BY

## Section: Abstract

AbstractSARS-COV-2 has roused the scientific community with a call to action to combat the growing pandemic. At the time of this writing, there are as yet no novel antiviral agents or approved vaccines available for deployment as a frontline defense. Understanding the pathobiology of COVID-19 could aid scientists in their discovery of potent antivirals by elucidating unexplored viral pathways. One method for accomplishing this is the leveraging of computational methods to discover new candidate drugs and vaccines in silico. In the last decade, machine learning-based models, trained on specific biomolecules, have offered inexpensive and rapid implementation methods for the discovery of effective viral therapies. Given a target biomolecule, these models are capable of predicting inhibitor candidates in a structural-based manner. If enough data are presented to a model, it can aid the search for a drug or vaccine candidate by identifying patterns within the data. In this review, we focus on the recent advances of COVID-19 drug and vaccine development using artificial intelligence and the potential of intelligent training for the discovery of COVID-19 therapeutics. To facilitate applications of deep learning for SARS-COV-2, we highlight multiple molecular targets of COVID-19, inhibition of which may increase patient survival. Moreover, we present CoronaDB-AI, a dataset of compounds, peptides, and epitopes discovered either in silico or in vitro that can be potentially used for training models in order to extract COVID-19 treatment. The information and datasets provided in this review can be used to train deep learning-based models and accelerate the discovery of effective viral therapies.Keywords: COVID-19, SARS-COV-2, drug, vaccine, artificial intelligence, deep learning

## Section: Introduction

Coronaviridae is a viral family responsible for causing pneumonia-like symptoms that has been a global threat since its first outbreak in 2002 (Jabeer Khan et al., 2020). Severe Acute Respiratory Disease (SARS) and Middle Eastern Respiratory Syndrome (MERS), emerging in 2002 and 2013, respectively, caused diseases marked by both gastrointestinal and pulmonary dysfunction (Hilgenfeld and Peiris, 2013). In 2019, SARS-COV-2 was the causative agent of a third Coronavirus outbreak and has been identified as the virus responsible for COVID-19, the symptoms of which range from those of the common cold to more severe respiratory failure (Kong W.-H. et al., 2020). Despite its having been declared a pandemic by the World Health Organization (WHO), COVID-19 has continued to spread and has infected at least 20 million individuals, reaching a death toll of over half a million at the time of this review (Worldometer, 2020).

While hospitals are resorting to trial and error tactics for COVID-19 drug discovery, Virtual Screening (VS) has emerged as a popular method for discovering potent compounds due to the inefficiency of lab-based high throughput screening (HTS) (Jin et al., 2020; Kandeel and Al-Nazawi, 2020). VS for rational drug discovery is essentially an approach that involves computationally targeting a specific biomolecule (e.g., DNA, protein, RNA, lipid) of a cell to inhibit its growth and/or activation (Shoichet, 2004; Lionta et al., 2014). Structure-based and ligand-based drug discovery and design are two important subgroups of this type of screening (Lionta et al., 2014; Yu and Mackerell, 2017; Arshadi et al., 2020; Broom et al., 2020). Given our access to computationally and experimentally determined viral protein structures (Senior et al., 2020; Zhang L. et al., 2020), VS provides a rapid and cost-effective strategy for identifying antiviral candidates.

Additionally, conventional vaccine discovery methods have been costly, and it may take many years to develop an appropriate vaccine against a specified pathogen. In the early 1990s, the introduction of a genome-based vaccine design approach dubbed “Reverse Vaccinology” (RV) (Rappuoli, 2000; Bullock et al., 2020), revolutionized the field to a more efficient status, due in part to the fact that bacterial culturing was no longer required for identifying vaccine targets (Bruno et al., 2015; Heinson et al., 2015; Soria-Guerra et al., 2015). Moreover, all of the putative target protein antigens can be identified, rather than identification being limited to those isolated from bacterial cultures (Xiang and He, 2009; Bowman et al., 2011). All of these advantages taken together led scientists to generate RV prediction programs.

Over the past decade, artificial intelligence (AI)-based models have revolutionized drug discovery in general (Zhong et al., 2018; Duan et al., 2019; Lavecchia, 2019). AI has also led to the creation of many RV virtual frameworks, which are generally classified as rule-based filtering models (Naz et al., 2019; Ong et al., 2020a). Machine learning (ML) enables the creation of models that learn and generalize the patterns within the available data and can make inferences from previously unseen data. With the advent of deep learning (DL), the learning procedure can also include automatic feature extraction from raw data (Lecun et al., 2015). Moreover, it has recently been found that deep learning's feature extraction can result in superior performance compared to other computer-aided models (Ma et al., 2015; Chen et al., 2018; Zhavoronkov et al., 2019).

In this review, we provide a survey of AI-based models for COVID-19 drug discovery and vaccine development. Moreover, we identify and evaluate the best candidate targets for future treatment development. We propose that a concerted effort should be made to leverage the knowledge from pre-existing data by using machine learning approaches. To that end, we present a wide-ranging collection of small molecules, peptides, and epitopes for therapy discovery that could also direct AI-based models, screening, or generation, in an intelligent manner.

## Section: Background of Machine Learning Methods for Therapy Discovery

In recent years, machine learning has revolutionized many fields of science and engineering. It has largely transformed our daily lives, from speech and face recognition (Alaghband et al., 2020; Grover and Toghi, 2020; Sun et al., 2020) to customized targeted advertisements (Zhai et al., 2016). The power of automatic abstract feature learning, combined with a massive volume of data, has immensely contributed to the successful application of ML (Lecun et al., 2015). Two of the most impactful areas affected are drug and vaccine discovery (Chen et al., 2018), in which ML has offered compound property prediction (Ma et al., 2015), activity prediction (Zhavoronkov et al., 2019), reaction prediction (Fooshee et al., 2018), and ligand–protein interaction.

On the prediction front, Graph Convolutional Neural Networks (GCNN) have been the favorite tool for drug discovery applications (Duvenaud et al., 2015; Kearnes et al., 2016). These networks are able to handle graphs and extract features via encoding the adjacency information within the features. Successful representation learning from molecules using GCNNs has been demonstrated in drug property prediction (Heskett et al., 2018; Bazgir et al., 2019; Liu et al., 2019), protein interface estimation (Fout et al., 2017), reactivity prediction (Coley et al., 2019), and drug–target interactions (Torng and Altman, 2019; Wang et al., 2020). Sequence-based models such as genomics, proteomics, and transcriptomics have also gained some attention in recent years due to the advancements made in the natural language processing domain. The more recent generation of context-based models are transformers that use attention mechanisms and self-supervision to extract representations from sequences (Vaswani et al., 2017; Devlin et al., 2018). Transformers have demonstrated the capacity to predict drug–target interactions (Shin et al., 2019), model protein sequences (Choromanski et al., 2020), and predict retrosynthetic reactions. These models learn to extract features from sequences on the location, context, and order of the input tokens (Belinkov and Glass, 2018). Recurrent neural networks (RNNs) and long short-term memory (LSTM) networks have successfully demonstrated the ability to perform when trained on molecules or protein sequences to predict secondary structure (Pollastri et al., 2002), quantitative structure–activity relationship (QSAR) modeling (Chakravarti et al., 2019), and function prediction (Liu, 2017).

On the lead generation front, de novo design has benefitted the most from the application of deep learning. This subfield has drastically evolved from its traditional usage of ligand-based models and creating molecules from sub-blocks (Acharya et al., 2010). The current approach involves the use of state-of-the-art deep learning models such as Generative Adversarial Networks (GANs) to create data-oriented molecules (Guimaraes et al., 2017). Traditional de novo design fails to fully implement this exploration by constraining the generation of molecules with ligand or fragment libraries. More recent approaches utilize deep learning generative models such as variational autoencoders (VAE) (De Cao and Kipf, 2018) in order to create sequences of atoms. This approach lifts the constraints of ligand-based designs and allows the generation of unique molecules with greater diversity (Guimaraes et al., 2017; De Cao and Kipf, 2018; Jin et al., 2018; Liu et al., 2018; Simonovsky and Komodakis, 2018).

Machine learning has also improved the field of vaccine design over the past two decades. VaxiJen was the first implementation of ML in RV approaches and has shown promising results for antigen prediction (Doytchinova and Flower, 2007; Heinson et al., 2017). In addition, the recent development of Vaxign-ML, a web-based RV program leveraging machine learning approaches for bacterial antigen prediction, is a testament to the success of exercising mathematical ML-based in RV (He et al., 2010a; Heinson et al., 2017). In essence, these pipelines consist of feature extraction, feature selection, data augmentation, and cross-validation implemented to predict vaccine candidates against various bacterial and viral pathogens known to cause infectious disease. The use of biological, structural, and physiochemical features is prevalent among the approaches in this domain, as seen in reverse vaccinology and immunoinformatic methods such as IEDB and BlastP, which are feature extractors for AI-based models like RNN in the study of different pathogenic viruses (Flower et al., 2010; He and Zhu, 2015; Abbasi, 2020). More recently, graph-based features have also shown the ability to represent the antibodies instead of an expert-designed feature; Magar et al. showed that graph featurization is followed by mean pooling, and then classification is implemented using shallow and deep models (Magar et al., 2020). Deep Learning approaches have also revolutionized the field of cancer vaccinology through the improved prediction of neoantigens and their HLA binding affinity (Sher et al., 2017; Tran et al., 2019; Wu et al., 2019). Autoencoders of deep learning have shown promising improvement in extracting characteristics of human Leukocyte Antigen (HLA-A), which could be utilized in both transplantations and vaccine discovery (Miyake et al., 2018).

Key aspects of therapy discovery are safety and reliability. The Vaccine Adverse Event Reporting System (VAERS) and Vaccine Safety Databank (VSD) have been among the most popular immunization registries for tracking, recording, and predicting vaccine safety. In prior decades, implementations of computational simulation and mathematical modeling have significantly improved the tradeoff between the assessment of safety and efficacy by using the aforementioned resources (He et al., 2010b; Vaishnav et al., 2015). Zheng et al. implemented Natural language Processing (NLP) for the identification of adverse events related to Tdap vaccines (Zheng et al., 2019).

In drug development cases, the final drug candidate produced in the process of drug discovery needs to be safe for human consumption. This requires an observation of the drug's side effects as well as confirmation that the drug is non-toxic. To accomplish this, the Toxicology in the 21st Century program (Tox-21) has screened ~10,000 compounds from 70 screening assays, creating a database that can be used to facilitate toxicity modeling. Furthermore, the project has also expanded to contain 700 assays with nearly 1,800 molecules in the ToxCast dataset. On the side-effect prevention front, the off-target interactions are predicted and minimized in silico. In doing so, potential drug candidates are chosen, with consideration given to their off-target polypharmacological profiles (Zhou H. et al., 2015). In a different approach, AI-based studies were implemented to detect the potential prolongation of QT intervals and cardiotoxicity of a candidate drug, hydroxychloroquine, using ECG data from smartwatches (Li J. et al., 2020)1.

In summary, artificial intelligence has been applied to many subfields of drug discovery and vaccine development. This improvement is crucial for the current situation and immediate SARS-COV-2 therapy discovery for several key reasons. Firstly, the automatic feature extraction ability of deep learning can support models with better accuracy and deliver more reliable results. Secondly, the generative ability demonstrated by deep learning models can be utilized to create more druggable molecules and better epitope prediction, lowering the chance of failure in the trial pipeline. Lastly, the novelty of the virus causes the data around its possible therapies to be scarce, which is a suitable scenario for transfer learning and leveraging the learned knowledge from previous tasks (e.g., TranscreenTM) (Salem et al., 2020). Transfer learning has been shown to alleviate this problem through the transferring of learned knowledge and parameters from a secondary task with big data available to the task at hand (Weiss et al., 2016). Therefore, the use of deep learning in therapy discovery for SARS-COV-2 is essential in order to make a timely and accurate response to the virus.

## Section: COVID-19 Molecular Mechanism and Target Selection

Coronaviruses are enveloped viruses with a positive-sense single-stranded RNA genome (Fehr and Perlman, 2015). They are known to infect both humans and other eukaryotes (Andersen et al., 2020; Hoffmann et al., 2020). The novel coronavirus manages to bind to the host receptor with a higher affinity than SARS due to the increased modification of its viral spike, among other structural proteins, resulting in enhanced transmission (Zhou Y. et al., 2020).

SARS-CoV-2 interaction with host cells begins with attachment via the viral spike (S) protein to the host ACE2 receptor (Hoffmann et al., 2020; Zhou P. et al., 2020). ACE2 binding induces the host surface serine protease, TMPRSS2, to prime the S protein via cleavage at its S1/S2 border, facilitating viral fusion with the cell membrane (Hoffmann et al., 2020). Once inside the cell, the viral RNA genome is released into the cytosol, where it is translated by host ribosome machinery, producing two polyproteins: pp1a and pp1ab, which are then cleaved by viral 3CL protease (main protease) and PL protease. This gives rise to several non-structural proteins (nsps) as the foundation of RNA-dependent RNA polymerase (RdRP); this RdRP then transcribes a template strand of the genomic RNA, from which it then transcribes subgenomic mRNA products to be translated. These products encode the structural proteins S, E, M, and N, as well as additional accessory nsps (Figure 1) (Lai and Cavanagh, 1997; Kim D. et al., 2020).

The severity of the host response depends on an innate response to viral recognition, involving the expression of type-1 IFNs and pro-inflammatory cytokines (Pazhouhandeh et al., 2018; Prompetchara et al., 2020). If the antiviral response is delayed or inhibited, viral proliferation can lead to the large-scale recruitment of neutrophils and monocyte-macrophages to the lungs, creating a hyperinflammatory environment (Prompetchara et al., 2020). Overactive release of pro-inflammatory cytokines, i.e., cytokine storm (CS), has been found in COVID-19 patients and can lead to severe complications like acute respiratory distress syndrome (ARDS) (Moore and June, 2020). It has been found that levels of IL-1B, IL-1RA, IL-8, IL-10, IFNγ, IP10, MCP1, and MIP1s are higher in COVID-19 patients than in healthy adults (Huang et al., 2020). IL-6, in particular, has been highly implicated in CRS and COVID-19 severity, and inhibition of IL-6/IL-6R activity may lead to improved patient outcome, increasing its desirability as a target (Figure 1) (Scheller et al., 2014; Tanaka et al., 2016; Zhang C. et al., 2020).

Throughout the process of viral entry, replication, and dissemination, there are several proteins that can serve as suitable targets for therapeutic intervention. The S protein is one of the candidates receiving the most focus, as it is necessary for viral entry into host cells and is highly specific to the virus itself. The host receptor ACE2 is another possible target, but the presence of ACE2 in non-lung tissues such as heart, kidney, and intestine (Hamming et al., 2004) could complicate its inhibition. Another host protein, the TMPRSS2 protease, is essential for viral entry into the cell, making it an additional viable target (Hoffmann et al., 2020).

The pipeline of AI-based drug discovery and vaccine development for COVID-19.

## Section: COVID-19 Drug Discovery › Protein-Based

The recent applications of Artificial Intelligence for COVID-19 include the virtual screening of both repurposed drug candidates and new chemical entities. For repurposed drugs, the goal has been to rapidly predict and exploit interconnected biological pathways or the off-target biology of existing medicines that are proven safe and can thus be readily tested in new clinical trials. In one of the early attempts, Gordon et al. paved the way for the repurposing of candidate drugs by experimentally identifying 66 human proteins linked with 26 SARS-CoV-2 proteins (Gordon et al., 2020). In addition to wet-lab approaches, network-based model simulation has been the main computational approach for analyzing the virus–host interactome (Messina et al., 2020). Li et al. identified 30 drugs for repurposing by analyzing the genome sequence of three main viral family members of the coronavirus and then relating them to the human disease-based pathways (Li X. et al., 2020). In a different approach, Zhou et al. offered a combination of network-based methodologies for repurposed drug combination (Zhou Y. et al., 2020).

UK-based BenevolentAI leveraged its AI-derived knowledge graph, which integrates biomedical data from structured and unstructured sources (Richardson et al., 2020). It targeted the inhibition of host protein AAK1 and identified Baricitinib, an approved drug for the treatment of rheumatoid arthritis (Stebbing et al., 2020). Similarly, Beck et al. published an application of their DL-based drug–target interaction model that predicted commercially available antiviral drugs that may target the SARS-COV-2-related protease and helicase (Beck et al., 2020a). Atomwise has also focused on targeting several SARS-CoV-2 protein binding sites that are highly conserved across multiple coronavirus species in an effort to develop new broad-spectrum antivirals. Using its AtomNet® deep convolutional neural network technology (Wallach et al., 2020), Atomwise is screening millions of virtual compounds against these diverse targets alongside 15 different partnerships with academic researchers that will test the predicted compounds in their in vitro assays2.

There have been several other applications of multi-task deep learning models for identifying existing drugs that can target the main viral proteins, especially the main protease (3CLpro) and spike protein (Hu et al., 2020; Kadioglu et al., 2020; Kim J. et al., 2020; Redka et al., 2020). One impressive example is Cyclica's creation and mining of PolypharmDB, a platform of known drugs and their predicted binding to human protein targets that uncovered off-target applications of 30 existing drugs against the viral protein 3CLpro and the ACE2 binding site as two examples (Redka et al., 2020). At least two other applications of DL-based virtual screening for the SARS-CoV-2 main protease have been published and include the open sharing of newly predicted chemical structures (Bung et al., 2020; Zhang H. et al., 2020).

ML-aided molecular docking has been one of the most prevalent approaches for virtual screening. This process normally requires the following: (1) Dataset of Druglike or Approved Molecules, (2) Crystal Structure or Homology Model of the target, (3) Molecular Docking Program, and (4) Compute Resources (Ewing et al., 2001; Pagadala et al., 2017). Through docking, many molecules have been reported to fit the binding site of various SARS-CoV-2 proteins essential for viral replication and infection. 3CLpro, Spike Protein, RdRP, and PLpro are among those screened, as well as the host ACE2 receptor and TMPRSS2 protease (Chen et al., 2020; Choudhary et al., 2020; Kong R. et al., 2020; Smith and Smith, 2020; Wu et al., 2020). As an example, Ton et al. identified at least 1000 protease inhibitors by creating and utilizing the Deep Docking (DD) network technology approach. However, as they used the QSAR for training their model, no novel docking score was provided (Ton et al., 2020).

It is clear that 3CLpro is the most popular target for virtual screening (Figure 1). The main reason for this is its pivotal role in viral replication and transcription and its well-defined structural information. Viral protease inhibitors have been extensively studied as treatments for other viruses. In addition, deep learning-aided approaches have been the main focus of research, as their automatic feature extraction accelerates discovery. The datasets cited often rely on the ZINC database (Wu et al., 2020), while other screened datasets include the FDA-approved LOPAC library (Choudhary et al., 2020), SWEETLEAD library (Smith and Smith, 2020), or all purchasable drugs (Drugs-lib) (Chen et al., 2020). Moreover this review sampled a variety of publications witch used different computational resources. It can be carried out on a small scale on a MacOS Mojave Workstation with an 8 core Zeon E5 processor or on a large scale as with the world's strongest supercomputer, SUMMIT, for enhanced parallelization (Choudhary et al., 2020; Smith and Smith, 2020).

## Section: COVID-19 Drug Discovery › RNA-Based

Conserved structured elements have already been shown to play critical functional roles in the life cycles of Coronaviruses (Yang and Leibowitz, 2015). Through direct interactions with host RNA-binding proteins and helicases, structural elements add a layer of complexity to the regulatory information that is encoded in the viral RNA. Targeted disruption of the regulatory functions of these structural elements provides a largely unexplored strategy that can limit viral loads with minimal impact on the biology of normal cells (Park et al., 2011). While this idea would have been farfetched a mere 5 years ago, advances in AI-driven computational modeling and high-throughput experimental RNA shape analyses have all but overcome the critical barriers (Alipanahi et al., 2015).

Highly conserved RNA structural elements have been identified in a number of viral families, many of which have been functionally validated (Jaafar and Kieft, 2019). Some of these stem loops in SARS-CoV-2′s 5′UTRs structural elements are conserved across beta coronaviruses and are known to impact viral replication (Yang and Leibowitz, 2015). There are many functional RNA structural elements that fall within the coding sequence and the 3′UTR as well (Plant and Dinman, 2008; Stammler et al., 2011). Rangan et al. identified 106 structurally conserved regions that would be suitable biotargets for unexplored antiviral agents (Rangan et al., 2020). Moreover, they predicted at least 59 unstructured regions that are conserved within SARS-CoV-2. Park et al. identified an RNA Pseudoknot-Binding molecule against SARS-CoV-1 in target-based virtual screening (Park et al., 2011; Nakagawa et al., 2016).

Studying the changes in RNA information also allows for the identification of new and evolved targets. In a different approach, Wu et al. showed that a recently FDA-approved drug named Remdesivir could bind to the RNA-binding channel of the novel coronavirus. They discovered other candidate drugs via analyzing the proteins critical to RNA processing and pathways (Wu et al., 2020). It seems that viral genome, RdRP, and processed mRNA would make promising targets for drug repurposing.

## Section: COVID-19 Drug Discovery › Generative Approaches

Molecule generation has been one of the fields of drug discovery that have been most revolutionized by the implementation of artificial intelligence over the last decade. As mentioned, VAE is a generator model for enhancing the diversity of generated data. Autoencoders instruct molecules into a vector that captures properties such as bond order, element, and functional group (Bjerrum and Sattarov, 2018). Chenthamarakshan et al., together with IBM Research, demonstrated a VAE that captures molecules in a latent space. Once captured, variations are made on the original molecule vectors based on desired properties. These can then be decoded back into novel molecules (Chenthamarakshan et al., 2020). To optimize the structures, QED, Synthetic Accessibility, and LogP regressors were used to improve the latent space variations.

In a different approach, Tang et al. overcame many of the issues with traditional generative models by developing a novel advanced deep Q-learning network with fragment-based drug design (ADQN-FBDD). This allowed for the enhanced exploration of space by assembling SARS-CoV-2 molecules one fragment at a time rather than relying on latent space adjustments. After making connections and rewarding molecules with the most druglike connections, a pharmacophore and descriptor filter was used to refine the set. They demonstrated a robust method for designing novel, high-binding compounds refined to the structure of SARS-CoV-2 3CLPro (Tang et al., 2020). To design a drug-generative network, the following is necessary: (1) collection of Druglike Molecules, (2) a representation of these molecules in silico (i.e., Fingerprints, Tokenizers), (3) a method of altering molecules to increase diversity, and (4) screening and modification of the altered molecules. Pursuing GAN-related models, Insilico Medicine used three of its previously validated generative chemistry approaches to target the main protease, namely, crystal-derived pocked-based generation, homology modeling-based generation, and ligand-based generation (Zhavoronkov et al., 2020). Similar to target-based virtual screening, the main protease has been the main object of interest for scientists for de novo drug discovery.

## Section: COVID-19 Vaccine Discovery

Identification of the best possible targets for the development of a vaccine is crucial in order to counteract a virus's high infection rate (Choudhary et al., 2020). A host immune system fights virus-infected cells either through the production of antibodies by B cells or through the direct attack of T cells (Amanat and Krammer, 2020). The HLA gene encodes MCH-I and MCH-II proteins, which present epitopes as antigenic determinants. These proteins assist B-cell and T-cell antibodies in their ability to bind and attack invaders (Dangi et al., 2018; Gupta et al., 2020; Smith and Smith, 2020). Machine learning approaches, including Random Forest (RF), Support Vector Machine (SVM), and Recursive Feature Selection (RFE), have been basic tools for identifying antigens from protein sequences (Bowick et al., 2010; Rahman et al., 2019). However, due to their low sensitivity in the prediction of locally clustered interactions in some cases, Deep Convolutional Neural Networks (DCNN) have been a more valid alternative for the binding prediction of MHC and peptides (Han and Kim, 2017).

Since the outbreak of this first coronavirus, different AI-based approaches have been used to predict potential epitopes so as to design vaccines (Park et al., 2011; Yang and Leibowitz, 2015; Ton et al., 2020). Fast and Chen used MARIA (Chen et al., 2019) and NetMHCPan4 (Jurtz et al., 2017), two supervised neural network-driven tools, to discover potential T-cell epitopes for SARS-CoV-2 close to the 2019-nCoV spike receptor-binding domain (RBD) (Fast and Chen, 2020). The Long Short-Term Memory (LSTM) network has also shown some promising results. Abbasi et al. used this type of RNN to predict epitopes for Spike (Abbasi, 2020). Using a similar tactic, Crossman et al. employed deep-learning RNN and provided simulated sequences of Spike to identify possible targets for vaccine design (Crossman, 2020). RNN provided the sequences for a protein of interest with high sequence identity to the BLAST match.

Using a separate method, Feng et al. leveraged the iNeo tool to design a vaccine containing both B-cell and T-cell epitopes. This multi-peptide vaccine could provide a new strategy against SARS-CoV-2. Additionally, they discovered 17 vaccine peptides involving both immune cells (Nakagawa et al., 2016; Rangan et al., 2020). Ong et al. used Vaxign-RV to prioritize non-structural proteins as vaccine candidates for SARS-CoV-2 (Ong et al., 2020b). Nsp3, the largest non-structural protein of the coronavirus family, was identified as the most promising potential target for vaccine development after Spike (Ong et al., 2020b). Malone et al. also studied the entire SARS-CoV-2 proteome beyond Spike and provided a comprehensive vaccine design blueprint for SARS-CoV-2 using NEC Immune Profiler, IEDB, and BepiPred tools to create an epitope map for different HLA alleles (Malone et al., 2020).

Natural language processing models, specifically language modeling techniques, have also made an impact in the domain of COVID-19 vaccine discovery. Pre-trained transformers were used to predict protein interaction (Nambiar et al., 2020) and model molecular reactions in carbohydrate chemistry (Pesciullesi et al., 2020), which can be utilized in the process of vaccine development. Chen et al. discussed the use-case of an LSTM-based seq-2-seq model for predicting the secondary structure of certain SARS-COV-2 proteins (Karpov et al., 2019)3. Also, Beck et al. used transformers to repurpose commercially available drugs by predicting their interactions with viral proteins of SARS-COV-2 (Beck et al., 2020b).

Taking this work together, it is clear that spike protein has been the most popular candidate for virtual vaccine discovery (Oany et al., 2014). As the spike protein of SARS-COV-2 is crucial for viral entry, specific neutralizing antibodies against the receptor-binding domain of Spike can interrupt the attachment and fusion of viral proteins (Wan et al., 2019). This method could provide simulated sequences that can serve as a guide for further vaccine discovery against COVID-19 and possibly new zoonosis that may arise in the future.

## Section: Data Collection

Data-driven solutions rely on patterns embedded in the data in order to extract mathematical models. That being said, a data collection campaign will face a plethora of challenges in the case of any recently emerged virus, primarily due to the existence of bias and imbalance in the limited data available. Therefore, even the most sophisticated of modeling approaches will be ineffective when trained on such datasets. In order to overcome this issue, we compiled a multifaceted and comprehensive investigation of the existing literature, datasets, and online resources to provide potential small molecules, peptides, and epitopes. Such elements can be beneficial in the process of discovering or designing novel drugs to treat COVID-19 when used with both conventional and data-driven AI-based approaches.

We choose to focus on both potential antiviral agents and host biotarget inhibitors. The provided data entitled CoronaDB-AI in Table 1 includes the small molecules and peptides proposed by both in-silico and in-vitro approaches. In addition to candidate scaffolds against the coronavirus's structural proteins, the potential inhibition of other respiratory tract viruses is taken into consideration to increase the therapeutic potential. Antimicrobial peptides have been validated as potent antivirals that disrupt either the viral membrane or an additional molecular mechanism of the virus (Akaji et al., 2011; Han and Kraí, 2020; Xia et al., 2020). As described before, the cytokine storm and an elevated immune response of the host plays a vital role in disease complication, so candidate immunosuppressants were also added as host-targeted agents. In addition to the potency of a candidate drug, it is crucial that the drug have high selectivity and low toxicity. Therefore, we also gathered a complete toxicity dataset from distinct databases, including ToxCast and Tox21. Finally, we gathered a comprehensive epitope-based dataset that could also guide deep learning-based models for improved vaccine development and epitope generation.

CoronaDB-AI is a collection of small molecules, peptides, and epitopes for the purpose of COVID-19 therapy discovery.

## Section: Discussion

SARS-COV-2 rapidly transformed into a global challenge, costing thousands of lives, overwhelming healthcare systems, and threatening the economy all around the world. As we demonstrated above, it can be extremely challenging to experimentally perform a comprehensive potency evaluation of all drug and vaccine candidates in a timely fashion. We believe that leveraging computational models capable of filtering and generating reliable therapies can significantly speed up these discovery efforts. Employing artificial neural networks and supervised learning methods has proven to be a vital game-changer when used for the purpose of virtual filtering and de novo design. However, in order to achieve the desired performance in such intelligent methods, one requires the knowledge to recognize the most relevant biotargets in addition to a large-scale training dataset. This fact motivated us to perform a survey of biotargets that have been employed in the virtual drug and vaccine discovery literature. We observed that the viral spike protein and the main protease have been the most prevalent choices for vaccine development and drug discovery, respectively, due to their importance. Furthermore, we gathered a list of datasets titled “CoronaDB-AI” that can be used for our particular application. Having access to these key elements removes the burden of collecting training data and the required knowledge for both computer scientists and bioinformaticians and consequently enhances research outcomes.

## Section: Author Contributions

AK organized and wrote most of article and gathered all the data. JW contributed to the molecular part. MS contributed to the background for AI-based methods. EC, ED-C, and BK from A2A and SC-T from Atomwise contributed to the COVID19 drug discovery. NG and JC contributed to the vaccine discovery. HG contributed to the RNA-based and molecular sections. JY provided guidance in the opportunities of deep learning in a multidiscipline collaboration. All authors contributed to the article and approved the submitted version.

## Section: Conflict of Interest

EC, ED-C, and BK were employed by the company A2A Pharmaceuticals. SC-T was employed by the company Atomwise Inc. The remaining authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.

## Section: Acknowledgments

We thank Farnam Kavehei for designing the figure. Also, we thank Melana Francisco for her contribution to the introduction of the article.


---

# Artificial intelligence in drug discovery: what is realistic, what are illusions? Part 1: Ways to make an impact, and why we are not there yet

- **Authors:** Andreas Bender, Isidro Cortés-Ciriano
- **Issuer:** Drug discovery today
- **Type:** Scientific article
- **Published:** 2020-12-17
- **Language:** en
- **DOI:** 10.1016/j.drudis.2020.12.009
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33346134/
- **Licence:** CC-BY

## Section: Abstract

Although artificial intelligence (AI) has had a profound impact on areas such as image recognition, comparable advances in drug discovery are rare. This article quantifies the stages of drug discovery in which improvements in the time taken, success rate or affordability will have the most profound overall impact on bringing new drugs to market. Changes in clinical success rates will have the most profound impact on improving success in drug discovery; in other words, the quality of decisions regarding which compound to take forward (and how to conduct clinical trials) are more important than speed or cost. Although current advances in AI focus on how to make a given compound, the question of which compound to make, using clinical efficacy and safety-related end points, has received significantly less attention. As a consequence, current proxy measures and available data cannot fully utilize the potential of AI in drug discovery, in particular when it comes to drug efficacy and safety in vivo. Thus, addressing the questions of which data to generate and which end points to model will be key to improving clinically relevant decision-making in the future.


---

# Biomarkers: Opportunities and Challenges for Drug Development in the Current Regulatory Landscape

- **Authors:** Mariya Gromova, Annegret Vaggelas, Gabriele Dallmann, Diane Seimetz
- **Issuer:** Biomarker insights
- **Type:** Scientific article
- **Published:** 2020-12-08
- **Language:** en
- **DOI:** 10.1177/1177271920974652
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33343195/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractBiomarkers are widely used at every stage of drug discovery and development. Utilisation of biomarkers has a potential to make drug discovery, development and approval processes more efficient. An overview of the current global regulatory landscape is presented in this article with particular emphasis on the validation and qualification of biomarkers, as well as legal framework for companion diagnostics. Furthermore, this article shows how the number of approved drugs with at least 1 biomarker used during development (biomarker acceptance) is affected by the recent advances in the biomarker regulations. More than half of analysed approvals were supported by biomarker data and there has been a slight increase in acceptance of biomarkers in recent years, even though the growth is not continuous. For certain pharmacotherapeutic groups, approvals with biomarkers are more common than without. Examples include immunosuppressants, immunostimulants, drugs used in diabetes, antithrombotic drugs, antineoplastic agents and antivirals. As a conclusion, potential benefits, challenges and opportunities of using biomarkers in drug discovery and development in the current regulatory landscape are summarised and discussed.Keywords: Biomarker, EMA, FDA, regulatory landscape, qualification, companion diagnostics, drug development, drug approval

## Section: Introduction

Biomarkers have been used for centuries as indicators of human health or for the diagnosis of pathological conditions. One of the oldest biomarkers used to diagnose certain illnesses was the arterial pulse, which was already documented in ancient Chinese, Indian, Egyptian and Greek medicine.1 This was followed by blood pressure experiments, which were conducted for the first time in the middle of the 18th century.2 Arterial pulse, blood pressure and many other biomarkers, such as body temperature and quantification of various blood components (eg, cholesterol levels), have now become an essential part of modern healthcare globally.

In general, the term ‘biomarker’ refers to a biological parameter that can be measured or quantified accurately and reproducibly. This term is incredibly diverse and includes physiological parameters (eg, diastolic pressure) as well as molecular (eg, liver enzymes, blood glycose), histologic and imaging characteristics (eg, angiography).3 Nowadays, biomarkers are widely used in diagnostics, to ensure safety of treatment and to guide clinical decisions. Furthermore, since the beginning of the 21st century, biomarkers have gained prominence in drug discovery, development and approval processes, as described in Figure 1. Development of suitable biomarker can contribute to understanding the mechanism of action of a drug, selecting right patients for a clinical trial, monitoring and prediction of toxicity issues and guiding regulatory as well as drug development decisions. Furthermore, biomarkers facilitate more adaptive development paradigm, meaning that the traditional clinical phase 1, phase 2 and phase 3 designs are likely to become less important. Consequently, the regulatory strategies will need to be adapted.4 All of this has a potential to make development more sustainable, to improve quality and safety of a drug, to reduce development costs and to accelerate the approval process significantly.

The aims of this article are (1) to present an overview of the current global regulatory landscape for biomarkers, (2) to evaluate how it affects the number of approved drugs with at least 1 biomarker used during development (ie, biomarker acceptance) in the European Union (EU) and the United States of America (US) and (3) to describe potential benefits and challenges of using biomarkers in drug development.

Drug discovery and development processes with a potential to benefit from biomarkers phase I, II and III refer to clinical trial phases. NDA, new drug application (FDA); BLA, biological license application (FDA); MAA, marketing authorisation application (EU).

## Section: Biomarker Definitions and Classification

To date there is no standardised definition of the term biomarker. European Medicines Agency (EMA) defines a biomarker as ‘biological molecule found in blood, other body fluids, or tissues that can be used to follow body processes and diseases in humans and animals’.5 In the Biomarkers, EndpointS and other Tools (BEST) Resource glossary, a biomarker is ‘a defined characteristic that is measured as an indicator of normal biological processes, pathogenic processes, or responses to an exposure or intervention, including therapeutic interventions. [. . .] A biomarker is not an assessment of how an individual feels, functions, or survives’, a category of measure known as clinical outcome assessment (COA).6 BEST Resource was developed in 2016 by the Food and Drug Administration – National Institutes of Health (FDA-NIH) Biomarker Working Group and its main aim is to clarify and harmonise terminology and thus speed up the research, development and testing on novel methodologies, in particular biomarkers. According to the BEST Resource glossary, each biomarker belongs to 1 of 7 defined categories, described in Table 1. It is also possible that a biomarker belongs to several categories, but only given that enough evidence is generated for each category.7 This is the case with BReast CAncer genes 1 and 2 (BRCA1/2) mutations that can be used as both predictive and prognostic biomarkers (Table 1).

BEST Resource also covers definition of surrogacy and underlines that not every biomarker can be a surrogate endpoint. A surrogate marker is a ‘laboratory measurement or physical sign that is used in therapeutic trials as a substitute for a clinically meaningful endpoint that is a direct measure of how a patient feels, functions, or survives and is expected to predict the effect of the therapy’.15 On the contrary, the majority of known biomarkers lack sufficient data to prove the direct relation between the level of a biomarker and the clinical outcome, that is, the change in the biomarker does not necessary explain the change in the clinical outcome.7 There are also other more sophisticated biomarker categories that are not covered by BEST Resource glossary, for example, digital biomarkers.7

Biomarkers categories according to BEST Resource glossary.

## Section: Current Regulatory Landscape for Biomarkers

In the majority of cases biomarkers are currently studied and evaluated as part of drug development programme, that is, linked to a particular drug development. As both drug development and biomarker development are extremely cost- and time-intensive, it might be challenging for a sponsor to develop both simultaneously.16 The current regulatory landscape for biomarkers progresses rapidly, with ongoing developments for both publicly reported biomarkers and biomarkers used in individual development programmes. There is a tendency though to promote availability of public data on biomarkers, which aids cost reduction and resource optimisation for both drug developers and regulatory agencies.

Rapid development of regulations in biomarkers field began in early 21st century and is closely linked to the development of the ‘personalised medicine’ concept involving delivery of tailored therapy to a particular patient, based on his genetic and epigenetic information. ICH E15 Guideline17 was published in 2006 and defines pharmacogenomics (PGx, study of variations of DNA and RNA characteristics as related to drug response) and pharmacogenetics (PGt, study of variations in DNA sequence as related to drug response). Genomic biomarkers are DNA or RNA characteristics that are a crucial part of drug development and essential for successful regulatory approval.18,19 Examples of the use of genomic biomarkers in drug development include:

Numerous PGx and PGt related guidelines are available from both EMA and FDA.20-27 This article will describe in detail the regulatory framework applicable for the biomarker qualification in the European Union (EU) and the United States of America (US). It will also address the regulatory systems to be followed in both regions for placing on the market of companion diagnostic (CDx) assays that are utilised to test predictive biomarkers.

EMA novel methodologies qualification procedure. QT, qualification team; LoQ, list of questions; LOI, Letter of Intent; SAWP, scientific advice working party; CHMP, Committee for Medicinal Products for Human Use; Figure created based on the information provided in EMA guidance to applicants ‘Qualification of novel methodologies for drug development’.33

Possible outcomes of the EMA Novel Methodologies Qualification procedure. Figure created based on the information provided in EMA guidance to applicants ‘Qualification of novel methodologies for drug development’.33

FDA Biomarker Qualification Program procedure. DDT, Drug Development Tools; LOI, Letter of Intent, Figure created based on the information provided in FDA draft guidance for industry and FDA staff ‘Qualification process for drug development tools’.38

Description of each step of the FDA Biomarker Qualification Program procedure.

EMA SAWP/CHMP biomarker qualifications to date (as of 30th of March 2020).

Qualified biomarkers by FDA CDER BQP to date (as of 19th of February 2020).

Regulatory framework for investigational medical devices in the US.

## Section: Current Regulatory Landscape for Biomarkers › Biomarker validation and qualification

One of the main challenges in the biomarker field is to distinguish between a potential biomarker and a reliable biomarker that can be universally used to guide important clinical and commercial decisions. Scientific justification behind biomarkers and interpretation of biomarker measurements are not always reliable and appropriate. As a response to the increasing need to address quality and suitability of biomarkers, concepts of biomarker qualification and validation have been developed.28 Biomarker validation refers to the validation of analytical assays, that is, assessment of performance characteristics, such as, for example, precision, accuracy, detection limit and robustness. Biomarkers qualification, on the other hand, is providing evidence that biomarker is linked with a certain biological process and clinical endpoint.29,30

The fact that development of better evaluation tools and biomarkers in particular was named a top priority of the FDA’s Critical Path Opportunities Report in 2006 underlined the importance of defining biomarkers validation and qualification processes.31 Joint effort of FDA, EMA and Predictive Safety Testing Consortium’s (PSTC) Nephrotoxicity Working Group created the pilot process for biomarker qualification. As a result, 7 renal safety biomarkers have been qualified for limited use in nonclinical and clinical development in 2010.28,32 The first qualification of renal safety biomarkers has not only become a basis for the still evolving biomarkers qualification procedure, but also emphasised the willingness of agencies to collaborate in this area. The following sections will focus on the biomarker qualification procedures in the EU and the US.

EMA novel methodologies qualification procedure. QT, qualification team; LoQ, list of questions; LOI, Letter of Intent; SAWP, scientific advice working party; CHMP, Committee for Medicinal Products for Human Use; Figure created based on the information provided in EMA guidance to applicants ‘Qualification of novel methodologies for drug development’.33

Possible outcomes of the EMA Novel Methodologies Qualification procedure. Figure created based on the information provided in EMA guidance to applicants ‘Qualification of novel methodologies for drug development’.33

FDA Biomarker Qualification Program procedure. DDT, Drug Development Tools; LOI, Letter of Intent, Figure created based on the information provided in FDA draft guidance for industry and FDA staff ‘Qualification process for drug development tools’.38

Description of each step of the FDA Biomarker Qualification Program procedure.

EMA SAWP/CHMP biomarker qualifications to date (as of 30th of March 2020).

Qualified biomarkers by FDA CDER BQP to date (as of 19th of February 2020).

## Section: Current Regulatory Landscape for Biomarkers › Biomarker validation and qualification › Biomarker qualification in the EU

A voluntary procedure for qualification of biomarkers has been developed by EMA and is described in the EMA guidance for applicants ‘Qualification of novel methodologies for drug development’.33 Novel methodologies include not only biomarkers, but also clinical outcome assessments, symptom scales, animal models, statistical methods etc. The Scientific Advice Working Party (SAWP) and Committee for Medicinal Products for Human Use (CHMP) are both involved in the qualification of novel methodologies, which can lead to 2 possible outcomes: CHMP Qualification Advice or CHMP Qualification opinion.34

The procedure for EMA novel methodologies qualification is depicted in Figure 2, and starts with the submission of a Letter of Intent (LOI) and a draft dossier at Day-60. At this stage, it is not compulsory to decide which pathway to follow, that is, qualification opinion or qualification advice. EMA validation procedure follows shortly after initial submission, similar to the process utilised in the Scientific Advice procedure.33 Furthermore, a qualification team (QT) is usually appointed during the first weeks after initial application. The core QT consists of at least 5 members, that is, 1 to 2 coordinators (SAWP or CHMP) and at least 4 subject experts. Subject experts are chosen based on the context of use of the technology of interest (eg, translational research, nonclinical safety testing etc.), technology platform (eg, genomics, proteomics etc.) and additional needs for this particular project (ie, statisticians, experts in particular therapeutic area).34 Subject experts can be members of CHMP, SAWP, other EMA working parties or European experts’ network. When the QT is determined, the procedure starts at Day 0 followed by extensive discussion during QT meetings, SAWP meetings and meetings with the applicant. During this timeframe, a List of Questions (LoQ) to the applicant is issued and discussed. As the result, at Day 70, a draft report is issued. Moreover, at Day 90 SAWP issues a recommendation on whether to follow the qualification opinion or advice pathway, based on the type of request and available data. For the qualification advice pathway, CHMP adopts the qualification advice for future studies during the first CHMP Meeting at Day 100.33 Alternatively, if enough information is available, a draft qualification opinion will be issued, discussed and adopted during the first and the second CHMP meetings (Day 100 and 130). After adoption by CHMP, the qualification opinion is always released for a 6-week public consultation period to collect opinions of the scientific community. Following this, the CHMP Qualification opinion is adopted and published on the EMA website 15 days later. EMA and CHMP may then organise qualification workshops to familiarise interested parties with the qualified methodology.33

Overall, the procedure for the qualification advice and opinion lasts 160 days and 250 calendar days, respectively. Clock-stops may be requested during the procedure and will further extend the timeline. Possible outcomes of the above-described procedure are summarised in Figure 3. ‘CHMP Qualification Advice on future protocols and methods for further method development towards qualification’ is usually issued for candidate novel methodologies when more data are needed to support the proposed context of use.33 As soon as more/better quality data is collected, the CHMP Qualification opinion may be requested. CHMP Qualification Advice is confidential, as opposed to the CHMP Qualification opinion, which is publicly available. When the CHMP Qualification Advice is issued, EMA may propose a Letter of support for novel methodologies, which is also publicly available and aims to encourage data sharing and thus to facilitate future studies.33

To maximise a chance of scientific consensus, EMA allows and encourages involvement of non-EU regulatory agencies in parallel qualification procedure. This is facilitated by the existing confidentiality agreement between the FDA/PMDA and the EMA. An option to submit a joint Letter of Intent (LOI) to EMA and FDA was introduced in December 2014 and has been recently discontinued. At present, it is the responsibility of the applicant to ensure that other agencies are informed about the parallel qualification before the start of EMA qualification procedure.33 EMA qualification procedure is associated with fees, similar to Scientific Advice fees.

EMA novel methodologies qualification procedure. QT, qualification team; LoQ, list of questions; LOI, Letter of Intent; SAWP, scientific advice working party; CHMP, Committee for Medicinal Products for Human Use; Figure created based on the information provided in EMA guidance to applicants ‘Qualification of novel methodologies for drug development’.33

Possible outcomes of the EMA Novel Methodologies Qualification procedure. Figure created based on the information provided in EMA guidance to applicants ‘Qualification of novel methodologies for drug development’.33

## Section: Current Regulatory Landscape for Biomarkers › Biomarker validation and qualification › Biomarker qualification in the US

Depending on the chosen strategy, data for each biomarker can either be reviewed as part of regulatory submissions for the drug under development (ie, IND/NDA/BLA) or in a separate qualification procedure. Following qualification, biomarker-related data is made public and can be used for development of multiple drugs.35 Qualification of biomarkers implies FDA’s agreement that a particular biomarker and its proposed context of use (COU) can be used in drug development and for regulatory submissions without FDA having to reconfirm its suitability.36 COU is crucial for biomarker qualification and consists of BEST biomarker category and the intended use in drug development, for example, ‘Safety biomarker for the detection of acute drug induced renal tubule alterations in male rats’.37

In the US, biomarkers can currently be qualified using the Center For Drug Evaluation and Research (CDER) Biomarker Qualification Program (BQP) that is described within the ‘Drug Development Tools’ (DDTs) Program. DDTs are methods, materials, or measures that have the potential to facilitate drug development36 and include not only biomarkers, but also clinical outcome assessments (COA), animal models etc. There are no fees for a BQP procedure. Development of DDTs is described in the draft guidance ‘Qualification process for drug development tools’ that was issued by FDA in January 2014 and was replaced by the draft guidance with the same name in December 2019 to incorporate requirements outlined in Section 3011 of the 21st Century Cures Act of 2016, that is, addition of the new section 507, Qualification of Drug Development Tools (DDTs), to the Federal Food, Drug and Cosmetic Act (FD&C Act). When finalised, this guidance will describe ‘CDER and CBER’s (Center for Biologics Evaluation and Research) current thinking on taxonomy for biomarkers and other drug development tools (DDTs)’.38 The taxonomy of biomarkers and other DDTs described in this guidance is based on the BEST Resource glossary. In addition to DDTs Program, there is also a ‘Medical Device Development Tools’ (MDDTs) Program that includes biomarker tests, that is, lab tests used to detect biomarkers and is described in a separate FDA Guidance.39

Normally each biomarker should be submitted separately for a qualification unless several biomarkers are intended to be combined in a particular way to represent a single COU. BQP is a 3-stage process, as illustrated in Figure 4. Each stage consists of initial assessment by FDA, comprehensive review and DDT Committee evaluation.38

The amount of data and the expected level of details increases gradually during the process and is described in Table 2. The completion of each stage is determined by the issue of Determination Letter: accept or not accept for LOI and QP stages; and qualified or not qualified for FQP stage. For LOI and QP stages, the application will only proceed to the next stage in case of receipt of an accept Determination Letter.

BQP and other DDT qualification projects are usually complex and require an interdisciplinary approach as well as dedicated financial investments. To aid biomarker qualification, FDA issued a draft guidance for industry and FDA staff entitled ‘Biomarker Qualification: Evidentiary Framework’ in 2018. This guidance provides recommendations on general considerations to address when developing a biomarker for qualification and describes the evidentiary framework that should be used when determining the level of details required for successful qualification.40 The evidentiary framework requires a detailed description of the need assessment, proposed COU and benefit-risk assessment for a particular biomarker. Extensive collaborations are accepted and promoted by FDA. The assessment of DDTs and corresponding COUs is performed by subject matter experts (SMEs), that is, internal FDA staff and external specialists focusing on the required area. SMEs then contribute to the list of considerations and recommendations to the DDT Committee.35 FDA also encourages collaborations and data sharing between single entities developing biomarkers to facilitate and accelerate the DDT development process, for example, by establishing public-private partnerships.

FDA qualification procedure is free of charge, as opposed to EMA. Both FDA and EMA underline the importance of interdisciplinary collaboration and extensive communication between the applicant(s) and the agencies.

FDA Biomarker Qualification Program procedure. DDT, Drug Development Tools; LOI, Letter of Intent, Figure created based on the information provided in FDA draft guidance for industry and FDA staff ‘Qualification process for drug development tools’.38

Description of each step of the FDA Biomarker Qualification Program procedure.

## Section: Current Regulatory Landscape for Biomarkers › Biomarker validation and qualification › Qualified biomarkers

In addition to EMA and FDA efforts to promote biomarker qualification, the International Council for Harmonisation of Technical Requirements for Pharmaceuticals (ICH) issued the draft harmonised Guideline E16 in August 2010 summarising recommendations on the structure for biomarkers qualification applications, format of submissions and formulation of context of use.41 This guideline is mainly focused on genomic biomarkers, but principles are applicable to other types of biomarkers. ICH E16 has already been implemented in the EU, US, Canada, South Korea, Japan and Switzerland.42 This was a crucial step to the increasing acceptance of biomarkers in drug development globally.43

The biomarkers already qualified by EMA and FDA are shown in Tables 3 and 4, respectively. 21 novel methodologies have been qualified by EMA SAWP/CHMP, 8 of which are biomarkers.44 Moreover, further 10 biomarkers have received a Letter of support from CHMP and may be qualified in the future. Eight biomarkers have already been qualified using FDA CDER BQP, as shown in Table 4, 4 of which are related to kidney disease or injury.45 Qualified biomarkers belong to safety, diagnostic, prognostic and monitoring categories according to the BEST Resource glossary. In addition, 41 biomarkers have been submitted to FDA, but were not qualified yet, including legacy projects in transition to 507 process.46

Qualification of urinary renal safety biomarkers, including kidney injury molecule-1 (KIM-1), clusterin (CLU), albumin, total protein, β2-microglobulin, cystatin C and trefoil factor 3 (TFF3) is the first formal qualification of biomarkers for both EMA and FDA.32 The request was made by Predictive Safety and Testing Consortium (PSTC), Nephrotoxicity Working Group. This qualification required extensive communication between FDA/EMA and PSTC in order to address data gaps, reach scientific consensus and initiate establishment of new biomarker qualification processes in both agencies.32,47 It was demonstrated that following the qualification of KIM-1 biomarker for the detection of acute drug-induced nephrotoxicity assessment in rats, citation rate for KIM-1 biomarker increased significantly and the biomarker was widely further investigated both in research and drug development.48

Information published by requestors following the successful biomarker qualification allows to identify the most common challenges experienced during the biomarker qualification procedure:

Therefore, in order to overcome these challenges and gain regulatory endorsement of a biomarker, input from numerous organisations and experts is required. This explains why biomarker qualifications are more often requested by academic groups and consortia, rather than by single commercial drug developers. Collaboration allows sharing the cost and risks associated with biomarker qualification and gives access to more extensive and diverse clinical data. Furthermore, commercial drug developers are often reluctant to invest upfront into biomarkers and make biomarkers data available in public domain.

EMA SAWP/CHMP biomarker qualifications to date (as of 30th of March 2020).

Qualified biomarkers by FDA CDER BQP to date (as of 19th of February 2020).

## Section: Current Regulatory Landscape for Biomarkers › Companion diagnostics

The term companion diagnostic (CDx) is used for the assay that is utilised to test predictive biomarkers to classify patients and identify those with higher chance to respond to therapy, those who are likely to develop certain side effects and/or to monitor response to treatment. Thus, CDx plays an important role in the development of more efficacious and safe medicines and is a crucial part of precision medicine.56 Certain disease areas, like oncology and neurodegenerative disorders, require more rapid testing to facilitate monitoring of the disease status and to guide more efficient treatment strategies.57 Development of CDx leads to an increased number of tumour-agnostic (histology-independent) approvals, creating new clinical and regulatory challenges and causing a paradigm shift, especially in oncology.

FDA defines CDx as ‘a medical device, often an in vitro device, which provides information that is essential for the safe and effective use of a corresponding drug or biological product. The test helps a health care professional to determine whether a particular therapeutic product’s benefits to patients will outweigh any potential serious side effects or risks’.58 CDx are also very closely defined in the new EU’s in vitro diagnostics medical device regulation (IVDR59) as ‘a device which is essential for the safe and effective use of a corresponding medicinal product to:

The regulatory path for the development and approval of CDx differs significantly between FDA and EMA. In the US, the development of IVDs is guided by The Investigational Device Exemptions (IDE) regulation, Title 21, Code of Federal Regulations (21 CFR) Part 812, which sets regulatory requirements for studies of investigational devices.60 Investigational IVDs may belong to one of the following categories depending on the level of risk that the study presents to subjects: significant risk (SR), non-significant risk (NSR) or excepted devices. Applicable regulations for each category are presented in Table 5.

FDA classifies CDx as Class III Medical Devices in the vast majority of cases, because the risk associated with CDx is similar to the risk associated with the drug that will or will not be administered on the basis of a CDx test.61 Class III Medical Devices require a premarketing approval (PMA) procedure according to section 515 of the FD&C Act,62 34 of 38 currently FDA-approved CDx have undergone the PMA procedure.63 Two CDx tests (MRDx BCR-ABL Test and FerriScan) have been cleared by 510(k) and 2 further devices cleared by a Humanitarian Device Exemption (HDE) (device intended to be used for a disease that affects less than 8000 individuals in the US per year).64 FDA issued the Guidance for Industry on In Vitro CDx in 2014.65 This guidance underlines the importance of early strategic decisions on whether CDx is needed, provides recommendations on co-development of drugs and IVDs and emphasises the importance of collaboration between FDA and CDx developers.

In July 2016 FDA released an extensive draft guidance ‘Principles for Co-development of an In-vitro Companion Diagnostic Device with a Therapeutic Product’,66 which discusses potential issues developers might face when co-developing IVD CDx and a therapeutic product, for example, (a) different schedules and agency interactions for therapeutic agents and CDx development and corresponding managing issues; (b) determination of the ‘goals of the therapeutic product development programme that are dependent on the IVD’; (c) deciding on what data are needed for NDA/BLA; (d) IVD in therapeutic product clinical trial design and assessment of the associated risks. Along with CDx, further definition of ‘Complementary Diagnostics’ is now being developed, meaning ‘Tests that identify a biomarker-defined subset of patients that respond particularly well to a drug and aid risk/benefit assessments for individual patients, but that are not pre-requisites for receiving the drug’. For example, PD-L1 IHC 28-8 pharmDx test may be used to determine PD-L1 expression that may be associated with enhanced survival from Opdivo® (nivolumab).67

In the EU, the legal framework for IVDs and thus for CDx is currently changing. Between the in vitro diagnostic medical device European Directive 98/79/EC (IVDD), the Directive currently in place, and the IVDR, the new regulation to come, a transition period is currently active. Accordingly, the IVDR will fully become effective on 26 May 2022.59 The companion diagnostics definition stated in IVDR is similar to the one provided by FDA. CDx are considered class C. Hence strict quality management, analytical testing and clinical trials are now required for CDx.68 In the EU, any device clinical trial application, including those needed for biomarker and CDx establishment, is regulated by national agencies and the procedure differs in each country according to the individual laws. The development process for investigational IVDs and CDx is thus required to be agreed by the sponsor, the national competent authority and the chosen notified body on a case-by-case basis. For example, according to the German Act on Medical Devices, some IVDs are eligible for a waiver of the authorisation of a clinical trial.69

In future, according to the IVDR, the conformity assessment process for CDx requires consultation between a notified body (currently involved in CDx assessment) and a competent authority, that is, EMA or national competent authority, which are not involved in the CDx assessment in the current system.68 The dialogue between notified bodies and EMA/national competent authorities will allow to assess the evidence that CDx is beneficial in combination with a particular drug and the evidence of CDx impact on patient outcome (clinical utility).68 The future CDx consultation procedure allows notified bodies to request a scientific opinion from the EMA or national competent authorities ‘on the basis of the draft summary of safety and performance and the draft instructions for use’. The timeframe for this assessment is set to 60 days and can be optionally extended to 120 days.59 To further support CDx development, EMA issued the ‘Concept paper on predictive biomarker-based assay development in the context of drug development and lifecycle’.70 This concept paper acknowledges that legislations covering medicinal products and IVDs are not directly linked in the EU and addresses the interface between predictive biomarker-based assays including CDx, and the development and lifecycle of medicinal products. If the labelling states ‘that a medicinal product should be used in conjunction with a predictive biomarker, any commercial assay used for this purpose will be considered a CDx’ and thus require CE-mark.70 It is not clear when the draft guideline based on this concept paper will be released.

In general, CDx development involves numerous scientific, operational and commercial decisions, such as choosing the sample type (eg, snap frozen, formalin-fixed, paraffin-embedded (FFPE) or RNAlater® preserved tissue samples; fresh samples or archived samples) and the analysis method (eg, immunohistochemistry (IHC), fluorescence in situ hybridisation (FISH), silver in situ hybridisation (SISH) or quantitative polymerase chain reaction (qPCR) for molecular diagnosis). Due to the high development cost, it is crucial to formulate a clear development and commercialisation strategy, which is usually based on 4 key developmental steps: identification of user need, definition of the intended use, creation of an integrated development plan and implementation of the quality management system.57 Setting a strategy for CDx/therapeutic product co-development requires diligent planning, experience and multidisciplinary work. Synchronising of co-development in different regions is challenging and requires constant monitoring of the regulatory framework and potential differences in regional regulations.

Regulatory framework for investigational medical devices in the US.

## Section: Biomarker Acceptance in Drug Development in the EU and the US

To evaluate the acceptance of biomarkers in the EU and the US, the number of approved drugs with at least 1 biomarker used during development was analysed.

EMA and FDA drug approvals with and without biomarkers between 2015 and 2019.

Selected EMA drug approvals with and without biomarkers between 2015 and 2019 by pharmacotherapeutic group.

## Section: Biomarker Acceptance in Drug Development in the EU and the US › Method: EMA approvals

For analysis of the approvals in the EU, the centralised procedure was considered (EMA). For EMA approvals, the ‘Download medicine data’ tool of the EMA website was used to access a table of all European public assessment reports (EPARs).71 EPARs are full scientific assessment reports of medicines authorised at the EU level. EPARs provide public information on human and veterinary medicines, including how it was assessed by EMA, and normally consist of several documents, such as summary for the public, product information, risk-management plan, public assessment report, summary of positive CHMP opinion, changes since initial authorisation of medicine.

The downloaded table of EPARs was then used to filter approvals using the following criteria:

The list of all approved drugs that followed these criteria was created and each EPAR was scanned for ‘biomarker’ and ‘marker’ keywords. The context in which these keywords appear in the assessment report was carefully evaluated, that is, ‘biomarker’ and ‘marker’ keywords were not taken into account if they are used in the wrong context, such as:

Cases when biomarkers were used for preselection of patients eligible/not eligible for a treatment, were included in the statistics.

## Section: Biomarker Acceptance in Drug Development in the EU and the US › Method: FDA approvals

Both CDER and CBER approvals were considered and several FDA tools were used, that is, list of FDA-approved biosimilars,72 CDER statistics,73 CBER statistics,74 and Drugs@FDA75 (to access fixed combinations approvals). The selection of drugs was performed using the following criteria:

The list of all approved drugs that followed these criteria was created. For CDER-approved drugs, Drugs@FDA tool was used to access drug approval package, which includes approval letter, printed labelling, product quality review, multi-discipline review, clinical review, statistical review, administrative and correspondence documents as well as other reviews. FDA CBER website was used to access the same documents for CBER-approved drugs. Every product approval package was then scanned for ‘biomarker’ and ‘marker’ keywords. The context in which these keywords appear in the assessment report was carefully evaluated using the same criteria as for EMA approvals.

## Section: Biomarker Acceptance in Drug Development in the EU and the US › Results

Figure 5 illustrates the number of drugs approved by EMA and FDA with at least 1 biomarker used during development (ie, biomarker acceptance) between 2015 and 2019. It can be clearly seen that more than half of the approvals were supported by biomarker data during at least 1 of the development stages. Remarkably, the proportion of approvals with biomarkers is comparable between EMA and FDA with average of 69% and 59%, respectively for the time period under consideration. There has been a slight increase in acceptance of biomarkers in recent years, even though the growth is not continuous. As of 16th of April 2020, more than 33 000 clinical trials involving biomarkers are registered in ClinicalTrials.gov database including around 4000 Phase 3 and 4 trials. Thus, the biomarkers acceptance is expected to grow rapidly in the nearest future.

Interestingly, as compared to the average EMA biomarker acceptance of 69%, EMA biomarker acceptance among orphan drugs is 87% and among drugs approved via EMA accelerated assessment is 88%. This implies that intrinsically more sophisticated development programmes are more open to innovative approaches, such as utilisation of biomarkers to facilitate determination of the benefit-risk profile, regulatory and development decisions. Biomarker acceptance is also relatively high among biosimilars: at least 1 biomarker was used during the development of 77% of biosimilars approved by EMA between 2015 and 2019. Moreover, approval documentation of more than 85% of monoclonal antibodies approved during the same period includes biomarker-related information.

Biomarker acceptance varies significantly with the pharmacotherapeutic group of the drug. As illustrated in Figure 6, biomarkers are rarely used during the development of antibacterial and respiratory system therapeutic products. On the other hand, for certain pharmacotherapeutic groups, approvals with biomarkers are more common than without. Examples include immunosuppressants, immunostimulants, drugs used in diabetes, antithrombotic drugs, antineoplastic agents and antivirals. The latter is strongly driven by human immunodeficiency virus (HIV) therapies. Biomarker-guided discovery, development and treatment is common in HIV area, for example, Odefsey (treatment of HIV-1 infection) was approved based on 2 surrogate biomarkers: viral suppression and CD4+ cell counts.76 Average biomarker acceptance in vaccine development is lower than for therapeutic medicines. Even though utilising of biomarkers in vaccinology may facilitate development of vaccines for diseases with unpredictable epidemiology, such as Zika, Chikungunya, Malaria and Lassa Fever, the utilisation of biomarkers has not yet been used in these developments and regulatory agencies often hesitate to give green light to biomarker-based strategies.77

EMA and FDA drug approvals with and without biomarkers between 2015 and 2019.

Selected EMA drug approvals with and without biomarkers between 2015 and 2019 by pharmacotherapeutic group.

## Section: Challenges and Opportunities for Drug Development

Biomarkers are crucial tools for drug discovery, development and approval of new medicines. They can contribute to a quicker development of safer and more effective medicines and thus add substantial value to a development programme. Over 20% of drugs approved by FDA between 2014 and 2018 and around 42% in 2018 alone belong to ‘personalised medicines’.68,78 In this article, it was shown that in average around 65% of drug approvals by EMA and FDA between 2015 and 2019 have been associated with incorporation of at least 1 biomarker in the development programme and higher percentage of biomarker acceptance is expected in the nearest future. Even though this percentage depends on a number of factors, such as recent scientific development, features of a product class, development of the regulatory landscape, it is clear that biomarkers are now essential part of drug development. This is associated with numerous benefits for patients and opportunities for drug developers, for example:

Overall, the use of biomarkers in a suitable way has the potential to make development more sustainable, improve quality and safety of a drug, reduce development costs and accelerate approval process significantly. Biomarker development, however, is associated with certain challenges such as:

Continuous development of the biomarker scientific and regulatory landscape is driven by collaborations between industry, private organisations, academic institutions and regulatory agencies. These collaborations have resulted in the increase in biomarkers acceptance in the EU and US in recent years. Biomarkers acceptance is expected to grow further in the nearest future.

## Section: Supplemental Material

Click here for additional data file.

## Section: Associated Data

Click here for additional data file.

## Section: Associated Data › Supplementary Materials

Click here for additional data file.


---

# Characterization of Molecular Cluster Detection and Evaluation of Cluster Investigation Criteria Using Machine Learning Methods and Statewide Surveillance Data in Washington State

- **Authors:** Steven J Erly, Joshua T Herbeck, Roxanne P Kerani, Jennifer R Reuer
- **Issuer:** Viruses
- **Type:** Scientific article
- **Published:** 2020-01-26
- **Language:** en
- **DOI:** 10.3390/v12020142
- **Source:** https://pubmed.ncbi.nlm.nih.gov/31991877/
- **Licence:** CC-BY

## Section: Abstract

Molecular cluster detection can be used to interrupt HIV transmission but is dependent on identifying clusters where transmission is likely. We characterized molecular cluster detection in Washington State, evaluated the current cluster investigation criteria, and developed a criterion using machine learning. The population living with HIV (PLWH) in Washington State, those with an analyzable genotype sequences, and those in clusters were described across demographic characteristics from 2015 to2018. The relationship between 3- and 12-month cluster growth and demographic, clinical, and temporal predictors were described, and a random forest model was fit using data from 2016 to 2017. The ability of this model to identify clusters with future transmission was compared to Centers for Disease Control and Prevention (CDC) and the Washington state criteria in 2018. The population with a genotype was similar to all PLWH, but people in a cluster were disproportionately white, male, and men who have sex with men. The clusters selected for investigation by the random forest model grew on average 2.3 cases (95% CI 1.1–1.4) in 3 months, which was not significantly larger than the CDC criteria (2.0 cases, 95% CI 0.5–3.4). Disparities in the cases analyzed suggest that molecular cluster detection may not benefit all populations. Jurisdictions should use auxiliary data sources for prediction or continue using established investigation criteria.

## Section: 1. Introduction

In the past five years, progress in reducing HIV incidence has slowed in the United States [1,2]. In response, the United States federal government launched the Ending the HIV Epidemic Initiative, which sets the goal of reducing new HIV infections by 90% within 10 years. One of the four major components of the initiative is “Respond quickly to potential HIV outbreaks to get needed prevention and treatment services to people who need them” in an effort to reduce transmission [3]. Molecular cluster detection is a component of this.

Molecular epidemiological approaches are used to identify groups of individuals (clusters) with closely related HIV viruses, which may reflect groups of people with ongoing HIV transmission, and lead to prevention resources being directed to those groups [4,5]. The existence of a cluster does not mean that transmission is occurring, however, as some clusters may represent transmission that occurred many years in the past [6]. Similarly, transmission may occur independently of identifiable clustering; incomplete genetic data or late sampling of genetic data (potentially after changes to genetic sequences from selective pressure or genetic drift) can hide genetic linkages [7].

While molecular cluster detection can be a useful epidemiological tool, its potential for real-time effectiveness relies partly on the ability to distinguish clusters where transmission is occurring from clusters that are stable. Many state and local health jurisdictions do not have the resources to review and investigate every cluster, therefore prioritization of clusters should be based on the resources available and potential cases averted. The general prioritization criteria suggested by the Centers for Disease Control and Prevention (CDC) for medium and high-burden jurisdictions (>4000 people living with HIV) is to investigate clusters that have grown by five cases linked by a genetic distance of 0.5% (0.005 substitutions per site) in the past 12 months [8]. This criterion is not sensitive to differences in local HIV transmission dynamics, and its appropriateness across jurisdictions or varying resources and priorities is unclear. The Washington State Department of Health currently manually reviews all clusters that have grown by three cases linked by a genetic distance of 1.5% (0.015 substitutions per site) in the last 12 months. Two other investigation criteria are under consideration for use by Washington State: 3 cases in the past 12 months linked by a genetic distance of 0.5% and 5 cases in the past 12 months linked by a genetic distance of 1.5% [9,10].

An ideal cluster investigation criterion would be a strong predictor of cluster growth and would be flexible enough to accommodate varying levels of health department resources. It would also include only data that are readily accessible to surveillance programs to minimize the burden of prediction. Previous efforts to predict cluster growth have been successful in a number of jurisdictions, though some have demonstrated that predictors of cluster growth change in performance over time, which indicates that static models may not be suitable tools for describing a dynamic transmission environment [11,12]. Random forest modeling is a supervised learning algorithm that requires minimal input and has demonstrated considerable predictive success in other public health settings. Unlike traditional regression models, random forests perform well without input such as individual variable selection and fitting [13,14]. The model’s flexibility and ease of implementation make it an appealing choice for the development of a tool that can be tailored to local settings and updated continuously as the context of the HIV epidemic changes.

The objectives of this study were to characterize current molecular cluster detection and growth in Washington State, to examine the performance of the CDC and current Washington State criteria for cluster review, and to assess the performance of random forest modeling using core surveillance data as a tool to prioritize cluster investigation in Washington State. By identifying successful criteria for cluster investigation, the results of our study can be used to optimize the cluster review and intervention to fully leverage the power of molecular cluster detection to prevent HIV transmission.

## Section: 2. Materials and Methods › 2.1. Study Design and Data Collection

We conducted a retrospective study of active clusters of molecularly linked HIV cases in Washington State from 2015 to 2018. Demographic, risk, HIV genetic sequence, and HIV viral load information were collected as part of core HIV surveillance by the Washington State Department of Health.

Washington State is considered a “moderate prevalence” jurisdiction; in 2018 the HIV prevalence was 13,417 and there were 511 incident cases reported within the state [2,15]. Of these incident cases, 20% had reported previous positive tests and may have been diagnosed in another state and were not in care or were from another country [16]. Washington State has had name-based HIV case reporting and mandatory reporting of CD4 test and all HIV viral load (detectable and undetectable) results since 2006 [15]. HIV genotype sequence reporting was not mandatory during the study period, potentially impacting completeness of molecular cluster membership [17]. Additionally, resistance testing was not ordered for all new HIV diagnoses, also impacting completeness [18].

HIV genetic sequences were used to identify clusters of molecularly linked HIV cases using the CDC recommended HIV-TRACE software. Full documentation of the methodology to generate these clusters has been previously described [8,19]. Briefly, the pairwise genetic distances between protease and reverse transcriptase sequences from every pair of individuals was calculated using the Tamura–Nei 93 nucleotide substitution model [20]. For this analysis, we used only the HIV sequence obtained from each individual’s first sample (when HIV sequences were collected from multiple samples of the same individual). Cases were considered molecularly linked if the genetic distance between their sequences was 1.5% or less. Active clusters were defined as HIV clusters of three or more individuals with molecular links in Washington State at any point between 2016 and 2018. Clusters with less than three individuals are not routinely monitored in Washington State.

## Section: 2. Materials and Methods › 2.2. Variables

On a monthly basis, we described active clusters across the following dimensions: size (number of cases living in Washington), viremic cases (number of cases with last viral load >200 copies/mL or no viral load in last 12 months), late diagnoses (number of cases with first post-diagnosis CD4 count <200 cells/mm3), gender (number of female vs. non-female cases), transmission risk (number of cases with reported injection drug use vs. no reported injection drug use), race (number of white cases vs. non-white cases), and time since diagnosis. Cases were determined to be living in Washington from addresses reported to the health department; departure from Washington State was estimated to be at the midpoint between a person’s last reported residence in Washington State and their first reported residence outside of Washington State. The number of viremic cases was assessed using the cases’ most recent viral load value at the current month of analysis. These variables were selected for their availability in surveillance data, associations with transmission rate in Washington State, and their ability to describe historic clusters with rapid growth in Washington State. The variable categories were selected to accommodate population size and to preserve contrasts of particular interest (e.g., transmission risks of male sex with male (MSM), heterosexual contact, pediatric exposure, etc. were all categorized as no injection drug use).

These metrics were expressed as counts, percent of overall cluster size, and percentiles (quartiles for cluster size and viremia, and above and below the median for the number of late diagnosis, gender, transmission risk, and race). To simulate the information available at the time of analysis, cases were included in the cluster based on the date their genotype sequences were received by the Washington State Department of Health.

In addition to point-of-time information, CDC and Washington State candidate criteria for cluster investigation were generated for each month: 3 cases in the previous 12 months at 0.5% genetic distance, 5 cases in the previous 12 months at 0.5% genetic distance, 3 cases in the previous 12 months at 1.5% genetic distance, and 5 cases in the previous 12 months at 1.5% genetic distance (Table 1).

## Section: 2. Materials and Methods › 2.3. Analysis

To characterize molecular cluster detection in Washington State, we described the state’s molecular cluster detection program in terms of number of active clusters, the proportion of cases (prevalent and incident) with a valid genotype sequence reported to the state, the proportion of cases in any cluster (including historical clusters not analyzed in this study), the proportion of cases in active clusters, the median days from HIV diagnosis to specimen collection of genotype sequences, and the median time from HIV diagnosis to HIV-TRACE analysis.

To characterize the study population, we compared the population of people living with HIV (PLWH) with genotypes (who could potentially be in a cluster) and the population of PLWH in active clusters to the prevalent population of PLWH in Washington State in terms of gender, transmission risk, and age on 31 December 2018.

We measured cluster growth as the number of newly diagnosed cases added to the cluster in the subsequent 3 and 12 months in Washington State, regardless of when the sequence was identified as a member of the cluster. In this case, diagnosis is used as a proxy for transmission, and such cases would be considered potentially preventable during a cluster intervention. Clusters were stratified by posited predictors of cluster growth (cluster size, virally suppressed individuals, % not suppressed, the CDC/Washington State candidate historical criteria, number of cases with a first CD4 count <200, gender, transmission risk, race, and time since diagnosis), which were updated monthly. The number of newly diagnosed cases added to each cluster in the subsequent 3- and 12-month periods was calculated both on an absolute scale and as a rate per 100 person-months. Differences between categories, confidence intervals, and p-values were calculated using a repeated-measures generalized estimating equation with a Poisson distribution.

## Section: 2. Materials and Methods › 2.4. Prediction of Cluster Growth

A random forest regression model was generated to predict the number of newly diagnosed cases added to the cluster in the subsequent three months using data from 2016 to 2017. The following variables were included in the model: number of cases per cluster living in Washington State; number of viremic individuals per cluster; number of new cases in the previous 1, 3, and 12 months at both 0.015 and 0.005 genetic distance; number of late diagnoses; number of white cases; number of cases described as injection drug use transmission risk; number of female cases; and number of cases that had been diagnosed <1 year prior. A random search was used to identify optimum number of candidate variables at each split. Five hundred trees were estimated. A second model was fit to predict rate of cluster growth per 100 person-months. Regression was performed using the RandomTree package in R [21].

To create an investigation criterion from this model, we derived a cutoff for predicted cluster growth at which an investigation should be initiated. For comparability with the existing criteria, we sought a criterion that would yield approximately the same number of investigations as the existing criteria. To identify this target number of investigations, we counted the number of investigations initiated by the existing criteria from 2016 to 2017 (n). To translate this into a cutoff for the random forest models, we ranked the clusters by their highest monthly predicted growth from the random forest model. The predicted growth of the top nth cluster was selected as the cutoff for investigation, as this value would yield n investigations in 2016–2017.

Using this technique, we derived two investigation criteria to match the activity of the most stringent and least stringent CDC and Washington State investigation criteria (five cases at 0.005% genetic distance and three cases at 0.015% genetic distance).

## Section: 2. Materials and Methods › 2.5. Evaluation of Investigation Criteria

The CDC cluster investigation criterion, Washington State cluster investigation criterion, and random forest criteria were evaluated for 2018 on the basis of growth of clusters indicated for investigation. The number of new diagnoses in the subsequent three months and the rate of new diagnoses per 100 person-months were calculated for clusters that met each criterion. To simulate a real public health intervention, clusters were only eligible for investigation once. Criteria that identified clusters with higher growth over the subsequent three-month period were considered the best.

The data collected and analyses conducted under HIV/AIDS surveillance authority as an evaluation of the surveillance system are not considered research. No data which could identify individuals are presented.

## Section: 3. Results › 3.1. Cluster Detection in Washington State

Between 2015 and 2018, 57% (1058 of 1847) of new cases had a reverse transcriptase or protease sequence reported to the state. Only 49% (7373 of 15,150) of prevalent cases in that time frame had sequences. The median days from diagnosis to genotype specimen collection was 14 (IQR 6–31) and from diagnosis to TRACE analysis was 291 (138–714). From 2015 to 2018, these delays decreased from a median of 17 to 11 days and 821 to 109 days, respectively (Table 2). People with a genotype were more likely to be under 45 years of age (41% vs. 33%, p < 0.01) (Table 3).

Using the 1.5% genetic distance threshold, 107 clusters were present during the study time period, which represented 22% of new HIV cases and 8% of prevalent HIV cases (Table 2). Compared to the total population of PLWH in Washington, those within clusters of three or more prevalent cases were more likely to be recently diagnosed (47% diagnosed in the last five years vs. 21%), male (93% vs. 83%, p < 0.01), white (64% vs. 57%, p < 0.01), be described as MSM transmission risk (74% vs. 60%, p < 0.01), and be under 45 years old (68% vs. 34%, p < 0.01) (Table 3).

## Section: 3. Results › 3.2. Predictors of Cluster Growth

In 2016 and 2017, the mean number of new cases added to clusters was 0.24 (95% CI 0.18–0.33) per three-month period and 1.22 (95% CI 0.86–1.73) per 100 person-months. Over a three-month period, larger clusters and clusters with more viremic individuals grew faster on an absolute scale. Clusters with three or fewer members grew at an average of 0.17 cases (95% CI 0.11–0.17), while clusters with 12 or more members grew at an average of 0.37 cases (95% CI 0.24–0.58). Clusters with zero viremic individuals grew at an average of 0.13 cases (95% CI 0.08–0.20), while clusters with three or more viremic individuals grew at an average of 0.38 cases (95% CI 0.26–0.57). As a rate, the only significant predictor of growth was cluster size, where larger clusters grew more slowly (0.43, 95% CI 0.33–0.58 cases per 100 person-months in clusters of 12 members or more vs. 2.07, 95% CI 1.29–3.34 cases in clusters with three or fewer members).

Clusters meeting CDC criteria of five cases in the previous 12 months at a genetic distance of 0.005 had the highest growth on the absolute scale (1.50, 95% CI 0.79–2.86) and a high growth rate (2.93 per 100 person-months, 95% CI 0.79–10.86), but these values were not significantly different from clusters outside of this criteria (Table 4). Assessed at 12 months of growth, clusters showed similar, but attenuated trends (Table 5).

## Section: 3. Results › 3.3. Derivation and Evaluation of Investigation Criteria

The CDC criteria identified four clusters from 2016 to 2017 that would prompt investigation. To create a criterion that would produce a similar volume of investigations, a cutoff was selected for the random forest model (i.e., the predicted number of newly diagnosed cases in the subsequent three months that would prompt investigation). The criterion to prompt investigation was set at 2.3 predicted cases. This value would have initiated the same number of investigations on unique clusters from 2016 to 2017. A looser criterion was set at 0.9 predicted cases, as this would have matched the 24 clusters investigated under the Washington State Department of Health investigation criterion. For growth per 100 person-months, criteria of 0.14 and 0.42 were selected. The first four layers of an example tree sampled from the random forest are presented in Figure 1. Of note, this represents one of the 500 trees which were combined to create the prediction model.

In 2018, there were six clusters that met the CDC investigation criterion, which had on average 28.3 (95% CI 5.7–62.4) members and grew 2.0 (95% CI 0.5–3.4) members in the subsequent three months. The clusters selected for investigation by the random forest model did not grow significantly faster. The model selected four clusters with a mean of 31.8 (95% CI 20.5–42.9) members that grew 2.3 (95% CI 1.3–3.2) members in the subsequent three months. There were 17 clusters that met the Department of Helath investigation criterion that had a mean size of 20.5 (95% CI 8.3–32.6) and grew an average of 1.4 cases (95% CI 0.8–2.0). The clusters selected by the random forest model with a looser criterion did not grow significantly faster (n = 15, mean size = 19.9, 95% CI 16.8–23.1, mean growth = 1.3, 95% CI 1.1–1.4). All criteria selected clusters that grew significantly faster than the statewide cluster growth of 0.3 cases per three months.

Prediction of cluster growth per 100 person-months was poor, and only the random forest with the looser criterion selected clusters that grew significantly faster than the statewide cluster growth of 1.4 cases per 100 person-months. This model detected 20 clusters with a mean size of 7.5 (95% CI 6.1–8.8) and a mean growth of 3.4 (95% CI 2.8–4.0) per 100 person-months. The random forest model with the stricter criterion only identified one cluster, which did not grow (Table 6).

## Section: 4. Discussion

Molecular cluster detection of HIV has the potential to guide public health intervention to populations of the greatest need. This is dependent on completion of genetic sequence data and the ability to identify molecular clusters where transmission is likely to occur. In this analysis, we demonstrated the disparities in the applicability of molecular cluster detection in populations in Washington State and the challenge of predicting cluster growth from core surveillance data. Finally, we suggest that the established criteria for prediction of cluster growth based on cases in the previous 12 months continue to be used in absence of additional data sources.

Molecular cluster detection is dependent on the timeliness and completeness of the sequence data included in the analysis [17]. From 2015 to 2018, there was an 87% decrease in the median time from a person’s HIV diagnosis to analysis in HIV-TRACE. In the same time period, Washington State was near the CDC target of 60% completeness of sequence data in new HIV cases (57%) but only achieved 49% in prevalent cases. The majority of incident and prevalent cases do not have an observed molecular link within the state (71% and 82%, respectively.) While the population of PLWH with analyzable genotype sequences was fairly equivalent to the population of Washington State, there were stark disparities in the populations who were in analyzable clusters of three or more individuals. People in analyzable clusters are more likely to be white, male, and MSM. In Washington State, these are populations with decreasing incidence counts and a higher proportion of viral suppression, which may indicate that these populations may not be those who could most benefit from interventions informed by molecular cluster detection. The disparity between the population with analyzable genotype sequences and the population in analyzable clusters may be tied to disparity in time since diagnosis, which could hide a difference in the distribution of cases with sequences in more recent years. There may also be differences in the network structure of demographic groups that affect the number of analyzable clusters.

Completeness of collection of molecular sequences can be a challenge for health departments as there are multiple points in the process that can result in a sequence not being available for analysis: an individual is not diagnosed, the individual is not linked to care, a resistance test is not ordered at the time of initial linkage to care, there is a problem with the specimen collection, there is a problem with specimen storage or transportation, there is a problem at the time of running the test, or the sequence is not transmitted to the health department. Efforts to improve the completeness (to increase the percentage of new diagnoses with reported sequences) and efficiency (to decrease the amount of time for inclusion of sequences in analysis) of the process are important to the utility of the program.

The random forest model used in this analysis did not predict cluster growth significantly better than the CDC or Washington State criteria. This demonstrates the limitations in predictive power of HIV core surveillance and molecular cluster detection in isolation. Previous successful prediction efforts have used partner services data to supplement these information sources, but some jurisdictions may have limited access to such data through structural or legal barriers [12]. In addition to partner services data, information about cluster topology and data from prior cluster and data for care investigations could be useful in prediction of cluster growth. The performance of our prediction model (relative to the existing criteria) was likely hurt by the rapid growth of an outbreak cluster among heterosexual persons who were living homeless and injecting drugs in King County in 2018, which was unlike the baseline cluster growth in years past [10]. This is the type of event that would be important to predict, however, and highlights the limitations of prediction models in the domain of rare events [22]. A larger dataset, either covering a longer time period or a larger geographic region would be useful for predicting such events.

In the absence of complete or readily available adjunct data from partner services investigations, the results of this study suggest that jurisdictions use the established criteria based on cluster growth in the past 12 months. Looser criteria (e.g., smaller numbers of individuals at a less restrictive genetic distance cutoff) may offer an added benefit of offering staff a chance to identify non-surveillance indicators that are important in the local transmission networks.

Notably, no criteria examined in our analyses was able to predict cluster growth as a rate. Jurisdictions that are concerned with cases prevented as a function of investigated cases may need to seek criteria based on information outside of core surveillance.

For cluster detection and response to be most effective it should incorporate robust core surveillance including an ongoing understanding of changes in HIV transmission trends and complete case and lab reporting, robust partner services activities with disease investigators that are familiar with the profile of their local cases, and efficient and complete molecular data collection and analysis [10,12,23]. There should also be transparency and dialogue with the community about the activities being undertaken and why they are important. It is only with the combination of information and efforts that programs will be able to make effective use of cluster detection to decrease HIV transmission early and focus prevention efforts.


---

# Comparison of Conventional Statistical Methods with Machine Learning in Medicine: Diagnosis, Drug Development, and Treatment

- **Authors:** Hema Sekhar Reddy Rajula, Giuseppe Verlato, Mirko Manchia, Nadia Antonucci, Vassilios Fanos
- **Issuer:** Medicina (Kaunas, Lithuania)
- **Type:** Scientific article
- **Published:** 2020-09-08
- **Language:** en
- **DOI:** 10.3390/medicina56090455
- **Source:** https://pubmed.ncbi.nlm.nih.gov/32911665/
- **Licence:** CC-BY

## Section: Abstract

AbstractFuturists have anticipated that novel autonomous technologies, embedded with machine learning (ML), will substantially influence healthcare. ML is focused on making predictions as accurate as possible, while traditional statistical models are aimed at inferring relationships between variables. The benefits of ML comprise flexibility and scalability compared with conventional statistical approaches, which makes it deployable for several tasks, such as diagnosis and classification, and survival predictions. However, much of ML-based analysis remains scattered, lacking a cohesive structure. There is a need to evaluate and compare the performance of well-developed conventional statistical methods and ML on patient outcomes, such as survival, response to treatment, and patient-reported outcomes (PROs). In this article, we compare the usefulness and limitations of traditional statistical methods and ML, when applied to the medical field. Traditional statistical methods seem to be more useful when the number of cases largely exceeds the number of variables under study and a priori knowledge on the topic under study is substantial such as in public health. ML could be more suited in highly innovative fields with a huge bulk of data, such as omics, radiodiagnostics, drug development, and personalized treatment. Integration of the two approaches should be preferred over a unidirectional choice of either approach.Keywords: machine learning, medicine, healthcare, diagnosis, drug development, personalized treatment, autonomous technology

## Section: 1. Introduction

Machine learning (ML) is a type of artificial intelligence (AI) consisting of algorithmic approaches that enable machines to solve problems deprived of explicit computer programming [1]. ML is becoming increasingly relevant in medicine as it can optimize the trajectory of clinical care of patients affected by chronic diseases and might inform precision medicine approaches and facilitate clinical trials. As shown in Figure 1, the number of articles applying ML to the medical field has been exponentially increasing, especially with regard to diagnostics and drug discovery. According to Accenture data, vital medical health AI applications can possibly create USD 150 billion in yearly savings for the United States healthcare sector by 2026 [2]. These data show that the healthcare industry can heavily leverage the possibilities provided by ML. This might also explain why AI companies are being increasingly involved in the area of medicine, from diagnosis to treatment and drug development. For instance, convolutional neural networks (used in image recognition and processing) have been able to effectively improve the diagnostic process of diabetic retinopathy [3,4]. Another example is rehabilitation, where learning agents can be trained to run by controlling the muscles attached to the virtual skeleton. Ideally, doctors might predict if a patient is able to walk, jump, or run properly after a specific treatment. Furthermore, data obtained during phases of rehabilitation might be later used to project new, AI designed, leg prostheses.

AI uses multiple layers of non-linear processing units to “teach” itself how to understand data, classify the records, or make predictions [5]. Thus, AI can produce electronic health records (EHRs) data and unstructured facts to make predictions about a patient’s health. For instance, AI can rapidly read a retinal image or flag cases for follow up when several manual reviews would be too cumbersome [6].

When applied to big data, AI offers the promise of unlocking novel insights and accelerating breakthroughs. Paradoxically, although an unprecedented quantity of data is becoming available, only a fraction is being properly integrated, understood, and analyzed. The challenge lies in harnessing high volumes of data, integrating them from hundreds of sources, and understanding their various formats. AI offers potential for addressing these challenges, since cognitive answers are explicitly intended to integrate and analyze big datasets. AI can understand diverse types of data such as lab calculations in a structured database or the script of a scientific publication. These software solutions are trained to understand technical, industry-specific content and use advanced reasoning, predictive modelling, and ML techniques to advance research.

Indeed, AI can be applied to big data using different approaches. When it comes to the effectiveness of ML, the rule of thumb is that the more data, the more accurate the prediction. Although this is an oversimplification, it is evident that the healthcare sector is sitting on a data goldmine. Estimates are that big data and ML in pharma and medicine could generate a value of up to USD 70 billion to 100 billion annually [7], given the downstream effects of these approaches.

One main difference between ML and traditional statistical methods lies in their purpose, as the former remains focused on making predictions as accurate as possible, while the latter are aimed at inferring relationships between variables [8].

However, the key difference between traditional statistical approaches and ML is that in the latter, a model learns from examples rather than being programmed with rules. For a given assignment, samples are provided in the form of inputs (called features) and outputs (called labels). For instance, digitized slides read by pathologists are rehabilitated to features (pixels of the slides) and labels (e.g., data indicating that a slide comprises evidence of deviations indicating cancer) [9]. Using algorithms for learning from observations, computers then govern how to accomplish the mapping from features to labels in order to create a model that will generalize the data, such that an assignment can be achieved properly with new, never seen before inputs (e.g., pathology slides that have not yet been read by a human). This process is called supervised machine learning.

When predictive accuracy is critically significant, the ability of a model to find statistical patterns through millions of features and instances is what enables superhuman performance. Nonetheless, these patterns do not necessarily relate to the identification of underlying biologic pathways or modifiable risk factors that might facilitate the development of new therapies [9].

A crucial difference between human learning and ML is that humans can learn to make general and complex associations from small amounts of data. Machines, in general, require several more samples than humans to acquire the same task, and machines are not capable of common sense. The flipside, however, is that the machine can learn from massive amounts of data: it is perfectly feasible for an ML model to be trained with the use of tens of millions of patient charts warehoused in EHRs, with hundreds of billions of data points, deprived of any lapses of attention, while it is very challenging for a human physician to understand more than a few tens of thousands of patients in a complete career. The performance of well-developed conventional statistical approaches needs to be evaluated and compared with ML in terms of predictivity of clinically relevant outcomes (e.g., survival, response to treatment, patient-reported outcomes (PROs), etc.).

In this narrative review, we aim to offer an expert perspective on the comparison of traditional statistical methods with ML, and their corresponding advantages and limitations in medicine, with a specific focus on the integration between the two approaches and its application to illness detection, drug development, and treatment. To this end, we have selectively reviewed the literature on this topic, presenting evidence illustrating the difference between traditional statistical methods and ML in healthcare.

Number of articles, reviews, and editorials, dealing with machine learning and either diagnostics, medicine, drug discovery, surgery, personalized medicine, and pediatrics, published between 2000 and 2019 and indexed on the Web of Science.

## Section: 2. Advantages of Traditional Statistical Methods over ML

Traditional statistical approaches have the advantage of being simple to understand. Indeed, they usually take into account a small number of clinically important variables and they produce “clinician-friendly” measures of association, such as odds ratios in the logistic regression model or the hazard ratios in the Cox regression model. Traditional statistical approaches allow us to easily understand the underlying biological mechanisms.

On the other hand, the results of ML are often difficult to interpret. Lack of interpretability is particularly evident in neural networks, but it is less pronounced in least absolute shrinkage and selection operator (Lasso) regression. Moreover, computation to find the minimum of the cost function of neural networks is quite complex and time-consuming, depending on the type of cost function chosen, the number of nodes and layers of the neural network, and the number of training observations [10]. Furthermore, ML algorithms entail data pre-processing, training on datasets, require large datasets, and iterative refinement with regard to the real medical problem [1]. ML techniques can also lead to overfitting, i.e., to the production of a model too closely related to the underlying dataset. This phenomenon can limit the possibility of generalizing the model to different datasets, and hence, making predictions [11]. An appropriate balance between the training set and the validation set is necessary to avoid this problem.

## Section: 3. Advantages of ML over Traditional Statistical Techniques

ML techniques have large flexibility and are free from a priori assumptions, while traditional statistical methods rely on strong assumptions, such as the type of error distribution, additivity of the parameters within the linear predictor, and proportional hazards. These assumptions are often not met in clinical practice and they are often overlooked in the scientific literature. For instance, the assumption of proportional hazards has been violated when studying survival in gastric cancer patients, as the prognostic significance of the depth of tumor invasion and nodal status tends to decrease with increasing follow-up, while the histology and the loss of TP53 gene acquire prognostic importance after at least two years of follow-up [12].

ML has the advantage of taking into account all the available information on a particular field. Traditional statistical approaches, even those at the top of the pyramid of evidence, often fail because they make a priori selection of the variables to be considered. For instance, a Cochrane review, dealing with the extension of lymphadenectomy in gastric cancer surgery, was criticized and later withdrawn mainly because it failed to take into account the quality of surgical procedures under comparison [13]. ML is particularly suited when there are few observations and many predictors, such as in genomics, transcriptomics, proteomics, and metabolomics [14]. In such a situation, traditional regression models show several limitations, especially for the choice of the most important risk factors. Therefore, in building ML predictive models, it is possible to use numerous approaches to apply also on small datasets.

ML can also easily address interactions, which are difficult to investigate with traditional statistical methods that can mostly address interactions between the main determinant and single potential confounders. For instance, the effect of the surgical approach on survival in gastric cancer patients is modulated by tumor stage and histology [15]. However, this second-order interaction is difficult to highlight within a Cox model [16], as the interaction between lymphadenectomy and histology becomes apparent after the first two years of follow-up.

Furthermore, ML algorithms have the ability to analyze various data types (for instance, imaging data, demographic data, and laboratory findings) and integrate them into predictions for illness risk, diagnosis, prognosis, and applicable treatments [1].

## Section: 4. Different Indications for the Two Computational Approaches

Taking into account the strengths and limitations discussed above, different fields of application can be proposed for traditional statistical techniques and ML. Traditional statistical approaches could be more suitable than ML when: (1) there is substantial a priori knowledge on the topic under study; (2) the set of input variables is limited and rather defined in the current literature; (3) the number of observations largely exceeds the number of input variables. This situation is typically encountered in public health research, especially when performed on large healthcare utilization databases [17,18].

On the other hand, ML techniques have proven to be more appropriate in “omics” [19], where numerous variables are involved (genes, RNA molecules, proteins, metabolites). Indeed, with a large number of interactions (such as polygenicity and epistatic effects in genomics), ML might help disentangle the complex relationships between these components in determining their effect on the main outcome (i.e., the illness risk).

Traditional statistical approaches are appropriate when the set of predictors tends to be defined a priori on the basis of available reliable evidence on the specific topic. For instance, most articles dealing with gastric cancer surgery include a fixed set of covariates in survival models, comprising sex, age, tumor site, histology, and stage [12]. The selection of variables is important to avoid the introduction of strongly collinear variables, such as tumor stage and surgical efficacy (completeness of tumor removal), and this is usually done on the basis of a priori knowledge, as techniques to compare non-nested models, such as Akaike Information Criterion, are rather limited. This approach makes the studies more comparable: for instance, the use of the same prognostic factors allows the comparison of datasets collected in different countries and makes easy to develop internationally accepted prognostic scores [20]. On the other hand, this approach could slow down the progress of clinical research, as few novel prognostic factors are addressed by each research project.

ML allows us to take into account a huge bulk of potential predictors, avoiding an a priori choice among them. Hence, ML is more suited for big steps in diagnostics and therapeutics. ML has given an important contribution to the rapidly progressing therapeutic revolution fostered by “omics”. However, whatever boundaries we can establish today between traditional statistics and ML, these will be surely overcome in the next future.

## Section: 5. Integration between the Two Approaches

A traditional statistical approach requires us to choose a model that incorporates our knowledge of the system, and ML requires us to choose a predictive algorithm by relying on its empirical capabilities [19]. Justification for an inference model generally rests on whether it sufficiently captures the characteristics of the system. The choice of algorithm in pattern learning frequently hangs on measures of previous performance in similar scenarios. Inference and ML are complementary in pointing us to biologically meaningful conclusions.

Of note, traditional statistical approaches and ML are often used in sequence. When trying to differentiate groups of patients based on their proteomic or metabolomics profile, classical statistical techniques are first used for preliminary screening, while ML is used to finalize the analysis.

For instance, Fabris et al. have recently identified a set of urinary proteins that allow the discrimination between two different renal diseases, nephrolithiasis and Medullary Sponge Kidney [14]. Remarkably, this result was achieved on a very small series (22 patients with MSK and 22 patients with idiopathic calcium nephrolithiasis), analyzing a huge bulk of urinary proteins (n = 1529). Traditional statistical techniques (multidimensional scaling, volcano plot, and ROC curves) allowed them to reduce the set of urinary proteins considered from 1529 to 16, while Support Vector Machine (SVM) permitted a further reduction to 5 proteins. In a subsequent study on the same topic, Bruschi et al. first used partial least squares discriminant analysis and then SVM [21].

## Section: 6. Applications of ML in Medicine

Applications of machine learning (ML) in medicine.

## Section: 6. Applications of ML in Medicine › 6.1. Diagnostic Process

The ability of ML to detect diagnostic models reaching the level of clinical accuracy remains an objective not yet achieved, but seemingly feasible. This objective faces the challenge of finding ways to work with all the available data. This highlights the relevance of interdisciplinary collaborative work. In the area of brain diseases like depression, the Predicting Response to Depression Treatment (PReDicT) project has applied predictive analytics to help diagnose depression and identify the most effective treatment, with the overall goal of producing a commercially available emotional test battery for use in clinical settings [22]. In general, the use of ML to aggregate large datasets could significantly accelerate the diagnostic processes [23]. In Table 1, we have summarized information on ML in medicine.

Of the numerous opportunities for the use of ML in clinical practice, medical imaging workflows are those that will be likely be most impacted in the near term. ML-driven algorithms that automatically process two- or three-dimensional image scans to recognize clinical signs (e.g., tumors or lesions) or articulate diagnoses are now available and some are progressing through regulatory steps toward the market [24]. Many of these use deep learning, a form of ML based on layered representations of variables, referred to as artificial neural networks. The latter can learn extremely complex relationships between features and labels and have been shown to exceed human abilities in performing tasks such as classification of images.

ML can improve diagnostic accuracy by analyzing not only medical images but also textual records. Indeed, ML allowed the identification of varicella cases in a pediatric Electronic Medical Record Database with a positive predictive value of 63.1% and a negative predictive value of 98.8% [25].

Applications of machine learning (ML) in medicine.

## Section: 6. Applications of ML in Medicine › 6.2. Predicting Prognosis

ML has been shown to achieve the same or better prognostic definition in several clinical conditions, as compared to conventional statistical methods. In particular, ML can better predict clinical deterioration in the ward [26], mortality in acute coronary syndrome [27], survival in patients with epithelial ovarian cancer [28], complications of bariatric surgery [29], and risk of metabolic syndrome [30]. On the other hand, other studies reported that ML and conventional statistical methods have similar prognostic usefulness in predicting mortality in intensive care units [31], readmission in patients hospitalized for heart failure [32], and all-cause mortality and cardiovascular events [33].

## Section: 6. Applications of ML in Medicine › 6.3. Drug Discovery

ML can facilitate various phases of the early stages of drug discovery, from initial screening of drug compounds to predicted success rates based on biological factors. This includes R&D technologies like next-generation sequencing. Precision medicine, which relies on the recognition of pathophysiological mechanisms and might serve the development of alternative therapeutic pathways, appears as the most innovative area. Much of this study encompasses unsupervised learning, which is in large part still limited to identifying patterns in data without predictions (the latter is still in the realm of supervised learning). Data from experimentation or manufacturing processes have the potential to aid pharmaceutical manufacturers to diminish the time required to produce drugs, leading to lowered costs and better replication. Adopting ML approaches could play a significant role in discovering new molecules or repurposing existing drugs for rare conditions or epidemics where urgency is key. With the increase in antibiotic resistance, exploiting ML techniques is already proving quite powerful in identifying new antibacterial agents in a faster and potentially inexpensive way [23]. For example, AI recently allowed the discovery of halicin, a compound structurally divergent from conventional antibiotics, acting against Clostridium difficile and pandrug-resistant Acinetobacter baumannii infections in murine models [34].

## Section: 6. Applications of ML in Medicine › 6.4. Personalized Treatment

Personalized medicine, which should lead to the identification of more effective treatment based on individual health data paired with predictive analytics, is closely related to better disease assessment. To meet the complexity of personalized medicine, new types of trials have been developed, such as basket, umbrella, or platform trials. The area is presently governed by supervised learning, which permits physicians, for instance, to select from further limited sets of diagnoses or estimate patient risk based on symptoms and genetic information.

Over the next decade, the increased use of micro biosensors and devices, as well as mobile apps with more sophisticated health measurement and remote monitoring capabilities, will provide an additional surge of data that can be used to help facilitate research and development, and treatment efficacy. This type of personalized treatment has significant consequences for the individual in terms of health optimization, but also for plummeting overall healthcare costs. If more patients adhere to following prescribed drug or treatment tactics, for instance, the reduction in health care charges will trickle up and back down.

Using ML in these settings depends on the collection and analysis of huge amounts of data, but with the emergence of big data comes the challenge of statistical inference from complex datasets to identify genuine patterns, while also restraining false classifications and making decisive judgments on diagnosis and treatment possibilities. Statistical bioinformatics has proven very useful in proteomic and genomic data analysis, and the adoption of ML to build predictors and classifiers has shown significant potential [23].

## Section: 7. Discussion

ML has the potential to transform the way medicine works [35]. However, increased enthusiasm has previously not been met by a corresponding interest from healthcare providers and operators.

Examples where ML has done well: Gulshan et al. have applied deep learning to build an algorithm-automated detection of diabetic retinopathy and diabetic macular edema in retinal fundus photographs [36]. Bejnordi et al. have recently evaluated the performance of automated deep learning algorithms at identifying metastases in hematoxylin and eosin-stained tissue sections of lymph nodes of women with breast cancer and related it with pathologists’ diagnoses in a diagnostic setting [37]. There are several similar ML studies on images and challenges in radiology, pathology, dermatology, ophthalmology, gastroenterology, cardiology, etc. ML is beginning to have an impact in medicine at three levels: for clinicians, predominantly via rapid, accurate image interpretation; for patients, by enabling them to process their own data to promote health; and for health systems, by improving workflow and the potential for reducing medical errors [38]. Steele et al. observed that data-driven models used on a prolonged dataset can outperform conventional models for prognosis, deprived of data pre-processing or imputing missing values for predicting patient mortality in coronary artery disease [39].

Examples where ML has done poorly: Esteva et al. recently demonstrated the effectiveness of deep learning in dermatology, as regards both general skin conditions and specific cancers [40]. However, they also observed that in the set of biopsy images, if an image had a ruler in it, the algorithm was more likely to call it tumor malignant because the presence of a ruler was associated with an augmented likelihood that a lesion was cancerous.

There is no clear line between ML models and traditional statistical models, and a recent article summarizes the relationship between the two [41]. However, sophisticated new ML models (e.g., those used in “deep learning” [42,43]) are well suited to learn from the complex and heterogeneous kinds of data that are generated from current clinical care, such as medical notes entered by doctors, medical images, continuous monitoring data from sensors, and genomic data to aid make therapeutically significant predictions. Most ML classifiers perform uncertainly with risk prediction. Possibly much bigger sample sizes are required to gain reliable (calibrated) risk predictions [44] than reliable (diagnostic) classifications.

ML is creating a paradigm shift in medicine, from basic research to clinical applications, but it should be carefully implemented. Vulnerabilities such as security of data and adversarial attacks, where malicious manipulation in the input can affect a complete misdiagnosis, which could be employed for fraudulent interests, present a real threat to the technology [23]. However, these vulnerabilities can be met with adequate efforts.

In the 1970s and 1980s, computerized tomography, based on the automatic elaboration of a huge bulk of X-rays images, revolutionized radio diagnostics, enabling radiologists to overcome the so-called “grey barrier”. The use of CT allowed radiologists to improve their role in the healthcare system. However, the ML revolution seems to threaten one of physicians’ most exclusive tasks, i.e., diagnostic activity. The new generation of practitioners should accept the challenge of ML, by learning how to comprehend, develop, and eventually, control it so as to improve patient care [24].

ML can analyze large amounts of data and turn that information into functional tools that can assist both doctors and patients. The increased integration of ML into everyday medical applications might improve the efficiency of treatments and lower costs in various ways. The challenge is to combine big data provided by genomics, transcriptomics, proteomics, and metabolomics with complex systems science, systems biology, and systems medicine of the body [45]. ML tools can be built for system-level interventions, comprising improving patient selection and enrolment for clinical trials, decreasing patient readmission, and automated follow-up of patients for scrutiny of complications.

## Section: 8. Conclusions

As technology is widening and innovations and ideas are pouring, there is an enormous volume of data that is being generated in modern healthcare. Proper analytical methods are key to obtain the maximum insight from collected data.

The periphery between traditional statistics and ML is a topic to debate [46]. Some approaches fall squarely into one or the other domain, but numerous are used in both. Both statistics and ML can be of value, traditional statistics being more useful in public health and ML in omics science.

Conventional statistical approaches and ML are complementary in directing us to biologically significant conclusions: the ideal approach would be to integrate the two technologies in a way that can determine an added value. Our review has provided compelling insights into the difference between conventional statistical approaches and ML in healthcare, which in turn may help us to better integrate technology and medical care.

## Section: Author Contributions

Conceptualization, V.F. and G.V.; methodology, H.S.R.R.; writing—original draft preparation, H.S.R.R., M.M., N.A.; writing—review and editing, V.F., G.V., H.S.R.R., M.M., N.A. All authors have read and agreed to the published version of the manuscript.

## Section: Funding

This research was funded by the European Union’s Horizon 2020 research and innovation program under the Marie Skłodowska-Curie Grant Agreement No. 721567, CAPICE project-Childhood and Adolescence Psychopathology: unravelling the complex aetiology by a large Interdisciplinary Collaboration in Europe under Grant Agreement 721567.

## Section: Conflicts of Interest

The authors declare no conflict of interest.


---

# Deep Learning-driven research for drug discovery: Tackling Malaria

- **Authors:** Bruno J Neves, Rodolpho C Braga, Vinicius M Alves, Marília N N Lima, Gustavo C Cassiano, Eugene N Muratov, Fabio T M Costa, Carolina Horta Andrade
- **Issuer:** PLoS computational biology
- **Type:** Scientific article
- **Published:** 2020-02-18
- **Language:** en
- **DOI:** 10.1371/journal.pcbi.1007025
- **Source:** https://pubmed.ncbi.nlm.nih.gov/32069285/
- **Licence:** CC-BY

## Section: Abstract

AbstractMalaria is an infectious disease that affects over 216 million people worldwide, killing over 445,000 patients annually. Due to the constant emergence of parasitic resistance to the current antimalarial drugs, the discovery of new drug candidates is a major global health priority. Aiming to make the drug discovery processes faster and less expensive, we developed binary and continuous Quantitative Structure-Activity Relationships (QSAR) models implementing deep learning for predicting antiplasmodial activity and cytotoxicity of untested compounds. Then, we applied the best models for a virtual screening of a large database of chemical compounds. The top computational predictions were evaluated experimentally against asexual blood stages of both sensitive and multi-drug-resistant Plasmodium falciparum strains. Among them, two compounds, LabMol-149 and LabMol-152, showed potent antiplasmodial activity at low nanomolar concentrations (EC50 <500 nM) and low cytotoxicity in mammalian cells. Therefore, the computational approach employing deep learning developed here allowed us to discover two new families of potential next generation antimalarial agents, which are in compliance with the guidelines and criteria for antimalarial target candidates.

## Section: Introduction

Malaria is a serious worldwide health problem that affects 216 million people, killing over 445,000 patients annually, especially children younger than five-years-old and pregnant women in Sub-Saharan Africa [1]. The disease is transmitted to humans through the bites of infected female Anopheles mosquitoes and caused by parasites of the genus Plasmodium [2,3]. Among them, P. falciparum is the most prevalent and dangerous species, causing the severe form of the disease, i.e., cerebral malaria [3,4].

Current control and eradication of malaria demands a multifaceted approach. The World Health Organization recommends a combination of at least two drugs with different mechanism of action. However, the efficacy of antimalarial drugs is threatened by the emergence and spread of resistant strains to all major antimalarial drugs, such as chloroquine [5], atovaquone [6], pyrimethamine [7], and sulfadoxine [8]. More recently, drug resistance has also been reported to front-line artemisinin-based combination therapies (ACTs) in the Greater Mekong Subregion and southeast Asia [9–11]. All these aspects highlight the compelling need for the development of new therapies to solve the challenges of drug resistance and treatment adherence by identifying molecules with novel mechanisms of action and activity against all known resistant parasite strains [12].

In this context, computational approaches, especially quantitative structure-activity relationships (QSAR) modeling, have had a profound impact in drug discovery [13]. Methodologically, QSAR modeling can be presented as a three-part process. Initially, a set of chemicals with experimentally-determined biological properties is converted into molecular descriptors (independent variables). Then, statistical methods are employed to establish relationships between descriptors and the biological properties (dependent variable) [14,15]. Early statistical methods used in QSAR applications were linear regression models [16–18], but these were quickly supplanted by Bayesian neural networks [19,20], followed by Support Vector Machines [21] and Random Forests [22–24]. Once statistically validated using appropriate metrics, the generated model represents a helpful tool for the virtual screening (VS) of new chemicals with desired biological properties.

The availability of large datasets of chemical compounds with at least one biological property measured [25,26], associated with thousands of molecular descriptors paired with the popularization of in silico approaches resulted in the widespread use of QSAR for a diverse array of biological properties relevant to drug discovery [27–32]. However, dealing with big datasets has posed a challenge to model biological properties using classical machine learning algorithms [33,34]. To address this issue, deep learning methods (deep neural networks) have been presented as a practical solution [35,36]. Deep learning is particularly well-suited for QSAR modeling because it possesses multiple hidden layers capable of computing adaptive non-linear features that increasingly capture complex data patterns with each iterative additional layer, which makes this approach useful for tackling more complex chemical data [37,38].

Recently, there have been some exciting studies implementing deep learning for de novo design of molecules [39–41] compounds with desired activity. Here, we developed a modeling protocol employing deep learning to build binary and continuous QSAR models based on large datasets and applied them for predicting the antiplasmodial activity and cytotoxicity of untested compounds. Then, the prioritized compounds were experimentally evaluated against asexual blood stages P. falciparum and mammalian cells. The general study design is presented in Fig 1. Briefly, we followed the following successive steps: (i) dataset collection, curation, and integration of molecules with activity against P. falciparum and cytotoxicity in fibroblasts; (ii) chemical space analysis of curated datasets; (iii) development of both binary and continuous QSAR models using deep learning; (iv) mechanistic interpretation of continuous models to provide structural and biological insights useful for design of new antiplasmodial compounds; (v) VS of ChemBridge chemical database (∼500,000 compounds); (vi) experimental validation of prioritized compounds on asexual blood stages of P. falciparum (sensitive and multi-drug resistant strains) and mammalian cells; and (vii) identification of novel antiplasmodial compounds.

(i) dataset collection, curation, and integration of molecules with activity against P. falciparum and cytotoxicity in fibroblasts; (ii) chemical space analysis; (iii) development of QSAR models using deep learning; (iv) mechanistic interpretation of models; (v) VS of ChemBridge chemical database; (vi) experimental validation of prioritized compounds; and (vii) identification of novel antiplasmodial compounds.

## Section: Results

Cluster analysis of A) 1,162 compounds from P. falciparum dataset and B) 1,270 compounds from cytotoxicity dataset. Dendrogram and heatmap of the distance matrix are both colored according to structural similarity (orange/red = similar; blue/violet = dissimilar). The x- and y-axis labels of the heatmap represent compounds.

The plot was obtained using barycentric coordinates from 2D RDKit descriptors showing active (blue dots) and inactive (black diamonds) compounds of P. falciparum dataset and toxic (red stars) and nontoxic (green triangles) from cytotoxicity dataset.

Compounds experimentally tested in P. falciparum assay, extracted from the literature and used to build/validate our models. Fragments increasing the activity are colored in red; structural moieties decreasing the activity are highlighted in green; indifferent fragments are not highlighted. pEC50 exp = pEC50 experimental; pEC50 pred = pEC50 predicted.

Veber and Lipinski rules were used to prioritize candidate compounds with good oral bioavailability, to ensure that the compound has basic properties of active drugs; colloidal aggregation tool was used to filter out molecules that are known to aggregate in experimental assays; chemical similarity analysis and visual inspection were performed to select a subset of structurally diverse candidate compounds.

Atoms or fragments promoting positive contribution for the antiplasmodial activity are highlighted in red.

## Section: Results › Chemical space analysis

Initially, an activity threshold of 1 μM based on half maximal effective concentration (EC50) against P. falciparum was defined for discrimination between active and inactive compounds previously tested against asexual blood stages of P. falciparum. In addition, a threshold of 10 μM based on half-maximal cytotoxic concentration (CC50) for the NIH/3T3 cells was defined for discrimination between toxic and nontoxic compounds [42]. The analysis of chemical space was performed by using the curated datasets (see Materials and Methods) for erythrocytic stages of P. falciparum 3D7 strain (chloroquine sensitive) dataset containing 1,162 compounds (P. falciparum dataset) and cytotoxicity dataset tested against mouse embryonic fibroblasts (NIH/3T3 cell line) containing 1,270 compounds (cytotoxicity dataset). This analysis has been performed by clustering both datasets separately, which revealed that both are very structurally dissimilar, containing smaller clusters of similar compounds (Fig 2).

Although the datasets are structurally diverse, they share the same regions of chemical space. When analyzing the chemical space of both datasets together, by protting the two-dimensional barcentric coordinates [43] (Fig 3, see Materials and Methods for details), one can see that most of the active and inactive compounds from P. falciparum dataset overlap within the same regions of chemical space of toxic and nontoxic compounds from the cytotoxicity dataset. This analysis reveals that multiple compounds active against P. falciparum in the erythrocytic stage are potentially toxic in mouse embryonic fibroblasts. For this reason, we developed predictive computational models for both biological properties in order to select only compounds predicted as active for P. falciparum and nontoxic for mammalian cells.

Cluster analysis of A) 1,162 compounds from P. falciparum dataset and B) 1,270 compounds from cytotoxicity dataset. Dendrogram and heatmap of the distance matrix are both colored according to structural similarity (orange/red = similar; blue/violet = dissimilar). The x- and y-axis labels of the heatmap represent compounds.

The plot was obtained using barycentric coordinates from 2D RDKit descriptors showing active (blue dots) and inactive (black diamonds) compounds of P. falciparum dataset and toxic (red stars) and nontoxic (green triangles) from cytotoxicity dataset.

## Section: Results › Performance of binary QSAR models

Binary QSAR models were built to distinguish active vs. inactive compounds for P. falciparum and toxic vs. nontoxic compounds for NIH/3T3 cells. According to the statistical results of a 5-fold external cross-validation procedure (see Materials and Methods), the combination of Morgan and FeatMorgan fingerprints (radius 2: FeatMorgan_2, Morgan_2; radius 4: FeatMorgan_4, Morgan_4) with deep learning (see Materials and Methods for details) led to predictive binary QSAR models. Statistical characteristics of developed QSAR models estimated by 5-fold external cross-validation are reported in Table 1. Briefly, correct classification rate (CCR) values were ranging between 0.82–0.87; sensitivity (SE)– 0.82–0.87; specificity (SP)– 0.82–0.87, and a coverage– 0.77–0.87. Table 1 shows the detailed performances of the binary QSAR models. The model built using Morgan_2 demonstrated the best performance among all other models developed for P. falciparum (CCR = 0.84; SE = 0.82; SP = 0.86; and PPV = 0.86). On the other hand, the best model developed for prediction of cytotoxicity for mammalian fibroblasts was built using FeatMorgan_4 (CCR = 0.87; SE = 0.87; and SP = 0.87).

## Section: Results › Performance of continuous QSAR models

We have developed continuous QSAR models aiming to predict negative logarithmic units of EC50 values (pEC50) against P. falciparum and CC50 values (pCC50) against NIH/3T3 cell line. According to the statistical results of a 5-fold external cross-validation procedure, the combination of Morgan and FeatMorgan fingerprints (radius 2: FeatMorgan_2, Morgan_2) with deep learning led to statistically predictive models (Table 2), with predictive squared correlation coefficient for the test set (Qext2) values ranging between 0.70–0.88, root mean square error of cross-validation (RMSECV) of 0.44–0.55, mean absolute error (MAE) of 0.31–0.43, and coverage of 0.79–0.81. The model built using Morgan_2 demonstrated the best performance among all other models developed for P. falciparum (Qext2 = 0.88, RMSECV = 0.49, and MAE = 0.43). On the other hand, the best model developed for prediction of cytotoxicity for mammalian fibroblasts was built using FeatMorgan_2 (Rext2 = 0.74, RMSECV = 0.44, and MAE = 0.31).

## Section: Results › Model interpretation

To provide a mechanistic interpretation and shed some light from the structural and biological data used to build the continuous QSAR models, we plotted the predicted feature (fingerprint) importance to visualize how the fragments contributed for the antiplasmodial activity and the cytotoxicity (Fig 4 and S1 Fig). According to our results, atoms or fragments promoting positive contribution for the antiplasmodial activity are highlighted in red, while structural moieties decreasing the activity are highlighted in green.

By analyzing the contribution maps generated for the P. falciparum dataset, we identified six major fragments with favorable contribution for antiplasmodial activity. Examples of favorable fragments are as follows: 1,2,4,5-tetraoxaspiro[5.5]undecane; 7-chloroquinoline; 2,5-dimethylhexa-1,5-diene; pyridin-2-amine; 1,4-dihydroquinolin-4-one; and 1,3,5-triazine-2,4,6-triamine. We also identified six fragments with unfavorable contribution for antiplasmodial activity, such as: 1,2-dimethyl-1,4-dihydropyridin-4-one; 2-methylfuran; 5-guanidine; N-ethylpropanamide; 2,6-dimethylhepta-1,5-diene; and 4H-pyrido[1,2-a]pyrimidin-4-one. Moreover, we also calculated the predicted influence of structural fragments on the cytotoxicity. A summarized list of atoms or fragments with favorable and unfavorable contribution for cytotoxicity on mammalian fibroblasts is available in S1 Fig. The structural and biological information provided by the QSAR models developed using deep learning could be useful for designing or optimizing potent and selective antiplasmodial compounds by replacing unfavorable fragments by favorable fragments, assuming true independence of physicochemical effects.

Compounds experimentally tested in P. falciparum assay, extracted from the literature and used to build/validate our models. Fragments increasing the activity are colored in red; structural moieties decreasing the activity are highlighted in green; indifferent fragments are not highlighted. pEC50 exp = pEC50 experimental; pEC50 pred = pEC50 predicted.

## Section: Results › Virtual screening

The virtual screening (VS) was carried out following the workflow presented in Fig 5. Initially, 486,115 compounds available on EXPRESS-Pick collection of ChemBridge were downloaded and standardized for VS. Then, drug-likeness filters (Veber [44] and Lipinski’s rules [45]) were applied to prioritize molecules with good oral bioavailability, to ensure that the compound has basic properties of active drugs. In parallel, colloidal aggregation tool was used to filter out molecules that are known to aggregate in experimental assays [46,47] After these steps, 72,260 compounds were excluded. Afterwards, the remaining compounds were submitted to conservative binary and continuous QSAR models for prediction of the activity against blood stages of P. falciparum and cytotoxicity against mammalian cells. The final selection of candidate compounds can be summarized as follows: (i) the compounds predicted as active and non-cytotoxic by the binary QSAR models; (ii) compounds with pEC50 ≥6.00 (i.e., EC50 ≤1 μM for P. falciparum) and pCC50 <5.00 (i.e., CC50 >10 μM for mammalian cells) predicted by the continuous QSAR models; (iii) and compounds inside the applicability domain (AD) of the QSAR models. The combination of binary and continuous QSAR models was implemented to increase success rates in virtual screening campaign. In addition, the AD was determined in order to set “reliable” and “unreliable” predictions [48,49]. The predictions were considered reliable when they were within the chemical space used for training the models. Finally, we performed a chemical similarity analysis to select a subset of structurally diverse compounds. At the end of this process, five candidate compounds were selected for biological evaluation (Fig 6).

Veber and Lipinski rules were used to prioritize candidate compounds with good oral bioavailability, to ensure that the compound has basic properties of active drugs; colloidal aggregation tool was used to filter out molecules that are known to aggregate in experimental assays; chemical similarity analysis and visual inspection were performed to select a subset of structurally diverse candidate compounds.

Atoms or fragments promoting positive contribution for the antiplasmodial activity are highlighted in red.

## Section: Results › Experimental validation

The five candidate compounds were evaluated in vitro against asexual blood stages of P. falciparum sensitive (3D7), and multi-drug-resistant (W2) strains. The EC50 for each compound (Table 3) indicate that two compounds, 2-(4,6-diphenyl-1,2-dihydro-1,3,5-triazin-2-yl)phenol (LabMol-149), 4-{N-[3-(morpholin-4-yl)-1,4-dioxo-1,4-dihydronaphthalen-2-yl]acetamido}benzoic acid (LabMol-151) and N2-(3-fluorophenyl)-N4-[(oxolan-2-yl)methyl]quinazoline-2,4-diamine (LabMol-152), were potent at inhibiting the parasite growth, showing activities in submicromolar and low nanomolar range against both 3D7 and W2 strains. Moreover, the compound LabMol-152 (EC50 = 0.049 μM and 0.078 μM for 3D7 and W2, respectively) showed efficacy in the same range of activity of the reference drugs, chloroquine (EC50 = 0.011 μM) and pyrimethamine (EC50 = 0.037 μM). The candidate compounds were also evaluated for their cytotoxicity against fibroblast-like cell lines derived from monkey kidney (COS-7 cells). With respect to selectivity, LabMol-149 and LabMol-152 showed the most promising results (selectivity index, SI, ranging between 71.4–340.8, Table 3).

## Section: Discussion

In this work, we used a deep learning technique to obtain both binary and continuous QSAR models to predict the antiplasmodial activity and cytotoxicity of untested compounds. Models were developed following the best practices of QSAR modeling [14,15], which are fully compliant to Organization for Economic Co-operation and Development (OECD) guidance [50], such as (i) a defined endpoint (biological properties in our case), (ii) an unambiguous algorithm, (iii) a defined applicability domain (AD), (iv) appropriate measures of goodness-of-fit, robustness, and predictivity, and (v) mechanistic interpretation, if possible [50].

Our study follows the most recent tendencies in the usage of deep learning to probe chemical space of drug-like molecules [38,51]. As a result, we have obtained predictive QSAR models, with CCR values ranging between 0.82–0.87 (binary models) and Qext2 values ranging between 0.70–0.88 (continuous models). These results suggest that deep learning can be efficiently used to rationalize the identification of potent and selective antiplasmodial compounds in early stages of drug discovery. In addition, analysis of chemical space of P. falciparum and cytotoxicity dataset revealed that the compounds active against P. falciparum share the same chemical space of many compounds that are toxic in mouse embryonic fibroblasts.

By applying the workflow presented on Fig 5, we were able prioritize five new compounds for further experimental testing in vitro against sensitive (3D7) and multidrug-resistant (W2) strains of P. falciparum. Two compounds (LabMol-149 and LabMol-151) showed activity at submicromolar concentrations against asexual blood stages and low cytotoxicity in mammalian cells. More remarkable, the compound LabMol-152 showed efficacy in the same range of activity as the reference drug pyrimethamine against 3D7 strain (EC50 = 0.049 and 0.037 μM, respectively). Drug resistance in Plasmodium spp. is a complex daunting issue, and there is an opinion that resistant parasite strains will always emerge [12]. Although not fully understood, clinical resistance is probably due to high parasite genetic diversity and the misuse of therapeutics. The compounds tested here present chemical scaffolds dissimilar from current antimalarial drugs, according to the Tanimoto coefficient calculated using MACCS structural keys descriptors (Fig 7, S2 and S3 Figs, Supporting Information). Furthermore, no compound showed cross-resistance with a P. falciparum multidrug-resistant strain, thus indicating new mechanisms of action and potentially representing new weapons in our arsenal of antimalarials. However, parasite resistance to new compounds seems more likely to be a problem by de novo acquisition than pre-existing resistance [52]. Thus, how quickly resistance against our compounds would occur is an interesting question and needs to be better elucidated in future studies.

To summarize, the approach developed in this study allowed us to discover three new chemicals belonging to three different structural families (triazines, naphtoquinones, and quinazolines), which are promising starting points for developing of potential next generation antimalarial agents. Moreover, two of these compounds (LabMol-149 and LabMol-152) completely satisfy the guidelines and criteria for discovery of new antimalarial drugs, i.e., activity at low nanomolar concentrations (EC50 <500nM) against sensitive and multiple resistant strains of Plasmodium spp. and SI greater than 10 folds [12,42]. Future directions include structural optimization of potency and selectivity, determination of the stage in the asexual life cycle of P. falciparum where these compounds seem to act, as well as in vivo assays.

The similarity was accessed by the Tanimoto coefficient (Tc) and MACCS structural key fingerprints.

## Section: Materials and methods › Computational › Datasets

In this study, deep learning algorithms were explored to build binary and continuous QSAR models using two datasets extracted from the ChEMBL database (https://www.ebi.ac.uk/chembl/) [25]. A brief description of the datasets is presented below.

## Section: Materials and methods › Computational › Data curation

All chemical structures and correspondent biological information were carefully standardized using Standardizer v.16.9.5.0 (ChemAxon, Budapest, Hungary, http://www.chemaxon.com) according to the protocols proposed by Fourches and colleagues [53–55]. Briefly, explicit hydrogens were added, whereas polymers, salts, metals, organometallic compounds, and mixtures were removed. In addition, specific chemotypes such as aromatic rings and nitro groups were normalized. Furthermore, we performed the analysis and exclusion of duplicates. Different criteria were adopted, as follows:

## Section: Materials and methods › Computational › Chemical space analysis

Chemical space formed by P. falciparum and cytotoxicity datasets was analyzed by plotting the barycentric coordinates of all the structures encountered in both datasets, which were defined by the 2D RDKit descriptors. Barycentric coordinates correspond to the location of the points of a simplex (a triangle, tetrahedron, etc.) in the space, defined by the vertices [43]. In other words, the location of a chemical in a multidimensional space of 2D RDKit descriptors has been scaled to two dimensions. In this case, a simplex is defined by all the RDKit descriptors of a particular chemical substance. Barycentric coordinates were determined using Methods of Data Analysis module of HiT QSAR software [57]. In addition, both datasets were independently clustered using the Sequential Agglomerative Hierarchical Non-overlapping method [58] implemented in Python v.3.6. Briefly, a dendrogram of the parent-child relationships between clusters and a heatmap of the proximity matrix colored according to the pairwise chemical similarity between compounds. To better visualize the clusters, the distance matrix of the compounds from the two datasets were independently calculated and the compounds were clustered.

## Section: Materials and methods › Computational › Molecular fingerprints

Morgan and FeatMorgan fingerprints were calculated in the open-source cheminformatics software RDKit (http://www.rdkit.org, [59]) executed on Python v.3.6 (https://www.python.org). Both fingerprints were generated with radius 2−4 and bit vector of 2,048 bits. Morgan is a type circular fingerprint built by applying the Morgan algorithm to a set of user-supplied 2D chemical structures [60,61]. The fingerprint generation process systematically records the neighborhood of each non-hydrogen atom into multiple circular layers up to a stablished radius. The radius is a dominant parameter which controls the number and the maximum size of considered atom neighborhoods, thus it controls the complexity of fragment representation. These atom-centered substructural features are interpreted as indexes of bits in a huge virtual bit string. Each position in this bit string accounts for the presence or absence of a specific fragment feature [60,61]. The Morgan captures highly specific atomic information enabling the representation of a large set of precisely defined structural features [60]. Additionally, invariants of Morgan called as FeatMorgan fingerprints can also be calculated by including functional features (i.e., hydrogen-bond donor and acceptors, aromatic, halogen, basic and acid groups) [62].

## Section: Materials and methods › Computational › Deep learning

The binary and continuous QSAR models were developed using Keras (https://keras.io/), a deep learning library, and Tensorflow (www.tensorflow.org), a GPU training and CPU for prediction), as backend. Binary models were trained using previously established activity/toxicity thresholds, while continuous models were developed using pEC50 (P. falciparum) and pCC50 (cytotoxicity). The following parameters of the deep learning method were optimized prior to model training: layer type (dense), hidden layers (8), activation function (ReLU), output layer function (sigmoid), model optimizer (Adam). The “binary cross-entropy” and “mean squared error” were used as loss functions in binary and continuous QSAR modeling, respectively. The “accuracy” and “mean absolute error” were used as parameters to judge the performance of binary and continuous models, respectively. The following hyperparameters were used for further deep learning training: epochs (5, 10, 50, 100), and batch size (10, 20, 40, 60, 80, 100).

## Section: Materials and methods › Computational › 5-fold external cross-validation (5FECV)

According to the best practices of QSAR modeling [15], we chose five-fold external cross-validation for the estimation of predictivity of developed models. The procedure can be described as follows: the entire dataset of compounds was randomly divided into five subsets of equal size; then one of these subsets (20% of all compounds) is set aside as an external validation set and the remaining four sets together form the modeling set (80% of the full set). This procedure was repeated five times, allowing each of the five subsets to be used as an external validation set. Models were built using the modeling set while the compounds in momentary external set (fold) were employed to evaluation of predictive performance.

## Section: Materials and methods › Computational › Performance of QSAR models

The predictive performance of binary QSAR models was evaluated using sensitivity (SE), specificity (SP), correct classification rate (CCR), positive predictive value (PPV), and negative predictive value (NPV). These metrics were calculated as follows:

Here, TP and TN represent the number of true positives and true negatives, respectively, while FP and FN represent the number of false positives and false negatives, respectively.

The predictive performance of continuous QSAR models was evaluated using correlation coefficient (R2), root mean square error of cross validation (RMSECV), mean absolute error (MAE), and predictive squared correlation coefficient for the test set (Qext2) [63]. These metrics were calculated as follows:

In the above equations, Yobs represents experimental pEC50 or pCC50 value, Ypred represents the predicted pEC50 or pCC50 value, ntrain and ntest are the number of compounds in training and test set, respectively, and Y¯train is the average of experimental values of the training set.

## Section: Materials and methods › Computational › Applicability domain

The AD was estimated based on the Euclidean distances among the training set of each QSAR model generated in the 5-fold external cross-validation procedure. The distance of a test set compound to its nearest neighbor in the training set was compared to the predefined AD threshold level. The prediction was considered to be less reliable if the distance was greater than the threshold level. In our study, the AD was defined as a distance threshold (DT) between a compound under prediction and the closest nearest neighbors in training set. The following equation was used for calculation of distance threshold [64]:

In which ӯ is the average Euclidean distance of the k nearest neighbors within the modeling set, σ is the standard deviation of these Euclidean distances, and Z is an arbitrary parameter to control the significance level. We set the default value of this parameter Z at 0.5. If the compound distance exceeded the threshold, the prediction was considered to be less trustworthy [65].

## Section: Materials and methods › Computational › Mechanistic interpretation

Contribution maps were generated from continuous QSAR models to visualize the atomic and fragment contributions for antimalarial activity and cytotoxicity. Here, the "weight" of an atom was considered as predicted-potency difference obtained when the bits in the fingerprint corresponding to the atom are removed. Then, the normalized weights were used to color the atoms in a topography-like map in which green indicating a negative difference (i.e., potency increases when the bits are removed), and red indicating a positive difference in biological property.

## Section: Materials and methods › Computational › Virtual screening (VS)

Developed QSAR models were used for VS of EXPRESS-Pick collection of ChemBridge Corporation (http://www.chembridge.com/) aiming to identify new potential antiplasmodial compounds, which could be potentially selective against the parasite (i.e. non-toxic to mammalian cells). Prior to screening, the database was filtered using a aggregator advisor tool to identify molecules that are known-to aggregate in experimental assays [46,47]. Subsequently, Veber [44] and Lipinski’s rules [45] were employed in screening to prioritize drug-like compounds. Then, the remaining compounds had their antiplasmodial activity and cytotoxicity against mammalian cells predicted by binary and continuous QSAR models. In addition, the structural diversity of candidate compounds was investigated using pairwise Tanimoto coefficients between compounds. Finally, the selected candidate compounds were purchased and submitted to in vitro experimental evaluation.

## Section: Materials and methods › Experimental › Materials

Candidate compounds were purchased from ChemBridge (San Diego-CA, USA) and resuspended in 100% DMSO. It is important to mention that all compounds had a minimum purity of 95%. The DMEM and RPMI 1640 media were purchased from Vitrocell Embriolife (Campinas-SP, Brazil). All other reagents were purchased from Sigma-Aldrich (St. Louis-MO, USA).

## Section: Materials and methods › Experimental › Parasite culture

The 3D7 and W2 strains were cultured in RPMI 1640 medium supplemented with 0.05 mg/mL gentamycin, 38.4 mM HEPES, 0.2% sodium bicarbonate, and 10% O+ human serum, as previously described in standardized protocol [66]. Then, erythrocytes were added to the culture to obtain a 5% of hematocrit, and incubated at 37°C under 5% CO2 atmosphere, with daily exchange of medium. The parasitemia was monitored daily in smears, stained with Giemsa. Synchronic cultures in ring stage were obtained by two consecutive treatments, at 48h intervals with a 5% solution of D-sorbitol [67].

## Section: Materials and methods › Experimental › Antiplasmodial assay

Parasites synchronized at the ring stage, with 0.5% parasitemia and 2% hematocrit, were distributed in the wells of a 96-well plate. The compounds were tested in triplicates using 12-point dilution series (0.019 μM– 40 μM) over 72h. Chloroquine and pyrimethamine were used as positive controls. The in vitro susceptibility of parasite to tested drugs was measured by SYBR Green according to Hartwig and colleagues [68]. Briefly, 100 μL of lysis buffer (20 mM Tris, 5 mM EDTA, 0,008% wt/vol saponin, 0,08% vol/vol Triton X-100 and 0.4 μL/mL of SYBR Green) were added in each well of a new black 96-well plate and 100 μL of parasite culture incubated with drugs were transferred. After homogenization, the plates were incubated for 1h in the dark. Fluorescence was measured at 490 nm excitation and 540 nm emission (CLARIOstar, Labtech BMG).

## Section: Materials and methods › Experimental › Cytotoxicity assay

Cytotoxicity assays used fibroblast-like cell lines derived from monkey kidney tissue (COS7 cells), grown in DMEM medium supplemented with 10% fetal bovine serum and 0.05 mg/mL gentamicin in atmosphere containing 5% CO2 at 37°C. Drug cytotoxicity in COS-7 cells was determined in duplicate, using 12 dilution series (0.097 μM– 200 μM). After an incubation period (72 hours), cell viability analysis was performed via the MMT reduction method (3- [4,5- dimethyl-thiazol-2-yl] -2,5-diphenyltetrazolium chloride) [69]. The optical density was determined at 570 nm (CLARIOstar, Labtech BMG) and the 50% cytotoxicity concentrations (CC50) was expressed as the percent viability relative to the control.

## Section: Materials and methods › Experimental › Statistics

The EC50 and CC50 values were calculated by plotting the Log doses vs. inhibition (expressed as a percentage relative to the control) in GraphPad Prism v.6 (GraphPad Software, La Jolla California USA, www.graphpad.com).

## Section: Supporting information

(XLSX)

Click here for additional data file.

(XLSX)

Click here for additional data file.

(XLSX)

Click here for additional data file.

(XLSX)

Click here for additional data file.

Fragments contributing for the cytotoxicity are colored in red, atoms or fragments decreasing the cytotoxicity are highlighted in green, and no highlighting means no influence to cytotoxicity.

(TIF)

Click here for additional data file.

The similarity was calculated using Tanimoto coefficient (Tc) and MACCS structural keys descriptors.

(TIF)

Click here for additional data file.

The similarity was calculated using Tanimoto coefficient (Tc) and MACCS structural keys descriptors.

(TIF)

Click here for additional data file.

## Section: Acknowledgments

We are thankful for Kirsten Overdahl for her kind help with editing the manuscript. We gratefully acknowledge the support of NVIDIA Corporation with the donation of the Titan Xp GPU used for this research and ChemAxon for providing us with academic license for their software.

## Section: Data Availability

All relevant data are within the paper and its Supporting Information files.

## Section: Funding Statement

The authors would like to thank Brazilian funding agencies, CNPq, FAPEG, FAPESP, and CAPES for financial support and fellowships. FTMC, GCC, and CHA were supported by FAPESP (grants #2012/16525-2, #2015/20774-6, 2017/18611-7 and #2017/02353-9). ENM appreciate financial support of NIH (grant 1U01CA207160). CHA and FTMC are CNPq research fellows. CHA also thanks the “L'Oréal-UNESCO-ABC Para Mulheres na Ciência” and “L’Oréal-UNESCO International Rising Talents” for the awards and fellowships received, which partially funded this work. The funders had no role in study design, data collection and analysis, decision to publish, or preparation of the manuscript.

## Section: Associated Data

(XLSX)

Click here for additional data file.

(XLSX)

Click here for additional data file.

(XLSX)

Click here for additional data file.

(XLSX)

Click here for additional data file.

Fragments contributing for the cytotoxicity are colored in red, atoms or fragments decreasing the cytotoxicity are highlighted in green, and no highlighting means no influence to cytotoxicity.

(TIF)

Click here for additional data file.

The similarity was calculated using Tanimoto coefficient (Tc) and MACCS structural keys descriptors.

(TIF)

Click here for additional data file.

The similarity was calculated using Tanimoto coefficient (Tc) and MACCS structural keys descriptors.

(TIF)

Click here for additional data file.

## Section: Associated Data › Supplementary Materials

(XLSX)

Click here for additional data file.

(XLSX)

Click here for additional data file.

(XLSX)

Click here for additional data file.

(XLSX)

Click here for additional data file.

Fragments contributing for the cytotoxicity are colored in red, atoms or fragments decreasing the cytotoxicity are highlighted in green, and no highlighting means no influence to cytotoxicity.

(TIF)

Click here for additional data file.

The similarity was calculated using Tanimoto coefficient (Tc) and MACCS structural keys descriptors.

(TIF)

Click here for additional data file.

The similarity was calculated using Tanimoto coefficient (Tc) and MACCS structural keys descriptors.

(TIF)

Click here for additional data file.

## Section: Associated Data › Data Availability Statement

All relevant data are within the paper and its Supporting Information files.


---

# Deep Neural Network for Reducing the Screening Workload in Systematic Reviews for Clinical Guidelines: Algorithm Validation Study

- **Authors:** Tomohide Yamada, Daisuke Yoneoka, Yuta Hiraike, Kimihiro Hino, Hiroyoshi Toyoshiba, Akira Shishido, Hisashi Noma, Nobuhiro Shojima, Toshimasa Yamauchi
- **Issuer:** Journal of medical Internet research
- **Type:** Scientific article
- **Published:** 2020-12-30
- **Language:** en
- **DOI:** 10.2196/22422
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33262102/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackgroundPerforming systematic reviews is a time-consuming and resource-intensive process.ObjectiveWe investigated whether a machine learning system could perform systematic reviews more efficiently.MethodsAll systematic reviews and meta-analyses of interventional randomized controlled trials cited in recent clinical guidelines from the American Diabetes Association, American College of Cardiology, American Heart Association (2 guidelines), and American Stroke Association were assessed. After reproducing the primary screening data set according to the published search strategy of each, we extracted correct articles (those actually reviewed) and incorrect articles (those not reviewed) from the data set. These 2 sets of articles were used to train a neural network–based artificial intelligence engine (Concept Encoder, Fronteo Inc). The primary endpoint was work saved over sampling at 95% recall (WSS@95%).ResultsAmong 145 candidate reviews of randomized controlled trials, 8 reviews fulfilled the inclusion criteria. For these 8 reviews, the machine learning system significantly reduced the literature screening workload by at least 6-fold versus that of manual screening based on WSS@95%. When machine learning was initiated using 2 correct articles that were randomly selected by a researcher, a 10-fold reduction in workload was achieved versus that of manual screening based on the WSS@95% value, with high sensitivity for eligible studies. The area under the receiver operating characteristic curve increased dramatically every time the algorithm learned a correct article.ConclusionsConcept Encoder achieved a 10-fold reduction of the screening workload for systematic review after learning from 2 randomly selected studies on the target topic. However, few meta-analyses of randomized controlled trials were included. Concept Encoder could facilitate the acquisition of evidence for clinical guidelines.Keywords: machine learning, evidence-based medicine, systematic review, meta-analysis, clinical guideline, deep learning, neural network

## Section: Introduction

Evidence-based medicine aims to provide treatment that matches a patient’s needs by integrating the best and latest scientific evidence and clinical skills [1]. Performing systematic reviews and meta-analyses is vital to obtain data that can inform evidence-based clinical decisions as well as the development of clinical and public health guidelines [2].

When performing a systematic review, it is critical to minimize potential bias by identifying all relevant published articles through exhaustive and systematic screening of the literature, which can be an extremely time-consuming and resource-intensive process.

The Cochrane collaboration mandates reinvestigation and updating of published systematic reviews and meta-analyses every 2 years to maintain the novelty and quality of evidence [3], but this is an onerous task. As a single systematic review or meta-analysis usually requires 1 to 2 years to complete, only one-third of all Cochrane reviews are updated on time [4], and many reviews are obsolete or missing [5,6]. Therefore, the development of methods for the automation of the systematic review process has been suggested [7].

To reduce the time and cost of screening literature when performing systematic reviews, researchers have explored the use of active learning text classification systems to achieve semiautomated exclusion of irrelevant studies while retaining a high proportion of eligible studies for subsequent manual review [8,9]. However, little progress has been made for the following reasons. First, previous studies did not investigate well-characterized and high-quality data sets, so the type of systematic review used as the data source was unclear, and the method of applying machine learning to the clinical studies was obscure. Second, previous reports did not specify how active machine learning was used. Third, only an approximate 30%-50% reduction of the workload was achieved [8]. Fourth, a method that extracts 100% of the correct articles from the literature has not been developed because most studies use a targeted extraction of 95% as the primary outcome; despite the importance of not missing any eligible studies when performing systematic reviews (ie, the objective is to identify all relevant articles) [10-14].

To overcome some of these issues, we studied systematic reviews of randomized controlled trials cited in several recent international clinical guidelines to investigate whether an active machine learning system (Concept Encoder, Fronteo Inc) could reduce the workload and accelerate the review process while improving its precision.

## Section: Methods

Flow diagram of information processing and user interaction with Concept Encoder.

## Section: Methods › Search Strategy and Selection of Reviews

This study was performed according to a specified protocol and was registered with the University Hospital Medical Information Network clinical trials registry (UMIN000032663). Our institutional review board waived the need for approval. Three reviewers (TYamada, HT, and NS) independently checked the reference lists of 5 recent clinical guidelines released by the American Diabetes Association [15], American College of Cardiology [16], American Heart Association (2 guidelines) [17,18], and American Stroke Association [19]. The reviewers identified all systematic reviews and meta-analyses cited in these guidelines with no language restrictions.

Next, the reviewers selected eligible systematic reviews and meta-analyses of interventional randomized controlled trials for medications that fulfilled the following inclusion criteria: First, a reproducible search strategy was required; therefore, articles with no description of the search strategy, or without a clear, reproducible description of the search strategy were excluded. In addition, meta-analyses using individual data, meta-analyses of observational studies, reports missing relevant information, and reviews of fewer than 5 studies were excluded. Finally, reviews were excluded if the primary screening data set did not include all of the correct articles (ie, those cited) when it was reproduced according to the published search strategy. Disagreements among the reviewers were resolved by consensus.

We reproduced primary screening data sets, including abstracts, according to reported search strategies, that is, a search strategy for PubMed was devised based on the search strategy for Ovid MEDLINE described in each review (Multimedia Appendix 1).

## Section: Methods › Active Machine Learning System

An artificial intelligence engine (Concept Encoder) [20] was used to convert sentences into vectors, extract and learn each vector component as a feature value, identify similar vectors as indicators of the similarity of sentence content, and perform a rapid search for similar sentences. Vectorization facilitates text analysis by providing numerical data that allow various calculations to be performed (eg, to assess clustering of results). In addition, vectorization allows searches to be based on the sums and differences of sentences, facilitating comparison of content between 2 sentences and resulting in a sentence retrieval engine that can be adapted to research targets.

First, each sentence is decomposed into morphemes (the smallest meaningful units of a language) by morphological analysis, applying rules to label each morpheme level element with a word. Next, the word labels were embedded in the k-dimension vector space [21-24] using the word2vec technique. Sentences can also be embedded in the k-dimension vector space using an expansion to the word-embedding method called doc2vec that yields paragraph vectors [21-24]. Several parameters are used in these embedding techniques, such as the number of embedded words, the vectors' dimensions, and negative sampling (ie, the number noise samples, nonobserved data, generated in both word2vec and doc2vec algorithms). These algorithms enable the transformation into vectors of words and documents from articles in a systematic review. Assuming that there are a total of m abstracts and n words in all the articles (both reviewed and not reviewed) in a single systematic review or meta-analysis (ie, 1 of the 8 systematic reviews or meta-analyses included) embedded in a k-dimension vector space, then the abstracts and words can be expressed as

Embedded vectors are well known to possess interesting features such as word analogy and outperform the bag of word approaches in several linguistic tasks. For example, if 2 articles have similar contents, then the 2 row vectors in D associated with those articles are a short cosine distance from one another. Similarly, the 2 row vectors in W associated with 2 words having a similar meaning are also a short cosine distance from one another. Hence, if there are differences between the articles that were reviewed and not reviewed, then the reviewed articles should be closer to each other than those that were not reviewed. These features persist after the 2 matrices are multiplied due to linearity of multiplication. For example, if wi ≅ wj for 2 row vectors in matrix W, then the inner product with d (a row vector in matrix D) is d · wi ≅ d · wj. Expanding this to word analogy, if wi – wi ≅ wi' – wj' where i, j, i', j' ∈ [1, 2, 3, ..., n] holds for 4 row vectors in matrix W, then d · wi – d · wj ≅ d · wi' – d · wj' is true for any row vector d in matrix D.

Hence, the product of these 2 matrices is a DW matrix, which is a sentence-word matrix that also possesses these interesting features of the original matrices.

In this study, sentence similarity was evaluated by using a DW matrix.

Neural networks have previously been used to calculate D and W matrices, but calculation of these matrices becomes computationally intense when a large number of articles are investigated [21-24]. Hence, a neural network is generally restricted to embedding the 1000 most common words in m articles. In our analysis, the 1000 most common words were identified for each of the 8 studies.

A skip-gram model with negative sampling was chosen to calculate W. The embedding vector dimension was set at k=300, which is usually considered sufficient to capture word and document features, and the number of negative samplings was set at ns=5. A previous paper [25] reported that values of negative sampling in the range of ns=5-20 were useful for small training data sets, whereas for large data sets, ns can be as small as 2-5; the size of the data sets used in this study ranged from m=138 to m=6935.

For D, the distributed bag of words version of paragraph vector [20-24] was used as it is usually consistent across many tasks [24]. The same negative sampling and embedding dimension (ns=5 and k=300) were used. Both D and W were obtained at the same time in this study. However, it is possible to obtain W first and then calculate D by using the pretrained W. We used the gensim (version 3.8.3)[26] package for Python (version 3.6) with ns=5, k=300, and 1000 words.

A dimension reduction technique, such as singular value decomposition, can be used to approximate the DW matrix with a lower dimension matrix to reduce computational requirements; however, this was not done in this analysis (the number of columns in the DW matrix kept as 1000).

## Section: Methods › Reproduction of the Reviews

The similarity of any 2 articles is defined as the cosine distance of the 2 vectors associated with these articles. After a correct (reviewed) or incorrect (not reviewed) article is identified, the associated row vector is defined as a correct or incorrect and used as the feature vector representing a correct or incorrect article. The cosine distances for all other articles (m − 1 articles) are calculated and arranged in descending order. For the next article from the top of the list, if the article is a correct one, the mean of the vectors for the correct articles is used to train Concept Encoder in the next step of active learning. If the article is an incorrect one, the vector is subtracted to train Concept Encoder in the next step of active learning, that is, it is used as the feature vector. Cosine distances between the updated vector and all other articles are calculated and ordered again, and this process is repeated until all of the correct articles have been identified. Here, the mean vector is simply used as the feature vector for the correct articles. We could build classification models using these vectors as features to arrange the remaining articles in a descending manner by active learning; however, similarity of articles seemed to be embedded in the vectors, and using the vectors directly as the features was effective. Therefore, we kept the process simple, and no further machine learning was conducted in our active learning process.

## Section: Methods › Workload Reduction

Using 2 randomly selected correct articles (selected by Concept Encoder from among the correct articles), the following steps were performed to calculate how much workload reduction could be achieved using Concept Encoder.

Flow diagram of information processing and user interaction with Concept Encoder.

## Section: Methods › Endpoints

The primary endpoint of this study was the reduction in the literature screening workload when Concept Encoder was used to identify all of the correct articles, relative to the workload for finding all of the correct articles by manual review with random sampling. WSS@95% recall was used for comparability as this endpoint is often used in previous studies (Multimedia Appendix 1).

## Section: Methods › Statistical Analysis

WSS and receiver operating characteristics were used to evaluate the performance of the algorithm. Area under the receiver operating characteristic curve (AUROC) shows how much the active learning improves classification ability between correct and incorrect articles at each step of learning .

To evaluate the impact of the 2 initial papers selected on system performance, all possible pairs of papers were generated and used to run the algorithm. Then the mean and standard deviation of WSS@95% were measured. The confidence interval of the AUROC was determined at each step of the active learning process for all 8 studies using scores calculated from the cosine distances for articles that were used or not used in the systematic reviews.

## Section: Results

A flowchart of our strategy for performing the literature search and study selection is shown in Figure 2. The systematic reviews and meta-analyses used in this study were cited in 5 recent clinical guidelines (93 from American Diabetes Association 2017 guidelines [15], 2 from American College of Cardiology guidelines for nonstatin therapy [16], 13 from American Heart Association 2017 guidelines for valvular disease [17], 18 from American Heart Association 2017 guidelines for heart failure [18], 19 from American Stroke Association 2015 guidelines [19]). Among the 145 candidate reviews, 137 were excluded, with the main reasons being that the search strategy was not described in sufficient detail to reproduce the data set (57 reviews), or the data set could not be reproduced despite following the described search strategy (45 reviews). A final 8 reviews published between 2012 and 2016 were selected [27-34]. These reviews comprised 2 Cochrane Database Systematic Reviews and 1 each published in JAMA Neurology, the British Medical Journal, PLOS Medicine, the Journal of the American Medical Association, the Lancet, and the Archives of Internal Medicine. The characteristics of these reviews are summarized in Multimedia Appendix 1.

After reproducing the primary screening data set (including abstracts) according to the search strategy described in each review, 81 sets of correct articles and 22,664 sets of incorrect articles were obtained (Multimedia Appendix 1). The search strategies employed for the reproduction of the data sets are detailed in Multimedia Appendix 1.

One of the 8 studies contained only 140 articles. The number of words appearing more than twice in the data set was approximately 1200, including the stopwords. We also wished to examine the difference in performance between studies. Figure 3 displays the average cumulative recall curves for the 8 reviews. The performance of Concept Encoder was evaluated for every possible pair of articles chosen at the start of active learning. Concept Encoder was found to significantly reduce the workload by at least 0.867 compared with manual screening (the lowest mean WSS@95%). The average reduction of the workload compared with manual screening was >90% or 10-fold (WSS@95%: mean 0.904), and Concept Encoder showed a high ability to discriminate between correct and incorrect studies (Table 1). The choice of the initial 2 articles only had a small influence on the performance of the learning algorithm.

Prioritization (ie, the score based on cosine distance) of the algorithm by machine learning increased the AUROC to between 0.99 to 1.00, while the standard deviation of the AUROC decreased with each prioritization step (Figure 4).

Literature search and study selection strategy.

Average cumulative recall curves for all data sets: (a) Chatterjee et al [27], (b) Balsells et al [28], (c) Muduliar et al [29], (d) Yanovski and Yanovski [30], (e) Eng et al [31], (f) McBrien et al [32], (g) Andrade Castetllanos et al [33], and (h) Arguedas et al [34]. WSS: work saved over sampling.

Review data sets and corresponding results.

Performance for an increasing number of prioritization steps: (a) Chatterjee et al [27], (b) Balsells et al [28], (c) Muduliar et al [29], (d) Yanovski and Yanovski [30], (e) Eng et al [31], (f) McBrien et al [32], (g) Andrade Castetllanos et al [33], and (h) Arguedas et al [34]. AUROC: area under the receiver operating characteristic curve.

## Section: Discussion › Principal Results

These findings demonstrated that an active machine learning system could dramatically reduce the workload for performing systematic reviews of randomized controlled trials in several medical fields. Our data suggest that an active machine learning system could improve the precision of the systematic review process as well as reduce the time required, thus assisting with the development of clinical guidelines. In this study, the deep neural network–based active machine learning system achieved a 10-fold reduction in the literature screening workload for systematic reviews after a researcher initiated the learning process by randomly selecting 2 studies.

## Section: Discussion › Strengths and Limitations

We demonstrated that a 90% reduction in the workload for searching literature compared with manual assessment could be achieved and, whereas previous research mainly focused on small databases, we showed that this reduction in workload could be applied to large data sets by using systematic reviews of clinical studies. In addition, we specifically described the methods employed by our active machine learning system for systematic reviews of literature, which most previous reports do not explain.

One of the limitations of our study was the absence of a criterion for when active learning can be stopped. The study focused on how much workload could be reduced by the embedding-based technique using WSS@95%; however, active learning could increase the AUROC value as active learning steps proceeded; and therefore, at some point, this method could separate correct articles from incorrect articles in the learning process. The other limitation of the study was that 2 correct articles were required at the beginning of active learning. In practice, it may be challenging to start the review process with 2 correct articles already identified. This limitation might be overcome by using 2 consecutive systematic reviews on the same topic; the papers used in the first review could be used as the learning data to identify new articles for the second systematic review.

## Section: Discussion › Comparison With Prior Work

Several studies using text mining or computational technique to reduce workload in systematic reviews have been reported. Marshall et al [35] used an ensemble model consisting of support vector classification and convolutional neural networks to classify randomized controlled trial papers and showed that the model predicted randomized controlled trial papers (AUROC 0.987, 95% CI 0.984-0.989) and also discussed the automating risk of bias assessment using large corpus labeled by distant supervision and presented a step toward automating or semiautomating the data extraction needed for the synthesis of clinical trials [36]. These authors also evaluated the performance of the RobotReviewer in another paper [37] and showed that machine learning could help reviewers to detect sentences or documents containing risk of bias but are not be able to replace manual review by humans yet. However, these works showed a great potency of workload reduction in systematic reviews with machine learning techniques. Wallace et al [38] developed a tool for systematic review called Abstrackr. Based on its technical report [38], 2 case studies were tested, and a 40% workload reduction with 100% recall was achieved. Rathbone et al [39] evaluated the performance of Abstrackr for 4 systematic reviews and summarized that reduction of workload varied from 10% to 80%, but that precision was also decreased. Recently, Gates et al [40] evaluated the Abstrackr performance retrospectively against human review for 4 studies and concluded that it could reduce workload by 9.5% to 88.4%, varying by the screening task. A review of systematic reviews [41] noted that current use of text mining in systematic reviews could reduce workload from 30% to 70%, at 95% recall. As for other techniques to reduce workload in systematic reviews, using 17 studies, RobotAnalyst [42] was reported as an active learning approach using latent Dirichlet allocation to reduce workload, for which WSS@95% varied between 6.89% to 70.74%. Workload reduction varies by study or task; therefore, direct comparison with our study is difficult. However, our method, using an embedding-based technique, showed good performance with the 8 systematic review data sets of randomized controlled trials.

Regarding other embedding methods, embedding vectors from BioBERT-Base version 1.1 (4.5 billion PubMed abstracts, trained for 1 million steps) [43] were applied to the same 8 studies. WSS@95% was calculated for each study using the same algorithm. The mean WSS@95% for the 8 studies was 0.747 (SD 0.119), which was about 15% lower than the 0.904 (SD 0.02) from this study (Table 1). Fine-tuning for each study was not performed because some of the studies include only a small number of articles. Hence, the performance of BioBERT could be improved by fine-tuning. However, the method in the present paper is still competitive enough considering the performance and simplicity of the model.

We assessed systematic reviews and meta-analyses of randomized controlled trials because these can estimate the true efficacy and risks of treatment. In contrast, estimates derived from systematic reviews and meta-analyses of epidemiological studies are more limited due to the observational design of the underlying studies. Therefore, further investigation will be needed to assess the effectiveness of our system for meta-analyses of epidemiological studies. Furthermore, in the future, we plan to evaluate Cochrane review papers, which have a standardized review process.

## Section: Discussion › Conclusion

The deep neural network–based active machine learning system investigated in this study achieved at least a 10-fold reduction of the literature screening workload for systematic reviews after a researcher initiated the learning process by randomly selecting 2 studies that fulfilled the inclusion criteria for the target review. Our findings suggest that machine learning could facilitate the acquisition of evidence for developing new clinical guidelines.

## Section: Acknowledgments

TYamada was funded by The Japan Diabetes Society, Japan Society for the Promotion of Science (16 K20965), Japan Foundation for Applied Enzymology, Japan Health Promotion Foundation, Pfizer Health Research Foundation, Suzuki Manpei Diabetes Foundation, The Daiwa Anglo-Japanese Foundation, The Tanita Healthy Weight Community Trust, Daiwa Securities Health Foundation, European Foundation for the Study of Diabetes and Japan Diabetes Society Reciprocal Travel Research Fellowship Programme, The Kanae Foundation for the Promotion of Medical Science, The Takano Science Foundation, Senri Life Science Foundation, Foundation for Total Health Promotion, The Telecommunications Advancement Foundation, Okinaka Memorial Institute for Medical Research, The Uehara Memorial Foundation, Kao Healthcare Science Foundation, Fuji Foundation for Protein Research, Honjo International Scholarship Foundation, The Salt Science Research Foundation, Japan Health and Research Institute, and The Health Care Science Institute. The funding sources had no role in the design, conduct, and reporting of this study.


---

# Developing a machine learning model to identify protein-protein interaction hotspots to facilitate drug discovery

- **Authors:** Rohit Nandakumar, Valentin Dinu
- **Issuer:** PeerJ
- **Type:** Scientific article
- **Published:** 2020-12-07
- **Language:** en
- **DOI:** 10.7717/peerj.10381
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33354416/
- **Licence:** CC-BY

## Section: Abstract

AbstractThroughout the history of drug discovery, an enzymatic-based approach for identifying new drug molecules has been primarily utilized. Recently, protein–protein interfaces that can be disrupted to identify small molecules that could be viable targets for certain diseases, such as cancer and the human immunodeficiency virus, have been identified. Existing studies computationally identify hotspots on these interfaces, with most models attaining accuracies of ~70%. Many studies do not effectively integrate information relating to amino acid chains and other structural information relating to the complex. Herein, (1) a machine learning model has been created and (2) its ability to integrate multiple features, such as those associated with amino-acid chains, has been evaluated to enhance the ability to predict protein–protein interface hotspots. Virtual drug screening analysis of a set of hotspots determined on the EphB2-ephrinB2 complex has also been performed. The predictive capabilities of this model offer an AUROC of 0.842, sensitivity/recall of 0.833, and specificity of 0.850. Virtual screening of a set of hotspots identified by the machine learning model developed in this study has identified potential medications to treat diseases caused by the overexpression of the EphB2-ephrinB2 complex, including prostate, gastric, colorectal and melanoma cancers which are linked to EphB2 mutations. The efficacy of this model has been demonstrated through its successful ability to predict drug-disease associations previously identified in literature, including cimetidine, idarubicin, pralatrexate for these conditions. In addition, nadolol, a beta blocker, has also been identified in this study to bind to the EphB2-ephrinB2 complex, and the possibility of this drug treating multiple cancers is still relatively unexplored.Keywords: Machine learning, Protein-protein interaction, Drug discovery

## Section: Introduction

Drug discovery is the scientific process where new drugs and small molecules are developed and identified to treat certain conditions. Throughout most of the history of drug discovery, an enzymatic-based (lock and key) approach for identifying new drug molecules was utilized (Bakail & Ochsenbein, 2016). As a result, many drugs targeting G-protein coupled receptors (GPCRs), which interact via this approach, constitute about 34% of the drugs in the market today (Hauser et al., 2017).

Protein-protein interfaces have been of particular interest in regards to drug discovery, such as the EphA4-EphrinB2 complex, which is considered to be conformationally flexible (Ma & Nussinov, 2014). Protein-protein interfaces can be stabilized or disrupted to identify small molecules that could be viable targets for certain diseases such as cancer and the human immunodeficiency virus (HIV). Identifying residue hotspots on these protein–protein interfaces and repurposing existing drugs to target these new hotspots can lead to novel drug targets, ultimately leading to new therapeutic treatments (Scott et al., 2016). Although protein-based drug discovery (as opposed to enzymatic-based drug discovery) is a relatively new and emerging field, recent studies have shown promising results in regard to its potential in a wide range of fields from drug discovery to drug repositioning. For example, the SpotOn study has produced remarkable results in regards to identifying hotspots that are viable for drug discovery, and AnchorQuery, which identifies small molecule protein-interaction inhibitors (Moreira et al., 2017; Koes, Dömling & Camacho, 2018).

In addition, PPI-based peptide drug discovery has been used to identify new therapeutic targets by disrupting PPIs. Major advances in docking simulations and models in recent years have yielded to be effective in more accurately identifying peptide-protein interactions. Although peptide-based PPI drug discovery does have its challenges, such as limited bioavailability and solubility of peptides, this emerging field highlights potentially exciting advances in computationally aided protein–protein interaction based discovery techniques with the use of interfering peptides (Lee et al., 2019).

Currently, only 10–14% of the human proteome is considered to be “druggable”, and most targets with published leads are in the rhodopsin-like GPCR family, with a smaller number in cation channels and protein kinases (Hopkins & Groom, 2002; López-Cortés et al., 2019). Druggability is the ability for a drug to bind to a specific target. As protein-based drug discovery is a relatively new field compared to traditional drug discovery, more research is needed to identify new hotspots on protein–protein interfaces. Existing studies do computationally identify hotspots on these interfaces, but most of the models developed only attain accuracies of around 70% (Kim, Chivian & Baker, 2004; Tuncbag, Keskin & Gursoy, 2010). Moreover, many studies do not effectively integrate information relating to amino acid chains and other structural information relating to the complex/interface, and/or have completely different approaches to predict the likelihood of hotspots on a particular interface.

For example, molecular dynamics (MD) simulations have been used to elucidate the mechanisms of protein interactions and their viability for drug discovery. This strategy has mixed results however—although the approach of molecular dynamics simulations have relatively high predictive power, these simulations are computationally expensive (Cukuroglu et al., 2014). In contrast, knowledge-based machine learning techniques have the advantage of providing accurate results based on the properties/features of a specific interaction. Machine learning and other statistical approaches allow for a high predictive power of hotspot detection, while being computationally efficient, provided that the features inputted into the model are relevant.

This leads to the proposed research question: “Can the development of a machine learning model lead to the discovery of new druggable targets and new drug-disease associations?” The hypothesis was that the integration of different protein–protein interaction features will lead to promising new hotspots. In addition, new drug-disease associations could potentially be identified from these hotspots to treat deadly diseases such as cancer.

To test this hypothesis, (1) a machine learning model was developed and (2) its ability to integrate multiple features, including structural information, such as that associated with amino-acid chains, to enhance the ability to predict protein–protein interface hotspots was evaluated. In addition, virtual drug screening of a set of hotspots identified by the machine learning model developed herein was performed in order to identify potentially new drug-disease associations. Phase 1 consisted of developing the machine learning model to identify potential protein–protein interface hotspots that could be viable as a drug target, using the cancer-associated EphB2-ephrinB2 protein complex (PDB code: 1KGY) for illustration. Phase 2 of this project aimed to identify small molecules that could act as inhibitors or disruptors to the hotspots identified for further analysis in Phase 1.

The machine learning model developed in Phase 1 achieved an area under receiver operating characteristic (AUROC) of 0.842 on the testing set, and identified residues 1122–1126 on this complex as potential hotspot residues. This information was then used to generate a pharmacophore in Phase 2 which identified nine drug candidates to disrupt the EphB2-ephrinB2 complex. Out of these candidates, further literature review identified four drug candidates that could treat diseases that are overexpressed by this complex: cimetidine, idarubicin, pralatrexate, and nadolol. Although nadolol has been relatively unexplored in its potential of treating certain cancers, a drug with a similar chemical makeup, propranolol, has been identified to treat multiple cancers including colon cancer, which is linked to the overexpression of the EphB2-ephrinB2 complex (Pantziarka et al., 2016; Işeri et al., 2014), and thus highlights significant repositioning opportunities for nadolol.

## Section: Methods › Dataset collection and feature aggregation

As a starting point, the dataset and codebase from the SpotOn study (Moreira et al., 2017) were acquired. This study was selected as the starting point for its high effectiveness in identifying potential hotspots that could aid in drug discovery. The SpotOn database already has information regarding amino acid composition, solvent-accessible surface area (SASA) information, position-specific scoring matrices, the number of amino acids at 2.5 and 4.0 Angstrom, the number of nearby hydrophobic residues, the total change in SASA, the number of interfacial residues, pseudo-amino acid composition, and scales-based descriptors of 2D and 3D descriptors from the protr R package (see below) for a total of 881 features.

In order to add more information to this dataset to better aid model prediction, the protr R package (Xiao et al., 2015) was used to add more features related to amino acid composition, dipeptide composition, etc., to the already pre-existing data. Additionally, data related to pair potential, complex/monomer accessible surface area, residue information, amino acid information, etc. were extracted from the HotPoint database (Tuncbag, Keskin & Gursoy, 2010) and then added to the pre-existing dataset. This data was added to add more information regarding the entire protein complex, as evidenced by most of protr’s features, and to add residue specific features such as pair potential that could improve predictive power. The addition of new features in the protr R package and the HotPoint database led to a total of 2,323 features.

Upon further investigation of the SpotOn dataset, we found that chains I of proteins with PDB code 2FTL, 3SG8, and 1CH0 do not exist as specified in the Protein Data Bank. In the SpotOn study, these chains are specified, and features were derived for these chains; however, in this study, as additional features are added and these chains could not be identified, these chains have been removed from our dataset. This leads to a total of 520 protein residues, lower than SpotOn’s 534 protein residues. A total of 398 residues are labeled as non-hotspots, and 122 residues are labeled as hotspots.

In order to derive features on our prediction dataset with the EphB2-ephrinB2 complex (PDB code: 1KGY), we first downloaded the structure from the Protein Data Bank, and ran this structure through the SpotOn’s codebase/pipeline to collect features specific to the SpotOn study. Then, we sequentially added additional features unique to this study, such as from the protr’s R package and features from the HotPoint database. Missing values are assigned the average value of all non-missing values in a feature.

## Section: Methods › Preprocessing and feature engineering

Similar to the SpotOn study, both the training and testing sets were normalized, and the testing set was normalized using mean and standard deviation of the training set. In addition, before the model was run, data balance had to be accounted for, and oversampling was performed in order to retain the properties of the majority class without sacrificing the information available in this class (More, 2016). SMOTE, or synthetic minority oversampling technique, was performed with k = 5 nearest neighbors (Chawla et al., 2002). To account for multicollinearity, principal component analysis was also performed. This leads to four different combinations: a pipeline without any changes to the training data, a pipeline with only SMOTE applied, a pipeline with only PCA applied, and a pipeline with both SMOTE and PCA applied.

Before the model was trained, the dataset was first subjected to feature engineering. Three existing features that were selected for further exploration are the number of intermolecular contacts within 4.0 Angstroms (#Dist-4.0), the number of hydrophobic contacts (#Hydrophobic), and the pair potential of a specific residue (Pair Potential). We hypothesized that an increase of hydrophobic contacts would cause a decrease in hydrophobic pair potential due to the attractive interaction because of the hydrophobic effect (Israelachvili & Pashley, 1982). As a result, we multiplied both variables and multiplied by −1 to amplify the effects of this association and accounting for the inverse correlation. In addition, we hypothesized that the number of intermolecular contacts will increase the pair potential as this may lead to many body potentials, which are mostly repulsive at short distances (Byggmästar, Granberg & Nordlund, 2018). To model this association, #Dist-4.0 and #Hydrophobic are multiplied to amplify the effects as well. These two new engineered variables were named #Dist-4.0 * Pair Potential and -#Hydrophobic * Pair Potential. This lead to a total of 2,323 features on the training and testing datasets, as well as our dataset containing residue information on the crystal structure of the EphB2-ephrinB2 complex (PDB code: 1KGY).

## Section: Methods › Machine learning model selection

Five different machine learning models were selected in order to evaluate and develop a model: Logistic regression (LR), XGBoost (XGB), a balanced random forest classifier (RF), K Nearest Neighbors (KNN), multilayer perceptron neural network (MLP), and a Gaussian Naïve Bayes (GNB). This data was then split into a training:testing set ratio of 80:20. 10-fold cross validation was performed 10 times on the training set to prevent overfitting. GridSearch was performed in order to identify the best combination of hyperparameters/parameters that could yield the best results. The following hyperparameters/parameters were tested: LR, with C equal to 0.01, 0.1, 1, 10, 50, 100, 500, 1,000, and 5,000; RF with balanced class weight, with the number of estimators equal to 50, 100, 150, 250, 350, 500, and maximum depth of 5, 7, 9, 11; XGB, with a learning rate of 0.001, 0.01, 0.1, the number of estimators as 50, 100, 150, 200, and maximum depth of 4, 5, 6; KNN, with n neighbors of 1, 3, 5, 10, 15, 20; a multilayer perceptron model of hidden_layer_sizes (10, 10, 10), (50, 1), (10, 10), (10, 1), (5, 5), (5, 5, 5) and alpha of 0.0001, 0.0002, 0.0005, 0.001; and GNB with variance smoothing of 1e−8, 1e−7, 1e−6, 1e−5, 1e−4, 1e−3, and 1e−2. The metric used to identify the best model from these sets of parameters on the validation set is AUROC (area under receiver operating characteristic), and this was chosen to compare our models more accurately with the AUROC and receiver-operating characteristic curves provided in SpotOn. Four different run conditions on the four different pipelines was also run and the results are compared. The model(s) with the best run conditions on the highest scoring pre-processing dataset will be used to build an ensemble model, similar to the SpotOn study. If the ensemble model has a higher predictive capability than any individual model, the ensemble model will then be used to predict hotspots on the EphB2-ephrinB2 complex, as this complex has been overexpressed in many cancer cells, most notably in prostate, gastric, colorectal and melanoma cancers (Pasquale, 2010). PyMol was utilized to visualize the hotspots predicted on the EphB2-ephrinB2 complex.

## Section: Methods › Small molecule selection

A cluster of hotspots was identified and LigandScout (Wolber & Langer, 2005) was used to create an apo-site pharmacophore. Virtual screening was then performed on this pharmacophore to identify possible new drug indications. To perform the drug screening, an approved Drugbank (Wishart et al., 2008) database that has a library of all molecules that have molecular weight from 150 to 500 daltons was used. These small molecules were then ranked by the LigandScout software to identify molecules that most strongly conform to the pharmacophore based on the chemical and structural properties of that molecule. The drug-disease associations were then verified with scientific literature to assess the validity and efficacy of the model, and then we identified new drug-disease associations that have not been previously identified by cross-referencing existing scientific literature.

## Section: Methods › Metric calculation

In context, sensitivity is the ability for the model to identify the hotspots and the specificity/recall is the ability for the model to identify the non-hotspots, and both of these statistics are defined as:

Precision is defined as:

F1, MCC, Kappa, and Precision-Recall are all metrics that are robust in dealing with data imbalance. They are defined as:

Kappa=(po−pe)/(1−pe) where po is the probability of agreementassigned to any sample, and pe is the expected/hypothetical probability of chance agreement.

Precision-Recall =∑n⁡(Rn−Rn−1)Pn where Pn and Rn are precision and recall, respectively, at the nth threshold.

All of these calculations are calculated using the Scikit-learn package in Python.

## Section: Results

The “AUROC” column is bolded as to highlight the metric used to select the best pre-processing pipeline. The “SMOTE, PCA” pipeline is the best performing pipeline based on AUROC.

The “AUROC” column is bolded as to highlight the metric used to select the best individual algorithm. The logistic regression algorithm is the best performing model based on AUROC.

The “LG from PCA and SMOTE” column is selected to highlight the metrics from the best performing algorithm from the best performing pipeline from our study.

The “AUROC” column is bolded as to highlight the metric used to select the best ensemble classifier. The logistic regression stacked with logistic regression is the best performing pipeline based on AUROC.

The “Our model” column is bolded as to highlight the results of our model to other models.

Sensitivity analysis of the logistic regression from the SMOTE-only pipeline were performed. Features near the top of the graph have higher feature importances.

Residues 1122–1126 are highlighted as shown in green as surface markers. The rest of the complex is in pink.

Apo site pharmacophore of residues 1122–1126. The gray parts of the grid indicate the levels of buriedness and surface area.

## Section: Results › Phase 1

The average test metrics of each of the six algorithms tested on the four different pre-processing pipelines are shown in Table 1. As the preprocessing pipeline where SMOTE and PCA are applied has the highest AUROC, the top algorithms from this pipeline are used to create an ensemble model.

In Table 2 are the best individual algorithms tested in the SMOTE and PCA pipeline. The best set of hyperparameters were selected using GridSearch as follows: the logistic regression with C = 1,000, the random forest classifier with maximum depth of 5 trees and the total number of estimators at 50 trees, an XGBoost classifier with learning rate 0.1, maximum depth of 5, and 50 estimators, K-nearest neighbors with 5 neighbors, a multi-layer perceptron classifier with alpha as 0.0002 and three layers of 10 neurons each, and a Gaussian Naïve Bayes of variable smoothing of 1e−5. The best performing algorithm in this pipeline is the logistic regression, as it has the highest AUROC.

The results of the Logistic Regression from the SMOTE and PCA pipeline were compared with SpotOn’s highest performing algorithm from the upsampling pre-processing procedure, as shown in Table 3. In order to more aptly analyze the predictive capabilities of our top performing algorithm, we adjusted the threshold to achieve a ≥0.88 specificity, as that is the specificity of the highest performing individual algorithm in SpotOn, and comparing other metrics based on this threshold change. This reduced the AUROC from 0.842, as identified in Table 2, to 0.840, as identified in Table 3, but was still greater than any individual model in SpotOn. Our algorithms perform better to that of SpotOn’s ScaledUp processing step in all six metrics as demonstrated in Table 3.

The top ranking algorithms in the SMOTE and PCA pipeline are used to develop an ensemble classifier to achieve better performance compared to any single algorithm. Different ensemble algorithms are tested: stacking, where a meta-classifier is used to combine the predictive power multiple base classifiers, and voting, a simple ensemble method where each of the six algorithms tested votes on a specific data point, and a simple majority vote is used to predict the classification of that data point as shown in Table 4. In this case, the meta-classifier used during stacking is a Logistic Regression classifier where C = 5. Each individual model is used as a base model separately with the meta-classifier, and all models are combined with the meta-classifier. All ensemble models are run on the SMOTE and PCA pipeline. In the voting ensemble, hard voting was implemented, and all six algorithms are subjected to majority voting. Here, the best performing classifier was the stacking classifier where all models are combined with the meta-classifier. However, the AUROC of this ensemble method is still lower than that of the top individual model, the logistic regression in the SMOTE and PCA pipeline.

A comparison of the accuracy and performance of the model developed herein, shown in bold, compared with SpotOn as shown in Table 5. In our model, the logistic regression was our top performing algorithm, and was thus used to develop to predict hotspots with high accuracies. The SpotOn study (Moreira et al., 2017) was used in order to identify the testing accuracies of the SpotOn study and those of the other studies as well. The other studies that are compared to are SpotOn, SBHD213, Robetta23, KFC2-A24, KFC2-B, and CPORT25 (Kim, Chivian & Baker, 2004; Martins et al., 2014; De Vries & Bonvin, 2011; Zhu & Mitchell, 2011).

The “AUROC” column is bolded as to highlight the metric used to select the best pre-processing pipeline. The “SMOTE, PCA” pipeline is the best performing pipeline based on AUROC.

The “AUROC” column is bolded as to highlight the metric used to select the best individual algorithm. The logistic regression algorithm is the best performing model based on AUROC.

The “LG from PCA and SMOTE” column is selected to highlight the metrics from the best performing algorithm from the best performing pipeline from our study.

The “AUROC” column is bolded as to highlight the metric used to select the best ensemble classifier. The logistic regression stacked with logistic regression is the best performing pipeline based on AUROC.

The “Our model” column is bolded as to highlight the results of our model to other models.

## Section: Results › Phase 2

The top logistic regression algorithm from the SMOTE and PCA pipeline was utilized to predict the hotspots from the EphB2-ephrinB2 complex. This resulted in consecutive residues 1122–1126 predicted as viable hotspots. Drug screening performed on these hotspots results in nine potential small molecules that could bind to this hotspot. The pharmacophore fit scores are provided from our drug screening analysis, where the highest ranked drug also has the highest pharmacophore fit score as shown in Table 6. Extensive literature review was conducted to identify which drugs could aid in treating conditions associated with the EphB2-ephrinB2 complex.

## Section: Results › Phase 1

As the best performing classifier, the logistic regression from the SMOTE and PCA pipeline is subjected to PCA, it is difficult to analyze exactly which features are the most valuable. As a result, in order to identify the most relevant features, sensitivity analysis using Python library Pytolemaic (https://pypi.org/project/pytolemaic/) was performed on the best performing logistic regression classifier from the SMOTE-only pipeline to understand the significance of adding new features to the existing dataset as provided by the SpotOn study. Three out of the top ten features (Relative Complex ASA, Complex ASA, and the engineered features Dist-4.0 * Pair Potential) as identified by Fig. 1 were added in this study exclusively, and highlights the improvement in predictive capabilities of the addition of these features.

PyMol (Schrödinger, 2015) was used to derive and highlight residues 1122–1126 on chain E of the EphB2-ephrinB2 complex. Predicted druggable hotspot residues are shown as more visible surface markers (in green), and the other residues are shown in pink or light red in Fig. 2. Residues 1122–1126 were selected for drug screening as consecutive residues may be used as initial fragments in drug screening (Modell, Blosser & Arora, 2016).

Sensitivity analysis of the logistic regression from the SMOTE-only pipeline were performed. Features near the top of the graph have higher feature importances.

Residues 1122–1126 are highlighted as shown in green as surface markers. The rest of the complex is in pink.

## Section: Results › Phase 2

An apo-site grid, as shown in Fig. 3, was developed and implemented on hotspot residues 1122–1126 as identified via the machine learning model on the EphB2-ephrinB2 complex, where a visual representation of the hotspots on the complex are shown in Fig. 2. This grid was developed by first calculating the pockets of hotspot residues 1122–1126 on LigandScout (Wolber & Langer, 2005).

Figure 4 shows the 26-feature pharmacophore developed using an apo-site grid derived using hotspot residues 1122, 1123, 1124, 1125, and 1126 identified in Fig. 3 via the machine learning model. A pharmacophore identifies the key parts of the molecular features that define the function and shape of a specific ligand, and includes features such as H-bond acceptors and donors, hydrophobic and aromatic rings, etc. This pharmacophore is then used to identify drugs that fit its features. The scoring of this screening procedure follows a pharmacophore-fit scoring function as provided in LigandScout. A maximum number of two features are omitted from this multi-feature pharmacophore to identify small molecule hits, and the best matching conformation is selected.

Cimetidine, currently an acid reflux medication, was identified via virtual screening to potentially bind to the EphB2-ephrinB2 complex associated with cancer cells as shown in Fig. 5. The right image is cimetidine in relation to the 26-feature pharmacophore developed as shown in Fig. 4. A pharmacophore-fit score of 43.86 was achieved during drug screening. Further literature review identified cimetidine as a potential repositioning target for many different types of cancers, including melanoma, gastric, and colorectal cancers (Pantziarka et al., 2014).

Idarubicin, a chemotherapy medication that’s currently used to treat breast cancer, was identified via virtual screening to potentially bind to the EphB2-ephrinB2 complex, where the expression of the complex is associated with cancer cells as shown in Fig. 6. The pharmacophore fit score of this small molecule is 45.46. This drug was also found to treat cancers linked to the EphB2-ephrinB2 complex such as melanoma and leukemia (Martoni et al., 1986; Jabbour et al., 2017). The right image is idarubicin in relation to the pharmacophore developed as shown in Fig. 4.

Pralatrexate, a T-cell lymphoma medication, was identified via virtual screening to potentially bind to the EphB2-ephrinB2 complex, where the expression of the complex is associated with cancer cells as shown in Fig. 7. This small molecule has a pharmacophore fit score of 47.41, and literature review suggests that this drug could potentially treat breast cancer and prostate cancer (Yu, Zhao & Gao, 2018; Serova et al., 2011). Recent research has shown that pralatrexate can treat esophagogastric cancer, which is associated with the various gastrointestinal cancers of the EphB2-ephrinB2 complex (Malhotra et al., 2020). The right image is pralatrexate in relation to the pharmacophore developed as shown in Fig. 4.

Nadolol, a beta blocker, was identified via virtual screening to potentially bind to the EphB2-ephrinB2 complex, where the expression of the complex is associated with cancer cells as shown in Fig. 8. This small molecule has a pharmacophore fit score of 45.97, and literature review suggests that beta blockers could potentially treat a variety of cancers, including breast cancer and pancreatic cancer (Ishida et al., 2016). A close relative of this drug, propranolol, can induce apoptosis in liver cancer cells (Wang et al., 2018). This research suggests nadolol’s potential role in mitigating the effects of other cancers as well. The right image is nadolol in relation to the pharmacophore developed as shown in Fig. 4.

Virtual drug screening identified nine drugs (pralatrexate, chlortetracycline, nadolol, imipenem, idarubicin, valganciclovir, conivaptan, cimetidine, and barnidipine) that bind to the pharmacophore shown in Fig. 4. Further analysis via literature review identified four drug candidates to potentially treat various types of cancers: cimetidine, idarubicin, pralatrexate, and nadolol. Figure 5 shows the possibility for cimetidine, an antacid, to bind with the EphB2-ephrinB2 complex, and scientific literature identified the possibility for this drug to potentially treat melanoma, gastric, and colorectal cancers (Pantziarka et al., 2014). Figure 6 identifies the possibility for idarubicin, a chemotherapy drug used to treat leukemia, to bind with the EphB2-ephrinB2 complex, and literature review identified the possibility for this drug to potentially treat melanoma and leukemia (Martoni et al., 1986; Jabbour et al., 2017). Figure 7 demonstrates the possibility for pralatrexate, a T-cell lymphoma medication to bind to the EphB2-ephrinB2 complex.

Apo site pharmacophore of residues 1122–1126. The gray parts of the grid indicate the levels of buriedness and surface area.

## Section: Discussion

In this article, we presented our development of a machine learning approach for identifying druggable hotspots at protein–protein interfaces. Our algorithm builds on previously existing methods, most notably the SpotOn study. Our approach combines molecular features that have not previously been combined, such as the molecular descriptors used in the SpotOn and HotPoint studies, and additional information related to amino acid composition as provided by the protr module. It applies various machine learning techniques, such as 10-fold cross-validation, feature engineering, and ensembling techniques, including voting and stacking. A logistic regression with C = 1,000 was used in order to achieve an AUROC of 0.842, sensitivity/recall of 0.833, and specificity of 0.850.

In order to find the most optimal pipeline, all four pipelines were run, and the pipeline that used SMOTE and PCA during the pre-processing step was chosen the most optimal pipeline due to its high average AUROC score. The average metrics of all classifiers in each of the pre-processing steps are recorded in Table 1. Furthermore, the results of each top performing classifier in the SMOTE and PCA pre-processing step are illustrated in Table 2. In Table 3, the top metrics of the highest performing algorithm in the most optimal pipeline, the SMOTE and PCA pre-processing pipeline, are compared with the top-performing model in the ScaledUp pre-processing dataset in SpotOn, the highest performing dataset in that study. SpotOn-specific metrics are provided by the study itself. The individual models of our study performed better than the individual models of SpotOn as highlighted in Table 3. After this step, ensemble methods such as stacking and voting were implemented to potentially achieve even better results than any single model. The results of performing this step are shown in Table 4.

Although our models outperform that of SpotOn’s individual models on all metrics, the results of our approach are lower on three out of four metrics than the top performing ensemble model from the SpotOn study, as illustrated in Table 5. This may be due to one of many reasons. Even though there was an increase in the total number of features as compared to the SpotOn study, the slight decrease in the total number of samples could potentially negatively affect predictive performance. Another reason could be that the models tested are not diverse enough from each other to significantly boost performance via ensembling. Two of the models in this study are tree-based methods (random forest and gradient boosting). This seems to be the most plausible explanation for why our top individual model outperformed SpotOn’s top individual model on all metrics, but ensembling techniques did not improve performance. A greater diversity of these models would probably have boosted performance during stacking or voting, as a greater variety of base models have been shown to boost predictive performance (Whalen & Pandey, 2013).

To illustrate our approach, we applied this model to analyze the EphB2-ephrinB2 complex, which has been overexpressed and associated with multiple types of cancer, including prostate, gastric, colorectal and melanoma cancers (Pasquale, 2010). As the overexpression of the EphB2-ephrinB2 complex is associated with these cancers, further analysis for drug discovery could aid in identifying possible new hotspots that potentially aid in drug discovery in the fight against cancer (Barquilla & Pasquale, 2015). In addition, the viability for the EphB2-ephrinB2 complex, and more specifically the EphB2 receptor, for drug discovery has been examined, and it was determined that small molecules could potentially disrupt and/or bind to the ephrin binding pocket (Chrencik et al., 2007; Noberini, Lamberto & Pasquale, 2012).

The effectiveness of introducing new and engineered features was demonstrated by the sensitivity analysis on the logistic regression on the SMOTE-only pipeline (Fig. 1), where three out of the top ten features were added in this study exclusively. Our algorithm identified a set of residue hotspots (Fig. 2), which were then used to generate an apo-site grid and pharmacophore model (Figs. 3 and 4). This model was used to identify drugs with similar characteristics that could be potentially used to modulate the molecular functions of the EphB2-ephrinB2 complex. Table 6 outlines the nine small molecules that passed the drug screening test. Extensive literature review was performed on all nine drugs, and four small molecules were selected their potential efficacy regarding their ability to treat conditions associated with the EphB2-ephrinB2 complex. The identified drugs included compounds already used for cancer treatment, such as pralatrexate, a T-cell lymphoma medication, as well as non-cancer medication; cimetidine, an antacid; and nadolol, a beta blocker that can treat cardiac conditions. Literature review suggests that pralatrexate can potentially treat breast cancer and prostate cancer, and recent literature highlights the possibility for this small molecule to treat other conditions such as cancers of the gastric and esophageal systems (Yu, Zhao & Gao, 2018; Serova et al., 2011; Malhotra et al., 2020). Figure 8 identifies nadolol, a beta blocker that can treat cardiac conditions, as a candidate to bind to the EphB2-ephrinB2 complex. Literature review strongly supports that beta blockers can be repositioned to treat other cancers, such as cancer, and has identified a close relative of nadolol, propranolol, as a potential treatment against multiple cancers, including colon cancer (Işeri et al., 2014).

## Section: Conclusion

The model developed herein in phase one compares favorably with those developed in prior studies and offers enhanced predictive ability for identifying new druggable hotspots, including possible druggable hotspots for cancer-related protein interfaces. The predictive capabilities of the model developed herein are high, offering a high AUROC and overall predictive performance to date. Herein, a logistic regression with C = 1,000 was utilized to successfully identify hotspots.

Phase two of this project aims to identify possible drugs for repositioning. Structural properties of the identified hotspot residues, such as H-bond acceptors and donors, were identified as feature sets to aid in drug development. The efficacy of the model developed herein has been demonstrated through its successful ability to predict drug-disease associations previously identified in literature, including cimetidine, idarubicin, and pralatrexate. Importantly, nadolol has been uniquely identified in this study to potentially treat conditions caused by the overexpression of the EphB2-ephrinB2 complex. This work aims to yield better predictions in terms of hotspot discovery by primarily increasing the sheer amount of data that is available regarding protein–protein interactions. As a consequence, this work has shown that the increases in predictive power as a result of this addition of data.

Possible avenues for future work include drug development using the pharmacophores identified in this study to treat these diseases. Hopefully, by identifying hotspot residues with unparalleled accuracy and identifying possible drug repositioning opportunities, traditional drug development based on these residues and repositioned drugs could yield new and effective treatments for diseases such as cancer. In addition, adding additional novel features and data for hotspot identification, especially those that directly correlate with the extent of how energetically favorable residues are, could further improve model performance. Another avenue for future work would be to streamline the workflow of both phases. Phase one is automated with the help of the machine learning model. However, phase two requires manual input of the hotspot residues as identified in phase one to identify potential drug candidates. A more streamlined process would improve functionality and ease of use.

## Section: Supplemental Information

The individual training and testing metrics of each of algorithms developed and tested per pipeline, and during different ensembling techniques.

Click here for additional data file.

Raw data used to develop the machine learning model. This is built on top of the dataset from the SpotOn study. Features were added from the protr module, the HotPoint study, and through manual feature engineering.

Click here for additional data file.

This code works standing alone.

Click here for additional data file.

## Section: Acknowledgments

I would like to thank the researchers who conducted the SpotOn study, especially Ms. Irina Moreira, for providing the code and existing dataset that this study is built on top of. I would also like to thank Dr. Michael McKelvy of Basha High School for his extensive feedback on my poster and project. In addition, I would like to thank Mr. Thomas Lemker for his assistance in using the LigandScout software.

## Section: Funding Statement

The authors received no funding for this work.

## Section: Associated Data

The individual training and testing metrics of each of algorithms developed and tested per pipeline, and during different ensembling techniques.

Click here for additional data file.

Raw data used to develop the machine learning model. This is built on top of the dataset from the SpotOn study. Features were added from the protr module, the HotPoint study, and through manual feature engineering.

Click here for additional data file.

This code works standing alone.

Click here for additional data file.

## Section: Associated Data › Supplementary Materials

The individual training and testing metrics of each of algorithms developed and tested per pipeline, and during different ensembling techniques.

Click here for additional data file.

Raw data used to develop the machine learning model. This is built on top of the dataset from the SpotOn study. Features were added from the protr module, the HotPoint study, and through manual feature engineering.

Click here for additional data file.

This code works standing alone.

Click here for additional data file.

## Section: Associated Data › Data Availability Statement

The following information was supplied regarding data availability:

All data and code used to produce these results are available as Supplemental Files.

The code for the SpotOn study was obtained from Dr. Irina Moreira and her lab (irina.moreira@cnc.uc.pt) and the data from the HotPoint study is available at http://prism.ccbb.ku.edu.tr/hotpoint.


---

# Discovering the hidden messages within cell trajectories using a deep learning approach for in vitro evaluation of cancer drug treatments

- **Authors:** A Mencattini, D Di Giuseppe, M C Comes, P Casti, F Corsi, F R Bertani, L Ghibelli, L Businaro, C Di Natale, M C Parrini, E Martinelli
- **Issuer:** Scientific reports
- **Type:** Scientific article
- **Published:** 2020-05-06
- **Language:** en
- **DOI:** 10.1038/s41598-020-64246-3
- **Source:** https://pubmed.ncbi.nlm.nih.gov/32376840/
- **Licence:** CC-BY

## Section: Abstract

We describe a novel method to achieve a universal, massive, and fully automated analysis of cell motility behaviours, starting from time-lapse microscopy images. The approach was inspired by the recent successes in application of machine learning for style recognition in paintings and artistic style transfer. The originality of the method relies i) on the generation of atlas from the collection of single-cell trajectories in order to visually encode the multiple descriptors of cell motility, and ii) on the application of pre-trained Deep Learning Convolutional Neural Network architecture in order to extract relevant features to be used for classification tasks from this visual atlas. Validation tests were conducted on two different cell motility scenarios: 1) a 3D biomimetic gels of immune cells, co-cultured with breast cancer cells in organ-on-chip devices, upon treatment with an immunotherapy drug; 2) Petri dishes of clustered prostate cancer cells, upon treatment with a chemotherapy drug. For each scenario, single-cell trajectories are very accurately classified according to the presence or not of the drugs. This original approach demonstrates the existence of universal features in cell motility (a so called “motility style”) which are identified by the DL approach in the rationale of discovering the unknown message in cell trajectories.

## Section: Introduction

Cell motility is fundamental for life, along the entire evolutionary tree, being involved in bacteria collective motion1, in the morphogenesis of pluricellular organisms2, in adult physiological process (such as tissue repair and immune cell trafficking)3 and in some pathologies (such as cancer metastasis)4–7. Nature evolved a variety of cell motility modes, single-cell or collective, mesenchymal or amoeboid, random or directed, etc. Yet, since the driving force of cell motility is always the active reorganization of the cellular cytoskeleton, it is reasonable to assume that some universal principles of cell motility behaviours have been conserved. We applied machine learning approach to explore this hypothesis exploiting Deep Learning (DL) architecture, by presenting a novel tool called Deep Tracking. DL is a recent machine learning framework8 developed on the basis of the human brain machine. DL technique learns how to extract the “style” of an atlas of digital images (like the style from an atlas of an artist’s paintings9,10) in order to represent a given set of pictures in terms of most relevant quantitative descriptors (i.e., features)8. We addressed the question of whether DL could be proficient in extracting the motility styles, i.e. the paintings drawn by cells while moving.

Typically, cell motility experiments use time-lapse microscopy imaging (Fig. 1). Starting from the image stacks (Fig. 1A), video processing methods are used to track cell trajectories (see the description of the Cell Hunter tool11,12 in Steps 2 and 3, Methods section) (Fig. 1B). The first step of our Deep Tracking method relies on the assembly of the individual cell tracks collected for each video (in the range of hundreds) into single images (an atlas), which visually encode a variety of cell motility properties (Fig. 1C). Looking at these motility atlases, like when watching a painting, humans can easily perceive and measure some features, such as the directionality or speed of cell movements; we reasoned that machine learning13 will be able to enormously expand the number of features within the atlases to be used for the recognition of motility styles. The second step of Deep Tracking method exploits DL architecture, by using the widely used pre-trained Convolutional Neural Network, AlexNET14 (see Steps 4 and 5 In Methods section), to extract these “unperceivable-to-humans” features from the visual atlases of each experiment and to use them to classify the cell motility behaviours (Fig. 1D), by implementing the so-called transfer learning15. For validation of the method we choose a problem particularly relevant in cancer research: the pre-clinical in-vitro evaluation of anti-cancer drugs efficacy. We applied Deep Tracking to analyse two motility experiments of cancer cells in presence or not of particular drugs. Further details will be found in Results section.Figure 1A schematic representation of the proposed method. (A) Time-lapse microscopy is used to acquire the video sequence of cells moving in a Petri dish or in an OOC platform. (B) Cells are localized and tracked through the video sequence. (C) For each cell (or cluster of cells) of interest, an atlas of trajectories is collected for the different biological conditions under consideration. (D) Through a pre-trained Deep Learning architecture, i.e., AlexNET, the tool provides a feature representation of each ATLAS in order to perform experiment classification through a predefined taxonomy (e.g., drug vs no-drug).

In the first experiment, breast cancer cells (BT474 cell line, representative of HER2 + breast cancer subtype) were co-cultured in 3D biomimetic gels, within microfluidic devices, with immune cells (PBMCs, peripheral blood mononuclear cells from healthy donors); the addition of an immunotherapy drug, the Trastuzumab (brand name Herceptin), increases cancer-immune cell interactions12.

In the second experiment, prostate cancer cells (PC-3 cell line) were treated or not with a standard chemotherapeutic agent (etoposide); these cells naturally form clusters in 2D Petri dishes and the collective motility behaviours within the clusters are inhibited by the drug16.

For both experiments, Deep Tracking was able to classify the cells (n > 2·103) in the two categories of treated or untreated with an excellent accuracy (91.5% on average), demonstrating that the deep learning approach is very proficient in recognizing the impact of drug treatments on cell motility behaviours.

The performance of the method, despite the difference of the two scenarios in terms of microenvironment and of the biological diversity of cells involved, supports the notion of the existence of universal features in cell motility, encoded in the visual appearance of cell trajectories, which are identified and exploited by Deep Tracking approach. The possible applications of this innovative and robust method are countless; basically, any biomedical problem involving cell motility and video-microscopy could enormously benefit from the here described Deep Tracking approach, which builds a new and solid bridge between cell biology and artificial intelligence.

The proposed approach is framed in an ever more increasing plethora of work in the field of DL architectures and their applications15. DL have demonstrated a clear superiority with respect to existing machine learning approaches across several biomedical and biological fields17–19 producing comparable or higher accuracy than previous optimized methods. As one of the most recent example, method in17 proposes an architecture for improving cell motility discrimination by combining Deep Convolutional and Recurrence Neural Networks. With respect to17, Deep Tracking methodology proposes here many differences with the aim to provide a more effective biology-friendly platform.

First, in the present approach, a cell trajectory is depicted as a 2D image, more adapt for a human-expert visual inspection and understanding than a multichannel time-series approach20. As an immediate consequence, the image-coding used in Deep Tracking approach not only allows to perform 2D convolution (in place of 1D convolution independently applied over each coordinate series), but takes advantage of the possibility to apply pre-trained DL architecture (e.g., AlexNET model), exploiting the strength of pre-training on huge quantities of images and categories. Such a possibility opens the frontiers to a more robust use of transfer learning techniques. Transfer learning has proved that large-scale natural image sets15 are needed for pre-training models that serve as generic feature extractors for various types of biological images. In this regard, deep learning models have been recently used to predict protein subcellular localization for proteins not originally present in a training set21.

In addition, the possibility to use pre-trained net presents many advantages such as that of reducing time-consuming retraining of a new specific net on the new data (or of a part of it), at the risk of overlearning due to a small amount of biological data available. The possibility to use a pre-trained DL allows a high generalizability of the results and support its portability to different biological environment as long as the transferability of features between various closely related and distant learning tasks are investigated and demonstrated.

To overcome, the risk of proposing tailored solutions developed for specific biological tasks, Deep Tracking has been modularly designed allowing the user to embed any tracking tool available (see for example u track or M track plugin in ImageJ tool22) in order to extract trajectories that can be used to generate the atlas for transfer learning. Transfer learning is then used to generate a huge amount of descriptors able to be used in a standard pattern recognition approach (support vector machine) overtaking the question to recover a subset of descriptors in relation to a limited cell behaviour aspect, especially in the rationale of investigating the “unknown message in cell trajectories”.

Another important novelty of Deep Tracking approach relies on avoiding the use of labelled data, a question largely stressed in the review paper15. When DL is used to predict trajectories or to segment cells18, then manually-collected information are required (manually drawn trajectories or segmented cell shapes). Even if in the literature many attempts emerge to solve this drawback by the use of simulated video data of moving cells17, the question remains still debated. In Deep Tracking approach, only the labels of the biological conditions are needed for a subset of experiments (i.e., treated vs untreated), while cell-tracking, image-coding, and transfer learning are entirely performed using an unsupervised method. This means that the algorithms parameters are not tuned according to the label provided by the biologists (treated vs untreated). The only part of the platform that needs the label knowledge is of course the classification task. This approach drastically reduces the effort of experts in favour of an increased usability and usefulness of the platform. Not less relevant, the availability of a large collection of training data needed for DL to learn a novel model is usually hampered by challenges such as local bias, wider standards and legal issues (see discussion in15).

As a further new point of view, Deep Tracking proposes to extend the paradigm of consensus-based collective cell response to the context of biology (see step 6 in Methods section). The underlying assumption is that the response of a given cancer cell to a given treatment can be quantified by aggregating, by a majority voting procedure, the classification results provided by all the pictures of the neighbouring cell tracks (cancer or immune cells according to the experiment). In other words, such a biologically-frames consensus strategy assumes that despite individual cell behaviour that can deviate from expected activity, the majority of cell motility characteristics can be used to demonstrate the unified hidden cancer cell message.

A schematic representation of the proposed method. (A) Time-lapse microscopy is used to acquire the video sequence of cells moving in a Petri dish or in an OOC platform. (B) Cells are localized and tracked through the video sequence. (C) For each cell (or cluster of cells) of interest, an atlas of trajectories is collected for the different biological conditions under consideration. (D) Through a pre-trained Deep Learning architecture, i.e., AlexNET, the tool provides a feature representation of each ATLAS in order to perform experiment classification through a predefined taxonomy (e.g., drug vs no-drug).

## Section: Results

The high generalization capability of Deep Tracking approach is proved in this work by considering two different biological scenarios: breast cancer cell in immune-cancer crosstalk activities (CASE STUDY 1) and prostate cancer cell cultured with chemotherapeutic agents (CASE STUDY2). Generalization is proved by the use of different cell dimension, motility characteristics, and microfluidic environments (OOC vs Petri dishes). The validity of the classification problem is then performed using an experiment-independent testing procedure that can optimally demonstrate the actual generalizability of the approach. The selected testing approach ensures that trajectory pictures coming from the same video are not split between training and testing partition. More specifically, we used a two-fold testing procedure by dividing the videos of each case study in two partitions (in turn used for training and for testing and vice-versa). The same procedure is applied for both the case studies.

Four examples of trajectories of immune cells around a selected cancer cell: (a,b) treated cancer cells and (c,d) untreated cancer cells for CASE STUDY 1. Colours have been used only for the sake of track visualization.

Four examples of trajectories of a cancer cell within a cluster: treated (a,b) and untreated conditions (c,d) for CASE STUDY 2. Colours have been used only for the sake of track visualization.

Description of the two ATLAS compositions.

Classification accuracy values obtained for the two CASE STUDIES: CASE STUDY 1, CASE STUDY 2.

## Section: Results › Atlas preparation and classification task definition

CASE STUDY 1: we investigated the motility of immune cells in the proximity of cancer cells, without and with the drug trastuzumab, during an observation period of 72 hr; immune cells tracks are extracted and used to construct an atlas of images of immune cell tracks. The associated classification task was to evaluate the efficiency of drug treatment by analysing the “attractiveness” of tumor cells. More formally, the classification task is here to recognize experiments with treated cancer cells from experiments with untreated cancer cells by using as a “sentinel” the motility of the immune cells. The reference position here for the atlas construction is the centre of each tumor cell that is manually located. We verified that cancer cells were almost motionless and hence were located only in the first frame without the need of any further preprocessing step (i.e., segmentation, tracking, etc.). The underlying assumptions is that attractiveness of the cancer cell can be quantified by aggregating, by a majority voting procedure, the classification results provided by all the pictures of the immune cell tracks around the same cancer cell. In other words, such a biologically-frames consensus strategy assumes that despite individual immune cell behaviour that can deviate from expected activity, the majority of immune cell motility characteristics determines the general capacity of the tumor cell under the study to attract immune cells. Figure 2 shows some examples of selected cancer cells for (a)-(b) treated case and (c)-(d) untreated condition. Some related immune cells trajectories estimated by Cell Hunter software are also drawn. Colours are used only for the sake of visualization.Figure 2Four examples of trajectories of immune cells around a selected cancer cell: (a,b) treated cancer cells and (c,d) untreated cancer cells for CASE STUDY 1. Colours have been used only for the sake of track visualization.

CASE STUDY 2: we investigated the motility of cancer cells, without and with the administration of the drug etoposide for 6hrs. The classification task was to recognize treated vs untreated cancer cells from their collective behaviour within the same cluster. The geometrical centre of each cluster (computed by combining the geometrical centres of all the tracks localized within) is used as reference point to construct the atlas. The motility of all the cancer cells belonging to the same cluster are jointly analysed. Again, the logic of consensus is used to support the final assessment of the whole cluster as treated or untreated, by aggregating the classification results provided by all the pictures of the cancer cell tracks within the same cluster. In other word, the crucial assumption embedded in the proposed model is the diverse role of cells according to the position in the clusters23. Cells belonging to the core seem to be less representative in motility variation effects than cells on the cluster rim, probably due also to confinement effects. This ability overcomes the less general assumption of cell-based drug effect isotropy (e.g., should all cells have been influenced by the same amount of drug in exactly the same manner?) that is directly connected to the assumed presence of diverse cell-roles (leader/follower) in collective migration24. Figure 3 shows some examples of selected cluster of cancer cells for (a)-(b) treated case with etoposide 50μM and (c)-(d) untreated condition. Some related immune cells trajectories estimated by Cell Hunter software are also drawn. Colours are used only for the sake of visualization.Figure 3Four examples of trajectories of a cancer cell within a cluster: treated (a,b) and untreated conditions (c,d) for CASE STUDY 2. Colours have been used only for the sake of track visualization.

Four examples of trajectories of immune cells around a selected cancer cell: (a,b) treated cancer cells and (c,d) untreated cancer cells for CASE STUDY 1. Colours have been used only for the sake of track visualization.

Four examples of trajectories of a cancer cell within a cluster: treated (a,b) and untreated conditions (c,d) for CASE STUDY 2. Colours have been used only for the sake of track visualization.

## Section: Results › Accurate classification of cancer drug treatment effects

CASE-STUDY 1. In the first test, 12 different videos have been acquired as shown in Table 1a. In particular, VID1-VID6 belong to a first experiment while VID7-VID12 belong to a replicated experiment as highlighted by shaded green and yellow colours. Out of the videos, VID1, VID3, and VID5 (the same for VID7, VID9, and VID11) refer to the control case (without drug) while VID2, VID4, and VID6 (the same for VID8, VID10, and VID12) refer to the treated case (with drug). The number of the videos analysed increases the robustness and the generalizability of the method.Table 1Description of the two ATLAS compositions.EXPERIMENT 1EXPERIMENT 2VID1VID2VID3VID4VID5VID6VID7VID8VID9VID10VID11VID12CASE STUDY 1 (ATLAS 1)Treatment−+−+−+−+−+−+N. tumor Cells101010101010101010101010N. tracks200200200200200200200200200200200200Total tracks2400VID1VID2VID3VID4VID5VID6VID7CASE STUDY 2 (ATLAS2)Treatment+−−++++N. clusters95998811N. tracks394515431403060Total tracks399VID stands for videos. Case study 1 atlas composition; Case study 2 atlas composition. Bolded videos indicate testing partition for each case study.

For each video, 10 cancer cells are manually identified for a total number of 120 cells (Table 1, Case study, 1 fifth row). In the neighbourhood of each cancer cell, immune cells are tracked and trajectories are used for the analysis (200 tracks around each cancer cell for a total number of tracks of 2400, Table 1, Case study 1, sixth row).

As mentioned before, two-fold testing has been applied in order to perform system assessment (yellow vs green shaded videos). Table 2 (Case study 1) lists the accuracy values (average and individual values obtained in each turn of the two-fold validation, calculated only on the testing partitions). Three approaches are compared, i.e., single cell analysis (no majority voting) (column 1), majority voting computed over the tracks around the same cancer cell (column 2), and majority voting applied over all the tracks in the same video (column 3).Table 2Classification accuracy values obtained for the two CASE STUDIES: CASE STUDY 1, CASE STUDY 2.Accuracy ValuesSingle-cell analysisTumor-cell microenvironment analysis (majority voting)Video-level analysis (majority voting)Case Study 1Deep TrackingTraining80% (78%–82%)96% (95%–97%)100%Test68% (67%–69%)91% (86%–96%)100%Case Study 2Deep TrackingAccuracyValuesSingle-cell analysisCluster-level analysis (majority voting)Video-level analysis (majority voting)Training88% (87%–89%)96% (94%–98%)100%Test82% (78%–85%)92% (88%–95%)100%Diverse consensus levels have been considered. First column indicates single-cell analysis with no-consensus; second column indicates tumor-cell environment analysis where consensus by majority voting is performed over all the immune cells tracks in the neighbourhood of the same cancer cell (case study 1) or cancer cells tracks belonging to the same cluster (case study 2); third column indicates that majority voting has been performed at the video level by combining all the tracks within the same video. Balanced accuracy has been evaluated for all the situations to account for samples unbalance. The accuracy values within the brackets indicate the results obtained in each turn of the two-fold testing procedure. The average accuracy values are also reported.

Recognition accuracy is clearly improved after majority voting (second and third columns) indicating that the majority of trajectories around a given treated tumor cell has been recognized as significantly different from trajectories collected in the neighbourhood of untreated cancer cells. First of all, the result gives evidence of the fact there is an evident difference in immune cell motility approaching cancer cell in presence of drug, opening a new era for cell-motility based biosensors. Second, results obtained using a majority voting procedure demonstrate the fact that there is a dominant motility behaviour in immune cells around a cancer cells in presence of drug that can be exploited to evaluate increased cancer cell attractiveness in immunotherapy.

CASE-STUDY 2. In a second test, seven different videos were considered and divided into two partitions as indicated by the shaded green and yellow colours in Table 1b. In particular, VID2 and VID3 refer to the control case (without drug) whereas VID1 and VID4-VID7 refer to the treated case where a block replication drug was administered to the cancer cells with the aim to progressively reduce/stop cancer cell replication process. After plating in a Petri dish, cancer cells tend to cluster in a way that depends to drug administered. The number of clusters localized by Deep Tracking in each video are listed in Table 1 (Case study 2 total number of clusters equal to 59) along with the total number of tracks automatically extracted in each video (total number of tracks analysed equal to 399). Again, Deep Tracking is used to transform the atlas of the trajectories into numerical features and then an SVM classifier is trained using the two-fold testing strategy highlighted in colours in Table 1 (case study 2). Consensus aggregation is then applied to the labels assigned to the trajectories in the same cluster or to the trajectories within the same video.

Table 2 (case study 2) lists the accuracy values obtained in this case study. As above, average and individual accuracy values obtained in each turn are listed. As demonstrated in case study 1, majority voting is crucial in order to extract the dominant behaviour of the cells belonging to the cluster. Results indicated in columns 2 and 3 demonstrate that, more that individual cell motility, dominant migration characteristics become crucial in highlighting the cell behaviour towards the presence of drug. The high accuracy results obtained demonstrated the strength of the reasoning approach behind Deep Tracking methodology and the flexibility to be applied to diversified biological scenarios.

Description of the two ATLAS compositions.

Classification accuracy values obtained for the two CASE STUDIES: CASE STUDY 1, CASE STUDY 2.

## Section: Discussion

As a further demonstration of the effectiveness of the proposed approach with respect to the state of the art methodologies, we include direct comparison with alternative 1D convolutional deep learning methods (17), later Method A, as well as with classifiers using basic trajectory features, later Method B (see Methods). For the sake of comparison, we considered all the data included in the present manuscript, i.e., Case study 1 and 2. Table 3 summarizes the accuracy values obtained by the two comparative methods in the same three conditions as above in Table 2.Table 3Classification accuracy values obtained for the two CASE STUDIES (CASE STUDY 1, CASE STUDY 2) by applying METHOD A (time series analysis by 1D Deep Learning strategy as that described in17) and METHOD B (classifiers using basic trajectory features).ACCURACY VALUESSingle-cell analysisTumor-cell microenvironment analysis (majority voting)Video-level analysis (majority voting)CASE STUDY 1METHOD A59% (55–62%)59% (55–62%)59% (50–67%)METHOD B64% (60–70%)79% (70–87%)75% (67–83%)ACCURACY VALUESSingle-cell analysisCluster-level analysis (majority voting)Video-level analysis (majority voting)CASE STUDY 2METHOD A55% (54–56%)55% (46–63%)71% (67–75%)METHOD B65% (63– 66%)70% (68–72%)71% (67–75%)The three diverse consensus levels of Tab. 2 have been considered. First column indicates single-cell classification results with no-consensus; second column indicates tumor-cell environment analysis where consensus by majority voting is performed over all the immune cells tracks in the neighbourhood of the same cancer cell (case study 1) or cancer cells tracks belonging to the same cluster (case study 2); third column indicates that majority voting has been performed at the video level by combining the prediction of all the tracks within the same video. Balanced accuracy has been evaluated for all the situations to account for samples unbalance. The accuracy values within the brackets indicate the results obtained in each turn of the two-fold validation procedure. The average accuracy values are also reported.

As expected, the state of the art approaches reach very low performance with respect to the proposed method. This is due to the fact they use limited information about the input data such as 1D time series of coordinate or low-level trajectory statistics. More specifically, Regarding Method A, one serious limitation (originated by the 1D Deep Learning input fixed dimension) is related to the necessity to equalize the trajectory lengths of all the tracks involved. This is a problem already raised in25 for tracks comparison for which the solution of dummy points has been proposed. A dummy point is a point of the track artificially created and added to the track with the goal to extend the track length to a prefixed duration, typically the entire duration of the experiment. In our case, dummy points were added at the beginning and/or at the end of the track in order to have all the tracks starting at the first frame and ending at the last frame. After the revision of the commonly used approaches (e.g., zero-padding vs point repetition) we decided to replicate the initial and the last position of the track so to avoid abrupt changes of cell position during the video sequence). It is straightforward to note that the addition of such points affects the results obtained as demonstrated by the low accuracy values reported in Table 3. The effect is critical especially for Case study 1 when the observation time (72 hr) is much larger than the average duration of the trajectories (average 23 hr – std 17 hr, see Fig. 4).Figure 4Distribution of track length for (a) Case Study 1 and (b) Case Study 2. The dashed red line indicates the observation time (a) 72 hr and (b) 6 hr.

On the other hand, for long biological experiments (up to some days), phenomena such as apoptosis (i.e., cell-death), mitosis (cell replication), or simply cell entering and exiting from the field of view, it is frequent to have heterogeneous track lengths. One of the strengths of Deep Tracking is that the 2D representation of a track allows us to overcome such an aspect and to treat all the tracks in the same way without altering their content.

In addition to this, the length heterogeneity demonstrates also the potential application of Deep Tracking to diverse biological scenario. Figure 4 shows the distribution of track length in the two Cases. The red lines set the observation time. It can be observed that especially in Case study 1, there is a large dispersion of track length in the range of 72 hr with an average length of 23 hr. This fact means that Deep Tracking is robust to length diversity, confuting the fact that the length of the trajectory can be a predictor itself.

The main limitation of Method B is the difficulty to determine which low-level features will be predictive of a certain phenotype and may allow the automatic discrimination of biological phenomena. This is due to the fact that specific kinematics features may be related to a very particular phenomena leading to an application-oriented scenario. For this reason, a method to determine relevant features at a high-level (i.e., those obtained by DL strategy) for a given classification task is therefore crucial.

The new approach proposed by Deep Tracking overtakes the limitations of very specific kind of analysis by providing a tool that can be applied to very diversified scenarios and a DL model able to directly use the visual representation of what is under the microscope in order to reveal the hidden messages that cell trajectories carry on during the experiment.

To conclude, first of all, we proved that the appearance of cell trajectories itself conveys the information of the underlying biological phenomenon (drug administration, block replication effects, and so on), instead of detailed features extracted from the motility and the morphology of cells during the video sequences, as widely discussed before.

Secondly, the collaborative task represented by the combined activities of immune cells in the neighbourhood of cancer cells or of multitude of cancer cells within the same cluster can be effectively evaluated by computing the majority of the responses of all the agents within the collectivity. To this regard, we demonstrated that the majority of the responses is more reliable than simply averaging the responses of a synergic group of cells.

Classification accuracy values obtained for the two CASE STUDIES (CASE STUDY 1, CASE STUDY 2) by applying METHOD A (time series analysis by 1D Deep Learning strategy as that described in17) and METHOD B (classifiers using basic trajectory features).

Distribution of track length for (a) Case Study 1 and (b) Case Study 2. The dashed red line indicates the observation time (a) 72 hr and (b) 6 hr.

## Section: Methods

The software that we have developed for this kind of analysis and the detailed results are described in the following sections.

Step1. Video acquisition. Time-lapse microscopy generates a video sequence of the motile cells in the context of the experimental environment. Video sequence is composed by a series of sequential images each related to a static picture of the environment. Time-resolution (or frame rate) refers to the time-lag between two consecutive frames and pixel resolution refers to the equivalent dimension of an image pixel that is therefore the smallest amount of information distinguishable in the digital image. Typical time-resolution in cell-microscopy is within the [1,4] min range and pixel resolution is within [0.5-2]μm. Such parameters are crucial for reliable cell motility understanding. In the considered experiments, we have considered time-resolution of 1 and 2 min12,26 and pixel resolution of 0.66 and 0.64 μm12,26, for case study 1 and 2, respectively (see Results section).

Step2. Cell localization. Cells have to be localized within each frame and, in case of multi-population (e.g., the case of immune and cancer cells in the same microenvironment), different cell types have to be distinguished in an automatic way. Cells can be located using free available segmentation tools (e.g., ImageJ software22) or dedicated proprietary software. In our experiments, we developed a specific software for the task called Cell Hunter, whose mathematical details can be found in12,27. Cell Hunter includes the segmentation of circular-shaped objects using Circular Hough Transform28 with radius tolerance tuned according to a pre-estimation of cell radius for different populations, e.g. cancer cell radius about three times peripheral blood mononuclear cell (PBMC) radius. The position of each cell is hence coded into coordinates (x,y) and radius r for each time frame.

Step3. Cell tracking. Cells localized in a frame have to be linked to cells located in the next frame. The need to simultaneously link all the cells located forced us to solve an Optimal Sub-pattern Assignment Problem using the Munkres algorithm29 yielding the globally best possible pairing among located objects based on a given assignment cost. According to previous studies30, it is reasonable to assume cells motion to be a random walk with time-varying drift and volatility. Let us indicate with \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$(x(t),y(t))$$\end{document}(x(t),y(t)) the coordinate of a given cell at time t, then we may indicate the displacement in each direction at time t + 1 as1\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\{\begin{array}{c}\triangle x(t)=x(t+1)-x(t)={\mu }_{x}(t)+{\sigma }_{x}(t)\bullet w(t)\\ \triangle y(t)=y(t+1)-y(t)={\mu }_{y}(t)+{\sigma }_{y}(t)\bullet w(t)\end{array}$$\end{document}{∆x(t)=x(t+1)−x(t)=μx(t)+σx(t)∙w(t)∆y(t)=y(t+1)−y(t)=μy(t)+σy(t)∙w(t)where \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$w(t)$$\end{document}w(t) is a White Random Process, \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${\mu }_{x}(t)$$\end{document}μx(t) and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${\mu }_{y}(t)$$\end{document}μy(t) are two independent time-varying drift terms, while \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${\sigma }_{x}(t)$$\end{document}σx(t) and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${\sigma }_{y}(t)$$\end{document}σy(t) are two independent time varying volatility terms. Drift terms indicate the displacement in the 2D domain of the cell from a position to the next one, while the volatility is related to the dispersion of the displacement of the cell at each movement. It is straightforward to demonstrate that drift and square volatility parameters are the expected value and the expected variance of random displacement \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\triangle x(t)$$\end{document}∆x(t) and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\triangle y(t)$$\end{document}∆y(t) respectively. Assuming local ergodicity of processes \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\triangle x(t)$$\end{document}∆x(t) and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\triangle y(t)$$\end{document}∆y(t) in a limited time interval T, we then provide estimates for \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${\mu }_{x}(t)$$\end{document}μx(t), \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${\mu }_{y}(t)$$\end{document}μy(t), \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${\sigma }_{x}^{2}(t)$$\end{document}σx2(t), and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${\sigma }_{y}^{2}(t)$$\end{document}σy2(t) as follows:\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${\hat{\mu }}_{x}(t)=\frac{1}{T}\mathop{\sum }\limits_{s=t-T}^{t}\triangle x(s){\hat{\mu }}_{y}(t)=\frac{1}{T}\mathop{\sum }\limits_{s=t-T}^{t}\triangle y(s)$$\end{document}μˆx(t)=1T∑s=t−Tt∆x(s)μˆy(t)=1T∑s=t−Tt∆y(s)2\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${\hat{\sigma }}_{x}^{2}(t)=\frac{1}{T}\mathop{\sum }\limits_{s=t-T}^{t}{(\triangle x(s)-{\hat{\mu }}_{x}(s))}^{2}{\hat{\sigma }}_{y}^{2}(t)=\frac{1}{T}\mathop{\sum }\limits_{s=t-T}^{t}{(\triangle y(s)-{\hat{\mu }}_{y}(s))}^{2}$$\end{document}σˆx2(t)=1T∑s=t−Tt(∆x(s)−μˆx(s))2σˆy2(t)=1T∑s=t−Tt(∆y(s)−μˆy(s))2

Moreover, assuming independence between displacements \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\triangle x(t)$$\end{document}∆x(t) and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\triangle y(t)$$\end{document}∆y(t), the joint probability density function of the two random processes \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\triangle x(t)$$\end{document}∆x(t) and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\triangle y(t)$$\end{document}∆y(t) is given by3\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${f}_{{xy}}(\triangle x(t),\triangle y(t))=\frac{1}{2\pi {\hat{\sigma }}_{x}(t){\hat{\sigma }}_{y}(t)}{e}^{-\left(\frac{{(\triangle x(t)-{\hat{\mu }}_{x}(t))}^{2}}{2{\hat{\sigma }}_{x}^{2}(t)}+\frac{{(\triangle y(t)-{\hat{\mu }}_{y}(t))}^{2}}{2{\hat{\sigma }}_{y}^{2}(t)}\right)}$$\end{document}fxy(∆x(t),∆y(t))=12πσˆx(t)σˆy(t)e−(∆x(t)−μˆx(t))22σˆx2(t)+(∆y(t)−μˆy(t))22σˆy2(t)

Therefore, the cost matrix for solving the assignment problem includes at position \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$(n,m)$$\end{document}(n,m) the inverse of the probability (given by Eq. 3) that cell numbered as \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$n$$\end{document}n in frame \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$i$$\end{document}i has moved to the position occupied by cell numbered as \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$m$$\end{document}m in frame \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$i+1$$\end{document}i+1. Hence, the minimum cost is equivalent to the maximum overall probability of assignment. The tracking step produces a given number of tracks for each cell population.

Step4. Construction of the atlas of trajectories. Each track is coded as \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$(t,x(t),y(t))$$\end{document}(t,x(t),y(t))31. Provided a reference point \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$({x}_{c},{y}_{c})$$\end{document}(xc,yc) then we construct a 2D visual representation of the track by marking to 1 each pixel located at \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$({x(t)-x}_{c},{y(t)-y}_{c})$$\end{document}(x(t)−xc,y(t)−yc) within a given region size around the reference point. In this way, each track position is referred to a given location of interest that depends on the biological experiment under study (e.g., geometrical center of the track itself, geometrical center of all the tracks within a cluster, geometrical centre of tumor cell track for interaction studies, etc.).

The black and white representation of the single track (also named binary image or BW image in the image processing lexicon) produces a 2D projection of the track along time. An image with a singleton white marker denotes a stopped cell, as well as a linear pattern on the image denotes a drift motility, etc. Computer simulations allows to repeat the procedure for thousands of cells in a few seconds, thus enormously increasing the human capability of recording cells simultaneously moving in the environment. After applying the visual coding to all the tracks of the experiments of interest, a so-called visual atlas of trajectories is constructed.

Figure 5 shows some examples of atlases for two different cluster of cells in CASE STUDY 2. Cluster in (a) belongs to an untreated case and cluster in (b) relates to a treated case with 50μM of etoposide. Colours are used only for the sake of visualization, since pictures of trajectories are represented by black & white images.Figure 5Examples of atlases of trajectory pictures for CASE STUDY 2. (a) Cluster of untreated cancer cells. (b) Cluster of treated cancer cells with etoposide agent 50μM. Colours are used only for the sake of visualization, since pictures of trajectories are represented by black & white images.

Step5. Feature extraction (by CNN network). On the inspiration of the image style transfer25, we consider here a pre-trained DL architecture based on Convolutional Neural Network (CNN), that was used in competition ImageNet Large Scale Visual Recognition Challenge14. AlexNET has been trained on 15 M labelled images on more than 22 K categories. AlexNET allows to extract the style of the atlas by mapping the images into a set of descriptors that best represent the general core of the atlas (this procedure is also referred as Transfer Learning). Such descriptors may be used for different classification tasks in order to discriminate the biological behaviours of interest for the cells under observation. To assure more versatility to the method, we avoided a further fine retuning of the AlexNET architecture that would lead to the risk of overlearning phenomena. In the present work, we selected the pool2 layer (layer 9 in the AlexNET architecture) in which resulting features for each image are 43264. Most of the features are then reduced by unsupervised feature selection procedure based on the variance criterion (i.e., small feature variability implies rejection). The choice of a specific layer is motivated by the fact that the lower the information content of the image the higher the level for representation, to avoid excessive loss of information due to pooling and dropout procedures.

Step6. Classification task. Machine learning allows biologists to construct models of cell taxonomy according to the analysis performed in specific experimental conditions13,32. Drug efficacy, block of replication effects, apoptosis and/or mitosis rate, cell subtyping, are only a few examples deriving from cell motility studies. In the proposed case studies, features from the inner pooling layer (i.e., pool2) of the pre-trained AlexNET DL-CNN were extracted for the classification task. The kind of the atlas we extract do not motivate to go further in inner layers. We realized that pool2 was optimal to recover local patterns (such as change of direction or linear motion) but at the advantage of a reduction in atlas dimension. Then, Support Vector Machine (SVM) with linear kernel have been implemented. SVM represents a very consolidated machine learning technique, suitable to prevent overfitting problem thanks to the logic of support vectors33. For the aim of model training and testing, treated experiment were labelled as positive (drug administration in OOC microenvironment or in a Petri Dish) while untreated experiments were marked as negative (no drug). For each of the two atlases, we have validated the classification model by a two-fold testing strategy. The dataset of each case study has been divided into two independent experiments (case study 1) or independent set of experiments (case study 2). In turns, one of the two partitions is used to construct the model while the remaining one is used for testing. The two partitions are then exchanged. The average number of correctly classified cancer cells in the two classes (i.e., treated and untreated) in each case study is then computed as accuracy value and reported herein.

Step 7. Consensus aggregation. In a “wisdom of crowd” logic34, consensus based technique can then be used to aggregate results extracted from labelling (treated vs untreated) assigned by the classification model to immune cell trajectories around the same tumor cell (Case study 1) or to cancer cells in the same cluster (Case study 2), respectively. The main rationale behind this way to proceed is related to the awareness that individual cell motility alone cannot be representative of a given phenomenon, whose dynamics can be instead more realistically supported by the majority of cell responses. To apply this logic, for each cancer cell in case study 1 we computed the majority of the labels assigned to the immune cell trajectories in its neighborhood or for a more robust approach the majority of labels assigned to all the immune cell tracks in the entire video. For case study 2, the majority is computed over the labels assigned to the cancer cells in the same cluster to have the dominant behavior of the entire cluster of cells. Again, for a more robust approach, the majority of the labels assigned to all the cancer cell trajectories within the same video is also computed.

Examples of atlases of trajectory pictures for CASE STUDY 2. (a) Cluster of untreated cancer cells. (b) Cluster of treated cancer cells with etoposide agent 50μM. Colours are used only for the sake of visualization, since pictures of trajectories are represented by black & white images.

## Section: Methods › Method for comparative benchmark

To validate the potentialities of the proposed method, we have compared its performances with those obtained with two golden standard methods, called briefly Method A and Method B, for this kind of problem. For the sake of comparison, the same two-fold testing framework is used for both the methods.

Method A combines a Recurrent Neural Network (RNN) with 1D Convolutional Neural Network (CNN) feature extractors in a unique architecture, where ‘1D’ refers to apply CNNs to one-channel time series. If, on the one hand, CNN features extractors provide an unsupervised feature learning, on the other hand, RNN units, such as Long Short-Term Memory (LSTM) units, may capture the temporal dependencies within the input time series. Specifically, in the case under examination, cell trajectories in input may be considered as one-channel time series, disposed in a (time, x/y coordinate) matrix of fixed dimensions, with t as spatial dimension and x/y coordinate as one channel dimension.

Briefly, the CNN-RNN classification architecture is composed by four convolutional layers with one spatial dimension and one channel dimension, followed by an LSTM layer with n = 256 hidden units and two fully-connected layers of 256 and 128 units, respectively, paired with a rectified linear unit activation. The architecture lasts with a fully-connected layer with number of units equal to the number of classes paired with a softmax activation. Refers to17 for more details.

Method B extracts the 28 standard kinematics descriptors proposed in26 for each trajectory and use them within an SVM classifier with linear kernel33 and default setting. The 28 descriptors are obtained by computing statistical moments over the following eight low-level features: tangential speed magnitude, f1, track curvature, f2, angular speed magnitude, f3, turning angle, f4, distance to track centre, f5, average distance from the cancer/cluster centre, f6, diffusion coefficient, f7, and directional persistence, f8. In particular, to account for the variability of features f1- f5 along the track, we derived first, second, third and fourth statistical moments in addition to the Shannon entropy computed along time. Such high-level computation leads to a total of 25 high-level descriptors in addition to the remaining three low-level descriptors, f6–f8. Further mathematical details can be found in26. The main strength of such approach is that it is length-independent and hence allows to analyse trajectories with heterogeneous duration. On the other hand, a unique feature is often unrepresentative of very complex cell behaviour especially in very long observation period.

## Section: Supplementary information

Supplementary Information.

## Section: Supplementary information

Supplementary Information.

Supplementary Information.
